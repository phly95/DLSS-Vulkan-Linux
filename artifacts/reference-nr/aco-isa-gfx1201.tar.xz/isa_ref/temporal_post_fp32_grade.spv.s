BB0:
	s_mov_b32 s14, s1                                           ; be8e0001
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b128 s[16:19], s[14:15], 0x34                        ; f4004407 f8000034
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl1_add_u32 s18, ttmp9, s18                             ; 87121275
	s_lshl1_add_u32 s19, ttmp7, s19                             ; 87131373
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_min_i32 s1, s18, s19                                      ; 89011312
	s_add_co_u32 s16, s16, -1                                   ; 8010c110
	s_add_co_u32 s11, s18, 1                                    ; 800b8112
	s_cmp_ge_i32 s1, 0                                          ; bf038001
	s_mov_b32 s12, src_scc                                      ; be8c00fd
	s_cmp_ge_i32 s16, s11                                       ; bf030b10
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_and_b32 s16, s12, src_scc                                 ; 8b10fd0c
	s_add_co_u32 s17, s17, -1                                   ; 8011c111
	s_add_co_u32 s20, s19, 1                                    ; 80148113
	s_cmp_ge_i32 s17, s20                                       ; bf031411
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s16, s16, src_scc                                 ; 8b10fd10
	s_cbranch_scc0 BB2                                          ; bfa10009
BB1:
	s_load_b32 s1, s[14:15], 0x68                               ; f4000047 f8000068
	s_lshl1_add_u32 s16, s18, 3                                 ; 87108312
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl2_add_u32 s1, s1, -1                                  ; 8781c101
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_ge_i32 s1, s16                                        ; bf031001
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s1, vcc_lo, exec_lo                               ; 8b017e6a
	s_cbranch_scc0 BB5                                          ; bfa10009
BB4:
	s_load_b32 s1, s[14:15], 0x6c                               ; f4000047 f800006c
	s_lshl1_add_u32 s16, s19, 3                                 ; 87108313
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl2_add_u32 s1, s1, -1                                  ; 8781c101
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_ge_i32 s1, s16                                        ; bf031001
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB6                                                ; bfa00001
BB5:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB6:
	v_lshrrev_b32_e32 v1, 4, v0                                 ; 32020084
	s_and_b32 s1, vcc_lo, exec_lo                               ; 8b017e6a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_cbranch_scc0 BB12                                         ; bfa101be
BB7:
	s_mov_b32 s22, s0                                           ; be960000
	s_movk_i32 s23, 0x8000                                      ; b0178000
	s_clause 0x5                                                ; bf850005
	s_load_b32 s1, s[14:15], 0x68                               ; f4000047 f8000068
	s_load_b32 s16, s[14:15], 0x50                              ; f4000407 f8000050
	s_load_b32 s17, s[14:15], 0x5c                              ; f4000447 f800005c
	s_load_b32 s21, s[14:15], 0x74                              ; f4000547 f8000074
	s_load_b128 s[24:27], s[22:23], 0x0                         ; f400460b f8000000
	s_load_b128 s[28:31], s[22:23], 0x40                        ; f400470b f8000040
(invalid instruction)                                        ; d71f0002
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870241
	v_and_b32_e32 v3, 1, v2                                     ; 36060481
	v_bfe_u32 v4, v2, 1, 1                                      ; d6100004 02050302
	v_bfe_u32 v5, v2, 2, 1                                      ; d6100005 02050502
	v_bfe_u32 v2, v2, 3, 1                                      ; d6100002 02050702
	v_add_lshl_u32 v3, s18, v3, 1                               ; d6470003 02060612
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_add_lshl_u32 v5, s19, v5, 1                               ; d6470005 02060a13
	v_add_nc_u32_e32 v3, v3, v4                                 ; 4a060903
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_add_nc_u32_e32 v5, v5, v2                                 ; 4a0a0505
	v_lshrrev_b32_e32 v7, 2, v3                                 ; 320e0682
	v_and_b32_e32 v3, 3, v3                                     ; 36060683
	v_lshrrev_b32_e32 v6, 2, v5                                 ; 320c0a82
	v_and_b32_e32 v5, 3, v5                                     ; 360a0a83
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_and_b32 s16, s16, -4                                      ; 8b10c410
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v6, v1, vcc_lo                        ; 02000306
	v_lshl_add_u32 v5, v5, 2, v3                                ; d6460005 040d0505
	v_lshlrev_b32_e32 v5, 4, v5                                 ; 300a0a84
	v_add_lshl_u32 v6, v6, v7, 9                                ; d6470006 02260f06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_add3_u32 v8, v5, s16, v6                                  ; d6550008 04182105
	v_add3_u32 v6, s16, 0x100, v6                               ; d6550006 0419fe10 00000100
	v_add_nc_u32_e32 v8, v8, v1                                 ; 4a100308
	v_add3_u32 v6, v1, v6, v5                                   ; d6550006 04160d01
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[2:3], v8, s[24:27], null offen            ; c405407c 40803002 00000008
	buffer_load_b64 v[4:5], v6, s[24:27], null offen            ; c405407c 40803004 00000006
	v_add_lshl_u32 v9, s17, v1, 1                               ; d6470009 02060211
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_and_b32_e32 v10, -4, v9                                   ; 361412c4
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[12:15], v10, s[28:31], null offen offset:64 ; c405c07c 4080380c 0000400a
	buffer_load_d16_hi_b16 v11, v9, s[28:31], null offen offset:78 ; c408c07c 4080380b 00004e09
	buffer_load_b128 v[16:19], v10, s[28:31], null offen offset:96 ; c405c07c 40803810 0000600a
	buffer_load_d16_hi_b16 v20, v9, s[28:31], null offen offset:110 ; c408c07c 40803814 00006e09
	v_add_nc_u32_e32 v22, 0x60, v9                              ; 4a2c12ff 00000060
	v_add_nc_u32_e32 v21, 64, v9                                ; 4a2a12c0
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_pk_f32_fp8_e32 v[24:25], v130                         ; 7e30dd82
	v_cvt_pk_f32_fp8_e32 v[6:7], v2                             ; 7e0cdd02
	v_cvt_pk_f32_fp8_e32 v[26:27], v3                           ; 7e34dd03
	v_cvt_pk_f32_fp8_e32 v[2:3], v131                           ; 7e04dd83
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_pk_rtz_f16_f32_e32 v24, v24, v25                      ; 5e303318
	v_cvt_pk_rtz_f16_f32_e32 v6, v6, v7                         ; 5e0c0f06
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_pk_f32_fp8_e32 v[28:29], v5                           ; 7e38dd05
	v_cvt_pk_rtz_f16_f32_e32 v26, v26, v27                      ; 5e34371a
	v_cvt_pk_rtz_f16_f32_e32 v2, v2, v3                         ; 5e040702
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_cvt_pk_rtz_f16_f32_e32 v28, v28, v29                      ; 5e383b1c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_alignbyte_b32 v12, v13, v12, v21                          ; d617000c 0456190d
	v_alignbyte_b32 v13, v14, v13, v21                          ; d617000d 04561b0e
	v_alignbyte_b32 v14, v15, v14, v21                          ; d617000e 04561d0f
	v_alignbyte_b32 v15, v15, v15, v21                          ; d617000f 04561f0f
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_mov_b16_e32 v15.h, v11.h                                  ; 7f1e398b
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_alignbyte_b32 v16, v17, v16, v22                          ; d6170010 045a2111
	v_alignbyte_b32 v17, v18, v17, v22                          ; d6170011 045a2312
	v_alignbyte_b32 v18, v19, v18, v22                          ; d6170012 045a2513
	v_alignbyte_b32 v19, v19, v19, v22                          ; d6170013 045a2713
(invalid instruction)                                        ; cc100006
	v_min_num_f64_e32 v[1:2], v[6:7], v[12:13]                  ; 1a021906
(invalid instruction)                                        ; cc100018
	v_min_num_f64_e32 v[1:2], v[24:25], v[13:14]                ; 1a021b18
	v_cvt_pk_f32_fp8_e32 v[12:13], v4                           ; 7e18dd04
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v19.h, v20.h                                  ; 7f263994
(invalid instruction)                                        ; cc10001a
	v_min_num_f64_e32 v[1:2], v[26:27], v[14:15]                ; 1a021d1a
	s_cmp_eq_i32 s21, 0                                         ; bf008015
(invalid instruction)                                        ; cc100002
	v_min_num_f64_e32 v[1:2], v[2:3], v[15:16]                  ; 1a021f02
	v_cvt_pk_f32_fp8_e32 v[14:15], v132                         ; 7e1cdd84
	v_cvt_pk_f32_fp8_e32 v[4:5], v133                           ; 7e08dd85
(invalid instruction)                                        ; cc10001c
	v_min_num_f64_e32 v[1:2], v[28:29], v[18:19]                ; 1a02251c
	v_cvt_pk_rtz_f16_f32_e32 v12, v12, v13                      ; 5e181b0c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_cvt_pk_rtz_f16_f32_e32 v14, v14, v15                      ; 5e1c1f0e
	v_cvt_pk_rtz_f16_f32_e32 v4, v4, v5                         ; 5e080b04
(invalid instruction)                                        ; cc10000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[16:17]                ; 1a02210c
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; cc10000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[17:18]                ; 1a02230e
(invalid instruction)                                        ; cc100004
	v_min_num_f64_e32 v[1:2], v[4:5], v[19:20]                  ; 1a022704
	s_cbranch_scc0 BB10                                         ; bfa10002
BB8:
	s_load_b32 s21, s[14:15], 0x60                              ; f4000547 f8000060
BB10:
	s_load_b32 s1, s[14:15], 0x54                               ; f4000047 f8000054
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[16:19], v10, s[28:31], null offen        ; c405c07c 40803810 0000000a
	buffer_load_d16_hi_b16 v8, v9, s[28:31], null offen offset:14 ; c408c07c 40803808 00000e09
	buffer_load_b128 v[20:23], v10, s[28:31], null offen offset:32 ; c405c07c 40803814 0000200a
	v_and_b32_e32 v3, 15, v0                                    ; 3606008f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v3, 4, v3                                 ; 30060684
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s16, s19, s21                                     ; 96101513
	s_mul_i32 s21, s20, s21                                     ; 96151514
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s16, s18                                  ; 80101210
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s16, s16, 9                                      ; 84108910
	s_and_b32 s1, s1, -4                                        ; 8b01c401
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s16, 0x100                                ; 8011ff10 00000100
	s_add_co_u32 s22, s16, 0x200                                ; 8016ff10 00000200
	v_add3_u32 v5, v3, s1, s16                                  ; d6550005 00400303
	s_addk_co_i32 s16, 0x300                                    ; b7900300
	s_add_co_u32 s21, s21, s18                                  ; 80151215
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v7, v3, s1, s17                                  ; d6550007 00440303
	v_add3_u32 v10, v3, s1, s22                                 ; d655000a 00580303
	v_add3_u32 v11, v3, s1, s16                                 ; d655000b 00400303
	s_lshl_b32 s21, s21, 9                                      ; 84158915
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	v_add3_u32 v13, v3, s1, s21                                 ; d655000d 00540303
	s_add_co_u32 s23, s21, 0x100                                ; 8017ff15 00000100
	s_add_co_u32 s32, s21, 0x200                                ; 8020ff15 00000200
	s_addk_co_i32 s21, 0x300                                    ; b7950300
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	v_add_nc_u32_e32 v10, v10, v1                               ; 4a14030a
	v_add_nc_u32_e32 v11, v11, v1                               ; 4a16030b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v15, v3, s1, s23                                 ; d655000f 005c0303
	v_add3_u32 v25, v3, s1, s32                                 ; d6550019 00800303
	v_add3_u32 v3, v3, s1, s21                                  ; d6550003 00540303
	v_add_nc_u32_e32 v13, v13, v1                               ; 4a1a030d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add_nc_u32_e32 v15, v15, v1                               ; 4a1e030f
	v_add_nc_u32_e32 v25, v25, v1                               ; 4a320319
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[30:31], v5, s[24:27], null offen          ; c405407c 4080301e 00000005
	buffer_load_b64 v[32:33], v7, s[24:27], null offen          ; c405407c 40803020 00000007
	buffer_load_b64 v[34:35], v10, s[24:27], null offen         ; c405407c 40803022 0000000a
	buffer_load_b64 v[10:11], v11, s[24:27], null offen         ; c405407c 4080300a 0000000b
	buffer_load_b64 v[36:37], v13, s[24:27], null offen         ; c405407c 40803024 0000000d
	buffer_load_b64 v[38:39], v15, s[24:27], null offen         ; c405407c 40803026 0000000f
	buffer_load_b64 v[40:41], v25, s[24:27], null offen         ; c405407c 40803028 00000019
	buffer_load_b64 v[42:43], v3, s[24:27], null offen          ; c405407c 4080302a 00000003
	buffer_load_d16_hi_b16 v29, v9, s[28:31], null offen offset:46 ; c408c07c 4080381d 00002e09
	v_add_nc_u32_e32 v27, 32, v9                                ; 4a3612a0
	v_mov_b32_dpp v44, v6 dpp8:[0,0,2,2,0,0,2,2] fi:1           ; 7e5802ea 48048006
	v_mov_b32_dpp v45, v24 dpp8:[0,0,2,2,0,0,2,2] fi:1          ; 7e5a02ea 48048018
	v_mov_b32_dpp v46, v26 dpp8:[0,0,2,2,0,0,2,2] fi:1          ; 7e5c02ea 4804801a
	v_mov_b32_dpp v47, v2 dpp8:[0,0,2,2,0,0,2,2] fi:1           ; 7e5e02ea 48048002
	v_mov_b32_dpp v48, v12 dpp8:[0,0,2,2,0,0,2,2] fi:1          ; 7e6002ea 4804800c
	v_mov_b32_dpp v49, v14 dpp8:[0,0,2,2,0,0,2,2] fi:1          ; 7e6202ea 4804800e
	v_mov_b32_dpp v50, v28 dpp8:[0,0,2,2,0,0,2,2] fi:1          ; 7e6402ea 4804801c
	v_mov_b32_dpp v51, v4 dpp8:[0,0,2,2,0,0,2,2] fi:1           ; 7e6602ea 48048004
	v_mov_b32_dpp v52, v6 dpp8:[1,1,3,3,1,1,3,3] fi:1           ; 7e6802ea 6c96c906
	v_mov_b32_dpp v53, v24 dpp8:[1,1,3,3,1,1,3,3] fi:1          ; 7e6a02ea 6c96c918
	v_mov_b32_dpp v54, v26 dpp8:[1,1,3,3,1,1,3,3] fi:1          ; 7e6c02ea 6c96c91a
	v_mov_b32_dpp v55, v2 dpp8:[1,1,3,3,1,1,3,3] fi:1           ; 7e6e02ea 6c96c902
	v_mov_b32_dpp v56, v12 dpp8:[1,1,3,3,1,1,3,3] fi:1          ; 7e7002ea 6c96c90c
	v_mov_b32_dpp v57, v14 dpp8:[1,1,3,3,1,1,3,3] fi:1          ; 7e7202ea 6c96c90e
	v_mov_b32_dpp v58, v28 dpp8:[1,1,3,3,1,1,3,3] fi:1          ; 7e7402ea 6c96c91c
	v_mov_b32_dpp v59, v4 dpp8:[1,1,3,3,1,1,3,3] fi:1           ; 7e7602ea 6c96c904
	v_mov_b32_dpp v60, v6 dpp8:[4,4,6,6,4,4,6,6] fi:1           ; 7e7802ea da4da406
	v_mov_b32_dpp v61, v24 dpp8:[4,4,6,6,4,4,6,6] fi:1          ; 7e7a02ea da4da418
	v_mov_b32_dpp v62, v26 dpp8:[4,4,6,6,4,4,6,6] fi:1          ; 7e7c02ea da4da41a
	v_mov_b32_dpp v63, v2 dpp8:[4,4,6,6,4,4,6,6] fi:1           ; 7e7e02ea da4da402
	v_mov_b32_dpp v64, v12 dpp8:[4,4,6,6,4,4,6,6] fi:1          ; 7e8002ea da4da40c
	v_mov_b32_dpp v65, v14 dpp8:[4,4,6,6,4,4,6,6] fi:1          ; 7e8202ea da4da40e
	v_mov_b32_dpp v66, v28 dpp8:[4,4,6,6,4,4,6,6] fi:1          ; 7e8402ea da4da41c
	v_mov_b32_dpp v67, v4 dpp8:[4,4,6,6,4,4,6,6] fi:1           ; 7e8602ea da4da404
	v_mov_b32_dpp v6, v6 dpp8:[5,5,7,7,5,5,7,7] fi:1            ; 7e0c02ea fedfed06
	v_mov_b32_dpp v24, v24 dpp8:[5,5,7,7,5,5,7,7] fi:1          ; 7e3002ea fedfed18
	v_mov_b32_dpp v26, v26 dpp8:[5,5,7,7,5,5,7,7] fi:1          ; 7e3402ea fedfed1a
	v_mov_b32_dpp v2, v2 dpp8:[5,5,7,7,5,5,7,7] fi:1            ; 7e0402ea fedfed02
	v_mov_b32_dpp v12, v12 dpp8:[5,5,7,7,5,5,7,7] fi:1          ; 7e1802ea fedfed0c
	v_mov_b32_dpp v14, v14 dpp8:[5,5,7,7,5,5,7,7] fi:1          ; 7e1c02ea fedfed0e
	v_mov_b32_dpp v28, v28 dpp8:[5,5,7,7,5,5,7,7] fi:1          ; 7e3802ea fedfed1c
	v_mov_b32_dpp v4, v4 dpp8:[5,5,7,7,5,5,7,7] fi:1            ; 7e0802ea fedfed04
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_alignbyte_b32 v16, v17, v16, v9                           ; d6170010 04262111
	v_alignbyte_b32 v17, v18, v17, v9                           ; d6170011 04262312
	v_alignbyte_b32 v18, v19, v18, v9                           ; d6170012 04262513
	v_alignbyte_b32 v19, v19, v19, v9                           ; d6170013 04262713
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_mov_b16_e32 v19.h, v8.h                                   ; 7f263988
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cvt_pk_f32_fp8_e32 v[72:73], v31                          ; 7e90dd1f
	v_cvt_pk_f32_fp8_e32 v[68:69], v30                          ; 7e88dd1e
	v_cvt_pk_f32_fp8_e32 v[70:71], v158                         ; 7e8cdd9e
	v_cvt_pk_f32_fp8_e32 v[30:31], v159                         ; 7e3cdd9f
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_pk_f32_fp8_e32 v[8:9], v32                            ; 7e10dd20
	v_alignbyte_b32 v20, v21, v20, v27                          ; d6170014 046e2915
	v_alignbyte_b32 v21, v22, v21, v27                          ; d6170015 046e2b16
	v_cvt_pk_rtz_f16_f32_e32 v72, v72, v73                      ; 5e909348
	v_cvt_pk_rtz_f16_f32_e32 v68, v68, v69                      ; 5e888b44
	v_alignbyte_b32 v22, v23, v22, v27                          ; d6170016 046e2d17
	v_cvt_pk_rtz_f16_f32_e32 v70, v70, v71                      ; 5e8c8f46
	v_alignbyte_b32 v23, v23, v23, v27                          ; d6170017 046e2f17
	v_cvt_pk_rtz_f16_f32_e32 v30, v30, v31                      ; 5e3c3f1e
	v_cvt_pk_rtz_f16_f32_e32 v8, v8, v9                         ; 5e101308
	v_pk_fmac_f16 v46, v72, v18                                 ; 785c2548
	v_pk_fmac_f16 v44, v68, v16                                 ; 78582144
	v_cvt_pk_f32_fp8_e32 v[68:69], v33                          ; 7e88dd21
	v_pk_fmac_f16 v45, v70, v17                                 ; 785a2346
	v_pk_fmac_f16 v47, v30, v19                                 ; 785e271e
	v_cvt_pk_f32_fp8_e32 v[30:31], v160                         ; 7e3cdda0
	v_cvt_pk_f32_fp8_e32 v[32:33], v161                         ; 7e40dda1
	v_pk_fmac_f16 v48, v8, v20                                  ; 78602908
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_pk_f32_fp8_e32 v[8:9], v34                            ; 7e10dd22
	v_cvt_pk_rtz_f16_f32_e32 v68, v68, v69                      ; 5e888b44
	v_cvt_pk_rtz_f16_f32_e32 v30, v30, v31                      ; 5e3c3f1e
	v_cvt_pk_rtz_f16_f32_e32 v32, v32, v33                      ; 5e404320
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_cvt_pk_rtz_f16_f32_e32 v8, v8, v9                         ; 5e101308
	v_pk_fmac_f16 v50, v68, v22                                 ; 78642d44
	v_pk_fmac_f16 v49, v30, v21                                 ; 78622b1e
	v_pk_fmac_f16 v52, v8, v16                                  ; 78682108
	v_cvt_pk_f32_fp8_e32 v[8:9], v162                           ; 7e10dda2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_pk_rtz_f16_f32_e32 v8, v8, v9                         ; 5e101308
	v_pk_fmac_f16 v53, v8, v17                                  ; 786a2308
	v_cvt_pk_f32_fp8_e32 v[8:9], v35                            ; 7e10dd23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_pk_rtz_f16_f32_e32 v8, v8, v9                         ; 5e101308
	v_pk_fmac_f16 v54, v8, v18                                  ; 786c2508
	v_cvt_pk_f32_fp8_e32 v[8:9], v163                           ; 7e10dda3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_pk_rtz_f16_f32_e32 v8, v8, v9                         ; 5e101308
	v_pk_fmac_f16 v55, v8, v19                                  ; 786e2708
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_pk_f32_fp8_e32 v[8:9], v10                            ; 7e10dd0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_pk_rtz_f16_f32_e32 v8, v8, v9                         ; 5e101308
	v_pk_fmac_f16 v56, v8, v20                                  ; 78702908
	v_cvt_pk_f32_fp8_e32 v[8:9], v138                           ; 7e10dd8a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_pk_rtz_f16_f32_e32 v8, v8, v9                         ; 5e101308
	v_pk_fmac_f16 v57, v8, v21                                  ; 78722b08
	v_cvt_pk_f32_fp8_e32 v[8:9], v11                            ; 7e10dd0b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_pk_rtz_f16_f32_e32 v8, v8, v9                         ; 5e101308
	v_pk_fmac_f16 v58, v8, v22                                  ; 78742d08
	v_cvt_pk_f32_fp8_e32 v[8:9], v139                           ; 7e10dd8b
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_pk_f32_fp8_e32 v[10:11], v36                          ; 7e14dd24
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_cvt_pk_rtz_f16_f32_e32 v8, v8, v9                         ; 5e101308
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
	v_pk_fmac_f16 v60, v10, v16                                 ; 7878210a
	v_cvt_pk_f32_fp8_e32 v[10:11], v164                         ; 7e14dda4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
	v_pk_fmac_f16 v61, v10, v17                                 ; 787a230a
	v_cvt_pk_f32_fp8_e32 v[10:11], v37                          ; 7e14dd25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_pk_f32_fp8_e32 v[30:31], v40                          ; 7e3cdd28
	v_pk_fmac_f16 v62, v10, v18                                 ; 787c250a
	v_cvt_pk_f32_fp8_e32 v[10:11], v165                         ; 7e14dda5
	v_cvt_pk_rtz_f16_f32_e32 v30, v30, v31                      ; 5e3c3f1e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
	v_pk_fmac_f16 v6, v30, v16                                  ; 780c211e
	v_cvt_pk_f32_fp8_e32 v[30:31], v168                         ; 7e3cdda8
	v_pk_fmac_f16 v63, v10, v19                                 ; 787e270a
	v_cvt_pk_f32_fp8_e32 v[10:11], v38                          ; 7e14dd26
	v_cvt_pk_rtz_f16_f32_e32 v30, v30, v31                      ; 5e3c3f1e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
	v_pk_fmac_f16 v24, v30, v17                                 ; 7830231e
	v_cvt_pk_f32_fp8_e32 v[16:17], v41                          ; 7e20dd29
	v_pk_fmac_f16 v64, v10, v20                                 ; 7880290a
	v_cvt_pk_f32_fp8_e32 v[10:11], v166                         ; 7e14dda6
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
	v_pk_fmac_f16 v26, v16, v18                                 ; 78342510
	v_cvt_pk_f32_fp8_e32 v[16:17], v169                         ; 7e20dda9
	v_pk_fmac_f16 v65, v10, v21                                 ; 78822b0a
	v_cvt_pk_f32_fp8_e32 v[10:11], v39                          ; 7e14dd27
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
	v_pk_fmac_f16 v2, v16, v19                                  ; 78042710
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_pk_f32_fp8_e32 v[16:17], v42                          ; 7e20dd2a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v23.h, v29.h                                  ; 7f2e399d
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_pk_fmac_f16 v66, v10, v22                                 ; 78842d0a
	v_cvt_pk_f32_fp8_e32 v[10:11], v167                         ; 7e14dda7
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	v_pk_fmac_f16 v51, v32, v23                                 ; 78662f20
	v_pk_fmac_f16 v59, v8, v23                                  ; 78762f08
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
	v_pk_fmac_f16 v12, v16, v20                                 ; 78182910
	v_cvt_pk_f32_fp8_e32 v[16:17], v170                         ; 7e20ddaa
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_pk_fmac_f16 v67, v10, v23                                 ; 78862f0a
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_pk_fmac_f16 v14, v16, v21                                 ; 781c2b10
	v_cvt_pk_f32_fp8_e32 v[16:17], v43                          ; 7e20dd2b
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_pk_fmac_f16 v28, v16, v22                                 ; 78382d10
	v_cvt_pk_f32_fp8_e32 v[16:17], v171                         ; 7e20ddab
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_pk_fmac_f16 v4, v16, v23                                  ; 78082f10
BB12:
	s_and_not1_b32 s1, exec_lo, vcc_lo                          ; 91016a7e
	s_cbranch_scc0 BB17                                         ; bfa1009b
BB13:
	s_clause 0x1                                                ; bf850001
	s_load_b64 s[16:17], s[14:15], 0x34                         ; f4002407 f8000034
	s_load_b128 s[24:27], s[14:15], 0x68                        ; f4004607 f8000068
	v_and_b32_e32 v3, 3, v0                                     ; 36060083
	v_and_b32_e32 v5, 15, v0                                    ; 360a008f
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_max_i32 s21, s18, 0                                       ; 8a158012
	s_max_i32 s22, s19, 0                                       ; 8a168013
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v7, 2, v5                                 ; 320e0a82
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_add_co_u32 s16, s16, -1                                   ; 8010c110
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s21, s21, s16                                     ; 89151015
	s_add_co_u32 s17, s17, -1                                   ; 8011c111
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v3, s21, 2, v3                               ; d6460003 040d0415
	s_min_i32 s22, s22, s17                                     ; 89161116
	s_lshl2_add_u32 s23, s24, -1                                ; 8797c118
	s_lshl2_add_u32 s25, s25, -1                                ; 8799c119
	s_cmp_eq_i32 s27, 0                                         ; bf00801b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v7, s22, 2, v7                               ; d6460007 041d0416
	v_lshrrev_b32_e32 v3, 1, v3                                 ; 32060681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshrrev_b32_e32 v7, 1, v7                                 ; 320e0e81
	v_min_u32_e32 v3, s23, v3                                   ; 26060617
	v_min_u32_e32 v7, s25, v7                                   ; 260e0e19
	v_lshrrev_b32_e32 v9, 2, v3                                 ; 32120682
	v_and_b32_e32 v3, 3, v3                                     ; 36060683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_lshrrev_b32_e32 v8, 2, v7                                 ; 32100e82
	v_and_b32_e32 v7, 3, v7                                     ; 360e0e83
(invalid instruction)                                        ; d72c0008
	v_cndmask_b32_e32 v0, v8, v24, vcc_lo                       ; 02003108
	v_lshl_add_u32 v7, v7, 2, v3                                ; d6460007 040d0507
	s_cbranch_scc0 BB16                                         ; bfa10002
BB14:
	s_load_b32 s27, s[14:15], 0x60                              ; f40006c7 f8000060
BB16:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x2                                                ; bf850002
	s_load_b128 s[28:31], s[16:17], 0x0                         ; f4004708 f8000000
	s_load_b128 s[32:35], s[16:17], 0x40                        ; f4004808 f8000040
	s_load_b128 s[36:39], s[14:15], 0x50                        ; f4004907 f8000050
	v_add_lshl_u32 v8, v8, v9, 9                                ; d6470008 02261308
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s22, s22, s27                                     ; 96161b16
	s_and_b32 s36, s36, -4                                      ; 8b24c424
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s22, s22, s21                                  ; 80161516
	s_and_b32 s37, s37, -4                                      ; 8b25c425
	v_add_nc_u32_e32 v8, s36, v8                                ; 4a101024
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s22, s22, 9                                      ; 84168916
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s37, s22                                  ; 80251625
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_lshl_add_u32 v7, v7, 4, v8                                ; d6460007 04210907
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v5, v5, 4, s37                               ; d6460005 00950905
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[8:9], v7, s[28:31], null offen            ; c405407c 40803808 00000007
	buffer_load_b64 v[10:11], v5, s[28:31], null offen          ; c405407c 4080380a 00000005
	v_add_lshl_u32 v3, s39, v1, 1                               ; d6470003 02060227
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_and_b32_e32 v5, -4, v3                                    ; 360a06c4
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[16:19], v5, s[32:35], null offen offset:64 ; c405c07c 40804010 00004005
	buffer_load_d16_hi_b16 v7, v3, s[32:35], null offen offset:78 ; c408c07c 40804007 00004e03
	buffer_load_b128 v[20:23], v5, s[32:35], null offen         ; c405c07c 40804014 00000005
	buffer_load_d16_hi_b16 v15, v3, s[32:35], null offen offset:14 ; c408c07c 4080400f 00000e03
	v_add_nc_u32_e32 v13, 64, v3                                ; 4a1a06c0
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_pk_f32_fp8_e32 v[30:31], v8                           ; 7e3cdd08
	v_cvt_pk_f32_fp8_e32 v[32:33], v136                         ; 7e40dd88
	v_cvt_pk_f32_fp8_e32 v[34:35], v9                           ; 7e44dd09
	v_cvt_pk_f32_fp8_e32 v[8:9], v137                           ; 7e10dd89
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_pk_f32_fp8_e32 v[40:41], v11                          ; 7e50dd0b
	v_cvt_pk_f32_fp8_e32 v[38:39], v138                         ; 7e4cdd8a
	v_cvt_pk_f32_fp8_e32 v[36:37], v10                          ; 7e48dd0a
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	v_cvt_pk_rtz_f16_f32_e32 v30, v30, v31                      ; 5e3c3f1e
	v_cvt_pk_rtz_f16_f32_e32 v32, v32, v33                      ; 5e404320
	v_cvt_pk_rtz_f16_f32_e32 v34, v34, v35                      ; 5e444722
	v_cvt_pk_rtz_f16_f32_e32 v8, v8, v9                         ; 5e101308
	v_cvt_pk_rtz_f16_f32_e32 v40, v40, v41                      ; 5e505328
	v_cvt_pk_rtz_f16_f32_e32 v38, v38, v39                      ; 5e4c4f26
	v_cvt_pk_rtz_f16_f32_e32 v36, v36, v37                      ; 5e484b24
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_alignbyte_b32 v16, v17, v16, v13                          ; d6170010 04362111
	v_alignbyte_b32 v17, v18, v17, v13                          ; d6170011 04362312
	v_alignbyte_b32 v18, v19, v18, v13                          ; d6170012 04362513
	v_alignbyte_b32 v19, v19, v19, v13                          ; d6170013 04362713
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_mov_b16_e32 v19.h, v7.h                                   ; 7f263987
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_alignbyte_b32 v20, v21, v20, v3                           ; d6170014 040e2915
	v_alignbyte_b32 v21, v22, v21, v3                           ; d6170015 040e2b16
	v_alignbyte_b32 v22, v23, v22, v3                           ; d6170016 040e2d17
	v_alignbyte_b32 v23, v23, v23, v3                           ; d6170017 040e2f17
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v23.h, v15.h                                  ; 7f2e398f
(invalid instruction)                                        ; cc10002c
	v_min_num_f64_e32 v[1:2], v[30:31], v[16:17]                ; 1a02211e
(invalid instruction)                                        ; cc10002d
	v_min_num_f64_e32 v[1:2], v[32:33], v[17:18]                ; 1a022320
(invalid instruction)                                        ; cc10002e
	v_min_num_f64_e32 v[1:2], v[34:35], v[18:19]                ; 1a022522
(invalid instruction)                                        ; cc10002f
	v_min_num_f64_e32 v[1:2], v[8:9], v[19:20]                  ; 1a022708
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_pk_fmac_f16 v44, v36, v20                                 ; 78582924
	v_pk_fmac_f16 v45, v38, v21                                 ; 785a2b26
	v_pk_fmac_f16 v46, v40, v22                                 ; 785c2d28
	v_pk_fmac_f16 v47, v10, v23                                 ; 785e2f0a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_branch BB18                                               ; bfa00003
BB17:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB18:
	s_cmp_lg_i32 s12, 0                                         ; bf01800c
	s_cbranch_scc0 BB20                                         ; bfa10008
BB19:
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s18, s12                                       ; bf030c12
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s17, -1, 0                                    ; 981180c1
	s_branch BB21                                               ; bfa00002
BB20:
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_mov_b32 s17, -1                                           ; be9100c1
BB21:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 s17, exec_lo, s17                            ; 9111117e
	s_cbranch_scc0 BB23                                         ; bfa10007
BB22:
	s_load_b32 s12, s[14:15], 0x38                              ; f4000307 f8000038
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s19, s12                                       ; bf030c13
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB24                                               ; bfa00001
BB23:
	s_mov_b32 vcc_lo, -1                                        ; beea00c1
BB24:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s12, vcc_lo, exec_lo                              ; 8b0c7e6a
	s_cbranch_scc0 BB30                                         ; bfa1000f
BB25:
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB28                                         ; bfa10009
BB26:
	s_mov_b32 s22, s0                                           ; be960000
	s_movk_i32 s23, 0x8000                                      ; b0178000
	s_load_b128 s[24:27], s[22:23], 0x0                         ; f400460b f8000000
	v_mov_b32_e32 v3, 0                                         ; 7e060280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v3, off, s[24:27], s2                       ; c4060002 00803003 00000000
BB28:
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
BB30:
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_cvt_f32_f16_e32 v3, v172/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0617ac
	v_cvt_f32_f16_e32 v5, v44                                   ; 7e0a172c
	v_cvt_f32_f16_e32 v7, v173/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0e17ad
	v_cvt_f32_f16_e32 v9, v45                                   ; 7e12172d
	v_cvt_f32_f16_e32 v10, v174/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1417ae
	v_cvt_f32_f16_e32 v11, v46                                  ; 7e16172e
	v_cvt_f32_f16_e32 v13, v175/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1a17af
	v_cvt_f32_f16_e32 v15, v47                                  ; 7e1e172f
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                        ; 02020705
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v9, v7, vcc_lo                        ; 02020f09
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v11, v10, vcc_lo                      ; 0202150b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v15, v13, vcc_lo                      ; 02021b0f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cbranch_scc0 BB35                                         ; bfa100a2
BB31:
	s_clause 0x1                                                ; bf850001
	s_load_b64 s[22:23], s[14:15], 0x34                         ; f4002587 f8000034
	s_load_b128 s[24:27], s[14:15], 0x68                        ; f4004607 f8000068
	v_and_b32_e32 v3, 3, v0                                     ; 36060083
	v_and_b32_e32 v5, 15, v0                                    ; 360a008f
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_max_i32 s12, s18, 0                                       ; 8a0c8012
	s_max_i32 s17, s19, 0                                       ; 8a118013
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v7, 2, v5                                 ; 320e0a82
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_add_co_u32 s22, s22, -1                                   ; 8016c116
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s12, s12, s22                                     ; 890c160c
	s_add_co_u32 s23, s23, -1                                   ; 8017c117
	v_lshl_add_u32 v3, s12, 2, v3                               ; d6460003 040d040c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s17, s17, s23                                     ; 89111711
	s_lshl2_add_u32 s21, s24, -1                                ; 8795c118
	s_lshl2_add_u32 s25, s25, -1                                ; 8799c119
	s_cmp_eq_i32 s27, 0                                         ; bf00801b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v7, s17, 2, v7                               ; d6460007 041d0411
	v_lshrrev_b32_e32 v3, 1, v3                                 ; 32060681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshrrev_b32_e32 v7, 1, v7                                 ; 320e0e81
	v_min_u32_e32 v3, s21, v3                                   ; 26060615
	v_min_u32_e32 v7, s25, v7                                   ; 260e0e19
	v_lshrrev_b32_e32 v11, 2, v3                                ; 32160682
	v_and_b32_e32 v3, 3, v3                                     ; 36060683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_lshrrev_b32_e32 v10, 2, v7                                ; 32140e82
	v_and_b32_e32 v7, 3, v7                                     ; 360e0e83
(invalid instruction)                                        ; d72c000a
	v_cndmask_b32_e32 v0, v10, v24, vcc_lo                      ; 0200310a
	v_lshl_add_u32 v7, v7, 2, v3                                ; d6460007 040d0507
	s_cbranch_scc0 BB34                                         ; bfa10002
BB32:
	s_load_b32 s27, s[14:15], 0x60                              ; f40006c7 f8000060
BB34:
	s_mov_b32 s22, s0                                           ; be960000
	s_movk_i32 s23, 0x8000                                      ; b0178000
	s_clause 0x2                                                ; bf850002
	s_load_b128 s[28:31], s[22:23], 0x0                         ; f400470b f8000000
	s_load_b128 s[32:35], s[22:23], 0x40                        ; f400480b f8000040
	s_load_b128 s[36:39], s[14:15], 0x50                        ; f4004907 f8000050
	v_add_lshl_u32 v10, v10, v11, 9                             ; d647000a 0226170a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s17, s17, s27                                     ; 96111b11
	s_and_b32 s36, s36, -4                                      ; 8b24c424
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s17, s12                                  ; 80110c11
	s_and_b32 s37, s37, -4                                      ; 8b25c425
	v_add3_u32 v10, s36, 0x100, v10                             ; d655000a 0429fe24 00000100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s17, s17, 9                                      ; 84118911
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_addk_co_i32 s17, 0x100                                    ; b7910100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870151
	v_lshl_add_u32 v7, v7, 4, v10                               ; d6460007 04290907
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s37, s17                                  ; 80251125
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v5, v5, 4, s37                               ; d6460005 00950905
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d2
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[10:11], v7, s[28:31], null offen          ; c405407c 4080380a 00000007
	buffer_load_b64 v[16:17], v5, s[28:31], null offen          ; c405407c 40803810 00000005
	v_add_lshl_u32 v3, s39, v1, 1                               ; d6470003 02060227
	v_and_b32_e32 v5, -4, v3                                    ; 360a06c4
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[20:23], v5, s[32:35], null offen offset:96 ; c405c07c 40804014 00006005
	buffer_load_d16_hi_b16 v15, v3, s[32:35], null offen offset:110 ; c408c07c 4080400f 00006e03
	buffer_load_b128 v[32:35], v5, s[32:35], null offen offset:32 ; c405c07c 40804020 00002005
	buffer_load_d16_hi_b16 v18, v3, s[32:35], null offen offset:46 ; c408c07c 40804012 00002e03
	v_add_nc_u32_e32 v13, 32, v3                                ; 4a1a06a0
	v_add_nc_u32_e32 v7, 0x60, v3                               ; 4a0e06ff 00000060
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_pk_f32_fp8_e32 v[36:37], v138                         ; 7e48dd8a
	v_cvt_pk_f32_fp8_e32 v[38:39], v11                          ; 7e4cdd0b
	v_cvt_pk_f32_fp8_e32 v[30:31], v10                          ; 7e3cdd0a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_pk_f32_fp8_e32 v[48:49], v17                          ; 7e60dd11
	v_cvt_pk_f32_fp8_e32 v[40:41], v16                          ; 7e50dd10
	v_cvt_pk_rtz_f16_f32_e32 v36, v36, v37                      ; 5e484b24
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	v_cvt_pk_rtz_f16_f32_e32 v38, v38, v39                      ; 5e4c4f26
	v_cvt_pk_rtz_f16_f32_e32 v30, v30, v31                      ; 5e3c3f1e
	v_cvt_pk_f32_fp8_e32 v[42:43], v144                         ; 7e54dd90
	v_cvt_pk_rtz_f16_f32_e32 v48, v48, v49                      ; 5e606330
	v_cvt_pk_f32_fp8_e32 v[16:17], v145                         ; 7e20dd91
	v_cvt_pk_rtz_f16_f32_e32 v40, v40, v41                      ; 5e505328
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
	v_cvt_pk_rtz_f16_f32_e32 v42, v42, v43                      ; 5e54572a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_alignbyte_b32 v20, v21, v20, v7                           ; d6170014 041e2915
	v_alignbyte_b32 v21, v22, v21, v7                           ; d6170015 041e2b16
	v_alignbyte_b32 v22, v23, v22, v7                           ; d6170016 041e2d17
	v_alignbyte_b32 v23, v23, v23, v7                           ; d6170017 041e2f17
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_mov_b16_e32 v23.h, v15.h                                  ; 7f2e398f
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_alignbyte_b32 v32, v33, v32, v13                          ; d6170020 04364121
	v_alignbyte_b32 v33, v34, v33, v13                          ; d6170021 04364322
	v_alignbyte_b32 v34, v35, v34, v13                          ; d6170022 04364523
	v_alignbyte_b32 v35, v35, v35, v13                          ; d6170023 04364723
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v35.h, v18.h                                  ; 7f463992
(invalid instruction)                                        ; cc10001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[20:21]                ; 1a02291e
(invalid instruction)                                        ; cc100031
	v_min_num_f64_e32 v[1:2], v[36:37], v[21:22]                ; 1a022b24
(invalid instruction)                                        ; cc100032
	v_min_num_f64_e32 v[1:2], v[38:39], v[22:23]                ; 1a022d26
(invalid instruction)                                        ; cc100033
	v_min_num_f64_e32 v[1:2], v[10:11], v[23:24]                ; 1a022f0a
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_pk_fmac_f16 v30, v40, v32                                 ; 783c4128
	v_pk_fmac_f16 v49, v42, v33                                 ; 7862432a
	v_pk_fmac_f16 v50, v48, v34                                 ; 78644530
	v_pk_fmac_f16 v51, v16, v35                                 ; 78664710
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_mov_b32_e32 v48, v30                                      ; 7e60031e
	s_branch BB36                                               ; bfa00003
BB35:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB36:
	s_cmp_lg_i32 s16, 0                                         ; bf018010
	s_cbranch_scc0 BB38                                         ; bfa10007
BB37:
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s18, s12                                       ; bf030c12
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s16, -1, 0                                    ; 981080c1
	s_branch BB39                                               ; bfa00001
BB38:
	s_mov_b32 s16, -1                                           ; be9000c1
BB39:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 s16, exec_lo, s16                            ; 9110107e
	s_cbranch_scc0 BB41                                         ; bfa10007
BB40:
	s_load_b32 s12, s[14:15], 0x38                              ; f4000307 f8000038
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s19, s12                                       ; bf030c13
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB42                                               ; bfa00001
BB41:
	s_mov_b32 vcc_lo, -1                                        ; beea00c1
BB42:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s12, vcc_lo, exec_lo                              ; 8b0c7e6a
	s_cbranch_scc0 BB48                                         ; bfa1000f
BB43:
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB46                                         ; bfa10009
BB44:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_load_b128 s[24:27], s[16:17], 0x0                         ; f4004608 f8000000
	v_mov_b32_e32 v3, 0                                         ; 7e060280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v3, off, s[24:27], s2                       ; c4060002 00803003 00000000
BB46:
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
BB48:
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_cvt_f32_f16_e32 v3, v176/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0617b0
	v_cvt_f32_f16_e32 v5, v48                                   ; 7e0a1730
	v_cvt_f32_f16_e32 v7, v177/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0e17b1
	v_cvt_f32_f16_e32 v11, v49                                  ; 7e161731
	v_cvt_f32_f16_e32 v13, v178/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1a17b2
	v_cvt_f32_f16_e32 v15, v50                                  ; 7e1e1732
	v_cvt_f32_f16_e32 v16, v179/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2017b3
	v_cvt_f32_f16_e32 v17, v51                                  ; 7e221733
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                        ; 02020705
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                       ; 02020f0b
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v15, v13, vcc_lo                      ; 02021b0f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v17, v16, vcc_lo                      ; 02022111
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cbranch_scc0 BB53                                         ; bfa1009c
BB49:
	s_clause 0x1                                                ; bf850001
	s_load_b64 s[16:17], s[14:15], 0x34                         ; f4002407 f8000034
	s_load_b128 s[24:27], s[14:15], 0x68                        ; f4004607 f8000068
	v_and_b32_e32 v3, 3, v0                                     ; 36060083
	v_and_b32_e32 v5, 15, v0                                    ; 360a008f
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_max_i32 s12, s11, 0                                       ; 8a0c800b
	s_max_i32 s21, s19, 0                                       ; 8a158013
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v7, 2, v5                                 ; 320e0a82
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_add_co_u32 s16, s16, -1                                   ; 8010c110
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s12, s12, s16                                     ; 890c100c
	s_add_co_u32 s17, s17, -1                                   ; 8011c111
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v3, s12, 2, v3                               ; d6460003 040d040c
	s_min_i32 s21, s21, s17                                     ; 89151115
	s_lshl2_add_u32 s22, s24, -1                                ; 8796c118
	s_lshl2_add_u32 s25, s25, -1                                ; 8799c119
	s_cmp_eq_i32 s27, 0                                         ; bf00801b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v7, s21, 2, v7                               ; d6460007 041d0415
	v_lshrrev_b32_e32 v3, 1, v3                                 ; 32060681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshrrev_b32_e32 v7, 1, v7                                 ; 320e0e81
	v_min_u32_e32 v3, s22, v3                                   ; 26060616
	v_min_u32_e32 v7, s25, v7                                   ; 260e0e19
	v_lshrrev_b32_e32 v15, 2, v3                                ; 321e0682
	v_and_b32_e32 v3, 3, v3                                     ; 36060683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_lshrrev_b32_e32 v13, 2, v7                                ; 321a0e82
	v_and_b32_e32 v7, 3, v7                                     ; 360e0e83
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v13, v24, vcc_lo                      ; 0200310d
	v_lshl_add_u32 v7, v7, 2, v3                                ; d6460007 040d0507
	s_cbranch_scc0 BB52                                         ; bfa10002
BB50:
	s_load_b32 s27, s[14:15], 0x60                              ; f40006c7 f8000060
BB52:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x2                                                ; bf850002
	s_load_b128 s[28:31], s[16:17], 0x0                         ; f4004708 f8000000
	s_load_b128 s[32:35], s[16:17], 0x40                        ; f4004808 f8000040
	s_load_b128 s[36:39], s[14:15], 0x50                        ; f4004907 f8000050
	v_add_lshl_u32 v13, v13, v15, 9                             ; d647000d 02261f0d
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s21, s21, s27                                     ; 96151b15
	s_and_b32 s36, s36, -4                                      ; 8b24c424
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s21, s21, s12                                  ; 80150c15
	s_and_b32 s37, s37, -4                                      ; 8b25c425
	v_add_nc_u32_e32 v13, s36, v13                              ; 4a1a1a24
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s21, s21, 9                                      ; 84158915
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s37, s21                                  ; 80251525
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_lshl_add_u32 v7, v7, 4, v13                               ; d6460007 04350907
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v5, v5, 4, s37                               ; d6460005 00950905
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[16:17], v7, s[28:31], null offen          ; c405407c 40803810 00000007
	buffer_load_b64 v[18:19], v5, s[28:31], null offen          ; c405407c 40803812 00000005
	v_add_lshl_u32 v3, s39, v1, 1                               ; d6470003 02060227
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_and_b32_e32 v5, -4, v3                                    ; 360a06c4
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[20:23], v5, s[32:35], null offen offset:64 ; c405c07c 40804014 00004005
	buffer_load_d16_hi_b16 v7, v3, s[32:35], null offen offset:78 ; c408c07c 40804007 00004e03
	buffer_load_b128 v[32:35], v5, s[32:35], null offen         ; c405c07c 40804020 00000005
	buffer_load_d16_hi_b16 v15, v3, s[32:35], null offen offset:14 ; c408c07c 4080400f 00000e03
	v_add_nc_u32_e32 v13, 64, v3                                ; 4a1a06c0
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_pk_f32_fp8_e32 v[30:31], v16                          ; 7e3cdd10
	v_cvt_pk_f32_fp8_e32 v[38:39], v17                          ; 7e4cdd11
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_pk_f32_fp8_e32 v[40:41], v18                          ; 7e50dd12
	v_cvt_pk_f32_fp8_e32 v[52:53], v19                          ; 7e68dd13
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_pk_rtz_f16_f32_e32 v30, v30, v31                      ; 5e3c3f1e
	v_cvt_pk_f32_fp8_e32 v[36:37], v144                         ; 7e48dd90
	v_cvt_pk_rtz_f16_f32_e32 v38, v38, v39                      ; 5e4c4f26
	v_cvt_pk_rtz_f16_f32_e32 v40, v40, v41                      ; 5e505328
	v_cvt_pk_rtz_f16_f32_e32 v52, v52, v53                      ; 5e686b34
	v_cvt_pk_f32_fp8_e32 v[16:17], v145                         ; 7e20dd91
	v_cvt_pk_f32_fp8_e32 v[42:43], v146                         ; 7e54dd92
	v_cvt_pk_f32_fp8_e32 v[18:19], v147                         ; 7e24dd93
	v_cvt_pk_rtz_f16_f32_e32 v36, v36, v37                      ; 5e484b24
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_alignbyte_b32 v20, v21, v20, v13                          ; d6170014 04362915
	v_alignbyte_b32 v21, v22, v21, v13                          ; d6170015 04362b16
	v_alignbyte_b32 v22, v23, v22, v13                          ; d6170016 04362d17
	v_alignbyte_b32 v23, v23, v23, v13                          ; d6170017 04362f17
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_alignbyte_b32 v32, v33, v32, v3                           ; d6170020 040e4121
	v_alignbyte_b32 v33, v34, v33, v3                           ; d6170021 040e4322
	v_alignbyte_b32 v34, v35, v34, v3                           ; d6170022 040e4523
	v_alignbyte_b32 v35, v35, v35, v3                           ; d6170023 040e4723
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	v_mov_b16_e32 v23.h, v7.h                                   ; 7f2e3987
	v_cvt_pk_rtz_f16_f32_e32 v42, v42, v43                      ; 5e54572a
	v_cvt_pk_rtz_f16_f32_e32 v18, v18, v19                      ; 5e242712
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v35.h, v15.h                                  ; 7f46398f
(invalid instruction)                                        ; cc10001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[20:21]                ; 1a02291e
(invalid instruction)                                        ; cc100035
	v_min_num_f64_e32 v[1:2], v[36:37], v[21:22]                ; 1a022b24
(invalid instruction)                                        ; cc100036
	v_min_num_f64_e32 v[1:2], v[38:39], v[22:23]                ; 1a022d26
(invalid instruction)                                        ; cc100037
	v_min_num_f64_e32 v[1:2], v[16:17], v[23:24]                ; 1a022f10
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_pk_fmac_f16 v30, v40, v32                                 ; 783c4128
	v_pk_fmac_f16 v53, v42, v33                                 ; 786a432a
	v_pk_fmac_f16 v54, v52, v34                                 ; 786c4534
	v_pk_fmac_f16 v55, v18, v35                                 ; 786e4712
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_mov_b32_e32 v52, v30                                      ; 7e68031e
	s_branch BB54                                               ; bfa00003
BB53:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB54:
	s_min_i32 s12, s11, s19                                     ; 890c130b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_i32 s12, 0                                         ; bf03800c
	s_cbranch_scc0 BB56                                         ; bfa10008
BB55:
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s11, s12                                       ; bf030c0b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s17, -1, 0                                    ; 981180c1
	s_branch BB57                                               ; bfa00002
BB56:
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_mov_b32 s17, -1                                           ; be9100c1
BB57:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 s17, exec_lo, s17                            ; 9111117e
	s_cbranch_scc0 BB59                                         ; bfa10007
BB58:
	s_load_b32 s12, s[14:15], 0x38                              ; f4000307 f8000038
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s19, s12                                       ; bf030c13
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB60                                               ; bfa00001
BB59:
	s_mov_b32 vcc_lo, -1                                        ; beea00c1
BB60:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s12, vcc_lo, exec_lo                              ; 8b0c7e6a
	s_cbranch_scc0 BB66                                         ; bfa1000f
BB61:
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB64                                         ; bfa10009
BB62:
	s_mov_b32 s22, s0                                           ; be960000
	s_movk_i32 s23, 0x8000                                      ; b0178000
	s_load_b128 s[24:27], s[22:23], 0x0                         ; f400460b f8000000
	v_mov_b32_e32 v3, 0                                         ; 7e060280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v3, off, s[24:27], s2                       ; c4060002 00803003 00000000
BB64:
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
BB66:
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_cvt_f32_f16_e32 v3, v180/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0617b4
	v_cvt_f32_f16_e32 v5, v52                                   ; 7e0a1734
	v_cvt_f32_f16_e32 v7, v181/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0e17b5
	v_cvt_f32_f16_e32 v13, v53                                  ; 7e1a1735
	v_cvt_f32_f16_e32 v15, v182/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e17b6
	v_cvt_f32_f16_e32 v17, v54                                  ; 7e221736
	v_cvt_f32_f16_e32 v18, v183/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2417b7
	v_cvt_f32_f16_e32 v19, v55                                  ; 7e261737
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                        ; 02020705
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v13, v7, vcc_lo                       ; 02020f0d
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v17, v15, vcc_lo                      ; 02021f11
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v19, v18, vcc_lo                      ; 02022513
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cbranch_scc0 BB71                                         ; bfa100a3
BB67:
	s_clause 0x1                                                ; bf850001
	s_load_b64 s[22:23], s[14:15], 0x34                         ; f4002587 f8000034
	s_load_b128 s[24:27], s[14:15], 0x68                        ; f4004607 f8000068
	v_and_b32_e32 v3, 3, v0                                     ; 36060083
	v_and_b32_e32 v5, 15, v0                                    ; 360a008f
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_max_i32 s12, s11, 0                                       ; 8a0c800b
	s_max_i32 s17, s19, 0                                       ; 8a118013
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v7, 2, v5                                 ; 320e0a82
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_add_co_u32 s22, s22, -1                                   ; 8016c116
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s12, s12, s22                                     ; 890c160c
	s_add_co_u32 s23, s23, -1                                   ; 8017c117
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v3, s12, 2, v3                               ; d6460003 040d040c
	s_min_i32 s17, s17, s23                                     ; 89111711
	s_lshl2_add_u32 s21, s24, -1                                ; 8795c118
	s_lshl2_add_u32 s25, s25, -1                                ; 8799c119
	s_cmp_eq_i32 s27, 0                                         ; bf00801b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v7, s17, 2, v7                               ; d6460007 041d0411
	v_lshrrev_b32_e32 v3, 1, v3                                 ; 32060681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshrrev_b32_e32 v7, 1, v7                                 ; 320e0e81
	v_min_u32_e32 v3, s21, v3                                   ; 26060615
	v_min_u32_e32 v7, s25, v7                                   ; 260e0e19
	v_lshrrev_b32_e32 v15, 2, v3                                ; 321e0682
	v_and_b32_e32 v3, 3, v3                                     ; 36060683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_lshrrev_b32_e32 v13, 2, v7                                ; 321a0e82
	v_and_b32_e32 v7, 3, v7                                     ; 360e0e83
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v13, v24, vcc_lo                      ; 0200310d
	v_lshl_add_u32 v7, v7, 2, v3                                ; d6460007 040d0507
	s_cbranch_scc0 BB70                                         ; bfa10002
BB68:
	s_load_b32 s27, s[14:15], 0x60                              ; f40006c7 f8000060
BB70:
	s_mov_b32 s22, s0                                           ; be960000
	s_movk_i32 s23, 0x8000                                      ; b0178000
	s_clause 0x2                                                ; bf850002
	s_load_b128 s[28:31], s[22:23], 0x0                         ; f400470b f8000000
	s_load_b128 s[32:35], s[22:23], 0x40                        ; f400480b f8000040
	s_load_b128 s[36:39], s[14:15], 0x50                        ; f4004907 f8000050
	v_add_lshl_u32 v13, v13, v15, 9                             ; d647000d 02261f0d
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s17, s17, s27                                     ; 96111b11
	s_and_b32 s36, s36, -4                                      ; 8b24c424
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s17, s12                                  ; 80110c11
	s_and_b32 s37, s37, -4                                      ; 8b25c425
	v_add3_u32 v13, s36, 0x100, v13                             ; d655000d 0435fe24 00000100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s17, s17, 9                                      ; 84118911
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_addk_co_i32 s17, 0x100                                    ; b7910100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870151
	v_lshl_add_u32 v7, v7, 4, v13                               ; d6460007 04350907
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s37, s17                                  ; 80251125
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v5, v5, 4, s37                               ; d6460005 00950905
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d2
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[18:19], v7, s[28:31], null offen          ; c405407c 40803812 00000007
	buffer_load_b64 v[20:21], v5, s[28:31], null offen          ; c405407c 40803814 00000005
	v_add_lshl_u32 v3, s39, v1, 1                               ; d6470003 02060227
	v_and_b32_e32 v5, -4, v3                                    ; 360a06c4
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[32:35], v5, s[32:35], null offen offset:96 ; c405c07c 40804020 00006005
	buffer_load_d16_hi_b16 v15, v3, s[32:35], null offen offset:110 ; c408c07c 4080400f 00006e03
	buffer_load_b128 v[36:39], v5, s[32:35], null offen offset:32 ; c405c07c 40804024 00002005
	buffer_load_d16_hi_b16 v22, v3, s[32:35], null offen offset:46 ; c408c07c 40804016 00002e03
	v_add_nc_u32_e32 v13, 32, v3                                ; 4a1a06a0
	v_add_nc_u32_e32 v7, 0x60, v3                               ; 4a0e06ff 00000060
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_pk_f32_fp8_e32 v[40:41], v146                         ; 7e50dd92
	v_cvt_pk_f32_fp8_e32 v[42:43], v19                          ; 7e54dd13
	v_cvt_pk_f32_fp8_e32 v[30:31], v18                          ; 7e3cdd12
	v_cvt_pk_f32_fp8_e32 v[18:19], v147                         ; 7e24dd93
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_pk_f32_fp8_e32 v[56:57], v20                          ; 7e70dd14
	v_cvt_pk_f32_fp8_e32 v[68:69], v21                          ; 7e88dd15
	v_cvt_pk_f32_fp8_e32 v[58:59], v148                         ; 7e74dd94
	v_cvt_pk_f32_fp8_e32 v[20:21], v149                         ; 7e28dd95
	v_cvt_pk_rtz_f16_f32_e32 v40, v40, v41                      ; 5e505328
	v_cvt_pk_rtz_f16_f32_e32 v42, v42, v43                      ; 5e54572a
	v_cvt_pk_rtz_f16_f32_e32 v30, v30, v31                      ; 5e3c3f1e
	v_cvt_pk_rtz_f16_f32_e32 v18, v18, v19                      ; 5e242712
	v_cvt_pk_rtz_f16_f32_e32 v56, v56, v57                      ; 5e707338
	v_cvt_pk_rtz_f16_f32_e32 v68, v68, v69                      ; 5e888b44
	v_cvt_pk_rtz_f16_f32_e32 v58, v58, v59                      ; 5e74773a
	v_cvt_pk_rtz_f16_f32_e32 v20, v20, v21                      ; 5e282b14
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_alignbyte_b32 v32, v33, v32, v7                           ; d6170020 041e4121
	v_alignbyte_b32 v33, v34, v33, v7                           ; d6170021 041e4322
	v_alignbyte_b32 v34, v35, v34, v7                           ; d6170022 041e4523
	v_alignbyte_b32 v35, v35, v35, v7                           ; d6170023 041e4723
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_mov_b16_e32 v35.h, v15.h                                  ; 7f46398f
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_alignbyte_b32 v36, v37, v36, v13                          ; d6170024 04364925
	v_alignbyte_b32 v37, v38, v37, v13                          ; d6170025 04364b26
	v_alignbyte_b32 v38, v39, v38, v13                          ; d6170026 04364d27
	v_alignbyte_b32 v39, v39, v39, v13                          ; d6170027 04364f27
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v39.h, v22.h                                  ; 7f4e3996
(invalid instruction)                                        ; cc10001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[32:33]                ; 1a02411e
(invalid instruction)                                        ; cc100039
	v_min_num_f64_e32 v[1:2], v[40:41], v[33:34]                ; 1a024328
(invalid instruction)                                        ; cc10002a
	v_min_num_f64_e32 v[1:2], v[42:43], v[34:35]                ; 1a02452a
(invalid instruction)                                        ; cc10003b
	v_min_num_f64_e32 v[1:2], v[18:19], v[35:36]                ; 1a024712
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_pk_fma_f16 v56, v56, v36, v30                             ; cc0e4038 1c7a4938
	v_pk_fmac_f16 v57, v58, v37                                 ; 78724b3a
	v_pk_fma_f16 v58, v68, v38, v42                             ; cc0e403a 1caa4d44
	v_pk_fmac_f16 v59, v20, v39                                 ; 78764f14
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_branch BB72                                               ; bfa00003
BB71:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB72:
	s_cmp_lg_i32 s16, 0                                         ; bf018010
	s_cbranch_scc0 BB74                                         ; bfa10007
BB73:
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s11, s12                                       ; bf030c0b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s16, -1, 0                                    ; 981080c1
	s_branch BB75                                               ; bfa00001
BB74:
	s_mov_b32 s16, -1                                           ; be9000c1
BB75:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 s16, exec_lo, s16                            ; 9110107e
	s_cbranch_scc0 BB77                                         ; bfa10007
BB76:
	s_load_b32 s12, s[14:15], 0x38                              ; f4000307 f8000038
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s19, s12                                       ; bf030c13
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB78                                               ; bfa00001
BB77:
	s_mov_b32 vcc_lo, -1                                        ; beea00c1
BB78:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s12, vcc_lo, exec_lo                              ; 8b0c7e6a
	s_cbranch_scc0 BB84                                         ; bfa1000f
BB79:
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB82                                         ; bfa10009
BB80:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_load_b128 s[24:27], s[16:17], 0x0                         ; f4004608 f8000000
	v_mov_b32_e32 v3, 0                                         ; 7e060280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v3, off, s[24:27], s2                       ; c4060002 00803003 00000000
BB82:
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
BB84:
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_cvt_f32_f16_e32 v3, v184/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0617b8
	v_cvt_f32_f16_e32 v5, v56                                   ; 7e0a1738
	v_cvt_f32_f16_e32 v7, v185/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0e17b9
	v_cvt_f32_f16_e32 v13, v57                                  ; 7e1a1739
	v_cvt_f32_f16_e32 v15, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e17ba
	v_cvt_f32_f16_e32 v19, v58                                  ; 7e26173a
	v_cvt_f32_f16_e32 v20, v187/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2817bb
	v_cvt_f32_f16_e32 v21, v59                                  ; 7e2a173b
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                        ; 02020705
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v13, v7, vcc_lo                       ; 02020f0d
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v19, v15, vcc_lo                      ; 02021f13
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v21, v20, vcc_lo                      ; 02022915
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cbranch_scc0 BB89                                         ; bfa1009d
BB85:
	s_clause 0x1                                                ; bf850001
	s_load_b64 s[16:17], s[14:15], 0x34                         ; f4002407 f8000034
	s_load_b128 s[24:27], s[14:15], 0x68                        ; f4004607 f8000068
	v_and_b32_e32 v3, 3, v0                                     ; 36060083
	v_and_b32_e32 v5, 15, v0                                    ; 360a008f
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_max_i32 s12, s18, 0                                       ; 8a0c8012
	s_max_i32 s21, s20, 0                                       ; 8a158014
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v7, 2, v5                                 ; 320e0a82
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_add_co_u32 s16, s16, -1                                   ; 8010c110
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s12, s12, s16                                     ; 890c100c
	s_add_co_u32 s17, s17, -1                                   ; 8011c111
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v3, s12, 2, v3                               ; d6460003 040d040c
	s_min_i32 s21, s21, s17                                     ; 89151115
	s_lshl2_add_u32 s22, s24, -1                                ; 8796c118
	s_lshl2_add_u32 s25, s25, -1                                ; 8799c119
	s_cmp_eq_i32 s27, 0                                         ; bf00801b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v7, s21, 2, v7                               ; d6460007 041d0415
	v_lshrrev_b32_e32 v3, 1, v3                                 ; 32060681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshrrev_b32_e32 v7, 1, v7                                 ; 320e0e81
	v_min_u32_e32 v3, s22, v3                                   ; 26060616
	v_min_u32_e32 v7, s25, v7                                   ; 260e0e19
	v_lshrrev_b32_e32 v15, 2, v3                                ; 321e0682
	v_and_b32_e32 v3, 3, v3                                     ; 36060683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_lshrrev_b32_e32 v13, 2, v7                                ; 321a0e82
	v_and_b32_e32 v7, 3, v7                                     ; 360e0e83
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v13, v24, vcc_lo                      ; 0200310d
	v_lshl_add_u32 v7, v7, 2, v3                                ; d6460007 040d0507
	s_cbranch_scc0 BB88                                         ; bfa10002
BB86:
	s_load_b32 s27, s[14:15], 0x60                              ; f40006c7 f8000060
BB88:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x2                                                ; bf850002
	s_load_b128 s[28:31], s[16:17], 0x0                         ; f4004708 f8000000
	s_load_b128 s[32:35], s[16:17], 0x40                        ; f4004808 f8000040
	s_load_b128 s[36:39], s[14:15], 0x50                        ; f4004907 f8000050
	v_add_lshl_u32 v13, v13, v15, 9                             ; d647000d 02261f0d
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s21, s21, s27                                     ; 96151b15
	s_and_b32 s36, s36, -4                                      ; 8b24c424
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s21, s21, s12                                  ; 80150c15
	s_and_b32 s37, s37, -4                                      ; 8b25c425
	v_add_nc_u32_e32 v13, s36, v13                              ; 4a1a1a24
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s21, s21, 9                                      ; 84158915
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s37, s21                                  ; 80251525
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_lshl_add_u32 v7, v7, 4, v13                               ; d6460007 04350907
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v5, v5, 4, s37                               ; d6460005 00950905
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[20:21], v7, s[28:31], null offen          ; c405407c 40803814 00000007
	buffer_load_b64 v[22:23], v5, s[28:31], null offen          ; c405407c 40803816 00000005
	v_add_lshl_u32 v3, s39, v1, 1                               ; d6470003 02060227
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_and_b32_e32 v5, -4, v3                                    ; 360a06c4
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[32:35], v5, s[32:35], null offen offset:64 ; c405c07c 40804020 00004005
	buffer_load_d16_hi_b16 v7, v3, s[32:35], null offen offset:78 ; c408c07c 40804007 00004e03
	buffer_load_b128 v[36:39], v5, s[32:35], null offen         ; c405c07c 40804024 00000005
	buffer_load_d16_hi_b16 v15, v3, s[32:35], null offen offset:14 ; c408c07c 4080400f 00000e03
	v_add_nc_u32_e32 v13, 64, v3                                ; 4a1a06c0
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_pk_f32_fp8_e32 v[30:31], v20                          ; 7e3cdd14
	v_cvt_pk_f32_fp8_e32 v[40:41], v148                         ; 7e50dd94
	v_cvt_pk_f32_fp8_e32 v[42:43], v21                          ; 7e54dd15
	v_cvt_pk_f32_fp8_e32 v[20:21], v149                         ; 7e28dd95
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_pk_f32_fp8_e32 v[68:69], v23                          ; 7e88dd17
	v_cvt_pk_f32_fp8_e32 v[62:63], v150                         ; 7e7cdd96
	v_cvt_pk_f32_fp8_e32 v[60:61], v22                          ; 7e78dd16
	v_cvt_pk_f32_fp8_e32 v[22:23], v151                         ; 7e2cdd97
	v_cvt_pk_rtz_f16_f32_e32 v30, v30, v31                      ; 5e3c3f1e
	v_cvt_pk_rtz_f16_f32_e32 v40, v40, v41                      ; 5e505328
	v_cvt_pk_rtz_f16_f32_e32 v42, v42, v43                      ; 5e54572a
	v_cvt_pk_rtz_f16_f32_e32 v20, v20, v21                      ; 5e282b14
	v_cvt_pk_rtz_f16_f32_e32 v68, v68, v69                      ; 5e888b44
	v_cvt_pk_rtz_f16_f32_e32 v62, v62, v63                      ; 5e7c7f3e
	v_cvt_pk_rtz_f16_f32_e32 v60, v60, v61                      ; 5e787b3c
	v_cvt_pk_rtz_f16_f32_e32 v22, v22, v23                      ; 5e2c2f16
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_alignbyte_b32 v32, v33, v32, v13                          ; d6170020 04364121
	v_alignbyte_b32 v33, v34, v33, v13                          ; d6170021 04364322
	v_alignbyte_b32 v34, v35, v34, v13                          ; d6170022 04364523
	v_alignbyte_b32 v35, v35, v35, v13                          ; d6170023 04364723
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_mov_b16_e32 v35.h, v7.h                                   ; 7f463987
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_alignbyte_b32 v36, v37, v36, v3                           ; d6170024 040e4925
	v_alignbyte_b32 v37, v38, v37, v3                           ; d6170025 040e4b26
	v_alignbyte_b32 v38, v39, v38, v3                           ; d6170026 040e4d27
	v_alignbyte_b32 v39, v39, v39, v3                           ; d6170027 040e4f27
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v39.h, v15.h                                  ; 7f4e398f
(invalid instruction)                                        ; cc10001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[32:33]                ; 1a02411e
(invalid instruction)                                        ; cc10003d
	v_min_num_f64_e32 v[1:2], v[40:41], v[33:34]                ; 1a024328
(invalid instruction)                                        ; cc10002a
	v_min_num_f64_e32 v[1:2], v[42:43], v[34:35]                ; 1a02452a
(invalid instruction)                                        ; cc10003f
	v_min_num_f64_e32 v[1:2], v[20:21], v[35:36]                ; 1a024714
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_pk_fma_f16 v60, v60, v36, v30                             ; cc0e403c 1c7a493c
	v_pk_fmac_f16 v61, v62, v37                                 ; 787a4b3e
	v_pk_fma_f16 v62, v68, v38, v42                             ; cc0e403e 1caa4d44
	v_pk_fmac_f16 v63, v22, v39                                 ; 787e4f16
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_branch BB90                                               ; bfa00003
BB89:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB90:
	s_min_i32 s12, s18, s20                                     ; 890c1412
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_i32 s12, 0                                         ; bf03800c
	s_cbranch_scc0 BB92                                         ; bfa10008
BB91:
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s18, s12                                       ; bf030c12
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s17, -1, 0                                    ; 981180c1
	s_branch BB93                                               ; bfa00002
BB92:
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_mov_b32 s17, -1                                           ; be9100c1
BB93:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 s17, exec_lo, s17                            ; 9111117e
	s_cbranch_scc0 BB95                                         ; bfa10007
BB94:
	s_load_b32 s12, s[14:15], 0x38                              ; f4000307 f8000038
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s20, s12                                       ; bf030c14
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB96                                               ; bfa00001
BB95:
	s_mov_b32 vcc_lo, -1                                        ; beea00c1
BB96:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s12, vcc_lo, exec_lo                              ; 8b0c7e6a
	s_cbranch_scc0 BB102                                        ; bfa1000f
BB97:
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB100                                        ; bfa10009
BB98:
	s_mov_b32 s22, s0                                           ; be960000
	s_movk_i32 s23, 0x8000                                      ; b0178000
	s_load_b128 s[24:27], s[22:23], 0x0                         ; f400460b f8000000
	v_mov_b32_e32 v3, 0                                         ; 7e060280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v3, off, s[24:27], s2                       ; c4060002 00803003 00000000
BB100:
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v60, 0              ; ca100080 3d3c0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v62, 0              ; ca100080 3f3e0080
BB102:
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_cvt_f32_f16_e32 v3, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0617bc
	v_cvt_f32_f16_e32 v5, v60                                   ; 7e0a173c
	v_cvt_f32_f16_e32 v7, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0e17bd
	v_cvt_f32_f16_e32 v13, v61                                  ; 7e1a173d
	v_cvt_f32_f16_e32 v15, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e17be
	v_cvt_f32_f16_e32 v21, v62                                  ; 7e2a173e
	v_cvt_f32_f16_e32 v22, v191/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2c17bf
	v_cvt_f32_f16_e32 v23, v63                                  ; 7e2e173f
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                        ; 02020705
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v13, v7, vcc_lo                       ; 02020f0d
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v21, v15, vcc_lo                      ; 02021f15
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v23, v22, vcc_lo                      ; 02022d17
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cbranch_scc0 BB107                                        ; bfa100a3
BB103:
	s_clause 0x1                                                ; bf850001
	s_load_b64 s[22:23], s[14:15], 0x34                         ; f4002587 f8000034
	s_load_b128 s[24:27], s[14:15], 0x68                        ; f4004607 f8000068
	v_and_b32_e32 v3, 3, v0                                     ; 36060083
	v_and_b32_e32 v5, 15, v0                                    ; 360a008f
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_max_i32 s12, s18, 0                                       ; 8a0c8012
	s_max_i32 s17, s20, 0                                       ; 8a118014
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v7, 2, v5                                 ; 320e0a82
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_add_co_u32 s22, s22, -1                                   ; 8016c116
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s12, s12, s22                                     ; 890c160c
	s_add_co_u32 s23, s23, -1                                   ; 8017c117
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v3, s12, 2, v3                               ; d6460003 040d040c
	s_min_i32 s17, s17, s23                                     ; 89111711
	s_lshl2_add_u32 s21, s24, -1                                ; 8795c118
	s_lshl2_add_u32 s25, s25, -1                                ; 8799c119
	s_cmp_eq_i32 s27, 0                                         ; bf00801b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v7, s17, 2, v7                               ; d6460007 041d0411
	v_lshrrev_b32_e32 v3, 1, v3                                 ; 32060681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshrrev_b32_e32 v7, 1, v7                                 ; 320e0e81
	v_min_u32_e32 v3, s21, v3                                   ; 26060615
	v_min_u32_e32 v7, s25, v7                                   ; 260e0e19
	v_lshrrev_b32_e32 v15, 2, v3                                ; 321e0682
	v_and_b32_e32 v3, 3, v3                                     ; 36060683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_lshrrev_b32_e32 v13, 2, v7                                ; 321a0e82
	v_and_b32_e32 v7, 3, v7                                     ; 360e0e83
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v13, v24, vcc_lo                      ; 0200310d
	v_lshl_add_u32 v7, v7, 2, v3                                ; d6460007 040d0507
	s_cbranch_scc0 BB106                                        ; bfa10002
BB104:
	s_load_b32 s27, s[14:15], 0x60                              ; f40006c7 f8000060
BB106:
	s_mov_b32 s22, s0                                           ; be960000
	s_movk_i32 s23, 0x8000                                      ; b0178000
	s_clause 0x2                                                ; bf850002
	s_load_b128 s[28:31], s[22:23], 0x0                         ; f400470b f8000000
	s_load_b128 s[32:35], s[22:23], 0x40                        ; f400480b f8000040
	s_load_b128 s[36:39], s[14:15], 0x50                        ; f4004907 f8000050
	v_add_lshl_u32 v13, v13, v15, 9                             ; d647000d 02261f0d
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s17, s17, s27                                     ; 96111b11
	s_and_b32 s36, s36, -4                                      ; 8b24c424
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s17, s12                                  ; 80110c11
	s_and_b32 s37, s37, -4                                      ; 8b25c425
	v_add3_u32 v13, s36, 0x100, v13                             ; d655000d 0435fe24 00000100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s17, s17, 9                                      ; 84118911
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_addk_co_i32 s17, 0x100                                    ; b7910100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870151
	v_lshl_add_u32 v7, v7, 4, v13                               ; d6460007 04350907
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s37, s17                                  ; 80251125
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v5, v5, 4, s37                               ; d6460005 00950905
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d2
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[22:23], v7, s[28:31], null offen          ; c405407c 40803816 00000007
	buffer_load_b64 v[30:31], v5, s[28:31], null offen          ; c405407c 4080381e 00000005
	v_add_lshl_u32 v3, s39, v1, 1                               ; d6470003 02060227
	v_and_b32_e32 v5, -4, v3                                    ; 360a06c4
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[32:35], v5, s[32:35], null offen offset:96 ; c405c07c 40804020 00006005
	buffer_load_d16_hi_b16 v15, v3, s[32:35], null offen offset:110 ; c408c07c 4080400f 00006e03
	buffer_load_b128 v[36:39], v5, s[32:35], null offen offset:32 ; c405c07c 40804024 00002005
	buffer_load_d16_hi_b16 v25, v3, s[32:35], null offen offset:46 ; c408c07c 40804019 00002e03
	v_add_nc_u32_e32 v13, 32, v3                                ; 4a1a06a0
	v_add_nc_u32_e32 v7, 0x60, v3                               ; 4a0e06ff 00000060
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_pk_f32_fp8_e32 v[42:43], v150                         ; 7e54dd96
	v_cvt_pk_f32_fp8_e32 v[64:65], v23                          ; 7e80dd17
	v_cvt_pk_f32_fp8_e32 v[40:41], v22                          ; 7e50dd16
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_pk_f32_fp8_e32 v[70:71], v31                          ; 7e8cdd1f
	v_cvt_pk_f32_fp8_e32 v[66:67], v30                          ; 7e84dd1e
	v_cvt_pk_rtz_f16_f32_e32 v42, v42, v43                      ; 5e54572a
	v_cvt_pk_f32_fp8_e32 v[22:23], v151                         ; 7e2cdd97
	v_cvt_pk_rtz_f16_f32_e32 v64, v64, v65                      ; 5e808340
	v_cvt_pk_rtz_f16_f32_e32 v40, v40, v41                      ; 5e505328
	v_cvt_pk_f32_fp8_e32 v[68:69], v158                         ; 7e88dd9e
	v_cvt_pk_rtz_f16_f32_e32 v70, v70, v71                      ; 5e8c8f46
	v_cvt_pk_f32_fp8_e32 v[30:31], v159                         ; 7e3cdd9f
	v_cvt_pk_rtz_f16_f32_e32 v66, v66, v67                      ; 5e848742
	v_cvt_pk_rtz_f16_f32_e32 v22, v22, v23                      ; 5e2c2f16
	v_cvt_pk_rtz_f16_f32_e32 v68, v68, v69                      ; 5e888b44
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_alignbyte_b32 v32, v33, v32, v7                           ; d6170020 041e4121
	v_alignbyte_b32 v33, v34, v33, v7                           ; d6170021 041e4322
	v_alignbyte_b32 v34, v35, v34, v7                           ; d6170022 041e4523
	v_alignbyte_b32 v35, v35, v35, v7                           ; d6170023 041e4723
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_mov_b16_e32 v35.h, v15.h                                  ; 7f46398f
	v_cvt_pk_rtz_f16_f32_e32 v30, v30, v31                      ; 5e3c3f1e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_alignbyte_b32 v36, v37, v36, v13                          ; d6170024 04364925
	v_alignbyte_b32 v37, v38, v37, v13                          ; d6170025 04364b26
	v_alignbyte_b32 v38, v39, v38, v13                          ; d6170026 04364d27
	v_alignbyte_b32 v39, v39, v39, v13                          ; d6170027 04364f27
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v39.h, v25.h                                  ; 7f4e3999
(invalid instruction)                                        ; cc100028
	v_min_num_f64_e32 v[1:2], v[40:41], v[32:33]                ; 1a024128
(invalid instruction)                                        ; cc100041
	v_min_num_f64_e32 v[1:2], v[42:43], v[33:34]                ; 1a02432a
(invalid instruction)                                        ; cc100040
	v_min_num_f64_e32 v[1:2], v[64:65], v[34:35]                ; 1a024540
(invalid instruction)                                        ; cc100043
	v_min_num_f64_e32 v[1:2], v[22:23], v[35:36]                ; 1a024716
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_pk_fmac_f16 v40, v66, v36                                 ; 78504942
	v_pk_fmac_f16 v65, v68, v37                                 ; 78824b44
	v_pk_fma_f16 v66, v70, v38, v64                             ; cc0e4042 1d024d46
	v_pk_fmac_f16 v67, v30, v39                                 ; 78864f1e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_mov_b32_e32 v64, v40                                      ; 7e800328
	s_branch BB108                                              ; bfa00003
BB107:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB108:
	s_cmp_lg_i32 s16, 0                                         ; bf018010
	s_cbranch_scc0 BB110                                        ; bfa10007
BB109:
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s18, s12                                       ; bf030c12
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s16, -1, 0                                    ; 981080c1
	s_branch BB111                                              ; bfa00001
BB110:
	s_mov_b32 s16, -1                                           ; be9000c1
BB111:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 s16, exec_lo, s16                            ; 9110107e
	s_cbranch_scc0 BB113                                        ; bfa10007
BB112:
	s_load_b32 s12, s[14:15], 0x38                              ; f4000307 f8000038
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s20, s12                                       ; bf030c14
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB114                                              ; bfa00001
BB113:
	s_mov_b32 vcc_lo, -1                                        ; beea00c1
BB114:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s12, vcc_lo, exec_lo                              ; 8b0c7e6a
	s_cbranch_scc0 BB120                                        ; bfa1000f
BB115:
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB118                                        ; bfa10009
BB116:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_load_b128 s[24:27], s[16:17], 0x0                         ; f4004608 f8000000
	v_mov_b32_e32 v3, 0                                         ; 7e060280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v3, off, s[24:27], s2                       ; c4060002 00803003 00000000
BB118:
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v64, 0              ; ca100080 41400080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0              ; ca100080 43420080
BB120:
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_cvt_f32_f16_e32 v3, v192/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0617c0
	v_cvt_f32_f16_e32 v5, v64                                   ; 7e0a1740
	v_cvt_f32_f16_e32 v7, v193/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0e17c1
	v_cvt_f32_f16_e32 v13, v65                                  ; 7e1a1741
	v_cvt_f32_f16_e32 v15, v194/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e17c2
	v_cvt_f32_f16_e32 v23, v66                                  ; 7e2e1742
	v_cvt_f32_f16_e32 v25, v195/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3217c3
	v_cvt_f32_f16_e32 v27, v67                                  ; 7e361743
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                        ; 02020705
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v13, v7, vcc_lo                       ; 02020f0d
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v23, v15, vcc_lo                      ; 02021f17
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v27, v25, vcc_lo                      ; 0202331b
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cbranch_scc0 BB125                                        ; bfa1009d
BB121:
	s_clause 0x1                                                ; bf850001
	s_load_b64 s[16:17], s[14:15], 0x34                         ; f4002407 f8000034
	s_load_b128 s[24:27], s[14:15], 0x68                        ; f4004607 f8000068
	v_and_b32_e32 v2, 3, v0                                     ; 36040083
	v_and_b32_e32 v3, 15, v0                                    ; 3606008f
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_max_i32 s12, s11, 0                                       ; 8a0c800b
	s_max_i32 s21, s20, 0                                       ; 8a158014
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v5, 2, v3                                 ; 320a0682
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_add_co_u32 s16, s16, -1                                   ; 8010c110
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s12, s12, s16                                     ; 890c100c
	s_add_co_u32 s17, s17, -1                                   ; 8011c111
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v2, s12, 2, v2                               ; d6460002 0409040c
	s_min_i32 s21, s21, s17                                     ; 89151115
	s_lshl2_add_u32 s22, s24, -1                                ; 8796c118
	s_lshl2_add_u32 s25, s25, -1                                ; 8799c119
	s_cmp_eq_i32 s27, 0                                         ; bf00801b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v5, s21, 2, v5                               ; d6460005 04150415
	v_lshrrev_b32_e32 v2, 1, v2                                 ; 32040481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshrrev_b32_e32 v5, 1, v5                                 ; 320a0a81
	v_min_u32_e32 v2, s22, v2                                   ; 26040416
	v_min_u32_e32 v5, s25, v5                                   ; 260a0a19
	v_lshrrev_b32_e32 v7, 2, v2                                 ; 320e0482
	v_and_b32_e32 v2, 3, v2                                     ; 36040483
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_lshrrev_b32_e32 v6, 2, v5                                 ; 320c0a82
	v_and_b32_e32 v5, 3, v5                                     ; 360a0a83
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v6, v24, vcc_lo                       ; 02003106
	v_lshl_add_u32 v5, v5, 2, v2                                ; d6460005 04090505
	s_cbranch_scc0 BB124                                        ; bfa10002
BB122:
	s_load_b32 s27, s[14:15], 0x60                              ; f40006c7 f8000060
BB124:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x2                                                ; bf850002
	s_load_b128 s[28:31], s[16:17], 0x0                         ; f4004708 f8000000
	s_load_b128 s[32:35], s[16:17], 0x40                        ; f4004808 f8000040
	s_load_b128 s[36:39], s[14:15], 0x50                        ; f4004907 f8000050
	v_add_lshl_u32 v6, v6, v7, 9                                ; d6470006 02260f06
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s21, s21, s27                                     ; 96151b15
	s_and_b32 s36, s36, -4                                      ; 8b24c424
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s21, s21, s12                                  ; 80150c15
	s_and_b32 s37, s37, -4                                      ; 8b25c425
	v_add_nc_u32_e32 v6, s36, v6                                ; 4a0c0c24
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s21, s21, 9                                      ; 84158915
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s37, s21                                  ; 80251525
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_lshl_add_u32 v5, v5, 4, v6                                ; d6460005 04190905
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v3, v3, 4, s37                               ; d6460003 00950903
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[6:7], v5, s[28:31], null offen            ; c405407c 40803806 00000005
	buffer_load_b64 v[2:3], v3, s[28:31], null offen            ; c405407c 40803802 00000003
	v_add_lshl_u32 v5, s39, v1, 1                               ; d6470005 02060227
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_and_b32_e32 v13, -4, v5                                   ; 361a0ac4
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[24:27], v13, s[32:35], null offen offset:64 ; c405c07c 40804018 0000400d
	buffer_load_d16_hi_b16 v15, v5, s[32:35], null offen offset:78 ; c408c07c 4080400f 00004e05
	buffer_load_b128 v[32:35], v13, s[32:35], null offen        ; c405c07c 40804020 0000000d
	buffer_load_d16_hi_b16 v30, v5, s[32:35], null offen offset:14 ; c408c07c 4080401e 00000e05
	v_add_nc_u32_e32 v29, 64, v5                                ; 4a3a0ac0
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_pk_f32_fp8_e32 v[36:37], v6                           ; 7e48dd06
	v_cvt_pk_f32_fp8_e32 v[38:39], v134                         ; 7e4cdd86
	v_cvt_pk_f32_fp8_e32 v[40:41], v7                           ; 7e50dd07
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_pk_f32_fp8_e32 v[68:69], v130                         ; 7e88dd82
	v_cvt_pk_f32_fp8_e32 v[42:43], v2                           ; 7e54dd02
	v_cvt_pk_f32_fp8_e32 v[70:71], v3                           ; 7e8cdd03
	v_cvt_pk_f32_fp8_e32 v[2:3], v131                           ; 7e04dd83
	v_cvt_pk_rtz_f16_f32_e32 v36, v36, v37                      ; 5e484b24
	v_cvt_pk_rtz_f16_f32_e32 v38, v38, v39                      ; 5e4c4f26
	v_cvt_pk_rtz_f16_f32_e32 v40, v40, v41                      ; 5e505328
	v_cvt_pk_rtz_f16_f32_e32 v6, v6, v7                         ; 5e0c0f06
	v_cvt_pk_rtz_f16_f32_e32 v42, v42, v43                      ; 5e54572a
	v_cvt_pk_rtz_f16_f32_e32 v2, v2, v3                         ; 5e040702
	v_cvt_pk_rtz_f16_f32_e32 v68, v68, v69                      ; 5e888b44
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_alignbyte_b32 v24, v25, v24, v29                          ; d6170018 04763119
	v_alignbyte_b32 v25, v26, v25, v29                          ; d6170019 0476331a
	v_alignbyte_b32 v26, v27, v26, v29                          ; d617001a 0476351b
	v_alignbyte_b32 v27, v27, v27, v29                          ; d617001b 0476371b
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_mov_b16_e32 v27.h, v15.h                                  ; 7f36398f
	v_cvt_pk_rtz_f16_f32_e32 v70, v70, v71                      ; 5e8c8f46
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_alignbyte_b32 v32, v33, v32, v5                           ; d6170020 04164121
	v_alignbyte_b32 v33, v34, v33, v5                           ; d6170021 04164322
	v_alignbyte_b32 v34, v35, v34, v5                           ; d6170022 04164523
	v_alignbyte_b32 v35, v35, v35, v5                           ; d6170023 04164723
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v35.h, v30.h                                  ; 7f46399e
(invalid instruction)                                        ; cc100024
	v_min_num_f64_e32 v[1:2], v[36:37], v[24:25]                ; 1a023124
(invalid instruction)                                        ; cc100018
	v_min_num_f64_e32 v[1:2], v[38:39], v[25:26]                ; 1a023326
(invalid instruction)                                        ; cc10001a
	v_min_num_f64_e32 v[1:2], v[40:41], v[26:27]                ; 1a023528
(invalid instruction)                                        ; cc100006
	v_min_num_f64_e32 v[1:2], v[6:7], v[27:28]                  ; 1a023706
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_pk_fmac_f16 v36, v42, v32                                 ; 7848412a
	v_pk_fmac_f16 v24, v68, v33                                 ; 78304344
	v_pk_fmac_f16 v26, v70, v34                                 ; 78344546
	v_pk_fma_f16 v2, v2, v35, v6                                ; cc0e4002 1c1a4702
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_mov_b32_e32 v6, v36                                       ; 7e0c0324
	s_branch BB126                                              ; bfa00003
BB125:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB126:
	s_min_i32 s12, s11, s20                                     ; 890c140b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_i32 s12, 0                                         ; bf03800c
	s_cbranch_scc0 BB128                                        ; bfa10008
BB127:
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s11, s12                                       ; bf030c0b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s17, -1, 0                                    ; 981180c1
	s_branch BB129                                              ; bfa00002
BB128:
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_mov_b32 s17, -1                                           ; be9100c1
BB129:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 s17, exec_lo, s17                            ; 9111117e
	s_cbranch_scc0 BB131                                        ; bfa10007
BB130:
	s_load_b32 s12, s[14:15], 0x38                              ; f4000307 f8000038
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s20, s12                                       ; bf030c14
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB132                                              ; bfa00001
BB131:
	s_mov_b32 vcc_lo, -1                                        ; beea00c1
BB132:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s12, vcc_lo, exec_lo                              ; 8b0c7e6a
	s_cbranch_scc0 BB138                                        ; bfa1000f
BB133:
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB136                                        ; bfa10009
BB134:
	s_mov_b32 s22, s0                                           ; be960000
	s_movk_i32 s23, 0x8000                                      ; b0178000
	s_load_b128 s[24:27], s[22:23], 0x0                         ; f400460b f8000000
	v_mov_b32_e32 v2, 0                                         ; 7e040280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v2, off, s[24:27], s2                       ; c4060002 00803002 00000000
BB136:
	v_mov_b32_e32 v2, 0                                         ; 7e040280
	v_mov_b32_e32 v6, 0                                         ; 7e0c0280
	v_mov_b32_e32 v24, 0                                        ; 7e300280
	v_mov_b32_e32 v26, 0                                        ; 7e340280
BB138:
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	v_cvt_f32_f16_e32 v27, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e361782
	v_cvt_f32_f16_e32 v29, v2                                   ; 7e3a1702
	v_cvt_f32_f16_e32 v3, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e061786
	v_cvt_f32_f16_e32 v5, v6                                    ; 7e0a1706
	v_cvt_f32_f16_e32 v7, v152/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0e1798
	v_cvt_f32_f16_e32 v13, v24                                  ; 7e1a1718
	v_cvt_f32_f16_e32 v15, v154/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e179a
	v_cvt_f32_f16_e32 v25, v26                                  ; 7e32171a
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                        ; 02020705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v13, v7, vcc_lo                       ; 02020f0d
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v25, v15, vcc_lo                      ; 02021f19
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v29, v27, vcc_lo                      ; 0202371d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cbranch_scc0 BB144                                        ; bfa100a3
BB139:
	s_clause 0x1                                                ; bf850001
	s_load_b64 s[22:23], s[14:15], 0x34                         ; f4002587 f8000034
	s_load_b128 s[24:27], s[14:15], 0x68                        ; f4004607 f8000068
	v_and_b32_e32 v3, 3, v0                                     ; 36060083
	v_and_b32_e32 v4, 15, v0                                    ; 3608008f
	s_max_i32 s1, s11, 0                                        ; 8a01800b
	s_max_i32 s12, s20, 0                                       ; 8a0c8014
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v5, 2, v4                                 ; 320a0882
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_add_co_u32 s22, s22, -1                                   ; 8016c116
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s1, s1, s22                                       ; 89011601
	s_add_co_u32 s23, s23, -1                                   ; 8017c117
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v3, s1, 2, v3                                ; d6460003 040d0401
	s_min_i32 s12, s12, s23                                     ; 890c170c
	s_lshl2_add_u32 s17, s24, -1                                ; 8791c118
	s_lshl2_add_u32 s25, s25, -1                                ; 8799c119
	s_cmp_eq_i32 s27, 0                                         ; bf00801b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v5, s12, 2, v5                               ; d6460005 0415040c
	v_lshrrev_b32_e32 v3, 1, v3                                 ; 32060681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshrrev_b32_e32 v5, 1, v5                                 ; 320a0a81
	v_min_u32_e32 v3, s17, v3                                   ; 26060611
	v_min_u32_e32 v5, s25, v5                                   ; 260a0a19
	v_lshrrev_b32_e32 v12, 2, v3                                ; 32180682
	v_and_b32_e32 v3, 3, v3                                     ; 36060683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_lshrrev_b32_e32 v7, 2, v5                                 ; 320e0a82
	v_and_b32_e32 v5, 3, v5                                     ; 360a0a83
(invalid instruction)                                        ; d72c0007
	v_cndmask_b32_e32 v0, v7, v24, vcc_lo                       ; 02003107
	v_lshl_add_u32 v5, v5, 2, v3                                ; d6460005 040d0505
	s_cbranch_scc0 BB142                                        ; bfa10002
BB140:
	s_load_b32 s27, s[14:15], 0x60                              ; f40006c7 f8000060
BB142:
	s_mov_b32 s22, s0                                           ; be960000
	s_movk_i32 s23, 0x8000                                      ; b0178000
	s_clause 0x2                                                ; bf850002
	s_load_b128 s[28:31], s[22:23], 0x0                         ; f400470b f8000000
	s_load_b128 s[32:35], s[22:23], 0x40                        ; f400480b f8000040
	s_load_b128 s[36:39], s[14:15], 0x50                        ; f4004907 f8000050
	v_add_lshl_u32 v7, v7, v12, 9                               ; d6470007 02261907
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s12, s12, s27                                     ; 960c1b0c
	s_and_b32 s36, s36, -4                                      ; 8b24c424
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s12, s12, s1                                   ; 800c010c
	s_and_b32 s37, s37, -4                                      ; 8b25c425
	v_add3_u32 v7, s36, 0x100, v7                               ; d6550007 041dfe24 00000100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s12, s12, 9                                      ; 840c890c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_addk_co_i32 s12, 0x100                                    ; b78c0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870151
	v_lshl_add_u32 v5, v5, 4, v7                                ; d6460005 041d0905
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s37, s12                                  ; 80250c25
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v4, v4, 4, s37                               ; d6460004 00950904
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d2
	v_add_nc_u32_e32 v4, v4, v1                                 ; 4a080304
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[12:13], v5, s[28:31], null offen          ; c405407c 4080380c 00000005
	buffer_load_b64 v[4:5], v4, s[28:31], null offen            ; c405407c 40803804 00000004
	v_add_lshl_u32 v3, s39, v1, 1                               ; d6470003 02060227
	v_and_b32_e32 v7, -4, v3                                    ; 360e06c4
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[32:35], v7, s[32:35], null offen offset:96 ; c405c07c 40804020 00006007
	buffer_load_d16_hi_b16 v25, v3, s[32:35], null offen offset:110 ; c408c07c 40804019 00006e03
	buffer_load_b128 v[36:39], v7, s[32:35], null offen offset:32 ; c405c07c 40804024 00002007
	buffer_load_d16_hi_b16 v27, v3, s[32:35], null offen offset:46 ; c408c07c 4080401b 00002e03
	v_add_nc_u32_e32 v15, 32, v3                                ; 4a1e06a0
	v_add_nc_u32_e32 v14, 0x60, v3                              ; 4a1c06ff 00000060
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_pk_f32_fp8_e32 v[40:41], v140                         ; 7e50dd8c
	v_cvt_pk_f32_fp8_e32 v[42:43], v13                          ; 7e54dd0d
	v_cvt_pk_f32_fp8_e32 v[28:29], v12                          ; 7e38dd0c
	v_cvt_pk_f32_fp8_e32 v[12:13], v141                         ; 7e18dd8d
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_pk_f32_fp8_e32 v[68:69], v4                           ; 7e88dd04
	v_cvt_pk_f32_fp8_e32 v[72:73], v5                           ; 7e90dd05
	v_cvt_pk_f32_fp8_e32 v[70:71], v132                         ; 7e8cdd84
	v_cvt_pk_f32_fp8_e32 v[4:5], v133                           ; 7e08dd85
	v_cvt_pk_rtz_f16_f32_e32 v40, v40, v41                      ; 5e505328
	v_cvt_pk_rtz_f16_f32_e32 v42, v42, v43                      ; 5e54572a
	v_cvt_pk_rtz_f16_f32_e32 v28, v28, v29                      ; 5e383b1c
	v_cvt_pk_rtz_f16_f32_e32 v12, v12, v13                      ; 5e181b0c
	v_cvt_pk_rtz_f16_f32_e32 v68, v68, v69                      ; 5e888b44
	v_cvt_pk_rtz_f16_f32_e32 v72, v72, v73                      ; 5e909348
	v_cvt_pk_rtz_f16_f32_e32 v70, v70, v71                      ; 5e8c8f46
	v_cvt_pk_rtz_f16_f32_e32 v4, v4, v5                         ; 5e080b04
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_alignbyte_b32 v32, v33, v32, v14                          ; d6170020 043a4121
	v_alignbyte_b32 v33, v34, v33, v14                          ; d6170021 043a4322
	v_alignbyte_b32 v34, v35, v34, v14                          ; d6170022 043a4523
	v_alignbyte_b32 v35, v35, v35, v14                          ; d6170023 043a4723
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_mov_b16_e32 v35.h, v25.h                                  ; 7f463999
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_alignbyte_b32 v36, v37, v36, v15                          ; d6170024 043e4925
	v_alignbyte_b32 v37, v38, v37, v15                          ; d6170025 043e4b26
	v_alignbyte_b32 v38, v39, v38, v15                          ; d6170026 043e4d27
	v_alignbyte_b32 v39, v39, v39, v15                          ; d6170027 043e4f27
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v39.h, v27.h                                  ; 7f4e399b
(invalid instruction)                                        ; cc10001c
	v_min_num_f64_e32 v[1:2], v[28:29], v[32:33]                ; 1a02411c
(invalid instruction)                                        ; cc10000e
	v_min_num_f64_e32 v[1:2], v[40:41], v[33:34]                ; 1a024328
(invalid instruction)                                        ; cc10002a
	v_min_num_f64_e32 v[1:2], v[42:43], v[34:35]                ; 1a02452a
(invalid instruction)                                        ; cc10000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[35:36]                ; 1a02470c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_pk_fmac_f16 v28, v68, v36                                 ; 78384944
	v_pk_fmac_f16 v14, v70, v37                                 ; 781c4b46
	v_pk_fmac_f16 v42, v72, v38                                 ; 78544d48
	v_pk_fma_f16 v4, v4, v39, v12                               ; cc0e4004 1c324f04
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_mov_b32_e32 v12, v28                                      ; 7e18031c
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_mov_b32_e32 v28, v42                                      ; 7e38032a
BB144:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cmp_lg_i32 s16, 0                                         ; bf018010
	s_cbranch_scc0 BB146                                        ; bfa10007
BB145:
	s_load_b32 s1, s[14:15], 0x34                               ; f4000047 f8000034
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s11, s1                                        ; bf03010b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s11, -1, 0                                    ; 980b80c1
	s_branch BB147                                              ; bfa00001
BB146:
	s_mov_b32 s11, -1                                           ; be8b00c1
BB147:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s11, exec_lo, s11                            ; 910b0b7e
	s_cbranch_scc0 BB149                                        ; bfa10007
BB148:
	s_load_b32 s1, s[14:15], 0x38                               ; f4000047 f8000038
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_i32 s20, s1                                        ; bf030114
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB150                                              ; bfa00001
BB149:
	s_mov_b32 vcc_lo, -1                                        ; beea00c1
BB150:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s1, vcc_lo, exec_lo                               ; 8b017e6a
	s_cbranch_scc0 BB156                                        ; bfa1000f
BB151:
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB154                                        ; bfa10009
BB152:
	s_mov_b32 s10, s0                                           ; be8a0000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_load_b128 s[20:23], s[10:11], 0x0                         ; f4004505 f8000000
	v_mov_b32_e32 v3, 0                                         ; 7e060280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v3, off, s[20:23], s2                       ; c4060002 00802803 00000000
BB154:
	v_mov_b32_e32 v4, 0                                         ; 7e080280
	v_mov_b32_e32 v12, 0                                        ; 7e180280
	v_mov_b32_e32 v14, 0                                        ; 7e1c0280
	v_mov_b32_e32 v28, 0                                        ; 7e380280
BB156:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b256 s[24:31], s[0:1], 0x30                          ; f4006600 f8000030
	v_lshlrev_b32_e32 v3, 2, v0                                 ; 30060082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v5, s3, v3, 2                                ; d6470005 020a0603
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mov_b64 s[20:21], s[28:29]                                ; be94011c
	s_mov_b64 s[22:23], s[30:31]                                ; be96011e
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[32:35], v5, s[20:23], null offen         ; c405c07c 40802820 00000005
	buffer_load_b128 v[36:39], v5, s[20:23], null offen offset:512 ; c405c07c 40802824 00020005
	buffer_load_b128 v[40:43], v5, s[20:23], null offen offset:1024 ; c405c07c 40802828 00040005
	buffer_load_b128 v[68:71], v5, s[20:23], null offen offset:1536 ; c405c07c 40802844 00060005
	buffer_load_b128 v[72:75], v5, s[20:23], null offen offset:2048 ; c405c07c 40802848 00080005
	buffer_load_b128 v[76:79], v5, s[20:23], null offen offset:2560 ; c405c07c 4080284c 000a0005
	s_load_b32 s2, s[14:15], 0x24                               ; f4000087 f8000024
	v_cvt_f32_f16_e32 v7, v140/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0e178c
	v_cvt_f32_f16_e32 v13, v12                                  ; 7e1a170c
	v_cvt_f32_f16_e32 v15, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e178e
	v_cvt_f32_f16_e32 v25, v14                                  ; 7e32170e
	v_cvt_f32_f16_e32 v27, v156/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e36179c
	v_cvt_f32_f16_e32 v29, v28                                  ; 7e3a171c
	v_cvt_f32_f16_e32 v82, v132/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea41784
	v_cvt_f32_f16_e32 v83, v4                                   ; 7ea61704
	s_movk_i32 s3, 0x400                                        ; b0030400
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v13, v7, vcc_lo                       ; 02020f0d
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v25, v15, vcc_lo                      ; 02021f19
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v29, v27, vcc_lo                      ; 0202371d
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v83, v82, vcc_lo                      ; 0202a553
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[34:35], v[30:31], 0 ; cc464090 1a023d22
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[32:33], v[20:21], 0 ; cc464068 1a022920
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[16:17], 0 ; cc464080 1a022122
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[30:31], 0 ; cc464070 1a023d20
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[34:35], v[20:21], 0 ; cc464088 1a022922
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[8:9], 0 ; cc464078 1a021122
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[16:17], 0 ; cc464060 1a022120
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[8:9], 0   ; cc464058 1a021120
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[22:23], v[104:111] ; cc464068 1da22d24
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[80:81], v[112:119] ; cc464070 1dc2a124
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[18:19], v[96:103] ; cc464060 1d822524
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[10:11], v[88:95] ; cc464058 1d621524
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_maxmin_num_f32 v84, -4.0, v88, 4.0                        ; d6690054 03dab0f7
	v_maxmin_num_f32 v86, -4.0, v89, 4.0                        ; d6690056 03dab2f7
	v_maxmin_num_f32 v152, -4.0, v91, 4.0                       ; d6690098 03dab6f7
	v_maxmin_num_f32 v156, -4.0, v93, 4.0                       ; d669009c 03dabaf7
	v_maxmin_num_f32 v154, -4.0, v92, 4.0                       ; d669009a 03dab8f7
	v_maxmin_num_f32 v158, -4.0, v94, 4.0                       ; d669009e 03dabcf7
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v95, 4.0                       ; d66900a0 03dabef7
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v97, 4.0                       ; d66900a4 03dac2f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c842ad57 5754ab54 3f650000
	v_maxmin_num_f32 v162, -4.0, v96, 4.0                       ; d66900a2 03dac0f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v98, 4.0                       ; d66900a6 03dac4f7
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c8433d9f 9fa143a0 3f650000
	v_dual_mul_f32 v89, v89, v87 :: v_dual_mul_f32 v88, v88, v84 ; c8c6af59 5958a958
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v99, 4.0                       ; d66900a8 03dac6f7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_mul_f32 v94, v94, v159 ; c84749a5 a55f3f5e 3f650000
	v_maxmin_num_f32 v172, -4.0, v101, 4.0                      ; d66900ac 03dacaf7
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v90, 4.0                        ; d6690058 03dab4f7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v170, -4.0, v100, 4.0                      ; d66900aa 03dac8f7
	v_dual_mul_f32 v97, v97, v165 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8c34b61 61a347a2 3f650000
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v102, 4.0                      ; d66900ae 03daccf7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c8434da7 a7a953a8 3f650000
	v_maxmin_num_f32 v176, -4.0, v103, 4.0                      ; d66900b0 03dacef7
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 ; c8433398 9858b159 3f650000
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v98, v98, v167 ; c84759ad ad634f62 3f650000
	v_maxmin_num_f32 v180, -4.0, v105, 4.0                      ; d66900b4 03dad2f7
	v_dual_mul_f32 v99, v99, v168 :: v_dual_mul_f32 v96, v96, v162 ; c8c75163 63614560
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v178, -4.0, v104, 4.0                      ; d66900b2 03dad0f7
	v_mul_f32_e32 v91, v91, v152                                ; 10b7315b
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v90, v90, v89 ; c847399d 9d5ab35a 3f650000
	v_dual_mul_f32 v101, v101, v173 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8c35b65 65ab57aa 3f650000
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v106, 4.0                      ; d66900b6 03dad4f7
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c8435daf afb163b0 3f650000
	v_maxmin_num_f32 v184, -4.0, v107, 4.0                      ; d66900b8 03dad6f7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_dual_mul_f32 v93, v93, v157 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8c33b5d 5d9b379a 3f650000
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v188, -4.0, v109, 4.0                      ; d66900bc 03dadaf7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_mul_f32 v103, v103, v176 :: v_dual_mul_f32 v100, v100, v170 ; c8c76167 67655564
	v_maxmin_num_f32 v186, -4.0, v108, 4.0                      ; d66900ba 03dad8f7
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v102, v102, v175 ; c84769b5 b5675f66 3f650000
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v110, 4.0                      ; d66900be 03dadcf7
	v_dual_mul_f32 v95, v95, v160 :: v_dual_mul_f32 v92, v92, v154 ; c8c7415f 5f5d355c
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_mul_f32 v105, v105, v181 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c8c36b69 69b367b2 3f650000
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8436db7 b7b973b8 3f650000
	v_maxmin_num_f32 v13, -4.0, v112, 4.0                       ; d669000d 03dae0f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v25, -4.0, v113, 4.0                       ; d6690019 03dae2f7
	v_dual_mul_f32 v107, v107, v184 :: v_dual_mul_f32 v104, v104, v178 ; c8c7716b 6b696568
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v106, v106, v183 ; c84779bd bd6b6f6a 3f650000
	v_maxmin_num_f32 v29, -4.0, v114, 4.0                       ; d669001d 03dae4f7
	v_fma_mix_f32 v15, 0xab28, |v13|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620f 0bfe1aff 3728ab28
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8437dbf bfbb77ba 3f650000
	v_maxmin_num_f32 v84, -4.0, v115, 4.0                       ; d6690054 03dae6f7
	v_fma_mix_f32 v27, 0xab28, |v25|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe32ff 3728ab28
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_fma_mix_f32 v83, 0xab28, |v29|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfe3aff 3728ab28
	v_maxmin_num_f32 v86, -4.0, v116, 4.0                       ; d6690056 03dae8f7
	v_dual_fmaak_f32 v13, v13, v15, 0x3f650000 :: v_dual_mul_f32 v108, v108, v186 ; c8461f0d 0d6d756c 3f650000
	v_maxmin_num_f32 v88, -4.0, v117, 4.0                       ; d6690058 03daeaf7
	v_dual_mul_f32 v110, v110, v191 :: v_dual_mul_f32 v109, v109, v189 ; c8c77f6e 6e6d7b6d
	v_maxmin_num_f32 v191, -4.0, v111, 4.0                      ; d66900bf 03dadef7
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_fmaak_f32 v27, v27, v25, 0x3f650000                       ; 5a36331b 3f650000
	v_maxmin_num_f32 v90, -4.0, v118, 4.0                       ; d669005a 03daecf7
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v119, 4.0                       ; d669005c 03daeef7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v7, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bff7eff 3728ab28
	v_dual_fmaak_f32 v83, v29, v83, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c842a71d 5354ab54 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[10:11], v[120:127] ; cc464078 1de21526
	v_dual_mul_f32 v113, v113, v27 :: v_dual_mul_f32 v112, v112, v13 ; c8c63771 71701b70
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v87, 0x3f650000 ; c842b159 5956af56 3f650000
	v_fmaak_f32 v191, v191, v7, 0x3f650000                      ; 5b7e0fbf 3f650000
	v_dual_mul_f32 v115, v115, v84 :: v_dual_mul_f32 v114, v114, v83 ; c8c6a973 7372a772
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 :: v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 ; c842bb5c 5c5ab55b 3f650000
	v_dual_mul_f32 v117, v117, v89 :: v_dual_mul_f32 v116, v116, v86 ; c8c6b375 7574ad74
	v_mul_f32_e32 v111, v111, v191                              ; 10df7f6f
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v98, -4.0, v122, 4.0                       ; d6690062 03daf4f7
	v_maxmin_num_f32 v96, -4.0, v121, 4.0                       ; d6690060 03daf2f7
	v_maxmin_num_f32 v94, -4.0, v120, 4.0                       ; d669005e 03daf0f7
	v_maxmin_num_f32 v100, -4.0, v123, 4.0                      ; d6690064 03daf6f7
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[38:39], v[18:19], v[128:135] ; cc464080 1e022526
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[38:39], v[22:23], v[136:143] ; cc464088 1e222d26
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[80:81], v[144:151] ; cc464090 1e42a126
	v_dual_mul_f32 v119, v119, v92 :: v_dual_mul_f32 v118, v118, v91 ; c8c6b977 7776b776
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v102, -4.0, v124, 4.0                      ; d6690066 03daf8f7
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_maxmin_num_f32 v104, -4.0, v125, 4.0                      ; d6690068 03dafaf7
	v_maxmin_num_f32 v106, -4.0, v126, 4.0                      ; d669006a 03dafcf7
	v_maxmin_num_f32 v108, -4.0, v127, 4.0                      ; d669006c 03dafef7
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v128, 4.0                      ; d669006e 03db00f7
	v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c842c161 615ebf5e 3f650000
	v_maxmin_num_f32 v112, -4.0, v129, 4.0                      ; d6690070 03db02f7
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c842c563 6364cb64 3f650000
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_maxmin_num_f32 v114, -4.0, v130, 4.0                      ; d6690072 03db04f7
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_mul_f32 v121, v121, v97 :: v_dual_mul_f32 v120, v120, v94 ; c8c6c379 7978bd78
	v_maxmin_num_f32 v116, -4.0, v131, 4.0                      ; d6690074 03db06f7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_dual_mul_f32 v123, v123, v100 :: v_dual_mul_f32 v122, v122, v99 ; c8c6c97b 7b7ac77a
	v_dual_fmaak_f32 v105, v105, v104, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 ; c842d169 6966cf66 3f650000
	v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 :: v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 ; c842db6c 6c6ad56b 3f650000
	v_maxmin_num_f32 v118, -4.0, v132, 4.0                      ; d6690076 03db08f7
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v133, 4.0                      ; d6690078 03db0af7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v125, v125, v105 :: v_dual_mul_f32 v124, v124, v102 ; c8c6d37d 7d7ccd7c
	v_maxmin_num_f32 v122, -4.0, v134, 4.0                      ; d669007a 03db0cf7
	v_dual_mul_f32 v127, v127, v108 :: v_dual_mul_f32 v126, v126, v107 ; c8c6d97f 7f7ed77e
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 :: v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 ; c842eb74 7472e573 3f650000
	v_dual_mul_f32 v129, v129, v113 :: v_dual_mul_f32 v128, v128, v110 ; c8c6e381 8180dd80
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v135, 4.0                      ; d669007c 03db0ef7
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v136, 4.0                      ; d669007e 03db10f7
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 ; c842f179 7976ef76 3f650000
	v_dual_mul_f32 v131, v131, v116 :: v_dual_mul_f32 v130, v130, v115 ; c8c6e983 8382e782
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v128, -4.0, v137, 4.0                      ; d6690080 03db12f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_dual_mul_f32 v133, v133, v121 :: v_dual_mul_f32 v132, v132, v118 ; c8c6f385 8584ed84
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v130, -4.0, v138, 4.0                      ; d6690082 03db14f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 ; c842fb7c 7c7af57b 3f650000
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v132, -4.0, v139, 4.0                      ; d6690084 03db16f7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v127, 0x3f650000 ; c8430181 817eff7e 3f650000
	v_dual_mul_f32 v135, v135, v124 :: v_dual_mul_f32 v134, v134, v123 ; c8c6f987 8786f786
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_dual_mul_f32 v137, v137, v129 :: v_dual_mul_f32 v136, v136, v126 ; c8c70389 8988fd88
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v134, -4.0, v140, 4.0                      ; d6690086 03db18f7
	v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 ; c8430b84 84830583 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_maxmin_num_f32 v136, -4.0, v141, 4.0                      ; d6690088 03db1af7
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v145, 4.0                      ; d6690098 03db22f7
	v_dual_mul_f32 v139, v139, v132 :: v_dual_mul_f32 v138, v138, v131 ; c8c7098b 8b8b078a
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_maxmin_num_f32 v138, -4.0, v142, 4.0                      ; d669008a 03db1cf7
	v_maxmin_num_f32 v154, -4.0, v146, 4.0                      ; d669009a 03db24f7
	v_maxmin_num_f32 v156, -4.0, v147, 4.0                      ; d669009c 03db26f7
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c8431189 89870f86 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v148, 4.0                      ; d669009e 03db28f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v149, 4.0                      ; d66900a0 03db2af7
	v_dual_mul_f32 v141, v141, v137 :: v_dual_mul_f32 v140, v140, v134 ; c8c7138d 8d8d0d8c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c843359b 9b9d3b9c 3f650000
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v150, 4.0                      ; d66900a2 03db2cf7
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_maxmin_num_f32 v140, -4.0, v143, 4.0                      ; d669008c 03db1ef7
	v_maxmin_num_f32 v164, -4.0, v151, 4.0                      ; d66900a4 03db2ef7
	v_dual_mul_f32 v147, v147, v156 :: v_dual_mul_f32 v146, v146, v155 ; c8c73993 93933792
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84341a1 a19f3f9e 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[8:9], 0  ; cc464060 1a021128
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_mul_f32 v149, v149, v161 :: v_dual_mul_f32 v148, v148, v158 ; c8c74395 95953d94
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 :: v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 ; c8431b8c 8c8b158b 3f650000
	v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 :: v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 ; c8434ba4 a4a345a3 3f650000
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_dual_mul_f32 v143, v143, v140 :: v_dual_mul_f32 v142, v142, v139 ; c8c7198f 8f8f178e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[10:11], v[96:103] ; cc464060 1d821544
	v_dual_mul_f32 v151, v151, v164 :: v_dual_mul_f32 v150, v150, v163 ; c8c74997 97974796
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_maxmin_num_f32 v142, -4.0, v144, 4.0                      ; d669008e 03db20f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[16:17], 0 ; cc464068 1a022128
	v_maxmin_num_f32 v166, -4.0, v96, 4.0                       ; d66900a6 03dac0f7
	v_maxmin_num_f32 v168, -4.0, v97, 4.0                       ; d66900a8 03dac2f7
	v_maxmin_num_f32 v170, -4.0, v98, 4.0                       ; d66900aa 03dac4f7
	v_maxmin_num_f32 v172, -4.0, v99, 4.0                       ; d66900ac 03dac6f7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8433199 998f1f8e 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[20:21], 0 ; cc464070 1a022928
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[30:31], 0 ; cc464078 1a023d28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_mul_f32 v145, v145, v153 :: v_dual_mul_f32 v144, v144, v142 ; c8c73391 91911d90
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[18:19], v[104:111] ; cc464068 1da22544
	v_maxmin_num_f32 v174, -4.0, v100, 4.0                      ; d66900ae 03dac8f7
	v_maxmin_num_f32 v176, -4.0, v101, 4.0                      ; d66900b0 03dacaf7
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[68:69], v[22:23], v[112:119] ; cc464070 1dc22d44
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84351a9 a9a74fa6 3f650000
	v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 :: v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 ; c8435bac acab55ab 3f650000
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[80:81], v[120:127] ; cc464078 1de2a144
	v_maxmin_num_f32 v178, -4.0, v102, 4.0                      ; d66900b2 03daccf7
	v_maxmin_num_f32 v180, -4.0, v103, 4.0                      ; d66900b4 03dacef7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v104, 4.0                      ; d66900b6 03dad0f7
	v_dual_mul_f32 v97, v97, v169 :: v_dual_mul_f32 v96, v96, v166 ; c8c75361 61614d60
	v_dual_mul_f32 v99, v99, v172 :: v_dual_mul_f32 v98, v98, v171 ; c8c75963 63635762
	v_maxmin_num_f32 v184, -4.0, v105, 4.0                      ; d66900b8 03dad2f7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v186, -4.0, v106, 4.0                      ; d66900ba 03dad4f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v107, 4.0                      ; d66900bc 03dad6f7
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84361b1 b1af5fae 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v190, -4.0, v108, 4.0                      ; d66900be 03dad8f7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 :: v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 ; c8436bb4 b4b365b3 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_mul_f32 v101, v101, v177 :: v_dual_mul_f32 v100, v100, v174 ; c8c76365 65655d64
	v_maxmin_num_f32 v13, -4.0, v110, 4.0                       ; d669000d 03dadcf7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84371b9 b9b76fb6 3f650000
	v_maxmin_num_f32 v25, -4.0, v111, 4.0                       ; d6690019 03dadef7
	v_dual_mul_f32 v103, v103, v180 :: v_dual_mul_f32 v102, v102, v179 ; c8c76967 67676766
	v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 :: v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 ; c8437bbc bcbb75bb 3f650000
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v15, 0xab28, |v13|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620f 0bfe1aff 3728ab28
	v_maxmin_num_f32 v29, -4.0, v112, 4.0                       ; d669001d 03dae0f7
	v_maxmin_num_f32 v91, -4.0, v113, 4.0                       ; d669005b 03dae2f7
	v_dual_mul_f32 v105, v105, v185 :: v_dual_mul_f32 v104, v104, v182 ; c8c77369 69696d68
	v_fma_mix_f32 v27, 0xab28, |v25|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe32ff 3728ab28
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 :: v_dual_mul_f32 v107, v107, v188 ; c8477fbe be6b796b 3f650000
	v_maxmin_num_f32 v191, -4.0, v109, 4.0                      ; d66900bf 03dadaf7
	v_maxmin_num_f32 v95, -4.0, v115, 4.0                       ; d669005f 03dae6f7
	v_dual_fmaak_f32 v15, v15, v13, 0x3f650000 :: v_dual_mul_f32 v106, v106, v187 ; c8461b0f 0f6b776a 3f650000
	v_fma_mix_f32 v90, 0xab28, |v29|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfe3aff 3728ab28
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_fmaak_f32 v25, v25, v27, 0x3f650000                       ; 5a323719 3f650000
	v_maxmin_num_f32 v97, -4.0, v116, 4.0                       ; d6690061 03dae8f7
	v_maxmin_num_f32 v99, -4.0, v117, 4.0                       ; d6690063 03daeaf7
	v_fma_mix_f32 v7, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bff7eff 3728ab28
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v93, -4.0, v114, 4.0                       ; d669005d 03dae4f7
	v_dual_fmaak_f32 v29, v29, v90, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842b51d 1d5cb75c 3f650000
	v_dual_mul_f32 v111, v111, v25 :: v_dual_mul_f32 v108, v108, v190 ; c8c6336f 6f6d7d6c
	v_maxmin_num_f32 v103, -4.0, v119, 4.0                      ; d6690067 03daeef7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_fmaak_f32 v7, v7, v191, 0x3f650000                        ; 5a0f7f07 3f650000
	v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 :: v_dual_mul_f32 v110, v110, v15 ; c846c15f 5f6e1f6e 3f650000
	v_maxmin_num_f32 v105, -4.0, v120, 4.0                      ; d6690069 03daf0f7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_mul_f32_e32 v113, v113, v92                               ; 10e2b971
	v_maxmin_num_f32 v107, -4.0, v121, 4.0                      ; d669006b 03daf2f7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v118, 4.0                      ; d6690065 03daecf7
	v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 ; c842c561 6164c764 3f650000
	v_mul_f32_e32 v109, v109, v7                                ; 10da0f6d
	v_dual_mul_f32 v115, v115, v95 :: v_dual_mul_f32 v112, v112, v29 ; c8c6bf73 73703b70
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_dual_mul_f32 v117, v117, v100 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c8c2c975 755ebb5e 3f650000
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v111, -4.0, v123, 4.0                      ; d669006f 03daf6f7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v113, -4.0, v124, 4.0                      ; d6690071 03daf8f7
	v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 :: v_dual_mul_f32 v114, v114, v94 ; c846d167 6772bd72 3f650000
	v_maxmin_num_f32 v109, -4.0, v122, 4.0                      ; d669006d 03daf4f7
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 ; c842d569 696cd76c 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v119, v119, v103 :: v_dual_mul_f32 v116, v116, v97 ; c8c6cf77 7774c374
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v115, -4.0, v125, 4.0                      ; d6690073 03dafaf7
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_dual_mul_f32 v121, v121, v108 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c8c2d979 7966cb66 3f650000
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v117, -4.0, v126, 4.0                      ; d6690075 03dafcf7
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v111, v111, v112, 0x3f650000 :: v_dual_mul_f32 v118, v118, v102 ; c846e16f 6f76cd76 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[8:9], 0  ; cc464060 1a02112a
	v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 ; c842e571 7174e774 3f650000
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v119, -4.0, v127, 4.0                      ; d6690077 03dafef7
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_dual_mul_f32 v123, v123, v111 :: v_dual_mul_f32 v120, v120, v105 ; c8c6df7b 7b78d378
	v_dual_mul_f32 v125, v125, v116 :: v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 ; c8c2e97d 7d6edb6e 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[10:11], v[96:103] ; cc464060 1d821546
	v_dual_fmaak_f32 v119, v119, v120, 0x3f650000 :: v_dual_mul_f32 v122, v122, v110 ; c846f177 777add7a 3f650000
	v_dual_mul_f32 v127, v127, v119 :: v_dual_mul_f32 v124, v124, v113 ; c8c6ef7f 7f7ce37c
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[16:17], 0 ; cc464068 1a02212a
	v_maxmin_num_f32 v130, -4.0, v97, 4.0                       ; d6690082 03dac2f7
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v128, -4.0, v96, 4.0                       ; d6690080 03dac0f7
	v_maxmin_num_f32 v132, -4.0, v98, 4.0                       ; d6690084 03dac4f7
	v_maxmin_num_f32 v134, -4.0, v99, 4.0                       ; d6690086 03dac6f7
	v_maxmin_num_f32 v138, -4.0, v101, 4.0                      ; d669008a 03dacaf7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v140, -4.0, v102, 4.0                      ; d669008c 03daccf7
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[18:19], v[104:111] ; cc464068 1da22546
	v_maxmin_num_f32 v142, -4.0, v103, 4.0                      ; d669008e 03dacef7
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v118, v118, v117, 0x3f650000 ; c8430583 8376eb76 3f650000
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c8430985 85870f86 3f650000
	v_maxmin_num_f32 v136, -4.0, v100, 4.0                      ; d6690088 03dac8f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_dual_mul_f32 v97, v97, v131 :: v_dual_mul_f32 v126, v126, v118 ; c8c70761 617eed7e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[20:21], 0 ; cc464070 1a02292a
	v_dual_mul_f32 v99, v99, v134 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8c30d63 63810380 3f650000
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c843198d 8d8f1f8e 3f650000
	v_maxmin_num_f32 v146, -4.0, v105, 4.0                      ; d6690092 03dad2f7
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[30:31], 0 ; cc464078 1a023d2a
	v_maxmin_num_f32 v148, -4.0, v106, 4.0                      ; d6690094 03dad4f7
	v_maxmin_num_f32 v150, -4.0, v107, 4.0                      ; d6690096 03dad6f7
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_mul_f32 v96, v96, v128 ; c847158b 8b610160 3f650000
	v_dual_mul_f32 v103, v103, v142 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c8c31d67 67891388 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[22:23], v[112:119] ; cc464070 1dc22d46
	v_maxmin_num_f32 v144, -4.0, v104, 4.0                      ; d6690090 03dad0f7
	v_maxmin_num_f32 v154, -4.0, v109, 4.0                      ; d669009a 03dadaf7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_dual_mul_f32 v101, v101, v139 :: v_dual_mul_f32 v98, v98, v133 ; c8c71765 65630b62
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_mul_f32 v100, v100, v136 ; c8472593 93651164 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[80:81], v[120:127] ; cc464078 1de2a146
	v_maxmin_num_f32 v156, -4.0, v110, 4.0                      ; d669009c 03dadcf7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v111, 4.0                      ; d669009e 03dadef7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8432995 95972f96 3f650000
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_mul_f32 v105, v105, v147 :: v_dual_mul_f32 v102, v102, v141 ; c8c72769 69671b66
	v_maxmin_num_f32 v152, -4.0, v108, 4.0                      ; d6690098 03dad8f7
	v_maxmin_num_f32 v162, -4.0, v113, 4.0                      ; d66900a2 03dae2f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_mul_f32 v107, v107, v150 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8c32d6b 6b912390 3f650000
	v_maxmin_num_f32 v164, -4.0, v114, 4.0                      ; d66900a4 03dae4f7
	v_maxmin_num_f32 v166, -4.0, v115, 4.0                      ; d66900a6 03dae6f7
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v112, 4.0                      ; d66900a0 03dae0f7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c843399d 9d9f3f9e 3f650000
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_mul_f32 v104, v104, v144 ; c847359b 9b692168 3f650000
	v_maxmin_num_f32 v170, -4.0, v117, 4.0                      ; d66900aa 03daeaf7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v118, 4.0                      ; d66900ac 03daecf7
	v_dual_mul_f32 v111, v111, v158 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c8c33d6f 6f993398 3f650000
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v174, -4.0, v119, 4.0                      ; d66900ae 03daeef7
	v_dual_mul_f32 v109, v109, v155 :: v_dual_mul_f32 v106, v106, v149 ; c8c7376d 6d6b2b6a
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v116, 4.0                      ; d66900a8 03dae8f7
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84349a5 a5a74fa6 3f650000
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_mul_f32 v108, v108, v152 ; c84745a3 a36d316c 3f650000
	v_maxmin_num_f32 v178, -4.0, v121, 4.0                      ; d66900b2 03daf2f7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v122, 4.0                      ; d66900b4 03daf4f7
	v_dual_mul_f32 v115, v115, v166 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c8c34d73 73a143a0 3f650000
	v_maxmin_num_f32 v182, -4.0, v123, 4.0                      ; d66900b6 03daf6f7
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_dual_mul_f32 v113, v113, v163 :: v_dual_mul_f32 v110, v110, v157 ; c8c74771 716f3b6e
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84359ad adaf5fae 3f650000
	v_maxmin_num_f32 v176, -4.0, v120, 4.0                      ; d66900b0 03daf0f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_mul_f32 v112, v112, v160 ; c84755ab ab714170 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v186, -4.0, v125, 4.0                      ; d66900ba 03dafaf7
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_mul_f32 v119, v119, v174 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c8c35d77 77a953a8 3f650000
	v_maxmin_num_f32 v188, -4.0, v126, 4.0                      ; d66900bc 03dafcf7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v127, 4.0                      ; d66900be 03dafef7
	v_dual_mul_f32 v117, v117, v171 :: v_dual_mul_f32 v114, v114, v165 ; c8c75775 75734b72
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84369b5 b5b76fb6 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v124, 4.0                      ; d66900b8 03daf8f7
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_mul_f32 v116, v116, v168 ; c84765b3 b3755174 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[8:9], 0 ; cc464068 1a021148
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_mul_f32 v123, v123, v182 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c8c36d7b 7bb163b0 3f650000
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_mul_f32 v121, v121, v179 :: v_dual_mul_f32 v118, v118, v173 ; c8c76779 79775b76
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c84379bd bdbf7fbe 3f650000
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_mul_f32 v120, v120, v176 ; c84775bb bb796178 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[76:77], v[10:11], v[104:111] ; cc464068 1da2154c
	v_dual_mul_f32 v127, v127, v190 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8c37d7f 7fb973b8 3f650000
	v_dual_mul_f32 v125, v125, v187 :: v_dual_mul_f32 v122, v122, v181 ; c8c7777d 7d7b6b7a
(invalid instruction)                                        ; d7690060
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[72:73], v[16:17], 0 ; cc464070 1a022148
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[30:31], 0 ; cc464080 1a023d48
(invalid instruction)                                        ; d7694060
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v29, -4.0, v107, 4.0                       ; d669001d 03dad6f7
	v_maxmin_num_f32 v25, -4.0, v106, 4.0                       ; d6690019 03dad4f7
	v_maxmin_num_f32 v191, -4.0, v104, 4.0                      ; d66900bf 03dad0f7
	v_maxmin_num_f32 v13, -4.0, v105, 4.0                       ; d669000d 03dad2f7
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[76:77], v[18:19], v[112:119] ; cc464070 1dc2254c
	v_fma_mix_f32 v27, 0xab28, |v25|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe32ff 3728ab28
	v_fma_mix_f32 v7, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bff7eff 3728ab28
	v_fma_mix_f32 v15, 0xab28, |v13|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620f 0bfe1aff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[80:81], v[128:135] ; cc464080 1e02a14c
	v_maxmin_num_f32 v98, -4.0, v109, 4.0                       ; d6690062 03dadaf7
	v_dual_fmaak_f32 v27, v25, v27, 0x3f650000 :: v_dual_mul_f32 v126, v126, v189 ; c8463719 1b7f7b7e 3f650000
	v_dual_fmaak_f32 v191, v191, v7, 0x3f650000 :: v_dual_mul_f32 v124, v124, v184 ; c8460fbf bf7d717c 3f650000
	v_fmaak_f32 v15, v15, v13, 0x3f650000                       ; 5a1e1b0f 3f650000
	v_maxmin_num_f32 v100, -4.0, v110, 4.0                      ; d6690064 03dadcf7
	v_maxmin_num_f32 v102, -4.0, v111, 4.0                      ; d6690066 03dadef7
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
(invalid instruction)                                        ; d7690061
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694061
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[20:21], 0 ; cc464078 1a022948
	v_fma_mix_f32 v73, 0xab28, |v29|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206249 0bfe3aff 3728ab28
	v_mul_f32_e32 v105, v105, v15                               ; 10d21f69
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_dual_fmaak_f32 v29, v29, v73, 0x3f650000 :: v_dual_mul_f32 v104, v104, v191 ; c846931d 1d697f68 3f650000
	v_dual_fmaak_f32 v101, v101, v100, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 ; c842c965 6566cf66 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[76:77], v[22:23], v[120:127] ; cc464078 1de22d4c
	v_maxmin_num_f32 v76, -4.0, v108, 4.0                       ; d669004c 03dad8f7
	v_dual_mul_f32 v107, v107, v29 :: v_dual_mul_f32 v106, v106, v27 ; c8c63b6b 6b6a376a
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v104, -4.0, v112, 4.0                      ; d6690068 03dae0f7
	v_dual_mul_f32 v111, v111, v102 :: v_dual_mul_f32 v110, v110, v101 ; c8c6cd6f 6f6ecb6e
	v_fma_mix_f32 v77, 0xab28, |v76|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624d 0bfe98ff 3728ab28
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v106, -4.0, v113, 4.0                      ; d669006a 03dae2f7
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_fmaak_f32 v76, v76, v77, 0x3f650000 ; c842c563 634c9b4c 3f650000
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v109, v109, v99 :: v_dual_mul_f32 v108, v108, v76 ; c8c6c76d 6d6c996c
	v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 ; c842d56b 6b68d368 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870252
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v108, -4.0, v114, 4.0                      ; d669006c 03dae4f7
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v110, -4.0, v115, 4.0                      ; d669006e 03dae6f7
	v_dual_mul_f32 v113, v113, v107 :: v_dual_mul_f32 v112, v112, v104 ; c8c6d771 7170d170
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v119, 4.0                      ; d6690088 03daeef7
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v116, 4.0                      ; d6690070 03dae8f7
	v_maxmin_num_f32 v138, -4.0, v120, 4.0                      ; d669008a 03daf0f7
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842d96d 6d6edf6e 3f650000
	v_maxmin_num_f32 v140, -4.0, v121, 4.0                      ; d669008c 03daf2f7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v122, 4.0                      ; d669008e 03daf4f7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_dual_mul_f32 v115, v115, v110 :: v_dual_mul_f32 v114, v114, v109 ; c8c6dd73 7372db72
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v123, 4.0                      ; d6690090 03daf6f7
	v_fmaak_f32 v136, v136, v137, 0x3f650000                    ; 5b111388 3f650000
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v117, 4.0                      ; d6690072 03daeaf7
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c843198d 8d8b178a 3f650000
	v_maxmin_num_f32 v146, -4.0, v124, 4.0                      ; d6690092 03daf8f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v125, 4.0                      ; d6690094 03dafaf7
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v126, 4.0                      ; d6690096 03dafcf7
	v_dual_mul_f32 v120, v138, v120 :: v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 ; c8c2f18a 788f1d8f 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 :: v_dual_mul_f32 v119, v119, v136 ; c8472390 90771177 3f650000
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v127, 4.0                      ; d6690098 03dafef7
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_mul_f32 v122, v122, v143 :: v_dual_mul_f32 v121, v121, v141 ; c8c71f7a 7a791b79
	v_maxmin_num_f32 v154, -4.0, v128, 4.0                      ; d669009a 03db00f7
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8432995 95932792 3f650000
	v_maxmin_num_f32 v156, -4.0, v129, 4.0                      ; d669009c 03db02f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_mul_f32 v117, v117, v115 :: v_dual_mul_f32 v116, v116, v112 ; c8c6e775 7574e174
(invalid instruction)                                        ; d7690062
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_mul_f32 v124, v146, v124 :: v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 ; c8c2f992 7c972d97 3f650000
	buffer_load_b128 v[100:103], v5, s[20:23], null offen offset:3072 ; c405c07c 40802864 000c0005
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v130, 4.0                      ; d669009e 03db04f7
	v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 :: v_dual_mul_f32 v123, v123, v144 ; c8473398 987b217b 3f650000
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v116, -4.0, v118, 4.0                      ; d6690074 03daecf7
	buffer_load_b128 v[108:111], v5, s[20:23], null offen offset:3584 ; c405c07c 4080286c 000e0005
	v_dual_mul_f32 v126, v126, v151 :: v_dual_mul_f32 v125, v125, v149 ; c8c72f7e 7e7d2b7d
	v_maxmin_num_f32 v160, -4.0, v131, 4.0                      ; d66900a0 03db06f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_mul_f32 v127, v127, v152 ; c847379a 9a7f317f 3f650000
(invalid instruction)                                        ; d7694062
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v164, -4.0, v133, 4.0                      ; d66900a4 03db0af7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7690063
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v134, 4.0                      ; d66900a6 03db0cf7
	v_fmaak_f32 v159, v159, v158, 0x3f650000                    ; 5b3f3d9f 3f650000
	v_maxmin_num_f32 v168, -4.0, v135, 4.0                      ; d66900a8 03db0ef7
(invalid instruction)                                        ; d7694063
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v128, v128, v154 ; c847399d 9d813580 3f650000
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v132, 4.0                      ; d66900a2 03db08f7
	v_fmaak_f32 v117, v117, v116, 0x3f650000                    ; 5aeae975 3f650000
	v_fmaak_f32 v160, v160, v161, 0x3f650000                    ; 5b4143a0 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_mul_f32 v129, v129, v157 :: v_dual_mul_f32 v130, v130, v159 ; c8c73b81 81833f82
	v_fmaak_f32 v165, v165, v164, 0x3f650000                    ; 5b4b49a5 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_mul_f32_e32 v118, v118, v117                              ; 10eceb76
	v_mul_f32_e32 v131, v131, v160                              ; 11074183
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c8434da7 a7a953a8 3f650000
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_mul_f32_e32 v133, v133, v165                              ; 110b4b85
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[8:9], 0 ; cc464070 1a02114a
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v135, v135, v168 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8c35187 87a347a2 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[16:17], 0 ; cc464078 1a02214a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[78:79], v[10:11], v[112:119] ; cc464070 1dc2154e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[30:31], 0 ; cc464088 1a023d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[78:79], v[18:19], v[120:127] ; cc464078 1de2254e
	v_maxmin_num_f32 v176, -4.0, v115, 4.0                      ; d66900b0 03dae6f7
	v_maxmin_num_f32 v170, -4.0, v112, 4.0                      ; d66900aa 03dae0f7
	v_maxmin_num_f32 v174, -4.0, v114, 4.0                      ; d66900ae 03dae4f7
	v_maxmin_num_f32 v172, -4.0, v113, 4.0                      ; d66900ac 03dae2f7
	v_maxmin_num_f32 v180, -4.0, v117, 4.0                      ; d66900b4 03daeaf7
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[78:79], v[80:81], v[136:143] ; cc464088 1e22a14e
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v118, 4.0                      ; d66900b6 03daecf7
	v_maxmin_num_f32 v184, -4.0, v119, 4.0                      ; d66900b8 03daeef7
	v_maxmin_num_f32 v178, -4.0, v116, 4.0                      ; d66900b2 03dae8f7
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c8435daf afb163b0 3f650000
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v132, v132, v162 ; c84759ad ad854584 3f650000
	v_maxmin_num_f32 v188, -4.0, v121, 4.0                      ; d66900bc 03daf2f7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v122, 4.0                      ; d66900be 03daf4f7
	v_dual_mul_f32 v115, v115, v176 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8c36173 73ab57aa 3f650000
	v_dual_mul_f32 v113, v113, v173 :: v_dual_mul_f32 v134, v134, v167 ; c8c75b71 71874f86
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8436db7 b7b973b8 3f650000
	v_maxmin_num_f32 v186, -4.0, v120, 4.0                      ; d66900ba 03daf0f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v112, v112, v170 ; c84769b5 b5715570 3f650000
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[20:21], 0 ; cc464080 1a02294a
	v_dual_mul_f32 v119, v119, v184 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c8c37177 77b367b2 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_mul_f32 v118, v118, v183 ; c8477dbf bf776f76 3f650000
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_dual_mul_f32 v117, v117, v181 :: v_dual_mul_f32 v114, v114, v175 ; c8c76b75 75735f72
	v_maxmin_num_f32 v7, -4.0, v124, 4.0                        ; d6690007 03daf8f7
	v_maxmin_num_f32 v15, -4.0, v125, 4.0                       ; d669000f 03dafaf7
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v116, v116, v178 ; c84779bd bd756574 3f650000
	v_maxmin_num_f32 v27, -4.0, v126, 4.0                       ; d669001b 03dafcf7
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v13, 0xab28, |v7|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bfe0eff 3728ab28
	v_maxmin_num_f32 v106, -4.0, v127, 4.0                      ; d669006a 03dafef7
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[78:79], v[22:23], v[128:135] ; cc464080 1e022d4e
	v_fma_mix_f32 v25, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe1eff 3728ab28
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_mul_f32 v121, v121, v189 :: v_dual_mul_f32 v122, v122, v191 ; c8c77b79 797b7f7a
	v_maxmin_num_f32 v191, -4.0, v123, 4.0                      ; d66900bf 03daf6f7
	v_fma_mix_f32 v29, 0xab28, |v27|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe36ff 3728ab28
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_fmaak_f32 v25, v25, v15, 0x3f650000                       ; 5a321f19 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v128, 4.0                      ; d6690070 03db00f7
	v_dual_fmaak_f32 v29, v27, v29, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v107, 0x3f650000 ; c8423b1b 1d6ad76a 3f650000
	v_maxmin_num_f32 v114, -4.0, v129, 4.0                      ; d6690072 03db02f7
	v_maxmin_num_f32 v116, -4.0, v130, 4.0                      ; d6690074 03db04f7
	v_maxmin_num_f32 v118, -4.0, v131, 4.0                      ; d6690076 03db06f7
	v_dual_fmaak_f32 v191, v191, v5, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8420bbf bfbb77ba 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_dual_mul_f32 v127, v127, v106 :: v_dual_mul_f32 v126, v126, v29 ; c8c6d57f 7f7e3b7e
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_dual_fmaak_f32 v7, v7, v13, 0x3f650000 :: v_dual_mul_f32 v120, v120, v186 ; c8461b07 07797578 3f650000
	v_mul_f32_e32 v123, v123, v191                              ; 10f77f7b
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v116, 0x3f650000 ; c842ef76 7674e975 3f650000
	v_dual_mul_f32 v125, v125, v25 :: v_dual_mul_f32 v124, v124, v7 ; c8c6337d 7d7c0f7c
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v132, 4.0                      ; d6690078 03db08f7
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v122, -4.0, v133, 4.0                      ; d669007a 03db0af7
	v_dual_mul_f32 v129, v129, v115 :: v_dual_mul_f32 v128, v128, v112 ; c8c6e781 8180e180
	v_dual_mul_f32 v131, v131, v118 :: v_dual_mul_f32 v130, v130, v117 ; c8c6ed83 8382eb82
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v124, -4.0, v134, 4.0                      ; d669007c 03db0cf7
	v_maxmin_num_f32 v126, -4.0, v135, 4.0                      ; d669007e 03db0ef7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
(invalid instruction)                                        ; d769006a
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v128, -4.0, v136, 4.0                      ; d6690080 03db10f7
(invalid instruction)                                        ; d769406a
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v130, -4.0, v137, 4.0                      ; d6690082 03db12f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c842f57b 7b78f378 3f650000
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v126, v126, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 ; c842ff7e 7e7cf97d 3f650000
	v_dual_mul_f32 v133, v133, v123 :: v_dual_mul_f32 v132, v132, v120 ; c8c6f785 8584f184
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v135, v135, v126 :: v_dual_mul_f32 v134, v134, v125 ; c8c6fd87 8786fb86
(invalid instruction)                                        ; d769006b
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v132, -4.0, v138, 4.0                      ; d6690084 03db14f7
	v_dual_mul_f32 v137, v137, v131 :: v_dual_mul_f32 v136, v136, v128 ; c8c70789 89890188
(invalid instruction)                                        ; d769406b
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v134, -4.0, v139, 4.0                      ; d6690086 03db16f7
	v_maxmin_num_f32 v144, -4.0, v143, 4.0                      ; d6690090 03db1ef7
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
(invalid instruction)                                        ; d7690070
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_maxmin_num_f32 v136, -4.0, v140, 4.0                      ; d6690088 03db18f7
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c8430985 85870f86 3f650000
	v_dual_mul_f32 v139, v139, v134 :: v_dual_mul_f32 v138, v138, v133 ; c8c70d8b 8b8b0b8a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d7694070
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_maxmin_num_f32 v138, -4.0, v141, 4.0                      ; d669008a 03db1af7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c843158b 8b891388 3f650000
	v_dual_mul_f32 v141, v141, v139 :: v_dual_mul_f32 v140, v140, v136 ; c8c7178d 8d8d118c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d7690071
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_maxmin_num_f32 v140, -4.0, v142, 4.0                      ; d669008c 03db1cf7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 ; c8432390 908d198d 3f650000
	v_mul_f32_e32 v143, v143, v144                              ; 111f218f
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[100:101], v[8:9], 0 ; cc464078 1a021164
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[100:101], v[16:17], 0 ; cc464080 1a022164
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[30:31], 0 ; cc464090 1a023d64
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[108:109], v[10:11], v[120:127] ; cc464078 1de2156c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[108:109], v[18:19], v[128:135] ; cc464080 1e02256c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[80:81], v[144:151] ; cc464090 1e42a16c
	v_maxmin_num_f32 v158, -4.0, v123, 4.0                      ; d669009e 03daf6f7
	v_maxmin_num_f32 v154, -4.0, v121, 4.0                      ; d669009a 03daf2f7
	v_maxmin_num_f32 v152, -4.0, v120, 4.0                      ; d6690098 03daf0f7
	v_maxmin_num_f32 v156, -4.0, v122, 4.0                      ; d669009c 03daf4f7
	v_maxmin_num_f32 v162, -4.0, v125, 4.0                      ; d66900a2 03dafaf7
	v_maxmin_num_f32 v164, -4.0, v126, 4.0                      ; d66900a4 03dafcf7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v127, 4.0                      ; d66900a6 03dafef7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v124, 4.0                      ; d66900a0 03daf8f7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v170, -4.0, v129, 4.0                      ; d66900aa 03db02f7
	v_fmaak_f32 v155, v155, v154, 0x3f650000                    ; 5b37359b 3f650000
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c843399d 9d9f3f9e 3f650000
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v130, 4.0                      ; d66900ac 03db04f7
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84349a5 a5a74fa6 3f650000
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v131, 4.0                      ; d66900ae 03db06f7
	v_dual_mul_f32 v121, v121, v155 :: v_dual_mul_f32 v142, v142, v141 ; c8c73779 798f1b8e
	v_dual_mul_f32 v123, v123, v158 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c8c33d7b 7b993398 3f650000
	v_maxmin_num_f32 v168, -4.0, v128, 4.0                      ; d66900a8 03db00f7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_mul_f32 v127, v127, v166 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c8c34d7f 7fa143a0 3f650000
	v_maxmin_num_f32 v178, -4.0, v133, 4.0                      ; d66900b2 03db0af7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
(invalid instruction)                                        ; d7694071
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[100:101], v[20:21], 0 ; cc464088 1a022964
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_mul_f32 v120, v120, v152 ; c84745a3 a3793178 3f650000
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_mul_f32 v124, v124, v160 ; c84755ab ab7d417c 3f650000
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84359ad adaf5fae 3f650000
	v_maxmin_num_f32 v180, -4.0, v134, 4.0                      ; d66900b4 03db0cf7
	v_maxmin_num_f32 v182, -4.0, v135, 4.0                      ; d66900b6 03db0ef7
	v_maxmin_num_f32 v176, -4.0, v132, 4.0                      ; d66900b0 03db08f7
	v_dual_mul_f32 v125, v125, v163 :: v_dual_mul_f32 v122, v122, v157 ; c8c7477d 7d7b3b7a
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v129, v129, v171 :: v_dual_mul_f32 v126, v126, v165 ; c8c75781 817f4b7e
	v_dual_mul_f32 v131, v131, v174 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c8c35d83 83a953a8 3f650000
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[22:23], v[136:143] ; cc464088 1e222d6c
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
(invalid instruction)                                        ; d7694064
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_mul_f32 v128, v128, v168 ; c84765b3 b3815180 3f650000
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84369b5 b5b76fb6 3f650000
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769006c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v133, v133, v179 :: v_dual_mul_f32 v130, v130, v173 ; c8c76785 85835b82
	v_dual_mul_f32 v135, v135, v182 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c8c36d87 87b163b0 3f650000
	v_maxmin_num_f32 v188, -4.0, v138, 4.0                      ; d66900bc 03db14f7
	v_maxmin_num_f32 v190, -4.0, v139, 4.0                      ; d66900be 03db16f7
	v_maxmin_num_f32 v186, -4.0, v137, 4.0                      ; d66900ba 03db12f7
	v_maxmin_num_f32 v184, -4.0, v136, 4.0                      ; d66900b8 03db10f7
	v_maxmin_num_f32 v7, -4.0, v141, 4.0                        ; d6690007 03db1af7
(invalid instruction)                                        ; d769406c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_maxmin_num_f32 v15, -4.0, v142, 4.0                       ; d669000f 03db1cf7
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v13, 0xab28, |v7|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bfe0eff 3728ab28
	v_maxmin_num_f32 v27, -4.0, v143, 4.0                       ; d669001b 03db1ef7
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c84379bd bdbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v140, 4.0                      ; d66900bf 03db18f7
	v_fma_mix_f32 v25, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe1eff 3728ab28
	v_maxmin_num_f32 v116, -4.0, v144, 4.0                      ; d6690074 03db20f7
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_mul_f32 v132, v132, v176 ; c84775bb bb856184 3f650000
	v_fma_mix_f32 v29, 0xab28, |v27|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe36ff 3728ab28
	v_maxmin_num_f32 v118, -4.0, v145, 4.0                      ; d6690076 03db22f7
	v_dual_fmaak_f32 v13, v13, v7, 0x3f650000 :: v_dual_mul_f32 v138, v138, v189 ; c8460f0d 0d8b7b8a 3f650000
	v_dual_mul_f32 v139, v139, v190 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8c37d8b 8bb973b8 3f650000
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d769006d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_add_lshl_u32 v120, s8, v1, 2                              ; d6470078 020a0208
	v_dual_mul_f32 v137, v137, v187 :: v_dual_mul_f32 v134, v134, v181 ; c8c77789 89876b86
	s_mov_b64 s[32:33], s[24:25]                                ; bea00118
	s_mov_b64 s[34:35], s[26:27]                                ; bea2011a
	buffer_load_b128 v[124:127], v120, s[32:35], null offen     ; c405c07c 4080407c 00000078
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_mul_f32_e32 v141, v141, v13                               ; 111a1b8d
	buffer_load_b128 v[128:131], v120, s[32:35], null offen offset:16 ; c405c07c 40804080 00001078
	v_maxmin_num_f32 v121, -4.0, v146, 4.0                      ; d6690079 03db24f7
	v_dual_fmaak_f32 v191, v191, v5, 0x3f650000 :: v_dual_mul_f32 v136, v136, v184 ; c8460bbf bf897188 3f650000
(invalid instruction)                                        ; d769406d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v123, -4.0, v147, 4.0                      ; d669007b 03db26f7
	v_maxmin_num_f32 v133, -4.0, v148, 4.0                      ; d6690085 03db28f7
	v_maxmin_num_f32 v135, -4.0, v149, 4.0                      ; d6690087 03db2af7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
(invalid instruction)                                        ; d7690072
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694072
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_fmaak_f32 v25, v15, v25, 0x3f650000 :: v_dual_mul_f32 v140, v140, v191 ; c846330f 198d7f8c 3f650000
	v_fma_mix_f32 v132, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bfef6ff 3728ab28
	v_maxmin_num_f32 v137, -4.0, v150, 4.0                      ; d6690089 03db2cf7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v151, 4.0                      ; d669008b 03db2ef7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
(invalid instruction)                                        ; d7690073
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_fmaak_f32 v27, v29, v27, 0x3f650000 :: v_dual_mul_f32 v142, v142, v25 ; c846371d 1b8e338e 3f650000
	v_fmaak_f32 v123, v123, v132, 0x3f650000                    ; 5af7097b 3f650000
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 ; c8430d85 85890f88 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[102:103], v[20:21], 0 ; cc464098 1a022966
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	v_dual_mul_f32 v143, v143, v27 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c8c2378f 8f74eb74 3f650000
	v_dual_mul_f32 v149, v149, v136 :: v_dual_mul_f32 v148, v148, v133 ; c8c71195 95950b94
	v_add_lshl_u32 v160, s4, v3, 2                              ; d64700a0 020a0604
	buffer_load_b128 v[132:135], v160, s[20:23], null offen     ; c405c07c 40802884 000000a0
	v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 ; c843198b 8b8b138a 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[102:103], v[30:31], 0 ; cc4640a8 1a023d66
(invalid instruction)                                        ; d7694073
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_dual_mul_f32 v151, v151, v139 :: v_dual_mul_f32 v150, v150, v138 ; c8c71797 97971596
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[102:103], v[8:9], 0 ; cc464088 1a021166
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[110:111], v[10:11], v[136:143] ; cc464088 1e22156e
	buffer_load_b128 v[8:11], v160, s[20:23], null offen offset:512 ; c405c07c 40802808 000200a0
	v_dual_fmaak_f32 v119, v119, v118, 0x3f650000 :: v_dual_mul_f32 v144, v144, v116 ; c846ed77 7790e990 3f650000
(invalid instruction)                                        ; d7690075
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[110:111], v[22:23], v[152:159] ; cc464098 1e622d6e
(invalid instruction)                                        ; d7694075
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 :: v_dual_mul_f32 v145, v145, v119 ; c846f37a 7a90ef91 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d7690074
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_dual_mul_f32 v147, v147, v123 :: v_dual_mul_f32 v146, v146, v122 ; c8c6f793 9392f592
(invalid instruction)                                        ; d7694074
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[102:103], v[16:17], 0 ; cc464090 1a022166
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[110:111], v[18:19], v[144:151] ; cc464090 1e42256e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v160, s[20:23], null offen offset:1024 ; c405c07c 40802810 000400a0
	buffer_load_b128 v[176:179], v160, s[20:23], null offen offset:1536 ; c405c07c 408028b0 000600a0
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[110:111], v[80:81], v[168:175] ; cc4640a8 1ea2a16e
	v_maxmin_num_f32 v163, -4.0, v137, 4.0                      ; d66900a3 03db12f7
	v_maxmin_num_f32 v161, -4.0, v136, 4.0                      ; d66900a1 03db10f7
	v_maxmin_num_f32 v165, -4.0, v138, 4.0                      ; d66900a5 03db14f7
	v_maxmin_num_f32 v167, -4.0, v139, 4.0                      ; d66900a7 03db16f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_fma_mix_f32 v180, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff4eff 3728ab28
	v_maxmin_num_f32 v181, -4.0, v140, 4.0                      ; d66900b5 03db18f7
	v_fmaak_f32 v164, v164, v163, 0x3f650000                    ; 5b4947a4 3f650000
	v_fmaak_f32 v161, v161, v162, 0x3f650000                    ; 5b4345a1 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fmaak_f32 v167, v167, v180, 0x3f650000                    ; 5b4f69a7 3f650000
	v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 :: v_dual_mul_f32 v137, v137, v164 ; c8474ba6 a6894989 3f650000
	v_mul_f32_e32 v136, v136, v161                              ; 11114388
	v_maxmin_num_f32 v183, -4.0, v141, 4.0                      ; d66900b7 03db1af7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v139, v139, v167 :: v_dual_mul_f32 v138, v138, v166 ; c8c74f8b 8b8b4d8a
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fmaak_f32 v181, v181, v182, 0x3f650000                    ; 5b6b6db5 3f650000
	v_maxmin_num_f32 v185, -4.0, v142, 4.0                      ; d66900b9 03db1cf7
	v_maxmin_num_f32 v187, -4.0, v143, 4.0                      ; d66900bb 03db1ef7
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_fmaak_f32 v184, v184, v183, 0x3f650000                    ; 5b716fb8 3f650000
	v_mul_f32_e32 v140, v140, v181                              ; 11196b8c
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 :: v_dual_mul_f32 v141, v141, v184 ; c84773ba ba8d718d 3f650000
	v_fmaak_f32 v187, v187, v188, 0x3f650000                    ; 5b7779bb 3f650000
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v187 :: v_dual_mul_f32 v142, v142, v186 ; c8c7778f 8f8f758e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[136:139], v160, s[20:23], null offen offset:2048 ; c405c07c 40802888 000800a0
	buffer_load_b128 v[164:167], v160, s[20:23], null offen offset:2560 ; c405c07c 408028a4 000a00a0
	buffer_load_b128 v[180:183], v160, s[20:23], null offen offset:3072 ; c405c07c 408028b4 000c00a0
	buffer_load_b128 v[140:143], v160, s[20:23], null offen offset:3584 ; c405c07c 4080288c 000e00a0
	v_maxmin_num_f32 v189, -4.0, v144, 4.0                      ; d66900bd 03db20f7
	v_maxmin_num_f32 v191, -4.0, v145, 4.0                      ; d66900bf 03db22f7
	v_maxmin_num_f32 v7, -4.0, v146, 4.0                        ; d6690007 03db24f7
	v_maxmin_num_f32 v15, -4.0, v147, 4.0                       ; d669000f 03db26f7
	v_maxmin_num_f32 v25, -4.0, v148, 4.0                       ; d6690019 03db28f7
	v_maxmin_num_f32 v29, -4.0, v149, 4.0                       ; d669001d 03db2af7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	v_fma_mix_f32 v13, 0xab28, |v7|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bfe0eff 3728ab28
	v_maxmin_num_f32 v31, -4.0, v150, 4.0                       ; d669001f 03db2cf7
	v_fma_mix_f32 v23, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206217 0bfe1eff 3728ab28
	v_fmaak_f32 v189, v189, v190, 0x3f650000                    ; 5b7b7dbd 3f650000
	v_fmaak_f32 v5, v5, v191, 0x3f650000                        ; 5a0b7f05 3f650000
	v_fmaak_f32 v13, v13, v7, 0x3f650000                        ; 5a1a0f0d 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v15, v15, v23, 0x3f650000 :: v_dual_mul_f32 v144, v144, v189 ; c8462f0f 0f917b90 3f650000
	v_fma_mix_f32 v27, 0xab28, |v25|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe32ff 3728ab28
	v_mul_f32_e32 v145, v145, v5                                ; 11220b91
	v_dual_mul_f32 v147, v147, v15 :: v_dual_mul_f32 v146, v146, v13 ; c8c61f93 93921b92
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[144:147], v120, s[32:35], null offen offset:64 ; c405c07c 40804090 00004078
	buffer_load_b128 v[120:123], v120, s[32:35], null offen offset:80 ; c405c07c 40804078 00005078
	v_fma_mix_f32 v30, 0xab28, |v29|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621e 0bfe3aff 3728ab28
	v_maxmin_num_f32 v81, -4.0, v151, 4.0                       ; d6690051 03db2ef7
	v_fma_mix_f32 v80, 0xab28, |v31|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe3eff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v152, 4.0                      ; d6690067 03db30f7
	v_maxmin_num_f32 v111, -4.0, v153, 4.0                      ; d669006f 03db32f7
	v_maxmin_num_f32 v119, -4.0, v154, 4.0                      ; d6690077 03db34f7
	v_dual_fmaak_f32 v25, v25, v27, 0x3f650000 :: v_dual_fmaak_f32 v30, v30, v29, 0x3f650000 ; c8423719 191e3b1e 3f650000
	v_fma_mix_f32 v102, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfea2ff 3728ab28
	v_fmaak_f32 v80, v80, v31, 0x3f650000                       ; 5aa03f50 3f650000
	v_fma_mix_f32 v110, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfeceff 3728ab28
	v_fma_mix_f32 v118, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfedeff 3728ab28
	v_dual_mul_f32 v149, v149, v30 :: v_dual_mul_f32 v148, v148, v25 ; c8c63d95 95943394
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v150, v150, v80 :: v_dual_fmaak_f32 v81, v81, v102, 0x3f650000 ; c8c2a196 9650cd51 3f650000
	v_dual_fmaak_f32 v103, v103, v110, 0x3f650000 :: v_dual_fmaak_f32 v118, v118, v111, 0x3f650000 ; c842dd67 6776df76 3f650000
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v149, -4.0, v155, 4.0                      ; d6690095 03db36f7
	v_fma_mix_f32 v148, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bfeeeff 3728ab28
	v_mul_f32_e32 v151, v151, v81                               ; 112ea397
	v_dual_mul_f32 v153, v153, v118 :: v_dual_mul_f32 v152, v152, v103 ; c8c6ed99 9998cf98
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_maxmin_num_f32 v151, -4.0, v156, 4.0                      ; d6690097 03db38f7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v153, -4.0, v157, 4.0                      ; d6690099 03db3af7
	v_maxmin_num_f32 v161, -4.0, v168, 4.0                      ; d66900a1 03db50f7
	v_maxmin_num_f32 v163, -4.0, v169, 4.0                      ; d66900a3 03db52f7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v119, 0x3f650000 ; c8432d95 9594ef94 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v187, -4.0, v171, 4.0                      ; d66900bb 03db56f7
	v_fma_mix_f32 v184, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff46ff 3728ab28
	v_dual_mul_f32 v155, v155, v149 :: v_dual_mul_f32 v154, v154, v148 ; c8c72b9b 9b9b299a
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v172, 4.0                      ; d66900bd 03db58f7
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v163, 0x3f650000 ; c84345a1 a1b947b8 3f650000
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v155, -4.0, v158, 4.0                      ; d669009b 03db3cf7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v170, 4.0                      ; d66900b9 03db54f7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v173, 4.0                      ; d66900bf 03db5af7
	v_mul_f32_e32 v169, v169, v184                              ; 115371a9
	v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 :: v_dual_fmaak_f32 v151, v151, v152, 0x3f650000 ; c843339a 9a973197 3f650000
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v7, -4.0, v174, 4.0                        ; d6690007 03db5cf7
	v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 :: v_dual_mul_f32 v168, v168, v161 ; c8477dbd bda943a8 3f650000
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	v_maxmin_num_f32 v15, -4.0, v175, 4.0                       ; d669000f 03db5ef7
	v_dual_mul_f32 v157, v157, v154 :: v_dual_mul_f32 v156, v156, v151 ; c8c7359d 9d9d2f9c
	v_fma_mix_f32 v13, 0xab28, |v7|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bfe0eff 3728ab28
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_dual_fmaak_f32 v5, v5, v191, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c8437f05 05bb73ba 3f650000
	v_fma_mix_f32 v25, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe1eff 3728ab28
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_maxmin_num_f32 v157, -4.0, v159, 4.0                      ; d669009d 03db3ef7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_mul_f32_e32 v173, v173, v5                                ; 115a0bad
	v_dual_fmaak_f32 v13, v13, v7, 0x3f650000 :: v_dual_mul_f32 v170, v170, v186 ; c8460f0d 0dab75aa 3f650000
	v_dual_fmaak_f32 v15, v25, v15, 0x3f650000 :: v_dual_mul_f32 v172, v172, v189 ; c8461f19 0fad7bac 3f650000
	v_fma_mix_f32 v160, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3aff 3728ab28
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 ; c84379bb bb9d379c 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_dual_mul_f32 v175, v175, v15 :: v_dual_mul_f32 v174, v174, v13 ; c8c61faf afae1bae
	v_fmaak_f32 v157, v157, v160, 0x3f650000                    ; 5b3b419d 3f650000
	v_dual_mul_f32 v171, v171, v187 :: v_dual_mul_f32 v158, v158, v156 ; c8c777ab ab9f399e
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mix_f32 v154, v45, v126, neg(0) op_sel_hi:[1,0,0]     ; cc20009a 8a02fd2d
	v_fma_mix_f32 v155, v45, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089b 8a02ff2d
	v_fma_mix_f32 v153, v44, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a02fb2c
	v_fma_mix_f32 v152, v44, v124, neg(0) op_sel_hi:[1,0,0]     ; cc200098 8a02f92c
	v_fma_mix_f32 v168, v52, v124, neg(0) op_sel_hi:[1,0,0]     ; cc2000a8 8a02f934
	v_fma_mix_f32 v169, v52, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a02fb34
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mix_f32 v172, v54, v128, neg(0) op_sel_hi:[1,0,0]     ; cc2000ac 8a030136
	v_fma_mix_f32 v173, v54, v129, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ad 8a030336
	v_fma_mix_f32 v174, v55, v130, neg(0) op_sel_hi:[1,0,0]     ; cc2000ae 8a030537
	v_fma_mix_f32 v156, v46, v128, neg(0) op_sel_hi:[1,0,0]     ; cc20009c 8a03012e
	v_mul_f32_e32 v159, v159, v157                              ; 113f3b9f
	v_fma_mix_f32 v157, v46, v129, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a03032e
	v_fma_mix_f32 v175, v55, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a030737
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_fma_mix_f32 v159, v47, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089f 8a03072f
	v_fma_mix_f32 v158, v47, v130, neg(0) op_sel_hi:[1,0,0]     ; cc20009e 8a03052f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v27, s5, v3, 2                               ; d647001b 020a0605
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_fma_mix_f32 v170, v53, v126, neg(0) op_sel_hi:[1,0,0]     ; cc2000aa 8a02fd35
	v_fma_mix_f32 v171, v53, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ab 8a02ff35
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v27, s[20:23], null offen        ; c405c07c 4080282c 0000001b
	buffer_load_b128 v[52:55], v27, s[20:23], null offen offset:1024 ; c405c07c 40802834 0004001b
	v_fma_mix_f32 v184, v60, v124, neg(0) op_sel_hi:[1,0,0]     ; cc2000b8 8a02f93c
	v_fma_mix_f32 v185, v60, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a02fb3c
	v_fma_mix_f32 v186, v61, v126, neg(0) op_sel_hi:[1,0,0]     ; cc2000ba 8a02fd3d
	v_fma_mix_f32 v187, v61, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a02ff3d
	v_fma_mix_f32 v188, v62, v128, neg(0) op_sel_hi:[1,0,0]     ; cc2000bc 8a03013e
	v_fma_mix_f32 v189, v62, v129, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a03033e
	v_fma_mix_f32 v190, v63, v130, neg(0) op_sel_hi:[1,0,0]     ; cc2000be 8a03053f
	v_fma_mix_f32 v191, v63, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a03073f
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[60:63], v27, s[20:23], null offen offset:2048 ; c405c07c 4080283c 0008001b
	buffer_load_b128 v[148:151], v27, s[20:23], null offen offset:512 ; c405c07c 40802894 0002001b
	buffer_load_b128 v[160:163], v27, s[20:23], null offen offset:1536 ; c405c07c 408028a0 0006001b
	v_fma_mix_f32 v124, v6, v124, neg(0) op_sel_hi:[1,0,0]      ; cc20007c 8a02f906
	v_fma_mix_f32 v125, v6, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087d 8a02fb06
	v_fma_mix_f32 v126, v24, v126, neg(0) op_sel_hi:[1,0,0]     ; cc20007e 8a02fd18
	v_fma_mix_f32 v127, v24, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087f 8a02ff18
	v_fma_mix_f32 v128, v26, v128, neg(0) op_sel_hi:[1,0,0]     ; cc200080 8a03011a
	v_fma_mix_f32 v129, v26, v129, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a03031a
	buffer_load_b128 v[24:27], v27, s[20:23], null offen offset:2560 ; c405c07c 40802818 000a001b
	v_fma_mix_f32 v130, v2, v130, neg(0) op_sel_hi:[1,0,0]      ; cc200082 8a030502
	v_fma_mix_f32 v131, v2, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200883 8a030702
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[132:133], v[34:35], v[168:175] ; cc4640a8 1ea24584
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[132:133], v[32:33], v[152:159] ; cc464098 1e624184
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[132:133], v[82:83], v[124:131] ; cc46407c 1df2a584
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[8:9], v[84:85], v[168:175] ; cc4640a8 1ea2a908
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[8:9], v[38:39], v[152:159] ; cc464098 1e624d08
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[8:9], v[88:89], v[124:131] ; cc46407c 1df2b108
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[40:41], v[152:159] ; cc464098 1e625110
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[16:17], v[92:93], v[124:131] ; cc46407c 1df2b910
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[16:17], v[68:69], v[168:175] ; cc4640a8 1ea28910
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[176:177], v[42:43], v[152:159] ; cc464098 1e6255b0
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[176:177], v[96:97], v[124:131] ; cc46407c 1df2c1b0
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[176:177], v[70:71], v[168:175] ; cc4640a8 1ea28db0
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[136:137], v[72:73], v[152:159] ; cc464098 1e629188
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[136:137], v[104:105], v[124:131] ; cc46407c 1df2d188
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[136:137], v[76:77], v[168:175] ; cc4640a8 1ea29988
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[164:165], v[74:75], v[152:159] ; cc464098 1e6295a4
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[164:165], v[112:113], v[124:131] ; cc46407c 1df2e1a4
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[164:165], v[78:79], v[168:175] ; cc4640a8 1ea29da4
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[180:181], v[100:101], v[152:159] ; cc464098 1e62c9b4
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[180:181], v[116:117], v[124:131] ; cc46407c 1df2e9b4
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[180:181], v[108:109], v[168:175] ; cc4640a8 1ea2d9b4
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[140:141], v[20:21], v[152:159] ; cc464098 1e62298c
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[140:141], v[80:81], v[124:131] ; cc46407c 1df2a18c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[140:141], v[22:23], v[168:175] ; cc4640a8 1ea22d8c
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[132:133], v[36:37], v[184:191] ; cc4640b8 1ee24984
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694066
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694067
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mix_f32 v29, v48, v144, neg(0) op_sel_hi:[1,0,0]      ; cc20001d 8a032130
	v_fma_mix_f32 v48, v48, v145, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200830 8a032330
	v_fma_mix_f32 v110, v49, v146, neg(0) op_sel_hi:[1,0,0]     ; cc20006e 8a032531
	v_fma_mix_f32 v111, v49, v147, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086f 8a032731
	s_bitset0_b32 s25, 14                                       ; be99108e
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s2, s2, 2                                        ; 84028202
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[8:9], v[86:87], v[184:191] ; cc4640b8 1ee2ad08
	s_buffer_load_b32 s2, s[24:27], s2 offset:0x0               ; f402008c 04000000
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_fma_mix_f32 v2, v65, v146, neg(0) op_sel_hi:[1,0,0]       ; cc200002 8a032541
	v_fma_mix_f32 v65, v65, v147, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200841 8a032741
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mix_f32 v118, v50, v120, neg(0) op_sel_hi:[1,0,0]     ; cc200076 8a02f132
	v_fma_mix_f32 v119, v50, v121, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a02f332
	v_dual_mov_b32 v50, v112 :: v_dual_mov_b32 v15, v109        ; ca100170 320e016d
	v_fma_mix_f32 v132, v51, v122, neg(0) op_sel_hi:[1,0,0]     ; cc200084 8a02f533
	v_fma_mix_f32 v133, v51, v123, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200885 8a02f733
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[16:17], v[90:91], v[184:191] ; cc4640b8 1ee2b510
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[176:177], v[94:95], v[184:191] ; cc4640b8 1ee2bdb0
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[136:137], v[98:99], v[184:191] ; cc4640b8 1ee2c588
	v_fma_mix_f32 v136, v56, v144, neg(0) op_sel_hi:[1,0,0]     ; cc200088 8a032138
	v_fma_mix_f32 v137, v56, v145, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200889 8a032338
	v_dual_mov_b32 v56, v114 :: v_dual_mov_b32 v51, v113        ; ca100172 38320171
	v_dual_mov_b32 v112, v118 :: v_dual_mov_b32 v109, v48       ; ca100176 706c0130
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[164:165], v[106:107], v[184:191] ; cc4640b8 1ee2d5a4
	v_fma_mix_f32 v164, v58, v120, neg(0) op_sel_hi:[1,0,0]     ; cc2000a4 8a02f13a
	v_fma_mix_f32 v165, v58, v121, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a02f33a
	v_fma_mix_f32 v176, v59, v122, neg(0) op_sel_hi:[1,0,0]     ; cc2000b0 8a02f53b
	v_fma_mix_f32 v177, v59, v123, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a02f73b
	v_fma_mix_f32 v5, v66, v120, neg(0) op_sel_hi:[1,0,0]       ; cc200005 8a02f142
	v_fma_mix_f32 v66, v66, v121, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200842 8a02f342
	v_fma_mix_f32 v13, v67, v122, neg(0) op_sel_hi:[1,0,0]      ; cc20000d 8a02f543
	v_fma_mix_f32 v67, v67, v123, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200843 8a02f743
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[180:181], v[114:115], v[184:191] ; cc4640b8 1ee2e5b4
	v_dual_mov_b32 v114, v132 :: v_dual_mov_b32 v113, v119      ; ca100184 72700177
	v_fma_mix_f32 v180, v64, v144, neg(0) op_sel_hi:[1,0,0]     ; cc2000b4 8a032140
	v_fma_mix_f32 v181, v64, v145, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a032340
	v_fma_mix_f32 v144, v12, v144, neg(0) op_sel_hi:[1,0,0]     ; cc200090 8a03210c
	v_fma_mix_f32 v145, v12, v145, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a03230c
	v_fma_mix_f32 v120, v28, v120, neg(0) op_sel_hi:[1,0,0]     ; cc200078 8a02f11c
	v_fma_mix_f32 v121, v28, v121, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200879 8a02f31c
	v_fma_mix_f32 v122, v4, v122, neg(0) op_sel_hi:[1,0,0]      ; cc20007a 8a02f504
	v_fma_mix_f32 v123, v4, v123, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087b 8a02f704
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[140:141], v[30:31], v[184:191] ; cc4640b8 1ee23d8c
	v_fma_mix_f32 v140, v57, v146, neg(0) op_sel_hi:[1,0,0]     ; cc20008c 8a032539
	v_fma_mix_f32 v141, v57, v147, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088d 8a032739
	v_fma_mix_f32 v146, v14, v146, neg(0) op_sel_hi:[1,0,0]     ; cc200092 8a03250e
	v_fma_mix_f32 v147, v14, v147, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200893 8a03270e
	v_mov_b32_e32 v14, v108                                     ; 7e1c036c
	v_dual_mov_b32 v108, v29 :: v_dual_mov_b32 v57, v115        ; ca10011d 6c380173
	v_dual_mov_b32 v28, v138 :: v_dual_mov_b32 v115, v133       ; ca10018a 1c720185
	v_swap_b32 v142, v176                                       ; 7f1ccbb0
	v_swap_b32 v143, v177                                       ; 7f1ecbb1
	v_dual_mov_b32 v138, v140 :: v_dual_mov_b32 v29, v139       ; ca10018c 8a1c018b
	v_dual_mov_b32 v140, v164 :: v_dual_mov_b32 v139, v141      ; ca1001a4 8c8a018d
	v_dual_mov_b32 v119, v147 :: v_dual_mov_b32 v118, v146      ; ca100193 77760192
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[134:135], v[32:33], v[108:115] ; cc46406c 1db24186
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mov_b32 v32, v60 :: v_dual_mov_b32 v141, v165        ; ca10013c 208c01a5
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[134:135], v[34:35], v[136:143] ; cc464088 1e224586
	v_dual_mov_b32 v34, v62 :: v_dual_mov_b32 v33, v61          ; ca10013e 2220013d
	v_dual_mov_b32 v60, v180 :: v_dual_mov_b32 v35, v63         ; ca1001b4 3c22013f
	v_dual_mov_b32 v62, v2 :: v_dual_mov_b32 v63, v65           ; ca100102 3e3e0141
	v_dual_mov_b32 v64, v5 :: v_dual_mov_b32 v65, v66           ; ca100105 40400142
	v_dual_mov_b32 v66, v13 :: v_dual_mov_b32 v61, v181         ; ca10010d 423c01b5
	v_dual_mov_b32 v4, v116 :: v_dual_mov_b32 v5, v117          ; ca100174 04040175
	v_dual_mov_b32 v116, v144 :: v_dual_mov_b32 v117, v145      ; ca100190 74740191
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[10:11], v[38:39], v[108:115] ; cc46406c 1db24d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[134:135], v[36:37], v[60:67] ; cc46403c 1cf24986
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[84:85], v[136:143] ; cc464088 1e22a90a
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[134:135], v[82:83], v[116:123] ; cc464074 1dd2a586
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[18:19], v[40:41], v[108:115] ; cc46406c 1db25112
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[10:11], v[86:87], v[60:67] ; cc46403c 1cf2ad0a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[68:69], v[136:143] ; cc464088 1e228912
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[10:11], v[88:89], v[116:123] ; cc464074 1dd2b10a
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[178:179], v[42:43], v[108:115] ; cc46406c 1db255b2
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[18:19], v[90:91], v[60:67] ; cc46403c 1cf2b512
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[178:179], v[70:71], v[136:143] ; cc464088 1e228db2
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[18:19], v[92:93], v[116:123] ; cc464074 1dd2b912
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[28:29], v[72:73], v[108:115] ; cc46406c 1db2911c
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[178:179], v[94:95], v[60:67] ; cc46403c 1cf2bdb2
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[28:29], v[76:77], v[136:143] ; cc464088 1e22991c
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[178:179], v[96:97], v[116:123] ; cc464074 1dd2c1b2
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[166:167], v[74:75], v[108:115] ; cc46406c 1db295a6
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[28:29], v[98:99], v[60:67] ; cc46403c 1cf2c51c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[166:167], v[78:79], v[136:143] ; cc464088 1e229da6
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[28:29], v[104:105], v[116:123] ; cc464074 1dd2d11c
	v_dual_mov_b32 v29, v17 :: v_dual_mov_b32 v28, v16          ; ca100111 1d1c0110
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[182:183], v[100:101], v[108:115] ; cc46406c 1db2c9b6
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[166:167], v[106:107], v[60:67] ; cc46403c 1cf2d5a6
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[182:183], v[14:15], v[136:143] ; cc464088 1e221db6
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[166:167], v[50:51], v[116:123] ; cc464074 1dd265a6
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[176:177], v[20:21], v[108:115] ; cc46406c 1db229b0
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[182:183], v[56:57], v[60:67] ; cc46403c 1cf271b6
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[44:45], v[6:7], 0   ; cc464048 1a020d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[176:177], v[22:23], v[136:143] ; cc464088 1e222db0
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[6:7], 0   ; cc464058 1a020d34
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[182:183], v[4:5], v[116:123] ; cc464074 1dd209b6
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[176:177], v[30:31], v[60:67] ; cc46403c 1cf23db0
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[148:149], v[4:5], v[72:79] ; cc464048 1d220994
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[4:5], v[88:95] ; cc464058 1d6209a0
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[176:177], v[80:81], v[116:123] ; cc464074 1dd2a1b0
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[6:7], 0   ; cc464050 1a020d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[6:7], 0 ; cc4640b0 1a020d36
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[6:7], v[32:33], 0   ; cc464024 1a024106
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[6:7], v[34:35], 0   ; cc464010 1a024506
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[150:151], v[4:5], v[80:87] ; cc464050 1d420996
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[162:163], v[4:5], v[176:183] ; cc4640b0 1ec209a2
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[4:5], v[24:25], v[36:43] ; cc464024 1c923104
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[4:5], v[26:27], v[16:23] ; cc464010 1c423504
	v_dual_mul_f32 v48, v83, v83 :: v_dual_mul_f32 v31, v177, v177 ; c8c6a753 301f63b1
	v_dual_mul_f32 v49, v179, v179 :: v_dual_mul_f32 v30, v81, v81 ; c8c767b3 311ea351
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_dual_fmac_f32 v48, v75, v75 :: v_dual_fmac_f32 v31, v89, v89 ; c800974b 301eb359
	v_dual_fmac_f32 v49, v91, v91 :: v_dual_fmac_f32 v30, v73, v73 ; c800b75b 311e9349
	s_mov_b32 s4, 0x76543210                                    ; be8400ff 76543210
	s_mov_b32 s5, 0xfedcba98                                    ; be8500ff fedcba98
	v_dual_fmac_f32 v48, v79, v79 :: v_dual_fmac_f32 v31, v93, v93 ; c8009f4f 301ebb5d
	s_movk_i32 s8, 0x410                                        ; b0080410
	v_dual_fmac_f32 v49, v95, v95 :: v_dual_fmac_f32 v30, v77, v77 ; c800bf5f 311e9b4d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v48, v87, v87 :: v_dual_fmac_f32 v31, v181, v181 ; c800af57 301f6bb5
	v_dual_fmac_f32 v49, v183, v183 :: v_dual_fmac_f32 v30, v85, v85 ; c8016fb7 311eab55
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v31, v88, v88 :: v_dual_fmac_f32 v48, v74, v74 ; c800b158 1f30954a
	v_dual_fmac_f32 v49, v90, v90 :: v_dual_fmac_f32 v30, v72, v72 ; c800b55a 311e9148
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v31, v176, v176 :: v_dual_fmac_f32 v48, v82, v82 ; c80161b0 1f30a552
	v_dual_fmac_f32 v49, v178, v178 :: v_dual_fmac_f32 v30, v80, v80 ; c80165b2 311ea150
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v31, v92, v92 :: v_dual_fmac_f32 v48, v78, v78 ; c800b95c 1f309d4e
	v_dual_fmac_f32 v49, v94, v94 :: v_dual_fmac_f32 v30, v76, v76 ; c800bd5e 311e994c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v31, v180, v180 :: v_dual_fmac_f32 v48, v86, v86 ; c80169b4 1f30ad56
	v_dual_fmac_f32 v49, v182, v182 :: v_dual_fmac_f32 v30, v84, v84 ; c8016db6 311ea954
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_fma_mixlo_f16 v50, 1.0, v30, v48                          ; cc210032 04c23cf2
	v_fma_mixhi_f16 v50, 1.0, v31, v49                          ; cc220032 04c63ef2
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_permlanex16_b32 v51, v50, s4, s5 op_sel:[1,1]             ; d65c1833 00140932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; cc0f0032
	v_min_num_f64_e32 v[1:2], v[50:51], v[51:52]                ; 1a026732
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; cc1c0032
	v_subrev_f32_e32 v0, v50, v8                                ; 0a001132
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v56, v50                                  ; 7e701732
	v_cvt_f32_f16_e32 v50, v178/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e6417b2
	v_rsq_f32_e32 v56, v56                                      ; 7e705d38
	v_rsq_f32_e32 v50, v50                                      ; 7e645d32
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_mul_f32_e32 v56, s2, v56                                  ; 10707002
	v_dual_mul_f32 v90, v90, v50 :: v_dual_mul_f32 v91, v91, v50 ; c8c6655a 5a5a655b
	v_dual_mul_f32 v88, v88, v50 :: v_dual_mul_f32 v89, v89, v50 ; c8c66558 58586559
	v_dual_mul_f32 v93, v93, v50 :: v_dual_mul_f32 v92, v92, v50 ; c8c6655d 5d5c655c
	v_dual_mul_f32 v95, v95, v50 :: v_dual_mul_f32 v94, v94, v50 ; c8c6655f 5f5e655e
	v_dual_mul_f32 v73, v73, v56 :: v_dual_mul_f32 v72, v72, v56 ; c8c67149 49487148
	v_dual_mul_f32 v81, v81, v56 :: v_dual_mul_f32 v80, v80, v56 ; c8c67151 51507150
	v_dual_mul_f32 v78, v78, v56 :: v_dual_mul_f32 v79, v79, v56 ; c8c6714e 4e4e714f
	v_dual_mul_f32 v83, v83, v56 :: v_dual_mul_f32 v82, v82, v56 ; c8c67153 53527152
	v_dual_mul_f32 v87, v87, v56 :: v_dual_mul_f32 v86, v86, v56 ; c8c67157 57567156
	v_dual_mul_f32 v177, v177, v50 :: v_dual_mul_f32 v176, v176, v50 ; c8c665b1 b1b065b0
	v_dual_mul_f32 v76, v76, v56 :: v_dual_mul_f32 v77, v77, v56 ; c8c6714c 4c4c714d
	v_dual_mul_f32 v75, v75, v56 :: v_dual_mul_f32 v74, v74, v56 ; c8c6714b 4b4a714a
	v_dual_mul_f32 v85, v85, v56 :: v_dual_mul_f32 v84, v84, v56 ; c8c67155 55547154
	v_dual_mul_f32 v179, v179, v50 :: v_dual_mul_f32 v178, v178, v50 ; c8c665b3 b3b265b2
	v_dual_mul_f32 v181, v181, v50 :: v_dual_mul_f32 v180, v180, v50 ; c8c665b5 b5b465b4
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
	v_dual_mul_f32 v183, v183, v50 :: v_dual_mul_f32 v182, v182, v50 ; c8c665b7 b7b665b6
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_dual_mov_b32 v43, v103 :: v_dual_mov_b32 v42, v102        ; ca100167 2b2a0166
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[8:9], 0   ; cc464050 1a02112e
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[8:9], 0 ; cc4640b0 1a021136
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[44:45], v[8:9], 0   ; cc464048 1a02112c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[8:9], 0   ; cc464058 1a021134
	v_dual_mov_b32 v41, v17 :: v_dual_mov_b32 v40, v16          ; ca100111 29280110
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[8:9], v[32:33], 0   ; cc464010 1a024108
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[34:35], 0  ; cc464060 1a024508
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[150:151], v[10:11], v[80:87] ; cc464050 1d421596
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[162:163], v[10:11], v[176:183] ; cc4640b0 1ec215a2
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[148:149], v[10:11], v[72:79] ; cc464048 1d221594
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[10:11], v[88:95] ; cc464058 1d6215a0
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[10:11], v[24:25], v[16:23] ; cc464010 1c42310a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[10:11], v[26:27], v[96:103] ; cc464060 1d82350a
	v_dual_mul_f32 v59, v83, v83 :: v_dual_mul_f32 v58, v177, v177 ; c8c6a753 3b3b63b1
	v_dual_mul_f32 v68, v179, v179 :: v_dual_mul_f32 v57, v81, v81 ; c8c767b3 4438a351
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v59, v75, v75 :: v_dual_fmac_f32 v58, v89, v89 ; c800974b 3b3ab359
	v_dual_fmac_f32 v68, v91, v91 :: v_dual_fmac_f32 v57, v73, v73 ; c800b75b 44389349
	v_dual_fmac_f32 v59, v79, v79 :: v_dual_fmac_f32 v58, v93, v93 ; c8009f4f 3b3abb5d
	v_dual_fmac_f32 v68, v95, v95 :: v_dual_fmac_f32 v57, v77, v77 ; c800bf5f 44389b4d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v59, v87, v87 :: v_dual_fmac_f32 v58, v181, v181 ; c800af57 3b3b6bb5
	v_dual_fmac_f32 v68, v183, v183 :: v_dual_fmac_f32 v57, v85, v85 ; c8016fb7 4438ab55
	v_dual_fmac_f32 v58, v88, v88 :: v_dual_fmac_f32 v59, v74, v74 ; c800b158 3a3a954a
	v_dual_fmac_f32 v68, v90, v90 :: v_dual_fmac_f32 v57, v72, v72 ; c800b55a 44389148
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v58, v176, v176 :: v_dual_fmac_f32 v59, v82, v82 ; c80161b0 3a3aa552
	v_dual_fmac_f32 v68, v178, v178 :: v_dual_fmac_f32 v57, v80, v80 ; c80165b2 4438a150
	v_dual_fmac_f32 v58, v92, v92 :: v_dual_fmac_f32 v59, v78, v78 ; c800b95c 3a3a9d4e
	v_dual_fmac_f32 v68, v94, v94 :: v_dual_fmac_f32 v57, v76, v76 ; c800bd5e 4438994c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v58, v180, v180 :: v_dual_fmac_f32 v59, v86, v86 ; c80169b4 3a3aad56
	v_dual_fmac_f32 v68, v182, v182 :: v_dual_fmac_f32 v57, v84, v84 ; c8016db6 4438a954
	v_fma_mixlo_f16 v69, 1.0, v57, v59                          ; cc210045 04ee72f2
	v_fma_mixhi_f16 v69, 1.0, v58, v68                          ; cc220045 051274f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v70, v69, s4, s5 op_sel:[1,1]             ; d65c1846 00140945
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[70:71]                ; 1a028d45
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0045
	v_subrev_f32_e32 v0, v69, v8                                ; 0a001145
	v_cvt_f32_f16_e32 v71, v69                                  ; 7e8e1745
	v_cvt_f32_f16_e32 v69, v197/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8a17c5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v71, v71                                      ; 7e8e5d47
	v_rsq_f32_e32 v69, v69                                      ; 7e8a5d45
	v_mul_f32_e32 v71, s2, v71                                  ; 108e8e02
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v92, v92, v69 :: v_dual_mul_f32 v89, v89, v69 ; c8c68b5c 5c588b59
	v_dual_mul_f32 v94, v94, v69 :: v_dual_mul_f32 v91, v91, v69 ; c8c68b5e 5e5a8b5b
	v_dual_mul_f32 v90, v90, v69 :: v_dual_mul_f32 v79, v79, v71 ; c8c68b5a 5a4e8f4f
	v_mul_f32_e32 v74, v74, v71                                 ; 10948f4a
	v_dual_mul_f32 v176, v176, v69 :: v_dual_mul_f32 v85, v85, v71 ; c8c68bb0 b0548f55
	v_dual_mul_f32 v86, v86, v71 :: v_dual_mul_f32 v83, v83, v71 ; c8c68f56 56528f53
	v_dual_mul_f32 v84, v84, v71 :: v_dual_mul_f32 v81, v81, v71 ; c8c68f54 54508f51
	v_dual_mul_f32 v78, v78, v71 :: v_dual_mul_f32 v75, v75, v71 ; c8c68f4e 4e4a8f4b
	v_mul_f32_e32 v72, v72, v71                                 ; 10908f48
	v_dual_mul_f32 v88, v88, v69 :: v_dual_mul_f32 v77, v77, v71 ; c8c68b58 584c8f4d
	v_dual_mul_f32 v76, v76, v71 :: v_dual_mul_f32 v73, v73, v71 ; c8c68f4c 4c488f49
	v_dual_mul_f32 v80, v80, v71 :: v_dual_mul_f32 v93, v93, v69 ; c8c68f50 505c8b5d
	v_dual_mul_f32 v82, v82, v71 :: v_dual_mul_f32 v95, v95, v69 ; c8c68f52 525e8b5f
	v_dual_mul_f32 v178, v178, v69 :: v_dual_mul_f32 v87, v87, v71 ; c8c68bb2 b2568f57
	v_dual_mul_f32 v180, v180, v69 :: v_dual_mul_f32 v177, v177, v69 ; c8c68bb4 b4b08bb1
	v_dual_mul_f32 v182, v182, v69 :: v_dual_mul_f32 v179, v179, v69 ; c8c68bb6 b6b28bb3
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	v_dual_mov_b32 v2, v60 :: v_dual_mul_f32 v181, v181, v69    ; ca06013c 02b48bb5
	v_dual_mov_b32 v48, v61 :: v_dual_mul_f32 v183, v183, v69   ; ca06013d 30b68bb7
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_dual_mov_b32 v50, v63 :: v_dual_mov_b32 v49, v62          ; ca10013f 3230013e
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[28:29], 0 ; cc464050 1a02392e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[54:55], v[28:29], 0 ; cc464060 1a023936
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[44:45], v[28:29], 0 ; cc464048 1a02392c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[28:29], 0 ; cc464058 1a023934
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[28:29], v[32:33], 0 ; cc4640b0 1a02411c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[28:29], v[34:35], 0 ; cc464038 1a02451c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[150:151], v[12:13], v[80:87] ; cc464050 1d421996
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[162:163], v[12:13], v[96:103] ; cc464060 1d8219a2
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[148:149], v[12:13], v[72:79] ; cc464048 1d221994
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[12:13], v[88:95] ; cc464058 1d6219a0
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[24:25], v[176:183] ; cc4640b0 1ec2310c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[12:13], v[26:27], v[56:63] ; cc464038 1ce2350c
	v_dual_mul_f32 v70, v99, v99 :: v_dual_mul_f32 v51, v81, v81 ; c8c6c763 4632a351
	v_dual_mul_f32 v68, v97, v97 :: v_dual_mul_f32 v69, v83, v83 ; c8c6c361 4444a753
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v70, v91, v91 :: v_dual_fmac_f32 v51, v73, v73 ; c800b75b 46329349
	v_dual_fmac_f32 v68, v89, v89 :: v_dual_fmac_f32 v69, v75, v75 ; c800b359 4444974b
	v_dual_fmac_f32 v70, v95, v95 :: v_dual_fmac_f32 v51, v77, v77 ; c800bf5f 46329b4d
	v_dual_fmac_f32 v69, v79, v79 :: v_dual_fmac_f32 v68, v93, v93 ; c8009f4f 4544bb5d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v70, v103, v103 :: v_dual_fmac_f32 v51, v85, v85 ; c800cf67 4632ab55
	v_dual_fmac_f32 v69, v87, v87 :: v_dual_fmac_f32 v68, v101, v101 ; c800af57 4544cb65
	v_dual_fmac_f32 v70, v90, v90 :: v_dual_fmac_f32 v51, v72, v72 ; c800b55a 46329148
	v_dual_fmac_f32 v68, v88, v88 :: v_dual_fmac_f32 v69, v74, v74 ; c800b158 4444954a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmac_f32 v70, v98, v98 :: v_dual_fmac_f32 v51, v80, v80 ; c800c562 4632a150
	v_dual_fmac_f32 v68, v96, v96 :: v_dual_fmac_f32 v69, v82, v82 ; c800c160 4444a552
(invalid instruction)                                        ; d71f006a
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_dual_fmac_f32 v70, v94, v94 :: v_dual_fmac_f32 v51, v76, v76 ; c800bd5e 4632994c
	v_dual_fmac_f32 v68, v92, v92 :: v_dual_fmac_f32 v69, v78, v78 ; c800b95c 44449d4e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v70, v102, v102 :: v_dual_fmac_f32 v51, v84, v84 ; c800cd66 4632a954
	v_dual_fmac_f32 v68, v100, v100 :: v_dual_fmac_f32 v69, v86, v86 ; c800c964 4444ad56
	v_fma_mixlo_f16 v71, 1.0, v51, v69                          ; cc210047 051666f2
	v_fma_mixhi_f16 v71, 1.0, v68, v70                          ; cc220047 051a88f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v104, v71, s4, s5 op_sel:[1,1]            ; d65c1868 00140947
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[104:105]              ; 1a02d147
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0047
	v_subrev_f32_e32 v0, v71, v8                                ; 0a001147
	v_cvt_f32_f16_e32 v105, v71                                 ; 7ed21747
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v105, v105                                    ; 7ed25d69
	v_mul_f32_e32 v105, s2, v105                                ; 10d2d202
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c1
	v_dual_mul_f32 v74, v74, v105 :: v_dual_mul_f32 v75, v75, v105 ; c8c6d34a 4a4ad34b
	v_dual_mul_f32 v76, v76, v105 :: v_dual_and_b32 v107, 15, v106 ; c8e4d34c 4c6ad48f
	v_lshrrev_b32_e32 v106, 4, v106                             ; 32d4d484
	v_dual_mul_f32 v72, v72, v105 :: v_dual_mul_f32 v73, v73, v105 ; c8c6d348 4848d349
	v_lshl_add_u32 v107, v107, 6, s7                            ; d646006b 001d0d6b
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_lshl_add_u32 v106, v106, 3, v107                          ; d646006a 05ad076a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v77, v77, v105 :: v_dual_lshlrev_b32 v106, 2, v106 ; c8e2d34d 4d6ad482
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v106, s[32:35], null offen       ; c405c07c 40804048 0000006a
	buffer_load_b128 v[132:135], v106, s[32:35], null offen offset:16 ; c405c07c 40804084 0000106a
	v_cvt_f32_f16_e32 v71, v199/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8e17c7
	v_dual_mul_f32 v79, v79, v105 :: v_dual_mul_f32 v78, v78, v105 ; c8c6d34f 4f4ed34e
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_rsq_f32_e32 v71, v71                                      ; 7e8e5d47
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a5
	v_dual_mul_f32 v91, v91, v71 :: v_dual_mul_f32 v90, v90, v71 ; c8c68f5b 5b5a8f5a
	v_dual_mul_f32 v89, v89, v71 :: v_dual_mul_f32 v88, v88, v71 ; c8c68f59 59588f58
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[76:79], v106, s[32:35], null offen offset:4096 ; c405c07c 4080404c 0010006a
	buffer_load_b128 v[88:91], v106, s[32:35], null offen offset:4112 ; c405c07c 40804058 0010106a
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_mul_f32_e32 v80, v80, v105                                ; 10a0d350
	v_mul_f32_e32 v81, v81, v105                                ; 10a2d351
	v_mul_f32_e32 v83, v83, v105                                ; 10a6d353
	v_mul_f32_e32 v85, v85, v105                                ; 10aad355
	v_dual_mul_f32 v95, v95, v71 :: v_dual_mul_f32 v94, v94, v71 ; c8c68f5f 5f5e8f5e
	v_dual_mul_f32 v93, v93, v71 :: v_dual_mul_f32 v92, v92, v71 ; c8c68f5d 5d5c8f5c
	v_dual_mul_f32 v87, v87, v105 :: v_dual_mul_f32 v82, v82, v105 ; c8c6d357 5752d352
	v_dual_mul_f32 v97, v97, v71 :: v_dual_mul_f32 v96, v96, v71 ; c8c68f61 61608f60
	v_dual_mul_f32 v99, v99, v71 :: v_dual_mul_f32 v98, v98, v71 ; c8c68f63 63628f62
	v_dual_mul_f32 v101, v101, v71 :: v_dual_mul_f32 v100, v100, v71 ; c8c68f65 65648f64
	v_dual_mul_f32 v103, v103, v71 :: v_dual_mul_f32 v102, v102, v71 ; c8c68f67 67668f66
	v_dual_mov_b32 v71, v49 :: v_dual_mul_f32 v86, v86, v105    ; ca060131 4756d356
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_mov_b32_e32 v93, v168                                     ; 7eba03a8
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[42:43], 0 ; cc4640b0 1a02552e
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[42:43], 0 ; cc464060 1a02552c
	v_dual_mov_b32 v45, v65 :: v_dual_mul_f32 v84, v84, v105    ; ca060141 2d54d354
	v_dual_mov_b32 v95, v170 :: v_dual_mov_b32 v44, v64         ; ca1001aa 5f2c0140
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[52:53], v[42:43], 0 ; cc46403a 1a025534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[150:151], v[14:15], v[176:183] ; cc4640b0 1ec21d96
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_mov_b32_e32 v85, v140                                     ; 7eaa038c
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mov_b32_e32 v87, v142                                     ; 7eae038e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[14:15], v[96:103] ; cc464060 1d821d94
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[160:161], v[14:15], v[58:65] ; cc46403a 1cea1da0
	v_dual_mul_f32 v105, v177, v177 :: v_dual_mov_b32 v70, v48  ; c8d163b1 69460130
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_fmac_f32 v105, v97, v97 :: v_dual_mov_b32 v84, v50   ; c810c361 69540132
	v_wmma_f32_16x16x16_fp8_fp8 v[46:53], v[54:55], v[42:43], 0 ; cc46402e 1a025536
	v_fmac_f32_e32 v105, v101, v101                             ; 56d2cb65
	v_dual_fmac_f32 v105, v181, v181 :: v_dual_mov_b32 v92, v143 ; c8116bb5 695c018f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_fmac_f32_e32 v105, v96, v96                               ; 56d2c160
	v_wmma_f32_16x16x16_fp8_fp8 v[46:53], v[162:163], v[14:15], v[46:53] ; cc46402e 1cba1da2
	v_fmac_f32_e32 v105, v176, v176                             ; 56d361b0
	v_fmac_f32_e32 v105, v100, v100                             ; 56d2c964
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_fmac_f32_e32 v105, v180, v180                             ; 56d369b4
	v_mul_f32_e32 v107, v47, v47                                ; 10d65f2f
	v_mul_f32_e32 v149, v49, v49                                ; 112a6331
	v_fmac_f32_e32 v107, v59, v59                               ; 56d6773b
	v_fmac_f32_e32 v149, v61, v61                               ; 572a7b3d
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmac_f32 v107, v63, v63 :: v_dual_mov_b32 v86, v141  ; c8107f3f 6b56018d
	v_wmma_f32_16x16x16_fp8_fp8 v[140:147], v[42:43], v[32:33], 0 ; cc46408c 1a02412a
	v_dual_fmac_f32 v149, v65, v65 :: v_dual_mov_b32 v104, v171 ; c8108341 956801ab
	v_dual_fmac_f32 v107, v51, v51 :: v_dual_mov_b32 v94, v169  ; c8106733 6b5e01a9
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[42:43], v[34:35], 0 ; cc4640a4 1a02452a
	v_fmac_f32_e32 v149, v53, v53                               ; 572a6b35
	v_dual_fmac_f32 v107, v58, v58 :: v_dual_mul_f32 v148, v179, v179 ; c806753a 6b9567b3
	v_wmma_f32_16x16x16_fp8_fp8 v[140:147], v[14:15], v[24:25], v[140:147] ; cc46408c 1e32310e
	v_dual_fmac_f32 v107, v46, v46 :: v_dual_fmac_f32 v148, v99, v99 ; c8005d2e 6b94c763
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[14:15], v[26:27], v[164:171] ; cc4640a4 1e92350e
	v_dual_fmac_f32 v107, v62, v62 :: v_dual_fmac_f32 v148, v103, v103 ; c8007d3e 6b94cf67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v107, v50, v50 :: v_dual_fmac_f32 v148, v183, v183 ; c8006532 6b956fb7
	v_dual_fmac_f32 v149, v60, v60 :: v_dual_fmac_f32 v148, v98, v98 ; c800793c 9594c562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v149, v48, v48 :: v_dual_fmac_f32 v148, v178, v178 ; c8006130 959565b2
	v_dual_fmac_f32 v149, v64, v64 :: v_dual_fmac_f32 v148, v102, v102 ; c8008140 9594cd66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v149, v52, v52 :: v_dual_fmac_f32 v148, v182, v182 ; c8006934 95956db6
	v_fma_mixlo_f16 v150, 1.0, v105, v148                       ; cc210096 0652d2f2
	v_fma_mixhi_f16 v150, 1.0, v107, v149                       ; cc220096 0656d6f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v151, v150, s4, s5 op_sel:[1,1]           ; d65c1897 00140996
(invalid instruction)                                        ; cc0f0096
	v_min_num_f64_e32 v[1:2], v[150:151], v[151:152]            ; 1a032f96
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0096
	v_subrev_f32_e32 v0, v150, v8                               ; 0a001196
(invalid instruction)                                        ; d58b00a0
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                    ; 02010196
(invalid instruction)                                        ; d58b0896
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                    ; 02010196
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v160, v160                                    ; 7f405da0
	v_rsq_f32_e32 v150, v150                                    ; 7f2c5d96
	v_mul_f32_e32 v160, s2, v160                                ; 11414002
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v65, v65, v150 :: v_dual_mul_f32 v64, v64, v150 ; c8c72d41 41412d40
	v_dual_mul_f32 v58, v58, v150 :: v_dual_mul_f32 v59, v59, v150 ; c8c72d3a 3a3b2d3b
	v_dual_mul_f32 v63, v63, v150 :: v_dual_mul_f32 v62, v62, v150 ; c8c72d3f 3f3f2d3e
	v_dual_mul_f32 v60, v60, v150 :: v_dual_mul_f32 v61, v61, v150 ; c8c72d3c 3c3d2d3d
	v_dual_mul_f32 v103, v103, v160 :: v_dual_mul_f32 v102, v102, v160 ; c8c74167 67674166
	v_dual_mul_f32 v179, v179, v160 :: v_dual_mul_f32 v178, v178, v160 ; c8c741b3 b3b341b2
	v_dual_mul_f32 v181, v181, v160 :: v_dual_mul_f32 v180, v180, v160 ; c8c741b5 b5b541b4
	v_dual_mul_f32 v47, v47, v150 :: v_dual_mul_f32 v46, v46, v150 ; c8c72d2f 2f2f2d2e
	v_dual_mul_f32 v99, v99, v160 :: v_dual_mul_f32 v98, v98, v160 ; c8c74163 63634162
	v_dual_mul_f32 v177, v177, v160 :: v_dual_mul_f32 v176, v176, v160 ; c8c741b1 b1b141b0
	v_dual_mul_f32 v183, v183, v160 :: v_dual_mul_f32 v182, v182, v160 ; c8c741b7 b7b741b6
	v_dual_mul_f32 v101, v101, v160 :: v_dual_mul_f32 v100, v100, v160 ; c8c74165 65654164
	v_dual_mul_f32 v97, v97, v160 :: v_dual_mul_f32 v96, v96, v160 ; c8c74161 61614160
	v_dual_mul_f32 v49, v49, v150 :: v_dual_mul_f32 v48, v48, v150 ; c8c72d31 31312d30
	v_dual_mul_f32 v51, v51, v150 :: v_dual_mul_f32 v50, v50, v150 ; c8c72d33 33332d32
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_dual_mul_f32 v53, v53, v150 :: v_dual_mul_f32 v52, v52, v150 ; c8c72d35 35352d34
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[6:7], v[4:5], 0     ; cc464030 1a020906
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[6:7], v[8:9], 0    ; cc464060 1a021106
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[6:7], v[12:13], 0 ; cc464090 1a021906
	s_mov_b32 s10, 0x3d380000                                   ; be8a00ff 3d380000
	s_movk_i32 s11, 0x3e47                                      ; b00b3e47
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[6:7], v[14:15], 0 ; cc4640a0 1a021d06
	s_movk_i32 s12, 0x3c20                                      ; b00c3c20
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[38:39], v[36:37], v[48:55] ; cc464030 1cc24926
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[18:19], v[96:103] ; cc464060 1d822526
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[80:81], v[144:151] ; cc464090 1e42a126
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[38:39], v[32:33], v[160:167] ; cc4640a0 1e824126
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v169, s10, v50, v74                         ; cc2100a9 052a640a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v171, s10, v54, v134                        ; cc2100ab 061a6c0a
	v_fma_mixhi_f16 v171, s10, v55, v135                        ; cc2200ab 061e6e0a
	v_fma_mixlo_f16 v170, s10, v52, v132                        ; cc2100aa 0612680a
	v_fma_mixlo_f16 v168, s10, v48, v72                         ; cc2100a8 0522600a
	v_fma_mixhi_f16 v168, s10, v49, v73                         ; cc2200a8 0526620a
	v_fma_mixhi_f16 v170, s10, v53, v133                        ; cc2200aa 06166a0a
	v_fma_mixhi_f16 v169, s10, v51, v75                         ; cc2200a9 052e660a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v176, s10, v96, v76                         ; cc2100b0 0532c00a
	v_fma_mixhi_f16 v176, s10, v97, v77                         ; cc2200b0 0536c20a
	s_clause 0x6                                                ; bf850006
	buffer_load_b128 v[48:51], v106, s[32:35], null offen offset:8192 ; c405c07c 40804030 0020006a
	buffer_load_b128 v[52:55], v106, s[32:35], null offen offset:8208 ; c405c07c 40804034 0020106a
	buffer_load_b128 v[60:63], v106, s[32:35], null offen offset:12288 ; c405c07c 4080403c 0030006a
	buffer_load_b128 v[72:75], v106, s[32:35], null offen offset:12304 ; c405c07c 40804048 0030106a
	buffer_load_b128 v[132:135], v106, s[32:35], null offen offset:64 ; c405c07c 40804084 0000406a
	buffer_load_b128 v[140:143], v106, s[32:35], null offen offset:80 ; c405c07c 4080408c 0000506a
	buffer_load_b128 v[180:183], v106, s[32:35], null offen offset:4160 ; c405c07c 408040b4 0010406a
	v_dual_mov_b32 v39, v45 :: v_dual_mov_b32 v38, v44          ; ca10012d 2726012c
(invalid instruction)                                        ; cc1c00ab
	v_subrev_f32_e32 v0, v171, v12                              ; 0a0019ab
(invalid instruction)                                        ; d59c0006
	v_cndmask_b32_e32 v0, v176, v128, vcc_lo                    ; 020101b0
(invalid instruction)                                        ; d59c0807
	v_cndmask_b32_e32 v0, v176, v128, vcc_lo                    ; 020101b0
	v_dual_mov_b32 v59, v67 :: v_dual_mov_b32 v58, v66          ; ca100143 3b3a0142
	v_dual_mov_b32 v97, v79 :: v_dual_mov_b32 v96, v78          ; ca10014f 6160014e
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[176:179], v106, s[32:35], null offen offset:4176 ; c405c07c 408040b0 0010506a
	buffer_load_b128 v[44:47], v106, s[32:35], null offen offset:8256 ; c405c07c 4080402c 0020406a
	buffer_load_b128 v[64:67], v106, s[32:35], null offen offset:8272 ; c405c07c 40804040 0020506a
	buffer_load_b128 v[76:79], v106, s[32:35], null offen offset:12352 ; c405c07c 4080404c 0030406a
(invalid instruction)                                        ; cc1c00a8
	v_subrev_f32_e32 v0, v168, v12                              ; 0a0019a8
(invalid instruction)                                        ; cc1c00aa
	v_subrev_f32_e32 v0, v170, v12                              ; 0a0019aa
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v12                              ; 0a0019a9
(invalid instruction)                                        ; cc1b00ab
	v_subrev_f32_e32 v0, v171, v11                              ; 0a0017ab
	v_mov_b16_e32 v6.h, v7.l                                    ; 7f0c3907
	v_mov_b32_e32 v7, v84                                       ; 7e0e0354
	v_fma_mixlo_f16 v98, s10, v98, v96                          ; cc210062 0582c40a
	v_fma_mixhi_f16 v98, s10, v99, v97                          ; cc220062 0586c60a
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v99, s10, v100, v88                         ; cc210063 0562c80a
	v_fma_mixhi_f16 v99, s10, v101, v89                         ; cc220063 0566ca0a
	v_fma_mixlo_f16 v100, s10, v102, v90                        ; cc210064 056acc0a
(invalid instruction)                                        ; cc1b00a8
	v_subrev_f32_e32 v0, v168, v11                              ; 0a0017a8
	v_dual_mov_b32 v97, v150 :: v_dual_mov_b32 v96, v149        ; ca100196 61600195
(invalid instruction)                                        ; cc1b00aa
	v_subrev_f32_e32 v0, v170, v11                              ; 0a0017aa
(invalid instruction)                                        ; cc1b00a9
	v_subrev_f32_e32 v0, v169, v11                              ; 0a0017a9
(invalid instruction)                                        ; cc1c0006
	v_subrev_f32_e32 v0, v6, v12                                ; 0a001906
	v_fma_mixhi_f16 v100, s10, v103, v91                        ; cc220064 056ece0a
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v12                               ; 0a001962
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v12                               ; 0a001963
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; cc1b0006
	v_subrev_f32_e32 v0, v6, v11                                ; 0a001706
(invalid instruction)                                        ; cc1c0064
	v_subrev_f32_e32 v0, v100, v12                              ; 0a001964
(invalid instruction)                                        ; cc1b0062
	v_subrev_f32_e32 v0, v98, v11                               ; 0a001762
(invalid instruction)                                        ; cc1b0063
	v_subrev_f32_e32 v0, v99, v11                               ; 0a001763
(invalid instruction)                                        ; cc1b0064
	v_subrev_f32_e32 v0, v100, v11                              ; 0a001764
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v102, s10, v146, v50                        ; cc210066 04cb240a
	v_fma_mixhi_f16 v102, s10, v147, v51                        ; cc220066 04cf260a
	v_dual_mov_b32 v51, v148 :: v_dual_mov_b32 v50, v87         ; ca100194 33320157
	v_fma_mixlo_f16 v101, s10, v144, v48                        ; cc210065 04c3200a
	v_fma_mixhi_f16 v101, s10, v145, v49                        ; cc220065 04c7220a
	v_dual_mov_b32 v49, v86 :: v_dual_mov_b32 v48, v85          ; ca100156 31300155
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v160, s10, v160, v60                        ; cc2100a0 04f3400a
	v_fma_mixhi_f16 v160, s10, v161, v61                        ; cc2200a0 04f7420a
	v_fma_mixlo_f16 v161, s10, v162, v62                        ; cc2100a1 04fb440a
	v_fma_mixhi_f16 v161, s10, v163, v63                        ; cc2200a1 04ff460a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v163, s10, v166, v74                        ; cc2100a3 052b4c0a
	v_fma_mixlo_f16 v162, s10, v164, v72                        ; cc2100a2 0523480a
	v_fma_mixhi_f16 v162, s10, v165, v73                        ; cc2200a2 05274a0a
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[10:11], v[4:5], 0   ; cc464054 1a02090a
	v_dual_mov_b32 v73, v57 :: v_dual_mov_b32 v72, v56          ; ca100139 49480138
	v_fma_mixhi_f16 v163, s10, v167, v75                        ; cc2200a3 052f4e0a
(invalid instruction)                                        ; cc1c0066
	v_subrev_f32_e32 v0, v102, v12                              ; 0a001966
	v_dual_mov_b32 v167, v58 :: v_dual_mov_b32 v74, v59         ; ca10013a a74a013b
	v_fma_mixlo_f16 v105, s10, v51, v52                         ; cc210069 04d2660a
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v12                              ; 0a001965
	v_fma_mixhi_f16 v105, s10, v96, v53                         ; cc220069 04d6c00a
	v_dual_mov_b32 v103, v151 :: v_dual_mov_b32 v164, v48       ; ca100197 67a40130
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[10:11], v[8:9], 0 ; cc464090 1a02110a
	v_dual_mov_b32 v165, v49 :: v_dual_mov_b32 v166, v50        ; ca100131 a5a60132
	v_fma_mixlo_f16 v107, s10, v97, v54                         ; cc21006b 04dac20a
(invalid instruction)                                        ; cc1c00a0
	v_subrev_f32_e32 v0, v160, v12                              ; 0a0019a0
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[10:11], v[14:15], 0 ; cc464038 1a021d0a
(invalid instruction)                                        ; cc1c00a1
	v_subrev_f32_e32 v0, v161, v12                              ; 0a0019a1
(invalid instruction)                                        ; cc1b0066
	v_subrev_f32_e32 v0, v102, v11                              ; 0a001766
	v_fma_mixhi_f16 v107, s10, v103, v55                        ; cc22006b 04dece0a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[10:11], v[12:13], 0 ; cc464030 1a02190a
	v_dual_mov_b32 v10, v99 :: v_dual_mov_b32 v75, v98          ; ca100163 0a4a0162
	buffer_load_b128 v[96:99], v106, s[32:35], null offen offset:12368 ; c405c07c 40804060 0030506a
(invalid instruction)                                        ; cc1b0065
	v_subrev_f32_e32 v0, v101, v11                              ; 0a001765
(invalid instruction)                                        ; cc1c0069
	v_subrev_f32_e32 v0, v105, v12                              ; 0a001969
(invalid instruction)                                        ; cc1c00a2
	v_subrev_f32_e32 v0, v162, v12                              ; 0a0019a2
(invalid instruction)                                        ; cc1c00a3
	v_subrev_f32_e32 v0, v163, v12                              ; 0a0019a3
(invalid instruction)                                        ; cc1b00a0
	v_subrev_f32_e32 v0, v160, v11                              ; 0a0017a0
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[20:21], v[36:37], v[84:91] ; cc464054 1d524914
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[20:21], v[18:19], v[144:151] ; cc464090 1e422514
(invalid instruction)                                        ; cc1b00a1
	v_subrev_f32_e32 v0, v161, v11                              ; 0a0017a1
(invalid instruction)                                        ; cc1c006b
	v_subrev_f32_e32 v0, v107, v12                              ; 0a00196b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[20:21], v[32:33], v[56:63] ; cc464038 1ce24114
(invalid instruction)                                        ; cc1b0069
	v_subrev_f32_e32 v0, v105, v11                              ; 0a001769
(invalid instruction)                                        ; cc1b00a2
	v_subrev_f32_e32 v0, v162, v11                              ; 0a0017a2
(invalid instruction)                                        ; cc1b00a3
	v_subrev_f32_e32 v0, v163, v11                              ; 0a0017a3
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[20:21], v[80:81], v[48:55] ; cc464030 1cc2a114
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v20, s10, v86, v134                         ; cc210014 061aac0a
	v_mov_b32_e32 v103, v89                                     ; 7ece0359
	v_mov_b32_e32 v21, v88                                      ; 7e2a0358
	v_fma_mixlo_f16 v11, s10, v84, v132                         ; cc21000b 0612a80a
	v_fma_mixhi_f16 v11, s10, v85, v133                         ; cc22000b 0616aa0a
	v_mov_b32_e32 v133, v91                                     ; 7f0a035b
(invalid instruction)                                        ; cc1b006b
	v_subrev_f32_e32 v0, v107, v11                              ; 0a00176b
	v_fma_mixhi_f16 v20, s10, v87, v135                         ; cc220014 061eae0a
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v134, s10, v21, v140                        ; cc210086 06322a0a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v140, s10, v144, v180                       ; cc21008c 06d3200a
	v_fma_mixhi_f16 v140, s10, v145, v181                       ; cc22008c 06d7220a
	v_fma_mixhi_f16 v134, s10, v103, v141                       ; cc220086 0636ce0a
	v_fma_mixlo_f16 v141, s10, v146, v182                       ; cc21008d 06db240a
	v_fma_mixhi_f16 v141, s10, v147, v183                       ; cc22008d 06df260a
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v12                               ; 0a00190b
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v12                               ; 0a001914
(invalid instruction)                                        ; cc1c008c
	v_subrev_f32_e32 v0, v140, v12                              ; 0a00198c
(invalid instruction)                                        ; cc1c0086
	v_subrev_f32_e32 v0, v134, v12                              ; 0a001986
(invalid instruction)                                        ; cc1c008d
	v_subrev_f32_e32 v0, v141, v12                              ; 0a00198d
(invalid instruction)                                        ; cc1b000b
	v_subrev_f32_e32 v0, v11, v11                               ; 0a00170b
(invalid instruction)                                        ; cc1b0014
	v_subrev_f32_e32 v0, v20, v11                               ; 0a001714
(invalid instruction)                                        ; cc1b008c
	v_subrev_f32_e32 v0, v140, v11                              ; 0a00178c
(invalid instruction)                                        ; cc1b0086
	v_subrev_f32_e32 v0, v134, v11                              ; 0a001786
(invalid instruction)                                        ; cc1b008d
	v_subrev_f32_e32 v0, v141, v11                              ; 0a00178d
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_mov_b32_e32 v21, v140                                     ; 7e2a038c
	v_dual_mov_b32 v103, v141 :: v_dual_mov_b32 v132, v90       ; ca10018d 6784015a
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[28:29], v[4:5], 0   ; cc464054 1a02091c
	v_fma_mixlo_f16 v135, s10, v132, v142                       ; cc210087 063b080a
	v_fma_mixhi_f16 v135, s10, v133, v143                       ; cc220087 063f0a0a
	v_wmma_f32_16x16x16_fp8_fp8 v[140:147], v[28:29], v[8:9], 0 ; cc46408c 1a02111c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v132, s10, v148, v176                       ; cc210084 06c3280a
	v_fma_mixhi_f16 v132, s10, v149, v177                       ; cc220084 06c72a0a
	v_fma_mixlo_f16 v133, s10, v150, v178                       ; cc210085 06cb2c0a
	v_fma_mixhi_f16 v133, s10, v151, v179                       ; cc220085 06cf2e0a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[28:29], v[12:13], 0 ; cc4640b0 1a02191c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v148, s10, v48, v44                         ; cc210094 04b2600a
	v_fma_mixhi_f16 v148, s10, v49, v45                         ; cc220094 04b6620a
(invalid instruction)                                        ; cc1c0087
	v_subrev_f32_e32 v0, v135, v12                              ; 0a001987
	v_fma_mixlo_f16 v149, s10, v50, v46                         ; cc210095 04ba640a
	v_fma_mixhi_f16 v149, s10, v51, v47                         ; cc220095 04be660a
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[28:29], v[14:15], 0 ; cc46402c 1a021d1c
(invalid instruction)                                        ; cc1c0084
	v_subrev_f32_e32 v0, v132, v12                              ; 0a001984
(invalid instruction)                                        ; cc1c0085
	v_subrev_f32_e32 v0, v133, v12                              ; 0a001985
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[82:83], v[36:37], v[84:91] ; cc464054 1d524952
	v_wmma_f32_16x16x16_fp8_fp8 v[140:147], v[82:83], v[18:19], v[140:147] ; cc46408c 1e322552
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v150, s10, v52, v64                         ; cc210096 0502680a
	v_fma_mixhi_f16 v150, s10, v53, v65                         ; cc220096 05066a0a
(invalid instruction)                                        ; cc1c0094
	v_subrev_f32_e32 v0, v148, v12                              ; 0a001994
(invalid instruction)                                        ; cc1b0087
	v_subrev_f32_e32 v0, v135, v11                              ; 0a001787
(invalid instruction)                                        ; cc1c0095
	v_subrev_f32_e32 v0, v149, v12                              ; 0a001995
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[82:83], v[80:81], v[176:183] ; cc4640b0 1ec2a152
	v_fma_mixlo_f16 v151, s10, v54, v66                         ; cc210097 050a6c0a
(invalid instruction)                                        ; cc1b0084
	v_subrev_f32_e32 v0, v132, v11                              ; 0a001784
(invalid instruction)                                        ; cc1b0085
	v_subrev_f32_e32 v0, v133, v11                              ; 0a001785
	v_fma_mixhi_f16 v151, s10, v55, v67                         ; cc220097 050e6e0a
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[82:83], v[32:33], v[44:51] ; cc46402c 1cb24152
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v28, s10, v56, v76                          ; cc21001c 0532700a
	v_fma_mixhi_f16 v28, s10, v57, v77                          ; cc22001c 0536720a
(invalid instruction)                                        ; cc1c0096
	v_subrev_f32_e32 v0, v150, v12                              ; 0a001996
(invalid instruction)                                        ; cc1b0094
	v_subrev_f32_e32 v0, v148, v11                              ; 0a001794
(invalid instruction)                                        ; cc1b0095
	v_subrev_f32_e32 v0, v149, v11                              ; 0a001795
	v_fma_mixlo_f16 v29, s10, v58, v78                          ; cc21001d 053a740a
	v_fma_mixhi_f16 v29, s10, v59, v79                          ; cc22001d 053e760a
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[56:59], v106, s[32:35], null offen offset:128 ; c405c07c 40804038 0000806a
	buffer_load_b128 v[64:67], v106, s[32:35], null offen offset:144 ; c405c07c 40804040 0000906a
	buffer_load_b128 v[76:79], v106, s[32:35], null offen offset:4224 ; c405c07c 4080404c 0010806a
(invalid instruction)                                        ; cc1c0097
	v_subrev_f32_e32 v0, v151, v12                              ; 0a001997
	v_mov_b32_e32 v54, v63                                      ; 7e6c033f
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_mov_b32_e32 v55, v99                                      ; 7e6e0363
	v_fma_mixlo_f16 v52, s10, v60, v96                          ; cc210034 0582780a
	v_fma_mixhi_f16 v52, s10, v61, v97                          ; cc220034 05867a0a
	v_fma_mixlo_f16 v53, s10, v62, v98                          ; cc210035 058a7c0a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v106, s[32:35], null offen offset:4240 ; c405c07c 4080403c 0010906a
	buffer_load_b128 v[96:99], v106, s[32:35], null offen offset:8320 ; c405c07c 40804060 0020806a
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v12                               ; 0a00191c
(invalid instruction)                                        ; cc1b0096
	v_subrev_f32_e32 v0, v150, v11                              ; 0a001796
(invalid instruction)                                        ; cc1c001d
	v_subrev_f32_e32 v0, v29, v12                               ; 0a00191d
(invalid instruction)                                        ; cc1b0097
	v_subrev_f32_e32 v0, v151, v11                              ; 0a001797
	v_fma_mixhi_f16 v53, s10, v54, v55                          ; cc220035 04de6c0a
(invalid instruction)                                        ; cc1c0034
	v_subrev_f32_e32 v0, v52, v12                               ; 0a001934
(invalid instruction)                                        ; cc1b001c
	v_subrev_f32_e32 v0, v28, v11                               ; 0a00171c
(invalid instruction)                                        ; cc1b001d
	v_subrev_f32_e32 v0, v29, v11                               ; 0a00171d
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; cc1c0035
	v_subrev_f32_e32 v0, v53, v12                               ; 0a001935
(invalid instruction)                                        ; cc1b0034
	v_subrev_f32_e32 v0, v52, v11                               ; 0a001734
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v56, s10, v84, v56                          ; cc210038 04e2a80a
(invalid instruction)                                        ; cc1b0035
	v_subrev_f32_e32 v0, v53, v11                               ; 0a001735
	v_fma_mixhi_f16 v56, s10, v85, v57                          ; cc220038 04e6aa0a
	v_fma_mixlo_f16 v57, s10, v86, v58                          ; cc210039 04eaac0a
	v_fma_mixhi_f16 v57, s10, v87, v59                          ; cc220039 04eeae0a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v58, s10, v88, v64                          ; cc21003a 0502b00a
	v_mov_b32_e32 v54, v67                                      ; 7e6c0343
	v_fma_mixlo_f16 v59, s10, v90, v66                          ; cc21003b 050ab40a
	v_fma_mixhi_f16 v58, s10, v89, v65                          ; cc22003a 0506b20a
	v_mov_b32_e32 v55, v91                                      ; 7e6e035b
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[84:87], v106, s[32:35], null offen offset:8336 ; c405c07c 40804054 0020906a
	buffer_load_b128 v[64:67], v106, s[32:35], null offen offset:12416 ; c405c07c 40804040 0030806a
	buffer_load_b128 v[88:91], v106, s[32:35], null offen offset:12432 ; c405c07c 40804058 0030906a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v76, s10, v140, v76                         ; cc21004c 0533180a
	v_fma_mixhi_f16 v76, s10, v141, v77                         ; cc22004c 05371a0a
	v_fma_mixlo_f16 v77, s10, v142, v78                         ; cc21004d 053b1c0a
	v_fma_mixhi_f16 v77, s10, v143, v79                         ; cc22004d 053f1e0a
	v_dual_mov_b32 v79, v137 :: v_dual_mov_b32 v78, v136        ; ca100189 4f4e0188
(invalid instruction)                                        ; cc1c0038
	v_subrev_f32_e32 v0, v56, v12                               ; 0a001938
	v_dual_mov_b32 v83, v139 :: v_dual_mov_b32 v82, v138        ; ca10018b 5352018a
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v12                               ; 0a001939
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[24:25], v[4:5], 0 ; cc464088 1a020918
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v12                               ; 0a00193a
	v_fma_mixhi_f16 v59, s10, v55, v54                          ; cc22003b 04da6e0a
(invalid instruction)                                        ; cc1c004c
	v_subrev_f32_e32 v0, v76, v12                               ; 0a00194c
(invalid instruction)                                        ; cc1b0038
	v_subrev_f32_e32 v0, v56, v11                               ; 0a001738
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v11                               ; 0a001739
(invalid instruction)                                        ; cc1c004d
	v_subrev_f32_e32 v0, v77, v12                               ; 0a00194d
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v11                               ; 0a00173a
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v12                               ; 0a00193b
(invalid instruction)                                        ; cc1b004c
	v_subrev_f32_e32 v0, v76, v11                               ; 0a00174c
	v_dual_mov_b32 v5, v57 :: v_dual_mov_b32 v4, v56            ; ca100139 05040138
(invalid instruction)                                        ; cc1b004d
	v_subrev_f32_e32 v0, v77, v11                               ; 0a00174d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v11                               ; 0a00173b
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v144, s10, v144, v60                        ; cc210090 04f3200a
	v_fma_mixhi_f16 v144, s10, v145, v61                        ; cc220090 04f7220a
	v_fma_mixlo_f16 v145, s10, v146, v62                        ; cc210091 04fb240a
	v_fma_mixhi_f16 v145, s10, v147, v63                        ; cc220091 04ff260a
	v_dual_mov_b32 v147, v175 :: v_dual_mov_b32 v146, v174      ; ca1001af 939201ae
	v_dual_mov_b32 v63, v59 :: v_dual_mov_b32 v62, v58          ; ca10013b 3f3e013a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v96, s10, v176, v96                         ; cc210060 0583600a
	v_fma_mixhi_f16 v96, s10, v177, v97                         ; cc220060 0587620a
	v_fma_mixlo_f16 v97, s10, v178, v98                         ; cc210061 058b640a
	v_fma_mixhi_f16 v97, s10, v179, v99                         ; cc220061 058f660a
	v_dual_mov_b32 v99, v173 :: v_dual_mov_b32 v98, v172        ; ca1001ad 636201ac
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[24:25], v[8:9], 0   ; cc464036 1a021118
(invalid instruction)                                        ; cc1c0090
	v_subrev_f32_e32 v0, v144, v12                              ; 0a001990
(invalid instruction)                                        ; cc1c0091
	v_subrev_f32_e32 v0, v145, v12                              ; 0a001991
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[24:25], v[12:13], 0 ; cc4640ac 1a021918
(invalid instruction)                                        ; cc1c0060
	v_subrev_f32_e32 v0, v96, v12                               ; 0a001960
(invalid instruction)                                        ; cc1c0061
	v_subrev_f32_e32 v0, v97, v12                               ; 0a001961
(invalid instruction)                                        ; cc1b0090
	v_subrev_f32_e32 v0, v144, v11                              ; 0a001790
(invalid instruction)                                        ; cc1b0091
	v_subrev_f32_e32 v0, v145, v11                              ; 0a001791
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[34:35], v[36:37], v[136:143] ; cc464088 1e224922
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[34:35], v[18:19], v[54:61] ; cc464036 1cda2522
(invalid instruction)                                        ; cc1b0060
	v_subrev_f32_e32 v0, v96, v11                               ; 0a001760
(invalid instruction)                                        ; cc1b0061
	v_subrev_f32_e32 v0, v97, v11                               ; 0a001761
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[34:35], v[80:81], v[172:179] ; cc4640ac 1eb2a122
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v180, s10, v180, v84                        ; cc2100b4 0553680a
	v_fma_mixhi_f16 v180, s10, v181, v85                        ; cc2200b4 05576a0a
	v_dual_mov_b32 v85, v11 :: v_dual_mov_b32 v84, v10          ; ca10010b 5554010a
	v_fma_mixlo_f16 v181, s10, v182, v86                        ; cc2100b5 055b6c0a
	v_fma_mixhi_f16 v181, s10, v183, v87                        ; cc2200b5 055f6e0a
	v_dual_mov_b32 v183, v7 :: v_dual_mov_b32 v182, v6          ; ca100107 b7b60106
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[24:25], v[14:15], 0  ; cc464006 1a021d18
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v86, s10, v44, v64                          ; cc210056 0502580a
	v_fma_mixhi_f16 v86, s10, v45, v65                          ; cc220056 05065a0a
	v_fma_mixlo_f16 v87, s10, v46, v66                          ; cc210057 050a5c0a
	v_fma_mixhi_f16 v87, s10, v47, v67                          ; cc220057 050e5e0a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v88, s10, v48, v88                          ; cc210058 0562600a
	v_fma_mixhi_f16 v88, s10, v49, v89                          ; cc220058 0566620a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[34:35], v[32:33], v[6:13] ; cc464006 1c1a4122
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v12                              ; 0a0019b4
	v_fma_mixlo_f16 v89, s10, v50, v90                          ; cc210059 056a640a
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v12                              ; 0a0019b5
	v_mov_b32_e32 v14, v51                                      ; 7e1c0333
(invalid instruction)                                        ; cc1c0056
	v_subrev_f32_e32 v0, v86, v12                               ; 0a001956
	v_dual_mov_b32 v18, v39 :: v_dual_mov_b32 v15, v38          ; ca100127 120e0126
	v_dual_mov_b32 v24, v83 :: v_dual_mov_b32 v19, v82          ; ca100153 18120152
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[32:35], v106, s[32:35], null offen offset:192 ; c405c07c 40804020 0000c06a
	buffer_load_b128 v[44:47], v106, s[32:35], null offen offset:208 ; c405c07c 4080402c 0000d06a
	buffer_load_b128 v[64:67], v106, s[32:35], null offen offset:4288 ; c405c07c 40804040 0010c06a
	buffer_load_b128 v[48:51], v106, s[32:35], null offen offset:4304 ; c405c07c 40804030 0010d06a
	buffer_load_b128 v[36:39], v106, s[32:35], null offen offset:8384 ; c405c07c 40804024 0020c06a
	buffer_load_b128 v[80:83], v106, s[32:35], null offen offset:8400 ; c405c07c 40804050 0020d06a
(invalid instruction)                                        ; cc1c0057
	v_subrev_f32_e32 v0, v87, v12                               ; 0a001957
(invalid instruction)                                        ; cc1c0058
	v_subrev_f32_e32 v0, v88, v12                               ; 0a001958
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v25, s10, v136, v32                         ; cc210019 0483100a
(invalid instruction)                                        ; cc1b00b4
	v_subrev_f32_e32 v0, v180, v11                              ; 0a0017b4
	v_fma_mixhi_f16 v89, s10, v14, v91                          ; cc220059 056e1c0a
	v_fma_mixhi_f16 v25, s10, v137, v33                         ; cc220019 0487120a
	v_fma_mixlo_f16 v32, s10, v138, v34                         ; cc210020 048b140a
	v_fma_mixhi_f16 v32, s10, v139, v35                         ; cc220020 048f160a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mov_b32_e32 v14, v32                                      ; 7e1c0320
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[136:139], v106, s[32:35], null offen offset:12480 ; c405c07c 40804088 0030c06a
	buffer_load_b128 v[32:35], v106, s[32:35], null offen offset:12496 ; c405c07c 40804020 0030d06a
(invalid instruction)                                        ; cc1b00b5
	v_subrev_f32_e32 v0, v181, v11                              ; 0a0017b5
(invalid instruction)                                        ; cc1b0056
	v_subrev_f32_e32 v0, v86, v11                               ; 0a001756
(invalid instruction)                                        ; cc1b0057
	v_subrev_f32_e32 v0, v87, v11                               ; 0a001757
(invalid instruction)                                        ; cc1b0058
	v_subrev_f32_e32 v0, v88, v11                               ; 0a001758
	s_mov_b32 s16, 0x7ff88000                                   ; be9000ff 7ff88000
(invalid instruction)                                        ; cc1c0059
	v_subrev_f32_e32 v0, v89, v12                               ; 0a001959
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v12                               ; 0a001919
(invalid instruction)                                        ; cc1c000e
	v_subrev_f32_e32 v0, v14, v12                               ; 0a00190e
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v91, s10, v140, v44                         ; cc21005b 04b3180a
	v_fma_mixhi_f16 v91, s10, v141, v45                         ; cc22005b 04b71a0a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v20, v20, 5, s16                             ; d6460014 00410b14
	v_lshl_add_u32 v4, v4, 5, s16                               ; d6460004 00410b04
	v_lshl_add_u32 v169, v169, 5, s16                           ; d64600a9 00410ba9
	v_lshl_add_u32 v168, v168, 5, s16                           ; d64600a8 00410ba8
	v_lshl_add_u32 v85, v85, 5, s16                             ; d6460055 00410b55
	v_fma_mixlo_f16 v106, s10, v142, v46                        ; cc21006a 04bb1c0a
	v_fma_mixhi_f16 v106, s10, v143, v47                        ; cc22006a 04bf1e0a
(invalid instruction)                                        ; cc1b0059
	v_subrev_f32_e32 v0, v89, v11                               ; 0a001759
(invalid instruction)                                        ; cc1b0019
	v_subrev_f32_e32 v0, v25, v11                               ; 0a001719
(invalid instruction)                                        ; cc1b000e
	v_subrev_f32_e32 v0, v14, v11                               ; 0a00170e
	v_lshl_add_u32 v5, v5, 5, s16                               ; d6460005 00410b05
(invalid instruction)                                        ; cc1c005b
	v_subrev_f32_e32 v0, v91, v12                               ; 0a00195b
(invalid instruction)                                        ; cc0f008c
	v_min_num_f64_e32 v[1:2], v[169:170], v[20:21]              ; 1a0229a9
	v_lshl_add_u32 v170, v170, 5, s16                           ; d64600aa 00410baa
	v_lshl_add_u32 v134, v134, 5, s16                           ; d6460086 00410b86
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[168:169], v[85:86]              ; 1a02aba8
	v_lshl_add_u32 v62, v62, 5, s16                             ; d646003e 00410b3e
(invalid instruction)                                        ; cc1c006a
	v_subrev_f32_e32 v0, v106, v12                              ; 0a00196a
	v_lshl_add_u32 v25, v25, 5, s16                             ; d6460019 00410b19
	v_lshl_add_u32 v14, v14, 5, s16                             ; d646000e 00410b0e
	v_lshl_add_u32 v171, v171, 5, s16                           ; d64600ab 00410bab
	v_lshl_add_u32 v135, v135, 5, s16                           ; d6460087 00410b87
(invalid instruction)                                        ; cc1b005b
	v_subrev_f32_e32 v0, v91, v11                               ; 0a00175b
	v_lshl_add_u32 v63, v63, 5, s16                             ; d646003f 00410b3f
(invalid instruction)                                        ; cc0f008c
	v_min_num_f64_e32 v[1:2], v[140:141], v[5:6]                ; 1a020b8c
(invalid instruction)                                        ; cc0f008d
	v_min_num_f64_e32 v[1:2], v[170:171], v[134:135]            ; 1a030daa
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[4:5]                  ; 1a02095a
(invalid instruction)                                        ; cc1b006a
	v_subrev_f32_e32 v0, v106, v11                              ; 0a00176a
(invalid instruction)                                        ; cc0f008e
	v_min_num_f64_e32 v[1:2], v[171:172], v[135:136]            ; 1a030fab
	v_lshl_add_u32 v91, v91, 5, s16                             ; d646005b 00410b5b
(invalid instruction)                                        ; cc0f008c
	v_min_num_f64_e32 v[1:2], v[140:141], v[14:15]              ; 1a021d8c
(invalid instruction)                                        ; cc0f008d
	v_min_num_f64_e32 v[1:2], v[141:142], v[62:63]              ; 1a027d8d
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[25:26]                ; 1a02335a
	v_lshl_add_u32 v106, v106, 5, s16                           ; d646006a 00410b6a
(invalid instruction)                                        ; cc0f008e
	v_min_num_f64_e32 v[1:2], v[142:143], v[63:64]              ; 1a027f8e
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; cc0f008d
	v_min_num_f64_e32 v[1:2], v[141:142], v[91:92]              ; 1a02b78d
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[140:141]              ; 1a03195a
(invalid instruction)                                        ; cc0f008e
	v_min_num_f64_e32 v[1:2], v[142:143], v[106:107]            ; 1a02d58e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[141:142]              ; 1a031b5a
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[142:143]              ; 1a031d5a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v143, v90, s4, s5 op_sel:[1,1]            ; d65c188f 0014095a
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[143:144]              ; 1a031f5a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v44, v90, v218/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 6459b55a
	v_max_num_f16_e32 v44, s3, v44                              ; 62585803
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v45, v44                                  ; 7e5a172c
	v_rcp_f32_e32 v45, v45                                      ; 7e5a552d
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v47, v169, v45, neg(0) op_sel_hi:[1,0,0]      ; cc20002f 8a025ba9
	v_fma_mix_f32 v140, v171, v45, neg(0) op_sel_hi:[1,0,0]     ; cc20008c 8a025bab
	v_fma_mix_f32 v169, v169, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a025ba9
	v_fma_mix_f32 v46, v168, v45, neg(0) op_sel_hi:[1,0,0]      ; cc20002e 8a025ba8
	v_fma_mix_f32 v142, v20, v45, neg(0) op_sel_hi:[1,0,0]      ; cc20008e 8a025b14
	v_fma_mix_f32 v168, v168, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a8 8a025ba8
	v_fma_mix_f32 v90, v170, v45, neg(0) op_sel_hi:[1,0,0]      ; cc20005a 8a025baa
	v_fma_mix_f32 v170, v170, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008aa 8a025baa
	v_fma_mix_f32 v171, v171, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ab 8a025bab
	v_fma_mix_f32 v141, v85, v45, neg(0) op_sel_hi:[1,0,0]      ; cc20008d 8a025b55
	v_fma_mix_f32 v85, v85, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200855 8a025b55
	v_fma_mix_f32 v20, v20, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a025b14
	v_fma_mix_f32 v143, v134, v45, neg(0) op_sel_hi:[1,0,0]     ; cc20008f 8a025b86
	v_fma_mix_f32 v134, v134, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200886 8a025b86
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v46, v168, vcc_lo                     ; 0203512e
	v_fma_mix_f32 v168, v135, v45, neg(0) op_sel_hi:[1,0,0]     ; cc2000a8 8a025b87
	v_fma_mix_f32 v135, v135, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200887 8a025b87
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v47, v169, vcc_lo                     ; 0203532f
	v_fma_mix_f32 v169, v4, v45, neg(0) op_sel_hi:[1,0,0]       ; cc2000a9 8a025b04
	v_fma_mix_f32 v4, v4, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200804 8a025b04
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v90, v170, vcc_lo                     ; 0203555a
	v_fma_mix_f32 v170, v5, v45, neg(0) op_sel_hi:[1,0,0]       ; cc2000aa 8a025b05
	v_fma_mix_f32 v5, v5, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200805 8a025b05
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v140, v171, vcc_lo                    ; 0203578c
	v_fma_mix_f32 v171, v62, v45, neg(0) op_sel_hi:[1,0,0]      ; cc2000ab 8a025b3e
(invalid instruction)                                        ; d769008c
	v_cndmask_b32_e32 v1, v141, v85, vcc_lo                     ; 0202ab8d
	v_fma_mix_f32 v62, v62, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083e 8a025b3e
(invalid instruction)                                        ; d769408c
	v_cndmask_b32_e32 v1, v142, v20, vcc_lo                     ; 0202298e
(invalid instruction)                                        ; d769008d
	v_cndmask_b32_e32 v1, v143, v134, vcc_lo                    ; 02030d8f
(invalid instruction)                                        ; d769408d
	v_cndmask_b32_e32 v1, v168, v135, vcc_lo                    ; 02030fa8
	v_fma_mix_f32 v20, v14, v45, neg(0) op_sel_hi:[1,0,0]       ; cc200014 8a025b0e
(invalid instruction)                                        ; d7690086
	v_cndmask_b32_e32 v1, v169, v4, vcc_lo                      ; 020209a9
	v_fma_mix_f32 v4, v63, v45, neg(0) op_sel_hi:[1,0,0]        ; cc200004 8a025b3f
	v_fma_mix_f32 v63, v63, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083f 8a025b3f
	v_fma_mix_f32 v14, v14, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080e 8a025b0e
(invalid instruction)                                        ; d7694086
	v_cndmask_b32_e32 v1, v170, v5, vcc_lo                      ; 02020baa
	v_fma_mix_f32 v5, v25, v45, neg(0) op_sel_hi:[1,0,0]        ; cc200005 8a025b19
	v_fma_mix_f32 v25, v25, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a025b19
	v_fma_mix_f32 v44, v106, v45, neg(0) op_sel_hi:[1,0,0]      ; cc20002c 8a025b6a
	v_fma_mix_f32 v106, v106, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086a 8a025b6a
(invalid instruction)                                        ; d7690087
	v_cndmask_b32_e32 v1, v171, v62, vcc_lo                     ; 02027dab
	v_lshl_add_u32 v182, v182, 5, s16                           ; d64600b6 00410bb6
	v_lshl_add_u32 v21, v21, 5, s16                             ; d6460015 00410b15
	v_lshl_add_u32 v76, v76, 5, s16                             ; d646004c 00410b4c
	v_lshl_add_u32 v75, v75, 5, s16                             ; d646004b 00410b4b
	v_lshl_add_u32 v103, v103, 5, s16                           ; d6460067 00410b67
(invalid instruction)                                        ; d7694087
	v_cndmask_b32_e32 v1, v4, v63, vcc_lo                       ; 02027f04
	v_lshl_add_u32 v77, v77, 5, s16                             ; d646004d 00410b4d
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                       ; 02023305
	v_fma_mix_f32 v25, v91, v45, neg(0) op_sel_hi:[1,0,0]       ; cc200019 8a025b5b
	v_fma_mix_f32 v91, v91, v45, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085b 8a025b5b
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v20, v14, vcc_lo                      ; 02021d14
	v_lshl_add_u32 v84, v84, 5, s16                             ; d6460054 00410b54
	v_lshl_add_u32 v132, v132, 5, s16                           ; d6460084 00410b84
	v_lshl_add_u32 v144, v144, 5, s16                           ; d6460090 00410b90
	v_lshl_add_u32 v100, v100, 5, s16                           ; d6460064 00410b64
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[182:183], v[21:22]              ; 1a022bb6
	v_lshl_add_u32 v133, v133, 5, s16                           ; d6460085 00410b85
	v_lshl_add_u32 v145, v145, 5, s16                           ; d6460091 00410b91
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[75:76], v[103:104]              ; 1a02cf4b
	v_lshl_add_u32 v101, v101, 5, s16                           ; d6460065 00410b65
	v_lshl_add_u32 v148, v148, 5, s16                           ; d6460094 00410b94
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v25, v91, vcc_lo                      ; 0202b719
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v44, v106, vcc_lo                     ; 0202d52c
	v_lshl_add_u32 v96, v96, 5, s16                             ; d6460060 00410b60
	v_lshl_add_u32 v102, v102, 5, s16                           ; d6460066 00410b66
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[84:85], v[132:133]              ; 1a030954
	v_lshl_add_u32 v149, v149, 5, s16                           ; d6460095 00410b95
	v_lshl_add_u32 v97, v97, 5, s16                             ; d6460061 00410b61
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[76:77]                ; 1a02992d
	v_lshl_add_u32 v105, v105, 5, s16                           ; d6460069 00410b69
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[100:101], v[133:134]            ; 1a030b64
	v_lshl_add_u32 v150, v150, 5, s16                           ; d6460096 00410b96
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[77:78]                ; 1a029b3e
	v_lshl_add_u32 v180, v180, 5, s16                           ; d64600b4 00410bb4
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[101:102], v[148:149]            ; 1a032965
	v_lshl_add_u32 v107, v107, 5, s16                           ; d646006b 00410b6b
	v_lshl_add_u32 v151, v151, 5, s16                           ; d6460097 00410b97
	v_lshl_add_u32 v181, v181, 5, s16                           ; d64600b5 00410bb5
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[144:145]              ; 1a03213f
(invalid instruction)                                        ; cc0f005b
	v_min_num_f64_e32 v[1:2], v[102:103], v[149:150]            ; 1a032b66
	v_lshl_add_u32 v160, v160, 5, s16                           ; d64600a0 00410ba0
	v_lshl_add_u32 v28, v28, 5, s16                             ; d646001c 00410b1c
	v_lshl_add_u32 v86, v86, 5, s16                             ; d6460056 00410b56
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[145:146]              ; 1a032355
(invalid instruction)                                        ; cc0f006a
	v_min_num_f64_e32 v[1:2], v[105:106], v[150:151]            ; 1a032d69
	v_lshl_add_u32 v161, v161, 5, s16                           ; d64600a1 00410ba1
	v_lshl_add_u32 v29, v29, 5, s16                             ; d646001d 00410b1d
	v_lshl_add_u32 v87, v87, 5, s16                             ; d6460057 00410b57
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[96:97]                ; 1a02c15a
(invalid instruction)                                        ; cc0f008e
	v_min_num_f64_e32 v[1:2], v[107:108], v[151:152]            ; 1a032f6b
	v_lshl_add_u32 v162, v162, 5, s16                           ; d64600a2 00410ba2
	v_lshl_add_u32 v52, v52, 5, s16                             ; d6460034 00410b34
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v169, s10, v54, v64                         ; cc2100a9 05026c0a
(invalid instruction)                                        ; cc0f005b
	v_min_num_f64_e32 v[1:2], v[91:92], v[97:98]                ; 1a02c35b
	v_fma_mixhi_f16 v169, s10, v55, v65                         ; cc2200a9 05066e0a
(invalid instruction)                                        ; cc0f008f
	v_min_num_f64_e32 v[1:2], v[160:161], v[28:29]              ; 1a0239a0
	v_fma_mixlo_f16 v170, s10, v56, v66                         ; cc2100aa 050a700a
	v_fma_mixhi_f16 v170, s10, v57, v67                         ; cc2200aa 050e720a
(invalid instruction)                                        ; cc0f006a
	v_min_num_f64_e32 v[1:2], v[106:107], v[180:181]            ; 1a03696a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v171, s10, v58, v48                         ; cc2100ab 04c2740a
(invalid instruction)                                        ; cc0f00a8
	v_min_num_f64_e32 v[1:2], v[161:162], v[29:30]              ; 1a023ba1
	v_fma_mixhi_f16 v171, s10, v59, v49                         ; cc2200ab 04c6760a
(invalid instruction)                                        ; cc0f008e
	v_min_num_f64_e32 v[1:2], v[142:143], v[181:182]            ; 1a036b8e
	v_fma_mixlo_f16 v14, s10, v60, v50                          ; cc21000e 04ca780a
	v_fma_mixhi_f16 v14, s10, v61, v51                          ; cc22000e 04ce7a0a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v20, s10, v172, v36                         ; cc210014 0493580a
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v12                              ; 0a0019a9
(invalid instruction)                                        ; cc0f008f
	v_min_num_f64_e32 v[1:2], v[143:144], v[86:87]              ; 1a02ad8f
	v_fma_mixhi_f16 v20, s10, v173, v37                         ; cc220014 04975a0a
(invalid instruction)                                        ; cc1c00aa
	v_subrev_f32_e32 v0, v170, v12                              ; 0a0019aa
	v_fma_mixlo_f16 v25, s10, v174, v38                         ; cc210019 049b5c0a
	v_fma_mixhi_f16 v25, s10, v175, v39                         ; cc220019 049f5e0a
(invalid instruction)                                        ; cc0f00a8
	v_min_num_f64_e32 v[1:2], v[168:169], v[87:88]              ; 1a02afa8
(invalid instruction)                                        ; cc1c00ab
	v_subrev_f32_e32 v0, v171, v12                              ; 0a0019ab
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v36, s10, v176, v80                         ; cc210024 0543600a
	v_fma_mixhi_f16 v36, s10, v177, v81                         ; cc220024 0547620a
(invalid instruction)                                        ; cc1c000e
	v_subrev_f32_e32 v0, v14, v12                               ; 0a00190e
	v_fma_mixlo_f16 v37, s10, v178, v82                         ; cc210025 054b640a
(invalid instruction)                                        ; cc1b00a9
	v_subrev_f32_e32 v0, v169, v11                              ; 0a0017a9
	v_fma_mixhi_f16 v37, s10, v179, v83                         ; cc220025 054f660a
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v12                               ; 0a001914
(invalid instruction)                                        ; cc1b00aa
	v_subrev_f32_e32 v0, v170, v11                              ; 0a0017aa
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v12                               ; 0a001919
(invalid instruction)                                        ; cc1b00ab
	v_subrev_f32_e32 v0, v171, v11                              ; 0a0017ab
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v12                               ; 0a001924
(invalid instruction)                                        ; cc1b000e
	v_subrev_f32_e32 v0, v14, v11                               ; 0a00170e
(invalid instruction)                                        ; cc1c0025
	v_subrev_f32_e32 v0, v37, v12                               ; 0a001925
(invalid instruction)                                        ; cc1b0014
	v_subrev_f32_e32 v0, v20, v11                               ; 0a001714
(invalid instruction)                                        ; cc1b0019
	v_subrev_f32_e32 v0, v25, v11                               ; 0a001719
(invalid instruction)                                        ; cc1b0024
	v_subrev_f32_e32 v0, v36, v11                               ; 0a001724
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b0025
	v_subrev_f32_e32 v0, v37, v11                               ; 0a001725
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v39, s10, v8, v138                          ; cc210027 062a100a
	v_fma_mixhi_f16 v39, s10, v9, v139                          ; cc220027 062e120a
	v_fma_mixlo_f16 v38, s10, v6, v136                          ; cc210026 06220c0a
	v_fma_mixhi_f16 v38, s10, v7, v137                          ; cc220026 06260e0a
	v_lshl_add_u32 v169, v169, 5, s16                           ; d64600a9 00410ba9
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v48, s10, v12, v34                          ; cc210030 048a180a
	v_fma_mixlo_f16 v44, s10, v10, v32                          ; cc21002c 0482140a
	v_fma_mixhi_f16 v44, s10, v11, v33                          ; cc22002c 0486160a
	v_fma_mixhi_f16 v48, s10, v13, v35                          ; cc220030 048e1a0a
	v_lshl_add_u32 v170, v170, 5, s16                           ; d64600aa 00410baa
	v_lshl_add_u32 v171, v171, 5, s16                           ; d64600ab 00410bab
	v_lshl_add_u32 v14, v14, 5, s16                             ; d646000e 00410b0e
(invalid instruction)                                        ; cc1c0027
	v_subrev_f32_e32 v0, v39, v12                               ; 0a001927
(invalid instruction)                                        ; cc1c0026
	v_subrev_f32_e32 v0, v38, v12                               ; 0a001926
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[169:170]              ; 1a03532d
(invalid instruction)                                        ; cc1c002c
	v_subrev_f32_e32 v0, v44, v12                               ; 0a00192c
(invalid instruction)                                        ; cc1c0030
	v_subrev_f32_e32 v0, v48, v12                               ; 0a001930
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[170:171]              ; 1a03553e
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[171:172]              ; 1a03573f
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[14:15]                ; 1a021d55
(invalid instruction)                                        ; cc1b0027
	v_subrev_f32_e32 v0, v39, v11                               ; 0a001727
(invalid instruction)                                        ; cc1b0026
	v_subrev_f32_e32 v0, v38, v11                               ; 0a001726
(invalid instruction)                                        ; cc1b002c
	v_subrev_f32_e32 v0, v44, v11                               ; 0a00172c
(invalid instruction)                                        ; cc1b0030
	v_subrev_f32_e32 v0, v48, v11                               ; 0a001730
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[62:63]                ; 1a027d2d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[63:64]                ; 1a027f2d
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[85:86]                ; 1a02ab2d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v49, v45, s4, s5 op_sel:[1,1]             ; d65c1831 0014092d
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[49:50]                ; 1a02632d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v50, v45, v173/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64655b2d
	v_max_num_f16_e32 v50, s3, v50                              ; 62646403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
	v_rcp_f32_e32 v51, v51                                      ; 7e665533
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v56, v84, v51, neg(0) op_sel_hi:[1,0,0]       ; cc200038 8a026754
	v_fma_mix_f32 v58, v21, v51, neg(0) op_sel_hi:[1,0,0]       ; cc20003a 8a026715
	v_fma_mix_f32 v57, v100, v51, neg(0) op_sel_hi:[1,0,0]      ; cc200039 8a026764
	v_fma_mix_f32 v59, v103, v51, neg(0) op_sel_hi:[1,0,0]      ; cc20003b 8a026767
	v_fma_mix_f32 v21, v21, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a026715
	v_fma_mix_f32 v55, v75, v51, neg(0) op_sel_hi:[1,0,0]       ; cc200037 8a02674b
	v_fma_mix_f32 v75, v75, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084b 8a02674b
	v_fma_mix_f32 v100, v100, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200864 8a026764
	v_fma_mix_f32 v84, v84, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200854 8a026754
	v_fma_mix_f32 v54, v182, v51, neg(0) op_sel_hi:[1,0,0]      ; cc200036 8a0267b6
	v_fma_mix_f32 v182, v182, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a0267b6
	v_fma_mix_f32 v103, v103, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200867 8a026767
	v_fma_mix_f32 v60, v132, v51, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a026784
	v_fma_mix_f32 v132, v132, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200884 8a026784
	v_fma_mix_f32 v61, v133, v51, neg(0) op_sel_hi:[1,0,0]      ; cc20003d 8a026785
	v_fma_mix_f32 v133, v133, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200885 8a026785
	v_fma_mix_f32 v62, v76, v51, neg(0) op_sel_hi:[1,0,0]       ; cc20003e 8a02674c
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v58, v21, vcc_lo                      ; 02022b3a
	v_fma_mix_f32 v76, v76, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084c 8a02674c
	v_fma_mix_f32 v63, v77, v51, neg(0) op_sel_hi:[1,0,0]       ; cc20003f 8a02674d
	v_fma_mix_f32 v77, v77, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084d 8a02674d
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v56, v84, vcc_lo                      ; 0202a938
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v57, v100, vcc_lo                     ; 0202c939
	v_fma_mix_f32 v64, v144, v51, neg(0) op_sel_hi:[1,0,0]      ; cc200040 8a026790
	v_fma_mix_f32 v144, v144, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200890 8a026790
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v54, v182, vcc_lo                     ; 02036d36
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v55, v75, vcc_lo                      ; 02029737
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v59, v103, vcc_lo                     ; 0202cf3b
	v_fma_mix_f32 v65, v145, v51, neg(0) op_sel_hi:[1,0,0]      ; cc200041 8a026791
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v60, v132, vcc_lo                     ; 0203093c
	v_fma_mix_f32 v145, v145, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a026791
	v_fma_mix_f32 v66, v169, v51, neg(0) op_sel_hi:[1,0,0]      ; cc200042 8a0267a9
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v61, v133, vcc_lo                     ; 02030b3d
	v_fma_mix_f32 v169, v169, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a0267a9
	v_fma_mix_f32 v67, v170, v51, neg(0) op_sel_hi:[1,0,0]      ; cc200043 8a0267aa
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                      ; 0202993e
	v_fma_mix_f32 v170, v170, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008aa 8a0267aa
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v63, v77, vcc_lo                      ; 02029b3f
	v_fma_mix_f32 v75, v171, v51, neg(0) op_sel_hi:[1,0,0]      ; cc20004b 8a0267ab
	v_fma_mix_f32 v171, v171, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ab 8a0267ab
	v_fma_mix_f32 v76, v14, v51, neg(0) op_sel_hi:[1,0,0]       ; cc20004c 8a02670e
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v64, v144, vcc_lo                     ; 02032140
	v_fma_mix_f32 v14, v14, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080e 8a02670e
	v_lshl_add_u32 v20, v20, 5, s16                             ; d6460014 00410b14
	v_lshl_add_u32 v25, v25, 5, s16                             ; d6460019 00410b19
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v65, v145, vcc_lo                     ; 02032341
	v_lshl_add_u32 v36, v36, 5, s16                             ; d6460024 00410b24
	v_lshl_add_u32 v37, v37, 5, s16                             ; d6460025 00410b25
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v66, v169, vcc_lo                     ; 02035342
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v67, v170, vcc_lo                     ; 02035543
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v75, v171, vcc_lo                     ; 0203574b
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v76, v14, vcc_lo                      ; 02021d4c
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[20:21]                ; 1a02295a
(invalid instruction)                                        ; cc0f005b
	v_min_num_f64_e32 v[1:2], v[91:92], v[25:26]                ; 1a02335b
(invalid instruction)                                        ; cc0f006a
	v_min_num_f64_e32 v[1:2], v[106:107], v[36:37]              ; 1a02496a
(invalid instruction)                                        ; cc0f008e
	v_min_num_f64_e32 v[1:2], v[142:143], v[37:38]              ; 1a024b8e
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[91:92]                ; 1a02b75a
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[106:107]              ; 1a02d55a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[142:143]              ; 1a031d5a
	v_permlanex16_b32 v77, v90, s4, s5 op_sel:[1,1]             ; d65c184d 0014095a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[77:78]                ; 1a029b5a
	v_add_f16_e32 v80, v90, v218/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64a1b55a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v80, s3, v80                              ; 62a0a003
	v_cvt_f32_f16_e32 v81, v80                                  ; 7ea21750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v81, v81                                      ; 7ea25551
	v_fma_mix_f32 v90, v148, v81, neg(0) op_sel_hi:[1,0,0]      ; cc20005a 8a02a394
	v_fma_mix_f32 v84, v105, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200054 8a02a369
	v_fma_mix_f32 v148, v148, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200894 8a02a394
	v_fma_mix_f32 v105, v105, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200869 8a02a369
	v_fma_mix_f32 v82, v101, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200052 8a02a365
	v_add_lshl_u32 v1, s9, v1, 2                                ; d6470001 020a0209
	buffer_load_b128 v[56:59], v1, s[32:35], null offen         ; c405c07c 40804038 00000001
	v_fma_mix_f32 v101, v101, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200865 8a02a365
	v_fma_mix_f32 v83, v102, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200053 8a02a366
	v_fma_mix_f32 v102, v102, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200866 8a02a366
	v_fma_mix_f32 v91, v149, v81, neg(0) op_sel_hi:[1,0,0]      ; cc20005b 8a02a395
	buffer_load_b128 v[60:63], v1, s[32:35], null offen offset:16 ; c405c07c 4080403c 00001001
	v_fma_mix_f32 v85, v107, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200055 8a02a36b
	v_fma_mix_f32 v107, v107, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086b 8a02a36b
	v_fma_mix_f32 v149, v149, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a02a395
	v_fma_mix_f32 v100, v150, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200064 8a02a396
	v_fma_mix_f32 v150, v150, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200896 8a02a396
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v90, v148, vcc_lo                     ; 0203295a
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v84, v105, vcc_lo                     ; 0202d354
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v82, v101, vcc_lo                     ; 0202cb52
	v_fma_mix_f32 v101, v151, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200065 8a02a397
	v_fma_mix_f32 v151, v151, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a02a397
	v_fma_mix_f32 v103, v97, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200067 8a02a361
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v83, v102, vcc_lo                     ; 0202cd53
	v_fma_mix_f32 v102, v96, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200066 8a02a360
	v_fma_mix_f32 v96, v96, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200860 8a02a360
	v_fma_mix_f32 v97, v97, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200861 8a02a361
	v_fma_mix_f32 v105, v180, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200069 8a02a3b4
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v85, v107, vcc_lo                     ; 0202d755
	v_fma_mix_f32 v180, v180, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a02a3b4
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v91, v149, vcc_lo                     ; 02032b5b
	v_fma_mix_f32 v106, v181, v81, neg(0) op_sel_hi:[1,0,0]     ; cc20006a 8a02a3b5
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v100, v150, vcc_lo                    ; 02032d64
	v_fma_mix_f32 v181, v181, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a02a3b5
	v_fma_mix_f32 v107, v20, v81, neg(0) op_sel_hi:[1,0,0]      ; cc20006b 8a02a314
	v_fma_mix_f32 v20, v20, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a02a314
	v_fma_mix_f32 v132, v25, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200084 8a02a319
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v101, v151, vcc_lo                    ; 02032f65
	v_fma_mix_f32 v25, v25, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a02a319
	v_fma_mix_f32 v133, v36, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200085 8a02a324
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v3, s6, v3, 2                                ; d6470003 020a0606
	buffer_load_b128 v[64:67], v3, s[20:23], null offen         ; c405c07c 40802840 00000003
	v_fma_mix_f32 v36, v36, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200824 8a02a324
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v102, v96, vcc_lo                     ; 0202c166
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v103, v97, vcc_lo                     ; 0202c367
	v_fma_mix_f32 v136, v37, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200088 8a02a325
	v_fma_mix_f32 v37, v37, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200825 8a02a325
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v105, v180, vcc_lo                    ; 02036969
	v_lshl_add_u32 v38, v38, 5, s16                             ; d6460026 00410b26
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v106, v181, vcc_lo                    ; 02036b6a
	buffer_load_b128 v[80:83], v3, s[20:23], null offen offset:512 ; c405c07c 40802850 00020003
	v_lshl_add_u32 v39, v39, 5, s16                             ; d6460027 00410b27
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v107, v20, vcc_lo                     ; 0202296b
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v132, v25, vcc_lo                     ; 02023384
(invalid instruction)                                        ; cc0f0089
	v_min_num_f64_e32 v[1:2], v[162:163], v[52:53]              ; 1a0269a2
	v_lshl_add_u32 v88, v88, 5, s16                             ; d6460058 00410b58
	v_lshl_add_u32 v44, v44, 5, s16                             ; d646002c 00410b2c
	v_lshl_add_u32 v163, v163, 5, s16                           ; d64600a3 00410ba3
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v133, v36, vcc_lo                     ; 02024985
	v_lshl_add_u32 v53, v53, 5, s16                             ; d6460035 00410b35
	v_lshl_add_u32 v89, v89, 5, s16                             ; d6460059 00410b59
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v136, v37, vcc_lo                     ; 02024b88
	v_lshl_add_u32 v48, v48, 5, s16                             ; d6460030 00410b30
(invalid instruction)                                        ; cc0f008f
	v_min_num_f64_e32 v[1:2], v[143:144], v[38:39]              ; 1a024d8f
(invalid instruction)                                        ; cc0f00a8
	v_min_num_f64_e32 v[1:2], v[168:169], v[39:40]              ; 1a024fa8
(invalid instruction)                                        ; cc0f0089
	v_min_num_f64_e32 v[1:2], v[137:138], v[88:89]              ; 1a02b189
(invalid instruction)                                        ; cc0f008a
	v_min_num_f64_e32 v[1:2], v[163:164], v[53:54]              ; 1a026ba3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
(invalid instruction)                                        ; cc0f008f
	v_min_num_f64_e32 v[1:2], v[143:144], v[168:169]            ; 1a03518f
(invalid instruction)                                        ; cc0f0089
	v_min_num_f64_e32 v[1:2], v[137:138], v[44:45]              ; 1a025989
(invalid instruction)                                        ; cc0f008a
	v_min_num_f64_e32 v[1:2], v[138:139], v[89:90]              ; 1a02b38a
(invalid instruction)                                        ; cc0f008f
	v_min_num_f64_e32 v[1:2], v[143:144], v[137:138]            ; 1a03138f
(invalid instruction)                                        ; cc0f008a
	v_min_num_f64_e32 v[1:2], v[138:139], v[48:49]              ; 1a02618a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f008f
	v_min_num_f64_e32 v[1:2], v[143:144], v[138:139]            ; 1a03158f
	v_permlanex16_b32 v139, v143, s4, s5 op_sel:[1,1]           ; d65c188b 0014098f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f008f
	v_min_num_f64_e32 v[1:2], v[143:144], v[139:140]            ; 1a03178f
(invalid instruction)                                        ; d532108e
	v_cndmask_b32_e32 v1, v143, v143, vcc_lo                    ; 02031f8f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d531008e
	v_cndmask_b32_e32 v1, s3, v142, vcc_lo                      ; 02031c03
(invalid instruction)                                        ; d58b008f
	v_cndmask_b32_e32 v0, v142, v128, vcc_lo                    ; 0201018e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v143, v143                                    ; 7f1e558f
	v_fma_mix_f32 v145, v161, v143, neg(0) op_sel_hi:[1,0,0]    ; cc200091 8a031fa1
	v_fma_mix_f32 v150, v28, v143, neg(0) op_sel_hi:[1,0,0]     ; cc200096 8a031f1c
	v_fma_mix_f32 v161, v161, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a1 8a031fa1
	v_fma_mix_f32 v149, v163, v143, neg(0) op_sel_hi:[1,0,0]    ; cc200095 8a031fa3
	v_fma_mix_f32 v28, v28, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a031f1c
	v_fma_mix_f32 v148, v162, v143, neg(0) op_sel_hi:[1,0,0]    ; cc200094 8a031fa2
	v_fma_mix_f32 v162, v162, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a2 8a031fa2
	v_fma_mix_f32 v144, v160, v143, neg(0) op_sel_hi:[1,0,0]    ; cc200090 8a031fa0
	v_fma_mix_f32 v163, v163, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a3 8a031fa3
	v_fma_mix_f32 v160, v160, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a0 8a031fa0
	v_fma_mix_f32 v151, v29, v143, neg(0) op_sel_hi:[1,0,0]     ; cc200097 8a031f1d
	v_fma_mix_f32 v29, v29, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081d 8a031f1d
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v150, v28, vcc_lo                     ; 02023996
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v148, v162, vcc_lo                    ; 02034594
	v_fma_mix_f32 v162, v86, v143, neg(0) op_sel_hi:[1,0,0]     ; cc2000a2 8a031f56
	v_fma_mix_f32 v86, v86, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200856 8a031f56
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                    ; 02034795
	v_fma_mix_f32 v163, v87, v143, neg(0) op_sel_hi:[1,0,0]     ; cc2000a3 8a031f57
	v_fma_mix_f32 v87, v87, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200857 8a031f57
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v144, v160, vcc_lo                    ; 02034190
	s_load_b64 s[2:3], s[14:15], 0x78                           ; f4002087 f8000078
	v_fma_mix_f32 v160, v52, v143, neg(0) op_sel_hi:[1,0,0]     ; cc2000a0 8a031f34
	v_fma_mix_f32 v52, v52, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200834 8a031f34
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v145, v161, vcc_lo                    ; 02034391
	v_fma_mix_f32 v161, v53, v143, neg(0) op_sel_hi:[1,0,0]     ; cc2000a1 8a031f35
	v_fma_mix_f32 v53, v53, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200835 8a031f35
	v_fma_mix_f32 v168, v88, v143, neg(0) op_sel_hi:[1,0,0]     ; cc2000a8 8a031f58
	v_fma_mix_f32 v88, v88, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200858 8a031f58
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v151, v29, vcc_lo                     ; 02023b97
	v_fma_mix_f32 v169, v89, v143, neg(0) op_sel_hi:[1,0,0]     ; cc2000a9 8a031f59
	v_dual_mov_b32 v14, v183 :: v_dual_mov_b32 v3, v104         ; ca1001b7 0e020168
	v_fma_mix_f32 v89, v89, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200859 8a031f59
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v162, v86, vcc_lo                     ; 0202ada2
	v_fma_mix_f32 v170, v38, v143, neg(0) op_sel_hi:[1,0,0]     ; cc2000aa 8a031f26
	v_fma_mix_f32 v38, v38, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200826 8a031f26
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v163, v87, vcc_lo                     ; 0202afa3
	v_fma_mix_f32 v171, v39, v143, neg(0) op_sel_hi:[1,0,0]     ; cc2000ab 8a031f27
	v_fma_mix_f32 v39, v39, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200827 8a031f27
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v160, v52, vcc_lo                     ; 020269a0
	v_fma_mix_f32 v172, v44, v143, neg(0) op_sel_hi:[1,0,0]     ; cc2000ac 8a031f2c
	v_fma_mix_f32 v44, v44, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082c 8a031f2c
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v161, v53, vcc_lo                     ; 02026ba1
	v_fma_mix_f32 v173, v48, v143, neg(0) op_sel_hi:[1,0,0]     ; cc2000ad 8a031f30
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v168, v88, vcc_lo                     ; 0202b1a8
	v_fma_mix_f32 v48, v48, v143, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200830 8a031f30
	v_wmma_f32_16x16x16_fp8_fp8 v[100:107], v[30:31], v[32:33], 0 ; cc464064 1a02411e
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v169, v89, vcc_lo                     ; 0202b3a9
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[30:31], v[6:7], 0   ; cc464054 1a020d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[36:37], 0 ; cc4640b0 1a02491e
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v170, v38, vcc_lo                     ; 02024daa
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v171, v39, vcc_lo                     ; 02024fab
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v172, v44, vcc_lo                     ; 020259ac
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v173, v48, vcc_lo                     ; 020261ad
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[30:31], v[46:47], 0 ; cc4640a8 1a025d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[100:107], v[16:17], v[34:35], v[100:107] ; cc464064 1d924510
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[16:17], v[8:9], v[84:91] ; cc464054 1d521110
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[54:55], v[176:183] ; cc4640b0 1ec26d10
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[16:17], v[140:141], v[168:175] ; cc4640a8 1ea31910
	v_wmma_f32_16x16x16_fp8_fp8 v[100:107], v[68:69], v[50:51], v[100:107] ; cc464064 1d926544
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[68:69], v[10:11], v[84:91] ; cc464054 1d521544
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[68:69], v[28:29], v[176:183] ; cc4640b0 1ec23944
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[134:135], v[168:175] ; cc4640a8 1ea30d44
	v_wmma_f32_16x16x16_fp8_fp8 v[100:107], v[26:27], v[20:21], v[100:107] ; cc464064 1d92291a
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[26:27], v[12:13], v[84:91] ; cc464054 1d52191a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[26:27], v[52:53], v[176:183] ; cc4640b0 1ec2691a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[26:27], v[4:5], v[168:175] ; cc4640a8 1ea2091a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[40:41], v[32:33], 0 ; cc464054 1a024128
	v_wmma_f32_16x16x16_fp8_fp8 v[100:107], v[40:41], v[36:37], 0 ; cc464064 1a024928
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[40:41], v[6:7], 0 ; cc4640b0 1a020d28
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[46:47], 0 ; cc4640a8 1a025d28
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[22:23], v[34:35], v[84:91] ; cc464054 1d524516
	v_wmma_f32_16x16x16_fp8_fp8 v[100:107], v[22:23], v[54:55], v[100:107] ; cc464064 1d926d16
	s_bitset0_b32 s29, 14                                       ; be9d108e
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bfe_u32 s17, s2, 0x1b0001                                 ; 9311ff02 001b0001
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s17, s17, 2                                      ; 84118211
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[22:23], v[8:9], v[176:183] ; cc4640b0 1ec21116
	s_clause 0x2                                                ; bf850002
	s_buffer_load_b512 s[48:63], s[28:31], s17 offset:0x0       ; f4028c0e 22000000
	s_buffer_load_b512 s[64:79], s[28:31], s17 offset:0x40      ; f402900e 22000040
	s_buffer_load_b512 s[80:95], s[28:31], s17 offset:0x80      ; f402940e 22000080
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[140:141], v[168:175] ; cc4640a8 1ea31916
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[72:73], v[50:51], v[84:91] ; cc464054 1d526548
	v_wmma_f32_16x16x16_fp8_fp8 v[100:107], v[72:73], v[28:29], v[100:107] ; cc464064 1d923948
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[72:73], v[10:11], v[176:183] ; cc4640b0 1ec21548
	s_mov_b64 s[6:7], s[18:19]                                  ; be860112
	s_buffer_load_b512 s[16:31], s[28:31], s17 offset:0xc0      ; f402840e 220000c0
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[134:135], v[168:175] ; cc4640a8 1ea30d48
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[42:43], v[20:21], v[84:91] ; cc464054 1d52292a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_mul_f32_e32 v41, v153, v57                                ; 10527399
	v_wmma_f32_16x16x16_fp8_fp8 v[100:107], v[42:43], v[52:53], v[100:107] ; cc464064 1d92692a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v47, v159, v63 :: v_dual_mul_f32 v46, v158, v62 ; c8c67f9f 2f2e7d9e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[12:13], v[176:183] ; cc4640b0 1ec2192a
	v_dual_mul_f32 v49, v94, v57 :: v_dual_mul_f32 v44, v156, v60 ; c8c6735e 312c799c
	v_dual_mul_f32 v51, v3, v59 :: v_dual_mul_f32 v48, v93, v56 ; c8c67703 3330715d
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[42:43], v[4:5], v[168:175] ; cc4640a8 1ea2092a
	v_dual_mul_f32 v43, v155, v59 :: v_dual_mul_f32 v40, v152, v56 ; c8c6779b 2b287198
	v_dual_mul_f32 v45, v157, v61 :: v_dual_mul_f32 v42, v154, v58 ; c8c67b9d 2d2a759a
	v_dual_mul_f32 v53, v61, v99 :: v_dual_mul_f32 v50, v95, v58 ; c8c6c73d 3532755f
	v_dual_mul_f32 v55, v147, v63 :: v_dual_mul_f32 v52, v98, v60 ; c8c67f93 37347962
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_dual_mul_f32 v97, v185, v57 :: v_dual_mul_f32 v54, v146, v62 ; c8c673b9 61367d92
	v_dual_mul_f32 v99, v187, v59 :: v_dual_mul_f32 v96, v184, v56 ; c8c677bb 636071b8
	v_dual_mul_f32 v101, v189, v61 :: v_dual_mul_f32 v98, v186, v58 ; c8c67bbd 656275ba
	v_dual_mul_f32 v103, v191, v63 :: v_dual_mul_f32 v100, v188, v60 ; c8c67fbf 676479bc
	v_dual_mul_f32 v137, v125, v57 :: v_dual_mul_f32 v102, v190, v62 ; c8c6737d 89667dbe
	v_dual_mul_f32 v139, v127, v59 :: v_dual_mul_f32 v136, v124, v56 ; c8c6777f 8b88717c
	v_dual_mul_f32 v141, v129, v61 :: v_dual_mul_f32 v138, v126, v58 ; c8c67b81 8d8a757e
	v_dual_mul_f32 v143, v131, v63 :: v_dual_mul_f32 v140, v128, v60 ; c8c67f83 8f8c7980
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[64:65], v[16:17], v[40:47] ; cc464028 1ca22140
	s_bfm_b32 vcc_lo, 16, 0                                     ; 956a8090
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[64:65], v[26:27], v[48:55] ; cc464030 1cc23540
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[64:65], v[30:31], v[96:103] ; cc464060 1d823d40
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[80:81], v[4:5], v[40:47] ; cc464028 1ca20950
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[80:81], v[6:7], v[48:55] ; cc464030 1cc20d50
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[80:81], v[8:9], v[96:103] ; cc464060 1d821150
	v_cvt_f16_f32_e32 v20, v40                                  ; 7e281528
(invalid instruction)                                        ; 7f281529
	v_cvt_f16_f32_e32 v21, v42                                  ; 7e2a152a
(invalid instruction)                                        ; 7f2a152b
	v_cvt_f16_f32_e32 v22, v44                                  ; 7e2c152c
(invalid instruction)                                        ; 7f2c152d
	buffer_load_b128 v[40:43], v1, s[32:35], null offen offset:64 ; c405c07c 40804028 00004001
	v_cvt_f16_f32_e32 v23, v46                                  ; 7e2e152e
(invalid instruction)                                        ; 7f2e152f
	buffer_load_b128 v[44:47], v1, s[32:35], null offen offset:80 ; c405c07c 4080402c 00005001
	v_cvt_f16_f32_e32 v25, v48                                  ; 7e321530
	v_cvt_f16_f32_e32 v32, v54                                  ; 7e401536
	v_cvt_f16_f32_e32 v28, v50                                  ; 7e381532
	v_cvt_f16_f32_e32 v29, v52                                  ; 7e3a1534
(invalid instruction)                                        ; 7f3a1535
(invalid instruction)                                        ; 7f401537
(invalid instruction)                                        ; 7f321531
(invalid instruction)                                        ; 7f381533
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_cndmask_b32 v50, v23, v32 :: v_dual_cndmask_b32 v49, v22, v29 ; ca524117 32303b16
	v_dual_cndmask_b32 v33, v20, v25 :: v_dual_mul_f32 v142, v130, v62 ; ca463314 218e7d82
	v_cndmask_b32_e32 v48, v21, v28, vcc_lo                     ; 02603915
	v_permlanex16_b32 v49, v49, s4, s5 op_sel:[1,1]             ; d65c1831 00140931
	v_permlanex16_b32 v50, v50, s4, s5 op_sel:[1,1]             ; d65c1832 00140932
	v_permlanex16_b32 v33, v33, s4, s5 op_sel:[1,1]             ; d65c1821 00140921
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[64:65], v[38:39], v[136:143] ; cc464088 1e224d40
	v_permlanex16_b32 v48, v48, s4, s5 op_sel:[1,1]             ; d65c1830 00140930
	v_dual_cndmask_b32 v32, v32, v50 :: v_dual_cndmask_b32 v29, v29, v49 ; ca526520 201c631d
	v_dual_cndmask_b32 v50, v50, v23 :: v_dual_cndmask_b32 v49, v49, v22 ; ca522f32 32302d31
	v_cndmask_b32_e32 v25, v25, v33, vcc_lo                     ; 02324319
	v_cndmask_b32_e32 v33, v33, v20, vcc_lo                     ; 02422921
	v_cndmask_b32_e32 v28, v28, v48, vcc_lo                     ; 0238611c
	v_cndmask_b32_e32 v48, v48, v21, vcc_lo                     ; 02602b30
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mix_f32 v35, s64, v33, neg(0) op_sel_hi:[1,1,0]       ; cc200023 9a024240
	v_fma_mix_f32 v36, s80, v33, neg(0) op_sel_hi:[1,1,0]       ; cc200024 9a024250
	v_fma_mix_f32 v34, s48, v33, neg(0) op_sel_hi:[1,1,0]       ; cc200022 9a024230
	v_cvt_f16_f32_e32 v51, v96                                  ; 7e661560
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[80:81], v[10:11], v[136:143] ; cc464088 1e221550
(invalid instruction)                                        ; 7f661561
	v_cvt_f16_f32_e32 v52, v98                                  ; 7e681562
	v_fma_mix_f32 v35, s64, v33, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8e4240
	v_fma_mix_f32 v36, s80, v33, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c924250
	v_fma_mix_f32 v34, s48, v33, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8a4230
(invalid instruction)                                        ; 7f681563
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v35, s65, v48, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8e6041
	v_fma_mix_f32 v36, s81, v48, v36 op_sel_hi:[1,1,0]          ; cc200024 1c926051
	v_fma_mix_f32 v34, s49, v48, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8a6031
	v_cvt_f16_f32_e32 v56, v138                                 ; 7e70158a
(invalid instruction)                                        ; 7f70158b
	v_cvt_f16_f32_e32 v55, v136                                 ; 7e6e1588
(invalid instruction)                                        ; 7f6e1589
	v_fma_mix_f32 v35, s65, v48, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8e6041
	v_fma_mix_f32 v36, s81, v48, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c926051
	v_fma_mix_f32 v34, s49, v48, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8a6031
	v_fma_mix_f32 v37, s16, v33, neg(0) op_sel_hi:[1,1,0]       ; cc200025 9a024210
	v_dual_cndmask_b32 v64, v52, v56 :: v_dual_cndmask_b32 v59, v51, v55 ; ca527134 403a6f33
	v_fma_mix_f32 v35, s66, v49, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8e6242
	v_fma_mix_f32 v36, s82, v49, v36 op_sel_hi:[1,1,0]          ; cc200024 1c926252
	v_fma_mix_f32 v34, s50, v49, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8a6232
	v_fma_mix_f32 v33, s16, v33, v37 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201821 1c964210
	v_permlanex16_b32 v64, v64, s4, s5 op_sel:[1,1]             ; d65c1840 00140940
	v_permlanex16_b32 v59, v59, s4, s5 op_sel:[1,1]             ; d65c183b 0014093b
	v_fma_mix_f32 v35, s66, v49, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8e6242
	v_fma_mix_f32 v36, s82, v49, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c926252
	v_fma_mix_f32 v34, s50, v49, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8a6232
	v_fma_mix_f32 v33, s17, v48, v33 op_sel_hi:[1,1,0]          ; cc200021 1c866011
	v_dual_cndmask_b32 v56, v56, v64 :: v_dual_cndmask_b32 v55, v55, v59 ; ca528138 38367737
	v_fma_mix_f32 v35, s67, v50, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8e6443
	v_fma_mix_f32 v36, s83, v50, v36 op_sel_hi:[1,1,0]          ; cc200024 1c926453
	v_fma_mix_f32 v34, s51, v50, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8a6433
	v_fma_mix_f32 v48, s17, v48, v33 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201830 1c866011
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v35, s67, v50, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8e6443
	v_fma_mix_f32 v36, s83, v50, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c926453
	v_fma_mix_f32 v34, s51, v50, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8a6433
	v_fma_mix_f32 v48, s18, v49, v48 op_sel_hi:[1,1,0]          ; cc200030 1cc26212
	v_fma_mix_f32 v35, s68, v25, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8e3244
	v_fma_mix_f32 v36, s84, v25, v36 op_sel_hi:[1,1,0]          ; cc200024 1c923254
	v_fma_mix_f32 v34, s52, v25, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8a3234
	v_fma_mix_f32 v49, s18, v49, v48 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201831 1cc26212
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v35, s68, v25, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8e3244
	v_fma_mix_f32 v36, s84, v25, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c923254
	v_fma_mix_f32 v34, s52, v25, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8a3234
	v_fma_mix_f32 v49, s19, v50, v49 op_sel_hi:[1,1,0]          ; cc200031 1cc66413
	v_fma_mix_f32 v35, s69, v28, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8e3845
	v_fma_mix_f32 v36, s85, v28, v36 op_sel_hi:[1,1,0]          ; cc200024 1c923855
	v_fma_mix_f32 v34, s53, v28, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8a3835
	v_fma_mix_f32 v50, s19, v50, v49 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201832 1cc66413
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v35, s69, v28, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8e3845
	v_fma_mix_f32 v36, s85, v28, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c923855
	v_fma_mix_f32 v34, s53, v28, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8a3835
	v_fma_mix_f32 v50, s20, v25, v50 op_sel_hi:[1,1,0]          ; cc200032 1cca3214
	v_fma_mix_f32 v35, s70, v29, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8e3a46
	v_fma_mix_f32 v36, s86, v29, v36 op_sel_hi:[1,1,0]          ; cc200024 1c923a56
	v_fma_mix_f32 v34, s54, v29, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8a3a36
	v_fma_mix_f32 v25, s20, v25, v50 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201819 1cca3214
	v_dual_cndmask_b32 v64, v64, v52 :: v_dual_cndmask_b32 v59, v59, v51 ; ca526940 403a673b
	v_cvt_f16_f32_e32 v53, v100                                 ; 7e6a1564
(invalid instruction)                                        ; 7f6a1565
	v_fma_mix_f32 v35, s70, v29, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8e3a46
	v_cvt_f16_f32_e32 v54, v102                                 ; 7e6c1566
	v_fma_mix_f32 v36, s86, v29, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c923a56
	v_fma_mix_f32 v34, s54, v29, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8a3a36
(invalid instruction)                                        ; 7f6c1567
	v_cvt_f16_f32_e32 v57, v140                                 ; 7e72158c
	v_fma_mix_f32 v25, s21, v28, v25 op_sel_hi:[1,1,0]          ; cc200019 1c663815
(invalid instruction)                                        ; 7f72158d
	v_cvt_f16_f32_e32 v58, v142                                 ; 7e74158e
(invalid instruction)                                        ; 7f74158f
	v_fma_mix_f32 v35, s71, v32, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8e4047
	v_fma_mix_f32 v36, s87, v32, v36 op_sel_hi:[1,1,0]          ; cc200024 1c924057
	v_fma_mix_f32 v34, s55, v32, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8a4037
	v_fma_mix_f32 v60, s48, v59, neg(0) op_sel_hi:[1,1,0]       ; cc20003c 9a027630
	v_fma_mix_f32 v28, s21, v28, v25 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20181c 1c663815
	v_fma_mix_f32 v61, s64, v59, neg(0) op_sel_hi:[1,1,0]       ; cc20003d 9a027640
	v_dual_cndmask_b32 v68, v54, v58 :: v_dual_cndmask_b32 v65, v53, v57 ; ca527536 44407335
	v_fma_mix_f32 v35, s71, v32, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8e4047
	v_fma_mix_f32 v62, s80, v59, neg(0) op_sel_hi:[1,1,0]       ; cc20003e 9a027650
	v_fma_mix_f32 v36, s87, v32, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c924057
	v_fma_mix_f32 v63, s16, v59, neg(0) op_sel_hi:[1,1,0]       ; cc20003f 9a027610
	v_fma_mix_f32 v34, s55, v32, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8a4037
	v_fma_mix_f32 v60, s48, v59, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf27630
	v_fma_mix_f32 v28, s22, v29, v28 op_sel_hi:[1,1,0]          ; cc20001c 1c723a16
	v_fma_mix_f32 v61, s64, v59, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf67640
	v_permlanex16_b32 v68, v68, s4, s5 op_sel:[1,1]             ; d65c1844 00140944
	v_permlanex16_b32 v65, v65, s4, s5 op_sel:[1,1]             ; d65c1841 00140941
	v_fma_mix_f32 v62, s80, v59, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfa7650
	v_fma_mix_f32 v59, s16, v59, v63 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183b 1cfe7610
	v_fma_mix_f32 v60, s49, v64, v60 op_sel_hi:[1,1,0]          ; cc20003c 1cf28031
	v_fma_mix_f32 v29, s22, v29, v28 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20181d 1c723a16
	v_fma_mix_f32 v61, s65, v64, v61 op_sel_hi:[1,1,0]          ; cc20003d 1cf68041
	v_dual_cndmask_b32 v58, v58, v68 :: v_dual_cndmask_b32 v57, v57, v65 ; ca52893a 3a388339
	v_dual_cndmask_b32 v68, v68, v54 :: v_dual_cndmask_b32 v65, v65, v53 ; ca526d44 44406b41
	v_fma_mix_f32 v62, s81, v64, v62 op_sel_hi:[1,1,0]          ; cc20003e 1cfa8051
	v_fma_mix_f32 v59, s17, v64, v59 op_sel_hi:[1,1,0]          ; cc20003b 1cee8011
	v_fma_mix_f32 v60, s49, v64, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf28031
	v_fma_mix_f32 v29, s23, v32, v29 op_sel_hi:[1,1,0]          ; cc20001d 1c764017
	v_fma_mix_f32 v61, s65, v64, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf68041
	v_fma_mix_f32 v62, s81, v64, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfa8051
	v_fma_mix_f32 v64, s17, v64, v59 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201840 1cee8011
	v_fma_mix_f32 v60, s50, v65, v60 op_sel_hi:[1,1,0]          ; cc20003c 1cf28232
	v_fma_mix_f32 v32, s23, v32, v29 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201820 1c764017
	v_fma_mix_f32 v61, s66, v65, v61 op_sel_hi:[1,1,0]          ; cc20003d 1cf68242
	v_fma_mix_f32 v62, s82, v65, v62 op_sel_hi:[1,1,0]          ; cc20003e 1cfa8252
	v_fma_mix_f32 v64, s18, v65, v64 op_sel_hi:[1,1,0]          ; cc200040 1d028212
	v_fma_mix_f32 v60, s50, v65, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf28232
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v61, s66, v65, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf68242
	v_fma_mix_f32 v62, s82, v65, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfa8252
	v_fma_mix_f32 v65, s18, v65, v64 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201841 1d028212
	v_fma_mix_f32 v60, s51, v68, v60 op_sel_hi:[1,1,0]          ; cc20003c 1cf28833
	v_fma_mix_f32 v61, s67, v68, v61 op_sel_hi:[1,1,0]          ; cc20003d 1cf68843
	v_fma_mix_f32 v62, s83, v68, v62 op_sel_hi:[1,1,0]          ; cc20003e 1cfa8853
	v_fma_mix_f32 v65, s19, v68, v65 op_sel_hi:[1,1,0]          ; cc200041 1d068813
	v_fma_mix_f32 v60, s51, v68, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf28833
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v61, s67, v68, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf68843
	v_fma_mix_f32 v62, s83, v68, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfa8853
	v_fma_mix_f32 v68, s19, v68, v65 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201844 1d068813
	v_fma_mix_f32 v60, s52, v55, v60 op_sel_hi:[1,1,0]          ; cc20003c 1cf26e34
	v_fma_mix_f32 v61, s68, v55, v61 op_sel_hi:[1,1,0]          ; cc20003d 1cf66e44
	v_fma_mix_f32 v62, s84, v55, v62 op_sel_hi:[1,1,0]          ; cc20003e 1cfa6e54
	v_fma_mix_f32 v68, s20, v55, v68 op_sel_hi:[1,1,0]          ; cc200044 1d126e14
	v_fma_mix_f32 v60, s52, v55, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf26e34
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v61, s68, v55, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf66e44
	v_fma_mix_f32 v62, s84, v55, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfa6e54
	v_fma_mix_f32 v55, s20, v55, v68 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201837 1d126e14
	v_fma_mix_f32 v60, s53, v56, v60 op_sel_hi:[1,1,0]          ; cc20003c 1cf27035
	v_fma_mix_f32 v61, s69, v56, v61 op_sel_hi:[1,1,0]          ; cc20003d 1cf67045
	v_fma_mix_f32 v62, s85, v56, v62 op_sel_hi:[1,1,0]          ; cc20003e 1cfa7055
	v_fma_mix_f32 v55, s21, v56, v55 op_sel_hi:[1,1,0]          ; cc200037 1cde7015
	v_fma_mix_f32 v60, s53, v56, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf27035
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v61, s69, v56, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf67045
	v_fma_mix_f32 v62, s85, v56, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfa7055
	v_fma_mix_f32 v56, s21, v56, v55 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201838 1cde7015
	v_fma_mix_f32 v60, s54, v57, v60 op_sel_hi:[1,1,0]          ; cc20003c 1cf27236
	v_fma_mix_f32 v61, s70, v57, v61 op_sel_hi:[1,1,0]          ; cc20003d 1cf67246
	v_fma_mix_f32 v62, s86, v57, v62 op_sel_hi:[1,1,0]          ; cc20003e 1cfa7256
	v_fma_mix_f32 v56, s22, v57, v56 op_sel_hi:[1,1,0]          ; cc200038 1ce27216
	v_fma_mix_f32 v60, s54, v57, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf27236
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v61, s70, v57, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf67246
	v_fma_mix_f32 v62, s86, v57, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfa7256
	v_fma_mix_f32 v57, s22, v57, v56 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201839 1ce27216
	v_fma_mix_f32 v60, s55, v58, v60 op_sel_hi:[1,1,0]          ; cc20003c 1cf27437
	v_fma_mix_f32 v61, s71, v58, v61 op_sel_hi:[1,1,0]          ; cc20003d 1cf67447
	v_fma_mix_f32 v62, s87, v58, v62 op_sel_hi:[1,1,0]          ; cc20003e 1cfa7457
	v_fma_mix_f32 v57, s23, v58, v57 op_sel_hi:[1,1,0]          ; cc200039 1ce67417
	v_fma_mix_f32 v60, s55, v58, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf27437
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v61, s71, v58, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf67447
	v_fma_mix_f32 v62, s87, v58, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfa7457
	v_fma_mix_f32 v58, s23, v58, v57 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183a 1ce67417
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_dual_mul_f32 v97, v79, v41 :: v_dual_mul_f32 v96, v78, v40 ; c8c6534f 6160514e
	v_dual_mul_f32 v99, v24, v43 :: v_dual_mul_f32 v98, v19, v42 ; c8c65718 63625513
	v_dual_mul_f32 v73, v117, v41 :: v_dual_mul_f32 v72, v116, v40 ; c8c65375 49485174
	v_dual_mul_f32 v91, v14, v43 :: v_dual_mul_f32 v90, v71, v42 ; c8c6570e 5b5a5547
	v_dual_mul_f32 v89, v41, v70 :: v_dual_mul_f32 v88, v2, v40 ; c8c68d29 59585102
	v_dual_mul_f32 v50, v110, v42 :: v_dual_mul_f32 v51, v111, v43 ; c8c6556e 3232576f
	v_dual_mul_f32 v48, v108, v40 :: v_dual_mul_f32 v49, v109, v41 ; c8c6516c 3030536d
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mul_f32 v101, v165, v45 :: v_dual_mul_f32 v100, v164, v44 ; c8c65ba5 656459a4
	v_dual_mul_f32 v52, v112, v44 :: v_dual_mul_f32 v53, v113, v45 ; c8c65970 34345b71
	v_dual_mul_f32 v103, v92, v47 :: v_dual_mul_f32 v102, v166, v46 ; c8c65f5c 67665da6
	v_dual_mul_f32 v93, v18, v45 :: v_dual_mul_f32 v92, v15, v44 ; c8c65b12 5d5c590f
	v_dual_mul_f32 v95, v74, v47 :: v_dual_mul_f32 v94, v167, v46 ; c8c65f4a 5f5e5da7
	v_dual_mul_f32 v75, v119, v43 :: v_dual_mul_f32 v74, v118, v42 ; c8c65777 4b4a5576
	v_dual_mul_f32 v55, v115, v47 :: v_dual_mul_f32 v54, v114, v46 ; c8c65f73 37365d72
	v_dual_mul_f32 v79, v123, v47 :: v_dual_mul_f32 v78, v122, v46 ; c8c65f7b 4f4e5d7a
	v_dual_mul_f32 v77, v121, v45 :: v_dual_mul_f32 v76, v120, v44 ; c8c65b79 4d4c5978
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[26:27], v[96:103] ; cc464060 1d823542
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[66:67], v[38:39], v[72:79] ; cc464048 1d224d42
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[66:67], v[30:31], v[88:95] ; cc464058 1d623d42
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[66:67], v[16:17], v[48:55] ; cc464030 1cc22142
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[82:83], v[6:7], v[96:103] ; cc464060 1d820d52
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[82:83], v[10:11], v[72:79] ; cc464048 1d221552
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[82:83], v[8:9], v[88:95] ; cc464058 1d621152
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[82:83], v[4:5], v[48:55] ; cc464030 1cc20952
	v_cvt_f16_f32_e32 v81, v96                                  ; 7ea21560
(invalid instruction)                                        ; 7fa21561
	v_cvt_f16_f32_e32 v82, v98                                  ; 7ea41562
(invalid instruction)                                        ; 7fa41563
	v_cvt_f16_f32_e32 v83, v100                                 ; 7ea61564
(invalid instruction)                                        ; 7fa61565
	v_cvt_f16_f32_e32 v84, v102                                 ; 7ea81566
(invalid instruction)                                        ; 7fa81567
	v_cvt_f16_f32_e32 v71, v52                                  ; 7e8e1534
	v_cvt_f16_f32_e32 v69, v48                                  ; 7e8a1530
(invalid instruction)                                        ; 7f8a1531
	v_cvt_f16_f32_e32 v70, v50                                  ; 7e8c1532
(invalid instruction)                                        ; 7f8c1533
	v_cvt_f16_f32_e32 v80, v54                                  ; 7ea01536
(invalid instruction)                                        ; 7fa01537
(invalid instruction)                                        ; 7f8e1535
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_dual_cndmask_b32 v86, v70, v82 :: v_dual_cndmask_b32 v85, v69, v81 ; ca52a546 5654a345
	v_dual_cndmask_b32 v96, v80, v84 :: v_dual_cndmask_b32 v87, v71, v83 ; ca52a950 6056a747
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_permlanex16_b32 v86, v86, s4, s5 op_sel:[1,1]             ; d65c1856 00140956
	v_permlanex16_b32 v85, v85, s4, s5 op_sel:[1,1]             ; d65c1855 00140955
	v_permlanex16_b32 v96, v96, s4, s5 op_sel:[1,1]             ; d65c1860 00140960
	v_permlanex16_b32 v87, v87, s4, s5 op_sel:[1,1]             ; d65c1857 00140957
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_dual_cndmask_b32 v82, v82, v86 :: v_dual_cndmask_b32 v81, v81, v85 ; ca52ad52 5250ab51
	v_dual_cndmask_b32 v86, v86, v70 :: v_dual_cndmask_b32 v85, v85, v69 ; ca528d56 56548b55
	v_dual_cndmask_b32 v84, v84, v96 :: v_dual_cndmask_b32 v83, v83, v87 ; ca52c154 5452af53
	v_dual_cndmask_b32 v96, v96, v80 :: v_dual_cndmask_b32 v87, v87, v71 ; ca52a160 60568f57
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_fma_mix_f32 v34, s56, v85, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8aaa38
	v_fma_mix_f32 v36, s88, v85, v36 op_sel_hi:[1,1,0]          ; cc200024 1c92aa58
	v_fma_mix_f32 v32, s24, v85, v32 op_sel_hi:[1,1,0]          ; cc200020 1c82aa18
	v_fma_mix_f32 v35, s72, v85, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8eaa48
	v_fma_mix_f32 v34, s56, v85, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8aaa38
	v_fma_mix_f32 v36, s88, v85, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c92aa58
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_fma_mix_f32 v35, s72, v85, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8eaa48
	v_fma_mix_f32 v85, s24, v85, v32 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201855 1c82aa18
	v_fma_mix_f32 v34, s57, v86, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8aac39
	v_fma_mix_f32 v36, s89, v86, v36 op_sel_hi:[1,1,0]          ; cc200024 1c92ac59
	v_fma_mix_f32 v35, s73, v86, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8eac49
	v_fma_mix_f32 v85, s25, v86, v85 op_sel_hi:[1,1,0]          ; cc200055 1d56ac19
	v_fma_mix_f32 v34, s57, v86, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8aac39
	v_fma_mix_f32 v36, s89, v86, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c92ac59
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v35, s73, v86, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8eac49
	v_fma_mix_f32 v86, s25, v86, v85 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201856 1d56ac19
	v_fma_mix_f32 v34, s58, v87, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8aae3a
	v_fma_mix_f32 v36, s90, v87, v36 op_sel_hi:[1,1,0]          ; cc200024 1c92ae5a
	v_fma_mix_f32 v35, s74, v87, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8eae4a
	v_fma_mix_f32 v86, s26, v87, v86 op_sel_hi:[1,1,0]          ; cc200056 1d5aae1a
	v_fma_mix_f32 v34, s58, v87, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8aae3a
	v_fma_mix_f32 v36, s90, v87, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c92ae5a
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v35, s74, v87, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8eae4a
	v_fma_mix_f32 v87, s26, v87, v86 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201857 1d5aae1a
	v_fma_mix_f32 v34, s59, v96, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8ac03b
	v_fma_mix_f32 v36, s91, v96, v36 op_sel_hi:[1,1,0]          ; cc200024 1c92c05b
	v_fma_mix_f32 v35, s75, v96, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8ec04b
	v_fma_mix_f32 v87, s27, v96, v87 op_sel_hi:[1,1,0]          ; cc200057 1d5ec01b
	v_fma_mix_f32 v34, s59, v96, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8ac03b
	v_fma_mix_f32 v36, s91, v96, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c92c05b
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v35, s75, v96, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8ec04b
	v_fma_mix_f32 v96, s27, v96, v87 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201860 1d5ec01b
	v_fma_mix_f32 v34, s60, v81, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8aa23c
	v_fma_mix_f32 v36, s92, v81, v36 op_sel_hi:[1,1,0]          ; cc200024 1c92a25c
	v_fma_mix_f32 v35, s76, v81, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8ea24c
	v_fma_mix_f32 v96, s28, v81, v96 op_sel_hi:[1,1,0]          ; cc200060 1d82a21c
	v_fma_mix_f32 v34, s60, v81, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8aa23c
	v_fma_mix_f32 v36, s92, v81, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c92a25c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v35, s76, v81, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8ea24c
	v_fma_mix_f32 v81, s28, v81, v96 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201851 1d82a21c
	v_fma_mix_f32 v34, s61, v82, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8aa43d
	v_fma_mix_f32 v36, s93, v82, v36 op_sel_hi:[1,1,0]          ; cc200024 1c92a45d
	v_fma_mix_f32 v35, s77, v82, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8ea44d
	v_fma_mix_f32 v81, s29, v82, v81 op_sel_hi:[1,1,0]          ; cc200051 1d46a41d
	v_fma_mix_f32 v34, s61, v82, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8aa43d
	v_fma_mix_f32 v36, s93, v82, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c92a45d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v35, s77, v82, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8ea44d
	v_fma_mix_f32 v82, s29, v82, v81 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201852 1d46a41d
	v_fma_mix_f32 v34, s62, v83, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8aa63e
	v_cvt_f16_f32_e32 v97, v88                                  ; 7ec21558
	v_fma_mix_f32 v36, s94, v83, v36 op_sel_hi:[1,1,0]          ; cc200024 1c92a65e
(invalid instruction)                                        ; 7fc21559
	v_fma_mix_f32 v35, s78, v83, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8ea64e
	v_cvt_f16_f32_e32 v98, v90                                  ; 7ec4155a
(invalid instruction)                                        ; 7fc4155b
	v_fma_mix_f32 v82, s30, v83, v82 op_sel_hi:[1,1,0]          ; cc200052 1d4aa61e
	v_cvt_f16_f32_e32 v99, v92                                  ; 7ec6155c
	v_fma_mix_f32 v34, s62, v83, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8aa63e
(invalid instruction)                                        ; 7fc6155d
	v_cvt_f16_f32_e32 v100, v94                                 ; 7ec8155e
(invalid instruction)                                        ; 7fc8155f
	v_fma_mix_f32 v36, s94, v83, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c92a65e
	v_cvt_f16_f32_e32 v101, v72                                 ; 7eca1548
(invalid instruction)                                        ; 7fca1549
	s_load_b256 s[16:23], s[0:1], 0x60                          ; f4006400 f8000060
	v_fma_mix_f32 v35, s78, v83, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8ea64e
	v_cvt_f16_f32_e32 v102, v74                                 ; 7ecc154a
(invalid instruction)                                        ; 7fcc154b
	v_cvt_f16_f32_e32 v103, v76                                 ; 7ece154c
	v_fma_mix_f32 v83, s30, v83, v82 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201853 1d4aa61e
(invalid instruction)                                        ; 7fce154d
	v_fma_mix_f32 v34, s63, v84, v34 op_sel_hi:[1,1,0]          ; cc200022 1c8aa83f
	v_fma_mix_f32 v36, s95, v84, v36 op_sel_hi:[1,1,0]          ; cc200024 1c92a85f
	v_cvt_f16_f32_e32 v104, v78                                 ; 7ed0154e
(invalid instruction)                                        ; 7fd0154f
	v_fma_mix_f32 v35, s79, v84, v35 op_sel_hi:[1,1,0]          ; cc200023 1c8ea84f
	v_dual_cndmask_b32 v106, v98, v102 :: v_dual_cndmask_b32 v105, v97, v101 ; ca52cd62 6a68cb61
	v_fma_mix_f32 v83, s31, v84, v83 op_sel_hi:[1,1,0]          ; cc200053 1d4ea81f
	v_fma_mix_f32 v34, s63, v84, v34 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201822 1c8aa83f
	v_fma_mix_f32 v36, s95, v84, v36 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201824 1c92a85f
	v_dual_cndmask_b32 v108, v100, v104 :: v_dual_cndmask_b32 v107, v99, v103 ; ca52d164 6c6acf63
	v_fma_mix_f32 v35, s79, v84, v35 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201823 1c8ea84f
	v_permlanex16_b32 v105, v105, s4, s5 op_sel:[1,1]           ; d65c1869 00140969
	v_permlanex16_b32 v106, v106, s4, s5 op_sel:[1,1]           ; d65c186a 0014096a
	v_fma_mix_f32 v84, s31, v84, v83 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201854 1d4ea81f
	v_bfe_u32 v109, v0, 4, 1                                    ; d610006d 02050900
	v_permlanex16_b32 v107, v107, s4, s5 op_sel:[1,1]           ; d65c186b 0014096b
	v_permlanex16_b32 v108, v108, s4, s5 op_sel:[1,1]           ; d65c186c 0014096c
	v_dual_cndmask_b32 v102, v102, v106 :: v_dual_cndmask_b32 v101, v101, v105 ; ca52d566 6664d365
	v_dual_cndmask_b32 v106, v106, v98 :: v_dual_cndmask_b32 v105, v105, v97 ; ca52c56a 6a68c369
	v_add_lshl_u32 v109, s6, v109, 2                            ; d647006d 020ada06
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_cndmask_b32 v104, v104, v108 :: v_dual_cndmask_b32 v103, v103, v107 ; ca52d968 6866d767
	v_dual_cndmask_b32 v107, v107, v99 :: v_dual_and_b32 v110, 3, v0 ; ca64c76b 6b6e0083
	v_fma_mix_f32 v58, s24, v105, v58 op_sel_hi:[1,1,0]         ; cc20003a 1cead218
	v_fma_mix_f32 v60, s56, v105, v60 op_sel_hi:[1,1,0]         ; cc20003c 1cf2d238
	v_fma_mix_f32 v62, s88, v105, v62 op_sel_hi:[1,1,0]         ; cc20003e 1cfad258
	v_fma_mix_f32 v61, s72, v105, v61 op_sel_hi:[1,1,0]         ; cc20003d 1cf6d248
	v_dual_cndmask_b32 v108, v108, v100 :: v_dual_add_nc_u32 v109, v109, v110 ; ca60c96c 6c6cdd6d
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v60, s56, v105, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf2d238
	v_fma_mix_f32 v62, s88, v105, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfad258
	v_fma_mix_f32 v61, s72, v105, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf6d248
	v_fma_mix_f32 v105, s24, v105, v58 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201869 1cead218
	v_fma_mix_f32 v60, s57, v106, v60 op_sel_hi:[1,1,0]         ; cc20003c 1cf2d439
	v_fma_mix_f32 v62, s89, v106, v62 op_sel_hi:[1,1,0]         ; cc20003e 1cfad459
	v_fma_mix_f32 v61, s73, v106, v61 op_sel_hi:[1,1,0]         ; cc20003d 1cf6d449
	v_fma_mix_f32 v105, s25, v106, v105 op_sel_hi:[1,1,0]       ; cc200069 1da6d419
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v60, s57, v106, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf2d439
	v_fma_mix_f32 v62, s89, v106, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfad459
	v_fma_mix_f32 v61, s73, v106, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf6d449
	v_fma_mix_f32 v106, s25, v106, v105 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20186a 1da6d419
	v_fma_mix_f32 v60, s58, v107, v60 op_sel_hi:[1,1,0]         ; cc20003c 1cf2d63a
	v_fma_mix_f32 v62, s90, v107, v62 op_sel_hi:[1,1,0]         ; cc20003e 1cfad65a
	v_fma_mix_f32 v61, s74, v107, v61 op_sel_hi:[1,1,0]         ; cc20003d 1cf6d64a
	v_fma_mix_f32 v106, s26, v107, v106 op_sel_hi:[1,1,0]       ; cc20006a 1daad61a
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v60, s58, v107, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf2d63a
	v_fma_mix_f32 v62, s90, v107, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfad65a
	v_fma_mix_f32 v61, s74, v107, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf6d64a
	v_fma_mix_f32 v107, s26, v107, v106 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20186b 1daad61a
	v_fma_mix_f32 v60, s59, v108, v60 op_sel_hi:[1,1,0]         ; cc20003c 1cf2d83b
	v_fma_mix_f32 v62, s91, v108, v62 op_sel_hi:[1,1,0]         ; cc20003e 1cfad85b
	v_fma_mix_f32 v61, s75, v108, v61 op_sel_hi:[1,1,0]         ; cc20003d 1cf6d84b
	v_fma_mix_f32 v107, s27, v108, v107 op_sel_hi:[1,1,0]       ; cc20006b 1daed81b
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v60, s59, v108, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf2d83b
	v_fma_mix_f32 v62, s91, v108, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfad85b
	v_fma_mix_f32 v61, s75, v108, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf6d84b
	v_fma_mix_f32 v108, s27, v108, v107 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20186c 1daed81b
	v_fma_mix_f32 v60, s60, v101, v60 op_sel_hi:[1,1,0]         ; cc20003c 1cf2ca3c
	v_fma_mix_f32 v62, s92, v101, v62 op_sel_hi:[1,1,0]         ; cc20003e 1cfaca5c
	v_fma_mix_f32 v61, s76, v101, v61 op_sel_hi:[1,1,0]         ; cc20003d 1cf6ca4c
	v_fma_mix_f32 v108, s28, v101, v108 op_sel_hi:[1,1,0]       ; cc20006c 1db2ca1c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v60, s60, v101, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf2ca3c
	v_fma_mix_f32 v62, s92, v101, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfaca5c
	v_fma_mix_f32 v61, s76, v101, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf6ca4c
	v_fma_mix_f32 v101, s28, v101, v108 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201865 1db2ca1c
	v_fma_mix_f32 v60, s61, v102, v60 op_sel_hi:[1,1,0]         ; cc20003c 1cf2cc3d
	v_fma_mix_f32 v62, s93, v102, v62 op_sel_hi:[1,1,0]         ; cc20003e 1cfacc5d
	v_fma_mix_f32 v61, s77, v102, v61 op_sel_hi:[1,1,0]         ; cc20003d 1cf6cc4d
	v_fma_mix_f32 v101, s29, v102, v101 op_sel_hi:[1,1,0]       ; cc200065 1d96cc1d
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v60, s61, v102, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf2cc3d
	v_fma_mix_f32 v62, s93, v102, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfacc5d
	v_fma_mix_f32 v61, s77, v102, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf6cc4d
	v_fma_mix_f32 v102, s29, v102, v101 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201866 1d96cc1d
	v_fma_mix_f32 v60, s62, v103, v60 op_sel_hi:[1,1,0]         ; cc20003c 1cf2ce3e
	v_fma_mix_f32 v62, s94, v103, v62 op_sel_hi:[1,1,0]         ; cc20003e 1cface5e
	v_bfe_u32 v111, v0, 2, 2                                    ; d610006f 02090500
	v_fma_mix_f32 v61, s78, v103, v61 op_sel_hi:[1,1,0]         ; cc20003d 1cf6ce4e
	v_fma_mix_f32 v102, s30, v103, v102 op_sel_hi:[1,1,0]       ; cc200066 1d9ace1e
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bfe_u32 s8, s17, 0x2001e                                  ; 9308ff11 0002001e
	v_fma_mix_f32 v60, s62, v103, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf2ce3e
	v_fma_mix_f32 v62, s94, v103, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cface5e
	v_lshl_add_u32 v112, s7, 2, v111                            ; d6460070 05bd0407
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s8, s8, 1                                      ; 80088108
	s_and_b32 s9, s18, 0x3fff                                   ; 8b09ff12 00003fff
	v_fma_mix_f32 v61, s78, v103, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf6ce4e
	v_fma_mix_f32 v103, s30, v103, v102 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201867 1d9ace1e
	v_fma_mix_f32 v60, s63, v104, v60 op_sel_hi:[1,1,0]         ; cc20003c 1cf2d03f
	v_fma_mix_f32 v62, s95, v104, v62 op_sel_hi:[1,1,0]         ; cc20003e 1cfad05f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl2_add_u32 s9, s9, s8                                  ; 87890809
	s_bfe_u32 s10, s17, 0x50019                                 ; 930aff11 00050019
	v_fma_mix_f32 v61, s79, v104, v61 op_sel_hi:[1,1,0]         ; cc20003d 1cf6d04f
	v_fma_mix_f32 v103, s31, v104, v103 op_sel_hi:[1,1,0]       ; cc200067 1d9ed01f
	v_min_i32_e32 v113, v112, v109                              ; 22e2db70
	v_fma_mix_f32 v60, s63, v104, v60 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183c 1cf2d03f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s9, s9, s10                                      ; 85090a09
	s_bfe_u32 s26, s18, 0x10000e                                ; 931aff12 0010000e
	v_fma_mix_f32 v62, s95, v104, v62 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183e 1cfad05f
	v_fma_mix_f32 v61, s79, v104, v61 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc20183d 1cf6d04f
	v_fma_mix_f32 v104, s31, v104, v103 op_sel:[1,1,0] op_sel_hi:[1,1,0] ; cc201868 1d9ed01f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s26, s26, 1                                    ; 801a811a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s26, s26, s10                                    ; 851a0a1a
	s_max_u32 s9, s9, 1                                         ; 8a898109
	s_cmp_eq_i32 s17, 0                                         ; bf008011
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cselect_b32 s9, 0, s9                                     ; 98090980
	s_max_u32 s26, s26, 1                                       ; 8a9a811a
	s_cmp_eq_i32 s17, 0                                         ; bf008011
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmp_le_i32_e32 vcc_lo, s9, v109                           ; 7c86da09
	s_cselect_b32 s26, 0, s26                                   ; 981a1a80
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d443000c
	v_cndmask_b32_e32 v1, s26, v112, vcc_lo                     ; 0202e01a
	s_or_b32 s12, s12, vcc_lo                                   ; 8c0c6a0c
	v_cmp_gt_i32_e32 vcc_lo, 0, v113                            ; 7c88e280
	s_nor_b32 exec_lo, vcc_lo, s12                              ; 8f7e0c6a
	s_cbranch_execz BB249                                       ; bfa50363
BB157:
	s_clause 0x2                                                ; bf850002
	s_load_b256 s[32:39], s[0:1], 0xa0                          ; f4006800 f80000a0
	s_load_b128 s[28:31], s[0:1], 0xd0                          ; f4004700 f80000d0
	s_load_b128 s[40:43], s[0:1], 0x50                          ; f4004a00 f8000050
	v_cvt_f32_i32_e32 v1, v109                                  ; 7e020b6d
	v_cvt_f32_i32_e32 v2, v112                                  ; 7e040b70
	s_bitcmp1_b32 s13, 0                                        ; bf0d800d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_mov_b32 s4, src_scc                                       ; be8400fd
	v_dual_add_f32 v2, 0.5, v2 :: v_dual_add_f32 v1, 0.5, v1    ; c90804f0 020002f0
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bfe_u32 s5, s33, 0x2001e                                  ; 9305ff21 0002001e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s5, s5, 1                                      ; 80058105
	s_and_b32 s8, s34, 0x3fff                                   ; 8b08ff22 00003fff
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl2_add_u32 s8, s8, s5                                  ; 87880508
	s_bfe_u32 s10, s33, 0x50019                                 ; 930aff21 00050019
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s8, s8, s10                                      ; 85080a08
	s_bfe_u32 s50, s34, 0x10000e                                ; 9332ff22 0010000e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s50, s50, 1                                    ; 80328132
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s50, s50, s10                                    ; 85320a32
	s_max_u32 s8, s8, 1                                         ; 8a888108
	s_cmp_eq_i32 s33, 0                                         ; bf008021
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cselect_b32 s8, 0, s8                                     ; 98080880
	s_max_u32 s50, s50, 1                                       ; 8ab28132
	s_cmp_eq_i32 s33, 0                                         ; bf008021
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_f32_i32 s8, s8                                        ; be886408
	s_cselect_b32 s50, 0, s50                                   ; 98323280
	s_and_b32 s12, s31, -2.0                                    ; 8b0cf51f
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840008
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                      ; 02010008
	s_cvt_f32_i32 s50, s50                                      ; beb26432
	s_cmp_eq_i32 s12, -2.0                                      ; bf00f50c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s14, s4, src_scc                                  ; 8b0efd04
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840032
	v_cndmask_b32_e32 v0, s50, v128, vcc_lo                     ; 02010032
	s_mov_b32 s15, src_scc                                      ; be8f00fd
	s_and_b32 s24, s31, 0x3fffffff                              ; 8b18ff1f 3fffffff
	s_cmp_lg_i32 s15, 0                                         ; bf01800f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cselect_b32 s31, s24, s31                                 ; 981f1f18
	v_dual_mul_f32 v2, s50, v2 :: v_dual_mul_f32 v1, s8, v1     ; c8c60432 02000208
	image_sample_lz v[4:7], [v1, v2], s[32:39], s[28:31] dmask:0xf dim:SQ_RSRC_IMG_2D ; e7c7c001 0e004004 00000201
	s_bitset0_b32 s41, 14                                       ; bea9108e
	s_buffer_load_b128 s[28:31], s[40:43], 0x0                  ; f4024714 f8000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_neq_f32 s28, 0                                        ; bf4d801c
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_fma_f32 v8, 0x3e800000, v34, v4 clamp                     ; d6138008 041244ff 3e800000
	v_fma_f32 v9, 0x3e800000, v35, v5 clamp                     ; d6138009 041646ff 3e800000
	v_fma_f32 v10, 0x3e800000, v36, v6 clamp                    ; d613800a 041a48ff 3e800000
	s_cbranch_scc0 BB159                                        ; bfa100d6
BB158:
	s_clause 0x3                                                ; bf850003
	s_load_b256 s[32:39], s[0:1], 0xe0                          ; f4006800 f80000e0
	s_load_b128 s[44:47], s[0:1], 0x110                         ; f4004b00 f8000110
	s_load_b256 s[48:55], s[0:1], 0x120                         ; f4006c00 f8000120
	s_load_b128 s[56:59], s[0:1], 0x150                         ; f4004e00 f8000150
	s_buffer_load_b128 s[60:63], s[40:43], 0x20                 ; f4024f14 f8000020
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_and_b32 s5, s47, -2.0                                     ; 8b05f52f
	v_fma_f32 v3, s60, v1, s62                                  ; d6130003 00fa023c
	v_fma_f32 v11, s61, v2, s63                                 ; d613000b 00fe043d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_eq_i32 s5, -2.0                                       ; bf00f505
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s8, s4, src_scc                                   ; 8b08fd04
	s_mov_b32 s10, src_scc                                      ; be8a00fd
	s_and_b32 s11, s47, 0x3fffffff                              ; 8b0bff2f 3fffffff
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s10, 0                                         ; bf01800a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s47, s11, s47                                 ; 982f2f0b
	image_sample_lz v[12:13], [v3, v11], s[32:39], s[44:47] dmask:0x3 dim:SQ_RSRC_IMG_2D ; e4c7c001 1600400c 00000b03
	s_buffer_load_b64 s[10:11], s[40:43], 0x10                  ; f4022294 f8000010
	s_mov_b32 s12, 0x40200000                                   ; be8c00ff 40200000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_add_f32 s14, s10, -0.5                                    ; a00ef10a
	s_add_f32 s15, s11, -0.5                                    ; a00ff10b
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_fmac_f32_e32 v2, s30, v13                                 ; 56041a1e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_f32 v14, s11, v2, -0.5                                ; d613000e 03c6040b
	v_floor_f32_e32 v14, v14                                    ; 7e1c490e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v15, 0.5, v14                                 ; 061e1cf0
	v_fma_f32 v2, s11, v2, -v15 clamp                           ; d6138002 843e040b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v16, v2, v2                                   ; 10200502
	v_mul_f32_e32 v17, v16, v2                                  ; 10220510
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d5030002
(invalid instruction)                                        ; 7a022302
	v_fma_f32 v18, 0x3fc00000, v17, 1.0                         ; d6130012 03ca22ff 3fc00000
(invalid instruction)                                        ; d5040011
	v_min_num_f64_e32 v[1:2], v[17:18], v[16:17]                ; 1a022111
(invalid instruction)                                        ; d684000b
	v_cndmask_b32_e32 v0, s11, v128, vcc_lo                     ; 0201000b
	s_and_b32 s24, s59, -2.0                                    ; 8b18f53b
	v_dual_add_f32 v2, v16, v2 :: v_dual_fmac_f32 v1, s29, v12  ; c9000510 0200181d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_eq_i32 s24, -2.0                                      ; bf00f518
	v_fma_f32 v18, -s12, v16, v18                               ; d6130012 244a200c
	s_and_b32 s4, s4, src_scc                                   ; 8b04fd04
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_sub_f32_e32 v19, 1.0, v2                                  ; 082604f2
	v_fma_f32 v12, s10, v1, -0.5                                ; d613000c 03c6020a
	s_mov_b32 s25, src_scc                                      ; be9900fd
	s_and_b32 s27, s59, 0x3fffffff                              ; 8b1bff3b 3fffffff
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s25, 0                                         ; bf018019
	v_sub_f32_e32 v19, v19, v18                                 ; 08262513
	v_floor_f32_e32 v12, v12                                    ; 7e18490c
	s_cselect_b32 s59, s27, s59                                 ; 983b3b1b
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_sub_f32_e32 v19, v19, v17                                 ; 08262313
	v_dual_add_f32 v13, 0.5, v12 :: v_dual_add_f32 v18, v18, v19 ; c90818f0 0d122712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1) ; bf8702b1
	v_fma_f32 v1, s10, v1, -v13 clamp                           ; d6138001 8436020a
(invalid instruction)                                        ; d684000a
	v_cndmask_b32_e32 v0, s10, v128, vcc_lo                     ; 0201000a
	v_rcp_f32_e32 v21, v18                                      ; 7e2a5512
	v_dual_fmac_f32 v15, v19, v21 :: v_dual_add_f32 v20, -0.5, v12 ; c8082b13 0f1418f1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_maxmin_num_f32 v15, 0.5, v15, s15                         ; d669000f 003e1ef0
	v_maxmin_num_f32 v20, 0.5, v20, s14                         ; d6690014 003a28f0
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_dual_mul_f32 v15, s11, v15 :: v_dual_mul_f32 v20, s10, v20 ; c8c61e0b 0f14280a
	image_sample_lz v[22:24], [v20, v15], s[48:55], s[56:59] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1c006016 00000f14
	v_mul_f32_e32 v25, v1, v1                                   ; 10320301
	v_dual_add_f32 v12, s12, v12 :: v_dual_add_f32 v29, -0.5, v14 ; c908180c 0c1c1cf1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_mul_f32_e32 v26, v25, v1                                  ; 10340319
	v_maxmin_num_f32 v29, 0.5, v29, s15                         ; d669001d 003e3af0
	v_maxmin_num_f32 v12, 0.5, v12, s14                         ; d669000c 003a18f0
(invalid instruction)                                        ; d5030001
(invalid instruction)                                        ; 7a023501
	v_fma_f32 v27, 0x3fc00000, v26, 1.0                         ; d613001b 03ca34ff 3fc00000
(invalid instruction)                                        ; d504001a
	v_min_num_f64_e32 v[1:2], v[26:27], v[25:26]                ; 1a02331a
	v_dual_mul_f32 v12, s10, v12 :: v_dual_mul_f32 v29, s11, v29 ; c8c6180a 0c1c3a0b
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_add_f32_e32 v1, v1, v25                                   ; 06023301
	v_fma_f32 v27, -s12, v25, v27                               ; d613001b 246e320c
	v_sub_f32_e32 v28, 1.0, v1                                  ; 083802f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_f32_e32 v28, v28, v27                                 ; 0838371c
	v_sub_f32_e32 v28, v28, v26                                 ; 0838351c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v27, v27, v28                                 ; 0636391b
	v_rcp_f32_e32 v30, v27                                      ; 7e3c551b
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_dual_add_f32 v14, s12, v14 :: v_dual_fmac_f32 v13, v30, v28 ; c9001c0c 0e0c391e
	v_maxmin_num_f32 v14, 0.5, v14, s15                         ; d669000e 003e1cf0
	v_maxmin_num_f32 v13, 0.5, v13, s14                         ; d669000d 003a1af0
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v14, s11, v14 :: v_dual_mul_f32 v13, s10, v13 ; c8c61c0b 0e0c1a0a
	s_clause 0x3                                                ; bf850003
	image_sample_lz v[31:33], [v13, v29], s[48:55], s[56:59] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1c00601f 00001d0d
	image_sample_lz v[34:36], [v13, v15], s[48:55], s[56:59] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1c006022 00000f0d
	image_sample_lz v[37:39], [v13, v14], s[48:55], s[56:59] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1c006025 00000e0d
	image_sample_lz v[40:42], [v12, v15], s[48:55], s[56:59] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1c006028 00000f0c
	v_mul_f32_e32 v84, 0x3fb8aa3b, v84                          ; 10a8a8ff 3fb8aa3b
	s_max_num_f32 s31, s31, 0                                   ; a19f801f
	v_dual_mul_f32 v26, v26, v18 :: v_dual_mul_f32 v1, v1, v18  ; c8c6251a 1a002501
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_num_f32 s31, s31, 1.0                                 ; a11ff21f
(invalid instruction)                                        ; d5a50054
	v_min_i32_e32 v0, v84, v128                                 ; 22010154
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_add_f32_e32 v84, 1.0, v84                                 ; 06a8a8f2
	v_rcp_f32_e32 v84, v84                                      ; 7ea85554
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870155
	v_dual_mul_f32 v2, v2, v27 :: v_dual_mul_f32 v11, s31, v84  ; c8c63702 020aa81f
	s_wait_samplecnt 0x4                                        ; bfc20004
	v_dual_mul_f32 v22, v22, v1 :: v_dual_mul_f32 v43, v27, v18 ; c8c60316 162a251b
	v_dual_mul_f32 v24, v24, v1 :: v_dual_mul_f32 v17, v17, v27 ; c8c60318 18103711
	s_wait_samplecnt 0x3                                        ; bfc20003
	v_dual_fmac_f32 v22, v2, v31 :: v_dual_mul_f32 v23, v23, v1 ; c8063f02 16160317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_fmac_f32 v24, v33, v2 :: v_dual_fmac_f32 v23, v32, v2 ; c8000521 18160520
	s_wait_samplecnt 0x2                                        ; bfc20002
	v_dual_fmac_f32 v22, v34, v43 :: v_dual_add_f32 v1, v1, v2  ; c8085722 16000501
	v_dual_add_f32 v1, v1, v43 :: v_dual_fmac_f32 v24, v36, v43 ; c9005701 01185724
	s_wait_samplecnt 0x1                                        ; bfc20001
	v_dual_fmac_f32 v22, v37, v17 :: v_dual_fmac_f32 v23, v35, v43 ; c8002325 16165723
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_fmac_f32 v24, v39, v17 :: v_dual_fmac_f32 v23, v38, v17 ; c8002327 18162326
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_dual_fmac_f32 v22, v40, v26 :: v_dual_add_f32 v1, v1, v17 ; c8083528 16002301
	v_dual_fmac_f32 v24, v42, v26 :: v_dual_add_f32 v1, v1, v26 ; c808352a 18003501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v1, v1                                        ; 7e025501
	v_fma_f32 v22, v22, v1, -v8                                 ; d6130016 84220316
	v_fma_f32 v24, v24, v1, -v10                                ; d6130018 842a0318
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmac_f32 v8, v22, v11 :: v_dual_fmac_f32 v23, v41, v26 ; c8001716 08163529
	v_fma_f32 v23, v23, v1, -v9                                 ; d6130017 84260317
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmac_f32 v10, v11, v24 :: v_dual_fmac_f32 v9, v11, v23 ; c800310b 0a082f0b
	s_branch BB160                                              ; bfa00001
BB159:
	v_mov_b32_e32 v11, 0                                        ; 7e160280
BB160:
	v_sub_f32_e32 v1, v8, v4                                    ; 08020908
	v_dual_sub_f32 v3, v10, v6 :: v_dual_sub_f32 v2, v9, v5     ; c94a0d0a 03020b09
	s_min_num_f32 s4, s3, 1.0                                   ; a104f203
	s_cmp_lt_f32 1.0, s3                                        ; bf4103f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_f32 v12, s4, v1, v4 clamp                             ; d613800c 04120204
	v_fma_f32 v13, s4, v2, v5 clamp                             ; d613800d 04160404
	v_fma_f32 v14, s4, v3, v6 clamp                             ; d613800e 041a0604
	s_cbranch_scc0 BB163                                        ; bfa10026
BB161:
	s_mov_b32 s4, 0x3f371759                                    ; be8400ff 3f371759
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fmaak_f32 v1, s4, v13, 0x3b000000                         ; 5a021a04 3b000000
	v_fmaak_f32 v2, s4, v5, 0x3b000000                          ; 5a040a04 3b000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmamk_f32 v1, v14, 0x3d93dd98, v1                         ; 5802030e 3d93dd98
	v_fmamk_f32 v2, v6, 0x3d93dd98, v2                          ; 58040506 3d93dd98
	v_fmamk_f32 v1, v12, 0x3e59b3d0, v1                         ; 5802030c 3e59b3d0
	v_fmamk_f32 v2, v4, 0x3e59b3d0, v2                          ; 58040504 3e59b3d0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v2, v2                                        ; 7e045502
	v_mul_f32_e32 v1, v1, v2                                    ; 10020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f32_e32 v1, 0x358637bd, v1                        ; 2c0202ff 358637bd
	v_log_f32_e32 v3, v1                                        ; 7e064f01
	v_rcp_f32_e32 v1, v1                                        ; 7e025501
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870096
	v_mul_dx9_zero_f32_e32 v3, s3, v3                           ; 0e060603
	v_exp_f32_e32 v3, v3                                        ; 7e064b03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_maxmin_num_f32 v3, 0.5, v3, 2.0                           ; d6690003 03d206f0
	v_mul_f32_e32 v3, v3, v1                                    ; 10060303
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d508800c
	v_cndmask_b32_e32 v1, v12, v3, vcc_lo                       ; 0202070c
(invalid instruction)                                        ; d508800d
	v_cndmask_b32_e32 v1, v13, v3, vcc_lo                       ; 0202070d
(invalid instruction)                                        ; d508800e
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                       ; 0202070e
BB163:
	s_bfe_u32 s4, s2, 0x2001c                                   ; 9304ff02 0002001c
	s_cbranch_scc0 BB238                                        ; bfa101cc
BB164:
	s_cmp_eq_i32 s4, 1                                          ; bf008104
(invalid instruction)                                        ; d503800c
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                     ; 0201010c
(invalid instruction)                                        ; d503800d
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                     ; 0201010d
(invalid instruction)                                        ; d503800e
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	s_cselect_b32 s5, 0x3f6edb40, 1.0                           ; 9805f2ff 3f6edb40
	s_mul_i32 s8, 0xbe800000, src_scc                           ; 9608fdff be800000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_mul_f32_e32 v12, s5, v12                                  ; 10181805
	s_mov_b32 s11, exec_lo                                      ; be8b007e
	v_dual_mul_f32 v14, s5, v14 :: v_dual_mul_f32 v13, s5, v13  ; c8c61c05 0e0c1a05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v2, v12, v12 :: v_dual_fmaak_f32 v1, -2.0, v12, 0x40400000 ; c8c2190c 020018f5 40400000
	v_mul_f32_e32 v15, v14, v14                                 ; 101e1d0e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_f32 v2, v2, v1, -v12                                  ; d6130002 84320302
	v_fma_f32 v2, s8, v2, v12 clamp                             ; d6138002 04320408
	v_dual_mul_f32 v12, v13, v13 :: v_dual_fmaak_f32 v3, -2.0, v13, 0x40400000 ; c8c21b0d 0c021af5 40400000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_f32 v12, v12, v3, -v13                                ; d613000c 8436070c
	v_fma_f32 v12, s8, v12, v13 clamp                           ; d613800c 04361808
	v_fmaak_f32 v13, -2.0, v14, 0x40400000                      ; 5a1a1cf5 40400000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_f32 v15, v15, v13, -v14                               ; d613000f 843a1b0f
	v_fma_f32 v15, s8, v15, v14 clamp                           ; d613800f 043a1e08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_max3_num_f32 v16, v2, v12, v15                            ; d62a0010 043e1902
	v_min3_num_f32 v17, v2, v12, v15                            ; d6290011 043e1902
	v_add_f32_e32 v18, v16, v17                                 ; 06242310
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v19, 0.5, v18                                 ; 102624f0
	v_cmpx_lt_f32_e32 v17, v16                                  ; 7d222111
	s_cbranch_execz BB174                                       ; bfa50027
BB165:
	v_sub_f32_e32 v1, v16, v17                                  ; 08022310
	v_sub_f32_e32 v3, 2.0, v16                                  ; 080620f4
	v_cmp_lt_f32_e32 vcc_lo, 0.5, v19                           ; 7c2226f0
	s_mov_b32 s5, exec_lo                                       ; be85007e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_sub_f32_e32 v3, v3, v17                                   ; 08062303
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v3, v18, v3, vcc_lo                       ; 02060712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v3, v3                                        ; 7e065503
	v_mul_f32_e32 v3, v1, v3                                    ; 10060701
	v_cmpx_eq_f32_e32 v16, v2                                   ; 7d240510
BB166:
	v_sub_f32_e32 v2, v12, v15                                  ; 08041f0c
	v_rcp_f32_e32 v1, v1                                        ; 7e025501
	v_cmp_lt_f32_e32 vcc_lo, v12, v15                           ; 7c221f0c
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v12, 0, 0x40c00000, vcc_lo                ; d501000c 01a9fe80 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v12, v2, v1                                  ; 56180302
	v_mul_f32_e32 v12, 0x3e2aaaab, v12                          ; 101818ff 3e2aaaab
	s_and_not1_b32 exec_lo, s5, exec_lo                         ; 917e7e05
BB169:
	v_rcp_f32_e32 v1, v1                                        ; 7e025501
	v_dual_sub_f32 v15, v15, v2 :: v_dual_sub_f32 v2, v2, v12   ; c94a050f 0f021902
	v_cmp_eq_f32_e32 vcc_lo, v16, v12                           ; 7c241910
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)    ; bf870105
	v_fma_f32 v2, v2, v1, 4.0                                   ; d6130002 03da0302
	v_fma_f32 v15, v15, v1, 2.0                                 ; d613000f 03d2030f
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cndmask_b32_e32 v2, v2, v15, vcc_lo                       ; 02041f02
	v_mul_f32_e32 v12, 0x3e2aaaab, v2                           ; 101804ff 3e2aaaab
BB171:
	s_mov_b32 exec_lo, s5                                       ; befe0005
BB174:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 exec_lo, s11, exec_lo                        ; 917e7e0b
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v3, 0               ; ca100080 0c020080
BB176:
	s_mov_b32 exec_lo, s11                                      ; befe000b
	s_cmp_eq_i32 s4, 1                                          ; bf008104
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s5, 0x3f666666, 1.0                           ; 9805f2ff 3f666666
	s_cmp_eq_i32 s4, 2                                          ; bf008204
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cselect_b32 s5, 0x3f59999a, s5                            ; 980505ff 3f59999a
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d5088003
	v_cndmask_b32_e32 v1, s5, v3, vcc_lo                        ; 02020605
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_lt_f32_e32 0, v3                                     ; 7d220680
	s_cbranch_execz BB198                                       ; bfa50082
BB177:
	v_add_f32_e32 v1, 1.0, v3                                   ; 060206f2
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v19                           ; 7c2826f0
	v_add_f32_e32 v13, 0x3eaaaaab, v12                          ; 061a18ff 3eaaaaab
	s_mov_b32 s4, exec_lo                                       ; be84007e
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_dual_mul_f32 v1, v19, v1 :: v_dual_add_f32 v2, v19, v3    ; c8c80313 01020713
	v_fma_f32 v3, -v19, v3, v2                                  ; d6130003 240a0713
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cndmask_b32_e32 v3, v3, v1, vcc_lo                        ; 02060303
	v_cmp_gt_f32_e32 vcc_lo, 0, v13                             ; 7c281a80
	v_sub_f32_e32 v19, v18, v3                                  ; 08260712
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v14, 0, 1.0, vcc_lo                       ; d501000e 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v13, v13, v14                                 ; 061a1d0d
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v13                           ; 7c221af2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v15, 0, 1.0, vcc_lo                       ; d501000f 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_f32_e32 v13, v13, v15                                 ; 081a1f0d
	v_cmpx_gt_f32_e32 0x3e2aaaab, v13                           ; 7d281aff 3e2aaaab
BB178:
	v_sub_f32_e32 v1, v3, v19                                   ; 08022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v1, 0x40c00000, v1                            ; 100202ff 40c00000
	v_fma_f32 v13, v13, v1, v19                                 ; d613000d 044e030d
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB181:
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_sub_f32_e32 v2, 0x3f2aaaab, v13                           ; 08041aff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v13                    ; 7c281aff 3f2aaaab
	v_dual_mul_f32 v2, 0x40c00000, v2 :: v_dual_sub_f32 v1, v3, v19 ; c8ca04ff 02002703 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_f32 v2, v2, v1, v19                                   ; d6130002 044e0302
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v2, v19, v2, vcc_lo                       ; 02040513
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v13                           ; 7c281af0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v13, v2, v3, vcc_lo                       ; 021a0702
BB183:
	s_mov_b32 exec_lo, s4                                       ; befe0004
	v_cmp_gt_f32_e32 vcc_lo, 0, v12                             ; 7c281880
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v1, 0, 1.0, vcc_lo                        ; d5010001 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v1, v12, v1                                   ; 0602030c
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v1                            ; 7c2202f2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v2, 0, 1.0, vcc_lo                        ; d5010002 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_f32_e32 v1, v1, v2                                    ; 08020501
	v_cmpx_gt_f32_e32 0x3e2aaaab, v1                            ; 7d2802ff 3e2aaaab
BB184:
	v_sub_f32_e32 v2, v3, v19                                   ; 08042703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v2, 0x40c00000, v2                            ; 100404ff 40c00000
	v_fma_f32 v1, v1, v2, v19                                   ; d6130001 044e0501
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB187:
	v_sub_f32_e32 v2, v3, v19                                   ; 08042703
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_sub_f32_e32 v14, 0x3f2aaaab, v1                           ; 081c02ff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v1                     ; 7c2802ff 3f2aaaab
	v_mul_f32_e32 v14, 0x40c00000, v14                          ; 101c1cff 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_f32 v14, v14, v2, v19                                 ; d613000e 044e050e
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v14, v19, v14, vcc_lo                     ; 021c1d13
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v1                            ; 7c2802f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                       ; 0202070e
BB189:
	s_mov_b32 exec_lo, s4                                       ; befe0004
	v_add_f32_e32 v12, 0xbeaaaaab, v12                          ; 061818ff beaaaaab
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_gt_f32_e32 vcc_lo, 0, v12                             ; 7c281880
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v2, 0, 1.0, vcc_lo                        ; d5010002 01a9e480
	v_add_f32_e32 v12, v12, v2                                  ; 0618050c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v12                           ; 7c2218f2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v14, 0, 1.0, vcc_lo                       ; d501000e 01a9e480
	v_sub_f32_e32 v12, v12, v14                                 ; 08181d0c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_gt_f32_e32 0x3e2aaaab, v12                           ; 7d2818ff 3e2aaaab
BB190:
	v_sub_f32_e32 v3, v3, v19                                   ; 08062703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v3, 0x40c00000, v3                            ; 100606ff 40c00000
	v_fmac_f32_e32 v19, v12, v3                                 ; 5626070c
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB193:
	v_sub_f32_e32 v14, 0x3f2aaaab, v12                          ; 081c18ff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v12                    ; 7c2818ff 3f2aaaab
	v_sub_f32_e32 v2, v3, v19                                   ; 08042703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_mul_f32_e32 v14, 0x40c00000, v14                          ; 101c1cff 40c00000
	v_fma_f32 v14, v14, v2, v19                                 ; d613000e 044e050e
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cndmask_b32_e32 v19, v19, v14, vcc_lo                     ; 02261d13
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v12                           ; 7c2818f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v19, v19, v3, vcc_lo                      ; 02260713
BB195:
	s_mov_b32 exec_lo, s4                                       ; befe0004
BB198:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 exec_lo, s11, exec_lo                        ; 917e7e0b
	v_mov_b32_e32 v1, v19                                       ; 7e020313
	v_mov_b32_e32 v13, v19                                      ; 7e1a0313
BB200:
	s_mov_b32 exec_lo, s11                                      ; befe000b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_max3_num_f32 v2, v13, v1, v19                             ; d62a0002 044e030d
	v_min3_num_f32 v3, v13, v1, v19                             ; d6290003 044e030d
	v_add_f32_e32 v12, v2, v3                                   ; 06180702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v14, 0.5, v12                                 ; 101c18f0
	v_cmpx_lt_f32_e32 v3, v2                                    ; 7d220503
	s_cbranch_execz BB210                                       ; bfa50027
BB201:
	v_sub_f32_e32 v16, 2.0, v2                                  ; 082004f4
	v_cmp_lt_f32_e32 vcc_lo, 0.5, v14                           ; 7c221cf0
	s_mov_b32 s4, exec_lo                                       ; be84007e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_sub_f32_e32 v16, v16, v3                                  ; 08200710
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_dual_cndmask_b32 v16, v12, v16 :: v_dual_sub_f32 v15, v2, v3 ; ca4a210c 100e0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v16, v16                                      ; 7e205510
	v_mul_f32_e32 v16, v15, v16                                 ; 1020210f
	v_cmpx_eq_f32_e32 v2, v13                                   ; 7d241b02
BB202:
	v_sub_f32_e32 v2, v1, v19                                   ; 08042701
	v_rcp_f32_e32 v15, v15                                      ; 7e1e550f
	v_cmp_lt_f32_e32 vcc_lo, v1, v19                            ; 7c222701
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v3, 0, 0x40c00000, vcc_lo                 ; d5010003 01a9fe80 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v3, v2, v15                                  ; 56061f02
	v_mul_f32_e32 v3, 0x3e2aaaab, v3                            ; 100606ff 3e2aaaab
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB205:
	v_sub_f32_e32 v19, v19, v13                                 ; 08261b13
	v_sub_f32_e32 v13, v13, v1                                  ; 081a030d
	v_rcp_f32_e32 v15, v15                                      ; 7e1e550f
	v_cmp_eq_f32_e32 vcc_lo, v2, v1                             ; 7c240302
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b5
	v_fma_f32 v13, v13, v15, 4.0                                ; d613000d 03da1f0d
	v_fma_f32 v19, v19, v15, 2.0                                ; d6130013 03d21f13
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v13, v13, v19, vcc_lo                     ; 021a270d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v3, 0x3e2aaaab, v13                           ; 10061aff 3e2aaaab
BB207:
	s_mov_b32 exec_lo, s4                                       ; befe0004
BB210:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 exec_lo, s11, exec_lo                        ; 917e7e0b
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v3, 0               ; ca100080 10020080
BB212:
	s_mov_b32 exec_lo, s11                                      ; befe000b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5038010
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
	v_cmpx_lt_f32_e32 0, v16                                    ; 7d222080
	s_cbranch_execz BB234                                       ; bfa50083
BB213:
	v_add_f32_e32 v1, 1.0, v16                                  ; 060220f2
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v14                           ; 7c281cf0
	s_mov_b32 s4, exec_lo                                       ; be84007e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_mul_f32 v1, v14, v1 :: v_dual_add_f32 v2, v14, v16   ; c8c8030e 0102210e
	v_fma_f32 v16, -v14, v16, v2                                ; d6130010 240a210e
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cndmask_b32_e32 v16, v16, v1, vcc_lo                      ; 02200310
	v_sub_f32_e32 v14, v12, v16                                 ; 081c210c
	v_add_f32_e32 v12, 0x3eaaaaab, v3                           ; 061806ff 3eaaaaab
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_gt_f32_e32 vcc_lo, 0, v12                             ; 7c281880
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v13, 0, 1.0, vcc_lo                       ; d501000d 01a9e480
	v_add_f32_e32 v12, v12, v13                                 ; 06181b0c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v12                           ; 7c2218f2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v15, 0, 1.0, vcc_lo                       ; d501000f 01a9e480
	v_sub_f32_e32 v12, v12, v15                                 ; 08181f0c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_gt_f32_e32 0x3e2aaaab, v12                           ; 7d2818ff 3e2aaaab
BB214:
	v_sub_f32_e32 v1, v16, v14                                  ; 08021d10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v1, 0x40c00000, v1                            ; 100202ff 40c00000
	v_fma_f32 v12, v12, v1, v14                                 ; d613000c 043a030c
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB217:
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_sub_f32_e32 v2, 0x3f2aaaab, v12                           ; 080418ff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v12                    ; 7c2818ff 3f2aaaab
	v_dual_mul_f32 v2, 0x40c00000, v2 :: v_dual_subrev_f32 v1, v14, v16 ; c8cc04ff 0200210e 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_f32 v2, v2, v1, v14                                   ; d6130002 043a0302
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v2, v14, v2, vcc_lo                       ; 0204050e
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v12                           ; 7c2818f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v12, v2, v16, vcc_lo                      ; 02182102
BB219:
	s_mov_b32 exec_lo, s4                                       ; befe0004
	v_cmp_gt_f32_e32 vcc_lo, 0, v3                              ; 7c280680
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v1, 0, 1.0, vcc_lo                        ; d5010001 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v1, v3, v1                                    ; 06020303
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v1                            ; 7c2202f2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v2, 0, 1.0, vcc_lo                        ; d5010002 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_f32_e32 v1, v1, v2                                    ; 08020501
	v_cmpx_gt_f32_e32 0x3e2aaaab, v1                            ; 7d2802ff 3e2aaaab
BB220:
	v_sub_f32_e32 v2, v16, v14                                  ; 08041d10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v2, 0x40c00000, v2                            ; 100404ff 40c00000
	v_fma_f32 v1, v1, v2, v14                                   ; d6130001 043a0501
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB223:
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_sub_f32_e32 v13, 0x3f2aaaab, v1                           ; 081a02ff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v1                     ; 7c2802ff 3f2aaaab
	v_dual_mul_f32 v13, 0x40c00000, v13 :: v_dual_sub_f32 v2, v16, v14 ; c8ca1aff 0d021d10 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_f32 v13, v13, v2, v14                                 ; d613000d 043a050d
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v13, v14, v13, vcc_lo                     ; 021a1b0e
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v1                            ; 7c2802f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v1, v13, v16, vcc_lo                      ; 0202210d
BB225:
	s_mov_b32 exec_lo, s4                                       ; befe0004
	v_add_f32_e32 v3, 0xbeaaaaab, v3                            ; 060606ff beaaaaab
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_gt_f32_e32 vcc_lo, 0, v3                              ; 7c280680
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v2, 0, 1.0, vcc_lo                        ; d5010002 01a9e480
	v_add_f32_e32 v3, v3, v2                                    ; 06060503
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v3                            ; 7c2206f2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v13, 0, 1.0, vcc_lo                       ; d501000d 01a9e480
	v_sub_f32_e32 v3, v3, v13                                   ; 08061b03
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_gt_f32_e32 0x3e2aaaab, v3                            ; 7d2806ff 3e2aaaab
BB226:
	v_sub_f32_e32 v16, v16, v14                                 ; 08201d10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v16, 0x40c00000, v16                          ; 102020ff 40c00000
	v_fmac_f32_e32 v14, v3, v16                                 ; 561c2103
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB229:
	v_sub_f32_e32 v13, 0x3f2aaaab, v3                           ; 081a06ff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v3                     ; 7c2806ff 3f2aaaab
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_mul_f32 v13, 0x40c00000, v13 :: v_dual_sub_f32 v2, v16, v14 ; c8ca1aff 0d021d10 40c00000
	v_fma_f32 v13, v13, v2, v14                                 ; d613000d 043a050d
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cndmask_b32_e32 v14, v14, v13, vcc_lo                     ; 021c1b0e
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v3                            ; 7c2806f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v14, v14, v16, vcc_lo                     ; 021c210e
BB231:
	s_mov_b32 exec_lo, s4                                       ; befe0004
BB234:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 exec_lo, s11, exec_lo                        ; 917e7e0b
	v_dual_mov_b32 v12, v14 :: v_dual_mov_b32 v1, v14           ; ca10010e 0c00010e
BB236:
	s_mov_b32 exec_lo, s11                                      ; befe000b
	s_max_num_f32 s4, s3, 0                                     ; a1848003
(invalid instruction)                                        ; d503800e
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d503800c
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                     ; 0201010c
(invalid instruction)                                        ; d5038001
	v_cndmask_b32_e32 v0, v1, v128, vcc_lo                      ; 02010101
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_num_f32 s4, s4, 1.0                                   ; a104f204
	v_sub_f32_e32 v12, v12, v4                                  ; 0818090c
	v_dual_sub_f32 v14, v14, v6 :: v_dual_sub_f32 v1, v1, v5    ; c94a0d0e 0e000b01
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_fma_f32 v12, s4, v12, v4 clamp                            ; d613800c 04121804
	v_fma_f32 v13, s4, v1, v5 clamp                             ; d613800d 04160204
	v_fma_f32 v14, s4, v14, v6 clamp                            ; d613800e 041a1c04
BB238:
	s_cmp_lt_i32 s2, 0                                          ; bf048002
	s_cbranch_scc0 BB243                                        ; bfa1002c
BB239:
	s_bitcmp1_b32 s2, 30                                        ; bf0d9e02
	s_cbranch_scc0 BB244                                        ; bfa1002b
BB240:
(invalid instruction)                                        ; d503800c
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                     ; 0201010c
(invalid instruction)                                        ; d503800d
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                     ; 0201010d
(invalid instruction)                                        ; d503800e
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_mul_f32_e32 v12, 0x437f0000, v12                          ; 101818ff 437f0000
	v_dual_mul_f32 v14, 0x437f0000, v14 :: v_dual_mul_f32 v13, 0x437f0000, v13 ; c8c61cff 0e0c1aff 437f0000
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_fract_f32_e32 v1, v12                                     ; 7e02410c
	v_floor_f32_e32 v12, v12                                    ; 7e18490c
	v_floor_f32_e32 v3, v13                                     ; 7e06490d
	v_fract_f32_e32 v13, v13                                    ; 7e1a410d
	v_floor_f32_e32 v5, v14                                     ; 7e0a490e
	v_fract_f32_e32 v14, v14                                    ; 7e1c410e
	v_cmp_le_f32_e32 vcc_lo, 0.5, v1                            ; 7c2602f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v2, 0, 1.0, vcc_lo                        ; d5010002 01a9e480
	v_cmp_le_f32_e32 vcc_lo, 0.5, v13                           ; 7c261af0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v4, 0, 1.0, vcc_lo                        ; d5010004 01a9e480
	v_cmp_le_f32_e32 vcc_lo, 0.5, v14                           ; 7c261cf0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v6, 0, 1.0, vcc_lo                        ; d5010006 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_add_f32 v5, v6, v5 :: v_dual_add_f32 v12, v12, v2    ; c9080b06 050c050c
	v_dual_mul_f32 v14, 0x3b808081, v5 :: v_dual_add_f32 v3, v3, v4 ; c8c80aff 0e020903 3b808081
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v13, 0x3b808081, v3 :: v_dual_mul_f32 v12, 0x3b808081, v12 ; c8c606ff 0d0c18ff 3b808081
	s_branch BB244                                              ; bfa00001
BB243:
	v_mov_b32_e32 v7, 1.0                                       ; 7e0e02f2
BB244:
	s_load_b256 s[32:39], s[0:1], 0x80                          ; f4006800 f8000080
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mov_b32_e32 v15, v7                                       ; 7e1e0307
	image_store v[12:15], [v109, v112], s[16:23] dmask:0xf dim:SQ_RSRC_IMG_2D ; d3c18001 0000200c 0000706d
	s_wait_kmcnt 0x0                                            ; bfc70000
	image_store v[8:11], [v109, v112], s[32:39] dmask:0xf dim:SQ_RSRC_IMG_2D ; d3c18001 00004008 0000706d
BB249:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_lshl2_add_u32 s7, s7, 4                                   ; 87878407
	v_add_nc_u32_e32 v0, 32, v0                                 ; 4a0000a0
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_nc_u32_e32 v111, s7, v111                             ; 4adede07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_bfe_u32 v0, v0, 4, 1                                      ; d6100000 02050900
(invalid instruction)                                        ; d443001a
	v_cndmask_b32_e32 v1, s26, v111, vcc_lo                     ; 0202de1a
	v_add_lshl_u32 v0, s6, v0, 2                                ; d6470000 020a0006
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v0, v0, v110                               ; 4a00dd00
	v_min_i32_e32 v1, v111, v0                                  ; 2202016f
	v_cmp_le_i32_e32 vcc_lo, s9, v0                             ; 7c860009
	s_or_b32 s26, s26, vcc_lo                                   ; 8c1a6a1a
	v_cmp_gt_i32_e32 vcc_lo, 0, v1                              ; 7c880280
	s_nor_b32 exec_lo, vcc_lo, s26                              ; 8f7e1a6a
	s_cbranch_execz BB342                                       ; bfa50363
BB250:
	s_clause 0x2                                                ; bf850002
	s_load_b256 s[24:31], s[0:1], 0xa0                          ; f4006600 f80000a0
	s_load_b128 s[4:7], s[0:1], 0xd0                            ; f4004100 f80000d0
	s_load_b128 s[8:11], s[0:1], 0x50                           ; f4004200 f8000050
	v_cvt_f32_i32_e32 v1, v0                                    ; 7e020b00
	v_cvt_f32_i32_e32 v2, v111                                  ; 7e040b6f
	s_bitcmp1_b32 s13, 0                                        ; bf0d800d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_mov_b32 s12, src_scc                                      ; be8c00fd
	v_dual_add_f32 v2, 0.5, v2 :: v_dual_add_f32 v1, 0.5, v1    ; c90804f0 020002f0
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bfe_u32 s13, s25, 0x2001e                                 ; 930dff19 0002001e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s13, s13, 1                                    ; 800d810d
	s_and_b32 s14, s26, 0x3fff                                  ; 8b0eff1a 00003fff
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl2_add_u32 s14, s14, s13                               ; 878e0d0e
	s_bfe_u32 s15, s25, 0x50019                                 ; 930fff19 00050019
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s14, s14, s15                                    ; 850e0f0e
	s_bfe_u32 s34, s26, 0x10000e                                ; 9322ff1a 0010000e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s34, s34, 1                                    ; 80228122
	s_lshr_b32 s34, s34, s15                                    ; 85220f22
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_max_u32 s14, s14, 1                                       ; 8a8e810e
	s_cmp_eq_i32 s25, 0                                         ; bf008019
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cselect_b32 s14, 0, s14                                   ; 980e0e80
	s_max_u32 s34, s34, 1                                       ; 8aa28122
	s_cmp_eq_i32 s25, 0                                         ; bf008019
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_f32_i32 s14, s14                                      ; be8e640e
	s_cselect_b32 s34, 0, s34                                   ; 98222280
	s_and_b32 s33, s7, -2.0                                     ; 8b21f507
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d684000e
	v_cndmask_b32_e32 v0, s14, v128, vcc_lo                     ; 0201000e
	s_cvt_f32_i32 s34, s34                                      ; bea26422
	s_cmp_eq_i32 s33, -2.0                                      ; bf00f521
(invalid instruction)                                        ; d6840022
	v_cndmask_b32_e32 v0, s34, v128, vcc_lo                     ; 02010022
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_dual_mul_f32 v2, s34, v2 :: v_dual_mul_f32 v1, s14, v1    ; c8c60422 0200020e
	s_and_b32 s34, s12, src_scc                                 ; 8b22fd0c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mov_b32 s35, src_scc                                      ; bea300fd
	s_and_b32 s36, s7, 0x3fffffff                               ; 8b24ff07 3fffffff
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s35, 0                                         ; bf018023
	s_cselect_b32 s7, s36, s7                                   ; 98070724
	image_sample_lz v[4:7], [v1, v2], s[24:31], s[4:7] dmask:0xf dim:SQ_RSRC_IMG_2D ; e7c7c001 02003004 00000201
	s_bitset0_b32 s9, 14                                        ; be89108e
	s_buffer_load_b128 s[4:7], s[8:11], 0x0                     ; f4024104 f8000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_neq_f32 s4, 0                                         ; bf4d8004
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_fma_f32 v8, 0x3e800000, v60, v4 clamp                     ; d6138008 041278ff 3e800000
	v_fma_f32 v9, 0x3e800000, v61, v5 clamp                     ; d6138009 04167aff 3e800000
	v_fma_f32 v10, 0x3e800000, v62, v6 clamp                    ; d613800a 041a7cff 3e800000
	s_cbranch_scc0 BB252                                        ; bfa100d6
BB251:
	s_clause 0x3                                                ; bf850003
	s_load_b256 s[24:31], s[0:1], 0xe0                          ; f4006600 f80000e0
	s_load_b128 s[32:35], s[0:1], 0x110                         ; f4004800 f8000110
	s_load_b256 s[40:47], s[0:1], 0x120                         ; f4006a00 f8000120
	s_load_b128 s[36:39], s[0:1], 0x150                         ; f4004900 f8000150
	s_buffer_load_b128 s[48:51], s[8:11], 0x20                  ; f4024c04 f8000020
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_and_b32 s4, s35, -2.0                                     ; 8b04f523
	v_fma_f32 v3, s48, v1, s50                                  ; d6130003 00ca0230
	v_fma_f32 v11, s49, v2, s51                                 ; d613000b 00ce0431
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_eq_i32 s4, -2.0                                       ; bf00f504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s13, s12, src_scc                                 ; 8b0dfd0c
	s_mov_b32 s14, src_scc                                      ; be8e00fd
	s_and_b32 s15, s35, 0x3fffffff                              ; 8b0fff23 3fffffff
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s14, 0                                         ; bf01800e
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s35, s15, s35                                 ; 9823230f
	image_sample_lz v[12:13], [v3, v11], s[24:31], s[32:35] dmask:0x3 dim:SQ_RSRC_IMG_2D ; e4c7c001 1000300c 00000b03
	s_buffer_load_b64 s[8:9], s[8:11], 0x10                     ; f4022204 f8000010
	s_mov_b32 s24, 0x40200000                                   ; be9800ff 40200000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_add_f32 s25, s8, -0.5                                     ; a019f108
	s_add_f32 s26, s9, -0.5                                     ; a01af109
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_fmac_f32_e32 v2, s6, v13                                  ; 56041a06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_f32 v14, s9, v2, -0.5                                 ; d613000e 03c60409
	v_floor_f32_e32 v14, v14                                    ; 7e1c490e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v15, 0.5, v14                                 ; 061e1cf0
	v_fma_f32 v2, s9, v2, -v15 clamp                            ; d6138002 843e0409
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v16, v2, v2                                   ; 10200502
	v_mul_f32_e32 v17, v16, v2                                  ; 10220510
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d5030002
(invalid instruction)                                        ; 7a022302
	v_fma_f32 v18, 0x3fc00000, v17, 1.0                         ; d6130012 03ca22ff 3fc00000
(invalid instruction)                                        ; d5040011
	v_min_num_f64_e32 v[1:2], v[17:18], v[16:17]                ; 1a022111
(invalid instruction)                                        ; d6840009
	v_cndmask_b32_e32 v0, s9, v128, vcc_lo                      ; 02010009
	s_and_b32 s27, s39, -2.0                                    ; 8b1bf527
	v_dual_add_f32 v2, v16, v2 :: v_dual_fmac_f32 v1, s5, v12   ; c9000510 02001805
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_eq_i32 s27, -2.0                                      ; bf00f51b
	v_fma_f32 v18, -s24, v16, v18                               ; d6130012 244a2018
	s_and_b32 s12, s12, src_scc                                 ; 8b0cfd0c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_sub_f32_e32 v19, 1.0, v2                                  ; 082604f2
	v_fma_f32 v12, s8, v1, -0.5                                 ; d613000c 03c60208
	s_mov_b32 s28, src_scc                                      ; be9c00fd
	s_and_b32 s29, s39, 0x3fffffff                              ; 8b1dff27 3fffffff
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s28, 0                                         ; bf01801c
	v_sub_f32_e32 v19, v19, v18                                 ; 08262513
	v_floor_f32_e32 v12, v12                                    ; 7e18490c
	s_cselect_b32 s39, s29, s39                                 ; 9827271d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_sub_f32_e32 v19, v19, v17                                 ; 08262313
	v_dual_add_f32 v13, 0.5, v12 :: v_dual_add_f32 v18, v18, v19 ; c90818f0 0d122712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1) ; bf8702b1
	v_fma_f32 v1, s8, v1, -v13 clamp                            ; d6138001 84360208
(invalid instruction)                                        ; d6840008
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                      ; 02010008
	v_rcp_f32_e32 v21, v18                                      ; 7e2a5512
	v_dual_fmac_f32 v15, v19, v21 :: v_dual_add_f32 v20, -0.5, v12 ; c8082b13 0f1418f1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_maxmin_num_f32 v15, 0.5, v15, s26                         ; d669000f 006a1ef0
	v_maxmin_num_f32 v20, 0.5, v20, s25                         ; d6690014 006628f0
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_dual_mul_f32 v15, s9, v15 :: v_dual_mul_f32 v20, s8, v20  ; c8c61e09 0f142808
	image_sample_lz v[22:24], [v20, v15], s[40:47], s[36:39] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 12005016 00000f14
	v_mul_f32_e32 v25, v1, v1                                   ; 10320301
	v_dual_add_f32 v12, s24, v12 :: v_dual_add_f32 v29, -0.5, v14 ; c9081818 0c1c1cf1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_mul_f32_e32 v26, v25, v1                                  ; 10340319
	v_maxmin_num_f32 v29, 0.5, v29, s26                         ; d669001d 006a3af0
	v_maxmin_num_f32 v12, 0.5, v12, s25                         ; d669000c 006618f0
(invalid instruction)                                        ; d5030001
(invalid instruction)                                        ; 7a023501
	v_fma_f32 v27, 0x3fc00000, v26, 1.0                         ; d613001b 03ca34ff 3fc00000
(invalid instruction)                                        ; d504001a
	v_min_num_f64_e32 v[1:2], v[26:27], v[25:26]                ; 1a02331a
	v_dual_mul_f32 v12, s8, v12 :: v_dual_mul_f32 v29, s9, v29  ; c8c61808 0c1c3a09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_add_f32_e32 v1, v1, v25                                   ; 06023301
	v_fma_f32 v27, -s24, v25, v27                               ; d613001b 246e3218
	v_sub_f32_e32 v28, 1.0, v1                                  ; 083802f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_f32_e32 v28, v28, v27                                 ; 0838371c
	v_sub_f32_e32 v28, v28, v26                                 ; 0838351c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v27, v27, v28                                 ; 0636391b
	v_rcp_f32_e32 v30, v27                                      ; 7e3c551b
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_dual_add_f32 v14, s24, v14 :: v_dual_fmac_f32 v13, v30, v28 ; c9001c18 0e0c391e
	v_maxmin_num_f32 v14, 0.5, v14, s26                         ; d669000e 006a1cf0
	v_maxmin_num_f32 v13, 0.5, v13, s25                         ; d669000d 00661af0
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v14, s9, v14 :: v_dual_mul_f32 v13, s8, v13  ; c8c61c09 0e0c1a08
	s_clause 0x3                                                ; bf850003
	image_sample_lz v[31:33], [v13, v29], s[40:47], s[36:39] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1200501f 00001d0d
	image_sample_lz v[34:36], [v13, v15], s[40:47], s[36:39] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 12005022 00000f0d
	image_sample_lz v[37:39], [v13, v14], s[40:47], s[36:39] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 12005025 00000e0d
	image_sample_lz v[40:42], [v12, v15], s[40:47], s[36:39] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 12005028 00000f0c
	v_mul_f32_e32 v104, 0x3fb8aa3b, v104                        ; 10d0d0ff 3fb8aa3b
	s_max_num_f32 s7, s7, 0                                     ; a1878007
	v_dual_mul_f32 v26, v26, v18 :: v_dual_mul_f32 v1, v1, v18  ; c8c6251a 1a002501
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_num_f32 s7, s7, 1.0                                   ; a107f207
(invalid instruction)                                        ; d5a50068
	v_min_i32_e32 v0, v104, v128                                ; 22010168
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_add_f32_e32 v104, 1.0, v104                               ; 06d0d0f2
	v_rcp_f32_e32 v104, v104                                    ; 7ed05568
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870155
	v_dual_mul_f32 v2, v2, v27 :: v_dual_mul_f32 v11, s7, v104  ; c8c63702 020ad007
	s_wait_samplecnt 0x4                                        ; bfc20004
	v_dual_mul_f32 v22, v22, v1 :: v_dual_mul_f32 v43, v27, v18 ; c8c60316 162a251b
	v_dual_mul_f32 v24, v24, v1 :: v_dual_mul_f32 v17, v17, v27 ; c8c60318 18103711
	s_wait_samplecnt 0x3                                        ; bfc20003
	v_dual_fmac_f32 v22, v2, v31 :: v_dual_mul_f32 v23, v23, v1 ; c8063f02 16160317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_fmac_f32 v24, v33, v2 :: v_dual_fmac_f32 v23, v32, v2 ; c8000521 18160520
	s_wait_samplecnt 0x2                                        ; bfc20002
	v_dual_fmac_f32 v22, v34, v43 :: v_dual_add_f32 v1, v1, v2  ; c8085722 16000501
	v_dual_add_f32 v1, v1, v43 :: v_dual_fmac_f32 v24, v36, v43 ; c9005701 01185724
	s_wait_samplecnt 0x1                                        ; bfc20001
	v_dual_fmac_f32 v22, v37, v17 :: v_dual_fmac_f32 v23, v35, v43 ; c8002325 16165723
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_fmac_f32 v24, v39, v17 :: v_dual_fmac_f32 v23, v38, v17 ; c8002327 18162326
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_dual_fmac_f32 v22, v40, v26 :: v_dual_add_f32 v1, v1, v17 ; c8083528 16002301
	v_dual_fmac_f32 v24, v42, v26 :: v_dual_add_f32 v1, v1, v26 ; c808352a 18003501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v1, v1                                        ; 7e025501
	v_fma_f32 v22, v22, v1, -v8                                 ; d6130016 84220316
	v_fma_f32 v24, v24, v1, -v10                                ; d6130018 842a0318
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmac_f32 v8, v22, v11 :: v_dual_fmac_f32 v23, v41, v26 ; c8001716 08163529
	v_fma_f32 v23, v23, v1, -v9                                 ; d6130017 84260317
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmac_f32 v10, v11, v24 :: v_dual_fmac_f32 v9, v11, v23 ; c800310b 0a082f0b
	s_branch BB253                                              ; bfa00001
BB252:
	v_mov_b32_e32 v11, 0                                        ; 7e160280
BB253:
	v_sub_f32_e32 v1, v8, v4                                    ; 08020908
	v_dual_sub_f32 v3, v10, v6 :: v_dual_sub_f32 v2, v9, v5     ; c94a0d0a 03020b09
	s_min_num_f32 s4, s3, 1.0                                   ; a104f203
	s_cmp_lt_f32 1.0, s3                                        ; bf4103f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_f32 v12, s4, v1, v4 clamp                             ; d613800c 04120204
	v_fma_f32 v13, s4, v2, v5 clamp                             ; d613800d 04160404
	v_fma_f32 v14, s4, v3, v6 clamp                             ; d613800e 041a0604
	s_cbranch_scc0 BB256                                        ; bfa10026
BB254:
	s_mov_b32 s4, 0x3f371759                                    ; be8400ff 3f371759
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fmaak_f32 v1, s4, v13, 0x3b000000                         ; 5a021a04 3b000000
	v_fmaak_f32 v2, s4, v5, 0x3b000000                          ; 5a040a04 3b000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmamk_f32 v1, v14, 0x3d93dd98, v1                         ; 5802030e 3d93dd98
	v_fmamk_f32 v2, v6, 0x3d93dd98, v2                          ; 58040506 3d93dd98
	v_fmamk_f32 v1, v12, 0x3e59b3d0, v1                         ; 5802030c 3e59b3d0
	v_fmamk_f32 v2, v4, 0x3e59b3d0, v2                          ; 58040504 3e59b3d0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v2, v2                                        ; 7e045502
	v_mul_f32_e32 v1, v1, v2                                    ; 10020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f32_e32 v1, 0x358637bd, v1                        ; 2c0202ff 358637bd
	v_log_f32_e32 v3, v1                                        ; 7e064f01
	v_rcp_f32_e32 v1, v1                                        ; 7e025501
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870096
	v_mul_dx9_zero_f32_e32 v3, s3, v3                           ; 0e060603
	v_exp_f32_e32 v3, v3                                        ; 7e064b03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_maxmin_num_f32 v3, 0.5, v3, 2.0                           ; d6690003 03d206f0
	v_mul_f32_e32 v3, v3, v1                                    ; 10060303
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d508800c
	v_cndmask_b32_e32 v1, v12, v3, vcc_lo                       ; 0202070c
(invalid instruction)                                        ; d508800d
	v_cndmask_b32_e32 v1, v13, v3, vcc_lo                       ; 0202070d
(invalid instruction)                                        ; d508800e
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                       ; 0202070e
BB256:
	s_bfe_u32 s4, s2, 0x2001c                                   ; 9304ff02 0002001c
	s_cbranch_scc0 BB331                                        ; bfa101cc
BB257:
	s_cmp_eq_i32 s4, 1                                          ; bf008104
(invalid instruction)                                        ; d503800c
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                     ; 0201010c
(invalid instruction)                                        ; d503800d
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                     ; 0201010d
(invalid instruction)                                        ; d503800e
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	s_cselect_b32 s5, 0x3f6edb40, 1.0                           ; 9805f2ff 3f6edb40
	s_mul_i32 s6, 0xbe800000, src_scc                           ; 9606fdff be800000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_mul_f32_e32 v12, s5, v12                                  ; 10181805
	s_mov_b32 s8, exec_lo                                       ; be88007e
	v_dual_mul_f32 v14, s5, v14 :: v_dual_mul_f32 v13, s5, v13  ; c8c61c05 0e0c1a05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v2, v12, v12 :: v_dual_fmaak_f32 v1, -2.0, v12, 0x40400000 ; c8c2190c 020018f5 40400000
	v_mul_f32_e32 v15, v14, v14                                 ; 101e1d0e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_f32 v2, v2, v1, -v12                                  ; d6130002 84320302
	v_fma_f32 v2, s6, v2, v12 clamp                             ; d6138002 04320406
	v_dual_mul_f32 v12, v13, v13 :: v_dual_fmaak_f32 v3, -2.0, v13, 0x40400000 ; c8c21b0d 0c021af5 40400000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_f32 v12, v12, v3, -v13                                ; d613000c 8436070c
	v_fma_f32 v12, s6, v12, v13 clamp                           ; d613800c 04361806
	v_fmaak_f32 v13, -2.0, v14, 0x40400000                      ; 5a1a1cf5 40400000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_f32 v15, v15, v13, -v14                               ; d613000f 843a1b0f
	v_fma_f32 v15, s6, v15, v14 clamp                           ; d613800f 043a1e06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_max3_num_f32 v16, v2, v12, v15                            ; d62a0010 043e1902
	v_min3_num_f32 v17, v2, v12, v15                            ; d6290011 043e1902
	v_add_f32_e32 v18, v16, v17                                 ; 06242310
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v19, 0.5, v18                                 ; 102624f0
	v_cmpx_lt_f32_e32 v17, v16                                  ; 7d222111
	s_cbranch_execz BB267                                       ; bfa50027
BB258:
	v_sub_f32_e32 v1, v16, v17                                  ; 08022310
	v_sub_f32_e32 v3, 2.0, v16                                  ; 080620f4
	v_cmp_lt_f32_e32 vcc_lo, 0.5, v19                           ; 7c2226f0
	s_mov_b32 s5, exec_lo                                       ; be85007e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_sub_f32_e32 v3, v3, v17                                   ; 08062303
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v3, v18, v3, vcc_lo                       ; 02060712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v3, v3                                        ; 7e065503
	v_mul_f32_e32 v3, v1, v3                                    ; 10060701
	v_cmpx_eq_f32_e32 v16, v2                                   ; 7d240510
BB259:
	v_sub_f32_e32 v2, v12, v15                                  ; 08041f0c
	v_rcp_f32_e32 v1, v1                                        ; 7e025501
	v_cmp_lt_f32_e32 vcc_lo, v12, v15                           ; 7c221f0c
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v12, 0, 0x40c00000, vcc_lo                ; d501000c 01a9fe80 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v12, v2, v1                                  ; 56180302
	v_mul_f32_e32 v12, 0x3e2aaaab, v12                          ; 101818ff 3e2aaaab
	s_and_not1_b32 exec_lo, s5, exec_lo                         ; 917e7e05
BB262:
	v_rcp_f32_e32 v1, v1                                        ; 7e025501
	v_dual_sub_f32 v15, v15, v2 :: v_dual_sub_f32 v2, v2, v12   ; c94a050f 0f021902
	v_cmp_eq_f32_e32 vcc_lo, v16, v12                           ; 7c241910
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)    ; bf870105
	v_fma_f32 v2, v2, v1, 4.0                                   ; d6130002 03da0302
	v_fma_f32 v15, v15, v1, 2.0                                 ; d613000f 03d2030f
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cndmask_b32_e32 v2, v2, v15, vcc_lo                       ; 02041f02
	v_mul_f32_e32 v12, 0x3e2aaaab, v2                           ; 101804ff 3e2aaaab
BB264:
	s_mov_b32 exec_lo, s5                                       ; befe0005
BB267:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 exec_lo, s8, exec_lo                         ; 917e7e08
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v3, 0               ; ca100080 0c020080
BB269:
	s_mov_b32 exec_lo, s8                                       ; befe0008
	s_cmp_eq_i32 s4, 1                                          ; bf008104
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s5, 0x3f666666, 1.0                           ; 9805f2ff 3f666666
	s_cmp_eq_i32 s4, 2                                          ; bf008204
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cselect_b32 s5, 0x3f59999a, s5                            ; 980505ff 3f59999a
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d5088003
	v_cndmask_b32_e32 v1, s5, v3, vcc_lo                        ; 02020605
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_lt_f32_e32 0, v3                                     ; 7d220680
	s_cbranch_execz BB291                                       ; bfa50082
BB270:
	v_add_f32_e32 v1, 1.0, v3                                   ; 060206f2
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v19                           ; 7c2826f0
	v_add_f32_e32 v13, 0x3eaaaaab, v12                          ; 061a18ff 3eaaaaab
	s_mov_b32 s4, exec_lo                                       ; be84007e
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_dual_mul_f32 v1, v19, v1 :: v_dual_add_f32 v2, v19, v3    ; c8c80313 01020713
	v_fma_f32 v3, -v19, v3, v2                                  ; d6130003 240a0713
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cndmask_b32_e32 v3, v3, v1, vcc_lo                        ; 02060303
	v_cmp_gt_f32_e32 vcc_lo, 0, v13                             ; 7c281a80
	v_sub_f32_e32 v19, v18, v3                                  ; 08260712
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v14, 0, 1.0, vcc_lo                       ; d501000e 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v13, v13, v14                                 ; 061a1d0d
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v13                           ; 7c221af2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v15, 0, 1.0, vcc_lo                       ; d501000f 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_f32_e32 v13, v13, v15                                 ; 081a1f0d
	v_cmpx_gt_f32_e32 0x3e2aaaab, v13                           ; 7d281aff 3e2aaaab
BB271:
	v_sub_f32_e32 v1, v3, v19                                   ; 08022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v1, 0x40c00000, v1                            ; 100202ff 40c00000
	v_fma_f32 v13, v13, v1, v19                                 ; d613000d 044e030d
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB274:
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_sub_f32_e32 v2, 0x3f2aaaab, v13                           ; 08041aff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v13                    ; 7c281aff 3f2aaaab
	v_dual_mul_f32 v2, 0x40c00000, v2 :: v_dual_sub_f32 v1, v3, v19 ; c8ca04ff 02002703 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_f32 v2, v2, v1, v19                                   ; d6130002 044e0302
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v2, v19, v2, vcc_lo                       ; 02040513
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v13                           ; 7c281af0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v13, v2, v3, vcc_lo                       ; 021a0702
BB276:
	s_mov_b32 exec_lo, s4                                       ; befe0004
	v_cmp_gt_f32_e32 vcc_lo, 0, v12                             ; 7c281880
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v1, 0, 1.0, vcc_lo                        ; d5010001 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v1, v12, v1                                   ; 0602030c
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v1                            ; 7c2202f2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v2, 0, 1.0, vcc_lo                        ; d5010002 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_f32_e32 v1, v1, v2                                    ; 08020501
	v_cmpx_gt_f32_e32 0x3e2aaaab, v1                            ; 7d2802ff 3e2aaaab
BB277:
	v_sub_f32_e32 v2, v3, v19                                   ; 08042703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v2, 0x40c00000, v2                            ; 100404ff 40c00000
	v_fma_f32 v1, v1, v2, v19                                   ; d6130001 044e0501
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB280:
	v_sub_f32_e32 v2, v3, v19                                   ; 08042703
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_sub_f32_e32 v14, 0x3f2aaaab, v1                           ; 081c02ff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v1                     ; 7c2802ff 3f2aaaab
	v_mul_f32_e32 v14, 0x40c00000, v14                          ; 101c1cff 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_f32 v14, v14, v2, v19                                 ; d613000e 044e050e
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v14, v19, v14, vcc_lo                     ; 021c1d13
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v1                            ; 7c2802f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                       ; 0202070e
BB282:
	s_mov_b32 exec_lo, s4                                       ; befe0004
	v_add_f32_e32 v12, 0xbeaaaaab, v12                          ; 061818ff beaaaaab
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_gt_f32_e32 vcc_lo, 0, v12                             ; 7c281880
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v2, 0, 1.0, vcc_lo                        ; d5010002 01a9e480
	v_add_f32_e32 v12, v12, v2                                  ; 0618050c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v12                           ; 7c2218f2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v14, 0, 1.0, vcc_lo                       ; d501000e 01a9e480
	v_sub_f32_e32 v12, v12, v14                                 ; 08181d0c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_gt_f32_e32 0x3e2aaaab, v12                           ; 7d2818ff 3e2aaaab
BB283:
	v_sub_f32_e32 v3, v3, v19                                   ; 08062703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v3, 0x40c00000, v3                            ; 100606ff 40c00000
	v_fmac_f32_e32 v19, v12, v3                                 ; 5626070c
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB286:
	v_sub_f32_e32 v14, 0x3f2aaaab, v12                          ; 081c18ff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v12                    ; 7c2818ff 3f2aaaab
	v_sub_f32_e32 v2, v3, v19                                   ; 08042703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_mul_f32_e32 v14, 0x40c00000, v14                          ; 101c1cff 40c00000
	v_fma_f32 v14, v14, v2, v19                                 ; d613000e 044e050e
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cndmask_b32_e32 v19, v19, v14, vcc_lo                     ; 02261d13
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v12                           ; 7c2818f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v19, v19, v3, vcc_lo                      ; 02260713
BB288:
	s_mov_b32 exec_lo, s4                                       ; befe0004
BB291:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 exec_lo, s8, exec_lo                         ; 917e7e08
	v_mov_b32_e32 v1, v19                                       ; 7e020313
	v_mov_b32_e32 v13, v19                                      ; 7e1a0313
BB293:
	s_mov_b32 exec_lo, s8                                       ; befe0008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_max3_num_f32 v2, v13, v1, v19                             ; d62a0002 044e030d
	v_min3_num_f32 v3, v13, v1, v19                             ; d6290003 044e030d
	v_add_f32_e32 v12, v2, v3                                   ; 06180702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v14, 0.5, v12                                 ; 101c18f0
	v_cmpx_lt_f32_e32 v3, v2                                    ; 7d220503
	s_cbranch_execz BB303                                       ; bfa50027
BB294:
	v_sub_f32_e32 v16, 2.0, v2                                  ; 082004f4
	v_cmp_lt_f32_e32 vcc_lo, 0.5, v14                           ; 7c221cf0
	s_mov_b32 s4, exec_lo                                       ; be84007e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_sub_f32_e32 v16, v16, v3                                  ; 08200710
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_dual_cndmask_b32 v16, v12, v16 :: v_dual_sub_f32 v15, v2, v3 ; ca4a210c 100e0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v16, v16                                      ; 7e205510
	v_mul_f32_e32 v16, v15, v16                                 ; 1020210f
	v_cmpx_eq_f32_e32 v2, v13                                   ; 7d241b02
BB295:
	v_sub_f32_e32 v2, v1, v19                                   ; 08042701
	v_rcp_f32_e32 v15, v15                                      ; 7e1e550f
	v_cmp_lt_f32_e32 vcc_lo, v1, v19                            ; 7c222701
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v3, 0, 0x40c00000, vcc_lo                 ; d5010003 01a9fe80 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v3, v2, v15                                  ; 56061f02
	v_mul_f32_e32 v3, 0x3e2aaaab, v3                            ; 100606ff 3e2aaaab
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB298:
	v_sub_f32_e32 v19, v19, v13                                 ; 08261b13
	v_sub_f32_e32 v13, v13, v1                                  ; 081a030d
	v_rcp_f32_e32 v15, v15                                      ; 7e1e550f
	v_cmp_eq_f32_e32 vcc_lo, v2, v1                             ; 7c240302
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b5
	v_fma_f32 v13, v13, v15, 4.0                                ; d613000d 03da1f0d
	v_fma_f32 v19, v19, v15, 2.0                                ; d6130013 03d21f13
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v13, v13, v19, vcc_lo                     ; 021a270d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v3, 0x3e2aaaab, v13                           ; 10061aff 3e2aaaab
BB300:
	s_mov_b32 exec_lo, s4                                       ; befe0004
BB303:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 exec_lo, s8, exec_lo                         ; 917e7e08
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v3, 0               ; ca100080 10020080
BB305:
	s_mov_b32 exec_lo, s8                                       ; befe0008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5038010
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
	v_cmpx_lt_f32_e32 0, v16                                    ; 7d222080
	s_cbranch_execz BB327                                       ; bfa50083
BB306:
	v_add_f32_e32 v1, 1.0, v16                                  ; 060220f2
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v14                           ; 7c281cf0
	s_mov_b32 s4, exec_lo                                       ; be84007e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_mul_f32 v1, v14, v1 :: v_dual_add_f32 v2, v14, v16   ; c8c8030e 0102210e
	v_fma_f32 v16, -v14, v16, v2                                ; d6130010 240a210e
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cndmask_b32_e32 v16, v16, v1, vcc_lo                      ; 02200310
	v_sub_f32_e32 v14, v12, v16                                 ; 081c210c
	v_add_f32_e32 v12, 0x3eaaaaab, v3                           ; 061806ff 3eaaaaab
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_gt_f32_e32 vcc_lo, 0, v12                             ; 7c281880
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v13, 0, 1.0, vcc_lo                       ; d501000d 01a9e480
	v_add_f32_e32 v12, v12, v13                                 ; 06181b0c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v12                           ; 7c2218f2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v15, 0, 1.0, vcc_lo                       ; d501000f 01a9e480
	v_sub_f32_e32 v12, v12, v15                                 ; 08181f0c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_gt_f32_e32 0x3e2aaaab, v12                           ; 7d2818ff 3e2aaaab
BB307:
	v_sub_f32_e32 v1, v16, v14                                  ; 08021d10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v1, 0x40c00000, v1                            ; 100202ff 40c00000
	v_fma_f32 v12, v12, v1, v14                                 ; d613000c 043a030c
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB310:
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_sub_f32_e32 v2, 0x3f2aaaab, v12                           ; 080418ff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v12                    ; 7c2818ff 3f2aaaab
	v_dual_mul_f32 v2, 0x40c00000, v2 :: v_dual_subrev_f32 v1, v14, v16 ; c8cc04ff 0200210e 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_f32 v2, v2, v1, v14                                   ; d6130002 043a0302
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v2, v14, v2, vcc_lo                       ; 0204050e
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v12                           ; 7c2818f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v12, v2, v16, vcc_lo                      ; 02182102
BB312:
	s_mov_b32 exec_lo, s4                                       ; befe0004
	v_cmp_gt_f32_e32 vcc_lo, 0, v3                              ; 7c280680
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v1, 0, 1.0, vcc_lo                        ; d5010001 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v1, v3, v1                                    ; 06020303
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v1                            ; 7c2202f2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v2, 0, 1.0, vcc_lo                        ; d5010002 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_f32_e32 v1, v1, v2                                    ; 08020501
	v_cmpx_gt_f32_e32 0x3e2aaaab, v1                            ; 7d2802ff 3e2aaaab
BB313:
	v_sub_f32_e32 v2, v16, v14                                  ; 08041d10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v2, 0x40c00000, v2                            ; 100404ff 40c00000
	v_fma_f32 v1, v1, v2, v14                                   ; d6130001 043a0501
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB316:
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_sub_f32_e32 v13, 0x3f2aaaab, v1                           ; 081a02ff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v1                     ; 7c2802ff 3f2aaaab
	v_dual_mul_f32 v13, 0x40c00000, v13 :: v_dual_sub_f32 v2, v16, v14 ; c8ca1aff 0d021d10 40c00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_f32 v13, v13, v2, v14                                 ; d613000d 043a050d
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v13, v14, v13, vcc_lo                     ; 021a1b0e
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v1                            ; 7c2802f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v1, v13, v16, vcc_lo                      ; 0202210d
BB318:
	s_mov_b32 exec_lo, s4                                       ; befe0004
	v_add_f32_e32 v3, 0xbeaaaaab, v3                            ; 060606ff beaaaaab
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_gt_f32_e32 vcc_lo, 0, v3                              ; 7c280680
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v2, 0, 1.0, vcc_lo                        ; d5010002 01a9e480
	v_add_f32_e32 v3, v3, v2                                    ; 06060503
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_cmp_lt_f32_e32 vcc_lo, 1.0, v3                            ; 7c2206f2
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v13, 0, 1.0, vcc_lo                       ; d501000d 01a9e480
	v_sub_f32_e32 v3, v3, v13                                   ; 08061b03
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_gt_f32_e32 0x3e2aaaab, v3                            ; 7d2806ff 3e2aaaab
BB319:
	v_sub_f32_e32 v16, v16, v14                                 ; 08201d10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v16, 0x40c00000, v16                          ; 102020ff 40c00000
	v_fmac_f32_e32 v14, v3, v16                                 ; 561c2103
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
BB322:
	v_sub_f32_e32 v13, 0x3f2aaaab, v3                           ; 081a06ff 3f2aaaab
	v_cmp_gt_f32_e32 vcc_lo, 0x3f2aaaab, v3                     ; 7c2806ff 3f2aaaab
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_mul_f32 v13, 0x40c00000, v13 :: v_dual_sub_f32 v2, v16, v14 ; c8ca1aff 0d021d10 40c00000
	v_fma_f32 v13, v13, v2, v14                                 ; d613000d 043a050d
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cndmask_b32_e32 v14, v14, v13, vcc_lo                     ; 021c1b0e
	v_cmp_gt_f32_e32 vcc_lo, 0.5, v3                            ; 7c2806f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v14, v14, v16, vcc_lo                     ; 021c210e
BB324:
	s_mov_b32 exec_lo, s4                                       ; befe0004
BB327:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 exec_lo, s8, exec_lo                         ; 917e7e08
	v_dual_mov_b32 v12, v14 :: v_dual_mov_b32 v1, v14           ; ca10010e 0c00010e
BB329:
	s_mov_b32 exec_lo, s8                                       ; befe0008
	s_max_num_f32 s3, s3, 0                                     ; a1838003
(invalid instruction)                                        ; d503800e
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d503800c
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                     ; 0201010c
(invalid instruction)                                        ; d5038001
	v_cndmask_b32_e32 v0, v1, v128, vcc_lo                      ; 02010101
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_num_f32 s3, s3, 1.0                                   ; a103f203
	v_sub_f32_e32 v12, v12, v4                                  ; 0818090c
	v_dual_sub_f32 v14, v14, v6 :: v_dual_sub_f32 v1, v1, v5    ; c94a0d0e 0e000b01
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_fma_f32 v12, s3, v12, v4 clamp                            ; d613800c 04121803
	v_fma_f32 v13, s3, v1, v5 clamp                             ; d613800d 04160203
	v_fma_f32 v14, s3, v14, v6 clamp                            ; d613800e 041a1c03
BB331:
	s_cmp_lt_i32 s2, 0                                          ; bf048002
	s_cbranch_scc0 BB336                                        ; bfa1002c
BB332:
	s_bitcmp1_b32 s2, 30                                        ; bf0d9e02
	s_cbranch_scc0 BB337                                        ; bfa1002b
BB333:
(invalid instruction)                                        ; d503800c
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                     ; 0201010c
(invalid instruction)                                        ; d503800d
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                     ; 0201010d
(invalid instruction)                                        ; d503800e
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_mul_f32_e32 v12, 0x437f0000, v12                          ; 101818ff 437f0000
	v_dual_mul_f32 v14, 0x437f0000, v14 :: v_dual_mul_f32 v13, 0x437f0000, v13 ; c8c61cff 0e0c1aff 437f0000
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_fract_f32_e32 v1, v12                                     ; 7e02410c
	v_floor_f32_e32 v12, v12                                    ; 7e18490c
	v_floor_f32_e32 v3, v13                                     ; 7e06490d
	v_fract_f32_e32 v13, v13                                    ; 7e1a410d
	v_floor_f32_e32 v5, v14                                     ; 7e0a490e
	v_fract_f32_e32 v14, v14                                    ; 7e1c410e
	v_cmp_le_f32_e32 vcc_lo, 0.5, v1                            ; 7c2602f0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v2, 0, 1.0, vcc_lo                        ; d5010002 01a9e480
	v_cmp_le_f32_e32 vcc_lo, 0.5, v13                           ; 7c261af0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v4, 0, 1.0, vcc_lo                        ; d5010004 01a9e480
	v_cmp_le_f32_e32 vcc_lo, 0.5, v14                           ; 7c261cf0
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e64 v6, 0, 1.0, vcc_lo                        ; d5010006 01a9e480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_add_f32 v5, v6, v5 :: v_dual_add_f32 v12, v12, v2    ; c9080b06 050c050c
	v_dual_mul_f32 v14, 0x3b808081, v5 :: v_dual_add_f32 v3, v3, v4 ; c8c80aff 0e020903 3b808081
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v13, 0x3b808081, v3 :: v_dual_mul_f32 v12, 0x3b808081, v12 ; c8c606ff 0d0c18ff 3b808081
	s_branch BB337                                              ; bfa00001
BB336:
	v_mov_b32_e32 v7, 1.0                                       ; 7e0e02f2
BB337:
	s_load_b256 s[0:7], s[0:1], 0x80                            ; f4006000 f8000080
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mov_b32_e32 v15, v7                                       ; 7e1e0307
	image_store v[12:15], [v0, v111], s[16:23] dmask:0xf dim:SQ_RSRC_IMG_2D ; d3c18001 0000200c 00006f00
	s_wait_kmcnt 0x0                                            ; bfc70000
	image_store v[8:11], [v0, v111], s[0:7] dmask:0xf dim:SQ_RSRC_IMG_2D ; d3c18001 00000008 00006f00
BB342:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
