BB0:
	s_cmp_lg_i32 s10, -1                                        ; bf01c10a
	s_cbranch_scc0 BB2                                          ; bfa1000f
BB1:
	s_mov_b32 s14, s0                                           ; be8e0000
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b128 s[16:19], s[14:15], 0x30                        ; f4004407 f8000030
	s_lshl2_add_u32 s13, s10, 24                                ; 878d980a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s13, s[16:19], s13 offset:0x0             ; f4020348 1a000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s13, 0x54434852                                ; bf01ff0d 54434852
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s13, vcc_lo, exec_lo                              ; 8b0d7e6a
	s_cselect_b32 s10, -1, s10                                  ; 980a0ac1
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s10, -1                                        ; bf01c10a
	s_cbranch_scc0 BB5                                          ; bfa1000b
BB4:
	s_mov_b32 s14, s0                                           ; be8e0000
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b128 s[16:19], s[14:15], 0x30                        ; f4004407 f8000030
	s_mov_b32 s13, src_scc                                      ; be8d00fd
	s_lshl2_add_u32 s14, s10, 12                                ; 878e8c0a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s14, s[16:19], s14 offset:0x0             ; f4020388 1c000000
	s_branch BB6                                                ; bfa00002
BB5:
	s_mov_b32 s13, src_scc                                      ; be8d00fd
	s_mov_b32 s14, -1                                           ; be8e00c1
BB6:
	s_mov_b32 s15, ttmp9                                        ; be8f0075
	s_mov_b32 s16, ttmp7                                        ; be900073
	s_cmp_lg_i32 s9, 0                                          ; bf018009
	s_cbranch_scc0 BB9                                          ; bfa1004c
BB7:
	s_mul_i32 s15, s11, ttmp7                                   ; 960f730b
	s_mul_i32 s16, s9, s12                                      ; 96100c09
	s_add_co_u32 s15, ttmp9, s15                                ; 800f0f75
	s_cvt_f32_u32 s17, s16                                      ; be916510
(invalid instruction)                                        ; d6840011
	v_cndmask_b32_e32 v0, s17, v128, vcc_lo                     ; 02010011
	s_mul_f32 s17, s17, 0x4f7ffffe                              ; a211ff11 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s17, s17                                      ; be916711
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s18, s16, s17                                     ; 96121110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s18, 0, s18                                    ; 81921280
	s_mul_hi_u32 s18, s17, s18                                  ; 96921211
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s17, s17, s18                                  ; 80111211
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s17, s15, s17                                  ; 9691110f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s19, s17, s16                                     ; 96131011
	s_sub_co_i32 s19, s15, s19                                  ; 8193130f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s20, s19, s16                                  ; 80941013
	s_absdiff_i32 s22, src_scc, 1                               ; 831681fd
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_add_co_u32 s17, s17, s22                                  ; 80111611
	s_sub_co_u32 s20, s19, s16                                  ; 80941013
	s_cselect_b32 s19, s19, s20                                 ; 98131413
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_ge_u32 s19, s16                                       ; bf091013
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s17, src_scc                              ; 8011fd11
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s17, s17, s9                                      ; 96110911
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s11, s11, s17                                  ; 818b110b
	s_mul_i32 s12, s17, s12                                     ; 960c0c11
	s_min_u32 s9, s9, s11                                       ; 89890b09
	s_sub_co_i32 s15, s15, s12                                  ; 818f0c0f
	s_cvt_f32_u32 s23, s9                                       ; be976509
(invalid instruction)                                        ; d6840017
	v_cndmask_b32_e32 v0, s23, v128, vcc_lo                     ; 02010017
	s_mul_f32 s23, s23, 0x4f7ffffe                              ; a217ff17 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s23, s23                                      ; be976717
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s24, s9, s23                                      ; 96181709
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s24, 0, s24                                    ; 81981880
	s_mul_hi_u32 s24, s23, s24                                  ; 96981817
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s23, s23, s24                                  ; 80171817
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s23, s15, s23                                  ; 9697170f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s25, s23, s9                                      ; 96190917
	s_sub_co_i32 s15, s15, s25                                  ; 818f190f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s26, s15, s9                                   ; 809a090f
	s_absdiff_i32 s28, src_scc, 1                               ; 831c81fd
	s_sub_co_u32 s26, s15, s9                                   ; 809a090f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s15, s15, s26                                 ; 980f1a0f
	s_sub_co_u32 s9, s15, s9                                    ; 8089090f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mov_b32 s29, src_scc                                      ; be9d00fd
	s_absdiff_i32 s30, src_scc, 1                               ; 831e81fd
	s_cmp_lg_i32 s29, 0                                         ; bf01801d
	s_cselect_b32 s15, s15, s9                                  ; 980f090f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s15, s17, s15                                  ; 800f0f11
	s_add_co_u32 s23, s23, s28                                  ; 80171c17
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s23, s30                                  ; 80101e17
BB9:
	s_cmp_lg_i32 s13, 0                                         ; bf01800d
	s_cbranch_scc0 BB11                                         ; bfa1000e
BB10:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[20:23], s[12:13], 0x30                        ; f4004506 f8000030
	s_lshl2_add_u32 s9, s10, 8                                  ; 8789880a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_buffer_load_b32 s9, s[20:23], s9 offset:0x0               ; f402024a 12000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s9, -1                                         ; bf01c109
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB12                                               ; bfa00001
BB11:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB12:
	s_lshl_b32 s15, s15, 6                                      ; 840f860f
	s_and_b32 s9, vcc_lo, exec_lo                               ; 8b097e6a
	s_cbranch_scc0 BB47                                         ; bfa1005f
BB13:
	s_and_b32 s9, ttmp8, 0x3e000000                             ; 8b09ff74 3e000000
	s_cbranch_scc1 BB45                                         ; bfa2005a
BB14:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[20:23], s[12:13], 0x30                        ; f4004506 f8000030
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s11, s10, 8                                    ; 800b880a
	s_add_co_u32 s17, s10, 16                                   ; 8011900a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_clause 0x2                                                ; bf850002
	s_buffer_load_b32 s9, s[20:23], s10 offset:0x0              ; f402024a 14000000
	s_buffer_load_b32 s11, s[20:23], s11 offset:0x0             ; f40202ca 16000000
	s_buffer_load_b32 s17, s[20:23], s17 offset:0x0             ; f402044a 22000000
	s_load_b128 s[24:27], s[12:13], 0x0                         ; f4004606 f8000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s17, s17, 2                                      ; 84118211
	buffer_load_b32 v1, off, s[24:27], s17 scope:SCOPE_DEV      ; c4050011 00883001 00000000
	s_lshr_b32 s18, s15, 4                                      ; 8512840f
	s_bfm_b64 s[12:13], 1, 16                                   ; 958c9081
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s19, v1                                 ; 7e260501
BB15:
	s_add_co_u32 s17, s18, s13                                  ; 80110d12
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s11, s17                                  ; 8011110b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s17, s17, 2                                      ; 84118211
	s_buffer_load_b32 s17, s[20:23], s17 offset:0x0             ; f402044a 22000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s17, -1                                        ; bf01c111
	s_cbranch_scc0 BB25                                         ; bfa10019
BB16:
	s_branch BB17                                               ; bfa00001
BB22:
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
BB17:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s12, 0                                         ; bf01800c
	s_cbranch_scc0 BB19                                         ; bfa10010
BB18:
	s_and_b32 s28, s17, 0xfffff                                 ; 8b1cff11 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s28, s9, s28                                   ; 801c1c09
	s_lshl_b32 s28, s28, 2                                      ; 841c821c
	buffer_load_b32 v1, off, s[24:27], s28 scope:SCOPE_DEV      ; c405001c 00883001 00000000
	s_lshr_b32 s29, s17, 20                                     ; 851d9411
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s29, s29, s19                                     ; 961d131d
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s30, v1                                 ; 7e3c0501
	s_cmp_lt_u32 s30, s29                                       ; bf0a1d1e
	s_cselect_b32 s31, -1, 0                                    ; 981f80c1
	s_branch BB20                                               ; bfa00001
BB19:
	s_mov_b32 s31, 0                                            ; be9f0080
BB20:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s31, exec_lo, s31                            ; 911f1f7e
	s_cbranch_scc0 BB22                                         ; bfa1ffe8
BB25:
	s_add_co_u32 s13, s13, 1                                    ; 800d810d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_ge_u32 s13, 4                                         ; bf09840d
	s_cbranch_scc0 BB15                                         ; bfa1ffd9
BB28:
	s_cmp_eq_i32 s12, 0                                         ; bf00800c
	s_cbranch_scc0 BB30                                         ; bfa10002
BB29:
	s_mov_b32 s9, 1                                             ; be890081
	s_branch BB31                                               ; bfa00001
BB30:
	s_mov_b32 s9, 0                                             ; be890080
BB31:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mov_b32 exec_lo, s9                                       ; befe0009
	s_cbranch_execz BB43                                        ; bfa5000e
BB32:
	s_ctz_i32_b32 s9, exec_lo                                   ; be89087e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s9, 1, s9                                        ; 84090981
	s_and_saveexec_b32 s9, s9                                   ; be892009
	s_cbranch_execz BB43                                        ; bfa50009
BB33:
	s_add_co_u32 s10, s10, 20                                   ; 800a940a
	s_buffer_load_b32 s10, s[20:23], s10 offset:0x0             ; f402028a 14000000
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	buffer_atomic_max_u32 v1, off, s[24:27], s10                ; c40ec00a 00803001 00000000
BB43:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
BB45:
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
BB47:
	v_and_b32_e32 v3, 31, v0                                    ; 3606009f
	v_and_b32_e32 v7, 15, v0                                    ; 360e008f
	s_lshr_b32 s9, s8, 4                                        ; 85098408
	s_lshr_b32 s10, s15, 4                                      ; 850a840f
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshlrev_b32_e32 v4, 2, v3                                 ; 30080682
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	s_mul_i32 s11, s10, s9                                      ; 960b090a
	v_lshlrev_b32_e32 v8, 4, v7                                 ; 30100e84
	s_lshl_b32 s11, s11, 8                                      ; 840b880b
	s_add_co_u32 s12, 16, s15                                   ; 800c0f90
	v_bfe_u32 v1, v0, 5, 1                                      ; d6100001 02050b00
	v_lshlrev_b32_e32 v3, 3, v3                                 ; 30060683
	s_lshr_b32 s13, s12, 4                                      ; 850d840c
	v_add3_u32 v9, v8, s1, s11                                  ; d6550009 002c0308
	s_mul_i32 s17, s13, s9                                      ; 9611090d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s17, s17, 8                                      ; 84118811
	s_add_co_u32 s18, 32, s15                                   ; 80120fa0
	v_add_nc_u32_e32 v9, v9, v3                                 ; 4a120709
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v10, v8, s1, s17                                 ; d655000a 00440308
	s_lshr_b32 s19, s18, 4                                      ; 85138412
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_mul_i32 s20, s19, s9                                      ; 96140913
	v_add_nc_u32_e32 v10, v10, v3                               ; 4a14070a
	s_lshl_b32 s20, s20, 8                                      ; 84148814
	s_add_co_u32 s21, 48, s15                                   ; 80150fb0
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v16, 0              ; ca100080 11100080
	v_add3_u32 v11, v8, s1, s20                                 ; d655000b 00500308
	s_lshr_b32 s22, s21, 4                                      ; 85168415
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s23, s22, s9                                      ; 96170916
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0              ; ca100080 18180080
	v_add_nc_u32_e32 v11, v11, v3                               ; 4a16070b
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0              ; ca100080 1c1c0080
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s23, s23, 8                                      ; 84178817
	s_lshl_b32 s16, s16, 7                                      ; 84108710
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_lshr_b32 s24, s8, 7                                       ; 85188708
	v_lshrrev_b32_e32 v9, 2, v9                                 ; 32121282
	v_lshrrev_b32_e32 v10, 2, v10                               ; 32141482
	v_lshrrev_b32_e32 v11, 2, v11                               ; 32161682
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v8, v8, s1, s23                                  ; d6550008 005c0308
	s_mov_b32 s1, 0                                             ; be810080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_lshl_add_u32 v1, v1, 6, s16                               ; d6460001 00410d01
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_add_nc_u32_e32 v8, v8, v3                                 ; 4a100708
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_add_nc_u32_e32 v5, 32, v1                                 ; 4a0a02a0
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	v_lshrrev_b32_e32 v2, 5, v1                                 ; 32040285
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v60, 0              ; ca100080 3d3c0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v62, 0              ; ca100080 3f3e0080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v64, 0              ; ca100080 41400080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0              ; ca100080 43420080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v68, 0              ; ca100080 45440080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v70, 0              ; ca100080 47460080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v72, 0              ; ca100080 49480080
	v_lshrrev_b32_e32 v8, 2, v8                                 ; 32101082
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v74, 0              ; ca100080 4b4a0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v76, 0              ; ca100080 4d4c0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v78, 0              ; ca100080 4f4e0080
	v_lshrrev_b32_e32 v6, 5, v5                                 ; 320c0a85
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v80, 0              ; ca100080 51500080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v82, 0              ; ca100080 53520080
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                        ; 02001302
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v84, 0              ; ca100080 55540080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v86, 0              ; ca100080 57560080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v88, 0              ; ca100080 59580080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v90, 0              ; ca100080 5b5a0080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v92, 0              ; ca100080 5d5c0080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v94, 0              ; ca100080 5f5e0080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v96, 0              ; ca100080 61600080
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v98, 0              ; ca100080 63620080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v100, 0            ; ca100080 65640080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v102, 0            ; ca100080 67660080
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v104, 0            ; ca100080 69680080
	v_dual_mov_b32 v107, 0 :: v_dual_mov_b32 v106, 0            ; ca100080 6b6a0080
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v6, v9, vcc_lo                        ; 02001306
	v_dual_mov_b32 v109, 0 :: v_dual_mov_b32 v108, 0            ; ca100080 6d6c0080
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v110, 0            ; ca100080 6f6e0080
	v_dual_mov_b32 v113, 0 :: v_dual_mov_b32 v112, 0            ; ca100080 71700080
	v_dual_mov_b32 v115, 0 :: v_dual_mov_b32 v114, 0            ; ca100080 73720080
	v_dual_mov_b32 v117, 0 :: v_dual_mov_b32 v116, 0            ; ca100080 75740080
	v_dual_mov_b32 v119, 0 :: v_dual_mov_b32 v118, 0            ; ca100080 77760080
	v_dual_mov_b32 v121, 0 :: v_dual_mov_b32 v120, 0            ; ca100080 79780080
	v_dual_mov_b32 v123, 0 :: v_dual_mov_b32 v122, 0            ; ca100080 7b7a0080
	v_dual_mov_b32 v125, 0 :: v_dual_mov_b32 v124, 0            ; ca100080 7d7c0080
	v_lshl_add_u32 v2, v2, 7, s4                                ; d6460002 00110f02
	v_dual_mov_b32 v127, 0 :: v_dual_mov_b32 v126, 0            ; ca100080 7f7e0080
	v_dual_mov_b32 v129, 0 :: v_dual_mov_b32 v128, 0            ; ca100080 81800080
	v_dual_mov_b32 v131, 0 :: v_dual_mov_b32 v130, 0            ; ca100080 83820080
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v132, 0            ; ca100080 85840080
	v_dual_mov_b32 v135, 0 :: v_dual_mov_b32 v134, 0            ; ca100080 87860080
	v_dual_mov_b32 v137, 0 :: v_dual_mov_b32 v136, 0            ; ca100080 89880080
	v_dual_mov_b32 v139, 0 :: v_dual_mov_b32 v138, 0            ; ca100080 8b8a0080
	v_dual_mov_b32 v141, 0 :: v_dual_mov_b32 v140, 0            ; ca100080 8d8c0080
	v_dual_mov_b32 v143, 0 :: v_dual_mov_b32 v142, 0            ; ca100080 8f8e0080
	v_lshl_add_u32 v6, v6, 7, s4                                ; d6460006 00110f06
	s_branch BB48                                               ; bfa001d3
BB50:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[28:31], s[16:17], 0x70                        ; f4004708 f8000070
	s_load_b128 s[32:35], s[16:17], 0x30                        ; f4004808 f8000030
	s_lshl_b32 s4, s1, 7                                        ; 84048701
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s4, s4, 4                                        ; 85048404
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s9, s4, 8                                        ; 84098804
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s9, s9, 2                                        ; 85098209
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v3, s9, v9, 2                                ; d6470003 020a1209
	v_add_lshl_u32 v12, s9, v10, 2                              ; d647000c 020a1409
	v_add_lshl_u32 v13, s9, v11, 2                              ; d647000d 020a1609
	v_add_lshl_u32 v14, s9, v8, 2                               ; d647000e 020a1009
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[144:145], v3, s[28:31], null offen        ; c405407c 40803890 00000003
	buffer_load_b64 v[146:147], v12, s[28:31], null offen       ; c405407c 40803892 0000000c
	buffer_load_b64 v[148:149], v13, s[28:31], null offen       ; c405407c 40803894 0000000d
	buffer_load_b64 v[150:151], v14, s[28:31], null offen       ; c405407c 40803896 0000000e
	s_lshl_b32 s4, s4, 7                                        ; 84048704
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v15, s4, v2, v4                                  ; d655000f 04120404
	v_add3_u32 v152, s4, v6, v4                                 ; d6550098 04120c04
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshlrev_b32_e32 v15, 2, v15                               ; 301e1e82
	v_lshlrev_b32_e32 v152, 2, v152                             ; 31313082
	s_clause 0xb                                                ; bf85000b
	buffer_load_b128 v[156:159], v15, s[32:35], null offen      ; c405c07c 4080409c 0000000f
	buffer_load_b128 v[160:163], v152, s[32:35], null offen     ; c405c07c 408040a0 00000098
	buffer_load_b128 v[164:167], v15, s[32:35], null offen offset:512 ; c405c07c 408040a4 0002000f
	buffer_load_b128 v[168:171], v152, s[32:35], null offen offset:512 ; c405c07c 408040a8 00020098
	buffer_load_b128 v[172:175], v15, s[32:35], null offen offset:1024 ; c405c07c 408040ac 0004000f
	buffer_load_b128 v[176:179], v152, s[32:35], null offen offset:1024 ; c405c07c 408040b0 00040098
	buffer_load_b128 v[180:183], v15, s[32:35], null offen offset:1536 ; c405c07c 408040b4 0006000f
	buffer_load_b128 v[184:187], v152, s[32:35], null offen offset:1536 ; c405c07c 408040b8 00060098
	buffer_load_b128 v[188:191], v15, s[32:35], null offen offset:2048 ; c405c07c 408040bc 0008000f
	buffer_load_b128 v[192:195], v152, s[32:35], null offen offset:2048 ; c405c07c 408040c0 00080098
	buffer_load_b128 v[196:199], v15, s[32:35], null offen offset:2560 ; c405c07c 408040c4 000a000f
	buffer_load_b128 v[200:203], v152, s[32:35], null offen offset:2560 ; c405c07c 408040c8 000a0098
	s_clause 0x17                                               ; bf850017
	buffer_load_b64 v[154:155], v3, s[28:31], null offen offset:256 ; c405407c 4080389a 00010003
	buffer_load_b64 v[204:205], v12, s[28:31], null offen offset:256 ; c405407c 408038cc 0001000c
	buffer_load_b64 v[206:207], v13, s[28:31], null offen offset:256 ; c405407c 408038ce 0001000d
	buffer_load_b64 v[208:209], v14, s[28:31], null offen offset:256 ; c405407c 408038d0 0001000e
	buffer_load_b64 v[210:211], v3, s[28:31], null offen offset:512 ; c405407c 408038d2 00020003
	buffer_load_b64 v[212:213], v12, s[28:31], null offen offset:512 ; c405407c 408038d4 0002000c
	buffer_load_b64 v[214:215], v13, s[28:31], null offen offset:512 ; c405407c 408038d6 0002000d
	buffer_load_b64 v[216:217], v14, s[28:31], null offen offset:512 ; c405407c 408038d8 0002000e
	buffer_load_b64 v[218:219], v3, s[28:31], null offen offset:768 ; c405407c 408038da 00030003
	buffer_load_b64 v[220:221], v12, s[28:31], null offen offset:768 ; c405407c 408038dc 0003000c
	buffer_load_b64 v[222:223], v13, s[28:31], null offen offset:768 ; c405407c 408038de 0003000d
	buffer_load_b64 v[224:225], v14, s[28:31], null offen offset:768 ; c405407c 408038e0 0003000e
	buffer_load_b64 v[226:227], v3, s[28:31], null offen offset:1024 ; c405407c 408038e2 00040003
	buffer_load_b64 v[228:229], v12, s[28:31], null offen offset:1024 ; c405407c 408038e4 0004000c
	buffer_load_b64 v[230:231], v13, s[28:31], null offen offset:1024 ; c405407c 408038e6 0004000d
	buffer_load_b64 v[232:233], v14, s[28:31], null offen offset:1024 ; c405407c 408038e8 0004000e
	buffer_load_b64 v[234:235], v3, s[28:31], null offen offset:1280 ; c405407c 408038ea 00050003
	buffer_load_b64 v[236:237], v12, s[28:31], null offen offset:1280 ; c405407c 408038ec 0005000c
	buffer_load_b64 v[238:239], v13, s[28:31], null offen offset:1280 ; c405407c 408038ee 0005000d
	buffer_load_b64 v[240:241], v14, s[28:31], null offen offset:1280 ; c405407c 408038f0 0005000e
	buffer_load_b64 v[242:243], v3, s[28:31], null offen offset:1536 ; c405407c 408038f2 00060003
	buffer_load_b64 v[244:245], v12, s[28:31], null offen offset:1536 ; c405407c 408038f4 0006000c
	buffer_load_b64 v[246:247], v13, s[28:31], null offen offset:1536 ; c405407c 408038f6 0006000d
	buffer_load_b64 v[248:249], v14, s[28:31], null offen offset:1536 ; c405407c 408038f8 0006000e
	s_wait_loadcnt 0x23                                         ; bfc00023
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[150:151], v[156:157], v[112:119] ; cc464070 1dc33996
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[150:151], v[158:159], v[120:127] ; cc464078 1de33d96
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[144:145], v[156:157], v[16:23] ; cc464010 1c433990
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[144:145], v[158:159], v[24:31] ; cc464018 1c633d90
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[146:147], v[156:157], v[48:55] ; cc464030 1cc33992
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[146:147], v[158:159], v[56:63] ; cc464038 1ce33d92
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[148:149], v[156:157], v[80:87] ; cc464050 1d433994
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[148:149], v[158:159], v[88:95] ; cc464058 1d633d94
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[252:255], v15, s[32:35], null offen offset:3072 ; c405c07c 408040fc 000c000f
	buffer_load_b128 v[156:159], v152, s[32:35], null offen offset:3072 ; c405c07c 4080409c 000c0098
	s_wait_loadcnt 0x24                                         ; bfc00024
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[144:145], v[160:161], v[32:39] ; cc464020 1c834190
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[144:145], v[162:163], v[40:47] ; cc464028 1ca34590
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[146:147], v[160:161], v[64:71] ; cc464040 1d034192
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[146:147], v[162:163], v[72:79] ; cc464048 1d234592
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[144:145], v3, s[28:31], null offen offset:1792 ; c405407c 40803890 00070003
	buffer_load_b64 v[146:147], v12, s[28:31], null offen offset:1792 ; c405407c 40803892 0007000c
	buffer_load_b64 v[12:13], v13, s[28:31], null offen offset:1792 ; c405407c 4080380c 0007000d
	buffer_load_b64 v[250:251], v14, s[28:31], null offen offset:1792 ; c405407c 408038fa 0007000e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[160:161], v[96:103] ; cc464060 1d834194
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[148:149], v[162:163], v[104:111] ; cc464068 1da34594
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[150:151], v[160:161], v[128:135] ; cc464080 1e034196
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[150:151], v[162:163], v[136:143] ; cc464088 1e234596
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[148:151], v15, s[32:35], null offen offset:3584 ; c405c07c 40804094 000e000f
	buffer_load_b128 v[160:163], v152, s[32:35], null offen offset:3584 ; c405c07c 408040a0 000e0098
	s_add_co_u32 s1, s1, 1                                      ; 80018101
	s_wait_loadcnt 0x1f                                         ; bfc0001f
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[154:155], v[164:165], v[16:23] ; cc464010 1c43499a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[154:155], v[166:167], v[24:31] ; cc464018 1c634d9a
	s_wait_loadcnt 0x1e                                         ; bfc0001e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[204:205], v[164:165], v[48:55] ; cc464030 1cc349cc
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[204:205], v[166:167], v[56:63] ; cc464038 1ce34dcc
	s_wait_loadcnt 0x1d                                         ; bfc0001d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[206:207], v[164:165], v[80:87] ; cc464050 1d4349ce
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[206:207], v[166:167], v[88:95] ; cc464058 1d634dce
	s_wait_loadcnt 0x1c                                         ; bfc0001c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[208:209], v[164:165], v[112:119] ; cc464070 1dc349d0
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[208:209], v[166:167], v[120:127] ; cc464078 1de34dd0
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[154:155], v[168:169], v[32:39] ; cc464020 1c83519a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[154:155], v[170:171], v[40:47] ; cc464028 1ca3559a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[204:205], v[168:169], v[64:71] ; cc464040 1d0351cc
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[204:205], v[170:171], v[72:79] ; cc464048 1d2355cc
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[206:207], v[168:169], v[96:103] ; cc464060 1d8351ce
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[206:207], v[170:171], v[104:111] ; cc464068 1da355ce
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[208:209], v[168:169], v[128:135] ; cc464080 1e0351d0
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[208:209], v[170:171], v[136:143] ; cc464088 1e2355d0
	s_wait_loadcnt 0x1b                                         ; bfc0001b
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[210:211], v[172:173], v[16:23] ; cc464010 1c4359d2
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[210:211], v[174:175], v[24:31] ; cc464018 1c635dd2
	s_wait_loadcnt 0x1a                                         ; bfc0001a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[212:213], v[172:173], v[48:55] ; cc464030 1cc359d4
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[212:213], v[174:175], v[56:63] ; cc464038 1ce35dd4
	s_wait_loadcnt 0x19                                         ; bfc00019
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[214:215], v[172:173], v[80:87] ; cc464050 1d4359d6
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[214:215], v[174:175], v[88:95] ; cc464058 1d635dd6
	s_wait_loadcnt 0x18                                         ; bfc00018
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[216:217], v[172:173], v[112:119] ; cc464070 1dc359d8
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[216:217], v[174:175], v[120:127] ; cc464078 1de35dd8
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[210:211], v[176:177], v[32:39] ; cc464020 1c8361d2
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[210:211], v[178:179], v[40:47] ; cc464028 1ca365d2
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[212:213], v[176:177], v[64:71] ; cc464040 1d0361d4
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[212:213], v[178:179], v[72:79] ; cc464048 1d2365d4
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[214:215], v[176:177], v[96:103] ; cc464060 1d8361d6
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[214:215], v[178:179], v[104:111] ; cc464068 1da365d6
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[216:217], v[176:177], v[128:135] ; cc464080 1e0361d8
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[216:217], v[178:179], v[136:143] ; cc464088 1e2365d8
	s_wait_loadcnt 0x17                                         ; bfc00017
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[218:219], v[180:181], v[16:23] ; cc464010 1c4369da
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[218:219], v[182:183], v[24:31] ; cc464018 1c636dda
	s_wait_loadcnt 0x16                                         ; bfc00016
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[220:221], v[180:181], v[48:55] ; cc464030 1cc369dc
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[220:221], v[182:183], v[56:63] ; cc464038 1ce36ddc
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[222:223], v[180:181], v[80:87] ; cc464050 1d4369de
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[222:223], v[182:183], v[88:95] ; cc464058 1d636dde
	s_wait_loadcnt 0x14                                         ; bfc00014
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[224:225], v[180:181], v[112:119] ; cc464070 1dc369e0
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[224:225], v[182:183], v[120:127] ; cc464078 1de36de0
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[218:219], v[184:185], v[32:39] ; cc464020 1c8371da
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[218:219], v[186:187], v[40:47] ; cc464028 1ca375da
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[220:221], v[184:185], v[64:71] ; cc464040 1d0371dc
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[220:221], v[186:187], v[72:79] ; cc464048 1d2375dc
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[222:223], v[184:185], v[96:103] ; cc464060 1d8371de
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[222:223], v[186:187], v[104:111] ; cc464068 1da375de
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[224:225], v[184:185], v[128:135] ; cc464080 1e0371e0
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[224:225], v[186:187], v[136:143] ; cc464088 1e2375e0
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[226:227], v[188:189], v[16:23] ; cc464010 1c4379e2
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[226:227], v[190:191], v[24:31] ; cc464018 1c637de2
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[228:229], v[188:189], v[48:55] ; cc464030 1cc379e4
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[228:229], v[190:191], v[56:63] ; cc464038 1ce37de4
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[230:231], v[188:189], v[80:87] ; cc464050 1d4379e6
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[230:231], v[190:191], v[88:95] ; cc464058 1d637de6
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[232:233], v[188:189], v[112:119] ; cc464070 1dc379e8
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[232:233], v[190:191], v[120:127] ; cc464078 1de37de8
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[226:227], v[192:193], v[32:39] ; cc464020 1c8381e2
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[226:227], v[194:195], v[40:47] ; cc464028 1ca385e2
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[228:229], v[192:193], v[64:71] ; cc464040 1d0381e4
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[228:229], v[194:195], v[72:79] ; cc464048 1d2385e4
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[230:231], v[192:193], v[96:103] ; cc464060 1d8381e6
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[230:231], v[194:195], v[104:111] ; cc464068 1da385e6
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[232:233], v[192:193], v[128:135] ; cc464080 1e0381e8
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[232:233], v[194:195], v[136:143] ; cc464088 1e2385e8
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[234:235], v[196:197], v[16:23] ; cc464010 1c4389ea
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[234:235], v[198:199], v[24:31] ; cc464018 1c638dea
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[236:237], v[196:197], v[48:55] ; cc464030 1cc389ec
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[236:237], v[198:199], v[56:63] ; cc464038 1ce38dec
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[238:239], v[196:197], v[80:87] ; cc464050 1d4389ee
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[238:239], v[198:199], v[88:95] ; cc464058 1d638dee
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[240:241], v[196:197], v[112:119] ; cc464070 1dc389f0
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[240:241], v[198:199], v[120:127] ; cc464078 1de38df0
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[234:235], v[200:201], v[32:39] ; cc464020 1c8391ea
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[234:235], v[202:203], v[40:47] ; cc464028 1ca395ea
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[236:237], v[200:201], v[64:71] ; cc464040 1d0391ec
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[236:237], v[202:203], v[72:79] ; cc464048 1d2395ec
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[238:239], v[200:201], v[96:103] ; cc464060 1d8391ee
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[238:239], v[202:203], v[104:111] ; cc464068 1da395ee
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[240:241], v[200:201], v[128:135] ; cc464080 1e0391f0
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[240:241], v[202:203], v[136:143] ; cc464088 1e2395f0
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[242:243], v[252:253], v[16:23] ; cc464010 1c43f9f2
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[242:243], v[254:255], v[24:31] ; cc464018 1c63fdf2
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[244:245], v[252:253], v[48:55] ; cc464030 1cc3f9f4
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[244:245], v[254:255], v[56:63] ; cc464038 1ce3fdf4
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[246:247], v[252:253], v[80:87] ; cc464050 1d43f9f6
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[246:247], v[254:255], v[88:95] ; cc464058 1d63fdf6
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[248:249], v[252:253], v[112:119] ; cc464070 1dc3f9f8
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[248:249], v[254:255], v[120:127] ; cc464078 1de3fdf8
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[242:243], v[156:157], v[32:39] ; cc464020 1c8339f2
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[242:243], v[158:159], v[40:47] ; cc464028 1ca33df2
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[244:245], v[156:157], v[64:71] ; cc464040 1d0339f4
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[244:245], v[158:159], v[72:79] ; cc464048 1d233df4
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[246:247], v[156:157], v[96:103] ; cc464060 1d8339f6
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[246:247], v[158:159], v[104:111] ; cc464068 1da33df6
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[248:249], v[156:157], v[128:135] ; cc464080 1e0339f8
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[248:249], v[158:159], v[136:143] ; cc464088 1e233df8
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[144:145], v[148:149], v[16:23] ; cc464010 1c432990
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[144:145], v[150:151], v[24:31] ; cc464018 1c632d90
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[146:147], v[148:149], v[48:55] ; cc464030 1cc32992
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[146:147], v[150:151], v[56:63] ; cc464038 1ce32d92
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[148:149], v[80:87] ; cc464050 1d43290c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[150:151], v[88:95] ; cc464058 1d632d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[250:251], v[148:149], v[112:119] ; cc464070 1dc329fa
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[250:251], v[150:151], v[120:127] ; cc464078 1de32dfa
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[144:145], v[160:161], v[32:39] ; cc464020 1c834190
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[144:145], v[162:163], v[40:47] ; cc464028 1ca34590
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[146:147], v[160:161], v[64:71] ; cc464040 1d034192
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[146:147], v[162:163], v[72:79] ; cc464048 1d234592
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[160:161], v[96:103] ; cc464060 1d83410c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[162:163], v[104:111] ; cc464068 1da3450c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[250:251], v[160:161], v[128:135] ; cc464080 1e0341fa
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[250:251], v[162:163], v[136:143] ; cc464088 1e2345fa
BB48:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s1, s24                                        ; bf091801
	s_cbranch_scc0 BB50                                         ; bfa1fe2a
BB51:
	s_cmp_lt_u32 s15, s6                                        ; bf0a060f
	s_cbranch_scc0 BB53                                         ; bfa100ad
BB52:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[16:17], 0x40                        ; f4004608 f8000040
	s_load_b128 s[28:31], s[16:17], 0x10                        ; f4004708 f8000010
	v_add3_u32 v2, v7, s5, v1                                   ; d6550002 04040b07
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v2, 1, v2                                 ; 30040481
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v3, v2, s[24:27], null offen            ; c408007c 40803003 00000002
	v_and_b32_e32 v6, 16, v0                                    ; 360c0090
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_lshr_b32 s4, s7, 4                                        ; 85048407
	v_lshrrev_b32_e32 v4, 4, v1                                 ; 32080284
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s4, s10, s4                                       ; 9604040a
	v_lshl_or_b32 v6, v6, 3, v7                                 ; d6560006 041d0706
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_add_lshl_u32 v4, s4, v4, 8                                ; d6470004 02220804
	v_add3_u32 v8, v6, s2, v4                                   ; d6550008 04100506
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v9, v8, s[28:31], null offen             ; c407807c 40803809 00000008
	buffer_load_d16_u8 v10, v8, s[28:31], null offen offset:16  ; c407807c 4080380a 00001008
	buffer_load_d16_u8 v11, v8, s[28:31], null offen offset:32  ; c407807c 4080380b 00002008
	buffer_load_d16_u8 v12, v8, s[28:31], null offen offset:48  ; c407807c 4080380c 00003008
	buffer_load_d16_u8 v13, v8, s[28:31], null offen offset:64  ; c407807c 4080380d 00004008
	buffer_load_d16_u8 v14, v8, s[28:31], null offen offset:80  ; c407807c 4080380e 00005008
	buffer_load_d16_u8 v15, v8, s[28:31], null offen offset:96  ; c407807c 4080380f 00006008
	buffer_load_d16_u8 v144, v8, s[28:31], null offen offset:112 ; c407807c 40803890 00007008
	v_add3_u32 v6, v6, s3, v4                                   ; d6550006 04100706
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v145, v9                                  ; 7f22d909
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v149, v10                                 ; 7f2ad90a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v153, v11                                 ; 7f32d90b
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v157, v12                                 ; 7f3ad90c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v146, v3, v145, v16 op_sel_hi:[1,0,0]       ; cc210092 0c432303
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v161, v13                                 ; 7f42d90d
	v_fma_mixlo_f16 v150, v3, v149, v17 op_sel_hi:[1,0,0]       ; cc210096 0c472b03
	v_fma_mixlo_f16 v154, v3, v153, v18 op_sel_hi:[1,0,0]       ; cc21009a 0c4b3303
	v_fma_mixlo_f16 v158, v3, v157, v19 op_sel_hi:[1,0,0]       ; cc21009e 0c4f3b03
	v_maxmin_num_f16 v146, 0xdf00, v146, neg(0xdf00)            ; d66b0092 83ff24ff 0000df00
	v_fma_mixlo_f16 v162, v3, v161, v20 op_sel_hi:[1,0,0]       ; cc2100a2 0c534303
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v165, v14                                 ; 7f4ad90e
	v_maxmin_num_f16 v150, 0xdf00, v150, neg(0xdf00)            ; d66b0096 83ff2cff 0000df00
	v_maxmin_num_f16 v154, 0xdf00, v154, neg(0xdf00)            ; d66b009a 83ff34ff 0000df00
	v_maxmin_num_f16 v158, 0xdf00, v158, neg(0xdf00)            ; d66b009e 83ff3cff 0000df00
(invalid instruction)                                        ; d58b0093
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                    ; 02010192
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v169, v15                                 ; 7f52d90f
	v_maxmin_num_f16 v162, 0xdf00, v162, neg(0xdf00)            ; d66b00a2 83ff44ff 0000df00
	v_fma_mixlo_f16 v166, v3, v165, v21 op_sel_hi:[1,0,0]       ; cc2100a6 0c574b03
(invalid instruction)                                        ; d58b0097
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                    ; 02010196
(invalid instruction)                                        ; d58b009b
	v_cndmask_b32_e32 v0, v154, v128, vcc_lo                    ; 0201019a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v173, v144                                ; 7f5ad990
(invalid instruction)                                        ; d58b009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
(invalid instruction)                                        ; d7690094
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                    ; 02010193
	v_fma_mixlo_f16 v170, v3, v169, v22 op_sel_hi:[1,0,0]       ; cc2100aa 0c5b5303
(invalid instruction)                                        ; d58b00a3
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
	v_maxmin_num_f16 v166, 0xdf00, v166, neg(0xdf00)            ; d66b00a6 83ff4cff 0000df00
(invalid instruction)                                        ; d7690098
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                    ; 02010197
(invalid instruction)                                        ; d769009c
	v_cndmask_b32_e32 v0, v155, v128, vcc_lo                    ; 0201019b
	v_fma_mixlo_f16 v3, v3, v173, v23 op_sel_hi:[1,0,0]         ; cc210003 0c5f5b03
(invalid instruction)                                        ; d76900a0
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                    ; 0201019f
	v_maxmin_num_f16 v170, 0xdf00, v170, neg(0xdf00)            ; d66b00aa 83ff54ff 0000df00
(invalid instruction)                                        ; d76900a4
	v_cndmask_b32_e32 v0, v163, v128, vcc_lo                    ; 020101a3
(invalid instruction)                                        ; d58b00a7
	v_cndmask_b32_e32 v0, v166, v128, vcc_lo                    ; 020101a6
	v_maxmin_num_f16 v3, 0xdf00, v3, neg(0xdf00)                ; d66b0003 83fe06ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; d58b00ab
	v_cndmask_b32_e32 v0, v170, v128, vcc_lo                    ; 020101aa
(invalid instruction)                                        ; d76900a8
	v_cndmask_b32_e32 v0, v167, v128, vcc_lo                    ; 020101a7
	v_cvt_f32_f16_e32 v174, v3                                  ; 7f5c1703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d76900ac
	v_cndmask_b32_e32 v0, v171, v128, vcc_lo                    ; 020101ab
(invalid instruction)                                        ; d76900af
	v_cndmask_b32_e32 v0, v174, v128, vcc_lo                    ; 020101ae
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v148, v6, s[28:31], null offen              ; c406007c 40803894 00000006
	buffer_store_b8 v152, v6, s[28:31], null offen offset:16    ; c406007c 40803898 00001006
	buffer_store_b8 v156, v6, s[28:31], null offen offset:32    ; c406007c 4080389c 00002006
	buffer_store_b8 v160, v6, s[28:31], null offen offset:48    ; c406007c 408038a0 00003006
	buffer_store_b8 v164, v6, s[28:31], null offen offset:64    ; c406007c 408038a4 00004006
	buffer_store_b8 v168, v6, s[28:31], null offen offset:80    ; c406007c 408038a8 00005006
	buffer_store_b8 v172, v6, s[28:31], null offen offset:96    ; c406007c 408038ac 00006006
	buffer_store_b8 v175, v6, s[28:31], null offen offset:112   ; c406007c 408038af 00007006
	s_branch BB54                                               ; bfa00001
BB53:
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB54:
	v_add_nc_u32_e32 v2, 16, v1                                 ; 4a040290
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc0 BB56                                         ; bfa10143
BB55:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[16:17], 0x40                        ; f4004608 f8000040
	s_load_b128 s[28:31], s[16:17], 0x10                        ; f4004708 f8000010
	v_add3_u32 v3, v7, s5, v1                                   ; d6550003 04040b07
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v3, 1, v3                                 ; 30060681
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v4, v3, s[24:27], null offen offset:32  ; c408007c 40803004 00002003
	v_and_b32_e32 v8, 16, v0                                    ; 36100090
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_lshr_b32 s4, s7, 4                                        ; 85048407
	v_lshrrev_b32_e32 v6, 4, v2                                 ; 320c0484
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s4, s10, s4                                       ; 9604040a
	v_lshl_or_b32 v8, v8, 3, v7                                 ; d6560008 041d0708
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_add_lshl_u32 v6, s4, v6, 8                                ; d6470006 02220c04
	v_add3_u32 v9, v8, s2, v6                                   ; d6550009 04180508
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v10, v9, s[28:31], null offen            ; c407807c 4080380a 00000009
	buffer_load_d16_u8 v11, v9, s[28:31], null offen offset:16  ; c407807c 4080380b 00001009
	buffer_load_d16_u8 v12, v9, s[28:31], null offen offset:32  ; c407807c 4080380c 00002009
	buffer_load_d16_u8 v13, v9, s[28:31], null offen offset:48  ; c407807c 4080380d 00003009
	buffer_load_d16_u8 v14, v9, s[28:31], null offen offset:64  ; c407807c 4080380e 00004009
	buffer_load_d16_u8 v15, v9, s[28:31], null offen offset:80  ; c407807c 4080380f 00005009
	buffer_load_d16_u8 v16, v9, s[28:31], null offen offset:96  ; c407807c 40803810 00006009
	buffer_load_d16_u8 v17, v9, s[28:31], null offen offset:112 ; c407807c 40803811 00007009
	buffer_load_d16_b16 v18, v3, s[24:27], null offen offset:64 ; c408007c 40803012 00004003
	v_lshrrev_b32_e32 v19, 4, v5                                ; 32260a84
	v_add3_u32 v6, v8, s3, v6                                   ; d6550006 04180708
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_add_lshl_u32 v19, s4, v19, 8                              ; d6470013 02222604
	v_add3_u32 v20, v8, s2, v19                                 ; d6550014 044c0508
	v_add3_u32 v8, v8, s3, v19                                  ; d6550008 044c0708
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cvt_f32_fp8_e32 v21, v10                                  ; 7e2ad90a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v144, v11                                 ; 7f20d90b
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v148, v12                                 ; 7f28d90c
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v152, v13                                 ; 7f30d90d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v22, v4, v21, v24 op_sel_hi:[1,0,0]         ; cc210016 0c622b04
	v_fma_mixlo_f16 v145, v4, v144, v25 op_sel_hi:[1,0,0]       ; cc210091 0c672104
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v156, v14                                 ; 7f38d90e
	v_fma_mixlo_f16 v149, v4, v148, v26 op_sel_hi:[1,0,0]       ; cc210095 0c6b2904
	v_fma_mixlo_f16 v153, v4, v152, v27 op_sel_hi:[1,0,0]       ; cc210099 0c6f3104
	v_maxmin_num_f16 v22, 0xdf00, v22, neg(0xdf00)              ; d66b0016 83fe2cff 0000df00
	v_maxmin_num_f16 v145, 0xdf00, v145, neg(0xdf00)            ; d66b0091 83ff22ff 0000df00
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v160, v15                                 ; 7f40d90f
	v_fma_mixlo_f16 v157, v4, v156, v28 op_sel_hi:[1,0,0]       ; cc21009d 0c733904
	v_maxmin_num_f16 v149, 0xdf00, v149, neg(0xdf00)            ; d66b0095 83ff2aff 0000df00
	v_maxmin_num_f16 v153, 0xdf00, v153, neg(0xdf00)            ; d66b0099 83ff32ff 0000df00
	v_cvt_f32_f16_e32 v23, v22                                  ; 7e2e1716
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v164, v16                                 ; 7f48d910
(invalid instruction)                                        ; d58b0092
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                    ; 02010191
	v_fma_mixlo_f16 v161, v4, v160, v29 op_sel_hi:[1,0,0]       ; cc2100a1 0c774104
	v_maxmin_num_f16 v157, 0xdf00, v157, neg(0xdf00)            ; d66b009d 83ff3aff 0000df00
(invalid instruction)                                        ; d58b0096
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                    ; 02010195
(invalid instruction)                                        ; d58b009a
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                    ; 02010199
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v168, v17                                 ; 7f50d911
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v0, v23, v128, vcc_lo                     ; 02010117
	v_fma_mixlo_f16 v165, v4, v164, v30 op_sel_hi:[1,0,0]       ; cc2100a5 0c7b4904
(invalid instruction)                                        ; d7690093
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                    ; 02010192
	v_maxmin_num_f16 v161, 0xdf00, v161, neg(0xdf00)            ; d66b00a1 83ff42ff 0000df00
(invalid instruction)                                        ; d58b009e
	v_cndmask_b32_e32 v0, v157, v128, vcc_lo                    ; 0201019d
(invalid instruction)                                        ; d7690097
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                    ; 02010196
(invalid instruction)                                        ; d769009b
	v_cndmask_b32_e32 v0, v154, v128, vcc_lo                    ; 0201019a
	v_fma_mixlo_f16 v4, v4, v168, v31 op_sel_hi:[1,0,0]         ; cc210004 0c7f5104
	v_maxmin_num_f16 v165, 0xdf00, v165, neg(0xdf00)            ; d66b00a5 83ff4aff 0000df00
(invalid instruction)                                        ; d58b00a2
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
(invalid instruction)                                        ; d769009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v4, 0xdf00, v4, neg(0xdf00)                ; d66b0004 83fe08ff 0000df00
(invalid instruction)                                        ; d58b00a6
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
(invalid instruction)                                        ; d76900a3
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
	v_cvt_f32_f16_e32 v169, v4                                  ; 7f521704
(invalid instruction)                                        ; d76900a7
	v_cndmask_b32_e32 v0, v166, v128, vcc_lo                    ; 020101a6
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900aa
	v_cndmask_b32_e32 v0, v169, v128, vcc_lo                    ; 020101a9
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v24, v6, s[28:31], null offen               ; c406007c 40803818 00000006
	buffer_store_b8 v147, v6, s[28:31], null offen offset:16    ; c406007c 40803893 00001006
	buffer_store_b8 v151, v6, s[28:31], null offen offset:32    ; c406007c 40803897 00002006
	buffer_store_b8 v155, v6, s[28:31], null offen offset:48    ; c406007c 4080389b 00003006
	buffer_store_b8 v159, v6, s[28:31], null offen offset:64    ; c406007c 4080389f 00004006
	buffer_store_b8 v163, v6, s[28:31], null offen offset:80    ; c406007c 408038a3 00005006
	buffer_store_b8 v167, v6, s[28:31], null offen offset:96    ; c406007c 408038a7 00006006
	buffer_store_b8 v170, v6, s[28:31], null offen offset:112   ; c406007c 408038aa 00007006
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v171, v20, s[28:31], null offen          ; c407807c 408038ab 00000014
	buffer_load_d16_u8 v172, v20, s[28:31], null offen offset:16 ; c407807c 408038ac 00001014
	buffer_load_d16_u8 v173, v20, s[28:31], null offen offset:32 ; c407807c 408038ad 00002014
	buffer_load_d16_u8 v174, v20, s[28:31], null offen offset:48 ; c407807c 408038ae 00003014
	buffer_load_d16_u8 v175, v20, s[28:31], null offen offset:64 ; c407807c 408038af 00004014
	buffer_load_d16_u8 v176, v20, s[28:31], null offen offset:80 ; c407807c 408038b0 00005014
	buffer_load_d16_u8 v177, v20, s[28:31], null offen offset:96 ; c407807c 408038b1 00006014
	buffer_load_d16_u8 v178, v20, s[28:31], null offen offset:112 ; c407807c 408038b2 00007014
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v179, v171                                ; 7f66d9ab
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v183, v172                                ; 7f6ed9ac
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v187, v173                                ; 7f76d9ad
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v191, v174                                ; 7f7ed9ae
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v180, v18, v179, v32 op_sel_hi:[1,0,0]      ; cc2100b4 0c836712
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v195, v175                                ; 7f86d9af
	v_fma_mixlo_f16 v184, v18, v183, v33 op_sel_hi:[1,0,0]      ; cc2100b8 0c876f12
	v_fma_mixlo_f16 v188, v18, v187, v34 op_sel_hi:[1,0,0]      ; cc2100bc 0c8b7712
	v_fma_mixlo_f16 v192, v18, v191, v35 op_sel_hi:[1,0,0]      ; cc2100c0 0c8f7f12
	v_maxmin_num_f16 v180, 0xdf00, v180, neg(0xdf00)            ; d66b00b4 83ff68ff 0000df00
	v_fma_mixlo_f16 v196, v18, v195, v36 op_sel_hi:[1,0,0]      ; cc2100c4 0c938712
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v199, v176                                ; 7f8ed9b0
	v_maxmin_num_f16 v184, 0xdf00, v184, neg(0xdf00)            ; d66b00b8 83ff70ff 0000df00
	v_maxmin_num_f16 v188, 0xdf00, v188, neg(0xdf00)            ; d66b00bc 83ff78ff 0000df00
	v_maxmin_num_f16 v192, 0xdf00, v192, neg(0xdf00)            ; d66b00c0 83ff80ff 0000df00
(invalid instruction)                                        ; d58b00b5
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                    ; 020101b4
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v203, v177                                ; 7f96d9b1
	v_maxmin_num_f16 v196, 0xdf00, v196, neg(0xdf00)            ; d66b00c4 83ff88ff 0000df00
	v_fma_mixlo_f16 v200, v18, v199, v37 op_sel_hi:[1,0,0]      ; cc2100c8 0c978f12
(invalid instruction)                                        ; d58b00b9
	v_cndmask_b32_e32 v0, v184, v128, vcc_lo                    ; 020101b8
(invalid instruction)                                        ; d58b00bd
	v_cndmask_b32_e32 v0, v188, v128, vcc_lo                    ; 020101bc
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v207, v178                                ; 7f9ed9b2
(invalid instruction)                                        ; d58b00c1
	v_cndmask_b32_e32 v0, v192, v128, vcc_lo                    ; 020101c0
(invalid instruction)                                        ; d76900b6
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                    ; 020101b5
	v_fma_mixlo_f16 v204, v18, v203, v38 op_sel_hi:[1,0,0]      ; cc2100cc 0c9b9712
(invalid instruction)                                        ; d58b00c5
	v_cndmask_b32_e32 v0, v196, v128, vcc_lo                    ; 020101c4
	v_maxmin_num_f16 v200, 0xdf00, v200, neg(0xdf00)            ; d66b00c8 83ff90ff 0000df00
(invalid instruction)                                        ; d76900ba
	v_cndmask_b32_e32 v0, v185, v128, vcc_lo                    ; 020101b9
(invalid instruction)                                        ; d76900be
	v_cndmask_b32_e32 v0, v189, v128, vcc_lo                    ; 020101bd
	v_fma_mixlo_f16 v18, v18, v207, v39 op_sel_hi:[1,0,0]       ; cc210012 0c9f9f12
(invalid instruction)                                        ; d76900c2
	v_cndmask_b32_e32 v0, v193, v128, vcc_lo                    ; 020101c1
	v_maxmin_num_f16 v204, 0xdf00, v204, neg(0xdf00)            ; d66b00cc 83ff98ff 0000df00
(invalid instruction)                                        ; d76900c6
	v_cndmask_b32_e32 v0, v197, v128, vcc_lo                    ; 020101c5
(invalid instruction)                                        ; d58b00c9
	v_cndmask_b32_e32 v0, v200, v128, vcc_lo                    ; 020101c8
	v_maxmin_num_f16 v18, 0xdf00, v18, neg(0xdf00)              ; d66b0012 83fe24ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; d58b00cd
	v_cndmask_b32_e32 v0, v204, v128, vcc_lo                    ; 020101cc
(invalid instruction)                                        ; d76900ca
	v_cndmask_b32_e32 v0, v201, v128, vcc_lo                    ; 020101c9
	v_cvt_f32_f16_e32 v208, v18                                 ; 7fa01712
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d76900ce
	v_cndmask_b32_e32 v0, v205, v128, vcc_lo                    ; 020101cd
(invalid instruction)                                        ; d76900d1
	v_cndmask_b32_e32 v0, v208, v128, vcc_lo                    ; 020101d0
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v182, v8, s[28:31], null offen              ; c406007c 408038b6 00000008
	buffer_store_b8 v186, v8, s[28:31], null offen offset:16    ; c406007c 408038ba 00001008
	buffer_store_b8 v190, v8, s[28:31], null offen offset:32    ; c406007c 408038be 00002008
	buffer_store_b8 v194, v8, s[28:31], null offen offset:48    ; c406007c 408038c2 00003008
	buffer_store_b8 v198, v8, s[28:31], null offen offset:64    ; c406007c 408038c6 00004008
	buffer_store_b8 v202, v8, s[28:31], null offen offset:80    ; c406007c 408038ca 00005008
	buffer_store_b8 v206, v8, s[28:31], null offen offset:96    ; c406007c 408038ce 00006008
	buffer_store_b8 v209, v8, s[28:31], null offen offset:112   ; c406007c 408038d1 00007008
	s_branch BB57                                               ; bfa00001
BB56:
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB57:
	v_add_nc_u32_e32 v3, 48, v1                                 ; 4a0602b0
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc0 BB60                                         ; bfa100a5
BB58:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[16:17], 0x40                        ; f4004608 f8000040
	s_load_b128 s[28:31], s[16:17], 0x10                        ; f4004708 f8000010
	v_add3_u32 v4, v7, s5, v1                                   ; d6550004 04040b07
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v4, 1, v4                                 ; 30080881
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v6, v4, s[24:27], null offen offset:96  ; c408007c 40803006 00006004
	v_and_b32_e32 v9, 16, v0                                    ; 36120090
	s_lshr_b32 s1, s7, 4                                        ; 85018407
	v_lshrrev_b32_e32 v8, 4, v3                                 ; 32100684
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s1, s10, s1                                       ; 9601010a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshl_or_b32 v9, v9, 3, v7                                 ; d6560009 041d0709
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v8, s1, v8, 8                                ; d6470008 02221001
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v10, v9, s2, v8                                  ; d655000a 04200509
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v11, v10, s[28:31], null offen           ; c407807c 4080380b 0000000a
	buffer_load_d16_u8 v12, v10, s[28:31], null offen offset:16 ; c407807c 4080380c 0000100a
	buffer_load_d16_u8 v13, v10, s[28:31], null offen offset:32 ; c407807c 4080380d 0000200a
	buffer_load_d16_u8 v14, v10, s[28:31], null offen offset:48 ; c407807c 4080380e 0000300a
	buffer_load_d16_u8 v15, v10, s[28:31], null offen offset:64 ; c407807c 4080380f 0000400a
	buffer_load_d16_u8 v16, v10, s[28:31], null offen offset:80 ; c407807c 40803810 0000500a
	buffer_load_d16_u8 v17, v10, s[28:31], null offen offset:96 ; c407807c 40803811 0000600a
	buffer_load_d16_u8 v18, v10, s[28:31], null offen offset:112 ; c407807c 40803812 0000700a
	v_add3_u32 v9, v9, s3, v8                                   ; d6550009 04200709
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v19, v11                                  ; 7e26d90b
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v23, v12                                  ; 7e2ed90c
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v27, v13                                  ; 7e36d90d
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v31, v14                                  ; 7e3ed90e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v20, v6, v19, v40 op_sel_hi:[1,0,0]         ; cc210014 0ca22706
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v35, v15                                  ; 7e46d90f
	v_fma_mixlo_f16 v24, v6, v23, v41 op_sel_hi:[1,0,0]         ; cc210018 0ca62f06
	v_fma_mixlo_f16 v28, v6, v27, v42 op_sel_hi:[1,0,0]         ; cc21001c 0caa3706
	v_fma_mixlo_f16 v32, v6, v31, v43 op_sel_hi:[1,0,0]         ; cc210020 0cae3f06
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
	v_fma_mixlo_f16 v36, v6, v35, v44 op_sel_hi:[1,0,0]         ; cc210024 0cb24706
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v39, v16                                  ; 7e4ed910
	v_maxmin_num_f16 v24, 0xdf00, v24, neg(0xdf00)              ; d66b0018 83fe30ff 0000df00
	v_maxmin_num_f16 v28, 0xdf00, v28, neg(0xdf00)              ; d66b001c 83fe38ff 0000df00
	v_maxmin_num_f16 v32, 0xdf00, v32, neg(0xdf00)              ; d66b0020 83fe40ff 0000df00
	v_cvt_f32_f16_e32 v21, v20                                  ; 7e2a1714
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v43, v17                                  ; 7e56d911
	v_maxmin_num_f16 v36, 0xdf00, v36, neg(0xdf00)              ; d66b0024 83fe48ff 0000df00
	v_fma_mixlo_f16 v40, v6, v39, v45 op_sel_hi:[1,0,0]         ; cc210028 0cb64f06
	v_cvt_f32_f16_e32 v25, v24                                  ; 7e321718
	v_cvt_f32_f16_e32 v29, v28                                  ; 7e3a171c
	v_cvt_f32_f16_e32 v33, v32                                  ; 7e421720
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v144, v18                                 ; 7f20d912
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
	v_fma_mixlo_f16 v44, v6, v43, v46 op_sel_hi:[1,0,0]         ; cc21002c 0cba5706
	v_cvt_f32_f16_e32 v37, v36                                  ; 7e4a1724
	v_maxmin_num_f16 v40, 0xdf00, v40, neg(0xdf00)              ; d66b0028 83fe50ff 0000df00
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v0, v25, v128, vcc_lo                     ; 02010119
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v0, v29, v128, vcc_lo                     ; 0201011d
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v0, v33, v128, vcc_lo                     ; 02010121
	v_fma_mixlo_f16 v6, v6, v144, v47 op_sel_hi:[1,0,0]         ; cc210006 0cbf2106
	v_maxmin_num_f16 v44, 0xdf00, v44, neg(0xdf00)              ; d66b002c 83fe58ff 0000df00
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v0, v37, v128, vcc_lo                     ; 02010125
	v_cvt_f32_f16_e32 v41, v40                                  ; 7e521728
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_maxmin_num_f16 v6, 0xdf00, v6, neg(0xdf00)                ; d66b0006 83fe0cff 0000df00
	v_cvt_f32_f16_e32 v45, v44                                  ; 7e5a172c
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v0, v41, v128, vcc_lo                     ; 02010129
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_cvt_f32_f16_e32 v145, v6                                  ; 7f221706
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v0, v45, v128, vcc_lo                     ; 0201012d
(invalid instruction)                                        ; d7690092
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                    ; 02010191
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v22, v9, s[28:31], null offen               ; c406007c 40803816 00000009
	buffer_store_b8 v26, v9, s[28:31], null offen offset:16     ; c406007c 4080381a 00001009
	buffer_store_b8 v30, v9, s[28:31], null offen offset:32     ; c406007c 4080381e 00002009
	buffer_store_b8 v34, v9, s[28:31], null offen offset:48     ; c406007c 40803822 00003009
	buffer_store_b8 v38, v9, s[28:31], null offen offset:64     ; c406007c 40803826 00004009
	buffer_store_b8 v42, v9, s[28:31], null offen offset:80     ; c406007c 4080382a 00005009
	buffer_store_b8 v46, v9, s[28:31], null offen offset:96     ; c406007c 4080382e 00006009
	buffer_store_b8 v146, v9, s[28:31], null offen offset:112   ; c406007c 40803892 00007009
BB60:
	s_cmp_lt_u32 s12, s6                                        ; bf0a060c
	s_cbranch_scc0 BB63                                         ; bfa10268
BB61:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[16:17], 0x40                        ; f4004608 f8000040
	s_load_b128 s[28:31], s[16:17], 0x10                        ; f4004708 f8000010
	v_add3_u32 v4, v7, s5, v1                                   ; d6550004 04040b07
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v4, 1, v4                                 ; 30080881
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v6, v4, s[24:27], null offen            ; c408007c 40803006 00000004
	v_and_b32_e32 v9, 16, v0                                    ; 36120090
	s_lshr_b32 s1, s7, 4                                        ; 85018407
	v_lshrrev_b32_e32 v8, 4, v1                                 ; 32100284
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s13, s13, s1                                      ; 960d010d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshl_or_b32 v9, v9, 3, v7                                 ; d6560009 041d0709
	v_add_lshl_u32 v8, s13, v8, 8                               ; d6470008 0222100d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v10, v9, s2, v8                                  ; d655000a 04200509
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v11, v10, s[28:31], null offen           ; c407807c 4080380b 0000000a
	buffer_load_d16_u8 v12, v10, s[28:31], null offen offset:16 ; c407807c 4080380c 0000100a
	buffer_load_d16_u8 v13, v10, s[28:31], null offen offset:32 ; c407807c 4080380d 0000200a
	buffer_load_d16_u8 v14, v10, s[28:31], null offen offset:48 ; c407807c 4080380e 0000300a
	buffer_load_d16_u8 v15, v10, s[28:31], null offen offset:64 ; c407807c 4080380f 0000400a
	buffer_load_d16_u8 v16, v10, s[28:31], null offen offset:80 ; c407807c 40803810 0000500a
	buffer_load_d16_u8 v17, v10, s[28:31], null offen offset:96 ; c407807c 40803811 0000600a
	buffer_load_d16_u8 v18, v10, s[28:31], null offen offset:112 ; c407807c 40803812 0000700a
	s_clause 0x2                                                ; bf850002
	buffer_load_d16_b16 v19, v4, s[24:27], null offen offset:32 ; c408007c 40803013 00002004
	buffer_load_d16_b16 v20, v4, s[24:27], null offen offset:64 ; c408007c 40803014 00004004
	buffer_load_d16_b16 v21, v4, s[24:27], null offen offset:96 ; c408007c 40803015 00006004
	v_lshrrev_b32_e32 v22, 4, v2                                ; 322c0484
	v_add3_u32 v8, v9, s3, v8                                   ; d6550008 04200709
	v_lshrrev_b32_e32 v24, 4, v5                                ; 32300a84
	v_lshrrev_b32_e32 v26, 4, v3                                ; 32340684
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_add_lshl_u32 v22, s13, v22, 8                             ; d6470016 02222c0d
	v_add_lshl_u32 v24, s13, v24, 8                             ; d6470018 0222300d
	v_add_lshl_u32 v26, s13, v26, 8                             ; d647001a 0222340d
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_add3_u32 v23, v9, s2, v22                                 ; d6550017 04580509
	v_add3_u32 v22, v9, s3, v22                                 ; d6550016 04580709
	v_add3_u32 v25, v9, s2, v24                                 ; d6550019 04600509
	v_add3_u32 v24, v9, s3, v24                                 ; d6550018 04600709
	v_add3_u32 v27, v9, s2, v26                                 ; d655001b 04680509
	v_add3_u32 v9, v9, s3, v26                                  ; d6550009 04680709
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cvt_f32_fp8_e32 v28, v11                                  ; 7e38d90b
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_cvt_f32_fp8_e32 v32, v12                                  ; 7e40d90c
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cvt_f32_fp8_e32 v36, v13                                  ; 7e48d90d
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v40, v14                                  ; 7e50d90e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v29, v6, v28, v48 op_sel_hi:[1,0,0]         ; cc21001d 0cc23906
	v_fma_mixlo_f16 v33, v6, v32, v49 op_sel_hi:[1,0,0]         ; cc210021 0cc64106
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v44, v15                                  ; 7e58d90f
	v_fma_mixlo_f16 v37, v6, v36, v50 op_sel_hi:[1,0,0]         ; cc210025 0cca4906
	v_fma_mixlo_f16 v41, v6, v40, v51 op_sel_hi:[1,0,0]         ; cc210029 0cce5106
	v_maxmin_num_f16 v29, 0xdf00, v29, neg(0xdf00)              ; d66b001d 83fe3aff 0000df00
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v48, v16                                  ; 7e60d910
	v_maxmin_num_f16 v33, 0xdf00, v33, neg(0xdf00)              ; d66b0021 83fe42ff 0000df00
	v_fma_mixlo_f16 v45, v6, v44, v52 op_sel_hi:[1,0,0]         ; cc21002d 0cd25906
	v_maxmin_num_f16 v37, 0xdf00, v37, neg(0xdf00)              ; d66b0025 83fe4aff 0000df00
	v_maxmin_num_f16 v41, 0xdf00, v41, neg(0xdf00)              ; d66b0029 83fe52ff 0000df00
	v_cvt_f32_f16_e32 v30, v29                                  ; 7e3c171d
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v52, v17                                  ; 7e68d911
	v_fma_mixlo_f16 v49, v6, v48, v53 op_sel_hi:[1,0,0]         ; cc210031 0cd66106
	v_cvt_f32_f16_e32 v34, v33                                  ; 7e441721
	v_maxmin_num_f16 v45, 0xdf00, v45, neg(0xdf00)              ; d66b002d 83fe5aff 0000df00
	v_cvt_f32_f16_e32 v38, v37                                  ; 7e4c1725
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v145, v18                                 ; 7f22d912
	v_cvt_f32_f16_e32 v42, v41                                  ; 7e541729
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v0, v30, v128, vcc_lo                     ; 0201011e
	v_fma_mixlo_f16 v53, v6, v52, v54 op_sel_hi:[1,0,0]         ; cc210035 0cda6906
	v_maxmin_num_f16 v49, 0xdf00, v49, neg(0xdf00)              ; d66b0031 83fe62ff 0000df00
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v0, v34, v128, vcc_lo                     ; 02010122
	v_cvt_f32_f16_e32 v46, v45                                  ; 7e5c172d
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v0, v38, v128, vcc_lo                     ; 02010126
	v_fma_mixlo_f16 v6, v6, v145, v55 op_sel_hi:[1,0,0]         ; cc210006 0cdf2306
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v0, v42, v128, vcc_lo                     ; 0201012a
	v_maxmin_num_f16 v53, 0xdf00, v53, neg(0xdf00)              ; d66b0035 83fe6aff 0000df00
	v_cvt_f32_f16_e32 v50, v49                                  ; 7e641731
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
	v_maxmin_num_f16 v6, 0xdf00, v6, neg(0xdf00)                ; d66b0006 83fe0cff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_cvt_f32_f16_e32 v54, v53                                  ; 7e6c1735
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v0, v50, v128, vcc_lo                     ; 02010132
	v_cvt_f32_f16_e32 v146, v6                                  ; 7f241706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d7690090
	v_cndmask_b32_e32 v0, v54, v128, vcc_lo                     ; 02010136
(invalid instruction)                                        ; d7690093
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                    ; 02010192
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v31, v8, s[28:31], null offen               ; c406007c 4080381f 00000008
	buffer_store_b8 v35, v8, s[28:31], null offen offset:16     ; c406007c 40803823 00001008
	buffer_store_b8 v39, v8, s[28:31], null offen offset:32     ; c406007c 40803827 00002008
	buffer_store_b8 v43, v8, s[28:31], null offen offset:48     ; c406007c 4080382b 00003008
	buffer_store_b8 v47, v8, s[28:31], null offen offset:64     ; c406007c 4080382f 00004008
	buffer_store_b8 v51, v8, s[28:31], null offen offset:80     ; c406007c 40803833 00005008
	buffer_store_b8 v144, v8, s[28:31], null offen offset:96    ; c406007c 40803890 00006008
	buffer_store_b8 v147, v8, s[28:31], null offen offset:112   ; c406007c 40803893 00007008
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v148, v23, s[28:31], null offen          ; c407807c 40803894 00000017
	buffer_load_d16_u8 v149, v23, s[28:31], null offen offset:16 ; c407807c 40803895 00001017
	buffer_load_d16_u8 v150, v23, s[28:31], null offen offset:32 ; c407807c 40803896 00002017
	buffer_load_d16_u8 v151, v23, s[28:31], null offen offset:48 ; c407807c 40803897 00003017
	buffer_load_d16_u8 v152, v23, s[28:31], null offen offset:64 ; c407807c 40803898 00004017
	buffer_load_d16_u8 v153, v23, s[28:31], null offen offset:80 ; c407807c 40803899 00005017
	buffer_load_d16_u8 v154, v23, s[28:31], null offen offset:96 ; c407807c 4080389a 00006017
	buffer_load_d16_u8 v155, v23, s[28:31], null offen offset:112 ; c407807c 4080389b 00007017
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v156, v148                                ; 7f38d994
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v160, v149                                ; 7f40d995
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v164, v150                                ; 7f48d996
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v168, v151                                ; 7f50d997
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v157, v19, v156, v56 op_sel_hi:[1,0,0]      ; cc21009d 0ce33913
	v_fma_mixlo_f16 v161, v19, v160, v57 op_sel_hi:[1,0,0]      ; cc2100a1 0ce74113
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v172, v152                                ; 7f58d998
	v_fma_mixlo_f16 v165, v19, v164, v58 op_sel_hi:[1,0,0]      ; cc2100a5 0ceb4913
	v_fma_mixlo_f16 v169, v19, v168, v59 op_sel_hi:[1,0,0]      ; cc2100a9 0cef5113
	v_maxmin_num_f16 v157, 0xdf00, v157, neg(0xdf00)            ; d66b009d 83ff3aff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v176, v153                                ; 7f60d999
	v_maxmin_num_f16 v161, 0xdf00, v161, neg(0xdf00)            ; d66b00a1 83ff42ff 0000df00
	v_fma_mixlo_f16 v173, v19, v172, v60 op_sel_hi:[1,0,0]      ; cc2100ad 0cf35913
	v_maxmin_num_f16 v165, 0xdf00, v165, neg(0xdf00)            ; d66b00a5 83ff4aff 0000df00
	v_maxmin_num_f16 v169, 0xdf00, v169, neg(0xdf00)            ; d66b00a9 83ff52ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v180, v154                                ; 7f68d99a
(invalid instruction)                                        ; d58b009e
	v_cndmask_b32_e32 v0, v157, v128, vcc_lo                    ; 0201019d
	v_fma_mixlo_f16 v177, v19, v176, v61 op_sel_hi:[1,0,0]      ; cc2100b1 0cf76113
(invalid instruction)                                        ; d58b00a2
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
	v_maxmin_num_f16 v173, 0xdf00, v173, neg(0xdf00)            ; d66b00ad 83ff5aff 0000df00
(invalid instruction)                                        ; d58b00a6
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
(invalid instruction)                                        ; d58b00aa
	v_cndmask_b32_e32 v0, v169, v128, vcc_lo                    ; 020101a9
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v184, v155                                ; 7f70d99b
	v_fma_mixlo_f16 v181, v19, v180, v62 op_sel_hi:[1,0,0]      ; cc2100b5 0cfb6913
(invalid instruction)                                        ; d769009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
	v_maxmin_num_f16 v177, 0xdf00, v177, neg(0xdf00)            ; d66b00b1 83ff62ff 0000df00
(invalid instruction)                                        ; d76900a3
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v173, v128, vcc_lo                    ; 020101ad
(invalid instruction)                                        ; d76900a7
	v_cndmask_b32_e32 v0, v166, v128, vcc_lo                    ; 020101a6
(invalid instruction)                                        ; d76900ab
	v_cndmask_b32_e32 v0, v170, v128, vcc_lo                    ; 020101aa
	v_fma_mixlo_f16 v19, v19, v184, v63 op_sel_hi:[1,0,0]       ; cc210013 0cff7113
	v_maxmin_num_f16 v181, 0xdf00, v181, neg(0xdf00)            ; d66b00b5 83ff6aff 0000df00
(invalid instruction)                                        ; d58b00b2
	v_cndmask_b32_e32 v0, v177, v128, vcc_lo                    ; 020101b1
(invalid instruction)                                        ; d76900af
	v_cndmask_b32_e32 v0, v174, v128, vcc_lo                    ; 020101ae
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
(invalid instruction)                                        ; d58b00b6
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                    ; 020101b5
(invalid instruction)                                        ; d76900b3
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                    ; 020101b2
	v_cvt_f32_f16_e32 v185, v19                                 ; 7f721713
(invalid instruction)                                        ; d76900b7
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                    ; 020101b6
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900ba
	v_cndmask_b32_e32 v0, v185, v128, vcc_lo                    ; 020101b9
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v159, v22, s[28:31], null offen             ; c406007c 4080389f 00000016
	buffer_store_b8 v163, v22, s[28:31], null offen offset:16   ; c406007c 408038a3 00001016
	buffer_store_b8 v167, v22, s[28:31], null offen offset:32   ; c406007c 408038a7 00002016
	buffer_store_b8 v171, v22, s[28:31], null offen offset:48   ; c406007c 408038ab 00003016
	buffer_store_b8 v175, v22, s[28:31], null offen offset:64   ; c406007c 408038af 00004016
	buffer_store_b8 v179, v22, s[28:31], null offen offset:80   ; c406007c 408038b3 00005016
	buffer_store_b8 v183, v22, s[28:31], null offen offset:96   ; c406007c 408038b7 00006016
	buffer_store_b8 v186, v22, s[28:31], null offen offset:112  ; c406007c 408038ba 00007016
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v187, v25, s[28:31], null offen          ; c407807c 408038bb 00000019
	buffer_load_d16_u8 v188, v25, s[28:31], null offen offset:16 ; c407807c 408038bc 00001019
	buffer_load_d16_u8 v189, v25, s[28:31], null offen offset:32 ; c407807c 408038bd 00002019
	buffer_load_d16_u8 v190, v25, s[28:31], null offen offset:48 ; c407807c 408038be 00003019
	buffer_load_d16_u8 v191, v25, s[28:31], null offen offset:64 ; c407807c 408038bf 00004019
	buffer_load_d16_u8 v192, v25, s[28:31], null offen offset:80 ; c407807c 408038c0 00005019
	buffer_load_d16_u8 v193, v25, s[28:31], null offen offset:96 ; c407807c 408038c1 00006019
	buffer_load_d16_u8 v194, v25, s[28:31], null offen offset:112 ; c407807c 408038c2 00007019
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v195, v187                                ; 7f86d9bb
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v199, v188                                ; 7f8ed9bc
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v203, v189                                ; 7f96d9bd
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v207, v190                                ; 7f9ed9be
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v196, v20, v195, v64 op_sel_hi:[1,0,0]      ; cc2100c4 0d038714
	v_fma_mixlo_f16 v200, v20, v199, v65 op_sel_hi:[1,0,0]      ; cc2100c8 0d078f14
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v211, v191                                ; 7fa6d9bf
	v_fma_mixlo_f16 v204, v20, v203, v66 op_sel_hi:[1,0,0]      ; cc2100cc 0d0b9714
	v_fma_mixlo_f16 v208, v20, v207, v67 op_sel_hi:[1,0,0]      ; cc2100d0 0d0f9f14
	v_maxmin_num_f16 v196, 0xdf00, v196, neg(0xdf00)            ; d66b00c4 83ff88ff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v215, v192                                ; 7faed9c0
	v_maxmin_num_f16 v200, 0xdf00, v200, neg(0xdf00)            ; d66b00c8 83ff90ff 0000df00
	v_fma_mixlo_f16 v212, v20, v211, v68 op_sel_hi:[1,0,0]      ; cc2100d4 0d13a714
	v_maxmin_num_f16 v204, 0xdf00, v204, neg(0xdf00)            ; d66b00cc 83ff98ff 0000df00
	v_maxmin_num_f16 v208, 0xdf00, v208, neg(0xdf00)            ; d66b00d0 83ffa0ff 0000df00
(invalid instruction)                                        ; d58b00c5
	v_cndmask_b32_e32 v0, v196, v128, vcc_lo                    ; 020101c4
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v219, v193                                ; 7fb6d9c1
	v_fma_mixlo_f16 v216, v20, v215, v69 op_sel_hi:[1,0,0]      ; cc2100d8 0d17af14
(invalid instruction)                                        ; d58b00c9
	v_cndmask_b32_e32 v0, v200, v128, vcc_lo                    ; 020101c8
	v_maxmin_num_f16 v212, 0xdf00, v212, neg(0xdf00)            ; d66b00d4 83ffa8ff 0000df00
(invalid instruction)                                        ; d58b00cd
	v_cndmask_b32_e32 v0, v204, v128, vcc_lo                    ; 020101cc
(invalid instruction)                                        ; d58b00d1
	v_cndmask_b32_e32 v0, v208, v128, vcc_lo                    ; 020101d0
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v223, v194                                ; 7fbed9c2
(invalid instruction)                                        ; d76900c6
	v_cndmask_b32_e32 v0, v197, v128, vcc_lo                    ; 020101c5
	v_fma_mixlo_f16 v220, v20, v219, v70 op_sel_hi:[1,0,0]      ; cc2100dc 0d1bb714
	v_maxmin_num_f16 v216, 0xdf00, v216, neg(0xdf00)            ; d66b00d8 83ffb0ff 0000df00
(invalid instruction)                                        ; d76900ca
	v_cndmask_b32_e32 v0, v201, v128, vcc_lo                    ; 020101c9
(invalid instruction)                                        ; d58b00d5
	v_cndmask_b32_e32 v0, v212, v128, vcc_lo                    ; 020101d4
(invalid instruction)                                        ; d76900ce
	v_cndmask_b32_e32 v0, v205, v128, vcc_lo                    ; 020101cd
(invalid instruction)                                        ; d76900d2
	v_cndmask_b32_e32 v0, v209, v128, vcc_lo                    ; 020101d1
	v_fma_mixlo_f16 v20, v20, v223, v71 op_sel_hi:[1,0,0]       ; cc210014 0d1fbf14
	v_maxmin_num_f16 v220, 0xdf00, v220, neg(0xdf00)            ; d66b00dc 83ffb8ff 0000df00
(invalid instruction)                                        ; d58b00d9
	v_cndmask_b32_e32 v0, v216, v128, vcc_lo                    ; 020101d8
(invalid instruction)                                        ; d76900d6
	v_cndmask_b32_e32 v0, v213, v128, vcc_lo                    ; 020101d5
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
(invalid instruction)                                        ; d58b00dd
	v_cndmask_b32_e32 v0, v220, v128, vcc_lo                    ; 020101dc
(invalid instruction)                                        ; d76900da
	v_cndmask_b32_e32 v0, v217, v128, vcc_lo                    ; 020101d9
	v_cvt_f32_f16_e32 v224, v20                                 ; 7fc01714
(invalid instruction)                                        ; d76900de
	v_cndmask_b32_e32 v0, v221, v128, vcc_lo                    ; 020101dd
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900e1
	v_cndmask_b32_e32 v0, v224, v128, vcc_lo                    ; 020101e0
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v198, v24, s[28:31], null offen             ; c406007c 408038c6 00000018
	buffer_store_b8 v202, v24, s[28:31], null offen offset:16   ; c406007c 408038ca 00001018
	buffer_store_b8 v206, v24, s[28:31], null offen offset:32   ; c406007c 408038ce 00002018
	buffer_store_b8 v210, v24, s[28:31], null offen offset:48   ; c406007c 408038d2 00003018
	buffer_store_b8 v214, v24, s[28:31], null offen offset:64   ; c406007c 408038d6 00004018
	buffer_store_b8 v218, v24, s[28:31], null offen offset:80   ; c406007c 408038da 00005018
	buffer_store_b8 v222, v24, s[28:31], null offen offset:96   ; c406007c 408038de 00006018
	buffer_store_b8 v225, v24, s[28:31], null offen offset:112  ; c406007c 408038e1 00007018
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v226, v27, s[28:31], null offen          ; c407807c 408038e2 0000001b
	buffer_load_d16_u8 v227, v27, s[28:31], null offen offset:16 ; c407807c 408038e3 0000101b
	buffer_load_d16_u8 v228, v27, s[28:31], null offen offset:32 ; c407807c 408038e4 0000201b
	buffer_load_d16_u8 v229, v27, s[28:31], null offen offset:48 ; c407807c 408038e5 0000301b
	buffer_load_d16_u8 v230, v27, s[28:31], null offen offset:64 ; c407807c 408038e6 0000401b
	buffer_load_d16_u8 v231, v27, s[28:31], null offen offset:80 ; c407807c 408038e7 0000501b
	buffer_load_d16_u8 v232, v27, s[28:31], null offen offset:96 ; c407807c 408038e8 0000601b
	buffer_load_d16_u8 v233, v27, s[28:31], null offen offset:112 ; c407807c 408038e9 0000701b
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v234, v226                                ; 7fd4d9e2
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v238, v227                                ; 7fdcd9e3
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v242, v228                                ; 7fe4d9e4
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v246, v229                                ; 7fecd9e5
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v235, v21, v234, v72 op_sel_hi:[1,0,0]      ; cc2100eb 0d23d515
	v_fma_mixlo_f16 v239, v21, v238, v73 op_sel_hi:[1,0,0]      ; cc2100ef 0d27dd15
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v250, v230                                ; 7ff4d9e6
	v_fma_mixlo_f16 v243, v21, v242, v74 op_sel_hi:[1,0,0]      ; cc2100f3 0d2be515
	v_fma_mixlo_f16 v247, v21, v246, v75 op_sel_hi:[1,0,0]      ; cc2100f7 0d2fed15
	v_maxmin_num_f16 v235, 0xdf00, v235, neg(0xdf00)            ; d66b00eb 83ffd6ff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v254, v231                                ; 7ffcd9e7
	v_maxmin_num_f16 v239, 0xdf00, v239, neg(0xdf00)            ; d66b00ef 83ffdeff 0000df00
	v_fma_mixlo_f16 v251, v21, v250, v76 op_sel_hi:[1,0,0]      ; cc2100fb 0d33f515
	v_maxmin_num_f16 v243, 0xdf00, v243, neg(0xdf00)            ; d66b00f3 83ffe6ff 0000df00
	v_maxmin_num_f16 v247, 0xdf00, v247, neg(0xdf00)            ; d66b00f7 83ffeeff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v4, v232                                  ; 7e08d9e8
(invalid instruction)                                        ; d58b00ec
	v_cndmask_b32_e32 v0, v235, v128, vcc_lo                    ; 020101eb
	v_fma_mixlo_f16 v255, v21, v254, v77 op_sel_hi:[1,0,0]      ; cc2100ff 0d37fd15
(invalid instruction)                                        ; d58b00f0
	v_cndmask_b32_e32 v0, v239, v128, vcc_lo                    ; 020101ef
	v_maxmin_num_f16 v251, 0xdf00, v251, neg(0xdf00)            ; d66b00fb 83fff6ff 0000df00
(invalid instruction)                                        ; d58b00f4
	v_cndmask_b32_e32 v0, v243, v128, vcc_lo                    ; 020101f3
(invalid instruction)                                        ; d58b00f8
	v_cndmask_b32_e32 v0, v247, v128, vcc_lo                    ; 020101f7
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v11, v233                                 ; 7e16d9e9
	v_fma_mixlo_f16 v6, v21, v4, v78 op_sel_hi:[1,0,0]          ; cc210006 0d3a0915
(invalid instruction)                                        ; d76900ed
	v_cndmask_b32_e32 v0, v236, v128, vcc_lo                    ; 020101ec
	v_maxmin_num_f16 v255, 0xdf00, v255, neg(0xdf00)            ; d66b00ff 83fffeff 0000df00
(invalid instruction)                                        ; d76900f1
	v_cndmask_b32_e32 v0, v240, v128, vcc_lo                    ; 020101f0
(invalid instruction)                                        ; d58b00fc
	v_cndmask_b32_e32 v0, v251, v128, vcc_lo                    ; 020101fb
(invalid instruction)                                        ; d76900f5
	v_cndmask_b32_e32 v0, v244, v128, vcc_lo                    ; 020101f4
(invalid instruction)                                        ; d76900f9
	v_cndmask_b32_e32 v0, v248, v128, vcc_lo                    ; 020101f8
	v_fma_mixlo_f16 v21, v21, v11, v79 op_sel_hi:[1,0,0]        ; cc210015 0d3e1715
	v_maxmin_num_f16 v6, 0xdf00, v6, neg(0xdf00)                ; d66b0006 83fe0cff 0000df00
(invalid instruction)                                        ; d58b00ff
	v_cndmask_b32_e32 v0, v255, v128, vcc_lo                    ; 020101ff
(invalid instruction)                                        ; d76900fd
	v_cndmask_b32_e32 v0, v252, v128, vcc_lo                    ; 020101fc
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v21, 0xdf00, v21, neg(0xdf00)              ; d66b0015 83fe2aff 0000df00
	v_cvt_f32_f16_e32 v8, v6                                    ; 7e101706
(invalid instruction)                                        ; d76900ff
	v_cndmask_b32_e32 v0, v255, v128, vcc_lo                    ; 020101ff
	v_cvt_f32_f16_e32 v12, v21                                  ; 7e181715
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v0, v8, v128, vcc_lo                      ; 02010108
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                     ; 0201010c
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v237, v9, s[28:31], null offen              ; c406007c 408038ed 00000009
	buffer_store_b8 v241, v9, s[28:31], null offen offset:16    ; c406007c 408038f1 00001009
	buffer_store_b8 v245, v9, s[28:31], null offen offset:32    ; c406007c 408038f5 00002009
	buffer_store_b8 v249, v9, s[28:31], null offen offset:48    ; c406007c 408038f9 00003009
	buffer_store_b8 v253, v9, s[28:31], null offen offset:64    ; c406007c 408038fd 00004009
	buffer_store_b8 v255, v9, s[28:31], null offen offset:80    ; c406007c 408038ff 00005009
	buffer_store_b8 v10, v9, s[28:31], null offen offset:96     ; c406007c 4080380a 00006009
	buffer_store_b8 v13, v9, s[28:31], null offen offset:112    ; c406007c 4080380d 00007009
BB63:
	s_cmp_lt_u32 s18, s6                                        ; bf0a0612
	s_cbranch_scc0 BB66                                         ; bfa10262
BB64:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[12:13], 0x40                        ; f4004606 f8000040
	s_load_b128 s[28:31], s[12:13], 0x10                        ; f4004706 f8000010
	v_add3_u32 v4, v7, s5, v1                                   ; d6550004 04040b07
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v4, 1, v4                                 ; 30080881
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v6, v4, s[24:27], null offen            ; c408007c 40803006 00000004
	v_and_b32_e32 v9, 16, v0                                    ; 36120090
	s_lshr_b32 s1, s7, 4                                        ; 85018407
	v_lshrrev_b32_e32 v8, 4, v1                                 ; 32100284
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s19, s19, s1                                      ; 96130113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshl_or_b32 v9, v9, 3, v7                                 ; d6560009 041d0709
	v_add_lshl_u32 v8, s19, v8, 8                               ; d6470008 02221013
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v10, v9, s2, v8                                  ; d655000a 04200509
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v11, v10, s[28:31], null offen           ; c407807c 4080380b 0000000a
	buffer_load_d16_u8 v12, v10, s[28:31], null offen offset:16 ; c407807c 4080380c 0000100a
	buffer_load_d16_u8 v13, v10, s[28:31], null offen offset:32 ; c407807c 4080380d 0000200a
	buffer_load_d16_u8 v14, v10, s[28:31], null offen offset:48 ; c407807c 4080380e 0000300a
	buffer_load_d16_u8 v15, v10, s[28:31], null offen offset:64 ; c407807c 4080380f 0000400a
	buffer_load_d16_u8 v16, v10, s[28:31], null offen offset:80 ; c407807c 40803810 0000500a
	buffer_load_d16_u8 v17, v10, s[28:31], null offen offset:96 ; c407807c 40803811 0000600a
	buffer_load_d16_u8 v18, v10, s[28:31], null offen offset:112 ; c407807c 40803812 0000700a
	s_clause 0x2                                                ; bf850002
	buffer_load_d16_b16 v19, v4, s[24:27], null offen offset:32 ; c408007c 40803013 00002004
	buffer_load_d16_b16 v20, v4, s[24:27], null offen offset:64 ; c408007c 40803014 00004004
	buffer_load_d16_b16 v21, v4, s[24:27], null offen offset:96 ; c408007c 40803015 00006004
	v_lshrrev_b32_e32 v22, 4, v2                                ; 322c0484
	v_add3_u32 v8, v9, s3, v8                                   ; d6550008 04200709
	v_lshrrev_b32_e32 v24, 4, v5                                ; 32300a84
	v_lshrrev_b32_e32 v26, 4, v3                                ; 32340684
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_add_lshl_u32 v22, s19, v22, 8                             ; d6470016 02222c13
	v_add_lshl_u32 v24, s19, v24, 8                             ; d6470018 02223013
	v_add_lshl_u32 v26, s19, v26, 8                             ; d647001a 02223413
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_add3_u32 v23, v9, s2, v22                                 ; d6550017 04580509
	v_add3_u32 v22, v9, s3, v22                                 ; d6550016 04580709
	v_add3_u32 v25, v9, s2, v24                                 ; d6550019 04600509
	v_add3_u32 v24, v9, s3, v24                                 ; d6550018 04600709
	v_add3_u32 v27, v9, s2, v26                                 ; d655001b 04680509
	v_add3_u32 v9, v9, s3, v26                                  ; d6550009 04680709
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cvt_f32_fp8_e32 v28, v11                                  ; 7e38d90b
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_cvt_f32_fp8_e32 v32, v12                                  ; 7e40d90c
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cvt_f32_fp8_e32 v36, v13                                  ; 7e48d90d
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v40, v14                                  ; 7e50d90e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v29, v6, v28, v80 op_sel_hi:[1,0,0]         ; cc21001d 0d423906
	v_fma_mixlo_f16 v33, v6, v32, v81 op_sel_hi:[1,0,0]         ; cc210021 0d464106
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v44, v15                                  ; 7e58d90f
	v_fma_mixlo_f16 v37, v6, v36, v82 op_sel_hi:[1,0,0]         ; cc210025 0d4a4906
	v_fma_mixlo_f16 v41, v6, v40, v83 op_sel_hi:[1,0,0]         ; cc210029 0d4e5106
	v_maxmin_num_f16 v29, 0xdf00, v29, neg(0xdf00)              ; d66b001d 83fe3aff 0000df00
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v48, v16                                  ; 7e60d910
	v_maxmin_num_f16 v33, 0xdf00, v33, neg(0xdf00)              ; d66b0021 83fe42ff 0000df00
	v_fma_mixlo_f16 v45, v6, v44, v84 op_sel_hi:[1,0,0]         ; cc21002d 0d525906
	v_maxmin_num_f16 v37, 0xdf00, v37, neg(0xdf00)              ; d66b0025 83fe4aff 0000df00
	v_maxmin_num_f16 v41, 0xdf00, v41, neg(0xdf00)              ; d66b0029 83fe52ff 0000df00
	v_cvt_f32_f16_e32 v30, v29                                  ; 7e3c171d
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v52, v17                                  ; 7e68d911
	v_fma_mixlo_f16 v49, v6, v48, v85 op_sel_hi:[1,0,0]         ; cc210031 0d566106
	v_cvt_f32_f16_e32 v34, v33                                  ; 7e441721
	v_maxmin_num_f16 v45, 0xdf00, v45, neg(0xdf00)              ; d66b002d 83fe5aff 0000df00
	v_cvt_f32_f16_e32 v38, v37                                  ; 7e4c1725
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v56, v18                                  ; 7e70d912
	v_cvt_f32_f16_e32 v42, v41                                  ; 7e541729
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v0, v30, v128, vcc_lo                     ; 0201011e
	v_fma_mixlo_f16 v53, v6, v52, v86 op_sel_hi:[1,0,0]         ; cc210035 0d5a6906
	v_maxmin_num_f16 v49, 0xdf00, v49, neg(0xdf00)              ; d66b0031 83fe62ff 0000df00
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v0, v34, v128, vcc_lo                     ; 02010122
	v_cvt_f32_f16_e32 v46, v45                                  ; 7e5c172d
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v0, v38, v128, vcc_lo                     ; 02010126
	v_fma_mixlo_f16 v6, v6, v56, v87 op_sel_hi:[1,0,0]          ; cc210006 0d5e7106
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v0, v42, v128, vcc_lo                     ; 0201012a
	v_maxmin_num_f16 v53, 0xdf00, v53, neg(0xdf00)              ; d66b0035 83fe6aff 0000df00
	v_cvt_f32_f16_e32 v50, v49                                  ; 7e641731
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
	v_maxmin_num_f16 v6, 0xdf00, v6, neg(0xdf00)                ; d66b0006 83fe0cff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_cvt_f32_f16_e32 v54, v53                                  ; 7e6c1735
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v0, v50, v128, vcc_lo                     ; 02010132
	v_cvt_f32_f16_e32 v57, v6                                   ; 7e721706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v0, v54, v128, vcc_lo                     ; 02010136
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                     ; 02010139
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v31, v8, s[28:31], null offen               ; c406007c 4080381f 00000008
	buffer_store_b8 v35, v8, s[28:31], null offen offset:16     ; c406007c 40803823 00001008
	buffer_store_b8 v39, v8, s[28:31], null offen offset:32     ; c406007c 40803827 00002008
	buffer_store_b8 v43, v8, s[28:31], null offen offset:48     ; c406007c 4080382b 00003008
	buffer_store_b8 v47, v8, s[28:31], null offen offset:64     ; c406007c 4080382f 00004008
	buffer_store_b8 v51, v8, s[28:31], null offen offset:80     ; c406007c 40803833 00005008
	buffer_store_b8 v55, v8, s[28:31], null offen offset:96     ; c406007c 40803837 00006008
	buffer_store_b8 v58, v8, s[28:31], null offen offset:112    ; c406007c 4080383a 00007008
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v59, v23, s[28:31], null offen           ; c407807c 4080383b 00000017
	buffer_load_d16_u8 v60, v23, s[28:31], null offen offset:16 ; c407807c 4080383c 00001017
	buffer_load_d16_u8 v61, v23, s[28:31], null offen offset:32 ; c407807c 4080383d 00002017
	buffer_load_d16_u8 v62, v23, s[28:31], null offen offset:48 ; c407807c 4080383e 00003017
	buffer_load_d16_u8 v63, v23, s[28:31], null offen offset:64 ; c407807c 4080383f 00004017
	buffer_load_d16_u8 v64, v23, s[28:31], null offen offset:80 ; c407807c 40803840 00005017
	buffer_load_d16_u8 v65, v23, s[28:31], null offen offset:96 ; c407807c 40803841 00006017
	buffer_load_d16_u8 v66, v23, s[28:31], null offen offset:112 ; c407807c 40803842 00007017
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v67, v59                                  ; 7e86d93b
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v71, v60                                  ; 7e8ed93c
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v75, v61                                  ; 7e96d93d
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v79, v62                                  ; 7e9ed93e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v68, v19, v67, v88 op_sel_hi:[1,0,0]        ; cc210044 0d628713
	v_fma_mixlo_f16 v72, v19, v71, v89 op_sel_hi:[1,0,0]        ; cc210048 0d668f13
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v83, v63                                  ; 7ea6d93f
	v_fma_mixlo_f16 v76, v19, v75, v90 op_sel_hi:[1,0,0]        ; cc21004c 0d6a9713
	v_fma_mixlo_f16 v80, v19, v79, v91 op_sel_hi:[1,0,0]        ; cc210050 0d6e9f13
	v_maxmin_num_f16 v68, 0xdf00, v68, neg(0xdf00)              ; d66b0044 83fe88ff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v87, v64                                  ; 7eaed940
	v_maxmin_num_f16 v72, 0xdf00, v72, neg(0xdf00)              ; d66b0048 83fe90ff 0000df00
	v_fma_mixlo_f16 v84, v19, v83, v92 op_sel_hi:[1,0,0]        ; cc210054 0d72a713
	v_maxmin_num_f16 v76, 0xdf00, v76, neg(0xdf00)              ; d66b004c 83fe98ff 0000df00
	v_maxmin_num_f16 v80, 0xdf00, v80, neg(0xdf00)              ; d66b0050 83fea0ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v91, v65                                  ; 7eb6d941
	v_cvt_f32_f16_e32 v69, v68                                  ; 7e8a1744
	v_fma_mixlo_f16 v88, v19, v87, v93 op_sel_hi:[1,0,0]        ; cc210058 0d76af13
	v_cvt_f32_f16_e32 v73, v72                                  ; 7e921748
	v_maxmin_num_f16 v84, 0xdf00, v84, neg(0xdf00)              ; d66b0054 83fea8ff 0000df00
	v_cvt_f32_f16_e32 v77, v76                                  ; 7e9a174c
	v_cvt_f32_f16_e32 v81, v80                                  ; 7ea21750
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v144, v66                                 ; 7f20d942
	v_fma_mixlo_f16 v92, v19, v91, v94 op_sel_hi:[1,0,0]        ; cc21005c 0d7ab713
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v0, v69, v128, vcc_lo                     ; 02010145
	v_maxmin_num_f16 v88, 0xdf00, v88, neg(0xdf00)              ; d66b0058 83feb0ff 0000df00
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v0, v73, v128, vcc_lo                     ; 02010149
	v_cvt_f32_f16_e32 v85, v84                                  ; 7eaa1754
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v0, v77, v128, vcc_lo                     ; 0201014d
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v0, v81, v128, vcc_lo                     ; 02010151
	v_fma_mixlo_f16 v19, v19, v144, v95 op_sel_hi:[1,0,0]       ; cc210013 0d7f2113
	v_maxmin_num_f16 v92, 0xdf00, v92, neg(0xdf00)              ; d66b005c 83feb8ff 0000df00
	v_cvt_f32_f16_e32 v89, v88                                  ; 7eb21758
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v0, v85, v128, vcc_lo                     ; 02010155
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
	v_cvt_f32_f16_e32 v93, v92                                  ; 7eba175c
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v0, v89, v128, vcc_lo                     ; 02010159
	v_cvt_f32_f16_e32 v145, v19                                 ; 7f221713
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v0, v93, v128, vcc_lo                     ; 0201015d
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690092
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                    ; 02010191
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v70, v22, s[28:31], null offen              ; c406007c 40803846 00000016
	buffer_store_b8 v74, v22, s[28:31], null offen offset:16    ; c406007c 4080384a 00001016
	buffer_store_b8 v78, v22, s[28:31], null offen offset:32    ; c406007c 4080384e 00002016
	buffer_store_b8 v82, v22, s[28:31], null offen offset:48    ; c406007c 40803852 00003016
	buffer_store_b8 v86, v22, s[28:31], null offen offset:64    ; c406007c 40803856 00004016
	buffer_store_b8 v90, v22, s[28:31], null offen offset:80    ; c406007c 4080385a 00005016
	buffer_store_b8 v94, v22, s[28:31], null offen offset:96    ; c406007c 4080385e 00006016
	buffer_store_b8 v146, v22, s[28:31], null offen offset:112  ; c406007c 40803892 00007016
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v147, v25, s[28:31], null offen          ; c407807c 40803893 00000019
	buffer_load_d16_u8 v148, v25, s[28:31], null offen offset:16 ; c407807c 40803894 00001019
	buffer_load_d16_u8 v149, v25, s[28:31], null offen offset:32 ; c407807c 40803895 00002019
	buffer_load_d16_u8 v150, v25, s[28:31], null offen offset:48 ; c407807c 40803896 00003019
	buffer_load_d16_u8 v151, v25, s[28:31], null offen offset:64 ; c407807c 40803897 00004019
	buffer_load_d16_u8 v152, v25, s[28:31], null offen offset:80 ; c407807c 40803898 00005019
	buffer_load_d16_u8 v153, v25, s[28:31], null offen offset:96 ; c407807c 40803899 00006019
	buffer_load_d16_u8 v154, v25, s[28:31], null offen offset:112 ; c407807c 4080389a 00007019
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v155, v147                                ; 7f36d993
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v159, v148                                ; 7f3ed994
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v163, v149                                ; 7f46d995
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v167, v150                                ; 7f4ed996
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v156, v20, v155, v96 op_sel_hi:[1,0,0]      ; cc21009c 0d833714
	v_fma_mixlo_f16 v160, v20, v159, v97 op_sel_hi:[1,0,0]      ; cc2100a0 0d873f14
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v171, v151                                ; 7f56d997
	v_fma_mixlo_f16 v164, v20, v163, v98 op_sel_hi:[1,0,0]      ; cc2100a4 0d8b4714
	v_fma_mixlo_f16 v168, v20, v167, v99 op_sel_hi:[1,0,0]      ; cc2100a8 0d8f4f14
	v_maxmin_num_f16 v156, 0xdf00, v156, neg(0xdf00)            ; d66b009c 83ff38ff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v175, v152                                ; 7f5ed998
	v_maxmin_num_f16 v160, 0xdf00, v160, neg(0xdf00)            ; d66b00a0 83ff40ff 0000df00
	v_fma_mixlo_f16 v172, v20, v171, v100 op_sel_hi:[1,0,0]     ; cc2100ac 0d935714
	v_maxmin_num_f16 v164, 0xdf00, v164, neg(0xdf00)            ; d66b00a4 83ff48ff 0000df00
	v_maxmin_num_f16 v168, 0xdf00, v168, neg(0xdf00)            ; d66b00a8 83ff50ff 0000df00
(invalid instruction)                                        ; d58b009d
	v_cndmask_b32_e32 v0, v156, v128, vcc_lo                    ; 0201019c
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v179, v153                                ; 7f66d999
	v_fma_mixlo_f16 v176, v20, v175, v101 op_sel_hi:[1,0,0]     ; cc2100b0 0d975f14
(invalid instruction)                                        ; d58b00a1
	v_cndmask_b32_e32 v0, v160, v128, vcc_lo                    ; 020101a0
	v_maxmin_num_f16 v172, 0xdf00, v172, neg(0xdf00)            ; d66b00ac 83ff58ff 0000df00
(invalid instruction)                                        ; d58b00a5
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
(invalid instruction)                                        ; d58b00a9
	v_cndmask_b32_e32 v0, v168, v128, vcc_lo                    ; 020101a8
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v183, v154                                ; 7f6ed99a
(invalid instruction)                                        ; d769009e
	v_cndmask_b32_e32 v0, v157, v128, vcc_lo                    ; 0201019d
	v_fma_mixlo_f16 v180, v20, v179, v102 op_sel_hi:[1,0,0]     ; cc2100b4 0d9b6714
	v_maxmin_num_f16 v176, 0xdf00, v176, neg(0xdf00)            ; d66b00b0 83ff60ff 0000df00
(invalid instruction)                                        ; d76900a2
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
(invalid instruction)                                        ; d58b00ad
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
(invalid instruction)                                        ; d76900a6
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
(invalid instruction)                                        ; d76900aa
	v_cndmask_b32_e32 v0, v169, v128, vcc_lo                    ; 020101a9
	v_fma_mixlo_f16 v20, v20, v183, v103 op_sel_hi:[1,0,0]      ; cc210014 0d9f6f14
	v_maxmin_num_f16 v180, 0xdf00, v180, neg(0xdf00)            ; d66b00b4 83ff68ff 0000df00
(invalid instruction)                                        ; d58b00b1
	v_cndmask_b32_e32 v0, v176, v128, vcc_lo                    ; 020101b0
(invalid instruction)                                        ; d76900ae
	v_cndmask_b32_e32 v0, v173, v128, vcc_lo                    ; 020101ad
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
(invalid instruction)                                        ; d58b00b5
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                    ; 020101b4
(invalid instruction)                                        ; d76900b2
	v_cndmask_b32_e32 v0, v177, v128, vcc_lo                    ; 020101b1
	v_cvt_f32_f16_e32 v184, v20                                 ; 7f701714
(invalid instruction)                                        ; d76900b6
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                    ; 020101b5
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900b9
	v_cndmask_b32_e32 v0, v184, v128, vcc_lo                    ; 020101b8
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v158, v24, s[28:31], null offen             ; c406007c 4080389e 00000018
	buffer_store_b8 v162, v24, s[28:31], null offen offset:16   ; c406007c 408038a2 00001018
	buffer_store_b8 v166, v24, s[28:31], null offen offset:32   ; c406007c 408038a6 00002018
	buffer_store_b8 v170, v24, s[28:31], null offen offset:48   ; c406007c 408038aa 00003018
	buffer_store_b8 v174, v24, s[28:31], null offen offset:64   ; c406007c 408038ae 00004018
	buffer_store_b8 v178, v24, s[28:31], null offen offset:80   ; c406007c 408038b2 00005018
	buffer_store_b8 v182, v24, s[28:31], null offen offset:96   ; c406007c 408038b6 00006018
	buffer_store_b8 v185, v24, s[28:31], null offen offset:112  ; c406007c 408038b9 00007018
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v186, v27, s[28:31], null offen          ; c407807c 408038ba 0000001b
	buffer_load_d16_u8 v187, v27, s[28:31], null offen offset:16 ; c407807c 408038bb 0000101b
	buffer_load_d16_u8 v188, v27, s[28:31], null offen offset:32 ; c407807c 408038bc 0000201b
	buffer_load_d16_u8 v189, v27, s[28:31], null offen offset:48 ; c407807c 408038bd 0000301b
	buffer_load_d16_u8 v190, v27, s[28:31], null offen offset:64 ; c407807c 408038be 0000401b
	buffer_load_d16_u8 v191, v27, s[28:31], null offen offset:80 ; c407807c 408038bf 0000501b
	buffer_load_d16_u8 v192, v27, s[28:31], null offen offset:96 ; c407807c 408038c0 0000601b
	buffer_load_d16_u8 v193, v27, s[28:31], null offen offset:112 ; c407807c 408038c1 0000701b
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v194, v186                                ; 7f84d9ba
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v198, v187                                ; 7f8cd9bb
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v202, v188                                ; 7f94d9bc
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v206, v189                                ; 7f9cd9bd
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v195, v21, v194, v104 op_sel_hi:[1,0,0]     ; cc2100c3 0da38515
	v_fma_mixlo_f16 v199, v21, v198, v105 op_sel_hi:[1,0,0]     ; cc2100c7 0da78d15
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v210, v190                                ; 7fa4d9be
	v_fma_mixlo_f16 v203, v21, v202, v106 op_sel_hi:[1,0,0]     ; cc2100cb 0dab9515
	v_fma_mixlo_f16 v207, v21, v206, v107 op_sel_hi:[1,0,0]     ; cc2100cf 0daf9d15
	v_maxmin_num_f16 v195, 0xdf00, v195, neg(0xdf00)            ; d66b00c3 83ff86ff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v214, v191                                ; 7facd9bf
	v_maxmin_num_f16 v199, 0xdf00, v199, neg(0xdf00)            ; d66b00c7 83ff8eff 0000df00
	v_fma_mixlo_f16 v211, v21, v210, v108 op_sel_hi:[1,0,0]     ; cc2100d3 0db3a515
	v_maxmin_num_f16 v203, 0xdf00, v203, neg(0xdf00)            ; d66b00cb 83ff96ff 0000df00
	v_maxmin_num_f16 v207, 0xdf00, v207, neg(0xdf00)            ; d66b00cf 83ff9eff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v218, v192                                ; 7fb4d9c0
(invalid instruction)                                        ; d58b00c4
	v_cndmask_b32_e32 v0, v195, v128, vcc_lo                    ; 020101c3
	v_fma_mixlo_f16 v215, v21, v214, v109 op_sel_hi:[1,0,0]     ; cc2100d7 0db7ad15
(invalid instruction)                                        ; d58b00c8
	v_cndmask_b32_e32 v0, v199, v128, vcc_lo                    ; 020101c7
	v_maxmin_num_f16 v211, 0xdf00, v211, neg(0xdf00)            ; d66b00d3 83ffa6ff 0000df00
(invalid instruction)                                        ; d58b00cc
	v_cndmask_b32_e32 v0, v203, v128, vcc_lo                    ; 020101cb
(invalid instruction)                                        ; d58b00d0
	v_cndmask_b32_e32 v0, v207, v128, vcc_lo                    ; 020101cf
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v222, v193                                ; 7fbcd9c1
	v_fma_mixlo_f16 v219, v21, v218, v110 op_sel_hi:[1,0,0]     ; cc2100db 0dbbb515
(invalid instruction)                                        ; d76900c5
	v_cndmask_b32_e32 v0, v196, v128, vcc_lo                    ; 020101c4
	v_maxmin_num_f16 v215, 0xdf00, v215, neg(0xdf00)            ; d66b00d7 83ffaeff 0000df00
(invalid instruction)                                        ; d76900c9
	v_cndmask_b32_e32 v0, v200, v128, vcc_lo                    ; 020101c8
(invalid instruction)                                        ; d58b00d4
	v_cndmask_b32_e32 v0, v211, v128, vcc_lo                    ; 020101d3
(invalid instruction)                                        ; d76900cd
	v_cndmask_b32_e32 v0, v204, v128, vcc_lo                    ; 020101cc
(invalid instruction)                                        ; d76900d1
	v_cndmask_b32_e32 v0, v208, v128, vcc_lo                    ; 020101d0
	v_fma_mixlo_f16 v21, v21, v222, v111 op_sel_hi:[1,0,0]      ; cc210015 0dbfbd15
	v_maxmin_num_f16 v219, 0xdf00, v219, neg(0xdf00)            ; d66b00db 83ffb6ff 0000df00
(invalid instruction)                                        ; d58b00d8
	v_cndmask_b32_e32 v0, v215, v128, vcc_lo                    ; 020101d7
(invalid instruction)                                        ; d76900d5
	v_cndmask_b32_e32 v0, v212, v128, vcc_lo                    ; 020101d4
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v21, 0xdf00, v21, neg(0xdf00)              ; d66b0015 83fe2aff 0000df00
(invalid instruction)                                        ; d58b00dc
	v_cndmask_b32_e32 v0, v219, v128, vcc_lo                    ; 020101db
(invalid instruction)                                        ; d76900d9
	v_cndmask_b32_e32 v0, v216, v128, vcc_lo                    ; 020101d8
	v_cvt_f32_f16_e32 v223, v21                                 ; 7fbe1715
(invalid instruction)                                        ; d76900dd
	v_cndmask_b32_e32 v0, v220, v128, vcc_lo                    ; 020101dc
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900e0
	v_cndmask_b32_e32 v0, v223, v128, vcc_lo                    ; 020101df
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v197, v9, s[28:31], null offen              ; c406007c 408038c5 00000009
	buffer_store_b8 v201, v9, s[28:31], null offen offset:16    ; c406007c 408038c9 00001009
	buffer_store_b8 v205, v9, s[28:31], null offen offset:32    ; c406007c 408038cd 00002009
	buffer_store_b8 v209, v9, s[28:31], null offen offset:48    ; c406007c 408038d1 00003009
	buffer_store_b8 v213, v9, s[28:31], null offen offset:64    ; c406007c 408038d5 00004009
	buffer_store_b8 v217, v9, s[28:31], null offen offset:80    ; c406007c 408038d9 00005009
	buffer_store_b8 v221, v9, s[28:31], null offen offset:96    ; c406007c 408038dd 00006009
	buffer_store_b8 v224, v9, s[28:31], null offen offset:112   ; c406007c 408038e0 00007009
BB66:
	s_cmp_lt_u32 s21, s6                                        ; bf0a0615
	s_cbranch_scc0 BB69                                         ; bfa1025a
BB67:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[12:13], 0x40                        ; f4004406 f8000040
	s_load_b128 s[24:27], s[12:13], 0x10                        ; f4004606 f8000010
	v_and_b32_e32 v6, 16, v0                                    ; 360c0090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshl_or_b32 v6, v6, 3, v7                                 ; d6560006 041d0706
	v_add3_u32 v7, v7, s5, v1                                   ; d6550007 04040b07
	v_lshlrev_b32_e32 v7, 1, v7                                 ; 300e0e81
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v8, v7, s[16:19], null offen            ; c408007c 40802008 00000007
	v_lshrrev_b32_e32 v4, 4, v1                                 ; 32080284
	s_lshr_b32 s7, s7, 4                                        ; 85078407
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b9
	s_mul_i32 s22, s22, s7                                      ; 96160716
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v4, s22, v4, 8                               ; d6470004 02220816
	v_add3_u32 v9, v6, s2, v4                                   ; d6550009 04100506
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v10, v9, s[24:27], null offen            ; c407807c 4080300a 00000009
	buffer_load_d16_u8 v11, v9, s[24:27], null offen offset:16  ; c407807c 4080300b 00001009
	buffer_load_d16_u8 v12, v9, s[24:27], null offen offset:32  ; c407807c 4080300c 00002009
	buffer_load_d16_u8 v13, v9, s[24:27], null offen offset:48  ; c407807c 4080300d 00003009
	buffer_load_d16_u8 v14, v9, s[24:27], null offen offset:64  ; c407807c 4080300e 00004009
	buffer_load_d16_u8 v15, v9, s[24:27], null offen offset:80  ; c407807c 4080300f 00005009
	buffer_load_d16_u8 v16, v9, s[24:27], null offen offset:96  ; c407807c 40803010 00006009
	buffer_load_d16_u8 v17, v9, s[24:27], null offen offset:112 ; c407807c 40803011 00007009
	s_clause 0x2                                                ; bf850002
	buffer_load_d16_b16 v18, v7, s[16:19], null offen offset:32 ; c408007c 40802012 00002007
	buffer_load_d16_b16 v19, v7, s[16:19], null offen offset:64 ; c408007c 40802013 00004007
	buffer_load_d16_b16 v20, v7, s[16:19], null offen offset:96 ; c408007c 40802014 00006007
	v_lshrrev_b32_e32 v2, 4, v2                                 ; 32040484
	v_add3_u32 v4, v6, s3, v4                                   ; d6550004 04100706
	v_lshrrev_b32_e32 v5, 4, v5                                 ; 320a0a84
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_add_lshl_u32 v2, s22, v2, 8                               ; d6470002 02220416
	v_add_lshl_u32 v5, s22, v5, 8                               ; d6470005 02220a16
	v_add_lshl_u32 v3, s22, v3, 8                               ; d6470003 02220616
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_add3_u32 v21, v6, s2, v2                                  ; d6550015 04080506
	v_add3_u32 v2, v6, s3, v2                                   ; d6550002 04080706
	v_add3_u32 v22, v6, s2, v5                                  ; d6550016 04140506
	v_add3_u32 v5, v6, s3, v5                                   ; d6550005 04140706
	v_add3_u32 v23, v6, s2, v3                                  ; d6550017 040c0506
	v_add3_u32 v6, v6, s3, v3                                   ; d6550006 040c0706
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cvt_f32_fp8_e32 v24, v10                                  ; 7e30d90a
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_cvt_f32_fp8_e32 v28, v11                                  ; 7e38d90b
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cvt_f32_fp8_e32 v32, v12                                  ; 7e40d90c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v36, v13                                  ; 7e48d90d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v25, v8, v24, v112 op_sel_hi:[1,0,0]        ; cc210019 0dc23108
	v_fma_mixlo_f16 v29, v8, v28, v113 op_sel_hi:[1,0,0]        ; cc21001d 0dc63908
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v40, v14                                  ; 7e50d90e
	v_fma_mixlo_f16 v33, v8, v32, v114 op_sel_hi:[1,0,0]        ; cc210021 0dca4108
	v_fma_mixlo_f16 v37, v8, v36, v115 op_sel_hi:[1,0,0]        ; cc210025 0dce4908
	v_maxmin_num_f16 v25, 0xdf00, v25, neg(0xdf00)              ; d66b0019 83fe32ff 0000df00
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v44, v15                                  ; 7e58d90f
	v_maxmin_num_f16 v29, 0xdf00, v29, neg(0xdf00)              ; d66b001d 83fe3aff 0000df00
	v_fma_mixlo_f16 v41, v8, v40, v116 op_sel_hi:[1,0,0]        ; cc210029 0dd25108
	v_maxmin_num_f16 v33, 0xdf00, v33, neg(0xdf00)              ; d66b0021 83fe42ff 0000df00
	v_maxmin_num_f16 v37, 0xdf00, v37, neg(0xdf00)              ; d66b0025 83fe4aff 0000df00
	v_cvt_f32_f16_e32 v26, v25                                  ; 7e341719
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v48, v16                                  ; 7e60d910
	v_fma_mixlo_f16 v45, v8, v44, v117 op_sel_hi:[1,0,0]        ; cc21002d 0dd65908
	v_cvt_f32_f16_e32 v30, v29                                  ; 7e3c171d
	v_maxmin_num_f16 v41, 0xdf00, v41, neg(0xdf00)              ; d66b0029 83fe52ff 0000df00
	v_cvt_f32_f16_e32 v34, v33                                  ; 7e441721
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v52, v17                                  ; 7e68d911
	v_cvt_f32_f16_e32 v38, v37                                  ; 7e4c1725
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
	v_fma_mixlo_f16 v49, v8, v48, v118 op_sel_hi:[1,0,0]        ; cc210031 0dda6108
	v_maxmin_num_f16 v45, 0xdf00, v45, neg(0xdf00)              ; d66b002d 83fe5aff 0000df00
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v0, v30, v128, vcc_lo                     ; 0201011e
	v_cvt_f32_f16_e32 v42, v41                                  ; 7e541729
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v0, v34, v128, vcc_lo                     ; 02010122
	v_fma_mixlo_f16 v8, v8, v52, v119 op_sel_hi:[1,0,0]         ; cc210008 0dde6908
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v0, v38, v128, vcc_lo                     ; 02010126
	v_maxmin_num_f16 v49, 0xdf00, v49, neg(0xdf00)              ; d66b0031 83fe62ff 0000df00
	v_cvt_f32_f16_e32 v46, v45                                  ; 7e5c172d
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v0, v42, v128, vcc_lo                     ; 0201012a
	v_maxmin_num_f16 v8, 0xdf00, v8, neg(0xdf00)                ; d66b0008 83fe10ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_cvt_f32_f16_e32 v50, v49                                  ; 7e641731
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
	v_cvt_f32_f16_e32 v53, v8                                   ; 7e6a1708
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v0, v50, v128, vcc_lo                     ; 02010132
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v0, v53, v128, vcc_lo                     ; 02010135
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v27, v4, s[24:27], null offen               ; c406007c 4080301b 00000004
	buffer_store_b8 v31, v4, s[24:27], null offen offset:16     ; c406007c 4080301f 00001004
	buffer_store_b8 v35, v4, s[24:27], null offen offset:32     ; c406007c 40803023 00002004
	buffer_store_b8 v39, v4, s[24:27], null offen offset:48     ; c406007c 40803027 00003004
	buffer_store_b8 v43, v4, s[24:27], null offen offset:64     ; c406007c 4080302b 00004004
	buffer_store_b8 v47, v4, s[24:27], null offen offset:80     ; c406007c 4080302f 00005004
	buffer_store_b8 v51, v4, s[24:27], null offen offset:96     ; c406007c 40803033 00006004
	buffer_store_b8 v54, v4, s[24:27], null offen offset:112    ; c406007c 40803036 00007004
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v55, v21, s[24:27], null offen           ; c407807c 40803037 00000015
	buffer_load_d16_u8 v56, v21, s[24:27], null offen offset:16 ; c407807c 40803038 00001015
	buffer_load_d16_u8 v57, v21, s[24:27], null offen offset:32 ; c407807c 40803039 00002015
	buffer_load_d16_u8 v58, v21, s[24:27], null offen offset:48 ; c407807c 4080303a 00003015
	buffer_load_d16_u8 v59, v21, s[24:27], null offen offset:64 ; c407807c 4080303b 00004015
	buffer_load_d16_u8 v60, v21, s[24:27], null offen offset:80 ; c407807c 4080303c 00005015
	buffer_load_d16_u8 v61, v21, s[24:27], null offen offset:96 ; c407807c 4080303d 00006015
	buffer_load_d16_u8 v62, v21, s[24:27], null offen offset:112 ; c407807c 4080303e 00007015
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v63, v55                                  ; 7e7ed937
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v67, v56                                  ; 7e86d938
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v71, v57                                  ; 7e8ed939
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v75, v58                                  ; 7e96d93a
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v64, v18, v63, v120 op_sel_hi:[1,0,0]       ; cc210040 0de27f12
	v_fma_mixlo_f16 v68, v18, v67, v121 op_sel_hi:[1,0,0]       ; cc210044 0de68712
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v79, v59                                  ; 7e9ed93b
	v_fma_mixlo_f16 v72, v18, v71, v122 op_sel_hi:[1,0,0]       ; cc210048 0dea8f12
	v_fma_mixlo_f16 v76, v18, v75, v123 op_sel_hi:[1,0,0]       ; cc21004c 0dee9712
	v_maxmin_num_f16 v64, 0xdf00, v64, neg(0xdf00)              ; d66b0040 83fe80ff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v83, v60                                  ; 7ea6d93c
	v_maxmin_num_f16 v68, 0xdf00, v68, neg(0xdf00)              ; d66b0044 83fe88ff 0000df00
	v_fma_mixlo_f16 v80, v18, v79, v124 op_sel_hi:[1,0,0]       ; cc210050 0df29f12
	v_maxmin_num_f16 v72, 0xdf00, v72, neg(0xdf00)              ; d66b0048 83fe90ff 0000df00
	v_maxmin_num_f16 v76, 0xdf00, v76, neg(0xdf00)              ; d66b004c 83fe98ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v87, v61                                  ; 7eaed93d
	v_cvt_f32_f16_e32 v65, v64                                  ; 7e821740
	v_fma_mixlo_f16 v84, v18, v83, v125 op_sel_hi:[1,0,0]       ; cc210054 0df6a712
	v_cvt_f32_f16_e32 v69, v68                                  ; 7e8a1744
	v_maxmin_num_f16 v80, 0xdf00, v80, neg(0xdf00)              ; d66b0050 83fea0ff 0000df00
	v_cvt_f32_f16_e32 v73, v72                                  ; 7e921748
	v_cvt_f32_f16_e32 v77, v76                                  ; 7e9a174c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v91, v62                                  ; 7eb6d93e
	v_fma_mixlo_f16 v88, v18, v87, v126 op_sel_hi:[1,0,0]       ; cc210058 0dfaaf12
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v0, v65, v128, vcc_lo                     ; 02010141
	v_maxmin_num_f16 v84, 0xdf00, v84, neg(0xdf00)              ; d66b0054 83fea8ff 0000df00
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v0, v69, v128, vcc_lo                     ; 02010145
	v_cvt_f32_f16_e32 v81, v80                                  ; 7ea21750
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v0, v73, v128, vcc_lo                     ; 02010149
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v0, v77, v128, vcc_lo                     ; 0201014d
	v_fma_mixlo_f16 v18, v18, v91, v127 op_sel_hi:[1,0,0]       ; cc210012 0dfeb712
	v_maxmin_num_f16 v88, 0xdf00, v88, neg(0xdf00)              ; d66b0058 83feb0ff 0000df00
	v_cvt_f32_f16_e32 v85, v84                                  ; 7eaa1754
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v0, v81, v128, vcc_lo                     ; 02010151
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v18, 0xdf00, v18, neg(0xdf00)              ; d66b0012 83fe24ff 0000df00
	v_cvt_f32_f16_e32 v89, v88                                  ; 7eb21758
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v0, v85, v128, vcc_lo                     ; 02010155
	v_cvt_f32_f16_e32 v92, v18                                  ; 7eb81712
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v0, v89, v128, vcc_lo                     ; 02010159
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v0, v92, v128, vcc_lo                     ; 0201015c
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v66, v2, s[24:27], null offen               ; c406007c 40803042 00000002
	buffer_store_b8 v70, v2, s[24:27], null offen offset:16     ; c406007c 40803046 00001002
	buffer_store_b8 v74, v2, s[24:27], null offen offset:32     ; c406007c 4080304a 00002002
	buffer_store_b8 v78, v2, s[24:27], null offen offset:48     ; c406007c 4080304e 00003002
	buffer_store_b8 v82, v2, s[24:27], null offen offset:64     ; c406007c 40803052 00004002
	buffer_store_b8 v86, v2, s[24:27], null offen offset:80     ; c406007c 40803056 00005002
	buffer_store_b8 v90, v2, s[24:27], null offen offset:96     ; c406007c 4080305a 00006002
	buffer_store_b8 v93, v2, s[24:27], null offen offset:112    ; c406007c 4080305d 00007002
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v94, v22, s[24:27], null offen           ; c407807c 4080305e 00000016
	buffer_load_d16_u8 v95, v22, s[24:27], null offen offset:16 ; c407807c 4080305f 00001016
	buffer_load_d16_u8 v96, v22, s[24:27], null offen offset:32 ; c407807c 40803060 00002016
	buffer_load_d16_u8 v97, v22, s[24:27], null offen offset:48 ; c407807c 40803061 00003016
	buffer_load_d16_u8 v98, v22, s[24:27], null offen offset:64 ; c407807c 40803062 00004016
	buffer_load_d16_u8 v99, v22, s[24:27], null offen offset:80 ; c407807c 40803063 00005016
	buffer_load_d16_u8 v100, v22, s[24:27], null offen offset:96 ; c407807c 40803064 00006016
	buffer_load_d16_u8 v101, v22, s[24:27], null offen offset:112 ; c407807c 40803065 00007016
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v102, v94                                 ; 7eccd95e
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v106, v95                                 ; 7ed4d95f
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v110, v96                                 ; 7edcd960
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v114, v97                                 ; 7ee4d961
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v103, v19, v102, v128 op_sel_hi:[1,0,0]     ; cc210067 0e02cd13
	v_fma_mixlo_f16 v107, v19, v106, v129 op_sel_hi:[1,0,0]     ; cc21006b 0e06d513
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v118, v98                                 ; 7eecd962
	v_fma_mixlo_f16 v111, v19, v110, v130 op_sel_hi:[1,0,0]     ; cc21006f 0e0add13
	v_fma_mixlo_f16 v115, v19, v114, v131 op_sel_hi:[1,0,0]     ; cc210073 0e0ee513
	v_maxmin_num_f16 v103, 0xdf00, v103, neg(0xdf00)            ; d66b0067 83feceff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v122, v99                                 ; 7ef4d963
	v_maxmin_num_f16 v107, 0xdf00, v107, neg(0xdf00)            ; d66b006b 83fed6ff 0000df00
	v_fma_mixlo_f16 v119, v19, v118, v132 op_sel_hi:[1,0,0]     ; cc210077 0e12ed13
	v_maxmin_num_f16 v111, 0xdf00, v111, neg(0xdf00)            ; d66b006f 83fedeff 0000df00
	v_maxmin_num_f16 v115, 0xdf00, v115, neg(0xdf00)            ; d66b0073 83fee6ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v126, v100                                ; 7efcd964
	v_cvt_f32_f16_e32 v104, v103                                ; 7ed01767
	v_fma_mixlo_f16 v123, v19, v122, v133 op_sel_hi:[1,0,0]     ; cc21007b 0e16f513
	v_cvt_f32_f16_e32 v108, v107                                ; 7ed8176b
	v_maxmin_num_f16 v119, 0xdf00, v119, neg(0xdf00)            ; d66b0077 83feeeff 0000df00
	v_cvt_f32_f16_e32 v112, v111                                ; 7ee0176f
	v_cvt_f32_f16_e32 v116, v115                                ; 7ee81773
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v130, v101                                ; 7f04d965
	v_fma_mixlo_f16 v127, v19, v126, v134 op_sel_hi:[1,0,0]     ; cc21007f 0e1afd13
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v0, v104, v128, vcc_lo                    ; 02010168
	v_maxmin_num_f16 v123, 0xdf00, v123, neg(0xdf00)            ; d66b007b 83fef6ff 0000df00
(invalid instruction)                                        ; d769006d
	v_cndmask_b32_e32 v0, v108, v128, vcc_lo                    ; 0201016c
	v_cvt_f32_f16_e32 v120, v119                                ; 7ef01777
(invalid instruction)                                        ; d7690071
	v_cndmask_b32_e32 v0, v112, v128, vcc_lo                    ; 02010170
(invalid instruction)                                        ; d7690075
	v_cndmask_b32_e32 v0, v116, v128, vcc_lo                    ; 02010174
	v_fma_mixlo_f16 v19, v19, v130, v135 op_sel_hi:[1,0,0]      ; cc210013 0e1f0513
	v_maxmin_num_f16 v127, 0xdf00, v127, neg(0xdf00)            ; d66b007f 83fefeff 0000df00
	v_cvt_f32_f16_e32 v124, v123                                ; 7ef8177b
(invalid instruction)                                        ; d7690079
	v_cndmask_b32_e32 v0, v120, v128, vcc_lo                    ; 02010178
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
	v_cvt_f32_f16_e32 v128, v127                                ; 7f00177f
(invalid instruction)                                        ; d769007d
	v_cndmask_b32_e32 v0, v124, v128, vcc_lo                    ; 0201017c
	v_cvt_f32_f16_e32 v131, v19                                 ; 7f061713
(invalid instruction)                                        ; d7690081
	v_cndmask_b32_e32 v0, v128, v128, vcc_lo                    ; 02010180
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690084
	v_cndmask_b32_e32 v0, v131, v128, vcc_lo                    ; 02010183
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v105, v5, s[24:27], null offen              ; c406007c 40803069 00000005
	buffer_store_b8 v109, v5, s[24:27], null offen offset:16    ; c406007c 4080306d 00001005
	buffer_store_b8 v113, v5, s[24:27], null offen offset:32    ; c406007c 40803071 00002005
	buffer_store_b8 v117, v5, s[24:27], null offen offset:48    ; c406007c 40803075 00003005
	buffer_store_b8 v121, v5, s[24:27], null offen offset:64    ; c406007c 40803079 00004005
	buffer_store_b8 v125, v5, s[24:27], null offen offset:80    ; c406007c 4080307d 00005005
	buffer_store_b8 v129, v5, s[24:27], null offen offset:96    ; c406007c 40803081 00006005
	buffer_store_b8 v132, v5, s[24:27], null offen offset:112   ; c406007c 40803084 00007005
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v133, v23, s[24:27], null offen          ; c407807c 40803085 00000017
	buffer_load_d16_u8 v134, v23, s[24:27], null offen offset:16 ; c407807c 40803086 00001017
	buffer_load_d16_u8 v135, v23, s[24:27], null offen offset:32 ; c407807c 40803087 00002017
	buffer_load_d16_u8 v144, v23, s[24:27], null offen offset:48 ; c407807c 40803090 00003017
	buffer_load_d16_u8 v145, v23, s[24:27], null offen offset:64 ; c407807c 40803091 00004017
	buffer_load_d16_u8 v146, v23, s[24:27], null offen offset:80 ; c407807c 40803092 00005017
	buffer_load_d16_u8 v147, v23, s[24:27], null offen offset:96 ; c407807c 40803093 00006017
	buffer_load_d16_u8 v148, v23, s[24:27], null offen offset:112 ; c407807c 40803094 00007017
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v149, v133                                ; 7f2ad985
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v153, v134                                ; 7f32d986
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v157, v135                                ; 7f3ad987
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v161, v144                                ; 7f42d990
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v150, v20, v149, v136 op_sel_hi:[1,0,0]     ; cc210096 0e232b14
	v_fma_mixlo_f16 v154, v20, v153, v137 op_sel_hi:[1,0,0]     ; cc21009a 0e273314
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v165, v145                                ; 7f4ad991
	v_fma_mixlo_f16 v158, v20, v157, v138 op_sel_hi:[1,0,0]     ; cc21009e 0e2b3b14
	v_fma_mixlo_f16 v162, v20, v161, v139 op_sel_hi:[1,0,0]     ; cc2100a2 0e2f4314
	v_maxmin_num_f16 v150, 0xdf00, v150, neg(0xdf00)            ; d66b0096 83ff2cff 0000df00
	v_maxmin_num_f16 v154, 0xdf00, v154, neg(0xdf00)            ; d66b009a 83ff34ff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v169, v146                                ; 7f52d992
	v_fma_mixlo_f16 v166, v20, v165, v140 op_sel_hi:[1,0,0]     ; cc2100a6 0e334b14
	v_maxmin_num_f16 v158, 0xdf00, v158, neg(0xdf00)            ; d66b009e 83ff3cff 0000df00
	v_maxmin_num_f16 v162, 0xdf00, v162, neg(0xdf00)            ; d66b00a2 83ff44ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v173, v147                                ; 7f5ad993
(invalid instruction)                                        ; d58b0097
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                    ; 02010196
(invalid instruction)                                        ; d58b009b
	v_cndmask_b32_e32 v0, v154, v128, vcc_lo                    ; 0201019a
	v_fma_mixlo_f16 v170, v20, v169, v141 op_sel_hi:[1,0,0]     ; cc2100aa 0e375314
	v_maxmin_num_f16 v166, 0xdf00, v166, neg(0xdf00)            ; d66b00a6 83ff4cff 0000df00
(invalid instruction)                                        ; d58b009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
(invalid instruction)                                        ; d58b00a3
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v177, v148                                ; 7f62d994
	v_fma_mixlo_f16 v174, v20, v173, v142 op_sel_hi:[1,0,0]     ; cc2100ae 0e3b5b14
(invalid instruction)                                        ; d7690098
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                    ; 02010197
(invalid instruction)                                        ; d769009c
	v_cndmask_b32_e32 v0, v155, v128, vcc_lo                    ; 0201019b
	v_maxmin_num_f16 v170, 0xdf00, v170, neg(0xdf00)            ; d66b00aa 83ff54ff 0000df00
(invalid instruction)                                        ; d58b00a7
	v_cndmask_b32_e32 v0, v166, v128, vcc_lo                    ; 020101a6
(invalid instruction)                                        ; d76900a0
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                    ; 0201019f
(invalid instruction)                                        ; d76900a4
	v_cndmask_b32_e32 v0, v163, v128, vcc_lo                    ; 020101a3
	v_fma_mixlo_f16 v20, v20, v177, v143 op_sel_hi:[1,0,0]      ; cc210014 0e3f6314
	v_maxmin_num_f16 v174, 0xdf00, v174, neg(0xdf00)            ; d66b00ae 83ff5cff 0000df00
(invalid instruction)                                        ; d58b00ab
	v_cndmask_b32_e32 v0, v170, v128, vcc_lo                    ; 020101aa
(invalid instruction)                                        ; d76900a8
	v_cndmask_b32_e32 v0, v167, v128, vcc_lo                    ; 020101a7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
(invalid instruction)                                        ; d58b00af
	v_cndmask_b32_e32 v0, v174, v128, vcc_lo                    ; 020101ae
(invalid instruction)                                        ; d76900ac
	v_cndmask_b32_e32 v0, v171, v128, vcc_lo                    ; 020101ab
	v_cvt_f32_f16_e32 v178, v20                                 ; 7f641714
(invalid instruction)                                        ; d76900b0
	v_cndmask_b32_e32 v0, v175, v128, vcc_lo                    ; 020101af
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900b3
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                    ; 020101b2
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v152, v6, s[24:27], null offen              ; c406007c 40803098 00000006
	buffer_store_b8 v156, v6, s[24:27], null offen offset:16    ; c406007c 4080309c 00001006
	buffer_store_b8 v160, v6, s[24:27], null offen offset:32    ; c406007c 408030a0 00002006
	buffer_store_b8 v164, v6, s[24:27], null offen offset:48    ; c406007c 408030a4 00003006
	buffer_store_b8 v168, v6, s[24:27], null offen offset:64    ; c406007c 408030a8 00004006
	buffer_store_b8 v172, v6, s[24:27], null offen offset:80    ; c406007c 408030ac 00005006
	buffer_store_b8 v176, v6, s[24:27], null offen offset:96    ; c406007c 408030b0 00006006
	buffer_store_b8 v179, v6, s[24:27], null offen offset:112   ; c406007c 408030b3 00007006
BB69:
	s_cmp_eq_i32 s8, 0                                          ; bf008008
	s_cbranch_scc0 BB78                                         ; bfa10021
BB70:
	s_mul_i32 s1, ttmp9, 0x83                                   ; 9601ff75 00000083
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_nc_u32_e32 v0, s1, v0                                 ; 4a000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_and_b32_e32 v0, 0xfff, v0                                 ; 360000ff 00000fff
	v_lshlrev_b32_e32 v1, 2, v0                                 ; 30020082
	ds_store_b32 v1, v0                                         ; d8340000 00000001
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_add_nc_u32_e32 v0, 1, v0                                  ; 4a000081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_and_b32_e32 v0, 0xfff, v0                                 ; 360000ff 00000fff
	v_lshlrev_b32_e32 v0, 2, v0                                 ; 30000082
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b32 v0, v0                                          ; d8d80000 00000000
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cmpx_eq_i32_e32 5, v0                                     ; 7d840085
	s_cbranch_execz BB78                                        ; bfa5000a
BB71:
	s_mov_b32 s2, s0                                            ; be820000
	s_movk_i32 s3, 0x8000                                       ; b0038000
	s_load_b128 s[4:7], s[2:3], 0x20                            ; f4004101 f8000020
	v_mov_b32_e32 v0, 0                                         ; 7e000280
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b32 v0, off, s[4:7], null                      ; c406807c 00800800 00000000
BB78:
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s14, -1                                        ; bf01c10e
	s_cbranch_scc0 BB87                                         ; bfa1000f
BB79:
	s_mov_b32 exec_lo, 15                                       ; befe008f
BB80:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[0:3], s[0:1], 0x0                             ; f4004000 f8000000
	s_add_co_u32 s14, s14, s10                                  ; 800e0a0e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
(invalid instruction)                                        ; d71f0000
	v_cndmask_b32_e32 v0, -1, v14, vcc_lo                       ; 02001cc1
	v_dual_mov_b32 v1, 1 :: v_dual_lshlrev_b32 v0, 2, v0        ; ca220081 01000082
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_atomic_add_u32 v1, v0, s[0:3], null offen            ; c40d407c 40800001 00000000
BB87:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
