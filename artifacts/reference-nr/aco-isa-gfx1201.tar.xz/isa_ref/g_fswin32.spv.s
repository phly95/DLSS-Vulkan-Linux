BB0:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cmp_lg_i32 s15, -1                                        ; bf01c10f
	s_cbranch_scc0 BB2                                          ; bfa1000f
BB1:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_load_b128 s[16:19], s[16:17], 0x40                        ; f4004408 f8000040
	s_lshl2_add_u32 s20, s15, 24                                ; 8794980f
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s20, s[16:19], s20 offset:0x0             ; f4020508 28000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s20, 0x54434852                                ; bf01ff14 54434852
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s16, vcc_lo, exec_lo                              ; 8b107e6a
	s_cselect_b32 s15, -1, s15                                  ; 980f0fc1
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s15, -1                                        ; bf01c10f
	s_cbranch_scc0 BB5                                          ; bfa1000e
BB4:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_load_b128 s[16:19], s[16:17], 0x40                        ; f4004408 f8000040
	s_lshl2_add_u32 s20, s15, 4                                 ; 8794840f
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s20, s[16:19], s20 offset:0x0             ; f4020508 28000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s20, 0                                         ; bf018014
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s21, -1, 0                                    ; 981580c1
	s_branch BB6                                                ; bfa00001
BB5:
	s_mov_b32 s21, 0                                            ; be950080
BB6:
	s_cmp_eq_i32 ttmp9, 0                                       ; bf008075
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s16, -1, 0                                    ; 981080c1
	s_and_b32 s21, s21, s16                                     ; 8b151015
	s_cmp_eq_i32 ttmp7, 0                                       ; bf008073
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s17, -1, 0                                    ; 981180c1
	s_and_b32 s21, s21, s17                                     ; 8b151115
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 exec_lo, s21, 1                                   ; 8b7e8115
	s_cbranch_execz BB12                                        ; bfa50012
BB7:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[16:17], 0x40                        ; f4004508 f8000040
	s_load_b128 s[16:19], s[16:17], 0x0                         ; f4004408 f8000000
	s_lshl2_add_u32 s15, s15, 16                                ; 878f900f
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_buffer_load_b32 s15, s[20:23], s15 offset:0x0             ; f40203ca 1e000000
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s15, s15, 2                                      ; 840f820f
	buffer_atomic_add_u32 v1, off, s[16:19], s15                ; c40d400f 00802001 00000000
BB12:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_lshl1_add_u32 s13, ttmp9, s13                             ; 870d0d75
	s_lshl1_add_u32 s14, ttmp7, s14                             ; 870e0e73
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_min_i32 s15, s13, s14                                     ; 890f0e0d
	s_cmp_lt_i32 s15, 0                                         ; bf04800f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_cselect_b32 s16, -1, 0                                    ; 981080c1
	s_cmp_ge_i32 s13, s11                                       ; bf030b0d
	s_cselect_b32 s17, -1, 0                                    ; 981180c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_or_b32 s16, s16, s17                                      ; 8c101110
	s_cmp_ge_i32 s14, s12                                       ; bf030c0e
	s_cselect_b32 s18, -1, 0                                    ; 981280c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s16, s16, s18                                      ; 8c101210
	s_mov_b32 s19, src_scc                                      ; be9300fd
	s_add_co_u32 s20, s13, 1                                    ; 8014810d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_min_i32 s21, s20, s14                                     ; 89150e14
	s_cmp_lt_i32 s21, 0                                         ; bf048015
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_cselect_b32 s22, -1, 0                                    ; 981680c1
	s_cmp_ge_i32 s20, s11                                       ; bf030b14
	s_cselect_b32 s23, -1, 0                                    ; 981780c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s22, s22, s23                                      ; 8c161716
	s_or_b32 s22, s22, s18                                      ; 8c161216
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mov_b32 s24, src_scc                                      ; be9800fd
	s_absdiff_i32 s25, s19, 1                                   ; 83198113
	s_cmp_lg_i32 s19, 0                                         ; bf018013
	s_cselect_b32 s26, 2, 3                                     ; 981a8382
	s_mov_b32 s27, src_scc                                      ; be9b00fd
	s_cmp_lg_i32 s24, 0                                         ; bf018018
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_cselect_b32 s25, s25, s26                                 ; 98191a19
	s_mov_b32 s28, src_scc                                      ; be9c00fd
	s_add_co_u32 s29, s14, 1                                    ; 801d810e
	s_min_i32 s30, s13, s29                                     ; 891e1d0d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s30, 0                                         ; bf04801e
	s_cselect_b32 s31, -1, 0                                    ; 981f80c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_or_b32 s31, s31, s17                                      ; 8c1f111f
	s_cmp_ge_i32 s29, s12                                       ; bf030c1d
	s_cselect_b32 s32, -1, 0                                    ; 982080c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s31, s31, s32                                      ; 8c1f201f
	s_mov_b32 s33, src_scc                                      ; bea100fd
	s_or_b32 s34, s25, 4                                        ; 8c228419
	s_cmp_lg_i32 s33, 0                                         ; bf018021
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_cselect_b32 s25, s25, s34                                 ; 98192219
	s_mov_b32 s35, src_scc                                      ; bea300fd
	s_min_i32 s36, s20, s29                                     ; 89241d14
	s_cmp_lt_i32 s36, 0                                         ; bf048024
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s37, -1, 0                                    ; 982580c1
	s_or_b32 s37, s37, s23                                      ; 8c251725
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s37, s37, s32                                      ; 8c252025
	s_mov_b32 s38, src_scc                                      ; bea600fd
	s_or_b32 s39, s25, 8                                        ; 8c278819
	s_cmp_lg_i32 s38, 0                                         ; bf018026
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s25, s25, s39                                 ; 98192719
	s_mov_b32 s40, src_scc                                      ; bea800fd
	s_cmp_lg_i32 s25, 15                                        ; bf018f19
	s_cbranch_scc0 BB17                                         ; bfa1000d
BB13:
	s_and_b32 s15, s25, 3                                       ; 8b0f8319
	s_cbranch_scc0 BB15                                         ; bfa10009
BB14:
	s_and_b32 s15, s25, 10                                      ; 8b0f8a19
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_cselect_b32 s17, 15, 5                                    ; 9811858f
	s_and_b32 s18, s25, 5                                       ; 8b128519
	s_cselect_b32 s17, s17, 10                                  ; 98118a11
	s_and_b32 s25, s25, 12                                      ; 8b198c19
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s17, s17, 3                                   ; 98118311
	s_branch BB18                                               ; bfa00003
BB15:
	s_mov_b32 s17, 12                                           ; be91008c
	s_branch BB18                                               ; bfa00001
BB17:
	s_mov_b32 s17, 15                                           ; be91008f
BB18:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_eq_i32 s17, 15                                        ; bf008f11
	s_cbranch_scc0 BB20                                         ; bfa1155b
BB19:
	s_mov_b32 s15, s1                                           ; be8f0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[0:1], 0x0                           ; f4004400 f8000000
	s_load_b256 s[32:39], s[0:1], 0x30                          ; f4006800 f8000030
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_max_i32 s13, s13, 0                                       ; 8a0d800d
	s_add_co_u32 s21, s11, -1                                   ; 8015c10b
	s_movk_i32 s24, 0x100                                       ; b0180100
	s_min_i32 s13, s13, s21                                     ; 890d150d
	s_max_i32 s14, s14, 0                                       ; 8a0e800e
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	s_min_i32 s14, s14, s12                                     ; 890e0c0e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s14, s14, s11                                     ; 960e0b0e
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_add_co_u32 s22, s14, s13                                  ; 80160d0e
	s_lshl_b32 s22, s22, 9                                      ; 84168916
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s23, s15, s22                                  ; 8017160f
	s_max_i32 s20, s20, 0                                       ; 8a148014
	v_add3_u32 v5, v3, s23, s24                                 ; d6550005 00602f03
	v_add3_u32 v4, v1, s23, v3                                  ; d6550004 040c2f01
	s_min_i32 s20, s20, s21                                     ; 89141514
	s_add_co_u32 s14, s14, s20                                  ; 800e140e
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_lshl_b32 s14, s14, 9                                      ; 840e890e
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s25, s15, s14                                  ; 80190e0f
	s_max_i32 s29, s29, 0                                       ; 8a1d801d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v7, v3, s25, s24                                 ; d6550007 00603303
	v_add3_u32 v6, v1, s25, v3                                  ; d6550006 040c3301
	s_min_i32 s29, s29, s12                                     ; 891d0c1d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mul_i32 s29, s29, s11                                     ; 961d0b1d
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	s_add_co_u32 s13, s29, s13                                  ; 800d0d1d
	s_lshl_b32 s13, s13, 9                                      ; 840d890d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s26, s15, s13                                  ; 801a0d0f
	s_add_co_u32 s29, s29, s20                                  ; 801d141d
	v_add3_u32 v9, v3, s26, s24                                 ; d6550009 00603503
	v_add3_u32 v8, v1, s26, v3                                  ; d6550008 040c3501
	s_lshl_b32 s29, s29, 9                                      ; 841d891d
	s_add_co_u32 s15, s15, s29                                  ; 800f1d0f
	v_add_nc_u32_e32 v9, v9, v1                                 ; 4a120309
	v_add3_u32 v10, v1, s15, v3                                 ; d655000a 040c1f01
	v_add3_u32 v11, v3, s15, s24                                ; d655000b 00601f03
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v11, v11, v1                               ; 4a16030b
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[12:13], v4, s[16:19], null offen          ; c405407c 4080200c 00000004
	buffer_load_b64 v[4:5], v5, s[16:19], null offen            ; c405407c 40802004 00000005
	buffer_load_b64 v[14:15], v6, s[16:19], null offen          ; c405407c 4080200e 00000006
	buffer_load_b64 v[6:7], v7, s[16:19], null offen            ; c405407c 40802006 00000007
	buffer_load_b64 v[16:17], v8, s[16:19], null offen          ; c405407c 40802010 00000008
	buffer_load_b64 v[8:9], v9, s[16:19], null offen            ; c405407c 40802008 00000009
	buffer_load_b64 v[18:19], v10, s[16:19], null offen         ; c405407c 40802012 0000000a
	buffer_load_b64 v[10:11], v11, s[16:19], null offen         ; c405407c 4080200a 0000000b
	v_lshlrev_b32_e32 v20, 2, v0                                ; 30280082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v21, s3, v20, 2                              ; d6470015 020a2803
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[24:27], v21, s[36:39], null offen        ; c405c07c 40804818 00000015
	buffer_load_b128 v[28:31], v21, s[36:39], null offen offset:512 ; c405c07c 4080481c 00020015
	buffer_load_b128 v[32:35], v21, s[36:39], null offen offset:1024 ; c405c07c 40804820 00040015
	buffer_load_b128 v[36:39], v21, s[36:39], null offen offset:1536 ; c405c07c 40804824 00060015
	buffer_load_b128 v[40:43], v21, s[36:39], null offen offset:2048 ; c405c07c 40804828 00080015
	buffer_load_b128 v[44:47], v21, s[36:39], null offen offset:2560 ; c405c07c 4080482c 000a0015
	s_movk_i32 s27, 0x400                                       ; b01b0400
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_dual_mov_b32 v23, v13 :: v_dual_mov_b32 v22, v12          ; ca10010d 1716010c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_dual_mov_b32 v49, v5 :: v_dual_mov_b32 v48, v4            ; ca100105 31300104
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_dual_mov_b32 v51, v15 :: v_dual_mov_b32 v50, v14          ; ca10010f 3332010e
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_dual_mov_b32 v53, v7 :: v_dual_mov_b32 v52, v6            ; ca100107 35340106
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_dual_mov_b32 v55, v17 :: v_dual_mov_b32 v54, v16          ; ca100111 37360110
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_dual_mov_b32 v57, v9 :: v_dual_mov_b32 v56, v8            ; ca100109 39380108
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mov_b32 v59, v19 :: v_dual_mov_b32 v58, v18          ; ca100113 3b3a0112
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mov_b32 v61, v11 :: v_dual_mov_b32 v60, v10          ; ca10010b 3d3c010a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[12:13], 0 ; cc464040 1a021918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[16:17], 0 ; cc464050 1a022118
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[18:19], 0 ; cc464058 1a022518
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[12:13], 0 ; cc464060 1a02191a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[18:19], 0 ; cc464078 1a02251a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[14:15], 0 ; cc464048 1a021d18
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[14:15], 0 ; cc464068 1a021d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[16:17], 0 ; cc464070 1a02211a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[28:29], v[4:5], v[64:71] ; cc464040 1d02091c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[8:9], v[80:87] ; cc464050 1d42111c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[10:11], v[88:95] ; cc464058 1d62151c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[6:7], v[72:79] ; cc464048 1d220d1c
	v_maxmin_num_f32 v26, -4.0, v65, 4.0                        ; d669001a 03da82f7
	v_maxmin_num_f32 v28, -4.0, v66, 4.0                        ; d669001c 03da84f7
	v_maxmin_num_f32 v24, -4.0, v64, 4.0                        ; d6690018 03da80f7
	v_maxmin_num_f32 v62, -4.0, v67, 4.0                        ; d669003e 03da86f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
	v_fma_mix_f32 v27, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe34ff 3728ab28
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
	v_fma_mix_f32 v25, 0xab28, |v24|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe30ff 3728ab28
	v_fma_mix_f32 v63, 0xab28, |v62|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623f 0bfe7cff 3728ab28
	v_dual_fmaak_f32 v27, v27, v26, 0x3f650000 :: v_dual_fmaak_f32 v24, v24, v25, 0x3f650000 ; c842351b 1b183318 3f650000
	v_dual_fmaak_f32 v63, v63, v62, 0x3f650000 :: v_dual_fmaak_f32 v28, v28, v29, 0x3f650000 ; c8427d3f 3f1c3b1c 3f650000
	v_maxmin_num_f32 v128, -4.0, v71, 4.0                       ; d6690080 03da8ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v65, v65, v27 :: v_dual_mul_f32 v64, v64, v24 ; c8c63741 41403140
	v_dual_mul_f32 v67, v67, v63 :: v_dual_mul_f32 v66, v66, v28 ; c8c67f43 43423942
	v_maxmin_num_f32 v130, -4.0, v72, 4.0                       ; d6690082 03da90f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_maxmin_num_f32 v64, -4.0, v68, 4.0                        ; d6690040 03da88f7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_maxmin_num_f32 v66, -4.0, v69, 4.0                        ; d6690042 03da8af7
	v_maxmin_num_f32 v132, -4.0, v73, 4.0                       ; d6690084 03da92f7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_maxmin_num_f32 v134, -4.0, v74, 4.0                       ; d6690086 03da94f7
	v_fma_mix_f32 v65, 0xab28, |v64|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe80ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v75, 4.0                       ; d6690088 03da96f7
	v_fma_mix_f32 v67, 0xab28, |v66|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206243 0bfe84ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v138, -4.0, v76, 4.0                       ; d669008a 03da98f7
	v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 ; c8430782 82810181 3f650000
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_fmaak_f32 v67, v67, v66, 0x3f650000 :: v_dual_fmaak_f32 v64, v64, v65, 0x3f650000 ; c8428543 43408340 3f650000
	v_maxmin_num_f32 v140, -4.0, v77, 4.0                       ; d669008c 03da9af7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v78, 4.0                       ; d669008e 03da9cf7
	v_dual_mul_f32 v72, v72, v130 :: v_dual_mul_f32 v71, v71, v129 ; c8c70548 48470347
	v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 ; c8430f86 86850985 3f650000
	v_dual_mul_f32 v69, v69, v67 :: v_dual_mul_f32 v68, v68, v64 ; c8c68745 45448144
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v79, 4.0                       ; d6690090 03da9ef7
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 ; c843178a 8a891189 3f650000
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v80, 4.0                       ; d6690092 03daa0f7
	v_dual_mul_f32 v74, v74, v134 :: v_dual_mul_f32 v73, v73, v133 ; c8c70d4a 4a490b49
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_maxmin_num_f32 v68, -4.0, v70, 4.0                        ; d6690044 03da8cf7
	v_maxmin_num_f32 v148, -4.0, v81, 4.0                       ; d6690094 03daa2f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_dual_mul_f32 v76, v76, v138 :: v_dual_mul_f32 v75, v75, v137 ; c8c7154c 4c4b134b
	v_maxmin_num_f32 v150, -4.0, v82, 4.0                       ; d6690096 03daa4f7
	v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 ; c8431f8e 8e8d198d 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	v_fma_mix_f32 v69, 0xab28, |v68|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe88ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v83, 4.0                       ; d6690098 03daa6f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_maxmin_num_f32 v154, -4.0, v84, 4.0                       ; d669009a 03daa8f7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_mul_f32 v78, v78, v142 :: v_dual_mul_f32 v77, v77, v141 ; c8c71d4e 4e4d1b4d
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 ; c8432792 92912191 3f650000
	v_maxmin_num_f32 v156, -4.0, v85, 4.0                       ; d669009c 03daaaf7
	v_fmaak_f32 v68, v68, v69, 0x3f650000                       ; 5a888b44 3f650000
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v86, 4.0                       ; d669009e 03daacf7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c8432f96 96952995 3f650000
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	v_maxmin_num_f32 v160, -4.0, v87, 4.0                       ; d66900a0 03daaef7
	v_dual_mul_f32 v80, v80, v146 :: v_dual_mul_f32 v79, v79, v145 ; c8c72550 504f234f
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_mul_f32_e32 v70, v70, v68                                 ; 108c8946
	v_maxmin_num_f32 v162, -4.0, v88, 4.0                       ; d66900a2 03dab0f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 ; c843379a 9a993199 3f650000
	v_dual_mul_f32 v82, v82, v150 :: v_dual_mul_f32 v81, v81, v149 ; c8c72d52 52512b51
	v_maxmin_num_f32 v164, -4.0, v89, 4.0                       ; d66900a4 03dab2f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v90, 4.0                       ; d66900a6 03dab4f7
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c8433f9e 9e9d399d 3f650000
	v_dual_mul_f32 v84, v84, v154 :: v_dual_mul_f32 v83, v83, v153 ; c8c73554 54533353
	v_maxmin_num_f32 v168, -4.0, v91, 4.0                       ; d66900a8 03dab6f7
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v170, -4.0, v92, 4.0                       ; d66900aa 03dab8f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v93, 4.0                       ; d66900ac 03dabaf7
	v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 ; c84347a2 a2a141a1 3f650000
	v_dual_mul_f32 v86, v86, v158 :: v_dual_mul_f32 v85, v85, v157 ; c8c73d56 56553b55
	v_maxmin_num_f32 v174, -4.0, v94, 4.0                       ; d66900ae 03dabcf7
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v95, 4.0                       ; d66900b0 03dabef7
	v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 ; c8434fa6 a6a549a5 3f650000
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[30:31], v[4:5], v[96:103] ; cc464060 1d82091e
	v_dual_mul_f32 v88, v88, v162 :: v_dual_mul_f32 v87, v87, v161 ; c8c74558 58574357
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 ; c84357aa aaa951a9 3f650000
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_dual_mul_f32 v90, v90, v166 :: v_dual_mul_f32 v89, v89, v165 ; c8c74d5a 5a594b59
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 ; c8435fae aead59ad 3f650000
	v_dual_mul_f32 v92, v92, v170 :: v_dual_mul_f32 v91, v91, v169 ; c8c7555c 5c5b535b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[6:7], v[104:111] ; cc464068 1da20d1e
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v180, -4.0, v97, 4.0                       ; d66900b4 03dac2f7
	v_maxmin_num_f32 v178, -4.0, v96, 4.0                       ; d66900b2 03dac0f7
	v_maxmin_num_f32 v182, -4.0, v98, 4.0                       ; d66900b6 03dac4f7
	v_dual_mul_f32 v94, v94, v174 :: v_dual_mul_f32 v93, v93, v173 ; c8c75d5e 5e5d5b5d
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[8:9], v[112:119] ; cc464070 1dc2111e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[10:11], v[120:127] ; cc464078 1de2151e
	v_maxmin_num_f32 v184, -4.0, v99, 4.0                       ; d66900b8 03dac6f7
	v_maxmin_num_f32 v186, -4.0, v100, 4.0                      ; d66900ba 03dac8f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v188, -4.0, v101, 4.0                      ; d66900bc 03dacaf7
	v_maxmin_num_f32 v190, -4.0, v102, 4.0                      ; d66900be 03daccf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 ; c84367b2 b2b161b1 3f650000
	v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 ; c8436fb6 b6b569b5 3f650000
	v_maxmin_num_f32 v65, -4.0, v104, 4.0                       ; d6690041 03dad0f7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v67, -4.0, v105, 4.0                       ; d6690043 03dad2f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 ; c84377ba bab971b9 3f650000
	v_dual_mul_f32 v96, v96, v178 :: v_dual_mul_f32 v95, v95, v177 ; c8c76560 605f635f
	v_dual_mul_f32 v98, v98, v182 :: v_dual_mul_f32 v97, v97, v181 ; c8c76d62 62616b61
	v_maxmin_num_f32 v69, -4.0, v106, 4.0                       ; d6690045 03dad4f7
	v_fma_mix_f32 v66, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206242 0bfe82ff 3728ab28
	v_fma_mix_f32 v68, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206244 0bfe86ff 3728ab28
	v_maxmin_num_f32 v71, -4.0, v107, 4.0                       ; d6690047 03dad6f7
	v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 :: v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 ; c8437fbe bebd79bd 3f650000
	v_maxmin_num_f32 v191, -4.0, v103, 4.0                      ; d66900bf 03dacef7
	v_dual_mul_f32 v100, v100, v186 :: v_dual_mul_f32 v99, v99, v185 ; c8c77564 64637363
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_fma_mix_f32 v70, 0xab28, |v69|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe8aff 3728ab28
	v_maxmin_num_f32 v73, -4.0, v108, 4.0                       ; d6690049 03dad8f7
	v_dual_fmaak_f32 v68, v68, v67, 0x3f650000 :: v_dual_fmaak_f32 v65, v65, v66, 0x3f650000 ; c8428744 44408541 3f650000
	v_maxmin_num_f32 v75, -4.0, v109, 4.0                       ; d669004b 03dadaf7
	v_fma_mix_f32 v72, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe8eff 3728ab28
	v_fma_mix_f32 v64, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206240 0bff7eff 3728ab28
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v77, -4.0, v110, 4.0                       ; d669004d 03dadcf7
	v_maxmin_num_f32 v79, -4.0, v111, 4.0                       ; d669004f 03dadef7
	v_fma_mix_f32 v74, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe92ff 3728ab28
	v_dual_mul_f32 v104, v104, v65 :: v_dual_mul_f32 v105, v105, v68 ; c8c68368 68688969
	v_fma_mix_f32 v76, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624c 0bfe96ff 3728ab28
	v_dual_fmaak_f32 v72, v72, v71, 0x3f650000 :: v_dual_fmaak_f32 v69, v69, v70, 0x3f650000 ; c8428f48 48448d45 3f650000
	v_maxmin_num_f32 v81, -4.0, v112, 4.0                       ; d6690051 03dae0f7
	v_dual_fmaak_f32 v64, v64, v191, 0x3f650000 :: v_dual_mul_f32 v101, v101, v189 ; c8477f40 40657b65 3f650000
	v_maxmin_num_f32 v83, -4.0, v113, 4.0                       ; d6690053 03dae2f7
	v_fma_mix_f32 v78, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe9aff 3728ab28
	v_fma_mix_f32 v80, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe9eff 3728ab28
	v_dual_fmaak_f32 v76, v76, v75, 0x3f650000 :: v_dual_fmaak_f32 v73, v73, v74, 0x3f650000 ; c842974c 4c489549 3f650000
	v_dual_mul_f32 v107, v107, v72 :: v_dual_mul_f32 v106, v106, v69 ; c8c6916b 6b6a8b6a
	v_maxmin_num_f32 v85, -4.0, v114, 4.0                       ; d6690055 03dae4f7
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_dual_mul_f32 v102, v102, v190 :: v_dual_mul_f32 v103, v103, v64 ; c8c77d66 66668167
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v87, -4.0, v115, 4.0                       ; d6690057 03dae6f7
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_dual_fmaak_f32 v80, v80, v79, 0x3f650000 :: v_dual_fmaak_f32 v77, v77, v78, 0x3f650000 ; c8429f50 504c9d4d 3f650000
	v_dual_mul_f32 v109, v109, v76 :: v_dual_mul_f32 v108, v108, v73 ; c8c6996d 6d6c936c
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v89, -4.0, v116, 4.0                       ; d6690059 03dae8f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v117, 4.0                       ; d669005b 03daeaf7
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 ; c842a754 5450a551 3f650000
	v_maxmin_num_f32 v93, -4.0, v118, 4.0                       ; d669005d 03daecf7
	v_dual_mul_f32 v111, v111, v80 :: v_dual_mul_f32 v110, v110, v77 ; c8c6a16f 6f6e9b6e
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v95, -4.0, v119, 4.0                       ; d669005f 03daeef7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v120, 4.0                       ; d6690061 03daf0f7
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af58 5854ad55 3f650000
	v_maxmin_num_f32 v99, -4.0, v121, 4.0                       ; d6690063 03daf2f7
	v_dual_mul_f32 v113, v113, v84 :: v_dual_mul_f32 v112, v112, v81 ; c8c6a971 7170a370
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v122, 4.0                      ; d6690065 03daf4f7
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c842b75c 5c58b559 3f650000
	v_maxmin_num_f32 v103, -4.0, v123, 4.0                      ; d6690067 03daf6f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_mul_f32 v115, v115, v88 :: v_dual_mul_f32 v114, v114, v85 ; c8c6b173 7372ab72
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v105, -4.0, v124, 4.0                      ; d6690069 03daf8f7
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v125, 4.0                      ; d669006b 03dafaf7
	v_dual_mul_f32 v117, v117, v92 :: v_dual_mul_f32 v116, v116, v89 ; c8c6b975 7574b374
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 :: v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 ; c842c764 6460c561 3f650000
	v_maxmin_num_f32 v109, -4.0, v126, 4.0                      ; d669006d 03dafcf7
	v_maxmin_num_f32 v111, -4.0, v127, 4.0                      ; d669006f 03dafef7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_mul_f32 v119, v119, v96 :: v_dual_mul_f32 v118, v118, v93 ; c8c6c177 7776bb76
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 :: v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 ; c842cf68 6864cd65 3f650000
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[32:33], v[12:13], 0 ; cc464048 1a021920
	v_dual_mul_f32 v121, v121, v100 :: v_dual_mul_f32 v120, v120, v97 ; c8c6c979 7978c378
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 :: v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 ; c842d76c 6c68d569 3f650000
	v_dual_mul_f32 v123, v123, v104 :: v_dual_mul_f32 v122, v122, v101 ; c8c6d17b 7b7acb7a
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 :: v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 ; c842df70 706cdd6d 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v125, v125, v108 :: v_dual_mul_f32 v124, v124, v105 ; c8c6d97d 7d7cd37c
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[36:37], v[4:5], v[72:79] ; cc464048 1d220924
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[14:15], 0 ; cc464050 1a021d20
	v_dual_mul_f32 v127, v127, v112 :: v_dual_mul_f32 v126, v126, v109 ; c8c6e17f 7f7edb7e
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[16:17], 0 ; cc464058 1a022120
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[18:19], 0 ; cc464060 1a022520
	v_maxmin_num_f32 v119, -4.0, v75, 4.0                       ; d6690077 03da96f7
	v_maxmin_num_f32 v113, -4.0, v72, 4.0                       ; d6690071 03da90f7
	v_maxmin_num_f32 v117, -4.0, v74, 4.0                       ; d6690075 03da94f7
	v_maxmin_num_f32 v115, -4.0, v73, 4.0                       ; d6690073 03da92f7
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[6:7], v[80:87] ; cc464050 1d420d24
	v_maxmin_num_f32 v121, -4.0, v76, 4.0                       ; d6690079 03da98f7
	v_maxmin_num_f32 v123, -4.0, v77, 4.0                       ; d669007b 03da9af7
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[8:9], v[88:95] ; cc464058 1d621124
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[10:11], v[96:103] ; cc464060 1d821524
	v_maxmin_num_f32 v125, -4.0, v78, 4.0                       ; d669007d 03da9cf7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v79, 4.0                       ; d669007f 03da9ef7
	v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842ef78 7874ed75 3f650000
	v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 :: v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 ; c842e774 7470e571 3f650000
	v_maxmin_num_f32 v129, -4.0, v80, 4.0                       ; d6690081 03daa0f7
	v_maxmin_num_f32 v131, -4.0, v81, 4.0                       ; d6690083 03daa2f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 :: v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 ; c842f77c 7c78f579 3f650000
	v_maxmin_num_f32 v133, -4.0, v82, 4.0                       ; d6690085 03daa4f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v83, 4.0                       ; d6690087 03daa6f7
	v_dual_mul_f32 v75, v75, v120 :: v_dual_mul_f32 v74, v74, v117 ; c8c6f14b 4b4aeb4a
	v_dual_mul_f32 v73, v73, v116 :: v_dual_mul_f32 v72, v72, v113 ; c8c6e949 4948e348
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_mul_f32 v77, v77, v124 :: v_dual_mul_f32 v76, v76, v121 ; c8c6f94d 4d4cf34c
	v_maxmin_num_f32 v137, -4.0, v84, 4.0                       ; d6690089 03daa8f7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842ff80 807cfd7d 3f650000
	v_maxmin_num_f32 v139, -4.0, v85, 4.0                       ; d669008b 03daaaf7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 ; c8430784 84810581 3f650000
	v_maxmin_num_f32 v141, -4.0, v86, 4.0                       ; d669008d 03daacf7
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	v_maxmin_num_f32 v143, -4.0, v87, 4.0                       ; d669008f 03daaef7
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_dual_mul_f32 v79, v79, v128 :: v_dual_mul_f32 v78, v78, v125 ; c8c7014f 4f4efb4e
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430f88 88850d85 3f650000
	v_maxmin_num_f32 v145, -4.0, v88, 4.0                       ; d6690091 03dab0f7
	v_maxmin_num_f32 v147, -4.0, v89, 4.0                       ; d6690093 03dab2f7
	v_dual_mul_f32 v81, v81, v132 :: v_dual_mul_f32 v80, v80, v129 ; c8c70951 51510350
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_maxmin_num_f32 v149, -4.0, v90, 4.0                       ; d6690095 03dab4f7
	v_dual_fmaak_f32 v140, v140, v139, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 ; c843178c 8c891589 3f650000
	v_dual_mul_f32 v83, v83, v136 :: v_dual_mul_f32 v82, v82, v133 ; c8c71153 53530b52
	v_maxmin_num_f32 v151, -4.0, v91, 4.0                       ; d6690097 03dab6f7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c8431f90 908d1d8d 3f650000
	v_maxmin_num_f32 v153, -4.0, v92, 4.0                       ; d6690099 03dab8f7
	v_maxmin_num_f32 v155, -4.0, v93, 4.0                       ; d669009b 03dabaf7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_mul_f32 v85, v85, v140 :: v_dual_mul_f32 v84, v84, v137 ; c8c71955 55551354
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8432794 94912591 3f650000
	v_maxmin_num_f32 v157, -4.0, v94, 4.0                       ; d669009d 03dabcf7
	v_dual_mul_f32 v87, v87, v144 :: v_dual_mul_f32 v86, v86, v141 ; c8c72157 57571b56
	v_maxmin_num_f32 v159, -4.0, v95, 4.0                       ; d669009f 03dabef7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v161, -4.0, v96, 4.0                       ; d66900a1 03dac0f7
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432f98 98952d95 3f650000
	v_dual_mul_f32 v89, v89, v148 :: v_dual_mul_f32 v88, v88, v145 ; c8c72959 59592358
	v_maxmin_num_f32 v163, -4.0, v97, 4.0                       ; d66900a3 03dac2f7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c843379c 9c993599 3f650000
	v_maxmin_num_f32 v165, -4.0, v98, 4.0                       ; d66900a5 03dac4f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v99, 4.0                       ; d66900a7 03dac6f7
	v_dual_mul_f32 v91, v91, v152 :: v_dual_mul_f32 v90, v90, v149 ; c8c7315b 5b5b2b5a
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v169, -4.0, v100, 4.0                      ; d66900a9 03dac8f7
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c8433fa0 a09d3d9d 3f650000
	v_dual_mul_f32 v93, v93, v156 :: v_dual_mul_f32 v92, v92, v153 ; c8c7395d 5d5d335c
	v_maxmin_num_f32 v171, -4.0, v101, 4.0                      ; d66900ab 03dacaf7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v173, -4.0, v102, 4.0                      ; d66900ad 03daccf7
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c84347a4 a4a145a1 3f650000
	v_maxmin_num_f32 v175, -4.0, v103, 4.0                      ; d66900af 03dacef7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_mul_f32 v95, v95, v160 :: v_dual_mul_f32 v94, v94, v157 ; c8c7415f 5f5f3b5e
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 ; c8434fa8 a8a54da5 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[34:35], v[12:13], 0 ; cc464050 1a021922
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_mul_f32 v97, v97, v164 :: v_dual_mul_f32 v96, v96, v161 ; c8c74961 61614360
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 ; c84357ac aca955a9 3f650000
	v_dual_mul_f32 v99, v99, v168 :: v_dual_mul_f32 v98, v98, v165 ; c8c75163 63634b62
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 ; c8435fb0 b0ad5dad 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v101, v101, v172 :: v_dual_mul_f32 v100, v100, v169 ; c8c75965 65655364
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[34:35], v[14:15], 0 ; cc464058 1a021d22
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[38:39], v[4:5], v[80:87] ; cc464050 1d420926
	v_dual_mul_f32 v103, v103, v176 :: v_dual_mul_f32 v102, v102, v173 ; c8c76167 67675b66
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[34:35], v[18:19], 0 ; cc464068 1a022522
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[38:39], v[6:7], v[88:95] ; cc464058 1d620d26
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[16:17], 0 ; cc464060 1a022122
	v_maxmin_num_f32 v179, -4.0, v81, 4.0                       ; d66900b3 03daa2f7
	v_maxmin_num_f32 v177, -4.0, v80, 4.0                       ; d66900b1 03daa0f7
	v_maxmin_num_f32 v181, -4.0, v82, 4.0                       ; d66900b5 03daa4f7
	v_maxmin_num_f32 v183, -4.0, v83, 4.0                       ; d66900b7 03daa6f7
	v_maxmin_num_f32 v185, -4.0, v84, 4.0                       ; d66900b9 03daa8f7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[10:11], v[104:111] ; cc464068 1da21526
	v_maxmin_num_f32 v187, -4.0, v85, 4.0                       ; d66900bb 03daaaf7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[8:9], v[96:103] ; cc464060 1d821126
	v_maxmin_num_f32 v189, -4.0, v86, 4.0                       ; d66900bd 03daacf7
	v_maxmin_num_f32 v191, -4.0, v87, 4.0                       ; d66900bf 03daaef7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 ; c84367b4 b4b165b1 3f650000
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c8436fb8 b8b56db5 3f650000
	v_maxmin_num_f32 v39, -4.0, v88, 4.0                        ; d6690027 03dab0f7
	v_maxmin_num_f32 v75, -4.0, v89, 4.0                        ; d669004b 03dab2f7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_maxmin_num_f32 v77, -4.0, v90, 4.0                        ; d669004d 03dab4f7
	v_fma_mix_f32 v38, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206226 0bff7eff 3728ab28
	v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 ; c84377bc bcb975b9 3f650000
	v_maxmin_num_f32 v79, -4.0, v91, 4.0                        ; d669004f 03dab6f7
	v_dual_mul_f32 v81, v81, v180 :: v_dual_mul_f32 v80, v80, v177 ; c8c76951 51516350
	v_dual_mul_f32 v83, v83, v184 :: v_dual_mul_f32 v82, v82, v181 ; c8c77153 53536b52
	v_fma_mix_f32 v74, 0xab28, |v39|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe4eff 3728ab28
	v_fma_mix_f32 v76, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624c 0bfe96ff 3728ab28
	v_fma_mix_f32 v78, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe9aff 3728ab28
	v_dual_fmaak_f32 v38, v38, v191, 0x3f650000 :: v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 ; c8437f26 26bd7dbd 3f650000
	v_dual_mul_f32 v85, v85, v188 :: v_dual_mul_f32 v84, v84, v185 ; c8c77955 55557354
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v81, -4.0, v92, 4.0                        ; d6690051 03dab8f7
	v_fma_mix_f32 v80, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe9eff 3728ab28
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v83, -4.0, v93, 4.0                        ; d6690053 03dabaf7
	v_dual_fmaak_f32 v76, v76, v75, 0x3f650000 :: v_dual_fmaak_f32 v39, v39, v74, 0x3f650000 ; c842974c 4c269527 3f650000
	v_dual_mul_f32 v87, v87, v38 :: v_dual_mul_f32 v86, v86, v189 ; c8c64d57 57577b56
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v85, -4.0, v94, 4.0                        ; d6690055 03dabcf7
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_dual_fmaak_f32 v80, v80, v79, 0x3f650000 :: v_dual_fmaak_f32 v77, v77, v78, 0x3f650000 ; c8429f50 504c9d4d 3f650000
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_dual_mul_f32 v89, v89, v76 :: v_dual_mul_f32 v88, v88, v39 ; c8c69959 59584f58
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v87, -4.0, v95, 4.0                        ; d6690057 03dabef7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_dual_mul_f32 v91, v91, v80 :: v_dual_mul_f32 v90, v90, v77 ; c8c6a15b 5b5a9b5a
	v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 ; c842a754 5450a551 3f650000
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v89, -4.0, v96, 4.0                        ; d6690059 03dac0f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v97, 4.0                        ; d669005b 03dac2f7
	v_dual_mul_f32 v93, v93, v84 :: v_dual_mul_f32 v92, v92, v81 ; c8c6a95d 5d5ca35c
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af58 5854ad55 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v93, -4.0, v98, 4.0                        ; d669005d 03dac4f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_mul_f32 v95, v95, v88 :: v_dual_mul_f32 v94, v94, v85 ; c8c6b15f 5f5eab5e
	v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842b559 595cb75c 3f650000
	v_maxmin_num_f32 v113, -4.0, v102, 4.0                      ; d6690071 03daccf7
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v99, 4.0                        ; d669005f 03dac6f7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v115, -4.0, v103, 4.0                      ; d6690073 03dacef7
	v_dual_mul_f32 v97, v97, v92 :: v_dual_mul_f32 v96, v96, v89 ; c8c6b961 6160b360
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v117, -4.0, v104, 4.0                      ; d6690075 03dad0f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v100, 4.0                       ; d6690061 03dac8f7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v105, 4.0                      ; d6690077 03dad2f7
	v_maxmin_num_f32 v121, -4.0, v106, 4.0                      ; d6690079 03dad4f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842e774 7474ed75 3f650000
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v107, 4.0                      ; d669007b 03dad6f7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v108, 4.0                      ; d669007d 03dad8f7
	v_dual_mul_f32 v99, v99, v96 :: v_dual_mul_f32 v98, v98, v93 ; c8c6c163 6362bb62
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 :: v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 ; c842ef78 7878f579 3f650000
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v109, 4.0                      ; d669007f 03dadaf7
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v101, 4.0                       ; d6690063 03dacaf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v110, 4.0                      ; d6690081 03dadcf7
	v_dual_mul_f32 v106, v106, v121 :: v_dual_mul_f32 v103, v103, v116 ; c8c6f36a 6a66e967
	v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842f77c 7c7cfd7d 3f650000
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v111, 4.0                      ; d6690083 03dadef7
	v_fma_mix_f32 v112, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfec6ff 3728ab28
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[12:13], 0 ; cc464050 1a021928
	v_fmaak_f32 v97, v97, v98, 0x3f650000                       ; 5ac2c561 3f650000
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_dual_mul_f32 v108, v108, v125 :: v_dual_mul_f32 v105, v105, v120 ; c8c6fb6c 6c68f169
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_fmaak_f32 v112, v112, v99, 0x3f650000 :: v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 ; c842c770 7070e571 3f650000
	v_mul_f32_e32 v100, v100, v97                               ; 10c8c364
	v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 ; c842ff80 80810581 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_mul_f32_e32 v102, v102, v113                              ; 10cce366
	v_dual_mul_f32 v104, v104, v117 :: v_dual_mul_f32 v101, v101, v112 ; c8c6eb68 6864e165
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[4:5], v[80:87] ; cc464050 1d42092c
	v_dual_mul_f32 v110, v110, v129 :: v_dual_mul_f32 v107, v107, v124 ; c8c7036e 6e6af96b
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[14:15], 0 ; cc464058 1a021d28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[16:17], 0 ; cc464060 1a022128
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v135, -4.0, v81, 4.0                       ; d6690087 03daa2f7
	v_maxmin_num_f32 v137, -4.0, v82, 4.0                       ; d6690089 03daa4f7
	v_maxmin_num_f32 v133, -4.0, v80, 4.0                       ; d6690085 03daa0f7
	v_maxmin_num_f32 v139, -4.0, v83, 4.0                       ; d669008b 03daa6f7
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[6:7], v[88:95] ; cc464058 1d620d2c
	v_maxmin_num_f32 v141, -4.0, v84, 4.0                       ; d669008d 03daa8f7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[8:9], v[96:103] ; cc464060 1d82112c
	v_maxmin_num_f32 v143, -4.0, v85, 4.0                       ; d669008f 03daaaf7
	v_maxmin_num_f32 v145, -4.0, v86, 4.0                       ; d6690091 03daacf7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 ; c8430f88 88891589 3f650000
	v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430784 84850d85 3f650000
	v_maxmin_num_f32 v147, -4.0, v87, 4.0                       ; d6690093 03daaef7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_maxmin_num_f32 v149, -4.0, v88, 4.0                       ; d6690095 03dab0f7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_dual_fmaak_f32 v140, v140, v139, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c843178c 8c8d1d8d 3f650000
	v_dual_mul_f32 v80, v80, v133 :: v_dual_mul_f32 v109, v109, v128 ; c8c70b50 506d016d
	v_dual_mul_f32 v82, v82, v137 :: v_dual_mul_f32 v111, v111, v132 ; c8c71352 526f096f
	v_maxmin_num_f32 v151, -4.0, v89, 4.0                       ; d6690097 03dab2f7
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_maxmin_num_f32 v153, -4.0, v90, 4.0                       ; d6690099 03dab4f7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8431f90 90912591 3f650000
	v_dual_mul_f32 v84, v84, v141 :: v_dual_mul_f32 v81, v81, v136 ; c8c71b54 54511151
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[18:19], 0 ; cc464068 1a022528
	v_maxmin_num_f32 v155, -4.0, v91, 4.0                       ; d669009b 03dab6f7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v92, 4.0                       ; d669009d 03dab8f7
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432794 94952d95 3f650000
	v_dual_mul_f32 v86, v86, v145 :: v_dual_mul_f32 v83, v83, v140 ; c8c72356 56531953
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v159, -4.0, v93, 4.0                       ; d669009f 03dabaf7
	v_maxmin_num_f32 v161, -4.0, v94, 4.0                       ; d66900a1 03dabcf7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c8432f98 98993599 3f650000
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_mul_f32 v88, v88, v149 :: v_dual_mul_f32 v85, v85, v144 ; c8c72b58 58552155
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v163, -4.0, v95, 4.0                       ; d66900a3 03dabef7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[10:11], v[104:111] ; cc464068 1da2152c
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v96, 4.0                       ; d66900a5 03dac0f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_mul_f32 v90, v90, v153 :: v_dual_mul_f32 v87, v87, v148 ; c8c7335a 5a572957
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c843379c 9c9d3d9d 3f650000
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v97, 4.0                       ; d66900a7 03dac2f7
	v_maxmin_num_f32 v169, -4.0, v98, 4.0                       ; d66900a9 03dac4f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c8433fa0 a0a145a1 3f650000
	v_maxmin_num_f32 v171, -4.0, v99, 4.0                       ; d66900ab 03dac6f7
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_dual_mul_f32 v92, v92, v157 :: v_dual_mul_f32 v89, v89, v152 ; c8c73b5c 5c593159
	v_maxmin_num_f32 v173, -4.0, v100, 4.0                      ; d66900ad 03dac8f7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 ; c84347a4 a4a54da5 3f650000
	v_dual_mul_f32 v94, v94, v161 :: v_dual_mul_f32 v91, v91, v156 ; c8c7435e 5e5b395b
	v_maxmin_num_f32 v175, -4.0, v101, 4.0                      ; d66900af 03dacaf7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_maxmin_num_f32 v177, -4.0, v102, 4.0                      ; d66900b1 03daccf7
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 ; c8434fa8 a8a955a9 3f650000
	v_dual_mul_f32 v96, v96, v165 :: v_dual_mul_f32 v93, v93, v160 ; c8c74b60 605d415d
	v_maxmin_num_f32 v179, -4.0, v103, 4.0                      ; d66900b3 03dacef7
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v181, -4.0, v104, 4.0                      ; d66900b5 03dad0f7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v183, -4.0, v105, 4.0                      ; d66900b7 03dad2f7
	v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 ; c84357ac acad5dad 3f650000
	v_dual_mul_f32 v98, v98, v169 :: v_dual_mul_f32 v95, v95, v164 ; c8c75362 625f495f
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	buffer_load_b128 v[80:83], v21, s[36:39], null offen offset:3072 ; c405c07c 40804850 000c0015
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v106, 4.0                      ; d66900b9 03dad4f7
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 ; c8435fb0 b0b165b1 3f650000
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	buffer_load_b128 v[88:91], v21, s[36:39], null offen offset:3584 ; c405c07c 40804858 000e0015
	v_dual_mul_f32 v100, v100, v173 :: v_dual_mul_f32 v97, v97, v168 ; c8c75b64 64615161
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v187, -4.0, v107, 4.0                      ; d66900bb 03dad6f7
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c84367b4 b4b56db5 3f650000
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_dual_mul_f32 v102, v102, v177 :: v_dual_mul_f32 v99, v99, v172 ; c8c76366 66635963
	v_maxmin_num_f32 v189, -4.0, v108, 4.0                      ; d66900bd 03dad8f7
	v_maxmin_num_f32 v191, -4.0, v109, 4.0                      ; d66900bf 03dadaf7
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_mul_f32 v103, v103, v180 ; c8476fb8 b8676967 3f650000
	v_dual_mul_f32 v104, v104, v181 :: v_dual_mul_f32 v101, v101, v176 ; c8c76b68 68656165
	v_maxmin_num_f32 v86, -4.0, v110, 4.0                       ; d6690056 03dadcf7
	v_fmaak_f32 v185, v185, v186, 0x3f650000                    ; 5b7375b9 3f650000
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v92, -4.0, v111, 4.0                       ; d669005c 03dadef7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_fma_mix_f32 v21, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bff7eff 3728ab28
	v_fmaak_f32 v188, v188, v187, 0x3f650000                    ; 5b7977bc 3f650000
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[12:13], 0 ; cc464060 1a02192a
	v_dual_mul_f32 v105, v105, v184 :: v_dual_mul_f32 v106, v106, v185 ; c8c77169 696b736a
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_fmaak_f32 v189, v189, v190, 0x3f650000                    ; 5b7b7dbd 3f650000
	v_mul_f32_e32 v107, v107, v188                              ; 10d7796b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v87, 0x3f650000 ; c842b95d 5d56af56 3f650000
	v_dual_fmaak_f32 v21, v21, v191, 0x3f650000 :: v_dual_mul_f32 v108, v108, v189 ; c8477f15 156d7b6c 3f650000
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[4:5], v[96:103] ; cc464060 1d82092e
	v_dual_mul_f32 v111, v111, v93 :: v_dual_mul_f32 v110, v110, v86 ; c8c6bb6f 6f6ead6e
	v_mul_f32_e32 v109, v109, v21                               ; 10da2b6d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[16:17], 0 ; cc464070 1a02212a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[18:19], 0 ; cc464078 1a02252a
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[14:15], 0 ; cc464068 1a021d2a
	v_maxmin_num_f32 v94, -4.0, v96, 4.0                        ; d669005e 03dac0f7
	v_maxmin_num_f32 v128, -4.0, v97, 4.0                       ; d6690080 03dac2f7
	v_maxmin_num_f32 v132, -4.0, v99, 4.0                       ; d6690084 03dac6f7
	v_maxmin_num_f32 v130, -4.0, v98, 4.0                       ; d6690082 03dac4f7
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[8:9], v[112:119] ; cc464070 1dc2112e
	v_maxmin_num_f32 v134, -4.0, v100, 4.0                      ; d6690086 03dac8f7
	v_maxmin_num_f32 v136, -4.0, v101, 4.0                      ; d6690088 03dacaf7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[10:11], v[120:127] ; cc464078 1de2152e
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[6:7], v[104:111] ; cc464068 1da20d2e
	v_maxmin_num_f32 v138, -4.0, v102, 4.0                      ; d669008a 03daccf7
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v140, -4.0, v103, 4.0                      ; d669008c 03dacef7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c8430181 815ebf5e 3f650000
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8430985 85830782 3f650000
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c8431189 89870f86 3f650000
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_dual_mul_f32 v97, v97, v129 :: v_dual_mul_f32 v96, v96, v94 ; c8c70361 6160bd60
	v_dual_mul_f32 v99, v99, v133 :: v_dual_mul_f32 v98, v98, v130 ; c8c70b63 63630562
	v_maxmin_num_f32 v142, -4.0, v104, 4.0                      ; d669008e 03dad0f7
	v_maxmin_num_f32 v148, -4.0, v107, 4.0                      ; d6690094 03dad6f7
	v_maxmin_num_f32 v144, -4.0, v105, 4.0                      ; d6690090 03dad2f7
	v_maxmin_num_f32 v146, -4.0, v106, 4.0                      ; d6690092 03dad4f7
	v_dual_mul_f32 v101, v101, v137 :: v_dual_mul_f32 v100, v100, v134 ; c8c71365 65650d64
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c843198d 8d8b178a 3f650000
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v150, -4.0, v108, 4.0                      ; d6690096 03dad8f7
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v109, 4.0                      ; d6690098 03dadaf7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v154, -4.0, v110, 4.0                      ; d669009a 03dadcf7
	v_dual_mul_f32 v103, v103, v141 :: v_dual_mul_f32 v102, v102, v138 ; c8c71b67 67671566
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v111, 4.0                      ; d669009c 03dadef7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v112, 4.0                      ; d669009e 03dae0f7
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432191 918f1f8e 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8432995 95932792 3f650000
	v_maxmin_num_f32 v160, -4.0, v113, 4.0                      ; d66900a0 03dae2f7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v114, 4.0                      ; d66900a2 03dae4f7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8433199 99972f96 3f650000
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v115, 4.0                      ; d66900a4 03dae6f7
	v_dual_mul_f32 v105, v105, v145 :: v_dual_mul_f32 v104, v104, v142 ; c8c72369 69691d68
	v_dual_mul_f32 v107, v107, v149 :: v_dual_mul_f32 v106, v106, v146 ; c8c72b6b 6b6b256a
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c843399d 9d9b379a 3f650000
	v_maxmin_num_f32 v166, -4.0, v116, 4.0                      ; d66900a6 03dae8f7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_mul_f32 v109, v109, v153 :: v_dual_mul_f32 v108, v108, v150 ; c8c7336d 6d6d2d6c
	v_maxmin_num_f32 v168, -4.0, v117, 4.0                      ; d66900a8 03daeaf7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v170, -4.0, v118, 4.0                      ; d66900aa 03daecf7
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84341a1 a19f3f9e 3f650000
	v_dual_mul_f32 v111, v111, v157 :: v_dual_mul_f32 v110, v110, v154 ; c8c73b6f 6f6f356e
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v119, 4.0                      ; d66900ac 03daeef7
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84349a5 a5a347a2 3f650000
	v_maxmin_num_f32 v174, -4.0, v120, 4.0                      ; d66900ae 03daf0f7
	v_maxmin_num_f32 v176, -4.0, v121, 4.0                      ; d66900b0 03daf2f7
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_dual_mul_f32 v113, v113, v161 :: v_dual_mul_f32 v112, v112, v158 ; c8c74371 71713d70
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_maxmin_num_f32 v178, -4.0, v122, 4.0                      ; d66900b2 03daf4f7
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84351a9 a9a74fa6 3f650000
	v_dual_mul_f32 v115, v115, v165 :: v_dual_mul_f32 v114, v114, v162 ; c8c74b73 73734572
	v_maxmin_num_f32 v180, -4.0, v123, 4.0                      ; d66900b4 03daf6f7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v182, -4.0, v124, 4.0                      ; d66900b6 03daf8f7
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84359ad adab57aa 3f650000
	v_maxmin_num_f32 v184, -4.0, v125, 4.0                      ; d66900b8 03dafaf7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_dual_mul_f32 v117, v117, v169 :: v_dual_mul_f32 v116, v116, v166 ; c8c75375 75754d74
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v186, -4.0, v126, 4.0                      ; d66900ba 03dafcf7
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84361b1 b1af5fae 3f650000
	v_maxmin_num_f32 v188, -4.0, v127, 4.0                      ; d66900bc 03dafef7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_mul_f32 v119, v119, v173 :: v_dual_mul_f32 v118, v118, v170 ; c8c75b77 77775576
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84369b5 b5b367b2 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_mul_f32 v121, v121, v177 :: v_dual_mul_f32 v120, v120, v174 ; c8c76379 79795d78
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84371b9 b9b76fb6 3f650000
	v_dual_mul_f32 v123, v123, v181 :: v_dual_mul_f32 v122, v122, v178 ; c8c76b7b 7b7b657a
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84379bd bdbb77ba 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_dual_mul_f32 v125, v125, v185 :: v_dual_mul_f32 v124, v124, v182 ; c8c7737d 7d7d6d7c
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[80:81], v[14:15], 0 ; cc464068 1a021d50
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[80:81], v[16:17], 0 ; cc464070 1a022150
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[80:81], v[12:13], 0 ; cc464060 1a021950
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[88:89], v[6:7], v[104:111] ; cc464068 1da20d58
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[88:89], v[8:9], v[112:119] ; cc464070 1dc21158
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[88:89], v[4:5], v[96:103] ; cc464060 1d820958
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_maxmin_num_f32 v190, -4.0, v96, 4.0                       ; d66900be 03dac0f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v127, v127, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b7f 7fbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v97, 4.0                       ; d66900bf 03dac2f7
	v_maxmin_num_f32 v95, -4.0, v100, 4.0                       ; d669005f 03dac8f7
	v_fma_mix_f32 v21, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v21, v21, v191, 0x3f650000 :: v_dual_mul_f32 v126, v126, v186 ; c8477f15 157f757e 3f650000
	v_dual_mul_f32 v97, v97, v21 :: v_dual_mul_f32 v96, v96, v190 ; c8c62b61 61617d60
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[18:19], 0 ; cc464078 1a022550
	v_maxmin_num_f32 v81, -4.0, v98, 4.0                        ; d6690051 03dac4f7
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v101, 4.0                       ; d6690061 03dacaf7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[88:89], v[10:11], v[120:127] ; cc464078 1de21558
	v_maxmin_num_f32 v89, -4.0, v99, 4.0                        ; d6690059 03dac6f7
	v_fma_mix_f32 v88, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfea2ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v104, 4.0                      ; d6690081 03dad0f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v94, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfeb2ff 3728ab28
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v105, 4.0                      ; d6690083 03dad2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_dual_fmaak_f32 v94, v94, v89, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v88, 0x3f650000 ; c842b35e 5e50b151 3f650000
	v_maxmin_num_f32 v133, -4.0, v106, 4.0                      ; d6690085 03dad4f7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_mul_f32 v99, v99, v94 :: v_dual_mul_f32 v98, v98, v81 ; c8c6bd63 6362a362
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v102, 4.0                       ; d6690063 03daccf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430784 84850d85 3f650000
	v_maxmin_num_f32 v135, -4.0, v107, 4.0                      ; d6690087 03dad6f7
	v_maxmin_num_f32 v137, -4.0, v108, 4.0                      ; d6690089 03dad8f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c842c362 625ec15f 3f650000
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v109, 4.0                      ; d669008b 03dadaf7
	v_maxmin_num_f32 v141, -4.0, v110, 4.0                      ; d669008d 03dadcf7
	v_dual_mul_f32 v101, v101, v98 :: v_dual_mul_f32 v100, v100, v95 ; c8c6c565 6564bf64
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 ; c8430f88 88891589 3f650000
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v101, -4.0, v103, 4.0                      ; d6690065 03dacef7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v143, -4.0, v111, 4.0                      ; d669008f 03dadef7
	v_maxmin_num_f32 v145, -4.0, v112, 4.0                      ; d6690091 03dae0f7
	v_dual_mul_f32 v108, v108, v137 :: v_dual_mul_f32 v105, v105, v132 ; c8c7136c 6c690969
	v_dual_fmaak_f32 v140, v140, v139, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c843178c 8c8d1d8d 3f650000
	v_maxmin_num_f32 v147, -4.0, v113, 4.0                      ; d6690093 03dae2f7
	v_fma_mix_f32 v128, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfecaff 3728ab28
	v_fmaak_f32 v99, v99, v100, 0x3f650000                      ; 5ac6c963 3f650000
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_maxmin_num_f32 v149, -4.0, v114, 4.0                      ; d6690095 03dae4f7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_dual_mul_f32 v110, v110, v141 :: v_dual_mul_f32 v107, v107, v136 ; c8c71b6e 6e6b116b
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_dual_fmaak_f32 v128, v128, v101, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 ; c842cb80 80810581 3f650000
	v_maxmin_num_f32 v151, -4.0, v115, 4.0                      ; d6690097 03dae6f7
	v_mul_f32_e32 v102, v102, v99                               ; 10ccc766
	v_maxmin_num_f32 v153, -4.0, v116, 4.0                      ; d6690099 03dae8f7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8431f90 90912591 3f650000
	v_mul_f32_e32 v104, v104, v129                              ; 10d10368
	v_dual_mul_f32 v106, v106, v133 :: v_dual_mul_f32 v103, v103, v128 ; c8c70b6a 6a670167
	v_maxmin_num_f32 v155, -4.0, v117, 4.0                      ; d669009b 03daeaf7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v118, 4.0                      ; d669009d 03daecf7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432794 94952d95 3f650000
	v_dual_mul_f32 v112, v112, v145 :: v_dual_mul_f32 v109, v109, v140 ; c8c72370 706d196d
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v159, -4.0, v119, 4.0                      ; d669009f 03daeef7
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v120, 4.0                      ; d66900a1 03daf0f7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c8432f98 98993599 3f650000
	v_dual_mul_f32 v114, v114, v149 :: v_dual_mul_f32 v111, v111, v144 ; c8c72b72 726f216f
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v163, -4.0, v121, 4.0                      ; d66900a3 03daf2f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_lshrrev_b32_e32 v0, 4, v0                                 ; 32000084
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c843379c 9c9d3d9d 3f650000
	v_dual_mul_f32 v116, v116, v153 :: v_dual_mul_f32 v113, v113, v148 ; c8c73374 74712971
	s_mov_b64 s[40:41], s[32:33]                                ; bea80120
	s_mov_b64 s[42:43], s[34:35]                                ; beaa0122
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c8433fa0 a0a145a1 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v119, v160, v119 :: v_dual_lshlrev_b32 v0, 3, v0 ; c8e2efa0 77000083
	v_add_lshl_u32 v165, s8, v0, 2                              ; d64700a5 020a0008
	buffer_load_b128 v[96:99], v165, s[40:43], null offen       ; c405c07c 40805060 000000a5
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	buffer_load_b128 v[104:107], v165, s[40:43], null offen offset:16 ; c405c07c 40805068 000010a5
	v_maxmin_num_f32 v166, -4.0, v122, 4.0                      ; d66900a6 03daf4f7
	v_maxmin_num_f32 v168, -4.0, v123, 4.0                      ; d66900a8 03daf6f7
	v_dual_mul_f32 v118, v118, v157 :: v_dual_mul_f32 v115, v115, v152 ; c8c73b76 76733173
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_mul_f32_e32 v120, v120, v161                              ; 10f14378
	v_maxmin_num_f32 v170, -4.0, v124, 4.0                      ; d66900aa 03daf8f7
	v_maxmin_num_f32 v172, -4.0, v125, 4.0                      ; d66900ac 03dafaf7
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_mul_f32 v117, v117, v156 ; c84747a4 a4753975 3f650000
	v_maxmin_num_f32 v174, -4.0, v126, 4.0                      ; d66900ae 03dafcf7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v176, -4.0, v127, 4.0                      ; d66900b0 03dafef7
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[12:13], 0 ; cc464070 1a021952
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 :: v_dual_mul_f32 v121, v121, v164 ; c8474fa6 a6794979 3f650000
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fmaak_f32 v170, v170, v171, 0x3f650000                    ; 5b5557aa 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 ; c8435fae aead59ad 3f650000
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_mul_f32 v122, v122, v166 ; c84751a9 a97b4d7a 3f650000
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[90:91], v[4:5], v[112:119] ; cc464070 1dc2095a
	v_dual_mul_f32 v126, v126, v174 :: v_dual_mul_f32 v125, v125, v173 ; c8c75d7e 7e7d5b7d
	v_dual_mul_f32 v124, v124, v170 :: v_dual_mul_f32 v123, v123, v169 ; c8c7557c 7c7b537b
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[16:17], 0 ; cc464080 1a022152
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[82:83], v[18:19], 0 ; cc464088 1a022552
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694064
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v180, -4.0, v113, 4.0                      ; d66900b4 03dae2f7
	v_maxmin_num_f32 v182, -4.0, v114, 4.0                      ; d66900b6 03dae4f7
	v_maxmin_num_f32 v178, -4.0, v112, 4.0                      ; d66900b2 03dae0f7
	v_maxmin_num_f32 v184, -4.0, v115, 4.0                      ; d66900b8 03dae6f7
	v_maxmin_num_f32 v186, -4.0, v116, 4.0                      ; d66900ba 03dae8f7
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[90:91], v[8:9], v[128:135] ; cc464080 1e02115a
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[90:91], v[10:11], v[136:143] ; cc464088 1e22155a
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add_lshl_u32 v188, s4, v20, 2                             ; d64700bc 020a2804
	buffer_load_b128 v[8:11], v188, s[36:39], null offen        ; c405c07c 40804808 000000bc
	v_maxmin_num_f32 v189, -4.0, v117, 4.0                      ; d66900bd 03daeaf7
	v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 ; c8436fb6 b6b569b5 3f650000
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 ; c84367b2 b2b161b1 3f650000
	v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 ; c84377ba bab971b9 3f650000
	v_maxmin_num_f32 v191, -4.0, v118, 4.0                      ; d66900bf 03daecf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_dual_mul_f32 v112, v112, v178 :: v_dual_mul_f32 v127, v127, v177 ; c8c76570 707f637f
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[82:83], v[14:15], 0 ; cc464078 1a021d52
	buffer_load_b128 v[12:15], v188, s[36:39], null offen offset:512 ; c405c07c 4080480c 000200bc
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_mul_f32 v114, v114, v182 :: v_dual_mul_f32 v113, v113, v181 ; c8c76d72 72716b71
	buffer_load_b128 v[108:111], v188, s[36:39], null offen offset:1024 ; c405c07c 4080486c 000400bc
	v_dual_mul_f32 v116, v116, v186 :: v_dual_mul_f32 v115, v115, v185 ; c8c77574 74737373
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[90:91], v[6:7], v[120:127] ; cc464078 1de20d5a
	v_maxmin_num_f32 v7, -4.0, v119, 4.0                        ; d6690007 03daeef7
	v_fma_mix_f32 v16, 0xab28, |v7|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206210 0bfe0eff 3728ab28
	v_maxmin_num_f32 v19, -4.0, v121, 4.0                       ; d6690013 03daf2f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_fmaak_f32 v16, v16, v7, 0x3f650000                        ; 5a200f10 3f650000
	v_maxmin_num_f32 v17, -4.0, v120, 4.0                       ; d6690011 03daf0f7
	v_fma_mix_f32 v21, 0xab28, |v19|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfe26ff 3728ab28
	v_fma_mix_f32 v6, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206206 0bff7eff 3728ab28
	v_mul_f32_e32 v119, v119, v16                               ; 10ee2177
	v_fma_mix_f32 v18, 0xab28, |v17|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206212 0bfe22ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v17, v17, v18, 0x3f650000                       ; 5a222511 3f650000
	v_dual_fmaak_f32 v21, v21, v19, 0x3f650000 :: v_dual_mul_f32 v120, v120, v17 ; c8462715 15782378 3f650000
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v188, s[36:39], null offen offset:1536 ; c405c07c 40804810 000600bc
	buffer_load_b128 v[112:115], v188, s[36:39], null offen offset:2048 ; c405c07c 40804870 000800bc
	v_maxmin_num_f32 v82, -4.0, v122, 4.0                       ; d6690052 03daf4f7
	v_dual_fmaak_f32 v191, v191, v6, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c8420dbf bfbf7bbe 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v118, v118, v191 :: v_dual_mul_f32 v117, v117, v190 ; c8c77f76 76757d75
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[116:119], v188, s[36:39], null offen offset:2560 ; c405c07c 40804874 000a00bc
	buffer_load_b128 v[144:147], v188, s[36:39], null offen offset:3072 ; c405c07c 40804890 000c00bc
	v_maxmin_num_f32 v90, -4.0, v123, 4.0                       ; d669005a 03daf6f7
	v_maxmin_num_f32 v102, -4.0, v124, 4.0                      ; d6690066 03daf8f7
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_fmaak_f32 v82, v82, v83, 0x3f650000                       ; 5aa4a752 3f650000
	v_fmaak_f32 v91, v91, v90, 0x3f650000                       ; 5ab6b55b 3f650000
	v_fmaak_f32 v102, v102, v103, 0x3f650000                    ; 5acccf66 3f650000
	v_dual_mul_f32 v122, v122, v82 :: v_dual_mul_f32 v121, v121, v21 ; c8c6a57a 7a782b79
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_mul_f32_e32 v123, v123, v91                               ; 10f6b77b
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v125, 4.0                      ; d6690078 03dafaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v122, -4.0, v126, 4.0                      ; d669007a 03dafcf7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_dual_mul_f32 v124, v124, v102 :: v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 ; c8c2cd7c 7c78f179 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fmaak_f32 v122, v122, v123, 0x3f650000                    ; 5af4f77a 3f650000
	v_dual_mul_f32 v126, v126, v122 :: v_dual_mul_f32 v125, v125, v121 ; c8c6f57e 7e7cf37d
	buffer_load_b128 v[120:123], v188, s[36:39], null offen offset:3584 ; c405c07c 40804878 000e00bc
	v_maxmin_num_f32 v148, -4.0, v129, 4.0                      ; d6690094 03db02f7
	v_maxmin_num_f32 v150, -4.0, v130, 4.0                      ; d6690096 03db04f7
	v_maxmin_num_f32 v152, -4.0, v131, 4.0                      ; d6690098 03db06f7
	v_maxmin_num_f32 v154, -4.0, v132, 4.0                      ; d669009a 03db08f7
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v127, 4.0                      ; d669007c 03dafef7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v133, 4.0                      ; d669009c 03db0af7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v125, v125, v124, 0x3f650000                    ; 5afaf97d 3f650000
	v_mul_f32_e32 v127, v127, v125                              ; 10fefb7f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v128, 4.0                      ; d669007e 03db00f7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v126, v126, v127, 0x3f650000                    ; 5afcff7e 3f650000
	v_mul_f32_e32 v128, v128, v126                              ; 1100fd80
	v_maxmin_num_f32 v158, -4.0, v134, 4.0                      ; d669009e 03db0cf7
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c8432f96 96952995 3f650000
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 ; c843379a 9a993199 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_mul_f32 v130, v130, v150 :: v_dual_mul_f32 v129, v129, v149 ; c8c72d82 82812b81
	v_dual_mul_f32 v132, v132, v154 :: v_dual_mul_f32 v131, v131, v153 ; c8c73584 84833383
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[124:127], v165, s[40:43], null offen offset:64 ; c405c07c 4080507c 000040a5
	buffer_load_b128 v[128:131], v165, s[40:43], null offen offset:80 ; c405c07c 40805080 000050a5
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v135, 4.0                      ; d66900a0 03db0ef7
	v_maxmin_num_f32 v162, -4.0, v136, 4.0                      ; d66900a2 03db10f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v137, 4.0                      ; d66900a4 03db12f7
	v_maxmin_num_f32 v166, -4.0, v138, 4.0                      ; d66900a6 03db14f7
	v_maxmin_num_f32 v168, -4.0, v139, 4.0                      ; d66900a8 03db16f7
	v_maxmin_num_f32 v170, -4.0, v140, 4.0                      ; d66900aa 03db18f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c8433f9e 9e9d399d 3f650000
	v_maxmin_num_f32 v172, -4.0, v141, 4.0                      ; d66900ac 03db1af7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fmaak_f32 v161, v161, v160, 0x3f650000                    ; 5b4341a1 3f650000
	v_maxmin_num_f32 v174, -4.0, v142, 4.0                      ; d66900ae 03db1cf7
	v_maxmin_num_f32 v176, -4.0, v143, 4.0                      ; d66900b0 03db1ef7
	v_dual_mul_f32 v134, v134, v158 :: v_dual_mul_f32 v133, v133, v157 ; c8c73d86 86853b85
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84349a5 a5a347a2 3f650000
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84351a9 a9a74fa6 3f650000
	v_cvt_pk_f32_fp8_e32 v[102:103], v22                        ; 7eccdd16
	v_mul_f32_e32 v135, v135, v161                              ; 110f4387
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84359ad adab57aa 3f650000
	v_dual_mul_f32 v137, v137, v165 :: v_dual_mul_f32 v136, v136, v162 ; c8c74b89 89894588
	v_dual_mul_f32 v139, v139, v169 :: v_dual_mul_f32 v138, v138, v166 ; c8c7538b 8b8b4d8a
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84361b1 b1af5fae 3f650000
	v_dual_mul_f32 v141, v141, v173 :: v_dual_mul_f32 v140, v140, v170 ; c8c75b8d 8d8d558c
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_dual_mul_f32 v137, v103, v97 :: v_dual_mul_f32 v136, v102, v96 ; c8c6c367 8988c166
	v_cvt_pk_f32_fp8_e32 v[102:103], v150                       ; 7eccdd96
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v143, v143, v177 :: v_dual_mul_f32 v142, v142, v174 ; c8c7638f 8f8f5d8e
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
	v_dual_mul_f32 v139, v103, v99 :: v_dual_mul_f32 v138, v102, v98 ; c8c6c767 8b8ac566
	v_cvt_pk_f32_fp8_e32 v[102:103], v23                        ; 7eccdd17
	v_cvt_pk_f32_fp8_e32 v[22:23], v151                         ; 7e2cdd97
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_dual_mul_f32 v141, v103, v105 :: v_dual_mul_f32 v140, v102, v104 ; c8c6d367 8d8cd166
	v_dual_mul_f32 v143, v23, v107 :: v_dual_mul_f32 v142, v22, v106 ; c8c6d717 8f8ed516
	v_cvt_pk_f32_fp8_e32 v[22:23], v50                          ; 7e2cdd32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v153, v23, v97 :: v_dual_mul_f32 v152, v22, v96 ; c8c6c317 9998c116
	v_cvt_pk_f32_fp8_e32 v[22:23], v178                         ; 7e2cddb2
	v_dual_mul_f32 v155, v23, v99 :: v_dual_mul_f32 v154, v22, v98 ; c8c6c717 9b9ac516
	v_cvt_pk_f32_fp8_e32 v[22:23], v51                          ; 7e2cdd33
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v157, v23, v105 :: v_dual_mul_f32 v156, v22, v104 ; c8c6d317 9d9cd116
	v_cvt_pk_f32_fp8_e32 v[22:23], v179                         ; 7e2cddb3
	v_dual_mul_f32 v159, v23, v107 :: v_dual_mul_f32 v158, v22, v106 ; c8c6d717 9f9ed516
	v_cvt_pk_f32_fp8_e32 v[22:23], v54                          ; 7e2cdd36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v161, v23, v97 :: v_dual_mul_f32 v160, v22, v96 ; c8c6c317 a1a0c116
	v_cvt_pk_f32_fp8_e32 v[22:23], v182                         ; 7e2cddb6
	v_dual_mul_f32 v163, v23, v99 :: v_dual_mul_f32 v162, v22, v98 ; c8c6c717 a3a2c516
	v_cvt_pk_f32_fp8_e32 v[22:23], v55                          ; 7e2cdd37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v165, v23, v105 :: v_dual_mul_f32 v164, v22, v104 ; c8c6d317 a5a4d116
	v_cvt_pk_f32_fp8_e32 v[22:23], v183                         ; 7e2cddb7
	v_dual_mul_f32 v167, v23, v107 :: v_dual_mul_f32 v166, v22, v106 ; c8c6d717 a7a6d516
	v_cvt_pk_f32_fp8_e32 v[22:23], v58                          ; 7e2cdd3a
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[8:9], v[26:27], v[152:159] ; cc464098 1e623508
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[8:9], v[24:25], v[136:143] ; cc464088 1e223108
	v_dual_mul_f32 v169, v23, v97 :: v_dual_mul_f32 v168, v22, v96 ; c8c6c317 a9a8c116
	v_cvt_pk_f32_fp8_e32 v[22:23], v186                         ; 7e2cddba
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[8:9], v[28:29], v[160:167] ; cc4640a0 1e823908
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v178, s5, v20, 2                             ; d64700b2 020a2805
	v_dual_mul_f32 v171, v23, v99 :: v_dual_mul_f32 v170, v22, v98 ; c8c6c717 abaac516
	buffer_load_b128 v[96:99], v178, s[36:39], null offen       ; c405c07c 40804860 000000b2
	v_cvt_pk_f32_fp8_e32 v[22:23], v59                          ; 7e2cdd3b
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[12:13], v[64:65], v[152:159] ; cc464098 1e62810c
	v_dual_mul_f32 v173, v23, v105 :: v_dual_mul_f32 v172, v22, v104 ; c8c6d317 adacd116
	v_cvt_pk_f32_fp8_e32 v[22:23], v187                         ; 7e2cddbb
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v175, v23, v107 :: v_dual_mul_f32 v174, v22, v106 ; c8c6d717 afaed516
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[8:9], v[62:63], v[168:175] ; cc4640a8 1ea27d08
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[104:107], v178, s[36:39], null offen offset:1024 ; c405c07c 40804868 000400b2
	buffer_load_b128 v[132:135], v178, s[36:39], null offen offset:2048 ; c405c07c 40804884 000800b2
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[12:13], v[30:31], v[136:143] ; cc464088 1e223d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[66:67], v[160:167] ; cc4640a0 1e82850c
	buffer_load_b128 v[148:151], v178, s[36:39], null offen offset:512 ; c405c07c 40804894 000200b2
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[36:37], v[152:159] ; cc464098 1e62496c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[12:13], v[68:69], v[168:175] ; cc4640a8 1ea2890c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[32:33], v[136:143] ; cc464088 1e22416c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[108:109], v[70:71], v[160:167] ; cc4640a0 1e828d6c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[38:39], v[152:159] ; cc464098 1e624d10
	buffer_load_b128 v[180:183], v178, s[36:39], null offen offset:1536 ; c405c07c 408048b4 000600b2
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[108:109], v[72:73], v[168:175] ; cc4640a8 1ea2916c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[16:17], v[34:35], v[136:143] ; cc464088 1e224510
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[74:75], v[160:167] ; cc4640a0 1e829510
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[44:45], v[152:159] ; cc464098 1e625970
	buffer_load_b128 v[176:179], v178, s[36:39], null offen offset:2560 ; c405c07c 408048b0 000a00b2
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[16:17], v[76:77], v[168:175] ; cc4640a8 1ea29910
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[40:41], v[136:143] ; cc464088 1e225170
	v_cvt_pk_f32_fp8_e32 v[50:51], v48                          ; 7e64dd30
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[112:113], v[78:79], v[160:167] ; cc4640a0 1e829d70
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[46:47], v[152:159] ; cc464098 1e625d74
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[112:113], v[84:85], v[168:175] ; cc4640a8 1ea2a970
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[116:117], v[42:43], v[136:143] ; cc464088 1e225574
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[116:117], v[86:87], v[160:167] ; cc4640a0 1e82ad74
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[144:145], v[88:89], v[152:159] ; cc464098 1e62b190
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[116:117], v[92:93], v[168:175] ; cc4640a8 1ea2b974
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mul_f32 v185, v51, v125 :: v_dual_mul_f32 v184, v50, v124 ; c8c6fb33 b9b8f932
	v_cvt_pk_f32_fp8_e32 v[50:51], v176                         ; 7e64ddb0
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[144:145], v[80:81], v[136:143] ; cc464088 1e22a190
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[144:145], v[94:95], v[160:167] ; cc4640a0 1e82bd90
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[120:121], v[6:7], v[152:159] ; cc464098 1e620d78
	v_dual_mul_f32 v187, v51, v127 :: v_dual_mul_f32 v186, v50, v126 ; c8c6ff33 bbbafd32
	v_cvt_pk_f32_fp8_e32 v[50:51], v49                          ; 7e64dd31
	v_cvt_pk_f32_fp8_e32 v[48:49], v177                         ; 7e60ddb1
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[144:145], v[100:101], v[168:175] ; cc4640a8 1ea2c990
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[120:121], v[4:5], v[136:143] ; cc464088 1e220978
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[120:121], v[82:83], v[160:167] ; cc4640a0 1e82a578
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v189, v51, v129 :: v_dual_mul_f32 v188, v50, v128 ; c8c70333 bdbd0132
	v_dual_mul_f32 v191, v49, v131 :: v_dual_mul_f32 v190, v48, v130 ; c8c70731 bfbf0530
	v_cvt_pk_f32_fp8_e32 v[48:49], v52                          ; 7e60dd34
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[120:121], v[90:91], v[168:175] ; cc4640a8 1ea2b578
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_cvt_pk_f32_fp8_e32 v[50:51], v180                         ; 7e64ddb4
	v_dual_mul_f32 v49, v49, v125 :: v_dual_mul_f32 v48, v48, v124 ; c8c6fb31 3130f930
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	s_bitset0_b32 s33, 14                                       ; bea1108e
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_buffer_load_b32 s10, s[32:35], s10 offset:0x0             ; f4020290 14000000
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_cvt_pk_f32_fp8_e32 v[54:55], v53                          ; 7e6cdd35
	v_cvt_pk_f32_fp8_e32 v[58:59], v181                         ; 7e74ddb5
	v_cvt_pk_f32_fp8_e32 v[102:103], v56                        ; 7eccdd38
	v_cvt_pk_f32_fp8_e32 v[108:109], v184                       ; 7ed8ddb8
	v_dual_mul_f32 v51, v51, v127 :: v_dual_mul_f32 v50, v50, v126 ; c8c6ff33 3332fd32
	v_cvt_pk_f32_fp8_e32 v[112:113], v57                        ; 7ee0dd39
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_cvt_pk_f32_fp8_e32 v[56:57], v185                         ; 7e70ddb9
	v_cvt_pk_f32_fp8_e32 v[116:117], v60                        ; 7ee8dd3c
	v_cvt_pk_f32_fp8_e32 v[120:121], v188                       ; 7ef0ddbc
	v_dual_mul_f32 v55, v55, v129 :: v_dual_mul_f32 v52, v54, v128 ; c8c70337 37350136
	v_dual_mul_f32 v59, v59, v131 :: v_dual_mul_f32 v54, v58, v130 ; c8c7073b 3b37053a
	v_dual_mul_f32 v103, v103, v125 :: v_dual_mul_f32 v102, v102, v124 ; c8c6fb67 6766f966
	v_mul_f32_e32 v109, v109, v127                              ; 10daff6d
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[10:11], v[24:25], v[184:191] ; cc4640b8 1ee2310a
	v_mul_f32_e32 v113, v113, v129                              ; 10e30371
	v_dual_mul_f32 v57, v57, v131 :: v_dual_mul_f32 v108, v108, v126 ; c8c70739 396cfd6c
	v_dual_mul_f32 v117, v117, v125 :: v_dual_mul_f32 v112, v112, v128 ; c8c6fb75 75710170
	v_dual_mul_f32 v121, v121, v127 :: v_dual_mul_f32 v116, v116, v124 ; c8c6ff79 7974f974
	v_cvt_pk_f32_fp8_e32 v[124:125], v61                        ; 7ef8dd3d
	v_cvt_pk_f32_fp8_e32 v[60:61], v189                         ; 7e78ddbd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_dual_mul_f32 v125, v125, v129 :: v_dual_mul_f32 v56, v56, v130 ; c8c7037d 7d390538
	v_dual_mov_b32 v53, v55 :: v_dual_mul_f32 v124, v124, v128  ; ca060137 357d017c
	v_dual_mul_f32 v127, v61, v131 :: v_dual_mul_f32 v120, v120, v126 ; c8c7073d 7f78fd78
	v_dual_mov_b32 v55, v59 :: v_dual_mul_f32 v126, v60, v130   ; ca06013b 377f053c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[10:11], v[26:27], v[48:55] ; cc464030 1cc2350a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[14:15], v[30:31], v[184:191] ; cc4640b8 1ee23d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[14:15], v[64:65], v[48:55] ; cc464030 1cc2810e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[32:33], v[184:191] ; cc4640b8 1ee2416e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mov_b32 v27, v107 :: v_dual_mov_b32 v26, v106        ; ca10016b 1b1a016a
	v_dual_mov_b32 v107, v113 :: v_dual_mov_b32 v106, v112      ; ca100171 6b6a0170
	v_dual_mov_b32 v25, v105 :: v_dual_mov_b32 v24, v104        ; ca100169 19180168
	v_dual_mov_b32 v105, v109 :: v_dual_mov_b32 v104, v108      ; ca10016d 6968016c
	v_dual_mov_b32 v109, v57 :: v_dual_mov_b32 v108, v56        ; ca100139 6d6c0138
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[110:111], v[36:37], v[48:55] ; cc464030 1cc2496e
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[10:11], v[28:29], v[102:109] ; cc464066 1d9a390a
	v_dual_mov_b32 v21, v122 :: v_dual_mov_b32 v28, v123        ; ca10017a 151c017b
	v_dual_mov_b32 v123, v121 :: v_dual_mov_b32 v122, v120      ; ca100179 7b7a0178
	v_dual_mov_b32 v121, v117 :: v_dual_mov_b32 v120, v116      ; ca100175 79780174
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[18:19], v[34:35], v[184:191] ; cc4640b8 1ee24512
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[18:19], v[38:39], v[48:55] ; cc464030 1cc24d12
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[62:63], v[120:127] ; cc464078 1de27d0a
	v_dual_mov_b32 v11, v28 :: v_dual_mov_b32 v10, v21          ; ca10011c 0b0a0115
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[14:15], v[66:67], v[102:109] ; cc464066 1d9a850e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[40:41], v[184:191] ; cc4640b8 1ee25172
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[114:115], v[44:45], v[48:55] ; cc464030 1cc25972
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[68:69], v[120:127] ; cc464078 1de2890e
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[110:111], v[70:71], v[102:109] ; cc464066 1d9a8d6e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[42:43], v[184:191] ; cc4640b8 1ee25576
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[26:27], v[8:9], 0   ; cc464040 1a02111a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[118:119], v[46:47], v[48:55] ; cc464030 1cc25d76
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[98:99], v[8:9], 0   ; cc464028 1a021162
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[110:111], v[72:73], v[120:127] ; cc464078 1de2916e
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[18:19], v[74:75], v[102:109] ; cc464066 1d9a9512
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[146:147], v[80:81], v[184:191] ; cc4640b8 1ee2a192
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[146:147], v[88:89], v[48:55] ; cc464030 1cc2b192
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[76:77], v[120:127] ; cc464078 1de29912
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[114:115], v[78:79], v[102:109] ; cc464066 1d9a9d72
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[10:11], v[4:5], v[184:191] ; cc4640b8 1ee2090a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[10:11], v[6:7], v[48:55] ; cc464030 1cc20d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[114:115], v[84:85], v[120:127] ; cc464078 1de2a972
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[96:97], v[8:9], 0   ; cc464020 1a021160
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[118:119], v[86:87], v[102:109] ; cc464066 1d9aad76
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[8:9], 0   ; cc464038 1a021118
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[118:119], v[92:93], v[120:127] ; cc464078 1de2b976
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[146:147], v[94:95], v[102:109] ; cc464066 1d9abd92
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[150:151], v[4:5], v[40:47] ; cc464028 1ca20996
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[148:149], v[4:5], v[32:39] ; cc464020 1c820994
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[182:183], v[4:5], v[64:71] ; cc464040 1d0209b6
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[180:181], v[4:5], v[56:63] ; cc464038 1ce209b4
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[146:147], v[100:101], v[120:127] ; cc464078 1de2c992
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[10:11], v[82:83], v[102:109] ; cc464066 1d9aa50a
	v_dual_mul_f32 v88, v67, v67 :: v_dual_mul_f32 v29, v41, v41 ; c8c68743 581c5329
	v_dual_mul_f32 v31, v43, v43 :: v_dual_mul_f32 v30, v65, v65 ; c8c6572b 1f1e8341
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[132:133], 0 ; cc464048 1a030908
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[134:135], 0 ; cc464050 1a030d08
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[90:91], v[120:127] ; cc464078 1de2b50a
	v_dual_fmac_f32 v88, v59, v59 :: v_dual_fmac_f32 v29, v33, v33 ; c800773b 581c4321
	v_dual_fmac_f32 v31, v35, v35 :: v_dual_fmac_f32 v30, v57, v57 ; c8004723 1f1e7339
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[4:5], v[176:177], v[72:79] ; cc464048 1d236104
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[4:5], v[178:179], v[80:87] ; cc464050 1d436504
	v_dual_fmac_f32 v88, v63, v63 :: v_dual_fmac_f32 v29, v37, v37 ; c8007f3f 581c4b25
	v_dual_fmac_f32 v31, v39, v39 :: v_dual_fmac_f32 v30, v61, v61 ; c8004f27 1f1e7b3d
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s28, 0x76543210                                   ; be9c00ff 76543210
	s_mov_b32 s30, 0xfedcba98                                   ; be9e00ff fedcba98
	v_dual_fmac_f32 v88, v71, v71 :: v_dual_fmac_f32 v29, v45, v45 ; c8008f47 581c5b2d
	s_movk_i32 s31, 0x410                                       ; b01f0410
	v_dual_fmac_f32 v31, v47, v47 :: v_dual_fmac_f32 v30, v69, v69 ; c8005f2f 1f1e8b45
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v88, v58, v58 :: v_dual_fmac_f32 v29, v32, v32 ; c800753a 581c4120
	v_dual_fmac_f32 v30, v56, v56 :: v_dual_fmac_f32 v31, v34, v34 ; c8007138 1e1e4522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v88, v66, v66 :: v_dual_fmac_f32 v29, v40, v40 ; c8008542 581c5128
	v_dual_fmac_f32 v30, v64, v64 :: v_dual_fmac_f32 v31, v42, v42 ; c8008140 1e1e552a
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v88, v62, v62 :: v_dual_fmac_f32 v29, v36, v36 ; c8007d3e 581c4924
	v_dual_fmac_f32 v30, v60, v60 :: v_dual_fmac_f32 v31, v38, v38 ; c800793c 1e1e4d26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v88, v70, v70 :: v_dual_fmac_f32 v29, v44, v44 ; c8008d46 581c592c
	v_dual_fmac_f32 v30, v68, v68 :: v_dual_fmac_f32 v31, v46, v46 ; c8008944 1e1e5d2e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v89, 1.0, v29, v31                          ; cc210059 047e3af2
	v_fma_mixhi_f16 v89, 1.0, v30, v88                          ; cc220059 05623cf2
	v_permlanex16_b32 v90, v89, s28, s30 op_sel:[1,1]           ; d65c185a 00783959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0059
	v_min_num_f64_e32 v[1:2], v[89:90], v[90:91]                ; 1a02b559
(invalid instruction)                                        ; cc1c0059
	v_subrev_f32_e32 v0, v89, v31                               ; 0a003f59
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v91, v89                                  ; 7eb61759
	v_cvt_f32_f16_e32 v89, v217/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eb217d9
	v_rsq_f32_e32 v91, v91                                      ; 7eb65d5b
	v_rsq_f32_e32 v89, v89                                      ; 7eb25d59
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_mul_f32_e32 v91, s10, v91                                 ; 10b6b60a
	v_dual_mul_f32 v59, v59, v89 :: v_dual_mul_f32 v58, v58, v89 ; c8c6b33b 3b3ab33a
	v_dual_mul_f32 v61, v61, v89 :: v_dual_mul_f32 v60, v60, v89 ; c8c6b33d 3d3cb33c
	v_dual_mul_f32 v63, v63, v89 :: v_dual_mul_f32 v62, v62, v89 ; c8c6b33f 3f3eb33e
	v_dual_mul_f32 v57, v57, v89 :: v_dual_mul_f32 v56, v56, v89 ; c8c6b339 3938b338
	v_dual_mul_f32 v37, v37, v91 :: v_dual_mul_f32 v36, v36, v91 ; c8c6b725 2524b724
	v_dual_mul_f32 v45, v45, v91 :: v_dual_mul_f32 v44, v44, v91 ; c8c6b72d 2d2cb72c
	v_dual_mul_f32 v41, v41, v91 :: v_dual_mul_f32 v40, v40, v91 ; c8c6b729 2928b728
	v_dual_mul_f32 v32, v32, v91 :: v_dual_mul_f32 v33, v33, v91 ; c8c6b720 2020b721
	v_dual_mul_f32 v65, v65, v89 :: v_dual_mul_f32 v64, v64, v89 ; c8c6b341 4140b340
	v_dual_mul_f32 v43, v43, v91 :: v_dual_mul_f32 v42, v42, v91 ; c8c6b72b 2b2ab72a
	v_dual_mul_f32 v47, v47, v91 :: v_dual_mul_f32 v46, v46, v91 ; c8c6b72f 2f2eb72e
	v_dual_mul_f32 v39, v39, v91 :: v_dual_mul_f32 v38, v38, v91 ; c8c6b727 2726b726
	v_dual_mul_f32 v34, v34, v91 :: v_dual_mul_f32 v35, v35, v91 ; c8c6b722 2222b723
	v_dual_mul_f32 v67, v67, v89 :: v_dual_mul_f32 v66, v66, v89 ; c8c6b343 4342b342
	v_dual_mul_f32 v69, v69, v89 :: v_dual_mul_f32 v68, v68, v89 ; c8c6b345 4544b344
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	v_lshl_add_u32 v92, v2, 5, v1                               ; d646005c 04050b02
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	v_dual_mul_f32 v71, v71, v89 :: v_dual_mul_f32 v70, v70, v89 ; c8c6b347 4746b346
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v92, v[8:9], v[30:31] offset1:2          ; d9380200 001e085c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[98:99], v[12:13], 0 ; cc464028 1a021962
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[26:27], v[12:13], 0 ; cc464040 1a02191a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[96:97], v[12:13], 0 ; cc464020 1a021960
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[12:13], 0 ; cc464038 1a021918
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[12:13], v[132:133], 0 ; cc464048 1a03090c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[150:151], v[6:7], v[40:47] ; cc464028 1ca20d96
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[134:135], 0 ; cc464050 1a030d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[182:183], v[6:7], v[64:71] ; cc464040 1d020db6
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[148:149], v[6:7], v[32:39] ; cc464020 1c820d94
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[180:181], v[6:7], v[56:63] ; cc464038 1ce20db4
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[6:7], v[176:177], v[72:79] ; cc464048 1d236106
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[6:7], v[178:179], v[80:87] ; cc464050 1d436506
	v_dual_mul_f32 v100, v67, v67 :: v_dual_mul_f32 v93, v41, v41 ; c8c68743 645c5329
	v_dual_mul_f32 v95, v43, v43 :: v_dual_mul_f32 v94, v65, v65 ; c8c6572b 5f5e8341
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v100, v59, v59 :: v_dual_fmac_f32 v93, v33, v33 ; c800773b 645c4321
	v_dual_fmac_f32 v95, v35, v35 :: v_dual_fmac_f32 v94, v57, v57 ; c8004723 5f5e7339
	v_dual_fmac_f32 v100, v63, v63 :: v_dual_fmac_f32 v93, v37, v37 ; c8007f3f 645c4b25
	v_dual_fmac_f32 v95, v39, v39 :: v_dual_fmac_f32 v94, v61, v61 ; c8004f27 5f5e7b3d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v100, v71, v71 :: v_dual_fmac_f32 v93, v45, v45 ; c8008f47 645c5b2d
	v_dual_fmac_f32 v95, v47, v47 :: v_dual_fmac_f32 v94, v69, v69 ; c8005f2f 5f5e8b45
	v_dual_fmac_f32 v100, v58, v58 :: v_dual_fmac_f32 v93, v32, v32 ; c800753a 645c4120
	v_dual_fmac_f32 v94, v56, v56 :: v_dual_fmac_f32 v95, v34, v34 ; c8007138 5e5e4522
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v100, v66, v66 :: v_dual_fmac_f32 v93, v40, v40 ; c8008542 645c5128
	v_dual_fmac_f32 v94, v64, v64 :: v_dual_fmac_f32 v95, v42, v42 ; c8008140 5e5e552a
	v_dual_fmac_f32 v100, v62, v62 :: v_dual_fmac_f32 v93, v36, v36 ; c8007d3e 645c4924
	v_dual_fmac_f32 v94, v60, v60 :: v_dual_fmac_f32 v95, v38, v38 ; c800793c 5e5e4d26
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v100, v70, v70 :: v_dual_fmac_f32 v93, v44, v44 ; c8008d46 645c592c
	v_dual_fmac_f32 v94, v68, v68 :: v_dual_fmac_f32 v95, v46, v46 ; c8008944 5e5e5d2e
	v_fma_mixlo_f16 v101, 1.0, v93, v95                         ; cc210065 057ebaf2
	v_fma_mixhi_f16 v101, 1.0, v94, v100                        ; cc220065 0592bcf2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v110, v101, s28, s30 op_sel:[1,1]         ; d65c186e 00783965
(invalid instruction)                                        ; cc0f0065
	v_min_num_f64_e32 v[1:2], v[101:102], v[110:111]            ; 1a02dd65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v31                              ; 0a003f65
	v_cvt_f32_f16_e32 v111, v101                                ; 7ede1765
	v_cvt_f32_f16_e32 v101, v229/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eca17e5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v111, v111                                    ; 7ede5d6f
	v_rsq_f32_e32 v101, v101                                    ; 7eca5d65
	v_mul_f32_e32 v111, s10, v111                               ; 10dede0a
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v63, v63, v101 :: v_dual_mul_f32 v62, v62, v101 ; c8c6cb3f 3f3ecb3e
	v_dual_mul_f32 v59, v59, v101 :: v_dual_mul_f32 v58, v58, v101 ; c8c6cb3b 3b3acb3a
	v_dual_mul_f32 v61, v61, v101 :: v_dual_mul_f32 v60, v60, v101 ; c8c6cb3d 3d3ccb3c
	v_dual_mul_f32 v57, v57, v101 :: v_dual_mul_f32 v56, v56, v101 ; c8c6cb39 3938cb38
	v_dual_mul_f32 v32, v32, v111 :: v_dual_mul_f32 v33, v33, v111 ; c8c6df20 2020df21
	v_dual_mul_f32 v41, v41, v111 :: v_dual_mul_f32 v40, v40, v111 ; c8c6df29 2928df28
	v_dual_mul_f32 v36, v36, v111 :: v_dual_mul_f32 v37, v37, v111 ; c8c6df24 2424df25
	v_dual_mul_f32 v65, v65, v101 :: v_dual_mul_f32 v64, v64, v101 ; c8c6cb41 4140cb40
	v_dual_mul_f32 v43, v43, v111 :: v_dual_mul_f32 v42, v42, v111 ; c8c6df2b 2b2adf2a
	v_dual_mul_f32 v34, v34, v111 :: v_dual_mul_f32 v35, v35, v111 ; c8c6df22 2222df23
	v_dual_mul_f32 v45, v45, v111 :: v_dual_mul_f32 v44, v44, v111 ; c8c6df2d 2d2cdf2c
	v_dual_mul_f32 v47, v47, v111 :: v_dual_mul_f32 v46, v46, v111 ; c8c6df2f 2f2edf2e
	v_dual_mul_f32 v39, v39, v111 :: v_dual_mul_f32 v38, v38, v111 ; c8c6df27 2726df26
	v_dual_mul_f32 v67, v67, v101 :: v_dual_mul_f32 v66, v66, v101 ; c8c6cb43 4342cb42
	v_dual_mul_f32 v69, v69, v101 :: v_dual_mul_f32 v68, v68, v101 ; c8c6cb45 4544cb44
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
	v_dual_mul_f32 v71, v71, v101 :: v_dual_mul_f32 v70, v70, v101 ; c8c6cb47 4746cb46
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v92, v[12:13], v[34:35] offset0:64 offset1:66 ; d9384240 00220c5c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[98:99], v[16:17], 0 ; cc464038 1a022162
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[16:17], 0 ; cc464048 1a02211a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[96:97], v[16:17], 0 ; cc464028 1a022160
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[16:17], 0 ; cc464040 1a022118
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[132:133], 0 ; cc464050 1a030910
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[150:151], v[10:11], v[56:63] ; cc464038 1ce21596
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[134:135], 0 ; cc464070 1a030d10
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[182:183], v[10:11], v[72:79] ; cc464048 1d2215b6
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[148:149], v[10:11], v[40:47] ; cc464028 1ca21594
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[180:181], v[10:11], v[64:71] ; cc464040 1d0215b4
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[10:11], v[176:177], v[80:87] ; cc464050 1d43610a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[178:179], v[112:119] ; cc464070 1dc3650a
	v_dual_mul_f32 v131, v75, v75 :: v_dual_mul_f32 v128, v57, v57 ; c8c6974b 83807339
	v_dual_mul_f32 v130, v59, v59 :: v_dual_mul_f32 v129, v73, v73 ; c8c6773b 82809349
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v131, v67, v67 :: v_dual_fmac_f32 v128, v41, v41 ; c8008743 83805329
	v_dual_fmac_f32 v130, v43, v43 :: v_dual_fmac_f32 v129, v65, v65 ; c800572b 82808341
	v_dual_fmac_f32 v131, v71, v71 :: v_dual_fmac_f32 v128, v45, v45 ; c8008f47 83805b2d
	v_dual_fmac_f32 v130, v47, v47 :: v_dual_fmac_f32 v129, v69, v69 ; c8005f2f 82808b45
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v131, v79, v79 :: v_dual_fmac_f32 v128, v61, v61 ; c8009f4f 83807b3d
	v_dual_fmac_f32 v130, v63, v63 :: v_dual_fmac_f32 v129, v77, v77 ; c8007f3f 82809b4d
	v_dual_fmac_f32 v131, v66, v66 :: v_dual_fmac_f32 v128, v40, v40 ; c8008542 83805128
	v_dual_fmac_f32 v129, v64, v64 :: v_dual_fmac_f32 v130, v42, v42 ; c8008140 8182552a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v131, v74, v74 :: v_dual_fmac_f32 v128, v56, v56 ; c800954a 83807138
	v_dual_fmac_f32 v129, v72, v72 :: v_dual_fmac_f32 v130, v58, v58 ; c8009148 8182753a
	v_dual_fmac_f32 v131, v70, v70 :: v_dual_fmac_f32 v128, v44, v44 ; c8008d46 8380592c
	v_dual_fmac_f32 v129, v68, v68 :: v_dual_fmac_f32 v130, v46, v46 ; c8008944 81825d2e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v131, v78, v78 :: v_dual_fmac_f32 v128, v60, v60 ; c8009d4e 8380793c
	v_dual_fmac_f32 v129, v76, v76 :: v_dual_fmac_f32 v130, v62, v62 ; c800994c 81827d3e
	v_fma_mixlo_f16 v144, 1.0, v128, v130                       ; cc210090 060b00f2
	v_fma_mixhi_f16 v144, 1.0, v129, v131                       ; cc220090 060f02f2
	v_lshl_add_u32 v2, v2, 6, s7                                ; d6460002 001d0d02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v145, v144, s28, s30 op_sel:[1,1]         ; d65c1891 00783990
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
(invalid instruction)                                        ; cc0f0090
	v_min_num_f64_e32 v[1:2], v[144:145], v[145:146]            ; 1a032390
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0090
	v_subrev_f32_e32 v0, v144, v31                              ; 0a003f90
(invalid instruction)                                        ; d58b0092
	v_cndmask_b32_e32 v0, v144, v128, vcc_lo                    ; 02010190
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v146, v146                                    ; 7f245d92
	v_mul_f32_e32 v146, s10, v146                               ; 1125240a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v41, v41, v146 :: v_dual_mul_f32 v40, v40, v146 ; c8c72529 29292528
	v_dual_mul_f32 v43, v43, v146 :: v_dual_mul_f32 v42, v42, v146 ; c8c7252b 2b2b252a
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[36:39], v2, s[40:43], null offen         ; c405c07c 40805024 00000002
	buffer_load_b128 v[40:43], v2, s[40:43], null offen offset:16 ; c405c07c 40805028 00001002
(invalid instruction)                                        ; d58b0890
	v_cndmask_b32_e32 v0, v144, v128, vcc_lo                    ; 02010190
	v_dual_mul_f32 v45, v45, v146 :: v_dual_mul_f32 v44, v44, v146 ; c8c7252d 2d2d252c
	v_dual_mul_f32 v47, v47, v146 :: v_dual_mul_f32 v46, v46, v146 ; c8c7252f 2f2f252e
	v_dual_mul_f32 v57, v57, v146 :: v_dual_mul_f32 v56, v56, v146 ; c8c72539 39392538
	v_dual_mul_f32 v59, v59, v146 :: v_dual_mul_f32 v58, v58, v146 ; c8c7253b 3b3b253a
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_rsq_f32_e32 v144, v144                                    ; 7f205d90
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a5
	v_dual_mul_f32 v67, v67, v144 :: v_dual_mul_f32 v66, v66, v144 ; c8c72143 43432142
	v_dual_mul_f32 v65, v65, v144 :: v_dual_mul_f32 v64, v64, v144 ; c8c72141 41412140
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[64:67], v2, s[40:43], null offen offset:4096 ; c405c07c 40805040 00100002
	buffer_load_b128 v[56:59], v2, s[40:43], null offen offset:4112 ; c405c07c 40805038 00101002
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	v_dual_mul_f32 v61, v61, v146 :: v_dual_mul_f32 v60, v60, v146 ; c8c7253d 3d3d253c
	v_dual_mul_f32 v63, v63, v146 :: v_dual_mul_f32 v62, v62, v146 ; c8c7253f 3f3f253e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	buffer_load_b128 v[60:63], v2, s[40:43], null offen offset:8192 ; c405c07c 4080503c 00200002
	v_dual_mul_f32 v75, v75, v144 :: v_dual_mul_f32 v74, v74, v144 ; c8c7214b 4b4b214a
	v_dual_mul_f32 v69, v69, v144 :: v_dual_mul_f32 v68, v68, v144 ; c8c72145 45452144
	v_dual_mul_f32 v71, v71, v144 :: v_dual_mul_f32 v70, v70, v144 ; c8c72147 47472146
	v_dual_mul_f32 v73, v73, v144 :: v_dual_mul_f32 v72, v72, v144 ; c8c72149 49492148
	v_dual_mul_f32 v77, v77, v144 :: v_dual_mul_f32 v76, v76, v144 ; c8c7214d 4d4d214c
	v_dual_mul_f32 v79, v79, v144 :: v_dual_mul_f32 v78, v78, v144 ; c8c7214f 4f4f214e
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v92, v[16:17], v[46:47] offset0:128 offset1:130 ; d9388280 002e105c
	buffer_load_b128 v[68:71], v2, s[40:43], null offen offset:8208 ; c405c07c 40805044 00201002
	v_mov_b32_e32 v47, v23                                      ; 7e5e0317
	v_dual_mov_b32 v147, v20 :: v_dual_mov_b32 v46, v22         ; ca100114 932e0116
	v_dual_mov_b32 v89, v127 :: v_dual_mov_b32 v88, v126        ; ca10017f 5958017e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[96:97], v[22:23], 0 ; cc464048 1a022d60
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[98:99], v[22:23], 0 ; cc464050 1a022d62
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[22:23], 0 ; cc464070 1a022d18
	v_wmma_f32_16x16x16_fp8_fp8 v[94:101], v[26:27], v[22:23], 0 ; cc46405e 1a022d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[20:27], v[46:47], v[132:133], 0 ; cc464014 1a03092e
	v_wmma_f32_16x16x16_fp8_fp8 v[126:133], v[46:47], v[134:135], 0 ; cc46407e 1a030d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[148:149], v[14:15], v[72:79] ; cc464048 1d221d94
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[150:151], v[14:15], v[80:87] ; cc464050 1d421d96
	v_wmma_f32_16x16x16_fp8_fp8 v[20:27], v[14:15], v[176:177], v[20:27] ; cc464014 1c53610e
	v_wmma_f32_16x16x16_fp8_fp8 v[126:133], v[14:15], v[178:179], v[126:133] ; cc46407e 1dfb650e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[148:151], v2, s[40:43], null offen offset:12288 ; c405c07c 40805094 00300002
	buffer_load_b128 v[176:179], v2, s[40:43], null offen offset:12304 ; c405c07c 408050b0 00301002
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[180:181], v[14:15], v[112:119] ; cc464070 1dc21db4
	v_wmma_f32_16x16x16_fp8_fp8 v[94:101], v[182:183], v[14:15], v[94:101] ; cc46405e 1d7a1db6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v91, v95, v95 :: v_dual_mul_f32 v90, v81, v81 ; c8c6bf5f 5b5aa351
	v_dual_mul_f32 v93, v83, v83 :: v_dual_fmac_f32 v90, v73, v73 ; c8c0a753 5d5a9349
	v_fmac_f32_e32 v91, v113, v113                              ; 56b6e371
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmac_f32 v93, v75, v75 :: v_dual_mul_f32 v110, v97, v97 ; c806974b 5d6ec361
	v_dual_fmac_f32 v91, v117, v117 :: v_dual_fmac_f32 v110, v115, v115 ; c800eb75 5b6ee773
	buffer_load_b128 v[180:183], v2, s[40:43], null offen offset:64 ; c405c07c 408050b4 00004002
	v_mov_b32_e32 v134, v147                                    ; 7f0c0393
	buffer_load_b128 v[144:147], v2, s[40:43], null offen offset:80 ; c405c07c 40805090 00005002
	v_fmac_f32_e32 v110, v119, v119                             ; 56dcef77
	v_dual_fmac_f32 v91, v99, v99 :: v_dual_fmac_f32 v90, v77, v77 ; c800c763 5b5a9b4d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v93, v79, v79 :: v_dual_fmac_f32 v90, v85, v85 ; c8009f4f 5d5aab55
	v_dual_fmac_f32 v110, v101, v101 :: v_dual_fmac_f32 v93, v87, v87 ; c800cb65 6e5caf57
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmac_f32 v93, v74, v74 :: v_dual_fmac_f32 v90, v72, v72 ; c800954a 5d5a9148
	v_dual_fmac_f32 v110, v114, v114 :: v_dual_fmac_f32 v91, v112, v112 ; c800e572 6e5ae170
	v_dual_fmac_f32 v93, v82, v82 :: v_dual_fmac_f32 v90, v80, v80 ; c800a552 5d5aa150
	v_dual_fmac_f32 v110, v96, v96 :: v_dual_fmac_f32 v91, v94, v94 ; c800c160 6e5abd5e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v90, v76, v76 :: v_dual_fmac_f32 v93, v78, v78 ; c800994c 5a5c9d4e
	v_dual_fmac_f32 v110, v118, v118 :: v_dual_fmac_f32 v91, v116, v116 ; c800ed76 6e5ae974
	v_dual_fmac_f32 v93, v86, v86 :: v_dual_fmac_f32 v90, v84, v84 ; c800ad56 5d5aa954
	v_dual_fmac_f32 v110, v100, v100 :: v_dual_fmac_f32 v91, v98, v98 ; c800c964 6e5ac562
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mixlo_f16 v111, 1.0, v90, v93                         ; cc21006f 0576b4f2
	v_fma_mixhi_f16 v111, 1.0, v91, v110                        ; cc22006f 05bab6f2
	v_permlanex16_b32 v135, v111, s28, s30 op_sel:[1,1]         ; d65c1887 0078396f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[135:136]            ; 1a030f6f
(invalid instruction)                                        ; cc1c006f
	v_subrev_f32_e32 v0, v111, v31                              ; 0a003f6f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v14, v111                                 ; 7e1c176f
	v_rsq_f32_e32 v14, v14                                      ; 7e1c5d0e
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v14, s10, v14                                 ; 101c1c0a
	v_dual_mul_f32 v72, v72, v14 :: v_dual_mul_f32 v73, v73, v14 ; c8c61d48 48481d49
	v_dual_mul_f32 v78, v78, v14 :: v_dual_mul_f32 v79, v79, v14 ; c8c61d4e 4e4e1d4f
	v_dual_mul_f32 v74, v74, v14 :: v_dual_mul_f32 v75, v75, v14 ; c8c61d4a 4a4a1d4b
	v_dual_mul_f32 v76, v76, v14 :: v_dual_mul_f32 v77, v77, v14 ; c8c61d4c 4c4c1d4d
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v2, s[40:43], null offen offset:4160 ; c405c07c 40805048 00104002
	buffer_load_b128 v[76:79], v2, s[40:43], null offen offset:4176 ; c405c07c 4080504c 00105002
	v_cvt_f32_f16_e32 v111, v239/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ede17ef
	v_dual_mul_f32 v81, v81, v14 :: v_dual_mul_f32 v80, v80, v14 ; c8c61d51 51501d50
	v_dual_mul_f32 v83, v83, v14 :: v_dual_mul_f32 v82, v82, v14 ; c8c61d53 53521d52
	v_dual_mul_f32 v85, v85, v14 :: v_dual_mul_f32 v84, v84, v14 ; c8c61d55 55541d54
	v_dual_mul_f32 v87, v87, v14 :: v_dual_mul_f32 v86, v86, v14 ; c8c61d57 57561d56
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_rsq_f32_e32 v111, v111                                    ; 7ede5d6f
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v115, v115, v111 :: v_dual_mul_f32 v114, v114, v111 ; c8c6df73 7372df72
	v_dual_mul_f32 v95, v95, v111 :: v_dual_mul_f32 v94, v94, v111 ; c8c6df5f 5f5edf5e
	v_dual_mul_f32 v119, v119, v111 :: v_dual_mul_f32 v118, v118, v111 ; c8c6df77 7776df76
	v_mul_f32_e32 v112, v112, v111                              ; 10e0df70
	v_dual_mul_f32 v97, v97, v111 :: v_dual_mul_f32 v96, v96, v111 ; c8c6df61 6160df60
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v111 ; c8c6df75 7574df74
	v_dual_mul_f32 v99, v99, v111 :: v_dual_mul_f32 v98, v98, v111 ; c8c6df63 6362df62
	v_dual_mul_f32 v101, v101, v111 :: v_dual_mul_f32 v100, v100, v111 ; c8c6df65 6564df64
	v_mul_f32_e32 v113, v113, v111                              ; 10e2df71
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v92, v[90:91], v[14:15] offset0:192 offset1:194 ; d938c2c0 000e5a5c
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_load_b64 v[24:25], v92                                   ; d9d80000 1800005c
	ds_load_b64 v[26:27], v92 offset:16                         ; d9d80010 1a00005c
	s_mov_b32 s32, 0x3d380000                                   ; bea000ff 3d380000
	s_movk_i32 s33, 0x3e47                                      ; b0213e47
	s_movk_i32 s34, 0x3c20                                      ; b0223c20
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[126:133], v[24:25], v[46:47], 0 ; cc46407e 1a025d18
	v_wmma_f32_16x16x16_fp8_fp8 v[94:101], v[24:25], v[10:11], 0 ; cc46405e 1a021518
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[4:5], 0   ; cc464050 1a020918
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[6:7], 0 ; cc464070 1a020d18
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[126:133], v[26:27], v[22:23], v[126:133] ; cc46407e 1dfa2d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[26:27], v[28:29], v[80:87] ; cc464050 1d42391a
	v_wmma_f32_16x16x16_fp8_fp8 v[94:101], v[26:27], v[44:45], v[94:101] ; cc46405e 1d7a591a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[32:33], v[112:119] ; cc464070 1dc2411a
	v_mov_b32_e32 v27, v92                                      ; 7e36035c
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v24, s32, v80, v36                          ; cc210018 0492a020
	v_fma_mixhi_f16 v24, s32, v81, v37                          ; cc220018 0496a220
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v26, s32, v84, v40                          ; cc21001a 04a2a820
	v_fma_mixhi_f16 v26, s32, v85, v41                          ; cc22001a 04a6aa20
	v_dual_mov_b32 v85, v43 :: v_dual_mov_b32 v84, v42          ; ca10012b 5554012a
	v_fma_mixlo_f16 v25, s32, v82, v38                          ; cc210019 049aa420
	v_fma_mixhi_f16 v25, s32, v83, v39                          ; cc220019 049ea620
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[36:39], v2, s[40:43], null offen offset:8256 ; c405c07c 40805024 00204002
	buffer_load_b128 v[80:83], v2, s[40:43], null offen offset:8272 ; c405c07c 40805050 00205002
	buffer_load_b128 v[90:93], v2, s[40:43], null offen offset:12352 ; c405c07c 4080505a 00304002
	buffer_load_b128 v[40:43], v2, s[40:43], null offen offset:12368 ; c405c07c 40805028 00305002
(invalid instruction)                                        ; cc1c0018
	v_subrev_f32_e32 v0, v24, v34                               ; 0a004518
(invalid instruction)                                        ; cc1c001a
	v_subrev_f32_e32 v0, v26, v34                               ; 0a00451a
	v_fma_mixlo_f16 v86, s32, v86, v84                          ; cc210056 0552ac20
	v_fma_mixhi_f16 v86, s32, v87, v85                          ; cc220056 0556ae20
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_fma_mixlo_f16 v110, s32, v114, v66                        ; cc21006e 050ae420
	v_fma_mixhi_f16 v110, s32, v115, v67                        ; cc22006e 050ee620
	v_fma_mixlo_f16 v87, s32, v112, v64                         ; cc210057 0502e020
	v_fma_mixhi_f16 v87, s32, v113, v65                         ; cc220057 0506e220
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v34                               ; 0a004519
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v111, s32, v116, v56                        ; cc21006f 04e2e820
	v_fma_mixhi_f16 v111, s32, v117, v57                        ; cc22006f 04e6ea20
(invalid instruction)                                        ; cc1b0018
	v_subrev_f32_e32 v0, v24, v33                               ; 0a004318
(invalid instruction)                                        ; cc1b001a
	v_subrev_f32_e32 v0, v26, v33                               ; 0a00431a
	v_fma_mixlo_f16 v112, s32, v118, v58                        ; cc210070 04eaec20
	v_fma_mixhi_f16 v112, s32, v119, v59                        ; cc220070 04eeee20
(invalid instruction)                                        ; cc1c0056
	v_subrev_f32_e32 v0, v86, v34                               ; 0a004556
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v113, s32, v94, v60                         ; cc210071 04f2bc20
(invalid instruction)                                        ; cc1c006e
	v_subrev_f32_e32 v0, v110, v34                              ; 0a00456e
	v_fma_mixhi_f16 v113, s32, v95, v61                         ; cc220071 04f6be20
(invalid instruction)                                        ; cc1c0057
	v_subrev_f32_e32 v0, v87, v34                               ; 0a004557
	ds_load_b64 v[56:57], v27 offset:512                        ; d9d80200 3800001b
(invalid instruction)                                        ; cc1b0019
	v_subrev_f32_e32 v0, v25, v33                               ; 0a004319
	v_fma_mixlo_f16 v114, s32, v96, v62                         ; cc210072 04fac020
	v_fma_mixhi_f16 v114, s32, v97, v63                         ; cc220072 04fec220
	ds_load_b64 v[58:59], v27 offset:528                        ; d9d80210 3a00001b
(invalid instruction)                                        ; cc1c006f
	v_subrev_f32_e32 v0, v111, v34                              ; 0a00456f
(invalid instruction)                                        ; cc1c0070
	v_subrev_f32_e32 v0, v112, v34                              ; 0a004570
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v115, s32, v98, v68                         ; cc210073 0512c420
	v_fma_mixhi_f16 v115, s32, v99, v69                         ; cc220073 0516c620
(invalid instruction)                                        ; cc1b0056
	v_subrev_f32_e32 v0, v86, v33                               ; 0a004356
(invalid instruction)                                        ; cc1b006e
	v_subrev_f32_e32 v0, v110, v33                              ; 0a00436e
(invalid instruction)                                        ; cc1c0071
	v_subrev_f32_e32 v0, v113, v34                              ; 0a004571
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v117, s32, v126, v148                       ; cc210075 0652fc20
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v126, s32, v132, v178                       ; cc21007e 06cb0820
(invalid instruction)                                        ; cc1b0057
	v_subrev_f32_e32 v0, v87, v33                               ; 0a004357
	v_fma_mixhi_f16 v126, s32, v133, v179                       ; cc22007e 06cf0a20
(invalid instruction)                                        ; cc1c0072
	v_subrev_f32_e32 v0, v114, v34                              ; 0a004572
	v_dual_mov_b32 v62, v153 :: v_dual_mov_b32 v61, v152        ; ca100199 3e3c0198
(invalid instruction)                                        ; cc1b006f
	v_subrev_f32_e32 v0, v111, v33                              ; 0a00436f
	v_dual_mov_b32 v84, v155 :: v_dual_mov_b32 v63, v154        ; ca10019b 543e019a
(invalid instruction)                                        ; cc1b0070
	v_subrev_f32_e32 v0, v112, v33                              ; 0a004370
	v_fma_mixlo_f16 v116, s32, v100, v70                        ; cc210074 051ac820
	v_fma_mixhi_f16 v116, s32, v101, v71                        ; cc220074 051eca20
(invalid instruction)                                        ; cc1c0073
	v_subrev_f32_e32 v0, v115, v34                              ; 0a004573
	v_fma_mixhi_f16 v117, s32, v127, v149                       ; cc220075 0656fe20
(invalid instruction)                                        ; cc1b0071
	v_subrev_f32_e32 v0, v113, v33                              ; 0a004371
	v_fma_mixlo_f16 v118, s32, v128, v150                       ; cc210076 065b0020
	v_fma_mixhi_f16 v118, s32, v129, v151                       ; cc220076 065f0220
(invalid instruction)                                        ; cc1c007e
	v_subrev_f32_e32 v0, v126, v34                              ; 0a00457e
(invalid instruction)                                        ; cc1b0072
	v_subrev_f32_e32 v0, v114, v33                              ; 0a004372
	v_fma_mixlo_f16 v119, s32, v130, v176                       ; cc210077 06c30420
	v_fma_mixhi_f16 v119, s32, v131, v177                       ; cc220077 06c70620
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[56:57], v[4:5], 0   ; cc464040 1a020938
(invalid instruction)                                        ; cc1c0074
	v_subrev_f32_e32 v0, v116, v34                              ; 0a004574
(invalid instruction)                                        ; cc1b0073
	v_subrev_f32_e32 v0, v115, v33                              ; 0a004373
	v_wmma_f32_16x16x16_fp8_fp8 v[94:101], v[56:57], v[6:7], 0  ; cc46405e 1a020d38
(invalid instruction)                                        ; cc1c0075
	v_subrev_f32_e32 v0, v117, v34                              ; 0a004575
	v_wmma_f32_16x16x16_fp8_fp8 v[148:155], v[56:57], v[46:47], 0 ; cc464094 1a025d38
(invalid instruction)                                        ; cc1c0076
	v_subrev_f32_e32 v0, v118, v34                              ; 0a004576
(invalid instruction)                                        ; cc1b007e
	v_subrev_f32_e32 v0, v126, v33                              ; 0a00437e
(invalid instruction)                                        ; cc1c0077
	v_subrev_f32_e32 v0, v119, v34                              ; 0a004577
(invalid instruction)                                        ; cc1b0074
	v_subrev_f32_e32 v0, v116, v33                              ; 0a004374
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[58:59], v[28:29], v[64:71] ; cc464040 1d02393a
(invalid instruction)                                        ; cc1b0075
	v_subrev_f32_e32 v0, v117, v33                              ; 0a004375
	v_wmma_f32_16x16x16_fp8_fp8 v[94:101], v[58:59], v[32:33], v[94:101] ; cc46405e 1d7a413a
(invalid instruction)                                        ; cc1b0076
	v_subrev_f32_e32 v0, v118, v33                              ; 0a004376
	v_mov_b32_e32 v60, v126                                     ; 7e78037e
	v_wmma_f32_16x16x16_fp8_fp8 v[126:133], v[56:57], v[10:11], 0 ; cc46407e 1a021538
(invalid instruction)                                        ; cc1b0077
	v_subrev_f32_e32 v0, v119, v33                              ; 0a004377
	v_wmma_f32_16x16x16_fp8_fp8 v[148:155], v[58:59], v[22:23], v[148:155] ; cc464094 1e522d3a
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v144, s32, v68, v144                        ; cc210090 06428820
	v_fma_mixhi_f16 v144, s32, v69, v145                        ; cc220090 06468a20
	v_fma_mixlo_f16 v85, s32, v64, v180                         ; cc210055 06d28020
	ds_load_b64 v[56:57], v27 offset:1024                       ; d9d80400 3800001b
	v_fma_mixlo_f16 v135, s32, v66, v182                        ; cc210087 06da8420
	v_fma_mixhi_f16 v135, s32, v67, v183                        ; cc220087 06de8620
	v_wmma_f32_16x16x16_fp8_fp8 v[126:133], v[58:59], v[44:45], v[126:133] ; cc46407e 1dfa593a
	ds_load_b64 v[58:59], v27 offset:1040                       ; d9d80410 3a00001b
	v_fma_mixhi_f16 v85, s32, v65, v181                         ; cc220055 06d68220
	v_fma_mixlo_f16 v145, s32, v70, v146                        ; cc210091 064a8c20
	v_fma_mixhi_f16 v145, s32, v71, v147                        ; cc220091 064e8e20
(invalid instruction)                                        ; cc1c0090
	v_subrev_f32_e32 v0, v144, v34                              ; 0a004590
(invalid instruction)                                        ; cc1c0087
	v_subrev_f32_e32 v0, v135, v34                              ; 0a004587
(invalid instruction)                                        ; cc1c0055
	v_subrev_f32_e32 v0, v85, v34                               ; 0a004555
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c0091
	v_subrev_f32_e32 v0, v145, v34                              ; 0a004591
(invalid instruction)                                        ; cc1b0090
	v_subrev_f32_e32 v0, v144, v33                              ; 0a004390
(invalid instruction)                                        ; cc1b0087
	v_subrev_f32_e32 v0, v135, v33                              ; 0a004387
(invalid instruction)                                        ; cc1b0055
	v_subrev_f32_e32 v0, v85, v33                               ; 0a004355
(invalid instruction)                                        ; cc1b0091
	v_subrev_f32_e32 v0, v145, v33                              ; 0a004391
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v146, s32, v94, v72                         ; cc210092 0522bc20
	v_fma_mixhi_f16 v146, s32, v95, v73                         ; cc220092 0526be20
	v_fma_mixlo_f16 v147, s32, v96, v74                         ; cc210093 052ac020
	v_fma_mixhi_f16 v147, s32, v97, v75                         ; cc220093 052ec220
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v176, s32, v98, v76                         ; cc2100b0 0532c420
	v_fma_mixhi_f16 v176, s32, v99, v77                         ; cc2200b0 0536c620
	v_fma_mixlo_f16 v177, s32, v100, v78                        ; cc2100b1 053ac820
	v_fma_mixhi_f16 v177, s32, v101, v79                        ; cc2200b1 053eca20
(invalid instruction)                                        ; cc1c0092
	v_subrev_f32_e32 v0, v146, v34                              ; 0a004592
(invalid instruction)                                        ; cc1c0093
	v_subrev_f32_e32 v0, v147, v34                              ; 0a004593
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v34                              ; 0a0045b0
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[56:57], v[4:5], 0   ; cc464040 1a020938
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v34                              ; 0a0045b1
(invalid instruction)                                        ; cc1b0092
	v_subrev_f32_e32 v0, v146, v33                              ; 0a004392
(invalid instruction)                                        ; cc1b0093
	v_subrev_f32_e32 v0, v147, v33                              ; 0a004393
(invalid instruction)                                        ; cc1b00b0
	v_subrev_f32_e32 v0, v176, v33                              ; 0a0043b0
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[56:57], v[6:7], 0   ; cc464048 1a020d38
	v_wmma_f32_16x16x16_fp8_fp8 v[94:101], v[56:57], v[10:11], 0 ; cc46405e 1a021538
(invalid instruction)                                        ; cc1b00b1
	v_subrev_f32_e32 v0, v177, v33                              ; 0a0043b1
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[58:59], v[28:29], v[64:71] ; cc464040 1d02393a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[58:59], v[32:33], v[72:79] ; cc464048 1d22413a
	v_wmma_f32_16x16x16_fp8_fp8 v[94:101], v[58:59], v[44:45], v[94:101] ; cc46405e 1d7a593a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v178, s32, v126, v36                        ; cc2100b2 0492fc20
	v_fma_mixlo_f16 v179, s32, v128, v38                        ; cc2100b3 049b0020
	v_fma_mixhi_f16 v179, s32, v129, v39                        ; cc2200b3 049f0220
	v_dual_mov_b32 v39, v125 :: v_dual_mov_b32 v38, v124        ; ca10017d 2726017c
	v_fma_mixhi_f16 v178, s32, v127, v37                        ; cc2200b2 0496fe20
	v_dual_mov_b32 v37, v123 :: v_dual_mov_b32 v36, v122        ; ca10017b 2524017a
	v_wmma_f32_16x16x16_fp8_fp8 v[122:129], v[56:57], v[46:47], 0 ; cc46407a 1a025d38
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v56, s32, v130, v80                         ; cc210038 05430420
	v_fma_mixhi_f16 v56, s32, v131, v81                         ; cc220038 05470620
	v_fma_mixlo_f16 v57, s32, v132, v82                         ; cc210039 054b0820
	v_fma_mixhi_f16 v57, s32, v133, v83                         ; cc220039 054f0a20
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v34                              ; 0a0045b3
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v34                              ; 0a0045b2
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v80, s32, v152, v40                         ; cc210050 04a33020
(invalid instruction)                                        ; cc1c0038
	v_subrev_f32_e32 v0, v56, v34                               ; 0a004538
	v_fma_mixhi_f16 v80, s32, v153, v41                         ; cc220050 04a73220
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v34                               ; 0a004539
	v_fma_mixlo_f16 v81, s32, v154, v42                         ; cc210051 04ab3420
(invalid instruction)                                        ; cc1b00b3
	v_subrev_f32_e32 v0, v179, v33                              ; 0a0043b3
(invalid instruction)                                        ; cc1b00b2
	v_subrev_f32_e32 v0, v178, v33                              ; 0a0043b2
	v_fma_mixhi_f16 v81, s32, v155, v43                         ; cc220051 04af3620
	v_wmma_f32_16x16x16_fp8_fp8 v[122:129], v[58:59], v[22:23], v[122:129] ; cc46407a 1dea2d3a
	v_fma_mixlo_f16 v58, s32, v148, v90                         ; cc21003a 056b2820
	v_fma_mixhi_f16 v58, s32, v149, v91                         ; cc22003a 056f2a20
	v_fma_mixlo_f16 v59, s32, v150, v92                         ; cc21003b 05732c20
	v_fma_mixhi_f16 v59, s32, v151, v93                         ; cc22003b 05772e20
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[40:43], v2, s[40:43], null offen offset:128 ; c405c07c 40805028 00008002
	buffer_load_b128 v[148:151], v2, s[40:43], null offen offset:144 ; c405c07c 40805094 00009002
	buffer_load_b128 v[152:155], v2, s[40:43], null offen offset:4224 ; c405c07c 40805098 00108002
	buffer_load_b128 v[180:183], v2, s[40:43], null offen offset:4240 ; c405c07c 408050b4 00109002
	buffer_load_b128 v[90:93], v2, s[40:43], null offen offset:8320 ; c405c07c 4080505a 00208002
	buffer_load_b128 v[130:133], v2, s[40:43], null offen offset:8336 ; c405c07c 40805082 00209002
(invalid instruction)                                        ; cc1b0038
	v_subrev_f32_e32 v0, v56, v33                               ; 0a004338
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v34                               ; 0a004550
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v33                               ; 0a004339
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v34                               ; 0a004551
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v34                               ; 0a00453a
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v34                               ; 0a00453b
(invalid instruction)                                        ; cc1b0050
	v_subrev_f32_e32 v0, v80, v33                               ; 0a004350
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v82, s32, v64, v40                          ; cc210052 04a28020
	v_fma_mixhi_f16 v82, s32, v65, v41                          ; cc220052 04a68220
	v_fma_mixlo_f16 v83, s32, v66, v42                          ; cc210053 04aa8420
	v_fma_mixhi_f16 v83, s32, v67, v43                          ; cc220053 04ae8620
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v2, s[40:43], null offen offset:12416 ; c405c07c 40805028 00308002
	buffer_load_b128 v[64:67], v2, s[40:43], null offen offset:12432 ; c405c07c 40805040 00309002
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v148, s32, v68, v148                        ; cc210094 06528820
	v_fma_mixhi_f16 v148, s32, v69, v149                        ; cc220094 06568a20
	ds_load_b64 v[68:69], v27 offset:1536                       ; d9d80600 4400001b
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v33                               ; 0a004351
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v33                               ; 0a00433a
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v33                               ; 0a00433b
	v_fma_mixlo_f16 v149, s32, v70, v150                        ; cc210095 065a8c20
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v150, s32, v72, v152                        ; cc210096 06629020
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v152, s32, v76, v180                        ; cc210098 06d29820
	v_fma_mixhi_f16 v152, s32, v77, v181                        ; cc220098 06d69a20
	v_dual_mov_b32 v181, v0 :: v_dual_mov_b32 v70, v3           ; ca100100 b5460103
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v34                               ; 0a004552
	v_fma_mixhi_f16 v150, s32, v73, v153                        ; cc220096 06669220
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v34                               ; 0a004553
	v_fma_mixlo_f16 v153, s32, v78, v182                        ; cc210099 06da9c20
	v_fma_mixhi_f16 v153, s32, v79, v183                        ; cc220099 06de9e20
	v_dual_mov_b32 v183, v2 :: v_dual_mov_b32 v182, v1          ; ca100102 b7b60101
	v_fma_mixhi_f16 v149, s32, v71, v151                        ; cc220095 065e8e20
	v_fma_mixlo_f16 v151, s32, v74, v154                        ; cc210097 066a9420
(invalid instruction)                                        ; cc1c0094
	v_subrev_f32_e32 v0, v148, v34                              ; 0a004594
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v154, s32, v94, v90                         ; cc21009a 056abc20
	v_fma_mixhi_f16 v154, s32, v95, v91                         ; cc22009a 056ebe20
	v_dual_mov_b32 v91, v127 :: v_dual_mov_b32 v90, v126        ; ca10017f 5b5a017e
	v_fma_mixhi_f16 v151, s32, v75, v155                        ; cc220097 066e9620
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v33                               ; 0a004352
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v71, s32, v100, v132                        ; cc210047 0612c820
(invalid instruction)                                        ; cc1c0096
	v_subrev_f32_e32 v0, v150, v34                              ; 0a004596
	v_fma_mixhi_f16 v71, s32, v101, v133                        ; cc220047 0616ca20
(invalid instruction)                                        ; cc1b0053
	v_subrev_f32_e32 v0, v83, v33                               ; 0a004353
	v_dual_mov_b32 v101, v129 :: v_dual_mov_b32 v100, v128      ; ca100181 65640180
(invalid instruction)                                        ; cc1c0098
	v_subrev_f32_e32 v0, v152, v34                              ; 0a004598
(invalid instruction)                                        ; cc1c0095
	v_subrev_f32_e32 v0, v149, v34                              ; 0a004595
(invalid instruction)                                        ; cc1c0099
	v_subrev_f32_e32 v0, v153, v34                              ; 0a004599
(invalid instruction)                                        ; cc1b0094
	v_subrev_f32_e32 v0, v148, v33                              ; 0a004394
	v_fma_mixlo_f16 v155, s32, v96, v92                         ; cc21009b 0572c020
(invalid instruction)                                        ; cc1c009a
	v_subrev_f32_e32 v0, v154, v34                              ; 0a00459a
	v_fma_mixhi_f16 v155, s32, v97, v93                         ; cc22009b 0576c220
(invalid instruction)                                        ; cc1c0097
	v_subrev_f32_e32 v0, v151, v34                              ; 0a004597
	v_fma_mixlo_f16 v180, s32, v98, v130                        ; cc2100b4 060ac420
(invalid instruction)                                        ; cc1b0096
	v_subrev_f32_e32 v0, v150, v33                              ; 0a004396
	v_fma_mixhi_f16 v180, s32, v99, v131                        ; cc2200b4 060ec620
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[68:69], v[4:5], 0   ; cc464048 1a020944
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[68:69], v[6:7], 0   ; cc46405c 1a020d44
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[68:69], v[10:11], 0   ; cc464000 1a021544
	ds_load_b64 v[10:11], v27 offset:1552                       ; d9d80610 0a00001b
(invalid instruction)                                        ; cc1b0098
	v_subrev_f32_e32 v0, v152, v33                              ; 0a004398
(invalid instruction)                                        ; cc1b0095
	v_subrev_f32_e32 v0, v149, v33                              ; 0a004395
(invalid instruction)                                        ; cc1c0047
	v_subrev_f32_e32 v0, v71, v34                               ; 0a004547
(invalid instruction)                                        ; cc1b0099
	v_subrev_f32_e32 v0, v153, v33                              ; 0a004399
	v_wmma_f32_16x16x16_fp8_fp8 v[126:133], v[68:69], v[46:47], 0 ; cc46407e 1a025d44
(invalid instruction)                                        ; cc1b009a
	v_subrev_f32_e32 v0, v154, v33                              ; 0a00439a
(invalid instruction)                                        ; cc1c009b
	v_subrev_f32_e32 v0, v155, v34                              ; 0a00459b
(invalid instruction)                                        ; cc1b0097
	v_subrev_f32_e32 v0, v151, v33                              ; 0a004397
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v34                              ; 0a0045b4
(invalid instruction)                                        ; cc1b0047
	v_subrev_f32_e32 v0, v71, v33                               ; 0a004347
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b009b
	v_subrev_f32_e32 v0, v155, v33                              ; 0a00439b
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[10:11], v[44:45], v[0:7] ; cc464000 1c02590a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[10:11], v[28:29], v[72:79] ; cc464048 1d22390a
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[10:11], v[32:33], v[92:99] ; cc46405c 1d72410a
(invalid instruction)                                        ; cc1b00b4
	v_subrev_f32_e32 v0, v180, v33                              ; 0a0043b4
	v_wmma_f32_16x16x16_fp8_fp8 v[126:133], v[10:11], v[22:23], v[126:133] ; cc46407e 1dfa2d0a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v122, s32, v122, v40                        ; cc21007a 04a2f420
	v_fma_mixhi_f16 v122, s32, v123, v41                        ; cc22007a 04a6f620
	v_fma_mixlo_f16 v123, s32, v124, v42                        ; cc21007b 04aaf820
	v_fma_mixhi_f16 v123, s32, v125, v43                        ; cc22007b 04aefa20
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v125, s32, v100, v66                        ; cc21007d 050ac820
	v_fma_mixhi_f16 v125, s32, v101, v67                        ; cc22007d 050eca20
	v_fma_mixlo_f16 v124, s32, v90, v64                         ; cc21007c 0502b420
	v_fma_mixhi_f16 v124, s32, v91, v65                         ; cc22007c 0506b620
	v_mov_b32_e32 v10, v26                                      ; 7e14031a
	v_dual_mov_b32 v22, v71 :: v_dual_mov_b32 v11, v70          ; ca100147 160a0146
	v_dual_mov_b32 v32, v89 :: v_dual_mov_b32 v23, v88          ; ca100159 20160158
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[40:43], v183, s[40:43], null offen offset:192 ; c405c07c 40805028 0000c0b7
	buffer_load_b128 v[44:47], v183, s[40:43], null offen offset:208 ; c405c07c 4080502c 0000d0b7
	buffer_load_b128 v[64:67], v183, s[40:43], null offen offset:4288 ; c405c07c 40805040 0010c0b7
	buffer_load_b128 v[26:29], v183, s[40:43], null offen offset:4304 ; c405c07c 4080501a 0010d0b7
	buffer_load_b128 v[68:71], v183, s[40:43], null offen offset:8384 ; c405c07c 40805044 0020c0b7
	buffer_load_b128 v[88:91], v183, s[40:43], null offen offset:8400 ; c405c07c 40805058 0020d0b7
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v33, s32, v72, v40                          ; cc210021 04a29020
(invalid instruction)                                        ; cc1c007a
	v_subrev_f32_e32 v0, v122, v34                              ; 0a00457a
	v_fma_mixhi_f16 v33, s32, v73, v41                          ; cc220021 04a69220
	v_fma_mixlo_f16 v40, s32, v74, v42                          ; cc210028 04aa9420
	v_fma_mixhi_f16 v40, s32, v75, v43                          ; cc220028 04ae9620
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mov_b32_e32 v100, v40                                     ; 7ec80328
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v183, s[40:43], null offen offset:12480 ; c405c07c 40805048 0030c0b7
	buffer_load_b128 v[40:43], v183, s[40:43], null offen offset:12496 ; c405c07c 40805028 0030d0b7
(invalid instruction)                                        ; cc1c007b
	v_subrev_f32_e32 v0, v123, v34                              ; 0a00457b
(invalid instruction)                                        ; cc1c007d
	v_subrev_f32_e32 v0, v125, v34                              ; 0a00457d
(invalid instruction)                                        ; cc1c007c
	v_subrev_f32_e32 v0, v124, v34                              ; 0a00457c
	s_mov_b32 s35, 0x7ff88000                                   ; bea300ff 7ff88000
(invalid instruction)                                        ; cc1b007a
	v_subrev_f32_e32 v0, v122, v33                              ; 0a00437a
(invalid instruction)                                        ; cc1c0021
	v_subrev_f32_e32 v0, v33, v34                               ; 0a004521
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v101, s32, v76, v44                         ; cc210065 04b29820
	v_fma_mixhi_f16 v101, s32, v77, v45                         ; cc220065 04b69a20
	v_fma_mixlo_f16 v183, s32, v78, v46                         ; cc2100b7 04ba9c20
(invalid instruction)                                        ; cc1c0064
	v_subrev_f32_e32 v0, v100, v34                              ; 0a004564
	v_fma_mixhi_f16 v183, s32, v79, v47                         ; cc2200b7 04be9e20
(invalid instruction)                                        ; cc1b007b
	v_subrev_f32_e32 v0, v123, v33                              ; 0a00437b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v24, v24, 5, s35                             ; d6460018 008d0b18
	v_lshl_add_u32 v85, v85, 5, s35                             ; d6460055 008d0b55
(invalid instruction)                                        ; cc1b007d
	v_subrev_f32_e32 v0, v125, v33                              ; 0a00437d
	v_lshl_add_u32 v82, v82, 5, s35                             ; d6460052 008d0b52
(invalid instruction)                                        ; cc1b007c
	v_subrev_f32_e32 v0, v124, v33                              ; 0a00437c
(invalid instruction)                                        ; cc1b0021
	v_subrev_f32_e32 v0, v33, v33                               ; 0a004321
	v_lshl_add_u32 v25, v25, 5, s35                             ; d6460019 008d0b19
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v34                              ; 0a004565
	v_lshl_add_u32 v135, v135, 5, s35                           ; d6460087 008d0b87
(invalid instruction)                                        ; cc1b0064
	v_subrev_f32_e32 v0, v100, v33                              ; 0a004364
	v_lshl_add_u32 v83, v83, 5, s35                             ; d6460053 008d0b53
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v34                              ; 0a0045b7
	v_lshl_add_u32 v10, v10, 5, s35                             ; d646000a 008d0b0a
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[24:25], v[85:86]                ; 1a02ab18
	v_lshl_add_u32 v144, v144, 5, s35                           ; d6460090 008d0b90
	v_lshl_add_u32 v148, v148, 5, s35                           ; d6460094 008d0b94
	v_lshl_add_u32 v33, v33, 5, s35                             ; d6460021 008d0b21
(invalid instruction)                                        ; cc1b0065
	v_subrev_f32_e32 v0, v101, v33                              ; 0a004365
	v_lshl_add_u32 v86, v86, 5, s35                             ; d6460056 008d0b56
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[25:26], v[135:136]              ; 1a030f19
	v_lshl_add_u32 v100, v100, 5, s35                           ; d6460064 008d0b64
	v_lshl_add_u32 v145, v145, 5, s35                           ; d6460091 008d0b91
(invalid instruction)                                        ; cc1b00b7
	v_subrev_f32_e32 v0, v183, v33                              ; 0a0043b7
	v_lshl_add_u32 v149, v149, 5, s35                           ; d6460095 008d0b95
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[44:45], v[82:83]                ; 1a02a52c
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[10:11], v[144:145]              ; 1a03210a
	v_lshl_add_u32 v101, v101, 5, s35                           ; d6460065 008d0b65
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[83:84]                ; 1a02a72d
(invalid instruction)                                        ; cc0f002f
	v_min_num_f64_e32 v[1:2], v[86:87], v[145:146]              ; 1a032356
	v_lshl_add_u32 v183, v183, 5, s35                           ; d64600b7 008d0bb7
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[44:45], v[33:34]                ; 1a02432c
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[148:149]              ; 1a03292e
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[100:101]              ; 1a02c92d
(invalid instruction)                                        ; cc0f002f
	v_min_num_f64_e32 v[1:2], v[47:48], v[149:150]              ; 1a032b2f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[101:102]              ; 1a02cb2e
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[44:45], v[45:46]                ; 1a025b2c
(invalid instruction)                                        ; cc0f002f
	v_min_num_f64_e32 v[1:2], v[47:48], v[183:184]              ; 1a036f2f
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[44:45], v[46:47]                ; 1a025d2c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[44:45], v[47:48]                ; 1a025f2c
	v_permlanex16_b32 v76, v44, s28, s30 op_sel:[1,1]           ; d65c184c 0078392c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[44:45], v[76:77]                ; 1a02992c
	v_add_f16_e32 v77, v44, v172/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 649b592c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v77, s27, v77                             ; 629a9a1b
	v_cvt_f32_f16_e32 v78, v77                                  ; 7e9c174d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v78, v78                                      ; 7e9c554e
	v_fma_mix_f32 v79, v24, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20004f 8a029d18
	v_fma_mix_f32 v47, v85, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20002f 8a029d55
	v_fma_mix_f32 v76, v135, v78, neg(0) op_sel_hi:[1,0,0]      ; cc20004c 8a029d87
	v_fma_mix_f32 v24, v24, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200818 8a029d18
	v_fma_mix_f32 v46, v86, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20002e 8a029d56
	v_fma_mix_f32 v86, v86, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200856 8a029d56
	v_fma_mix_f32 v85, v85, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200855 8a029d55
	v_fma_mix_f32 v135, v135, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200887 8a029d87
	v_fma_mix_f32 v77, v144, v78, neg(0) op_sel_hi:[1,0,0]      ; cc20004d 8a029d90
	v_fma_mix_f32 v144, v144, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200890 8a029d90
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v79, v24, vcc_lo                      ; 0202314f
	v_fma_mix_f32 v24, v25, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200018 8a029d19
	v_fma_mix_f32 v25, v25, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a029d19
	v_fma_mix_f32 v79, v145, v78, neg(0) op_sel_hi:[1,0,0]      ; cc20004f 8a029d91
	v_fma_mix_f32 v145, v145, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a029d91
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
	v_fma_mix_f32 v25, v10, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200019 8a029d0a
	v_fma_mix_f32 v10, v10, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080a 8a029d0a
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v47, v85, vcc_lo                      ; 0202ab2f
	v_fma_mix_f32 v85, v82, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200055 8a029d52
	v_fma_mix_f32 v82, v82, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200852 8a029d52
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v76, v135, vcc_lo                     ; 02030f4c
	v_fma_mix_f32 v135, v148, v78, neg(0) op_sel_hi:[1,0,0]     ; cc200087 8a029d94
	v_fma_mix_f32 v148, v148, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200894 8a029d94
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v25, v10, vcc_lo                      ; 02021519
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v46, v86, vcc_lo                      ; 0202ad2e
	v_fma_mix_f32 v86, v83, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200056 8a029d53
	v_fma_mix_f32 v83, v83, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200853 8a029d53
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v77, v144, vcc_lo                     ; 0203214d
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v79, v145, vcc_lo                     ; 0203234f
	v_fma_mix_f32 v144, v149, v78, neg(0) op_sel_hi:[1,0,0]     ; cc200090 8a029d95
	v_fma_mix_f32 v149, v149, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a029d95
	v_fma_mix_f32 v145, v33, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200091 8a029d21
	v_fma_mix_f32 v33, v33, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200821 8a029d21
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v85, v82, vcc_lo                      ; 0202a555
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v135, v148, vcc_lo                    ; 02032987
	v_fma_mix_f32 v148, v100, v78, neg(0) op_sel_hi:[1,0,0]     ; cc200094 8a029d64
	v_fma_mix_f32 v100, v100, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200864 8a029d64
	v_fma_mix_f32 v10, v183, v78, neg(0) op_sel_hi:[1,0,0]      ; cc20000a 8a029db7
	v_fma_mix_f32 v183, v183, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a029db7
	v_lshl_add_u32 v87, v87, 5, s35                             ; d6460057 008d0b57
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v86, v83, vcc_lo                      ; 0202a756
	v_lshl_add_u32 v146, v146, 5, s35                           ; d6460092 008d0b92
	v_lshl_add_u32 v150, v150, 5, s35                           ; d6460096 008d0b96
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v144, v149, vcc_lo                    ; 02032b90
	v_fma_mix_f32 v149, v101, v78, neg(0) op_sel_hi:[1,0,0]     ; cc200095 8a029d65
	v_fma_mix_f32 v101, v101, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200865 8a029d65
	v_lshl_add_u32 v110, v110, 5, s35                           ; d646006e 008d0b6e
	v_lshl_add_u32 v147, v147, 5, s35                           ; d6460093 008d0b93
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v145, v33, vcc_lo                     ; 02024391
	v_lshl_add_u32 v151, v151, 5, s35                           ; d6460097 008d0b97
	v_lshl_add_u32 v111, v111, 5, s35                           ; d646006f 008d0b6f
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v148, v100, vcc_lo                    ; 0202c994
	v_lshl_add_u32 v176, v176, 5, s35                           ; d64600b0 008d0bb0
	v_lshl_add_u32 v152, v152, 5, s35                           ; d6460098 008d0b98
	v_lshl_add_u32 v112, v112, 5, s35                           ; d6460070 008d0b70
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[87:88], v[146:147]              ; 1a032557
	v_lshl_add_u32 v177, v177, 5, s35                           ; d64600b1 008d0bb1
	v_lshl_add_u32 v153, v153, 5, s35                           ; d6460099 008d0b99
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v149, v101, vcc_lo                    ; 0202cb95
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v10, v183, vcc_lo                     ; 02036f0a
	v_lshl_add_u32 v113, v113, 5, s35                           ; d6460071 008d0b71
	v_lshl_add_u32 v178, v178, 5, s35                           ; d64600b2 008d0bb2
(invalid instruction)                                        ; cc0f004e
	v_min_num_f64_e32 v[1:2], v[110:111], v[147:148]            ; 1a03276e
	v_lshl_add_u32 v154, v154, 5, s35                           ; d646009a 008d0b9a
	v_lshl_add_u32 v114, v114, 5, s35                           ; d6460072 008d0b72
(invalid instruction)                                        ; cc0f004f
	v_min_num_f64_e32 v[1:2], v[111:112], v[176:177]            ; 1a03616f
	v_lshl_add_u32 v179, v179, 5, s35                           ; d64600b3 008d0bb3
	v_lshl_add_u32 v155, v155, 5, s35                           ; d646009b 008d0b9b
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[150:151]              ; 1a032d21
	v_lshl_add_u32 v115, v115, 5, s35                           ; d6460073 008d0b73
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[112:113], v[177:178]            ; 1a036370
	v_lshl_add_u32 v56, v56, 5, s35                             ; d6460038 008d0b38
	v_lshl_add_u32 v180, v180, 5, s35                           ; d64600b4 008d0bb4
	v_lshl_add_u32 v116, v116, 5, s35                           ; d6460074 008d0b74
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[113:114], v[178:179]            ; 1a036571
	v_lshl_add_u32 v57, v57, 5, s35                             ; d6460039 008d0b39
(invalid instruction)                                        ; cc0f004e
	v_min_num_f64_e32 v[1:2], v[78:79], v[151:152]              ; 1a032f4e
	v_lshl_add_u32 v22, v22, 5, s35                             ; d6460016 008d0b16
(invalid instruction)                                        ; cc0f004f
	v_min_num_f64_e32 v[1:2], v[79:80], v[152:153]              ; 1a03314f
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[114:115], v[179:180]            ; 1a036772
	v_lshl_add_u32 v117, v117, 5, s35                           ; d6460075 008d0b75
	v_lshl_add_u32 v58, v58, 5, s35                             ; d646003a 008d0b3a
	v_lshl_add_u32 v122, v122, 5, s35                           ; d646007a 008d0b7a
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[82:83], v[153:154]              ; 1a033352
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[115:116], v[56:57]              ; 1a027173
	v_lshl_add_u32 v118, v118, 5, s35                           ; d6460076 008d0b76
	v_lshl_add_u32 v59, v59, 5, s35                             ; d646003b 008d0b3b
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[154:155]              ; 1a033553
	v_lshl_add_u32 v123, v123, 5, s35                           ; d646007b 008d0b7b
(invalid instruction)                                        ; cc0f0064
	v_min_num_f64_e32 v[1:2], v[116:117], v[57:58]              ; 1a027374
	v_lshl_add_u32 v119, v119, 5, s35                           ; d6460077 008d0b77
	v_lshl_add_u32 v80, v80, 5, s35                             ; d6460050 008d0b50
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v144, s32, v92, v64                         ; cc210090 0502b820
	v_fma_mixhi_f16 v144, s32, v93, v65                         ; cc220090 0506ba20
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[155:156]              ; 1a033755
(invalid instruction)                                        ; cc0f0065
	v_min_num_f64_e32 v[1:2], v[117:118], v[58:59]              ; 1a027575
	v_fma_mixlo_f16 v145, s32, v94, v66                         ; cc210091 050abc20
	v_fma_mixhi_f16 v145, s32, v95, v67                         ; cc220091 050ebe20
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[86:87], v[180:181]              ; 1a036956
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v148, s32, v96, v26                         ; cc210094 046ac020
(invalid instruction)                                        ; cc0f0087
	v_min_num_f64_e32 v[1:2], v[118:119], v[59:60]              ; 1a027776
	v_fma_mixhi_f16 v148, s32, v97, v27                         ; cc220094 046ec220
(invalid instruction)                                        ; cc0f0064
	v_min_num_f64_e32 v[1:2], v[100:101], v[22:23]              ; 1a022d64
	v_fma_mixlo_f16 v149, s32, v98, v28                         ; cc210095 0472c420
	v_fma_mixhi_f16 v149, s32, v99, v29                         ; cc220095 0476c620
(invalid instruction)                                        ; cc1c0090
	v_subrev_f32_e32 v0, v144, v34                              ; 0a004590
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v183, s32, v0, v68                          ; cc2100b7 05120020
(invalid instruction)                                        ; cc0f0065
	v_min_num_f64_e32 v[1:2], v[101:102], v[122:123]            ; 1a02f565
	v_fma_mixhi_f16 v183, s32, v1, v69                          ; cc2200b7 05160220
(invalid instruction)                                        ; cc1c0091
	v_subrev_f32_e32 v0, v145, v34                              ; 0a004591
	v_fma_mixlo_f16 v0, s32, v2, v70                            ; cc210000 051a0420
	v_fma_mixhi_f16 v0, s32, v3, v71                            ; cc220000 051e0620
(invalid instruction)                                        ; cc0f0087
	v_min_num_f64_e32 v[1:2], v[135:136], v[123:124]            ; 1a02f787
(invalid instruction)                                        ; cc1c0094
	v_subrev_f32_e32 v0, v148, v34                              ; 0a004594
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v1, s32, v4, v88                            ; cc210001 05620820
	v_fma_mixhi_f16 v1, s32, v5, v89                            ; cc220001 05660a20
(invalid instruction)                                        ; cc1c0095
	v_subrev_f32_e32 v0, v149, v34                              ; 0a004595
(invalid instruction)                                        ; cc1b0090
	v_subrev_f32_e32 v0, v144, v33                              ; 0a004390
	v_fma_mixlo_f16 v2, s32, v6, v90                            ; cc210002 056a0c20
	v_fma_mixhi_f16 v2, s32, v7, v91                            ; cc220002 056e0e20
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v34                              ; 0a0045b7
(invalid instruction)                                        ; cc1b0091
	v_subrev_f32_e32 v0, v145, v33                              ; 0a004391
(invalid instruction)                                        ; cc1c0000
	v_subrev_f32_e32 v0, v0, v34                                ; 0a004500
(invalid instruction)                                        ; cc1b0094
	v_subrev_f32_e32 v0, v148, v33                              ; 0a004394
(invalid instruction)                                        ; cc1c0001
	v_subrev_f32_e32 v0, v1, v34                                ; 0a004501
(invalid instruction)                                        ; cc1b0095
	v_subrev_f32_e32 v0, v149, v33                              ; 0a004395
(invalid instruction)                                        ; cc1c0002
	v_subrev_f32_e32 v0, v2, v34                                ; 0a004502
(invalid instruction)                                        ; cc1b00b7
	v_subrev_f32_e32 v0, v183, v33                              ; 0a0043b7
(invalid instruction)                                        ; cc1b0000
	v_subrev_f32_e32 v0, v0, v33                                ; 0a004300
(invalid instruction)                                        ; cc1b0001
	v_subrev_f32_e32 v0, v1, v33                                ; 0a004301
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b0002
	v_subrev_f32_e32 v0, v2, v33                                ; 0a004302
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v3, s32, v126, v72                          ; cc210003 0522fc20
	v_fma_mixhi_f16 v3, s32, v127, v73                          ; cc220003 0526fe20
	v_fma_mixlo_f16 v4, s32, v128, v74                          ; cc210004 052b0020
	v_fma_mixhi_f16 v4, s32, v129, v75                          ; cc220004 052f0220
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v5, s32, v130, v40                          ; cc210005 04a30420
	v_fma_mixhi_f16 v5, s32, v131, v41                          ; cc220005 04a70620
	v_lshl_add_u32 v144, v144, 5, s35                           ; d6460090 008d0b90
	v_fma_mixlo_f16 v6, s32, v132, v42                          ; cc210006 04ab0820
	v_fma_mixhi_f16 v6, s32, v133, v43                          ; cc220006 04af0a20
	v_lshl_add_u32 v145, v145, 5, s35                           ; d6460091 008d0b91
	v_lshl_add_u32 v148, v148, 5, s35                           ; d6460094 008d0b94
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v34                                ; 0a004503
	v_lshl_add_u32 v149, v149, 5, s35                           ; d6460095 008d0b95
(invalid instruction)                                        ; cc1c0004
	v_subrev_f32_e32 v0, v4, v34                                ; 0a004504
(invalid instruction)                                        ; cc1c0005
	v_subrev_f32_e32 v0, v5, v34                                ; 0a004505
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[144:145]              ; 1a032121
(invalid instruction)                                        ; cc1c0006
	v_subrev_f32_e32 v0, v6, v34                                ; 0a004506
(invalid instruction)                                        ; cc0f004e
	v_min_num_f64_e32 v[1:2], v[78:79], v[145:146]              ; 1a03234e
(invalid instruction)                                        ; cc0f004f
	v_min_num_f64_e32 v[1:2], v[79:80], v[148:149]              ; 1a03294f
(invalid instruction)                                        ; cc1b0003
	v_subrev_f32_e32 v0, v3, v33                                ; 0a004303
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[82:83], v[149:150]              ; 1a032b52
(invalid instruction)                                        ; cc1b0004
	v_subrev_f32_e32 v0, v4, v33                                ; 0a004304
(invalid instruction)                                        ; cc1b0005
	v_subrev_f32_e32 v0, v5, v33                                ; 0a004305
(invalid instruction)                                        ; cc1b0006
	v_subrev_f32_e32 v0, v6, v33                                ; 0a004306
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[78:79]                ; 1a029d21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[79:80]                ; 1a029f21
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[82:83]                ; 1a02a521
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v7, v33, s28, s30 op_sel:[1,1]            ; d65c1807 00783921
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[7:8]                  ; 1a020f21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v10, v33, v161/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64154321
	v_max_num_f16_e32 v10, s27, v10                             ; 6214141b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v26, v10                                  ; 7e34170a
	v_rcp_f32_e32 v26, v26                                      ; 7e34551a
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v33, v111, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200021 8a02356f
	v_fma_mix_f32 v41, v146, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200029 8a023592
	v_fma_mix_f32 v27, v87, v26, neg(0) op_sel_hi:[1,0,0]       ; cc20001b 8a023557
	v_fma_mix_f32 v87, v87, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200857 8a023557
	v_fma_mix_f32 v146, v146, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200892 8a023592
	v_fma_mix_f32 v42, v147, v26, neg(0) op_sel_hi:[1,0,0]      ; cc20002a 8a023593
	v_fma_mix_f32 v111, v111, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086f 8a02356f
	v_fma_mix_f32 v40, v112, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200028 8a023570
	v_fma_mix_f32 v112, v112, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200870 8a023570
	v_fma_mix_f32 v29, v110, v26, neg(0) op_sel_hi:[1,0,0]      ; cc20001d 8a02356e
	v_fma_mix_f32 v110, v110, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086e 8a02356e
	v_fma_mix_f32 v147, v147, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200893 8a023593
	v_fma_mix_f32 v43, v176, v26, neg(0) op_sel_hi:[1,0,0]      ; cc20002b 8a0235b0
	v_fma_mix_f32 v176, v176, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a0235b0
	v_fma_mix_f32 v64, v177, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200040 8a0235b1
	v_fma_mix_f32 v177, v177, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a0235b1
	v_fma_mix_f32 v65, v150, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200041 8a023596
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v27, v87, vcc_lo                      ; 0202af1b
	v_fma_mix_f32 v150, v150, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200896 8a023596
	v_fma_mix_f32 v66, v151, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200042 8a023597
	v_fma_mix_f32 v151, v151, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a023597
	v_fma_mix_f32 v67, v152, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200043 8a023598
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v29, v110, vcc_lo                     ; 0202dd1d
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v33, v111, vcc_lo                     ; 0202df21
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v40, v112, vcc_lo                     ; 0202e128
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v41, v146, vcc_lo                     ; 02032529
	v_fma_mix_f32 v152, v152, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200898 8a023598
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v42, v147, vcc_lo                     ; 0203272a
	v_fma_mix_f32 v68, v153, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200044 8a023599
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v43, v176, vcc_lo                     ; 0203612b
	v_fma_mix_f32 v153, v153, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a023599
	v_fma_mix_f32 v69, v144, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200045 8a023590
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v64, v177, vcc_lo                     ; 02036340
	v_fma_mix_f32 v144, v144, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200890 8a023590
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v65, v150, vcc_lo                     ; 02032d41
	v_fma_mix_f32 v70, v145, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200046 8a023591
	v_fma_mix_f32 v145, v145, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a023591
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v66, v151, vcc_lo                     ; 02032f42
	v_fma_mix_f32 v71, v148, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200047 8a023594
	v_fma_mix_f32 v148, v148, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200894 8a023594
	v_fma_mix_f32 v72, v149, v26, neg(0) op_sel_hi:[1,0,0]      ; cc200048 8a023595
	v_fma_mix_f32 v149, v149, v26, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a023595
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v67, v152, vcc_lo                     ; 02033143
	v_lshl_add_u32 v183, v183, 5, s35                           ; d64600b7 008d0bb7
	v_lshl_add_u32 v0, v0, 5, s35                               ; d6460000 008d0b00
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v68, v153, vcc_lo                     ; 02033344
	v_lshl_add_u32 v1, v1, 5, s35                               ; d6460001 008d0b01
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v69, v144, vcc_lo                     ; 02032145
	v_lshl_add_u32 v2, v2, 5, s35                               ; d6460002 008d0b02
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v70, v145, vcc_lo                     ; 02032346
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v71, v148, vcc_lo                     ; 02032947
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v72, v149, vcc_lo                     ; 02032b48
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[183:184]              ; 1a036f53
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[0:1]                  ; 1a020155
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[86:87], v[1:2]                  ; 1a020356
(invalid instruction)                                        ; cc0f0064
	v_min_num_f64_e32 v[1:2], v[100:101], v[2:3]                ; 1a020564
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[85:86]                ; 1a02ab53
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[86:87]                ; 1a02ad53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[100:101]              ; 1a02c953
	v_permlanex16_b32 v73, v83, s28, s30 op_sel:[1,1]           ; d65c1849 00783953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[73:74]                ; 1a029353
	v_add_f16_e32 v74, v83, v211/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 6495a753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v74, s27, v74                             ; 6294941b
	v_cvt_f32_f16_e32 v75, v74                                  ; 7e96174a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v75, v75                                      ; 7e96554b
	v_fma_mix_f32 v85, v178, v75, neg(0) op_sel_hi:[1,0,0]      ; cc200055 8a0297b2
	v_fma_mix_f32 v83, v116, v75, neg(0) op_sel_hi:[1,0,0]      ; cc200053 8a029774
	v_fma_mix_f32 v82, v115, v75, neg(0) op_sel_hi:[1,0,0]      ; cc200052 8a029773
	v_add_lshl_u32 v181, s9, v181, 2                            ; d64700b5 020b6a09
	buffer_load_b128 v[68:71], v181, s[40:43], null offen       ; c405c07c 40805044 000000b5
	v_fma_mix_f32 v115, v115, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200873 8a029773
	v_fma_mix_f32 v79, v114, v75, neg(0) op_sel_hi:[1,0,0]      ; cc20004f 8a029772
	v_fma_mix_f32 v86, v179, v75, neg(0) op_sel_hi:[1,0,0]      ; cc200056 8a0297b3
	v_fma_mix_f32 v116, v116, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200874 8a029774
	buffer_load_b128 v[88:91], v181, s[40:43], null offen offset:16 ; c405c07c 40805058 000010b5
	v_fma_mix_f32 v178, v178, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a0297b2
	v_fma_mix_f32 v78, v113, v75, neg(0) op_sel_hi:[1,0,0]      ; cc20004e 8a029771
	v_fma_mix_f32 v113, v113, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200871 8a029771
	v_fma_mix_f32 v114, v114, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200872 8a029772
	v_fma_mix_f32 v179, v179, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a0297b3
	v_fma_mix_f32 v87, v56, v75, neg(0) op_sel_hi:[1,0,0]       ; cc200057 8a029738
	v_fma_mix_f32 v56, v56, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200838 8a029738
	v_fma_mix_f32 v92, v57, v75, neg(0) op_sel_hi:[1,0,0]       ; cc20005c 8a029739
	v_fma_mix_f32 v57, v57, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200839 8a029739
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v82, v115, vcc_lo                     ; 0202e752
	v_fma_mix_f32 v93, v154, v75, neg(0) op_sel_hi:[1,0,0]      ; cc20005d 8a02979a
	v_fma_mix_f32 v154, v154, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089a 8a02979a
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v83, v116, vcc_lo                     ; 0202e953
	v_fma_mix_f32 v94, v155, v75, neg(0) op_sel_hi:[1,0,0]      ; cc20005e 8a02979b
	v_fma_mix_f32 v155, v155, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089b 8a02979b
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v85, v178, vcc_lo                     ; 02036555
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v78, v113, vcc_lo                     ; 0202e34e
	v_fma_mix_f32 v95, v180, v75, neg(0) op_sel_hi:[1,0,0]      ; cc20005f 8a0297b4
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v79, v114, vcc_lo                     ; 0202e54f
	v_fma_mix_f32 v180, v180, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a0297b4
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v86, v179, vcc_lo                     ; 02036756
	v_fma_mix_f32 v96, v22, v75, neg(0) op_sel_hi:[1,0,0]       ; cc200060 8a029716
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v87, v56, vcc_lo                      ; 02027157
	v_fma_mix_f32 v22, v22, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a029716
	v_fma_mix_f32 v97, v183, v75, neg(0) op_sel_hi:[1,0,0]      ; cc200061 8a0297b7
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v92, v57, vcc_lo                      ; 0202735c
	v_fma_mix_f32 v183, v183, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a0297b7
	v_fma_mix_f32 v98, v0, v75, neg(0) op_sel_hi:[1,0,0]        ; cc200062 8a029700
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v93, v154, vcc_lo                     ; 0203355d
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v94, v155, vcc_lo                     ; 0203375e
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v95, v180, vcc_lo                     ; 0203695f
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v134, s6, v134, 2                            ; d6470086 020b0c06
	buffer_load_b128 v[92:95], v134, s[36:39], null offen       ; c405c07c 4080485c 00000086
	v_fma_mix_f32 v0, v0, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200800 8a029700
	v_fma_mix_f32 v99, v1, v75, neg(0) op_sel_hi:[1,0,0]        ; cc200063 8a029701
	v_fma_mix_f32 v1, v1, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200801 8a029701
	v_fma_mix_f32 v100, v2, v75, neg(0) op_sel_hi:[1,0,0]       ; cc200064 8a029702
	v_fma_mix_f32 v2, v2, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200802 8a029702
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v96, v22, vcc_lo                      ; 02022d60
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v97, v183, vcc_lo                     ; 02036f61
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v98, v0, vcc_lo                       ; 02020162
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v99, v1, vcc_lo                       ; 02020363
	buffer_load_b128 v[96:99], v134, s[36:39], null offen offset:512 ; c405c07c 40804860 00020086
	v_lshl_add_u32 v3, v3, 5, s35                               ; d6460003 008d0b03
	v_lshl_add_u32 v4, v4, 5, s35                               ; d6460004 008d0b04
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[119:120], v[80:81]              ; 1a02a177
	v_lshl_add_u32 v124, v124, 5, s35                           ; d646007c 008d0b7c
	v_lshl_add_u32 v5, v5, 5, s35                               ; d6460005 008d0b05
	v_lshl_add_u32 v60, v60, 5, s35                             ; d646003c 008d0b3c
	v_lshl_add_u32 v81, v81, 5, s35                             ; d6460051 008d0b51
	v_lshl_add_u32 v125, v125, 5, s35                           ; d646007d 008d0b7d
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v100, v2, vcc_lo                      ; 02020564
	v_lshl_add_u32 v6, v6, 5, s35                               ; d6460006 008d0b06
(invalid instruction)                                        ; cc0f0065
	v_min_num_f64_e32 v[1:2], v[101:102], v[3:4]                ; 1a020765
(invalid instruction)                                        ; cc0f0087
	v_min_num_f64_e32 v[1:2], v[135:136], v[4:5]                ; 1a020987
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[124:125]            ; 1a02f96e
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[60:61], v[81:82]                ; 1a02a33c
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
(invalid instruction)                                        ; cc0f0065
	v_min_num_f64_e32 v[1:2], v[101:102], v[135:136]            ; 1a030f65
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[5:6]                ; 1a020b6e
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[125:126]            ; 1a02fb6f
(invalid instruction)                                        ; cc0f0065
	v_min_num_f64_e32 v[1:2], v[101:102], v[110:111]            ; 1a02dd65
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[6:7]                ; 1a020d6f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0065
	v_min_num_f64_e32 v[1:2], v[101:102], v[111:112]            ; 1a02df65
	v_permlanex16_b32 v112, v101, s28, s30 op_sel:[1,1]         ; d65c1870 00783965
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0065
	v_min_num_f64_e32 v[1:2], v[101:102], v[112:113]            ; 1a02e165
	v_add_f16_e32 v113, v101, v229/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64e3cb65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v113, s27, v113                           ; 62e2e21b
	v_cvt_f32_f16_e32 v114, v113                                ; 7ee41771
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v114, v114                                    ; 7ee45572
	v_fma_mix_f32 v116, v118, v114, neg(0) op_sel_hi:[1,0,0]    ; cc200074 8a02e576
	v_fma_mix_f32 v115, v117, v114, neg(0) op_sel_hi:[1,0,0]    ; cc200073 8a02e575
	v_fma_mix_f32 v126, v59, v114, neg(0) op_sel_hi:[1,0,0]     ; cc20007e 8a02e53b
	v_fma_mix_f32 v117, v117, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200875 8a02e575
	v_fma_mix_f32 v118, v118, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200876 8a02e576
	v_fma_mix_f32 v59, v59, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083b 8a02e53b
	v_fma_mix_f32 v127, v80, v114, neg(0) op_sel_hi:[1,0,0]     ; cc20007f 8a02e550
	v_fma_mix_f32 v80, v80, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200850 8a02e550
	v_fma_mix_f32 v128, v81, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200080 8a02e551
	v_fma_mix_f32 v81, v81, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200851 8a02e551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v127, v80, vcc_lo                     ; 0202a17f
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v128, v81, vcc_lo                     ; 0202a380
	buffer_load_b128 v[80:83], v181, s[40:43], null offen offset:64 ; c405c07c 40805050 000040b5
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                    ; 0202eb73
	v_fma_mix_f32 v117, v119, v114, neg(0) op_sel_hi:[1,0,0]    ; cc200075 8a02e577
	v_fma_mix_f32 v119, v119, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a02e577
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v116, v118, vcc_lo                    ; 0202ed74
	v_fma_mix_f32 v118, v60, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200076 8a02e53c
	v_fma_mix_f32 v60, v60, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083c 8a02e53c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v117, v119, vcc_lo                    ; 0202ef75
	v_fma_mix_f32 v119, v58, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200077 8a02e53a
	v_fma_mix_f32 v58, v58, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083a 8a02e53a
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v118, v60, vcc_lo                     ; 02027976
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v119, v58, vcc_lo                     ; 02027577
	buffer_load_b128 v[116:119], v181, s[40:43], null offen offset:80 ; c405c07c 40805074 000050b5
	v_fma_mix_f32 v129, v122, v114, neg(0) op_sel_hi:[1,0,0]    ; cc200081 8a02e57a
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v126, v59, vcc_lo                     ; 0202777e
	v_fma_mix_f32 v122, v122, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087a 8a02e57a
	v_fma_mix_f32 v130, v123, v114, neg(0) op_sel_hi:[1,0,0]    ; cc200082 8a02e57b
	v_fma_mix_f32 v123, v123, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087b 8a02e57b
	v_mov_b32_e32 v152, v182                                    ; 7f3003b6
	v_fma_mix_f32 v133, v3, v114, neg(0) op_sel_hi:[1,0,0]      ; cc200085 8a02e503
	v_fma_mix_f32 v3, v3, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200803 8a02e503
	v_fma_mix_f32 v134, v4, v114, neg(0) op_sel_hi:[1,0,0]      ; cc200086 8a02e504
	v_fma_mix_f32 v4, v4, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200804 8a02e504
	v_fma_mix_f32 v135, v5, v114, neg(0) op_sel_hi:[1,0,0]      ; cc200087 8a02e505
	v_fma_mix_f32 v5, v5, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200805 8a02e505
	v_fma_mix_f32 v131, v124, v114, neg(0) op_sel_hi:[1,0,0]    ; cc200083 8a02e57c
	v_fma_mix_f32 v124, v124, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087c 8a02e57c
	v_fma_mix_f32 v132, v125, v114, neg(0) op_sel_hi:[1,0,0]    ; cc200084 8a02e57d
	v_fma_mix_f32 v125, v125, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087d 8a02e57d
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v129, v122, vcc_lo                    ; 0202f581
	v_fma_mix_f32 v144, v6, v114, neg(0) op_sel_hi:[1,0,0]      ; cc200090 8a02e506
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v130, v123, vcc_lo                    ; 0202f782
	v_fma_mix_f32 v6, v6, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200806 8a02e506
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v133, v3, vcc_lo                      ; 02020785
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[18:19], v[26:27], 0 ; cc4640b0 1a023512
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v134, v4, vcc_lo                      ; 02020986
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v135, v5, vcc_lo                      ; 02020b87
	v_dual_mov_b32 v4, v108 :: v_dual_mov_b32 v5, v109          ; ca10016c 0404016d
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[18:19], v[0:1], 0 ; cc46406c 1a020112
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v131, v124, vcc_lo                    ; 0202f983
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v132, v125, vcc_lo                    ; 0202fb84
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[44:45], 0 ; cc464080 1a025912
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v144, v6, vcc_lo                      ; 02020d90
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[18:19], v[28:29], 0 ; cc464090 1a023912
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[66:67], v[176:183] ; cc4640b0 1ec2851e
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[30:31], v[74:75], v[108:115] ; cc46406c 1db2951e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[24:25], v[128:135] ; cc464080 1e02311e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[30:31], v[40:41], v[144:151] ; cc464090 1e42511e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[34:35], v[56:57], v[176:183] ; cc4640b0 1ec27122
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[34:35], v[58:59], v[108:115] ; cc46406c 1db27522
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[46:47], v[128:135] ; cc464080 1e025d22
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[34:35], v[42:43], v[144:151] ; cc464090 1e425522
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[20:21], v[72:73], v[176:183] ; cc4640b0 1ec29114
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[20:21], v[2:3], v[108:115] ; cc46406c 1db20514
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[20:21], v[76:77], v[128:135] ; cc464080 1e029914
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[20:21], v[64:65], v[144:151] ; cc464090 1e428114
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[8:9], v[44:45], 0 ; cc464080 1a025908
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mul_f32 v45, v141, v89 :: v_dual_mul_f32 v44, v140, v88 ; c8c6b38d 2d2cb18c
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[8:9], v[28:29], 0 ; cc464090 1a023908
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[8:9], v[26:27], 0 ; cc4640b0 1a023508
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[8:9], v[0:1], 0   ; cc46406c 1a020108
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[12:13], v[24:25], v[128:135] ; cc464080 1e02310c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[12:13], v[40:41], v[144:151] ; cc464090 1e42510c
	v_dual_mul_f32 v40, v136, v68 :: v_dual_mul_f32 v41, v137, v69 ; c8c68988 28288b89
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[66:67], v[176:183] ; cc4640b0 1ec2850c
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[12:13], v[74:75], v[108:115] ; cc46406c 1db2950c
	v_dual_mul_f32 v75, v84, v71 :: v_dual_mul_f32 v74, v63, v70 ; c8c68f54 4b4a8d3f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[16:17], v[46:47], v[128:135] ; cc464080 1e025d10
	v_dual_mul_f32 v47, v143, v91 :: v_dual_mul_f32 v46, v142, v90 ; c8c6b78f 2f2eb58e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[16:17], v[42:43], v[144:151] ; cc464090 1e425510
	v_dual_mul_f32 v43, v139, v71 :: v_dual_mul_f32 v42, v138, v70 ; c8c68f8b 2b2a8d8a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[56:57], v[176:183] ; cc4640b0 1ec27110
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[16:17], v[58:59], v[108:115] ; cc46406c 1db27510
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[76:77], v[128:135] ; cc464080 1e02990e
	v_dual_mul_f32 v77, v157, v89 :: v_dual_mul_f32 v76, v156, v88 ; c8c6b39d 4d4cb19c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[14:15], v[64:65], v[144:151] ; cc464090 1e42810e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[14:15], v[72:73], v[176:183] ; cc4640b0 1ec2910e
	v_dual_mul_f32 v73, v62, v69 :: v_dual_mul_f32 v72, v61, v68 ; c8c68b3e 4948893d
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[14:15], v[2:3], v[108:115] ; cc46406c 1db2050e
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_dual_mul_f32 v79, v159, v91 :: v_dual_mul_f32 v78, v158, v90 ; c8c6b79f 4f4eb59e
	v_dual_mul_f32 v57, v161, v69 :: v_dual_mul_f32 v56, v160, v68 ; c8c68ba1 393889a0
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_dual_mul_f32 v59, v163, v71 :: v_dual_mul_f32 v58, v162, v70 ; c8c68fa3 3b3a8da2
	v_dual_mul_f32 v61, v165, v89 :: v_dual_mul_f32 v60, v164, v88 ; c8c6b3a5 3d3cb1a4
	v_dual_mul_f32 v63, v167, v91 :: v_dual_mul_f32 v62, v166, v90 ; c8c6b7a7 3f3eb5a6
	v_dual_mul_f32 v129, v169, v69 :: v_dual_mul_f32 v128, v168, v68 ; c8c68ba9 818089a8
	v_dual_mul_f32 v131, v171, v71 :: v_dual_mul_f32 v130, v170, v70 ; c8c68fab 83828daa
	v_dual_mul_f32 v133, v173, v89 :: v_dual_mul_f32 v132, v172, v88 ; c8c6b3ad 8584b1ac
	v_dual_mul_f32 v135, v175, v91 :: v_dual_mul_f32 v134, v174, v90 ; c8c6b7af 8786b5ae
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[92:93], v[6:7], v[40:47] ; cc464028 1ca20d5c
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[92:93], v[18:19], v[72:79] ; cc464048 1d22255c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[30:31], v[128:135] ; cc464080 1e023d5c
	s_add_co_u32 s22, s2, s22                                   ; 80161602
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[92:93], v[20:21], v[56:63] ; cc464038 1ce2295c
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[96:97], v[0:1], v[40:47] ; cc464028 1ca20160
	s_add_co_u32 s14, s2, s14                                   ; 800e0e02
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v10, v152, s22, v11                              ; d655000a 042c2d98
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[96:97], v[2:3], v[72:79] ; cc464048 1d220560
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[96:97], v[12:13], v[128:135] ; cc464080 1e021960
	v_add3_u32 v22, v152, s14, v11                              ; d6550016 042c1d98
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[96:97], v[8:9], v[56:63] ; cc464038 1ce21160
	s_add_co_u32 s13, s2, s13                                   ; 800d0d02
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_add3_u32 v26, v152, s13, v11                              ; d655001a 042c1b98
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_add_co_u32 s2, s2, s29                                    ; 80021d02
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v27, v152, s2, v11                               ; d655001b 042c0598
	s_clause 0x3                                                ; bf850003
	buffer_store_b64 v[14:15], v10, s[16:19], null offen        ; c406c07c 4080200e 0000000a
	buffer_store_b64 v[16:17], v22, s[16:19], null offen        ; c406c07c 40802010 00000016
	buffer_store_b64 v[24:25], v26, s[16:19], null offen        ; c406c07c 40802018 0000001a
	buffer_store_b64 v[28:29], v27, s[16:19], null offen        ; c406c07c 4080201c 0000001b
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_mul_f32_e32 v40, v184, v80                                ; 1050a1b8
	v_dual_mul_f32 v42, v186, v82 :: v_dual_mul_f32 v41, v185, v81 ; c8c6a5ba 2a28a3b9
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mul_f32 v44, v188, v116 :: v_dual_mul_f32 v43, v187, v83 ; c8c6e9bc 2c2aa7bb
	v_dual_mul_f32 v46, v190, v118 :: v_dual_mul_f32 v45, v189, v117 ; c8c6edbe 2e2cebbd
	v_dual_mul_f32 v56, v48, v80 :: v_dual_mul_f32 v47, v191, v119 ; c8c6a130 382eefbf
	v_dual_mul_f32 v58, v50, v82 :: v_dual_mul_f32 v57, v49, v81 ; c8c6a532 3a38a331
	v_dual_mul_f32 v60, v52, v116 :: v_dual_mul_f32 v59, v51, v83 ; c8c6e934 3c3aa733
	v_dual_mul_f32 v62, v54, v118 :: v_dual_mul_f32 v61, v53, v117 ; c8c6ed36 3e3ceb35
	v_dual_mul_f32 v48, v102, v80 :: v_dual_mul_f32 v63, v55, v119 ; c8c6a166 303eef37
	v_dual_mul_f32 v50, v104, v82 :: v_dual_mul_f32 v49, v103, v81 ; c8c6a568 3230a367
	v_dual_mul_f32 v52, v106, v116 :: v_dual_mul_f32 v51, v105, v83 ; c8c6e96a 3432a769
	v_dual_mul_f32 v54, v4, v118 :: v_dual_mul_f32 v53, v107, v117 ; c8c6ed04 3634eb6b
	v_dual_mul_f32 v65, v121, v81 :: v_dual_mul_f32 v64, v120, v80 ; c8c6a379 4140a178
	v_dual_mul_f32 v67, v37, v83 :: v_dual_mul_f32 v66, v36, v82 ; c8c6a725 4342a524
	v_dual_mul_f32 v71, v32, v119 :: v_dual_mul_f32 v68, v38, v116 ; c8c6ef20 4744e926
	v_add3_u32 v28, v11, s22, s24                               ; d655001c 00602d0b
	v_add3_u32 v29, v11, s14, s24                               ; d655001d 00601d0b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[94:95], v[6:7], v[40:47] ; cc464028 1ca20d5e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[94:95], v[18:19], v[56:63] ; cc464038 1ce2255e
	v_dual_mul_f32 v69, v39, v117 :: v_dual_add_nc_u32 v28, v28, v152 ; c8e0eb27 451d311c
	v_dual_mul_f32 v70, v23, v118 :: v_dual_add_nc_u32 v29, v29, v152 ; c8e0ed17 461d311d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[94:95], v[30:31], v[64:71] ; cc464040 1d023d5e
	v_add3_u32 v30, v11, s13, s24                               ; d655001e 00601b0b
	v_add3_u32 v11, v11, s2, s24                                ; d655000b 0060050b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[98:99], v[0:1], v[40:47] ; cc464028 1ca20162
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[98:99], v[2:3], v[56:63] ; cc464038 1ce20562
	v_dual_mul_f32 v55, v5, v119 :: v_dual_add_nc_u32 v30, v30, v152 ; c8e0ef05 371f311e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[94:95], v[20:21], v[48:55] ; cc464030 1cc2295e
	v_add_nc_u32_e32 v11, v11, v152                             ; 4a17310b
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[98:99], v[12:13], v[64:71] ; cc464040 1d021962
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[98:99], v[8:9], v[48:55] ; cc464030 1cc21162
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	s_clause 0x3                                                ; bf850003
	buffer_store_b64 v[0:1], v28, s[16:19], null offen          ; c406c07c 40802000 0000001c
	buffer_store_b64 v[2:3], v29, s[16:19], null offen          ; c406c07c 40802002 0000001d
	buffer_store_b64 v[4:5], v30, s[16:19], null offen          ; c406c07c 40802004 0000001e
	buffer_store_b64 v[6:7], v11, s[16:19], null offen          ; c406c07c 40802006 0000000b
	s_branch BB78                                               ; bfa02ddf
BB20:
	s_cmp_eq_i32 s17, 12                                        ; bf008c11
	s_cbranch_scc0 BB34                                         ; bfa10b72
BB21:
	s_mov_b32 s14, s1                                           ; be8e0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[0:1], 0x0                           ; f4004400 f8000000
	s_load_b256 s[48:55], s[0:1], 0x30                          ; f4006c00 f8000030
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_max_i32 s13, s13, 0                                       ; 8a0d800d
	s_add_co_u32 s15, s11, -1                                   ; 800fc10b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s13, s13, s15                                     ; 890d0f0d
	s_max_i32 s29, s29, 0                                       ; 8a1d801d
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	s_min_i32 s29, s29, s12                                     ; 891d0c1d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s29, s29, s11                                     ; 961d0b1d
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_add_co_u32 s13, s29, s13                                  ; 800d0d1d
	s_lshl_b32 s13, s13, 9                                      ; 840d890d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s21, s14, s13                                  ; 80150d0e
	s_max_i32 s20, s20, 0                                       ; 8a148014
	v_add3_u32 v5, v3, s21, 0x100                               ; d6550005 03fc2b03 00000100
	v_add3_u32 v4, v1, s21, v3                                  ; d6550004 040c2b01
	s_min_i32 s20, s20, s15                                     ; 89140f14
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s29, s29, s20                                  ; 801d141d
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_lshl_b32 s29, s29, 9                                      ; 841d891d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s14, s14, s29                                  ; 800e1d0e
	v_add3_u32 v7, v3, s14, 0x100                               ; d6550007 03fc1d03 00000100
	v_add3_u32 v6, v1, s14, v3                                  ; d6550006 040c1d01
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[8:9], v4, s[16:19], null offen            ; c405407c 40802008 00000004
	buffer_load_b64 v[4:5], v5, s[16:19], null offen            ; c405407c 40802004 00000005
	buffer_load_b64 v[10:11], v6, s[16:19], null offen          ; c405407c 4080200a 00000006
	buffer_load_b64 v[6:7], v7, s[16:19], null offen            ; c405407c 40802006 00000007
	v_lshlrev_b32_e32 v12, 2, v0                                ; 30180082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v13, s3, v12, 2                              ; d647000d 020a1803
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[16:19], v13, s[52:55], null offen        ; c405c07c 40806810 0000000d
	buffer_load_b128 v[20:23], v13, s[52:55], null offen offset:512 ; c405c07c 40806814 0002000d
	buffer_load_b128 v[24:27], v13, s[52:55], null offen offset:1024 ; c405c07c 40806818 0004000d
	buffer_load_b128 v[28:31], v13, s[52:55], null offen offset:1536 ; c405c07c 4080681c 0006000d
	buffer_load_b128 v[32:35], v13, s[52:55], null offen offset:2048 ; c405c07c 40806820 0008000d
	buffer_load_b128 v[36:39], v13, s[52:55], null offen offset:2560 ; c405c07c 40806824 000a000d
	buffer_load_b128 v[40:43], v13, s[52:55], null offen offset:3072 ; c405c07c 40806828 000c000d
	buffer_load_b128 v[44:47], v13, s[52:55], null offen offset:3584 ; c405c07c 4080682c 000e000d
	v_lshrrev_b32_e32 v0, 4, v0                                 ; 32000084
	s_mov_b64 s[20:21], s[48:49]                                ; be940130
	s_mov_b64 s[22:23], s[50:51]                                ; be960132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshlrev_b32_e32 v0, 3, v0                                 ; 30000083
	v_add_lshl_u32 v14, s8, v0, 2                               ; d647000e 020a0008
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v14, s[20:23], null offen        ; c405c07c 40802830 0000000e
	buffer_load_b128 v[52:55], v14, s[20:23], null offen offset:16 ; c405c07c 40802834 0000100e
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add_lshl_u32 v15, s4, v12, 2                              ; d647000f 020a1804
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[56:59], v15, s[52:55], null offen        ; c405c07c 40806838 0000000f
	buffer_load_b128 v[60:63], v15, s[52:55], null offen offset:512 ; c405c07c 4080683c 0002000f
	buffer_load_b128 v[64:67], v15, s[52:55], null offen offset:1024 ; c405c07c 40806840 0004000f
	buffer_load_b128 v[68:71], v15, s[52:55], null offen offset:1536 ; c405c07c 40806844 0006000f
	buffer_load_b128 v[72:75], v15, s[52:55], null offen offset:2048 ; c405c07c 40806848 0008000f
	buffer_load_b128 v[76:79], v15, s[52:55], null offen offset:2560 ; c405c07c 4080684c 000a000f
	buffer_load_b128 v[80:83], v15, s[52:55], null offen offset:3072 ; c405c07c 40806850 000c000f
	buffer_load_b128 v[84:87], v15, s[52:55], null offen offset:3584 ; c405c07c 40806854 000e000f
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_cndmask_b32_e64 v8, v8, 0, s31                            ; d5010008 007d0108
	v_cndmask_b32_e64 v9, v9, 0, s31                            ; d5010009 007d0109
	s_wait_loadcnt 0x14                                         ; bfc00014
	v_cndmask_b32_e64 v5, v5, 0, s31                            ; d5010005 007d0105
	v_cndmask_b32_e64 v4, v4, 0, s31                            ; d5010004 007d0104
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_cndmask_b32_e64 v10, v10, 0, s37                          ; d501000a 0095010a
	v_cndmask_b32_e64 v11, v11, 0, s37                          ; d501000b 0095010b
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v7, v7, 0, s37                            ; d5010007 00950107
	v_cndmask_b32_e64 v6, v6, 0, s37                            ; d5010006 00950106
	v_cvt_pk_f32_fp8_e32 v[92:93], v136                         ; 7eb8dd88
	v_cvt_pk_f32_fp8_e32 v[90:91], v8                           ; 7eb4dd08
	v_dual_mov_b32 v89, v9 :: v_dual_mov_b32 v88, v8            ; ca100109 59580108
	v_cvt_pk_f32_fp8_e32 v[94:95], v9                           ; 7ebcdd09
	v_cvt_pk_f32_fp8_e32 v[8:9], v137                           ; 7e10dd89
	v_dual_mov_b32 v97, v5 :: v_dual_mov_b32 v96, v4            ; ca100105 61600104
	v_cvt_pk_f32_fp8_e32 v[100:101], v10                        ; 7ec8dd0a
	v_dual_mov_b32 v99, v11 :: v_dual_mov_b32 v98, v10          ; ca10010b 6362010a
	v_cvt_pk_f32_fp8_e32 v[102:103], v138                       ; 7eccdd8a
	v_cvt_pk_f32_fp8_e32 v[104:105], v11                        ; 7ed0dd0b
	v_dual_mov_b32 v107, v7 :: v_dual_mov_b32 v106, v6          ; ca100107 6b6a0106
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[88:89], 0 ; cc464070 1a02b110
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[88:89], 0 ; cc464080 1a02b112
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[98:99], 0 ; cc464078 1a02c510
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[98:99], 0 ; cc464088 1a02c512
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[96:97], v[112:119] ; cc464070 1dc2c114
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[20:21], v[106:107], v[120:127] ; cc464078 1de2d514
	v_maxmin_num_f32 v110, -4.0, v116, 4.0                      ; d669006e 03dae8f7
	v_maxmin_num_f32 v20, -4.0, v114, 4.0                       ; d6690014 03dae4f7
	v_maxmin_num_f32 v108, -4.0, v115, 4.0                      ; d669006c 03dae6f7
	v_maxmin_num_f32 v18, -4.0, v113, 4.0                       ; d6690012 03dae2f7
	v_maxmin_num_f32 v16, -4.0, v112, 4.0                       ; d6690010 03dae0f7
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v21, 0xab28, |v20|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfe28ff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v19, 0xab28, |v18|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206213 0bfe24ff 3728ab28
	v_fma_mix_f32 v17, 0xab28, |v16|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206211 0bfe20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fmaak_f32 v109, v109, v108, 0x3f650000                    ; 5adad96d 3f650000
	v_dual_fmaak_f32 v19, v19, v18, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v17, 0x3f650000 ; c8422513 13102310 3f650000
	v_maxmin_num_f32 v144, -4.0, v121, 4.0                      ; d6690090 03daf2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_mul_f32 v115, v109, v115 :: v_dual_fmaak_f32 v20, v20, v21, 0x3f650000 ; c8c2e76d 73142b14 3f650000
	v_dual_mul_f32 v113, v113, v19 :: v_dual_mul_f32 v112, v112, v16 ; c8c62771 71702170
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v117, 4.0                      ; d6690070 03daeaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v123, 4.0                      ; d6690094 03daf6f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v122, 4.0                      ; d6690092 03daf4f7
	v_dual_mul_f32 v117, v117, v113 :: v_dual_mul_f32 v116, v116, v110 ; c8c6e375 7574dd74
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v125, 4.0                      ; d6690098 03dafaf7
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v116, -4.0, v119, 4.0                      ; d6690074 03daeef7
	v_maxmin_num_f32 v150, -4.0, v124, 4.0                      ; d6690096 03daf8f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v127, 4.0                      ; d669009c 03dafef7
	v_dual_fmaak_f32 v117, v116, v117, 0x3f650000 :: v_dual_mul_f32 v114, v114, v20 ; c846eb74 75722972 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v126, 4.0                      ; d669009a 03dafcf7
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v118, 4.0                      ; d6690072 03daecf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[96:97], v[128:135] ; cc464080 1e02c116
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_dual_mul_f32 v119, v119, v117 :: v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 ; c8c2eb77 7772e772 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v118, v118, v114 ; c8472191 9176e576 3f650000
	v_maxmin_num_f32 v160, -4.0, v129, 4.0                      ; d66900a0 03db02f7
	v_maxmin_num_f32 v158, -4.0, v128, 4.0                      ; d669009e 03db00f7
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v120, 4.0                      ; d6690076 03daf0f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v131, 4.0                      ; d66900a4 03db06f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v130, 4.0                      ; d66900a2 03db04f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_mul_f32 v121, v121, v145 :: v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 ; c8c32379 7976ef76 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[106:107], v[136:143] ; cc464088 1e22d516
	v_maxmin_num_f32 v168, -4.0, v133, 4.0                      ; d66900a8 03db0af7
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v120, v120, v118 ; c8472995 9578ed78 3f650000
	v_maxmin_num_f32 v166, -4.0, v132, 4.0                      ; d66900a6 03db08f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d3
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v123, v123, v149 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8c32b7b 7b932792 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v135, 4.0                      ; d66900ac 03db0ef7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v122, v122, v146 ; c8473199 997b257a 3f650000
	v_maxmin_num_f32 v170, -4.0, v134, 4.0                      ; d66900aa 03db0cf7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v125, v125, v153 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8c3337d 7d972f96 3f650000
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v137, 4.0                      ; d66900b0 03db12f7
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v124, v124, v150 ; c847399d 9d7d2d7c 3f650000
	v_maxmin_num_f32 v174, -4.0, v136, 4.0                      ; d66900ae 03db10f7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_mul_f32 v127, v127, v157 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8c33b7f 7f9b379a 3f650000
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v139, 4.0                      ; d66900b4 03db16f7
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_mul_f32 v126, v126, v154 ; c84741a1 a17f357e 3f650000
	v_maxmin_num_f32 v178, -4.0, v138, 4.0                      ; d66900b2 03db14f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v129, v129, v161 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c8c34381 819f3f9e 3f650000
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v141, 4.0                      ; d66900b8 03db1af7
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_mul_f32 v128, v128, v158 ; c84749a5 a5813d80 3f650000
	v_maxmin_num_f32 v182, -4.0, v140, 4.0                      ; d66900b6 03db18f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v131, v131, v165 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8c34b83 83a347a2 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v143, 4.0                      ; d66900bc 03db1ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_mul_f32 v130, v130, v162 ; c84751a9 a9834582 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[88:89], 0 ; cc464070 1a02b118
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v133, v133, v169 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c8c35385 85a74fa6 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v132, v132, v166 ; c84759ad ad854d84 3f650000
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[96:97], v[112:119] ; cc464070 1dc2c11c
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v135, v135, v173 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8c35b87 87ab57aa 3f650000
	v_maxmin_num_f32 v186, -4.0, v142, 4.0                      ; d66900ba 03db1cf7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_mul_f32 v134, v134, v170 ; c84761b1 b1875586 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v112, 4.0                      ; d66900be 03dae0f7
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v137, v137, v177 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c8c36389 89af5fae 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[98:99], 0 ; cc464078 1a02c518
	v_maxmin_num_f32 v15, -4.0, v114, 4.0                       ; d669000f 03dae4f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v136, v136, v174 ; c84769b5 b5895d88 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v25, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe1eff 3728ab28
	v_dual_mul_f32 v139, v139, v181 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c8c36b8b 8bb367b2 3f650000
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fmaak_f32 v15, v15, v25, 0x3f650000                       ; 5a1e330f 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[106:107], v[120:127] ; cc464078 1de2d51c
	v_maxmin_num_f32 v28, -4.0, v115, 4.0                       ; d669001c 03dae6f7
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_mul_f32 v138, v138, v178 ; c84771b9 b98b658a 3f650000
	v_maxmin_num_f32 v108, -4.0, v116, 4.0                      ; d669006c 03dae8f7
	v_maxmin_num_f32 v110, -4.0, v117, 4.0                      ; d669006e 03daeaf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v141, v141, v185 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c8c3738d 8db76fb6 3f650000
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v140, v140, v182 ; c84779bd bd8d6d8c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b8f 8fbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v113, 4.0                      ; d66900bf 03dae2f7
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v108 ; c8c6df75 7574d974
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 :: v_dual_mul_f32 v112, v112, v190 ; c846391d 1d717d70 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v115, v115, v29 :: v_dual_mul_f32 v114, v114, v15 ; c8c63b73 73721f72
	v_dual_fmaak_f32 v13, v191, v13, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8421bbf 0dbb77ba 3f650000
	v_maxmin_num_f32 v116, -4.0, v120, 4.0                      ; d6690074 03daf0f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v113, v113, v13 :: v_dual_mul_f32 v142, v142, v186 ; c8c61b71 718f758e
	v_maxmin_num_f32 v128, -4.0, v123, 4.0                      ; d6690080 03daf6f7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v118, 4.0                      ; d6690070 03daecf7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v119, 4.0                      ; d6690072 03daeef7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v125, 4.0                      ; d6690084 03dafaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v124, 4.0                      ; d6690082 03daf8f7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c8430181 8174eb74 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v127, 4.0                      ; d6690088 03dafef7
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_mul_f32 v123, v123, v129 :: v_dual_mul_f32 v120, v120, v116 ; c8c7037b 7b78e978
	v_maxmin_num_f32 v134, -4.0, v126, 4.0                      ; d6690086 03dafcf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v119, v119, v115 :: v_dual_mul_f32 v118, v118, v112 ; c8c6e777 7776e176
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8431189 89830782 3f650000
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v121, 4.0                      ; d6690076 03daf2f7
	v_dual_mul_f32 v127, v127, v137 :: v_dual_mul_f32 v124, v124, v130 ; c8c7137f 7f7d057c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fmaak_f32 v119, v119, v118, 0x3f650000                    ; 5aeeed77 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_mul_f32_e32 v121, v121, v119                              ; 10f2ef79
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[88:89], 0 ; cc464070 1a02b11a
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v122, 4.0                      ; d6690078 03daf4f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[96:97], v[112:119] ; cc464070 1dc2c11e
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8430985 8578f378 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v125, v125, v133 :: v_dual_mul_f32 v122, v122, v120 ; c8c70b7d 7d7af17a
	v_maxmin_num_f32 v140, -4.0, v113, 4.0                      ; d669008c 03dae2f7
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v144, -4.0, v115, 4.0                      ; d6690090 03dae6f7
	v_maxmin_num_f32 v138, -4.0, v112, 4.0                      ; d669008a 03dae0f7
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v142, -4.0, v114, 4.0                      ; d669008e 03dae4f7
	v_maxmin_num_f32 v148, -4.0, v117, 4.0                      ; d6690094 03daeaf7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v116, 4.0                      ; d6690092 03dae8f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v119, 4.0                      ; d6690098 03daeef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c843198d 8d870f86 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v118, 4.0                      ; d6690096 03daecf7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c8432191 918b178a 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432995 958f1f8e 3f650000
	v_dual_mul_f32 v113, v113, v141 :: v_dual_mul_f32 v126, v126, v134 ; c8c71b71 717f0d7e
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8433199 99932792 3f650000
	v_dual_mul_f32 v115, v115, v145 :: v_dual_mul_f32 v112, v112, v138 ; c8c72373 73711570
	v_dual_mul_f32 v117, v117, v149 :: v_dual_mul_f32 v114, v114, v142 ; c8c72b75 75731d72
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[98:99], 0 ; cc464078 1a02c51a
	v_dual_mul_f32 v119, v119, v153 :: v_dual_mul_f32 v116, v116, v146 ; c8c73377 77752574
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[106:107], v[120:127] ; cc464078 1de2d51e
	v_maxmin_num_f32 v164, -4.0, v125, 4.0                      ; d66900a4 03dafaf7
	v_maxmin_num_f32 v160, -4.0, v123, 4.0                      ; d66900a0 03daf6f7
	v_maxmin_num_f32 v154, -4.0, v120, 4.0                      ; d669009a 03daf0f7
	v_maxmin_num_f32 v156, -4.0, v121, 4.0                      ; d669009c 03daf2f7
	v_maxmin_num_f32 v158, -4.0, v122, 4.0                      ; d669009e 03daf4f7
	v_maxmin_num_f32 v162, -4.0, v124, 4.0                      ; d66900a2 03daf8f7
	v_maxmin_num_f32 v168, -4.0, v127, 4.0                      ; d66900a8 03dafef7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v126, 4.0                      ; d66900a6 03dafcf7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c84341a1 a19b379a 3f650000
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c843399d 9d972f96 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84349a5 a59f3f9e 3f650000
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84351a9 a9a347a2 3f650000
	v_dual_mul_f32 v123, v123, v161 :: v_dual_mul_f32 v120, v120, v154 ; c8c7437b 7b793578
	v_dual_mul_f32 v121, v121, v157 :: v_dual_mul_f32 v118, v118, v150 ; c8c73b79 79772d76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_mul_f32 v125, v125, v165 :: v_dual_mul_f32 v122, v122, v158 ; c8c74b7d 7d7b3d7a
	v_dual_mul_f32 v127, v127, v169 :: v_dual_mul_f32 v124, v124, v162 ; c8c7537f 7f7d457c
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[88:89], 0 ; cc464070 1a02b120
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[96:97], v[112:119] ; cc464070 1dc2c124
	v_maxmin_num_f32 v176, -4.0, v115, 4.0                      ; d66900b0 03dae6f7
	v_maxmin_num_f32 v174, -4.0, v114, 4.0                      ; d66900ae 03dae4f7
	v_maxmin_num_f32 v172, -4.0, v113, 4.0                      ; d66900ac 03dae2f7
	v_maxmin_num_f32 v170, -4.0, v112, 4.0                      ; d66900aa 03dae0f7
	v_maxmin_num_f32 v180, -4.0, v117, 4.0                      ; d66900b4 03daeaf7
	v_maxmin_num_f32 v178, -4.0, v116, 4.0                      ; d66900b2 03dae8f7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v119, 4.0                      ; d66900b8 03daeef7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v118, 4.0                      ; d66900b6 03daecf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84359ad ada74fa6 3f650000
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84361b1 b1ab57aa 3f650000
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84369b5 b5af5fae 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84371b9 b9b367b2 3f650000
	v_dual_mul_f32 v113, v113, v173 :: v_dual_mul_f32 v126, v126, v166 ; c8c75b71 717f4d7e
	v_dual_mul_f32 v115, v115, v177 :: v_dual_mul_f32 v112, v112, v170 ; c8c76373 73715570
	v_dual_mul_f32 v117, v117, v181 :: v_dual_mul_f32 v114, v114, v174 ; c8c76b75 75735d72
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v119, v119, v185 :: v_dual_mul_f32 v116, v116, v178 ; c8c77377 77756574
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[98:99], 0 ; cc464078 1a02c520
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[106:107], v[120:127] ; cc464078 1de2d524
	v_maxmin_num_f32 v190, -4.0, v122, 4.0                      ; d66900be 03daf4f7
	v_maxmin_num_f32 v186, -4.0, v120, 4.0                      ; d66900ba 03daf0f7
	v_maxmin_num_f32 v188, -4.0, v121, 4.0                      ; d66900bc 03daf2f7
	v_maxmin_num_f32 v15, -4.0, v124, 4.0                       ; d669000f 03daf8f7
	v_maxmin_num_f32 v108, -4.0, v125, 4.0                      ; d669006c 03dafaf7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v126, 4.0                      ; d669006e 03dafcf7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v127, 4.0                      ; d6690070 03dafef7
	v_fma_mix_f32 v37, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfe1eff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84379bd bdb76fb6 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v121, v121, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b79 79bf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v123, 4.0                      ; d66900bf 03daf6f7
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_mul_f32 v122, v122, v190 ; c846d96d 6d7b7d7a 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_dual_mul_f32 v127, v127, v113 :: v_dual_mul_f32 v126, v126, v110 ; c8c6e37f 7f7edd7e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v13, v13, v191, 0x3f650000 :: v_dual_mul_f32 v118, v118, v182 ; c8477f0d 0d776d76 3f650000
	v_dual_mul_f32 v123, v123, v13 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8c21b7b 7bbb77ba 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[88:89], 0 ; cc464070 1a02b122
	v_dual_fmaak_f32 v15, v15, v37, 0x3f650000 :: v_dual_mul_f32 v120, v120, v186 ; c8464b0f 0f797578 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_mul_f32 v125, v125, v109 :: v_dual_mul_f32 v124, v124, v15 ; c8c6db7d 7d7c1f7c
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[98:99], 0 ; cc464078 1a02c522
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[96:97], v[112:119] ; cc464070 1dc2c126
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[106:107], v[120:127] ; cc464078 1de2d526
	v_maxmin_num_f32 v138, -4.0, v117, 4.0                      ; d669008a 03daeaf7
	v_maxmin_num_f32 v130, -4.0, v113, 4.0                      ; d6690082 03dae2f7
	v_maxmin_num_f32 v136, -4.0, v116, 4.0                      ; d6690088 03dae8f7
	v_maxmin_num_f32 v132, -4.0, v114, 4.0                      ; d6690084 03dae4f7
	v_maxmin_num_f32 v134, -4.0, v115, 4.0                      ; d6690086 03dae6f7
	v_maxmin_num_f32 v128, -4.0, v112, 4.0                      ; d6690080 03dae0f7
	v_maxmin_num_f32 v140, -4.0, v118, 4.0                      ; d669008c 03daecf7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v119, 4.0                      ; d669008e 03daeef7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v120, 4.0                      ; d6690090 03daf0f7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v121, 4.0                      ; d6690092 03daf2f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c843158b 8b891388 3f650000
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430d87 87850b84 3f650000
	v_maxmin_num_f32 v148, -4.0, v122, 4.0                      ; d6690094 03daf4f7
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
	v_maxmin_num_f32 v150, -4.0, v123, 4.0                      ; d6690096 03daf6f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 ; c8431d8f 8f8d1b8c 3f650000
	v_dual_mul_f32 v117, v117, v139 :: v_dual_mul_f32 v116, v116, v136 ; c8c71775 75751174
	v_dual_mul_f32 v115, v115, v135 :: v_dual_mul_f32 v114, v114, v132 ; c8c70f73 73730972
	v_maxmin_num_f32 v152, -4.0, v124, 4.0                      ; d6690098 03daf8f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_mul_f32 v113, v113, v131 :: v_dual_mul_f32 v112, v112, v128 ; c8c70771 71710170
	v_maxmin_num_f32 v154, -4.0, v125, 4.0                      ; d669009a 03dafaf7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_dual_mul_f32 v119, v119, v143 :: v_dual_mul_f32 v118, v118, v140 ; c8c71f77 77771976
	v_maxmin_num_f32 v156, -4.0, v126, 4.0                      ; d669009c 03dafcf7
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v158, -4.0, v127, 4.0                      ; d669009e 03dafef7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_mul_f32 v121, v121, v147 :: v_dual_mul_f32 v120, v120, v144 ; c8c72779 79792178
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[88:89], 0 ; cc464070 1a02b128
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_dual_mul_f32 v123, v123, v151 :: v_dual_mul_f32 v122, v122, v148 ; c8c72f7b 7b7b297a
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_dual_mul_f32 v125, v125, v155 :: v_dual_mul_f32 v124, v124, v152 ; c8c7377d 7d7d317c
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[96:97], v[112:119] ; cc464070 1dc2c12c
	v_dual_mul_f32 v127, v127, v159 :: v_dual_mul_f32 v126, v126, v156 ; c8c73f7f 7f7f397e
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[98:99], 0 ; cc464078 1a02c528
	v_maxmin_num_f32 v162, -4.0, v113, 4.0                      ; d66900a2 03dae2f7
	v_maxmin_num_f32 v160, -4.0, v112, 4.0                      ; d66900a0 03dae0f7
	v_maxmin_num_f32 v164, -4.0, v114, 4.0                      ; d66900a4 03dae4f7
	v_maxmin_num_f32 v166, -4.0, v115, 4.0                      ; d66900a6 03dae6f7
	v_maxmin_num_f32 v168, -4.0, v116, 4.0                      ; d66900a8 03dae8f7
	v_maxmin_num_f32 v170, -4.0, v117, 4.0                      ; d66900aa 03daeaf7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v118, 4.0                      ; d66900ac 03daecf7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	buffer_load_b128 v[108:111], v14, s[20:23], null offen offset:64 ; c405c07c 4080286c 0000400e
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	v_dual_mul_f32 v113, v113, v163 :: v_dual_mul_f32 v112, v112, v160 ; c8c74771 71714170
	v_dual_mul_f32 v115, v115, v167 :: v_dual_mul_f32 v114, v114, v164 ; c8c74f73 73734972
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	buffer_load_b128 v[112:115], v14, s[20:23], null offen offset:80 ; c405c07c 40802870 0000500e
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v119, 4.0                      ; d66900ae 03daeef7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[106:107], v[120:127] ; cc464078 1de2d52c
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c84355ab aba953a8 3f650000
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v117, v117, v171 :: v_dual_mul_f32 v116, v116, v168 ; c8c75775 75755174
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 ; c8435daf afad5bac 3f650000
	v_maxmin_num_f32 v180, -4.0, v122, 4.0                      ; d66900b4 03daf4f7
	v_maxmin_num_f32 v178, -4.0, v121, 4.0                      ; d66900b2 03daf2f7
	v_maxmin_num_f32 v184, -4.0, v124, 4.0                      ; d66900b8 03daf8f7
	v_maxmin_num_f32 v176, -4.0, v120, 4.0                      ; d66900b0 03daf0f7
	v_maxmin_num_f32 v182, -4.0, v123, 4.0                      ; d66900b6 03daf6f7
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v119, v119, v175 :: v_dual_mul_f32 v118, v118, v172 ; c8c75f77 77775976
	v_maxmin_num_f32 v186, -4.0, v125, 4.0                      ; d66900ba 03dafaf7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v126, 4.0                      ; d66900bc 03dafcf7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v127, 4.0                      ; d66900be 03dafef7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84365b3 b3b163b0 3f650000
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c8436db7 b7b56bb4 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[98:99], 0 ; cc464080 1a02c52a
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84375bb bbb973b8 3f650000
	v_dual_mul_f32 v121, v121, v179 :: v_dual_mul_f32 v120, v120, v176 ; c8c76779 79796178
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8437dbf bfbd7bbc 3f650000
	v_dual_mul_f32 v123, v123, v183 :: v_dual_mul_f32 v122, v122, v180 ; c8c76f7b 7b7b697a
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v125, v125, v187 :: v_dual_mul_f32 v124, v124, v184 ; c8c7777d 7d7d717c
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v127, v127, v191 :: v_dual_mul_f32 v126, v126, v188 ; c8c77f7f 7f7f797e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[106:107], v[128:135] ; cc464080 1e02d52e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[88:89], 0 ; cc464078 1a02b12a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[96:97], v[120:127] ; cc464078 1de2c12e
	v_maxmin_num_f32 v42, -4.0, v121, 4.0                       ; d669002a 03daf2f7
	v_maxmin_num_f32 v191, -4.0, v120, 4.0                      ; d66900bf 03daf0f7
	v_maxmin_num_f32 v96, -4.0, v125, 4.0                       ; d6690060 03dafaf7
	v_maxmin_num_f32 v46, -4.0, v123, 4.0                       ; d669002e 03daf6f7
	v_maxmin_num_f32 v88, -4.0, v124, 4.0                       ; d6690058 03daf8f7
	v_maxmin_num_f32 v44, -4.0, v122, 4.0                       ; d669002c 03daf4f7
	v_fma_mix_f32 v43, 0xab28, |v42|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622b 0bfe54ff 3728ab28
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_fma_mix_f32 v47, 0xab28, |v46|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622f 0bfe5cff 3728ab28
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v98, s5, v12, 2                              ; d6470062 020a1805
	v_fma_mix_f32 v45, 0xab28, |v44|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe58ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v47, v47, v46, 0x3f650000 :: v_dual_fmaak_f32 v44, v44, v45, 0x3f650000 ; c8425d2f 2f2c5b2c 3f650000
	v_dual_mul_f32 v123, v123, v47 :: v_dual_mul_f32 v122, v122, v44 ; c8c65f7b 7b7a597a
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v98, s[52:55], null offen        ; c405c07c 4080682c 00000062
	buffer_load_b128 v[116:119], v98, s[52:55], null offen offset:1024 ; c405c07c 40806874 00040062
	v_maxmin_num_f32 v99, -4.0, v126, 4.0                       ; d6690063 03dafcf7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fmaak_f32 v43, v43, v42, 0x3f650000                       ; 5a56552b 3f650000
	v_fmaak_f32 v191, v191, v13, 0x3f650000                     ; 5b7e1bbf 3f650000
	v_maxmin_num_f32 v107, -4.0, v127, 4.0                      ; d669006b 03dafef7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_mul_f32 v121, v43, v121 :: v_dual_mul_f32 v120, v120, v191 ; c8c6f32b 79797f78
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v106, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfec6ff 3728ab28
	v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842c161 6158b358 3f650000
	v_fma_mix_f32 v120, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfed6ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fmaak_f32 v99, v99, v106, 0x3f650000                      ; 5ac6d563 3f650000
	v_dual_mul_f32 v125, v125, v97 :: v_dual_mul_f32 v124, v124, v88 ; c8c6c37d 7d7cb17c
	v_fmaak_f32 v120, v120, v107, 0x3f650000                    ; 5af0d778 3f650000
	v_mul_f32_e32 v126, v126, v99                               ; 10fcc77e
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v128, 4.0                      ; d669007c 03db00f7
	v_mul_f32_e32 v127, v127, v120                              ; 10fef17f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fmaak_f32 v124, v124, v125, 0x3f650000                    ; 5af8fb7c 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v128, v128, v124                              ; 1100f980
	v_maxmin_num_f32 v136, -4.0, v129, 4.0                      ; d6690088 03db02f7
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[120:123], v98, s[52:55], null offen offset:2048 ; c405c07c 40806878 00080062
	buffer_load_b128 v[124:127], v98, s[52:55], null offen offset:512 ; c405c07c 4080687c 00020062
	buffer_load_b128 v[140:143], v98, s[52:55], null offen offset:1536 ; c405c07c 4080688c 00060062
	buffer_load_b128 v[96:99], v98, s[52:55], null offen offset:2560 ; c405c07c 40806860 000a0062
	v_maxmin_num_f32 v138, -4.0, v130, 4.0                      ; d669008a 03db04f7
	v_maxmin_num_f32 v144, -4.0, v131, 4.0                      ; d6690090 03db06f7
	v_maxmin_num_f32 v146, -4.0, v132, 4.0                      ; d6690092 03db08f7
	v_maxmin_num_f32 v148, -4.0, v133, 4.0                      ; d6690094 03db0af7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v134, 4.0                      ; d6690096 03db0cf7
	v_maxmin_num_f32 v152, -4.0, v135, 4.0                      ; d6690098 03db0ef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fmaak_f32 v137, v137, v136, 0x3f650000                    ; 5b131189 3f650000
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c8432191 918b178a 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8432995 95932792 3f650000
	v_mul_f32_e32 v129, v129, v137                              ; 11031381
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8433199 99972f96 3f650000
	v_dual_mul_f32 v131, v131, v145 :: v_dual_mul_f32 v130, v130, v138 ; c8c72383 83831582
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_dual_mul_f32 v145, v101, v49 :: v_dual_mul_f32 v144, v100, v48 ; c8c66365 91906164
	v_dual_mul_f32 v133, v133, v149 :: v_dual_mul_f32 v132, v132, v146 ; c8c72b85 85852584
	v_dual_mul_f32 v147, v103, v51 :: v_dual_mul_f32 v146, v102, v50 ; c8c66767 93926566
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_mul_f32 v149, v105, v53 :: v_dual_mul_f32 v148, v104, v52 ; c8c66b69 95946968
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v129, v91, v49 :: v_dual_mul_f32 v128, v90, v48 ; c8c6635b 8180615a
	v_dual_mul_f32 v135, v135, v153 :: v_dual_mul_f32 v134, v134, v150 ; c8c73387 87872d86
	v_dual_mul_f32 v151, v11, v55 :: v_dual_mul_f32 v150, v10, v54 ; c8c66f0b 97966d0a
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v131, v93, v51 :: v_dual_mul_f32 v130, v92, v50 ; c8c6675d 8382655c
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[18:19], v[144:151] ; cc464090 1e422538
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	s_bitset0_b32 s49, 14                                       ; beb1108e
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_buffer_load_b32 s10, s[48:51], s10 offset:0x0             ; f4020298 14000000
	v_dual_mul_f32 v133, v95, v53 :: v_dual_mul_f32 v132, v94, v52 ; c8c66b5f 8584695e
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v135, v9, v55 :: v_dual_mul_f32 v134, v8, v54 ; c8c66f09 87866d08
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[16:17], v[128:135] ; cc464080 1e022138
	v_cvt_pk_f32_fp8_e32 v[48:49], v4                           ; 7e60dd04
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[22:23], v[144:151] ; cc464090 1e422d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[20:21], v[128:135] ; cc464080 1e02293c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[64:65], v[28:29], v[144:151] ; cc464090 1e423940
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[64:65], v[24:25], v[128:135] ; cc464080 1e023140
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[30:31], v[144:151] ; cc464090 1e423d44
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mul_f32 v153, v49, v109 :: v_dual_mul_f32 v152, v48, v108 ; c8c6db31 9998d930
	v_cvt_pk_f32_fp8_e32 v[48:49], v132                         ; 7e60dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[26:27], v[128:135] ; cc464080 1e023544
	v_dual_mul_f32 v155, v49, v111 :: v_dual_mul_f32 v154, v48, v110 ; c8c6df31 9b9add30
	v_cvt_pk_f32_fp8_e32 v[48:49], v5                           ; 7e60dd05
	v_cvt_pk_f32_fp8_e32 v[4:5], v133                           ; 7e08dd85
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[36:37], v[144:151] ; cc464090 1e424948
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v159, v5, v115 :: v_dual_mul_f32 v158, v4, v114 ; c8c6e705 9f9ee504
	v_cvt_pk_f32_fp8_e32 v[4:5], v6                             ; 7e08dd06
	v_dual_mul_f32 v157, v49, v113 :: v_dual_mul_f32 v156, v48, v112 ; c8c6e331 9d9ce130
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[32:33], v[128:135] ; cc464080 1e024148
	v_dual_mul_f32 v49, v5, v109 :: v_dual_mul_f32 v48, v4, v108 ; c8c6db05 3130d904
	v_cvt_pk_f32_fp8_e32 v[4:5], v134                           ; 7e08dd86
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[76:77], v[38:39], v[144:151] ; cc464090 1e424d4c
	v_dual_mul_f32 v51, v5, v111 :: v_dual_mul_f32 v50, v4, v110 ; c8c6df05 3332dd04
	v_cvt_pk_f32_fp8_e32 v[4:5], v7                             ; 7e08dd07
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[34:35], v[128:135] ; cc464080 1e02454c
	v_dual_mul_f32 v53, v5, v113 :: v_dual_mul_f32 v52, v4, v112 ; c8c6e305 3534e104
	v_cvt_pk_f32_fp8_e32 v[4:5], v135                           ; 7e08dd87
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[80:81], v[14:15], v[144:151] ; cc464090 1e421d50
	v_dual_mul_f32 v55, v5, v115 :: v_dual_mul_f32 v54, v4, v114 ; c8c6e705 3736e504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[58:59], v[18:19], v[48:55] ; cc464030 1cc2253a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[40:41], v[128:135] ; cc464080 1e025150
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[88:89], v[144:151] ; cc464090 1e42b154
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[62:63], v[22:23], v[48:55] ; cc464030 1cc22d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[42:43], v[128:135] ; cc464080 1e025554
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[16:17], v[152:159] ; cc464098 1e62213a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[66:67], v[28:29], v[48:55] ; cc464030 1cc23942
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[20:21], v[152:159] ; cc464098 1e62293e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[70:71], v[30:31], v[48:55] ; cc464030 1cc23d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[24:25], v[152:159] ; cc464098 1e623142
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[74:75], v[36:37], v[48:55] ; cc464030 1cc2494a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[70:71], v[26:27], v[152:159] ; cc464098 1e623546
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[78:79], v[38:39], v[48:55] ; cc464030 1cc24d4e
	v_lshl_add_u32 v160, v2, 5, v1                              ; d64600a0 04050b02
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[32:33], v[152:159] ; cc464098 1e62414a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[82:83], v[14:15], v[48:55] ; cc464030 1cc21d52
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, 0              ; ca100080 0f0e0080
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[78:79], v[34:35], v[152:159] ; cc464098 1e62454e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[86:87], v[88:89], v[48:55] ; cc464030 1cc2b156
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[82:83], v[40:41], v[152:159] ; cc464098 1e625152
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[42:43], v[152:159] ; cc464098 1e625556
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v160, v[14:15], v[14:15] offset1:2       ; d9380200 000e0ea0
	ds_store_2addr_b64 v160, v[14:15], v[14:15] offset0:64 offset1:66 ; d9384240 000e0ea0
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[46:47], v[8:9], 0   ; cc464018 1a02112e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[118:119], v[8:9], 0 ; cc464038 1a021176
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[8:9], 0   ; cc464010 1a02112c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[116:117], v[8:9], 0 ; cc464020 1a021174
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[120:121], 0 ; cc464040 1a02f108
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[122:123], 0 ; cc464048 1a02f508
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[126:127], v[4:5], v[24:31] ; cc464018 1c62097e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[142:143], v[4:5], v[56:63] ; cc464038 1ce2098e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[124:125], v[4:5], v[16:23] ; cc464010 1c42097c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[140:141], v[4:5], v[32:39] ; cc464020 1c82098c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[4:5], v[96:97], v[64:71] ; cc464040 1d02c104
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[4:5], v[98:99], v[72:79] ; cc464048 1d22c504
	v_dual_mul_f32 v164, v59, v59 :: v_dual_mul_f32 v161, v25, v25 ; c8c6773b a4a03319
	v_dual_mul_f32 v163, v27, v27 :: v_dual_mul_f32 v162, v57, v57 ; c8c6371b a3a27339
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_dual_fmac_f32 v164, v35, v35 :: v_dual_fmac_f32 v161, v17, v17 ; c8004723 a4a02311
	s_mov_b32 s24, 0x76543210                                   ; be9800ff 76543210
	v_dual_fmac_f32 v163, v19, v19 :: v_dual_fmac_f32 v162, v33, v33 ; c8002713 a3a24321
	s_mov_b32 s25, 0xfedcba98                                   ; be9900ff fedcba98
	v_dual_fmac_f32 v164, v39, v39 :: v_dual_fmac_f32 v161, v21, v21 ; c8004f27 a4a02b15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v163, v23, v23 :: v_dual_fmac_f32 v162, v37, v37 ; c8002f17 a3a24b25
	v_dual_fmac_f32 v164, v63, v63 :: v_dual_fmac_f32 v161, v29, v29 ; c8007f3f a4a03b1d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v163, v31, v31 :: v_dual_fmac_f32 v162, v61, v61 ; c8003f1f a3a27b3d
	v_dual_fmac_f32 v164, v34, v34 :: v_dual_fmac_f32 v161, v16, v16 ; c8004522 a4a02110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v32, v32 :: v_dual_fmac_f32 v163, v18, v18 ; c8004120 a2a22512
	v_dual_fmac_f32 v164, v58, v58 :: v_dual_fmac_f32 v161, v24, v24 ; c800753a a4a03118
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v56, v56 :: v_dual_fmac_f32 v163, v26, v26 ; c8007138 a2a2351a
	v_dual_fmac_f32 v164, v38, v38 :: v_dual_fmac_f32 v161, v20, v20 ; c8004d26 a4a02914
	v_lshl_add_u32 v2, v2, 6, s7                                ; d6460002 001d0d02
	v_dual_fmac_f32 v162, v36, v36 :: v_dual_fmac_f32 v163, v22, v22 ; c8004924 a2a22d16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
	v_dual_fmac_f32 v164, v62, v62 :: v_dual_fmac_f32 v161, v28, v28 ; c8007d3e a4a0391c
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
	v_dual_fmac_f32 v162, v60, v60 :: v_dual_fmac_f32 v163, v30, v30 ; c800793c a2a23d1e
	v_fma_mixlo_f16 v165, 1.0, v161, v163                       ; cc2100a5 068f42f2
	v_fma_mixhi_f16 v165, 1.0, v162, v164                       ; cc2200a5 069344f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v166, v165, s24, s25 op_sel:[1,1]         ; d65c18a6 006431a5
(invalid instruction)                                        ; cc0f00a5
	v_min_num_f64_e32 v[1:2], v[165:166], v[166:167]            ; 1a034da5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v255                             ; 0a01ffa5
(invalid instruction)                                        ; 00000410
(invalid instruction)                                        ; d58b00a7
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a1
	v_rsq_f32_e32 v167, v167                                    ; 7f4e5da7
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_mul_f32_e32 v167, s10, v167                               ; 114f4e0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v18, v18, v167 :: v_dual_mul_f32 v19, v19, v167 ; c8c74f12 12134f13
	v_dual_mul_f32 v16, v16, v167 :: v_dual_mul_f32 v17, v17, v167 ; c8c74f10 10114f11
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v2, s[20:23], null offen offset:8192 ; c405c07c 40802810 00200002
	buffer_load_b128 v[40:43], v2, s[20:23], null offen offset:8208 ; c405c07c 40802828 00201002
(invalid instruction)                                        ; d58b08a5
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
	v_dual_mul_f32 v23, v23, v167 :: v_dual_mul_f32 v22, v22, v167 ; c8c74f17 17174f16
	v_mul_f32_e32 v21, v21, v167                                ; 102b4f15
	v_mul_f32_e32 v20, v20, v167                                ; 10294f14
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_rsq_f32_e32 v165, v165                                    ; 7f4a5da5
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870125
	v_dual_mul_f32 v33, v33, v165 :: v_dual_mul_f32 v32, v32, v165 ; c8c74b21 21214b20
	v_dual_mul_f32 v35, v35, v165 :: v_dual_mul_f32 v34, v34, v165 ; c8c74b23 23234b22
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v2, s[20:23], null offen offset:12288 ; c405c07c 40802814 00300002
	buffer_load_b128 v[32:35], v2, s[20:23], null offen offset:12304 ; c405c07c 40802820 00301002
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v25, v25, v167 :: v_dual_mul_f32 v24, v24, v167 ; c8c74f19 19194f18
	v_dual_mul_f32 v27, v27, v167 :: v_dual_mul_f32 v26, v26, v167 ; c8c74f1b 1b1b4f1a
	v_dual_mul_f32 v29, v29, v167 :: v_dual_mul_f32 v28, v28, v167 ; c8c74f1d 1d1d4f1c
	v_dual_mul_f32 v31, v31, v167 :: v_dual_mul_f32 v30, v30, v167 ; c8c74f1f 1f1f4f1e
	v_dual_mul_f32 v39, v39, v165 :: v_dual_mul_f32 v38, v38, v165 ; c8c74b27 27274b26
	v_dual_mul_f32 v37, v37, v165 :: v_dual_mul_f32 v36, v36, v165 ; c8c74b25 25254b24
	v_dual_mul_f32 v57, v57, v165 :: v_dual_mul_f32 v56, v56, v165 ; c8c74b39 39394b38
	v_dual_mul_f32 v59, v59, v165 :: v_dual_mul_f32 v58, v58, v165 ; c8c74b3b 3b3b4b3a
	v_dual_mul_f32 v61, v61, v165 :: v_dual_mul_f32 v60, v60, v165 ; c8c74b3d 3d3d4b3c
	v_dual_mul_f32 v63, v63, v165 :: v_dual_mul_f32 v62, v62, v165 ; c8c74b3f 3f3f4b3e
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v160, v[8:9], v[26:27] offset0:128 offset1:130 ; d9388280 001a08a0
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v2, s[20:23], null offen offset:8256 ; c405c07c 4080281c 00204002
	buffer_load_b128 v[36:39], v2, s[20:23], null offen offset:8272 ; c405c07c 40802824 00205002
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[10:11], 0 ; cc464038 1a02152c
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[10:11], 0 ; cc464040 1a02152e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[10:11], v[120:121], 0 ; cc464058 1a02f10a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[122:123], 0 ; cc464068 1a02f50a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[6:7], v[96:97], v[88:95] ; cc464058 1d62c106
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[6:7], v[98:99], v[104:111] ; cc464068 1da2c506
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v2, s[20:23], null offen offset:12352 ; c405c07c 4080282c 00304002
	buffer_load_b128 v[96:99], v2, s[20:23], null offen offset:12368 ; c405c07c 40802860 00305002
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[116:117], v[10:11], 0 ; cc464048 1a021574
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[118:119], v[10:11], 0 ; cc464050 1a021576
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[124:125], v[6:7], v[56:63] ; cc464038 1ce20d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[126:127], v[6:7], v[64:71] ; cc464040 1d020d7e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[140:141], v[6:7], v[72:79] ; cc464048 1d220d8c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[142:143], v[6:7], v[80:87] ; cc464050 1d420d8e
	v_mul_f32_e32 v170, v67, v67                                ; 11548743
	v_mul_f32_e32 v168, v65, v65                                ; 11508341
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_fmac_f32_e32 v168, v57, v57                               ; 57507339
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[100:103], v2, s[20:23], null offen offset:8320 ; c405c07c 40802864 00208002
	buffer_load_b128 v[112:115], v2, s[20:23], null offen offset:8336 ; c405c07c 40802870 00209002
	v_dual_fmac_f32 v170, v59, v59 :: v_dual_mul_f32 v169, v81, v81 ; c806773b aaa8a351
	v_dual_fmac_f32 v168, v61, v61 :: v_dual_mul_f32 v171, v83, v83 ; c8067b3d a8aaa753
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v170, v63, v63 :: v_dual_fmac_f32 v169, v73, v73 ; c8007f3f aaa89349
	v_dual_fmac_f32 v168, v69, v69 :: v_dual_fmac_f32 v171, v75, v75 ; c8008b45 a8aa974b
	v_dual_fmac_f32 v170, v71, v71 :: v_dual_fmac_f32 v169, v77, v77 ; c8008f47 aaa89b4d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v168, v56, v56 :: v_dual_fmac_f32 v169, v85, v85 ; c8007138 a8a8ab55
	v_dual_fmac_f32 v170, v58, v58 :: v_dual_fmac_f32 v169, v72, v72 ; c800753a aaa89148
	v_dual_fmac_f32 v168, v64, v64 :: v_dual_fmac_f32 v171, v79, v79 ; c8008140 a8aa9f4f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v170, v66, v66 :: v_dual_fmac_f32 v169, v80, v80 ; c8008542 aaa8a150
	v_dual_fmac_f32 v168, v60, v60 :: v_dual_fmac_f32 v171, v87, v87 ; c800793c a8aaaf57
	v_dual_fmac_f32 v170, v62, v62 :: v_dual_fmac_f32 v169, v76, v76 ; c8007d3e aaa8994c
	v_dual_fmac_f32 v168, v68, v68 :: v_dual_fmac_f32 v171, v74, v74 ; c8008944 a8aa954a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v170, v70, v70 :: v_dual_fmac_f32 v169, v84, v84 ; c8008d46 aaa8a954
	v_fmac_f32_e32 v171, v82, v82                               ; 5756a552
	v_fma_mixlo_f16 v172, 1.0, v168, v170                       ; cc2100ac 06ab50f2
	v_fmac_f32_e32 v171, v78, v78                               ; 57569d4e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v171, v86, v86                               ; 5756ad56
	v_fma_mixhi_f16 v172, 1.0, v169, v171                       ; cc2200ac 06af52f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v173, v172, s24, s25 op_sel:[1,1]         ; d65c18ad 006431ac
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[173:174]            ; 1a035bac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v255                             ; 0a01ffac
(invalid instruction)                                        ; 00000410
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v174, v174                                    ; 7f5c5dae
	v_mul_f32_e32 v174, s10, v174                               ; 115d5c0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870241
	v_dual_mul_f32 v57, v57, v174 :: v_dual_mul_f32 v56, v56, v174 ; c8c75d39 39395d38
	v_dual_mul_f32 v63, v63, v174 :: v_dual_mul_f32 v62, v62, v174 ; c8c75d3f 3f3f5d3e
	v_dual_mul_f32 v59, v59, v174 :: v_dual_mul_f32 v58, v58, v174 ; c8c75d3b 3b3b5d3a
	v_dual_mul_f32 v61, v61, v174 :: v_dual_mul_f32 v60, v60, v174 ; c8c75d3d 3d3d5d3c
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v2, s[20:23], null offen offset:12416 ; c405c07c 40802838 00308002
	buffer_load_b128 v[60:63], v2, s[20:23], null offen offset:12432 ; c405c07c 4080283c 00309002
(invalid instruction)                                        ; d58b08ac
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	v_dual_mul_f32 v65, v65, v174 :: v_dual_mul_f32 v64, v64, v174 ; c8c75d41 41415d40
	v_dual_mul_f32 v67, v67, v174 :: v_dual_mul_f32 v66, v66, v174 ; c8c75d43 43435d42
	v_dual_mul_f32 v69, v69, v174 :: v_dual_mul_f32 v68, v68, v174 ; c8c75d45 45455d44
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_rsq_f32_e32 v172, v172                                    ; 7f585dac
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c5
	v_dual_mul_f32 v75, v75, v172 :: v_dual_mul_f32 v74, v74, v172 ; c8c7594b 4b4b594a
	v_dual_mul_f32 v73, v73, v172 :: v_dual_mul_f32 v72, v72, v172 ; c8c75949 49495948
	v_dual_mul_f32 v77, v77, v172 :: v_dual_mul_f32 v76, v76, v172 ; c8c7594d 4d4d594c
	v_dual_mul_f32 v79, v79, v172 :: v_dual_mul_f32 v78, v78, v172 ; c8c7594f 4f4f594e
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v2, s[20:23], null offen offset:8384 ; c405c07c 40802848 0020c002
	buffer_load_b128 v[76:79], v2, s[20:23], null offen offset:8400 ; c405c07c 4080284c 0020d002
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mul_f32_e32 v70, v70, v174                                ; 108d5d46
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_mul_f32_e32 v71, v71, v174                                ; 108f5d47
	v_dual_mul_f32 v81, v81, v172 :: v_dual_mul_f32 v80, v80, v172 ; c8c75951 51515950
	v_dual_mul_f32 v83, v83, v172 :: v_dual_mul_f32 v82, v82, v172 ; c8c75953 53535952
	v_dual_mul_f32 v85, v85, v172 :: v_dual_mul_f32 v84, v84, v172 ; c8c75955 55555954
	v_dual_mul_f32 v87, v87, v172 :: v_dual_mul_f32 v86, v86, v172 ; c8c75957 57575956
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v160, v[10:11], v[66:67] offset0:192 offset1:194 ; d938c2c0 00420aa0
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v2, s[20:23], null offen offset:12480 ; c405c07c 40802844 0030c002
	buffer_load_b128 v[80:83], v2, s[20:23], null offen offset:12496 ; c405c07c 40802850 0030d002
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_load_b64 v[66:67], v160                                  ; d9d80000 420000a0
	ds_load_b64 v[84:85], v160 offset:16                        ; d9d80010 540000a0
	s_mov_b32 s26, 0x3d380000                                   ; be9a00ff 3d380000
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[66:67], v[4:5], 0   ; cc464058 1a020942
	s_wait_dscnt 0x0                                            ; bfc60000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[84:85], v[24:25], v[88:95] ; cc464058 1d623154
	s_movk_i32 s27, 0x3e47                                      ; b01b3e47
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_fma_mixlo_f16 v176, s26, v90, v18                         ; cc2100b0 044ab41a
	v_fma_mixlo_f16 v175, s26, v88, v16                         ; cc2100af 0442b01a
	v_fma_mixhi_f16 v176, s26, v91, v19                         ; cc2200b0 044eb61a
	v_fma_mixhi_f16 v175, s26, v89, v17                         ; cc2200af 0446b21a
	ds_load_b64 v[16:17], v160 offset:512                       ; d9d80200 100000a0
	ds_load_b64 v[18:19], v160 offset:528                       ; d9d80210 120000a0
	s_movk_i32 s28, 0x3c20                                      ; b01c3c20
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[66:67], v[6:7], 0 ; cc464068 1a020d42
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v177, s26, v92, v40                         ; cc2100b1 04a2b81a
	v_fma_mixhi_f16 v177, s26, v93, v41                         ; cc2200b1 04a6ba1a
	v_fma_mixlo_f16 v178, s26, v94, v42                         ; cc2100b2 04aabc1a
	v_fma_mixhi_f16 v178, s26, v95, v43                         ; cc2200b2 04aebe1a
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v28                              ; 0a0039b0
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v28                              ; 0a0039af
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v28                              ; 0a0039b1
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v28                              ; 0a0039b2
(invalid instruction)                                        ; cc1b00b0
	v_subrev_f32_e32 v0, v176, v27                              ; 0a0037b0
(invalid instruction)                                        ; cc1b00af
	v_subrev_f32_e32 v0, v175, v27                              ; 0a0037af
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[84:85], v[64:65], v[104:111] ; cc464068 1da28154
(invalid instruction)                                        ; cc1b00b1
	v_subrev_f32_e32 v0, v177, v27                              ; 0a0037b1
(invalid instruction)                                        ; cc1b00b2
	v_subrev_f32_e32 v0, v178, v27                              ; 0a0037b2
	s_wait_loadcnt 0xd                                          ; bfc0000d
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mixlo_f16 v179, s26, v104, v20                        ; cc2100b3 0452d01a
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v182, s26, v110, v34                        ; cc2100b6 048adc1a
	v_fma_mixhi_f16 v182, s26, v111, v35                        ; cc2200b6 048ede1a
	v_fma_mixlo_f16 v180, s26, v106, v22                        ; cc2100b4 045ad41a
	v_fma_mixhi_f16 v180, s26, v107, v23                        ; cc2200b4 045ed61a
	v_fma_mixhi_f16 v179, s26, v105, v21                        ; cc2200b3 0456d21a
	v_fma_mixlo_f16 v181, s26, v108, v32                        ; cc2100b5 0482d81a
	v_fma_mixhi_f16 v181, s26, v109, v33                        ; cc2200b5 0486da1a
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[4:5], 0   ; cc464058 1a020910
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[6:7], 0 ; cc464068 1a020d10
(invalid instruction)                                        ; cc1c00b6
	v_subrev_f32_e32 v0, v182, v28                              ; 0a0039b6
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v28                              ; 0a0039b4
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v28                              ; 0a0039b3
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v28                              ; 0a0039b5
	ds_load_b64 v[16:17], v160 offset:1024                      ; d9d80400 100000a0
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[18:19], v[24:25], v[88:95] ; cc464058 1d623112
(invalid instruction)                                        ; cc1b00b6
	v_subrev_f32_e32 v0, v182, v27                              ; 0a0037b6
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[64:65], v[104:111] ; cc464068 1da28112
	ds_load_b64 v[18:19], v160 offset:1040                      ; d9d80410 120000a0
(invalid instruction)                                        ; cc1b00b4
	v_subrev_f32_e32 v0, v180, v27                              ; 0a0037b4
(invalid instruction)                                        ; cc1b00b3
	v_subrev_f32_e32 v0, v179, v27                              ; 0a0037b3
(invalid instruction)                                        ; cc1b00b5
	v_subrev_f32_e32 v0, v181, v27                              ; 0a0037b5
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v183, s26, v88, v28                         ; cc2100b7 0472b01a
	v_fma_mixlo_f16 v184, s26, v90, v30                         ; cc2100b8 047ab41a
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v186, s26, v94, v38                         ; cc2100ba 049abc1a
	v_fma_mixhi_f16 v186, s26, v95, v39                         ; cc2200ba 049ebe1a
	v_fma_mixlo_f16 v185, s26, v92, v36                         ; cc2100b9 0492b81a
	v_fma_mixhi_f16 v184, s26, v91, v31                         ; cc2200b8 047eb61a
	v_fma_mixhi_f16 v185, s26, v93, v37                         ; cc2200b9 0496ba1a
	v_fma_mixhi_f16 v183, s26, v89, v29                         ; cc2200b7 0476b21a
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v187, s26, v104, v44                        ; cc2100bb 04b2d01a
	v_fma_mixhi_f16 v187, s26, v105, v45                        ; cc2200bb 04b6d21a
	v_fma_mixlo_f16 v188, s26, v106, v46                        ; cc2100bc 04bad41a
	v_fma_mixhi_f16 v188, s26, v107, v47                        ; cc2200bc 04bed61a
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v28                              ; 0a0039ba
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v189, s26, v108, v96                        ; cc2100bd 0582d81a
	v_fma_mixhi_f16 v189, s26, v109, v97                        ; cc2200bd 0586da1a
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v28                              ; 0a0039b8
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v28                              ; 0a0039b9
	v_fma_mixlo_f16 v190, s26, v110, v98                        ; cc2100be 058adc1a
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v28                              ; 0a0039b7
	v_fma_mixhi_f16 v190, s26, v111, v99                        ; cc2200be 058ede1a
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v28                              ; 0a0039bb
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v28                              ; 0a0039bc
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[4:5], 0   ; cc464020 1a020910
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[6:7], 0   ; cc464028 1a020d10
(invalid instruction)                                        ; cc1b00ba
	v_subrev_f32_e32 v0, v186, v27                              ; 0a0037ba
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v28                              ; 0a0039bd
(invalid instruction)                                        ; cc1b00b8
	v_subrev_f32_e32 v0, v184, v27                              ; 0a0037b8
(invalid instruction)                                        ; cc1b00b9
	v_subrev_f32_e32 v0, v185, v27                              ; 0a0037b9
(invalid instruction)                                        ; cc1b00b7
	v_subrev_f32_e32 v0, v183, v27                              ; 0a0037b7
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v28                              ; 0a0039be
	ds_load_b64 v[16:17], v160 offset:1536                      ; d9d80600 100000a0
(invalid instruction)                                        ; cc1b00bb
	v_subrev_f32_e32 v0, v187, v27                              ; 0a0037bb
(invalid instruction)                                        ; cc1b00bc
	v_subrev_f32_e32 v0, v188, v27                              ; 0a0037bc
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[24:25], v[32:39] ; cc464020 1c823112
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[64:65], v[40:47] ; cc464028 1ca28112
	ds_load_b64 v[18:19], v160 offset:1552                      ; d9d80610 120000a0
(invalid instruction)                                        ; cc1b00bd
	v_subrev_f32_e32 v0, v189, v27                              ; 0a0037bd
(invalid instruction)                                        ; cc1b00be
	v_subrev_f32_e32 v0, v190, v27                              ; 0a0037be
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v20, s26, v38, v114                         ; cc210014 05ca4c1a
	v_fma_mixhi_f16 v20, s26, v39, v115                         ; cc220014 05ce4e1a
	v_fma_mixlo_f16 v13, s26, v36, v112                         ; cc21000d 05c2481a
	v_fma_mixhi_f16 v13, s26, v37, v113                         ; cc22000d 05c64a1a
	v_fma_mixlo_f16 v191, s26, v32, v100                        ; cc2100bf 0592401a
	v_fma_mixlo_f16 v2, s26, v34, v102                          ; cc210002 059a441a
	v_fma_mixhi_f16 v2, s26, v35, v103                          ; cc220002 059e461a
	v_fma_mixhi_f16 v191, s26, v33, v101                        ; cc2200bf 0596421a
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v28                               ; 0a003914
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v28                               ; 0a00390d
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c0002
	v_subrev_f32_e32 v0, v2, v28                                ; 0a003902
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v28                              ; 0a0039bf
(invalid instruction)                                        ; cc1b0014
	v_subrev_f32_e32 v0, v20, v27                               ; 0a003714
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v27                               ; 0a00370d
(invalid instruction)                                        ; cc1b0002
	v_subrev_f32_e32 v0, v2, v27                                ; 0a003702
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v27                              ; 0a0037bf
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v21, s26, v40, v56                          ; cc210015 04e2501a
	v_fma_mixhi_f16 v21, s26, v41, v57                          ; cc220015 04e6521a
	v_fma_mixlo_f16 v22, s26, v42, v58                          ; cc210016 04ea541a
	v_fma_mixhi_f16 v22, s26, v43, v59                          ; cc220016 04ee561a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v28, s26, v46, v62                          ; cc21001c 04fa5c1a
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[4:5], 0   ; cc464020 1a020910
	v_fma_mixlo_f16 v23, s26, v44, v60                          ; cc210017 04f2581a
	v_fma_mixhi_f16 v23, s26, v45, v61                          ; cc220017 04f65a1a
	v_fma_mixhi_f16 v28, s26, v47, v63                          ; cc22001c 04fe5e1a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[6:7], 0   ; cc464028 1a020d10
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v28                               ; 0a003915
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v28                               ; 0a003916
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v28                               ; 0a003917
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v28                               ; 0a00391c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[24:25], v[32:39] ; cc464020 1c823112
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v27                               ; 0a003715
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v27                               ; 0a003716
(invalid instruction)                                        ; cc1b0017
	v_subrev_f32_e32 v0, v23, v27                               ; 0a003717
(invalid instruction)                                        ; cc1b001c
	v_subrev_f32_e32 v0, v28, v27                               ; 0a00371c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[64:65], v[40:47] ; cc464028 1ca28112
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v29, s26, v32, v72                          ; cc21001d 0522401a
	v_fma_mixhi_f16 v29, s26, v33, v73                          ; cc22001d 0526421a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v31, s26, v36, v76                          ; cc21001f 0532481a
	v_fma_mixlo_f16 v32, s26, v38, v78                          ; cc210020 053a4c1a
	v_fma_mixhi_f16 v32, s26, v39, v79                          ; cc220020 053e4e1a
	v_fma_mixhi_f16 v31, s26, v37, v77                          ; cc22001f 05364a1a
	v_fma_mixlo_f16 v30, s26, v34, v74                          ; cc21001e 052a441a
	v_fma_mixhi_f16 v30, s26, v35, v75                          ; cc22001e 052e461a
(invalid instruction)                                        ; cc1c001d
	v_subrev_f32_e32 v0, v29, v28                               ; 0a00391d
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v28                               ; 0a003920
(invalid instruction)                                        ; cc1c001f
	v_subrev_f32_e32 v0, v31, v28                               ; 0a00391f
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v33, s26, v40, v68                          ; cc210021 0512501a
	v_fma_mixhi_f16 v33, s26, v41, v69                          ; cc220021 0516521a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v35, s26, v44, v80                          ; cc210023 0542581a
	v_fma_mixhi_f16 v35, s26, v45, v81                          ; cc220023 05465a1a
	v_fma_mixlo_f16 v34, s26, v42, v70                          ; cc210022 051a541a
	v_fma_mixhi_f16 v34, s26, v43, v71                          ; cc220022 051e561a
(invalid instruction)                                        ; cc1c001e
	v_subrev_f32_e32 v0, v30, v28                               ; 0a00391e
	v_fma_mixlo_f16 v36, s26, v46, v82                          ; cc210024 054a5c1a
(invalid instruction)                                        ; cc1b001d
	v_subrev_f32_e32 v0, v29, v27                               ; 0a00371d
	v_fma_mixhi_f16 v36, s26, v47, v83                          ; cc220024 054e5e1a
(invalid instruction)                                        ; cc1b0020
	v_subrev_f32_e32 v0, v32, v27                               ; 0a003720
(invalid instruction)                                        ; cc1b001f
	v_subrev_f32_e32 v0, v31, v27                               ; 0a00371f
	s_mov_b32 s30, 0x7ff88000                                   ; be9e00ff 7ff88000
(invalid instruction)                                        ; cc1c0021
	v_subrev_f32_e32 v0, v33, v28                               ; 0a003921
(invalid instruction)                                        ; cc1c0023
	v_subrev_f32_e32 v0, v35, v28                               ; 0a003923
(invalid instruction)                                        ; cc1c0022
	v_subrev_f32_e32 v0, v34, v28                               ; 0a003922
(invalid instruction)                                        ; cc1b001e
	v_subrev_f32_e32 v0, v30, v27                               ; 0a00371e
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v28                               ; 0a003924
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v183, v183, 5, s30                           ; d64600b7 00790bb7
	v_lshl_add_u32 v175, v175, 5, s30                           ; d64600af 00790baf
	v_lshl_add_u32 v29, v29, 5, s30                             ; d646001d 00790b1d
	v_lshl_add_u32 v176, v176, 5, s30                           ; d64600b0 00790bb0
	v_lshl_add_u32 v184, v184, 5, s30                           ; d64600b8 00790bb8
	v_lshl_add_u32 v191, v191, 5, s30                           ; d64600bf 00790bbf
	v_lshl_add_u32 v2, v2, 5, s30                               ; d6460002 00790b02
(invalid instruction)                                        ; cc1b0021
	v_subrev_f32_e32 v0, v33, v27                               ; 0a003721
(invalid instruction)                                        ; cc1b0023
	v_subrev_f32_e32 v0, v35, v27                               ; 0a003723
(invalid instruction)                                        ; cc1b0022
	v_subrev_f32_e32 v0, v34, v27                               ; 0a003722
	v_lshl_add_u32 v177, v177, 5, s30                           ; d64600b1 00790bb1
	v_lshl_add_u32 v30, v30, 5, s30                             ; d646001e 00790b1e
	v_lshl_add_u32 v185, v185, 5, s30                           ; d64600b9 00790bb9
(invalid instruction)                                        ; cc1b0024
	v_subrev_f32_e32 v0, v36, v27                               ; 0a003724
	v_add_lshl_u32 v0, s9, v0, 2                                ; d6470000 020a0009
	v_lshl_add_u32 v13, v13, 5, s30                             ; d646000d 00790b0d
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[4:7], v0, s[20:23], null offen           ; c405c07c 40802804 00000000
	buffer_load_b128 v[16:19], v0, s[20:23], null offen offset:16 ; c405c07c 40802810 00001000
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[175:176], v[183:184]            ; 1a036faf
	v_lshl_add_u32 v31, v31, 5, s30                             ; d646001f 00790b1f
	v_lshl_add_u32 v178, v178, 5, s30                           ; d64600b2 00790bb2
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[176:177], v[184:185]            ; 1a0371b0
	v_lshl_add_u32 v186, v186, 5, s30                           ; d64600ba 00790bba
	v_lshl_add_u32 v20, v20, 5, s30                             ; d6460014 00790b14
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[177:178], v[185:186]            ; 1a0373b1
	v_lshl_add_u32 v32, v32, 5, s30                             ; d6460020 00790b20
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[191:192]              ; 1a037f25
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[2:3]                  ; 1a020526
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[178:179], v[186:187]            ; 1a0375b2
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[13:14]                ; 1a021b27
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[29:30]                ; 1a023b25
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[30:31]                ; 1a023d26
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[40:41], v[20:21]                ; 1a022928
	s_lshr_b32 s6, s6, 2                                        ; 85068206
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[31:32]                ; 1a023f27
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v12, s6, v12, 2                              ; d647000c 020a1806
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[38:39]                ; 1a024d25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[39:40]                ; 1a024f25
	buffer_load_b64 v[38:39], v12, s[52:55], null offen         ; c405407c 40806826 0000000c
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[40:41], v[32:33]                ; 1a024128
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[40:41]                ; 1a025125
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v41, v37, s24, s25 op_sel:[1,1]           ; d65c1829 00643125
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[41:42]                ; 1a025325
	buffer_load_b64 v[40:41], v12, s[52:55], null offen offset:512 ; c405407c 40806828 0002000c
	v_add_f16_e32 v42, v37, v165/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64554b25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v42, 0x400, v42                           ; 625454ff 00000400
	v_cvt_f32_f16_e32 v43, v42                                  ; 7e56172a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v43, v43                                      ; 7e56552b
	v_fma_mix_f32 v46, v177, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002e 8a0257b1
	v_fma_mix_f32 v57, v184, v43, neg(0) op_sel_hi:[1,0,0]      ; cc200039 8a0257b8
	v_fma_mix_f32 v177, v177, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a0257b1
	v_fma_mix_f32 v45, v176, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002d 8a0257b0
	v_fma_mix_f32 v47, v178, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002f 8a0257b2
	v_fma_mix_f32 v176, v176, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a0257b0
	v_fma_mix_f32 v56, v183, v43, neg(0) op_sel_hi:[1,0,0]      ; cc200038 8a0257b7
	v_fma_mix_f32 v183, v183, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a0257b7
	v_fma_mix_f32 v178, v178, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a0257b2
	v_fma_mix_f32 v44, v175, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002c 8a0257af
	v_fma_mix_f32 v175, v175, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a0257af
	v_fma_mix_f32 v184, v184, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a0257b8
	v_fma_mix_f32 v58, v185, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003a 8a0257b9
	v_fma_mix_f32 v185, v185, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a0257b9
	v_fma_mix_f32 v59, v186, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003b 8a0257ba
	v_fma_mix_f32 v186, v186, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a0257ba
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v46, v177, vcc_lo                     ; 0203632e
	v_fma_mix_f32 v60, v191, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a0257bf
	v_fma_mix_f32 v191, v191, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a0257bf
	v_fma_mix_f32 v61, v2, v43, neg(0) op_sel_hi:[1,0,0]        ; cc20003d 8a025702
	v_fma_mix_f32 v2, v2, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200802 8a025702
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v47, v178, vcc_lo                     ; 0203652f
	v_fma_mix_f32 v62, v13, v43, neg(0) op_sel_hi:[1,0,0]       ; cc20003e 8a02570d
	v_fma_mix_f32 v13, v13, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080d 8a02570d
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v44, v175, vcc_lo                     ; 02035f2c
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v45, v176, vcc_lo                     ; 0203612d
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v56, v183, vcc_lo                     ; 02036f38
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v57, v184, vcc_lo                     ; 02037139
	v_fma_mix_f32 v63, v20, v43, neg(0) op_sel_hi:[1,0,0]       ; cc20003f 8a025714
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v58, v185, vcc_lo                     ; 0203733a
	v_fma_mix_f32 v20, v20, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a025714
	v_fma_mix_f32 v64, v29, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200040 8a02571d
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v59, v186, vcc_lo                     ; 0203753b
	v_fma_mix_f32 v29, v29, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081d 8a02571d
	v_fma_mix_f32 v65, v30, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200041 8a02571e
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v60, v191, vcc_lo                     ; 02037f3c
	v_fma_mix_f32 v30, v30, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081e 8a02571e
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v61, v2, vcc_lo                       ; 0202053d
	v_fma_mix_f32 v66, v31, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200042 8a02571f
	v_fma_mix_f32 v31, v31, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081f 8a02571f
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v62, v13, vcc_lo                      ; 02021b3e
	v_fma_mix_f32 v67, v32, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200043 8a025720
	v_fma_mix_f32 v32, v32, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a025720
	v_lshl_add_u32 v179, v179, 5, s30                           ; d64600b3 00790bb3
	v_lshl_add_u32 v187, v187, 5, s30                           ; d64600bb 00790bbb
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v63, v20, vcc_lo                      ; 0202293f
	v_lshl_add_u32 v21, v21, 5, s30                             ; d6460015 00790b15
	v_lshl_add_u32 v33, v33, 5, s30                             ; d6460021 00790b21
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v64, v29, vcc_lo                      ; 02023b40
	v_lshl_add_u32 v180, v180, 5, s30                           ; d64600b4 00790bb4
	v_lshl_add_u32 v188, v188, 5, s30                           ; d64600bc 00790bbc
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v65, v30, vcc_lo                      ; 02023d41
	v_lshl_add_u32 v22, v22, 5, s30                             ; d6460016 00790b16
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v66, v31, vcc_lo                      ; 02023f42
	v_lshl_add_u32 v34, v34, 5, s30                             ; d6460022 00790b22
	v_lshl_add_u32 v181, v181, 5, s30                           ; d64600b5 00790bb5
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v67, v32, vcc_lo                      ; 02024143
	v_lshl_add_u32 v189, v189, 5, s30                           ; d64600bd 00790bbd
	v_lshl_add_u32 v23, v23, 5, s30                             ; d6460017 00790b17
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[179:180], v[187:188]            ; 1a0377b3
	v_lshl_add_u32 v35, v35, 5, s30                             ; d6460023 00790b23
	v_lshl_add_u32 v182, v182, 5, s30                           ; d64600b6 00790bb6
	v_lshl_add_u32 v190, v190, 5, s30                           ; d64600be 00790bbe
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[180:181], v[188:189]            ; 1a0379b4
	v_lshl_add_u32 v28, v28, 5, s30                             ; d646001c 00790b1c
	v_lshl_add_u32 v36, v36, 5, s30                             ; d6460024 00790b24
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[181:182], v[189:190]            ; 1a037bb5
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[21:22]                ; 1a022b44
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[182:183], v[190:191]            ; 1a037db6
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[22:23]                ; 1a022d45
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[23:24]                ; 1a022f46
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[33:34]                ; 1a024344
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[28:29]                ; 1a023947
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[34:35]                ; 1a024545
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[35:36]                ; 1a024746
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[36:37]                ; 1a024947
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[69:70]                ; 1a028b44
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[70:71]                ; 1a028d44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[71:72]                ; 1a028f44
	v_permlanex16_b32 v72, v68, s24, s25 op_sel:[1,1]           ; d65c1848 00643144
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[72:73]                ; 1a029144
	v_add_f16_e32 v73, v68, v196/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64938944
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v73, 0x400, v73                           ; 629292ff 00000400
	v_cvt_f32_f16_e32 v74, v73                                  ; 7e941749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v74, v74                                      ; 7e94554a
	v_fma_mix_f32 v83, v21, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200053 8a029515
	v_fma_mix_f32 v85, v23, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200055 8a029517
	v_fma_mix_f32 v23, v23, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a029517
	v_fma_mix_f32 v75, v179, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004b 8a0295b3
	v_fma_mix_f32 v179, v179, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a0295b3
	v_fma_mix_f32 v76, v180, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004c 8a0295b4
	v_fma_mix_f32 v86, v28, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200056 8a02951c
	v_fma_mix_f32 v28, v28, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a02951c
	v_fma_mix_f32 v180, v180, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a0295b4
	v_fma_mix_f32 v21, v21, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a029515
	v_fma_mix_f32 v77, v181, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004d 8a0295b5
	v_fma_mix_f32 v181, v181, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a0295b5
	v_fma_mix_f32 v78, v182, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004e 8a0295b6
	v_fma_mix_f32 v182, v182, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a0295b6
	v_fma_mix_f32 v79, v187, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004f 8a0295bb
	v_fma_mix_f32 v187, v187, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a0295bb
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v75, v179, vcc_lo                     ; 0203674b
	v_fma_mix_f32 v80, v188, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200050 8a0295bc
	v_fma_mix_f32 v188, v188, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a0295bc
	v_fma_mix_f32 v81, v189, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200051 8a0295bd
	v_fma_mix_f32 v189, v189, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a0295bd
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v76, v180, vcc_lo                     ; 0203694c
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v83, v21, vcc_lo                      ; 02022b53
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v85, v23, vcc_lo                      ; 02022f55
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v86, v28, vcc_lo                      ; 02023956
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	v_fma_mix_f32 v82, v190, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200052 8a0295be
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v77, v181, vcc_lo                     ; 02036b4d
	v_fma_mix_f32 v190, v190, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a0295be
	v_fma_mix_f32 v84, v22, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200054 8a029516
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v78, v182, vcc_lo                     ; 02036d4e
	v_fma_mix_f32 v22, v22, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a029516
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v79, v187, vcc_lo                     ; 0203774f
	v_fma_mix_f32 v87, v33, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200057 8a029521
	v_fma_mix_f32 v33, v33, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200821 8a029521
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v80, v188, vcc_lo                     ; 02037950
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v81, v189, vcc_lo                     ; 02037b51
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[28:29], v[24:25], 0 ; cc464040 1a02311c
	v_fma_mix_f32 v88, v34, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200058 8a029522
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v82, v190, vcc_lo                     ; 02037d52
	v_fma_mix_f32 v34, v34, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200822 8a029522
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v84, v22, vcc_lo                      ; 02022d54
	v_fma_mix_f32 v89, v35, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200059 8a029523
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v87, v33, vcc_lo                      ; 02024357
	v_fma_mix_f32 v35, v35, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200823 8a029523
	v_fma_mix_f32 v90, v36, v74, neg(0) op_sel_hi:[1,0,0]       ; cc20005a 8a029524
	v_fma_mix_f32 v36, v36, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200824 8a029524
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[30:31], 0 ; cc464048 1a023d1c
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v88, v34, vcc_lo                      ; 02024558
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v89, v35, vcc_lo                      ; 02024759
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[28:29], v[44:45], v[64:71] ; cc464040 1d02591c
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v90, v36, vcc_lo                      ; 0202495a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[42:43], v[72:79] ; cc464048 1d22551c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[14:15], v[46:47], v[64:71] ; cc464050 1d025d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[46:47], v[64:71] ; cc464040 1d025d08
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v59, v131, v7 :: v_dual_mul_f32 v58, v130, v6 ; c8c60f83 3b3a0d82
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v63, v135, v19 :: v_dual_mul_f32 v62, v134, v18 ; c8c62787 3f3e2586
	v_dual_mul_f32 v61, v133, v17 :: v_dual_mul_f32 v60, v132, v16 ; c8c62385 3d3c2184
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[14:15], v[20:21], v[72:79] ; cc464058 1d22290e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[20:21], v[72:79] ; cc464048 1d222908
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[26:27], v[56:57], v[80:87] ; cc464050 1d42711a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[10:11], v[56:57], v[64:71] ; cc464040 1d02710a
	v_dual_mul_f32 v57, v129, v5 :: v_dual_mul_f32 v56, v128, v4 ; c8c60b81 39380980
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[26:27], v[22:23], v[88:95] ; cc464058 1d622d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[10:11], v[22:23], v[72:79] ; cc464048 1d222d0a
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_dual_mul_f32 v69, v149, v17 :: v_dual_mul_f32 v68, v148, v16 ; c8c62395 45442194
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_dual_mul_f32 v65, v145, v5 :: v_dual_mul_f32 v64, v144, v4 ; c8c60b91 41400990
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v67, v147, v7 :: v_dual_mul_f32 v66, v146, v6 ; c8c60f93 43420d92
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_dual_mul_f32 v71, v151, v19 :: v_dual_mul_f32 v70, v150, v18 ; c8c62797 47462596
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[38:39], v[14:15], v[56:63] ; cc464038 1ce21d26
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_cmp_lg_i32 s35, 0                                         ; bf018023
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[38:39], v[24:25], v[64:71] ; cc464040 1d023126
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[40:41], v[8:9], v[56:63] ; cc464038 1ce21128
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[40:41], v[10:11], v[64:71] ; cc464040 1d021528
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_cbranch_scc1 BB24                                         ; bfa20007
BB22:
	v_add3_u32 v2, v3, s2, s13                                  ; d6550002 00340503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[4:5], v2, s[16:19], null offen           ; c406c07c 40802004 00000002
BB24:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_lg_i32 s40, 0                                         ; bf018028
	s_cbranch_scc1 BB27                                         ; bfa20007
BB25:
	v_add3_u32 v2, v3, s2, s29                                  ; d6550002 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[4:5], v2, s[16:19], null offen           ; c406c07c 40802004 00000002
BB27:
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[4:7], v0, s[20:23], null offen offset:64 ; c405c07c 40802804 00004000
	buffer_load_b128 v[16:19], v0, s[20:23], null offen offset:80 ; c405c07c 40802810 00005000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[20:21], v12, s[52:55], null offen offset:8 ; c405407c 40806814 0000080c
	buffer_load_b64 v[12:13], v12, s[52:55], null offen offset:520 ; c405407c 4080680c 0002080c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v33, v153, v5 :: v_dual_mul_f32 v32, v152, v4 ; c8c60b99 21200998
	v_dual_mul_f32 v35, v155, v7 :: v_dual_mul_f32 v34, v154, v6 ; c8c60f9b 23220d9a
	v_dual_mul_f32 v41, v49, v5 :: v_dual_mul_f32 v40, v48, v4  ; c8c60b31 29280930
	v_dual_mul_f32 v43, v51, v7 :: v_dual_mul_f32 v42, v50, v6  ; c8c60f33 2b2a0d32
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v37, v157, v17 :: v_dual_mul_f32 v36, v156, v16 ; c8c6239d 2524219c
	v_dual_mul_f32 v39, v159, v19 :: v_dual_mul_f32 v38, v158, v18 ; c8c6279f 2726259e
	v_dual_mul_f32 v45, v53, v17 :: v_dual_mul_f32 v44, v52, v16 ; c8c62335 2d2c2134
	v_dual_mul_f32 v47, v55, v19 :: v_dual_mul_f32 v46, v54, v18 ; c8c62737 2f2e2536
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[20:21], v[14:15], v[32:39] ; cc464020 1c821d14
	s_mov_b32 s0, vcc_lo                                        ; be80006a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[20:21], v[24:25], v[40:47] ; cc464028 1ca23114
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[12:13], v[8:9], v[32:39] ; cc464020 1c82110c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[10:11], v[40:47] ; cc464028 1ca2150c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_cbranch_scc1 BB30                                         ; bfa20009
BB28:
	s_add_co_u32 s1, s2, 0x100                                  ; 8001ff02 00000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	v_add3_u32 v0, v3, s1, s13                                  ; d6550000 00340303
	v_add_nc_u32_e32 v0, v0, v1                                 ; 4a000300
	buffer_store_b64 v[4:5], v0, s[16:19], null offen           ; c406c07c 40802004 00000000
BB30:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB78                                         ; bfa22275
BB31:
	s_addk_co_i32 s2, 0x100                                     ; b7820100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v3, v3, s2, s29                                  ; d6550003 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	buffer_store_b64 v[4:5], v3, s[16:19], null offen           ; c406c07c 40802004 00000003
	s_branch BB78                                               ; bfa0226b
BB34:
	s_cmp_eq_i32 s17, 3                                         ; bf008311
	s_cbranch_scc0 BB48                                         ; bfa10b73
BB35:
	s_mov_b32 s15, s1                                           ; be8f0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[32:35], s[0:1], 0x0                           ; f4004800 f8000000
	s_load_b256 s[40:47], s[0:1], 0x30                          ; f4006a00 f8000030
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_max_i32 s13, s13, 0                                       ; 8a0d800d
	s_add_co_u32 s17, s11, -1                                   ; 8011c10b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s13, s13, s17                                     ; 890d110d
	s_max_i32 s14, s14, 0                                       ; 8a0e800e
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	s_min_i32 s14, s14, s12                                     ; 890e0c0e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s14, s14, s11                                     ; 960e0b0e
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_add_co_u32 s13, s14, s13                                  ; 800d0d0e
	s_lshl_b32 s13, s13, 9                                      ; 840d890d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s18, s15, s13                                  ; 80120d0f
	s_max_i32 s20, s20, 0                                       ; 8a148014
	v_add3_u32 v5, v3, s18, 0x100                               ; d6550005 03fc2503 00000100
	v_add3_u32 v4, v1, s18, v3                                  ; d6550004 040c2501
	s_min_i32 s20, s20, s17                                     ; 89141114
	s_add_co_u32 s14, s14, s20                                  ; 800e140e
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_lshl_b32 s14, s14, 9                                      ; 840e890e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s15, s15, s14                                  ; 800f0e0f
	v_add3_u32 v7, v3, s15, 0x100                               ; d6550007 03fc1f03 00000100
	v_add3_u32 v6, v1, s15, v3                                  ; d6550006 040c1f01
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[8:9], v4, s[32:35], null offen            ; c405407c 40804008 00000004
	buffer_load_b64 v[4:5], v5, s[32:35], null offen            ; c405407c 40804004 00000005
	buffer_load_b64 v[10:11], v6, s[32:35], null offen          ; c405407c 4080400a 00000006
	buffer_load_b64 v[6:7], v7, s[32:35], null offen            ; c405407c 40804006 00000007
	v_lshlrev_b32_e32 v12, 2, v0                                ; 30180082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v13, s3, v12, 2                              ; d647000d 020a1803
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[16:19], v13, s[44:47], null offen        ; c405c07c 40805810 0000000d
	buffer_load_b128 v[20:23], v13, s[44:47], null offen offset:512 ; c405c07c 40805814 0002000d
	buffer_load_b128 v[24:27], v13, s[44:47], null offen offset:1024 ; c405c07c 40805818 0004000d
	buffer_load_b128 v[28:31], v13, s[44:47], null offen offset:1536 ; c405c07c 4080581c 0006000d
	buffer_load_b128 v[32:35], v13, s[44:47], null offen offset:2048 ; c405c07c 40805820 0008000d
	buffer_load_b128 v[36:39], v13, s[44:47], null offen offset:2560 ; c405c07c 40805824 000a000d
	buffer_load_b128 v[40:43], v13, s[44:47], null offen offset:3072 ; c405c07c 40805828 000c000d
	buffer_load_b128 v[44:47], v13, s[44:47], null offen offset:3584 ; c405c07c 4080582c 000e000d
	v_lshrrev_b32_e32 v0, 4, v0                                 ; 32000084
	s_mov_b64 s[36:37], s[40:41]                                ; bea40128
	s_mov_b64 s[38:39], s[42:43]                                ; bea6012a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshlrev_b32_e32 v0, 3, v0                                 ; 30000083
	v_add_lshl_u32 v14, s8, v0, 2                               ; d647000e 020a0008
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v14, s[36:39], null offen        ; c405c07c 40804830 0000000e
	buffer_load_b128 v[52:55], v14, s[36:39], null offen offset:16 ; c405c07c 40804834 0000100e
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add_lshl_u32 v15, s4, v12, 2                              ; d647000f 020a1804
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[56:59], v15, s[44:47], null offen        ; c405c07c 40805838 0000000f
	buffer_load_b128 v[60:63], v15, s[44:47], null offen offset:512 ; c405c07c 4080583c 0002000f
	buffer_load_b128 v[64:67], v15, s[44:47], null offen offset:1024 ; c405c07c 40805840 0004000f
	buffer_load_b128 v[68:71], v15, s[44:47], null offen offset:1536 ; c405c07c 40805844 0006000f
	buffer_load_b128 v[72:75], v15, s[44:47], null offen offset:2048 ; c405c07c 40805848 0008000f
	buffer_load_b128 v[76:79], v15, s[44:47], null offen offset:2560 ; c405c07c 4080584c 000a000f
	buffer_load_b128 v[80:83], v15, s[44:47], null offen offset:3072 ; c405c07c 40805850 000c000f
	buffer_load_b128 v[84:87], v15, s[44:47], null offen offset:3584 ; c405c07c 40805854 000e000f
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_cndmask_b32_e64 v8, v8, 0, s16                            ; d5010008 00410108
	v_cndmask_b32_e64 v9, v9, 0, s16                            ; d5010009 00410109
	s_wait_loadcnt 0x14                                         ; bfc00014
	v_cndmask_b32_e64 v5, v5, 0, s16                            ; d5010005 00410105
	v_cndmask_b32_e64 v4, v4, 0, s16                            ; d5010004 00410104
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_cndmask_b32_e64 v10, v10, 0, s22                          ; d501000a 0059010a
	v_cndmask_b32_e64 v11, v11, 0, s22                          ; d501000b 0059010b
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v7, v7, 0, s22                            ; d5010007 00590107
	v_cndmask_b32_e64 v6, v6, 0, s22                            ; d5010006 00590106
	v_cvt_pk_f32_fp8_e32 v[92:93], v136                         ; 7eb8dd88
	v_cvt_pk_f32_fp8_e32 v[90:91], v8                           ; 7eb4dd08
	v_dual_mov_b32 v89, v9 :: v_dual_mov_b32 v88, v8            ; ca100109 59580108
	v_cvt_pk_f32_fp8_e32 v[94:95], v9                           ; 7ebcdd09
	v_cvt_pk_f32_fp8_e32 v[8:9], v137                           ; 7e10dd89
	v_dual_mov_b32 v97, v5 :: v_dual_mov_b32 v96, v4            ; ca100105 61600104
	v_cvt_pk_f32_fp8_e32 v[100:101], v10                        ; 7ec8dd0a
	v_dual_mov_b32 v99, v11 :: v_dual_mov_b32 v98, v10          ; ca10010b 6362010a
	v_cvt_pk_f32_fp8_e32 v[102:103], v138                       ; 7eccdd8a
	v_cvt_pk_f32_fp8_e32 v[104:105], v11                        ; 7ed0dd0b
	v_dual_mov_b32 v107, v7 :: v_dual_mov_b32 v106, v6          ; ca100107 6b6a0106
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[88:89], 0 ; cc464070 1a02b110
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[88:89], 0 ; cc464080 1a02b112
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[98:99], 0 ; cc464078 1a02c510
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[98:99], 0 ; cc464088 1a02c512
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[96:97], v[112:119] ; cc464070 1dc2c114
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[20:21], v[106:107], v[120:127] ; cc464078 1de2d514
	v_maxmin_num_f32 v110, -4.0, v116, 4.0                      ; d669006e 03dae8f7
	v_maxmin_num_f32 v20, -4.0, v114, 4.0                       ; d6690014 03dae4f7
	v_maxmin_num_f32 v108, -4.0, v115, 4.0                      ; d669006c 03dae6f7
	v_maxmin_num_f32 v18, -4.0, v113, 4.0                       ; d6690012 03dae2f7
	v_maxmin_num_f32 v16, -4.0, v112, 4.0                       ; d6690010 03dae0f7
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v21, 0xab28, |v20|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfe28ff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v19, 0xab28, |v18|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206213 0bfe24ff 3728ab28
	v_fma_mix_f32 v17, 0xab28, |v16|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206211 0bfe20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fmaak_f32 v109, v109, v108, 0x3f650000                    ; 5adad96d 3f650000
	v_dual_fmaak_f32 v19, v19, v18, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v17, 0x3f650000 ; c8422513 13102310 3f650000
	v_maxmin_num_f32 v144, -4.0, v121, 4.0                      ; d6690090 03daf2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_mul_f32 v115, v109, v115 :: v_dual_fmaak_f32 v20, v20, v21, 0x3f650000 ; c8c2e76d 73142b14 3f650000
	v_dual_mul_f32 v113, v113, v19 :: v_dual_mul_f32 v112, v112, v16 ; c8c62771 71702170
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v117, 4.0                      ; d6690070 03daeaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v123, 4.0                      ; d6690094 03daf6f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v122, 4.0                      ; d6690092 03daf4f7
	v_dual_mul_f32 v117, v117, v113 :: v_dual_mul_f32 v116, v116, v110 ; c8c6e375 7574dd74
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v125, 4.0                      ; d6690098 03dafaf7
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v116, -4.0, v119, 4.0                      ; d6690074 03daeef7
	v_maxmin_num_f32 v150, -4.0, v124, 4.0                      ; d6690096 03daf8f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v127, 4.0                      ; d669009c 03dafef7
	v_dual_fmaak_f32 v117, v116, v117, 0x3f650000 :: v_dual_mul_f32 v114, v114, v20 ; c846eb74 75722972 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v126, 4.0                      ; d669009a 03dafcf7
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v118, 4.0                      ; d6690072 03daecf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[96:97], v[128:135] ; cc464080 1e02c116
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_dual_mul_f32 v119, v119, v117 :: v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 ; c8c2eb77 7772e772 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v118, v118, v114 ; c8472191 9176e576 3f650000
	v_maxmin_num_f32 v160, -4.0, v129, 4.0                      ; d66900a0 03db02f7
	v_maxmin_num_f32 v158, -4.0, v128, 4.0                      ; d669009e 03db00f7
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v120, 4.0                      ; d6690076 03daf0f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v131, 4.0                      ; d66900a4 03db06f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v130, 4.0                      ; d66900a2 03db04f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_mul_f32 v121, v121, v145 :: v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 ; c8c32379 7976ef76 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[106:107], v[136:143] ; cc464088 1e22d516
	v_maxmin_num_f32 v168, -4.0, v133, 4.0                      ; d66900a8 03db0af7
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v120, v120, v118 ; c8472995 9578ed78 3f650000
	v_maxmin_num_f32 v166, -4.0, v132, 4.0                      ; d66900a6 03db08f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d3
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v123, v123, v149 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8c32b7b 7b932792 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v135, 4.0                      ; d66900ac 03db0ef7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v122, v122, v146 ; c8473199 997b257a 3f650000
	v_maxmin_num_f32 v170, -4.0, v134, 4.0                      ; d66900aa 03db0cf7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v125, v125, v153 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8c3337d 7d972f96 3f650000
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v137, 4.0                      ; d66900b0 03db12f7
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v124, v124, v150 ; c847399d 9d7d2d7c 3f650000
	v_maxmin_num_f32 v174, -4.0, v136, 4.0                      ; d66900ae 03db10f7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_mul_f32 v127, v127, v157 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8c33b7f 7f9b379a 3f650000
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v139, 4.0                      ; d66900b4 03db16f7
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_mul_f32 v126, v126, v154 ; c84741a1 a17f357e 3f650000
	v_maxmin_num_f32 v178, -4.0, v138, 4.0                      ; d66900b2 03db14f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v129, v129, v161 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c8c34381 819f3f9e 3f650000
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v141, 4.0                      ; d66900b8 03db1af7
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_mul_f32 v128, v128, v158 ; c84749a5 a5813d80 3f650000
	v_maxmin_num_f32 v182, -4.0, v140, 4.0                      ; d66900b6 03db18f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v131, v131, v165 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8c34b83 83a347a2 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v143, 4.0                      ; d66900bc 03db1ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_mul_f32 v130, v130, v162 ; c84751a9 a9834582 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[88:89], 0 ; cc464070 1a02b118
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v133, v133, v169 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c8c35385 85a74fa6 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v132, v132, v166 ; c84759ad ad854d84 3f650000
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[96:97], v[112:119] ; cc464070 1dc2c11c
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v135, v135, v173 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8c35b87 87ab57aa 3f650000
	v_maxmin_num_f32 v186, -4.0, v142, 4.0                      ; d66900ba 03db1cf7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_mul_f32 v134, v134, v170 ; c84761b1 b1875586 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v112, 4.0                      ; d66900be 03dae0f7
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v137, v137, v177 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c8c36389 89af5fae 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[98:99], 0 ; cc464078 1a02c518
	v_maxmin_num_f32 v15, -4.0, v114, 4.0                       ; d669000f 03dae4f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v136, v136, v174 ; c84769b5 b5895d88 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v25, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe1eff 3728ab28
	v_dual_mul_f32 v139, v139, v181 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c8c36b8b 8bb367b2 3f650000
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fmaak_f32 v15, v15, v25, 0x3f650000                       ; 5a1e330f 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[106:107], v[120:127] ; cc464078 1de2d51c
	v_maxmin_num_f32 v28, -4.0, v115, 4.0                       ; d669001c 03dae6f7
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_mul_f32 v138, v138, v178 ; c84771b9 b98b658a 3f650000
	v_maxmin_num_f32 v108, -4.0, v116, 4.0                      ; d669006c 03dae8f7
	v_maxmin_num_f32 v110, -4.0, v117, 4.0                      ; d669006e 03daeaf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v141, v141, v185 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c8c3738d 8db76fb6 3f650000
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v140, v140, v182 ; c84779bd bd8d6d8c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b8f 8fbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v113, 4.0                      ; d66900bf 03dae2f7
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v108 ; c8c6df75 7574d974
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 :: v_dual_mul_f32 v112, v112, v190 ; c846391d 1d717d70 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v115, v115, v29 :: v_dual_mul_f32 v114, v114, v15 ; c8c63b73 73721f72
	v_dual_fmaak_f32 v13, v191, v13, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8421bbf 0dbb77ba 3f650000
	v_maxmin_num_f32 v116, -4.0, v120, 4.0                      ; d6690074 03daf0f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v113, v113, v13 :: v_dual_mul_f32 v142, v142, v186 ; c8c61b71 718f758e
	v_maxmin_num_f32 v128, -4.0, v123, 4.0                      ; d6690080 03daf6f7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v118, 4.0                      ; d6690070 03daecf7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v119, 4.0                      ; d6690072 03daeef7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v125, 4.0                      ; d6690084 03dafaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v124, 4.0                      ; d6690082 03daf8f7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c8430181 8174eb74 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v127, 4.0                      ; d6690088 03dafef7
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_mul_f32 v123, v123, v129 :: v_dual_mul_f32 v120, v120, v116 ; c8c7037b 7b78e978
	v_maxmin_num_f32 v134, -4.0, v126, 4.0                      ; d6690086 03dafcf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v119, v119, v115 :: v_dual_mul_f32 v118, v118, v112 ; c8c6e777 7776e176
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8431189 89830782 3f650000
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v121, 4.0                      ; d6690076 03daf2f7
	v_dual_mul_f32 v127, v127, v137 :: v_dual_mul_f32 v124, v124, v130 ; c8c7137f 7f7d057c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fmaak_f32 v119, v119, v118, 0x3f650000                    ; 5aeeed77 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_mul_f32_e32 v121, v121, v119                              ; 10f2ef79
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[88:89], 0 ; cc464070 1a02b11a
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v122, 4.0                      ; d6690078 03daf4f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[96:97], v[112:119] ; cc464070 1dc2c11e
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8430985 8578f378 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v125, v125, v133 :: v_dual_mul_f32 v122, v122, v120 ; c8c70b7d 7d7af17a
	v_maxmin_num_f32 v140, -4.0, v113, 4.0                      ; d669008c 03dae2f7
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v144, -4.0, v115, 4.0                      ; d6690090 03dae6f7
	v_maxmin_num_f32 v138, -4.0, v112, 4.0                      ; d669008a 03dae0f7
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v142, -4.0, v114, 4.0                      ; d669008e 03dae4f7
	v_maxmin_num_f32 v148, -4.0, v117, 4.0                      ; d6690094 03daeaf7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v116, 4.0                      ; d6690092 03dae8f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v119, 4.0                      ; d6690098 03daeef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c843198d 8d870f86 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v118, 4.0                      ; d6690096 03daecf7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c8432191 918b178a 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432995 958f1f8e 3f650000
	v_dual_mul_f32 v113, v113, v141 :: v_dual_mul_f32 v126, v126, v134 ; c8c71b71 717f0d7e
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8433199 99932792 3f650000
	v_dual_mul_f32 v115, v115, v145 :: v_dual_mul_f32 v112, v112, v138 ; c8c72373 73711570
	v_dual_mul_f32 v117, v117, v149 :: v_dual_mul_f32 v114, v114, v142 ; c8c72b75 75731d72
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[98:99], 0 ; cc464078 1a02c51a
	v_dual_mul_f32 v119, v119, v153 :: v_dual_mul_f32 v116, v116, v146 ; c8c73377 77752574
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[106:107], v[120:127] ; cc464078 1de2d51e
	v_maxmin_num_f32 v164, -4.0, v125, 4.0                      ; d66900a4 03dafaf7
	v_maxmin_num_f32 v160, -4.0, v123, 4.0                      ; d66900a0 03daf6f7
	v_maxmin_num_f32 v154, -4.0, v120, 4.0                      ; d669009a 03daf0f7
	v_maxmin_num_f32 v156, -4.0, v121, 4.0                      ; d669009c 03daf2f7
	v_maxmin_num_f32 v158, -4.0, v122, 4.0                      ; d669009e 03daf4f7
	v_maxmin_num_f32 v162, -4.0, v124, 4.0                      ; d66900a2 03daf8f7
	v_maxmin_num_f32 v168, -4.0, v127, 4.0                      ; d66900a8 03dafef7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v126, 4.0                      ; d66900a6 03dafcf7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c84341a1 a19b379a 3f650000
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c843399d 9d972f96 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84349a5 a59f3f9e 3f650000
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84351a9 a9a347a2 3f650000
	v_dual_mul_f32 v123, v123, v161 :: v_dual_mul_f32 v120, v120, v154 ; c8c7437b 7b793578
	v_dual_mul_f32 v121, v121, v157 :: v_dual_mul_f32 v118, v118, v150 ; c8c73b79 79772d76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_mul_f32 v125, v125, v165 :: v_dual_mul_f32 v122, v122, v158 ; c8c74b7d 7d7b3d7a
	v_dual_mul_f32 v127, v127, v169 :: v_dual_mul_f32 v124, v124, v162 ; c8c7537f 7f7d457c
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[88:89], 0 ; cc464070 1a02b120
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[96:97], v[112:119] ; cc464070 1dc2c124
	v_maxmin_num_f32 v176, -4.0, v115, 4.0                      ; d66900b0 03dae6f7
	v_maxmin_num_f32 v174, -4.0, v114, 4.0                      ; d66900ae 03dae4f7
	v_maxmin_num_f32 v172, -4.0, v113, 4.0                      ; d66900ac 03dae2f7
	v_maxmin_num_f32 v170, -4.0, v112, 4.0                      ; d66900aa 03dae0f7
	v_maxmin_num_f32 v180, -4.0, v117, 4.0                      ; d66900b4 03daeaf7
	v_maxmin_num_f32 v178, -4.0, v116, 4.0                      ; d66900b2 03dae8f7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v119, 4.0                      ; d66900b8 03daeef7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v118, 4.0                      ; d66900b6 03daecf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84359ad ada74fa6 3f650000
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84361b1 b1ab57aa 3f650000
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84369b5 b5af5fae 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84371b9 b9b367b2 3f650000
	v_dual_mul_f32 v113, v113, v173 :: v_dual_mul_f32 v126, v126, v166 ; c8c75b71 717f4d7e
	v_dual_mul_f32 v115, v115, v177 :: v_dual_mul_f32 v112, v112, v170 ; c8c76373 73715570
	v_dual_mul_f32 v117, v117, v181 :: v_dual_mul_f32 v114, v114, v174 ; c8c76b75 75735d72
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v119, v119, v185 :: v_dual_mul_f32 v116, v116, v178 ; c8c77377 77756574
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[98:99], 0 ; cc464078 1a02c520
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[106:107], v[120:127] ; cc464078 1de2d524
	v_maxmin_num_f32 v190, -4.0, v122, 4.0                      ; d66900be 03daf4f7
	v_maxmin_num_f32 v186, -4.0, v120, 4.0                      ; d66900ba 03daf0f7
	v_maxmin_num_f32 v188, -4.0, v121, 4.0                      ; d66900bc 03daf2f7
	v_maxmin_num_f32 v15, -4.0, v124, 4.0                       ; d669000f 03daf8f7
	v_maxmin_num_f32 v108, -4.0, v125, 4.0                      ; d669006c 03dafaf7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v126, 4.0                      ; d669006e 03dafcf7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v127, 4.0                      ; d6690070 03dafef7
	v_fma_mix_f32 v37, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfe1eff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84379bd bdb76fb6 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v121, v121, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b79 79bf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v123, 4.0                      ; d66900bf 03daf6f7
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_mul_f32 v122, v122, v190 ; c846d96d 6d7b7d7a 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_dual_mul_f32 v127, v127, v113 :: v_dual_mul_f32 v126, v126, v110 ; c8c6e37f 7f7edd7e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v13, v13, v191, 0x3f650000 :: v_dual_mul_f32 v118, v118, v182 ; c8477f0d 0d776d76 3f650000
	v_dual_mul_f32 v123, v123, v13 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8c21b7b 7bbb77ba 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[88:89], 0 ; cc464070 1a02b122
	v_dual_fmaak_f32 v15, v15, v37, 0x3f650000 :: v_dual_mul_f32 v120, v120, v186 ; c8464b0f 0f797578 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_mul_f32 v125, v125, v109 :: v_dual_mul_f32 v124, v124, v15 ; c8c6db7d 7d7c1f7c
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[98:99], 0 ; cc464078 1a02c522
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[96:97], v[112:119] ; cc464070 1dc2c126
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[106:107], v[120:127] ; cc464078 1de2d526
	v_maxmin_num_f32 v138, -4.0, v117, 4.0                      ; d669008a 03daeaf7
	v_maxmin_num_f32 v130, -4.0, v113, 4.0                      ; d6690082 03dae2f7
	v_maxmin_num_f32 v136, -4.0, v116, 4.0                      ; d6690088 03dae8f7
	v_maxmin_num_f32 v132, -4.0, v114, 4.0                      ; d6690084 03dae4f7
	v_maxmin_num_f32 v134, -4.0, v115, 4.0                      ; d6690086 03dae6f7
	v_maxmin_num_f32 v128, -4.0, v112, 4.0                      ; d6690080 03dae0f7
	v_maxmin_num_f32 v140, -4.0, v118, 4.0                      ; d669008c 03daecf7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v119, 4.0                      ; d669008e 03daeef7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v120, 4.0                      ; d6690090 03daf0f7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v121, 4.0                      ; d6690092 03daf2f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c843158b 8b891388 3f650000
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430d87 87850b84 3f650000
	v_maxmin_num_f32 v148, -4.0, v122, 4.0                      ; d6690094 03daf4f7
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
	v_maxmin_num_f32 v150, -4.0, v123, 4.0                      ; d6690096 03daf6f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 ; c8431d8f 8f8d1b8c 3f650000
	v_dual_mul_f32 v117, v117, v139 :: v_dual_mul_f32 v116, v116, v136 ; c8c71775 75751174
	v_dual_mul_f32 v115, v115, v135 :: v_dual_mul_f32 v114, v114, v132 ; c8c70f73 73730972
	v_maxmin_num_f32 v152, -4.0, v124, 4.0                      ; d6690098 03daf8f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_mul_f32 v113, v113, v131 :: v_dual_mul_f32 v112, v112, v128 ; c8c70771 71710170
	v_maxmin_num_f32 v154, -4.0, v125, 4.0                      ; d669009a 03dafaf7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_dual_mul_f32 v119, v119, v143 :: v_dual_mul_f32 v118, v118, v140 ; c8c71f77 77771976
	v_maxmin_num_f32 v156, -4.0, v126, 4.0                      ; d669009c 03dafcf7
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v158, -4.0, v127, 4.0                      ; d669009e 03dafef7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_mul_f32 v121, v121, v147 :: v_dual_mul_f32 v120, v120, v144 ; c8c72779 79792178
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[88:89], 0 ; cc464070 1a02b128
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_dual_mul_f32 v123, v123, v151 :: v_dual_mul_f32 v122, v122, v148 ; c8c72f7b 7b7b297a
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_dual_mul_f32 v125, v125, v155 :: v_dual_mul_f32 v124, v124, v152 ; c8c7377d 7d7d317c
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[96:97], v[112:119] ; cc464070 1dc2c12c
	v_dual_mul_f32 v127, v127, v159 :: v_dual_mul_f32 v126, v126, v156 ; c8c73f7f 7f7f397e
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[98:99], 0 ; cc464078 1a02c528
	v_maxmin_num_f32 v162, -4.0, v113, 4.0                      ; d66900a2 03dae2f7
	v_maxmin_num_f32 v160, -4.0, v112, 4.0                      ; d66900a0 03dae0f7
	v_maxmin_num_f32 v164, -4.0, v114, 4.0                      ; d66900a4 03dae4f7
	v_maxmin_num_f32 v166, -4.0, v115, 4.0                      ; d66900a6 03dae6f7
	v_maxmin_num_f32 v168, -4.0, v116, 4.0                      ; d66900a8 03dae8f7
	v_maxmin_num_f32 v170, -4.0, v117, 4.0                      ; d66900aa 03daeaf7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v118, 4.0                      ; d66900ac 03daecf7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	buffer_load_b128 v[108:111], v14, s[36:39], null offen offset:64 ; c405c07c 4080486c 0000400e
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v119, 4.0                      ; d66900ae 03daeef7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[106:107], v[120:127] ; cc464078 1de2d52c
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_mul_f32 v113, v113, v163 :: v_dual_mul_f32 v112, v112, v160 ; c8c74771 71714170
	v_dual_mul_f32 v115, v115, v167 :: v_dual_mul_f32 v114, v114, v164 ; c8c74f73 73734972
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	buffer_load_b128 v[112:115], v14, s[36:39], null offen offset:80 ; c405c07c 40804870 0000500e
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c84355ab aba953a8 3f650000
	v_maxmin_num_f32 v178, -4.0, v121, 4.0                      ; d66900b2 03daf2f7
	v_maxmin_num_f32 v176, -4.0, v120, 4.0                      ; d66900b0 03daf0f7
	v_maxmin_num_f32 v180, -4.0, v122, 4.0                      ; d66900b4 03daf4f7
	v_maxmin_num_f32 v182, -4.0, v123, 4.0                      ; d66900b6 03daf6f7
	v_maxmin_num_f32 v184, -4.0, v124, 4.0                      ; d66900b8 03daf8f7
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 ; c8435daf afad5bac 3f650000
	v_maxmin_num_f32 v186, -4.0, v125, 4.0                      ; d66900ba 03dafaf7
	v_dual_mul_f32 v117, v117, v171 :: v_dual_mul_f32 v116, v116, v168 ; c8c75775 75755174
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v126, 4.0                      ; d66900bc 03dafcf7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_mul_f32 v119, v119, v175 :: v_dual_mul_f32 v118, v118, v172 ; c8c75f77 77775976
	v_maxmin_num_f32 v190, -4.0, v127, 4.0                      ; d66900be 03dafef7
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84365b3 b3b163b0 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c8436db7 b7b56bb4 3f650000
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84375bb bbb973b8 3f650000
	v_dual_mul_f32 v121, v121, v179 :: v_dual_mul_f32 v120, v120, v176 ; c8c76779 79796178
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[98:99], 0 ; cc464080 1a02c52a
	v_dual_mul_f32 v123, v123, v183 :: v_dual_mul_f32 v122, v122, v180 ; c8c76f7b 7b7b697a
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8437dbf bfbd7bbc 3f650000
	v_dual_mul_f32 v125, v125, v187 :: v_dual_mul_f32 v124, v124, v184 ; c8c7777d 7d7d717c
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v127, v127, v191 :: v_dual_mul_f32 v126, v126, v188 ; c8c77f7f 7f7f797e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[106:107], v[128:135] ; cc464080 1e02d52e
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[88:89], 0 ; cc464078 1a02b12a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[96:97], v[120:127] ; cc464078 1de2c12e
	v_maxmin_num_f32 v46, -4.0, v123, 4.0                       ; d669002e 03daf6f7
	v_maxmin_num_f32 v44, -4.0, v122, 4.0                       ; d669002c 03daf4f7
	v_maxmin_num_f32 v42, -4.0, v121, 4.0                       ; d669002a 03daf2f7
	v_maxmin_num_f32 v191, -4.0, v120, 4.0                      ; d66900bf 03daf0f7
	v_maxmin_num_f32 v88, -4.0, v124, 4.0                       ; d6690058 03daf8f7
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_fma_mix_f32 v47, 0xab28, |v46|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622f 0bfe5cff 3728ab28
	v_fma_mix_f32 v45, 0xab28, |v44|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe58ff 3728ab28
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v96, s5, v12, 2                              ; d6470060 020a1805
	v_fma_mix_f32 v43, 0xab28, |v42|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622b 0bfe54ff 3728ab28
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v125, 4.0                       ; d6690061 03dafaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_fmaak_f32 v43, v43, v42, 0x3f650000 :: v_dual_fmaak_f32 v44, v44, v45, 0x3f650000 ; c842552b 2b2c5b2c 3f650000
	v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 :: v_dual_fmaak_f32 v47, v47, v46, 0x3f650000 ; c842b358 582e5d2f 3f650000
	v_dual_mul_f32 v122, v122, v44 :: v_dual_mul_f32 v121, v121, v43 ; c8c6597a 7a785779
	v_dual_mul_f32 v124, v124, v88 :: v_dual_mul_f32 v123, v123, v47 ; c8c6b17c 7c7a5f7b
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v96, s[44:47], null offen        ; c405c07c 4080582c 00000060
	buffer_load_b128 v[116:119], v96, s[44:47], null offen offset:1024 ; c405c07c 40805874 00040060
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v191, v191, v13, 0x3f650000                     ; 5b7e1bbf 3f650000
	v_mul_f32_e32 v120, v120, v191                              ; 10f17f78
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870251
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v99, -4.0, v126, 4.0                       ; d6690063 03dafcf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v127, 4.0                      ; d669006b 03dafef7
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v106, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfec6ff 3728ab28
	v_fmaak_f32 v98, v98, v97, 0x3f650000                       ; 5ac4c362 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_fmaak_f32 v99, v99, v106, 0x3f650000                      ; 5ac6d563 3f650000
	v_maxmin_num_f32 v136, -4.0, v128, 4.0                      ; d6690088 03db00f7
	v_mul_f32_e32 v125, v125, v98                               ; 10fac57d
	v_mul_f32_e32 v126, v126, v99                               ; 10fcc77e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v124, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfed6ff 3728ab28
	v_fmaak_f32 v124, v124, v107, 0x3f650000                    ; 5af8d77c 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_mul_f32_e32 v127, v127, v124                              ; 10fef97f
	v_maxmin_num_f32 v138, -4.0, v129, 4.0                      ; d669008a 03db02f7
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[120:123], v96, s[44:47], null offen offset:2048 ; c405c07c 40805878 00080060
	buffer_load_b128 v[124:127], v96, s[44:47], null offen offset:512 ; c405c07c 4080587c 00020060
	buffer_load_b128 v[140:143], v96, s[44:47], null offen offset:1536 ; c405c07c 4080588c 00060060
	buffer_load_b128 v[96:99], v96, s[44:47], null offen offset:2560 ; c405c07c 40805860 000a0060
	v_maxmin_num_f32 v144, -4.0, v130, 4.0                      ; d6690090 03db04f7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v131, 4.0                      ; d6690092 03db06f7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v132, 4.0                      ; d6690094 03db08f7
	v_maxmin_num_f32 v150, -4.0, v133, 4.0                      ; d6690096 03db0af7
	v_maxmin_num_f32 v152, -4.0, v134, 4.0                      ; d6690098 03db0cf7
	v_maxmin_num_f32 v154, -4.0, v135, 4.0                      ; d669009a 03db0ef7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fmaak_f32 v136, v136, v137, 0x3f650000                    ; 5b111388 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fmaak_f32 v144, v144, v145, 0x3f650000                    ; 5b212390 3f650000
	v_dual_mul_f32 v128, v128, v136 :: v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 ; c8c31180 808b158b 3f650000
	v_fmaak_f32 v147, v147, v146, 0x3f650000                    ; 5b272593 3f650000
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v130, v130, v144 :: v_dual_mul_f32 v129, v129, v139 ; c8c72182 82811781
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_dual_mul_f32 v145, v101, v49 :: v_dual_mul_f32 v144, v100, v48 ; c8c66365 91906164
	v_mul_f32_e32 v131, v131, v147                              ; 11072783
	v_dual_mul_f32 v147, v103, v51 :: v_dual_mul_f32 v146, v102, v50 ; c8c66767 93926566
	v_dual_mul_f32 v133, v133, v151 :: v_dual_mul_f32 v132, v132, v148 ; c8c72f85 85852984
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_mul_f32 v149, v105, v53 :: v_dual_mul_f32 v148, v104, v52 ; c8c66b69 95946968
	v_dual_mul_f32 v151, v11, v55 :: v_dual_mul_f32 v150, v10, v54 ; c8c66f0b 97966d0a
	v_dual_mul_f32 v135, v135, v155 :: v_dual_mul_f32 v134, v134, v152 ; c8c73787 87873186
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v129, v91, v49 :: v_dual_mul_f32 v128, v90, v48 ; c8c6635b 8180615a
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[18:19], v[144:151] ; cc464090 1e422538
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v131, v93, v51 :: v_dual_mul_f32 v130, v92, v50 ; c8c6675d 8382655c
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	s_bitset0_b32 s41, 14                                       ; bea9108e
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_buffer_load_b32 s10, s[40:43], s10 offset:0x0             ; f4020294 14000000
	v_dual_mul_f32 v133, v95, v53 :: v_dual_mul_f32 v132, v94, v52 ; c8c66b5f 8584695e
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v135, v9, v55 :: v_dual_mul_f32 v134, v8, v54 ; c8c66f09 87866d08
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[16:17], v[128:135] ; cc464080 1e022138
	v_cvt_pk_f32_fp8_e32 v[48:49], v4                           ; 7e60dd04
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[22:23], v[144:151] ; cc464090 1e422d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[20:21], v[128:135] ; cc464080 1e02293c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[64:65], v[28:29], v[144:151] ; cc464090 1e423940
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[64:65], v[24:25], v[128:135] ; cc464080 1e023140
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[30:31], v[144:151] ; cc464090 1e423d44
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mul_f32 v153, v49, v109 :: v_dual_mul_f32 v152, v48, v108 ; c8c6db31 9998d930
	v_cvt_pk_f32_fp8_e32 v[48:49], v132                         ; 7e60dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[26:27], v[128:135] ; cc464080 1e023544
	v_dual_mul_f32 v155, v49, v111 :: v_dual_mul_f32 v154, v48, v110 ; c8c6df31 9b9add30
	v_cvt_pk_f32_fp8_e32 v[48:49], v5                           ; 7e60dd05
	v_cvt_pk_f32_fp8_e32 v[4:5], v133                           ; 7e08dd85
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[36:37], v[144:151] ; cc464090 1e424948
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[32:33], v[128:135] ; cc464080 1e024148
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v157, v49, v113 :: v_dual_mul_f32 v156, v48, v112 ; c8c6e331 9d9ce130
	v_dual_mul_f32 v159, v5, v115 :: v_dual_mul_f32 v158, v4, v114 ; c8c6e705 9f9ee504
	v_cvt_pk_f32_fp8_e32 v[4:5], v6                             ; 7e08dd06
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[76:77], v[38:39], v[144:151] ; cc464090 1e424d4c
	v_dual_mul_f32 v49, v5, v109 :: v_dual_mul_f32 v48, v4, v108 ; c8c6db05 3130d904
	v_cvt_pk_f32_fp8_e32 v[4:5], v134                           ; 7e08dd86
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[34:35], v[128:135] ; cc464080 1e02454c
	v_dual_mul_f32 v51, v5, v111 :: v_dual_mul_f32 v50, v4, v110 ; c8c6df05 3332dd04
	v_cvt_pk_f32_fp8_e32 v[4:5], v7                             ; 7e08dd07
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[80:81], v[14:15], v[144:151] ; cc464090 1e421d50
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[16:17], v[152:159] ; cc464098 1e62213a
	v_dual_mul_f32 v53, v5, v113 :: v_dual_mul_f32 v52, v4, v112 ; c8c6e305 3534e104
	v_cvt_pk_f32_fp8_e32 v[4:5], v135                           ; 7e08dd87
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[40:41], v[128:135] ; cc464080 1e025150
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[88:89], v[144:151] ; cc464090 1e42b154
	v_dual_mul_f32 v55, v5, v115 :: v_dual_mul_f32 v54, v4, v114 ; c8c6e705 3736e504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[58:59], v[18:19], v[48:55] ; cc464030 1cc2253a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[20:21], v[152:159] ; cc464098 1e62293e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[42:43], v[128:135] ; cc464080 1e025554
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[62:63], v[22:23], v[48:55] ; cc464030 1cc22d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[24:25], v[152:159] ; cc464098 1e623142
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[66:67], v[28:29], v[48:55] ; cc464030 1cc23942
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[70:71], v[26:27], v[152:159] ; cc464098 1e623546
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[118:119], v[8:9], 0 ; cc464038 1a021176
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[70:71], v[30:31], v[48:55] ; cc464030 1cc23d46
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[46:47], v[8:9], 0   ; cc464018 1a02112e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[32:33], v[152:159] ; cc464098 1e62414a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[8:9], 0   ; cc464010 1a02112c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[74:75], v[36:37], v[48:55] ; cc464030 1cc2494a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[78:79], v[34:35], v[152:159] ; cc464098 1e62454e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[78:79], v[38:39], v[48:55] ; cc464030 1cc24d4e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[116:117], v[8:9], 0 ; cc464020 1a021174
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[82:83], v[40:41], v[152:159] ; cc464098 1e625152
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[82:83], v[14:15], v[48:55] ; cc464030 1cc21d52
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[42:43], v[152:159] ; cc464098 1e625556
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[86:87], v[88:89], v[48:55] ; cc464030 1cc2b156
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[120:121], 0 ; cc464040 1a02f108
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[122:123], 0 ; cc464048 1a02f508
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[140:141], v[4:5], v[32:39] ; cc464020 1c82098c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[126:127], v[4:5], v[24:31] ; cc464018 1c62097e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[124:125], v[4:5], v[16:23] ; cc464010 1c42097c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[142:143], v[4:5], v[56:63] ; cc464038 1ce2098e
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[4:5], v[96:97], v[64:71] ; cc464040 1d02c104
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[4:5], v[98:99], v[72:79] ; cc464048 1d22c504
	v_dual_mul_f32 v163, v59, v59 :: v_dual_mul_f32 v160, v25, v25 ; c8c6773b a3a03319
	v_dual_mul_f32 v162, v27, v27 :: v_dual_mul_f32 v161, v57, v57 ; c8c6371b a2a07339
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_dual_fmac_f32 v163, v35, v35 :: v_dual_fmac_f32 v160, v17, v17 ; c8004723 a3a02311
	s_mov_b32 s19, 0x76543210                                   ; be9300ff 76543210
	v_dual_fmac_f32 v162, v19, v19 :: v_dual_fmac_f32 v161, v33, v33 ; c8002713 a2a04321
	s_mov_b32 s20, 0xfedcba98                                   ; be9400ff fedcba98
	v_dual_fmac_f32 v163, v39, v39 :: v_dual_fmac_f32 v160, v21, v21 ; c8004f27 a3a02b15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v23, v23 :: v_dual_fmac_f32 v161, v37, v37 ; c8002f17 a2a04b25
	v_dual_fmac_f32 v163, v63, v63 :: v_dual_fmac_f32 v160, v29, v29 ; c8007f3f a3a03b1d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v31, v31 :: v_dual_fmac_f32 v161, v61, v61 ; c8003f1f a2a07b3d
	v_dual_fmac_f32 v163, v34, v34 :: v_dual_fmac_f32 v160, v16, v16 ; c8004522 a3a02110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v32, v32 :: v_dual_fmac_f32 v162, v18, v18 ; c8004120 a1a22512
	v_dual_fmac_f32 v163, v58, v58 :: v_dual_fmac_f32 v160, v24, v24 ; c800753a a3a03118
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v56, v56 :: v_dual_fmac_f32 v162, v26, v26 ; c8007138 a1a2351a
	v_dual_fmac_f32 v163, v38, v38 :: v_dual_fmac_f32 v160, v20, v20 ; c8004d26 a3a02914
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v36, v36 :: v_dual_fmac_f32 v162, v22, v22 ; c8004924 a1a22d16
	v_dual_fmac_f32 v163, v62, v62 :: v_dual_fmac_f32 v160, v28, v28 ; c8007d3e a3a0391c
	v_lshl_add_u32 v167, v2, 5, v1                              ; d64600a7 04050b02
	v_lshl_add_u32 v2, v2, 6, s7                                ; d6460002 001d0d02
	v_dual_fmac_f32 v161, v60, v60 :: v_dual_fmac_f32 v162, v30, v30 ; c800793c a1a23d1e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
	v_fma_mixlo_f16 v164, 1.0, v160, v162                       ; cc2100a4 068b40f2
	v_fma_mixhi_f16 v164, 1.0, v161, v163                       ; cc2200a4 068f42f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_permlanex16_b32 v165, v164, s19, s20 op_sel:[1,1]         ; d65c18a5 005027a4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[165:166]            ; 1a034ba4
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v255                             ; 0a01ffa4
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00a6
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
	v_rsq_f32_e32 v166, v166                                    ; 7f4c5da6
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v166, s10, v166                               ; 114d4c0a
	v_dual_mul_f32 v17, v17, v166 :: v_dual_mul_f32 v16, v16, v166 ; c8c74d11 11114d10
	v_dual_mul_f32 v19, v19, v166 :: v_dual_mul_f32 v18, v18, v166 ; c8c74d13 13134d12
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v2, s[36:39], null offen         ; c405c07c 40804810 00000002
	buffer_load_b128 v[40:43], v2, s[36:39], null offen offset:16 ; c405c07c 40804828 00001002
(invalid instruction)                                        ; d58b08a4
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
	v_mul_f32_e32 v22, v22, v166                                ; 102d4d16
	v_dual_mul_f32 v21, v21, v166 :: v_dual_mul_f32 v20, v20, v166 ; c8c74d15 15154d14
	v_mul_f32_e32 v23, v23, v166                                ; 102f4d17
	v_dual_mul_f32 v25, v25, v166 :: v_dual_mul_f32 v24, v24, v166 ; c8c74d19 19194d18
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_rsq_f32_e32 v164, v164                                    ; 7f485da4
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870125
	v_dual_mul_f32 v33, v33, v164 :: v_dual_mul_f32 v32, v32, v164 ; c8c74921 21214920
	v_dual_mul_f32 v35, v35, v164 :: v_dual_mul_f32 v34, v34, v164 ; c8c74923 23234922
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v2, s[36:39], null offen offset:4096 ; c405c07c 40804814 00100002
	buffer_load_b128 v[32:35], v2, s[36:39], null offen offset:4112 ; c405c07c 40804820 00101002
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v27, v27, v166 :: v_dual_mul_f32 v26, v26, v166 ; c8c74d1b 1b1b4d1a
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
	v_dual_mul_f32 v29, v29, v166 :: v_dual_mul_f32 v28, v28, v166 ; c8c74d1d 1d1d4d1c
	v_dual_mul_f32 v31, v31, v166 :: v_dual_mul_f32 v30, v30, v166 ; c8c74d1f 1f1f4d1e
	v_dual_mul_f32 v37, v37, v164 :: v_dual_mul_f32 v36, v36, v164 ; c8c74925 25254924
	v_dual_mul_f32 v39, v39, v164 :: v_dual_mul_f32 v38, v38, v164 ; c8c74927 27274926
	v_dual_mul_f32 v57, v57, v164 :: v_dual_mul_f32 v56, v56, v164 ; c8c74939 39394938
	v_dual_mul_f32 v59, v59, v164 :: v_dual_mul_f32 v58, v58, v164 ; c8c7493b 3b3b493a
	v_dual_mul_f32 v61, v61, v164 :: v_dual_mul_f32 v60, v60, v164 ; c8c7493d 3d3d493c
	v_dual_mul_f32 v63, v63, v164 :: v_dual_mul_f32 v62, v62, v164 ; c8c7493f 3f3f493e
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v167, v[8:9], v[26:27] offset1:2         ; d9380200 001a08a7
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v2, s[36:39], null offen offset:64 ; c405c07c 4080481c 00004002
	buffer_load_b128 v[36:39], v2, s[36:39], null offen offset:80 ; c405c07c 40804824 00005002
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[10:11], 0 ; cc464040 1a02152e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[10:11], 0 ; cc464038 1a02152c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[118:119], v[10:11], 0 ; cc464050 1a021576
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[10:11], v[120:121], 0 ; cc464058 1a02f10a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[122:123], 0 ; cc464068 1a02f50a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[6:7], v[96:97], v[88:95] ; cc464058 1d62c106
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[6:7], v[98:99], v[104:111] ; cc464068 1da2c506
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v2, s[36:39], null offen offset:4160 ; c405c07c 4080482c 00104002
	buffer_load_b128 v[96:99], v2, s[36:39], null offen offset:4176 ; c405c07c 40804860 00105002
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[116:117], v[10:11], 0 ; cc464048 1a021574
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[126:127], v[6:7], v[64:71] ; cc464040 1d020d7e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[124:125], v[6:7], v[56:63] ; cc464038 1ce20d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[142:143], v[6:7], v[80:87] ; cc464050 1d420d8e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[140:141], v[6:7], v[72:79] ; cc464048 1d220d8c
	v_mul_f32_e32 v170, v67, v67                                ; 11548743
	v_mul_f32_e32 v168, v65, v65                                ; 11508341
	v_mul_f32_e32 v171, v83, v83                                ; 1156a753
	v_mul_f32_e32 v169, v81, v81                                ; 1152a351
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fmac_f32_e32 v170, v59, v59                               ; 5754773b
	v_fmac_f32_e32 v168, v57, v57                               ; 57507339
	v_fmac_f32_e32 v171, v75, v75                               ; 5756974b
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[100:103], v2, s[36:39], null offen offset:128 ; c405c07c 40804864 00008002
	buffer_load_b128 v[112:115], v2, s[36:39], null offen offset:144 ; c405c07c 40804870 00009002
	v_fmac_f32_e32 v169, v73, v73                               ; 57529349
	v_dual_fmac_f32 v171, v79, v79 :: v_dual_fmac_f32 v168, v61, v61 ; c8009f4f aba87b3d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v170, v63, v63 :: v_dual_fmac_f32 v169, v77, v77 ; c8007f3f aaa89b4d
	v_dual_fmac_f32 v171, v87, v87 :: v_dual_fmac_f32 v168, v69, v69 ; c800af57 aba88b45
	v_dual_fmac_f32 v170, v71, v71 :: v_dual_fmac_f32 v169, v85, v85 ; c8008f47 aaa8ab55
	v_dual_fmac_f32 v171, v74, v74 :: v_dual_fmac_f32 v168, v56, v56 ; c800954a aba87138
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v169, v72, v72 :: v_dual_fmac_f32 v170, v58, v58 ; c8009148 a9aa753a
	v_dual_fmac_f32 v171, v82, v82 :: v_dual_fmac_f32 v168, v64, v64 ; c800a552 aba88140
	v_dual_fmac_f32 v169, v80, v80 :: v_dual_fmac_f32 v170, v66, v66 ; c800a150 a9aa8542
	v_dual_fmac_f32 v171, v78, v78 :: v_dual_fmac_f32 v168, v60, v60 ; c8009d4e aba8793c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v169, v76, v76 :: v_dual_fmac_f32 v170, v62, v62 ; c800994c a9aa7d3e
	v_dual_fmac_f32 v171, v86, v86 :: v_dual_fmac_f32 v168, v68, v68 ; c800ad56 aba88944
	v_dual_fmac_f32 v169, v84, v84 :: v_dual_fmac_f32 v170, v70, v70 ; c800a954 a9aa8d46
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v172, 1.0, v168, v170                       ; cc2100ac 06ab50f2
	v_fma_mixhi_f16 v172, 1.0, v169, v171                       ; cc2200ac 06af52f2
	v_permlanex16_b32 v173, v172, s19, s20 op_sel:[1,1]         ; d65c18ad 005027ac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[173:174]            ; 1a035bac
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v255                             ; 0a01ffac
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	v_rsq_f32_e32 v174, v174                                    ; 7f5c5dae
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v174, s10, v174                               ; 115d5c0a
	v_dual_mul_f32 v58, v58, v174 :: v_dual_mul_f32 v59, v59, v174 ; c8c75d3a 3a3b5d3b
	v_dual_mul_f32 v56, v56, v174 :: v_dual_mul_f32 v57, v57, v174 ; c8c75d38 38395d39
	v_dual_mul_f32 v62, v62, v174 :: v_dual_mul_f32 v63, v63, v174 ; c8c75d3e 3e3f5d3f
	v_dual_mul_f32 v60, v60, v174 :: v_dual_mul_f32 v61, v61, v174 ; c8c75d3c 3c3d5d3d
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v2, s[36:39], null offen offset:4224 ; c405c07c 40804838 00108002
	buffer_load_b128 v[60:63], v2, s[36:39], null offen offset:4240 ; c405c07c 4080483c 00109002
(invalid instruction)                                        ; d58b08ac
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	v_dual_mul_f32 v65, v65, v174 :: v_dual_mul_f32 v64, v64, v174 ; c8c75d41 41415d40
	v_dual_mul_f32 v67, v67, v174 :: v_dual_mul_f32 v66, v66, v174 ; c8c75d43 43435d42
	v_dual_mul_f32 v69, v69, v174 :: v_dual_mul_f32 v68, v68, v174 ; c8c75d45 45455d44
	v_dual_mul_f32 v71, v71, v174 :: v_dual_mul_f32 v70, v70, v174 ; c8c75d47 47475d46
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_rsq_f32_e32 v172, v172                                    ; 7f585dac
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a5
	v_dual_mul_f32 v75, v75, v172 :: v_dual_mul_f32 v74, v74, v172 ; c8c7594b 4b4b594a
	v_dual_mul_f32 v73, v73, v172 :: v_dual_mul_f32 v72, v72, v172 ; c8c75949 49495948
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v2, s[36:39], null offen offset:192 ; c405c07c 40804844 0000c002
	buffer_load_b128 v[72:75], v2, s[36:39], null offen offset:208 ; c405c07c 40804848 0000d002
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v81, v81, v172 :: v_dual_mul_f32 v80, v80, v172 ; c8c75951 51515950
	v_dual_mul_f32 v83, v83, v172 :: v_dual_mul_f32 v82, v82, v172 ; c8c75953 53535952
	v_dual_mul_f32 v79, v79, v172 :: v_dual_mul_f32 v78, v78, v172 ; c8c7594f 4f4f594e
	v_dual_mul_f32 v85, v85, v172 :: v_dual_mul_f32 v84, v84, v172 ; c8c75955 55555954
	v_dual_mul_f32 v77, v77, v172 :: v_dual_mul_f32 v76, v76, v172 ; c8c7594d 4d4d594c
	v_dual_mul_f32 v87, v87, v172 :: v_dual_mul_f32 v86, v86, v172 ; c8c75957 57575956
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v167, v[10:11], v[66:67] offset0:64 offset1:66 ; d9384240 00420aa7
	buffer_load_b128 v[76:79], v2, s[36:39], null offen offset:4288 ; c405c07c 4080484c 0010c002
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0              ; ca100080 43420080
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v167, v[66:67], v[66:67] offset0:128 offset1:130 ; d9388280 004242a7
	buffer_load_b128 v[80:83], v2, s[36:39], null offen offset:4304 ; c405c07c 40804850 0010d002
	ds_store_2addr_b64 v167, v[66:67], v[66:67] offset0:192 offset1:194 ; d938c2c0 004242a7
	ds_load_b64 v[66:67], v167                                  ; d9d80000 420000a7
	ds_load_b64 v[84:85], v167 offset:16                        ; d9d80010 540000a7
	s_mov_b32 s21, 0x3d380000                                   ; be9500ff 3d380000
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[66:67], v[4:5], 0   ; cc464058 1a020942
	s_wait_dscnt 0x0                                            ; bfc60000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[84:85], v[24:25], v[88:95] ; cc464058 1d623154
	s_movk_i32 s22, 0x3e47                                      ; b0163e47
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_mixlo_f16 v175, s21, v88, v16                         ; cc2100af 0442b015
	v_fma_mixlo_f16 v176, s21, v90, v18                         ; cc2100b0 044ab415
	v_fma_mixhi_f16 v176, s21, v91, v19                         ; cc2200b0 044eb615
	v_fma_mixhi_f16 v175, s21, v89, v17                         ; cc2200af 0446b215
	ds_load_b64 v[16:17], v167 offset:512                       ; d9d80200 100000a7
	ds_load_b64 v[18:19], v167 offset:528                       ; d9d80210 120000a7
	s_movk_i32 s23, 0x3c20                                      ; b0173c20
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[66:67], v[6:7], 0 ; cc464068 1a020d42
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v177, s21, v92, v40                         ; cc2100b1 04a2b815
	v_fma_mixhi_f16 v177, s21, v93, v41                         ; cc2200b1 04a6ba15
	v_fma_mixlo_f16 v178, s21, v94, v42                         ; cc2100b2 04aabc15
	v_fma_mixhi_f16 v178, s21, v95, v43                         ; cc2200b2 04aebe15
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v23                              ; 0a002faf
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v23                              ; 0a002fb0
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v23                              ; 0a002fb1
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v23                              ; 0a002fb2
(invalid instruction)                                        ; cc1b00af
	v_subrev_f32_e32 v0, v175, v22                              ; 0a002daf
(invalid instruction)                                        ; cc1b00b0
	v_subrev_f32_e32 v0, v176, v22                              ; 0a002db0
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[84:85], v[64:65], v[104:111] ; cc464068 1da28154
(invalid instruction)                                        ; cc1b00b1
	v_subrev_f32_e32 v0, v177, v22                              ; 0a002db1
(invalid instruction)                                        ; cc1b00b2
	v_subrev_f32_e32 v0, v178, v22                              ; 0a002db2
	s_wait_loadcnt 0xc                                          ; bfc0000c
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mixlo_f16 v182, s21, v110, v34                        ; cc2100b6 048adc15
	v_fma_mixhi_f16 v182, s21, v111, v35                        ; cc2200b6 048ede15
	v_fma_mixlo_f16 v181, s21, v108, v32                        ; cc2100b5 0482d815
	v_fma_mixhi_f16 v181, s21, v109, v33                        ; cc2200b5 0486da15
	v_fma_mixlo_f16 v179, s21, v104, v20                        ; cc2100b3 0452d015
	v_fma_mixhi_f16 v179, s21, v105, v21                        ; cc2200b3 0456d215
	v_fma_mixlo_f16 v180, s21, v106, v22                        ; cc2100b4 045ad415
	v_fma_mixhi_f16 v180, s21, v107, v23                        ; cc2200b4 045ed615
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[4:5], 0   ; cc464058 1a020910
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[6:7], 0 ; cc464068 1a020d10
(invalid instruction)                                        ; cc1c00b6
	v_subrev_f32_e32 v0, v182, v23                              ; 0a002fb6
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v23                              ; 0a002fb5
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v23                              ; 0a002fb3
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v23                              ; 0a002fb4
	ds_load_b64 v[16:17], v167 offset:1024                      ; d9d80400 100000a7
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[18:19], v[24:25], v[88:95] ; cc464058 1d623112
(invalid instruction)                                        ; cc1b00b6
	v_subrev_f32_e32 v0, v182, v22                              ; 0a002db6
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[64:65], v[104:111] ; cc464068 1da28112
	ds_load_b64 v[18:19], v167 offset:1040                      ; d9d80410 120000a7
(invalid instruction)                                        ; cc1b00b5
	v_subrev_f32_e32 v0, v181, v22                              ; 0a002db5
(invalid instruction)                                        ; cc1b00b3
	v_subrev_f32_e32 v0, v179, v22                              ; 0a002db3
(invalid instruction)                                        ; cc1b00b4
	v_subrev_f32_e32 v0, v180, v22                              ; 0a002db4
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v184, s21, v90, v30                         ; cc2100b8 047ab415
	v_fma_mixhi_f16 v184, s21, v91, v31                         ; cc2200b8 047eb615
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v186, s21, v94, v38                         ; cc2100ba 049abc15
	v_fma_mixhi_f16 v186, s21, v95, v39                         ; cc2200ba 049ebe15
	v_fma_mixlo_f16 v185, s21, v92, v36                         ; cc2100b9 0492b815
	v_fma_mixhi_f16 v185, s21, v93, v37                         ; cc2200b9 0496ba15
	v_fma_mixlo_f16 v183, s21, v88, v28                         ; cc2100b7 0472b015
	v_fma_mixhi_f16 v183, s21, v89, v29                         ; cc2200b7 0476b215
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v23                              ; 0a002fb8
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v187, s21, v104, v44                        ; cc2100bb 04b2d015
	v_fma_mixhi_f16 v187, s21, v105, v45                        ; cc2200bb 04b6d215
	v_fma_mixlo_f16 v188, s21, v106, v46                        ; cc2100bc 04bad415
	v_fma_mixhi_f16 v188, s21, v107, v47                        ; cc2200bc 04bed615
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v23                              ; 0a002fba
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v189, s21, v108, v96                        ; cc2100bd 0582d815
	v_fma_mixhi_f16 v189, s21, v109, v97                        ; cc2200bd 0586da15
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v23                              ; 0a002fb9
	v_fma_mixlo_f16 v190, s21, v110, v98                        ; cc2100be 058adc15
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v23                              ; 0a002fb7
	v_fma_mixhi_f16 v190, s21, v111, v99                        ; cc2200be 058ede15
(invalid instruction)                                        ; cc1b00b8
	v_subrev_f32_e32 v0, v184, v22                              ; 0a002db8
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v23                              ; 0a002fbb
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[4:5], 0   ; cc464020 1a020910
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[6:7], 0   ; cc464028 1a020d10
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v23                              ; 0a002fbc
(invalid instruction)                                        ; cc1b00ba
	v_subrev_f32_e32 v0, v186, v22                              ; 0a002dba
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v23                              ; 0a002fbd
(invalid instruction)                                        ; cc1b00b9
	v_subrev_f32_e32 v0, v185, v22                              ; 0a002db9
(invalid instruction)                                        ; cc1b00b7
	v_subrev_f32_e32 v0, v183, v22                              ; 0a002db7
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v23                              ; 0a002fbe
	ds_load_b64 v[16:17], v167 offset:1536                      ; d9d80600 100000a7
(invalid instruction)                                        ; cc1b00bb
	v_subrev_f32_e32 v0, v187, v22                              ; 0a002dbb
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[24:25], v[32:39] ; cc464020 1c823112
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[64:65], v[40:47] ; cc464028 1ca28112
	ds_load_b64 v[18:19], v167 offset:1552                      ; d9d80610 120000a7
(invalid instruction)                                        ; cc1b00bc
	v_subrev_f32_e32 v0, v188, v22                              ; 0a002dbc
(invalid instruction)                                        ; cc1b00bd
	v_subrev_f32_e32 v0, v189, v22                              ; 0a002dbd
(invalid instruction)                                        ; cc1b00be
	v_subrev_f32_e32 v0, v190, v22                              ; 0a002dbe
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v20, s21, v38, v114                         ; cc210014 05ca4c15
	v_fma_mixhi_f16 v20, s21, v39, v115                         ; cc220014 05ce4e15
	v_fma_mixlo_f16 v13, s21, v36, v112                         ; cc21000d 05c24815
	v_fma_mixhi_f16 v13, s21, v37, v113                         ; cc22000d 05c64a15
	v_fma_mixlo_f16 v2, s21, v34, v102                          ; cc210002 059a4415
	v_fma_mixhi_f16 v2, s21, v35, v103                          ; cc220002 059e4615
	v_fma_mixlo_f16 v191, s21, v32, v100                        ; cc2100bf 05924015
	v_fma_mixhi_f16 v191, s21, v33, v101                        ; cc2200bf 05964215
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v23                               ; 0a002f14
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v23                               ; 0a002f0d
(invalid instruction)                                        ; cc1c0002
	v_subrev_f32_e32 v0, v2, v23                                ; 0a002f02
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v23                              ; 0a002fbf
(invalid instruction)                                        ; cc1b0014
	v_subrev_f32_e32 v0, v20, v22                               ; 0a002d14
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v22                               ; 0a002d0d
(invalid instruction)                                        ; cc1b0002
	v_subrev_f32_e32 v0, v2, v22                                ; 0a002d02
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v22                              ; 0a002dbf
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v21, s21, v40, v56                          ; cc210015 04e25015
	v_fma_mixhi_f16 v21, s21, v41, v57                          ; cc220015 04e65215
	v_fma_mixlo_f16 v22, s21, v42, v58                          ; cc210016 04ea5415
	v_fma_mixhi_f16 v22, s21, v43, v59                          ; cc220016 04ee5615
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[4:5], 0   ; cc464020 1a020910
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v28, s21, v46, v62                          ; cc21001c 04fa5c15
	v_fma_mixhi_f16 v28, s21, v47, v63                          ; cc22001c 04fe5e15
	v_fma_mixlo_f16 v23, s21, v44, v60                          ; cc210017 04f25815
	v_fma_mixhi_f16 v23, s21, v45, v61                          ; cc220017 04f65a15
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[6:7], 0   ; cc464028 1a020d10
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v23                               ; 0a002f15
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v23                               ; 0a002f16
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v23                               ; 0a002f1c
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v23                               ; 0a002f17
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[24:25], v[32:39] ; cc464020 1c823112
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v22                               ; 0a002d15
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v22                               ; 0a002d16
(invalid instruction)                                        ; cc1b001c
	v_subrev_f32_e32 v0, v28, v22                               ; 0a002d1c
(invalid instruction)                                        ; cc1b0017
	v_subrev_f32_e32 v0, v23, v22                               ; 0a002d17
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[64:65], v[40:47] ; cc464028 1ca28112
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v29, s21, v32, v68                          ; cc21001d 05124015
	v_fma_mixhi_f16 v29, s21, v33, v69                          ; cc22001d 05164215
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v32, s21, v38, v74                          ; cc210020 052a4c15
	v_fma_mixhi_f16 v32, s21, v39, v75                          ; cc220020 052e4e15
	v_fma_mixlo_f16 v31, s21, v36, v72                          ; cc21001f 05224815
	v_fma_mixhi_f16 v31, s21, v37, v73                          ; cc22001f 05264a15
	v_fma_mixlo_f16 v30, s21, v34, v70                          ; cc21001e 051a4415
	v_fma_mixhi_f16 v30, s21, v35, v71                          ; cc22001e 051e4615
(invalid instruction)                                        ; cc1c001d
	v_subrev_f32_e32 v0, v29, v23                               ; 0a002f1d
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v23                               ; 0a002f20
(invalid instruction)                                        ; cc1c001f
	v_subrev_f32_e32 v0, v31, v23                               ; 0a002f1f
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v35, s21, v44, v80                          ; cc210023 05425815
	v_fma_mixlo_f16 v33, s21, v40, v76                          ; cc210021 05325015
	v_fma_mixhi_f16 v33, s21, v41, v77                          ; cc220021 05365215
	v_fma_mixhi_f16 v35, s21, v45, v81                          ; cc220023 05465a15
	v_fma_mixlo_f16 v34, s21, v42, v78                          ; cc210022 053a5415
	v_fma_mixhi_f16 v34, s21, v43, v79                          ; cc220022 053e5615
(invalid instruction)                                        ; cc1c001e
	v_subrev_f32_e32 v0, v30, v23                               ; 0a002f1e
	v_fma_mixlo_f16 v36, s21, v46, v82                          ; cc210024 054a5c15
(invalid instruction)                                        ; cc1b001d
	v_subrev_f32_e32 v0, v29, v22                               ; 0a002d1d
(invalid instruction)                                        ; cc1b0020
	v_subrev_f32_e32 v0, v32, v22                               ; 0a002d20
	v_fma_mixhi_f16 v36, s21, v47, v83                          ; cc220024 054e5e15
(invalid instruction)                                        ; cc1b001f
	v_subrev_f32_e32 v0, v31, v22                               ; 0a002d1f
	s_mov_b32 s24, 0x7ff88000                                   ; be9800ff 7ff88000
(invalid instruction)                                        ; cc1c0021
	v_subrev_f32_e32 v0, v33, v23                               ; 0a002f21
(invalid instruction)                                        ; cc1c0023
	v_subrev_f32_e32 v0, v35, v23                               ; 0a002f23
(invalid instruction)                                        ; cc1c0022
	v_subrev_f32_e32 v0, v34, v23                               ; 0a002f22
(invalid instruction)                                        ; cc1b001e
	v_subrev_f32_e32 v0, v30, v22                               ; 0a002d1e
	v_lshl_add_u32 v191, v191, 5, s24                           ; d64600bf 00610bbf
	v_lshl_add_u32 v183, v183, 5, s24                           ; d64600b7 00610bb7
	v_lshl_add_u32 v176, v176, 5, s24                           ; d64600b0 00610bb0
	v_lshl_add_u32 v175, v175, 5, s24                           ; d64600af 00610baf
	v_lshl_add_u32 v29, v29, 5, s24                             ; d646001d 00610b1d
	v_lshl_add_u32 v184, v184, 5, s24                           ; d64600b8 00610bb8
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v23                               ; 0a002f24
	v_lshl_add_u32 v2, v2, 5, s24                               ; d6460002 00610b02
(invalid instruction)                                        ; cc1b0021
	v_subrev_f32_e32 v0, v33, v22                               ; 0a002d21
(invalid instruction)                                        ; cc1b0023
	v_subrev_f32_e32 v0, v35, v22                               ; 0a002d23
(invalid instruction)                                        ; cc1b0022
	v_subrev_f32_e32 v0, v34, v22                               ; 0a002d22
	v_lshl_add_u32 v177, v177, 5, s24                           ; d64600b1 00610bb1
	v_lshl_add_u32 v30, v30, 5, s24                             ; d646001e 00610b1e
	v_lshl_add_u32 v185, v185, 5, s24                           ; d64600b9 00610bb9
	v_lshl_add_u32 v13, v13, 5, s24                             ; d646000d 00610b0d
	v_lshl_add_u32 v31, v31, 5, s24                             ; d646001f 00610b1f
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[175:176], v[183:184]            ; 1a036faf
	v_lshl_add_u32 v178, v178, 5, s24                           ; d64600b2 00610bb2
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[176:177], v[184:185]            ; 1a0371b0
	v_add_lshl_u32 v0, s9, v0, 2                                ; d6470000 020a0009
	buffer_load_b128 v[4:7], v0, s[36:39], null offen           ; c405c07c 40804804 00000000
	v_lshl_add_u32 v186, v186, 5, s24                           ; d64600ba 00610bba
(invalid instruction)                                        ; cc1b0024
	v_subrev_f32_e32 v0, v36, v22                               ; 0a002d24
	v_lshl_add_u32 v20, v20, 5, s24                             ; d6460014 00610b14
	v_lshl_add_u32 v32, v32, 5, s24                             ; d6460020 00610b20
	buffer_load_b128 v[16:19], v0, s[36:39], null offen offset:16 ; c405c07c 40804810 00001000
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[177:178], v[185:186]            ; 1a0373b1
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[191:192]              ; 1a037f25
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[2:3]                  ; 1a020526
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[178:179], v[186:187]            ; 1a0375b2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[13:14]                ; 1a021b27
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[29:30]                ; 1a023b25
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[30:31]                ; 1a023d26
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[40:41], v[20:21]                ; 1a022928
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[31:32]                ; 1a023f27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[38:39]                ; 1a024d25
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[40:41], v[32:33]                ; 1a024128
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[39:40]                ; 1a024f25
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v12, s6, v12, 2                              ; d647000c 020a1806
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[40:41]                ; 1a025125
	buffer_load_b64 v[38:39], v12, s[44:47], null offen         ; c405407c 40805826 0000000c
	v_permlanex16_b32 v41, v37, s19, s20 op_sel:[1,1]           ; d65c1829 00502725
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[41:42]                ; 1a025325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v42, v37, v165/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64554b25
	v_max_num_f16_e32 v42, 0x400, v42                           ; 625454ff 00000400
	buffer_load_b64 v[40:41], v12, s[44:47], null offen offset:512 ; c405407c 40805828 0002000c
	v_cvt_f32_f16_e32 v43, v42                                  ; 7e56172a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v43, v43                                      ; 7e56552b
	v_fma_mix_f32 v47, v178, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002f 8a0257b2
	v_fma_mix_f32 v57, v184, v43, neg(0) op_sel_hi:[1,0,0]      ; cc200039 8a0257b8
	v_fma_mix_f32 v44, v175, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002c 8a0257af
	v_fma_mix_f32 v45, v176, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002d 8a0257b0
	v_fma_mix_f32 v176, v176, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a0257b0
	v_fma_mix_f32 v178, v178, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a0257b2
	v_fma_mix_f32 v46, v177, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002e 8a0257b1
	v_fma_mix_f32 v56, v183, v43, neg(0) op_sel_hi:[1,0,0]      ; cc200038 8a0257b7
	v_fma_mix_f32 v183, v183, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a0257b7
	v_fma_mix_f32 v177, v177, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a0257b1
	v_fma_mix_f32 v175, v175, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a0257af
	v_fma_mix_f32 v184, v184, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a0257b8
	v_fma_mix_f32 v58, v185, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003a 8a0257b9
	v_fma_mix_f32 v185, v185, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a0257b9
	v_fma_mix_f32 v59, v186, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003b 8a0257ba
	v_fma_mix_f32 v186, v186, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a0257ba
	v_fma_mix_f32 v60, v191, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a0257bf
	v_fma_mix_f32 v191, v191, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a0257bf
	v_fma_mix_f32 v61, v2, v43, neg(0) op_sel_hi:[1,0,0]        ; cc20003d 8a025702
	v_fma_mix_f32 v2, v2, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200802 8a025702
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v46, v177, vcc_lo                     ; 0203632e
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v47, v178, vcc_lo                     ; 0203652f
	v_fma_mix_f32 v62, v13, v43, neg(0) op_sel_hi:[1,0,0]       ; cc20003e 8a02570d
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v44, v175, vcc_lo                     ; 02035f2c
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v45, v176, vcc_lo                     ; 0203612d
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v56, v183, vcc_lo                     ; 02036f38
	v_fma_mix_f32 v13, v13, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080d 8a02570d
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v57, v184, vcc_lo                     ; 02037139
	v_fma_mix_f32 v63, v20, v43, neg(0) op_sel_hi:[1,0,0]       ; cc20003f 8a025714
	v_fma_mix_f32 v20, v20, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a025714
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v58, v185, vcc_lo                     ; 0203733a
	v_fma_mix_f32 v64, v29, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200040 8a02571d
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v59, v186, vcc_lo                     ; 0203753b
	v_fma_mix_f32 v29, v29, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081d 8a02571d
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v60, v191, vcc_lo                     ; 02037f3c
	v_fma_mix_f32 v65, v30, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200041 8a02571e
	v_fma_mix_f32 v30, v30, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081e 8a02571e
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v61, v2, vcc_lo                       ; 0202053d
	v_fma_mix_f32 v66, v31, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200042 8a02571f
	v_fma_mix_f32 v31, v31, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081f 8a02571f
	v_fma_mix_f32 v67, v32, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200043 8a025720
	v_fma_mix_f32 v32, v32, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a025720
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v62, v13, vcc_lo                      ; 02021b3e
	v_lshl_add_u32 v179, v179, 5, s24                           ; d64600b3 00610bb3
	v_lshl_add_u32 v187, v187, 5, s24                           ; d64600bb 00610bbb
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v63, v20, vcc_lo                      ; 0202293f
	v_lshl_add_u32 v21, v21, 5, s24                             ; d6460015 00610b15
	v_lshl_add_u32 v33, v33, 5, s24                             ; d6460021 00610b21
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v64, v29, vcc_lo                      ; 02023b40
	v_lshl_add_u32 v180, v180, 5, s24                           ; d64600b4 00610bb4
	v_lshl_add_u32 v188, v188, 5, s24                           ; d64600bc 00610bbc
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v65, v30, vcc_lo                      ; 02023d41
	v_lshl_add_u32 v22, v22, 5, s24                             ; d6460016 00610b16
	v_lshl_add_u32 v34, v34, 5, s24                             ; d6460022 00610b22
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v66, v31, vcc_lo                      ; 02023f42
	v_lshl_add_u32 v181, v181, 5, s24                           ; d64600b5 00610bb5
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v67, v32, vcc_lo                      ; 02024143
	v_lshl_add_u32 v189, v189, 5, s24                           ; d64600bd 00610bbd
	v_lshl_add_u32 v23, v23, 5, s24                             ; d6460017 00610b17
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[179:180], v[187:188]            ; 1a0377b3
	v_lshl_add_u32 v35, v35, 5, s24                             ; d6460023 00610b23
	v_lshl_add_u32 v182, v182, 5, s24                           ; d64600b6 00610bb6
	v_lshl_add_u32 v190, v190, 5, s24                           ; d64600be 00610bbe
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[180:181], v[188:189]            ; 1a0379b4
	v_lshl_add_u32 v28, v28, 5, s24                             ; d646001c 00610b1c
	v_lshl_add_u32 v36, v36, 5, s24                             ; d6460024 00610b24
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[181:182], v[189:190]            ; 1a037bb5
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[21:22]                ; 1a022b44
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[182:183], v[190:191]            ; 1a037db6
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[22:23]                ; 1a022d45
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[23:24]                ; 1a022f46
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[33:34]                ; 1a024344
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[28:29]                ; 1a023947
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[34:35]                ; 1a024545
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[35:36]                ; 1a024746
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[36:37]                ; 1a024947
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[69:70]                ; 1a028b44
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[70:71]                ; 1a028d44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[71:72]                ; 1a028f44
	v_permlanex16_b32 v72, v68, s19, s20 op_sel:[1,1]           ; d65c1848 00502744
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[72:73]                ; 1a029144
	v_add_f16_e32 v73, v68, v196/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64938944
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v73, 0x400, v73                           ; 629292ff 00000400
	v_cvt_f32_f16_e32 v74, v73                                  ; 7e941749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v74, v74                                      ; 7e94554a
	v_fma_mix_f32 v79, v187, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004f 8a0295bb
	v_fma_mix_f32 v80, v188, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200050 8a0295bc
	v_fma_mix_f32 v76, v180, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004c 8a0295b4
	v_fma_mix_f32 v180, v180, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a0295b4
	v_fma_mix_f32 v187, v187, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a0295bb
	v_fma_mix_f32 v75, v179, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004b 8a0295b3
	v_fma_mix_f32 v179, v179, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a0295b3
	v_fma_mix_f32 v78, v182, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004e 8a0295b6
	v_fma_mix_f32 v182, v182, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a0295b6
	v_fma_mix_f32 v77, v181, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004d 8a0295b5
	v_fma_mix_f32 v181, v181, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a0295b5
	v_fma_mix_f32 v188, v188, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a0295bc
	v_fma_mix_f32 v81, v189, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200051 8a0295bd
	v_fma_mix_f32 v189, v189, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a0295bd
	v_fma_mix_f32 v82, v190, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200052 8a0295be
	v_fma_mix_f32 v190, v190, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a0295be
	v_fma_mix_f32 v83, v21, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200053 8a029515
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v79, v187, vcc_lo                     ; 0203774f
	v_fma_mix_f32 v21, v21, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a029515
	v_fma_mix_f32 v84, v22, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200054 8a029516
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v75, v179, vcc_lo                     ; 0203674b
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v76, v180, vcc_lo                     ; 0203694c
	v_fma_mix_f32 v22, v22, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a029516
	v_fma_mix_f32 v85, v23, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200055 8a029517
	v_fma_mix_f32 v23, v23, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a029517
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v77, v181, vcc_lo                     ; 02036b4d
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v78, v182, vcc_lo                     ; 02036d4e
	v_fma_mix_f32 v86, v28, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200056 8a02951c
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v80, v188, vcc_lo                     ; 02037950
	v_fma_mix_f32 v28, v28, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a02951c
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v81, v189, vcc_lo                     ; 02037b51
	v_fma_mix_f32 v87, v33, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200057 8a029521
	v_fma_mix_f32 v33, v33, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200821 8a029521
	v_fma_mix_f32 v88, v34, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200058 8a029522
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v82, v190, vcc_lo                     ; 02037d52
	v_fma_mix_f32 v34, v34, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200822 8a029522
	v_fma_mix_f32 v89, v35, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200059 8a029523
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v83, v21, vcc_lo                      ; 02022b53
	v_fma_mix_f32 v35, v35, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200823 8a029523
	v_fma_mix_f32 v90, v36, v74, neg(0) op_sel_hi:[1,0,0]       ; cc20005a 8a029524
	v_fma_mix_f32 v36, v36, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200824 8a029524
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[24:25], 0 ; cc464040 1a02310e
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v84, v22, vcc_lo                      ; 02022d54
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v85, v23, vcc_lo                      ; 02022f55
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[30:31], 0 ; cc464048 1a023d0e
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, 0              ; ca100080 0f0e0080
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v86, v28, vcc_lo                      ; 02023956
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v87, v33, vcc_lo                      ; 02024357
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v88, v34, vcc_lo                      ; 02024558
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v89, v35, vcc_lo                      ; 02024759
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v90, v36, vcc_lo                      ; 0202495a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[26:27], v[44:45], v[64:71] ; cc464040 1d02591a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[42:43], v[72:79] ; cc464048 1d22551a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[46:47], v[64:71] ; cc464040 1d025d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[20:21], v[72:79] ; cc464048 1d22290e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v59, v131, v7 :: v_dual_mul_f32 v58, v130, v6 ; c8c60f83 3b3a0d82
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v63, v135, v19 :: v_dual_mul_f32 v62, v134, v18 ; c8c62787 3f3e2586
	v_dual_mul_f32 v61, v133, v17 :: v_dual_mul_f32 v60, v132, v16 ; c8c62385 3d3c2184
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[56:57], v[64:71] ; cc464040 1d02710e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[22:23], v[72:79] ; cc464048 1d222d0e
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[24:25], 0   ; cc464040 1a023108
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[30:31], 0   ; cc464048 1a023d08
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[10:11], v[44:45], v[64:71] ; cc464040 1d02590a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[10:11], v[42:43], v[72:79] ; cc464048 1d22550a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[46:47], v[64:71] ; cc464040 1d025d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[20:21], v[72:79] ; cc464048 1d22290e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[56:57], v[64:71] ; cc464040 1d02710e
	v_dual_mul_f32 v57, v129, v5 :: v_dual_mul_f32 v56, v128, v4 ; c8c60b81 39380980
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[22:23], v[72:79] ; cc464048 1d222d0e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[38:39], v[26:27], v[56:63] ; cc464038 1ce23526
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_dual_mul_f32 v69, v149, v17 :: v_dual_mul_f32 v68, v148, v16 ; c8c62395 45442194
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_dual_mul_f32 v71, v151, v19 :: v_dual_mul_f32 v70, v150, v18 ; c8c62797 47462596
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_dual_mul_f32 v65, v145, v5 :: v_dual_mul_f32 v64, v144, v4 ; c8c60b91 41400990
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v67, v147, v7 :: v_dual_mul_f32 v66, v146, v6 ; c8c60f93 43420d92
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_cmp_lg_i32 s27, 0                                         ; bf01801b
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[38:39], v[28:29], v[64:71] ; cc464040 1d023926
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[40:41], v[8:9], v[56:63] ; cc464038 1ce21128
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[40:41], v[10:11], v[64:71] ; cc464040 1d021528
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_cbranch_scc1 BB38                                         ; bfa20007
BB36:
	v_add3_u32 v2, v3, s2, s13                                  ; d6550002 00340503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[4:5], v2, s[32:35], null offen           ; c406c07c 40804004 00000002
BB38:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_lg_i32 s28, 0                                         ; bf01801c
	s_cbranch_scc1 BB41                                         ; bfa20007
BB39:
	v_add3_u32 v2, v3, s2, s14                                  ; d6550002 00380503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[4:5], v2, s[32:35], null offen           ; c406c07c 40804004 00000002
BB41:
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[4:7], v0, s[36:39], null offen offset:64 ; c405c07c 40804804 00004000
	buffer_load_b128 v[16:19], v0, s[36:39], null offen offset:80 ; c405c07c 40804810 00005000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[14:15], v12, s[44:47], null offen offset:8 ; c405407c 4080580e 0000080c
	buffer_load_b64 v[12:13], v12, s[44:47], null offen offset:520 ; c405407c 4080580c 0002080c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v33, v153, v5 :: v_dual_mul_f32 v32, v152, v4 ; c8c60b99 21200998
	v_dual_mul_f32 v35, v155, v7 :: v_dual_mul_f32 v34, v154, v6 ; c8c60f9b 23220d9a
	v_dual_mul_f32 v41, v49, v5 :: v_dual_mul_f32 v40, v48, v4  ; c8c60b31 29280930
	v_dual_mul_f32 v43, v51, v7 :: v_dual_mul_f32 v42, v50, v6  ; c8c60f33 2b2a0d32
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v37, v157, v17 :: v_dual_mul_f32 v36, v156, v16 ; c8c6239d 2524219c
	v_dual_mul_f32 v39, v159, v19 :: v_dual_mul_f32 v38, v158, v18 ; c8c6279f 2726259e
	v_dual_mul_f32 v45, v53, v17 :: v_dual_mul_f32 v44, v52, v16 ; c8c62335 2d2c2134
	v_dual_mul_f32 v47, v55, v19 :: v_dual_mul_f32 v46, v54, v18 ; c8c62737 2f2e2536
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[14:15], v[26:27], v[32:39] ; cc464020 1c82350e
	s_mov_b32 s0, vcc_lo                                        ; be80006a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[14:15], v[28:29], v[40:47] ; cc464028 1ca2390e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[12:13], v[8:9], v[32:39] ; cc464020 1c82110c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[10:11], v[40:47] ; cc464028 1ca2150c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_cbranch_scc1 BB44                                         ; bfa20009
BB42:
	s_add_co_u32 s1, s2, 0x100                                  ; 8001ff02 00000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	v_add3_u32 v0, v3, s1, s13                                  ; d6550000 00340303
	v_add_nc_u32_e32 v0, v0, v1                                 ; 4a000300
	buffer_store_b64 v[4:5], v0, s[32:35], null offen           ; c406c07c 40804004 00000000
BB44:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB78                                         ; bfa21700
BB45:
	s_addk_co_i32 s2, 0x100                                     ; b7820100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v3, v3, s2, s14                                  ; d6550003 00380503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	buffer_store_b64 v[4:5], v3, s[32:35], null offen           ; c406c07c 40804004 00000003
	s_branch BB78                                               ; bfa016f6
BB48:
	s_cmp_eq_i32 s17, 10                                        ; bf008a11
	s_cbranch_scc0 BB62                                         ; bfa10b78
BB49:
	s_mov_b32 s13, s1                                           ; be8d0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[0:1], 0x0                           ; f4004400 f8000000
	s_load_b256 s[48:55], s[0:1], 0x30                          ; f4006c00 f8000030
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_max_i32 s14, s14, 0                                       ; 8a0e800e
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s14, s14, s12                                     ; 890e0c0e
	s_max_i32 s20, s20, 0                                       ; 8a148014
	s_add_co_u32 s15, s11, -1                                   ; 800fc10b
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	s_mul_i32 s14, s14, s11                                     ; 960e0b0e
	s_min_i32 s20, s20, s15                                     ; 89140f14
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_add_co_u32 s14, s14, s20                                  ; 800e140e
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_lshl_b32 s14, s14, 9                                      ; 840e890e
	s_add_co_u32 s21, s13, s14                                  ; 80150e0d
	s_max_i32 s29, s29, 0                                       ; 8a1d801d
	v_add3_u32 v5, v3, s21, 0x100                               ; d6550005 03fc2b03 00000100
	v_add3_u32 v4, v1, s21, v3                                  ; d6550004 040c2b01
	s_min_i32 s29, s29, s12                                     ; 891d0c1d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mul_i32 s29, s29, s11                                     ; 961d0b1d
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_add_co_u32 s29, s29, s20                                  ; 801d141d
	s_lshl_b32 s29, s29, 9                                      ; 841d891d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s13, s13, s29                                  ; 800d1d0d
	v_add3_u32 v9, v3, s13, 0x100                               ; d6550009 03fc1b03 00000100
	v_add3_u32 v8, v1, s13, v3                                  ; d6550008 040c1b01
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v9, v9, v1                                 ; 4a120309
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[6:7], v4, s[16:19], null offen            ; c405407c 40802006 00000004
	buffer_load_b64 v[4:5], v5, s[16:19], null offen            ; c405407c 40802004 00000005
	buffer_load_b64 v[10:11], v8, s[16:19], null offen          ; c405407c 4080200a 00000008
	buffer_load_b64 v[8:9], v9, s[16:19], null offen            ; c405407c 40802008 00000009
	v_lshlrev_b32_e32 v12, 2, v0                                ; 30180082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v13, s3, v12, 2                              ; d647000d 020a1803
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[16:19], v13, s[52:55], null offen        ; c405c07c 40806810 0000000d
	buffer_load_b128 v[20:23], v13, s[52:55], null offen offset:512 ; c405c07c 40806814 0002000d
	buffer_load_b128 v[24:27], v13, s[52:55], null offen offset:1024 ; c405c07c 40806818 0004000d
	buffer_load_b128 v[28:31], v13, s[52:55], null offen offset:1536 ; c405c07c 4080681c 0006000d
	buffer_load_b128 v[32:35], v13, s[52:55], null offen offset:2048 ; c405c07c 40806820 0008000d
	buffer_load_b128 v[36:39], v13, s[52:55], null offen offset:2560 ; c405c07c 40806824 000a000d
	buffer_load_b128 v[40:43], v13, s[52:55], null offen offset:3072 ; c405c07c 40806828 000c000d
	buffer_load_b128 v[44:47], v13, s[52:55], null offen offset:3584 ; c405c07c 4080682c 000e000d
	v_lshrrev_b32_e32 v0, 4, v0                                 ; 32000084
	s_mov_b64 s[24:25], s[48:49]                                ; be980130
	s_mov_b64 s[26:27], s[50:51]                                ; be9a0132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshlrev_b32_e32 v0, 3, v0                                 ; 30000083
	v_add_lshl_u32 v14, s8, v0, 2                               ; d647000e 020a0008
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v14, s[24:27], null offen        ; c405c07c 40803030 0000000e
	buffer_load_b128 v[52:55], v14, s[24:27], null offen offset:16 ; c405c07c 40803034 0000100e
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add_lshl_u32 v15, s4, v12, 2                              ; d647000f 020a1804
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[56:59], v15, s[52:55], null offen        ; c405c07c 40806838 0000000f
	buffer_load_b128 v[60:63], v15, s[52:55], null offen offset:512 ; c405c07c 4080683c 0002000f
	buffer_load_b128 v[64:67], v15, s[52:55], null offen offset:1024 ; c405c07c 40806840 0004000f
	buffer_load_b128 v[68:71], v15, s[52:55], null offen offset:1536 ; c405c07c 40806844 0006000f
	buffer_load_b128 v[72:75], v15, s[52:55], null offen offset:2048 ; c405c07c 40806848 0008000f
	buffer_load_b128 v[76:79], v15, s[52:55], null offen offset:2560 ; c405c07c 4080684c 000a000f
	buffer_load_b128 v[80:83], v15, s[52:55], null offen offset:3072 ; c405c07c 40806850 000c000f
	buffer_load_b128 v[84:87], v15, s[52:55], null offen offset:3584 ; c405c07c 40806854 000e000f
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_cndmask_b32_e64 v6, v6, 0, s22                            ; d5010006 00590106
	v_cndmask_b32_e64 v7, v7, 0, s22                            ; d5010007 00590107
	s_wait_loadcnt 0x14                                         ; bfc00014
	v_cndmask_b32_e64 v4, v4, 0, s22                            ; d5010004 00590104
	v_cndmask_b32_e64 v5, v5, 0, s22                            ; d5010005 00590105
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_cndmask_b32_e64 v10, v10, 0, s37                          ; d501000a 0095010a
	v_cndmask_b32_e64 v11, v11, 0, s37                          ; d501000b 0095010b
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v8, v8, 0, s37                            ; d5010008 00950108
	v_cndmask_b32_e64 v9, v9, 0, s37                            ; d5010009 00950109
	v_cvt_pk_f32_fp8_e32 v[92:93], v134                         ; 7eb8dd86
	v_cvt_pk_f32_fp8_e32 v[90:91], v6                           ; 7eb4dd06
	v_cvt_pk_f32_fp8_e32 v[94:95], v7                           ; 7ebcdd07
	v_dual_mov_b32 v89, v7 :: v_dual_mov_b32 v88, v6            ; ca100107 59580106
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	v_dual_mov_b32 v97, v5 :: v_dual_mov_b32 v96, v4            ; ca100105 61600104
	v_dual_mov_b32 v99, v11 :: v_dual_mov_b32 v98, v10          ; ca10010b 6362010a
	v_cvt_pk_f32_fp8_e32 v[100:101], v10                        ; 7ec8dd0a
	v_cvt_pk_f32_fp8_e32 v[102:103], v138                       ; 7eccdd8a
	v_cvt_pk_f32_fp8_e32 v[104:105], v11                        ; 7ed0dd0b
	v_dual_mov_b32 v107, v9 :: v_dual_mov_b32 v106, v8          ; ca100109 6b6a0108
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[88:89], 0 ; cc464070 1a02b110
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[88:89], 0 ; cc464080 1a02b112
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[98:99], 0 ; cc464078 1a02c510
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[98:99], 0 ; cc464088 1a02c512
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[96:97], v[112:119] ; cc464070 1dc2c114
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[20:21], v[106:107], v[120:127] ; cc464078 1de2d514
	v_maxmin_num_f32 v20, -4.0, v114, 4.0                       ; d6690014 03dae4f7
	v_maxmin_num_f32 v18, -4.0, v113, 4.0                       ; d6690012 03dae2f7
	v_maxmin_num_f32 v108, -4.0, v115, 4.0                      ; d669006c 03dae6f7
	v_maxmin_num_f32 v110, -4.0, v116, 4.0                      ; d669006e 03dae8f7
	v_maxmin_num_f32 v16, -4.0, v112, 4.0                       ; d6690010 03dae0f7
	v_fma_mix_f32 v21, 0xab28, |v20|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfe28ff 3728ab28
	v_fma_mix_f32 v19, 0xab28, |v18|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206213 0bfe24ff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v17, 0xab28, |v16|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206211 0bfe20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fmaak_f32 v109, v109, v108, 0x3f650000                    ; 5adad96d 3f650000
	v_dual_fmaak_f32 v19, v19, v18, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v17, 0x3f650000 ; c8422513 13102310 3f650000
	v_maxmin_num_f32 v144, -4.0, v121, 4.0                      ; d6690090 03daf2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_mul_f32 v115, v109, v115 :: v_dual_fmaak_f32 v20, v20, v21, 0x3f650000 ; c8c2e76d 73142b14 3f650000
	v_dual_mul_f32 v113, v113, v19 :: v_dual_mul_f32 v112, v112, v16 ; c8c62771 71702170
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v117, 4.0                      ; d6690070 03daeaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v123, 4.0                      ; d6690094 03daf6f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v122, 4.0                      ; d6690092 03daf4f7
	v_dual_mul_f32 v117, v117, v113 :: v_dual_mul_f32 v116, v116, v110 ; c8c6e375 7574dd74
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v125, 4.0                      ; d6690098 03dafaf7
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v116, -4.0, v119, 4.0                      ; d6690074 03daeef7
	v_maxmin_num_f32 v150, -4.0, v124, 4.0                      ; d6690096 03daf8f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v127, 4.0                      ; d669009c 03dafef7
	v_dual_fmaak_f32 v117, v116, v117, 0x3f650000 :: v_dual_mul_f32 v114, v114, v20 ; c846eb74 75722972 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v126, 4.0                      ; d669009a 03dafcf7
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v118, 4.0                      ; d6690072 03daecf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[96:97], v[128:135] ; cc464080 1e02c116
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_dual_mul_f32 v119, v119, v117 :: v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 ; c8c2eb77 7772e772 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v118, v118, v114 ; c8472191 9176e576 3f650000
	v_maxmin_num_f32 v160, -4.0, v129, 4.0                      ; d66900a0 03db02f7
	v_maxmin_num_f32 v158, -4.0, v128, 4.0                      ; d669009e 03db00f7
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v120, 4.0                      ; d6690076 03daf0f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v131, 4.0                      ; d66900a4 03db06f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v130, 4.0                      ; d66900a2 03db04f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_mul_f32 v121, v121, v145 :: v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 ; c8c32379 7976ef76 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[106:107], v[136:143] ; cc464088 1e22d516
	v_maxmin_num_f32 v168, -4.0, v133, 4.0                      ; d66900a8 03db0af7
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v120, v120, v118 ; c8472995 9578ed78 3f650000
	v_maxmin_num_f32 v166, -4.0, v132, 4.0                      ; d66900a6 03db08f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d3
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v123, v123, v149 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8c32b7b 7b932792 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v135, 4.0                      ; d66900ac 03db0ef7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v122, v122, v146 ; c8473199 997b257a 3f650000
	v_maxmin_num_f32 v170, -4.0, v134, 4.0                      ; d66900aa 03db0cf7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v125, v125, v153 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8c3337d 7d972f96 3f650000
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v137, 4.0                      ; d66900b0 03db12f7
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v124, v124, v150 ; c847399d 9d7d2d7c 3f650000
	v_maxmin_num_f32 v174, -4.0, v136, 4.0                      ; d66900ae 03db10f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_dual_mul_f32 v127, v127, v157 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8c33b7f 7f9b379a 3f650000
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v139, 4.0                      ; d66900b4 03db16f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_mul_f32 v126, v126, v154 ; c84741a1 a17f357e 3f650000
	v_maxmin_num_f32 v178, -4.0, v138, 4.0                      ; d66900b2 03db14f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v129, v129, v161 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c8c34381 819f3f9e 3f650000
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v141, 4.0                      ; d66900b8 03db1af7
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_mul_f32 v128, v128, v158 ; c84749a5 a5813d80 3f650000
	v_maxmin_num_f32 v182, -4.0, v140, 4.0                      ; d66900b6 03db18f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v131, v131, v165 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8c34b83 83a347a2 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v143, 4.0                      ; d66900bc 03db1ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_mul_f32 v130, v130, v162 ; c84751a9 a9834582 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[88:89], 0 ; cc464070 1a02b118
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v133, v133, v169 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c8c35385 85a74fa6 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v132, v132, v166 ; c84759ad ad854d84 3f650000
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[96:97], v[112:119] ; cc464070 1dc2c11c
	v_dual_mul_f32 v135, v135, v173 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8c35b87 87ab57aa 3f650000
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v186, -4.0, v142, 4.0                      ; d66900ba 03db1cf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_mul_f32 v134, v134, v170 ; c84761b1 b1875586 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v112, 4.0                      ; d66900be 03dae0f7
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v137, v137, v177 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c8c36389 89af5fae 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[98:99], 0 ; cc464078 1a02c518
	v_maxmin_num_f32 v15, -4.0, v114, 4.0                       ; d669000f 03dae4f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v136, v136, v174 ; c84769b5 b5895d88 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v25, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe1eff 3728ab28
	v_dual_mul_f32 v139, v139, v181 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c8c36b8b 8bb367b2 3f650000
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[106:107], v[120:127] ; cc464078 1de2d51c
	v_maxmin_num_f32 v28, -4.0, v115, 4.0                       ; d669001c 03dae6f7
	v_fmaak_f32 v15, v15, v25, 0x3f650000                       ; 5a1e330f 3f650000
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_mul_f32 v138, v138, v178 ; c84771b9 b98b658a 3f650000
	v_maxmin_num_f32 v108, -4.0, v116, 4.0                      ; d669006c 03dae8f7
	v_maxmin_num_f32 v110, -4.0, v117, 4.0                      ; d669006e 03daeaf7
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v141, v141, v185 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c8c3738d 8db76fb6 3f650000
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v140, v140, v182 ; c84779bd bd8d6d8c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b8f 8fbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v113, 4.0                      ; d66900bf 03dae2f7
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v108 ; c8c6df75 7574d974
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 :: v_dual_mul_f32 v112, v112, v190 ; c846391d 1d717d70 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v115, v115, v29 :: v_dual_mul_f32 v114, v114, v15 ; c8c63b73 73721f72
	v_dual_fmaak_f32 v13, v191, v13, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8421bbf 0dbb77ba 3f650000
	v_maxmin_num_f32 v116, -4.0, v120, 4.0                      ; d6690074 03daf0f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v113, v113, v13 :: v_dual_mul_f32 v142, v142, v186 ; c8c61b71 718f758e
	v_maxmin_num_f32 v128, -4.0, v123, 4.0                      ; d6690080 03daf6f7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v118, 4.0                      ; d6690070 03daecf7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v119, 4.0                      ; d6690072 03daeef7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v125, 4.0                      ; d6690084 03dafaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v124, 4.0                      ; d6690082 03daf8f7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c8430181 8174eb74 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v127, 4.0                      ; d6690088 03dafef7
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_mul_f32 v123, v123, v129 :: v_dual_mul_f32 v120, v120, v116 ; c8c7037b 7b78e978
	v_maxmin_num_f32 v134, -4.0, v126, 4.0                      ; d6690086 03dafcf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v119, v119, v115 :: v_dual_mul_f32 v118, v118, v112 ; c8c6e777 7776e176
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8431189 89830782 3f650000
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v121, 4.0                      ; d6690076 03daf2f7
	v_dual_mul_f32 v127, v127, v137 :: v_dual_mul_f32 v124, v124, v130 ; c8c7137f 7f7d057c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fmaak_f32 v119, v119, v118, 0x3f650000                    ; 5aeeed77 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_mul_f32_e32 v121, v121, v119                              ; 10f2ef79
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[88:89], 0 ; cc464070 1a02b11a
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v122, 4.0                      ; d6690078 03daf4f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[96:97], v[112:119] ; cc464070 1dc2c11e
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8430985 8578f378 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_mul_f32 v125, v125, v133 :: v_dual_mul_f32 v122, v122, v120 ; c8c70b7d 7d7af17a
	v_maxmin_num_f32 v140, -4.0, v113, 4.0                      ; d669008c 03dae2f7
	v_maxmin_num_f32 v142, -4.0, v114, 4.0                      ; d669008e 03dae4f7
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v144, -4.0, v115, 4.0                      ; d6690090 03dae6f7
	v_maxmin_num_f32 v138, -4.0, v112, 4.0                      ; d669008a 03dae0f7
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v148, -4.0, v117, 4.0                      ; d6690094 03daeaf7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v116, 4.0                      ; d6690092 03dae8f7
	v_maxmin_num_f32 v152, -4.0, v119, 4.0                      ; d6690098 03daeef7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c843198d 8d870f86 3f650000
	v_maxmin_num_f32 v150, -4.0, v118, 4.0                      ; d6690096 03daecf7
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c8432191 918b178a 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432995 958f1f8e 3f650000
	v_dual_mul_f32 v113, v113, v141 :: v_dual_mul_f32 v126, v126, v134 ; c8c71b71 717f0d7e
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8433199 99932792 3f650000
	v_dual_mul_f32 v115, v115, v145 :: v_dual_mul_f32 v112, v112, v138 ; c8c72373 73711570
	v_dual_mul_f32 v117, v117, v149 :: v_dual_mul_f32 v114, v114, v142 ; c8c72b75 75731d72
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[98:99], 0 ; cc464078 1a02c51a
	v_dual_mul_f32 v119, v119, v153 :: v_dual_mul_f32 v116, v116, v146 ; c8c73377 77752574
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[106:107], v[120:127] ; cc464078 1de2d51e
	v_maxmin_num_f32 v160, -4.0, v123, 4.0                      ; d66900a0 03daf6f7
	v_maxmin_num_f32 v154, -4.0, v120, 4.0                      ; d669009a 03daf0f7
	v_maxmin_num_f32 v158, -4.0, v122, 4.0                      ; d669009e 03daf4f7
	v_maxmin_num_f32 v156, -4.0, v121, 4.0                      ; d669009c 03daf2f7
	v_maxmin_num_f32 v164, -4.0, v125, 4.0                      ; d66900a4 03dafaf7
	v_maxmin_num_f32 v162, -4.0, v124, 4.0                      ; d66900a2 03daf8f7
	v_maxmin_num_f32 v168, -4.0, v127, 4.0                      ; d66900a8 03dafef7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v126, 4.0                      ; d66900a6 03dafcf7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c84341a1 a19b379a 3f650000
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c843399d 9d972f96 3f650000
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84349a5 a59f3f9e 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84351a9 a9a347a2 3f650000
	v_dual_mul_f32 v123, v123, v161 :: v_dual_mul_f32 v120, v120, v154 ; c8c7437b 7b793578
	v_dual_mul_f32 v121, v121, v157 :: v_dual_mul_f32 v118, v118, v150 ; c8c73b79 79772d76
	v_dual_mul_f32 v125, v125, v165 :: v_dual_mul_f32 v122, v122, v158 ; c8c74b7d 7d7b3d7a
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v127, v127, v169 :: v_dual_mul_f32 v124, v124, v162 ; c8c7537f 7f7d457c
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[88:89], 0 ; cc464070 1a02b120
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[96:97], v[112:119] ; cc464070 1dc2c124
	v_maxmin_num_f32 v174, -4.0, v114, 4.0                      ; d66900ae 03dae4f7
	v_maxmin_num_f32 v176, -4.0, v115, 4.0                      ; d66900b0 03dae6f7
	v_maxmin_num_f32 v172, -4.0, v113, 4.0                      ; d66900ac 03dae2f7
	v_maxmin_num_f32 v170, -4.0, v112, 4.0                      ; d66900aa 03dae0f7
	v_maxmin_num_f32 v180, -4.0, v117, 4.0                      ; d66900b4 03daeaf7
	v_maxmin_num_f32 v178, -4.0, v116, 4.0                      ; d66900b2 03dae8f7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v119, 4.0                      ; d66900b8 03daeef7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v118, 4.0                      ; d66900b6 03daecf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84359ad ada74fa6 3f650000
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84361b1 b1ab57aa 3f650000
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84369b5 b5af5fae 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84371b9 b9b367b2 3f650000
	v_dual_mul_f32 v113, v113, v173 :: v_dual_mul_f32 v126, v126, v166 ; c8c75b71 717f4d7e
	v_dual_mul_f32 v115, v115, v177 :: v_dual_mul_f32 v112, v112, v170 ; c8c76373 73715570
	v_dual_mul_f32 v117, v117, v181 :: v_dual_mul_f32 v114, v114, v174 ; c8c76b75 75735d72
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v119, v119, v185 :: v_dual_mul_f32 v116, v116, v178 ; c8c77377 77756574
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[98:99], 0 ; cc464078 1a02c520
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[106:107], v[120:127] ; cc464078 1de2d524
	v_maxmin_num_f32 v190, -4.0, v122, 4.0                      ; d66900be 03daf4f7
	v_maxmin_num_f32 v188, -4.0, v121, 4.0                      ; d66900bc 03daf2f7
	v_maxmin_num_f32 v186, -4.0, v120, 4.0                      ; d66900ba 03daf0f7
	v_maxmin_num_f32 v15, -4.0, v124, 4.0                       ; d669000f 03daf8f7
	v_maxmin_num_f32 v108, -4.0, v125, 4.0                      ; d669006c 03dafaf7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v126, 4.0                      ; d669006e 03dafcf7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v127, 4.0                      ; d6690070 03dafef7
	v_fma_mix_f32 v37, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfe1eff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84379bd bdb76fb6 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v121, v121, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b79 79bf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v123, 4.0                      ; d66900bf 03daf6f7
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_mul_f32 v122, v122, v190 ; c846d96d 6d7b7d7a 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_dual_mul_f32 v127, v127, v113 :: v_dual_mul_f32 v126, v126, v110 ; c8c6e37f 7f7edd7e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v13, v13, v191, 0x3f650000 :: v_dual_mul_f32 v118, v118, v182 ; c8477f0d 0d776d76 3f650000
	v_dual_mul_f32 v123, v123, v13 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8c21b7b 7bbb77ba 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[88:89], 0 ; cc464070 1a02b122
	v_dual_fmaak_f32 v15, v15, v37, 0x3f650000 :: v_dual_mul_f32 v120, v120, v186 ; c8464b0f 0f797578 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v125, v125, v109 :: v_dual_mul_f32 v124, v124, v15 ; c8c6db7d 7d7c1f7c
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[96:97], v[112:119] ; cc464070 1dc2c126
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[98:99], 0 ; cc464078 1a02c522
	v_maxmin_num_f32 v136, -4.0, v116, 4.0                      ; d6690088 03dae8f7
	v_maxmin_num_f32 v132, -4.0, v114, 4.0                      ; d6690084 03dae4f7
	v_maxmin_num_f32 v138, -4.0, v117, 4.0                      ; d669008a 03daeaf7
	v_maxmin_num_f32 v130, -4.0, v113, 4.0                      ; d6690082 03dae2f7
	v_maxmin_num_f32 v134, -4.0, v115, 4.0                      ; d6690086 03dae6f7
	v_maxmin_num_f32 v128, -4.0, v112, 4.0                      ; d6690080 03dae0f7
	v_maxmin_num_f32 v140, -4.0, v118, 4.0                      ; d669008c 03daecf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v119, 4.0                      ; d669008e 03daeef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[106:107], v[120:127] ; cc464078 1de2d526
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c843158b 8b891388 3f650000
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430d87 87850b84 3f650000
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 ; c8431d8f 8f8d1b8c 3f650000
	v_dual_mul_f32 v117, v117, v139 :: v_dual_mul_f32 v116, v116, v136 ; c8c71775 75751174
	v_dual_mul_f32 v115, v115, v135 :: v_dual_mul_f32 v114, v114, v132 ; c8c70f73 73730972
	v_maxmin_num_f32 v148, -4.0, v122, 4.0                      ; d6690094 03daf4f7
	v_dual_mul_f32 v113, v113, v131 :: v_dual_mul_f32 v112, v112, v128 ; c8c70771 71710170
	v_maxmin_num_f32 v144, -4.0, v120, 4.0                      ; d6690090 03daf0f7
	v_maxmin_num_f32 v150, -4.0, v123, 4.0                      ; d6690096 03daf6f7
	v_maxmin_num_f32 v146, -4.0, v121, 4.0                      ; d6690092 03daf2f7
	v_dual_mul_f32 v119, v119, v143 :: v_dual_mul_f32 v118, v118, v140 ; c8c71f77 77771976
	v_maxmin_num_f32 v152, -4.0, v124, 4.0                      ; d6690098 03daf8f7
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v154, -4.0, v125, 4.0                      ; d669009a 03dafaf7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v126, 4.0                      ; d669009c 03dafcf7
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v127, 4.0                      ; d669009e 03dafef7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[88:89], 0 ; cc464070 1a02b128
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_dual_mul_f32 v123, v123, v151 :: v_dual_mul_f32 v122, v122, v148 ; c8c72f7b 7b7b297a
	v_dual_mul_f32 v121, v121, v147 :: v_dual_mul_f32 v120, v120, v144 ; c8c72779 79792178
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_dual_mul_f32 v125, v125, v155 :: v_dual_mul_f32 v124, v124, v152 ; c8c7377d 7d7d317c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[96:97], v[112:119] ; cc464070 1dc2c12c
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v127, v127, v159 :: v_dual_mul_f32 v126, v126, v156 ; c8c73f7f 7f7f397e
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[98:99], 0 ; cc464078 1a02c528
	v_maxmin_num_f32 v168, -4.0, v116, 4.0                      ; d66900a8 03dae8f7
	v_maxmin_num_f32 v162, -4.0, v113, 4.0                      ; d66900a2 03dae2f7
	v_maxmin_num_f32 v164, -4.0, v114, 4.0                      ; d66900a4 03dae4f7
	v_maxmin_num_f32 v160, -4.0, v112, 4.0                      ; d66900a0 03dae0f7
	v_maxmin_num_f32 v166, -4.0, v115, 4.0                      ; d66900a6 03dae6f7
	v_maxmin_num_f32 v170, -4.0, v117, 4.0                      ; d66900aa 03daeaf7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v118, 4.0                      ; d66900ac 03daecf7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	buffer_load_b128 v[108:111], v14, s[24:27], null offen offset:64 ; c405c07c 4080306c 0000400e
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	v_dual_mul_f32 v113, v113, v163 :: v_dual_mul_f32 v112, v112, v160 ; c8c74771 71714170
	v_dual_mul_f32 v115, v115, v167 :: v_dual_mul_f32 v114, v114, v164 ; c8c74f73 73734972
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	buffer_load_b128 v[112:115], v14, s[24:27], null offen offset:80 ; c405c07c 40803070 0000500e
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v119, 4.0                      ; d66900ae 03daeef7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[106:107], v[120:127] ; cc464078 1de2d52c
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c84355ab aba953a8 3f650000
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v117, v117, v171 :: v_dual_mul_f32 v116, v116, v168 ; c8c75775 75755174
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 ; c8435daf afad5bac 3f650000
	v_maxmin_num_f32 v180, -4.0, v122, 4.0                      ; d66900b4 03daf4f7
	v_maxmin_num_f32 v182, -4.0, v123, 4.0                      ; d66900b6 03daf6f7
	v_maxmin_num_f32 v178, -4.0, v121, 4.0                      ; d66900b2 03daf2f7
	v_maxmin_num_f32 v184, -4.0, v124, 4.0                      ; d66900b8 03daf8f7
	v_maxmin_num_f32 v176, -4.0, v120, 4.0                      ; d66900b0 03daf0f7
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v186, -4.0, v125, 4.0                      ; d66900ba 03dafaf7
	v_dual_mul_f32 v119, v119, v175 :: v_dual_mul_f32 v118, v118, v172 ; c8c75f77 77775976
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v126, 4.0                      ; d66900bc 03dafcf7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v127, 4.0                      ; d66900be 03dafef7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c8436db7 b7b56bb4 3f650000
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84365b3 b3b163b0 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[98:99], 0 ; cc464080 1a02c52a
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84375bb bbb973b8 3f650000
	v_dual_mul_f32 v123, v123, v183 :: v_dual_mul_f32 v122, v122, v180 ; c8c76f7b 7b7b697a
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8437dbf bfbd7bbc 3f650000
	v_dual_mul_f32 v121, v121, v179 :: v_dual_mul_f32 v120, v120, v176 ; c8c76779 79796178
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v125, v125, v187 :: v_dual_mul_f32 v124, v124, v184 ; c8c7777d 7d7d717c
	v_dual_mul_f32 v127, v127, v191 :: v_dual_mul_f32 v126, v126, v188 ; c8c77f7f 7f7f797e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[106:107], v[128:135] ; cc464080 1e02d52e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[88:89], 0 ; cc464078 1a02b12a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[96:97], v[120:127] ; cc464078 1de2c12e
	v_maxmin_num_f32 v88, -4.0, v124, 4.0                       ; d6690058 03daf8f7
	v_maxmin_num_f32 v96, -4.0, v125, 4.0                       ; d6690060 03dafaf7
	v_maxmin_num_f32 v191, -4.0, v120, 4.0                      ; d66900bf 03daf0f7
	v_maxmin_num_f32 v42, -4.0, v121, 4.0                       ; d669002a 03daf2f7
	v_maxmin_num_f32 v46, -4.0, v123, 4.0                       ; d669002e 03daf6f7
	v_maxmin_num_f32 v44, -4.0, v122, 4.0                       ; d669002c 03daf4f7
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_fma_mix_f32 v43, 0xab28, |v42|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622b 0bfe54ff 3728ab28
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v98, s5, v12, 2                              ; d6470062 020a1805
	v_fma_mix_f32 v47, 0xab28, |v46|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622f 0bfe5cff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v126, 4.0                       ; d6690063 03dafcf7
	v_fma_mix_f32 v45, 0xab28, |v44|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe58ff 3728ab28
	v_fmaak_f32 v191, v191, v13, 0x3f650000                     ; 5b7e1bbf 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_dual_fmaak_f32 v47, v47, v46, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c8425d2f 2f58b358 3f650000
	v_dual_fmaak_f32 v43, v43, v42, 0x3f650000 :: v_dual_mul_f32 v120, v120, v191 ; c846552b 2b797f78 3f650000
	v_maxmin_num_f32 v107, -4.0, v127, 4.0                      ; d669006b 03dafef7
	v_fma_mix_f32 v106, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfec6ff 3728ab28
	v_dual_mul_f32 v124, v124, v88 :: v_dual_mul_f32 v123, v123, v47 ; c8c6b17c 7c7a5f7b
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v121, v121, v43 :: v_dual_fmaak_f32 v44, v44, v45, 0x3f650000 ; c8c25779 792c5b2c 3f650000
	v_fmaak_f32 v99, v99, v106, 0x3f650000                      ; 5ac6d563 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v97, v96, v97, 0x3f650000 :: v_dual_mul_f32 v122, v122, v44 ; c846c360 617a597a 3f650000
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_fma_mix_f32 v120, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfed6ff 3728ab28
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fmaak_f32 v120, v120, v107, 0x3f650000                    ; 5af0d778 3f650000
	v_dual_mul_f32 v126, v126, v99 :: v_dual_mul_f32 v127, v127, v120 ; c8c6c77e 7e7ef17f
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[44:47], v98, s[52:55], null offen        ; c405c07c 4080682c 00000062
	buffer_load_b128 v[116:119], v98, s[52:55], null offen offset:1024 ; c405c07c 40806874 00040062
	buffer_load_b128 v[120:123], v98, s[52:55], null offen offset:2048 ; c405c07c 40806878 00080062
	buffer_load_b128 v[136:139], v98, s[52:55], null offen offset:512 ; c405c07c 40806888 00020062
	v_mul_f32_e32 v125, v125, v97                               ; 10fac37d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870251
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v128, 4.0                      ; d669007c 03db00f7
	v_maxmin_num_f32 v140, -4.0, v131, 4.0                      ; d669008c 03db06f7
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v129, 4.0                      ; d669007e 03db02f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_fmaak_f32 v124, v124, v125, 0x3f650000                    ; 5af8fb7c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fmaak_f32 v127, v127, v126, 0x3f650000                    ; 5afefd7f 3f650000
	v_dual_mul_f32 v129, v129, v127 :: v_dual_mul_f32 v128, v128, v124 ; c8c6ff81 8180f980
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[124:127], v98, s[52:55], null offen offset:1536 ; c405c07c 4080687c 00060062
	buffer_load_b128 v[96:99], v98, s[52:55], null offen offset:2560 ; c405c07c 40806860 000a0062
	v_maxmin_num_f32 v142, -4.0, v132, 4.0                      ; d669008e 03db08f7
	v_maxmin_num_f32 v144, -4.0, v133, 4.0                      ; d6690090 03db0af7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v134, 4.0                      ; d6690092 03db0cf7
	v_maxmin_num_f32 v148, -4.0, v135, 4.0                      ; d6690094 03db0ef7
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v128, -4.0, v130, 4.0                      ; d6690080 03db04f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432191 918f1f8e 3f650000
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_mul_f32 v151, v11, v55 :: v_dual_mul_f32 v150, v10, v54 ; c8c66f0b 97966d0a
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8432995 95932792 3f650000
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c843198d 8d810380 3f650000
	v_dual_mul_f32 v133, v133, v145 :: v_dual_mul_f32 v132, v132, v142 ; c8c72385 85851d84
	v_dual_mul_f32 v145, v101, v49 :: v_dual_mul_f32 v144, v100, v48 ; c8c66365 91906164
	v_dual_mul_f32 v135, v135, v149 :: v_dual_mul_f32 v134, v134, v146 ; c8c72b87 87872586
	v_dual_mul_f32 v147, v103, v51 :: v_dual_mul_f32 v146, v102, v50 ; c8c66767 93926566
	v_dual_mul_f32 v149, v105, v53 :: v_dual_mul_f32 v148, v104, v52 ; c8c66b69 95946968
	v_dual_mul_f32 v131, v131, v141 :: v_dual_mul_f32 v130, v130, v128 ; c8c71b83 83830182
	v_dual_mul_f32 v129, v91, v49 :: v_dual_mul_f32 v128, v90, v48 ; c8c6635b 8180615a
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v133, v95, v53 :: v_dual_mul_f32 v132, v94, v52 ; c8c66b5f 8584695e
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[18:19], v[144:151] ; cc464090 1e422538
	s_bitset0_b32 s49, 14                                       ; beb1108e
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_buffer_load_b32 s10, s[48:51], s10 offset:0x0             ; f4020298 14000000
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v135, v7, v55 :: v_dual_mul_f32 v134, v6, v54 ; c8c66f07 87866d06
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v131, v93, v51 :: v_dual_mul_f32 v130, v92, v50 ; c8c6675d 8382655c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[16:17], v[128:135] ; cc464080 1e022138
	v_cvt_pk_f32_fp8_e32 v[48:49], v4                           ; 7e60dd04
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[22:23], v[144:151] ; cc464090 1e422d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[20:21], v[128:135] ; cc464080 1e02293c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[64:65], v[28:29], v[144:151] ; cc464090 1e423940
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[64:65], v[24:25], v[128:135] ; cc464080 1e023140
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[30:31], v[144:151] ; cc464090 1e423d44
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mul_f32 v153, v49, v109 :: v_dual_mul_f32 v152, v48, v108 ; c8c6db31 9998d930
	v_cvt_pk_f32_fp8_e32 v[48:49], v132                         ; 7e60dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[26:27], v[128:135] ; cc464080 1e023544
	v_dual_mul_f32 v155, v49, v111 :: v_dual_mul_f32 v154, v48, v110 ; c8c6df31 9b9add30
	v_cvt_pk_f32_fp8_e32 v[48:49], v5                           ; 7e60dd05
	v_cvt_pk_f32_fp8_e32 v[4:5], v133                           ; 7e08dd85
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[36:37], v[144:151] ; cc464090 1e424948
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v157, v49, v113 :: v_dual_mul_f32 v156, v48, v112 ; c8c6e331 9d9ce130
	v_dual_mul_f32 v159, v5, v115 :: v_dual_mul_f32 v158, v4, v114 ; c8c6e705 9f9ee504
	v_cvt_pk_f32_fp8_e32 v[4:5], v8                             ; 7e08dd08
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[32:33], v[128:135] ; cc464080 1e024148
	v_dual_mul_f32 v49, v5, v109 :: v_dual_mul_f32 v48, v4, v108 ; c8c6db05 3130d904
	v_cvt_pk_f32_fp8_e32 v[4:5], v136                           ; 7e08dd88
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[76:77], v[38:39], v[144:151] ; cc464090 1e424d4c
	v_dual_mul_f32 v51, v5, v111 :: v_dual_mul_f32 v50, v4, v110 ; c8c6df05 3332dd04
	v_cvt_pk_f32_fp8_e32 v[4:5], v9                             ; 7e08dd09
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[34:35], v[128:135] ; cc464080 1e02454c
	v_dual_mul_f32 v53, v5, v113 :: v_dual_mul_f32 v52, v4, v112 ; c8c6e305 3534e104
	v_cvt_pk_f32_fp8_e32 v[4:5], v137                           ; 7e08dd89
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[80:81], v[14:15], v[144:151] ; cc464090 1e421d50
	v_dual_mul_f32 v55, v5, v115 :: v_dual_mul_f32 v54, v4, v114 ; c8c6e705 3736e504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[58:59], v[18:19], v[48:55] ; cc464030 1cc2253a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[40:41], v[128:135] ; cc464080 1e025150
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[88:89], v[144:151] ; cc464090 1e42b154
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[62:63], v[22:23], v[48:55] ; cc464030 1cc22d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[42:43], v[128:135] ; cc464080 1e025554
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[16:17], v[152:159] ; cc464098 1e62213a
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[66:67], v[28:29], v[48:55] ; cc464030 1cc23942
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[20:21], v[152:159] ; cc464098 1e62293e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[70:71], v[30:31], v[48:55] ; cc464030 1cc23d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[24:25], v[152:159] ; cc464098 1e623142
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[74:75], v[36:37], v[48:55] ; cc464030 1cc2494a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[70:71], v[26:27], v[152:159] ; cc464098 1e623546
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[78:79], v[38:39], v[48:55] ; cc464030 1cc24d4e
	v_lshl_add_u32 v160, v2, 5, v1                              ; d64600a0 04050b02
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[32:33], v[152:159] ; cc464098 1e62414a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[82:83], v[14:15], v[48:55] ; cc464030 1cc21d52
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, 0              ; ca100080 0f0e0080
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[78:79], v[34:35], v[152:159] ; cc464098 1e62454e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[86:87], v[88:89], v[48:55] ; cc464030 1cc2b156
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[82:83], v[40:41], v[152:159] ; cc464098 1e625152
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[42:43], v[152:159] ; cc464098 1e625556
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v160, v[14:15], v[14:15] offset1:2       ; d9380200 000e0ea0
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[46:47], v[6:7], 0   ; cc464018 1a020d2e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[118:119], v[6:7], 0 ; cc464038 1a020d76
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[6:7], 0   ; cc464010 1a020d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[116:117], v[6:7], 0 ; cc464020 1a020d74
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[6:7], v[120:121], 0 ; cc464040 1a02f106
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[6:7], v[122:123], 0 ; cc464048 1a02f506
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[138:139], v[4:5], v[24:31] ; cc464018 1c62098a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[126:127], v[4:5], v[56:63] ; cc464038 1ce2097e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[136:137], v[4:5], v[16:23] ; cc464010 1c420988
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[124:125], v[4:5], v[32:39] ; cc464020 1c82097c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[4:5], v[96:97], v[64:71] ; cc464040 1d02c104
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[4:5], v[98:99], v[72:79] ; cc464048 1d22c504
	v_dual_mul_f32 v163, v27, v27 :: v_dual_mul_f32 v162, v57, v57 ; c8c6371b a3a27339
	v_dual_mul_f32 v164, v59, v59 :: v_dual_mul_f32 v161, v25, v25 ; c8c6773b a4a03319
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_dual_fmac_f32 v163, v19, v19 :: v_dual_fmac_f32 v162, v33, v33 ; c8002713 a3a24321
	v_dual_fmac_f32 v164, v35, v35 :: v_dual_fmac_f32 v161, v17, v17 ; c8004723 a4a02311
	s_mov_b32 s22, 0x76543210                                   ; be9600ff 76543210
	s_mov_b32 s23, 0xfedcba98                                   ; be9700ff fedcba98
	v_dual_fmac_f32 v163, v23, v23 :: v_dual_fmac_f32 v162, v37, v37 ; c8002f17 a3a24b25
	v_dual_fmac_f32 v164, v39, v39 :: v_dual_fmac_f32 v161, v21, v21 ; c8004f27 a4a02b15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v163, v31, v31 :: v_dual_fmac_f32 v162, v61, v61 ; c8003f1f a3a27b3d
	v_dual_fmac_f32 v164, v63, v63 :: v_dual_fmac_f32 v161, v29, v29 ; c8007f3f a4a03b1d
	v_dual_fmac_f32 v162, v32, v32 :: v_dual_fmac_f32 v163, v18, v18 ; c8004120 a2a22512
	v_dual_fmac_f32 v164, v34, v34 :: v_dual_fmac_f32 v161, v16, v16 ; c8004522 a4a02110
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v162, v56, v56 :: v_dual_fmac_f32 v163, v26, v26 ; c8007138 a2a2351a
	v_dual_fmac_f32 v164, v58, v58 :: v_dual_fmac_f32 v161, v24, v24 ; c800753a a4a03118
	v_dual_fmac_f32 v162, v36, v36 :: v_dual_fmac_f32 v163, v22, v22 ; c8004924 a2a22d16
	v_dual_fmac_f32 v164, v38, v38 :: v_dual_fmac_f32 v161, v20, v20 ; c8004d26 a4a02914
	v_lshl_add_u32 v2, v2, 6, s7                                ; d6460002 001d0d02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
	v_dual_fmac_f32 v162, v60, v60 :: v_dual_fmac_f32 v163, v30, v30 ; c800793c a2a23d1e
	v_dual_fmac_f32 v164, v62, v62 :: v_dual_fmac_f32 v161, v28, v28 ; c8007d3e a4a0391c
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
	v_fma_mixlo_f16 v165, 1.0, v161, v163                       ; cc2100a5 068f42f2
	v_fma_mixhi_f16 v165, 1.0, v162, v164                       ; cc2200a5 069344f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v166, v165, s22, s23 op_sel:[1,1]         ; d65c18a6 005c2da5
(invalid instruction)                                        ; cc0f00a5
	v_min_num_f64_e32 v[1:2], v[165:166], v[166:167]            ; 1a034da5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v255                             ; 0a01ffa5
(invalid instruction)                                        ; 00000410
(invalid instruction)                                        ; d58b00a7
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a1
	v_rsq_f32_e32 v167, v167                                    ; 7f4e5da7
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_mul_f32_e32 v167, s10, v167                               ; 114f4e0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v20, v20, v167 :: v_dual_mul_f32 v19, v19, v167 ; c8c74f14 14134f13
	v_dual_mul_f32 v18, v18, v167 :: v_dual_mul_f32 v17, v17, v167 ; c8c74f12 12114f11
	v_mul_f32_e32 v16, v16, v167                                ; 10214f10
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v2, s[24:27], null offen offset:4096 ; c405c07c 40803010 00100002
	buffer_load_b128 v[40:43], v2, s[24:27], null offen offset:4112 ; c405c07c 40803028 00101002
(invalid instruction)                                        ; d58b08a5
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
	v_dual_mul_f32 v23, v23, v167 :: v_dual_mul_f32 v22, v22, v167 ; c8c74f17 17174f16
	v_mul_f32_e32 v21, v21, v167                                ; 102b4f15
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870293
	v_rsq_f32_e32 v165, v165                                    ; 7f4a5da5
	v_dual_mul_f32 v33, v33, v165 :: v_dual_mul_f32 v32, v32, v165 ; c8c74b21 21214b20
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	v_dual_mul_f32 v35, v35, v165 :: v_dual_mul_f32 v34, v34, v165 ; c8c74b23 23234b22
	v_dual_mul_f32 v37, v37, v165 :: v_dual_mul_f32 v36, v36, v165 ; c8c74b25 25254b24
	v_dual_mul_f32 v39, v39, v165 :: v_dual_mul_f32 v38, v38, v165 ; c8c74b27 27274b26
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[32:35], v2, s[24:27], null offen offset:12288 ; c405c07c 40803020 00300002
	buffer_load_b128 v[36:39], v2, s[24:27], null offen offset:12304 ; c405c07c 40803024 00301002
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	v_mul_f32_e32 v24, v24, v167                                ; 10314f18
	v_mul_f32_e32 v25, v25, v167                                ; 10334f19
	v_dual_mul_f32 v27, v27, v167 :: v_dual_mul_f32 v26, v26, v167 ; c8c74f1b 1b1b4f1a
	v_dual_mul_f32 v29, v29, v167 :: v_dual_mul_f32 v28, v28, v167 ; c8c74f1d 1d1d4f1c
	v_dual_mul_f32 v31, v31, v167 :: v_dual_mul_f32 v30, v30, v167 ; c8c74f1f 1f1f4f1e
	v_dual_mul_f32 v57, v57, v165 :: v_dual_mul_f32 v56, v56, v165 ; c8c74b39 39394b38
	v_dual_mul_f32 v59, v59, v165 :: v_dual_mul_f32 v58, v58, v165 ; c8c74b3b 3b3b4b3a
	v_dual_mul_f32 v61, v61, v165 :: v_dual_mul_f32 v60, v60, v165 ; c8c74b3d 3d3d4b3c
	v_dual_mul_f32 v63, v63, v165 :: v_dual_mul_f32 v62, v62, v165 ; c8c74b3f 3f3f4b3e
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v160, v[6:7], v[24:25] offset0:64 offset1:66 ; d9384240 001806a0
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[24:27], v2, s[24:27], null offen offset:4160 ; c405c07c 40803018 00104002
	buffer_load_b128 v[28:31], v2, s[24:27], null offen offset:4176 ; c405c07c 4080301c 00105002
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v160, v[14:15], v[14:15] offset0:128 offset1:130 ; d9388280 000e0ea0
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[10:11], 0 ; cc464038 1a02152c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[10:11], 0 ; cc464040 1a02152e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[116:117], v[10:11], 0 ; cc464048 1a021574
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[118:119], v[10:11], 0 ; cc464050 1a021576
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[10:11], v[120:121], 0 ; cc464058 1a02f10a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[122:123], 0 ; cc464068 1a02f50a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[136:137], v[8:9], v[56:63] ; cc464038 1ce21188
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[138:139], v[8:9], v[64:71] ; cc464040 1d02118a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[124:125], v[8:9], v[72:79] ; cc464048 1d22117c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[126:127], v[8:9], v[80:87] ; cc464050 1d42117e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[96:97], v[88:95] ; cc464058 1d62c108
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[98:99], v[104:111] ; cc464068 1da2c508
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v2, s[24:27], null offen offset:12352 ; c405c07c 40803008 00304002
	buffer_load_b128 v[44:47], v2, s[24:27], null offen offset:12368 ; c405c07c 4080302c 00305002
	v_mul_f32_e32 v170, v67, v67                                ; 11548743
	v_mul_f32_e32 v168, v65, v65                                ; 11508341
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmac_f32 v170, v59, v59 :: v_dual_mul_f32 v169, v81, v81 ; c806773b aaa8a351
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[96:99], v2, s[24:27], null offen offset:4224 ; c405c07c 40803060 00108002
	buffer_load_b128 v[100:103], v2, s[24:27], null offen offset:4240 ; c405c07c 40803064 00109002
	v_fmac_f32_e32 v168, v57, v57                               ; 57507339
	v_dual_fmac_f32 v170, v63, v63 :: v_dual_fmac_f32 v169, v73, v73 ; c8007f3f aaa89349
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v168, v61, v61 :: v_dual_mul_f32 v171, v83, v83 ; c8067b3d a8aaa753
	v_dual_fmac_f32 v170, v71, v71 :: v_dual_fmac_f32 v169, v77, v77 ; c8008f47 aaa89b4d
	v_dual_fmac_f32 v168, v69, v69 :: v_dual_fmac_f32 v171, v75, v75 ; c8008b45 a8aa974b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v168, v56, v56 :: v_dual_fmac_f32 v169, v85, v85 ; c8007138 a8a8ab55
	v_dual_fmac_f32 v168, v64, v64 :: v_dual_fmac_f32 v171, v79, v79 ; c8008140 a8aa9f4f
	v_dual_fmac_f32 v170, v58, v58 :: v_dual_fmac_f32 v169, v72, v72 ; c800753a aaa89148
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v168, v60, v60 :: v_dual_fmac_f32 v171, v87, v87 ; c800793c a8aaaf57
	v_dual_fmac_f32 v170, v66, v66 :: v_dual_fmac_f32 v169, v80, v80 ; c8008542 aaa8a150
	v_dual_fmac_f32 v168, v68, v68 :: v_dual_fmac_f32 v171, v74, v74 ; c8008944 a8aa954a
	v_dual_fmac_f32 v170, v62, v62 :: v_dual_fmac_f32 v169, v76, v76 ; c8007d3e aaa8994c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmac_f32_e32 v171, v82, v82                               ; 5756a552
	v_dual_fmac_f32 v170, v70, v70 :: v_dual_fmac_f32 v169, v84, v84 ; c8008d46 aaa8a954
	v_fmac_f32_e32 v171, v78, v78                               ; 57569d4e
	v_fma_mixlo_f16 v172, 1.0, v168, v170                       ; cc2100ac 06ab50f2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fmac_f32_e32 v171, v86, v86                               ; 5756ad56
	v_fma_mixhi_f16 v172, 1.0, v169, v171                       ; cc2200ac 06af52f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v173, v172, s22, s23 op_sel:[1,1]         ; d65c18ad 005c2dac
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[173:174]            ; 1a035bac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v255                             ; 0a01ffac
(invalid instruction)                                        ; 00000410
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v174, v174                                    ; 7f5c5dae
	v_mul_f32_e32 v174, s10, v174                               ; 115d5c0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870241
	v_dual_mul_f32 v57, v57, v174 :: v_dual_mul_f32 v56, v56, v174 ; c8c75d39 39395d38
	v_dual_mul_f32 v59, v59, v174 :: v_dual_mul_f32 v58, v58, v174 ; c8c75d3b 3b3b5d3a
	v_dual_mul_f32 v63, v63, v174 :: v_dual_mul_f32 v62, v62, v174 ; c8c75d3f 3f3f5d3e
	v_dual_mul_f32 v61, v61, v174 :: v_dual_mul_f32 v60, v60, v174 ; c8c75d3d 3d3d5d3c
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v2, s[24:27], null offen offset:12416 ; c405c07c 40803038 00308002
	buffer_load_b128 v[60:63], v2, s[24:27], null offen offset:12432 ; c405c07c 4080303c 00309002
(invalid instruction)                                        ; d58b08ac
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	v_dual_mul_f32 v65, v65, v174 :: v_dual_mul_f32 v64, v64, v174 ; c8c75d41 41415d40
	v_dual_mul_f32 v67, v67, v174 :: v_dual_mul_f32 v66, v66, v174 ; c8c75d43 43435d42
	v_dual_mul_f32 v69, v69, v174 :: v_dual_mul_f32 v68, v68, v174 ; c8c75d45 45455d44
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a4
	v_rsq_f32_e32 v172, v172                                    ; 7f585dac
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_dual_mul_f32 v77, v77, v172 :: v_dual_mul_f32 v76, v76, v172 ; c8c7594d 4d4d594c
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v75, v75, v172 :: v_dual_mul_f32 v74, v74, v172 ; c8c7594b 4b4b594a
	v_dual_mul_f32 v73, v73, v172 :: v_dual_mul_f32 v72, v72, v172 ; c8c75949 49495948
	v_dual_mul_f32 v79, v79, v172 :: v_dual_mul_f32 v78, v78, v172 ; c8c7594f 4f4f594e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[76:79], v2, s[24:27], null offen offset:4288 ; c405c07c 4080304c 0010c002
	buffer_load_b128 v[88:91], v2, s[24:27], null offen offset:4304 ; c405c07c 40803058 0010d002
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_mul_f32_e32 v70, v70, v174                                ; 108d5d46
	v_mul_f32_e32 v71, v71, v174                                ; 108f5d47
	v_dual_mul_f32 v81, v81, v172 :: v_dual_mul_f32 v80, v80, v172 ; c8c75951 51515950
	v_dual_mul_f32 v83, v83, v172 :: v_dual_mul_f32 v82, v82, v172 ; c8c75953 53535952
	v_dual_mul_f32 v85, v85, v172 :: v_dual_mul_f32 v84, v84, v172 ; c8c75955 55555954
	v_dual_mul_f32 v87, v87, v172 :: v_dual_mul_f32 v86, v86, v172 ; c8c75957 57575956
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v160, v[72:73], v[66:67] offset0:192 offset1:194 ; d938c2c0 004248a0
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v2, s[24:27], null offen offset:12480 ; c405c07c 40803044 0030c002
	buffer_load_b128 v[80:83], v2, s[24:27], null offen offset:12496 ; c405c07c 40803050 0030d002
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_load_b64 v[72:73], v160                                  ; d9d80000 480000a0
	ds_load_b64 v[84:85], v160 offset:16                        ; d9d80010 540000a0
	s_mov_b32 s30, 0x3d380000                                   ; be9e00ff 3d380000
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[4:5], 0 ; cc464068 1a020948
	s_wait_dscnt 0x0                                            ; bfc60000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[84:85], v[22:23], v[104:111] ; cc464068 1da22d54
	s_movk_i32 s31, 0x3e47                                      ; b01f3e47
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_fma_mixlo_f16 v176, s30, v106, v18                        ; cc2100b0 044ad41e
	v_fma_mixhi_f16 v176, s30, v107, v19                        ; cc2200b0 044ed61e
	v_fma_mixlo_f16 v175, s30, v104, v16                        ; cc2100af 0442d01e
	v_fma_mixhi_f16 v175, s30, v105, v17                        ; cc2200af 0446d21e
	ds_load_b64 v[16:17], v160 offset:512                       ; d9d80200 100000a0
	ds_load_b64 v[18:19], v160 offset:528                       ; d9d80210 120000a0
	s_movk_i32 s32, 0x3c20                                      ; b0203c20
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[72:73], v[14:15], 0 ; cc464070 1a021d48
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v177, s30, v108, v40                        ; cc2100b1 04a2d81e
	v_fma_mixhi_f16 v177, s30, v109, v41                        ; cc2200b1 04a6da1e
	v_fma_mixlo_f16 v178, s30, v110, v42                        ; cc2100b2 04aadc1e
	v_fma_mixhi_f16 v178, s30, v111, v43                        ; cc2200b2 04aede1e
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v32                              ; 0a0041af
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v32                              ; 0a0041b0
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v32                              ; 0a0041b1
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v32                              ; 0a0041b2
(invalid instruction)                                        ; cc1b00af
	v_subrev_f32_e32 v0, v175, v31                              ; 0a003faf
(invalid instruction)                                        ; cc1b00b0
	v_subrev_f32_e32 v0, v176, v31                              ; 0a003fb0
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[84:85], v[64:65], v[112:119] ; cc464070 1dc28154
(invalid instruction)                                        ; cc1b00b1
	v_subrev_f32_e32 v0, v177, v31                              ; 0a003fb1
(invalid instruction)                                        ; cc1b00b2
	v_subrev_f32_e32 v0, v178, v31                              ; 0a003fb2
	s_wait_loadcnt 0xd                                          ; bfc0000d
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mixlo_f16 v179, s30, v112, v32                        ; cc2100b3 0482e01e
	v_fma_mixhi_f16 v179, s30, v113, v33                        ; cc2200b3 0486e21e
	v_fma_mixlo_f16 v180, s30, v114, v34                        ; cc2100b4 048ae41e
	v_fma_mixhi_f16 v180, s30, v115, v35                        ; cc2200b4 048ee61e
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v181, s30, v116, v36                        ; cc2100b5 0492e81e
	v_fma_mixhi_f16 v181, s30, v117, v37                        ; cc2200b5 0496ea1e
	v_fma_mixlo_f16 v182, s30, v118, v38                        ; cc2100b6 049aec1e
	v_fma_mixhi_f16 v182, s30, v119, v39                        ; cc2200b6 049eee1e
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[4:5], 0   ; cc464020 1a020910
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[14:15], 0 ; cc464068 1a021d10
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v32                              ; 0a0041b3
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v32                              ; 0a0041b4
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v32                              ; 0a0041b5
(invalid instruction)                                        ; cc1c00b6
	v_subrev_f32_e32 v0, v182, v32                              ; 0a0041b6
	ds_load_b64 v[16:17], v160 offset:1024                      ; d9d80400 100000a0
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[22:23], v[32:39] ; cc464020 1c822d12
(invalid instruction)                                        ; cc1b00b3
	v_subrev_f32_e32 v0, v179, v31                              ; 0a003fb3
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[64:65], v[104:111] ; cc464068 1da28112
	ds_load_b64 v[18:19], v160 offset:1040                      ; d9d80410 120000a0
(invalid instruction)                                        ; cc1b00b4
	v_subrev_f32_e32 v0, v180, v31                              ; 0a003fb4
(invalid instruction)                                        ; cc1b00b5
	v_subrev_f32_e32 v0, v181, v31                              ; 0a003fb5
(invalid instruction)                                        ; cc1b00b6
	v_subrev_f32_e32 v0, v182, v31                              ; 0a003fb6
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v184, s30, v34, v26                         ; cc2100b8 046a441e
	v_fma_mixhi_f16 v184, s30, v35, v27                         ; cc2200b8 046e461e
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v186, s30, v38, v30                         ; cc2100ba 047a4c1e
	v_fma_mixhi_f16 v186, s30, v39, v31                         ; cc2200ba 047e4e1e
	v_fma_mixlo_f16 v185, s30, v36, v28                         ; cc2100b9 0472481e
	v_fma_mixhi_f16 v185, s30, v37, v29                         ; cc2200b9 04764a1e
	v_fma_mixlo_f16 v183, s30, v32, v24                         ; cc2100b7 0462401e
	v_fma_mixhi_f16 v183, s30, v33, v25                         ; cc2200b7 0466421e
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v32                              ; 0a0041b8
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v187, s30, v104, v8                         ; cc2100bb 0422d01e
	v_fma_mixhi_f16 v187, s30, v105, v9                         ; cc2200bb 0426d21e
	v_fma_mixlo_f16 v188, s30, v106, v10                        ; cc2100bc 042ad41e
	v_fma_mixhi_f16 v188, s30, v107, v11                        ; cc2200bc 042ed61e
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v32                              ; 0a0041ba
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v189, s30, v108, v44                        ; cc2100bd 04b2d81e
	v_fma_mixhi_f16 v189, s30, v109, v45                        ; cc2200bd 04b6da1e
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v32                              ; 0a0041b9
	v_fma_mixlo_f16 v190, s30, v110, v46                        ; cc2100be 04badc1e
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v32                              ; 0a0041b7
	v_fma_mixhi_f16 v190, s30, v111, v47                        ; cc2200be 04bede1e
(invalid instruction)                                        ; cc1b00b8
	v_subrev_f32_e32 v0, v184, v31                              ; 0a003fb8
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v32                              ; 0a0041bb
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[16:17], v[4:5], 0   ; cc464018 1a020910
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[14:15], 0 ; cc464020 1a021d10
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v32                              ; 0a0041bc
(invalid instruction)                                        ; cc1b00ba
	v_subrev_f32_e32 v0, v186, v31                              ; 0a003fba
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v32                              ; 0a0041bd
(invalid instruction)                                        ; cc1b00b9
	v_subrev_f32_e32 v0, v185, v31                              ; 0a003fb9
(invalid instruction)                                        ; cc1b00b7
	v_subrev_f32_e32 v0, v183, v31                              ; 0a003fb7
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v32                              ; 0a0041be
	ds_load_b64 v[8:9], v160 offset:1536                        ; d9d80600 080000a0
(invalid instruction)                                        ; cc1b00bb
	v_subrev_f32_e32 v0, v187, v31                              ; 0a003fbb
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[18:19], v[22:23], v[24:31] ; cc464018 1c622d12
	ds_load_b64 v[16:17], v160 offset:1552                      ; d9d80610 100000a0
(invalid instruction)                                        ; cc1b00bc
	v_subrev_f32_e32 v0, v188, v31                              ; 0a003fbc
(invalid instruction)                                        ; cc1b00bd
	v_subrev_f32_e32 v0, v189, v31                              ; 0a003fbd
(invalid instruction)                                        ; cc1b00be
	v_subrev_f32_e32 v0, v190, v31                              ; 0a003fbe
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[64:65], v[32:39] ; cc464020 1c828112
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v11, s30, v30, v102                         ; cc21000b 059a3c1e
	v_fma_mixhi_f16 v11, s30, v31, v103                         ; cc22000b 059e3e1e
	v_fma_mixlo_f16 v2, s30, v26, v98                           ; cc210002 058a341e
	v_fma_mixlo_f16 v191, s30, v24, v96                         ; cc2100bf 0582301e
	v_fma_mixhi_f16 v191, s30, v25, v97                         ; cc2200bf 0586321e
	v_fma_mixhi_f16 v2, s30, v27, v99                           ; cc220002 058e361e
	v_fma_mixlo_f16 v10, s30, v28, v100                         ; cc21000a 0592381e
	v_fma_mixhi_f16 v10, s30, v29, v101                         ; cc22000a 05963a1e
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v32                               ; 0a00410b
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v32                              ; 0a0041bf
(invalid instruction)                                        ; cc1c0002
	v_subrev_f32_e32 v0, v2, v32                                ; 0a004102
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c000a
	v_subrev_f32_e32 v0, v10, v32                               ; 0a00410a
(invalid instruction)                                        ; cc1b000b
	v_subrev_f32_e32 v0, v11, v31                               ; 0a003f0b
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v31                              ; 0a003fbf
(invalid instruction)                                        ; cc1b0002
	v_subrev_f32_e32 v0, v2, v31                                ; 0a003f02
(invalid instruction)                                        ; cc1b000a
	v_subrev_f32_e32 v0, v10, v31                               ; 0a003f0a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v13, s30, v32, v56                          ; cc21000d 04e2401e
	v_fma_mixlo_f16 v18, s30, v34, v58                          ; cc210012 04ea441e
	v_fma_mixhi_f16 v13, s30, v33, v57                          ; cc22000d 04e6421e
	v_fma_mixhi_f16 v18, s30, v35, v59                          ; cc220012 04ee461e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v19, s30, v36, v60                          ; cc210013 04f2481e
	v_fma_mixhi_f16 v19, s30, v37, v61                          ; cc220013 04f64a1e
	v_fma_mixlo_f16 v24, s30, v38, v62                          ; cc210018 04fa4c1e
	v_fma_mixhi_f16 v24, s30, v39, v63                          ; cc220018 04fe4e1e
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[8:9], v[4:5], 0     ; cc464020 1a020908
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[8:9], v[14:15], 0   ; cc464028 1a021d08
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v32                               ; 0a00410d
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v32                               ; 0a004112
(invalid instruction)                                        ; cc1c0013
	v_subrev_f32_e32 v0, v19, v32                               ; 0a004113
(invalid instruction)                                        ; cc1c0018
	v_subrev_f32_e32 v0, v24, v32                               ; 0a004118
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[22:23], v[32:39] ; cc464020 1c822d10
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v31                               ; 0a003f0d
(invalid instruction)                                        ; cc1b0012
	v_subrev_f32_e32 v0, v18, v31                               ; 0a003f12
(invalid instruction)                                        ; cc1b0013
	v_subrev_f32_e32 v0, v19, v31                               ; 0a003f13
(invalid instruction)                                        ; cc1b0018
	v_subrev_f32_e32 v0, v24, v31                               ; 0a003f18
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[64:65], v[40:47] ; cc464028 1ca28110
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v25, s30, v32, v76                          ; cc210019 0532401e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v28, s30, v38, v90                          ; cc21001c 056a4c1e
	v_fma_mixhi_f16 v25, s30, v33, v77                          ; cc220019 0536421e
	v_fma_mixlo_f16 v27, s30, v36, v88                          ; cc21001b 0562481e
	v_fma_mixhi_f16 v27, s30, v37, v89                          ; cc22001b 05664a1e
	v_fma_mixlo_f16 v26, s30, v34, v78                          ; cc21001a 053a441e
	v_fma_mixhi_f16 v26, s30, v35, v79                          ; cc22001a 053e461e
	v_fma_mixhi_f16 v28, s30, v39, v91                          ; cc22001c 056e4e1e
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v32                               ; 0a004119
(invalid instruction)                                        ; cc1c001b
	v_subrev_f32_e32 v0, v27, v32                               ; 0a00411b
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v29, s30, v40, v68                          ; cc21001d 0512501e
	v_fma_mixlo_f16 v30, s30, v42, v70                          ; cc21001e 051a541e
	v_fma_mixhi_f16 v29, s30, v41, v69                          ; cc22001d 0516521e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v31, s30, v44, v80                          ; cc21001f 0542581e
	v_fma_mixhi_f16 v30, s30, v43, v71                          ; cc22001e 051e561e
	v_fma_mixhi_f16 v31, s30, v45, v81                          ; cc22001f 05465a1e
(invalid instruction)                                        ; cc1c001a
	v_subrev_f32_e32 v0, v26, v32                               ; 0a00411a
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v32                               ; 0a00411c
(invalid instruction)                                        ; cc1b0019
	v_subrev_f32_e32 v0, v25, v31                               ; 0a003f19
	v_fma_mixlo_f16 v32, s30, v46, v82                          ; cc210020 054a5c1e
	v_fma_mixhi_f16 v32, s30, v47, v83                          ; cc220020 054e5e1e
(invalid instruction)                                        ; cc1b001b
	v_subrev_f32_e32 v0, v27, v31                               ; 0a003f1b
	s_mov_b32 s33, 0x7ff88000                                   ; bea100ff 7ff88000
(invalid instruction)                                        ; cc1c001d
	v_subrev_f32_e32 v0, v29, v32                               ; 0a00411d
(invalid instruction)                                        ; cc1c001e
	v_subrev_f32_e32 v0, v30, v32                               ; 0a00411e
(invalid instruction)                                        ; cc1c001f
	v_subrev_f32_e32 v0, v31, v32                               ; 0a00411f
(invalid instruction)                                        ; cc1b001a
	v_subrev_f32_e32 v0, v26, v31                               ; 0a003f1a
(invalid instruction)                                        ; cc1b001c
	v_subrev_f32_e32 v0, v28, v31                               ; 0a003f1c
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v183, v183, 5, s33                           ; d64600b7 00850bb7
	v_lshl_add_u32 v175, v175, 5, s33                           ; d64600af 00850baf
	v_lshl_add_u32 v191, v191, 5, s33                           ; d64600bf 00850bbf
	v_lshl_add_u32 v176, v176, 5, s33                           ; d64600b0 00850bb0
	v_lshl_add_u32 v25, v25, 5, s33                             ; d6460019 00850b19
	v_lshl_add_u32 v184, v184, 5, s33                           ; d64600b8 00850bb8
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v32                               ; 0a004120
	v_lshl_add_u32 v2, v2, 5, s33                               ; d6460002 00850b02
(invalid instruction)                                        ; cc1b001d
	v_subrev_f32_e32 v0, v29, v31                               ; 0a003f1d
(invalid instruction)                                        ; cc1b001e
	v_subrev_f32_e32 v0, v30, v31                               ; 0a003f1e
(invalid instruction)                                        ; cc1b001f
	v_subrev_f32_e32 v0, v31, v31                               ; 0a003f1f
	v_lshl_add_u32 v26, v26, 5, s33                             ; d646001a 00850b1a
	v_lshl_add_u32 v177, v177, 5, s33                           ; d64600b1 00850bb1
	v_lshl_add_u32 v185, v185, 5, s33                           ; d64600b9 00850bb9
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[175:176], v[183:184]            ; 1a036faf
	v_lshl_add_u32 v10, v10, 5, s33                             ; d646000a 00850b0a
	v_lshl_add_u32 v27, v27, 5, s33                             ; d646001b 00850b1b
	v_add_lshl_u32 v0, s9, v0, 2                                ; d6470000 020a0009
	v_lshl_add_u32 v178, v178, 5, s33                           ; d64600b2 00850bb2
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v0, s[24:27], null offen         ; c405c07c 40803028 00000000
	buffer_load_b128 v[44:47], v0, s[24:27], null offen offset:16 ; c405c07c 4080302c 00001000
(invalid instruction)                                        ; cc0f0022
	v_min_num_f64_e32 v[1:2], v[176:177], v[184:185]            ; 1a0371b0
	v_lshl_add_u32 v186, v186, 5, s33                           ; d64600ba 00850bba
(invalid instruction)                                        ; cc1b0020
	v_subrev_f32_e32 v0, v32, v31                               ; 0a003f20
	v_lshl_add_u32 v11, v11, 5, s33                             ; d646000b 00850b0b
(invalid instruction)                                        ; cc0f0023
	v_min_num_f64_e32 v[1:2], v[177:178], v[185:186]            ; 1a0373b1
	v_lshl_add_u32 v28, v28, 5, s33                             ; d646001c 00850b1c
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[191:192]              ; 1a037f21
(invalid instruction)                                        ; cc0f0022
	v_min_num_f64_e32 v[1:2], v[34:35], v[2:3]                  ; 1a020522
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[178:179], v[186:187]            ; 1a0375b2
(invalid instruction)                                        ; cc0f0023
	v_min_num_f64_e32 v[1:2], v[35:36], v[10:11]                ; 1a021523
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[25:26]                ; 1a023321
(invalid instruction)                                        ; cc0f0022
	v_min_num_f64_e32 v[1:2], v[34:35], v[26:27]                ; 1a023522
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[36:37], v[11:12]                ; 1a021724
(invalid instruction)                                        ; cc0f0023
	v_min_num_f64_e32 v[1:2], v[35:36], v[27:28]                ; 1a023723
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[34:35]                ; 1a024521
	s_lshr_b32 s6, s6, 2                                        ; 85068206
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[36:37], v[28:29]                ; 1a023924
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v12, s6, v12, 2                              ; d647000c 020a1806
	buffer_load_b64 v[8:9], v12, s[52:55], null offen           ; c405407c 40806808 0000000c
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[35:36]                ; 1a024721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[36:37]                ; 1a024921
	v_permlanex16_b32 v37, v33, s22, s23 op_sel:[1,1]           ; d65c1825 005c2d21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[37:38]                ; 1a024b21
	buffer_load_b64 v[14:15], v12, s[52:55], null offen offset:512 ; c405407c 4080680e 0002000c
	v_add_f16_e32 v38, v33, v161/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 644d4321
	v_max_num_f16_e32 v38, 0x400, v38                           ; 624c4cff 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v39, v38                                  ; 7e4e1726
	v_rcp_f32_e32 v39, v39                                      ; 7e4e5527
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v61, v184, v39, neg(0) op_sel_hi:[1,0,0]      ; cc20003d 8a024fb8
	v_fma_mix_f32 v60, v183, v39, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a024fb7
	v_fma_mix_f32 v183, v183, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a024fb7
	v_fma_mix_f32 v59, v178, v39, neg(0) op_sel_hi:[1,0,0]      ; cc20003b 8a024fb2
	v_fma_mix_f32 v58, v177, v39, neg(0) op_sel_hi:[1,0,0]      ; cc20003a 8a024fb1
	v_fma_mix_f32 v57, v176, v39, neg(0) op_sel_hi:[1,0,0]      ; cc200039 8a024fb0
	v_fma_mix_f32 v176, v176, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a024fb0
	v_fma_mix_f32 v177, v177, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a024fb1
	v_fma_mix_f32 v56, v175, v39, neg(0) op_sel_hi:[1,0,0]      ; cc200038 8a024faf
	v_fma_mix_f32 v178, v178, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a024fb2
	v_fma_mix_f32 v175, v175, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a024faf
	v_fma_mix_f32 v184, v184, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a024fb8
	v_fma_mix_f32 v62, v185, v39, neg(0) op_sel_hi:[1,0,0]      ; cc20003e 8a024fb9
	v_fma_mix_f32 v185, v185, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a024fb9
	v_fma_mix_f32 v63, v186, v39, neg(0) op_sel_hi:[1,0,0]      ; cc20003f 8a024fba
	v_fma_mix_f32 v186, v186, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a024fba
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v60, v183, vcc_lo                     ; 02036f3c
	v_fma_mix_f32 v64, v191, v39, neg(0) op_sel_hi:[1,0,0]      ; cc200040 8a024fbf
	v_fma_mix_f32 v191, v191, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a024fbf
	v_fma_mix_f32 v65, v2, v39, neg(0) op_sel_hi:[1,0,0]        ; cc200041 8a024f02
	v_fma_mix_f32 v2, v2, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200802 8a024f02
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v58, v177, vcc_lo                     ; 0203633a
	v_fma_mix_f32 v68, v10, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200044 8a024f0a
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v59, v178, vcc_lo                     ; 0203653b
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v56, v175, vcc_lo                     ; 02035f38
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v57, v176, vcc_lo                     ; 02036139
	v_fma_mix_f32 v10, v10, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080a 8a024f0a
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v61, v184, vcc_lo                     ; 0203713d
	v_fma_mix_f32 v69, v11, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200045 8a024f0b
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v62, v185, vcc_lo                     ; 0203733e
	v_fma_mix_f32 v11, v11, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080b 8a024f0b
	v_fma_mix_f32 v70, v25, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200046 8a024f19
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v63, v186, vcc_lo                     ; 0203753f
	v_fma_mix_f32 v25, v25, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a024f19
	v_fma_mix_f32 v71, v26, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200047 8a024f1a
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v64, v191, vcc_lo                     ; 02037f40
	v_fma_mix_f32 v26, v26, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081a 8a024f1a
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v65, v2, vcc_lo                       ; 02020541
	v_fma_mix_f32 v72, v27, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200048 8a024f1b
	v_fma_mix_f32 v27, v27, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081b 8a024f1b
	v_fma_mix_f32 v73, v28, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200049 8a024f1c
	v_fma_mix_f32 v28, v28, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a024f1c
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v68, v10, vcc_lo                      ; 02021544
	v_lshl_add_u32 v179, v179, 5, s33                           ; d64600b3 00850bb3
	v_lshl_add_u32 v187, v187, 5, s33                           ; d64600bb 00850bbb
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v69, v11, vcc_lo                      ; 02021745
	v_lshl_add_u32 v13, v13, 5, s33                             ; d646000d 00850b0d
	v_lshl_add_u32 v29, v29, 5, s33                             ; d646001d 00850b1d
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v70, v25, vcc_lo                      ; 02023346
	v_lshl_add_u32 v180, v180, 5, s33                           ; d64600b4 00850bb4
	v_lshl_add_u32 v188, v188, 5, s33                           ; d64600bc 00850bbc
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v71, v26, vcc_lo                      ; 02023547
	v_lshl_add_u32 v18, v18, 5, s33                             ; d6460012 00850b12
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v72, v27, vcc_lo                      ; 02023748
	v_lshl_add_u32 v30, v30, 5, s33                             ; d646001e 00850b1e
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v73, v28, vcc_lo                      ; 02023949
	v_lshl_add_u32 v181, v181, 5, s33                           ; d64600b5 00850bb5
	v_lshl_add_u32 v189, v189, 5, s33                           ; d64600bd 00850bbd
	v_lshl_add_u32 v19, v19, 5, s33                             ; d6460013 00850b13
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[179:180], v[187:188]            ; 1a0377b3
	v_lshl_add_u32 v31, v31, 5, s33                             ; d646001f 00850b1f
	v_lshl_add_u32 v182, v182, 5, s33                           ; d64600b6 00850bb6
	v_lshl_add_u32 v190, v190, 5, s33                           ; d64600be 00850bbe
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[180:181], v[188:189]            ; 1a0379b4
	v_lshl_add_u32 v24, v24, 5, s33                             ; d6460018 00850b18
	v_lshl_add_u32 v32, v32, 5, s33                             ; d6460020 00850b20
(invalid instruction)                                        ; cc0f004e
	v_min_num_f64_e32 v[1:2], v[181:182], v[189:190]            ; 1a037bb5
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[13:14]                ; 1a021b4c
(invalid instruction)                                        ; cc0f004f
	v_min_num_f64_e32 v[1:2], v[182:183], v[190:191]            ; 1a037db6
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[18:19]                ; 1a02254d
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f004e
	v_min_num_f64_e32 v[1:2], v[78:79], v[19:20]                ; 1a02274e
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[29:30]                ; 1a023b4c
(invalid instruction)                                        ; cc0f004f
	v_min_num_f64_e32 v[1:2], v[79:80], v[24:25]                ; 1a02314f
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[30:31]                ; 1a023d4d
(invalid instruction)                                        ; cc0f004e
	v_min_num_f64_e32 v[1:2], v[78:79], v[31:32]                ; 1a023f4e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; cc0f004f
	v_min_num_f64_e32 v[1:2], v[79:80], v[32:33]                ; 1a02414f
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[77:78]                ; 1a029b4c
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[78:79]                ; 1a029d4c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[79:80]                ; 1a029f4c
	v_permlanex16_b32 v80, v76, s22, s23 op_sel:[1,1]           ; d65c1850 005c2d4c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[80:81]                ; 1a02a14c
	v_add_f16_e32 v81, v76, v204/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64a3994c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v81, 0x400, v81                           ; 62a2a2ff 00000400
	v_cvt_f32_f16_e32 v82, v81                                  ; 7ea41751
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v82, v82                                      ; 7ea45552
	v_fma_mix_f32 v94, v24, v82, neg(0) op_sel_hi:[1,0,0]       ; cc20005e 8a02a518
	v_fma_mix_f32 v24, v24, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200818 8a02a518
	v_fma_mix_f32 v85, v181, v82, neg(0) op_sel_hi:[1,0,0]      ; cc200055 8a02a5b5
	v_fma_mix_f32 v181, v181, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a02a5b5
	v_fma_mix_f32 v93, v19, v82, neg(0) op_sel_hi:[1,0,0]       ; cc20005d 8a02a513
	v_fma_mix_f32 v19, v19, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200813 8a02a513
	v_fma_mix_f32 v84, v180, v82, neg(0) op_sel_hi:[1,0,0]      ; cc200054 8a02a5b4
	v_fma_mix_f32 v83, v179, v82, neg(0) op_sel_hi:[1,0,0]      ; cc200053 8a02a5b3
	v_fma_mix_f32 v179, v179, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a02a5b3
	v_fma_mix_f32 v180, v180, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a02a5b4
	v_fma_mix_f32 v86, v182, v82, neg(0) op_sel_hi:[1,0,0]      ; cc200056 8a02a5b6
	v_fma_mix_f32 v182, v182, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a02a5b6
	v_fma_mix_f32 v87, v187, v82, neg(0) op_sel_hi:[1,0,0]      ; cc200057 8a02a5bb
	v_fma_mix_f32 v187, v187, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a02a5bb
	v_fma_mix_f32 v88, v188, v82, neg(0) op_sel_hi:[1,0,0]      ; cc200058 8a02a5bc
	v_fma_mix_f32 v188, v188, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a02a5bc
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v85, v181, vcc_lo                     ; 02036b55
	v_fma_mix_f32 v89, v189, v82, neg(0) op_sel_hi:[1,0,0]      ; cc200059 8a02a5bd
	v_fma_mix_f32 v189, v189, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a02a5bd
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v93, v19, vcc_lo                      ; 0202275d
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v94, v24, vcc_lo                      ; 0202315e
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	v_fma_mix_f32 v90, v190, v82, neg(0) op_sel_hi:[1,0,0]      ; cc20005a 8a02a5be
	v_fma_mix_f32 v190, v190, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a02a5be
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v83, v179, vcc_lo                     ; 02036753
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v84, v180, vcc_lo                     ; 02036954
	v_fma_mix_f32 v91, v13, v82, neg(0) op_sel_hi:[1,0,0]       ; cc20005b 8a02a50d
	v_fma_mix_f32 v13, v13, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080d 8a02a50d
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v86, v182, vcc_lo                     ; 02036d56
	v_fma_mix_f32 v92, v18, v82, neg(0) op_sel_hi:[1,0,0]       ; cc20005c 8a02a512
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v87, v187, vcc_lo                     ; 02037757
	v_fma_mix_f32 v18, v18, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200812 8a02a512
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v88, v188, vcc_lo                     ; 02037958
	v_fma_mix_f32 v95, v29, v82, neg(0) op_sel_hi:[1,0,0]       ; cc20005f 8a02a51d
	v_fma_mix_f32 v29, v29, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081d 8a02a51d
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v89, v189, vcc_lo                     ; 02037b59
	v_fma_mix_f32 v96, v30, v82, neg(0) op_sel_hi:[1,0,0]       ; cc200060 8a02a51e
	v_fma_mix_f32 v30, v30, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081e 8a02a51e
	v_fma_mix_f32 v97, v31, v82, neg(0) op_sel_hi:[1,0,0]       ; cc200061 8a02a51f
	v_fma_mix_f32 v31, v31, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081f 8a02a51f
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v90, v190, vcc_lo                     ; 02037d5a
	v_fma_mix_f32 v98, v32, v82, neg(0) op_sel_hi:[1,0,0]       ; cc200062 8a02a520
	v_fma_mix_f32 v32, v32, v82, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a02a520
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v91, v13, vcc_lo                      ; 02021b5b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[4:5], 0   ; cc464038 1a020918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[26:27], 0 ; cc464050 1a023518
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v92, v18, vcc_lo                      ; 0202255c
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v95, v29, vcc_lo                      ; 02023b5f
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v96, v30, vcc_lo                      ; 02023d60
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v97, v31, vcc_lo                      ; 02023f61
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v98, v32, vcc_lo                      ; 02024162
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[16:17], v[56:63] ; cc464058 1ce22114
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[6:7], v[16:17], v[56:63] ; cc464038 1ce22106
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[34:35], v[80:87] ; cc464060 1d424514
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[6:7], v[34:35], v[80:87] ; cc464050 1d424506
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[22:23], v[88:95] ; cc464058 1d622d18
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v33, v145, v41 :: v_dual_mul_f32 v32, v144, v40 ; c8c65391 21205190
	v_dual_mul_f32 v27, v131, v43 :: v_dual_mul_f32 v26, v130, v42 ; c8c65783 1b1a5582
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v29, v133, v45 :: v_dual_mul_f32 v28, v132, v44 ; c8c65b85 1d1c5984
	v_dual_mul_f32 v31, v135, v47 :: v_dual_mul_f32 v30, v134, v46 ; c8c65f87 1f1e5d86
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[22:23], v[56:63] ; cc464038 1ce22d18
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[36:37], v[96:103] ; cc464060 1d824918
	v_dual_mul_f32 v35, v147, v43 :: v_dual_mul_f32 v34, v146, v42 ; c8c65793 23225592
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[36:37], v[80:87] ; cc464050 1d424918
	v_dual_mul_f32 v25, v129, v41 :: v_dual_mul_f32 v24, v128, v40 ; c8c65381 19185180
	v_dual_mul_f32 v37, v149, v45 :: v_dual_mul_f32 v36, v148, v44 ; c8c65b95 25245994
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[74:75], v[10:11], v[88:95] ; cc464058 1d62154a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[66:67], v[10:11], v[56:63] ; cc464038 1ce21542
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[66:67], v[18:19], v[80:87] ; cc464050 1d422542
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[74:75], v[18:19], v[96:103] ; cc464060 1d82254a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	v_dual_mul_f32 v39, v151, v47 :: v_dual_mul_f32 v38, v150, v46 ; c8c65f97 27265d96
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[8:9], v[4:5], v[24:31] ; cc464018 1c620908
	s_cmp_lg_i32 s28, 0                                         ; bf01801c
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[8:9], v[20:21], v[32:39] ; cc464020 1c822908
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[14:15], v[6:7], v[24:31] ; cc464018 1c620d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[14:15], v[10:11], v[32:39] ; cc464020 1c82150e
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
	s_cbranch_scc1 BB52                                         ; bfa20007
BB50:
	v_add3_u32 v2, v3, s2, s14                                  ; d6550002 00380503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[8:9], v2, s[16:19], null offen           ; c406c07c 40802008 00000002
BB52:
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_lg_i32 s40, 0                                         ; bf018028
	s_cbranch_scc1 BB55                                         ; bfa20007
BB53:
	v_add3_u32 v2, v3, s2, s29                                  ; d6550002 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[8:9], v2, s[16:19], null offen           ; c406c07c 40802008 00000002
BB55:
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v0, s[24:27], null offen offset:64 ; c405c07c 40803010 00004000
	buffer_load_b128 v[24:27], v0, s[24:27], null offen offset:80 ; c405c07c 40803018 00005000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[8:9], v12, s[52:55], null offen offset:8  ; c405407c 40806808 0000080c
	buffer_load_b64 v[12:13], v12, s[52:55], null offen offset:520 ; c405407c 4080680c 0002080c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v33, v153, v17 :: v_dual_mul_f32 v32, v152, v16 ; c8c62399 21202198
	v_dual_mul_f32 v35, v155, v19 :: v_dual_mul_f32 v34, v154, v18 ; c8c6279b 2322259a
	v_dual_mul_f32 v41, v49, v17 :: v_dual_mul_f32 v40, v48, v16 ; c8c62331 29282130
	v_dual_mul_f32 v43, v51, v19 :: v_dual_mul_f32 v42, v50, v18 ; c8c62733 2b2a2532
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v37, v157, v25 :: v_dual_mul_f32 v36, v156, v24 ; c8c6339d 2524319c
	v_dual_mul_f32 v39, v159, v27 :: v_dual_mul_f32 v38, v158, v26 ; c8c6379f 2726359e
	v_dual_mul_f32 v45, v53, v25 :: v_dual_mul_f32 v44, v52, v24 ; c8c63335 2d2c3134
	v_dual_mul_f32 v47, v55, v27 :: v_dual_mul_f32 v46, v54, v26 ; c8c63737 2f2e3536
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[8:9], v[4:5], v[32:39] ; cc464020 1c820908
	s_mov_b32 s0, vcc_lo                                        ; be80006a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[8:9], v[20:21], v[40:47] ; cc464028 1ca22908
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[12:13], v[6:7], v[32:39] ; cc464020 1c820d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[10:11], v[40:47] ; cc464028 1ca2150c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_cbranch_scc1 BB58                                         ; bfa20009
BB56:
	s_add_co_u32 s1, s2, 0x100                                  ; 8001ff02 00000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	v_add3_u32 v0, v3, s1, s14                                  ; d6550000 00380303
	v_add_nc_u32_e32 v0, v0, v1                                 ; 4a000300
	buffer_store_b64 v[4:5], v0, s[16:19], null offen           ; c406c07c 40802004 00000000
BB58:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB78                                         ; bfa20b86
BB59:
	s_addk_co_i32 s2, 0x100                                     ; b7820100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v3, v3, s2, s29                                  ; d6550003 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	buffer_store_b64 v[4:5], v3, s[16:19], null offen           ; c406c07c 40802004 00000003
	s_branch BB78                                               ; bfa00b7c
BB62:
	s_mov_b32 s15, s1                                           ; be8f0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	s_load_b256 s[40:47], s[0:1], 0x30                          ; f4006a00 f8000030
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_max_i32 s13, s13, 0                                       ; 8a0d800d
	s_add_co_u32 s17, s11, -1                                   ; 8011c10b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s13, s13, s17                                     ; 890d110d
	s_max_i32 s14, s14, 0                                       ; 8a0e800e
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	s_min_i32 s14, s14, s12                                     ; 890e0c0e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s14, s14, s11                                     ; 960e0b0e
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_add_co_u32 s14, s14, s13                                  ; 800e0d0e
	s_lshl_b32 s14, s14, 9                                      ; 840e890e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s18, s15, s14                                  ; 80120e0f
	s_max_i32 s29, s29, 0                                       ; 8a1d801d
	v_add3_u32 v5, v3, s18, 0x100                               ; d6550005 03fc2503 00000100
	v_add3_u32 v4, v1, s18, v3                                  ; d6550004 040c2501
	s_min_i32 s29, s29, s12                                     ; 891d0c1d
	s_mul_i32 s29, s29, s11                                     ; 961d0b1d
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_add_co_u32 s29, s29, s13                                  ; 801d0d1d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s29, s29, 9                                      ; 841d891d
	s_add_co_u32 s15, s15, s29                                  ; 800f1d0f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a9
	v_add3_u32 v8, v1, s15, v3                                  ; d6550008 040c1f01
	v_add3_u32 v9, v3, s15, 0x100                               ; d6550009 03fc1f03 00000100
	v_add_nc_u32_e32 v9, v9, v1                                 ; 4a120309
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[6:7], v4, s[20:23], null offen            ; c405407c 40802806 00000004
	buffer_load_b64 v[4:5], v5, s[20:23], null offen            ; c405407c 40802804 00000005
	buffer_load_b64 v[10:11], v8, s[20:23], null offen          ; c405407c 4080280a 00000008
	buffer_load_b64 v[8:9], v9, s[20:23], null offen            ; c405407c 40802808 00000009
	v_lshlrev_b32_e32 v12, 2, v0                                ; 30180082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v13, s3, v12, 2                              ; d647000d 020a1803
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[16:19], v13, s[44:47], null offen        ; c405c07c 40805810 0000000d
	buffer_load_b128 v[20:23], v13, s[44:47], null offen offset:512 ; c405c07c 40805814 0002000d
	buffer_load_b128 v[24:27], v13, s[44:47], null offen offset:1024 ; c405c07c 40805818 0004000d
	buffer_load_b128 v[28:31], v13, s[44:47], null offen offset:1536 ; c405c07c 4080581c 0006000d
	buffer_load_b128 v[32:35], v13, s[44:47], null offen offset:2048 ; c405c07c 40805820 0008000d
	buffer_load_b128 v[36:39], v13, s[44:47], null offen offset:2560 ; c405c07c 40805824 000a000d
	buffer_load_b128 v[40:43], v13, s[44:47], null offen offset:3072 ; c405c07c 40805828 000c000d
	buffer_load_b128 v[44:47], v13, s[44:47], null offen offset:3584 ; c405c07c 4080582c 000e000d
	v_lshrrev_b32_e32 v0, 4, v0                                 ; 32000084
	s_mov_b64 s[36:37], s[40:41]                                ; bea40128
	s_mov_b64 s[38:39], s[42:43]                                ; bea6012a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshlrev_b32_e32 v0, 3, v0                                 ; 30000083
	v_add_lshl_u32 v14, s8, v0, 2                               ; d647000e 020a0008
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v14, s[36:39], null offen        ; c405c07c 40804830 0000000e
	buffer_load_b128 v[52:55], v14, s[36:39], null offen offset:16 ; c405c07c 40804834 0000100e
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add_lshl_u32 v15, s4, v12, 2                              ; d647000f 020a1804
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[56:59], v15, s[44:47], null offen        ; c405c07c 40805838 0000000f
	buffer_load_b128 v[60:63], v15, s[44:47], null offen offset:512 ; c405c07c 4080583c 0002000f
	buffer_load_b128 v[64:67], v15, s[44:47], null offen offset:1024 ; c405c07c 40805840 0004000f
	buffer_load_b128 v[68:71], v15, s[44:47], null offen offset:1536 ; c405c07c 40805844 0006000f
	buffer_load_b128 v[72:75], v15, s[44:47], null offen offset:2048 ; c405c07c 40805848 0008000f
	buffer_load_b128 v[76:79], v15, s[44:47], null offen offset:2560 ; c405c07c 4080584c 000a000f
	buffer_load_b128 v[80:83], v15, s[44:47], null offen offset:3072 ; c405c07c 40805850 000c000f
	buffer_load_b128 v[84:87], v15, s[44:47], null offen offset:3584 ; c405c07c 40805854 000e000f
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_cndmask_b32_e64 v6, v6, 0, s16                            ; d5010006 00410106
	v_cndmask_b32_e64 v7, v7, 0, s16                            ; d5010007 00410107
	s_wait_loadcnt 0x14                                         ; bfc00014
	v_cndmask_b32_e64 v4, v4, 0, s16                            ; d5010004 00410104
	v_cndmask_b32_e64 v5, v5, 0, s16                            ; d5010005 00410105
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_cndmask_b32_e64 v10, v10, 0, s31                          ; d501000a 007d010a
	v_cndmask_b32_e64 v11, v11, 0, s31                          ; d501000b 007d010b
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v8, v8, 0, s31                            ; d5010008 007d0108
	v_cndmask_b32_e64 v9, v9, 0, s31                            ; d5010009 007d0109
	v_cvt_pk_f32_fp8_e32 v[92:93], v134                         ; 7eb8dd86
	v_cvt_pk_f32_fp8_e32 v[90:91], v6                           ; 7eb4dd06
	v_cvt_pk_f32_fp8_e32 v[94:95], v7                           ; 7ebcdd07
	v_dual_mov_b32 v89, v7 :: v_dual_mov_b32 v88, v6            ; ca100107 59580106
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	v_dual_mov_b32 v97, v5 :: v_dual_mov_b32 v96, v4            ; ca100105 61600104
	v_dual_mov_b32 v99, v11 :: v_dual_mov_b32 v98, v10          ; ca10010b 6362010a
	v_cvt_pk_f32_fp8_e32 v[100:101], v10                        ; 7ec8dd0a
	v_cvt_pk_f32_fp8_e32 v[102:103], v138                       ; 7eccdd8a
	v_cvt_pk_f32_fp8_e32 v[104:105], v11                        ; 7ed0dd0b
	v_dual_mov_b32 v107, v9 :: v_dual_mov_b32 v106, v8          ; ca100109 6b6a0108
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[88:89], 0 ; cc464070 1a02b110
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[88:89], 0 ; cc464080 1a02b112
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[98:99], 0 ; cc464078 1a02c510
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[98:99], 0 ; cc464088 1a02c512
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[96:97], v[112:119] ; cc464070 1dc2c114
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[20:21], v[106:107], v[120:127] ; cc464078 1de2d514
	v_maxmin_num_f32 v20, -4.0, v114, 4.0                       ; d6690014 03dae4f7
	v_maxmin_num_f32 v108, -4.0, v115, 4.0                      ; d669006c 03dae6f7
	v_maxmin_num_f32 v18, -4.0, v113, 4.0                       ; d6690012 03dae2f7
	v_maxmin_num_f32 v110, -4.0, v116, 4.0                      ; d669006e 03dae8f7
	v_maxmin_num_f32 v16, -4.0, v112, 4.0                       ; d6690010 03dae0f7
	v_fma_mix_f32 v21, 0xab28, |v20|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfe28ff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v19, 0xab28, |v18|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206213 0bfe24ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v17, 0xab28, |v16|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206211 0bfe20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_fmaak_f32 v109, v109, v108, 0x3f650000                    ; 5adad96d 3f650000
	v_dual_fmaak_f32 v19, v19, v18, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v17, 0x3f650000 ; c8422513 13102310 3f650000
	v_maxmin_num_f32 v144, -4.0, v121, 4.0                      ; d6690090 03daf2f7
	v_dual_mul_f32 v115, v109, v115 :: v_dual_fmaak_f32 v20, v20, v21, 0x3f650000 ; c8c2e76d 73142b14 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_mul_f32 v113, v113, v19 :: v_dual_mul_f32 v112, v112, v16 ; c8c62771 71702170
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v117, 4.0                      ; d6690070 03daeaf7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v123, 4.0                      ; d6690094 03daf6f7
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v122, 4.0                      ; d6690092 03daf4f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_mul_f32 v117, v117, v113 :: v_dual_mul_f32 v116, v116, v110 ; c8c6e375 7574dd74
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v125, 4.0                      ; d6690098 03dafaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v116, -4.0, v119, 4.0                      ; d6690074 03daeef7
	v_maxmin_num_f32 v150, -4.0, v124, 4.0                      ; d6690096 03daf8f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v127, 4.0                      ; d669009c 03dafef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v117, v116, v117, 0x3f650000 :: v_dual_mul_f32 v114, v114, v20 ; c846eb74 75722972 3f650000
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v126, 4.0                      ; d669009a 03dafcf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v118, 4.0                      ; d6690072 03daecf7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[96:97], v[128:135] ; cc464080 1e02c116
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v119, v119, v117 :: v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 ; c8c2eb77 7772e772 3f650000
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v118, v118, v114 ; c8472191 9176e576 3f650000
	v_maxmin_num_f32 v160, -4.0, v129, 4.0                      ; d66900a0 03db02f7
	v_maxmin_num_f32 v158, -4.0, v128, 4.0                      ; d669009e 03db00f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870253
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v120, 4.0                      ; d6690076 03daf0f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v131, 4.0                      ; d66900a4 03db06f7
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v130, 4.0                      ; d66900a2 03db04f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_mul_f32 v121, v121, v145 :: v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 ; c8c32379 7976ef76 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[106:107], v[136:143] ; cc464088 1e22d516
	v_maxmin_num_f32 v168, -4.0, v133, 4.0                      ; d66900a8 03db0af7
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v120, v120, v118 ; c8472995 9578ed78 3f650000
	v_maxmin_num_f32 v166, -4.0, v132, 4.0                      ; d66900a6 03db08f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d3
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v123, v123, v149 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8c32b7b 7b932792 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v135, 4.0                      ; d66900ac 03db0ef7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v122, v122, v146 ; c8473199 997b257a 3f650000
	v_maxmin_num_f32 v170, -4.0, v134, 4.0                      ; d66900aa 03db0cf7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v125, v125, v153 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8c3337d 7d972f96 3f650000
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v137, 4.0                      ; d66900b0 03db12f7
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v124, v124, v150 ; c847399d 9d7d2d7c 3f650000
	v_maxmin_num_f32 v174, -4.0, v136, 4.0                      ; d66900ae 03db10f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_dual_mul_f32 v127, v127, v157 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8c33b7f 7f9b379a 3f650000
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v139, 4.0                      ; d66900b4 03db16f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_mul_f32 v126, v126, v154 ; c84741a1 a17f357e 3f650000
	v_maxmin_num_f32 v178, -4.0, v138, 4.0                      ; d66900b2 03db14f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v129, v129, v161 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c8c34381 819f3f9e 3f650000
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v141, 4.0                      ; d66900b8 03db1af7
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_mul_f32 v128, v128, v158 ; c84749a5 a5813d80 3f650000
	v_maxmin_num_f32 v182, -4.0, v140, 4.0                      ; d66900b6 03db18f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v131, v131, v165 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8c34b83 83a347a2 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v143, 4.0                      ; d66900bc 03db1ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_mul_f32 v130, v130, v162 ; c84751a9 a9834582 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[88:89], 0 ; cc464070 1a02b118
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v133, v133, v169 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c8c35385 85a74fa6 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v132, v132, v166 ; c84759ad ad854d84 3f650000
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[96:97], v[112:119] ; cc464070 1dc2c11c
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v135, v135, v173 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8c35b87 87ab57aa 3f650000
	v_maxmin_num_f32 v186, -4.0, v142, 4.0                      ; d66900ba 03db1cf7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_mul_f32 v134, v134, v170 ; c84761b1 b1875586 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v112, 4.0                      ; d66900be 03dae0f7
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v137, v137, v177 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c8c36389 89af5fae 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[98:99], 0 ; cc464078 1a02c518
	v_maxmin_num_f32 v15, -4.0, v114, 4.0                       ; d669000f 03dae4f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v136, v136, v174 ; c84769b5 b5895d88 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v25, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe1eff 3728ab28
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_dual_mul_f32 v139, v139, v181 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c8c36b8b 8bb367b2 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[106:107], v[120:127] ; cc464078 1de2d51c
	v_maxmin_num_f32 v28, -4.0, v115, 4.0                       ; d669001c 03dae6f7
	v_fmaak_f32 v15, v15, v25, 0x3f650000                       ; 5a1e330f 3f650000
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_mul_f32 v138, v138, v178 ; c84771b9 b98b658a 3f650000
	v_maxmin_num_f32 v108, -4.0, v116, 4.0                      ; d669006c 03dae8f7
	v_maxmin_num_f32 v110, -4.0, v117, 4.0                      ; d669006e 03daeaf7
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v141, v141, v185 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c8c3738d 8db76fb6 3f650000
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v140, v140, v182 ; c84779bd bd8d6d8c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b8f 8fbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v113, 4.0                      ; d66900bf 03dae2f7
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v108 ; c8c6df75 7574d974
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 :: v_dual_mul_f32 v112, v112, v190 ; c846391d 1d717d70 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v115, v115, v29 :: v_dual_mul_f32 v114, v114, v15 ; c8c63b73 73721f72
	v_dual_fmaak_f32 v13, v191, v13, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8421bbf 0dbb77ba 3f650000
	v_maxmin_num_f32 v116, -4.0, v120, 4.0                      ; d6690074 03daf0f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v113, v113, v13 :: v_dual_mul_f32 v142, v142, v186 ; c8c61b71 718f758e
	v_maxmin_num_f32 v128, -4.0, v123, 4.0                      ; d6690080 03daf6f7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v118, 4.0                      ; d6690070 03daecf7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v119, 4.0                      ; d6690072 03daeef7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v125, 4.0                      ; d6690084 03dafaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v124, 4.0                      ; d6690082 03daf8f7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c8430181 8174eb74 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v127, 4.0                      ; d6690088 03dafef7
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_mul_f32 v123, v123, v129 :: v_dual_mul_f32 v120, v120, v116 ; c8c7037b 7b78e978
	v_maxmin_num_f32 v134, -4.0, v126, 4.0                      ; d6690086 03dafcf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v119, v119, v115 :: v_dual_mul_f32 v118, v118, v112 ; c8c6e777 7776e176
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8431189 89830782 3f650000
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v121, 4.0                      ; d6690076 03daf2f7
	v_dual_mul_f32 v127, v127, v137 :: v_dual_mul_f32 v124, v124, v130 ; c8c7137f 7f7d057c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fmaak_f32 v119, v119, v118, 0x3f650000                    ; 5aeeed77 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_mul_f32_e32 v121, v121, v119                              ; 10f2ef79
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[88:89], 0 ; cc464070 1a02b11a
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v122, 4.0                      ; d6690078 03daf4f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[96:97], v[112:119] ; cc464070 1dc2c11e
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8430985 8578f378 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v125, v125, v133 :: v_dual_mul_f32 v122, v122, v120 ; c8c70b7d 7d7af17a
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v140, -4.0, v113, 4.0                      ; d669008c 03dae2f7
	v_maxmin_num_f32 v142, -4.0, v114, 4.0                      ; d669008e 03dae4f7
	v_maxmin_num_f32 v144, -4.0, v115, 4.0                      ; d6690090 03dae6f7
	v_maxmin_num_f32 v138, -4.0, v112, 4.0                      ; d669008a 03dae0f7
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v148, -4.0, v117, 4.0                      ; d6690094 03daeaf7
	v_maxmin_num_f32 v146, -4.0, v116, 4.0                      ; d6690092 03dae8f7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v119, 4.0                      ; d6690098 03daeef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c843198d 8d870f86 3f650000
	v_maxmin_num_f32 v150, -4.0, v118, 4.0                      ; d6690096 03daecf7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c8432191 918b178a 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432995 958f1f8e 3f650000
	v_dual_mul_f32 v113, v113, v141 :: v_dual_mul_f32 v126, v126, v134 ; c8c71b71 717f0d7e
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8433199 99932792 3f650000
	v_dual_mul_f32 v115, v115, v145 :: v_dual_mul_f32 v112, v112, v138 ; c8c72373 73711570
	v_dual_mul_f32 v117, v117, v149 :: v_dual_mul_f32 v114, v114, v142 ; c8c72b75 75731d72
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[98:99], 0 ; cc464078 1a02c51a
	v_dual_mul_f32 v119, v119, v153 :: v_dual_mul_f32 v116, v116, v146 ; c8c73377 77752574
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[106:107], v[120:127] ; cc464078 1de2d51e
	v_maxmin_num_f32 v156, -4.0, v121, 4.0                      ; d669009c 03daf2f7
	v_maxmin_num_f32 v160, -4.0, v123, 4.0                      ; d66900a0 03daf6f7
	v_maxmin_num_f32 v164, -4.0, v125, 4.0                      ; d66900a4 03dafaf7
	v_maxmin_num_f32 v158, -4.0, v122, 4.0                      ; d669009e 03daf4f7
	v_maxmin_num_f32 v154, -4.0, v120, 4.0                      ; d669009a 03daf0f7
	v_maxmin_num_f32 v162, -4.0, v124, 4.0                      ; d66900a2 03daf8f7
	v_maxmin_num_f32 v168, -4.0, v127, 4.0                      ; d66900a8 03dafef7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v126, 4.0                      ; d66900a6 03dafcf7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c843399d 9d972f96 3f650000
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84349a5 a59f3f9e 3f650000
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c84341a1 a19b379a 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84351a9 a9a347a2 3f650000
	v_dual_mul_f32 v121, v121, v157 :: v_dual_mul_f32 v118, v118, v150 ; c8c73b79 79772d76
	v_dual_mul_f32 v125, v125, v165 :: v_dual_mul_f32 v122, v122, v158 ; c8c74b7d 7d7b3d7a
	v_dual_mul_f32 v123, v123, v161 :: v_dual_mul_f32 v120, v120, v154 ; c8c7437b 7b793578
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v127, v127, v169 :: v_dual_mul_f32 v124, v124, v162 ; c8c7537f 7f7d457c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[88:89], 0 ; cc464070 1a02b120
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[96:97], v[112:119] ; cc464070 1dc2c124
	v_maxmin_num_f32 v174, -4.0, v114, 4.0                      ; d66900ae 03dae4f7
	v_maxmin_num_f32 v172, -4.0, v113, 4.0                      ; d66900ac 03dae2f7
	v_maxmin_num_f32 v180, -4.0, v117, 4.0                      ; d66900b4 03daeaf7
	v_maxmin_num_f32 v176, -4.0, v115, 4.0                      ; d66900b0 03dae6f7
	v_maxmin_num_f32 v170, -4.0, v112, 4.0                      ; d66900aa 03dae0f7
	v_maxmin_num_f32 v178, -4.0, v116, 4.0                      ; d66900b2 03dae8f7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v119, 4.0                      ; d66900b8 03daeef7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v118, 4.0                      ; d66900b6 03daecf7
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84359ad ada74fa6 3f650000
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84369b5 b5af5fae 3f650000
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84361b1 b1ab57aa 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_mul_f32 v113, v113, v173 :: v_dual_mul_f32 v126, v126, v166 ; c8c75b71 717f4d7e
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84371b9 b9b367b2 3f650000
	v_dual_mul_f32 v117, v117, v181 :: v_dual_mul_f32 v114, v114, v174 ; c8c76b75 75735d72
	v_dual_mul_f32 v115, v115, v177 :: v_dual_mul_f32 v112, v112, v170 ; c8c76373 73715570
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[98:99], 0 ; cc464078 1a02c520
	v_dual_mul_f32 v119, v119, v185 :: v_dual_mul_f32 v116, v116, v178 ; c8c77377 77756574
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[106:107], v[120:127] ; cc464078 1de2d524
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_maxmin_num_f32 v15, -4.0, v124, 4.0                       ; d669000f 03daf8f7
	v_maxmin_num_f32 v186, -4.0, v120, 4.0                      ; d66900ba 03daf0f7
	v_maxmin_num_f32 v190, -4.0, v122, 4.0                      ; d66900be 03daf4f7
	v_maxmin_num_f32 v188, -4.0, v121, 4.0                      ; d66900bc 03daf2f7
	v_maxmin_num_f32 v108, -4.0, v125, 4.0                      ; d669006c 03dafaf7
	v_fma_mix_f32 v37, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfe1eff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v126, 4.0                      ; d669006e 03dafcf7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v127, 4.0                      ; d6690070 03dafef7
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84379bd bdb76fb6 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_dual_mul_f32 v121, v121, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b79 79bf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v123, 4.0                      ; d66900bf 03daf6f7
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_mul_f32 v122, v122, v190 ; c846d96d 6d7b7d7a 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_dual_mul_f32 v127, v127, v113 :: v_dual_mul_f32 v126, v126, v110 ; c8c6e37f 7f7edd7e
	v_dual_fmaak_f32 v13, v13, v191, 0x3f650000 :: v_dual_mul_f32 v118, v118, v182 ; c8477f0d 0d776d76 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_dual_mul_f32 v123, v123, v13 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8c21b7b 7bbb77ba 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[88:89], 0 ; cc464070 1a02b122
	v_dual_fmaak_f32 v15, v15, v37, 0x3f650000 :: v_dual_mul_f32 v120, v120, v186 ; c8464b0f 0f797578 3f650000
	v_dual_mul_f32 v125, v125, v109 :: v_dual_mul_f32 v124, v124, v15 ; c8c6db7d 7d7c1f7c
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[98:99], 0 ; cc464078 1a02c522
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[96:97], v[112:119] ; cc464070 1dc2c126
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[106:107], v[120:127] ; cc464078 1de2d526
	v_maxmin_num_f32 v130, -4.0, v113, 4.0                      ; d6690082 03dae2f7
	v_maxmin_num_f32 v138, -4.0, v117, 4.0                      ; d669008a 03daeaf7
	v_maxmin_num_f32 v136, -4.0, v116, 4.0                      ; d6690088 03dae8f7
	v_maxmin_num_f32 v134, -4.0, v115, 4.0                      ; d6690086 03dae6f7
	v_maxmin_num_f32 v132, -4.0, v114, 4.0                      ; d6690084 03dae4f7
	v_maxmin_num_f32 v128, -4.0, v112, 4.0                      ; d6690080 03dae0f7
	v_maxmin_num_f32 v140, -4.0, v118, 4.0                      ; d669008c 03daecf7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v119, 4.0                      ; d669008e 03daeef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v120, 4.0                      ; d6690090 03daf0f7
	v_maxmin_num_f32 v146, -4.0, v121, 4.0                      ; d6690092 03daf2f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c843158b 8b891388 3f650000
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430d87 87850b84 3f650000
	v_maxmin_num_f32 v148, -4.0, v122, 4.0                      ; d6690094 03daf4f7
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
	v_maxmin_num_f32 v150, -4.0, v123, 4.0                      ; d6690096 03daf6f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 ; c8431d8f 8f8d1b8c 3f650000
	v_dual_mul_f32 v117, v117, v139 :: v_dual_mul_f32 v116, v116, v136 ; c8c71775 75751174
	v_dual_mul_f32 v115, v115, v135 :: v_dual_mul_f32 v114, v114, v132 ; c8c70f73 73730972
	v_maxmin_num_f32 v152, -4.0, v124, 4.0                      ; d6690098 03daf8f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v125, 4.0                      ; d669009a 03dafaf7
	v_dual_mul_f32 v113, v113, v131 :: v_dual_mul_f32 v112, v112, v128 ; c8c70771 71710170
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_dual_mul_f32 v119, v119, v143 :: v_dual_mul_f32 v118, v118, v140 ; c8c71f77 77771976
	v_maxmin_num_f32 v156, -4.0, v126, 4.0                      ; d669009c 03dafcf7
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v158, -4.0, v127, 4.0                      ; d669009e 03dafef7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_mul_f32 v121, v121, v147 :: v_dual_mul_f32 v120, v120, v144 ; c8c72779 79792178
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[88:89], 0 ; cc464070 1a02b128
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_dual_mul_f32 v123, v123, v151 :: v_dual_mul_f32 v122, v122, v148 ; c8c72f7b 7b7b297a
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_dual_mul_f32 v125, v125, v155 :: v_dual_mul_f32 v124, v124, v152 ; c8c7377d 7d7d317c
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[96:97], v[112:119] ; cc464070 1dc2c12c
	v_dual_mul_f32 v127, v127, v159 :: v_dual_mul_f32 v126, v126, v156 ; c8c73f7f 7f7f397e
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[98:99], 0 ; cc464078 1a02c528
	v_maxmin_num_f32 v166, -4.0, v115, 4.0                      ; d66900a6 03dae6f7
	v_maxmin_num_f32 v168, -4.0, v116, 4.0                      ; d66900a8 03dae8f7
	v_maxmin_num_f32 v162, -4.0, v113, 4.0                      ; d66900a2 03dae2f7
	v_maxmin_num_f32 v164, -4.0, v114, 4.0                      ; d66900a4 03dae4f7
	v_maxmin_num_f32 v160, -4.0, v112, 4.0                      ; d66900a0 03dae0f7
	v_maxmin_num_f32 v170, -4.0, v117, 4.0                      ; d66900aa 03daeaf7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v118, 4.0                      ; d66900ac 03daecf7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	buffer_load_b128 v[108:111], v14, s[36:39], null offen offset:64 ; c405c07c 4080486c 0000400e
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v119, 4.0                      ; d66900ae 03daeef7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[106:107], v[120:127] ; cc464078 1de2d52c
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_mul_f32 v115, v115, v167 :: v_dual_mul_f32 v114, v114, v164 ; c8c74f73 73734972
	v_dual_mul_f32 v113, v113, v163 :: v_dual_mul_f32 v112, v112, v160 ; c8c74771 71714170
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	buffer_load_b128 v[112:115], v14, s[36:39], null offen offset:80 ; c405c07c 40804870 0000500e
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c84355ab aba953a8 3f650000
	v_maxmin_num_f32 v178, -4.0, v121, 4.0                      ; d66900b2 03daf2f7
	v_maxmin_num_f32 v176, -4.0, v120, 4.0                      ; d66900b0 03daf0f7
	v_maxmin_num_f32 v180, -4.0, v122, 4.0                      ; d66900b4 03daf4f7
	v_maxmin_num_f32 v182, -4.0, v123, 4.0                      ; d66900b6 03daf6f7
	v_maxmin_num_f32 v184, -4.0, v124, 4.0                      ; d66900b8 03daf8f7
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 ; c8435daf afad5bac 3f650000
	v_maxmin_num_f32 v186, -4.0, v125, 4.0                      ; d66900ba 03dafaf7
	v_dual_mul_f32 v117, v117, v171 :: v_dual_mul_f32 v116, v116, v168 ; c8c75775 75755174
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v126, 4.0                      ; d66900bc 03dafcf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v127, 4.0                      ; d66900be 03dafef7
	v_dual_mul_f32 v119, v119, v175 :: v_dual_mul_f32 v118, v118, v172 ; c8c75f77 77775976
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84365b3 b3b163b0 3f650000
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c8436db7 b7b56bb4 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84375bb bbb973b8 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[98:99], 0 ; cc464080 1a02c52a
	v_dual_mul_f32 v121, v121, v179 :: v_dual_mul_f32 v120, v120, v176 ; c8c76779 79796178
	v_dual_mul_f32 v123, v123, v183 :: v_dual_mul_f32 v122, v122, v180 ; c8c76f7b 7b7b697a
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8437dbf bfbd7bbc 3f650000
	v_dual_mul_f32 v125, v125, v187 :: v_dual_mul_f32 v124, v124, v184 ; c8c7777d 7d7d717c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v127, v127, v191 :: v_dual_mul_f32 v126, v126, v188 ; c8c77f7f 7f7f797e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[106:107], v[128:135] ; cc464080 1e02d52e
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[88:89], 0 ; cc464078 1a02b12a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[96:97], v[120:127] ; cc464078 1de2c12e
	v_maxmin_num_f32 v46, -4.0, v123, 4.0                       ; d669002e 03daf6f7
	v_maxmin_num_f32 v44, -4.0, v122, 4.0                       ; d669002c 03daf4f7
	v_maxmin_num_f32 v42, -4.0, v121, 4.0                       ; d669002a 03daf2f7
	v_maxmin_num_f32 v191, -4.0, v120, 4.0                      ; d66900bf 03daf0f7
	v_maxmin_num_f32 v88, -4.0, v124, 4.0                       ; d6690058 03daf8f7
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_fma_mix_f32 v47, 0xab28, |v46|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622f 0bfe5cff 3728ab28
	v_fma_mix_f32 v45, 0xab28, |v44|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe58ff 3728ab28
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v96, s5, v12, 2                              ; d6470060 020a1805
	v_fma_mix_f32 v43, 0xab28, |v42|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622b 0bfe54ff 3728ab28
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v125, 4.0                       ; d6690061 03dafaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_fmaak_f32 v43, v43, v42, 0x3f650000 :: v_dual_fmaak_f32 v44, v44, v45, 0x3f650000 ; c842552b 2b2c5b2c 3f650000
	v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 :: v_dual_fmaak_f32 v47, v47, v46, 0x3f650000 ; c842b358 582e5d2f 3f650000
	v_dual_mul_f32 v122, v122, v44 :: v_dual_mul_f32 v121, v121, v43 ; c8c6597a 7a785779
	v_dual_mul_f32 v124, v124, v88 :: v_dual_mul_f32 v123, v123, v47 ; c8c6b17c 7c7a5f7b
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v96, s[44:47], null offen        ; c405c07c 4080582c 00000060
	buffer_load_b128 v[116:119], v96, s[44:47], null offen offset:1024 ; c405c07c 40805874 00040060
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v191, v191, v13, 0x3f650000                     ; 5b7e1bbf 3f650000
	v_mul_f32_e32 v120, v120, v191                              ; 10f17f78
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870251
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v99, -4.0, v126, 4.0                       ; d6690063 03dafcf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v127, 4.0                      ; d669006b 03dafef7
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v106, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfec6ff 3728ab28
	v_fmaak_f32 v98, v98, v97, 0x3f650000                       ; 5ac4c362 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_fmaak_f32 v99, v99, v106, 0x3f650000                      ; 5ac6d563 3f650000
	v_maxmin_num_f32 v136, -4.0, v128, 4.0                      ; d6690088 03db00f7
	v_mul_f32_e32 v125, v125, v98                               ; 10fac57d
	v_mul_f32_e32 v126, v126, v99                               ; 10fcc77e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v124, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfed6ff 3728ab28
	v_fmaak_f32 v124, v124, v107, 0x3f650000                    ; 5af8d77c 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_mul_f32_e32 v127, v127, v124                              ; 10fef97f
	v_maxmin_num_f32 v138, -4.0, v129, 4.0                      ; d669008a 03db02f7
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[120:123], v96, s[44:47], null offen offset:2048 ; c405c07c 40805878 00080060
	buffer_load_b128 v[124:127], v96, s[44:47], null offen offset:512 ; c405c07c 4080587c 00020060
	buffer_load_b128 v[140:143], v96, s[44:47], null offen offset:1536 ; c405c07c 4080588c 00060060
	buffer_load_b128 v[96:99], v96, s[44:47], null offen offset:2560 ; c405c07c 40805860 000a0060
	v_maxmin_num_f32 v144, -4.0, v130, 4.0                      ; d6690090 03db04f7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v131, 4.0                      ; d6690092 03db06f7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v132, 4.0                      ; d6690094 03db08f7
	v_maxmin_num_f32 v150, -4.0, v133, 4.0                      ; d6690096 03db0af7
	v_maxmin_num_f32 v152, -4.0, v134, 4.0                      ; d6690098 03db0cf7
	v_maxmin_num_f32 v154, -4.0, v135, 4.0                      ; d669009a 03db0ef7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fmaak_f32 v136, v136, v137, 0x3f650000                    ; 5b111388 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fmaak_f32 v144, v144, v145, 0x3f650000                    ; 5b212390 3f650000
	v_dual_mul_f32 v128, v128, v136 :: v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 ; c8c31180 808b158b 3f650000
	v_fmaak_f32 v147, v147, v146, 0x3f650000                    ; 5b272593 3f650000
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v130, v130, v144 :: v_dual_mul_f32 v129, v129, v139 ; c8c72182 82811781
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_dual_mul_f32 v145, v101, v49 :: v_dual_mul_f32 v144, v100, v48 ; c8c66365 91906164
	v_mul_f32_e32 v131, v131, v147                              ; 11072783
	v_dual_mul_f32 v147, v103, v51 :: v_dual_mul_f32 v146, v102, v50 ; c8c66767 93926566
	v_dual_mul_f32 v133, v133, v151 :: v_dual_mul_f32 v132, v132, v148 ; c8c72f85 85852984
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_mul_f32 v149, v105, v53 :: v_dual_mul_f32 v148, v104, v52 ; c8c66b69 95946968
	v_dual_mul_f32 v151, v11, v55 :: v_dual_mul_f32 v150, v10, v54 ; c8c66f0b 97966d0a
	v_dual_mul_f32 v135, v135, v155 :: v_dual_mul_f32 v134, v134, v152 ; c8c73787 87873186
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v129, v91, v49 :: v_dual_mul_f32 v128, v90, v48 ; c8c6635b 8180615a
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[18:19], v[144:151] ; cc464090 1e422538
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v131, v93, v51 :: v_dual_mul_f32 v130, v92, v50 ; c8c6675d 8382655c
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	s_bitset0_b32 s41, 14                                       ; bea9108e
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_buffer_load_b32 s10, s[40:43], s10 offset:0x0             ; f4020294 14000000
	v_dual_mul_f32 v133, v95, v53 :: v_dual_mul_f32 v132, v94, v52 ; c8c66b5f 8584695e
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v135, v7, v55 :: v_dual_mul_f32 v134, v6, v54 ; c8c66f07 87866d06
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[16:17], v[128:135] ; cc464080 1e022138
	v_cvt_pk_f32_fp8_e32 v[48:49], v4                           ; 7e60dd04
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[22:23], v[144:151] ; cc464090 1e422d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[20:21], v[128:135] ; cc464080 1e02293c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[64:65], v[28:29], v[144:151] ; cc464090 1e423940
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[64:65], v[24:25], v[128:135] ; cc464080 1e023140
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[30:31], v[144:151] ; cc464090 1e423d44
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mul_f32 v153, v49, v109 :: v_dual_mul_f32 v152, v48, v108 ; c8c6db31 9998d930
	v_cvt_pk_f32_fp8_e32 v[48:49], v132                         ; 7e60dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[26:27], v[128:135] ; cc464080 1e023544
	v_dual_mul_f32 v155, v49, v111 :: v_dual_mul_f32 v154, v48, v110 ; c8c6df31 9b9add30
	v_cvt_pk_f32_fp8_e32 v[48:49], v5                           ; 7e60dd05
	v_cvt_pk_f32_fp8_e32 v[4:5], v133                           ; 7e08dd85
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[36:37], v[144:151] ; cc464090 1e424948
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[32:33], v[128:135] ; cc464080 1e024148
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v159, v5, v115 :: v_dual_mul_f32 v158, v4, v114 ; c8c6e705 9f9ee504
	v_cvt_pk_f32_fp8_e32 v[4:5], v8                             ; 7e08dd08
	v_dual_mul_f32 v157, v49, v113 :: v_dual_mul_f32 v156, v48, v112 ; c8c6e331 9d9ce130
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[76:77], v[38:39], v[144:151] ; cc464090 1e424d4c
	v_dual_mul_f32 v49, v5, v109 :: v_dual_mul_f32 v48, v4, v108 ; c8c6db05 3130d904
	v_cvt_pk_f32_fp8_e32 v[4:5], v136                           ; 7e08dd88
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[34:35], v[128:135] ; cc464080 1e02454c
	v_dual_mul_f32 v51, v5, v111 :: v_dual_mul_f32 v50, v4, v110 ; c8c6df05 3332dd04
	v_cvt_pk_f32_fp8_e32 v[4:5], v9                             ; 7e08dd09
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[80:81], v[14:15], v[144:151] ; cc464090 1e421d50
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[16:17], v[152:159] ; cc464098 1e62213a
	v_dual_mul_f32 v53, v5, v113 :: v_dual_mul_f32 v52, v4, v112 ; c8c6e305 3534e104
	v_cvt_pk_f32_fp8_e32 v[4:5], v137                           ; 7e08dd89
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[40:41], v[128:135] ; cc464080 1e025150
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[88:89], v[144:151] ; cc464090 1e42b154
	v_dual_mul_f32 v55, v5, v115 :: v_dual_mul_f32 v54, v4, v114 ; c8c6e705 3736e504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[58:59], v[18:19], v[48:55] ; cc464030 1cc2253a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[20:21], v[152:159] ; cc464098 1e62293e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[42:43], v[128:135] ; cc464080 1e025554
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[62:63], v[22:23], v[48:55] ; cc464030 1cc22d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[24:25], v[152:159] ; cc464098 1e623142
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[66:67], v[28:29], v[48:55] ; cc464030 1cc23942
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[70:71], v[26:27], v[152:159] ; cc464098 1e623546
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[118:119], v[6:7], 0 ; cc464038 1a020d76
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[70:71], v[30:31], v[48:55] ; cc464030 1cc23d46
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[46:47], v[6:7], 0   ; cc464018 1a020d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[32:33], v[152:159] ; cc464098 1e62414a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[6:7], 0   ; cc464010 1a020d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[74:75], v[36:37], v[48:55] ; cc464030 1cc2494a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[78:79], v[34:35], v[152:159] ; cc464098 1e62454e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[78:79], v[38:39], v[48:55] ; cc464030 1cc24d4e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[116:117], v[6:7], 0 ; cc464020 1a020d74
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[82:83], v[40:41], v[152:159] ; cc464098 1e625152
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[82:83], v[14:15], v[48:55] ; cc464030 1cc21d52
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[42:43], v[152:159] ; cc464098 1e625556
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[86:87], v[88:89], v[48:55] ; cc464030 1cc2b156
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[6:7], v[120:121], 0 ; cc464040 1a02f106
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[6:7], v[122:123], 0 ; cc464048 1a02f506
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[126:127], v[4:5], v[24:31] ; cc464018 1c62097e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[140:141], v[4:5], v[32:39] ; cc464020 1c82098c
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[142:143], v[4:5], v[56:63] ; cc464038 1ce2098e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[124:125], v[4:5], v[16:23] ; cc464010 1c42097c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[4:5], v[96:97], v[64:71] ; cc464040 1d02c104
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[4:5], v[98:99], v[72:79] ; cc464048 1d22c504
	v_dual_mul_f32 v163, v59, v59 :: v_dual_mul_f32 v160, v25, v25 ; c8c6773b a3a03319
	v_dual_mul_f32 v162, v27, v27 :: v_dual_mul_f32 v161, v57, v57 ; c8c6371b a2a07339
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_dual_fmac_f32 v163, v35, v35 :: v_dual_fmac_f32 v160, v17, v17 ; c8004723 a3a02311
	s_mov_b32 s19, 0x76543210                                   ; be9300ff 76543210
	v_dual_fmac_f32 v162, v19, v19 :: v_dual_fmac_f32 v161, v33, v33 ; c8002713 a2a04321
	s_mov_b32 s24, 0xfedcba98                                   ; be9800ff fedcba98
	v_dual_fmac_f32 v163, v39, v39 :: v_dual_fmac_f32 v160, v21, v21 ; c8004f27 a3a02b15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v23, v23 :: v_dual_fmac_f32 v161, v37, v37 ; c8002f17 a2a04b25
	v_dual_fmac_f32 v163, v63, v63 :: v_dual_fmac_f32 v160, v29, v29 ; c8007f3f a3a03b1d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v31, v31 :: v_dual_fmac_f32 v161, v61, v61 ; c8003f1f a2a07b3d
	v_dual_fmac_f32 v163, v34, v34 :: v_dual_fmac_f32 v160, v16, v16 ; c8004522 a3a02110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v32, v32 :: v_dual_fmac_f32 v162, v18, v18 ; c8004120 a1a22512
	v_dual_fmac_f32 v163, v58, v58 :: v_dual_fmac_f32 v160, v24, v24 ; c800753a a3a03118
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v56, v56 :: v_dual_fmac_f32 v162, v26, v26 ; c8007138 a1a2351a
	v_dual_fmac_f32 v163, v38, v38 :: v_dual_fmac_f32 v160, v20, v20 ; c8004d26 a3a02914
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v36, v36 :: v_dual_fmac_f32 v162, v22, v22 ; c8004924 a1a22d16
	v_dual_fmac_f32 v163, v62, v62 :: v_dual_fmac_f32 v160, v28, v28 ; c8007d3e a3a0391c
	v_lshl_add_u32 v167, v2, 5, v1                              ; d64600a7 04050b02
	v_lshl_add_u32 v2, v2, 6, s7                                ; d6460002 001d0d02
	v_dual_fmac_f32 v161, v60, v60 :: v_dual_fmac_f32 v162, v30, v30 ; c800793c a1a23d1e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
	v_fma_mixlo_f16 v164, 1.0, v160, v162                       ; cc2100a4 068b40f2
	v_fma_mixhi_f16 v164, 1.0, v161, v163                       ; cc2200a4 068f42f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_permlanex16_b32 v165, v164, s19, s24 op_sel:[1,1]         ; d65c18a5 006027a4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[165:166]            ; 1a034ba4
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v255                             ; 0a01ffa4
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00a6
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
	v_rsq_f32_e32 v166, v166                                    ; 7f4c5da6
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v166, s10, v166                               ; 114d4c0a
	v_dual_mul_f32 v19, v19, v166 :: v_dual_mul_f32 v18, v18, v166 ; c8c74d13 13134d12
	v_dual_mul_f32 v17, v17, v166 :: v_dual_mul_f32 v16, v16, v166 ; c8c74d11 11114d10
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v2, s[36:39], null offen         ; c405c07c 40804810 00000002
	buffer_load_b128 v[40:43], v2, s[36:39], null offen offset:16 ; c405c07c 40804828 00001002
(invalid instruction)                                        ; d58b08a4
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
	v_mul_f32_e32 v22, v22, v166                                ; 102d4d16
	v_mul_f32_e32 v23, v23, v166                                ; 102f4d17
	v_dual_mul_f32 v21, v21, v166 :: v_dual_mul_f32 v20, v20, v166 ; c8c74d15 15154d14
	v_dual_mul_f32 v25, v25, v166 :: v_dual_mul_f32 v24, v24, v166 ; c8c74d19 19194d18
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_rsq_f32_e32 v164, v164                                    ; 7f485da4
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a5
	v_dual_mul_f32 v35, v35, v164 :: v_dual_mul_f32 v34, v34, v164 ; c8c74923 23234922
	v_dual_mul_f32 v33, v33, v164 :: v_dual_mul_f32 v32, v32, v164 ; c8c74921 21214920
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v2, s[36:39], null offen offset:8192 ; c405c07c 40804814 00200002
	buffer_load_b128 v[32:35], v2, s[36:39], null offen offset:8208 ; c405c07c 40804820 00201002
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
	v_dual_mul_f32 v27, v27, v166 :: v_dual_mul_f32 v26, v26, v166 ; c8c74d1b 1b1b4d1a
	v_dual_mul_f32 v29, v29, v166 :: v_dual_mul_f32 v28, v28, v166 ; c8c74d1d 1d1d4d1c
	v_dual_mul_f32 v31, v31, v166 :: v_dual_mul_f32 v30, v30, v166 ; c8c74d1f 1f1f4d1e
	v_dual_mul_f32 v37, v37, v164 :: v_dual_mul_f32 v36, v36, v164 ; c8c74925 25254924
	v_dual_mul_f32 v39, v39, v164 :: v_dual_mul_f32 v38, v38, v164 ; c8c74927 27274926
	v_dual_mul_f32 v57, v57, v164 :: v_dual_mul_f32 v56, v56, v164 ; c8c74939 39394938
	v_dual_mul_f32 v59, v59, v164 :: v_dual_mul_f32 v58, v58, v164 ; c8c7493b 3b3b493a
	v_dual_mul_f32 v61, v61, v164 :: v_dual_mul_f32 v60, v60, v164 ; c8c7493d 3d3d493c
	v_dual_mul_f32 v63, v63, v164 :: v_dual_mul_f32 v62, v62, v164 ; c8c7493f 3f3f493e
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v167, v[6:7], v[26:27] offset1:2         ; d9380200 001a06a7
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v2, s[36:39], null offen offset:64 ; c405c07c 4080481c 00004002
	buffer_load_b128 v[36:39], v2, s[36:39], null offen offset:80 ; c405c07c 40804824 00005002
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	ds_store_2addr_b64 v167, v[26:27], v[26:27] offset0:64 offset1:66 ; d9384240 001a1aa7
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[10:11], 0 ; cc464040 1a02152e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[10:11], 0 ; cc464038 1a02152c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[116:117], v[10:11], 0 ; cc464048 1a021574
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[118:119], v[10:11], 0 ; cc464050 1a021576
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[10:11], v[120:121], 0 ; cc464058 1a02f10a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[122:123], 0 ; cc464068 1a02f50a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[126:127], v[8:9], v[64:71] ; cc464040 1d02117e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[124:125], v[8:9], v[56:63] ; cc464038 1ce2117c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[140:141], v[8:9], v[72:79] ; cc464048 1d22118c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[142:143], v[8:9], v[80:87] ; cc464050 1d42118e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[96:97], v[88:95] ; cc464058 1d62c108
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[98:99], v[104:111] ; cc464068 1da2c508
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v2, s[36:39], null offen offset:8256 ; c405c07c 40804808 00204002
	buffer_load_b128 v[44:47], v2, s[36:39], null offen offset:8272 ; c405c07c 4080482c 00205002
	v_mul_f32_e32 v168, v65, v65                                ; 11508341
	v_dual_mul_f32 v170, v67, v67 :: v_dual_mul_f32 v169, v81, v81 ; c8c68743 aaa8a351
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_fmac_f32_e32 v168, v57, v57                               ; 57507339
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[96:99], v2, s[36:39], null offen offset:128 ; c405c07c 40804860 00008002
	buffer_load_b128 v[100:103], v2, s[36:39], null offen offset:144 ; c405c07c 40804864 00009002
	v_dual_fmac_f32 v170, v59, v59 :: v_dual_fmac_f32 v169, v73, v73 ; c800773b aaa89349
	v_dual_fmac_f32 v168, v61, v61 :: v_dual_mul_f32 v171, v83, v83 ; c8067b3d a8aaa753
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v170, v63, v63 :: v_dual_fmac_f32 v169, v77, v77 ; c8007f3f aaa89b4d
	v_dual_fmac_f32 v168, v69, v69 :: v_dual_fmac_f32 v171, v75, v75 ; c8008b45 a8aa974b
	v_dual_fmac_f32 v170, v71, v71 :: v_dual_fmac_f32 v169, v85, v85 ; c8008f47 aaa8ab55
	v_dual_fmac_f32 v168, v56, v56 :: v_dual_fmac_f32 v171, v79, v79 ; c8007138 a8aa9f4f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v170, v58, v58 :: v_dual_fmac_f32 v169, v72, v72 ; c800753a aaa89148
	v_dual_fmac_f32 v168, v64, v64 :: v_dual_fmac_f32 v171, v87, v87 ; c8008140 a8aaaf57
	v_dual_fmac_f32 v170, v66, v66 :: v_dual_fmac_f32 v169, v80, v80 ; c8008542 aaa8a150
	v_dual_fmac_f32 v168, v60, v60 :: v_dual_fmac_f32 v171, v74, v74 ; c800793c a8aa954a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v170, v62, v62 :: v_dual_fmac_f32 v169, v76, v76 ; c8007d3e aaa8994c
	v_dual_fmac_f32 v171, v82, v82 :: v_dual_fmac_f32 v168, v68, v68 ; c800a552 aba88944
	v_dual_fmac_f32 v170, v70, v70 :: v_dual_fmac_f32 v169, v84, v84 ; c8008d46 aaa8a954
	v_fmac_f32_e32 v171, v78, v78                               ; 57569d4e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mixlo_f16 v172, 1.0, v168, v170                       ; cc2100ac 06ab50f2
	v_fmac_f32_e32 v171, v86, v86                               ; 5756ad56
	v_fma_mixhi_f16 v172, 1.0, v169, v171                       ; cc2200ac 06af52f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v173, v172, s19, s24 op_sel:[1,1]         ; d65c18ad 006027ac
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[173:174]            ; 1a035bac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v255                             ; 0a01ffac
(invalid instruction)                                        ; 00000410
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v174, v174                                    ; 7f5c5dae
	v_mul_f32_e32 v174, s10, v174                               ; 115d5c0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_mul_f32 v57, v57, v174 :: v_dual_mul_f32 v56, v56, v174 ; c8c75d39 39395d38
	v_dual_mul_f32 v61, v61, v174 :: v_dual_mul_f32 v60, v60, v174 ; c8c75d3d 3d3d5d3c
	v_dual_mul_f32 v63, v63, v174 :: v_dual_mul_f32 v62, v62, v174 ; c8c75d3f 3f3f5d3e
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v2, s[36:39], null offen offset:8320 ; c405c07c 4080483c 00208002
	buffer_load_b128 v[112:115], v2, s[36:39], null offen offset:8336 ; c405c07c 40804870 00209002
(invalid instruction)                                        ; d58b08ac
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	v_dual_mul_f32 v59, v59, v174 :: v_dual_mul_f32 v58, v58, v174 ; c8c75d3b 3b3b5d3a
	v_dual_mul_f32 v66, v66, v174 :: v_dual_mul_f32 v65, v65, v174 ; c8c75d42 42415d41
	v_dual_mul_f32 v68, v68, v174 :: v_dual_mul_f32 v67, v67, v174 ; c8c75d44 44435d43
	v_dual_mul_f32 v70, v70, v174 :: v_dual_mul_f32 v69, v69, v174 ; c8c75d46 46455d45
	v_rsq_f32_e32 v172, v172                                    ; 7f585dac
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870155
	v_mul_f32_e32 v72, v72, v172                                ; 10915948
	v_dual_mul_f32 v78, v78, v172 :: v_dual_mul_f32 v77, v77, v172 ; c8c7594e 4e4d594d
	v_dual_mul_f32 v64, v64, v174 :: v_dual_mul_f32 v79, v79, v172 ; c8c75d40 404f594f
	v_dual_mul_f32 v76, v76, v172 :: v_dual_mul_f32 v75, v75, v172 ; c8c7594c 4c4b594b
	v_dual_mul_f32 v74, v74, v172 :: v_dual_mul_f32 v73, v73, v172 ; c8c7594a 4a495949
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[76:79], v2, s[36:39], null offen offset:192 ; c405c07c 4080484c 0000c002
	buffer_load_b128 v[88:91], v2, s[36:39], null offen offset:208 ; c405c07c 40804858 0000d002
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mul_f32_e32 v71, v71, v174                                ; 108f5d47
	v_dual_mul_f32 v81, v81, v172 :: v_dual_mul_f32 v80, v80, v172 ; c8c75951 51515950
	v_dual_mul_f32 v83, v83, v172 :: v_dual_mul_f32 v82, v82, v172 ; c8c75953 53535952
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_dual_mul_f32 v85, v85, v172 :: v_dual_mul_f32 v84, v84, v172 ; c8c75955 55555954
	v_dual_mul_f32 v87, v87, v172 :: v_dual_mul_f32 v86, v86, v172 ; c8c75957 57575956
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v167, v[58:59], v[66:67] offset0:128 offset1:130 ; d9388280 00423aa7
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v2, s[36:39], null offen offset:8384 ; c405c07c 40804844 0020c002
	buffer_load_b128 v[80:83], v2, s[36:39], null offen offset:8400 ; c405c07c 40804850 0020d002
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v167, v[26:27], v[26:27] offset0:192 offset1:194 ; d938c2c0 001a1aa7
	ds_load_b64 v[26:27], v167                                  ; d9d80000 1a0000a7
	ds_load_b64 v[66:67], v167 offset:16                        ; d9d80010 420000a7
	s_mov_b32 s25, 0x3d380000                                   ; be9900ff 3d380000
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[4:5], 0 ; cc464068 1a02091a
	s_wait_dscnt 0x0                                            ; bfc60000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[66:67], v[24:25], v[104:111] ; cc464068 1da23142
	s_movk_i32 s26, 0x3e47                                      ; b01a3e47
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_mixlo_f16 v176, s25, v106, v18                        ; cc2100b0 044ad419
	v_fma_mixhi_f16 v176, s25, v107, v19                        ; cc2200b0 044ed619
	v_fma_mixlo_f16 v175, s25, v104, v16                        ; cc2100af 0442d019
	v_fma_mixhi_f16 v175, s25, v105, v17                        ; cc2200af 0446d219
	ds_load_b64 v[16:17], v167 offset:512                       ; d9d80200 100000a7
	ds_load_b64 v[18:19], v167 offset:528                       ; d9d80210 120000a7
	s_movk_i32 s28, 0x3c20                                      ; b01c3c20
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[56:57], 0 ; cc464078 1a02711a
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v177, s25, v108, v40                        ; cc2100b1 04a2d819
	v_fma_mixhi_f16 v177, s25, v109, v41                        ; cc2200b1 04a6da19
	v_fma_mixlo_f16 v178, s25, v110, v42                        ; cc2100b2 04aadc19
	v_fma_mixhi_f16 v178, s25, v111, v43                        ; cc2200b2 04aede19
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v28                              ; 0a0039af
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v28                              ; 0a0039b0
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v28                              ; 0a0039b1
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v28                              ; 0a0039b2
(invalid instruction)                                        ; cc1b00af
	v_subrev_f32_e32 v0, v175, v26                              ; 0a0035af
(invalid instruction)                                        ; cc1b00b0
	v_subrev_f32_e32 v0, v176, v26                              ; 0a0035b0
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[66:67], v[64:65], v[120:127] ; cc464078 1de28142
(invalid instruction)                                        ; cc1b00b1
	v_subrev_f32_e32 v0, v177, v26                              ; 0a0035b1
(invalid instruction)                                        ; cc1b00b2
	v_subrev_f32_e32 v0, v178, v26                              ; 0a0035b2
	s_wait_loadcnt 0xd                                          ; bfc0000d
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mixlo_f16 v180, s25, v122, v22                        ; cc2100b4 045af419
	v_fma_mixlo_f16 v179, s25, v120, v20                        ; cc2100b3 0452f019
	v_fma_mixhi_f16 v180, s25, v123, v23                        ; cc2200b4 045ef619
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v181, s25, v124, v32                        ; cc2100b5 0482f819
	v_fma_mixhi_f16 v181, s25, v125, v33                        ; cc2200b5 0486fa19
	v_fma_mixhi_f16 v179, s25, v121, v21                        ; cc2200b3 0456f219
	v_fma_mixlo_f16 v182, s25, v126, v34                        ; cc2100b6 048afc19
	v_fma_mixhi_f16 v182, s25, v127, v35                        ; cc2200b6 048efe19
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[4:5], 0 ; cc464068 1a020910
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[56:57], 0 ; cc464078 1a027110
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v28                              ; 0a0039b4
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v28                              ; 0a0039b5
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v28                              ; 0a0039b3
(invalid instruction)                                        ; cc1c00b6
	v_subrev_f32_e32 v0, v182, v28                              ; 0a0039b6
	ds_load_b64 v[16:17], v167 offset:1024                      ; d9d80400 100000a7
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[24:25], v[104:111] ; cc464068 1da23112
(invalid instruction)                                        ; cc1b00b4
	v_subrev_f32_e32 v0, v180, v26                              ; 0a0035b4
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[64:65], v[120:127] ; cc464078 1de28112
	ds_load_b64 v[18:19], v167 offset:1040                      ; d9d80410 120000a7
(invalid instruction)                                        ; cc1b00b5
	v_subrev_f32_e32 v0, v181, v26                              ; 0a0035b5
(invalid instruction)                                        ; cc1b00b3
	v_subrev_f32_e32 v0, v179, v26                              ; 0a0035b3
(invalid instruction)                                        ; cc1b00b6
	v_subrev_f32_e32 v0, v182, v26                              ; 0a0035b6
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v184, s25, v106, v30                        ; cc2100b8 047ad419
	v_fma_mixhi_f16 v184, s25, v107, v31                        ; cc2200b8 047ed619
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v186, s25, v110, v38                        ; cc2100ba 049adc19
	v_fma_mixlo_f16 v183, s25, v104, v28                        ; cc2100b7 0472d019
	v_fma_mixhi_f16 v186, s25, v111, v39                        ; cc2200ba 049ede19
	v_fma_mixlo_f16 v185, s25, v108, v36                        ; cc2100b9 0492d819
	v_fma_mixhi_f16 v185, s25, v109, v37                        ; cc2200b9 0496da19
	v_fma_mixhi_f16 v183, s25, v105, v29                        ; cc2200b7 0476d219
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v28                              ; 0a0039b8
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v187, s25, v120, v8                         ; cc2100bb 0422f019
	v_fma_mixhi_f16 v187, s25, v121, v9                         ; cc2200bb 0426f219
	v_fma_mixlo_f16 v188, s25, v122, v10                        ; cc2100bc 042af419
	v_fma_mixhi_f16 v188, s25, v123, v11                        ; cc2200bc 042ef619
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v189, s25, v124, v44                        ; cc2100bd 04b2f819
	v_fma_mixhi_f16 v189, s25, v125, v45                        ; cc2200bd 04b6fa19
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v28                              ; 0a0039ba
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v28                              ; 0a0039b9
	v_fma_mixlo_f16 v190, s25, v126, v46                        ; cc2100be 04bafc19
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v28                              ; 0a0039b7
(invalid instruction)                                        ; cc1b00b8
	v_subrev_f32_e32 v0, v184, v26                              ; 0a0035b8
	v_fma_mixhi_f16 v190, s25, v127, v47                        ; cc2200be 04befe19
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v28                              ; 0a0039bb
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[4:5], 0   ; cc464020 1a020910
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[56:57], 0 ; cc464028 1a027110
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v28                              ; 0a0039bc
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v28                              ; 0a0039bd
(invalid instruction)                                        ; cc1b00ba
	v_subrev_f32_e32 v0, v186, v26                              ; 0a0035ba
(invalid instruction)                                        ; cc1b00b9
	v_subrev_f32_e32 v0, v185, v26                              ; 0a0035b9
(invalid instruction)                                        ; cc1b00b7
	v_subrev_f32_e32 v0, v183, v26                              ; 0a0035b7
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v28                              ; 0a0039be
	ds_load_b64 v[8:9], v167 offset:1536                        ; d9d80600 080000a7
(invalid instruction)                                        ; cc1b00bb
	v_subrev_f32_e32 v0, v187, v26                              ; 0a0035bb
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[24:25], v[32:39] ; cc464020 1c823112
	ds_load_b64 v[16:17], v167 offset:1552                      ; d9d80610 100000a7
(invalid instruction)                                        ; cc1b00bc
	v_subrev_f32_e32 v0, v188, v26                              ; 0a0035bc
(invalid instruction)                                        ; cc1b00bd
	v_subrev_f32_e32 v0, v189, v26                              ; 0a0035bd
(invalid instruction)                                        ; cc1b00be
	v_subrev_f32_e32 v0, v190, v26                              ; 0a0035be
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[64:65], v[40:47] ; cc464028 1ca28112
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v10, s25, v36, v100                         ; cc21000a 05924819
	v_fma_mixhi_f16 v10, s25, v37, v101                         ; cc22000a 05964a19
	v_fma_mixlo_f16 v2, s25, v34, v98                           ; cc210002 058a4419
	v_fma_mixhi_f16 v2, s25, v35, v99                           ; cc220002 058e4619
	v_fma_mixlo_f16 v191, s25, v32, v96                         ; cc2100bf 05824019
	v_fma_mixhi_f16 v191, s25, v33, v97                         ; cc2200bf 05864219
	v_fma_mixlo_f16 v11, s25, v38, v102                         ; cc21000b 059a4c19
	v_fma_mixhi_f16 v11, s25, v39, v103                         ; cc22000b 059e4e19
(invalid instruction)                                        ; cc1c000a
	v_subrev_f32_e32 v0, v10, v28                               ; 0a00390a
(invalid instruction)                                        ; cc1c0002
	v_subrev_f32_e32 v0, v2, v28                                ; 0a003902
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v28                              ; 0a0039bf
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v28                               ; 0a00390b
(invalid instruction)                                        ; cc1b000a
	v_subrev_f32_e32 v0, v10, v26                               ; 0a00350a
(invalid instruction)                                        ; cc1b0002
	v_subrev_f32_e32 v0, v2, v26                                ; 0a003502
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v26                              ; 0a0035bf
(invalid instruction)                                        ; cc1b000b
	v_subrev_f32_e32 v0, v11, v26                               ; 0a00350b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v13, s25, v40, v60                          ; cc21000d 04f25019
	v_fma_mixhi_f16 v13, s25, v41, v61                          ; cc22000d 04f65219
	v_fma_mixlo_f16 v18, s25, v42, v62                          ; cc210012 04fa5419
	v_fma_mixhi_f16 v18, s25, v43, v63                          ; cc220012 04fe5619
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[8:9], v[4:5], 0     ; cc464020 1a020908
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v20, s25, v46, v114                         ; cc210014 05ca5c19
	v_fma_mixhi_f16 v20, s25, v47, v115                         ; cc220014 05ce5e19
	v_fma_mixlo_f16 v19, s25, v44, v112                         ; cc210013 05c25819
	v_fma_mixhi_f16 v19, s25, v45, v113                         ; cc220013 05c65a19
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[8:9], v[56:57], 0   ; cc464028 1a027108
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v28                               ; 0a00390d
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v28                               ; 0a003912
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v28                               ; 0a003914
(invalid instruction)                                        ; cc1c0013
	v_subrev_f32_e32 v0, v19, v28                               ; 0a003913
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[24:25], v[32:39] ; cc464020 1c823110
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v26                               ; 0a00350d
(invalid instruction)                                        ; cc1b0012
	v_subrev_f32_e32 v0, v18, v26                               ; 0a003512
(invalid instruction)                                        ; cc1b0014
	v_subrev_f32_e32 v0, v20, v26                               ; 0a003514
(invalid instruction)                                        ; cc1b0013
	v_subrev_f32_e32 v0, v19, v26                               ; 0a003513
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[64:65], v[40:47] ; cc464028 1ca28110
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v21, s25, v32, v76                          ; cc210015 05324019
	v_fma_mixhi_f16 v21, s25, v33, v77                          ; cc220015 05364219
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v24, s25, v38, v90                          ; cc210018 056a4c19
	v_fma_mixhi_f16 v24, s25, v39, v91                          ; cc220018 056e4e19
	v_fma_mixlo_f16 v23, s25, v36, v88                          ; cc210017 05624819
	v_fma_mixhi_f16 v23, s25, v37, v89                          ; cc220017 05664a19
	v_fma_mixlo_f16 v22, s25, v34, v78                          ; cc210016 053a4419
	v_fma_mixhi_f16 v22, s25, v35, v79                          ; cc220016 053e4619
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v28                               ; 0a003915
(invalid instruction)                                        ; cc1c0018
	v_subrev_f32_e32 v0, v24, v28                               ; 0a003918
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v28                               ; 0a003917
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v25, s25, v40, v68                          ; cc210019 05125019
	v_fma_mixhi_f16 v25, s25, v41, v69                          ; cc220019 05165219
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v27, s25, v44, v80                          ; cc21001b 05425819
	v_fma_mixhi_f16 v27, s25, v45, v81                          ; cc22001b 05465a19
	v_fma_mixlo_f16 v26, s25, v42, v70                          ; cc21001a 051a5419
	v_fma_mixhi_f16 v26, s25, v43, v71                          ; cc22001a 051e5619
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v28                               ; 0a003916
	v_fma_mixlo_f16 v28, s25, v46, v82                          ; cc21001c 054a5c19
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v26                               ; 0a003515
(invalid instruction)                                        ; cc1b0018
	v_subrev_f32_e32 v0, v24, v26                               ; 0a003518
	v_fma_mixhi_f16 v28, s25, v47, v83                          ; cc22001c 054e5e19
(invalid instruction)                                        ; cc1b0017
	v_subrev_f32_e32 v0, v23, v26                               ; 0a003517
	s_mov_b32 s30, 0x7ff88000                                   ; be9e00ff 7ff88000
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v28                               ; 0a003919
(invalid instruction)                                        ; cc1c001b
	v_subrev_f32_e32 v0, v27, v28                               ; 0a00391b
(invalid instruction)                                        ; cc1c001a
	v_subrev_f32_e32 v0, v26, v28                               ; 0a00391a
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v26                               ; 0a003516
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v21, v21, 5, s30                             ; d6460015 00790b15
	v_lshl_add_u32 v191, v191, 5, s30                           ; d64600bf 00790bbf
	v_lshl_add_u32 v183, v183, 5, s30                           ; d64600b7 00790bb7
	v_lshl_add_u32 v176, v176, 5, s30                           ; d64600b0 00790bb0
	v_lshl_add_u32 v175, v175, 5, s30                           ; d64600af 00790baf
	v_lshl_add_u32 v184, v184, 5, s30                           ; d64600b8 00790bb8
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v28                               ; 0a00391c
	v_lshl_add_u32 v2, v2, 5, s30                               ; d6460002 00790b02
(invalid instruction)                                        ; cc1b0019
	v_subrev_f32_e32 v0, v25, v26                               ; 0a003519
(invalid instruction)                                        ; cc1b001b
	v_subrev_f32_e32 v0, v27, v26                               ; 0a00351b
(invalid instruction)                                        ; cc1b001a
	v_subrev_f32_e32 v0, v26, v26                               ; 0a00351a
	v_lshl_add_u32 v177, v177, 5, s30                           ; d64600b1 00790bb1
	v_lshl_add_u32 v22, v22, 5, s30                             ; d6460016 00790b16
	v_lshl_add_u32 v185, v185, 5, s30                           ; d64600b9 00790bb9
	v_lshl_add_u32 v10, v10, 5, s30                             ; d646000a 00790b0a
	v_lshl_add_u32 v23, v23, 5, s30                             ; d6460017 00790b17
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[175:176], v[183:184]            ; 1a036faf
	v_lshl_add_u32 v178, v178, 5, s30                           ; d64600b2 00790bb2
(invalid instruction)                                        ; cc0f001e
	v_min_num_f64_e32 v[1:2], v[176:177], v[184:185]            ; 1a0371b0
	v_add_lshl_u32 v0, s9, v0, 2                                ; d6470000 020a0009
	buffer_load_b128 v[36:39], v0, s[36:39], null offen         ; c405c07c 40804824 00000000
	v_lshl_add_u32 v186, v186, 5, s30                           ; d64600ba 00790bba
(invalid instruction)                                        ; cc1b001c
	v_subrev_f32_e32 v0, v28, v26                               ; 0a00351c
	v_lshl_add_u32 v11, v11, 5, s30                             ; d646000b 00790b0b
	v_lshl_add_u32 v24, v24, 5, s30                             ; d6460018 00790b18
	buffer_load_b128 v[40:43], v0, s[36:39], null offen offset:16 ; c405c07c 40804828 00001000
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[177:178], v[185:186]            ; 1a0373b1
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[191:192]              ; 1a037f1d
(invalid instruction)                                        ; cc0f001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[2:3]                  ; 1a02051e
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[178:179], v[186:187]            ; 1a0375b2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[10:11]                ; 1a02151f
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[21:22]                ; 1a022b1d
(invalid instruction)                                        ; cc0f001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[22:23]                ; 1a022d1e
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[32:33], v[11:12]                ; 1a021720
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[23:24]                ; 1a022f1f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[30:31]                ; 1a023d1d
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[32:33], v[24:25]                ; 1a023120
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[31:32]                ; 1a023f1d
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v12, s6, v12, 2                              ; d647000c 020a1806
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[32:33]                ; 1a02411d
	buffer_load_b64 v[8:9], v12, s[44:47], null offen           ; c405407c 40805808 0000000c
	v_permlanex16_b32 v33, v29, s19, s24 op_sel:[1,1]           ; d65c1821 0060271d
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[33:34]                ; 1a02431d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v34, v29, v157/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64453b1d
	v_max_num_f16_e32 v34, 0x400, v34                           ; 624444ff 00000400
	buffer_load_b64 v[16:17], v12, s[44:47], null offen offset:512 ; c405407c 40805810 0002000c
	v_cvt_f32_f16_e32 v35, v34                                  ; 7e461722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v35, v35                                      ; 7e465523
	v_fma_mix_f32 v47, v178, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20002f 8a0247b2
	v_fma_mix_f32 v57, v184, v35, neg(0) op_sel_hi:[1,0,0]      ; cc200039 8a0247b8
	v_fma_mix_f32 v44, v175, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20002c 8a0247af
	v_fma_mix_f32 v45, v176, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20002d 8a0247b0
	v_fma_mix_f32 v176, v176, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a0247b0
	v_fma_mix_f32 v178, v178, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a0247b2
	v_fma_mix_f32 v56, v183, v35, neg(0) op_sel_hi:[1,0,0]      ; cc200038 8a0247b7
	v_fma_mix_f32 v183, v183, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a0247b7
	v_fma_mix_f32 v175, v175, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a0247af
	v_fma_mix_f32 v46, v177, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20002e 8a0247b1
	v_fma_mix_f32 v177, v177, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a0247b1
	v_fma_mix_f32 v184, v184, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a0247b8
	v_fma_mix_f32 v60, v185, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a0247b9
	v_fma_mix_f32 v185, v185, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a0247b9
	v_fma_mix_f32 v61, v186, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20003d 8a0247ba
	v_fma_mix_f32 v186, v186, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a0247ba
	v_fma_mix_f32 v62, v191, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20003e 8a0247bf
	v_fma_mix_f32 v191, v191, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a0247bf
	v_fma_mix_f32 v63, v2, v35, neg(0) op_sel_hi:[1,0,0]        ; cc20003f 8a024702
	v_fma_mix_f32 v2, v2, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200802 8a024702
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v56, v183, vcc_lo                     ; 02036f38
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v44, v175, vcc_lo                     ; 02035f2c
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v45, v176, vcc_lo                     ; 0203612d
	v_fma_mix_f32 v64, v10, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200040 8a02470a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v46, v177, vcc_lo                     ; 0203632e
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v47, v178, vcc_lo                     ; 0203652f
	v_fma_mix_f32 v10, v10, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080a 8a02470a
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v57, v184, vcc_lo                     ; 02037139
	v_fma_mix_f32 v65, v11, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200041 8a02470b
	v_fma_mix_f32 v11, v11, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080b 8a02470b
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v60, v185, vcc_lo                     ; 0203733c
	v_fma_mix_f32 v66, v21, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200042 8a024715
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v61, v186, vcc_lo                     ; 0203753d
	v_fma_mix_f32 v21, v21, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a024715
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v62, v191, vcc_lo                     ; 02037f3e
	v_fma_mix_f32 v67, v22, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200043 8a024716
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v63, v2, vcc_lo                       ; 0202053f
	v_fma_mix_f32 v22, v22, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a024716
	v_fma_mix_f32 v68, v23, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200044 8a024717
	v_fma_mix_f32 v23, v23, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a024717
	v_fma_mix_f32 v69, v24, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200045 8a024718
	v_fma_mix_f32 v24, v24, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200818 8a024718
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v64, v10, vcc_lo                      ; 02021540
	v_lshl_add_u32 v179, v179, 5, s30                           ; d64600b3 00790bb3
	v_lshl_add_u32 v187, v187, 5, s30                           ; d64600bb 00790bbb
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v65, v11, vcc_lo                      ; 02021741
	v_lshl_add_u32 v13, v13, 5, s30                             ; d646000d 00790b0d
	v_lshl_add_u32 v25, v25, 5, s30                             ; d6460019 00790b19
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v66, v21, vcc_lo                      ; 02022b42
	v_lshl_add_u32 v180, v180, 5, s30                           ; d64600b4 00790bb4
	v_lshl_add_u32 v188, v188, 5, s30                           ; d64600bc 00790bbc
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v67, v22, vcc_lo                      ; 02022d43
	v_lshl_add_u32 v18, v18, 5, s30                             ; d6460012 00790b12
	v_lshl_add_u32 v26, v26, 5, s30                             ; d646001a 00790b1a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v68, v23, vcc_lo                      ; 02022f44
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v69, v24, vcc_lo                      ; 02023145
	v_lshl_add_u32 v181, v181, 5, s30                           ; d64600b5 00790bb5
	v_lshl_add_u32 v189, v189, 5, s30                           ; d64600bd 00790bbd
	v_lshl_add_u32 v19, v19, 5, s30                             ; d6460013 00790b13
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[179:180], v[187:188]            ; 1a0377b3
	v_lshl_add_u32 v27, v27, 5, s30                             ; d646001b 00790b1b
	v_lshl_add_u32 v182, v182, 5, s30                           ; d64600b6 00790bb6
	v_lshl_add_u32 v190, v190, 5, s30                           ; d64600be 00790bbe
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[180:181], v[188:189]            ; 1a0379b4
	v_lshl_add_u32 v20, v20, 5, s30                             ; d6460014 00790b14
	v_lshl_add_u32 v28, v28, 5, s30                             ; d646001c 00790b1c
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[181:182], v[189:190]            ; 1a037bb5
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[13:14]                ; 1a021b46
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[182:183], v[190:191]            ; 1a037db6
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[18:19]                ; 1a022547
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[19:20]                ; 1a02274a
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[25:26]                ; 1a023346
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[20:21]                ; 1a02294b
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[26:27]                ; 1a023547
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[27:28]                ; 1a02374a
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[28:29]                ; 1a02394b
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[71:72]                ; 1a028f46
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[74:75]                ; 1a029546
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[75:76]                ; 1a029746
	v_permlanex16_b32 v76, v70, s19, s24 op_sel:[1,1]           ; d65c184c 00602746
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[76:77]                ; 1a029946
	v_add_f16_e32 v77, v70, v198/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 649b8d46
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v77, 0x400, v77                           ; 629a9aff 00000400
	v_cvt_f32_f16_e32 v78, v77                                  ; 7e9c174d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v78, v78                                      ; 7e9c554e
	v_fma_mix_f32 v83, v187, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200053 8a029dbb
	v_fma_mix_f32 v187, v187, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a029dbb
	v_fma_mix_f32 v80, v180, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200050 8a029db4
	v_fma_mix_f32 v180, v180, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a029db4
	v_fma_mix_f32 v84, v188, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200054 8a029dbc
	v_fma_mix_f32 v79, v179, v78, neg(0) op_sel_hi:[1,0,0]      ; cc20004f 8a029db3
	v_fma_mix_f32 v179, v179, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a029db3
	v_fma_mix_f32 v82, v182, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200052 8a029db6
	v_fma_mix_f32 v182, v182, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a029db6
	v_fma_mix_f32 v81, v181, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200051 8a029db5
	v_fma_mix_f32 v181, v181, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a029db5
	v_fma_mix_f32 v188, v188, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a029dbc
	v_fma_mix_f32 v85, v189, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200055 8a029dbd
	v_fma_mix_f32 v189, v189, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a029dbd
	v_fma_mix_f32 v86, v190, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200056 8a029dbe
	v_fma_mix_f32 v190, v190, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a029dbe
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v83, v187, vcc_lo                     ; 02037753
	v_fma_mix_f32 v87, v13, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200057 8a029d0d
	v_fma_mix_f32 v13, v13, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080d 8a029d0d
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[4:5], 0   ; cc464040 1a02090e
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v79, v179, vcc_lo                     ; 0203674f
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v80, v180, vcc_lo                     ; 02036950
	v_fma_mix_f32 v88, v18, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200058 8a029d12
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v81, v181, vcc_lo                     ; 02036b51
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v82, v182, vcc_lo                     ; 02036d52
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v84, v188, vcc_lo                     ; 02037954
	v_fma_mix_f32 v18, v18, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200812 8a029d12
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v85, v189, vcc_lo                     ; 02037b55
	v_fma_mix_f32 v89, v19, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200059 8a029d13
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v86, v190, vcc_lo                     ; 02037d56
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v87, v13, vcc_lo                      ; 02021b57
	v_fma_mix_f32 v19, v19, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200813 8a029d13
	v_fma_mix_f32 v90, v20, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005a 8a029d14
	v_fma_mix_f32 v20, v20, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a029d14
	v_fma_mix_f32 v91, v25, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005b 8a029d19
	v_fma_mix_f32 v25, v25, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a029d19
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[14:15], v[22:23], 0 ; cc464050 1a022d0e
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, 0              ; ca100080 0f0e0080
	v_fma_mix_f32 v92, v26, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005c 8a029d1a
	v_fma_mix_f32 v26, v26, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081a 8a029d1a
	v_fma_mix_f32 v93, v27, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005d 8a029d1b
	v_fma_mix_f32 v27, v27, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081b 8a029d1b
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v88, v18, vcc_lo                      ; 02022558
	v_fma_mix_f32 v94, v28, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005e 8a029d1c
	v_fma_mix_f32 v28, v28, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a029d1c
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v89, v19, vcc_lo                      ; 02022759
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v90, v20, vcc_lo                      ; 0202295a
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v91, v25, vcc_lo                      ; 0202335b
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[30:31], v[64:71] ; cc464040 1d023d0e
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v92, v26, vcc_lo                      ; 0202355c
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v93, v27, vcc_lo                      ; 0202375d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[14:15], v[34:35], v[80:87] ; cc464050 1d42450e
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v94, v28, vcc_lo                      ; 0202395e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[72:73], v[32:33], v[64:71] ; cc464040 1d024148
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[44:45], v[80:87] ; cc464050 1d425948
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[6:7], v[22:23], 0   ; cc464048 1a022d06
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v57, v129, v37 :: v_dual_mul_f32 v56, v128, v36 ; c8c64b81 39384980
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v61, v133, v41 :: v_dual_mul_f32 v60, v132, v40 ; c8c65385 3d3c5184
	v_dual_mul_f32 v63, v135, v43 :: v_dual_mul_f32 v62, v134, v42 ; c8c65787 3f3e5586
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[10:11], v[64:71] ; cc464040 1d02150e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[14:15], v[18:19], v[80:87] ; cc464050 1d42250e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[34:35], v[72:79] ; cc464048 1d22450e
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[6:7], v[4:5], 0     ; cc464040 1a020906
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[58:59], v[44:45], v[72:79] ; cc464048 1d22593a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[30:31], v[64:71] ; cc464040 1d023d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[18:19], v[72:79] ; cc464048 1d22250e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[58:59], v[32:33], v[64:71] ; cc464040 1d02413a
	v_dual_mul_f32 v59, v131, v39 :: v_dual_mul_f32 v58, v130, v38 ; c8c64f83 3b3a4d82
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[8:9], v[20:21], v[56:63] ; cc464038 1ce22908
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[10:11], v[64:71] ; cc464040 1d02150e
	s_cmp_lg_i32 s27, 0                                         ; bf01801b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_dual_mul_f32 v65, v145, v37 :: v_dual_mul_f32 v64, v144, v36 ; c8c64b91 41404990
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v67, v147, v39 :: v_dual_mul_f32 v66, v146, v38 ; c8c64f93 43424d92
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_dual_mul_f32 v69, v149, v41 :: v_dual_mul_f32 v68, v148, v40 ; c8c65395 45445194
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_dual_mul_f32 v71, v151, v43 :: v_dual_mul_f32 v70, v150, v42 ; c8c65797 47465596
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[24:25], v[64:71] ; cc464040 1d023108
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[16:17], v[4:5], v[56:63] ; cc464038 1ce20910
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[16:17], v[6:7], v[64:71] ; cc464040 1d020d10
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_cbranch_scc1 BB65                                         ; bfa20007
BB63:
	v_add3_u32 v2, v3, s2, s14                                  ; d6550002 00380503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[8:9], v2, s[20:23], null offen           ; c406c07c 40802808 00000002
BB65:
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_lg_i32 s35, 0                                         ; bf018023
	s_cbranch_scc1 BB68                                         ; bfa20007
BB66:
	v_add3_u32 v2, v3, s2, s29                                  ; d6550002 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[8:9], v2, s[20:23], null offen           ; c406c07c 40802808 00000002
BB68:
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v0, s[36:39], null offen offset:64 ; c405c07c 40804808 00004000
	buffer_load_b128 v[16:19], v0, s[36:39], null offen offset:80 ; c405c07c 40804810 00005000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[14:15], v12, s[44:47], null offen offset:8 ; c405407c 4080580e 0000080c
	buffer_load_b64 v[12:13], v12, s[44:47], null offen offset:520 ; c405407c 4080580c 0002080c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v33, v153, v9 :: v_dual_mul_f32 v32, v152, v8 ; c8c61399 21201198
	v_dual_mul_f32 v35, v155, v11 :: v_dual_mul_f32 v34, v154, v10 ; c8c6179b 2322159a
	v_dual_mul_f32 v41, v49, v9 :: v_dual_mul_f32 v40, v48, v8  ; c8c61331 29281130
	v_dual_mul_f32 v43, v51, v11 :: v_dual_mul_f32 v42, v50, v10 ; c8c61733 2b2a1532
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v37, v157, v17 :: v_dual_mul_f32 v36, v156, v16 ; c8c6239d 2524219c
	v_dual_mul_f32 v39, v159, v19 :: v_dual_mul_f32 v38, v158, v18 ; c8c6279f 2726259e
	v_dual_mul_f32 v45, v53, v17 :: v_dual_mul_f32 v44, v52, v16 ; c8c62335 2d2c2134
	v_dual_mul_f32 v47, v55, v19 :: v_dual_mul_f32 v46, v54, v18 ; c8c62737 2f2e2536
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[14:15], v[20:21], v[32:39] ; cc464020 1c82290e
	s_mov_b32 s0, vcc_lo                                        ; be80006a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[14:15], v[24:25], v[40:47] ; cc464028 1ca2310e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[12:13], v[4:5], v[32:39] ; cc464020 1c82090c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[6:7], v[40:47] ; cc464028 1ca20d0c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_cbranch_scc1 BB71                                         ; bfa20009
BB69:
	s_add_co_u32 s1, s2, 0x100                                  ; 8001ff02 00000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	v_add3_u32 v0, v3, s1, s14                                  ; d6550000 00380303
	v_add_nc_u32_e32 v0, v0, v1                                 ; 4a000300
	buffer_store_b64 v[4:5], v0, s[20:23], null offen           ; c406c07c 40802804 00000000
BB71:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB78                                         ; bfa20009
BB72:
	s_addk_co_i32 s2, 0x100                                     ; b7820100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v3, v3, s2, s29                                  ; d6550003 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	buffer_store_b64 v[4:5], v3, s[20:23], null offen           ; c406c07c 40802804 00000003
BB78:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
