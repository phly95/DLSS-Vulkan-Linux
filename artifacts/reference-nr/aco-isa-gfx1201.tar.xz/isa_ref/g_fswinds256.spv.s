BB0:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s10, s1                                           ; be8a0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_pack_ll_b32_b16 s21, ttmp7, 0                             ; 99158073
	s_clause 0x4                                                ; bf850004
	s_load_b128 s[12:15], s[0:1], 0x0                           ; f4004300 f8000000
	s_load_b128 s[16:19], s[10:11], 0x30                        ; f4004405 f8000030
	s_load_b32 s20, s[10:11], 0x40                              ; f4000505 f8000040
	s_load_b64 s[22:23], s[10:11], 0x20                         ; f4002585 f8000020
	s_load_b256 s[32:39], s[0:1], 0x30                          ; f4006800 f8000030
(invalid instruction)                                        ; d71f0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_lshrrev_b32_e32 v1, 5, v0                                 ; 32020085
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_and_b32_e32 v4, 15, v3                                    ; 3608068f
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_lshlrev_b32_e32 v2, 9, v1                                 ; 30040289
	v_lshlrev_b32_e32 v5, 4, v4                                 ; 300a0884
	v_lshlrev_b32_e32 v6, 3, v3                                 ; 300c0683
	v_add_nc_u32_e32 v8, 0x100, v2                              ; 4a1004ff 00000100
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl1_add_u32 s24, ttmp9, s19                             ; 87181375
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_max_i32 s25, s24, 0                                       ; 8a198018
	s_add_co_u32 s26, s17, -1                                   ; 801ac111
	s_min_i32 s25, s25, s26                                     ; 89191a19
	s_add_co_u32 s27, s18, -1                                   ; 801bc112
	s_lshl1_add_u32 s21, s21, s20                               ; 87151415
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_max_i32 s28, s21, 0                                       ; 8a1c8015
	s_min_i32 s28, s28, s27                                     ; 891c1b1c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s28, s28, s17                                     ; 961c111c
	s_add_co_u32 s29, s28, s25                                  ; 801d191c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s29, s29, 12                                     ; 841d8c1d
	s_add_co_u32 s30, s2, s29                                   ; 801e1d02
	s_add_co_u32 s31, s24, 1                                    ; 801f8118
	v_add3_u32 v7, v5, s30, v2                                  ; d6550007 04083d05
	v_add3_u32 v9, v5, s30, v8                                  ; d6550009 04203d05
	s_max_i32 s40, s31, 0                                       ; 8a28801f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_min_i32 s40, s40, s26                                     ; 89281a28
	v_add_nc_u32_e32 v7, v7, v6                                 ; 4a0e0d07
	v_add_nc_u32_e32 v9, v9, v6                                 ; 4a120d09
	s_add_co_u32 s28, s28, s40                                  ; 801c281c
	s_lshl_b32 s28, s28, 12                                     ; 841c8c1c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s41, s2, s28                                   ; 80291c02
	s_add_co_u32 s42, s21, 1                                    ; 802a8115
	v_add3_u32 v11, v5, s41, v8                                 ; d655000b 04205305
	v_add3_u32 v10, v5, s41, v2                                 ; d655000a 04085305
	s_max_i32 s43, s42, 0                                       ; 8a2b802a
	s_min_i32 s43, s43, s27                                     ; 892b1b2b
	v_add_nc_u32_e32 v11, v11, v6                               ; 4a160d0b
	v_add_nc_u32_e32 v10, v10, v6                               ; 4a140d0a
	s_mul_i32 s43, s43, s17                                     ; 962b112b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s25, s43, s25                                  ; 8019192b
	s_lshl_b32 s25, s25, 12                                     ; 84198c19
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s44, s2, s25                                   ; 802c1902
	s_add_co_u32 s43, s43, s40                                  ; 802b282b
	v_add3_u32 v13, v5, s44, v8                                 ; d655000d 04205905
	v_add3_u32 v12, v5, s44, v2                                 ; d655000c 04085905
	s_lshl_b32 s43, s43, 12                                     ; 842b8c2b
	s_add_co_u32 s2, s2, s43                                    ; 80022b02
	v_add_nc_u32_e32 v13, v13, v6                               ; 4a1a0d0d
	v_add_nc_u32_e32 v12, v12, v6                               ; 4a180d0c
	v_add3_u32 v14, v5, s2, v2                                  ; d655000e 04080505
	v_add3_u32 v15, v5, s2, v8                                  ; d655000f 04200505
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v6                               ; 4a1c0d0e
	v_add_nc_u32_e32 v15, v15, v6                               ; 4a1e0d0f
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[16:17], v7, s[12:15], null offen          ; c405407c 40801810 00000007
	buffer_load_b64 v[18:19], v9, s[12:15], null offen          ; c405407c 40801812 00000009
	buffer_load_b64 v[20:21], v10, s[12:15], null offen         ; c405407c 40801814 0000000a
	buffer_load_b64 v[10:11], v11, s[12:15], null offen         ; c405407c 4080180a 0000000b
	buffer_load_b64 v[22:23], v12, s[12:15], null offen         ; c405407c 40801816 0000000c
	buffer_load_b64 v[12:13], v13, s[12:15], null offen         ; c405407c 4080180c 0000000d
	buffer_load_b64 v[24:25], v14, s[12:15], null offen         ; c405407c 40801818 0000000e
	buffer_load_b64 v[14:15], v15, s[12:15], null offen         ; c405407c 4080180e 0000000f
	v_lshlrev_b32_e32 v26, 3, v1                                ; 30340283
	v_and_b32_e32 v29, 31, v0                                   ; 363a009f
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_sub_nc_u32_e32 v27, 0, v26                                ; 4c363480
	v_med3_i32 v28, -1, v26, 1                                  ; d620001c 020634c1
	v_add_nc_u32_e32 v31, 2, v26                                ; 4a3e3482
	v_lshlrev_b32_e32 v30, 2, v29                               ; 303c3a82
	v_max_i32_e32 v27, v26, v27                                 ; 2436371a
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_sub_nc_u32_e32 v32, 0, v31                                ; 4c403e80
	v_lshrrev_b32_e32 v27, 1, v27                               ; 32363681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_max_i32_e32 v32, v31, v32                                 ; 2440411f
	v_med3_i32 v31, -1, v31, 1                                  ; d620001f 02063ec1
(invalid instruction)                                        ; d72c001c
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                      ; 0202371c
	v_lshrrev_b32_e32 v32, 1, v32                               ; 32404081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d72c001f
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                      ; 0202411f
	v_lshl_add_u32 v28, v28, 11, s4                             ; d646001c 0011171c
	v_add_lshl_u32 v28, v28, v30, 2                             ; d647001c 020a3d1c
	v_lshl_add_u32 v31, v31, 11, s4                             ; d646001f 0011171f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v31, v31, v30, 2                             ; d647001f 020a3d1f
	s_clause 0x9                                                ; bf850009
	buffer_load_b128 v[32:35], v28, s[36:39], null offen        ; c405c07c 40804820 0000001c
	buffer_load_b128 v[36:39], v31, s[36:39], null offen        ; c405c07c 40804824 0000001f
	buffer_load_b128 v[40:43], v28, s[36:39], null offen offset:512 ; c405c07c 40804828 0002001c
	buffer_load_b128 v[44:47], v31, s[36:39], null offen offset:512 ; c405c07c 4080482c 0002001f
	buffer_load_b128 v[48:51], v28, s[36:39], null offen offset:1024 ; c405c07c 40804830 0004001c
	buffer_load_b128 v[52:55], v31, s[36:39], null offen offset:1024 ; c405c07c 40804834 0004001f
	buffer_load_b128 v[56:59], v28, s[36:39], null offen offset:1536 ; c405c07c 40804838 0006001c
	buffer_load_b128 v[60:63], v31, s[36:39], null offen offset:1536 ; c405c07c 4080483c 0006001f
	buffer_load_b128 v[64:67], v28, s[36:39], null offen offset:2048 ; c405c07c 40804840 0008001c
	buffer_load_b128 v[68:71], v31, s[36:39], null offen offset:2048 ; c405c07c 40804844 0008001f
	v_add_nc_u32_e32 v72, v5, v6                                ; 4a900d05
	s_min_i32 s45, s24, s21                                     ; 892d1518
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s45, 0                                         ; bf04802d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b1
	v_add_nc_u32_e32 v73, v2, v72                               ; 4a929102
	s_cselect_b32 s46, -1, 0                                    ; 982e80c1
	s_cmp_ge_i32 s24, s17                                       ; bf031118
	s_cselect_b32 s47, -1, 0                                    ; 982f80c1
	v_add_nc_u32_e32 v75, 0x2000, v73                           ; 4a9692ff 00002000
	v_add_nc_u32_e32 v76, 0x3000, v73                           ; 4a9892ff 00003000
	v_add_nc_u32_e32 v74, 0x1000, v73                           ; 4a9492ff 00001000
	s_or_b32 s46, s46, s47                                      ; 8c2e2f2e
	s_cmp_ge_i32 s21, s18                                       ; bf031215
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_mov_b32 s49, src_scc                                      ; beb100fd
	s_cselect_b32 s48, -1, 0                                    ; 983080c1
	s_nor_b32 vcc_lo, s46, s48                                  ; 8f6a302e
	s_min_i32 s50, s31, s21                                     ; 8932151f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s50, 0                                         ; bf048032
	s_cselect_b32 s51, -1, 0                                    ; 983380c1
	s_cmp_ge_i32 s31, s17                                       ; bf03111f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s52, -1, 0                                    ; 983480c1
	s_or_b32 s51, s51, s52                                      ; 8c333433
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_nor_b32 s51, s51, s48                                     ; 8f333033
	s_min_i32 s53, s24, s42                                     ; 89352a18
	s_pack_hh_b32_b16 s59, ttmp7, 0                             ; 9a3b8073
	s_movk_i32 s60, 0x400                                       ; b03c0400
	s_cmp_lt_i32 s53, 0                                         ; bf048035
	v_lshl_add_u32 v77, s59, 4, v72                             ; d646004d 0521083b
	s_cselect_b32 s54, -1, 0                                    ; 983680c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_or_b32 s54, s54, s47                                      ; 8c362f36
	s_cmp_ge_i32 s42, s18                                       ; bf03122a
	s_cselect_b32 s55, -1, 0                                    ; 983780c1
	s_mov_b32 s56, src_scc                                      ; beb800fd
	s_nor_b32 s54, s54, s55                                     ; 8f363736
	s_min_i32 s57, s31, s42                                     ; 89392a1f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s57, 0                                         ; bf048039
	s_cselect_b32 s58, -1, 0                                    ; 983a80c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s58, s58, s52                                      ; 8c3a343a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_nor_b32 s58, s58, s55                                     ; 8f3a373a
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_dual_cndmask_b32 v78, 0, v16 :: v_dual_cndmask_b32 v79, 0, v17 ; ca522080 4e4e2280
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_cndmask_b32 v16, 0, v18 :: v_dual_cndmask_b32 v17, 0, v19 ; ca522480 10102680
	ds_store_2addr_b64 v73, v[78:79], v[16:17] offset1:32       ; d9382000 00104e49
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_cndmask_b32_e64 v17, 0, v21, s51                          ; d5010011 00ce2a80
	v_cndmask_b32_e64 v16, 0, v20, s51                          ; d5010010 00ce2880
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_cndmask_b32_e64 v19, 0, v11, s51                          ; d5010013 00ce1680
	v_cndmask_b32_e64 v18, 0, v10, s51                          ; d5010012 00ce1480
	ds_store_2addr_b64 v74, v[16:17], v[18:19] offset1:32       ; d9382000 0012104a
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_cndmask_b32_e64 v10, 0, v22, s54                          ; d501000a 00da2c80
	v_cndmask_b32_e64 v11, 0, v23, s54                          ; d501000b 00da2e80
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_cndmask_b32_e64 v17, 0, v13, s54                          ; d5010011 00da1a80
	v_cndmask_b32_e64 v16, 0, v12, s54                          ; d5010010 00da1880
	ds_store_2addr_b64 v75, v[10:11], v[16:17] offset1:32       ; d9382000 00100a4b
	s_wait_loadcnt 0xb                                          ; bfc0000b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v10, 0, v24, s58                          ; d501000a 00ea3080
	v_cndmask_b32_e64 v11, 0, v25, s58                          ; d501000b 00ea3280
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cndmask_b32_e64 v12, 0, v14, s58                          ; d501000c 00ea1c80
	v_cndmask_b32_e64 v13, 0, v15, s58                          ; d501000d 00ea1e80
	ds_store_2addr_b64 v76, v[10:11], v[12:13] offset1:32       ; d9382000 000c0a4c
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[10:11], v77                                   ; d9d80000 0a00004d
	ds_load_b64 v[12:13], v77 offset:4096                       ; d9d81000 0c00004d
	ds_load_b64 v[14:15], v77 offset:8192                       ; d9d82000 0e00004d
	ds_load_b64 v[16:17], v77 offset:12288                      ; d9d83000 1000004d
	ds_load_b64 v[18:19], v77 offset:256                        ; d9d80100 1200004d
	ds_load_b64 v[20:21], v77 offset:4352                       ; d9d81100 1400004d
	ds_load_b64 v[22:23], v77 offset:8448                       ; d9d82100 1600004d
	ds_load_b64 v[24:25], v77 offset:12544                      ; d9d83100 1800004d
	ds_load_b64 v[78:79], v77 offset:512                        ; d9d80200 4e00004d
	ds_load_b64 v[80:81], v77 offset:4608                       ; d9d81200 5000004d
	v_mov_b32_e32 v82, v8                                       ; 7ea40308
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[34:35], v[14:15], 0 ; cc4640a0 1a021d22
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[12:13], 0 ; cc464078 1a021920
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[10:11], 0 ; cc464060 1a021522
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[14:15], 0 ; cc464098 1a021d20
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[12:13], 0 ; cc464080 1a021922
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[32:33], v[16:17], 0 ; cc4640b8 1a022120
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[10:11], 0 ; cc464058 1a021520
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[12:13], 0 ; cc464090 1a021926
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[36:37], v[14:15], 0 ; cc4640a8 1a021d24
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[36:37], v[12:13], 0 ; cc464088 1a021924
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[10:11], 0 ; cc464070 1a021526
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[10:11], 0 ; cc464068 1a021524
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[14:15], 0 ; cc4640b0 1a021d26
	v_mov_b32_e32 v15, v82                                      ; 7e1e0352
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[34:35], v[16:17], 0  ; cc464007 1a022122
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v33, v81 :: v_dual_mov_b32 v32, v80          ; ca100151 21200150
	v_dual_mov_b32 v35, v17 :: v_dual_mov_b32 v34, v16          ; ca100111 23220110
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[16:17], 0 ; cc464050 1a022124
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[18:19], v[96:103] ; cc464060 1d82252a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[20:21], v[120:127] ; cc464078 1de22928
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[20:21], v[128:135] ; cc464080 1e02292a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[18:19], v[88:95] ; cc464058 1d622528
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[20:21], v[144:151] ; cc464090 1e42292e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[22:23], v[152:159] ; cc464098 1e622d28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[44:45], v[20:21], v[136:143] ; cc464088 1e22292c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[42:43], v[22:23], v[160:167] ; cc4640a0 1e822d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[18:19], v[112:119] ; cc464070 1dc2252e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[22:23], v[168:175] ; cc4640a8 1ea22d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[18:19], v[104:111] ; cc464068 1da2252c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[22:23], v[176:183] ; cc4640b0 1ec22d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[38:39], v[34:35], 0 ; cc464010 1a024526
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[78:79], v[96:103] ; cc464060 1d829d32
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[32:33], v[120:127] ; cc464078 1de24130
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[32:33], v[128:135] ; cc464080 1e024132
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[32:33], v[144:151] ; cc464090 1e424136
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[78:79], v[88:95] ; cc464058 1d629d30
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[32:33], v[136:143] ; cc464088 1e224134
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[40:41], v[24:25], v[184:191] ; cc4640b8 1ee23128
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[42:43], v[24:25], v[7:14] ; cc464007 1c1e312a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[24:25], v[80:87] ; cc464050 1d42312c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[24:25], v[16:23] ; cc464010 1c42312e
	ds_load_b64 v[34:35], v77 offset:8704                       ; d9d82200 2200004d
	ds_load_b64 v[36:37], v77 offset:12800                      ; d9d83200 2400004d
	ds_load_b64 v[38:39], v77 offset:768                        ; d9d80300 2600004d
	ds_load_b64 v[32:33], v77 offset:4864                       ; d9d81300 2000004d
	ds_load_b64 v[40:41], v77 offset:8960                       ; d9d82300 2800004d
	ds_load_b64 v[42:43], v77 offset:13056                      ; d9d83300 2a00004d
	ds_load_b64 v[44:45], v77 offset:1024                       ; d9d80400 2c00004d
	ds_load_b64 v[24:25], v77 offset:5120                       ; d9d81400 1800004d
	ds_load_b64 v[46:47], v77 offset:9216                       ; d9d82400 2e00004d
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[78:79], v[104:111] ; cc464068 1da29d34
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[34:35], v[168:175] ; cc4640a8 1ea24534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[34:35], v[176:183] ; cc4640b0 1ec24536
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[34:35], v[152:159] ; cc464098 1e624530
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[34:35], v[160:167] ; cc4640a0 1e824532
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[50:51], v[36:37], v[7:14] ; cc464007 1c1e4932
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[52:53], v[36:37], v[80:87] ; cc464050 1d424934
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[48:49], v[36:37], v[184:191] ; cc4640b8 1ee24930
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[36:37], v[16:23] ; cc464010 1c424936
	ds_load_b64 v[34:35], v77 offset:13312                      ; d9d83400 2200004d
	ds_load_b64 v[48:49], v77 offset:1280                       ; d9d80500 3000004d
	ds_load_b64 v[50:51], v77 offset:5376                       ; d9d81500 3200004d
	ds_load_b64 v[52:53], v77 offset:9472                       ; d9d82500 3400004d
	ds_load_b64 v[36:37], v77 offset:13568                      ; d9d83500 2400004d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[78:79], v[112:119] ; cc464070 1dc29d36
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[38:39], v[88:95] ; cc464058 1d624d38
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[38:39], v[96:103] ; cc464060 1d824d3a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[32:33], v[120:127] ; cc464078 1de24138
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[32:33], v[128:135] ; cc464080 1e02413a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[40:41], v[152:159] ; cc464098 1e625138
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[40:41], v[160:167] ; cc4640a0 1e82513a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[58:59], v[42:43], v[7:14] ; cc464007 1c1e553a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[38:39], v[104:111] ; cc464068 1da24d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[32:33], v[136:143] ; cc464088 1e22413c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[40:41], v[168:175] ; cc4640a8 1ea2513c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[42:43], v[80:87] ; cc464050 1d42553c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[42:43], v[184:191] ; cc4640b8 1ee25538
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[32:33], v[144:151] ; cc464090 1e42413e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[40:41], v[176:183] ; cc4640b0 1ec2513e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[38:39], v[112:119] ; cc464070 1dc24d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[62:63], v[42:43], v[16:23] ; cc464010 1c42553e
	ds_load_b64 v[38:39], v77 offset:1536                       ; d9d80600 2600004d
	ds_load_b64 v[32:33], v77 offset:5632                       ; d9d81600 2000004d
	ds_load_b64 v[40:41], v77 offset:9728                       ; d9d82600 2800004d
	ds_load_b64 v[42:43], v77 offset:13824                      ; d9d83600 2a00004d
	s_wait_loadcnt_dscnt 0x10b                                  ; bfc8010b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[44:45], v[88:95] ; cc464058 1d625940
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[24:25], v[120:127] ; cc464078 1de23140
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[46:47], v[152:159] ; cc464098 1e625d40
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[44:45], v[96:103] ; cc464060 1d825942
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[24:25], v[128:135] ; cc464080 1e023142
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[46:47], v[160:167] ; cc4640a0 1e825d42
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[66:67], v[34:35], v[7:14] ; cc464007 1c1e4542
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[44:45], v[104:111] ; cc464068 1da25944
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[34:35], v[184:191] ; cc4640b8 1ee24540
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[24:25], v[136:143] ; cc464088 1e223144
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[46:47], v[168:175] ; cc4640a8 1ea25d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[34:35], v[80:87] ; cc464050 1d424544
	v_dual_mov_b32 v54, v71 :: v_dual_mov_b32 v27, v70          ; ca100147 361a0146
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[56:59], v28, s[36:39], null offen offset:2560 ; c405c07c 40804838 000a001c
	buffer_load_b128 v[60:63], v31, s[36:39], null offen offset:2560 ; c405c07c 4080483c 000a001f
	buffer_load_b128 v[64:67], v28, s[36:39], null offen offset:3072 ; c405c07c 40804840 000c001c
	buffer_load_b128 v[68:71], v31, s[36:39], null offen offset:3072 ; c405c07c 40804844 000c001f
	v_swap_b32 v28, v54                                         ; 7e38cb36
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[27:28], v[24:25], v[144:151] ; cc464090 1e42311b
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[27:28], v[46:47], v[176:183] ; cc4640b0 1ec25d1b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[27:28], v[44:45], v[112:119] ; cc464070 1dc2591b
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[27:28], v[34:35], v[16:23] ; cc464010 1c42451b
	ds_load_b64 v[44:45], v77 offset:1792                       ; d9d80700 2c00004d
	ds_load_b64 v[24:25], v77 offset:5888                       ; d9d81700 1800004d
	ds_load_b64 v[46:47], v77 offset:9984                       ; d9d82700 2e00004d
	ds_load_b64 v[34:35], v77 offset:14080                      ; d9d83700 2200004d
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[50:51], v[120:127] ; cc464078 1de26538
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[50:51], v[128:135] ; cc464080 1e02653a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[52:53], v[152:159] ; cc464098 1e626938
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[36:37], v[184:191] ; cc4640b8 1ee24938
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[48:49], v[88:95] ; cc464058 1d626138
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[52:53], v[160:167] ; cc4640a0 1e82693a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[48:49], v[96:103] ; cc464060 1d82613a
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[58:59], v[36:37], v[7:14] ; cc464007 1c1e493a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_mov_b32_e32 v27, v63                                      ; 7e36033f
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[48:49], v[104:111] ; cc464068 1da2613c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[50:51], v[136:143] ; cc464088 1e22653c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[52:53], v[168:175] ; cc4640a8 1ea2693c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[36:37], v[80:87] ; cc464050 1d42493c
	v_mov_b32_e32 v55, v62                                      ; 7e6e033e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v54, s[36:39], null offen offset:3584 ; c405c07c 40804838 000e0036
	buffer_load_b128 v[60:63], v31, s[36:39], null offen offset:3584 ; c405c07c 4080483c 000e001f
	v_swap_b32 v26, v55                                         ; 7e34cb37
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[48:49], v[112:119] ; cc464070 1dc2611a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[26:27], v[50:51], v[144:151] ; cc464090 1e42651a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[26:27], v[52:53], v[176:183] ; cc4640b0 1ec2691a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[26:27], v[36:37], v[16:23] ; cc464010 1c42491a
	ds_load_b64 v[48:49], v77 offset:2048                       ; d9d80800 3000004d
	ds_load_b64 v[50:51], v77 offset:6144                       ; d9d81800 3200004d
	ds_load_b64 v[52:53], v77 offset:10240                      ; d9d82800 3400004d
	ds_load_b64 v[26:27], v77 offset:14336                      ; d9d83800 1a00004d
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[38:39], v[88:95] ; cc464058 1d624d40
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[32:33], v[120:127] ; cc464078 1de24140
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[40:41], v[152:159] ; cc464098 1e625140
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[42:43], v[184:191] ; cc4640b8 1ee25540
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[38:39], v[96:103] ; cc464060 1d824d42
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[32:33], v[128:135] ; cc464080 1e024142
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[40:41], v[160:167] ; cc4640a0 1e825142
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[66:67], v[42:43], v[7:14] ; cc464007 1c1e5542
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[38:39], v[104:111] ; cc464068 1da24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[32:33], v[136:143] ; cc464088 1e224144
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[40:41], v[168:175] ; cc4640a8 1ea25144
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[42:43], v[80:87] ; cc464050 1d425544
	v_mov_b32_e32 v28, v70                                      ; 7e380346
	v_mov_b32_e32 v36, v71                                      ; 7e480347
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[64:67], v54, s[36:39], null offen offset:4096 ; c405c07c 40804840 00100036
	buffer_load_b128 v[68:71], v31, s[36:39], null offen offset:4096 ; c405c07c 40804844 0010001f
	v_swap_b32 v29, v36                                         ; 7e3acb24
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[28:29], v[42:43], v[16:23] ; cc464010 1c42551c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[38:39], v[112:119] ; cc464070 1dc24d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[28:29], v[32:33], v[144:151] ; cc464090 1e42411c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[28:29], v[40:41], v[176:183] ; cc4640b0 1ec2511c
	ds_load_b64 v[38:39], v77 offset:2304                       ; d9d80900 2600004d
	ds_load_b64 v[32:33], v77 offset:6400                       ; d9d81900 2000004d
	ds_load_b64 v[40:41], v77 offset:10496                      ; d9d82900 2800004d
	ds_load_b64 v[28:29], v77 offset:14592                      ; d9d83900 1c00004d
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[46:47], v[160:167] ; cc4640a0 1e825d3a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[58:59], v[34:35], v[7:14] ; cc464007 1c1e453a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[24:25], v[128:135] ; cc464080 1e02313a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[44:45], v[88:95] ; cc464058 1d625938
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[34:35], v[184:191] ; cc4640b8 1ee24538
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[24:25], v[120:127] ; cc464078 1de23138
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[44:45], v[96:103] ; cc464060 1d82593a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[46:47], v[152:159] ; cc464098 1e625d38
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[44:45], v[104:111] ; cc464068 1da2593c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[24:25], v[136:143] ; cc464088 1e22313c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[46:47], v[168:175] ; cc4640a8 1ea25d3c
	v_dual_mov_b32 v42, v63 :: v_dual_mov_b32 v37, v62          ; ca10013f 2a24013e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[34:35], v[80:87] ; cc464050 1d42453c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v54, s[36:39], null offen offset:4608 ; c405c07c 40804838 00120036
	buffer_load_b128 v[60:63], v31, s[36:39], null offen offset:4608 ; c405c07c 4080483c 0012001f
	v_dual_mov_b32 v43, v42 :: v_dual_mov_b32 v42, v37          ; ca10012a 2b2a0125
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[44:45], v[112:119] ; cc464070 1dc2592a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[24:25], v[144:151] ; cc464090 1e42312a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[46:47], v[176:183] ; cc4640b0 1ec25d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[42:43], v[34:35], v[16:23] ; cc464010 1c42452a
	ds_load_b64 v[44:45], v77 offset:2560                       ; d9d80a00 2c00004d
	ds_load_b64 v[24:25], v77 offset:6656                       ; d9d81a00 1800004d
	ds_load_b64 v[46:47], v77 offset:10752                      ; d9d82a00 2e00004d
	ds_load_b64 v[34:35], v77 offset:14848                      ; d9d83a00 2200004d
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[48:49], v[88:95] ; cc464058 1d626140
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[50:51], v[120:127] ; cc464078 1de26540
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[52:53], v[160:167] ; cc4640a0 1e826942
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[66:67], v[26:27], v[7:14] ; cc464007 1c1e3542
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[50:51], v[128:135] ; cc464080 1e026542
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[52:53], v[152:159] ; cc464098 1e626940
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[26:27], v[184:191] ; cc4640b8 1ee23540
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[48:49], v[96:103] ; cc464060 1d826142
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[48:49], v[104:111] ; cc464068 1da26144
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[50:51], v[136:143] ; cc464088 1e226544
	v_mov_b32_e32 v37, v71                                      ; 7e4a0347
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[52:53], v[168:175] ; cc4640a8 1ea26944
	v_mov_b32_e32 v43, v70                                      ; 7e560346
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[26:27], v[80:87] ; cc464050 1d423544
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[64:67], v54, s[36:39], null offen offset:5120 ; c405c07c 40804840 00140036
	buffer_load_b128 v[68:71], v31, s[36:39], null offen offset:5120 ; c405c07c 40804844 0014001f
	v_swap_b32 v36, v43                                         ; 7e48cb2b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[48:49], v[112:119] ; cc464070 1dc26124
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[50:51], v[144:151] ; cc464090 1e426524
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[36:37], v[52:53], v[176:183] ; cc4640b0 1ec26924
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[36:37], v[26:27], v[16:23] ; cc464010 1c423524
	ds_load_b64 v[48:49], v77 offset:2816                       ; d9d80b00 3000004d
	ds_load_b64 v[50:51], v77 offset:6912                       ; d9d81b00 3200004d
	ds_load_b64 v[52:53], v77 offset:11008                      ; d9d82b00 3400004d
	ds_load_b64 v[26:27], v77 offset:15104                      ; d9d83b00 1a00004d
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[58:59], v[28:29], v[7:14] ; cc464007 1c1e393a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[32:33], v[128:135] ; cc464080 1e02413a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[38:39], v[88:95] ; cc464058 1d624d38
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[32:33], v[120:127] ; cc464078 1de24138
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[40:41], v[152:159] ; cc464098 1e625138
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[28:29], v[184:191] ; cc4640b8 1ee23938
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[38:39], v[96:103] ; cc464060 1d824d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[40:41], v[160:167] ; cc4640a0 1e82513a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[38:39], v[104:111] ; cc464068 1da24d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[32:33], v[136:143] ; cc464088 1e22413c
	v_mov_b32_e32 v36, v63                                      ; 7e48033f
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[40:41], v[168:175] ; cc4640a8 1ea2513c
	v_mov_b32_e32 v42, v62                                      ; 7e54033e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[28:29], v[80:87] ; cc464050 1d42393c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v54, s[36:39], null offen offset:5632 ; c405c07c 40804838 00160036
	buffer_load_b128 v[60:63], v31, s[36:39], null offen offset:5632 ; c405c07c 4080483c 0016001f
	v_swap_b32 v36, v43                                         ; 7e48cb2b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[38:39], v[112:119] ; cc464070 1dc24d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[32:33], v[144:151] ; cc464090 1e42412a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[40:41], v[176:183] ; cc4640b0 1ec2512a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[42:43], v[28:29], v[16:23] ; cc464010 1c42392a
	ds_load_b64 v[38:39], v77 offset:3072                       ; d9d80c00 2600004d
	ds_load_b64 v[32:33], v77 offset:7168                       ; d9d81c00 2000004d
	ds_load_b64 v[40:41], v77 offset:11264                      ; d9d82c00 2800004d
	ds_load_b64 v[28:29], v77 offset:15360                      ; d9d83c00 1c00004d
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[46:47], v[160:167] ; cc4640a0 1e825d42
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[66:67], v[34:35], v[7:14] ; cc464007 1c1e4542
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[24:25], v[128:135] ; cc464080 1e023142
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[44:45], v[88:95] ; cc464058 1d625940
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[24:25], v[120:127] ; cc464078 1de23140
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[46:47], v[152:159] ; cc464098 1e625d40
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[34:35], v[184:191] ; cc4640b8 1ee24540
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[44:45], v[96:103] ; cc464060 1d825942
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[44:45], v[104:111] ; cc464068 1da25944
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[24:25], v[136:143] ; cc464088 1e223144
	v_dual_mov_b32 v42, v71 :: v_dual_mov_b32 v37, v70          ; ca100147 2a240146
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[46:47], v[168:175] ; cc4640a8 1ea25d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[34:35], v[80:87] ; cc464050 1d424544
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[64:67], v54, s[36:39], null offen offset:6144 ; c405c07c 40804840 00180036
	buffer_load_b128 v[68:71], v31, s[36:39], null offen offset:6144 ; c405c07c 40804844 0018001f
	v_dual_mov_b32 v43, v42 :: v_dual_mov_b32 v42, v37          ; ca10012a 2b2a0125
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[44:45], v[112:119] ; cc464070 1dc2592a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[24:25], v[144:151] ; cc464090 1e42312a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[46:47], v[176:183] ; cc4640b0 1ec25d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[42:43], v[34:35], v[16:23] ; cc464010 1c42452a
	ds_load_b64 v[44:45], v77 offset:3328                       ; d9d80d00 2c00004d
	ds_load_b64 v[24:25], v77 offset:7424                       ; d9d81d00 1800004d
	ds_load_b64 v[46:47], v77 offset:11520                      ; d9d82d00 2e00004d
	ds_load_b64 v[34:35], v77 offset:15616                      ; d9d83d00 2200004d
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[48:49], v[88:95] ; cc464058 1d626138
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[58:59], v[26:27], v[7:14] ; cc464007 1c1e353a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[50:51], v[128:135] ; cc464080 1e02653a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[50:51], v[120:127] ; cc464078 1de26538
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[52:53], v[152:159] ; cc464098 1e626938
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[26:27], v[184:191] ; cc4640b8 1ee23538
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[52:53], v[160:167] ; cc4640a0 1e82693a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[48:49], v[96:103] ; cc464060 1d82613a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[48:49], v[104:111] ; cc464068 1da2613c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[50:51], v[136:143] ; cc464088 1e22653c
	v_mov_b32_e32 v37, v63                                      ; 7e4a033f
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[52:53], v[168:175] ; cc4640a8 1ea2693c
	v_mov_b32_e32 v43, v62                                      ; 7e56033e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[26:27], v[80:87] ; cc464050 1d42353c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v54, s[36:39], null offen offset:6656 ; c405c07c 40804838 001a0036
	buffer_load_b128 v[60:63], v31, s[36:39], null offen offset:6656 ; c405c07c 4080483c 001a001f
	v_swap_b32 v36, v43                                         ; 7e48cb2b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[48:49], v[112:119] ; cc464070 1dc26124
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[50:51], v[144:151] ; cc464090 1e426524
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[36:37], v[52:53], v[176:183] ; cc4640b0 1ec26924
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[36:37], v[26:27], v[16:23] ; cc464010 1c423524
	ds_load_b64 v[48:49], v77 offset:3584                       ; d9d80e00 3000004d
	ds_load_b64 v[50:51], v77 offset:7680                       ; d9d81e00 3200004d
	ds_load_b64 v[52:53], v77 offset:11776                      ; d9d82e00 3400004d
	ds_load_b64 v[26:27], v77 offset:15872                      ; d9d83e00 1a00004d
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[32:33], v[128:135] ; cc464080 1e024142
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[66:67], v[28:29], v[7:14] ; cc464007 1c1e3942
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[38:39], v[88:95] ; cc464058 1d624d40
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[32:33], v[120:127] ; cc464078 1de24140
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[40:41], v[152:159] ; cc464098 1e625140
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[28:29], v[184:191] ; cc4640b8 1ee23940
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[38:39], v[96:103] ; cc464060 1d824d42
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[40:41], v[160:167] ; cc4640a0 1e825142
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[38:39], v[104:111] ; cc464068 1da24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[32:33], v[136:143] ; cc464088 1e224144
	v_mov_b32_e32 v36, v71                                      ; 7e480347
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[40:41], v[168:175] ; cc4640a8 1ea25144
	v_mov_b32_e32 v42, v70                                      ; 7e540346
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[28:29], v[80:87] ; cc464050 1d423944
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[64:67], v54, s[36:39], null offen offset:7168 ; c405c07c 40804840 001c0036
	buffer_load_b128 v[68:71], v31, s[36:39], null offen offset:7168 ; c405c07c 40804844 001c001f
	v_swap_b32 v36, v43                                         ; 7e48cb2b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[38:39], v[112:119] ; cc464070 1dc24d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[32:33], v[144:151] ; cc464090 1e42412a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[40:41], v[176:183] ; cc4640b0 1ec2512a
	ds_load_b64 v[38:39], v77 offset:3840                       ; d9d80f00 2600004d
	ds_load_b64 v[32:33], v77 offset:7936                       ; d9d81f00 2000004d
	ds_load_b64 v[40:41], v77 offset:12032                      ; d9d82f00 2800004d
	ds_load_b64 v[78:79], v77 offset:16128                      ; d9d83f00 4e00004d
	v_mov_b32_e32 v37, v55                                      ; 7e4a0337
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[42:43], v[28:29], v[16:23] ; cc464010 1c42392a
	v_mov_b32_e32 v42, v30                                      ; 7e54031e
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[44:45], v[88:95] ; cc464058 1d625938
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[24:25], v[120:127] ; cc464078 1de23138
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[46:47], v[152:159] ; cc464098 1e625d38
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[34:35], v[184:191] ; cc4640b8 1ee24538
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[54:57], v54, s[36:39], null offen offset:7680 ; c405c07c 40804836 001e0036
	buffer_load_b128 v[28:31], v31, s[36:39], null offen offset:7680 ; c405c07c 4080481c 001e001f
	v_mad_u32_u24 v43, s59, 0x50, v72                           ; d60b002b 0521fe3b 00000050
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[44:45], v[96:103] ; cc464060 1d82593a
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[58:59], v[34:35], v[7:14] ; cc464007 1c1e453a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[24:25], v[128:135] ; cc464080 1e02313a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[46:47], v[160:167] ; cc4640a0 1e825d3a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[46:47], v[168:175] ; cc4640a8 1ea25d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[44:45], v[104:111] ; cc464068 1da2593c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[24:25], v[136:143] ; cc464088 1e22313c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[44:45], v[112:119] ; cc464070 1dc2593e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[24:25], v[144:151] ; cc464090 1e42313e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[46:47], v[176:183] ; cc4640b0 1ec25d3e
	ds_load_b64 v[58:59], v43                                   ; d9d80000 3a00002b
	ds_load_b64 v[44:45], v43 offset:4096                       ; d9d81000 2c00002b
	ds_load_b64 v[24:25], v43 offset:8192                       ; d9d82000 1800002b
	ds_load_b64 v[46:47], v43 offset:12288                      ; d9d83000 2e00002b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[34:35], v[80:87] ; cc464050 1d42453c
	v_add_nc_u32_e32 v60, 4, v37                                ; 4a784a84
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[62:63], v[34:35], v[16:23] ; cc464010 1c42453e
	v_sub_nc_u32_e32 v61, 0, v60                                ; 4c7a7880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v61, v60, v61                                 ; 247a7b3c
	v_med3_i32 v60, -1, v60, 1                                  ; d620003c 020678c1
	v_lshrrev_b32_e32 v61, 1, v61                               ; 327a7a81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c003c
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
	v_lshl_add_u32 v60, v60, 11, s4                             ; d646003c 0011173c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v60, v60, v42, 2                             ; d647003c 020a553c
	v_mov_b32_e32 v34, v60                                      ; 7e44033c
	buffer_load_b128 v[60:63], v60, s[36:39], null offen        ; c405c07c 4080483c 0000003c
	v_add_nc_u32_e32 v37, 6, v37                                ; 4a4a4a86
	s_wait_loadcnt_dscnt 0x409                                  ; bfc80409
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[52:53], v[152:159] ; cc464098 1e626940
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[50:51], v[128:135] ; cc464080 1e026542
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[52:53], v[160:167] ; cc4640a0 1e826942
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[66:67], v[26:27], v[7:14] ; cc464007 1c1e3542
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[26:27], v[184:191] ; cc4640b8 1ee23540
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[48:49], v[96:103] ; cc464060 1d826142
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[48:49], v[88:95] ; cc464058 1d626140
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[50:51], v[120:127] ; cc464078 1de26540
	v_sub_nc_u32_e32 v35, 0, v37                                ; 4c464a80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v35, v37, v35                                 ; 24464725
	v_med3_i32 v37, -1, v37, 1                                  ; d6200025 02064ac1
	v_lshrrev_b32_e32 v35, 1, v35                               ; 32464681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0025
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                      ; 02024725
	v_lshl_add_u32 v37, v37, 11, s4                             ; d6460025 00111725
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v37, v37, v42, 2                             ; d6470025 020a5525
	buffer_load_b128 v[64:67], v37, s[36:39], null offen        ; c405c07c 40804840 00000025
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[48:49], v[104:111] ; cc464068 1da26144
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[50:51], v[136:143] ; cc464088 1e226544
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[52:53], v[168:175] ; cc4640a8 1ea26944
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[26:27], v[80:87] ; cc464050 1d423544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[48:49], v[112:119] ; cc464070 1dc26146
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[50:51], v[144:151] ; cc464090 1e426546
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[52:53], v[176:183] ; cc4640b0 1ec26946
	ds_load_b64 v[68:69], v43 offset:256                        ; d9d80100 4400002b
	ds_load_b64 v[48:49], v43 offset:4352                       ; d9d81100 3000002b
	ds_load_b64 v[50:51], v43 offset:8448                       ; d9d82100 3200002b
	ds_load_b64 v[52:53], v43 offset:12544                      ; d9d83100 3400002b
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[70:71], v[26:27], v[16:23] ; cc464010 1c423546
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[56:57], v[38:39], v[96:103] ; cc464060 1d824d38
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[32:33], v[128:135] ; cc464080 1e024138
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[78:79], v[184:191] ; cc4640b8 1ee29d36
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[56:57], v[40:41], v[160:167] ; cc4640a0 1e825138
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[32:33], v[120:127] ; cc464078 1de24136
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[54:55], v[40:41], v[152:159] ; cc464098 1e625136
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[54:55], v[38:39], v[88:95] ; cc464058 1d624d36
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[56:57], v[78:79], v[7:14] ; cc464007 1c1e9d38
	v_maxmin_num_f32 v54, -4.0, v88, 4.0                        ; d6690036 03dab0f7
	v_maxmin_num_f32 v77, -4.0, v91, 4.0                        ; d669004d 03dab6f7
	v_maxmin_num_f32 v56, -4.0, v89, 4.0                        ; d6690038 03dab2f7
	v_maxmin_num_f32 v70, -4.0, v90, 4.0                        ; d6690046 03dab4f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v55, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe6cff 3728ab28
	v_fma_mix_f32 v57, 0xab28, |v56|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206239 0bfe70ff 3728ab28
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_maxmin_num_f32 v35, -4.0, v94, 4.0                        ; d6690023 03dabcf7
	v_fmaak_f32 v54, v54, v55, 0x3f650000                       ; 5a6c6f36 3f650000
	v_maxmin_num_f32 v55, -4.0, v95, 4.0                        ; d6690037 03dabef7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v88, v88, v54 :: v_dual_fmaak_f32 v57, v57, v56, 0x3f650000 ; c8c26d58 58387139 3f650000
	v_fma_mix_f32 v54, 0xab28, |v35|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206236 0bfe46ff 3728ab28
	v_fma_mix_f32 v56, 0xab28, |v55|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206238 0bfe6eff 3728ab28
	v_dual_fmaak_f32 v70, v70, v71, 0x3f650000 :: v_dual_mul_f32 v89, v89, v57 ; c8468f46 46587359 3f650000
	v_maxmin_num_f32 v57, -4.0, v120, 4.0                       ; d6690039 03daf0f7
	v_dual_fmaak_f32 v35, v35, v54, 0x3f650000 :: v_dual_fmaak_f32 v56, v56, v55, 0x3f650000 ; c8426d23 23386f38 3f650000
	v_maxmin_num_f32 v71, -4.0, v121, 4.0                       ; d6690047 03daf2f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v89, -4.0, v92, 4.0                        ; d6690059 03dab8f7
	v_fma_mix_f32 v88, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfe9aff 3728ab28
	v_mul_f32_e32 v95, v95, v56                                 ; 10be715f
	v_fmaak_f32 v88, v88, v77, 0x3f650000                       ; 5ab09b58 3f650000
	v_fma_mix_f32 v77, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624d 0bfe8eff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v90, v90, v70 :: v_dual_mul_f32 v91, v91, v88 ; c8c68d5a 5a5ab15b
	v_fma_mix_f32 v70, 0xab28, |v57|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe72ff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v122, 4.0                       ; d6690058 03daf4f7
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v93, 4.0                        ; d669005b 03dabaf7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_fma_mix_f32 v27, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfeb6ff 3728ab28
	v_fmaak_f32 v89, v89, v90, 0x3f650000                       ; 5ab2b559 3f650000
	v_maxmin_num_f32 v90, -4.0, v123, 4.0                       ; d669005a 03daf6f7
	v_fmaak_f32 v27, v27, v91, 0x3f650000                       ; 5a36b71b 3f650000
	v_dual_fmaak_f32 v57, v57, v70, 0x3f650000 :: v_dual_mul_f32 v92, v92, v89 ; c8468d39 395cb35c 3f650000
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_mul_f32_e32 v93, v93, v27                                 ; 10ba375d
	v_dual_fmaak_f32 v77, v77, v71, 0x3f650000 :: v_dual_mul_f32 v120, v120, v57 ; c8468f4d 4d787378 3f650000
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v92, -4.0, v124, 4.0                       ; d669005c 03daf8f7
	v_dual_mul_f32 v121, v121, v77 :: v_dual_mul_f32 v94, v94, v35 ; c8c69b79 795e475e
	v_dual_mul_f32 v123, v123, v91 :: v_dual_mul_f32 v122, v122, v88 ; c8c6b77b 7b7ab17a
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v126, 4.0                      ; d6690078 03dafcf7
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v94, -4.0, v125, 4.0                       ; d669005e 03dafaf7
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v122, -4.0, v127, 4.0                      ; d669007a 03dafef7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 ; c842bd5f 5f5cbb5c 3f650000
	v_maxmin_num_f32 v35, -4.0, v155, 4.0                       ; d6690023 03db36f7
	v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c842f57b 7b78f378 3f650000
	v_dual_mul_f32 v125, v125, v95 :: v_dual_mul_f32 v124, v124, v92 ; c8c6bf7d 7d7cb97c
	v_maxmin_num_f32 v77, -4.0, v157, 4.0                       ; d669004d 03db3af7
	v_fma_mix_f32 v57, 0xab28, |v35|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206239 0bfe46ff 3728ab28
	v_dual_mul_f32 v127, v127, v123 :: v_dual_mul_f32 v126, v126, v120 ; c8c6f77f 7f7ef17e
	v_maxmin_num_f32 v70, -4.0, v156, 4.0                       ; d6690046 03db38f7
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v152, 4.0                      ; d669007c 03db30f7
	v_fma_mix_f32 v88, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfe9aff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v158, 4.0                       ; d6690059 03db3cf7
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v153, 4.0                      ; d669007e 03db32f7
	v_maxmin_num_f32 v91, -4.0, v159, 4.0                       ; d669005b 03db3ef7
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v184, 4.0                       ; d669005d 03db70f7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v185, 4.0                       ; d669005f 03db72f7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v120, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfebeff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v186, 4.0                      ; d6690079 03db74f7
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 ; c842fd7f 7f7cfb7c 3f650000
	v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842b559 595cb75c 3f650000
	v_maxmin_num_f32 v123, -4.0, v187, 4.0                      ; d669007b 03db76f7
	v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v95, 0x3f650000 ; c842bd5d 5d78bf78 3f650000
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[38:39], v[104:111] ; cc464068 1da24d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[28:29], v[32:33], v[136:143] ; cc464088 1e22411c
	v_dual_mul_f32 v153, v153, v127 :: v_dual_mul_f32 v152, v152, v124 ; c8c6ff99 9998f998
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_mul_f32 v185, v185, v120 :: v_dual_mul_f32 v158, v158, v89 ; c8c6f1b9 b99eb39e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[28:29], v[40:41], v[168:175] ; cc4640a8 1ea2511c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[78:79], v[80:87] ; cc464050 1d429d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[38:39], v[112:119] ; cc464070 1dc24d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[30:31], v[32:33], v[144:151] ; cc464090 1e42411e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[40:41], v[176:183] ; cc4640b0 1ec2511e
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v152, -4.0, v154, 4.0                      ; d6690098 03db34f7
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c842f579 797cf77c 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[30:31], v[78:79], v[16:23] ; cc464010 1c429d1e
	v_maxmin_num_f32 v125, -4.0, v188, 4.0                      ; d669007d 03db78f7
	v_maxmin_num_f32 v127, -4.0, v189, 4.0                      ; d669007f 03db7af7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_mul_f32 v187, v187, v124 :: v_dual_mul_f32 v184, v184, v93 ; c8c6f9bb bbb8bbb8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_fmaak_f32 v152, v152, v153, 0x3f650000                    ; 5b313398 3f650000
	v_maxmin_num_f32 v153, -4.0, v190, 4.0                      ; d6690099 03db7cf7
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_mul_f32 v154, v154, v152 :: v_dual_fmaak_f32 v57, v57, v35, 0x3f650000 ; c8c3319a 9a384739 3f650000
	v_fma_mix_f32 v152, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bfefeff 3728ab28
	v_dual_mul_f32 v155, v57, v155 :: v_dual_fmaak_f32 v88, v88, v77, 0x3f650000 ; c8c33739 9b589b58 3f650000
	v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v127, 0x3f650000 ; c842fd7d 7d98ff98 3f650000
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmaak_f32 v70, v70, v71, 0x3f650000 :: v_dual_mul_f32 v157, v157, v88 ; c8468f46 469cb19d 3f650000
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v155, -4.0, v191, 4.0                      ; d669009b 03db7ef7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_mul_f32 v189, v189, v152 :: v_dual_mul_f32 v186, v186, v121 ; c8c731bd bdbaf3ba
	v_maxmin_num_f32 v185, -4.0, v98, 4.0                       ; d66900b9 03dac4f7
	v_dual_mul_f32 v159, v159, v92 :: v_dual_mul_f32 v156, v156, v70 ; c8c6b99f 9f9c8d9c
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v187, -4.0, v99, 4.0                       ; d66900bb 03dac6f7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_maxmin_num_f32 v157, -4.0, v96, 4.0                       ; d669009d 03dac0f7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_maxmin_num_f32 v159, -4.0, v97, 4.0                       ; d669009f 03dac2f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 ; c8433599 999d379c 3f650000
	v_fma_mix_f32 v184, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff3eff 3728ab28
	v_maxmin_num_f32 v35, -4.0, v103, 4.0                       ; d6690023 03dacef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_mul_f32 v191, v191, v156 :: v_dual_mul_f32 v188, v188, v125 ; c8c739bf bfbcfbbc
	v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v159, 0x3f650000 ; c8433d9d 9db93fb8 3f650000
	v_maxmin_num_f32 v32, -4.0, v102, 4.0                       ; d6690020 03daccf7
	v_fma_mix_f32 v38, 0xab28, |v35|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206226 0bfe46ff 3728ab28
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_maxmin_num_f32 v189, -4.0, v100, 4.0                      ; d66900bd 03dac8f7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v39, -4.0, v128, 4.0                       ; d6690027 03db00f7
	v_dual_mul_f32 v97, v97, v184 :: v_dual_mul_f32 v190, v190, v153 ; c8c77161 61bf33be
	v_fma_mix_f32 v33, 0xab28, |v32|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206221 0bfe40ff 3728ab28
	v_maxmin_num_f32 v41, -4.0, v129, 4.0                       ; d6690029 03db02f7
	v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 ; c84375b9 b9bd77bc 3f650000
	v_fma_mix_f32 v40, 0xab28, |v39|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206228 0bfe4eff 3728ab28
	v_maxmin_num_f32 v71, -4.0, v130, 4.0                       ; d6690047 03db04f7
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v191, -4.0, v101, 4.0                      ; d66900bf 03dacaf7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_fma_mix_f32 v70, 0xab28, |v41|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe52ff 3728ab28
	v_maxmin_num_f32 v78, -4.0, v131, 4.0                       ; d669004e 03db06f7
	v_dual_mul_f32 v99, v99, v188 :: v_dual_mul_f32 v96, v96, v157 ; c8c77963 63613b60
	v_fma_mix_f32 v77, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624d 0bfe8eff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v132, 4.0                       ; d6690058 03db08f7
	v_fma_mix_f32 v31, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621f 0bff7eff 3728ab28
	v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 :: v_dual_mul_f32 v98, v98, v185 ; c8477dbd bd637362 3f650000
	v_dual_fmaak_f32 v39, v39, v40, 0x3f650000 :: v_dual_fmaak_f32 v70, v70, v41, 0x3f650000 ; c8425127 27465346 3f650000
	v_maxmin_num_f32 v90, -4.0, v133, 4.0                       ; d669005a 03db0af7
	v_fma_mix_f32 v79, 0xab28, |v78|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624f 0bfe9cff 3728ab28
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v134, 4.0                       ; d669005c 03db0cf7
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_dual_fmaak_f32 v31, v31, v191, 0x3f650000 :: v_dual_mul_f32 v100, v100, v189 ; c8477f1f 1f657b64 3f650000
	v_dual_fmaak_f32 v71, v71, v77, 0x3f650000 :: v_dual_mul_f32 v128, v128, v39 ; c8469b47 47804f80 3f650000
	v_maxmin_num_f32 v94, -4.0, v135, 4.0                       ; d669005e 03db0ef7
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v96, -4.0, v160, 4.0                       ; d6690060 03db40f7
	v_dual_fmaak_f32 v38, v35, v38, 0x3f650000 :: v_dual_mul_f32 v101, v101, v31 ; c8464d23 26643f65 3f650000
	v_maxmin_num_f32 v98, -4.0, v161, 4.0                       ; d6690062 03db42f7
	v_dual_fmaak_f32 v79, v79, v78, 0x3f650000 :: v_dual_mul_f32 v130, v130, v71 ; c8469d4f 4f828f82 3f650000
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v100, -4.0, v162, 4.0                      ; d6690064 03db44f7
	v_dual_mul_f32 v103, v103, v38 :: v_dual_fmaak_f32 v32, v32, v33, 0x3f650000 ; c8c24d67 67204320 3f650000
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_mul_f32_e32 v131, v131, v79                               ; 11069f83
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 ; c842bd5f 5f5cbb5c 3f650000
	v_dual_mul_f32 v133, v133, v91 :: v_dual_mul_f32 v132, v132, v88 ; c8c6b785 8584b184
	v_maxmin_num_f32 v120, -4.0, v164, 4.0                      ; d6690078 03db48f7
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_dual_mul_f32 v129, v129, v70 :: v_dual_mul_f32 v102, v102, v32 ; c8c68d81 81664166
	v_maxmin_num_f32 v122, -4.0, v165, 4.0                      ; d669007a 03db4af7
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v97, 0x3f650000 ; c842c563 6360c360 3f650000
	v_dual_mul_f32 v135, v135, v95 :: v_dual_mul_f32 v134, v134, v92 ; c8c6bf87 8786b986
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v124, -4.0, v166, 4.0                      ; d669007c 03db4cf7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_maxmin_num_f32 v126, -4.0, v167, 4.0                      ; d669007e 03db4ef7
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v102, -4.0, v163, 4.0                      ; d6690066 03db46f7
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_dual_mul_f32 v161, v161, v99 :: v_dual_mul_f32 v160, v160, v96 ; c8c6c7a1 a1a0c1a0
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v128, -4.0, v7, 4.0                        ; d6690080 03da0ef7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v8, 4.0                        ; d6690082 03da10f7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v9, 4.0                        ; d6690084 03da12f7
	v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c842f57b 7b78f378 3f650000
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_maxmin_num_f32 v134, -4.0, v10, 4.0                       ; d6690086 03da14f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 ; c842fd7f 7f7cfb7c 3f650000
	v_maxmin_num_f32 v152, -4.0, v11, 4.0                       ; d6690098 03da16f7
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c842cd67 6764cb64 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v12, 4.0                       ; d669009a 03da18f7
	v_dual_mul_f32 v165, v165, v123 :: v_dual_mul_f32 v164, v164, v120 ; c8c6f7a5 a5a4f1a4
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
	v_dual_mul_f32 v167, v167, v127 :: v_dual_mul_f32 v166, v166, v124 ; c8c6ffa7 a7a6f9a6
	v_maxmin_num_f32 v156, -4.0, v13, 4.0                       ; d669009c 03da1af7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v14, 4.0                       ; d669009e 03da1cf7
	v_dual_mul_f32 v163, v163, v103 :: v_dual_mul_f32 v162, v162, v100 ; c8c6cfa3 a3a2c9a2
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430d87 87850b84 3f650000
	v_maxmin_num_f32 v160, -4.0, v104, 4.0                      ; d66900a0 03dad0f7
	v_dual_mul_f32 v8, v8, v131 :: v_dual_mul_f32 v7, v7, v128  ; c8c70708 08070107
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_maxmin_num_f32 v162, -4.0, v105, 4.0                      ; d66900a2 03dad2f7
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_maxmin_num_f32 v164, -4.0, v106, 4.0                      ; d66900a4 03dad4f7
	v_dual_mul_f32 v10, v10, v135 :: v_dual_mul_f32 v9, v9, v132 ; c8c70f0a 0a090909
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v107, 4.0                      ; d66900a6 03dad6f7
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                        ; 02021107
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_maxmin_num_f32 v184, -4.0, v108, 4.0                      ; d66900b8 03dad8f7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_mul_f32 v12, v12, v155 :: v_dual_mul_f32 v11, v11, v152 ; c8c7370c 0c0b310b
	v_maxmin_num_f32 v186, -4.0, v109, 4.0                      ; d66900ba 03dadaf7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                       ; 02021509
	v_maxmin_num_f32 v190, -4.0, v111, 4.0                      ; d66900be 03dadef7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_mul_f32 v14, v14, v159 :: v_dual_mul_f32 v13, v13, v156 ; c8c73f0e 0e0d390d
	v_maxmin_num_f32 v188, -4.0, v110, 4.0                      ; d66900bc 03dadcf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v11, v12, vcc_lo                      ; 0202190b
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                      ; 02021d0d
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v10, -4.0, v137, 4.0                       ; d669000a 03db12f7
	v_maxmin_num_f32 v12, -4.0, v138, 4.0                       ; d669000c 03db14f7
	v_dual_mul_f32 v105, v105, v163 :: v_dual_mul_f32 v104, v104, v160 ; c8c74769 69694168
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84375bb bbb973b8 3f650000
	v_dual_mul_f32 v107, v107, v167 :: v_dual_mul_f32 v106, v106, v164 ; c8c74f6b 6b6b496a
	v_maxmin_num_f32 v14, -4.0, v139, 4.0                       ; d669000e 03db16f7
	v_maxmin_num_f32 v70, -4.0, v140, 4.0                       ; d6690046 03db18f7
	v_fma_mix_f32 v11, 0xab28, |v10|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620b 0bfe14ff 3728ab28
	v_fma_mix_f32 v13, 0xab28, |v12|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bfe18ff 3728ab28
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_mul_f32 v108, v108, v184 ; c8477dbf bf6d716c 3f650000
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_fma_mix_f32 v35, 0xab28, |v14|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206223 0bfe1cff 3728ab28
	v_maxmin_num_f32 v77, -4.0, v141, 4.0                       ; d669004d 03db1af7
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_maxmin_num_f32 v79, -4.0, v142, 4.0                       ; d669004f 03db1cf7
	v_dual_fmaak_f32 v12, v12, v13, 0x3f650000 :: v_dual_fmaak_f32 v11, v11, v10, 0x3f650000 ; c8421b0c 0c0a150b 3f650000
	v_dual_mul_f32 v111, v111, v191 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8c37f6f 6fbd7bbc 3f650000
	v_maxmin_num_f32 v191, -4.0, v136, 4.0                      ; d66900bf 03db10f7
	v_maxmin_num_f32 v89, -4.0, v143, 4.0                       ; d6690059 03db1ef7
	v_fma_mix_f32 v78, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe9aff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v168, 4.0                       ; d669005b 03db50f7
	v_dual_fmaak_f32 v70, v70, v71, 0x3f650000 :: v_dual_fmaak_f32 v35, v35, v14, 0x3f650000 ; c8428f46 46221d23 3f650000
	v_fma_mix_f32 v88, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfe9eff 3728ab28
	v_dual_mul_f32 v137, v137, v11 :: v_dual_mul_f32 v138, v138, v12 ; c8c61789 898a198a
	v_fma_mix_f32 v7, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bff7eff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v169, 4.0                       ; d669005d 03db52f7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v170, 4.0                       ; d669005f 03db54f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_mul_f32 v140, v140, v70 :: v_dual_mul_f32 v139, v139, v35 ; c8c68d8c 8c8a478b
	v_dual_fmaak_f32 v78, v78, v77, 0x3f650000 :: v_dual_fmaak_f32 v79, v79, v88, 0x3f650000 ; c8429b4e 4e4eb14f 3f650000
	v_dual_fmaak_f32 v191, v191, v7, 0x3f650000 :: v_dual_mul_f32 v110, v110, v188 ; c8460fbf bf6f796e 3f650000
	v_maxmin_num_f32 v97, -4.0, v171, 4.0                       ; d6690061 03db56f7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v172, 4.0                       ; d6690063 03db58f7
	v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 :: v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 ; c842b35a 5a5ab95b 3f650000
	v_dual_mul_f32 v142, v142, v79 :: v_dual_mul_f32 v141, v141, v78 ; c8c69f8e 8e8c9d8d
	v_dual_mul_f32 v109, v187, v109 :: v_dual_mul_f32 v136, v136, v191 ; c8c6dbbb 6d897f88
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v173, 4.0                      ; d6690065 03db5af7
	v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842c15f 5f5ebb5e 3f650000
	v_maxmin_num_f32 v103, -4.0, v174, 4.0                      ; d6690067 03db5cf7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_dual_mul_f32 v168, v168, v91 :: v_dual_mul_f32 v143, v143, v90 ; c8c6b7a8 a88eb58f
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v105, -4.0, v175, 4.0                      ; d6690069 03db5ef7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v80, 4.0                       ; d669006b 03daa0f7
	v_dual_mul_f32 v170, v170, v95 :: v_dual_mul_f32 v169, v169, v94 ; c8c6bfaa aaa8bda9
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 ; c842c963 6362c362 3f650000
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_maxmin_num_f32 v109, -4.0, v81, 4.0                       ; d669006d 03daa2f7
	v_maxmin_num_f32 v111, -4.0, v82, 4.0                       ; d669006f 03daa4f7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v83, 4.0                       ; d6690079 03daa6f7
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c842d167 6766cb66 3f650000
	v_dual_mul_f32 v172, v172, v99 :: v_dual_mul_f32 v171, v171, v98 ; c8c6c7ac acaac5ab
	v_maxmin_num_f32 v123, -4.0, v84, 4.0                       ; d669007b 03daa8f7
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_fma_mix_f32 v120, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfedeff 3728ab28
	v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 ; c842d96b 6b6ad36a 3f650000
	v_maxmin_num_f32 v125, -4.0, v85, 4.0                       ; d669007d 03daaaf7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v86, 4.0                       ; d669007f 03daacf7
	v_dual_mul_f32 v174, v174, v103 :: v_dual_mul_f32 v173, v173, v102 ; c8c6cfae aeaccdad
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_fmaak_f32 v111, v111, v120, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 ; c842f16f 6f6edb6e 3f650000
	v_maxmin_num_f32 v129, -4.0, v87, 4.0                       ; d6690081 03daaef7
	v_dual_mul_f32 v80, v80, v107 :: v_dual_mul_f32 v175, v175, v106 ; c8c6d750 50aed5af
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v112, 4.0                      ; d6690083 03dae0f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_maxmin_num_f32 v133, -4.0, v113, 4.0                      ; d6690085 03dae2f7
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f97b 7b7af37a 3f650000
	v_dual_mul_f32 v82, v82, v111 :: v_dual_mul_f32 v81, v81, v110 ; c8c6df52 5250dd51
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v114, 4.0                      ; d6690087 03dae4f7
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c843017f 7f7efb7e 3f650000
	v_maxmin_num_f32 v137, -4.0, v115, 4.0                      ; d6690089 03dae6f7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_dual_mul_f32 v84, v84, v123 :: v_dual_mul_f32 v83, v83, v122 ; c8c6f754 5452f553
	v_maxmin_num_f32 v139, -4.0, v116, 4.0                      ; d669008b 03dae8f7
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_maxmin_num_f32 v141, -4.0, v117, 4.0                      ; d669008d 03daeaf7
	v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 ; c8430983 83830382 3f650000
	v_dual_mul_f32 v86, v86, v127 :: v_dual_mul_f32 v85, v85, v126 ; c8c6ff56 5654fd55
	v_maxmin_num_f32 v143, -4.0, v118, 4.0                      ; d669008f 03daecf7
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 ; c8431187 87870b86 3f650000
	v_maxmin_num_f32 v153, -4.0, v119, 4.0                      ; d6690099 03daeef7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_dual_mul_f32 v112, v112, v131 :: v_dual_mul_f32 v87, v87, v130 ; c8c70770 70570557
	v_maxmin_num_f32 v155, -4.0, v144, 4.0                      ; d669009b 03db20f7
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_fma_mix_f32 v152, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff1eff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v145, 4.0                      ; d669009d 03db22f7
	v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 ; c843198b 8b8b138a 3f650000
	v_dual_mul_f32 v114, v114, v135 :: v_dual_mul_f32 v113, v113, v134 ; c8c70f72 72710d71
	v_maxmin_num_f32 v159, -4.0, v146, 4.0                      ; d669009f 03db24f7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_fmaak_f32 v143, v143, v152, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 ; c843318f 8f8f1b8e 3f650000
	v_maxmin_num_f32 v161, -4.0, v147, 4.0                      ; d66900a1 03db26f7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v148, 4.0                      ; d66900a3 03db28f7
	v_dual_mul_f32 v116, v116, v139 :: v_dual_mul_f32 v115, v115, v138 ; c8c71774 74731573
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
	v_maxmin_num_f32 v165, -4.0, v149, 4.0                      ; d66900a5 03db2af7
	v_dual_mul_f32 v118, v118, v143 :: v_dual_mul_f32 v117, v117, v142 ; c8c71f76 76751d75
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v150, 4.0                      ; d66900a7 03db2cf7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v171, -4.0, v176, 4.0                      ; d66900ab 03db60f7
	v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 ; c843419f 9f9f3b9e 3f650000
	v_dual_mul_f32 v144, v144, v155 :: v_dual_mul_f32 v119, v119, v154 ; c8c73790 90773577
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v173, -4.0, v177, 4.0                      ; d66900ad 03db62f7
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c84349a3 a3a343a2 3f650000
	v_maxmin_num_f32 v169, -4.0, v151, 4.0                      ; d66900a9 03db2ef7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_mul_f32 v146, v146, v159 :: v_dual_mul_f32 v145, v145, v158 ; c8c73f92 92913d91
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v175, -4.0, v178, 4.0                      ; d66900af 03db64f7
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84351a7 a7a74ba6 3f650000
	v_dual_mul_f32 v148, v148, v163 :: v_dual_mul_f32 v147, v147, v162 ; c8c74794 94934593
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v180, 4.0                      ; d66900b9 03db68f7
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v187, -4.0, v181, 4.0                      ; d66900bb 03db6af7
	v_dual_fmaak_f32 v174, v174, v173, 0x3f650000 :: v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 ; c8435bae aeab59ab 3f650000
	v_dual_mul_f32 v150, v150, v167 :: v_dual_mul_f32 v149, v149, v166 ; c8c74f96 96954d95
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_maxmin_num_f32 v189, -4.0, v182, 4.0                      ; d66900bd 03db6cf7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v183, 4.0                      ; d66900bf 03db6ef7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_dual_mul_f32 v177, v177, v174 :: v_dual_mul_f32 v176, v176, v171 ; c8c75db1 b1b157b0
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v14, -4.0, v16, 4.0                        ; d669000e 03da20f7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_fma_mix_f32 v7, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bff7eff 3728ab28
	v_maxmin_num_f32 v77, -4.0, v17, 4.0                        ; d669004d 03da22f7
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_maxmin_num_f32 v177, -4.0, v179, 4.0                      ; d66900b1 03db66f7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_fma_mix_f32 v35, 0xab28, |v14|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206223 0bfe1cff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v18, 4.0                        ; d6690055 03da24f7
	v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 ; c8437dbd bdbd77bc 3f650000
	v_fma_mix_f32 v84, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfe9aff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v19, 4.0                        ; d6690057 03da26f7
	v_fma_mix_f32 v184, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff62ff 3728ab28
	v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 :: v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 ; c84353aa aaaf61af 3f650000
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v20, 4.0                        ; d6690059 03da28f7
	v_dual_fmaak_f32 v14, v14, v35, 0x3f650000 :: v_dual_mul_f32 v181, v181, v188 ; c846470e 0eb579b5 3f650000
	v_dual_fmaak_f32 v7, v7, v191, 0x3f650000 :: v_dual_mul_f32 v182, v182, v189 ; c8477f07 07b77bb6 3f650000
	v_maxmin_num_f32 v91, -4.0, v21, 4.0                        ; d669005b 03da2af7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v184, v184, v177, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 ; c84363b8 b8b975b9 3f650000
	v_dual_mul_f32 v178, v178, v175 :: v_dual_mul_f32 v151, v151, v170 ; c8c75fb2 b2975597
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v22, 4.0                        ; d669005d 03da2cf7
	v_maxmin_num_f32 v95, -4.0, v23, 4.0                        ; d669005f 03da2ef7
	v_dual_fmaak_f32 v84, v84, v77, 0x3f650000 :: v_dual_mul_f32 v183, v183, v7 ; c8469b54 54b60fb7 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af58 5854ad55 3f650000
	v_dual_mul_f32 v180, v180, v185 :: v_dual_mul_f32 v179, v179, v184 ; c8c773b4 b4b371b3
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	s_wait_loadcnt_dscnt 0x105                                  ; bfc80105
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[24:25], 0 ; cc464068 1a02313c
	v_dual_mul_f32 v17, v17, v84 :: v_dual_mul_f32 v16, v16, v14 ; c8c6a911 11101d10
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[60:61], v[46:47], 0 ; cc464070 1a025d3c
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c842b75c 5c58b559 3f650000
	v_dual_mul_f32 v18, v18, v85 :: v_dual_mul_f32 v19, v19, v88 ; c8c6ab12 1212b113
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[62:63], v[58:59], 0 ; cc464078 1a02753e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[44:45], 0 ; cc464080 1a02593e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[62:63], v[24:25], 0 ; cc464088 1a02313e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[46:47], 0 ; cc464090 1a025d3e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[58:59], 0 ; cc464098 1a027540
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[64:65], v[44:45], 0 ; cc4640a0 1a025940
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[64:65], v[24:25], 0 ; cc4640a8 1a023140
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[64:65], v[46:47], 0 ; cc4640b0 1a025d40
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[66:67], v[58:59], 0 ; cc4640b8 1a027542
	v_dual_mul_f32 v21, v21, v92 :: v_dual_mul_f32 v20, v20, v89 ; c8c6b915 1514b314
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_dual_mul_f32 v23, v23, v96 :: v_dual_mul_f32 v22, v22, v93 ; c8c6c117 1716bb16
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[60:61], v[58:59], 0 ; cc464058 1a02753c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[60:61], v[44:45], 0 ; cc464060 1a02593c
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[66:67], v[44:45], 0 ; cc46403a 1a025942
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	v_mov_b32_e32 v44, v16                                      ; 7e580310
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mov_b32 v14, v6 :: v_dual_mov_b32 v45, v17           ; ca100106 0e2c0111
	v_dual_mov_b32 v6, v82 :: v_dual_mov_b32 v7, v83            ; ca100152 06060153
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[66:67], v[24:25], 0 ; cc464010 1a023142
	v_dual_mov_b32 v24, v80 :: v_dual_mov_b32 v25, v81          ; ca100150 18180151
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[66:67], v[46:47], 0 ; cc464050 1a025d42
	v_dual_mov_b32 v66, v44 :: v_dual_mov_b32 v67, v45          ; ca10012c 4242012d
	buffer_load_b128 v[44:47], v34, s[36:39], null offen offset:512 ; c405c07c 4080482c 00020022
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[50:51], v[136:143] ; cc464088 1e22652e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[68:69], v[120:127] ; cc464078 1de2892e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[50:51], v[104:111] ; cc464068 1da2652c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[48:49], v[128:135] ; cc464080 1e02612e
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[52:53], v[144:151] ; cc464090 1e42692e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[68:69], v[88:95] ; cc464058 1d62892c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[48:49], v[96:103] ; cc464060 1d82612c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[52:53], v[112:119] ; cc464070 1dc2692c
	buffer_load_b128 v[44:47], v37, s[36:39], null offen offset:512 ; c405c07c 4080482c 00020025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[46:47], v[48:49], v[58:65] ; cc46403a 1cea612e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[50:51], v[16:23] ; cc464010 1c42652e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[46:47], v[68:69], v[184:191] ; cc4640b8 1ee2892e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[44:45], v[68:69], v[152:159] ; cc464098 1e62892c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[44:45], v[52:53], v[176:183] ; cc4640b0 1ec2692c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[50:51], v[168:175] ; cc4640a8 1ea2652c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[44:45], v[48:49], v[160:167] ; cc4640a0 1e82612c
	ds_load_b64 v[44:45], v43 offset:512                        ; d9d80200 2c00002b
	ds_load_b64 v[68:69], v43 offset:4608                       ; d9d81200 4400002b
	ds_load_b64 v[48:49], v43 offset:8704                       ; d9d82200 3000002b
	ds_load_b64 v[50:51], v43 offset:12800                      ; d9d83200 3200002b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[52:53], v[80:87] ; cc464050 1d42692e
	s_wait_dscnt 0x3                                            ; bfc60003
	v_dual_mov_b32 v53, v45 :: v_dual_mov_b32 v52, v44          ; ca10012d 3534012c
	buffer_load_b128 v[44:47], v34, s[36:39], null offen offset:1024 ; c405c07c 4080482c 00040022
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[48:49], v[104:111] ; cc464068 1da2612c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[50:51], v[112:119] ; cc464070 1dc2652c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[52:53], v[120:127] ; cc464078 1de2692e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[68:69], v[96:103] ; cc464060 1d82892c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[68:69], v[128:135] ; cc464080 1e02892e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[48:49], v[136:143] ; cc464088 1e22612e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[52:53], v[88:95] ; cc464058 1d62692c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[50:51], v[144:151] ; cc464090 1e42652e
	buffer_load_b128 v[44:47], v37, s[36:39], null offen offset:1024 ; c405c07c 4080482c 00040025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[44:45], v[68:69], v[160:167] ; cc4640a0 1e82892c
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[46:47], v[68:69], v[58:65] ; cc46403a 1cea892e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[48:49], v[168:175] ; cc4640a8 1ea2612c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[44:45], v[50:51], v[176:183] ; cc4640b0 1ec2652c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[48:49], v[16:23] ; cc464010 1c42612e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[46:47], v[52:53], v[184:191] ; cc4640b8 1ee2692e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[44:45], v[52:53], v[152:159] ; cc464098 1e62692c
	ds_load_b64 v[44:45], v43 offset:768                        ; d9d80300 2c00002b
	ds_load_b64 v[52:53], v43 offset:4864                       ; d9d81300 3400002b
	ds_load_b64 v[68:69], v43 offset:8960                       ; d9d82300 4400002b
	ds_load_b64 v[48:49], v43 offset:13056                      ; d9d83300 3000002b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[50:51], v[80:87] ; cc464050 1d42652e
	s_wait_dscnt 0x3                                            ; bfc60003
	v_dual_mov_b32 v51, v45 :: v_dual_mov_b32 v50, v44          ; ca10012d 3332012c
	buffer_load_b128 v[44:47], v34, s[36:39], null offen offset:1536 ; c405c07c 4080482c 00060022
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[68:69], v[104:111] ; cc464068 1da2892c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[48:49], v[112:119] ; cc464070 1dc2612c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[50:51], v[120:127] ; cc464078 1de2652e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[52:53], v[128:135] ; cc464080 1e02692e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[68:69], v[136:143] ; cc464088 1e22892e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[48:49], v[144:151] ; cc464090 1e42612e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[50:51], v[88:95] ; cc464058 1d62652c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[52:53], v[96:103] ; cc464060 1d82692c
	buffer_load_b128 v[44:47], v37, s[36:39], null offen offset:1536 ; c405c07c 4080482c 00060025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[46:47], v[52:53], v[58:65] ; cc46403a 1cea692e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[68:69], v[16:23] ; cc464010 1c42892e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[68:69], v[168:175] ; cc4640a8 1ea2892c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[44:45], v[48:49], v[176:183] ; cc4640b0 1ec2612c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[44:45], v[50:51], v[152:159] ; cc464098 1e62652c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[46:47], v[50:51], v[184:191] ; cc4640b8 1ee2652e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[44:45], v[52:53], v[160:167] ; cc4640a0 1e82692c
	ds_load_b64 v[44:45], v43 offset:1024                       ; d9d80400 2c00002b
	ds_load_b64 v[50:51], v43 offset:5120                       ; d9d81400 3200002b
	ds_load_b64 v[52:53], v43 offset:9216                       ; d9d82400 3400002b
	ds_load_b64 v[68:69], v43 offset:13312                      ; d9d83400 4400002b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[48:49], v[80:87] ; cc464050 1d42612e
	buffer_load_b128 v[46:49], v34, s[36:39], null offen offset:2048 ; c405c07c 4080482e 00080022
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[68:69], v[112:119] ; cc464070 1dc2892e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[44:45], v[120:127] ; cc464078 1de25930
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[48:49], v[50:51], v[128:135] ; cc464080 1e026530
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[48:49], v[52:53], v[136:143] ; cc464088 1e226930
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[48:49], v[68:69], v[144:151] ; cc464090 1e428930
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[52:53], v[104:111] ; cc464068 1da2692e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[46:47], v[44:45], v[88:95] ; cc464058 1d62592e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[50:51], v[96:103] ; cc464060 1d82652e
	buffer_load_b128 v[46:49], v37, s[36:39], null offen offset:2048 ; c405c07c 4080482e 00080025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[48:49], v[50:51], v[58:65] ; cc46403a 1cea6530
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[68:69], v[176:183] ; cc4640b0 1ec2892e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[48:49], v[52:53], v[16:23] ; cc464010 1c426930
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[48:49], v[44:45], v[184:191] ; cc4640b8 1ee25930
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[46:47], v[50:51], v[160:167] ; cc4640a0 1e82652e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[44:45], v[152:159] ; cc464098 1e62592e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[46:47], v[52:53], v[168:175] ; cc4640a8 1ea2692e
	ds_load_b64 v[46:47], v43 offset:1280                       ; d9d80500 2e00002b
	ds_load_b64 v[44:45], v43 offset:5376                       ; d9d81500 2c00002b
	ds_load_b64 v[50:51], v43 offset:9472                       ; d9d82500 3200002b
	ds_load_b64 v[52:53], v43 offset:13568                      ; d9d83500 3400002b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[68:69], v[80:87] ; cc464050 1d428930
	s_wait_dscnt 0x1                                            ; bfc60001
	v_dual_mov_b32 v69, v51 :: v_dual_mov_b32 v68, v50          ; ca100133 45440132
	buffer_load_b128 v[48:51], v34, s[36:39], null offen offset:2560 ; c405c07c 40804830 000a0022
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[68:69], v[104:111] ; cc464068 1da28930
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[52:53], v[112:119] ; cc464070 1dc26930
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[46:47], v[120:127] ; cc464078 1de25d32
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[44:45], v[128:135] ; cc464080 1e025932
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[50:51], v[68:69], v[136:143] ; cc464088 1e228932
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[48:49], v[44:45], v[96:103] ; cc464060 1d825930
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[50:51], v[52:53], v[144:151] ; cc464090 1e426932
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[46:47], v[88:95] ; cc464058 1d625d30
	buffer_load_b128 v[48:51], v37, s[36:39], null offen offset:2560 ; c405c07c 40804830 000a0025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[50:51], v[44:45], v[58:65] ; cc46403a 1cea5932
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[48:49], v[68:69], v[168:175] ; cc4640a8 1ea28930
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[50:51], v[68:69], v[16:23] ; cc464010 1c428932
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[46:47], v[152:159] ; cc464098 1e625d30
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[48:49], v[52:53], v[176:183] ; cc4640b0 1ec26930
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[48:49], v[44:45], v[160:167] ; cc4640a0 1e825930
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[50:51], v[46:47], v[184:191] ; cc4640b8 1ee25d32
	ds_load_b64 v[48:49], v43 offset:1536                       ; d9d80600 3000002b
	ds_load_b64 v[46:47], v43 offset:5632                       ; d9d81600 2e00002b
	ds_load_b64 v[44:45], v43 offset:9728                       ; d9d82600 2c00002b
	ds_load_b64 v[68:69], v43 offset:13824                      ; d9d83600 4400002b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[50:51], v[52:53], v[80:87] ; cc464050 1d426932
	buffer_load_b128 v[50:53], v34, s[36:39], null offen offset:3072 ; c405c07c 40804832 000c0022
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[68:69], v[112:119] ; cc464070 1dc28932
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[52:53], v[48:49], v[120:127] ; cc464078 1de26134
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[52:53], v[46:47], v[128:135] ; cc464080 1e025d34
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[44:45], v[136:143] ; cc464088 1e225934
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[68:69], v[144:151] ; cc464090 1e428934
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[50:51], v[48:49], v[88:95] ; cc464058 1d626132
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[50:51], v[44:45], v[104:111] ; cc464068 1da25932
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[46:47], v[96:103] ; cc464060 1d825d32
	buffer_load_b128 v[50:53], v37, s[36:39], null offen offset:3072 ; c405c07c 40804832 000c0025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[52:53], v[46:47], v[58:65] ; cc46403a 1cea5d34
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[50:51], v[68:69], v[176:183] ; cc4640b0 1ec28932
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[52:53], v[44:45], v[16:23] ; cc464010 1c425934
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[52:53], v[48:49], v[184:191] ; cc4640b8 1ee26134
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[46:47], v[160:167] ; cc4640a0 1e825d32
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[50:51], v[48:49], v[152:159] ; cc464098 1e626132
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[50:51], v[44:45], v[168:175] ; cc4640a8 1ea25932
	ds_load_b64 v[50:51], v43 offset:1792                       ; d9d80700 3200002b
	ds_load_b64 v[48:49], v43 offset:5888                       ; d9d81700 3000002b
	ds_load_b64 v[46:47], v43 offset:9984                       ; d9d82700 2e00002b
	ds_load_b64 v[44:45], v43 offset:14080                      ; d9d83700 2c00002b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[52:53], v[68:69], v[80:87] ; cc464050 1d428934
	v_dual_mov_b32 v69, v55 :: v_dual_mov_b32 v68, v54          ; ca100137 45440136
	buffer_load_b128 v[52:55], v34, s[36:39], null offen offset:3584 ; c405c07c 40804834 000e0022
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[46:47], v[104:111] ; cc464068 1da25d34
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[52:53], v[44:45], v[112:119] ; cc464070 1dc25934
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[50:51], v[120:127] ; cc464078 1de26536
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[48:49], v[128:135] ; cc464080 1e026136
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[54:55], v[46:47], v[136:143] ; cc464088 1e225d36
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[48:49], v[96:103] ; cc464060 1d826134
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[44:45], v[144:151] ; cc464090 1e425936
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[50:51], v[88:95] ; cc464058 1d626534
	buffer_load_b128 v[52:55], v37, s[36:39], null offen offset:3584 ; c405c07c 40804834 000e0025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[54:55], v[48:49], v[58:65] ; cc46403a 1cea6136
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[46:47], v[168:175] ; cc4640a8 1ea25d34
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[46:47], v[16:23] ; cc464010 1c425d36
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[52:53], v[44:45], v[176:183] ; cc4640b0 1ec25934
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[50:51], v[152:159] ; cc464098 1e626534
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[48:49], v[160:167] ; cc4640a0 1e826134
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[50:51], v[184:191] ; cc4640b8 1ee26536
	ds_load_b64 v[52:53], v43 offset:2048                       ; d9d80800 3400002b
	ds_load_b64 v[50:51], v43 offset:6144                       ; d9d81800 3200002b
	ds_load_b64 v[48:49], v43 offset:10240                      ; d9d82800 3000002b
	ds_load_b64 v[46:47], v43 offset:14336                      ; d9d83800 2e00002b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[54:55], v[44:45], v[80:87] ; cc464050 1d425936
	v_dual_mov_b32 v54, v43 :: v_dual_mov_b32 v35, v42          ; ca10012b 3622012a
	buffer_load_b128 v[42:45], v34, s[36:39], null offen offset:4096 ; c405c07c 4080482a 00100022
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[48:49], v[104:111] ; cc464068 1da2612a
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[46:47], v[112:119] ; cc464070 1dc25d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[52:53], v[120:127] ; cc464078 1de2692c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[44:45], v[50:51], v[128:135] ; cc464080 1e02652c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[44:45], v[48:49], v[136:143] ; cc464088 1e22612c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[44:45], v[46:47], v[144:151] ; cc464090 1e425d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[50:51], v[96:103] ; cc464060 1d82652a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[42:43], v[52:53], v[88:95] ; cc464058 1d62692a
	buffer_load_b128 v[42:45], v37, s[36:39], null offen offset:4096 ; c405c07c 4080482a 00100025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[44:45], v[50:51], v[58:65] ; cc46403a 1cea652c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[42:43], v[48:49], v[168:175] ; cc4640a8 1ea2612a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[48:49], v[16:23] ; cc464010 1c42612c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[42:43], v[52:53], v[152:159] ; cc464098 1e62692a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[46:47], v[176:183] ; cc4640b0 1ec25d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[44:45], v[52:53], v[184:191] ; cc4640b8 1ee2692c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[42:43], v[50:51], v[160:167] ; cc4640a0 1e82652a
	ds_load_b64 v[42:43], v54 offset:2304                       ; d9d80900 2a000036
	ds_load_b64 v[52:53], v54 offset:6400                       ; d9d81900 34000036
	ds_load_b64 v[50:51], v54 offset:10496                      ; d9d82900 32000036
	ds_load_b64 v[48:49], v54 offset:14592                      ; d9d83900 30000036
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[46:47], v[80:87] ; cc464050 1d425d2c
	buffer_load_b128 v[44:47], v34, s[36:39], null offen offset:4608 ; c405c07c 4080482c 00120022
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[48:49], v[112:119] ; cc464070 1dc2612c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[42:43], v[120:127] ; cc464078 1de2552e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[52:53], v[128:135] ; cc464080 1e02692e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[50:51], v[136:143] ; cc464088 1e22652e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[48:49], v[144:151] ; cc464090 1e42612e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[50:51], v[104:111] ; cc464068 1da2652c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[42:43], v[88:95] ; cc464058 1d62552c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[52:53], v[96:103] ; cc464060 1d82692c
	buffer_load_b128 v[44:47], v37, s[36:39], null offen offset:4608 ; c405c07c 4080482c 00120025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[46:47], v[52:53], v[58:65] ; cc46403a 1cea692e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[44:45], v[48:49], v[176:183] ; cc4640b0 1ec2612c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[50:51], v[16:23] ; cc464010 1c42652e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[46:47], v[42:43], v[184:191] ; cc4640b8 1ee2552e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[44:45], v[52:53], v[160:167] ; cc4640a0 1e82692c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[50:51], v[168:175] ; cc4640a8 1ea2652c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[44:45], v[42:43], v[152:159] ; cc464098 1e62552c
	ds_load_b64 v[44:45], v54 offset:2560                       ; d9d80a00 2c000036
	ds_load_b64 v[42:43], v54 offset:6656                       ; d9d81a00 2a000036
	ds_load_b64 v[52:53], v54 offset:10752                      ; d9d82a00 34000036
	ds_load_b64 v[50:51], v54 offset:14848                      ; d9d83a00 32000036
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[48:49], v[80:87] ; cc464050 1d42612e
	buffer_load_b128 v[46:49], v34, s[36:39], null offen offset:5120 ; c405c07c 4080482e 00140022
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[50:51], v[112:119] ; cc464070 1dc2652e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[44:45], v[120:127] ; cc464078 1de25930
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[48:49], v[42:43], v[128:135] ; cc464080 1e025530
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[48:49], v[52:53], v[136:143] ; cc464088 1e226930
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[48:49], v[50:51], v[144:151] ; cc464090 1e426530
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[52:53], v[104:111] ; cc464068 1da2692e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[46:47], v[44:45], v[88:95] ; cc464058 1d62592e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[42:43], v[96:103] ; cc464060 1d82552e
	buffer_load_b128 v[46:49], v37, s[36:39], null offen offset:5120 ; c405c07c 4080482e 00140025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[48:49], v[42:43], v[58:65] ; cc46403a 1cea5530
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[50:51], v[176:183] ; cc4640b0 1ec2652e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[48:49], v[52:53], v[16:23] ; cc464010 1c426930
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[46:47], v[42:43], v[160:167] ; cc4640a0 1e82552e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[48:49], v[44:45], v[184:191] ; cc4640b8 1ee25930
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[46:47], v[52:53], v[168:175] ; cc4640a8 1ea2692e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[44:45], v[152:159] ; cc464098 1e62592e
	ds_load_b64 v[46:47], v54 offset:2816                       ; d9d80b00 2e000036
	ds_load_b64 v[44:45], v54 offset:6912                       ; d9d81b00 2c000036
	ds_load_b64 v[42:43], v54 offset:11008                      ; d9d82b00 2a000036
	ds_load_b64 v[52:53], v54 offset:15104                      ; d9d83b00 34000036
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[50:51], v[80:87] ; cc464050 1d426530
	buffer_load_b128 v[48:51], v34, s[36:39], null offen offset:5632 ; c405c07c 40804830 00160022
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[52:53], v[112:119] ; cc464070 1dc26930
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[46:47], v[120:127] ; cc464078 1de25d32
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[44:45], v[128:135] ; cc464080 1e025932
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[50:51], v[42:43], v[136:143] ; cc464088 1e225532
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[50:51], v[52:53], v[144:151] ; cc464090 1e426932
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[42:43], v[104:111] ; cc464068 1da25530
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[46:47], v[88:95] ; cc464058 1d625d30
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[48:49], v[44:45], v[96:103] ; cc464060 1d825930
	buffer_load_b128 v[48:51], v37, s[36:39], null offen offset:5632 ; c405c07c 40804830 00160025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[50:51], v[44:45], v[58:65] ; cc46403a 1cea5932
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[48:49], v[52:53], v[176:183] ; cc4640b0 1ec26930
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[50:51], v[42:43], v[16:23] ; cc464010 1c425532
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[48:49], v[44:45], v[160:167] ; cc4640a0 1e825930
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[50:51], v[46:47], v[184:191] ; cc4640b8 1ee25d32
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[48:49], v[42:43], v[168:175] ; cc4640a8 1ea25530
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[46:47], v[152:159] ; cc464098 1e625d30
	ds_load_b64 v[48:49], v54 offset:3072                       ; d9d80c00 30000036
	ds_load_b64 v[46:47], v54 offset:7168                       ; d9d81c00 2e000036
	ds_load_b64 v[44:45], v54 offset:11264                      ; d9d82c00 2c000036
	ds_load_b64 v[42:43], v54 offset:15360                      ; d9d83c00 2a000036
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[50:51], v[52:53], v[80:87] ; cc464050 1d426932
	buffer_load_b128 v[50:53], v34, s[36:39], null offen offset:6144 ; c405c07c 40804832 00180022
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[42:43], v[112:119] ; cc464070 1dc25532
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[52:53], v[48:49], v[120:127] ; cc464078 1de26134
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[52:53], v[46:47], v[128:135] ; cc464080 1e025d34
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[44:45], v[136:143] ; cc464088 1e225934
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[42:43], v[144:151] ; cc464090 1e425534
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[50:51], v[44:45], v[104:111] ; cc464068 1da25932
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[50:51], v[48:49], v[88:95] ; cc464058 1d626132
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[46:47], v[96:103] ; cc464060 1d825d32
	buffer_load_b128 v[50:53], v37, s[36:39], null offen offset:6144 ; c405c07c 40804832 00180025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[52:53], v[46:47], v[58:65] ; cc46403a 1cea5d34
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[50:51], v[42:43], v[176:183] ; cc4640b0 1ec25532
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[52:53], v[44:45], v[16:23] ; cc464010 1c425934
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[46:47], v[160:167] ; cc4640a0 1e825d32
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[52:53], v[48:49], v[184:191] ; cc4640b8 1ee26134
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[50:51], v[44:45], v[168:175] ; cc4640a8 1ea25932
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[50:51], v[48:49], v[152:159] ; cc464098 1e626132
	ds_load_b64 v[50:51], v54 offset:3328                       ; d9d80d00 32000036
	ds_load_b64 v[48:49], v54 offset:7424                       ; d9d81d00 30000036
	ds_load_b64 v[46:47], v54 offset:11520                      ; d9d82d00 2e000036
	ds_load_b64 v[44:45], v54 offset:15616                      ; d9d83d00 2c000036
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[52:53], v[42:43], v[80:87] ; cc464050 1d425534
	v_mov_b32_e32 v42, v54                                      ; 7e540336
	buffer_load_b128 v[52:55], v34, s[36:39], null offen offset:6656 ; c405c07c 40804834 001a0022
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[46:47], v[104:111] ; cc464068 1da25d34
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[52:53], v[44:45], v[112:119] ; cc464070 1dc25934
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[50:51], v[120:127] ; cc464078 1de26536
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[48:49], v[128:135] ; cc464080 1e026136
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[54:55], v[46:47], v[136:143] ; cc464088 1e225d36
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[44:45], v[144:151] ; cc464090 1e425936
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[48:49], v[96:103] ; cc464060 1d826134
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[50:51], v[88:95] ; cc464058 1d626534
	buffer_load_b128 v[52:55], v37, s[36:39], null offen offset:6656 ; c405c07c 40804834 001a0025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[54:55], v[48:49], v[58:65] ; cc46403a 1cea6136
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[46:47], v[168:175] ; cc4640a8 1ea25d34
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[46:47], v[16:23] ; cc464010 1c425d36
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[50:51], v[152:159] ; cc464098 1e626534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[52:53], v[44:45], v[176:183] ; cc4640b0 1ec25934
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[50:51], v[184:191] ; cc4640b8 1ee26536
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[48:49], v[160:167] ; cc4640a0 1e826134
	ds_load_b64 v[52:53], v42 offset:3584                       ; d9d80e00 3400002a
	ds_load_b64 v[50:51], v42 offset:7680                       ; d9d81e00 3200002a
	ds_load_b64 v[48:49], v42 offset:11776                      ; d9d82e00 3000002a
	ds_load_b64 v[46:47], v42 offset:15872                      ; d9d83e00 2e00002a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[54:55], v[44:45], v[80:87] ; cc464050 1d425936
	v_mov_b32_e32 v54, v42                                      ; 7e6c032a
	buffer_load_b128 v[42:45], v34, s[36:39], null offen offset:7168 ; c405c07c 4080482a 001c0022
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[48:49], v[104:111] ; cc464068 1da2612a
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[46:47], v[112:119] ; cc464070 1dc25d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[52:53], v[120:127] ; cc464078 1de2692c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[44:45], v[50:51], v[128:135] ; cc464080 1e02652c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[44:45], v[48:49], v[136:143] ; cc464088 1e22612c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[44:45], v[46:47], v[144:151] ; cc464090 1e425d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[50:51], v[96:103] ; cc464060 1d82652a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[42:43], v[52:53], v[88:95] ; cc464058 1d62692a
	buffer_load_b128 v[42:45], v37, s[36:39], null offen offset:7168 ; c405c07c 4080482a 001c0025
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[44:45], v[50:51], v[58:65] ; cc46403a 1cea652c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[42:43], v[48:49], v[168:175] ; cc4640a8 1ea2612a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[48:49], v[16:23] ; cc464010 1c42612c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[46:47], v[176:183] ; cc4640b0 1ec25d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[42:43], v[52:53], v[152:159] ; cc464098 1e62692a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[44:45], v[52:53], v[184:191] ; cc4640b8 1ee2692c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[42:43], v[50:51], v[160:167] ; cc4640a0 1e82652a
	ds_load_b64 v[42:43], v54 offset:3840                       ; d9d80f00 2a000036
	ds_load_b64 v[52:53], v54 offset:7936                       ; d9d81f00 34000036
	ds_load_b64 v[50:51], v54 offset:12032                      ; d9d82f00 32000036
	ds_load_b64 v[48:49], v54 offset:16128                      ; d9d83f00 30000036
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[46:47], v[80:87] ; cc464050 1d425d2c
	buffer_load_b128 v[44:47], v34, s[36:39], null offen offset:7680 ; c405c07c 4080482c 001e0022
	s_wait_loadcnt_dscnt 0x2                                    ; bfc80002
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[52:53], v[96:103] ; cc464060 1d82692c
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[50:51], v[104:111] ; cc464068 1da2652c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[48:49], v[112:119] ; cc464070 1dc2612c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[42:43], v[88:95] ; cc464058 1d62552c
	v_mov_b32_e32 v34, v46                                      ; 7e44032e
	v_mov_b32_e32 v54, v47                                      ; 7e6c032f
	buffer_load_b128 v[44:47], v37, s[36:39], null offen offset:7680 ; c405c07c 4080482c 001e0025
	v_swap_b32 v35, v54                                         ; 7e46cb36
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[52:53], v[128:135] ; cc464080 1e026922
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[34:35], v[50:51], v[136:143] ; cc464088 1e226522
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[34:35], v[48:49], v[144:151] ; cc464090 1e426122
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[42:43], v[120:127] ; cc464078 1de25522
	v_maxmin_num_f32 v55, -4.0, v88, 4.0                        ; d6690037 03dab0f7
	v_maxmin_num_f32 v34, -4.0, v89, 4.0                        ; d6690022 03dab2f7
	v_maxmin_num_f32 v37, -4.0, v90, 4.0                        ; d6690025 03dab4f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_fma_mix_f32 v77, 0xab28, |v55|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624d 0bfe6eff 3728ab28
	v_fma_mix_f32 v35, 0xab28, |v34|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206223 0bfe44ff 3728ab28
	v_fmaak_f32 v55, v55, v77, 0x3f650000                       ; 5a6e9b37 3f650000
	v_maxmin_num_f32 v77, -4.0, v91, 4.0                        ; d669004d 03dab6f7
	v_fmaak_f32 v35, v35, v34, 0x3f650000                       ; 5a464523 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v89, v35, v89 :: v_dual_mul_f32 v88, v88, v55 ; c8c6b323 59586f58
	v_fma_mix_f32 v55, 0xab28, |v37|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe4aff 3728ab28
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v89, -4.0, v92, 4.0                        ; d6690059 03dab8f7
	v_fma_mix_f32 v88, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfe9aff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmaak_f32 v37, v37, v55, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v77, 0x3f650000 ; c8426f25 25589b58 3f650000
	v_maxmin_num_f32 v77, -4.0, v95, 4.0                        ; d669004d 03dabef7
	v_dual_mul_f32 v91, v91, v88 :: v_dual_mul_f32 v90, v90, v37 ; c8c6b15b 5b5a4b5a
	v_maxmin_num_f32 v37, -4.0, v94, 4.0                        ; d6690025 03dabcf7
	v_fma_mix_f32 v88, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfe9aff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v93, 4.0                        ; d669005b 03dabaf7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_fma_mix_f32 v55, 0xab28, |v37|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe4aff 3728ab28
	v_fma_mix_f32 v35, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206223 0bfeb6ff 3728ab28
	v_fmaak_f32 v89, v89, v90, 0x3f650000                       ; 5ab2b559 3f650000
	v_dual_fmaak_f32 v37, v37, v55, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v77, 0x3f650000 ; c8426f25 25589b58 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fmaak_f32 v35, v35, v91, 0x3f650000                       ; 5a46b723 3f650000
	v_maxmin_num_f32 v91, -4.0, v97, 4.0                        ; d669005b 03dac2f7
	v_dual_mul_f32 v95, v95, v88 :: v_dual_mul_f32 v94, v94, v37 ; c8c6b15f 5f5e4b5e
	v_dual_mul_f32 v93, v93, v35 :: v_dual_mul_f32 v92, v92, v89 ; c8c6475d 5d5cb35c
	v_maxmin_num_f32 v89, -4.0, v96, 4.0                        ; d6690059 03dac0f7
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v93, -4.0, v98, 4.0                        ; d669005d 03dac4f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v99, 4.0                        ; d669005f 03dac6f7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v55, -4.0, v102, 4.0                       ; d6690037 03daccf7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842b559 595cb75c 3f650000
	v_fma_mix_f32 v77, 0xab28, |v55|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624d 0bfe6eff 3728ab28
	v_maxmin_num_f32 v90, -4.0, v103, 4.0                       ; d669005a 03dacef7
	v_dual_mul_f32 v97, v97, v92 :: v_dual_mul_f32 v96, v96, v89 ; c8c6b961 6160b360
	v_fmaak_f32 v55, v55, v77, 0x3f650000                       ; 5a6e9b37 3f650000
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v104, 4.0                       ; d669005c 03dad0f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v100, 4.0                       ; d6690061 03dac8f7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_mul_f32 v102, v102, v55 ; c846b55b 5b666f66 3f650000
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_maxmin_num_f32 v94, -4.0, v105, 4.0                       ; d669005e 03dad2f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_dual_mul_f32 v99, v99, v96 :: v_dual_mul_f32 v98, v98, v93 ; c8c6c163 6362bb62
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v96, -4.0, v106, 4.0                       ; d6690060 03dad4f7
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v101, 4.0                       ; d6690063 03dacaf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 ; c842bd5f 5f5cbb5c 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_fma_mix_f32 v37, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfec6ff 3728ab28
	v_fmaak_f32 v97, v97, v98, 0x3f650000                       ; 5ac2c561 3f650000
	v_maxmin_num_f32 v98, -4.0, v107, 4.0                       ; d6690062 03dad6f7
	v_dual_mul_f32 v105, v105, v95 :: v_dual_mul_f32 v104, v104, v92 ; c8c6bf69 6968b968
	v_fmaak_f32 v37, v37, v99, 0x3f650000                       ; 5a4ac725 3f650000
	v_dual_mul_f32 v103, v103, v91 :: v_dual_mul_f32 v100, v100, v97 ; c8c6b767 6764c364
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v104, -4.0, v110, 4.0                      ; d6690068 03dadcf7
	v_mul_f32_e32 v101, v101, v37                               ; 10ca4b65
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v97, 0x3f650000 ; c842c563 6360c360 3f650000
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v100, -4.0, v108, 4.0                      ; d6690064 03dad8f7
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v102, -4.0, v109, 4.0                      ; d6690066 03dadaf7
	v_dual_mul_f32 v107, v107, v99 :: v_dual_mul_f32 v106, v106, v96 ; c8c6c76b 6b6ac16a
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_maxmin_num_f32 v37, -4.0, v115, 4.0                       ; d6690025 03dae6f7
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v106, -4.0, v111, 4.0                      ; d669006a 03dadef7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c842cd67 6764cb64 3f650000
	v_fma_mix_f32 v55, 0xab28, |v37|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe4aff 3728ab28
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_dual_mul_f32 v109, v109, v103 :: v_dual_mul_f32 v108, v108, v100 ; c8c6cf6d 6d6cc96c
	v_maxmin_num_f32 v77, -4.0, v116, 4.0                       ; d669004d 03dae8f7
	v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 ; c842d56b 6b68d368 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v108, -4.0, v112, 4.0                      ; d669006c 03dae0f7
	v_maxmin_num_f32 v94, -4.0, v117, 4.0                       ; d669005e 03daeaf7
	v_fma_mix_f32 v93, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfe9aff 3728ab28
	v_dual_mul_f32 v111, v111, v107 :: v_dual_mul_f32 v110, v110, v104 ; c8c6d76f 6f6ed16e
	v_maxmin_num_f32 v96, -4.0, v118, 4.0                       ; d6690060 03daecf7
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_maxmin_num_f32 v98, -4.0, v119, 4.0                       ; d6690062 03daeef7
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_fmaak_f32 v77, v77, v93, 0x3f650000                       ; 5a9abb4d 3f650000
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v110, -4.0, v113, 4.0                      ; d669006e 03dae2f7
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_maxmin_num_f32 v100, -4.0, v120, 4.0                      ; d6690064 03daf0f7
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_maxmin_num_f32 v102, -4.0, v121, 4.0                      ; d6690066 03daf2f7
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v97, 0x3f650000 ; c842c563 6360c360 3f650000
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_maxmin_num_f32 v104, -4.0, v122, 4.0                      ; d6690068 03daf4f7
	v_fmaak_f32 v111, v111, v110, 0x3f650000                    ; 5adedd6f 3f650000
	v_maxmin_num_f32 v106, -4.0, v123, 4.0                      ; d669006a 03daf6f7
	v_dual_mul_f32 v119, v119, v99 :: v_dual_mul_f32 v118, v118, v96 ; c8c6c777 7776c176
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c842cd67 6764cb64 3f650000
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_dual_mul_f32 v113, v113, v111 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c8c2df71 716cdb6c 3f650000
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v125, 4.0                      ; d669006e 03dafaf7
	v_dual_mul_f32 v121, v121, v103 :: v_dual_mul_f32 v120, v120, v100 ; c8c6cf79 7978c978
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_fmaak_f32 v55, v55, v37, 0x3f650000 :: v_dual_mul_f32 v112, v112, v108 ; c8464b37 3770d970 3f650000
	v_maxmin_num_f32 v108, -4.0, v124, 4.0                      ; d669006c 03daf8f7
	v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 ; c842d56b 6b68d368 3f650000
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v114, 4.0                      ; d6690070 03dae4f7
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_dual_mul_f32 v123, v123, v107 :: v_dual_mul_f32 v122, v122, v104 ; c8c6d77b 7b7ad17a
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
	v_dual_mul_f32 v115, v115, v55 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c8c26f73 7370e370 3f650000
	v_dual_mul_f32 v125, v125, v111 :: v_dual_mul_f32 v124, v124, v108 ; c8c6df7d 7d7cd97c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_mul_f32 v114, v114, v112 ; c846bd5f 5f72e172 3f650000
	v_maxmin_num_f32 v112, -4.0, v126, 4.0                      ; d6690070 03dafcf7
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v127, 4.0                      ; d6690072 03dafef7
	v_dual_mul_f32 v117, v117, v95 :: v_dual_mul_f32 v116, v116, v77 ; c8c6bf75 75749b74
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v120, -4.0, v130, 4.0                      ; d6690078 03db04f7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v122, -4.0, v131, 4.0                      ; d669007a 03db06f7
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v116, -4.0, v128, 4.0                      ; d6690074 03db00f7
	v_maxmin_num_f32 v118, -4.0, v129, 4.0                      ; d6690076 03db02f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v124, -4.0, v132, 4.0                      ; d669007c 03db08f7
	v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c842f57b 7b78f378 3f650000
	v_dual_mul_f32 v127, v127, v115 :: v_dual_mul_f32 v126, v126, v112 ; c8c6e77f 7f7ee17e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v119, v119, v118, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c842ed77 7774eb74 3f650000
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_dual_mul_f32 v131, v131, v123 :: v_dual_mul_f32 v130, v130, v120 ; c8c6f783 8382f182
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v133, 4.0                      ; d669007e 03db0af7
	v_dual_mul_f32 v129, v129, v119 :: v_dual_mul_f32 v128, v128, v116 ; c8c6ef81 8180e980
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 ; c842fd7f 7f7cfb7c 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v133, v133, v127 :: v_dual_mul_f32 v132, v132, v124 ; c8c6ff85 8584f984
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[44:45], v[48:49], v[176:183] ; cc4640b0 1ec2612c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[48:49], v[80:87] ; cc464050 1d42612e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[50:51], v[168:175] ; cc4640a8 1ea2652c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[44:45], v[42:43], v[152:159] ; cc464098 1e62552c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[46:47], v[42:43], v[184:191] ; cc4640b8 1ee2552e
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v128, -4.0, v134, 4.0                      ; d6690080 03db0cf7
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v130, -4.0, v135, 4.0                      ; d6690082 03db0ef7
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[46:47], v[52:53], v[58:65] ; cc46403a 1cea692e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[50:51], v[16:23] ; cc464010 1c42652e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[44:45], v[52:53], v[160:167] ; cc4640a0 1e82692c
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v132, -4.0, v136, 4.0                      ; d6690084 03db10f7
	v_maxmin_num_f32 v37, -4.0, v139, 4.0                       ; d6690025 03db16f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_maxmin_num_f32 v48, -4.0, v141, 4.0                       ; d6690030 03db1af7
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v45, 0xab28, |v37|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe4aff 3728ab28
	v_maxmin_num_f32 v46, -4.0, v140, 4.0                       ; d669002e 03db18f7
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
	v_maxmin_num_f32 v52, -4.0, v143, 4.0                       ; d6690034 03db1ef7
	v_fma_mix_f32 v49, 0xab28, |v48|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206231 0bfe60ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
	v_fma_mix_f32 v47, 0xab28, |v46|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622f 0bfe5cff 3728ab28
	v_dual_mul_f32 v135, v135, v131 :: v_dual_mul_f32 v134, v134, v128 ; c8c70787 87870186
	v_maxmin_num_f32 v50, -4.0, v142, 4.0                       ; d6690032 03db1cf7
	v_fma_mix_f32 v53, 0xab28, |v52|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206235 0bfe68ff 3728ab28
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v134, -4.0, v137, 4.0                      ; d6690086 03db12f7
	v_fma_mix_f32 v51, 0xab28, |v50|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206233 0bfe64ff 3728ab28
	v_maxmin_num_f32 v55, -4.0, v144, 4.0                       ; d6690037 03db20f7
	v_maxmin_num_f32 v96, -4.0, v145, 4.0                       ; d6690060 03db22f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v77, 0xab28, |v55|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624d 0bfe6eff 3728ab28
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_maxmin_num_f32 v98, -4.0, v146, 4.0                       ; d6690062 03db24f7
	v_fmaak_f32 v135, v135, v134, 0x3f650000                    ; 5b0f0d87 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_maxmin_num_f32 v100, -4.0, v147, 4.0                      ; d6690064 03db26f7
	v_dual_mul_f32 v137, v137, v135 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8c30f89 89850b84 3f650000
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_dual_fmaak_f32 v45, v45, v37, 0x3f650000 :: v_dual_mul_f32 v136, v136, v132 ; c8464b2d 2d890988 3f650000
	v_maxmin_num_f32 v102, -4.0, v148, 4.0                      ; d6690066 03db28f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_maxmin_num_f32 v136, -4.0, v138, 4.0                      ; d6690088 03db14f7
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_maxmin_num_f32 v104, -4.0, v149, 4.0                      ; d6690068 03db2af7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_maxmin_num_f32 v106, -4.0, v150, 4.0                      ; d669006a 03db2cf7
	v_dual_mul_f32 v139, v45, v139 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c8c3172d 8b891388 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_maxmin_num_f32 v108, -4.0, v151, 4.0                      ; d669006c 03db2ef7
	v_dual_fmaak_f32 v49, v48, v49, 0x3f650000 :: v_dual_mul_f32 v138, v138, v136 ; c8466330 318b118a 3f650000
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v141, v141, v49 :: v_dual_fmaak_f32 v46, v46, v47, 0x3f650000 ; c8c2638d 8d2e5f2e 3f650000
	v_maxmin_num_f32 v110, -4.0, v152, 4.0                      ; d669006e 03db30f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v53, v53, v52, 0x3f650000 :: v_dual_mul_f32 v140, v140, v46 ; c8466935 358c5d8c 3f650000
	v_maxmin_num_f32 v112, -4.0, v153, 4.0                      ; d6690070 03db32f7
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v53 :: v_dual_fmaak_f32 v50, v50, v51, 0x3f650000 ; c8c26b8f 8f326732 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v114, -4.0, v154, 4.0                      ; d6690072 03db34f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v55, v55, v77, 0x3f650000 :: v_dual_mul_f32 v142, v142, v50 ; c8469b37 378e658e 3f650000
	v_maxmin_num_f32 v116, -4.0, v155, 4.0                      ; d6690074 03db36f7
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 :: v_dual_mul_f32 v144, v144, v55 ; c846c161 61906f90 3f650000
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_maxmin_num_f32 v118, -4.0, v156, 4.0                      ; d6690076 03db38f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_mul_f32 v145, v145, v97 :: v_dual_fmaak_f32 v98, v98, v99, 0x3f650000 ; c8c2c391 9162c762 3f650000
	v_maxmin_num_f32 v120, -4.0, v157, 4.0                      ; d6690078 03db3af7
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_dual_fmaak_f32 v101, v101, v100, 0x3f650000 :: v_dual_mul_f32 v146, v146, v98 ; c846c965 6592c592 3f650000
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_maxmin_num_f32 v122, -4.0, v158, 4.0                      ; d669007a 03db3cf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 :: v_dual_mul_f32 v147, v147, v101 ; c846cf66 6692cb93 3f650000
	v_maxmin_num_f32 v124, -4.0, v159, 4.0                      ; d669007c 03db3ef7
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v105, v105, v104, 0x3f650000 :: v_dual_mul_f32 v148, v148, v102 ; c846d169 6994cd94 3f650000
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_maxmin_num_f32 v126, -4.0, v160, 4.0                      ; d669007e 03db40f7
	v_dual_fmaak_f32 v106, v106, v107, 0x3f650000 :: v_dual_mul_f32 v149, v149, v105 ; c846d76a 6a94d395 3f650000
	v_maxmin_num_f32 v128, -4.0, v161, 4.0                      ; d6690080 03db42f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_mul_f32 v150, v150, v106 ; c846d96d 6d96d596 3f650000
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v162, 4.0                      ; d6690082 03db44f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 :: v_dual_mul_f32 v151, v151, v109 ; c846df6e 6e96db97 3f650000
	v_maxmin_num_f32 v132, -4.0, v163, 4.0                      ; d6690084 03db46f7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_mul_f32 v152, v152, v110 ; c846e171 7198dd98 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v134, -4.0, v164, 4.0                      ; d6690086 03db48f7
	v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 :: v_dual_mul_f32 v153, v153, v113 ; c846e772 7298e399 3f650000
	v_maxmin_num_f32 v136, -4.0, v165, 4.0                      ; d6690088 03db4af7
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_dual_fmaak_f32 v117, v117, v116, 0x3f650000 :: v_dual_mul_f32 v154, v154, v114 ; c846e975 759ae59a 3f650000
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v138, -4.0, v166, 4.0                      ; d669008a 03db4cf7
	v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 :: v_dual_mul_f32 v155, v155, v117 ; c846ef76 769aeb9b 3f650000
	v_maxmin_num_f32 v140, -4.0, v167, 4.0                      ; d669008c 03db4ef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_mul_f32 v156, v156, v118 ; c846f179 799ced9c 3f650000
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v168, 4.0                      ; d669008e 03db50f7
	v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 :: v_dual_mul_f32 v157, v157, v121 ; c846f77a 7a9cf39d 3f650000
	v_maxmin_num_f32 v144, -4.0, v169, 4.0                      ; d6690090 03db52f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 :: v_dual_mul_f32 v158, v158, v122 ; c846f97d 7d9ef59e 3f650000
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v170, 4.0                      ; d6690092 03db54f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v126, v126, v127, 0x3f650000 :: v_dual_mul_f32 v159, v159, v125 ; c846ff7e 7e9efb9f 3f650000
	v_maxmin_num_f32 v148, -4.0, v171, 4.0                      ; d6690094 03db56f7
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_mul_f32 v160, v160, v126 ; c8470181 81a0fda0 3f650000
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v172, 4.0                      ; d6690096 03db58f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 :: v_dual_mul_f32 v161, v161, v129 ; c8470782 82a103a1 3f650000
	v_maxmin_num_f32 v152, -4.0, v173, 4.0                      ; d6690098 03db5af7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_mul_f32 v162, v162, v130 ; c8470985 85a305a2 3f650000
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v174, 4.0                      ; d669009a 03db5cf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 :: v_dual_mul_f32 v163, v163, v133 ; c8470f86 86a30ba3 3f650000
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b2
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_mul_f32 v164, v164, v134 ; c8471189 89a50da4 3f650000
	s_lshr_b32 s16, s16, 2                                      ; 85108210
	v_lshl_add_u32 v156, v1, 10, s16                            ; d646009c 00411501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_mul_f32 v165, v165, v137 ; c847178a 8aa513a5 3f650000
	v_add_lshl_u32 v156, v156, v54, 2                           ; d647009c 020a6d9c
	buffer_load_b128 v[96:99], v156, s[36:39], null offen       ; c405c07c 40804860 0000009c
	v_maxmin_num_f32 v157, -4.0, v175, 4.0                      ; d669009d 03db5ef7
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_mul_f32 v166, v166, v138 ; c847198d 8da715a6 3f650000
	v_maxmin_num_f32 v159, -4.0, v176, 4.0                      ; d669009f 03db60f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 :: v_dual_mul_f32 v167, v167, v141 ; c8471f8e 8ea71ba7 3f650000
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	buffer_load_b128 v[100:103], v156, s[36:39], null offen offset:512 ; c405c07c 40804864 0002009c
	v_maxmin_num_f32 v161, -4.0, v177, 4.0                      ; d66900a1 03db62f7
	v_maxmin_num_f32 v163, -4.0, v178, 4.0                      ; d66900a3 03db64f7
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v168, v168, v142 ; c8472191 91a91da8 3f650000
	v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 :: v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 ; c8433b9e 9e9f419f 3f650000
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v179, 4.0                      ; d66900a5 03db66f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_mul_f32 v169, v169, v145 ; c8472792 92a923a9 3f650000
	buffer_load_b128 v[108:111], v156, s[36:39], null offen offset:1024 ; c405c07c 4080486c 0004009c
	v_dual_mul_f32 v176, v176, v159 :: v_dual_mul_f32 v175, v175, v158 ; c8c73fb0 b0af3daf
	v_maxmin_num_f32 v167, -4.0, v180, 4.0                      ; d66900a7 03db68f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c84349a3 a3a343a2 3f650000
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_maxmin_num_f32 v169, -4.0, v181, 4.0                      ; d66900a9 03db6af7
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v170, v170, v146 ; c8472995 95ab25aa 3f650000
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_fmaak_f32 v166, v166, v165, 0x3f650000                    ; 5b4d4ba6 3f650000
	buffer_load_b128 v[112:115], v156, s[36:39], null offen offset:1536 ; c405c07c 40804870 0006009c
	v_dual_mul_f32 v178, v178, v163 :: v_dual_mul_f32 v177, v177, v162 ; c8c747b2 b2b145b1
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_mul_f32 v171, v171, v149 ; c8472f96 96ab2bab 3f650000
	v_mul_f32_e32 v179, v179, v166                              ; 11674db3
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v172, v172, v150 ; c8473199 99ad2dac 3f650000
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_maxmin_num_f32 v171, -4.0, v182, 4.0                      ; d66900ab 03db6cf7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	buffer_load_b128 v[116:119], v156, s[36:39], null offen offset:2048 ; c405c07c 40804874 0008009c
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_mul_f32 v173, v173, v153 ; c847379a 9aad33ad 3f650000
	v_maxmin_num_f32 v177, -4.0, v185, 4.0                      ; d66900b1 03db72f7
	v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 :: v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 ; c84353aa aaa751a7 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_mul_f32_e32 v174, v174, v154                              ; 115d35ae
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_maxmin_num_f32 v173, -4.0, v183, 4.0                      ; d66900ad 03db6ef7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	buffer_load_b128 v[120:123], v156, s[36:39], null offen offset:2560 ; c405c07c 40804878 000a009c
	v_maxmin_num_f32 v179, -4.0, v186, 4.0                      ; d66900b3 03db74f7
	v_dual_mul_f32 v181, v181, v170 :: v_dual_mul_f32 v180, v180, v167 ; c8c755b5 b5b54fb4
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_maxmin_num_f32 v175, -4.0, v184, 4.0                      ; d66900af 03db70f7
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_maxmin_num_f32 v181, -4.0, v187, 4.0                      ; d66900b5 03db76f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	buffer_load_b128 v[124:127], v156, s[36:39], null offen offset:3072 ; c405c07c 4080487c 000c009c
	v_dual_fmaak_f32 v174, v174, v173, 0x3f650000 :: v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 ; c8435bae aeab59ab 3f650000
	v_fmaak_f32 v179, v179, v180, 0x3f650000                    ; 5b6769b3 3f650000
	v_dual_fmaak_f32 v178, v178, v177, 0x3f650000 :: v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 ; c84363b2 b2af61af 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_mul_f32 v183, v183, v174 :: v_dual_mul_f32 v182, v182, v171 ; c8c75db7 b7b757b6
	v_mul_f32_e32 v186, v186, v179                              ; 117567ba
	v_dual_mul_f32 v185, v185, v178 :: v_dual_mul_f32 v184, v184, v175 ; c8c765b9 b9b95fb8
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_maxmin_num_f32 v183, -4.0, v188, 4.0                      ; d66900b7 03db78f7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
(invalid instruction)                                        ; d769006a
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_maxmin_num_f32 v185, -4.0, v189, 4.0                      ; d66900b9 03db7af7
	buffer_load_b128 v[128:131], v156, s[36:39], null offen offset:3584 ; c405c07c 40804880 000e009c
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_maxmin_num_f32 v55, -4.0, v58, 4.0                        ; d6690037 03da74f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v183, v183, v184, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v181, 0x3f650000 ; c84371b7 b7b76bb6 3f650000
	v_fma_mix_f32 v77, 0xab28, |v55|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624d 0bfe6eff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v59, 4.0                       ; d6690084 03da76f7
	v_dual_mul_f32 v188, v188, v183 :: v_dual_mul_f32 v187, v187, v182 ; c8c76fbc bcbb6dbb
	v_fmaak_f32 v55, v55, v77, 0x3f650000                       ; 5a6e9b37 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v134, -4.0, v60, 4.0                       ; d6690086 03da78f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769406a
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v187, -4.0, v190, 4.0                      ; d66900bb 03db7cf7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v61, 4.0                       ; d6690088 03da7af7
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_mul_f32 v58, v58, v55 ; c8470985 853a6f3a 3f650000
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_maxmin_num_f32 v138, -4.0, v62, 4.0                       ; d669008a 03da7cf7
	v_fmaak_f32 v186, v186, v185, 0x3f650000                    ; 5b7573ba 3f650000
	v_maxmin_num_f32 v140, -4.0, v63, 4.0                       ; d669008c 03da7ef7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v59, v59, v133 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c8c30b3b 3b870f86 3f650000
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v64, 4.0                       ; d669008e 03da80f7
	v_mul_f32_e32 v189, v189, v186                              ; 117b75bd
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v65, 4.0                       ; d6690090 03da82f7
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_mul_f32 v60, v60, v134 ; c8471189 893d0d3c 3f650000
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v16, 4.0                       ; d6690092 03da20f7
(invalid instruction)                                        ; d769006b
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_maxmin_num_f32 v189, -4.0, v191, 4.0                      ; d66900bd 03db7ef7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v17, 4.0                       ; d6690094 03da22f7
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_mul_f32 v61, v61, v137 ; c847178a 8a3d133d 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v18, 4.0                       ; d6690096 03da24f7
	v_fma_mix_f32 v37, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bff7aff 3728ab28
	v_fmaak_f32 v187, v187, v188, 0x3f650000                    ; 5b7779bb 3f650000
	v_maxmin_num_f32 v152, -4.0, v19, 4.0                       ; d6690098 03da26f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_mul_f32 v62, v62, v138 ; c847198d 8d3f153e 3f650000
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v20, 4.0                       ; d669009a 03da28f7
	v_fmaak_f32 v37, v37, v189, 0x3f650000                      ; 5a4b7b25 3f650000
	v_mul_f32_e32 v190, v190, v187                              ; 117d77be
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v21, 4.0                       ; d669009c 03da2af7
	v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 :: v_dual_mul_f32 v63, v63, v141 ; c8471f8e 8e3f1b3f 3f650000
	v_maxmin_num_f32 v158, -4.0, v22, 4.0                       ; d669009e 03da2cf7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_lshrrev_b32_e32 v162, 4, v36                              ; 33444884
	v_mul_f32_e32 v191, v191, v37                               ; 117e4bbf
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v64, v64, v142 ; c8472191 91411d40 3f650000
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v23, 4.0                       ; d66900a0 03da2ef7
(invalid instruction)                                        ; d769406b
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_mul_f32 v65, v65, v145 ; c8472792 92412341 3f650000
	v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c8433f9e 9e9d399d 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v16, v16, v146 ; c8472995 95112510 3f650000
	v_dual_mul_f32 v21, v21, v157 :: v_dual_lshlrev_b32 v162, 3, v162 ; c8e33b15 15a34483
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_mul_f32 v17, v17, v149 ; c8472f96 96112b11 3f650000
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v18, v18, v150 ; c8473199 99132d12 3f650000
	v_maxmin_num_f32 v165, -4.0, v80, 4.0                       ; d66900a5 03daa0f7
	v_fma_mix_f32 v164, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff40ff 3728ab28
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_mul_f32 v19, v19, v153 ; c847379a 9a133313 3f650000
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_mul_f32 v20, v20, v154 :: v_dual_and_b32 v161, 0xffffffe0, v0 ; c8e53514 14a000ff ffffffe0
	v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v160, 0x3f650000 ; c8434da5 a5a541a4 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	v_add3_u32 v163, v162, s9, v161                             ; d65500a3 068413a2
	v_dual_mul_f32 v80, v80, v165 :: v_dual_mul_f32 v23, v23, v164 ; c8c74b50 50174917
	v_dual_mul_f32 v22, v22, v158 :: v_dual_lshlrev_b32 v163, 2, v163 ; c8e33d16 16a34682
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v163, s[32:35], null offen       ; c405c07c 4080403c 000000a3
	buffer_load_b128 v[20:23], v163, s[32:35], null offen offset:16 ; c405c07c 40804014 000010a3
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_maxmin_num_f32 v167, -4.0, v81, 4.0                       ; d66900a7 03daa2f7
	v_maxmin_num_f32 v169, -4.0, v82, 4.0                       ; d66900a9 03daa4f7
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_maxmin_num_f32 v171, -4.0, v83, 4.0                       ; d66900ab 03daa6f7
	v_maxmin_num_f32 v173, -4.0, v84, 4.0                       ; d66900ad 03daa8f7
	v_maxmin_num_f32 v175, -4.0, v85, 4.0                       ; d66900af 03daaaf7
	v_maxmin_num_f32 v177, -4.0, v86, 4.0                       ; d66900b1 03daacf7
	v_maxmin_num_f32 v179, -4.0, v87, 4.0                       ; d66900b3 03daaef7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fmaak_f32 v168, v168, v167, 0x3f650000                    ; 5b514fa8 3f650000
	v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 ; c84357ac aca955a9 3f650000
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 ; c8435fb0 b0ad5dad 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 ; c84367b4 b4b165b1 3f650000
	v_mul_f32_e32 v81, v81, v168                                ; 10a35151
	v_dual_mul_f32 v83, v83, v172 :: v_dual_mul_f32 v82, v82, v169 ; c8c75953 53535352
	v_dual_mul_f32 v85, v85, v176 :: v_dual_mul_f32 v84, v84, v173 ; c8c76155 55555b54
	v_dual_mul_f32 v87, v87, v180 :: v_dual_mul_f32 v86, v86, v177 ; c8c76957 57576356
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[28:29], 0 ; cc464098 1a023960
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[98:99], v[26:27], 0 ; cc4640a8 1a023562
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[56:57], 0 ; cc4640b8 1a027162
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[98:99], v[68:69], 0 ; cc4640b0 1a028962
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[96:97], v[68:69], 0 ; cc464088 1a028960
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[96:97], v[26:27], 0 ; cc464050 1a023560
	v_mov_b32_e32 v27, v162                                     ; 7e3603a2
	v_dual_mov_b32 v37, v163 :: v_dual_mov_b32 v26, v161        ; ca1001a3 251a01a1
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[56:57], 0 ; cc464090 1a027160
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[98:99], v[28:29], 0 ; cc4640a0 1a023962
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[100:101], v[40:41], v[152:159] ; cc464098 1e625164
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[102:103], v[30:31], v[168:175] ; cc4640a8 1ea23d66
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[102:103], v[32:33], v[176:183] ; cc4640b0 1ec24166
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[100:101], v[32:33], v[136:143] ; cc464088 1e224164
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[100:101], v[30:31], v[80:87] ; cc464050 1d423d64
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[110:111], v[8:9], v[168:175] ; cc4640a8 1ea2116e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[110:111], v[10:11], v[176:183] ; cc4640b0 1ec2156e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[102:103], v[38:39], v[184:191] ; cc4640b8 1ee24d66
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[10:11], v[136:143] ; cc464088 1e22156c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[108:109], v[8:9], v[80:87] ; cc464050 1d42116c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v37, s[32:35], null offen offset:64 ; c405c07c 40804008 00004025
	buffer_load_b128 v[28:31], v37, s[32:35], null offen offset:80 ; c405c07c 4080401c 00005025
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[38:39], v[144:151] ; cc464090 1e424d64
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[102:103], v[40:41], v[160:167] ; cc4640a0 1e825166
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[70:71], v[152:159] ; cc464098 1e628d6c
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[114:115], v[78:79], v[168:175] ; cc4640a8 1ea29d72
	v_lshlrev_b32_e32 v38, 11, v1                               ; 304c028b
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[12:13], v[184:191] ; cc4640b8 1ee2196e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[24:25], v[176:183] ; cc4640b0 1ec23172
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[24:25], v[136:143] ; cc464088 1e223170
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[112:113], v[78:79], v[80:87] ; cc464050 1d429d70
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[12:13], v[144:151] ; cc464090 1e42196c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[110:111], v[70:71], v[160:167] ; cc4640a0 1e828d6e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[66:67], v[152:159] ; cc464098 1e628570
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v39, v54, s5, v38                                ; d6550027 04980b36
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[118:119], v[34:35], v[168:175] ; cc4640a8 1ea24576
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[6:7], v[184:191] ; cc4640b8 1ee20d72
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[118:119], v[88:89], v[176:183] ; cc4640b0 1ec2b176
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[116:117], v[88:89], v[136:143] ; cc464088 1e22b174
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[116:117], v[34:35], v[80:87] ; cc464050 1d424574
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[112:113], v[6:7], v[144:151] ; cc464090 1e420d70
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[114:115], v[66:67], v[160:167] ; cc4640a0 1e828572
	v_lshlrev_b32_e32 v39, 2, v39                               ; 304e4e82
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[92:93], v[152:159] ; cc464098 1e62b974
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[122:123], v[94:95], v[168:175] ; cc4640a8 1ea2bd7a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[90:91], v[184:191] ; cc4640b8 1ee2b576
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[122:123], v[42:43], v[176:183] ; cc4640b0 1ec2557a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[120:121], v[42:43], v[136:143] ; cc464088 1e225578
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[120:121], v[94:95], v[80:87] ; cc464050 1d42bd78
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[116:117], v[90:91], v[144:151] ; cc464090 1e42b574
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[118:119], v[92:93], v[160:167] ; cc4640a0 1e82b976
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[120:121], v[46:47], v[152:159] ; cc464098 1e625d78
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[126:127], v[48:49], v[168:175] ; cc4640a8 1ea2617e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[122:123], v[44:45], v[184:191] ; cc4640b8 1ee2597a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[126:127], v[50:51], v[176:183] ; cc4640b0 1ec2657e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[124:125], v[50:51], v[136:143] ; cc464088 1e22657c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[124:125], v[48:49], v[80:87] ; cc464050 1d42617c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[120:121], v[44:45], v[144:151] ; cc464090 1e425978
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[122:123], v[46:47], v[160:167] ; cc4640a0 1e825d7a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[124:125], v[104:105], v[152:159] ; cc464098 1e62d17c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[130:131], v[106:107], v[168:175] ; cc4640a8 1ea2d582
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[126:127], v[52:53], v[184:191] ; cc4640b8 1ee2697e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[130:131], v[58:59], v[176:183] ; cc4640b0 1ec27582
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[128:129], v[58:59], v[136:143] ; cc464088 1e227580
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[128:129], v[106:107], v[80:87] ; cc464050 1d42d580
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[124:125], v[52:53], v[144:151] ; cc464090 1e42697c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[126:127], v[104:105], v[160:167] ; cc4640a0 1e82d17e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[128:129], v[18:19], v[152:159] ; cc464098 1e622580
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[130:131], v[16:17], v[184:191] ; cc4640b8 1ee22182
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	buffer_load_b128 v[32:35], v39, s[36:39], null offen        ; c405c07c 40804820 00000027
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[128:129], v[16:17], v[144:151] ; cc464090 1e422180
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[130:131], v[18:19], v[160:167] ; cc4640a0 1e822582
	v_add_nc_u32_e32 v46, 0x4000, v73                           ; 4a5c92ff 00004000
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	ds_store_2addr_b64 v46, v[6:7], v[24:25] offset1:32         ; d9382000 0018062e
	buffer_load_b128 v[48:51], v39, s[36:39], null offen offset:512 ; c405c07c 40804830 00020027
	v_add_nc_u32_e32 v47, 0x5000, v73                           ; 4a5e92ff 00005000
	v_add_nc_u32_e32 v52, 0x6000, v73                           ; 4a6892ff 00006000
	v_add_nc_u32_e32 v53, 0x7000, v73                           ; 4a6a92ff 00007000
	ds_store_2addr_b64 v47, v[12:13], v[40:41] offset1:32       ; d9382000 00280c2f
	ds_store_2addr_b64 v52, v[16:17], v[42:43] offset1:32       ; d9382000 002a1034
	ds_store_2addr_b64 v53, v[18:19], v[44:45] offset1:32       ; d9382000 002c1235
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	buffer_load_b128 v[16:19], v39, s[36:39], null offen offset:1024 ; c405c07c 40804810 00040027
	v_mad_u32_u24 v55, s59, 0x500, v2                           ; d60b0037 0409fe3b 00000500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v55, v55, v72                              ; 4a6e9137
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[6:7], v55                                     ; d9d80000 06000037
	ds_load_b64 v[12:13], v55 offset:4096                       ; d9d81000 0c000037
	ds_load_b64 v[24:25], v55 offset:8192                       ; d9d82000 18000037
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[40:41], v6                           ; 7e50dd06
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v65, v41, v61 :: v_dual_mul_f32 v64, v40, v60 ; c8c67b29 41407928
	v_cvt_pk_f32_fp8_e32 v[40:41], v134                         ; 7e50dd86
	v_dual_mul_f32 v67, v41, v63 :: v_dual_mul_f32 v66, v40, v62 ; c8c67f29 43427d28
	buffer_load_b128 v[40:43], v39, s[36:39], null offen offset:1536 ; c405c07c 40804828 00060027
	v_cvt_pk_f32_fp8_e32 v[44:45], v7                           ; 7e58dd07
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v69, v45, v21 :: v_dual_mul_f32 v68, v44, v20 ; c8c62b2d 4544292c
	ds_load_b64 v[44:45], v55 offset:12288                      ; d9d83000 2c000037
	buffer_load_b128 v[56:59], v39, s[36:39], null offen offset:2048 ; c405c07c 40804838 00080027
	ds_load_b64 v[78:79], v55 offset:256                        ; d9d80100 4e000037
	buffer_load_b128 v[92:95], v39, s[36:39], null offen offset:2560 ; c405c07c 4080485c 000a0027
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v71, v7, v23 :: v_dual_mul_f32 v70, v6, v22  ; c8c62f07 47462d06
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[6:7], v12                            ; 7e0cdd0c
	v_dual_mul_f32 v81, v7, v61 :: v_dual_mul_f32 v80, v6, v60  ; c8c67b07 51507906
	buffer_load_b128 v[96:99], v39, s[36:39], null offen offset:3072 ; c405c07c 40804860 000c0027
	v_cvt_pk_f32_fp8_e32 v[6:7], v140                           ; 7e0cdd8c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v83, v7, v63 :: v_dual_mul_f32 v82, v6, v62  ; c8c67f07 53527d06
	v_cvt_pk_f32_fp8_e32 v[6:7], v13                            ; 7e0cdd0d
	v_cvt_pk_f32_fp8_e32 v[12:13], v141                         ; 7e18dd8d
	v_dual_mul_f32 v85, v7, v21 :: v_dual_mul_f32 v84, v6, v20  ; c8c62b07 55542906
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v24                            ; 7e0cdd18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v89, v7, v61 :: v_dual_mul_f32 v88, v6, v60  ; c8c67b07 59587906
	v_cvt_pk_f32_fp8_e32 v[6:7], v152                           ; 7e0cdd98
	v_dual_mul_f32 v91, v7, v63 :: v_dual_mul_f32 v90, v6, v62  ; c8c67f07 5b5a7d06
	v_cvt_pk_f32_fp8_e32 v[6:7], v25                            ; 7e0cdd19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_dual_mul_f32 v87, v13, v23 :: v_dual_mul_f32 v100, v6, v20 ; c8c62f0d 57642906
	v_dual_mul_f32 v101, v7, v21 :: v_dual_mul_f32 v86, v12, v22 ; c8c62b07 65562d0c
	ds_load_b64 v[12:13], v55 offset:4352                       ; d9d81100 0c000037
	v_cvt_pk_f32_fp8_e32 v[6:7], v153                           ; 7e0cdd99
	v_dual_mul_f32 v103, v7, v23 :: v_dual_mul_f32 v102, v6, v22 ; c8c62f07 67662d06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v44                            ; 7e0cdd2c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v105, v7, v61                                 ; 10d27b07
	v_mul_f32_e32 v104, v6, v60                                 ; 10d07906
	v_cvt_pk_f32_fp8_e32 v[6:7], v172                           ; 7e0cddac
	v_dual_mul_f32 v107, v7, v63 :: v_dual_mul_f32 v106, v6, v62 ; c8c67f07 6b6a7d06
	buffer_load_b128 v[60:63], v39, s[36:39], null offen offset:3584 ; c405c07c 4080483c 000e0027
	v_cvt_pk_f32_fp8_e32 v[6:7], v45                            ; 7e0cdd2d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_dual_mul_f32 v109, v7, v21 :: v_dual_mul_f32 v108, v6, v20 ; c8c62b07 6d6c2906
	ds_load_b64 v[20:21], v55 offset:8448                       ; d9d82100 14000037
	buffer_load_b128 v[116:119], v39, s[36:39], null offen offset:4096 ; c405c07c 40804874 00100027
	v_cvt_pk_f32_fp8_e32 v[6:7], v173                           ; 7e0cddad
	v_dual_mul_f32 v111, v7, v23 :: v_dual_mul_f32 v110, v6, v22 ; c8c62f07 6f6e2d06
	ds_load_b64 v[22:23], v55 offset:12544                      ; d9d83100 16000037
	buffer_load_b128 v[120:123], v39, s[36:39], null offen offset:4608 ; c405c07c 40804878 00120027
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[6:7], v78                            ; 7e0cdd4e
	s_wait_loadcnt 0xb                                          ; bfc0000b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v7, v9 :: v_dual_mul_f32 v112, v6, v8  ; c8c61307 71701106
	v_cvt_pk_f32_fp8_e32 v[6:7], v206                           ; 7e0cddce
	v_dual_mul_f32 v115, v7, v11 :: v_dual_mul_f32 v114, v6, v10 ; c8c61707 73721506
	buffer_load_b128 v[140:143], v39, s[36:39], null offen offset:5120 ; c405c07c 4080488c 00140027
	v_cvt_pk_f32_fp8_e32 v[6:7], v79                            ; 7e0cdd4f
	s_wait_loadcnt 0xb                                          ; bfc0000b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v125, v7, v29 :: v_dual_mul_f32 v124, v6, v28 ; c8c63b07 7d7c3906
	v_cvt_pk_f32_fp8_e32 v[6:7], v207                           ; 7e0cddcf
	v_dual_mul_f32 v127, v7, v31 :: v_dual_mul_f32 v126, v6, v30 ; c8c63f07 7f7e3d06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v12                            ; 7e0cdd0c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
	v_dual_mul_f32 v129, v7, v9 :: v_dual_mul_f32 v128, v6, v8  ; c8c61307 81801106
	v_cvt_pk_f32_fp8_e32 v[6:7], v140                           ; 7e0cdd8c
	buffer_load_b128 v[144:147], v39, s[36:39], null offen offset:5632 ; c405c07c 40804890 00160027
	v_dual_mul_f32 v131, v7, v11 :: v_dual_mul_f32 v130, v6, v10 ; c8c61707 83821506
	v_cvt_pk_f32_fp8_e32 v[6:7], v13                            ; 7e0cdd0d
	v_dual_mul_f32 v133, v7, v29 :: v_dual_mul_f32 v132, v6, v28 ; c8c63b07 85843906
	v_cvt_pk_f32_fp8_e32 v[6:7], v141                           ; 7e0cdd8d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
	v_dual_mul_f32 v135, v7, v31 :: v_dual_mul_f32 v134, v6, v30 ; c8c63f07 87863d06
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[6:7], v20                            ; 7e0cdd14
	v_lshl_add_u32 v77, s59, 10, v72                            ; d646004d 0521143b
	v_dual_mul_f32 v137, v7, v9 :: v_dual_mul_f32 v136, v6, v8  ; c8c61307 89881106
	v_cvt_pk_f32_fp8_e32 v[6:7], v148                           ; 7e0cdd94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v139, v7, v11 :: v_dual_mul_f32 v138, v6, v10 ; c8c61707 8b8a1506
	v_cvt_pk_f32_fp8_e32 v[6:7], v21                            ; 7e0cdd15
	v_dual_mul_f32 v149, v7, v29 :: v_dual_mul_f32 v148, v6, v28 ; c8c63b07 95943906
	v_cvt_pk_f32_fp8_e32 v[6:7], v149                           ; 7e0cdd95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v151, v7, v31 :: v_dual_mul_f32 v150, v6, v30 ; c8c63f07 97963d06
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[6:7], v22                            ; 7e0cdd16
	v_dual_mul_f32 v153, v7, v9 :: v_dual_mul_f32 v152, v6, v8  ; c8c61307 99981106
	v_cvt_pk_f32_fp8_e32 v[6:7], v150                           ; 7e0cdd96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v155, v7, v11 :: v_dual_mul_f32 v154, v6, v10 ; c8c61707 9b9a1506
	buffer_load_b128 v[8:11], v39, s[36:39], null offen offset:6144 ; c405c07c 40804808 00180027
	v_cvt_pk_f32_fp8_e32 v[6:7], v23                            ; 7e0cdd17
	v_dual_mul_f32 v157, v7, v29 :: v_dual_mul_f32 v156, v6, v28 ; c8c63b07 9d9c3906
	v_cvt_pk_f32_fp8_e32 v[6:7], v151                           ; 7e0cdd97
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v159, v7, v31 :: v_dual_mul_f32 v158, v6, v30 ; c8c63f07 9f9e3d06
	ds_load_b64 v[6:7], v77 offset:16384                        ; d9d84000 0600004d
	ds_load_b64 v[12:13], v77 offset:20480                      ; d9d85000 0c00004d
	ds_load_b64 v[20:21], v77 offset:24576                      ; d9d86000 1400004d
	ds_load_b64 v[22:23], v77 offset:28672                      ; d9d87000 1600004d
	ds_load_b64 v[24:25], v77 offset:16640                      ; d9d84100 1800004d
	ds_load_b64 v[28:29], v77 offset:20736                      ; d9d85100 1c00004d
	ds_load_b64 v[30:31], v77 offset:24832                      ; d9d86100 1e00004d
	ds_load_b64 v[44:45], v77 offset:28928                      ; d9d87100 2c00004d
	ds_load_b64 v[78:79], v77 offset:16896                      ; d9d84200 4e00004d
	ds_load_b64 v[160:161], v77 offset:20992                    ; d9d85200 a000004d
	ds_load_b64 v[162:163], v77 offset:25088                    ; d9d86200 a200004d
	ds_load_b64 v[164:165], v77 offset:29184                    ; d9d87200 a400004d
	buffer_load_b128 v[168:171], v39, s[36:39], null offen offset:6656 ; c405c07c 408048a8 001a0027
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_dual_mov_b32 v175, v95 :: v_dual_mov_b32 v174, v94        ; ca10015f afae015e
	v_dual_mov_b32 v95, v103 :: v_dual_mov_b32 v94, v102        ; ca100167 5f5e0166
	v_dual_mov_b32 v173, v93 :: v_dual_mov_b32 v172, v92        ; ca10015d adac015c
	v_dual_mov_b32 v93, v101 :: v_dual_mov_b32 v92, v100        ; ca100165 5d5c0164
	ds_load_b64 v[100:101], v77 offset:17152                    ; d9d84300 6400004d
	ds_load_b64 v[102:103], v77 offset:21248                    ; d9d85300 6600004d
	ds_load_b64 v[166:167], v77 offset:25344                    ; d9d86300 a600004d
	ds_load_b64 v[176:177], v77 offset:29440                    ; d9d87300 b000004d
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_mov_b32 v181, v117 :: v_dual_mov_b32 v180, v116      ; ca100175 b5b40174
	v_dual_mov_b32 v117, v125 :: v_dual_mov_b32 v116, v124      ; ca10017d 7574017c
	v_dual_mov_b32 v183, v119 :: v_dual_mov_b32 v182, v118      ; ca100177 b7b60176
	v_dual_mov_b32 v119, v127 :: v_dual_mov_b32 v118, v126      ; ca10017f 7776017e
	buffer_load_b128 v[124:127], v39, s[36:39], null offen offset:7168 ; c405c07c 4080487c 001c0027
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[32:33], v[6:7], v[64:71] ; cc464040 1d020d20
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[12:13], v[80:87] ; cc464050 1d421920
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[32:33], v[22:23], v[104:111] ; cc464068 1da22d20
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[12:13], v[128:135] ; cc464080 1e021922
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[6:7], v[112:119] ; cc464070 1dc20d22
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[34:35], v[22:23], v[152:159] ; cc464098 1e622d22
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mov_b32 v187, v143 :: v_dual_mov_b32 v186, v142      ; ca10018f bbba018e
	v_dual_mov_b32 v143, v151 :: v_dual_mov_b32 v142, v150      ; ca100197 8f8e0196
	v_dual_mov_b32 v185, v141 :: v_dual_mov_b32 v184, v140      ; ca10018d b9b8018c
	v_dual_mov_b32 v141, v149 :: v_dual_mov_b32 v140, v148      ; ca100195 8d8c0194
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[20:21], v[88:95] ; cc464058 1d622920
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[34:35], v[20:21], v[136:143] ; cc464088 1e222922
	ds_load_b64 v[6:7], v77 offset:17408                        ; d9d84400 0600004d
	ds_load_b64 v[12:13], v77 offset:21504                      ; d9d85400 0c00004d
	ds_load_b64 v[20:21], v77 offset:25600                      ; d9d86400 1400004d
	ds_load_b64 v[22:23], v77 offset:29696                      ; d9d87400 1600004d
	buffer_load_b128 v[32:35], v39, s[36:39], null offen offset:7680 ; c405c07c 40804820 001e0027
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[48:49], v[24:25], v[64:71] ; cc464040 1d023130
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[28:29], v[80:87] ; cc464050 1d423930
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[44:45], v[104:111] ; cc464068 1da25930
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[28:29], v[128:135] ; cc464080 1e023932
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[24:25], v[112:119] ; cc464070 1dc23132
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[50:51], v[44:45], v[152:159] ; cc464098 1e625932
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[30:31], v[88:95] ; cc464058 1d623d30
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[50:51], v[30:31], v[136:143] ; cc464088 1e223d32
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[16:17], v[78:79], v[64:71] ; cc464040 1d029d10
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[160:161], v[80:87] ; cc464050 1d434110
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[164:165], v[104:111] ; cc464068 1da34910
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[160:161], v[128:135] ; cc464080 1e034112
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[78:79], v[112:119] ; cc464070 1dc29d12
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[18:19], v[164:165], v[152:159] ; cc464098 1e634912
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[162:163], v[88:95] ; cc464058 1d634510
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[162:163], v[136:143] ; cc464088 1e234512
	ds_load_b64 v[24:25], v77 offset:17664                      ; d9d84500 1800004d
	ds_load_b64 v[28:29], v77 offset:21760                      ; d9d85500 1c00004d
	ds_load_b64 v[30:31], v77 offset:25856                      ; d9d86500 1e00004d
	ds_load_b64 v[44:45], v77 offset:29952                      ; d9d87500 2c00004d
	ds_load_b64 v[16:17], v77 offset:17920                      ; d9d84600 1000004d
	ds_load_b64 v[18:19], v77 offset:22016                      ; d9d85600 1200004d
	ds_load_b64 v[48:49], v77 offset:26112                      ; d9d86600 3000004d
	ds_load_b64 v[50:51], v77 offset:30208                      ; d9d87600 3200004d
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[40:41], v[100:101], v[64:71] ; cc464040 1d02c928
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[102:103], v[80:87] ; cc464050 1d42cd28
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[176:177], v[104:111] ; cc464068 1da36128
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[102:103], v[128:135] ; cc464080 1e02cd2a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[100:101], v[112:119] ; cc464070 1dc2c92a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[42:43], v[176:177], v[152:159] ; cc464098 1e63612a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[166:167], v[88:95] ; cc464058 1d634d28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[166:167], v[136:143] ; cc464088 1e234d2a
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[56:57], v[6:7], v[64:71] ; cc464040 1d020d38
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[56:57], v[12:13], v[80:87] ; cc464050 1d421938
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[56:57], v[22:23], v[104:111] ; cc464068 1da22d38
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[12:13], v[128:135] ; cc464080 1e02193a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[6:7], v[112:119] ; cc464070 1dc20d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[22:23], v[152:159] ; cc464098 1e622d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[20:21], v[88:95] ; cc464058 1d622938
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[58:59], v[20:21], v[136:143] ; cc464088 1e22293a
	ds_load_b64 v[40:41], v77 offset:18176                      ; d9d84700 2800004d
	ds_load_b64 v[42:43], v77 offset:22272                      ; d9d85700 2a00004d
	ds_load_b64 v[78:79], v77 offset:26368                      ; d9d86700 4e00004d
	ds_load_b64 v[100:101], v77 offset:30464                    ; d9d87700 6400004d
	ds_load_b64 v[6:7], v77 offset:18432                        ; d9d84800 0600004d
	ds_load_b64 v[12:13], v77 offset:22528                      ; d9d85800 0c00004d
	ds_load_b64 v[20:21], v77 offset:26624                      ; d9d86800 1400004d
	ds_load_b64 v[22:23], v77 offset:30720                      ; d9d87800 1600004d
	v_add_lshl_u32 v102, s23, v1, 2                             ; d6470066 020a0217
	buffer_load_b32 v102, v102, s[32:35], null offen            ; c405007c 40804066 00000066
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[172:173], v[24:25], v[64:71] ; cc464040 1d0231ac
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[172:173], v[28:29], v[80:87] ; cc464050 1d4239ac
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[172:173], v[44:45], v[104:111] ; cc464068 1da259ac
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[174:175], v[28:29], v[128:135] ; cc464080 1e0239ae
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[174:175], v[24:25], v[112:119] ; cc464070 1dc231ae
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[174:175], v[44:45], v[152:159] ; cc464098 1e6259ae
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[172:173], v[30:31], v[88:95] ; cc464058 1d623dac
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[174:175], v[30:31], v[136:143] ; cc464088 1e223dae
	ds_load_b64 v[24:25], v77 offset:18688                      ; d9d84900 1800004d
	ds_load_b64 v[28:29], v77 offset:22784                      ; d9d85900 1c00004d
	ds_load_b64 v[30:31], v77 offset:26880                      ; d9d86900 1e00004d
	ds_load_b64 v[44:45], v77 offset:30976                      ; d9d87900 2c00004d
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[96:97], v[16:17], v[64:71] ; cc464040 1d022160
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[96:97], v[18:19], v[80:87] ; cc464050 1d422560
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[98:99], v[18:19], v[128:135] ; cc464080 1e022562
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[98:99], v[16:17], v[112:119] ; cc464070 1dc22162
	v_mad_u32_u24 v103, 0x1800, v1, s6                          ; d60b0067 001a02ff 00001800
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v103, v103, v54, 2                           ; d6470067 020a6d67
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v103, s[36:39], null offen       ; c405c07c 40804838 00000067
	buffer_load_b128 v[16:19], v103, s[36:39], null offen offset:8192 ; c405c07c 40804810 00200067
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[96:97], v[50:51], v[104:111] ; cc464068 1da26560
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[98:99], v[50:51], v[152:159] ; cc464098 1e626562
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[96:97], v[48:49], v[88:95] ; cc464058 1d626160
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[98:99], v[48:49], v[136:143] ; cc464088 1e226162
	ds_load_b64 v[48:49], v77 offset:18944                      ; d9d84a00 3000004d
	ds_load_b64 v[50:51], v77 offset:23040                      ; d9d85a00 3200004d
	ds_load_b64 v[96:97], v77 offset:27136                      ; d9d86a00 6000004d
	ds_load_b64 v[98:99], v77 offset:31232                      ; d9d87a00 6200004d
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[60:61], v[40:41], v[64:71] ; cc464040 1d02513c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[42:43], v[80:87] ; cc464050 1d42553c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[42:43], v[128:135] ; cc464080 1e02553e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[40:41], v[112:119] ; cc464070 1dc2513e
	buffer_load_b128 v[40:43], v103, s[36:39], null offen offset:512 ; c405c07c 40804828 00020067
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[100:101], v[104:111] ; cc464068 1da2c93c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[100:101], v[152:159] ; cc464098 1e62c93e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[60:61], v[78:79], v[88:95] ; cc464058 1d629d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[62:63], v[78:79], v[136:143] ; cc464088 1e229d3e
	ds_load_b64 v[60:61], v77 offset:19200                      ; d9d84b00 3c00004d
	ds_load_b64 v[62:63], v77 offset:23296                      ; d9d85b00 3e00004d
	ds_load_b64 v[78:79], v77 offset:27392                      ; d9d86b00 4e00004d
	ds_load_b64 v[100:101], v77 offset:31488                    ; d9d87b00 6400004d
	buffer_load_b128 v[148:151], v103, s[36:39], null offen offset:8704 ; c405c07c 40804894 00220067
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[180:181], v[6:7], v[64:71] ; cc464040 1d020db4
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[180:181], v[12:13], v[80:87] ; cc464050 1d4219b4
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[182:183], v[12:13], v[128:135] ; cc464080 1e0219b6
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[182:183], v[6:7], v[112:119] ; cc464070 1dc20db6
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[180:181], v[22:23], v[104:111] ; cc464068 1da22db4
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[182:183], v[22:23], v[152:159] ; cc464098 1e622db6
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[180:181], v[20:21], v[88:95] ; cc464058 1d6229b4
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[182:183], v[20:21], v[136:143] ; cc464088 1e2229b6
	ds_load_b64 v[6:7], v77 offset:19456                        ; d9d84c00 0600004d
	ds_load_b64 v[12:13], v77 offset:23552                      ; d9d85c00 0c00004d
	ds_load_b64 v[20:21], v77 offset:27648                      ; d9d86c00 1400004d
	ds_load_b64 v[22:23], v77 offset:31744                      ; d9d87c00 1600004d
	buffer_load_b128 v[160:163], v103, s[36:39], null offen offset:1024 ; c405c07c 408048a0 00040067
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[120:121], v[24:25], v[64:71] ; cc464040 1d023178
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[120:121], v[28:29], v[80:87] ; cc464050 1d423978
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[122:123], v[28:29], v[128:135] ; cc464080 1e02397a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[122:123], v[24:25], v[112:119] ; cc464070 1dc2317a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[120:121], v[44:45], v[104:111] ; cc464068 1da25978
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[122:123], v[44:45], v[152:159] ; cc464098 1e62597a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[120:121], v[30:31], v[88:95] ; cc464058 1d623d78
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[122:123], v[30:31], v[136:143] ; cc464088 1e223d7a
	ds_load_b64 v[24:25], v77 offset:19712                      ; d9d84d00 1800004d
	ds_load_b64 v[28:29], v77 offset:23808                      ; d9d85d00 1c00004d
	ds_load_b64 v[30:31], v77 offset:27904                      ; d9d86d00 1e00004d
	ds_load_b64 v[44:45], v77 offset:32000                      ; d9d87d00 2c00004d
	buffer_load_b128 v[120:123], v103, s[36:39], null offen offset:9216 ; c405c07c 40804878 00240067
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[184:185], v[48:49], v[64:71] ; cc464040 1d0261b8
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[184:185], v[50:51], v[80:87] ; cc464050 1d4265b8
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[186:187], v[50:51], v[128:135] ; cc464080 1e0265ba
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[186:187], v[48:49], v[112:119] ; cc464070 1dc261ba
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[184:185], v[98:99], v[104:111] ; cc464068 1da2c5b8
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[186:187], v[98:99], v[152:159] ; cc464098 1e62c5ba
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[184:185], v[96:97], v[88:95] ; cc464058 1d62c1b8
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[186:187], v[96:97], v[136:143] ; cc464088 1e22c1ba
	s_wait_loadcnt_dscnt 0xb0b                                  ; bfc80b0b
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[144:145], v[60:61], v[64:71] ; cc464040 1d027990
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[144:145], v[62:63], v[80:87] ; cc464050 1d427d90
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[146:147], v[62:63], v[128:135] ; cc464080 1e027d92
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[146:147], v[60:61], v[112:119] ; cc464070 1dc27992
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[144:145], v[100:101], v[104:111] ; cc464068 1da2c990
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[146:147], v[100:101], v[152:159] ; cc464098 1e62c992
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[144:145], v[78:79], v[88:95] ; cc464058 1d629d90
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[146:147], v[78:79], v[136:143] ; cc464088 1e229d92
	ds_load_b64 v[48:49], v77 offset:19968                      ; d9d84e00 3000004d
	ds_load_b64 v[50:51], v77 offset:24064                      ; d9d85e00 3200004d
	ds_load_b64 v[96:97], v77 offset:28160                      ; d9d86e00 6000004d
	ds_load_b64 v[98:99], v77 offset:32256                      ; d9d87e00 6200004d
	ds_load_b64 v[60:61], v77 offset:20224                      ; d9d84f00 3c00004d
	ds_load_b64 v[62:63], v77 offset:24320                      ; d9d85f00 3e00004d
	ds_load_b64 v[78:79], v77 offset:28416                      ; d9d86f00 4e00004d
	ds_load_b64 v[100:101], v77 offset:32512                    ; d9d87f00 6400004d
	s_wait_loadcnt_dscnt 0xa0f                                  ; bfc80a0f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[6:7], v[64:71] ; cc464040 1d020d08
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[12:13], v[80:87] ; cc464050 1d421908
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[6:7], v[112:119] ; cc464070 1dc20d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[12:13], v[128:135] ; cc464080 1e02190a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[22:23], v[104:111] ; cc464068 1da22d08
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[10:11], v[22:23], v[152:159] ; cc464098 1e622d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[20:21], v[88:95] ; cc464058 1d622908
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[20:21], v[136:143] ; cc464088 1e22290a
	s_wait_loadcnt_dscnt 0x90b                                  ; bfc8090b
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[168:169], v[24:25], v[64:71] ; cc464040 1d0231a8
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[168:169], v[28:29], v[80:87] ; cc464050 1d4239a8
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[24:25], v[112:119] ; cc464070 1dc231aa
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[170:171], v[28:29], v[128:135] ; cc464080 1e0239aa
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[168:169], v[44:45], v[104:111] ; cc464068 1da259a8
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[170:171], v[44:45], v[152:159] ; cc464098 1e6259aa
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[168:169], v[30:31], v[88:95] ; cc464058 1d623da8
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[170:171], v[30:31], v[136:143] ; cc464088 1e223daa
	s_wait_loadcnt_dscnt 0x807                                  ; bfc80807
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[124:125], v[48:49], v[64:71] ; cc464040 1d02617c
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[124:125], v[50:51], v[80:87] ; cc464050 1d42657c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[126:127], v[48:49], v[112:119] ; cc464070 1dc2617e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[126:127], v[50:51], v[128:135] ; cc464080 1e02657e
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[124:125], v[98:99], v[104:111] ; cc464068 1da2c57c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[126:127], v[98:99], v[152:159] ; cc464098 1e62c57e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[124:125], v[96:97], v[88:95] ; cc464058 1d62c17c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[126:127], v[96:97], v[136:143] ; cc464088 1e22c17e
	s_wait_loadcnt_dscnt 0x703                                  ; bfc80703
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[32:33], v[60:61], v[64:71] ; cc464040 1d027920
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[62:63], v[80:87] ; cc464050 1d427d20
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[60:61], v[112:119] ; cc464070 1dc27922
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[62:63], v[128:135] ; cc464080 1e027d22
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[32:33], v[100:101], v[104:111] ; cc464068 1da2c920
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[34:35], v[100:101], v[152:159] ; cc464098 1e62c922
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[78:79], v[88:95] ; cc464058 1d629d20
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[34:35], v[78:79], v[136:143] ; cc464088 1e229d22
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v73, v[6:7], v[20:21] offset1:32         ; d9382000 00140649
	ds_store_2addr_b64 v74, v[8:9], v[22:23] offset1:32         ; d9382000 0016084a
	ds_store_2addr_b64 v75, v[10:11], v[24:25] offset1:32       ; d9382000 00180a4b
	ds_store_2addr_b64 v76, v[12:13], v[28:29] offset1:32       ; d9382000 001c0c4c
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_lshl_add_u32 v104, s59, 11, v72                           ; d6460068 0521163b
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[6:7], v104                                    ; d9d80000 06000068
	ds_load_b64 v[8:9], v104 offset:4096                        ; d9d81000 08000068
	ds_load_b64 v[10:11], v104 offset:8192                      ; d9d82000 0a000068
	ds_load_b64 v[12:13], v104 offset:12288                     ; d9d83000 0c000068
	ds_load_b64 v[20:21], v104 offset:256                       ; d9d80100 14000068
	ds_load_b64 v[22:23], v104 offset:4352                      ; d9d81100 16000068
	ds_load_b64 v[24:25], v104 offset:8448                      ; d9d82100 18000068
	ds_load_b64 v[28:29], v104 offset:12544                     ; d9d83100 1c000068
	ds_load_b64 v[30:31], v104 offset:512                       ; d9d80200 1e000068
	ds_load_b64 v[32:33], v104 offset:4608                      ; d9d81200 20000068
	ds_load_b64 v[34:35], v104 offset:8704                      ; d9d82200 22000068
	ds_load_b64 v[44:45], v104 offset:12800                     ; d9d83200 2c000068
	v_mov_b32_e32 v37, v104                                     ; 7e4a0368
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_mov_b32_e32 v39, v102                                     ; 7e4e0366
	v_dual_mov_b32 v49, v72 :: v_dual_mov_b32 v48, v103         ; ca100148 31300167
	v_dual_mov_b32 v51, v77 :: v_dual_mov_b32 v50, v73          ; ca10014d 33320149
	v_dual_mov_b32 v125, v3 :: v_dual_mov_b32 v124, v2          ; ca100103 7d7c0102
	v_dual_mov_b32 v127, v5 :: v_dual_mov_b32 v126, v4          ; ca100105 7f7e0104
	v_dual_mov_b32 v147, v15 :: v_dual_mov_b32 v146, v14        ; ca10010f 9392010e
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[18:19], v[6:7], 0  ; cc464060 1a020d12
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[6:7], 0 ; cc464080 1a020d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[56:57], v[6:7], 0   ; cc464040 1a020d38
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[8:9], 0 ; cc4640b0 1a021110
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[56:57], v[8:9], 0   ; cc464050 1a021138
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[58:59], v[8:9], 0 ; cc464088 1a02113a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[18:19], v[8:9], 0   ; cc464048 1a021112
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[16:17], v[10:11], 0 ; cc4640b8 1a021510
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[10:11], 0 ; cc464058 1a021538
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[10:11], 0 ; cc464098 1a02153a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[56:57], v[12:13], 0 ; cc464070 1a021938
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[12:13], 0 ; cc464068 1a021910
	v_dual_mov_b32 v145, v13 :: v_dual_mov_b32 v144, v12        ; ca10010d 9190010c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[58:59], v[12:13], 0 ; cc4640a8 1a02193a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[16:17], v[6:7], 0   ; cc464038 1a020d10
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[18:19], v[10:11], 0   ; cc464002 1a021512
	s_wait_loadcnt_dscnt 0x307                                  ; bfc80307
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[40:41], v[20:21], v[64:71] ; cc464040 1d022928
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[20:21], v[128:135] ; cc464080 1e02292a
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[22:23], v[80:87] ; cc464050 1d422d28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[22:23], v[136:143] ; cc464088 1e222d2a
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[24:25], v[88:95] ; cc464058 1d623128
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[42:43], v[24:25], v[152:159] ; cc464098 1e62312a
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[28:29], v[112:119] ; cc464070 1dc23928
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[18:19], v[144:145], 0 ; cc46400a 1a032112
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[42:43], v[28:29], v[168:175] ; cc4640a8 1ea2392a
	ds_load_b64 v[18:19], v37 offset:768                        ; d9d80300 12000025
	ds_load_b64 v[40:41], v37 offset:4864                       ; d9d81300 28000025
	ds_load_b64 v[42:43], v37 offset:8960                       ; d9d82300 2a000025
	ds_load_b64 v[144:145], v37 offset:13056                    ; d9d83300 90000025
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[148:149], v[22:23], v[176:183] ; cc4640b0 1ec22d94
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[148:149], v[20:21], v[56:63] ; cc464038 1ce22994
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[150:151], v[20:21], v[96:103] ; cc464060 1d822996
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[150:151], v[22:23], v[72:79] ; cc464048 1d222d96
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v48, s[36:39], null offen offset:1536 ; c405c07c 40804814 00060030
	buffer_load_b128 v[164:167], v48, s[36:39], null offen offset:9728 ; c405c07c 408048a4 00260030
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[148:149], v[24:25], v[184:191] ; cc4640b8 1ee23194
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[148:149], v[28:29], v[104:111] ; cc464068 1da23994
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[150:151], v[24:25], v[2:9] ; cc464002 1c0a3196
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[150:151], v[28:29], v[10:17] ; cc46400a 1c2a3996
	ds_load_b64 v[24:25], v37 offset:1024                       ; d9d80400 18000025
	ds_load_b64 v[28:29], v37 offset:5120                       ; d9d81400 1c000025
	ds_load_b64 v[148:149], v37 offset:9216                     ; d9d82400 94000025
	ds_load_b64 v[150:151], v37 offset:13312                    ; d9d83400 96000025
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[160:161], v[30:31], v[64:71] ; cc464040 1d023da0
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[160:161], v[32:33], v[80:87] ; cc464050 1d4241a0
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[34:35], v[88:95] ; cc464058 1d6245a0
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[160:161], v[44:45], v[112:119] ; cc464070 1dc259a0
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[162:163], v[30:31], v[128:135] ; cc464080 1e023da2
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[162:163], v[32:33], v[136:143] ; cc464088 1e2241a2
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[162:163], v[34:35], v[152:159] ; cc464098 1e6245a2
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[162:163], v[44:45], v[168:175] ; cc4640a8 1ea259a2
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[120:121], v[30:31], v[56:63] ; cc464038 1ce23d78
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[120:121], v[32:33], v[176:183] ; cc4640b0 1ec24178
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[122:123], v[30:31], v[96:103] ; cc464060 1d823d7a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[122:123], v[32:33], v[72:79] ; cc464048 1d22417a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[160:163], v48, s[36:39], null offen offset:2048 ; c405c07c 408048a0 00080030
	buffer_load_b128 v[30:33], v48, s[36:39], null offen offset:10240 ; c405c07c 4080481e 00280030
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[120:121], v[34:35], v[184:191] ; cc4640b8 1ee24578
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[120:121], v[44:45], v[104:111] ; cc464068 1da25978
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[122:123], v[34:35], v[2:9] ; cc464002 1c0a457a
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[122:123], v[44:45], v[10:17] ; cc46400a 1c2a597a
	s_wait_loadcnt_dscnt 0x304                                  ; bfc80304
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[144:145], v[112:119] ; cc464070 1dc32114
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[42:43], v[88:95] ; cc464058 1d625514
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[18:19], v[64:71] ; cc464040 1d022514
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[40:41], v[80:87] ; cc464050 1d425114
	ds_load_b64 v[34:35], v37 offset:1280                       ; d9d80500 22000025
	ds_load_b64 v[44:45], v37 offset:5376                       ; d9d81500 2c000025
	ds_load_b64 v[120:121], v37 offset:9472                     ; d9d82500 78000025
	ds_load_b64 v[20:21], v37 offset:13568                      ; d9d83500 14000025
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[22:23], v[42:43], v[152:159] ; cc464098 1e625516
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[144:145], v[168:175] ; cc4640a8 1ea32116
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[40:41], v[136:143] ; cc464088 1e225116
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[18:19], v[128:135] ; cc464080 1e022516
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[164:165], v[18:19], v[56:63] ; cc464038 1ce225a4
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[164:165], v[40:41], v[176:183] ; cc4640b0 1ec251a4
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[166:167], v[18:19], v[96:103] ; cc464060 1d8225a6
	v_dual_mov_b32 v19, v39 :: v_dual_mov_b32 v18, v38          ; ca100127 13120126
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[166:167], v[40:41], v[72:79] ; cc464048 1d2251a6
	v_dual_mov_b32 v23, v125 :: v_dual_mov_b32 v22, v124        ; ca10017d 1716017c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[38:41], v48, s[36:39], null offen offset:2560 ; c405c07c 40804826 000a0030
	buffer_load_b128 v[122:125], v48, s[36:39], null offen offset:10752 ; c405c07c 4080487a 002a0030
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[164:165], v[42:43], v[184:191] ; cc4640b8 1ee255a4
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[164:165], v[144:145], v[104:111] ; cc464068 1da321a4
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[166:167], v[42:43], v[2:9] ; cc464002 1c0a55a6
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[166:167], v[144:145], v[10:17] ; cc46400a 1c2b21a6
	s_wait_loadcnt_dscnt 0x306                                  ; bfc80306
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[160:161], v[28:29], v[80:87] ; cc464050 1d4239a0
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[148:149], v[88:95] ; cc464058 1d6329a0
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[160:161], v[150:151], v[112:119] ; cc464070 1dc32da0
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[160:161], v[24:25], v[64:71] ; cc464040 1d0231a0
	ds_load_b64 v[42:43], v37 offset:1536                       ; d9d80600 2a000025
	ds_load_b64 v[144:145], v37 offset:5632                     ; d9d81600 90000025
	ds_load_b64 v[164:165], v37 offset:9728                     ; d9d82600 a4000025
	ds_load_b64 v[160:161], v37 offset:13824                    ; d9d83600 a0000025
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[162:163], v[28:29], v[136:143] ; cc464088 1e2239a2
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[162:163], v[150:151], v[168:175] ; cc4640a8 1ea32da2
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[162:163], v[24:25], v[128:135] ; cc464080 1e0231a2
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[162:163], v[148:149], v[152:159] ; cc464098 1e6329a2
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[30:31], v[24:25], v[56:63] ; cc464038 1ce2311e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[28:29], v[176:183] ; cc4640b0 1ec2391e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[30:31], v[148:149], v[184:191] ; cc4640b8 1ee3291e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[150:151], v[104:111] ; cc464068 1da32d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[24:25], v[96:103] ; cc464060 1d823120
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[32:33], v[28:29], v[72:79] ; cc464048 1d223920
	v_dual_mov_b32 v163, v27 :: v_dual_mov_b32 v162, v26        ; ca10011b a3a2011a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v48, s[36:39], null offen offset:3072 ; c405c07c 4080481c 000c0030
	buffer_load_b128 v[24:27], v48, s[36:39], null offen offset:11264 ; c405c07c 40804818 002c0030
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[32:33], v[148:149], v[2:9] ; cc464002 1c0b2920
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[32:33], v[150:151], v[10:17] ; cc46400a 1c2b2d20
	s_wait_loadcnt_dscnt 0x305                                  ; bfc80305
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[38:39], v[120:121], v[88:95] ; cc464058 1d62f126
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[20:21], v[112:119] ; cc464070 1dc22926
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[38:39], v[34:35], v[64:71] ; cc464040 1d024526
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[38:39], v[44:45], v[80:87] ; cc464050 1d425926
	ds_load_b64 v[148:149], v37 offset:1792                     ; d9d80700 94000025
	ds_load_b64 v[32:33], v37 offset:5888                       ; d9d81700 20000025
	ds_load_b64 v[150:151], v37 offset:9984                     ; d9d82700 96000025
	ds_load_b64 v[38:39], v37 offset:14080                      ; d9d83700 26000025
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[40:41], v[34:35], v[128:135] ; cc464080 1e024528
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[20:21], v[168:175] ; cc4640a8 1ea22928
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[120:121], v[152:159] ; cc464098 1e62f128
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[40:41], v[44:45], v[136:143] ; cc464088 1e225928
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[122:123], v[34:35], v[56:63] ; cc464038 1ce2457a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[124:125], v[34:35], v[96:103] ; cc464060 1d82457c
	v_dual_mov_b32 v35, v47 :: v_dual_mov_b32 v34, v46          ; ca10012f 2322012e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[122:123], v[44:45], v[176:183] ; cc4640b0 1ec2597a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[122:123], v[120:121], v[184:191] ; cc4640b8 1ee2f17a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[122:123], v[20:21], v[104:111] ; cc464068 1da2297a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[124:125], v[44:45], v[72:79] ; cc464048 1d22597c
	s_wait_dscnt 0x7                                            ; bfc60007
	v_dual_mov_b32 v123, v43 :: v_dual_mov_b32 v122, v42        ; ca10012b 7b7a012a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v48, s[36:39], null offen offset:3584 ; c405c07c 4080482c 000e0030
	buffer_load_b128 v[40:43], v48, s[36:39], null offen offset:11776 ; c405c07c 40804828 002e0030
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[124:125], v[120:121], v[2:9] ; cc464002 1c0af17c
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[124:125], v[20:21], v[10:17] ; cc46400a 1c2a297c
	s_wait_loadcnt_dscnt 0x306                                  ; bfc80306
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[144:145], v[80:87] ; cc464050 1d43211c
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[164:165], v[88:95] ; cc464058 1d63491c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[28:29], v[122:123], v[64:71] ; cc464040 1d02f51c
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[160:161], v[112:119] ; cc464070 1dc3411c
	ds_load_b64 v[120:121], v37 offset:2048                     ; d9d80800 78000025
	ds_load_b64 v[20:21], v37 offset:6144                       ; d9d81800 14000025
	ds_load_b64 v[124:125], v37 offset:10240                    ; d9d82800 7c000025
	ds_load_b64 v[28:29], v37 offset:14336                      ; d9d83800 1c000025
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[122:123], v[128:135] ; cc464080 1e02f51e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[144:145], v[136:143] ; cc464088 1e23211e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[24:25], v[144:145], v[176:183] ; cc4640b0 1ec32118
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[122:123], v[56:63] ; cc464038 1ce2f518
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[122:123], v[96:103] ; cc464060 1d82f51a
	v_dual_mov_b32 v123, v147 :: v_dual_mov_b32 v122, v146      ; ca100193 7b7a0192
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[24:25], v[164:165], v[184:191] ; cc4640b8 1ee34918
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[160:161], v[104:111] ; cc464068 1da34118
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[144:145], v[72:79] ; cc464048 1d23211a
	v_dual_mov_b32 v167, v23 :: v_dual_mov_b32 v166, v22        ; ca100117 a7a60116
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[144:147], v48, s[36:39], null offen offset:4096 ; c405c07c 40804890 00100030
	buffer_load_b128 v[22:25], v48, s[36:39], null offen offset:12288 ; c405c07c 40804816 00300030
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[30:31], v[164:165], v[152:159] ; cc464098 1e63491e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[30:31], v[160:161], v[168:175] ; cc4640a8 1ea3411e
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[26:27], v[164:165], v[2:9] ; cc464002 1c0b491a
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[26:27], v[160:161], v[10:17] ; cc46400a 1c2b411a
	s_wait_loadcnt_dscnt 0x305                                  ; bfc80305
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[150:151], v[88:95] ; cc464058 1d632d2c
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[38:39], v[112:119] ; cc464070 1dc24d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[44:45], v[148:149], v[64:71] ; cc464040 1d03292c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[32:33], v[80:87] ; cc464050 1d42412c
	ds_load_b64 v[30:31], v37 offset:2304                       ; d9d80900 1e000025
	ds_load_b64 v[26:27], v37 offset:6400                       ; d9d81900 1a000025
	ds_load_b64 v[160:161], v37 offset:10496                    ; d9d82900 a0000025
	ds_load_b64 v[44:45], v37 offset:14592                      ; d9d83900 2c000025
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[150:151], v[152:159] ; cc464098 1e632d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[32:33], v[136:143] ; cc464088 1e22412e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[148:149], v[128:135] ; cc464080 1e03292e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[38:39], v[104:111] ; cc464068 1da24d28
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[40:41], v[148:149], v[56:63] ; cc464038 1ce32928
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[40:41], v[150:151], v[184:191] ; cc4640b8 1ee32d28
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[40:41], v[32:33], v[176:183] ; cc4640b0 1ec24128
	v_dual_mov_b32 v41, v35 :: v_dual_mov_b32 v40, v34          ; ca100123 29280122
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[46:47], v[38:39], v[168:175] ; cc4640a8 1ea24d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[42:43], v[32:33], v[72:79] ; cc464048 1d22412a
	v_dual_mov_b32 v47, v167 :: v_dual_mov_b32 v46, v166        ; ca1001a7 2f2e01a6
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[32:35], v48, s[36:39], null offen offset:4608 ; c405c07c 40804820 00120030
	buffer_load_b128 v[164:167], v48, s[36:39], null offen offset:12800 ; c405c07c 408048a4 00320030
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[148:149], v[96:103] ; cc464060 1d83292a
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[42:43], v[150:151], v[2:9] ; cc464002 1c0b2d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[42:43], v[38:39], v[10:17] ; cc46400a 1c2a4d2a
	s_wait_loadcnt_dscnt 0x307                                  ; bfc80307
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[144:145], v[120:121], v[64:71] ; cc464040 1d02f190
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[144:145], v[20:21], v[80:87] ; cc464050 1d422990
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[144:145], v[124:125], v[88:95] ; cc464058 1d62f990
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[144:145], v[28:29], v[112:119] ; cc464070 1dc23990
	ds_load_b64 v[148:149], v37 offset:2560                     ; d9d80a00 94000025
	ds_load_b64 v[38:39], v37 offset:6656                       ; d9d81a00 26000025
	ds_load_b64 v[42:43], v37 offset:10752                      ; d9d82a00 2a000025
	ds_load_b64 v[144:145], v37 offset:14848                    ; d9d83a00 90000025
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[146:147], v[120:121], v[128:135] ; cc464080 1e02f192
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[146:147], v[20:21], v[136:143] ; cc464088 1e222992
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[146:147], v[28:29], v[168:175] ; cc4640a8 1ea23992
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[146:147], v[124:125], v[152:159] ; cc464098 1e62f992
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[22:23], v[124:125], v[184:191] ; cc4640b8 1ee2f916
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[28:29], v[104:111] ; cc464068 1da23916
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[22:23], v[20:21], v[176:183] ; cc4640b0 1ec22916
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[22:23], v[120:121], v[56:63] ; cc464038 1ce2f116
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[120:121], v[96:103] ; cc464060 1d82f118
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[20:21], v[72:79] ; cc464048 1d222918
	v_dual_mov_b32 v147, v123 :: v_dual_mov_b32 v146, v122      ; ca10017b 9392017a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v48, s[36:39], null offen offset:5120 ; c405c07c 40804814 00140030
	buffer_load_b128 v[120:123], v48, s[36:39], null offen offset:13312 ; c405c07c 40804878 00340030
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[24:25], v[124:125], v[2:9] ; cc464002 1c0af918
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[24:25], v[28:29], v[10:17] ; cc46400a 1c2a3918
	s_wait_loadcnt_dscnt 0x305                                  ; bfc80305
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[160:161], v[88:95] ; cc464058 1d634120
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[44:45], v[112:119] ; cc464070 1dc25920
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[32:33], v[30:31], v[64:71] ; cc464040 1d023d20
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[26:27], v[80:87] ; cc464050 1d423520
	ds_load_b64 v[124:125], v37 offset:2816                     ; d9d80b00 7c000025
	ds_load_b64 v[24:25], v37 offset:6912                       ; d9d81b00 18000025
	ds_load_b64 v[28:29], v37 offset:11008                      ; d9d82b00 1c000025
	ds_load_b64 v[32:33], v37 offset:15104                      ; d9d83b00 20000025
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[34:35], v[44:45], v[168:175] ; cc4640a8 1ea25922
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[34:35], v[160:161], v[152:159] ; cc464098 1e634122
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[30:31], v[128:135] ; cc464080 1e023d22
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[34:35], v[26:27], v[136:143] ; cc464088 1e223522
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[164:165], v[26:27], v[176:183] ; cc4640b0 1ec235a4
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[164:165], v[30:31], v[56:63] ; cc464038 1ce23da4
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[166:167], v[26:27], v[72:79] ; cc464048 1d2235a6
	v_dual_mov_b32 v27, v37 :: v_dual_mov_b32 v26, v36          ; ca100125 1b1a0124
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[164:165], v[160:161], v[184:191] ; cc4640b8 1ee341a4
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[164:165], v[44:45], v[104:111] ; cc464068 1da259a4
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[166:167], v[30:31], v[96:103] ; cc464060 1d823da6
	v_dual_mov_b32 v31, v163 :: v_dual_mov_b32 v30, v162        ; ca1001a3 1f1e01a2
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[34:37], v48, s[36:39], null offen offset:5632 ; c405c07c 40804822 00160030
	buffer_load_b128 v[162:165], v48, s[36:39], null offen offset:13824 ; c405c07c 408048a2 00360030
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[166:167], v[160:161], v[2:9] ; cc464002 1c0b41a6
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[166:167], v[44:45], v[10:17] ; cc46400a 1c2a59a6
	s_wait_loadcnt_dscnt 0x306                                  ; bfc80306
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[38:39], v[80:87] ; cc464050 1d424d14
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[42:43], v[88:95] ; cc464058 1d625514
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[144:145], v[112:119] ; cc464070 1dc32114
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[148:149], v[64:71] ; cc464040 1d032914
	ds_load_b64 v[150:151], v27 offset:3072                     ; d9d80c00 9600001b
	ds_load_b64 v[44:45], v27 offset:7168                       ; d9d81c00 2c00001b
	ds_load_b64 v[160:161], v27 offset:11264                    ; d9d82c00 a000001b
	ds_load_b64 v[20:21], v27 offset:15360                      ; d9d83c00 1400001b
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[148:149], v[128:135] ; cc464080 1e032916
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[38:39], v[136:143] ; cc464088 1e224d16
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[144:145], v[168:175] ; cc4640a8 1ea32116
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[22:23], v[42:43], v[152:159] ; cc464098 1e625516
	v_dual_mov_b32 v23, v41 :: v_dual_mov_b32 v22, v40          ; ca100129 17160128
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[120:121], v[148:149], v[56:63] ; cc464038 1ce32978
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[120:121], v[42:43], v[184:191] ; cc4640b8 1ee25578
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[120:121], v[38:39], v[176:183] ; cc4640b0 1ec24d78
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[120:121], v[144:145], v[104:111] ; cc464068 1da32178
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[122:123], v[148:149], v[96:103] ; cc464060 1d83297a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[122:123], v[38:39], v[72:79] ; cc464048 1d224d7a
	v_dual_mov_b32 v121, v147 :: v_dual_mov_b32 v120, v146      ; ca100193 79780192
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[38:41], v48, s[36:39], null offen offset:6144 ; c405c07c 40804826 00180030
	buffer_load_b128 v[146:149], v48, s[36:39], null offen offset:14336 ; c405c07c 40804892 00380030
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[122:123], v[42:43], v[2:9] ; cc464002 1c0a557a
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[122:123], v[144:145], v[10:17] ; cc46400a 1c2b217a
	s_wait_loadcnt_dscnt 0x305                                  ; bfc80305
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[34:35], v[28:29], v[88:95] ; cc464058 1d623922
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[32:33], v[112:119] ; cc464070 1dc24122
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[34:35], v[124:125], v[64:71] ; cc464040 1d02f922
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[34:35], v[24:25], v[80:87] ; cc464050 1d423122
	ds_load_b64 v[42:43], v27 offset:3328                       ; d9d80d00 2a00001b
	ds_load_b64 v[122:123], v27 offset:7424                     ; d9d81d00 7a00001b
	ds_load_b64 v[144:145], v27 offset:11520                    ; d9d82d00 9000001b
	ds_load_b64 v[34:35], v27 offset:15616                      ; d9d83d00 2200001b
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[36:37], v[124:125], v[128:135] ; cc464080 1e02f924
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[36:37], v[28:29], v[152:159] ; cc464098 1e623924
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[36:37], v[32:33], v[168:175] ; cc4640a8 1ea24124
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[36:37], v[24:25], v[136:143] ; cc464088 1e223124
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[162:163], v[24:25], v[176:183] ; cc4640b0 1ec231a2
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[162:163], v[124:125], v[56:63] ; cc464038 1ce2f9a2
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[164:165], v[124:125], v[96:103] ; cc464060 1d82f9a4
	v_dual_mov_b32 v125, v27 :: v_dual_mov_b32 v124, v26        ; ca10011b 7d7c011a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[162:163], v[28:29], v[184:191] ; cc4640b8 1ee239a2
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[162:163], v[32:33], v[104:111] ; cc464068 1da241a2
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[164:165], v[24:25], v[72:79] ; cc464048 1d2231a4
	s_wait_dscnt 0x5                                            ; bfc60005
	v_dual_mov_b32 v37, v161 :: v_dual_mov_b32 v36, v160        ; ca1001a1 252401a0
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[24:27], v48, s[36:39], null offen offset:6656 ; c405c07c 40804818 001a0030
	buffer_load_b128 v[160:163], v48, s[36:39], null offen offset:14848 ; c405c07c 408048a0 003a0030
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[164:165], v[28:29], v[2:9] ; cc464002 1c0a39a4
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[164:165], v[32:33], v[10:17] ; cc46400a 1c2a41a4
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[38:39], v[44:45], v[80:87] ; cc464050 1d425926
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[38:39], v[36:37], v[88:95] ; cc464058 1d624926
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[20:21], v[112:119] ; cc464070 1dc22926
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[38:39], v[150:151], v[64:71] ; cc464040 1d032d26
	ds_load_b64 v[28:29], v125 offset:3584                      ; d9d80e00 1c00007d
	ds_load_b64 v[32:33], v125 offset:7680                      ; d9d81e00 2000007d
	ds_load_b64 v[164:165], v125 offset:11776                   ; d9d82e00 a400007d
	ds_load_b64 v[38:39], v125 offset:15872                     ; d9d83e00 2600007d
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[40:41], v[150:151], v[128:135] ; cc464080 1e032d28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[40:41], v[44:45], v[136:143] ; cc464088 1e225928
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[36:37], v[152:159] ; cc464098 1e624928
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[20:21], v[168:175] ; cc4640a8 1ea22928
	v_dual_mov_b32 v41, v47 :: v_dual_mov_b32 v40, v46          ; ca10012f 2928012e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[146:147], v[36:37], v[184:191] ; cc4640b8 1ee24992
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[146:147], v[150:151], v[56:63] ; cc464038 1ce32d92
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[146:147], v[44:45], v[176:183] ; cc4640b0 1ec25992
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[146:147], v[20:21], v[104:111] ; cc464068 1da22992
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[150:151], v[96:103] ; cc464060 1d832d94
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[148:149], v[44:45], v[72:79] ; cc464048 1d225994
	s_wait_dscnt 0x5                                            ; bfc60005
	v_dual_mov_b32 v151, v145 :: v_dual_mov_b32 v150, v144      ; ca100191 97960190
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v48, s[36:39], null offen offset:7168 ; c405c07c 4080482c 001c0030
	buffer_load_b128 v[144:147], v48, s[36:39], null offen offset:15360 ; c405c07c 40804890 003c0030
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[148:149], v[36:37], v[2:9] ; cc464002 1c0a4994
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[148:149], v[20:21], v[10:17] ; cc46400a 1c2a2994
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[150:151], v[88:95] ; cc464058 1d632d18
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[34:35], v[112:119] ; cc464070 1dc24518
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[122:123], v[80:87] ; cc464050 1d42f518
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[42:43], v[64:71] ; cc464040 1d025518
	ds_load_b64 v[36:37], v125 offset:3840                      ; d9d80f00 2400007d
	ds_load_b64 v[20:21], v125 offset:7936                      ; d9d81f00 1400007d
	ds_load_b64 v[148:149], v125 offset:12032                   ; d9d82f00 9400007d
	ds_load_b64 v[24:25], v125 offset:16128                     ; d9d83f00 1800007d
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[42:43], v[128:135] ; cc464080 1e02551a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[26:27], v[150:151], v[152:159] ; cc464098 1e632d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[26:27], v[34:35], v[168:175] ; cc4640a8 1ea2451a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[122:123], v[136:143] ; cc464088 1e22f51a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[160:161], v[122:123], v[176:183] ; cc4640b0 1ec2f5a0
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[160:161], v[42:43], v[56:63] ; cc464038 1ce255a0
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[162:163], v[42:43], v[96:103] ; cc464060 1d8255a2
	v_mov_b32_e32 v42, v124                                     ; 7e54037c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[160:161], v[150:151], v[184:191] ; cc4640b8 1ee32da0
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[160:161], v[34:35], v[104:111] ; cc464068 1da245a0
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[162:163], v[122:123], v[72:79] ; cc464048 1d22f5a2
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v161, v25 :: v_dual_mov_b32 v160, v24        ; ca100119 a1a00118
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[122:125], v48, s[36:39], null offen offset:7680 ; c405c07c 4080487a 001e0030
	buffer_load_b128 v[24:27], v48, s[36:39], null offen offset:15872 ; c405c07c 40804818 003e0030
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[162:163], v[150:151], v[2:9] ; cc464002 1c0b2da2
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[162:163], v[34:35], v[10:17] ; cc46400a 1c2a45a2
	v_mad_u32_u24 v49, s59, 0x820, v49                          ; d60b0031 04c5fe3b 00000820
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[32:33], v[80:87] ; cc464050 1d42412c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[164:165], v[88:95] ; cc464058 1d63492c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[44:45], v[28:29], v[64:71] ; cc464040 1d02392c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[38:39], v[112:119] ; cc464070 1dc24d2c
	ds_load_b64 v[34:35], v49                                   ; d9d80000 22000031
	ds_load_b64 v[150:151], v49 offset:4096                     ; d9d81000 96000031
	ds_load_b64 v[162:163], v49 offset:8192                     ; d9d82000 a2000031
	ds_load_b64 v[44:45], v49 offset:12288                      ; d9d83000 2c000031
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[32:33], v[136:143] ; cc464088 1e22412e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[46:47], v[38:39], v[168:175] ; cc4640a8 1ea24d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[164:165], v[152:159] ; cc464098 1e63492e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[28:29], v[128:135] ; cc464080 1e02392e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mov_b32 v46, v147 :: v_dual_mov_b32 v43, v146        ; ca100193 2e2a0192
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[144:145], v[28:29], v[56:63] ; cc464038 1ce23990
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[144:145], v[32:33], v[176:183] ; cc4640b0 1ec24190
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[144:145], v[164:165], v[184:191] ; cc4640b8 1ee34990
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[144:145], v[38:39], v[104:111] ; cc464068 1da24d90
	buffer_load_b128 v[144:147], v48, s[36:39], null offen offset:16384 ; c405c07c 40804890 00400030
	v_dual_mov_b32 v47, v46 :: v_dual_mov_b32 v46, v43          ; ca10012e 2f2e012b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[46:47], v[32:33], v[72:79] ; cc464048 1d22412e
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[46:47], v[164:165], v[2:9] ; cc464002 1c0b492e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[28:29], v[96:103] ; cc464060 1d82392e
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[46:47], v[38:39], v[10:17] ; cc46400a 1c2a4d2e
	ds_load_b64 v[28:29], v49 offset:256                        ; d9d80100 1c000031
	ds_load_b64 v[32:33], v49 offset:4352                       ; d9d81100 20000031
	ds_load_b64 v[164:165], v49 offset:8448                     ; d9d82100 a4000031
	ds_load_b64 v[38:39], v49 offset:12544                      ; d9d83100 26000031
	s_mov_b32 s61, 0x76543210                                   ; bebd00ff 76543210
	s_mov_b32 s62, 0xfedcba98                                   ; bebe00ff fedcba98
	s_movk_i32 s63, 0x410                                       ; b03f0410
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[124:125], v[148:149], v[152:159] ; cc464098 1e63297c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[124:125], v[20:21], v[136:143] ; cc464088 1e22297c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[122:123], v[160:161], v[112:119] ; cc464070 1dc3417a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[122:123], v[36:37], v[64:71] ; cc464040 1d02497a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[122:123], v[20:21], v[80:87] ; cc464050 1d42297a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[124:125], v[36:37], v[128:135] ; cc464080 1e02497c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[124:125], v[160:161], v[168:175] ; cc4640a8 1ea3417c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[122:123], v[148:149], v[88:95] ; cc464058 1d63297a
	v_dual_mul_f32 v122, v131, v131 :: v_dual_mul_f32 v47, v129, v129 ; c8c70783 7a2f0381
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v122, v67, v67 :: v_dual_fmac_f32 v47, v65, v65 ; c8008743 7a2e8341
	v_dual_fmac_f32 v122, v71, v71 :: v_dual_fmac_f32 v47, v69, v69 ; c8008f47 7a2e8b45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v122, v135, v135 :: v_dual_fmac_f32 v47, v133, v133 ; c8010f87 7a2f0b85
	v_dual_fmac_f32 v122, v66, v66 :: v_dual_fmac_f32 v47, v64, v64 ; c8008542 7a2e8140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v122, v130, v130 :: v_dual_fmac_f32 v47, v128, v128 ; c8010582 7a2f0180
	v_dual_fmac_f32 v122, v70, v70 :: v_dual_fmac_f32 v47, v68, v68 ; c8008d46 7a2e8944
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v122, v134, v134 :: v_dual_fmac_f32 v47, v132, v132 ; c8010d86 7a2f0984
	v_fma_mixlo_f16 v123, 1.0, v47, v122                        ; cc21007b 05ea5ef2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v124, v123                                ; 7ef8d77b
	v_permlanex16_b32 v124, v124, s61, s62 op_sel:[1,1]         ; d65c187c 00f87b7c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v123, v123, v124                              ; 64f6f97b
	v_max_num_f16_e32 v123, s63, v123                           ; 62f6f63f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v125, v123                                ; 7efa177b
	v_rsq_f32_e32 v125, v125                                    ; 7efa5d7d
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v125, v125, v19                               ; 10fa277d
	v_dual_mul_f32 v64, v64, v125 :: v_dual_mul_f32 v65, v65, v125 ; c8c6fb40 4040fb41
	v_dual_mul_f32 v129, v129, v125 :: v_dual_mul_f32 v128, v128, v125 ; c8c6fb81 8180fb80
	v_dual_mul_f32 v131, v131, v125 :: v_dual_mul_f32 v130, v130, v125 ; c8c6fb83 8382fb82
	v_dual_mul_f32 v66, v66, v125 :: v_dual_mul_f32 v67, v67, v125 ; c8c6fb42 4242fb43
	v_dual_mul_f32 v68, v68, v125 :: v_dual_mul_f32 v69, v69, v125 ; c8c6fb44 4444fb45
	v_dual_mul_f32 v135, v135, v125 :: v_dual_mul_f32 v134, v134, v125 ; c8c6fb87 8786fb86
	v_dual_mul_f32 v133, v133, v125 :: v_dual_mul_f32 v132, v132, v125 ; c8c6fb85 8584fb84
	v_dual_mul_f32 v71, v71, v125 :: v_dual_mul_f32 v70, v70, v125 ; c8c6fb47 4746fb46
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v129, v139, v139 :: v_dual_mul_f32 v128, v137, v137 ; c8c7178b 81811389
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_dual_fmac_f32 v129, v83, v83 :: v_dual_fmac_f32 v128, v81, v81 ; c800a753 8180a351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v129, v87, v87 :: v_dual_fmac_f32 v128, v85, v85 ; c800af57 8180ab55
	v_dual_fmac_f32 v129, v143, v143 :: v_dual_fmac_f32 v128, v141, v141 ; c8011f8f 81811b8d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v129, v82, v82 :: v_dual_fmac_f32 v128, v80, v80 ; c800a552 8180a150
	v_dual_fmac_f32 v129, v138, v138 :: v_dual_fmac_f32 v128, v136, v136 ; c801158a 81811188
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v129, v86, v86 :: v_dual_fmac_f32 v128, v84, v84 ; c800ad56 8180a954
	v_dual_fmac_f32 v129, v142, v142 :: v_dual_fmac_f32 v128, v140, v140 ; c8011d8e 8181198c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v130, 1.0, v128, v129                       ; cc210082 060700f2
(invalid instruction)                                        ; d5eb0083
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                    ; 02010182
	v_dual_mul_f32 v134, v155, v155 :: v_dual_mul_f32 v133, v153, v153 ; c8c7379b 86853399
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v131, v131, s61, s62 op_sel:[1,1]         ; d65c1883 00f87b83
	v_dual_fmac_f32 v134, v91, v91 :: v_dual_fmac_f32 v133, v89, v89 ; c800b75b 8684b359
(invalid instruction)                                        ; d5320082
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_fmac_f32 v134, v95, v95 :: v_dual_fmac_f32 v133, v93, v93 ; c800bf5f 8684bb5d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d5310082
	v_cndmask_b32_e32 v1, s63, v130, vcc_lo                     ; 0203043f
	v_dual_fmac_f32 v134, v159, v159 :: v_dual_fmac_f32 v133, v157, v157 ; c8013f9f 86853b9d
(invalid instruction)                                        ; d58b0084
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                    ; 02010182
	v_dual_fmac_f32 v134, v90, v90 :: v_dual_fmac_f32 v133, v88, v88 ; c800b55a 8684b158
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a2
	v_rsq_f32_e32 v132, v132                                    ; 7f085d84
	v_dual_fmac_f32 v134, v154, v154 :: v_dual_fmac_f32 v133, v152, v152 ; c801359a 86853198
	v_mul_f32_e32 v132, v132, v19                               ; 11082784
	v_dual_fmac_f32 v134, v94, v94 :: v_dual_fmac_f32 v133, v92, v92 ; c800bd5e 8684b95c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v87, v87, v132 :: v_dual_mul_f32 v86, v86, v132 ; c8c70957 57570956
	v_dual_mul_f32 v136, v136, v132 :: v_dual_mul_f32 v137, v137, v132 ; c8c70988 88890989
	v_dual_mul_f32 v83, v83, v132 :: v_dual_mul_f32 v82, v82, v132 ; c8c70953 53530952
	v_dual_mul_f32 v138, v138, v132 :: v_dual_mul_f32 v139, v139, v132 ; c8c7098a 8a8b098b
	v_dual_mul_f32 v85, v85, v132 :: v_dual_mul_f32 v84, v84, v132 ; c8c70955 55550954
	v_dual_mul_f32 v81, v81, v132 :: v_dual_mul_f32 v80, v80, v132 ; c8c70951 51510950
	v_dual_mul_f32 v140, v140, v132 :: v_dual_mul_f32 v141, v141, v132 ; c8c7098c 8c8d098d
	v_dual_mul_f32 v143, v143, v132 :: v_dual_mul_f32 v142, v142, v132 ; c8c7098f 8f8f098e
	v_dual_fmac_f32 v134, v158, v158 :: v_dual_fmac_f32 v133, v156, v156 ; c8013d9e 8685399c
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mixlo_f16 v135, 1.0, v133, v134                       ; cc210087 061b0af2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; d5eb0088
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                    ; 02010187
	v_dual_mul_f32 v139, v171, v171 :: v_dual_mul_f32 v138, v169, v169 ; c8c757ab 8b8b53a9
	v_permlanex16_b32 v136, v136, s61, s62 op_sel:[1,1]         ; d65c1888 00f87b88
	v_dual_fmac_f32 v139, v115, v115 :: v_dual_fmac_f32 v138, v113, v113 ; c800e773 8b8ae371
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d5320087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                    ; 02031187
	v_dual_fmac_f32 v139, v119, v119 :: v_dual_fmac_f32 v138, v117, v117 ; c800ef77 8b8aeb75
(invalid instruction)                                        ; d5310087
	v_cndmask_b32_e32 v1, s63, v135, vcc_lo                     ; 02030e3f
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[36:37], v[56:63] ; cc464038 1ce24918
(invalid instruction)                                        ; d58b0089
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                    ; 02010187
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[24:25], v[20:21], v[176:183] ; cc4640b0 1ec22918
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[24:25], v[148:149], v[184:191] ; cc4640b8 1ee32918
	v_rsq_f32_e32 v137, v137                                    ; 7f125d89
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[160:161], v[104:111] ; cc464068 1da34118
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[36:37], v[96:103] ; cc464060 1d82491a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[20:21], v[72:79] ; cc464048 1d22291a
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[26:27], v[148:149], v[2:9] ; cc464002 1c0b291a
	v_mul_f32_e32 v137, v137, v19                               ; 11122789
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[26:27], v[160:161], v[10:17] ; cc46400a 1c2b411a
	v_dual_fmac_f32 v139, v175, v175 :: v_dual_fmac_f32 v138, v173, v173 ; c8015faf 8b8b5bad
	v_dual_mul_f32 v153, v153, v137 :: v_dual_mul_f32 v152, v152, v137 ; c8c71399 99991398
	v_dual_mul_f32 v155, v155, v137 :: v_dual_mul_f32 v154, v154, v137 ; c8c7139b 9b9b139a
	v_dual_mul_f32 v92, v92, v137 :: v_dual_mul_f32 v93, v93, v137 ; c8c7135c 5c5d135d
	v_dual_mul_f32 v88, v88, v137 :: v_dual_mul_f32 v89, v89, v137 ; c8c71358 58591359
	v_dual_mul_f32 v90, v90, v137 :: v_dual_mul_f32 v91, v91, v137 ; c8c7135a 5a5b135b
	v_dual_mul_f32 v95, v95, v137 :: v_dual_mul_f32 v94, v94, v137 ; c8c7135f 5f5f135e
	v_dual_mul_f32 v157, v157, v137 :: v_dual_mul_f32 v156, v156, v137 ; c8c7139d 9d9d139c
	v_dual_mul_f32 v159, v159, v137 :: v_dual_mul_f32 v158, v158, v137 ; c8c7139f 9f9f139e
	v_dual_fmac_f32 v139, v114, v114 :: v_dual_fmac_f32 v138, v112, v112 ; c800e572 8b8ae170
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_dual_fmac_f32 v139, v170, v170 :: v_dual_fmac_f32 v138, v168, v168 ; c80155aa 8b8b51a8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v139, v118, v118 :: v_dual_fmac_f32 v138, v116, v116 ; c800ed76 8b8ae974
	v_dual_fmac_f32 v139, v174, v174 :: v_dual_fmac_f32 v138, v172, v172 ; c8015dae 8b8b59ac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v140, 1.0, v138, v139                       ; cc21008c 062f14f2
(invalid instruction)                                        ; d5eb008d
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                    ; 0201018c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v141, v141, s61, s62 op_sel:[1,1]         ; d65c188d 00f87b8d
(invalid instruction)                                        ; d532008c
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d531008c
	v_cndmask_b32_e32 v1, s63, v140, vcc_lo                     ; 0203183f
(invalid instruction)                                        ; d58b008e
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                    ; 0201018c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v142, v142                                    ; 7f1c5d8e
	v_mul_f32_e32 v142, v142, v19                               ; 111c278e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v119, v119, v142 :: v_dual_mul_f32 v116, v116, v142 ; c8c71d77 77751d74
	v_dual_mul_f32 v173, v173, v142 :: v_dual_mul_f32 v170, v170, v142 ; c8c71dad adab1daa
	v_dual_mul_f32 v169, v169, v142 :: v_dual_mul_f32 v118, v118, v142 ; c8c71da9 a9771d76
	v_dual_mul_f32 v175, v175, v142 :: v_dual_mul_f32 v172, v172, v142 ; c8c71daf afad1dac
	v_mul_f32_e32 v113, v113, v142                              ; 10e31d71
	v_dual_mul_f32 v115, v115, v142 :: v_dual_mul_f32 v112, v112, v142 ; c8c71d73 73711d70
	v_dual_mul_f32 v143, v97, v97 :: v_dual_mul_f32 v174, v174, v142 ; c8c6c361 8faf1dae
	v_dual_mul_f32 v117, v117, v142 :: v_dual_mul_f32 v114, v114, v142 ; c8c71d75 75731d72
	v_dual_mul_f32 v171, v171, v142 :: v_dual_mul_f32 v168, v168, v142 ; c8c71dab aba91da8
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	buffer_load_b128 v[80:83], v48, s[36:39], null offen offset:16896 ; c405c07c 40804850 00420030
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_dual_fmac_f32 v143, v57, v57 :: v_dual_mul_f32 v148, v99, v99 ; c8067339 8f94c763
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_dual_fmac_f32 v143, v61, v61 :: v_dual_fmac_f32 v148, v59, v59 ; c8007b3d 8f94773b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v143, v101, v101 :: v_dual_fmac_f32 v148, v63, v63 ; c800cb65 8f947f3f
	v_dual_fmac_f32 v143, v56, v56 :: v_dual_fmac_f32 v148, v103, v103 ; c8007138 8f94cf67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v143, v96, v96 :: v_dual_fmac_f32 v148, v58, v58 ; c800c160 8f94753a
	v_dual_fmac_f32 v143, v60, v60 :: v_dual_fmac_f32 v148, v98, v98 ; c800793c 8f94c562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v143, v100, v100 :: v_dual_fmac_f32 v148, v62, v62 ; c800c964 8f947d3e
	v_fmac_f32_e32 v148, v102, v102                             ; 5728cd66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v149, 1.0, v143, v148                       ; cc210095 06531ef2
(invalid instruction)                                        ; d5eb0098
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                    ; 02010195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v152, v152, s61, s62 op_sel:[1,1]         ; d65c1898 00f87b98
(invalid instruction)                                        ; d5320095
	v_cndmask_b32_e32 v1, v149, v152, vcc_lo                    ; 02033195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5310095
	v_cndmask_b32_e32 v1, s63, v149, vcc_lo                     ; 02032a3f
(invalid instruction)                                        ; d58b0099
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                    ; 02010195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v153, v153                                    ; 7f325d99
	v_mul_f32_e32 v56, v56, v153                                ; 10713338
	v_dual_mul_f32 v58, v58, v153 :: v_dual_mul_f32 v57, v57, v153 ; c8c7333a 3a393339
	v_dual_mul_f32 v60, v60, v153 :: v_dual_mul_f32 v59, v59, v153 ; c8c7333c 3c3b333b
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v48, s[36:39], null offen offset:17408 ; c405c07c 40804838 00440030
	buffer_load_b128 v[84:87], v48, s[36:39], null offen offset:17920 ; c405c07c 40804854 00460030
	v_mul_f32_e32 v61, v61, v153                                ; 107b333d
	v_dual_mul_f32 v97, v97, v153 :: v_dual_mul_f32 v96, v96, v153 ; c8c73361 61613360
	v_dual_mul_f32 v63, v63, v153 :: v_dual_mul_f32 v62, v62, v153 ; c8c7333f 3f3f333e
	v_dual_mul_f32 v101, v101, v153 :: v_dual_mul_f32 v100, v100, v153 ; c8c73365 65653364
	v_dual_mul_f32 v99, v99, v153 :: v_dual_mul_f32 v98, v98, v153 ; c8c73363 63633362
	buffer_load_b128 v[88:91], v48, s[36:39], null offen offset:18432 ; c405c07c 40804858 00480030
	v_dual_mul_f32 v103, v103, v153 :: v_dual_mul_f32 v102, v102, v153 ; c8c73367 67673366
	v_mul_f32_e32 v154, v73, v73                                ; 11349349
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fmac_f32_e32 v154, v177, v177                             ; 573563b1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v154, v181, v181                             ; 57356bb5
	v_dual_fmac_f32 v154, v77, v77 :: v_dual_mul_f32 v155, v75, v75 ; c8069b4d 9a9a974b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v154, v176, v176 :: v_dual_fmac_f32 v155, v179, v179 ; c80161b0 9a9b67b3
	v_dual_fmac_f32 v154, v72, v72 :: v_dual_fmac_f32 v155, v183, v183 ; c8009148 9a9b6fb7
	buffer_load_b128 v[92:95], v48, s[36:39], null offen offset:18944 ; c405c07c 4080485c 004a0030
	v_dual_fmac_f32 v154, v180, v180 :: v_dual_fmac_f32 v155, v79, v79 ; c80169b4 9a9a9f4f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v155, v178, v178                             ; 573765b2
	v_fmac_f32_e32 v155, v74, v74                               ; 5736954a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v155, v182, v182                             ; 57376db6
	v_dual_fmac_f32 v155, v78, v78 :: v_dual_fmac_f32 v154, v76, v76 ; c8009d4e 9b9a994c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v156, 1.0, v154, v155                       ; cc21009c 066f34f2
(invalid instruction)                                        ; d5eb009d
	v_cndmask_b32_e32 v0, v156, v128, vcc_lo                    ; 0201019c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v157, v157, s61, s62 op_sel:[1,1]         ; d65c189d 00f87b9d
(invalid instruction)                                        ; d532009c
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	buffer_load_b128 v[96:99], v48, s[36:39], null offen offset:19456 ; c405c07c 40804860 004c0030
(invalid instruction)                                        ; d531009c
	v_cndmask_b32_e32 v1, s63, v156, vcc_lo                     ; 0203383f
	v_dual_mul_f32 v159, v3, v3 :: v_dual_mul_f32 v160, v5, v5  ; c8c60703 9fa00b05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d58b009e
	v_cndmask_b32_e32 v0, v156, v128, vcc_lo                    ; 0201019c
	v_dual_fmac_f32 v159, v185, v185 :: v_dual_fmac_f32 v160, v187, v187 ; c80173b9 9fa177bb
	v_rsq_f32_e32 v158, v158                                    ; 7f3c5d9e
	v_dual_fmac_f32 v159, v189, v189 :: v_dual_fmac_f32 v160, v191, v191 ; c8017bbd 9fa17fbf
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v177, v177, v158 :: v_dual_mul_f32 v176, v176, v158 ; c8c73db1 b1b13db0
	v_dual_mul_f32 v181, v181, v158 :: v_dual_mul_f32 v180, v180, v158 ; c8c73db5 b5b53db4
	v_dual_mul_f32 v179, v179, v158 :: v_dual_mul_f32 v178, v178, v158 ; c8c73db3 b3b33db2
	v_dual_fmac_f32 v159, v7, v7 :: v_dual_mul_f32 v78, v78, v158 ; c8060f07 9f4f3d4e
	v_dual_mul_f32 v79, v79, v158 :: v_dual_mul_f32 v76, v76, v158 ; c8c73d4f 4f4d3d4c
	v_mul_f32_e32 v77, v77, v158                                ; 109b3d4d
	v_dual_mul_f32 v73, v73, v158 :: v_dual_mul_f32 v72, v72, v158 ; c8c73d49 49493d48
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	buffer_load_b128 v[76:79], v48, s[36:39], null offen offset:19968 ; c405c07c 4080484c 004e0030
	v_dual_mul_f32 v183, v183, v158 :: v_dual_mul_f32 v182, v182, v158 ; c8c73db7 b7b73db6
	v_dual_mul_f32 v75, v75, v158 :: v_dual_mul_f32 v74, v74, v158 ; c8c73d4b 4b4b3d4a
	v_fmac_f32_e32 v160, v9, v9                                 ; 57401309
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	buffer_load_b128 v[100:103], v48, s[36:39], null offen offset:20480 ; c405c07c 40804864 00500030
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_dual_fmac_f32 v160, v186, v186 :: v_dual_fmac_f32 v159, v184, v184 ; c80175ba a09f71b8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v160, v4, v4 :: v_dual_fmac_f32 v159, v2, v2 ; c8000904 a09e0502
	v_dual_fmac_f32 v160, v190, v190 :: v_dual_fmac_f32 v159, v188, v188 ; c8017dbe a09f79bc
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v160, v8, v8 :: v_dual_fmac_f32 v159, v6, v6 ; c8001108 a09e0d06
	v_fma_mixlo_f16 v161, 1.0, v159, v160                       ; cc2100a1 06833ef2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d5eb00a6
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
	buffer_load_b128 v[112:115], v48, s[36:39], null offen offset:20992 ; c405c07c 40804870 00520030
	v_permlanex16_b32 v166, v166, s61, s62 op_sel:[1,1]         ; d65c18a6 00f87ba6
(invalid instruction)                                        ; d53200a1
	v_cndmask_b32_e32 v1, v161, v166, vcc_lo                    ; 02034da1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; d53100a1
	v_cndmask_b32_e32 v1, s63, v161, vcc_lo                     ; 0203423f
	v_dual_mul_f32 v169, v13, v13 :: v_dual_mul_f32 v168, v11, v11 ; c8c61b0d a9a8170b
(invalid instruction)                                        ; d58b00a7
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
	v_dual_fmac_f32 v169, v107, v107 :: v_dual_fmac_f32 v168, v105, v105 ; c800d76b a9a8d369
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_rsq_f32_e32 v167, v167                                    ; 7f4e5da7
	v_dual_fmac_f32 v169, v111, v111 :: v_dual_fmac_f32 v168, v109, v109 ; c800df6f a9a8db6d
	v_dual_fmac_f32 v169, v17, v17 :: v_dual_fmac_f32 v168, v15, v15 ; c8002311 a9a81f0f
	v_dual_mul_f32 v7, v7, v167 :: v_dual_mul_f32 v6, v6, v167  ; c8c74f07 07074f06
	v_dual_mul_f32 v9, v9, v167 :: v_dual_mul_f32 v8, v8, v167  ; c8c74f09 09094f08
	v_dual_mul_f32 v188, v188, v167 :: v_dual_mul_f32 v187, v187, v167 ; c8c74fbc bcbb4fbb
	v_dual_mul_f32 v186, v186, v167 :: v_dual_mul_f32 v185, v185, v167 ; c8c74fba bab94fb9
	v_mul_f32_e32 v184, v184, v167                              ; 11714fb8
	v_mul_f32_e32 v3, v3, v167                                  ; 10074f03
	v_dual_mul_f32 v190, v190, v167 :: v_dual_mul_f32 v189, v189, v167 ; c8c74fbe bebd4fbd
	v_dual_mul_f32 v5, v5, v167 :: v_dual_mul_f32 v4, v4, v167  ; c8c74f05 05054f04
	v_dual_mul_f32 v2, v2, v167 :: v_dual_mul_f32 v191, v191, v167 ; c8c74f02 02bf4fbf
	v_dual_fmac_f32 v169, v106, v106 :: v_dual_fmac_f32 v168, v104, v104 ; c800d56a a9a8d168
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v2, v3, vcc_lo                        ; 02020702
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                        ; 02020b04
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_dual_fmac_f32 v169, v12, v12 :: v_dual_fmac_f32 v168, v10, v10 ; c800190c a9a8150a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v169, v110, v110 :: v_dual_fmac_f32 v168, v108, v108 ; c800dd6e a9a8d96c
	v_dual_fmac_f32 v169, v16, v16 :: v_dual_fmac_f32 v168, v14, v14 ; c8002110 a9a81d0e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v170, 1.0, v168, v169                       ; cc2100aa 06a750f2
(invalid instruction)                                        ; d5eb00ab
	v_cndmask_b32_e32 v0, v170, v128, vcc_lo                    ; 020101aa
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v171, v171, s61, s62 op_sel:[1,1]         ; d65c18ab 00f87bab
(invalid instruction)                                        ; d53200aa
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53100aa
	v_cndmask_b32_e32 v1, s63, v170, vcc_lo                     ; 0203543f
(invalid instruction)                                        ; d58b00ac
	v_cndmask_b32_e32 v0, v170, v128, vcc_lo                    ; 020101aa
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v172, v172                                    ; 7f585dac
	v_dual_mul_f32 v107, v107, v172 :: v_dual_mul_f32 v106, v106, v172 ; c8c7596b 6b6b596a
	v_dual_mul_f32 v11, v11, v172 :: v_dual_mul_f32 v10, v10, v172 ; c8c7590b 0b0b590a
	v_dual_mul_f32 v105, v105, v172 :: v_dual_mul_f32 v104, v104, v172 ; c8c75969 69695968
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_mul_f32 v109, v109, v172 :: v_dual_mul_f32 v108, v108, v172 ; c8c7596d 6d6d596c
	v_dual_mul_f32 v111, v111, v172 :: v_dual_mul_f32 v110, v110, v172 ; c8c7596f 6f6f596e
	v_dual_mul_f32 v13, v13, v172 :: v_dual_mul_f32 v12, v12, v172 ; c8c7590d 0d0d590c
	v_dual_mul_f32 v15, v15, v172 :: v_dual_mul_f32 v14, v14, v172 ; c8c7590f 0f0f590e
	v_dual_mul_f32 v17, v17, v172 :: v_dual_mul_f32 v16, v16, v172 ; c8c75911 11115910
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	ds_load_b64 v[8:9], v49 offset:512                          ; d9d80200 08000031
	ds_load_b64 v[10:11], v49 offset:4608                       ; d9d81200 0a000031
	ds_load_b64 v[104:105], v49 offset:8704                     ; d9d82200 68000031
	ds_load_b64 v[106:107], v49 offset:12800                    ; d9d83200 6a000031
	ds_load_b64 v[12:13], v49 offset:768                        ; d9d80300 0c000031
	ds_load_b64 v[14:15], v49 offset:4864                       ; d9d81300 0e000031
	ds_load_b64 v[16:17], v49 offset:8960                       ; d9d82300 10000031
	ds_load_b64 v[108:109], v49 offset:13056                    ; d9d83300 6c000031
	s_wait_loadcnt_dscnt 0x90f                                  ; bfc8090f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[144:145], v[34:35], 0 ; cc464080 1a024590
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[146:147], v[34:35], 0 ; cc4640b0 1a024592
	v_dual_mov_b32 v34, v121 :: v_dual_mov_b32 v19, v120        ; ca100179 22120178
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_dual_mov_b32 v111, v147 :: v_dual_mov_b32 v110, v146      ; ca100193 6f6e0192
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[144:145], v[150:151], 0 ; cc464088 1a032d90
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[144:145], v[162:163], 0 ; cc464098 1a034590
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[144:145], v[44:45], 0 ; cc4640a8 1a025990
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[146:147], v[150:151], 0 ; cc4640b8 1a032d92
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[146:147], v[162:163], 0 ; cc464074 1a034592
	s_wait_loadcnt_dscnt 0x80b                                  ; bfc8080b
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[28:29], v[128:135] ; cc464080 1e023950
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[110:111], v[44:45], 0 ; cc464090 1a02596e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[82:83], v[28:29], v[176:183] ; cc4640b0 1ec23952
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[80:81], v[32:33], v[136:143] ; cc464088 1e224150
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[80:81], v[164:165], v[152:159] ; cc464098 1e634950
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[80:81], v[38:39], v[168:175] ; cc4640a8 1ea24d50
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[82:83], v[32:33], v[184:191] ; cc4640b8 1ee24152
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[82:83], v[38:39], v[144:151] ; cc464090 1e424d52
	ds_load_b64 v[44:45], v49 offset:1024                       ; d9d80400 2c000031
	ds_load_b64 v[110:111], v49 offset:5120                     ; d9d81400 6e000031
	ds_load_b64 v[124:125], v49 offset:9216                     ; d9d82400 7c000031
	ds_load_b64 v[160:161], v49 offset:13312                    ; d9d83400 a0000031
	ds_load_b64 v[28:29], v49 offset:1280                       ; d9d80500 1c000031
	ds_load_b64 v[32:33], v49 offset:5376                       ; d9d81500 20000031
	ds_load_b64 v[38:39], v49 offset:9472                       ; d9d82500 26000031
	ds_load_b64 v[80:81], v49 offset:13568                      ; d9d83500 50000031
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[82:83], v[164:165], v[116:123] ; cc464074 1dd34952
	s_wait_loadcnt_dscnt 0x70f                                  ; bfc8070f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[8:9], v[128:135] ; cc464080 1e021138
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[56:57], v[10:11], v[136:143] ; cc464088 1e221538
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[58:59], v[8:9], v[176:183] ; cc4640b0 1ec2113a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[104:105], v[152:159] ; cc464098 1e62d138
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[56:57], v[106:107], v[168:175] ; cc4640a8 1ea2d538
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[58:59], v[10:11], v[184:191] ; cc4640b8 1ee2153a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[58:59], v[106:107], v[144:151] ; cc464090 1e42d53a
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[58:59], v[104:105], v[116:123] ; cc464074 1dd2d13a
	ds_load_b64 v[8:9], v49 offset:1536                         ; d9d80600 08000031
	ds_load_b64 v[10:11], v49 offset:5632                       ; d9d81600 0a000031
	ds_load_b64 v[56:57], v49 offset:9728                       ; d9d82600 38000031
	ds_load_b64 v[58:59], v49 offset:13824                      ; d9d83600 3a000031
	s_wait_loadcnt_dscnt 0x60f                                  ; bfc8060f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[12:13], v[128:135] ; cc464080 1e021954
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[84:85], v[14:15], v[136:143] ; cc464088 1e221d54
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[86:87], v[12:13], v[176:183] ; cc4640b0 1ec21956
	v_dual_mov_b32 v163, v15 :: v_dual_mov_b32 v162, v14        ; ca10010f a3a2010e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[84:85], v[16:17], v[152:159] ; cc464098 1e622154
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[84:85], v[108:109], v[168:175] ; cc4640a8 1ea2d954
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[104:107], v48, s[36:39], null offen offset:21504 ; c405c07c 40804868 00540030
	buffer_load_b128 v[164:167], v48, s[36:39], null offen offset:22016 ; c405c07c 408048a4 00560030
	buffer_load_b128 v[82:85], v48, s[36:39], null offen offset:22528 ; c405c07c 40804852 00580030
	buffer_load_b128 v[12:15], v48, s[36:39], null offen offset:23040 ; c405c07c 4080480c 005a0030
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[86:87], v[108:109], v[144:151] ; cc464090 1e42d956
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[86:87], v[16:17], v[116:123] ; cc464074 1dd22156
	s_wait_loadcnt_dscnt 0x90b                                  ; bfc8090b
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[88:89], v[44:45], v[128:135] ; cc464080 1e025958
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[88:89], v[110:111], v[136:143] ; cc464088 1e22dd58
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[86:87], v[162:163], v[184:191] ; cc4640b8 1ee34556
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[90:91], v[44:45], v[176:183] ; cc4640b0 1ec2595a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[88:89], v[124:125], v[152:159] ; cc464098 1e62f958
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[88:89], v[160:161], v[168:175] ; cc4640a8 1ea34158
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[90:91], v[160:161], v[144:151] ; cc464090 1e43415a
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[90:91], v[124:125], v[116:123] ; cc464074 1dd2f95a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[90:91], v[110:111], v[184:191] ; cc4640b8 1ee2dd5a
	ds_load_b64 v[16:17], v49 offset:1792                       ; d9d80700 10000031
	ds_load_b64 v[86:87], v49 offset:5888                       ; d9d81700 56000031
	ds_load_b64 v[108:109], v49 offset:9984                     ; d9d82700 6c000031
	ds_load_b64 v[162:163], v49 offset:14080                    ; d9d83700 a2000031
	ds_load_b64 v[44:45], v49 offset:2048                       ; d9d80800 2c000031
	ds_load_b64 v[88:89], v49 offset:6144                       ; d9d81800 58000031
	ds_load_b64 v[90:91], v49 offset:10240                      ; d9d82800 5a000031
	ds_load_b64 v[110:111], v49 offset:14336                    ; d9d83800 6e000031
	s_wait_loadcnt_dscnt 0x80f                                  ; bfc8080f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[28:29], v[128:135] ; cc464080 1e02395c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[92:93], v[32:33], v[136:143] ; cc464088 1e22415c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[94:95], v[28:29], v[176:183] ; cc4640b0 1ec2395e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[92:93], v[38:39], v[152:159] ; cc464098 1e624d5c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[92:93], v[80:81], v[168:175] ; cc4640a8 1ea2a15c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[94:95], v[80:81], v[144:151] ; cc464090 1e42a15e
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[94:95], v[38:39], v[116:123] ; cc464074 1dd24d5e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[94:95], v[32:33], v[184:191] ; cc4640b8 1ee2415e
	s_wait_loadcnt_dscnt 0x70b                                  ; bfc8070b
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[96:97], v[8:9], v[128:135] ; cc464080 1e021160
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[96:97], v[10:11], v[136:143] ; cc464088 1e221560
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[98:99], v[8:9], v[176:183] ; cc4640b0 1ec21162
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[56:57], v[152:159] ; cc464098 1e627160
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[96:97], v[58:59], v[168:175] ; cc4640a8 1ea27560
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[98:99], v[58:59], v[144:151] ; cc464090 1e427562
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[98:99], v[56:57], v[116:123] ; cc464074 1dd27162
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[10:11], v[184:191] ; cc4640b8 1ee21562
	ds_load_b64 v[28:29], v49 offset:2304                       ; d9d80900 1c000031
	ds_load_b64 v[32:33], v49 offset:6400                       ; d9d81900 20000031
	ds_load_b64 v[38:39], v49 offset:10496                      ; d9d82900 26000031
	ds_load_b64 v[80:81], v49 offset:14592                      ; d9d83900 50000031
	ds_load_b64 v[8:9], v49 offset:2560                         ; d9d80a00 08000031
	ds_load_b64 v[10:11], v49 offset:6656                       ; d9d81a00 0a000031
	ds_load_b64 v[56:57], v49 offset:10752                      ; d9d82a00 38000031
	ds_load_b64 v[58:59], v49 offset:14848                      ; d9d83a00 3a000031
	s_wait_loadcnt_dscnt 0x60f                                  ; bfc8060f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[16:17], v[128:135] ; cc464080 1e02214c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[76:77], v[86:87], v[136:143] ; cc464088 1e22ad4c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[78:79], v[16:17], v[176:183] ; cc4640b0 1ec2214e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[76:77], v[108:109], v[152:159] ; cc464098 1e62d94c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[76:77], v[162:163], v[168:175] ; cc4640a8 1ea3454c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[78:79], v[162:163], v[144:151] ; cc464090 1e43454e
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[78:79], v[108:109], v[116:123] ; cc464074 1dd2d94e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[78:79], v[86:87], v[184:191] ; cc4640b8 1ee2ad4e
	ds_load_b64 v[16:17], v49 offset:2816                       ; d9d80b00 10000031
	ds_load_b64 v[76:77], v49 offset:6912                       ; d9d81b00 4c000031
	ds_load_b64 v[78:79], v49 offset:11008                      ; d9d82b00 4e000031
	ds_load_b64 v[86:87], v49 offset:15104                      ; d9d83b00 56000031
	ds_load_b64 v[92:93], v49 offset:3072                       ; d9d80c00 5c000031
	ds_load_b64 v[94:95], v49 offset:7168                       ; d9d81c00 5e000031
	ds_load_b64 v[96:97], v49 offset:11264                      ; d9d82c00 60000031
	ds_load_b64 v[98:99], v49 offset:15360                      ; d9d83c00 62000031
	ds_load_b64 v[108:109], v49 offset:3328                     ; d9d80d00 6c000031
	ds_load_b64 v[124:125], v49 offset:7424                     ; d9d81d00 7c000031
	ds_load_b64 v[160:161], v49 offset:11520                    ; d9d82d00 a0000031
	ds_load_b64 v[162:163], v49 offset:15616                    ; d9d83d00 a2000031
	s_wait_loadcnt_dscnt 0x517                                  ; bfc80517
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[100:101], v[44:45], v[128:135] ; cc464080 1e025964
	s_wait_dscnt 0x16                                           ; bfc60016
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[100:101], v[88:89], v[136:143] ; cc464088 1e22b164
	s_wait_dscnt 0x15                                           ; bfc60015
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[100:101], v[90:91], v[152:159] ; cc464098 1e62b564
	s_wait_dscnt 0x14                                           ; bfc60014
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[100:101], v[110:111], v[168:175] ; cc4640a8 1ea2dd64
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[102:103], v[44:45], v[176:183] ; cc4640b0 1ec25966
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[102:103], v[90:91], v[116:123] ; cc464074 1dd2b566
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[102:103], v[110:111], v[144:151] ; cc464090 1e42dd66
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[102:103], v[88:89], v[184:191] ; cc4640b8 1ee2b166
	s_wait_loadcnt_dscnt 0x413                                  ; bfc80413
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[112:113], v[28:29], v[128:135] ; cc464080 1e023970
	s_wait_dscnt 0x12                                           ; bfc60012
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[32:33], v[136:143] ; cc464088 1e224170
	s_wait_dscnt 0x11                                           ; bfc60011
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[38:39], v[152:159] ; cc464098 1e624d70
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[28:29], v[176:183] ; cc4640b0 1ec23972
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[114:115], v[38:39], v[116:123] ; cc464074 1dd24d72
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[32:33], v[184:191] ; cc4640b8 1ee24172
	ds_load_b64 v[100:101], v49 offset:3584                     ; d9d80e00 64000031
	ds_load_b64 v[44:45], v49 offset:7680                       ; d9d81e00 2c000031
	ds_load_b64 v[88:89], v49 offset:11776                      ; d9d82e00 58000031
	ds_load_b64 v[90:91], v49 offset:15872                      ; d9d83e00 5a000031
	ds_load_b64 v[102:103], v49 offset:3840                     ; d9d80f00 66000031
	ds_load_b64 v[28:29], v49 offset:7936                       ; d9d81f00 1c000031
	ds_load_b64 v[32:33], v49 offset:12032                      ; d9d82f00 20000031
	ds_load_b64 v[38:39], v49 offset:16128                      ; d9d83f00 26000031
	s_wait_dscnt 0x18                                           ; bfc60018
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[112:113], v[80:81], v[168:175] ; cc4640a8 1ea2a170
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[114:115], v[80:81], v[144:151] ; cc464090 1e42a172
	v_mov_b32_e32 v35, v50                                      ; 7e460332
	v_mov_b32_e32 v43, v51                                      ; 7e560333
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[112:115], v48, s[36:39], null offen offset:23552 ; c405c07c 40804870 005c0030
	buffer_load_b128 v[48:51], v48, s[36:39], null offen offset:24064 ; c405c07c 40804830 005e0030
	s_wait_loadcnt_dscnt 0x517                                  ; bfc80517
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[104:105], v[8:9], v[128:135] ; cc464080 1e021168
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[106:107], v[8:9], v[176:183] ; cc4640b0 1ec2116a
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_dual_mov_b32 v9, v109 :: v_dual_mov_b32 v8, v108          ; ca10016d 0908016c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[104:105], v[10:11], v[136:143] ; cc464088 1e221568
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[104:105], v[56:57], v[152:159] ; cc464098 1e627168
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[106:107], v[10:11], v[184:191] ; cc4640b8 1ee2156a
	v_dual_mov_b32 v11, v75 :: v_dual_mov_b32 v10, v74          ; ca10014b 0b0a014a
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[106:107], v[56:57], v[116:123] ; cc464074 1dd2716a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[104:105], v[58:59], v[168:175] ; cc4640a8 1ea27568
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[106:107], v[58:59], v[144:151] ; cc464090 1e42756a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[46:47], 0 ; cc464068 1a025d24
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[164:165], v[16:17], v[128:135] ; cc464080 1e0221a4
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[166:167], v[16:17], v[176:183] ; cc4640b0 1ec221a6
	v_dual_mov_b32 v17, v53 :: v_dual_mov_b32 v16, v52          ; ca100135 11100134
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[164:165], v[76:77], v[136:143] ; cc464088 1e2299a4
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[164:165], v[78:79], v[152:159] ; cc464098 1e629da4
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[166:167], v[76:77], v[184:191] ; cc4640b8 1ee299a6
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[166:167], v[78:79], v[116:123] ; cc464074 1dd29da6
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[164:165], v[86:87], v[168:175] ; cc4640a8 1ea2ada4
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[166:167], v[86:87], v[144:151] ; cc464090 1e42ada6
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[92:93], v[128:135] ; cc464080 1e02b952
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[84:85], v[92:93], v[176:183] ; cc4640b0 1ec2b954
	v_lshl_add_u32 v92, v1, 12, s8                              ; d646005c 00211901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v92, v126, 6, v92                            ; d646005c 05710d7e
	v_add_lshl_u32 v92, v92, v19, 2                             ; d647005c 020a275c
	buffer_load_b128 v[164:167], v92, s[32:35], null offen      ; c405c07c 408040a4 0000005c
	v_dual_mov_b32 v87, v55 :: v_dual_mov_b32 v86, v54          ; ca100137 57560136
	v_wmma_f32_16x16x16_fp8_fp8 v[74:81], v[62:63], v[46:47], 0 ; cc46404a 1a025d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[52:59], v[10:11], v[46:47], 0 ; cc464034 1a025d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[82:83], v[94:95], v[136:143] ; cc464088 1e22bd52
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[82:83], v[96:97], v[152:159] ; cc464098 1e62c152
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[84:85], v[94:95], v[184:191] ; cc4640b8 1ee2bd54
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[84:85], v[96:97], v[116:123] ; cc464074 1dd2c154
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[82:83], v[98:99], v[168:175] ; cc4640a8 1ea2c552
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[98:99], v[144:151] ; cc464090 1e42c554
	v_mov_b32_e32 v82, v92                                      ; 7ea4035c
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[4:5], v[46:47], 0   ; cc46405c 1a025d04
	v_mov_b32_e32 v46, v82                                      ; 7e5c0352
	buffer_load_b128 v[82:85], v82, s[32:35], null offen offset:16 ; c405c07c 40804052 00001052
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[64:65], v[104:111] ; cc464068 1da2813c
	s_mov_b32 s64, 0x3d380000                                   ; bec000ff 3d380000
	s_movk_i32 s65, 0x3e47                                      ; b0413e47
	v_wmma_f32_16x16x16_fp8_fp8 v[74:81], v[72:73], v[64:65], v[74:81] ; cc46404a 1d2a8148
	s_movk_i32 s66, 0x3c20                                      ; b0423c20
	v_wmma_f32_16x16x16_fp8_fp8 v[52:59], v[2:3], v[64:65], v[52:59] ; cc464034 1cd28102
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[12:13], v[8:9], v[128:135] ; cc464080 1e02110c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[12:13], v[124:125], v[136:143] ; cc464088 1e22f90c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[12:13], v[160:161], v[152:159] ; cc464098 1e63410c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[14:15], v[8:9], v[176:183] ; cc4640b0 1ec2110e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[14:15], v[124:125], v[184:191] ; cc4640b8 1ee2f90e
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[12:13], v[162:163], v[168:175] ; cc4640a8 1ea3450c
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[14:15], v[160:161], v[116:123] ; cc464074 1dd3410e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[14:15], v[162:163], v[144:151] ; cc464090 1e43450e
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[6:7], v[64:65], v[92:99] ; cc46405c 1d728106
	s_mov_b32 s67, 0x7ff88000                                   ; bec300ff 7ff88000
	s_wait_loadcnt_dscnt 0x305                                  ; bfc80305
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[88:89], v[152:159] ; cc464098 1e62b170
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[112:113], v[100:101], v[128:135] ; cc464080 1e02c970
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[44:45], v[136:143] ; cc464088 1e225970
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[100:101], v[176:183] ; cc4640b0 1ec2c972
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[44:45], v[184:191] ; cc4640b8 1ee25972
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[112:113], v[90:91], v[168:175] ; cc4640a8 1ea2b570
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[114:115], v[88:89], v[116:123] ; cc464074 1dd2b172
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[114:115], v[90:91], v[144:151] ; cc464090 1e42b572
	s_wait_loadcnt_dscnt 0x201                                  ; bfc80201
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[32:33], v[152:159] ; cc464098 1e624130
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[48:49], v[102:103], v[128:135] ; cc464080 1e02cd30
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[48:49], v[28:29], v[136:143] ; cc464088 1e223930
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[50:51], v[102:103], v[176:183] ; cc4640b0 1ec2cd32
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[50:51], v[28:29], v[184:191] ; cc4640b8 1ee23932
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[48:49], v[38:39], v[168:175] ; cc4640a8 1ea24d30
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[50:51], v[32:33], v[116:123] ; cc464074 1dd24132
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[50:51], v[38:39], v[144:151] ; cc464090 1e424d32
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	ds_store_2addr_b64 v22, v[8:9], v[12:13] offset1:32         ; d9382000 000c0816
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_mov_b32_e32 v9, v46                                       ; 7e12032e
	v_mov_b32_e32 v22, v30                                      ; 7e2c031e
	v_mov_b32_e32 v32, v31                                      ; 7e40031f
	v_dual_mov_b32 v38, v127 :: v_dual_mov_b32 v33, v126        ; ca10017f 2620017e
	s_clause 0xd                                                ; bf85000d
	buffer_load_b128 v[12:15], v46, s[32:35], null offen offset:64 ; c405c07c 4080400c 0000402e
	buffer_load_b128 v[48:51], v46, s[32:35], null offen offset:80 ; c405c07c 40804030 0000502e
	buffer_load_b128 v[88:91], v46, s[32:35], null offen offset:128 ; c405c07c 40804058 0000802e
	buffer_load_b128 v[100:103], v46, s[32:35], null offen offset:144 ; c405c07c 40804064 0000902e
	buffer_load_b128 v[112:115], v46, s[32:35], null offen offset:192 ; c405c07c 40804070 0000c02e
	buffer_load_b128 v[128:131], v46, s[32:35], null offen offset:208 ; c405c07c 40804080 0000d02e
	buffer_load_b128 v[132:135], v46, s[32:35], null offen offset:4096 ; c405c07c 40804084 0010002e
	buffer_load_b128 v[136:139], v46, s[32:35], null offen offset:4112 ; c405c07c 40804088 0010102e
	buffer_load_b128 v[160:163], v46, s[32:35], null offen offset:4160 ; c405c07c 408040a0 0010402e
	buffer_load_b128 v[176:179], v46, s[32:35], null offen offset:4176 ; c405c07c 408040b0 0010502e
	buffer_load_b128 v[180:183], v46, s[32:35], null offen offset:4224 ; c405c07c 408040b4 0010802e
	buffer_load_b128 v[44:47], v46, s[32:35], null offen offset:4240 ; c405c07c 4080402c 0010902e
	buffer_load_b128 v[28:31], v9, s[32:35], null offen offset:4288 ; c405c07c 4080401c 0010c009
	buffer_load_b128 v[124:127], v9, s[32:35], null offen offset:4304 ; c405c07c 4080407c 0010d009
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_mov_b32_e32 v64, v8                                       ; 7e800308
(invalid instruction)                                        ; d769008c
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d769408c
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d769008d
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d769408d
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	ds_store_2addr_b64 v23, v[64:65], v[140:141] offset1:32     ; d9382000 008c4017
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690074
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694074
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690075
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694075
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	ds_store_2addr_b64 v16, v[64:65], v[116:117] offset1:32     ; d9382000 00744010
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690074
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694074
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690075
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694075
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v17, v[64:65], v[116:117] offset1:32     ; d9382000 00744011
	v_dual_mov_b32 v17, v63 :: v_dual_mov_b32 v16, v62          ; ca10013f 1110013e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[66:67], 0 ; cc464090 1a028524
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_fma_mixlo_f16 v39, s64, v104, v164                        ; cc210027 0692d040
	v_fma_mixhi_f16 v39, s64, v105, v165                        ; cc220027 0696d240
	v_fma_mixlo_f16 v104, s64, v106, v166                       ; cc210068 069ad440
	v_fma_mixhi_f16 v104, s64, v107, v167                       ; cc220068 069ed640
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[66:67], 0 ; cc464098 1a02853e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[10:11], v[66:67], 0 ; cc4640a8 1a02850a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[4:5], v[66:67], 0 ; cc4640b8 1a028504
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[36:37], v[70:71], 0 ; cc464074 1a028d24
(invalid instruction)                                        ; cc1c0068
	v_subrev_f32_e32 v0, v104, v66                              ; 0a008568
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[68:69], v[144:151] ; cc464090 1e42893c
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v23, s64, v108, v82                         ; cc210017 054ad840
	v_fma_mixhi_f16 v23, s64, v109, v83                         ; cc220017 054eda40
	v_fma_mixlo_f16 v82, s64, v110, v84                         ; cc210052 0552dc40
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[68:69], v[152:159] ; cc464098 1e628948
(invalid instruction)                                        ; cc1c0027
	v_subrev_f32_e32 v0, v39, v66                               ; 0a008527
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[2:3], v[68:69], v[168:175] ; cc4640a8 1ea28902
	v_fma_mixhi_f16 v82, s64, v111, v85                         ; cc220052 0556de40
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[6:7], v[68:69], v[184:191] ; cc4640b8 1ee28906
	v_wmma_f32_16x16x16_fp8_fp8 v[62:69], v[16:17], v[70:71], 0 ; cc46403e 1a028d10
(invalid instruction)                                        ; cc1b0068
	v_subrev_f32_e32 v0, v104, v65                              ; 0a008368
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v66                               ; 0a008517
	v_dual_mov_b32 v105, v144 :: v_dual_mov_b32 v8, v147        ; ca100190 69080193
	v_dual_mov_b32 v107, v146 :: v_dual_mov_b32 v106, v145      ; ca100192 6b6a0191
	v_wmma_f32_16x16x16_fp8_fp8 v[140:147], v[10:11], v[70:71], 0 ; cc46408c 1a028d0a
(invalid instruction)                                        ; cc1b0027
	v_subrev_f32_e32 v0, v39, v65                               ; 0a008327
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v66                               ; 0a008552
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[60:61], v[20:21], v[116:123] ; cc464074 1dd2293c
	v_lshl_add_u32 v104, v104, 5, s67                           ; d6460068 010d0b68
(invalid instruction)                                        ; cc1b0017
	v_subrev_f32_e32 v0, v23, v65                               ; 0a008317
	v_dual_mov_b32 v164, v107 :: v_dual_mov_b32 v85, v106       ; ca10016b a454016a
	v_wmma_f32_16x16x16_fp8_fp8 v[62:69], v[72:73], v[20:21], v[62:69] ; cc46403e 1cfa2948
	v_lshl_add_u32 v39, v39, 5, s67                             ; d6460027 010d0b27
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v65                               ; 0a008352
	v_wmma_f32_16x16x16_fp8_fp8 v[140:147], v[2:3], v[20:21], v[140:147] ; cc46408c 1e322902
	v_dual_mov_b32 v84, v105 :: v_dual_mov_b32 v83, v104        ; ca100169 54520168
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[4:5], v[70:71], 0 ; cc464068 1a028d04
	v_lshl_add_u32 v23, v23, 5, s67                             ; d6460017 010d0b17
	v_lshl_add_u32 v82, v82, 5, s67                             ; d6460052 010d0b52
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[6:7], v[20:21], v[104:111] ; cc464068 1da22906
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_fma_mixlo_f16 v165, s64, v74, v12                         ; cc2100a5 04329440
	v_fma_mixhi_f16 v165, s64, v75, v13                         ; cc2200a5 04369640
	v_fma_mixlo_f16 v166, s64, v76, v14                         ; cc2100a6 043a9840
	v_fma_mixhi_f16 v166, s64, v77, v15                         ; cc2200a6 043e9a40
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v13, s64, v78, v48                          ; cc21000d 04c29c40
	v_fma_mixhi_f16 v13, s64, v79, v49                          ; cc22000d 04c69e40
	v_fma_mixlo_f16 v14, s64, v80, v50                          ; cc21000e 04caa040
	v_fma_mixhi_f16 v14, s64, v81, v51                          ; cc22000e 04cea240
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v66                              ; 0a0085a5
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v21, s64, v52, v88                          ; cc210015 05626840
(invalid instruction)                                        ; cc1c00a6
	v_subrev_f32_e32 v0, v166, v66                              ; 0a0085a6
	v_fma_mixhi_f16 v21, s64, v53, v89                          ; cc220015 05666a40
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v66                               ; 0a00850d
	v_fma_mixlo_f16 v48, s64, v54, v90                          ; cc210030 056a6c40
(invalid instruction)                                        ; cc1c000e
	v_subrev_f32_e32 v0, v14, v66                               ; 0a00850e
(invalid instruction)                                        ; cc1b00a5
	v_subrev_f32_e32 v0, v165, v65                              ; 0a0083a5
	v_fma_mixhi_f16 v48, s64, v55, v91                          ; cc220030 056e6e40
(invalid instruction)                                        ; cc1b00a6
	v_subrev_f32_e32 v0, v166, v65                              ; 0a0083a6
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v66                               ; 0a008515
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v65                               ; 0a00830d
(invalid instruction)                                        ; cc1b000e
	v_subrev_f32_e32 v0, v14, v65                               ; 0a00830e
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v49, s64, v56, v100                         ; cc210031 05927040
	v_lshl_add_u32 v165, v165, 5, s67                           ; d64600a5 010d0ba5
(invalid instruction)                                        ; cc1c0030
	v_subrev_f32_e32 v0, v48, v66                               ; 0a008530
	v_fma_mixhi_f16 v49, s64, v57, v101                         ; cc220031 05967240
	v_lshl_add_u32 v166, v166, 5, s67                           ; d64600a6 010d0ba6
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v65                               ; 0a008315
	v_lshl_add_u32 v13, v13, 5, s67                             ; d646000d 010d0b0d
	v_fma_mixlo_f16 v50, s64, v58, v102                         ; cc210032 059a7440
	v_fma_mixhi_f16 v50, s64, v59, v103                         ; cc220032 059e7640
	v_lshl_add_u32 v14, v14, 5, s67                             ; d646000e 010d0b0e
(invalid instruction)                                        ; cc0f00a7
	v_min_num_f64_e32 v[1:2], v[39:40], v[165:166]              ; 1a034b27
	s_clause 0x4                                                ; bf850004
	buffer_load_b128 v[52:55], v9, s[32:35], null offen offset:8192 ; c405c07c 40804034 00200009
	buffer_load_b128 v[56:59], v9, s[32:35], null offen offset:8208 ; c405c07c 40804038 00201009
	buffer_load_b128 v[76:79], v9, s[32:35], null offen offset:8256 ; c405c07c 4080404c 00204009
	buffer_load_b128 v[88:91], v9, s[32:35], null offen offset:8272 ; c405c07c 40804058 00205009
	buffer_load_b128 v[100:103], v9, s[32:35], null offen offset:8320 ; c405c07c 40804064 00208009
	v_dual_mov_b32 v74, v69 :: v_dual_mov_b32 v51, v68          ; ca100145 4a320144
	buffer_load_b128 v[68:71], v9, s[32:35], null offen offset:8336 ; c405c07c 40804044 00209009
(invalid instruction)                                        ; cc1b0030
	v_subrev_f32_e32 v0, v48, v65                               ; 0a008330
(invalid instruction)                                        ; cc1c0031
	v_subrev_f32_e32 v0, v49, v66                               ; 0a008531
(invalid instruction)                                        ; cc0f000c
	v_min_num_f64_e32 v[1:2], v[83:84], v[166:167]              ; 1a034d53
	v_lshl_add_u32 v21, v21, 5, s67                             ; d6460015 010d0b15
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[23:24], v[13:14]                ; 1a021b17
(invalid instruction)                                        ; cc1c0032
	v_subrev_f32_e32 v0, v50, v66                               ; 0a008532
(invalid instruction)                                        ; cc0f0014
	v_min_num_f64_e32 v[1:2], v[82:83], v[14:15]                ; 1a021d52
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_fma_mixlo_f16 v75, s64, v92, v112                         ; cc21004b 05c2b840
	v_fma_mixhi_f16 v75, s64, v93, v113                         ; cc22004b 05c6ba40
	v_fma_mixlo_f16 v80, s64, v94, v114                         ; cc210050 05cabc40
	v_fma_mixhi_f16 v80, s64, v95, v115                         ; cc220050 05cebe40
	v_lshl_add_u32 v48, v48, 5, s67                             ; d6460030 010d0b30
(invalid instruction)                                        ; cc1b0031
	v_subrev_f32_e32 v0, v49, v65                               ; 0a008331
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v81, s64, v96, v128                         ; cc210051 0602c040
(invalid instruction)                                        ; cc0f00a7
	v_min_num_f64_e32 v[1:2], v[167:168], v[21:22]              ; 1a022ba7
	v_fma_mixhi_f16 v81, s64, v97, v129                         ; cc220051 0606c240
(invalid instruction)                                        ; cc1b0032
	v_subrev_f32_e32 v0, v50, v65                               ; 0a008332
	v_fma_mixlo_f16 v92, s64, v98, v130                         ; cc21005c 060ac440
(invalid instruction)                                        ; cc1c004b
	v_subrev_f32_e32 v0, v75, v66                               ; 0a00854b
	v_fma_mixhi_f16 v92, s64, v99, v131                         ; cc22005c 060ec640
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v66                               ; 0a008550
(invalid instruction)                                        ; cc0f000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[48:49]                ; 1a02610c
	v_lshl_add_u32 v49, v49, 5, s67                             ; d6460031 010d0b31
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v66                               ; 0a008551
	v_lshl_add_u32 v50, v50, 5, s67                             ; d6460032 010d0b32
(invalid instruction)                                        ; cc1b004b
	v_subrev_f32_e32 v0, v75, v65                               ; 0a00834b
(invalid instruction)                                        ; cc1c005c
	v_subrev_f32_e32 v0, v92, v66                               ; 0a00855c
(invalid instruction)                                        ; cc1b0050
	v_subrev_f32_e32 v0, v80, v65                               ; 0a008350
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[49:50]                ; 1a02630f
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v65                               ; 0a008351
(invalid instruction)                                        ; cc0f0014
	v_min_num_f64_e32 v[1:2], v[20:21], v[50:51]                ; 1a026514
	v_lshl_add_u32 v75, v75, 5, s67                             ; d646004b 010d0b4b
(invalid instruction)                                        ; cc1b005c
	v_subrev_f32_e32 v0, v92, v65                               ; 0a00835c
	v_lshl_add_u32 v80, v80, 5, s67                             ; d6460050 010d0b50
	v_lshl_add_u32 v81, v81, 5, s67                             ; d6460051 010d0b51
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; cc0f00a7
	v_min_num_f64_e32 v[1:2], v[167:168], v[75:76]              ; 1a0297a7
	v_lshl_add_u32 v92, v92, 5, s67                             ; d646005c 010d0b5c
(invalid instruction)                                        ; cc0f000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[80:81]                ; 1a02a10c
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[81:82]                ; 1a02a30f
(invalid instruction)                                        ; cc0f0014
	v_min_num_f64_e32 v[1:2], v[20:21], v[92:93]                ; 1a02b914
(invalid instruction)                                        ; cc0f00a7
	v_min_num_f64_e32 v[1:2], v[167:168], v[12:13]              ; 1a0219a7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00a7
	v_min_num_f64_e32 v[1:2], v[167:168], v[15:16]              ; 1a021fa7
(invalid instruction)                                        ; cc0f00a7
	v_min_num_f64_e32 v[1:2], v[167:168], v[20:21]              ; 1a0229a7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v93, v167, s61, s62 op_sel:[1,1]          ; d65c185d 00f87ba7
(invalid instruction)                                        ; cc0f00a7
	v_min_num_f64_e32 v[1:2], v[167:168], v[93:94]              ; 1a02bba7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d532105e
	v_cndmask_b32_e32 v1, v167, v167, vcc_lo                    ; 02034fa7
	v_max_num_f16_e32 v94, s60, v94                             ; 62bcbc3c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v95, v94                                  ; 7ebe175e
	v_rcp_f32_e32 v95, v95                                      ; 7ebe555f
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v98, v23, v95, neg(0) op_sel_hi:[1,0,0]       ; cc200062 8a02bf17
	v_fma_mix_f32 v23, v23, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a02bf17
	v_fma_mix_f32 v96, v39, v95, neg(0) op_sel_hi:[1,0,0]       ; cc200060 8a02bf27
	v_fma_mix_f32 v113, v166, v95, neg(0) op_sel_hi:[1,0,0]     ; cc200071 8a02bfa6
	v_fma_mix_f32 v97, v83, v95, neg(0) op_sel_hi:[1,0,0]       ; cc200061 8a02bf53
	v_fma_mix_f32 v39, v39, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200827 8a02bf27
	v_fma_mix_f32 v112, v165, v95, neg(0) op_sel_hi:[1,0,0]     ; cc200070 8a02bfa5
	v_fma_mix_f32 v165, v165, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a02bfa5
	v_fma_mix_f32 v83, v83, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200853 8a02bf53
	v_fma_mix_f32 v99, v82, v95, neg(0) op_sel_hi:[1,0,0]       ; cc200063 8a02bf52
	v_fma_mix_f32 v82, v82, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200852 8a02bf52
	v_fma_mix_f32 v166, v166, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a6 8a02bfa6
	v_fma_mix_f32 v114, v13, v95, neg(0) op_sel_hi:[1,0,0]      ; cc200072 8a02bf0d
	v_fma_mix_f32 v13, v13, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080d 8a02bf0d
	v_fma_mix_f32 v115, v14, v95, neg(0) op_sel_hi:[1,0,0]      ; cc200073 8a02bf0e
	v_fma_mix_f32 v14, v14, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080e 8a02bf0e
	v_fma_mix_f32 v128, v21, v95, neg(0) op_sel_hi:[1,0,0]      ; cc200080 8a02bf15
	v_fma_mix_f32 v21, v21, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a02bf15
(invalid instruction)                                        ; d7690060
	v_cndmask_b32_e32 v1, v96, v39, vcc_lo                      ; 02024f60
	v_fma_mix_f32 v129, v48, v95, neg(0) op_sel_hi:[1,0,0]      ; cc200081 8a02bf30
	v_fma_mix_f32 v48, v48, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200830 8a02bf30
(invalid instruction)                                        ; d7694060
	v_cndmask_b32_e32 v1, v97, v83, vcc_lo                      ; 0202a761
(invalid instruction)                                        ; d7690061
	v_cndmask_b32_e32 v1, v98, v23, vcc_lo                      ; 02022f62
	v_fma_mix_f32 v130, v49, v95, neg(0) op_sel_hi:[1,0,0]      ; cc200082 8a02bf31
(invalid instruction)                                        ; d7694061
	v_cndmask_b32_e32 v1, v99, v82, vcc_lo                      ; 0202a563
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v112, v165, vcc_lo                    ; 02034b70
	v_fma_mix_f32 v49, v49, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200831 8a02bf31
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v113, v166, vcc_lo                    ; 02034d71
	v_fma_mix_f32 v131, v50, v95, neg(0) op_sel_hi:[1,0,0]      ; cc200083 8a02bf32
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v114, v13, vcc_lo                     ; 02021b72
	v_fma_mix_f32 v50, v50, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200832 8a02bf32
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v115, v14, vcc_lo                     ; 02021d73
	v_fma_mix_f32 v165, v75, v95, neg(0) op_sel_hi:[1,0,0]      ; cc2000a5 8a02bf4b
	v_fma_mix_f32 v75, v75, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084b 8a02bf4b
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v128, v21, vcc_lo                     ; 02022b80
	v_fma_mix_f32 v166, v80, v95, neg(0) op_sel_hi:[1,0,0]      ; cc2000a6 8a02bf50
	v_fma_mix_f32 v80, v80, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200850 8a02bf50
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v129, v48, vcc_lo                     ; 02026181
	v_fma_mix_f32 v167, v81, v95, neg(0) op_sel_hi:[1,0,0]      ; cc2000a7 8a02bf51
	v_fma_mix_f32 v81, v81, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200851 8a02bf51
	v_fma_mix_f32 v20, v92, v95, neg(0) op_sel_hi:[1,0,0]       ; cc200014 8a02bf5c
	v_fma_mix_f32 v92, v92, v95, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085c 8a02bf5c
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v130, v49, vcc_lo                     ; 02026382
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_fma_mixlo_f16 v21, s64, v84, v132                         ; cc210015 0612a840
	v_fma_mixhi_f16 v21, s64, v85, v133                         ; cc220015 0616aa40
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v131, v50, vcc_lo                     ; 02026583
	v_fma_mixlo_f16 v23, s64, v164, v134                        ; cc210017 061b4840
	v_fma_mixhi_f16 v23, s64, v8, v135                          ; cc220017 061e1040
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v165, v75, vcc_lo                     ; 020297a5
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v39, s64, v148, v136                        ; cc210027 06232840
	v_fma_mixhi_f16 v39, s64, v149, v137                        ; cc220027 06272a40
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v166, v80, vcc_lo                     ; 0202a1a6
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v167, v81, vcc_lo                     ; 0202a3a7
	v_fma_mixlo_f16 v48, s64, v150, v138                        ; cc210030 062b2c40
	v_fma_mixhi_f16 v48, s64, v151, v139                        ; cc220030 062f2e40
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v20, v92, vcc_lo                      ; 0202b914
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v49, s64, v152, v160                        ; cc210031 06833040
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v66                               ; 0a008515
	v_fma_mixhi_f16 v49, s64, v153, v161                        ; cc220031 06873240
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v66                               ; 0a008517
	v_fma_mixlo_f16 v50, s64, v154, v162                        ; cc210032 068b3440
	v_fma_mixhi_f16 v50, s64, v155, v163                        ; cc220032 068f3640
(invalid instruction)                                        ; cc1c0027
	v_subrev_f32_e32 v0, v39, v66                               ; 0a008527
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v75, s64, v156, v176                        ; cc21004b 06c33840
	v_fma_mixhi_f16 v75, s64, v157, v177                        ; cc22004b 06c73a40
(invalid instruction)                                        ; cc1c0030
	v_subrev_f32_e32 v0, v48, v66                               ; 0a008530
	v_fma_mixlo_f16 v80, s64, v158, v178                        ; cc210050 06cb3c40
	v_fma_mixhi_f16 v80, s64, v159, v179                        ; cc220050 06cf3e40
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v65                               ; 0a008315
(invalid instruction)                                        ; cc1c0031
	v_subrev_f32_e32 v0, v49, v66                               ; 0a008531
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[92:95], v9, s[32:35], null offen offset:8384 ; c405c07c 4080405c 0020c009
	buffer_load_b128 v[112:115], v9, s[32:35], null offen offset:8400 ; c405c07c 40804070 0020d009
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v81, s64, v168, v180                        ; cc210051 06d35040
(invalid instruction)                                        ; cc1b0017
	v_subrev_f32_e32 v0, v23, v65                               ; 0a008317
	v_fma_mixhi_f16 v81, s64, v169, v181                        ; cc220051 06d75240
(invalid instruction)                                        ; cc1c0032
	v_subrev_f32_e32 v0, v50, v66                               ; 0a008532
(invalid instruction)                                        ; cc1b0027
	v_subrev_f32_e32 v0, v39, v65                               ; 0a008327
(invalid instruction)                                        ; cc1c004b
	v_subrev_f32_e32 v0, v75, v66                               ; 0a00854b
	v_fma_mixlo_f16 v84, s64, v170, v182                        ; cc210054 06db5440
(invalid instruction)                                        ; cc1b0030
	v_subrev_f32_e32 v0, v48, v65                               ; 0a008330
	v_fma_mixhi_f16 v84, s64, v171, v183                        ; cc220054 06df5640
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v66                               ; 0a008550
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v85, s64, v172, v44                         ; cc210055 04b35840
(invalid instruction)                                        ; cc1b0031
	v_subrev_f32_e32 v0, v49, v65                               ; 0a008331
	v_fma_mixhi_f16 v85, s64, v173, v45                         ; cc220055 04b75a40
	v_fma_mixlo_f16 v98, s64, v174, v46                         ; cc210062 04bb5c40
	v_fma_mixhi_f16 v98, s64, v175, v47                         ; cc220062 04bf5e40
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v66                               ; 0a008551
(invalid instruction)                                        ; cc1b0032
	v_subrev_f32_e32 v0, v50, v65                               ; 0a008332
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v99, s64, v184, v28                         ; cc210063 04737040
(invalid instruction)                                        ; cc1b004b
	v_subrev_f32_e32 v0, v75, v65                               ; 0a00834b
	v_fma_mixhi_f16 v99, s64, v185, v29                         ; cc220063 04777240
(invalid instruction)                                        ; cc1c0054
	v_subrev_f32_e32 v0, v84, v66                               ; 0a008554
(invalid instruction)                                        ; cc1b0050
	v_subrev_f32_e32 v0, v80, v65                               ; 0a008350
	v_fma_mixlo_f16 v128, s64, v186, v30                        ; cc210080 047b7440
	v_fma_mixhi_f16 v128, s64, v187, v31                        ; cc220080 047f7640
(invalid instruction)                                        ; cc1c0055
	v_subrev_f32_e32 v0, v85, v66                               ; 0a008555
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v129, s64, v188, v124                       ; cc210081 05f37840
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v66                               ; 0a008562
	v_fma_mixhi_f16 v129, s64, v189, v125                       ; cc220081 05f77a40
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v65                               ; 0a008351
	v_fma_mixlo_f16 v130, s64, v190, v126                       ; cc210082 05fb7c40
	v_fma_mixhi_f16 v130, s64, v191, v127                       ; cc220082 05ff7e40
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v66                               ; 0a008563
(invalid instruction)                                        ; cc1b0054
	v_subrev_f32_e32 v0, v84, v65                               ; 0a008354
	v_lshl_add_u32 v21, v21, 5, s67                             ; d6460015 010d0b15
	v_lshl_add_u32 v49, v49, 5, s67                             ; d6460031 010d0b31
(invalid instruction)                                        ; cc1c0080
	v_subrev_f32_e32 v0, v128, v66                              ; 0a008580
(invalid instruction)                                        ; cc1b0055
	v_subrev_f32_e32 v0, v85, v65                               ; 0a008355
(invalid instruction)                                        ; cc1b0062
	v_subrev_f32_e32 v0, v98, v65                               ; 0a008362
(invalid instruction)                                        ; cc1c0081
	v_subrev_f32_e32 v0, v129, v66                              ; 0a008581
	v_lshl_add_u32 v81, v81, 5, s67                             ; d6460051 010d0b51
	v_lshl_add_u32 v23, v23, 5, s67                             ; d6460017 010d0b17
	v_lshl_add_u32 v50, v50, 5, s67                             ; d6460032 010d0b32
(invalid instruction)                                        ; cc1c0082
	v_subrev_f32_e32 v0, v130, v66                              ; 0a008582
(invalid instruction)                                        ; cc1b0063
	v_subrev_f32_e32 v0, v99, v65                               ; 0a008363
	v_lshl_add_u32 v84, v84, 5, s67                             ; d6460054 010d0b54
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[21:22], v[49:50]                ; 1a026315
(invalid instruction)                                        ; cc1b0080
	v_subrev_f32_e32 v0, v128, v65                              ; 0a008380
	v_lshl_add_u32 v39, v39, 5, s67                             ; d6460027 010d0b27
	v_lshl_add_u32 v75, v75, 5, s67                             ; d646004b 010d0b4b
(invalid instruction)                                        ; cc1b0081
	v_subrev_f32_e32 v0, v129, v65                              ; 0a008381
	v_lshl_add_u32 v85, v85, 5, s67                             ; d6460055 010d0b55
(invalid instruction)                                        ; cc0f0084
	v_min_num_f64_e32 v[1:2], v[23:24], v[50:51]                ; 1a026517
	v_lshl_add_u32 v48, v48, 5, s67                             ; d6460030 010d0b30
(invalid instruction)                                        ; cc1b0082
	v_subrev_f32_e32 v0, v130, v65                              ; 0a008382
	v_lshl_add_u32 v99, v99, 5, s67                             ; d6460063 010d0b63
	v_lshl_add_u32 v80, v80, 5, s67                             ; d6460050 010d0b50
	v_lshl_add_u32 v98, v98, 5, s67                             ; d6460062 010d0b62
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[131:132], v[81:82]              ; 1a02a383
	v_lshl_add_u32 v128, v128, 5, s67                           ; d6460080 010d0b80
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[39:40], v[75:76]                ; 1a029727
	v_lshl_add_u32 v129, v129, 5, s67                           ; d6460081 010d0b81
(invalid instruction)                                        ; cc0f0084
	v_min_num_f64_e32 v[1:2], v[132:133], v[84:85]              ; 1a02a984
	v_lshl_add_u32 v130, v130, 5, s67                           ; d6460082 010d0b82
(invalid instruction)                                        ; cc0f0086
	v_min_num_f64_e32 v[1:2], v[48:49], v[80:81]                ; 1a02a130
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[131:132], v[99:100]             ; 1a02c783
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[133:134], v[85:86]              ; 1a02ab85
(invalid instruction)                                        ; cc0f0084
	v_min_num_f64_e32 v[1:2], v[132:133], v[128:129]            ; 1a030184
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f0086
	v_min_num_f64_e32 v[1:2], v[134:135], v[98:99]              ; 1a02c586
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[133:134], v[129:130]            ; 1a030385
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[131:132], v[132:133]            ; 1a030983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f0086
	v_min_num_f64_e32 v[1:2], v[134:135], v[130:131]            ; 1a030586
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[131:132], v[133:134]            ; 1a030b83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[131:132], v[134:135]            ; 1a030d83
	v_permlanex16_b32 v135, v131, s61, s62 op_sel:[1,1]         ; d65c1887 00f87b83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[131:132], v[135:136]            ; 1a030f83
(invalid instruction)                                        ; d5321088
	v_cndmask_b32_e32 v1, v131, v131, vcc_lo                    ; 02030783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5310088
	v_cndmask_b32_e32 v1, s60, v136, vcc_lo                     ; 0203103c
(invalid instruction)                                        ; d58b0089
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                    ; 02010188
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v137, v137                                    ; 7f125589
	v_fma_mix_f32 v138, v21, v137, neg(0) op_sel_hi:[1,0,0]     ; cc20008a 8a031315
	v_fma_mix_f32 v21, v21, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a031315
	v_fma_mix_f32 v148, v39, v137, neg(0) op_sel_hi:[1,0,0]     ; cc200094 8a031327
	v_fma_mix_f32 v150, v49, v137, neg(0) op_sel_hi:[1,0,0]     ; cc200096 8a031331
	v_fma_mix_f32 v139, v23, v137, neg(0) op_sel_hi:[1,0,0]     ; cc20008b 8a031317
	v_fma_mix_f32 v23, v23, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a031317
	v_fma_mix_f32 v151, v50, v137, neg(0) op_sel_hi:[1,0,0]     ; cc200097 8a031332
	v_fma_mix_f32 v39, v39, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200827 8a031327
	v_fma_mix_f32 v149, v48, v137, neg(0) op_sel_hi:[1,0,0]     ; cc200095 8a031330
	v_fma_mix_f32 v48, v48, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200830 8a031330
	v_fma_mix_f32 v49, v49, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200831 8a031331
	v_fma_mix_f32 v50, v50, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200832 8a031332
	v_fma_mix_f32 v152, v75, v137, neg(0) op_sel_hi:[1,0,0]     ; cc200098 8a03134b
	v_fma_mix_f32 v75, v75, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084b 8a03134b
	v_fma_mix_f32 v153, v80, v137, neg(0) op_sel_hi:[1,0,0]     ; cc200099 8a031350
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v138, v21, vcc_lo                     ; 02022b8a
	v_fma_mix_f32 v80, v80, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200850 8a031350
	v_fma_mix_f32 v154, v81, v137, neg(0) op_sel_hi:[1,0,0]     ; cc20009a 8a031351
	v_fma_mix_f32 v81, v81, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200851 8a031351
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v139, v23, vcc_lo                     ; 02022f8b
	v_fma_mix_f32 v155, v84, v137, neg(0) op_sel_hi:[1,0,0]     ; cc20009b 8a031354
	v_fma_mix_f32 v84, v84, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200854 8a031354
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v148, v39, vcc_lo                     ; 02024f94
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v149, v48, vcc_lo                     ; 02026195
	v_fma_mix_f32 v156, v85, v137, neg(0) op_sel_hi:[1,0,0]     ; cc20009c 8a031355
	v_fma_mix_f32 v85, v85, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200855 8a031355
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v150, v49, vcc_lo                     ; 02026396
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v151, v50, vcc_lo                     ; 02026597
	v_fma_mix_f32 v157, v98, v137, neg(0) op_sel_hi:[1,0,0]     ; cc20009d 8a031362
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v152, v75, vcc_lo                     ; 02029798
	v_fma_mix_f32 v98, v98, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200862 8a031362
	v_fma_mix_f32 v158, v99, v137, neg(0) op_sel_hi:[1,0,0]     ; cc20009e 8a031363
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[124:127], v9, s[32:35], null offen offset:12288 ; c405c07c 4080407c 00300009
	buffer_load_b128 v[132:135], v9, s[32:35], null offen offset:12304 ; c405c07c 40804084 00301009
	v_fma_mix_f32 v99, v99, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200863 8a031363
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v153, v80, vcc_lo                     ; 0202a199
	v_fma_mix_f32 v159, v128, v137, neg(0) op_sel_hi:[1,0,0]    ; cc20009f 8a031380
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v154, v81, vcc_lo                     ; 0202a39a
	v_fma_mix_f32 v128, v128, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200880 8a031380
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v155, v84, vcc_lo                     ; 0202a99b
	v_fma_mix_f32 v160, v129, v137, neg(0) op_sel_hi:[1,0,0]    ; cc2000a0 8a031381
	v_fma_mix_f32 v129, v129, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a031381
	v_fma_mix_f32 v161, v130, v137, neg(0) op_sel_hi:[1,0,0]    ; cc2000a1 8a031382
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v156, v85, vcc_lo                     ; 0202ab9c
	v_fma_mix_f32 v130, v130, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200882 8a031382
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v162, s64, v116, v52                        ; cc2100a2 04d2e840
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v157, v98, vcc_lo                     ; 0202c59d
	v_fma_mixhi_f16 v162, s64, v117, v53                        ; cc2200a2 04d6ea40
	v_fma_mixlo_f16 v163, s64, v118, v54                        ; cc2100a3 04daec40
	v_fma_mixhi_f16 v163, s64, v119, v55                        ; cc2200a3 04deee40
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v158, v99, vcc_lo                     ; 0202c79e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v164, s64, v120, v56                        ; cc2100a4 04e2f040
	v_fma_mixhi_f16 v164, s64, v121, v57                        ; cc2200a4 04e6f240
	v_fma_mixlo_f16 v165, s64, v122, v58                        ; cc2100a5 04eaf440
	v_fma_mixhi_f16 v165, s64, v123, v59                        ; cc2200a5 04eef640
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[52:55], v9, s[32:35], null offen offset:12352 ; c405c07c 40804034 00304009
	buffer_load_b128 v[56:59], v9, s[32:35], null offen offset:12368 ; c405c07c 40804038 00305009
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v159, v128, vcc_lo                    ; 0203019f
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v160, v129, vcc_lo                    ; 020303a0
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v161, v130, vcc_lo                    ; 020305a1
(invalid instruction)                                        ; cc1c00a2
	v_subrev_f32_e32 v0, v162, v66                              ; 0a0085a2
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v166, s64, v62, v76                         ; cc2100a6 05327c40
	v_fma_mixhi_f16 v166, s64, v63, v77                         ; cc2200a6 05367e40
(invalid instruction)                                        ; cc1c00a3
	v_subrev_f32_e32 v0, v163, v66                              ; 0a0085a3
	v_fma_mixlo_f16 v167, s64, v64, v78                         ; cc2100a7 053a8040
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v66                              ; 0a0085a4
	v_fma_mixhi_f16 v167, s64, v65, v79                         ; cc2200a7 053e8240
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v66                              ; 0a0085a5
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v168, s64, v66, v88                         ; cc2100a8 05628440
	v_fma_mixhi_f16 v168, s64, v67, v89                         ; cc2200a8 05668640
	v_fma_mixlo_f16 v169, s64, v51, v90                         ; cc2100a9 056a6640
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v9, s[32:35], null offen offset:12416 ; c405c07c 40804030 00308009
	buffer_load_b128 v[64:67], v9, s[32:35], null offen offset:12432 ; c405c07c 40804040 00309009
	v_fma_mixhi_f16 v169, s64, v74, v91                         ; cc2200a9 056e9440
(invalid instruction)                                        ; cc1b00a2
	v_subrev_f32_e32 v0, v162, v65                              ; 0a0083a2
(invalid instruction)                                        ; cc1c00a6
	v_subrev_f32_e32 v0, v166, v66                              ; 0a0085a6
(invalid instruction)                                        ; cc1b00a3
	v_subrev_f32_e32 v0, v163, v65                              ; 0a0083a3
(invalid instruction)                                        ; cc1b00a4
	v_subrev_f32_e32 v0, v164, v65                              ; 0a0083a4
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v170, s64, v140, v100                       ; cc2100aa 05931840
	v_fma_mixhi_f16 v170, s64, v141, v101                       ; cc2200aa 05971a40
(invalid instruction)                                        ; cc1c00a7
	v_subrev_f32_e32 v0, v167, v66                              ; 0a0085a7
(invalid instruction)                                        ; cc1b00a5
	v_subrev_f32_e32 v0, v165, v65                              ; 0a0083a5
(invalid instruction)                                        ; cc1c00a8
	v_subrev_f32_e32 v0, v168, v66                              ; 0a0085a8
	v_fma_mixlo_f16 v171, s64, v142, v102                       ; cc2100ab 059b1c40
	v_fma_mixhi_f16 v171, s64, v143, v103                       ; cc2200ab 059f1e40
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v66                              ; 0a0085a9
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v172, s64, v144, v68                        ; cc2100ac 05132040
	v_fma_mixhi_f16 v172, s64, v145, v69                        ; cc2200ac 05172240
	v_fma_mixlo_f16 v173, s64, v146, v70                        ; cc2100ad 051b2440
	v_fma_mixhi_f16 v173, s64, v147, v71                        ; cc2200ad 051f2640
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v9, s[32:35], null offen offset:12480 ; c405c07c 40804044 0030c009
	buffer_load_b128 v[76:79], v9, s[32:35], null offen offset:12496 ; c405c07c 4080404c 0030d009
(invalid instruction)                                        ; cc1b00a6
	v_subrev_f32_e32 v0, v166, v65                              ; 0a0083a6
(invalid instruction)                                        ; cc1c00aa
	v_subrev_f32_e32 v0, v170, v66                              ; 0a0085aa
(invalid instruction)                                        ; cc1b00a7
	v_subrev_f32_e32 v0, v167, v65                              ; 0a0083a7
	v_add3_u32 v22, v32, s22, v22                               ; d6550016 04582d20
(invalid instruction)                                        ; cc1b00a8
	v_subrev_f32_e32 v0, v168, v65                              ; 0a0083a8
(invalid instruction)                                        ; cc1c00ab
	v_subrev_f32_e32 v0, v171, v66                              ; 0a0085ab
(invalid instruction)                                        ; cc1b00a9
	v_subrev_f32_e32 v0, v169, v65                              ; 0a0083a9
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v66                              ; 0a0085ac
(invalid instruction)                                        ; cc1c00ad
	v_subrev_f32_e32 v0, v173, v66                              ; 0a0085ad
(invalid instruction)                                        ; cc1b00aa
	v_subrev_f32_e32 v0, v170, v65                              ; 0a0083aa
	v_lshlrev_b32_e32 v22, 2, v22                               ; 302c2c82
(invalid instruction)                                        ; cc1b00ab
	v_subrev_f32_e32 v0, v171, v65                              ; 0a0083ab
(invalid instruction)                                        ; cc1b00ac
	v_subrev_f32_e32 v0, v172, v65                              ; 0a0083ac
(invalid instruction)                                        ; cc1b00ad
	v_subrev_f32_e32 v0, v173, v65                              ; 0a0083ad
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v174, s64, v104, v92                        ; cc2100ae 0572d040
	v_fma_mixhi_f16 v174, s64, v105, v93                        ; cc2200ae 0576d240
	v_fma_mixlo_f16 v175, s64, v106, v94                        ; cc2100af 057ad440
	v_fma_mixhi_f16 v175, s64, v107, v95                        ; cc2200af 057ed640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v177, s64, v110, v114                       ; cc2100b1 05cadc40
	v_fma_mixhi_f16 v177, s64, v111, v115                       ; cc2200b1 05cede40
	v_fma_mixlo_f16 v176, s64, v108, v112                       ; cc2100b0 05c2d840
	v_lshl_add_u32 v162, v162, 5, s67                           ; d64600a2 010d0ba2
	v_fma_mixhi_f16 v176, s64, v109, v113                       ; cc2200b0 05c6da40
	v_lshl_add_u32 v166, v166, 5, s67                           ; d64600a6 010d0ba6
	v_lshl_add_u32 v170, v170, 5, s67                           ; d64600aa 010d0baa
(invalid instruction)                                        ; cc1c00ae
	v_subrev_f32_e32 v0, v174, v66                              ; 0a0085ae
	v_lshl_add_u32 v163, v163, 5, s67                           ; d64600a3 010d0ba3
	v_lshl_add_u32 v167, v167, 5, s67                           ; d64600a7 010d0ba7
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v66                              ; 0a0085af
	v_lshl_add_u32 v171, v171, 5, s67                           ; d64600ab 010d0bab
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v66                              ; 0a0085b1
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v66                              ; 0a0085b0
	v_lshl_add_u32 v164, v164, 5, s67                           ; d64600a4 010d0ba4
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[162:163], v[166:167]            ; 1a034da2
	v_lshl_add_u32 v168, v168, 5, s67                           ; d64600a8 010d0ba8
(invalid instruction)                                        ; cc1b00ae
	v_subrev_f32_e32 v0, v174, v65                              ; 0a0083ae
	v_lshl_add_u32 v172, v172, 5, s67                           ; d64600ac 010d0bac
(invalid instruction)                                        ; cc0f00b3
	v_min_num_f64_e32 v[1:2], v[163:164], v[167:168]            ; 1a034fa3
(invalid instruction)                                        ; cc1b00af
	v_subrev_f32_e32 v0, v175, v65                              ; 0a0083af
	v_lshl_add_u32 v165, v165, 5, s67                           ; d64600a5 010d0ba5
(invalid instruction)                                        ; cc1b00b1
	v_subrev_f32_e32 v0, v177, v65                              ; 0a0083b1
(invalid instruction)                                        ; cc1b00b0
	v_subrev_f32_e32 v0, v176, v65                              ; 0a0083b0
	v_lshl_add_u32 v169, v169, 5, s67                           ; d64600a9 010d0ba9
	v_lshl_add_u32 v173, v173, 5, s67                           ; d64600ad 010d0bad
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[178:179], v[170:171]            ; 1a0355b2
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[164:165], v[168:169]            ; 1a0351a4
	v_lshl_add_u32 v174, v174, 5, s67                           ; d64600ae 010d0bae
(invalid instruction)                                        ; cc0f00b3
	v_min_num_f64_e32 v[1:2], v[179:180], v[171:172]            ; 1a0357b3
	v_lshl_add_u32 v175, v175, 5, s67                           ; d64600af 010d0baf
	v_lshl_add_u32 v177, v177, 5, s67                           ; d64600b1 010d0bb1
	v_lshl_add_u32 v176, v176, 5, s67                           ; d64600b0 010d0bb0
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[165:166], v[169:170]            ; 1a0353a5
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[172:173]            ; 1a0359b4
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[178:179], v[174:175]            ; 1a035db2
(invalid instruction)                                        ; cc0f00b3
	v_min_num_f64_e32 v[1:2], v[179:180], v[175:176]            ; 1a035fb3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[181:182], v[173:174]            ; 1a035bb5
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[176:177]            ; 1a0361b4
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[178:179], v[179:180]            ; 1a0367b2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[181:182], v[177:178]            ; 1a0363b5
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[178:179], v[180:181]            ; 1a0369b2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[178:179], v[181:182]            ; 1a036bb2
	v_permlanex16_b32 v182, v178, s61, s62 op_sel:[1,1]         ; d65c18b6 00f87bb2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[178:179], v[182:183]            ; 1a036db2
(invalid instruction)                                        ; d53210b7
	v_cndmask_b32_e32 v1, v178, v178, vcc_lo                    ; 020365b2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53100b7
	v_cndmask_b32_e32 v1, s60, v183, vcc_lo                     ; 02036e3c
(invalid instruction)                                        ; d58b00b8
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                    ; 020101b7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v184, v184                                    ; 7f7055b8
	v_fma_mix_f32 v185, v162, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000b9 8a0371a2
	v_fma_mix_f32 v189, v166, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bd 8a0371a6
	v_fma_mix_f32 v188, v165, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bc 8a0371a5
	v_fma_mix_f32 v165, v165, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a0371a5
	v_fma_mix_f32 v187, v164, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bb 8a0371a4
	v_fma_mix_f32 v164, v164, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a4 8a0371a4
	v_fma_mix_f32 v166, v166, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a6 8a0371a6
	v_fma_mix_f32 v186, v163, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000ba 8a0371a3
	v_fma_mix_f32 v163, v163, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a3 8a0371a3
	v_fma_mix_f32 v162, v162, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a2 8a0371a2
	v_fma_mix_f32 v190, v167, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000be 8a0371a7
	v_fma_mix_f32 v167, v167, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a7 8a0371a7
	v_fma_mix_f32 v191, v168, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0371a8
	v_fma_mix_f32 v168, v168, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a8 8a0371a8
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v187, v164, vcc_lo                    ; 020349bb
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v188, v165, vcc_lo                    ; 02034bbc
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v189, v166, vcc_lo                    ; 02034dbd
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v185, v162, vcc_lo                    ; 020345b9
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v186, v163, vcc_lo                    ; 020347ba
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v190, v167, vcc_lo                    ; 02034fbe
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v191, v168, vcc_lo                    ; 020351bf
	v_fma_mix_f32 v191, v169, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0371a9
	v_fma_mix_f32 v169, v169, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a0371a9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v191, v169, vcc_lo                    ; 020353bf
	v_fma_mix_f32 v191, v170, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0371aa
	v_fma_mix_f32 v170, v170, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008aa 8a0371aa
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v191, v170, vcc_lo                    ; 020355bf
	v_fma_mix_f32 v191, v171, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0371ab
	v_fma_mix_f32 v171, v171, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ab 8a0371ab
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v191, v171, vcc_lo                    ; 020357bf
	v_fma_mix_f32 v191, v172, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0371ac
	v_fma_mix_f32 v172, v172, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ac 8a0371ac
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v191, v172, vcc_lo                    ; 020359bf
	v_fma_mix_f32 v191, v173, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0371ad
	v_fma_mix_f32 v173, v173, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ad 8a0371ad
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[24:25], 0 ; cc464058 1a023124
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[24:25], 0 ; cc464068 1a023110
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[24:25], 0 ; cc464070 1a02310a
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v191, v173, vcc_lo                    ; 02035bbf
	v_fma_mix_f32 v191, v174, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0371ae
	v_fma_mix_f32 v174, v174, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ae 8a0371ae
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[4:5], v[24:25], 0 ; cc464088 1a023104
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[60:61], v[26:27], v[88:95] ; cc464058 1d62353c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[26:27], v[104:111] ; cc464068 1da23548
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v191, v174, vcc_lo                    ; 02035dbf
	v_fma_mix_f32 v191, v175, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0371af
	v_fma_mix_f32 v175, v175, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a0371af
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[2:3], v[26:27], v[112:119] ; cc464070 1dc23502
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[6:7], v[26:27], v[136:143] ; cc464088 1e223506
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v2, s64, v90, v126                          ; cc210002 05fab440
	v_fma_mixhi_f16 v2, s64, v91, v127                          ; cc220002 05feb640
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v191, v175, vcc_lo                    ; 02035fbf
	v_fma_mix_f32 v191, v176, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0371b0
	v_fma_mix_f32 v176, v176, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a0371b0
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v3, s64, v92, v132                          ; cc210003 0612b840
	v_fma_mixhi_f16 v3, s64, v93, v133                          ; cc220003 0616ba40
	v_fma_mixlo_f16 v4, s64, v94, v134                          ; cc210004 061abc40
	v_fma_mixhi_f16 v4, s64, v95, v135                          ; cc220004 061ebe40
(invalid instruction)                                        ; cc1c0002
	v_subrev_f32_e32 v0, v2, v66                                ; 0a008502
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v5, s64, v104, v52                          ; cc210005 04d2d040
	v_fma_mixhi_f16 v5, s64, v105, v53                          ; cc220005 04d6d240
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v191, v176, vcc_lo                    ; 020361bf
	v_fma_mix_f32 v191, v177, v184, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0371b1
	v_fma_mix_f32 v177, v177, v184, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a0371b1
	v_fma_mixlo_f16 v6, s64, v106, v54                          ; cc210006 04dad440
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v66                                ; 0a008503
	v_fma_mixhi_f16 v6, s64, v107, v55                          ; cc220006 04ded640
(invalid instruction)                                        ; cc1c0004
	v_subrev_f32_e32 v0, v4, v66                                ; 0a008504
(invalid instruction)                                        ; cc1b0002
	v_subrev_f32_e32 v0, v2, v65                                ; 0a008302
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v7, s64, v108, v56                          ; cc210007 04e2d840
	v_fma_mixhi_f16 v7, s64, v109, v57                          ; cc220007 04e6da40
(invalid instruction)                                        ; cc1c0005
	v_subrev_f32_e32 v0, v5, v66                                ; 0a008505
	v_fma_mixlo_f16 v10, s64, v110, v58                         ; cc21000a 04eadc40
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v191, v177, vcc_lo                    ; 020363bf
	v_fma_mixlo_f16 v191, s64, v88, v124                        ; cc2100bf 05f2b040
	v_fma_mixhi_f16 v191, s64, v89, v125                        ; cc2200bf 05f6b240
	v_fma_mixhi_f16 v10, s64, v111, v59                         ; cc22000a 04eede40
(invalid instruction)                                        ; cc1b0003
	v_subrev_f32_e32 v0, v3, v65                                ; 0a008303
(invalid instruction)                                        ; cc1c0006
	v_subrev_f32_e32 v0, v6, v66                                ; 0a008506
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v11, s64, v112, v48                         ; cc21000b 04c2e040
(invalid instruction)                                        ; cc1b0004
	v_subrev_f32_e32 v0, v4, v65                                ; 0a008304
	v_fma_mixhi_f16 v11, s64, v113, v49                         ; cc22000b 04c6e240
(invalid instruction)                                        ; cc1c0007
	v_subrev_f32_e32 v0, v7, v66                                ; 0a008507
	v_fma_mixlo_f16 v16, s64, v114, v50                         ; cc210010 04cae440
(invalid instruction)                                        ; cc1b0005
	v_subrev_f32_e32 v0, v5, v65                                ; 0a008305
	v_fma_mixhi_f16 v16, s64, v115, v51                         ; cc220010 04cee640
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v66                              ; 0a0085bf
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v17, s64, v116, v64                         ; cc210011 0502e840
	v_fma_mixhi_f16 v17, s64, v117, v65                         ; cc220011 0506ea40
(invalid instruction)                                        ; cc1c000a
	v_subrev_f32_e32 v0, v10, v66                               ; 0a00850a
(invalid instruction)                                        ; cc1b0006
	v_subrev_f32_e32 v0, v6, v65                                ; 0a008306
	v_fma_mixlo_f16 v23, s64, v118, v66                         ; cc210017 050aec40
	v_fma_mixhi_f16 v23, s64, v119, v67                         ; cc220017 050eee40
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v66                               ; 0a00850b
(invalid instruction)                                        ; cc1b0007
	v_subrev_f32_e32 v0, v7, v65                                ; 0a008307
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v24, s64, v136, v68                         ; cc210018 05131040
	v_fma_mixhi_f16 v24, s64, v137, v69                         ; cc220018 05171240
(invalid instruction)                                        ; cc1c0010
	v_subrev_f32_e32 v0, v16, v66                               ; 0a008510
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v65                              ; 0a0083bf
	v_fma_mixlo_f16 v25, s64, v138, v70                         ; cc210019 051b1440
	v_fma_mixhi_f16 v25, s64, v139, v71                         ; cc220019 051f1640
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v66                               ; 0a008511
(invalid instruction)                                        ; cc1b000a
	v_subrev_f32_e32 v0, v10, v65                               ; 0a00830a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v26, s64, v140, v76                         ; cc21001a 05331840
	v_fma_mixhi_f16 v26, s64, v141, v77                         ; cc22001a 05371a40
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v66                               ; 0a008517
(invalid instruction)                                        ; cc1b000b
	v_subrev_f32_e32 v0, v11, v65                               ; 0a00830b
	v_fma_mixlo_f16 v27, s64, v142, v78                         ; cc21001b 053b1c40
(invalid instruction)                                        ; cc1c0018
	v_subrev_f32_e32 v0, v24, v66                               ; 0a008518
	v_fma_mixhi_f16 v27, s64, v143, v79                         ; cc22001b 053f1e40
(invalid instruction)                                        ; cc1b0010
	v_subrev_f32_e32 v0, v16, v65                               ; 0a008310
	v_lshl_add_u32 v191, v191, 5, s67                           ; d64600bf 010d0bbf
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v66                               ; 0a008519
	v_lshl_add_u32 v5, v5, 5, s67                               ; d6460005 010d0b05
(invalid instruction)                                        ; cc1b0011
	v_subrev_f32_e32 v0, v17, v65                               ; 0a008311
(invalid instruction)                                        ; cc1c001a
	v_subrev_f32_e32 v0, v26, v66                               ; 0a00851a
(invalid instruction)                                        ; cc1b0017
	v_subrev_f32_e32 v0, v23, v65                               ; 0a008317
	v_lshl_add_u32 v11, v11, 5, s67                             ; d646000b 010d0b0b
	v_lshl_add_u32 v2, v2, 5, s67                               ; d6460002 010d0b02
	v_lshl_add_u32 v6, v6, 5, s67                               ; d6460006 010d0b06
(invalid instruction)                                        ; cc1b0018
	v_subrev_f32_e32 v0, v24, v65                               ; 0a008318
(invalid instruction)                                        ; cc1c001b
	v_subrev_f32_e32 v0, v27, v66                               ; 0a00851b
	v_lshl_add_u32 v16, v16, 5, s67                             ; d6460010 010d0b10
(invalid instruction)                                        ; cc1b0019
	v_subrev_f32_e32 v0, v25, v65                               ; 0a008319
	v_lshl_add_u32 v3, v3, 5, s67                               ; d6460003 010d0b03
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[191:192], v[5:6]                ; 1a020bbf
	v_lshl_add_u32 v7, v7, 5, s67                               ; d6460007 010d0b07
(invalid instruction)                                        ; cc1b001a
	v_subrev_f32_e32 v0, v26, v65                               ; 0a00831a
	v_lshl_add_u32 v17, v17, 5, s67                             ; d6460011 010d0b11
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[2:3], v[6:7]                    ; 1a020d02
	v_lshl_add_u32 v24, v24, 5, s67                             ; d6460018 010d0b18
	v_lshl_add_u32 v4, v4, 5, s67                               ; d6460004 010d0b04
	v_lshl_add_u32 v10, v10, 5, s67                             ; d646000a 010d0b0a
(invalid instruction)                                        ; cc1b001b
	v_subrev_f32_e32 v0, v27, v65                               ; 0a00831b
	v_lshl_add_u32 v25, v25, 5, s67                             ; d6460019 010d0b19
	v_lshl_add_u32 v23, v23, 5, s67                             ; d6460017 010d0b17
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[36:37], v[11:12]                ; 1a021724
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[3:4], v[7:8]                    ; 1a020f03
	v_lshl_add_u32 v26, v26, 5, s67                             ; d646001a 010d0b1a
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[16:17]                ; 1a022125
(invalid instruction)                                        ; cc0f0030
	v_min_num_f64_e32 v[1:2], v[4:5], v[10:11]                  ; 1a021504
	v_lshl_add_u32 v27, v27, 5, s67                             ; d646001b 010d0b1b
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[36:37], v[24:25]                ; 1a023124
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[17:18]                ; 1a022327
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[25:26]                ; 1a023325
(invalid instruction)                                        ; cc0f0030
	v_min_num_f64_e32 v[1:2], v[48:49], v[23:24]                ; 1a022f30
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[26:27]                ; 1a023527
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[36:37], v[37:38]                ; 1a024b24
(invalid instruction)                                        ; cc0f0030
	v_min_num_f64_e32 v[1:2], v[48:49], v[27:28]                ; 1a023730
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[36:37], v[39:40]                ; 1a024f24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[36:37], v[48:49]                ; 1a026124
	v_permlanex16_b32 v49, v36, s61, s62 op_sel:[1,1]           ; d65c1831 00f87b24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[36:37], v[49:50]                ; 1a026324
	v_add_f16_e32 v50, v36, v164/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64654924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v50, s60, v50                             ; 6264643c
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v51, v51                                      ; 7e665533
	v_fma_mix_f32 v53, v2, v51, neg(0) op_sel_hi:[1,0,0]        ; cc200035 8a026702
	v_fma_mix_f32 v52, v191, v51, neg(0) op_sel_hi:[1,0,0]      ; cc200034 8a0267bf
	v_fma_mix_f32 v191, v191, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a0267bf
	v_fma_mix_f32 v54, v3, v51, neg(0) op_sel_hi:[1,0,0]        ; cc200036 8a026703
	v_fma_mix_f32 v2, v2, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200802 8a026702
	v_fma_mix_f32 v55, v4, v51, neg(0) op_sel_hi:[1,0,0]        ; cc200037 8a026704
	v_fma_mix_f32 v4, v4, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200804 8a026704
	v_fma_mix_f32 v57, v6, v51, neg(0) op_sel_hi:[1,0,0]        ; cc200039 8a026706
	v_fma_mix_f32 v56, v5, v51, neg(0) op_sel_hi:[1,0,0]        ; cc200038 8a026705
	v_fma_mix_f32 v5, v5, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200805 8a026705
	v_fma_mix_f32 v3, v3, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200803 8a026703
	v_fma_mix_f32 v6, v6, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200806 8a026706
	v_fma_mix_f32 v58, v7, v51, neg(0) op_sel_hi:[1,0,0]        ; cc20003a 8a026707
	v_fma_mix_f32 v7, v7, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200807 8a026707
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v52, v191, vcc_lo                     ; 02037f34
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v53, v2, vcc_lo                       ; 02020535
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v56, v5, vcc_lo                       ; 02020b38
	v_fma_mix_f32 v59, v10, v51, neg(0) op_sel_hi:[1,0,0]       ; cc20003b 8a02670a
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v54, v3, vcc_lo                       ; 02020736
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v55, v4, vcc_lo                       ; 02020937
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v57, v6, vcc_lo                       ; 02020d39
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v58, v7, vcc_lo                       ; 02020f3a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[4:7], v22, s[32:35], null offen          ; c405c07c 40804004 00000016
	buffer_load_b128 v[52:55], v22, s[32:35], null offen offset:16 ; c405c07c 40804034 00001016
	v_fma_mix_f32 v10, v10, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080a 8a02670a
	v_fma_mix_f32 v60, v11, v51, neg(0) op_sel_hi:[1,0,0]       ; cc20003c 8a02670b
	v_fma_mix_f32 v11, v11, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080b 8a02670b
	v_fma_mix_f32 v61, v16, v51, neg(0) op_sel_hi:[1,0,0]       ; cc20003d 8a026710
	v_fma_mix_f32 v16, v16, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200810 8a026710
	v_fma_mix_f32 v64, v17, v51, neg(0) op_sel_hi:[1,0,0]       ; cc200040 8a026711
	v_mad_u32_u24 v70, s59, 0xc00, v40                          ; d60b0046 04a1fe3b 00000c00
	v_lshl_add_u32 v41, v41, 7, v33                             ; d6460029 04850f29
	v_fma_mix_f32 v17, v17, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200811 8a026711
	v_fma_mix_f32 v65, v23, v51, neg(0) op_sel_hi:[1,0,0]       ; cc200041 8a026717
	v_fma_mix_f32 v23, v23, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a026717
	v_fma_mix_f32 v66, v24, v51, neg(0) op_sel_hi:[1,0,0]       ; cc200042 8a026718
	v_fma_mix_f32 v24, v24, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200818 8a026718
	v_fma_mix_f32 v67, v25, v51, neg(0) op_sel_hi:[1,0,0]       ; cc200043 8a026719
	v_fma_mix_f32 v25, v25, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a026719
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v59, v10, vcc_lo                      ; 0202153b
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v60, v11, vcc_lo                      ; 0202173c
	v_fma_mix_f32 v68, v26, v51, neg(0) op_sel_hi:[1,0,0]       ; cc200044 8a02671a
	v_fma_mix_f32 v26, v26, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081a 8a02671a
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v61, v16, vcc_lo                      ; 0202213d
	v_fma_mix_f32 v69, v27, v51, neg(0) op_sel_hi:[1,0,0]       ; cc200045 8a02671b
	v_fma_mix_f32 v27, v27, v51, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081b 8a02671b
	v_add_nc_u32_e32 v70, v70, v41                              ; 4a8c5346
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v64, v17, vcc_lo                      ; 02022340
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v65, v23, vcc_lo                      ; 02022f41
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v66, v24, vcc_lo                      ; 02023142
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v67, v25, vcc_lo                      ; 02023343
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v68, v26, vcc_lo                      ; 02023544
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v69, v27, vcc_lo                      ; 02023745
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_load_u8_d16 v24, v70 offset:16384                        ; da884000 18000046
	ds_load_u8_d16 v71, v70 offset:16400                        ; da884010 47000046
	ds_load_u8_d16_hi v26, v70 offset:16416                     ; da8c4020 1a000046
	ds_load_u8_d16 v72, v70 offset:16432                        ; da884030 48000046
	ds_load_u8_d16 v25, v70 offset:16448                        ; da884040 19000046
	ds_load_u8_d16 v73, v70 offset:16464                        ; da884050 49000046
	ds_load_u8_d16_hi v27, v70 offset:16480                     ; da8c4060 1b000046
	ds_load_u8_d16 v76, v70 offset:16496                        ; da884070 4c000046
	ds_load_u8_d16 v48, v70 offset:20480                        ; da885000 30000046
	ds_load_u8_d16 v77, v70 offset:20496                        ; da885010 4d000046
	ds_load_u8_d16_hi v50, v70 offset:20512                     ; da8c5020 32000046
	ds_load_u8_d16 v78, v70 offset:20528                        ; da885030 4e000046
	ds_load_u8_d16 v49, v70 offset:20544                        ; da885040 31000046
	ds_load_u8_d16 v79, v70 offset:20560                        ; da885050 4f000046
	ds_load_u8_d16_hi v51, v70 offset:20576                     ; da8c5060 33000046
	ds_load_u8_d16 v80, v70 offset:20592                        ; da885070 50000046
	ds_load_u8_d16 v56, v70 offset:24576                        ; da886000 38000046
	ds_load_u8_d16 v81, v70 offset:24592                        ; da886010 51000046
	ds_load_u8_d16_hi v58, v70 offset:24608                     ; da8c6020 3a000046
	ds_load_u8_d16 v84, v70 offset:24624                        ; da886030 54000046
	ds_load_u8_d16 v57, v70 offset:24640                        ; da886040 39000046
	ds_load_u8_d16 v85, v70 offset:24656                        ; da886050 55000046
	ds_load_u8_d16_hi v59, v70 offset:24672                     ; da8c6060 3b000046
	ds_load_u8_d16 v88, v70 offset:24688                        ; da886070 58000046
	ds_load_u8_d16 v60, v70 offset:28672                        ; da887000 3c000046
	ds_load_u8_d16 v89, v70 offset:28688                        ; da887010 59000046
	ds_load_u8_d16_hi v64, v70 offset:28704                     ; da8c7020 40000046
	ds_load_u8_d16 v90, v70 offset:28720                        ; da887030 5a000046
	ds_load_u8_d16 v61, v70 offset:28736                        ; da887040 3d000046
	ds_load_u8_d16 v91, v70 offset:28752                        ; da887050 5b000046
	ds_load_u8_d16_hi v65, v70 offset:28768                     ; da8c7060 41000046
	ds_load_u8_d16 v92, v70 offset:28784                        ; da887070 5c000046
	s_wait_dscnt 0x1e                                           ; bfc6001e
	v_perm_b32 v24, v24, v71, 0x7060004                         ; d6440018 03fe8f18 07060004
	s_wait_dscnt 0x1a                                           ; bfc6001a
	v_perm_b32 v25, v25, v73, 0x7060004                         ; d6440019 03fe9319 07060004
	s_wait_dscnt 0x16                                           ; bfc60016
	v_perm_b32 v48, v48, v77, 0x7060004                         ; d6440030 03fe9b30 07060004
	s_wait_dscnt 0x12                                           ; bfc60012
	v_perm_b32 v49, v49, v79, 0x7060004                         ; d6440031 03fe9f31 07060004
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_perm_b32 v24, v24, v26, 0x7020504                         ; d6440018 03fe3518 07020504
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_perm_b32 v56, v56, v81, 0x7060004                         ; d6440038 03fea338 07060004
	v_perm_b32 v25, v25, v27, 0x7020504                         ; d6440019 03fe3719 07020504
	v_perm_b32 v48, v48, v50, 0x7020504                         ; d6440030 03fe6530 07020504
	v_perm_b32 v49, v49, v51, 0x7020504                         ; d6440031 03fe6731 07020504
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_perm_b32 v57, v57, v85, 0x7060004                         ; d6440039 03feab39 07060004
	v_perm_b32 v24, v24, v72, 0x60504                           ; d6440018 03fe9118 00060504
	v_perm_b32 v56, v56, v58, 0x7020504                         ; d6440038 03fe7538 07020504
	v_perm_b32 v25, v25, v76, 0x60504                           ; d6440019 03fe9919 00060504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[96:97], 0 ; cc464068 1a02c118
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[24:25], v[36:37], 0 ; cc464080 1a024918
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[8:9], 0 ; cc464078 1a021118
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[20:21], 0 ; cc464070 1a022918
	buffer_load_b128 v[24:27], v22, s[32:35], null offen offset:64 ; c405c07c 40804018 00004016
	v_perm_b32 v48, v48, v78, 0x60504                           ; d6440030 03fe9d30 00060504
	v_perm_b32 v49, v49, v80, 0x60504                           ; d6440031 03fea131 00060504
	s_wait_dscnt 0x9                                            ; bfc60009
	v_perm_b32 v57, v57, v59, 0x7020504                         ; d6440039 03fe7739 07020504
	v_perm_b32 v56, v56, v84, 0x60504                           ; d6440038 03fea938 00060504
	s_wait_dscnt 0x6                                            ; bfc60006
	v_perm_b32 v60, v60, v89, 0x7060004                         ; d644003c 03feb33c 07060004
	s_wait_dscnt 0x2                                            ; bfc60002
	v_perm_b32 v61, v61, v91, 0x7060004                         ; d644003d 03feb73d 07060004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[82:83], v[104:111] ; cc464068 1da2a530
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[46:47], v[120:127] ; cc464078 1de25d30
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[48:49], v[2:3], v[128:135] ; cc464080 1e020530
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[28:29], v[112:119] ; cc464070 1dc23930
	buffer_load_b128 v[48:51], v22, s[32:35], null offen offset:80 ; c405c07c 40804030 00005016
	v_perm_b32 v57, v57, v88, 0x60504                           ; d6440039 03feb139 00060504
	v_perm_b32 v60, v60, v64, 0x7020504                         ; d644003c 03fe813c 07020504
	s_wait_dscnt 0x1                                            ; bfc60001
	v_perm_b32 v61, v61, v65, 0x7020504                         ; d644003d 03fe833d 07020504
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[56:57], v[12:13], v[104:111] ; cc464068 1da21938
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[62:63], v[120:127] ; cc464078 1de27d38
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[10:11], v[128:135] ; cc464080 1e021538
	v_perm_b32 v60, v60, v90, 0x60504                           ; d644003c 03feb53c 00060504
	s_wait_dscnt 0x0                                            ; bfc60000
	v_perm_b32 v61, v61, v92, 0x60504                           ; d644003d 03feb93d 00060504
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[56:57], v[30:31], v[112:119] ; cc464070 1dc23d38
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[60:61], v[74:75], v[120:127] ; cc464078 1de2953c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[14:15], v[104:111] ; cc464068 1da21d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[16:17], v[128:135] ; cc464080 1e02213c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[60:61], v[44:45], v[112:119] ; cc464070 1dc2593c
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	ds_store_2addr_stride64_b64 v35, v[22:23], v[56:57] offset0:32 offset1:40 ; d93c2820 00381623
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	ds_store_2addr_stride64_b64 v35, v[22:23], v[56:57] offset0:48 offset1:56 ; d93c3830 00381623
	ds_load_u8_d16 v22, v70 offset:16640                        ; da884100 16000046
	ds_load_u8_d16 v93, v70 offset:16656                        ; da884110 5d000046
	ds_load_u8_d16_hi v56, v70 offset:16672                     ; da8c4120 38000046
	ds_load_u8_d16 v94, v70 offset:16688                        ; da884130 5e000046
	ds_load_u8_d16 v23, v70 offset:16704                        ; da884140 17000046
	ds_load_u8_d16 v95, v70 offset:16720                        ; da884150 5f000046
	ds_load_u8_d16_hi v57, v70 offset:16736                     ; da8c4160 39000046
	ds_load_u8_d16 v98, v70 offset:16752                        ; da884170 62000046
	ds_load_u8_d16 v58, v70 offset:20736                        ; da885100 3a000046
	ds_load_u8_d16 v99, v70 offset:20752                        ; da885110 63000046
	ds_load_u8_d16_hi v60, v70 offset:20768                     ; da8c5120 3c000046
	ds_load_u8_d16 v100, v70 offset:20784                       ; da885130 64000046
	ds_load_u8_d16 v59, v70 offset:20800                        ; da885140 3b000046
	ds_load_u8_d16 v101, v70 offset:20816                       ; da885150 65000046
	ds_load_u8_d16_hi v61, v70 offset:20832                     ; da8c5160 3d000046
	ds_load_u8_d16 v102, v70 offset:20848                       ; da885170 66000046
	ds_load_u8_d16 v64, v70 offset:24832                        ; da886100 40000046
	ds_load_u8_d16 v103, v70 offset:24848                       ; da886110 67000046
	ds_load_u8_d16_hi v66, v70 offset:24864                     ; da8c6120 42000046
	ds_load_u8_d16 v104, v70 offset:24880                       ; da886130 68000046
	ds_load_u8_d16 v65, v70 offset:24896                        ; da886140 41000046
	ds_load_u8_d16 v105, v70 offset:24912                       ; da886150 69000046
	ds_load_u8_d16_hi v67, v70 offset:24928                     ; da8c6160 43000046
	ds_load_u8_d16 v106, v70 offset:24944                       ; da886170 6a000046
	ds_load_u8_d16 v68, v70 offset:28928                        ; da887100 44000046
	ds_load_u8_d16 v107, v70 offset:28944                       ; da887110 6b000046
	ds_load_u8_d16_hi v72, v70 offset:28960                     ; da8c7120 48000046
	ds_load_u8_d16 v108, v70 offset:28976                       ; da887130 6c000046
	ds_load_u8_d16 v69, v70 offset:28992                        ; da887140 45000046
	ds_load_u8_d16 v109, v70 offset:29008                       ; da887150 6d000046
	ds_load_u8_d16_hi v73, v70 offset:29024                     ; da8c7160 49000046
	ds_load_u8_d16 v110, v70 offset:29040                       ; da887170 6e000046
	v_add_nc_u32_e32 v35, 0x100, v35                            ; 4a4646ff 00000100
	s_lshr_b32 s7, s7, 2                                        ; 85078207
	s_wait_dscnt 0x1e                                           ; bfc6001e
	v_perm_b32 v22, v22, v93, 0x7060004                         ; d6440016 03febb16 07060004
	s_wait_dscnt 0x1a                                           ; bfc6001a
	v_perm_b32 v23, v23, v95, 0x7060004                         ; d6440017 03febf17 07060004
	s_wait_dscnt 0x16                                           ; bfc60016
	v_perm_b32 v58, v58, v99, 0x7060004                         ; d644003a 03fec73a 07060004
	s_wait_dscnt 0x12                                           ; bfc60012
	v_perm_b32 v59, v59, v101, 0x7060004                        ; d644003b 03fecb3b 07060004
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v86, v86, s7, v18                                ; d6550056 04480f56
	v_perm_b32 v22, v22, v56, 0x7020504                         ; d6440016 03fe7116 07020504
	v_perm_b32 v23, v23, v57, 0x7020504                         ; d6440017 03fe7317 07020504
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
	v_lshlrev_b32_e32 v86, 2, v86                               ; 30acac82
	v_perm_b32 v22, v22, v94, 0x60504                           ; d6440016 03febd16 00060504
	v_perm_b32 v23, v23, v98, 0x60504                           ; d6440017 03fec517 00060504
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[8:9], 0 ; cc464078 1a021116
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[20:21], 0 ; cc464070 1a022916
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[36:37], 0 ; cc464080 1a024916
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[22:23], v[96:97], 0 ; cc464058 1a02c116
	buffer_load_b128 v[20:23], v86, s[36:39], null offen        ; c405c07c 40804814 00000056
	v_perm_b32 v58, v58, v60, 0x7020504                         ; d644003a 03fe793a 07020504
	s_wait_dscnt 0x11                                           ; bfc60011
	v_perm_b32 v59, v59, v61, 0x7020504                         ; d644003b 03fe7b3b 07020504
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_perm_b32 v64, v64, v103, 0x7060004                        ; d6440040 03fecf40 07060004
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_perm_b32 v65, v65, v105, 0x7060004                        ; d6440041 03fed341 07060004
	s_wait_dscnt 0x6                                            ; bfc60006
	v_perm_b32 v68, v68, v107, 0x7060004                        ; d6440044 03fed744 07060004
	v_perm_b32 v58, v58, v100, 0x60504                          ; d644003a 03fec93a 00060504
	s_wait_dscnt 0x2                                            ; bfc60002
	v_perm_b32 v69, v69, v109, 0x7060004                        ; d6440045 03fedb45 07060004
	v_perm_b32 v59, v59, v102, 0x60504                          ; d644003b 03fecd3b 00060504
	v_perm_b32 v64, v64, v66, 0x7020504                         ; d6440040 03fe8540 07020504
	v_perm_b32 v65, v65, v67, 0x7020504                         ; d6440041 03fe8741 07020504
	v_perm_b32 v68, v68, v72, 0x7020504                         ; d6440044 03fe9144 07020504
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[2:3], v[128:135] ; cc464080 1e02053a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[58:59], v[82:83], v[88:95] ; cc464058 1d62a53a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[28:29], v[112:119] ; cc464070 1dc2393a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[58:59], v[46:47], v[120:127] ; cc464078 1de25d3a
	s_wait_dscnt 0x1                                            ; bfc60001
	v_perm_b32 v69, v69, v73, 0x7020504                         ; d6440045 03fe9345 07020504
	v_perm_b32 v64, v64, v104, 0x60504                          ; d6440040 03fed140 00060504
	v_perm_b32 v65, v65, v106, 0x60504                          ; d6440041 03fed541 00060504
	v_perm_b32 v68, v68, v108, 0x60504                          ; d6440044 03fed944 00060504
	s_wait_dscnt 0x0                                            ; bfc60000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_perm_b32 v69, v69, v110, 0x60504                          ; d6440045 03fedd45 00060504
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[64:65], v[10:11], v[128:135] ; cc464080 1e021540
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[12:13], v[88:95] ; cc464058 1d621940
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[14:15], v[88:95] ; cc464058 1d621d44
	buffer_load_b128 v[12:15], v86, s[36:39], null offen offset:512 ; c405c07c 4080480c 00020056
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[64:65], v[30:31], v[112:119] ; cc464070 1dc23d40
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[62:63], v[120:127] ; cc464078 1de27d40
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[16:17], v[128:135] ; cc464080 1e022144
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[68:69], v[44:45], v[112:119] ; cc464070 1dc25944
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[74:75], v[120:127] ; cc464078 1de29544
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	ds_store_2addr_stride64_b64 v35, v[2:3], v[8:9] offset0:32 offset1:40 ; d93c2820 00080223
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	ds_store_2addr_stride64_b64 v35, v[2:3], v[8:9] offset0:48 offset1:56 ; d93c3830 00080223
	buffer_load_b128 v[8:11], v86, s[36:39], null offen offset:1024 ; c405c07c 40804808 00040056
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[2:3], v87                                     ; d9d80000 02000057
	ds_load_b64 v[16:17], v87 offset:4096                       ; d9d81000 10000057
	ds_load_b64 v[28:29], v87 offset:8192                       ; d9d82000 1c000057
	buffer_load_b128 v[44:47], v86, s[36:39], null offen offset:1536 ; c405c07c 4080482c 00060056
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[30:31], v2                           ; 7e3cdd02
	s_wait_loadcnt 0x7                                          ; bfc00007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v57, v31, v5 :: v_dual_mul_f32 v56, v30, v4  ; c8c60b1f 3938091e
	v_cvt_pk_f32_fp8_e32 v[30:31], v130                         ; 7e3cdd82
	v_dual_mul_f32 v59, v31, v7 :: v_dual_mul_f32 v58, v30, v6  ; c8c60f1f 3b3a0d1e
	v_cvt_pk_f32_fp8_e32 v[30:31], v3                           ; 7e3cdd03
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v61, v31, v53 :: v_dual_mul_f32 v60, v30, v52 ; c8c66b1f 3d3c691e
	ds_load_b64 v[30:31], v87 offset:12288                      ; d9d83000 1e000057
	buffer_load_b128 v[68:71], v86, s[36:39], null offen offset:2048 ; c405c07c 40804844 00080056
	ds_load_b64 v[36:37], v87 offset:256                        ; d9d80100 24000057
	buffer_load_b128 v[72:75], v86, s[36:39], null offen offset:2560 ; c405c07c 40804848 000a0056
	v_cvt_pk_f32_fp8_e32 v[2:3], v131                           ; 7e04dd83
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v63, v3, v55 :: v_dual_mul_f32 v62, v2, v54  ; c8c66f03 3f3e6d02
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[2:3], v16                            ; 7e04dd10
	v_dual_mul_f32 v65, v3, v5 :: v_dual_mul_f32 v64, v2, v4    ; c8c60b03 41400902
	buffer_load_b128 v[80:83], v86, s[36:39], null offen offset:3072 ; c405c07c 40804850 000c0056
	v_cvt_pk_f32_fp8_e32 v[2:3], v144                           ; 7e04dd90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v67, v3, v7 :: v_dual_mul_f32 v66, v2, v6    ; c8c60f03 43420d02
	v_cvt_pk_f32_fp8_e32 v[2:3], v17                            ; 7e04dd11
	v_cvt_pk_f32_fp8_e32 v[16:17], v145                         ; 7e20dd91
	v_dual_mul_f32 v77, v3, v53 :: v_dual_mul_f32 v76, v2, v52  ; c8c66b03 4d4c6902
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[2:3], v28                            ; 7e04dd1c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v89, v3, v5 :: v_dual_mul_f32 v88, v2, v4    ; c8c60b03 59580902
	v_cvt_pk_f32_fp8_e32 v[2:3], v156                           ; 7e04dd9c
	v_dual_mul_f32 v91, v3, v7 :: v_dual_mul_f32 v90, v2, v6    ; c8c60f03 5b5a0d02
	v_cvt_pk_f32_fp8_e32 v[2:3], v29                            ; 7e04dd1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_dual_mul_f32 v79, v17, v55 :: v_dual_mul_f32 v92, v2, v52 ; c8c66f11 4f5c6902
	v_dual_mul_f32 v93, v3, v53 :: v_dual_mul_f32 v78, v16, v54 ; c8c66b03 5d4e6d10
	ds_load_b64 v[16:17], v87 offset:4352                       ; d9d81100 10000057
	v_cvt_pk_f32_fp8_e32 v[2:3], v157                           ; 7e04dd9d
	v_dual_mul_f32 v95, v3, v55 :: v_dual_mul_f32 v94, v2, v54  ; c8c66f03 5f5e6d02
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[2:3], v30                            ; 7e04dd1e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v96, v2, v4                                   ; 10c00902
	v_mul_f32_e32 v97, v3, v5                                   ; 10c20b03
	v_cvt_pk_f32_fp8_e32 v[2:3], v158                           ; 7e04dd9e
	v_dual_mul_f32 v99, v3, v7 :: v_dual_mul_f32 v98, v2, v6    ; c8c60f03 63620d02
	buffer_load_b128 v[4:7], v86, s[36:39], null offen offset:3584 ; c405c07c 40804804 000e0056
	ds_load_b64 v[28:29], v87 offset:8448                       ; d9d82100 1c000057
	v_cvt_pk_f32_fp8_e32 v[2:3], v31                            ; 7e04dd1f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v101, v3, v53 :: v_dual_mul_f32 v100, v2, v52 ; c8c66b03 65646902
	v_cvt_pk_f32_fp8_e32 v[2:3], v159                           ; 7e04dd9f
	v_dual_mul_f32 v103, v3, v55 :: v_dual_mul_f32 v102, v2, v54 ; c8c66f03 67666d02
	buffer_load_b128 v[52:55], v86, s[36:39], null offen offset:4096 ; c405c07c 40804834 00100056
	ds_load_b64 v[30:31], v87 offset:12544                      ; d9d83100 1e000057
	buffer_load_b128 v[116:119], v86, s[36:39], null offen offset:4608 ; c405c07c 40804874 00120056
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[2:3], v36                            ; 7e04dd24
	s_wait_loadcnt 0xb                                          ; bfc0000b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v105, v3, v25 :: v_dual_mul_f32 v104, v2, v24 ; c8c63303 69683102
	v_cvt_pk_f32_fp8_e32 v[2:3], v164                           ; 7e04dda4
	v_dual_mul_f32 v107, v3, v27 :: v_dual_mul_f32 v106, v2, v26 ; c8c63703 6b6a3502
	v_cvt_pk_f32_fp8_e32 v[2:3], v37                            ; 7e04dd25
	s_wait_loadcnt 0xa                                          ; bfc0000a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v109, v3, v49 :: v_dual_mul_f32 v108, v2, v48 ; c8c66303 6d6c6102
	v_cvt_pk_f32_fp8_e32 v[2:3], v165                           ; 7e04dda5
	v_dual_mul_f32 v111, v3, v51 :: v_dual_mul_f32 v110, v2, v50 ; c8c66703 6f6e6502
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[2:3], v16                            ; 7e04dd10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v3, v25 :: v_dual_mul_f32 v112, v2, v24 ; c8c63303 71703102
	v_cvt_pk_f32_fp8_e32 v[2:3], v144                           ; 7e04dd90
	v_dual_mul_f32 v115, v3, v27 :: v_dual_mul_f32 v114, v2, v26 ; c8c63703 73723502
	v_cvt_pk_f32_fp8_e32 v[2:3], v17                            ; 7e04dd11
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v125, v3, v49 :: v_dual_mul_f32 v124, v2, v48 ; c8c66303 7d7c6102
	v_cvt_pk_f32_fp8_e32 v[2:3], v145                           ; 7e04dd91
	ds_load_b64 v[16:17], v43 offset:16384                      ; d9d84000 1000002b
	ds_load_b64 v[36:37], v43 offset:20480                      ; d9d85000 2400002b
	buffer_load_b128 v[120:123], v86, s[36:39], null offen offset:5120 ; c405c07c 40804878 00140056
	ds_load_b64 v[84:85], v43 offset:24576                      ; d9d86000 5400002b
	ds_load_b64 v[128:129], v43 offset:28672                    ; d9d87000 8000002b
	buffer_load_b128 v[132:135], v86, s[36:39], null offen offset:5632 ; c405c07c 40804884 00160056
	v_dual_mul_f32 v127, v3, v51 :: v_dual_mul_f32 v126, v2, v50 ; c8c66703 7f7e6502
	s_wait_dscnt 0x5                                            ; bfc60005
	v_cvt_pk_f32_fp8_e32 v[2:3], v28                            ; 7e04dd1c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v137, v3, v25 :: v_dual_mul_f32 v136, v2, v24 ; c8c63303 89883102
	v_cvt_pk_f32_fp8_e32 v[2:3], v156                           ; 7e04dd9c
	v_dual_mul_f32 v139, v3, v27 :: v_dual_mul_f32 v138, v2, v26 ; c8c63703 8b8a3502
	v_cvt_pk_f32_fp8_e32 v[2:3], v29                            ; 7e04dd1d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v141, v3, v49 :: v_dual_mul_f32 v140, v2, v48 ; c8c66303 8d8c6102
	v_cvt_pk_f32_fp8_e32 v[2:3], v157                           ; 7e04dd9d
	ds_load_b64 v[28:29], v43 offset:16640                      ; d9d84100 1c00002b
	ds_load_b64 v[130:131], v43 offset:20736                    ; d9d85100 8200002b
	ds_load_b64 v[146:147], v43 offset:24832                    ; d9d86100 9200002b
	ds_load_b64 v[148:149], v43 offset:28928                    ; d9d87100 9400002b
	v_dual_mul_f32 v143, v3, v51 :: v_dual_mul_f32 v142, v2, v50 ; c8c66703 8f8e6502
	s_wait_dscnt 0x8                                            ; bfc60008
	v_cvt_pk_f32_fp8_e32 v[2:3], v30                            ; 7e04dd1e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v144, v2, v24                                 ; 11203102
	v_mul_f32_e32 v145, v3, v25                                 ; 11223303
	v_cvt_pk_f32_fp8_e32 v[2:3], v158                           ; 7e04dd9e
	v_dual_mul_f32 v155, v3, v27 :: v_dual_mul_f32 v154, v2, v26 ; c8c63703 9b9a3502
	buffer_load_b128 v[24:27], v86, s[36:39], null offen offset:6144 ; c405c07c 40804818 00180056
	v_cvt_pk_f32_fp8_e32 v[2:3], v31                            ; 7e04dd1f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v157, v3, v49 :: v_dual_mul_f32 v156, v2, v48 ; c8c66303 9d9c6102
	v_cvt_pk_f32_fp8_e32 v[2:3], v159                           ; 7e04dd9f
	ds_load_b64 v[30:31], v43 offset:16896                      ; d9d84200 1e00002b
	ds_load_b64 v[48:49], v43 offset:20992                      ; d9d85200 3000002b
	ds_load_b64 v[150:151], v43 offset:25088                    ; d9d86200 9600002b
	ds_load_b64 v[152:153], v43 offset:29184                    ; d9d87200 9800002b
	buffer_load_b128 v[160:163], v86, s[36:39], null offen offset:6656 ; c405c07c 408048a0 001a0056
	v_dual_mul_f32 v159, v3, v51 :: v_dual_mul_f32 v158, v2, v50 ; c8c66703 9f9e6502
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_dual_mov_b32 v165, v69 :: v_dual_mov_b32 v164, v68        ; ca100145 a5a40144
	v_dual_mov_b32 v69, v77 :: v_dual_mov_b32 v68, v76          ; ca10014d 4544014c
	v_dual_mov_b32 v167, v71 :: v_dual_mov_b32 v166, v70        ; ca100147 a7a60146
	v_dual_mov_b32 v71, v79 :: v_dual_mov_b32 v70, v78          ; ca10014f 4746014e
	ds_load_b64 v[2:3], v43 offset:17152                        ; d9d84300 0200002b
	ds_load_b64 v[50:51], v43 offset:21248                      ; d9d85300 3200002b
	ds_load_b64 v[76:77], v43 offset:25344                      ; d9d86300 4c00002b
	ds_load_b64 v[78:79], v43 offset:29440                      ; d9d87300 4e00002b
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mov_b32 v171, v119 :: v_dual_mov_b32 v170, v118      ; ca100177 abaa0176
	v_dual_mov_b32 v119, v127 :: v_dual_mov_b32 v118, v126      ; ca10017f 7776017e
	v_dual_mov_b32 v169, v117 :: v_dual_mov_b32 v168, v116      ; ca100175 a9a80174
	v_dual_mov_b32 v117, v125 :: v_dual_mov_b32 v116, v124      ; ca10017d 7574017c
	buffer_load_b128 v[124:127], v86, s[36:39], null offen offset:7168 ; c405c07c 4080487c 001c0056
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[20:21], v[16:17], v[56:63] ; cc464038 1ce22114
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[84:85], v[88:95] ; cc464058 1d62a914
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[128:129], v[96:103] ; cc464060 1d830114
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[36:37], v[64:71] ; cc464040 1d024914
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[16:17], v[104:111] ; cc464068 1da22116
	s_wait_dscnt 0x4                                            ; bfc60004
	v_dual_mov_b32 v17, v153 :: v_dual_mov_b32 v16, v152        ; ca100199 11100198
	v_dual_mov_b32 v153, v145 :: v_dual_mov_b32 v152, v144      ; ca100191 99980190
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[84:85], v[136:143] ; cc464088 1e22a916
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[36:37], v[112:119] ; cc464070 1dc24916
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[22:23], v[128:129], v[152:159] ; cc464098 1e630116
	ds_load_b64 v[20:21], v43 offset:17408                      ; d9d84400 1400002b
	ds_load_b64 v[22:23], v43 offset:21504                      ; d9d85400 1600002b
	ds_load_b64 v[36:37], v43 offset:25600                      ; d9d86400 2400002b
	ds_load_b64 v[84:85], v43 offset:29696                      ; d9d87400 5400002b
	buffer_load_b128 v[172:175], v86, s[36:39], null offen offset:7680 ; c405c07c 408048ac 001e0056
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[12:13], v[28:29], v[56:63] ; cc464038 1ce2390c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[146:147], v[88:95] ; cc464058 1d63250c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[148:149], v[96:103] ; cc464060 1d83290c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[12:13], v[130:131], v[64:71] ; cc464040 1d03050c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[28:29], v[104:111] ; cc464068 1da2390e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[14:15], v[146:147], v[136:143] ; cc464088 1e23250e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[130:131], v[112:119] ; cc464070 1dc3050e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[14:15], v[148:149], v[152:159] ; cc464098 1e63290e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[8:9], v[30:31], v[56:63] ; cc464038 1ce23d08
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[150:151], v[88:95] ; cc464058 1d632d08
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[16:17], v[96:103] ; cc464060 1d822108
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[48:49], v[64:71] ; cc464040 1d026108
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[30:31], v[104:111] ; cc464068 1da23d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[150:151], v[136:143] ; cc464088 1e232d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[48:49], v[112:119] ; cc464070 1dc2610a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[10:11], v[16:17], v[152:159] ; cc464098 1e62210a
	ds_load_b64 v[12:13], v43 offset:17664                      ; d9d84500 0c00002b
	ds_load_b64 v[14:15], v43 offset:21760                      ; d9d85500 0e00002b
	ds_load_b64 v[28:29], v43 offset:25856                      ; d9d86500 1c00002b
	ds_load_b64 v[86:87], v43 offset:29952                      ; d9d87500 5600002b
	ds_load_b64 v[8:9], v43 offset:17920                        ; d9d84600 0800002b
	ds_load_b64 v[10:11], v43 offset:22016                      ; d9d85600 0a00002b
	ds_load_b64 v[16:17], v43 offset:26112                      ; d9d86600 1000002b
	ds_load_b64 v[30:31], v43 offset:30208                      ; d9d87600 1e00002b
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[2:3], v[56:63] ; cc464038 1ce2052c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[76:77], v[88:95] ; cc464058 1d62992c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[78:79], v[96:103] ; cc464060 1d829d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[44:45], v[50:51], v[64:71] ; cc464040 1d02652c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[2:3], v[104:111] ; cc464068 1da2052e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[76:77], v[136:143] ; cc464088 1e22992e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[50:51], v[112:119] ; cc464070 1dc2652e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[78:79], v[152:159] ; cc464098 1e629d2e
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[164:165], v[20:21], v[56:63] ; cc464038 1ce229a4
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[164:165], v[36:37], v[88:95] ; cc464058 1d6249a4
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[164:165], v[22:23], v[64:71] ; cc464040 1d022da4
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[166:167], v[20:21], v[104:111] ; cc464068 1da229a6
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[166:167], v[36:37], v[136:143] ; cc464088 1e2249a6
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[166:167], v[22:23], v[112:119] ; cc464070 1dc22da6
	ds_load_b64 v[2:3], v43 offset:18176                        ; d9d84700 0200002b
	ds_load_b64 v[44:45], v43 offset:22272                      ; d9d85700 2c00002b
	ds_load_b64 v[46:47], v43 offset:26368                      ; d9d86700 2e00002b
	ds_load_b64 v[48:49], v43 offset:30464                      ; d9d87700 3000002b
	ds_load_b64 v[20:21], v43 offset:18432                      ; d9d84800 1400002b
	ds_load_b64 v[22:23], v43 offset:22528                      ; d9d85800 1600002b
	ds_load_b64 v[36:37], v43 offset:26624                      ; d9d86800 2400002b
	ds_load_b64 v[50:51], v43 offset:30720                      ; d9d87800 3200002b
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[164:165], v[84:85], v[96:103] ; cc464060 1d82a9a4
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[72:73], v[12:13], v[56:63] ; cc464038 1ce21948
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[28:29], v[88:95] ; cc464058 1d623948
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[72:73], v[14:15], v[64:71] ; cc464040 1d021d48
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[74:75], v[12:13], v[104:111] ; cc464068 1da2194a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[28:29], v[136:143] ; cc464088 1e22394a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[14:15], v[112:119] ; cc464070 1dc21d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[166:167], v[84:85], v[152:159] ; cc464098 1e62a9a6
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[86:87], v[96:103] ; cc464060 1d82ad48
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[80:81], v[8:9], v[56:63] ; cc464038 1ce21150
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[80:81], v[16:17], v[88:95] ; cc464058 1d622150
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[80:81], v[10:11], v[64:71] ; cc464040 1d021550
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[82:83], v[8:9], v[104:111] ; cc464068 1da21152
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[82:83], v[16:17], v[136:143] ; cc464088 1e222152
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[10:11], v[112:119] ; cc464070 1dc21552
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[86:87], v[152:159] ; cc464098 1e62ad4a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[80:81], v[30:31], v[96:103] ; cc464060 1d823d50
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[82:83], v[30:31], v[152:159] ; cc464098 1e623d52
	ds_load_b64 v[12:13], v43 offset:18688                      ; d9d84900 0c00002b
	ds_load_b64 v[14:15], v43 offset:22784                      ; d9d85900 0e00002b
	ds_load_b64 v[28:29], v43 offset:26880                      ; d9d86900 1c00002b
	ds_load_b64 v[72:73], v43 offset:30976                      ; d9d87900 4800002b
	ds_load_b64 v[8:9], v43 offset:18944                        ; d9d84a00 0800002b
	ds_load_b64 v[10:11], v43 offset:23040                      ; d9d85a00 0a00002b
	ds_load_b64 v[16:17], v43 offset:27136                      ; d9d86a00 1000002b
	ds_load_b64 v[30:31], v43 offset:31232                      ; d9d87a00 1e00002b
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[4:5], v[2:3], v[56:63] ; cc464038 1ce20504
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[4:5], v[46:47], v[88:95] ; cc464058 1d625d04
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[4:5], v[44:45], v[64:71] ; cc464040 1d025904
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[6:7], v[2:3], v[104:111] ; cc464068 1da20506
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[6:7], v[44:45], v[112:119] ; cc464070 1dc25906
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[6:7], v[46:47], v[136:143] ; cc464088 1e225d06
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[4:5], v[48:49], v[96:103] ; cc464060 1d826104
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[6:7], v[48:49], v[152:159] ; cc464098 1e626106
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[52:53], v[20:21], v[56:63] ; cc464038 1ce22934
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[36:37], v[88:95] ; cc464058 1d624934
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[52:53], v[22:23], v[64:71] ; cc464040 1d022d34
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[54:55], v[20:21], v[104:111] ; cc464068 1da22936
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[22:23], v[112:119] ; cc464070 1dc22d36
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[54:55], v[36:37], v[136:143] ; cc464088 1e224936
	ds_load_b64 v[2:3], v43 offset:19200                        ; d9d84b00 0200002b
	ds_load_b64 v[4:5], v43 offset:23296                        ; d9d85b00 0400002b
	ds_load_b64 v[6:7], v43 offset:27392                        ; d9d86b00 0600002b
	ds_load_b64 v[44:45], v43 offset:31488                      ; d9d87b00 2c00002b
	ds_load_b64 v[20:21], v43 offset:19456                      ; d9d84c00 1400002b
	ds_load_b64 v[22:23], v43 offset:23552                      ; d9d85c00 1600002b
	ds_load_b64 v[36:37], v43 offset:27648                      ; d9d86c00 2400002b
	ds_load_b64 v[46:47], v43 offset:31744                      ; d9d87c00 2e00002b
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[168:169], v[12:13], v[56:63] ; cc464038 1ce219a8
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[168:169], v[28:29], v[88:95] ; cc464058 1d6239a8
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[168:169], v[14:15], v[64:71] ; cc464040 1d021da8
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[170:171], v[12:13], v[104:111] ; cc464068 1da219aa
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[14:15], v[112:119] ; cc464070 1dc21daa
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[170:171], v[28:29], v[136:143] ; cc464088 1e2239aa
	ds_load_b64 v[12:13], v43 offset:19712                      ; d9d84d00 0c00002b
	ds_load_b64 v[14:15], v43 offset:23808                      ; d9d85d00 0e00002b
	ds_load_b64 v[28:29], v43 offset:27904                      ; d9d86d00 1c00002b
	ds_load_b64 v[48:49], v43 offset:32000                      ; d9d87d00 3000002b
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[50:51], v[96:103] ; cc464060 1d826534
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[54:55], v[50:51], v[152:159] ; cc464098 1e626536
	s_wait_loadcnt_dscnt 0x50f                                  ; bfc8050f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[120:121], v[8:9], v[56:63] ; cc464038 1ce21178
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[120:121], v[16:17], v[88:95] ; cc464058 1d622178
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[120:121], v[10:11], v[64:71] ; cc464040 1d021578
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[122:123], v[8:9], v[104:111] ; cc464068 1da2117a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[122:123], v[10:11], v[112:119] ; cc464070 1dc2157a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[122:123], v[16:17], v[136:143] ; cc464088 1e22217a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[168:169], v[72:73], v[96:103] ; cc464060 1d8291a8
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[170:171], v[72:73], v[152:159] ; cc464098 1e6291aa
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[132:133], v[2:3], v[56:63] ; cc464038 1ce20584
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[132:133], v[6:7], v[88:95] ; cc464058 1d620d84
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[132:133], v[4:5], v[64:71] ; cc464040 1d020984
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[134:135], v[2:3], v[104:111] ; cc464068 1da20586
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[134:135], v[4:5], v[112:119] ; cc464070 1dc20986
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[134:135], v[6:7], v[136:143] ; cc464088 1e220d86
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[120:121], v[30:31], v[96:103] ; cc464060 1d823d78
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[122:123], v[30:31], v[152:159] ; cc464098 1e623d7a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[132:133], v[44:45], v[96:103] ; cc464060 1d825984
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[134:135], v[44:45], v[152:159] ; cc464098 1e625986
	ds_load_b64 v[8:9], v43 offset:19968                        ; d9d84e00 0800002b
	ds_load_b64 v[10:11], v43 offset:24064                      ; d9d85e00 0a00002b
	ds_load_b64 v[16:17], v43 offset:28160                      ; d9d86e00 1000002b
	ds_load_b64 v[30:31], v43 offset:32256                      ; d9d87e00 1e00002b
	ds_load_b64 v[2:3], v43 offset:20224                        ; d9d84f00 0200002b
	ds_load_b64 v[4:5], v43 offset:24320                        ; d9d85f00 0400002b
	ds_load_b64 v[6:7], v43 offset:28416                        ; d9d86f00 0600002b
	ds_load_b64 v[44:45], v43 offset:32512                      ; d9d87f00 2c00002b
	s_wait_loadcnt_dscnt 0x30f                                  ; bfc8030f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[20:21], v[56:63] ; cc464038 1ce22918
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[22:23], v[64:71] ; cc464040 1d022d18
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[36:37], v[88:95] ; cc464058 1d624918
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[20:21], v[104:111] ; cc464068 1da2291a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[22:23], v[112:119] ; cc464070 1dc22d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[36:37], v[136:143] ; cc464088 1e22491a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[46:47], v[96:103] ; cc464060 1d825d18
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[26:27], v[46:47], v[152:159] ; cc464098 1e625d1a
	s_wait_loadcnt_dscnt 0x20b                                  ; bfc8020b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[160:161], v[12:13], v[56:63] ; cc464038 1ce219a0
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[160:161], v[14:15], v[64:71] ; cc464040 1d021da0
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[28:29], v[88:95] ; cc464058 1d6239a0
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[162:163], v[12:13], v[104:111] ; cc464068 1da219a2
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[162:163], v[14:15], v[112:119] ; cc464070 1dc21da2
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[162:163], v[28:29], v[136:143] ; cc464088 1e2239a2
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[160:161], v[48:49], v[96:103] ; cc464060 1d8261a0
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[162:163], v[48:49], v[152:159] ; cc464098 1e6261a2
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[124:125], v[8:9], v[56:63] ; cc464038 1ce2117c
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[124:125], v[10:11], v[64:71] ; cc464040 1d02157c
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[124:125], v[16:17], v[88:95] ; cc464058 1d62217c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[126:127], v[8:9], v[104:111] ; cc464068 1da2117e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[126:127], v[10:11], v[112:119] ; cc464070 1dc2157e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[126:127], v[16:17], v[136:143] ; cc464088 1e22217e
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[124:125], v[30:31], v[96:103] ; cc464060 1d823d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[126:127], v[30:31], v[152:159] ; cc464098 1e623d7e
	s_wait_loadcnt_dscnt 0x3                                    ; bfc80003
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[172:173], v[2:3], v[56:63] ; cc464038 1ce205ac
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[172:173], v[4:5], v[64:71] ; cc464040 1d0209ac
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[172:173], v[6:7], v[88:95] ; cc464058 1d620dac
	s_cmp_ge_i32 s45, 0                                         ; bf03802d
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[174:175], v[2:3], v[104:111] ; cc464068 1da205ae
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[174:175], v[4:5], v[112:119] ; cc464070 1dc209ae
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[174:175], v[6:7], v[136:143] ; cc464088 1e220dae
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[172:173], v[44:45], v[96:103] ; cc464060 1d8259ac
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[174:175], v[44:45], v[152:159] ; cc464098 1e6259ae
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cselect_b32 s68, -1, 0                                    ; 984480c1
	s_cbranch_scc0 BB2                                          ; bfa10009
BB1:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s24, s0                                        ; bf040018
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00002
BB2:
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB5                                          ; bfa10008
BB4:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s21, s0                                        ; bf040015
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB6                                                ; bfa00001
BB5:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB6:
	v_lshlrev_b32_e32 v1, 1, v1                                 ; 30020281
	v_and_b32_e32 v0, 1, v0                                     ; 36000081
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_cndmask_b32_e64 v4, v56, v60, s0                          ; d5010004 00027938
	v_cndmask_b32_e64 v60, v60, v56, s0                         ; d501003c 0002713c
	v_cndmask_b32_e64 v5, v57, v61, s0                          ; d5010005 00027b39
	v_cndmask_b32_e64 v61, v61, v57, s0                         ; d501003d 0002733d
	v_cndmask_b32_e64 v6, v58, v62, s0                          ; d5010006 00027d3a
	v_cndmask_b32_e64 v62, v62, v58, s0                         ; d501003e 0002753e
	v_cndmask_b32_e64 v7, v59, v63, s0                          ; d5010007 00027f3b
	v_cndmask_b32_e64 v63, v63, v59, s0                         ; d501003f 0002773f
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v60, v60, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067808fa ff0cb13c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	v_add_f32_dpp v61, v61, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067a0afa ff0cb13d
	v_add_f32_dpp v62, v62, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067c0cfa ff0cb13e
	v_add_f32_dpp v63, v63, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067e0efa ff0cb13f
	v_cvt_f16_f32_e32 v10, v60                                  ; 7e14153c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_cvt_f16_f32_e32 v11, v61                                  ; 7e16153d
	v_cvt_f16_f32_e32 v8, v62                                   ; 7e10153e
	v_cndmask_b32_e64 v62, v62, v60, s2                         ; d501003e 000a793e
	v_cvt_f16_f32_e32 v9, v63                                   ; 7e12153f
	v_cndmask_b32_e64 v63, v63, v61, s2                         ; d501003f 000a7b3f
	v_cndmask_b32_e64 v12, v10, v8, s2                          ; d501000c 000a110a
	v_cvt_f16_f32_dpp v13, v62 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a14fa ff0d643e
	v_cndmask_b16 v12, v11, v9, s2                              ; d65d400c 000a130b
(invalid instruction)                                        ; 7f1a14fa
(invalid instruction)                                        ; ff0d643f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc0f000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[13:14]                ; 1a021b0c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB9                                          ; bfa1003a
BB7:
	s_load_b64 s[4:5], s[10:11], 0x44                           ; f4002105 f8000044
	s_ashr_i32 s0, s21, 1                                       ; 86008115
	s_ashr_i32 s2, s24, 1                                       ; 86028118
	v_bfe_u32 v4, v42, 1, 1                                     ; d6100004 0205032a
	v_bfe_u32 v5, v42, 3, 1                                     ; d6100005 0205072a
	s_and_b32 s6, s19, 1                                        ; 8b068113
	v_fma_mix_f32 v6, 0, v12, neg(0) op_sel_hi:[0,1,0]          ; cc200006 920218ff 3e800000
	v_fma_mix_f32 v12, 0, v12, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100c 920218ff 3e800000
	v_bfe_u32 v8, v42, 2, 1                                     ; d6100008 0205052a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s6, s6, 5                                        ; 84068506
	s_and_b32 s7, s20, 1                                        ; 8b078114
	v_lshl_add_u32 v5, v5, 2, v4                                ; d6460005 04110505
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v6, v12, vcc_lo                       ; 02021906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s7, s7, 7                                        ; 84078707
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v5, v5, 4, v32                               ; d6460005 04810905
	v_perm_b32 v10, v10, v7, 0x7060501                          ; d644000a 03fe0f0a 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s5                                        ; 96000500
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s2                                     ; 80000200
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v9, s0, 4, v1                                ; d6460009 04050800
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v9, v9, 8, s4                                ; d6460009 00111109
	v_add3_u32 v9, v9, s7, s6                                   ; d6550009 00180f09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v9, v9, v5                                 ; 4a120b09
	v_lshl_add_u32 v9, v0, 2, v9                                ; d6460009 04250500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v8, v8, 1, v9                                ; d6460008 04250308
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v7, v8, s[12:15], null offen                ; c406007c 40801807 00000008
	buffer_store_b8 v10, v8, s[12:15], null offen offset:1      ; c406007c 4080180a 00000108
BB9:
	s_or_not1_b32 s68, s47, s68                                 ; 9244442f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s0, src_scc, s49                                   ; 8c0031fd
	s_cbranch_scc1 BB12                                         ; bfa20008
BB10:
	v_add3_u32 v4, v40, s3, s29                                 ; d6550004 00740728
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v19, v4, v38                                 ; d6550004 049a0913
	buffer_store_b64 v[2:3], v4, s[12:15], null offen           ; c406c07c 40801802 00000004
BB12:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_ge_i32 s50, 0                                         ; bf038032
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s2, -1, 0                                     ; 980280c1
	s_cbranch_scc0 BB14                                         ; bfa1000a
BB13:
	s_load_b32 s4, s[10:11], 0x48                               ; f4000105 f8000048
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s4, s4, 1                                        ; 84048104
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s4                                        ; bf04041f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB15                                               ; bfa00002
BB14:
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB15:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	s_cbranch_scc0 BB17                                         ; bfa10009
BB16:
	s_load_b32 s4, s[10:11], 0x4c                               ; f4000105 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s4, s4, 1                                        ; 84048104
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s21, s4                                        ; bf040415
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB18                                               ; bfa00001
BB17:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB18:
	s_mov_b32 s4, 0xaaaaaaaa                                    ; be8400ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v64, v68, s4                          ; d5010004 00128940
	v_cndmask_b32_e64 v68, v68, v64, s4                         ; d5010044 00128144
	v_cndmask_b32_e64 v5, v65, v69, s4                          ; d5010005 00128b41
	v_cndmask_b32_e64 v69, v69, v65, s4                         ; d5010045 00128345
	v_cndmask_b32_e64 v6, v66, v70, s4                          ; d5010006 00128d42
	v_cndmask_b32_e64 v70, v70, v66, s4                         ; d5010046 00128546
	v_cndmask_b32_e64 v7, v67, v71, s4                          ; d5010007 00128f43
	v_cndmask_b32_e64 v71, v71, v67, s4                         ; d5010047 00128747
	s_mov_b32 s6, 0xf0f0f0f0                                    ; be8600ff f0f0f0f0
	v_add_f32_dpp v68, v68, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068808fa ff0cb144
	s_and_b32 s7, vcc_lo, exec_lo                               ; 8b077e6a
	v_add_f32_dpp v69, v69, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068a0afa ff0cb145
	v_add_f32_dpp v70, v70, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068c0cfa ff0cb146
	v_add_f32_dpp v71, v71, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068e0efa ff0cb147
	v_cvt_f16_f32_e32 v10, v68                                  ; 7e141544
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v11, v69                                  ; 7e161545
	v_cvt_f16_f32_e32 v8, v70                                   ; 7e101546
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v70, v70, v68, s6                         ; d5010046 001a8946
	v_cvt_f16_f32_e32 v9, v71                                   ; 7e121547
	v_cndmask_b32_e64 v71, v71, v69, s6                         ; d5010047 001a8b47
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v12, v10, v8, s6                          ; d501000c 001a110a
	v_cvt_f16_f32_dpp v13, v70 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a14fa ff0d6446
	v_cndmask_b16 v12, v11, v9, s6                              ; d65d400c 001a130b
(invalid instruction)                                        ; 7f1a14fa
(invalid instruction)                                        ; ff0d6447
(invalid instruction)                                        ; cc0f000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[13:14]                ; 1a021b0c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB21                                         ; bfa1003a
BB19:
	s_load_b64 s[6:7], s[10:11], 0x44                           ; f4002185 f8000044
	s_ashr_i32 s4, s21, 1                                       ; 86048115
	s_ashr_i32 s8, s31, 1                                       ; 8608811f
	v_bfe_u32 v4, v42, 1, 1                                     ; d6100004 0205032a
	v_bfe_u32 v5, v42, 3, 1                                     ; d6100005 0205072a
	s_and_b32 s9, s31, 1                                        ; 8b09811f
	v_fma_mix_f32 v6, 0, v12, neg(0) op_sel_hi:[0,1,0]          ; cc200006 920218ff 3e800000
	v_fma_mix_f32 v12, 0, v12, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100c 920218ff 3e800000
	v_bfe_u32 v8, v42, 2, 1                                     ; d6100008 0205052a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s9, s9, 5                                        ; 84098509
	s_and_b32 s16, s20, 1                                       ; 8b108114
	v_lshl_add_u32 v5, v5, 2, v4                                ; d6460005 04110505
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v6, v12, vcc_lo                       ; 02021906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s16, s16, 7                                      ; 84108710
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v5, v5, 4, v32                               ; d6460005 04810905
	v_perm_b32 v10, v10, v7, 0x7060501                          ; d644000a 03fe0f0a 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s4, s4, s7                                        ; 96040704
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s4, s8                                     ; 80040804
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v9, s4, 4, v1                                ; d6460009 04050804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v9, v9, 8, s6                                ; d6460009 00191109
	v_add3_u32 v9, v9, s16, s9                                  ; d6550009 00242109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v9, v9, v5                                 ; 4a120b09
	v_lshl_add_u32 v9, v0, 2, v9                                ; d6460009 04250500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v8, v8, 1, v9                                ; d6460008 04250308
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v7, v8, s[12:15], null offen                ; c406007c 40801807 00000008
	buffer_store_b8 v10, v8, s[12:15], null offen offset:1      ; c406007c 4080180a 00000108
BB21:
	s_or_not1_b32 s2, s52, s2                                   ; 92020234
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s49, src_scc, s49                                  ; 8c3131fd
	s_cbranch_scc1 BB24                                         ; bfa20008
BB22:
	v_add3_u32 v4, v40, s3, s28                                 ; d6550004 00700728
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v19, v4, v38                                 ; d6550004 049a0913
	buffer_store_b64 v[2:3], v4, s[12:15], null offen           ; c406c07c 40801802 00000004
BB24:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s2, src_scc                                       ; be8200fd
	s_cmp_ge_i32 s53, 0                                         ; bf038035
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s4, -1, 0                                     ; 980480c1
	s_cbranch_scc0 BB26                                         ; bfa1000a
BB25:
	s_load_b32 s6, s[10:11], 0x48                               ; f4000185 f8000048
	s_mov_b32 s7, src_scc                                       ; be8700fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s24, s6                                        ; bf040618
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB27                                               ; bfa00002
BB26:
	s_mov_b32 s7, src_scc                                       ; be8700fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB27:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	s_cbranch_scc0 BB29                                         ; bfa10009
BB28:
	s_load_b32 s6, s[10:11], 0x4c                               ; f4000185 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s6                                        ; bf04062a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB30                                               ; bfa00001
BB29:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB30:
	s_mov_b32 s6, 0xaaaaaaaa                                    ; be8600ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v88, v92, s6                          ; d5010004 001ab958
	v_cndmask_b32_e64 v92, v92, v88, s6                         ; d501005c 001ab15c
	v_cndmask_b32_e64 v5, v89, v93, s6                          ; d5010005 001abb59
	v_cndmask_b32_e64 v93, v93, v89, s6                         ; d501005d 001ab35d
	v_cndmask_b32_e64 v6, v90, v94, s6                          ; d5010006 001abd5a
	v_cndmask_b32_e64 v94, v94, v90, s6                         ; d501005e 001ab55e
	v_cndmask_b32_e64 v7, v91, v95, s6                          ; d5010007 001abf5b
	v_cndmask_b32_e64 v95, v95, v91, s6                         ; d501005f 001ab75f
	s_mov_b32 s8, 0xf0f0f0f0                                    ; be8800ff f0f0f0f0
	v_add_f32_dpp v92, v92, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06b808fa ff0cb15c
	s_and_b32 s9, vcc_lo, exec_lo                               ; 8b097e6a
	v_add_f32_dpp v93, v93, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ba0afa ff0cb15d
	v_add_f32_dpp v94, v94, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06bc0cfa ff0cb15e
	v_add_f32_dpp v95, v95, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06be0efa ff0cb15f
	v_cvt_f16_f32_e32 v10, v92                                  ; 7e14155c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v11, v93                                  ; 7e16155d
	v_cvt_f16_f32_e32 v8, v94                                   ; 7e10155e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v94, v94, v92, s8                         ; d501005e 0022b95e
	v_cvt_f16_f32_e32 v9, v95                                   ; 7e12155f
	v_cndmask_b32_e64 v95, v95, v93, s8                         ; d501005f 0022bb5f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v12, v10, v8, s8                          ; d501000c 0022110a
	v_cvt_f16_f32_dpp v13, v94 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a14fa ff0d645e
	v_cndmask_b16 v12, v11, v9, s8                              ; d65d400c 0022130b
(invalid instruction)                                        ; 7f1a14fa
(invalid instruction)                                        ; ff0d645f
(invalid instruction)                                        ; cc0f000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[13:14]                ; 1a021b0c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB33                                         ; bfa10039
BB31:
	s_load_b64 s[8:9], s[10:11], 0x44                           ; f4002205 f8000044
	s_ashr_i32 s6, s42, 1                                       ; 8606812a
	s_ashr_i32 s16, s24, 1                                      ; 86108118
	v_bfe_u32 v4, v42, 1, 1                                     ; d6100004 0205032a
	v_bfe_u32 v5, v42, 3, 1                                     ; d6100005 0205072a
	s_and_b32 s17, s19, 1                                       ; 8b118113
	v_fma_mix_f32 v6, 0, v12, neg(0) op_sel_hi:[0,1,0]          ; cc200006 920218ff 3e800000
	v_fma_mix_f32 v12, 0, v12, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100c 920218ff 3e800000
	v_bfe_u32 v8, v42, 2, 1                                     ; d6100008 0205052a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s17, s17, 5                                      ; 84118511
	s_and_b32 s18, s42, 1                                       ; 8b12812a
	v_lshl_add_u32 v5, v5, 2, v4                                ; d6460005 04110505
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v6, v12, vcc_lo                       ; 02021906
	s_lshl_b32 s18, s18, 7                                      ; 84128712
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v5, v5, 4, v32                               ; d6460005 04810905
	v_perm_b32 v10, v10, v7, 0x7060501                          ; d644000a 03fe0f0a 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s6, s6, s9                                        ; 96060906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s16                                    ; 80061006
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v9, s6, 4, v1                                ; d6460009 04050806
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v9, v9, 8, s8                                ; d6460009 00211109
	v_add3_u32 v9, v9, s18, s17                                 ; d6550009 00442509
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v9, v9, v5                                 ; 4a120b09
	v_lshl_add_u32 v9, v0, 2, v9                                ; d6460009 04250500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v8, v8, 1, v9                                ; d6460008 04250308
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v7, v8, s[12:15], null offen                ; c406007c 40801807 00000008
	buffer_store_b8 v10, v8, s[12:15], null offen offset:1      ; c406007c 4080180a 00000108
BB33:
	s_or_not1_b32 s47, s47, s4                                  ; 922f042f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s4, src_scc, s56                                   ; 8c0438fd
	s_cbranch_scc1 BB36                                         ; bfa20008
BB34:
	v_add3_u32 v4, v40, s3, s25                                 ; d6550004 00640728
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v19, v4, v38                                 ; d6550004 049a0913
	buffer_store_b64 v[2:3], v4, s[12:15], null offen           ; c406c07c 40801802 00000004
BB36:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s4, src_scc                                       ; be8400fd
	s_cmp_ge_i32 s57, 0                                         ; bf038039
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s6, -1, 0                                     ; 980680c1
	s_cbranch_scc0 BB38                                         ; bfa1000a
BB37:
	s_load_b32 s8, s[10:11], 0x48                               ; f4000205 f8000048
	s_mov_b32 s9, src_scc                                       ; be8900fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s8, s8, 1                                        ; 84088108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s8                                        ; bf04081f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB39                                               ; bfa00002
BB38:
	s_mov_b32 s9, src_scc                                       ; be8900fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB39:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s8, vcc_lo, exec_lo                               ; 8b087e6a
	s_cbranch_scc0 BB41                                         ; bfa10009
BB40:
	s_load_b32 s8, s[10:11], 0x4c                               ; f4000205 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s8, s8, 1                                        ; 84088108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s8                                        ; bf04082a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB42                                               ; bfa00001
BB41:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB42:
	s_mov_b32 s8, 0xaaaaaaaa                                    ; be8800ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v96, v100, s8                         ; d5010004 0022c960
	v_cndmask_b32_e64 v100, v100, v96, s8                       ; d5010064 0022c164
	v_cndmask_b32_e64 v5, v97, v101, s8                         ; d5010005 0022cb61
	v_cndmask_b32_e64 v101, v101, v97, s8                       ; d5010065 0022c365
	v_cndmask_b32_e64 v6, v98, v102, s8                         ; d5010006 0022cd62
	v_cndmask_b32_e64 v102, v102, v98, s8                       ; d5010066 0022c566
	v_cndmask_b32_e64 v7, v99, v103, s8                         ; d5010007 0022cf63
	v_cndmask_b32_e64 v103, v103, v99, s8                       ; d5010067 0022c767
	s_mov_b32 s16, 0xf0f0f0f0                                   ; be9000ff f0f0f0f0
	v_add_f32_dpp v100, v100, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06c808fa ff0cb164
	s_and_b32 s17, vcc_lo, exec_lo                              ; 8b117e6a
	v_add_f32_dpp v101, v101, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ca0afa ff0cb165
	v_add_f32_dpp v102, v102, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cc0cfa ff0cb166
	v_add_f32_dpp v103, v103, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ce0efa ff0cb167
	v_cvt_f16_f32_e32 v10, v100                                 ; 7e141564
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v11, v101                                 ; 7e161565
	v_cvt_f16_f32_e32 v8, v102                                  ; 7e101566
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v102, v102, v100, s16                     ; d5010066 0042c966
	v_cvt_f16_f32_e32 v9, v103                                  ; 7e121567
	v_cndmask_b32_e64 v103, v103, v101, s16                     ; d5010067 0042cb67
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v12, v10, v8, s16                         ; d501000c 0042110a
	v_cvt_f16_f32_dpp v13, v102 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a14fa ff0d6466
	v_cndmask_b16 v12, v11, v9, s16                             ; d65d400c 0042130b
(invalid instruction)                                        ; 7f1a14fa
(invalid instruction)                                        ; ff0d6467
(invalid instruction)                                        ; cc0f000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[13:14]                ; 1a021b0c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB45                                         ; bfa1003a
BB43:
	s_load_b64 s[16:17], s[10:11], 0x44                         ; f4002405 f8000044
	s_ashr_i32 s8, s42, 1                                       ; 8608812a
	s_ashr_i32 s18, s31, 1                                      ; 8612811f
	v_bfe_u32 v4, v42, 1, 1                                     ; d6100004 0205032a
	v_bfe_u32 v5, v42, 3, 1                                     ; d6100005 0205072a
	s_and_b32 s22, s31, 1                                       ; 8b16811f
	v_fma_mix_f32 v6, 0, v12, neg(0) op_sel_hi:[0,1,0]          ; cc200006 920218ff 3e800000
	v_fma_mix_f32 v12, 0, v12, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100c 920218ff 3e800000
	v_bfe_u32 v8, v42, 2, 1                                     ; d6100008 0205052a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s22, s22, 5                                      ; 84168516
	s_and_b32 s23, s42, 1                                       ; 8b17812a
	v_lshl_add_u32 v5, v5, 2, v4                                ; d6460005 04110505
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v6, v12, vcc_lo                       ; 02021906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s23, s23, 7                                      ; 84178717
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v5, v5, 4, v32                               ; d6460005 04810905
	v_perm_b32 v10, v10, v7, 0x7060501                          ; d644000a 03fe0f0a 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s8, s8, s17                                       ; 96081108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s8, s8, s18                                    ; 80081208
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v9, s8, 4, v1                                ; d6460009 04050808
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v9, v9, 8, s16                               ; d6460009 00411109
	v_add3_u32 v9, v9, s23, s22                                 ; d6550009 00582f09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v9, v9, v5                                 ; 4a120b09
	v_lshl_add_u32 v9, v0, 2, v9                                ; d6460009 04250500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v8, v8, 1, v9                                ; d6460008 04250308
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v7, v8, s[12:15], null offen                ; c406007c 40801807 00000008
	buffer_store_b8 v10, v8, s[12:15], null offen offset:1      ; c406007c 4080180a 00000108
BB45:
	s_or_not1_b32 s52, s52, s6                                  ; 92340634
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s56, src_scc, s56                                  ; 8c3838fd
	s_cbranch_scc1 BB48                                         ; bfa20008
BB46:
	v_add3_u32 v40, v40, s3, s43                                ; d6550028 00ac0728
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v40, v19, v40, v38                               ; d6550028 049a5113
	buffer_store_b64 v[2:3], v40, s[12:15], null offen          ; c406c07c 40801802 00000028
BB48:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s1, vcc_lo                                        ; be81006a
	s_cbranch_scc0 BB50                                         ; bfa10009
BB49:
	s_load_b32 s6, s[10:11], 0x48                               ; f4000185 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s24, s6                                        ; bf040618
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB51                                               ; bfa00001
BB50:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB51:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	s_cbranch_scc0 BB53                                         ; bfa10009
BB52:
	s_load_b32 s6, s[10:11], 0x4c                               ; f4000185 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s21, s6                                        ; bf040615
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB54                                               ; bfa00001
BB53:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB54:
	s_mov_b32 s6, 0xaaaaaaaa                                    ; be8600ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v104, v108, s6                        ; d5010004 001ad968
	v_cndmask_b32_e64 v108, v108, v104, s6                      ; d501006c 001ad16c
	v_cndmask_b32_e64 v5, v105, v109, s6                        ; d5010005 001adb69
	v_cndmask_b32_e64 v109, v109, v105, s6                      ; d501006d 001ad36d
	v_cndmask_b32_e64 v6, v106, v110, s6                        ; d5010006 001add6a
	v_cndmask_b32_e64 v110, v110, v106, s6                      ; d501006e 001ad56e
	v_cndmask_b32_e64 v7, v107, v111, s6                        ; d5010007 001adf6b
	v_cndmask_b32_e64 v111, v111, v107, s6                      ; d501006f 001ad76f
	s_mov_b32 s8, 0xf0f0f0f0                                    ; be8800ff f0f0f0f0
	v_add_f32_dpp v108, v108, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06d808fa ff0cb16c
	s_and_b32 s16, vcc_lo, exec_lo                              ; 8b107e6a
	v_add_f32_dpp v109, v109, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06da0afa ff0cb16d
	v_add_f32_dpp v110, v110, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06dc0cfa ff0cb16e
	v_add_f32_dpp v111, v111, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06de0efa ff0cb16f
	v_cvt_f16_f32_e32 v10, v108                                 ; 7e14156c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v11, v109                                 ; 7e16156d
	v_cvt_f16_f32_e32 v8, v110                                  ; 7e10156e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v110, v110, v108, s8                      ; d501006e 0022d96e
	v_cvt_f16_f32_e32 v9, v111                                  ; 7e12156f
	v_cndmask_b32_e64 v111, v111, v109, s8                      ; d501006f 0022db6f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v12, v10, v8, s8                          ; d501000c 0022110a
	v_cvt_f16_f32_dpp v13, v110 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a14fa ff0d646e
	v_cndmask_b16 v12, v11, v9, s8                              ; d65d400c 0022130b
(invalid instruction)                                        ; 7f1a14fa
(invalid instruction)                                        ; ff0d646f
(invalid instruction)                                        ; cc0f000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[13:14]                ; 1a021b0c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB57                                         ; bfa1003c
BB55:
	s_load_b64 s[16:17], s[10:11], 0x44                         ; f4002405 f8000044
	s_ashr_i32 s6, s21, 1                                       ; 86068115
	s_ashr_i32 s8, s24, 1                                       ; 86088118
	v_bfe_u32 v4, v42, 1, 1                                     ; d6100004 0205032a
	v_bfe_u32 v5, v42, 3, 1                                     ; d6100005 0205072a
	s_and_b32 s18, s19, 1                                       ; 8b128113
	v_fma_mix_f32 v6, 0, v12, neg(0) op_sel_hi:[0,1,0]          ; cc200006 920218ff 3e800000
	v_fma_mix_f32 v12, 0, v12, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100c 920218ff 3e800000
	v_bfe_u32 v8, v42, 2, 1                                     ; d6100008 0205052a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s18, s18, 5                                      ; 84128512
	s_and_b32 s22, s20, 1                                       ; 8b168114
	v_lshl_add_u32 v5, v5, 2, v4                                ; d6460005 04110505
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v6, v12, vcc_lo                       ; 02021906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s22, s22, 7                                      ; 84168716
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s22, s22, s18                                  ; 80161216
	v_lshl_add_u32 v5, v5, 4, v32                               ; d6460005 04810905
	v_perm_b32 v10, v10, v7, 0x7060501                          ; d644000a 03fe0f0a 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s6, s6, s17                                       ; 96061106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s8                                     ; 80060806
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v9, s6, 4, v1                                ; d6460009 04050806
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v9, v9, 8, 0x100                             ; d6460009 03fd1109 00000100
	v_add3_u32 v9, s22, s16, v9                                 ; d6550009 04242016
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v9, v9, v5                                 ; 4a120b09
	v_lshl_add_u32 v9, v0, 2, v9                                ; d6460009 04250500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v8, v8, 1, v9                                ; d6460008 04250308
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v7, v8, s[12:15], null offen                ; c406007c 40801807 00000008
	buffer_store_b8 v10, v8, s[12:15], null offen offset:1      ; c406007c 4080180a 00000108
BB57:
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB60                                         ; bfa20008
BB58:
	v_add3_u32 v4, v34, s3, s29                                 ; d6550004 00740722
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v19, v4, v38                                 ; d6550004 049a0913
	buffer_store_b64 v[2:3], v4, s[12:15], null offen           ; c406c07c 40801802 00000004
BB60:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s5, 0                                          ; bf018005
	s_cbranch_scc0 BB62                                         ; bfa10009
BB61:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s0                                        ; bf04001f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB63                                               ; bfa00001
BB62:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB63:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB65                                         ; bfa10009
BB64:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s21, s0                                        ; bf040015
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB66                                               ; bfa00001
BB65:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB66:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v112, v116, s0                        ; d5010004 0002e970
	v_cndmask_b32_e64 v116, v116, v112, s0                      ; d5010074 0002e174
	v_cndmask_b32_e64 v5, v113, v117, s0                        ; d5010005 0002eb71
	v_cndmask_b32_e64 v117, v117, v113, s0                      ; d5010075 0002e375
	v_cndmask_b32_e64 v6, v114, v118, s0                        ; d5010006 0002ed72
	v_cndmask_b32_e64 v118, v118, v114, s0                      ; d5010076 0002e576
	v_cndmask_b32_e64 v7, v115, v119, s0                        ; d5010007 0002ef73
	v_cndmask_b32_e64 v119, v119, v115, s0                      ; d5010077 0002e777
	s_mov_b32 s5, 0xf0f0f0f0                                    ; be8500ff f0f0f0f0
	v_add_f32_dpp v116, v116, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06e808fa ff0cb174
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	v_add_f32_dpp v117, v117, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ea0afa ff0cb175
	v_add_f32_dpp v118, v118, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ec0cfa ff0cb176
	v_add_f32_dpp v119, v119, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ee0efa ff0cb177
	v_cvt_f16_f32_e32 v10, v116                                 ; 7e141574
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v11, v117                                 ; 7e161575
	v_cvt_f16_f32_e32 v8, v118                                  ; 7e101576
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v118, v118, v116, s5                      ; d5010076 0016e976
	v_cvt_f16_f32_e32 v9, v119                                  ; 7e121577
	v_cndmask_b32_e64 v119, v119, v117, s5                      ; d5010077 0016eb77
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v12, v10, v8, s5                          ; d501000c 0016110a
	v_cvt_f16_f32_dpp v13, v118 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a14fa ff0d6476
	v_cndmask_b16 v12, v11, v9, s5                              ; d65d400c 0016130b
(invalid instruction)                                        ; 7f1a14fa
(invalid instruction)                                        ; ff0d6477
(invalid instruction)                                        ; cc0f000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[13:14]                ; 1a021b0c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB69                                         ; bfa1003a
BB67:
	s_load_b64 s[16:17], s[10:11], 0x44                         ; f4002405 f8000044
	s_ashr_i32 s21, s21, 1                                      ; 86158115
	s_ashr_i32 s0, s31, 1                                       ; 8600811f
	v_bfe_u32 v4, v42, 1, 1                                     ; d6100004 0205032a
	v_bfe_u32 v5, v42, 3, 1                                     ; d6100005 0205072a
	s_and_b32 s5, s31, 1                                        ; 8b05811f
	v_fma_mix_f32 v6, 0, v12, neg(0) op_sel_hi:[0,1,0]          ; cc200006 920218ff 3e800000
	v_fma_mix_f32 v12, 0, v12, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100c 920218ff 3e800000
	v_bfe_u32 v8, v42, 2, 1                                     ; d6100008 0205052a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s5, s5, 5                                        ; 84058505
	s_and_b32 s20, s20, 1                                       ; 8b148114
	v_lshl_add_u32 v5, v5, 2, v4                                ; d6460005 04110505
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v6, v12, vcc_lo                       ; 02021906
	s_lshl_b32 s20, s20, 7                                      ; 84148714
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s20, s20, s5                                   ; 80140514
	v_lshl_add_u32 v5, v5, 4, v32                               ; d6460005 04810905
	v_perm_b32 v10, v10, v7, 0x7060501                          ; d644000a 03fe0f0a 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s21, s21, s17                                     ; 96151115
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s21, s21, s0                                   ; 80150015
	v_lshl_add_u32 v9, s21, 4, v1                               ; d6460009 04050815
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v9, v9, 8, 0x100                             ; d6460009 03fd1109 00000100
	v_add3_u32 v9, s20, s16, v9                                 ; d6550009 04242014
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v9, v9, v5                                 ; 4a120b09
	v_lshl_add_u32 v9, v0, 2, v9                                ; d6460009 04250500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v8, v8, 1, v9                                ; d6460008 04250308
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v7, v8, s[12:15], null offen                ; c406007c 40801807 00000008
	buffer_store_b8 v10, v8, s[12:15], null offen offset:1      ; c406007c 4080180a 00000108
BB69:
	s_cmp_lg_i32 s2, 0                                          ; bf018002
	s_cbranch_scc1 BB72                                         ; bfa20008
BB70:
	v_add3_u32 v4, v34, s3, s28                                 ; d6550004 00700722
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v19, v4, v38                                 ; d6550004 049a0913
	buffer_store_b64 v[2:3], v4, s[12:15], null offen           ; c406c07c 40801802 00000004
BB72:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s7, 0                                          ; bf018007
	s_cbranch_scc0 BB74                                         ; bfa10009
BB73:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s24, s0                                        ; bf040018
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB75                                               ; bfa00001
BB74:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB75:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB77                                         ; bfa10009
BB76:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s0                                        ; bf04002a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB78                                               ; bfa00001
BB77:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB78:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v136, v140, s0                        ; d5010004 00031988
	v_cndmask_b32_e64 v140, v140, v136, s0                      ; d501008c 0003118c
	v_cndmask_b32_e64 v5, v137, v141, s0                        ; d5010005 00031b89
	v_cndmask_b32_e64 v141, v141, v137, s0                      ; d501008d 0003138d
	v_cndmask_b32_e64 v6, v138, v142, s0                        ; d5010006 00031d8a
	v_cndmask_b32_e64 v142, v142, v138, s0                      ; d501008e 0003158e
	v_cndmask_b32_e64 v7, v139, v143, s0                        ; d5010007 00031f8b
	v_cndmask_b32_e64 v143, v143, v139, s0                      ; d501008f 0003178f
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v140, v140, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 071808fa ff0cb18c
	s_and_b32 s5, vcc_lo, exec_lo                               ; 8b057e6a
	v_add_f32_dpp v141, v141, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 071a0afa ff0cb18d
	v_add_f32_dpp v142, v142, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 071c0cfa ff0cb18e
	v_add_f32_dpp v143, v143, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 071e0efa ff0cb18f
	v_cvt_f16_f32_e32 v10, v140                                 ; 7e14158c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v11, v141                                 ; 7e16158d
	v_cvt_f16_f32_e32 v8, v142                                  ; 7e10158e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v142, v142, v140, s2                      ; d501008e 000b198e
	v_cvt_f16_f32_e32 v9, v143                                  ; 7e12158f
	v_cndmask_b32_e64 v143, v143, v141, s2                      ; d501008f 000b1b8f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v12, v10, v8, s2                          ; d501000c 000a110a
	v_cvt_f16_f32_dpp v13, v142 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a14fa ff0d648e
	v_cndmask_b16 v12, v11, v9, s2                              ; d65d400c 000a130b
(invalid instruction)                                        ; 7f1a14fa
(invalid instruction)                                        ; ff0d648f
(invalid instruction)                                        ; cc0f000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[13:14]                ; 1a021b0c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB81                                         ; bfa1003c
BB79:
	s_load_b64 s[6:7], s[10:11], 0x44                           ; f4002185 f8000044
	s_ashr_i32 s0, s42, 1                                       ; 8600812a
	s_ashr_i32 s24, s24, 1                                      ; 86188118
	v_bfe_u32 v4, v42, 1, 1                                     ; d6100004 0205032a
	v_bfe_u32 v5, v42, 3, 1                                     ; d6100005 0205072a
	s_and_b32 s19, s19, 1                                       ; 8b138113
	v_fma_mix_f32 v6, 0, v12, neg(0) op_sel_hi:[0,1,0]          ; cc200006 920218ff 3e800000
	v_fma_mix_f32 v12, 0, v12, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100c 920218ff 3e800000
	v_bfe_u32 v8, v42, 2, 1                                     ; d6100008 0205052a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s19, s19, 5                                      ; 84138513
	s_and_b32 s2, s42, 1                                        ; 8b02812a
	v_lshl_add_u32 v5, v5, 2, v4                                ; d6460005 04110505
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v6, v12, vcc_lo                       ; 02021906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s2, s2, 7                                        ; 84028702
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s2, s2, s19                                    ; 80021302
	v_lshl_add_u32 v5, v5, 4, v32                               ; d6460005 04810905
	v_perm_b32 v10, v10, v7, 0x7060501                          ; d644000a 03fe0f0a 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s7                                        ; 96000700
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s24                                    ; 80001800
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v9, s0, 4, v1                                ; d6460009 04050800
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v9, v9, 8, 0x100                             ; d6460009 03fd1109 00000100
	v_add3_u32 v9, s2, s6, v9                                   ; d6550009 04240c02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v9, v9, v5                                 ; 4a120b09
	v_lshl_add_u32 v9, v0, 2, v9                                ; d6460009 04250500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v8, v8, 1, v9                                ; d6460008 04250308
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v7, v8, s[12:15], null offen                ; c406007c 40801807 00000008
	buffer_store_b8 v10, v8, s[12:15], null offen offset:1      ; c406007c 4080180a 00000108
BB81:
	s_cmp_lg_i32 s4, 0                                          ; bf018004
	s_cbranch_scc1 BB84                                         ; bfa20008
BB82:
	v_add3_u32 v4, v34, s3, s25                                 ; d6550004 00640722
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v19, v4, v38                                 ; d6550004 049a0913
	buffer_store_b64 v[2:3], v4, s[12:15], null offen           ; c406c07c 40801802 00000004
BB84:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s9, 0                                          ; bf018009
	s_cbranch_scc0 BB86                                         ; bfa10009
BB85:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s0                                        ; bf04001f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB87                                               ; bfa00001
BB86:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB87:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB89                                         ; bfa10009
BB88:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s0                                        ; bf04002a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB90                                               ; bfa00001
BB89:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB90:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v152, v156, s0                        ; d5010004 00033998
	v_cndmask_b32_e64 v156, v156, v152, s0                      ; d501009c 0003319c
	v_cndmask_b32_e64 v5, v153, v157, s0                        ; d5010005 00033b99
	v_cndmask_b32_e64 v157, v157, v153, s0                      ; d501009d 0003339d
	v_cndmask_b32_e64 v6, v154, v158, s0                        ; d5010006 00033d9a
	v_cndmask_b32_e64 v158, v158, v154, s0                      ; d501009e 0003359e
	v_cndmask_b32_e64 v7, v155, v159, s0                        ; d5010007 00033f9b
	v_cndmask_b32_e64 v159, v159, v155, s0                      ; d501009f 0003379f
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v156, v156, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 073808fa ff0cb19c
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	v_add_f32_dpp v157, v157, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 073a0afa ff0cb19d
	v_add_f32_dpp v158, v158, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 073c0cfa ff0cb19e
	v_add_f32_dpp v159, v159, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 073e0efa ff0cb19f
	v_cvt_f16_f32_e32 v10, v156                                 ; 7e14159c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v11, v157                                 ; 7e16159d
	v_cvt_f16_f32_e32 v8, v158                                  ; 7e10159e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v158, v158, v156, s2                      ; d501009e 000b399e
	v_cvt_f16_f32_e32 v9, v159                                  ; 7e12159f
	v_cndmask_b32_e64 v159, v159, v157, s2                      ; d501009f 000b3b9f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v12, v10, v8, s2                          ; d501000c 000a110a
	v_cvt_f16_f32_dpp v13, v158 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a14fa ff0d649e
	v_cndmask_b16 v12, v11, v9, s2                              ; d65d400c 000a130b
(invalid instruction)                                        ; 7f1a14fa
(invalid instruction)                                        ; ff0d649f
(invalid instruction)                                        ; cc0f000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[13:14]                ; 1a021b0c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB93                                         ; bfa1003c
BB91:
	s_load_b64 s[4:5], s[10:11], 0x44                           ; f4002105 f8000044
	s_ashr_i32 s0, s42, 1                                       ; 8600812a
	s_ashr_i32 s2, s31, 1                                       ; 8602811f
	v_bfe_u32 v4, v42, 1, 1                                     ; d6100004 0205032a
	v_bfe_u32 v5, v42, 3, 1                                     ; d6100005 0205072a
	s_and_b32 s31, s31, 1                                       ; 8b1f811f
	v_fma_mix_f32 v6, 0, v12, neg(0) op_sel_hi:[0,1,0]          ; cc200006 920218ff 3e800000
	v_fma_mix_f32 v12, 0, v12, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100c 920218ff 3e800000
	v_bfe_u32 v42, v42, 2, 1                                    ; d610002a 0205052a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s31, s31, 5                                      ; 841f851f
	s_and_b32 s42, s42, 1                                       ; 8b2a812a
	v_lshl_add_u32 v5, v5, 2, v4                                ; d6460005 04110505
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v6, v12, vcc_lo                       ; 02021906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s42, s42, 7                                      ; 842a872a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s42, s42, s31                                  ; 802a1f2a
	v_lshl_add_u32 v5, v5, 4, v32                               ; d6460005 04810905
	v_perm_b32 v8, v8, v7, 0x7060501                            ; d6440008 03fe0f08 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s5                                        ; 96000500
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s2                                     ; 80000200
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v1, s0, 4, v1                                ; d6460001 04050800
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v1, v1, 8, 0x100                             ; d6460001 03fd1101 00000100
	v_add3_u32 v1, s42, s4, v1                                  ; d6550001 0404082a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v1, v1, v5                                 ; 4a020b01
	v_lshl_add_u32 v0, v0, 2, v1                                ; d6460000 04050500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v42, v42, 1, v0                              ; d646002a 0401032a
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v7, v42, s[12:15], null offen               ; c406007c 40801807 0000002a
	buffer_store_b8 v8, v42, s[12:15], null offen offset:1      ; c406007c 40801808 0000012a
BB93:
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc1 BB96                                         ; bfa20008
BB94:
	v_add3_u32 v34, v34, s3, s43                                ; d6550022 00ac0722
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v19, v19, v34, v38                               ; d6550013 049a4513
	buffer_store_b64 v[2:3], v19, s[12:15], null offen          ; c406c07c 40801802 00000013
BB96:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
