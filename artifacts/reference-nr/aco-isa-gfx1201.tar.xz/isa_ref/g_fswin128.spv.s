BB0:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s16, s1                                           ; be900001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	s_load_b256 s[32:39], s[0:1], 0x30                          ; f4006800 f8000030
	s_lshl1_add_u32 s14, ttmp9, s14                             ; 870e0e75
	s_pack_ll_b32_b16 s17, ttmp7, 0                             ; 99118073
(invalid instruction)                                        ; d71f0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_lshrrev_b32_e32 v1, 5, v0                                 ; 32020085
	s_lshl1_add_u32 s17, s17, s15                               ; 87110f11
	s_max_i32 s18, s14, 0                                       ; 8a12800e
	s_add_co_u32 s19, s12, -1                                   ; 8013c10c
	v_and_b32_e32 v4, 15, v3                                    ; 3608068f
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_lshlrev_b32_e32 v2, 9, v1                                 ; 30040289
	s_min_i32 s18, s18, s19                                     ; 89121312
	s_max_i32 s24, s17, 0                                       ; 8a188011
	s_add_co_u32 s25, s13, -1                                   ; 8019c10d
	v_lshlrev_b32_e32 v5, 4, v4                                 ; 300a0884
	v_lshlrev_b32_e32 v3, 3, v3                                 ; 30060683
	v_add_nc_u32_e32 v7, 0x100, v2                              ; 4a0e04ff 00000100
	s_min_i32 s24, s24, s25                                     ; 89181918
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s24, s24, s12                                     ; 96180c18
	s_add_co_u32 s26, s24, s18                                  ; 801a1218
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s26, s26, 11                                     ; 841a8b1a
	s_add_co_u32 s27, s16, s26                                  ; 801b1a10
	s_add_co_u32 s28, s14, 1                                    ; 801c810e
	v_add3_u32 v6, v5, s27, v2                                  ; d6550006 04083705
	v_add3_u32 v8, v5, s27, v7                                  ; d6550008 041c3705
	s_max_i32 s29, s28, 0                                       ; 8a1d801c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_min_i32 s29, s29, s19                                     ; 891d131d
	v_add_nc_u32_e32 v6, v6, v3                                 ; 4a0c0706
	v_add_nc_u32_e32 v8, v8, v3                                 ; 4a100708
	s_add_co_u32 s24, s24, s29                                  ; 80181d18
	s_lshl_b32 s24, s24, 11                                     ; 84188b18
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s30, s16, s24                                  ; 801e1810
	s_add_co_u32 s31, s17, 1                                    ; 801f8111
	v_add3_u32 v9, v5, s30, v2                                  ; d6550009 04083d05
	v_add3_u32 v10, v5, s30, v7                                 ; d655000a 041c3d05
	s_max_i32 s40, s31, 0                                       ; 8a28801f
	s_min_i32 s40, s40, s25                                     ; 89281928
	v_add_nc_u32_e32 v9, v9, v3                                 ; 4a120709
	v_add_nc_u32_e32 v10, v10, v3                               ; 4a14070a
	s_mul_i32 s40, s40, s12                                     ; 96280c28
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s18, s40, s18                                  ; 80121228
	s_lshl_b32 s18, s18, 11                                     ; 84128b12
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s41, s16, s18                                  ; 80291210
	s_add_co_u32 s40, s40, s29                                  ; 80281d28
	v_add3_u32 v11, v5, s41, v2                                 ; d655000b 04085305
	v_add3_u32 v12, v5, s41, v7                                 ; d655000c 041c5305
	s_lshl_b32 s40, s40, 11                                     ; 84288b28
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s16, s40                                  ; 80102810
	v_add_nc_u32_e32 v11, v11, v3                               ; 4a16070b
	v_add_nc_u32_e32 v12, v12, v3                               ; 4a18070c
	v_add3_u32 v14, v5, s16, v7                                 ; d655000e 041c2105
	v_add3_u32 v13, v5, s16, v2                                 ; d655000d 04082105
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v3                               ; 4a1c070e
	v_add_nc_u32_e32 v13, v13, v3                               ; 4a1a070d
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[16:17], v6, s[20:23], null offen          ; c405407c 40802810 00000006
	buffer_load_b64 v[18:19], v8, s[20:23], null offen          ; c405407c 40802812 00000008
	buffer_load_b64 v[8:9], v9, s[20:23], null offen            ; c405407c 40802808 00000009
	buffer_load_b64 v[20:21], v10, s[20:23], null offen         ; c405407c 40802814 0000000a
	buffer_load_b64 v[10:11], v11, s[20:23], null offen         ; c405407c 4080280a 0000000b
	buffer_load_b64 v[22:23], v12, s[20:23], null offen         ; c405407c 40802816 0000000c
	buffer_load_b64 v[12:13], v13, s[20:23], null offen         ; c405407c 4080280c 0000000d
	buffer_load_b64 v[14:15], v14, s[20:23], null offen         ; c405407c 4080280e 0000000e
	v_lshlrev_b32_e32 v24, 3, v1                                ; 30300283
	v_and_b32_e32 v27, 31, v0                                   ; 3636009f
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_add_nc_u32_e32 v29, 2, v24                                ; 4a3a3082
	v_med3_i32 v26, -1, v24, 1                                  ; d620001a 020630c1
	v_sub_nc_u32_e32 v25, 0, v24                                ; 4c323080
	v_lshlrev_b32_e32 v28, 2, v27                               ; 30383682
	v_sub_nc_u32_e32 v30, 0, v29                                ; 4c3c3a80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_max_i32_e32 v25, v24, v25                                 ; 24323318
	v_max_i32_e32 v30, v29, v30                                 ; 243c3d1d
	v_med3_i32 v29, -1, v29, 1                                  ; d620001d 02063ac1
	v_lshrrev_b32_e32 v25, 1, v25                               ; 32323281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_lshrrev_b32_e32 v30, 1, v30                               ; 323c3c81
(invalid instruction)                                        ; d72c001a
	v_cndmask_b32_e32 v1, v26, v25, vcc_lo                      ; 0202331a
(invalid instruction)                                        ; d72c001d
	v_cndmask_b32_e32 v1, v29, v30, vcc_lo                      ; 02023d1d
	v_lshl_add_u32 v26, v26, 10, s3                             ; d646001a 000d151a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshl_add_u32 v29, v29, 10, s3                             ; d646001d 000d151d
	v_add_lshl_u32 v26, v26, v28, 2                             ; d647001a 020a391a
	v_add_lshl_u32 v29, v29, v28, 2                             ; d647001d 020a391d
	s_clause 0xa                                                ; bf85000a
	buffer_load_b128 v[32:35], v26, s[36:39], null offen        ; c405c07c 40804820 0000001a
	buffer_load_b128 v[36:39], v29, s[36:39], null offen        ; c405c07c 40804824 0000001d
	buffer_load_b128 v[40:43], v26, s[36:39], null offen offset:512 ; c405c07c 40804828 0002001a
	buffer_load_b128 v[44:47], v29, s[36:39], null offen offset:512 ; c405c07c 4080482c 0002001d
	buffer_load_b128 v[48:51], v26, s[36:39], null offen offset:1024 ; c405c07c 40804830 0004001a
	buffer_load_b128 v[52:55], v29, s[36:39], null offen offset:1024 ; c405c07c 40804834 0004001d
	buffer_load_b128 v[56:59], v26, s[36:39], null offen offset:1536 ; c405c07c 40804838 0006001a
	buffer_load_b128 v[60:63], v29, s[36:39], null offen offset:1536 ; c405c07c 4080483c 0006001d
	buffer_load_b128 v[64:67], v26, s[36:39], null offen offset:2048 ; c405c07c 40804840 0008001a
	buffer_load_b128 v[68:71], v29, s[36:39], null offen offset:2048 ; c405c07c 40804844 0008001d
	buffer_load_b128 v[72:75], v26, s[36:39], null offen offset:2560 ; c405c07c 40804848 000a001a
	v_add_nc_u32_e32 v31, v5, v3                                ; 4a3e0705
	s_min_i32 s42, s14, s17                                     ; 892a110e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_cmp_lt_i32 s42, 0                                         ; bf04802a
	v_add_nc_u32_e32 v76, v2, v31                               ; 4a983f02
	s_cselect_b32 s43, -1, 0                                    ; 982b80c1
	s_cmp_ge_i32 s14, s12                                       ; bf030c0e
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s44, -1, 0                                    ; 982c80c1
	v_add_nc_u32_e32 v79, 0x1800, v76                           ; 4a9e98ff 00001800
	v_add_nc_u32_e32 v77, 0x800, v76                            ; 4a9a98ff 00000800
	v_add_nc_u32_e32 v78, 0x1000, v76                           ; 4a9c98ff 00001000
	s_or_b32 s43, s43, s44                                      ; 8c2b2c2b
	s_cmp_ge_i32 s17, s13                                       ; bf030d11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s45, -1, 0                                    ; 982d80c1
	s_or_b32 s43, s43, s45                                      ; 8c2b2d2b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mov_b32 s46, src_scc                                      ; beae00fd
	s_min_i32 s17, s28, s17                                     ; 8911111c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s17, 0                                         ; bf048011
	s_cselect_b32 s47, -1, 0                                    ; 982f80c1
	s_cmp_ge_i32 s28, s12                                       ; bf030c1c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s48, -1, 0                                    ; 983080c1
	s_or_b32 s47, s47, s48                                      ; 8c2f302f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s47, s47, s45                                      ; 8c2f2d2f
	s_pack_hh_b32_b16 s55, ttmp7, 0                             ; 9a378073
	s_mov_b32 s49, src_scc                                      ; beb100fd
	s_min_i32 s14, s14, s31                                     ; 890e1f0e
	s_movk_i32 s56, 0x400                                       ; b0380400
	v_lshl_add_u32 v80, s55, 4, v31                             ; d6460050 047d0837
	s_cmp_lt_i32 s14, 0                                         ; bf04800e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s50, -1, 0                                    ; 983280c1
	s_or_b32 s50, s50, s44                                      ; 8c322c32
	s_cmp_ge_i32 s31, s13                                       ; bf030d1f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s51, -1, 0                                    ; 983380c1
	s_or_b32 s50, s50, s51                                      ; 8c323332
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_mov_b32 s52, src_scc                                      ; beb400fd
	s_min_i32 s28, s28, s31                                     ; 891c1f1c
	s_cmp_lt_i32 s28, 0                                         ; bf04801c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s53, -1, 0                                    ; 983580c1
	s_or_b32 s53, s53, s48                                      ; 8c353035
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s53, s53, s51                                      ; 8c353335
	s_mov_b32 s54, src_scc                                      ; beb600fd
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v82, v16, 0, s43                          ; d5010052 00ad0110
	v_cndmask_b32_e64 v83, v17, 0, s43                          ; d5010053 00ad0111
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_cndmask_b32_e64 v17, v19, 0, s43                          ; d5010011 00ad0113
	v_cndmask_b32_e64 v16, v18, 0, s43                          ; d5010010 00ad0112
	ds_store_2addr_b64 v76, v[82:83], v[16:17] offset1:32       ; d9382000 0010524c
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_cndmask_b32_e64 v17, v9, 0, s47                           ; d5010011 00bd0109
	v_cndmask_b32_e64 v16, v8, 0, s47                           ; d5010010 00bd0108
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_cndmask_b32_e64 v8, v20, 0, s47                           ; d5010008 00bd0114
	v_cndmask_b32_e64 v9, v21, 0, s47                           ; d5010009 00bd0115
	ds_store_2addr_b64 v77, v[16:17], v[8:9] offset1:32         ; d9382000 0008104d
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_cndmask_b32_e64 v8, v10, 0, s50                           ; d5010008 00c9010a
	v_cndmask_b32_e64 v9, v11, 0, s50                           ; d5010009 00c9010b
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_cndmask_b32_e64 v10, v22, 0, s50                          ; d501000a 00c90116
	v_cndmask_b32_e64 v11, v23, 0, s50                          ; d501000b 00c90117
	ds_store_2addr_b64 v78, v[8:9], v[10:11] offset1:32         ; d9382000 000a084e
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_cndmask_b32_e64 v8, v12, 0, s53                           ; d5010008 00d5010c
	v_cndmask_b32_e64 v9, v13, 0, s53                           ; d5010009 00d5010d
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_cndmask_b32_e64 v11, v15, 0, s53                          ; d501000b 00d5010f
	v_cndmask_b32_e64 v10, v14, 0, s53                          ; d501000a 00d5010e
	ds_store_2addr_b64 v79, v[8:9], v[10:11] offset1:32         ; d9382000 000a084f
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[8:9], v80                                     ; d9d80000 08000050
	ds_load_b64 v[10:11], v80 offset:2048                       ; d9d80800 0a000050
	ds_load_b64 v[12:13], v80 offset:4096                       ; d9d81000 0c000050
	ds_load_b64 v[14:15], v80 offset:6144                       ; d9d81800 0e000050
	ds_load_b64 v[16:17], v80 offset:256                        ; d9d80100 10000050
	ds_load_b64 v[18:19], v80 offset:2304                       ; d9d80900 12000050
	ds_load_b64 v[20:21], v80 offset:4352                       ; d9d81100 14000050
	ds_load_b64 v[22:23], v80 offset:6400                       ; d9d81900 16000050
	ds_load_b64 v[82:83], v80 offset:512                        ; d9d80200 52000050
	v_mov_b32_e32 v81, v7                                       ; 7ea20307
	v_mov_b32_e32 v25, v28                                      ; 7e32031c
	v_dual_mov_b32 v85, v31 :: v_dual_mov_b32 v84, v29          ; ca10011f 5554011d
	s_wait_loadcnt_dscnt 0xa08                                  ; bfc80a08
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[8:9], 0  ; cc464060 1a021122
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[8:9], 0   ; cc464058 1a021120
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[10:11], 0 ; cc464080 1a021522
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[10:11], 0 ; cc464078 1a021520
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[12:13], 0 ; cc464098 1a021920
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[34:35], v[12:13], 0 ; cc4640a0 1a021922
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[12:13], 0 ; cc4640b0 1a021926
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[36:37], v[10:11], 0 ; cc464088 1a021524
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[32:33], v[14:15], 0 ; cc4640b8 1a021d20
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[8:9], 0 ; cc464070 1a021126
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[8:9], 0 ; cc464068 1a021124
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[10:11], 0 ; cc464090 1a021526
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[36:37], v[12:13], 0 ; cc4640a8 1a021924
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[34:35], v[14:15], 0  ; cc464006 1a021d22
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[36:37], v[14:15], 0 ; cc46401c 1a021d24
	v_dual_mov_b32 v37, v15 :: v_dual_mov_b32 v36, v14          ; ca10010f 2524010e
	s_wait_loadcnt_dscnt 0x804                                  ; bfc80804
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[16:17], v[96:103] ; cc464060 1d82212a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[16:17], v[88:95] ; cc464058 1d622128
	s_wait_dscnt 0x3                                            ; bfc60003
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[18:19], v[120:127] ; cc464078 1de22528
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[18:19], v[128:135] ; cc464080 1e02252a
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[20:21], v[152:159] ; cc464098 1e622928
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[44:45], v[18:19], v[136:143] ; cc464088 1e22252c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[42:43], v[20:21], v[160:167] ; cc4640a0 1e82292a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[16:17], v[112:119] ; cc464070 1dc2212e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[20:21], v[176:183] ; cc4640b0 1ec2292e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[16:17], v[104:111] ; cc464068 1da2212c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[18:19], v[144:151] ; cc464090 1e42252e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[20:21], v[168:175] ; cc4640a8 1ea2292c
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[38:39], v[36:37], 0 ; cc46400e 1a024926
	s_wait_loadcnt_dscnt 0x600                                  ; bfc80600
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[82:83], v[96:103] ; cc464060 1d82a532
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[40:41], v[22:23], v[184:191] ; cc4640b8 1ee22d28
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[82:83], v[88:95] ; cc464058 1d62a530
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[42:43], v[22:23], v[6:13] ; cc464006 1c1a2d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[44:45], v[22:23], v[28:35] ; cc46401c 1c722d2c
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[82:83], v[104:111] ; cc464068 1da2a534
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[82:83], v[112:119] ; cc464070 1dc2a536
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[46:47], v[22:23], v[14:21] ; cc46400e 1c3a2d2e
	ds_load_b64 v[36:37], v80 offset:2560                       ; d9d80a00 24000050
	ds_load_b64 v[38:39], v80 offset:4608                       ; d9d81200 26000050
	ds_load_b64 v[40:41], v80 offset:6656                       ; d9d81a00 28000050
	ds_load_b64 v[42:43], v80 offset:768                        ; d9d80300 2a000050
	ds_load_b64 v[44:45], v80 offset:2816                       ; d9d80b00 2c000050
	ds_load_b64 v[22:23], v80 offset:4864                       ; d9d81300 16000050
	ds_load_b64 v[46:47], v80 offset:6912                       ; d9d81b00 2e000050
	ds_load_b64 v[82:83], v80 offset:1024                       ; d9d80400 52000050
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[36:37], v[128:135] ; cc464080 1e024932
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[36:37], v[144:151] ; cc464090 1e424936
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[36:37], v[120:127] ; cc464078 1de24930
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[36:37], v[136:143] ; cc464088 1e224934
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[38:39], v[152:159] ; cc464098 1e624d30
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[38:39], v[176:183] ; cc4640b0 1ec24d36
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[38:39], v[160:167] ; cc4640a0 1e824d32
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[38:39], v[168:175] ; cc4640a8 1ea24d34
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[48:49], v[40:41], v[184:191] ; cc4640b8 1ee25130
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[52:53], v[40:41], v[28:35] ; cc46401c 1c725134
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[50:51], v[40:41], v[6:13] ; cc464006 1c1a5132
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[54:55], v[40:41], v[14:21] ; cc46400e 1c3a5136
	ds_load_b64 v[36:37], v80 offset:3072                       ; d9d80c00 24000050
	ds_load_b64 v[38:39], v80 offset:5120                       ; d9d81400 26000050
	ds_load_b64 v[48:49], v80 offset:7168                       ; d9d81c00 30000050
	ds_load_b64 v[50:51], v80 offset:1280                       ; d9d80500 32000050
	ds_load_b64 v[52:53], v80 offset:3328                       ; d9d80d00 34000050
	ds_load_b64 v[40:41], v80 offset:5376                       ; d9d81500 28000050
	ds_load_b64 v[54:55], v80 offset:7424                       ; d9d81d00 36000050
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[42:43], v[88:95] ; cc464058 1d625538
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[42:43], v[96:103] ; cc464060 1d82553a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[44:45], v[120:127] ; cc464078 1de25938
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[44:45], v[128:135] ; cc464080 1e02593a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[22:23], v[152:159] ; cc464098 1e622d38
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[22:23], v[160:167] ; cc4640a0 1e822d3a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[46:47], v[184:191] ; cc4640b8 1ee25d38
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[42:43], v[104:111] ; cc464068 1da2553c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[44:45], v[136:143] ; cc464088 1e22593c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[22:23], v[168:175] ; cc4640a8 1ea22d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[42:43], v[112:119] ; cc464070 1dc2553e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[44:45], v[144:151] ; cc464090 1e42593e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[22:23], v[176:183] ; cc4640b0 1ec22d3e
	ds_load_b64 v[56:57], v80 offset:1536                       ; d9d80600 38000050
	ds_load_b64 v[42:43], v80 offset:3584                       ; d9d80e00 2a000050
	ds_load_b64 v[44:45], v80 offset:5632                       ; d9d81600 2c000050
	ds_load_b64 v[22:23], v80 offset:7680                       ; d9d81e00 16000050
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[60:61], v[46:47], v[28:35] ; cc46401c 1c725d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[58:59], v[46:47], v[6:13] ; cc464006 1c1a5d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[62:63], v[46:47], v[14:21] ; cc46400e 1c3a5d3e
	ds_load_b64 v[46:47], v80 offset:1792                       ; d9d80700 2e000050
	ds_load_b64 v[58:59], v80 offset:3840                       ; d9d80f00 3a000050
	s_wait_loadcnt_dscnt 0x20c                                  ; bfc8020c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[36:37], v[120:127] ; cc464078 1de24940
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[82:83], v[88:95] ; cc464058 1d62a540
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[38:39], v[152:159] ; cc464098 1e624d40
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[36:37], v[128:135] ; cc464080 1e024942
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[38:39], v[160:167] ; cc4640a0 1e824d42
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[36:37], v[136:143] ; cc464088 1e224944
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[38:39], v[168:175] ; cc4640a8 1ea24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[36:37], v[144:151] ; cc464090 1e424946
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[38:39], v[176:183] ; cc4640b0 1ec24d46
	ds_load_b64 v[36:37], v80 offset:5888                       ; d9d81700 24000050
	ds_load_b64 v[38:39], v80 offset:7936                       ; d9d81f00 26000050
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[48:49], v[184:191] ; cc4640b8 1ee26140
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[82:83], v[96:103] ; cc464060 1d82a542
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[82:83], v[104:111] ; cc464068 1da2a544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[82:83], v[112:119] ; cc464070 1dc2a546
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[68:69], v[48:49], v[28:35] ; cc46401c 1c726144
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[66:67], v[48:49], v[6:13] ; cc464006 1c1a6142
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[48:49], v[14:21] ; cc46400e 1c3a6146
	v_mov_b32_e32 v48, v81                                      ; 7e600351
	v_mov_b32_e32 v49, v85                                      ; 7e620355
	s_clause 0x4                                                ; bf850004
	buffer_load_b128 v[60:63], v84, s[36:39], null offen offset:2560 ; c405c07c 4080483c 000a0054
	buffer_load_b128 v[64:67], v26, s[36:39], null offen offset:3072 ; c405c07c 40804840 000c001a
	buffer_load_b128 v[68:71], v84, s[36:39], null offen offset:3072 ; c405c07c 40804844 000c0054
	buffer_load_b128 v[80:83], v26, s[36:39], null offen offset:3584 ; c405c07c 40804850 000e001a
	buffer_load_b128 v[84:87], v84, s[36:39], null offen offset:3584 ; c405c07c 40804854 000e0054
	s_wait_loadcnt_dscnt 0x50b                                  ; bfc8050b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[50:51], v[88:95] ; cc464058 1d626548
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[52:53], v[120:127] ; cc464078 1de26948
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[40:41], v[152:159] ; cc464098 1e625148
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[72:73], v[54:55], v[184:191] ; cc4640b8 1ee26d48
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[74:75], v[50:51], v[96:103] ; cc464060 1d82654a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[52:53], v[128:135] ; cc464080 1e02694a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[74:75], v[40:41], v[160:167] ; cc4640a0 1e82514a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[74:75], v[54:55], v[6:13] ; cc464006 1c1a6d4a
	v_mad_u32_u24 v72, s55, 0x50, v49                           ; d60b0048 04c5fe37 00000050
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[50:51], v[104:111] ; cc464068 1da2653c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[52:53], v[136:143] ; cc464088 1e22693c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[40:41], v[168:175] ; cc4640a8 1ea2513c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[52:53], v[144:151] ; cc464090 1e42693e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[50:51], v[112:119] ; cc464070 1dc2653e
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[60:61], v[54:55], v[28:35] ; cc46401c 1c726d3c
	ds_load_b64 v[74:75], v72                                   ; d9d80000 4a000048
	ds_load_b64 v[60:61], v72 offset:2048                       ; d9d80800 3c000048
	ds_load_b64 v[50:51], v72 offset:4096                       ; d9d81000 32000048
	ds_load_b64 v[52:53], v72 offset:6144                       ; d9d81800 34000048
	v_add_nc_u32_e32 v73, 4, v24                                ; 4a923084
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[62:63], v[54:55], v[14:21] ; cc46400e 1c3a6d3e
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_dual_mov_b32 v55, v43 :: v_dual_mov_b32 v54, v42          ; ca10012b 3736012a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[40:41], v[176:183] ; cc4640b0 1ec2513e
	v_sub_nc_u32_e32 v26, 0, v73                                ; 4c349280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v26, v73, v26                                 ; 24343549
	v_med3_i32 v73, -1, v73, 1                                  ; d6200049 020692c1
	v_lshrrev_b32_e32 v26, 1, v26                               ; 32343481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0049
	v_cndmask_b32_e32 v1, v73, v26, vcc_lo                      ; 02023549
	v_lshl_add_u32 v73, v73, 10, s3                             ; d6460049 000d1549
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v73, v73, v25, 2                             ; d6470049 020a3349
	buffer_load_b128 v[40:43], v73, s[36:39], null offen        ; c405c07c 40804828 00000049
	v_add_nc_u32_e32 v24, 6, v24                                ; 4a303086
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[56:57], v[88:95] ; cc464058 1d627140
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[54:55], v[120:127] ; cc464078 1de26d40
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[44:45], v[152:159] ; cc464098 1e625940
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[22:23], v[184:191] ; cc4640b8 1ee22d40
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[56:57], v[96:103] ; cc464060 1d827142
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[54:55], v[128:135] ; cc464080 1e026d42
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[44:45], v[160:167] ; cc4640a0 1e825942
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[66:67], v[22:23], v[6:13] ; cc464006 1c1a2d42
	v_sub_nc_u32_e32 v62, 0, v24                                ; 4c7c3080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v62, v24, v62                                 ; 247c7d18
	v_med3_i32 v24, -1, v24, 1                                  ; d6200018 020630c1
	v_lshrrev_b32_e32 v62, 1, v62                               ; 327c7c81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0018
	v_cndmask_b32_e32 v1, v24, v62, vcc_lo                      ; 02027d18
	v_lshl_add_u32 v24, v24, 10, s3                             ; d6460018 000d1518
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v24, v24, v25, 2                             ; d6470018 020a3318
	buffer_load_b128 v[64:67], v24, s[36:39], null offen        ; c405c07c 40804840 00000018
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[56:57], v[104:111] ; cc464068 1da27144
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[54:55], v[136:143] ; cc464088 1e226d44
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[44:45], v[168:175] ; cc4640a8 1ea25944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[56:57], v[112:119] ; cc464070 1dc27146
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[54:55], v[144:151] ; cc464090 1e426d46
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[44:45], v[176:183] ; cc4640b0 1ec25946
	ds_load_b64 v[62:63], v72 offset:256                        ; d9d80100 3e000048
	ds_load_b64 v[56:57], v72 offset:2304                       ; d9d80900 38000048
	ds_load_b64 v[54:55], v72 offset:4352                       ; d9d81100 36000048
	ds_load_b64 v[44:45], v72 offset:6400                       ; d9d81900 2c000048
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[68:69], v[22:23], v[28:35] ; cc46401c 1c722d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[22:23], v[14:21] ; cc46400e 1c3a2d46
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[80:81], v[46:47], v[88:95] ; cc464058 1d625d50
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[58:59], v[120:127] ; cc464078 1de27550
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[80:81], v[36:37], v[152:159] ; cc464098 1e624950
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[80:81], v[38:39], v[184:191] ; cc4640b8 1ee24d50
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[82:83], v[46:47], v[96:103] ; cc464060 1d825d52
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[58:59], v[128:135] ; cc464080 1e027552
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[82:83], v[36:37], v[160:167] ; cc4640a0 1e824952
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[82:83], v[38:39], v[6:13] ; cc464006 1c1a4d52
	v_maxmin_num_f32 v80, -4.0, v90, 4.0                        ; d6690050 03dab4f7
	v_maxmin_num_f32 v68, -4.0, v88, 4.0                        ; d6690044 03dab0f7
	v_maxmin_num_f32 v82, -4.0, v91, 4.0                        ; d6690052 03dab6f7
	v_maxmin_num_f32 v70, -4.0, v89, 4.0                        ; d6690046 03dab2f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_fma_mix_f32 v69, 0xab28, |v68|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe88ff 3728ab28
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c842a553 5350a350 3f650000
	v_maxmin_num_f32 v26, -4.0, v95, 4.0                        ; d669001a 03dabef7
	v_dual_fmaak_f32 v71, v71, v70, 0x3f650000 :: v_dual_fmaak_f32 v68, v68, v69, 0x3f650000 ; c8428d47 47448b44 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_mul_f32 v91, v91, v83 :: v_dual_mul_f32 v90, v90, v80 ; c8c6a75b 5b5aa15a
	v_dual_mul_f32 v89, v89, v71 :: v_dual_mul_f32 v88, v88, v68 ; c8c68f59 59588958
	v_fma_mix_f32 v68, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206244 0bfe34ff 3728ab28
	v_maxmin_num_f32 v69, -4.0, v120, 4.0                       ; d6690045 03daf0f7
	v_maxmin_num_f32 v71, -4.0, v121, 4.0                       ; d6690047 03daf2f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v92, 4.0                        ; d6690058 03dab8f7
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v90, -4.0, v93, 4.0                        ; d669005a 03dabaf7
	v_fmaak_f32 v68, v68, v26, 0x3f650000                       ; 5a883544 3f650000
	v_fma_mix_f32 v70, 0xab28, |v69|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe8aff 3728ab28
	v_fma_mix_f32 v80, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe8eff 3728ab28
	v_maxmin_num_f32 v81, -4.0, v122, 4.0                       ; d6690051 03daf4f7
	v_maxmin_num_f32 v83, -4.0, v123, 4.0                       ; d6690053 03daf6f7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_dual_fmaak_f32 v80, v80, v71, 0x3f650000 :: v_dual_fmaak_f32 v69, v69, v70, 0x3f650000 ; c8428f50 50448d45 3f650000
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	v_maxmin_num_f32 v89, -4.0, v124, 4.0                       ; d6690059 03daf8f7
	v_dual_mul_f32 v120, v120, v69 :: v_dual_mul_f32 v121, v121, v80 ; c8c68b78 7878a179
	v_dual_mul_f32 v93, v93, v91 :: v_dual_mul_f32 v92, v92, v88 ; c8c6b75d 5d5cb15c
	v_maxmin_num_f32 v91, -4.0, v125, 4.0                       ; d669005b 03dafaf7
	v_fma_mix_f32 v88, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfea6ff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v92, -4.0, v94, 4.0                        ; d669005c 03dabcf7
	v_dual_fmaak_f32 v88, v88, v83, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 ; c842a758 5850a551 3f650000
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_mul_f32 v123, v123, v88 :: v_dual_mul_f32 v122, v122, v81 ; c8c6b17b 7b7aa37a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmaak_f32 v92, v92, v93, 0x3f650000                       ; 5ab8bb5c 3f650000
	v_maxmin_num_f32 v93, -4.0, v126, 4.0                       ; d669005d 03dafcf7
	v_dual_mul_f32 v94, v92, v94 :: v_dual_mul_f32 v95, v95, v68 ; c8c6bd5c 5e5e895f
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v152, 4.0                      ; d6690079 03db30f7
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v123, -4.0, v153, 4.0                      ; d669007b 03db32f7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v127, 4.0                       ; d669005f 03dafef7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c842b75c 5c58b559 3f650000
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v120, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfebeff 3728ab28
	v_dual_mul_f32 v125, v125, v92 :: v_dual_mul_f32 v124, v124, v89 ; c8c6b97d 7d7cb37c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v120, v120, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf78 785cbd5d 3f650000
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v125, -4.0, v154, 4.0                      ; d669007d 03db34f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_mul_f32 v127, v127, v120 :: v_dual_mul_f32 v126, v126, v93 ; c8c6f17f 7f7ebb7e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c842f579 797cf77c 3f650000
	v_maxmin_num_f32 v80, -4.0, v158, 4.0                       ; d6690050 03db3cf7
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v127, -4.0, v155, 4.0                      ; d669007f 03db36f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v82, -4.0, v159, 4.0                       ; d6690052 03db3ef7
	v_dual_mul_f32 v153, v153, v124 :: v_dual_mul_f32 v152, v152, v121 ; c8c6f999 9998f398
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[84:85], v[46:47], v[104:111] ; cc464068 1da25d54
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v153, -4.0, v156, 4.0                      ; d6690099 03db38f7
	v_fma_mix_f32 v152, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bfefeff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[84:85], v[58:59], v[136:143] ; cc464088 1e227554
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[84:85], v[36:37], v[168:175] ; cc4640a8 1ea24954
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[84:85], v[38:39], v[28:35] ; cc46401c 1c724d54
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[86:87], v[46:47], v[112:119] ; cc464070 1dc25d56
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[86:87], v[58:59], v[144:151] ; cc464090 1e427556
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c842a553 5350a350 3f650000
	v_dual_fmaak_f32 v152, v152, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842ff98 987cfd7d 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[86:87], v[36:37], v[176:183] ; cc4640b0 1ec24956
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[86:87], v[38:39], v[14:21] ; cc46400e 1c3a4d56
	v_maxmin_num_f32 v84, -4.0, v184, 4.0                       ; d6690054 03db70f7
	v_maxmin_num_f32 v86, -4.0, v185, 4.0                       ; d6690056 03db72f7
	v_dual_mul_f32 v159, v159, v83 :: v_dual_mul_f32 v158, v158, v80 ; c8c6a79f 9f9ea19e
	v_dual_mul_f32 v155, v155, v152 :: v_dual_mul_f32 v154, v154, v125 ; c8c7319b 9b9afb9a
	v_maxmin_num_f32 v88, -4.0, v186, 4.0                       ; d6690058 03db74f7
	v_maxmin_num_f32 v90, -4.0, v187, 4.0                       ; d669005a 03db76f7
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v188, 4.0                       ; d669005c 03db78f7
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v155, -4.0, v157, 4.0                      ; d669009b 03db3af7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v94, -4.0, v189, 4.0                       ; d669005e 03db7af7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c842ad57 5754ab54 3f650000
	v_maxmin_num_f32 v120, -4.0, v190, 4.0                      ; d6690078 03db7cf7
	v_maxmin_num_f32 v122, -4.0, v191, 4.0                      ; d669007a 03db7ef7
	v_fma_mix_f32 v26, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bff36ff 3728ab28
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	v_maxmin_num_f32 v124, -4.0, v96, 4.0                       ; d669007c 03dac0f7
	v_dual_mul_f32 v185, v185, v87 :: v_dual_mul_f32 v184, v184, v84 ; c8c6afb9 b9b8a9b8
	v_maxmin_num_f32 v126, -4.0, v97, 4.0                       ; d669007e 03dac2f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_dual_fmaak_f32 v26, v26, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c843371a 1a993599 3f650000
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 ; c842bd5f 5f5cbb5c 3f650000
	v_dual_mul_f32 v187, v187, v91 :: v_dual_mul_f32 v186, v186, v88 ; c8c6b7bb bbbab1ba
	v_maxmin_num_f32 v152, -4.0, v98, 4.0                       ; d6690098 03dac4f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v99, 4.0                       ; d669009a 03dac6f7
	v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c842f57b 7b78f378 3f650000
	v_dual_mul_f32 v157, v157, v26 :: v_dual_mul_f32 v156, v156, v153 ; c8c6359d 9d9d339c
	v_dual_mul_f32 v189, v189, v95 :: v_dual_mul_f32 v188, v188, v92 ; c8c6bfbd bdbcb9bc
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 ; c842fd7f 7f7cfb7c 3f650000
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_mul_f32 v191, v191, v123 :: v_dual_mul_f32 v190, v190, v120 ; c8c6f7bf bfbef1be
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_maxmin_num_f32 v156, -4.0, v100, 4.0                      ; d669009c 03dac8f7
	v_maxmin_num_f32 v158, -4.0, v101, 4.0                      ; d669009e 03dacaf7
	v_maxmin_num_f32 v184, -4.0, v102, 4.0                      ; d66900b8 03daccf7
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_dual_mul_f32 v97, v97, v127 :: v_dual_mul_f32 v96, v96, v124 ; c8c6ff61 6160f960
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v190, -4.0, v129, 4.0                      ; d66900be 03db02f7
	v_maxmin_num_f32 v188, -4.0, v128, 4.0                      ; d66900bc 03db00f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v186, -4.0, v103, 4.0                      ; d66900ba 03dacef7
	v_dual_mul_f32 v99, v99, v155 :: v_dual_mul_f32 v98, v98, v152 ; c8c73763 63633162
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v47, -4.0, v131, 4.0                       ; d669002f 03db06f7
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_maxmin_num_f32 v59, -4.0, v132, 4.0                       ; d669003b 03db08f7
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8437dbf bfb973b8 3f650000
	v_maxmin_num_f32 v81, -4.0, v133, 4.0                       ; d6690051 03db0af7
	v_fma_mix_f32 v58, 0xab28, |v47|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623a 0bfe5eff 3728ab28
	v_dual_mul_f32 v101, v101, v159 :: v_dual_mul_f32 v100, v100, v156 ; c8c73f65 65653964
	v_maxmin_num_f32 v83, -4.0, v134, 4.0                       ; d6690053 03db0cf7
	v_fma_mix_f32 v80, 0xab28, |v59|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe76ff 3728ab28
	v_dual_mul_f32 v129, v129, v191 :: v_dual_mul_f32 v102, v102, v184 ; c8c77f81 81677166
	v_maxmin_num_f32 v191, -4.0, v130, 4.0                      ; d66900bf 03db04f7
	v_maxmin_num_f32 v85, -4.0, v135, 4.0                       ; d6690055 03db0ef7
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v160, 4.0                       ; d6690057 03db40f7
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_dual_fmaak_f32 v59, v59, v80, 0x3f650000 :: v_dual_fmaak_f32 v58, v58, v47, 0x3f650000 ; c842a13b 3b3a5f3a 3f650000
	v_fma_mix_f32 v26, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bff7eff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v161, 4.0                       ; d6690059 03db42f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v162, 4.0                       ; d669005b 03db44f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 ; c842a953 5352a352 3f650000
	v_dual_mul_f32 v131, v131, v58 :: v_dual_mul_f32 v132, v132, v59 ; c8c67583 83847784
	v_dual_fmaak_f32 v191, v191, v26, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c84235bf bfbd7bbc 3f650000
	v_maxmin_num_f32 v93, -4.0, v163, 4.0                       ; d669005d 03db46f7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v164, 4.0                       ; d669005f 03db48f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842b157 5756ab56 3f650000
	v_dual_mul_f32 v134, v134, v83 :: v_dual_mul_f32 v133, v133, v82 ; c8c6a786 8684a585
	v_dual_mul_f32 v130, v130, v191 :: v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 ; c8c37f82 82bb75bb 3f650000
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v165, 4.0                       ; d6690061 03db4af7
	v_maxmin_num_f32 v99, -4.0, v166, 4.0                       ; d6690063 03db4cf7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b95b 5b5ab35a 3f650000
	v_dual_mul_f32 v160, v160, v87 :: v_dual_mul_f32 v135, v135, v86 ; c8c6afa0 a086ad87
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v103, v103, v187 :: v_dual_mul_f32 v128, v128, v188 ; c8c77767 67817980
	v_maxmin_num_f32 v101, -4.0, v167, 4.0                      ; d6690065 03db4ef7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842c15f 5f5ebb5e 3f650000
	v_dual_mul_f32 v162, v162, v91 :: v_dual_mul_f32 v161, v161, v90 ; c8c6b7a2 a2a0b5a1
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v121, -4.0, v7, 4.0                        ; d6690079 03da0ef7
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v103, -4.0, v6, 4.0                        ; d6690067 03da0cf7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v8, 4.0                        ; d669007b 03da10f7
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 ; c842c963 6362c362 3f650000
	v_dual_mul_f32 v164, v164, v95 :: v_dual_mul_f32 v163, v163, v94 ; c8c6bfa4 a4a2bda3
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v9, 4.0                        ; d669007d 03da12f7
	v_maxmin_num_f32 v127, -4.0, v10, 4.0                       ; d669007f 03da14f7
	v_fma_mix_f32 v120, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeceff 3728ab28
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v11, 4.0                       ; d6690081 03da16f7
	v_dual_mul_f32 v166, v166, v99 :: v_dual_mul_f32 v165, v165, v98 ; c8c6c7a6 a6a4c5a5
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_maxmin_num_f32 v131, -4.0, v12, 4.0                       ; d6690083 03da18f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_dual_fmaak_f32 v103, v103, v120, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c842f167 6766cb66 3f650000
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f97b 7b7af37a 3f650000
	v_maxmin_num_f32 v133, -4.0, v13, 4.0                       ; d6690085 03da1af7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_maxmin_num_f32 v135, -4.0, v104, 4.0                      ; d6690087 03dad0f7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c843017f 7f7efb7e 3f650000
	v_dual_mul_f32 v6, v6, v103 :: v_dual_mul_f32 v167, v167, v102 ; c8c6cf06 06a6cda7
	v_maxmin_num_f32 v153, -4.0, v105, 4.0                      ; d6690099 03dad2f7
	v_dual_mul_f32 v8, v8, v123 :: v_dual_mul_f32 v7, v7, v122  ; c8c6f708 0806f507
	v_maxmin_num_f32 v155, -4.0, v106, 4.0                      ; d669009b 03dad4f7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_fma_mix_f32 v152, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff0eff 3728ab28
	v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 ; c8430983 83830382 3f650000
	v_dual_mul_f32 v10, v10, v127 :: v_dual_mul_f32 v9, v9, v126 ; c8c6ff0a 0a08fd09
	v_maxmin_num_f32 v157, -4.0, v107, 4.0                      ; d669009d 03dad6f7
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v159, -4.0, v108, 4.0                      ; d669009f 03dad8f7
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_fmaak_f32 v135, v135, v152, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 ; c8433187 87870b86 3f650000
	v_dual_mul_f32 v12, v12, v131 :: v_dual_mul_f32 v11, v11, v130 ; c8c7070c 0c0b050b
	v_maxmin_num_f32 v161, -4.0, v109, 4.0                      ; d66900a1 03dadaf7
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
	v_maxmin_num_f32 v163, -4.0, v110, 4.0                      ; d66900a3 03dadcf7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v111, 4.0                      ; d66900a5 03dadef7
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
	v_dual_mul_f32 v104, v104, v135 :: v_dual_mul_f32 v13, v13, v134 ; c8c70f68 680d0d0d
	v_maxmin_num_f32 v167, -4.0, v136, 4.0                      ; d66900a7 03db10f7
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v137, 4.0                      ; d66900b9 03db12f7
	v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 ; c843419f 9f9f3b9e 3f650000
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v187, -4.0, v138, 4.0                      ; d66900bb 03db14f7
	v_dual_mul_f32 v106, v106, v155 :: v_dual_mul_f32 v105, v105, v154 ; c8c7376a 6a693569
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
	v_fma_mix_f32 v184, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff4eff 3728ab28
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c84349a3 a3a343a2 3f650000
	v_maxmin_num_f32 v189, -4.0, v139, 4.0                      ; d66900bd 03db16f7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v140, 4.0                      ; d66900bf 03db18f7
	v_dual_mul_f32 v108, v108, v159 :: v_dual_mul_f32 v107, v107, v158 ; c8c73f6c 6c6b3d6b
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v12, -4.0, v141, 4.0                       ; d669000c 03db1af7
	v_dual_fmaak_f32 v167, v167, v184, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84371a7 a7a74ba6 3f650000
	v_dual_mul_f32 v110, v110, v163 :: v_dual_mul_f32 v109, v109, v162 ; c8c7476e 6e6d456d
	v_maxmin_num_f32 v26, -4.0, v142, 4.0                       ; d669001a 03db1cf7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_fma_mix_f32 v11, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620b 0bff7eff 3728ab28
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84379bb bbbb73ba 3f650000
	v_maxmin_num_f32 v81, -4.0, v143, 4.0                       ; d6690051 03db1ef7
	v_fma_mix_f32 v13, 0xab28, |v12|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bfe18ff 3728ab28
	v_maxmin_num_f32 v83, -4.0, v168, 4.0                       ; d6690053 03db50f7
	v_dual_mul_f32 v136, v136, v167 :: v_dual_mul_f32 v111, v111, v166 ; c8c74f88 886f4d6f
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v80, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe34ff 3728ab28
	v_dual_fmaak_f32 v191, v191, v11, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c84217bf bfbf7bbe 3f650000
	v_maxmin_num_f32 v85, -4.0, v169, 4.0                       ; d6690055 03db52f7
	v_dual_mul_f32 v138, v138, v187 :: v_dual_mul_f32 v137, v137, v186 ; c8c7778a 8a897589
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v170, 4.0                       ; d6690057 03db54f7
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v89, -4.0, v171, 4.0                       ; d6690059 03db56f7
	v_dual_fmaak_f32 v26, v80, v26, 0x3f650000 :: v_dual_fmaak_f32 v13, v13, v12, 0x3f650000 ; c8423550 1a0c190d 3f650000
	v_dual_mul_f32 v140, v140, v191 :: v_dual_mul_f32 v139, v139, v190 ; c8c77f8c 8c8b7d8b
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v172, 4.0                       ; d669005b 03db58f7
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 ; c842a953 5352a352 3f650000
	v_maxmin_num_f32 v93, -4.0, v173, 4.0                       ; d669005d 03db5af7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v174, 4.0                       ; d669005f 03db5cf7
	v_dual_mul_f32 v142, v142, v26 :: v_dual_mul_f32 v141, v141, v13 ; c8c6358e 8e8c1b8d
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 :: v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 ; c842ab56 5656b157 3f650000
	v_maxmin_num_f32 v97, -4.0, v175, 4.0                       ; d6690061 03db5ef7
	v_dual_mul_f32 v168, v168, v83 :: v_dual_mul_f32 v143, v143, v82 ; c8c6a7a8 a88ea58f
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v28, 4.0                        ; d6690063 03da38f7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_maxmin_num_f32 v101, -4.0, v29, 4.0                       ; d6690065 03da3af7
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b95b 5b5ab35a 3f650000
	v_dual_mul_f32 v170, v170, v87 :: v_dual_mul_f32 v169, v169, v86 ; c8c6afaa aaa8ada9
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v30, 4.0                       ; d6690067 03da3cf7
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842c15f 5f5ebb5e 3f650000
	v_maxmin_num_f32 v105, -4.0, v31, 4.0                       ; d6690069 03da3ef7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_dual_mul_f32 v172, v172, v91 :: v_dual_mul_f32 v171, v171, v90 ; c8c6b7ac acaab5ab
	v_maxmin_num_f32 v107, -4.0, v32, 4.0                       ; d669006b 03da40f7
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_maxmin_num_f32 v109, -4.0, v33, 4.0                       ; d669006d 03da42f7
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 ; c842c963 6362c362 3f650000
	v_dual_mul_f32 v174, v174, v95 :: v_dual_mul_f32 v173, v173, v94 ; c8c6bfae aeacbdad
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_maxmin_num_f32 v111, -4.0, v34, 4.0                       ; d669006f 03da44f7
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v35, 4.0                       ; d6690079 03da46f7
	v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c842d167 6766cb66 3f650000
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_dual_mul_f32 v28, v28, v99 :: v_dual_mul_f32 v175, v175, v98 ; c8c6c71c 1caec5af
	v_maxmin_num_f32 v123, -4.0, v112, 4.0                      ; d669007b 03dae0f7
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_fma_mix_f32 v120, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfedeff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v113, 4.0                      ; d669007d 03dae2f7
	v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 ; c842d96b 6b6ad36a 3f650000
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_dual_mul_f32 v30, v30, v103 :: v_dual_mul_f32 v29, v29, v102 ; c8c6cf1e 1e1ccd1d
	v_maxmin_num_f32 v127, -4.0, v114, 4.0                      ; d669007f 03dae4f7
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v115, 4.0                      ; d6690081 03dae6f7
	v_dual_fmaak_f32 v111, v111, v120, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 ; c842f16f 6f6edb6e 3f650000
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_dual_mul_f32 v32, v32, v107 :: v_dual_mul_f32 v31, v31, v106 ; c8c6d720 201ed51f
	v_maxmin_num_f32 v131, -4.0, v116, 4.0                      ; d6690083 03dae8f7
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v133, -4.0, v117, 4.0                      ; d6690085 03daeaf7
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f97b 7b7af37a 3f650000
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v118, 4.0                      ; d6690087 03daecf7
	v_dual_mul_f32 v34, v34, v111 :: v_dual_mul_f32 v33, v33, v110 ; c8c6df22 2220dd21
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v144, 4.0                      ; d669008b 03db20f7
	v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c843017f 7f7efb7e 3f650000
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_dual_mul_f32 v112, v112, v123 :: v_dual_mul_f32 v35, v35, v122 ; c8c6f770 7022f523
	v_maxmin_num_f32 v141, -4.0, v145, 4.0                      ; d669008d 03db22f7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	v_maxmin_num_f32 v137, -4.0, v119, 4.0                      ; d6690089 03daeef7
	v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 ; c8430983 83830382 3f650000
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_mul_f32 v114, v114, v127 :: v_dual_mul_f32 v113, v113, v126 ; c8c6ff72 7270fd71
	v_maxmin_num_f32 v143, -4.0, v146, 4.0                      ; d669008f 03db24f7
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 ; c8431187 87870b86 3f650000
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_dual_mul_f32 v116, v116, v131 :: v_dual_mul_f32 v115, v115, v130 ; c8c70774 74730573
	v_maxmin_num_f32 v153, -4.0, v148, 4.0                      ; d6690099 03db28f7
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v155, -4.0, v149, 4.0                      ; d669009b 03db2af7
	v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 :: v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 ; c8431b8e 8e8b198b 3f650000
	v_dual_mul_f32 v118, v118, v135 :: v_dual_mul_f32 v117, v117, v134 ; c8c70f76 76750d75
	v_maxmin_num_f32 v157, -4.0, v150, 4.0                      ; d669009d 03db2cf7
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_maxmin_num_f32 v159, -4.0, v151, 4.0                      ; d669009f 03db2ef7
	v_dual_mul_f32 v145, v145, v142 :: v_dual_mul_f32 v144, v144, v139 ; c8c71d91 91911790
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v176, 4.0                      ; d66900a1 03db60f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v145, -4.0, v147, 4.0                      ; d6690091 03db26f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v177, 4.0                      ; d66900a3 03db62f7
	v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 ; c8433d9d 9d9d379c 3f650000
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v178, 4.0                      ; d66900a5 03db64f7
	v_fma_mix_f32 v152, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff22ff 3728ab28
	v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 :: v_dual_fmaak_f32 v143, v143, v144, 0x3f650000 ; c843138a 8a8f218f 3f650000
	v_maxmin_num_f32 v167, -4.0, v179, 4.0                      ; d66900a7 03db66f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_dual_mul_f32 v150, v150, v157 :: v_dual_mul_f32 v149, v149, v156 ; c8c73b96 96953995
	v_maxmin_num_f32 v169, -4.0, v180, 4.0                      ; d66900a9 03db68f7
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 ; c84345a1 a1a13fa0 3f650000
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v152, v152, v145, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c8432398 98993599 3f650000
	v_dual_mul_f32 v146, v146, v143 :: v_dual_mul_f32 v119, v119, v138 ; c8c71f92 92771577
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v181, 4.0                      ; d66900ab 03db6af7
	v_maxmin_num_f32 v173, -4.0, v182, 4.0                      ; d66900ad 03db6cf7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_mul_f32 v176, v176, v161 :: v_dual_mul_f32 v151, v151, v160 ; c8c743b0 b0974197
	v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 ; c8434da5 a5a547a4 3f650000
	v_dual_mul_f32 v148, v148, v153 :: v_dual_mul_f32 v147, v147, v152 ; c8c73394 94933193
	v_maxmin_num_f32 v175, -4.0, v183, 4.0                      ; d66900af 03db6ef7
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 ; c84355a9 a9a94fa8 3f650000
	v_dual_mul_f32 v178, v178, v165 :: v_dual_mul_f32 v177, v177, v164 ; c8c74bb2 b2b149b1
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 ; c8435dad adad57ac 3f650000
	v_dual_mul_f32 v180, v180, v169 :: v_dual_mul_f32 v179, v179, v168 ; c8c753b4 b4b351b3
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_maxmin_num_f32 v177, -4.0, v14, 4.0                       ; d66900b1 03da1cf7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v18, 4.0                       ; d66900b9 03da24f7
	v_dual_mul_f32 v182, v182, v173 :: v_dual_mul_f32 v181, v181, v172 ; c8c75bb6 b6b559b5
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_maxmin_num_f32 v179, -4.0, v15, 4.0                       ; d66900b3 03da1ef7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v187, -4.0, v19, 4.0                       ; d66900bb 03da26f7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_maxmin_num_f32 v181, -4.0, v16, 4.0                       ; d66900b5 03da20f7
	v_maxmin_num_f32 v189, -4.0, v20, 4.0                       ; d66900bd 03da28f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 ; c84365b1 b1b15fb0 3f650000
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v21, 4.0                       ; d66900bf 03da2af7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[74:75], 0 ; cc464050 1a029528
	v_dual_mul_f32 v14, v14, v177 :: v_dual_mul_f32 v183, v183, v176 ; c8c7630e 0eb761b7
	v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 :: v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 ; c84377bc bcbd7dbd 3f650000
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[60:61], 0 ; cc464058 1a027928
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[50:51], 0 ; cc464060 1a026528
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[52:53], 0 ; cc464068 1a026928
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_maxmin_num_f32 v183, -4.0, v17, 4.0                       ; d66900b7 03da22f7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[74:75], 0 ; cc464070 1a02952a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[60:61], 0 ; cc464078 1a02792a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[50:51], 0 ; cc464080 1a02652a
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c84367b4 b4b56db5 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[52:53], 0 ; cc464088 1a02692a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[64:65], v[50:51], 0 ; cc4640a0 1a026540
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 ; c8436fb8 b8b975b9 3f650000
	v_mul_f32_e32 v16, v16, v181                                ; 10216b10
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[64:65], v[74:75], 0 ; cc464090 1a029540
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[60:61], 0 ; cc464098 1a027940
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[64:65], v[52:53], 0 ; cc4640a8 1a026940
	v_dual_mul_f32 v18, v18, v185 :: v_dual_mul_f32 v15, v15, v180 ; c8c77312 120f690f
	v_dual_mul_f32 v20, v20, v189 :: v_dual_mul_f32 v17, v17, v184 ; c8c77b14 14117111
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[66:67], v[74:75], 0 ; cc4640b0 1a029542
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_fma_mix_f32 v16, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206210 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
	v_dual_fmaak_f32 v16, v16, v191, 0x3f650000 :: v_dual_mul_f32 v19, v19, v188 ; c8477f10 10137913 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[66:67], v[60:61], 0 ; cc4640b8 1a027942
	v_dual_mov_b32 v40, v14 :: v_dual_mul_f32 v21, v21, v16     ; ca06010e 28142115
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mov_b32 v42, v58 :: v_dual_mov_b32 v41, v15          ; ca10013a 2a28010f
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[66:67], v[50:51], 0 ; cc46400e 1a026542
	s_wait_dscnt 0x3                                            ; bfc60003
	v_dual_mov_b32 v50, v62 :: v_dual_mov_b32 v43, v59          ; ca10013e 322a013b
	v_dual_mov_b32 v26, v72 :: v_dual_mov_b32 v51, v63          ; ca100148 1a32013f
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[66:67], v[52:53], 0 ; cc46403a 1a026942
	v_mov_b32_e32 v52, v73                                      ; 7e680349
	buffer_load_b128 v[72:75], v73, s[36:39], null offen offset:512 ; c405c07c 40804848 00020049
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[54:55], v[128:135] ; cc464080 1e026d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[56:57], v[88:95] ; cc464058 1d627148
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[54:55], v[96:103] ; cc464060 1d826d48
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[44:45], v[136:143] ; cc464088 1e22594a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[50:51], v[80:87] ; cc464050 1d426548
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[56:57], v[120:127] ; cc464078 1de2714a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[44:45], v[104:111] ; cc464068 1da25948
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[50:51], v[112:119] ; cc464070 1dc2654a
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:512 ; c405c07c 40804848 00020018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[50:51], v[144:151] ; cc464090 1e426548
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[56:57], v[184:191] ; cc4640b8 1ee2714a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[54:55], v[160:167] ; cc4640a0 1e826d48
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[54:55], v[14:21] ; cc46400e 1c3a6d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[50:51], v[176:183] ; cc4640b0 1ec2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[56:57], v[152:159] ; cc464098 1e627148
	ds_load_b64 v[66:67], v26 offset:512                        ; d9d80200 4200001a
	ds_load_b64 v[50:51], v26 offset:2560                       ; d9d80a00 3200001a
	ds_load_b64 v[56:57], v26 offset:4608                       ; d9d81200 3800001a
	ds_load_b64 v[54:55], v26 offset:6656                       ; d9d81a00 3600001a
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[44:45], v[58:65] ; cc46403a 1cea594a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[44:45], v[168:175] ; cc4640a8 1ea25948
	buffer_load_b128 v[72:75], v52, s[36:39], null offen offset:1024 ; c405c07c 40804848 00040034
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[54:55], v[104:111] ; cc464068 1da26d48
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[66:67], v[112:119] ; cc464070 1dc2854a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[50:51], v[120:127] ; cc464078 1de2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[56:57], v[128:135] ; cc464080 1e02714a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[54:55], v[136:143] ; cc464088 1e226d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[66:67], v[80:87] ; cc464050 1d428548
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[50:51], v[88:95] ; cc464058 1d626548
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[56:57], v[96:103] ; cc464060 1d827148
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:1024 ; c405c07c 40804848 00040018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[50:51], v[184:191] ; cc4640b8 1ee2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[56:57], v[160:167] ; cc4640a0 1e827148
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[56:57], v[14:21] ; cc46400e 1c3a714a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[66:67], v[176:183] ; cc4640b0 1ec2854a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[50:51], v[152:159] ; cc464098 1e626548
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[66:67], v[144:151] ; cc464090 1e428548
	ds_load_b64 v[44:45], v26 offset:768                        ; d9d80300 2c00001a
	ds_load_b64 v[66:67], v26 offset:2816                       ; d9d80b00 4200001a
	ds_load_b64 v[50:51], v26 offset:4864                       ; d9d81300 3200001a
	ds_load_b64 v[56:57], v26 offset:6912                       ; d9d81b00 3800001a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[54:55], v[168:175] ; cc4640a8 1ea26d48
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[54:55], v[58:65] ; cc46403a 1cea6d4a
	buffer_load_b128 v[72:75], v52, s[36:39], null offen offset:1536 ; c405c07c 40804848 00060034
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[56:57], v[104:111] ; cc464068 1da27148
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[44:45], v[112:119] ; cc464070 1dc2594a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[66:67], v[120:127] ; cc464078 1de2854a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[50:51], v[128:135] ; cc464080 1e02654a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[56:57], v[136:143] ; cc464088 1e22714a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[50:51], v[96:103] ; cc464060 1d826548
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[44:45], v[80:87] ; cc464050 1d425948
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[66:67], v[88:95] ; cc464058 1d628548
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:1536 ; c405c07c 40804848 00060018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[66:67], v[184:191] ; cc4640b8 1ee2854a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[50:51], v[160:167] ; cc4640a0 1e826548
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[50:51], v[14:21] ; cc46400e 1c3a654a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[44:45], v[144:151] ; cc464090 1e425948
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[44:45], v[176:183] ; cc4640b0 1ec2594a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[66:67], v[152:159] ; cc464098 1e628548
	ds_load_b64 v[54:55], v26 offset:1024                       ; d9d80400 3600001a
	ds_load_b64 v[44:45], v26 offset:3072                       ; d9d80c00 2c00001a
	ds_load_b64 v[66:67], v26 offset:5120                       ; d9d81400 4200001a
	ds_load_b64 v[50:51], v26 offset:7168                       ; d9d81c00 3200001a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[56:57], v[168:175] ; cc4640a8 1ea27148
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[56:57], v[58:65] ; cc46403a 1cea714a
	buffer_load_b128 v[72:75], v52, s[36:39], null offen offset:2048 ; c405c07c 40804848 00080034
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[50:51], v[104:111] ; cc464068 1da26548
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[54:55], v[112:119] ; cc464070 1dc26d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[44:45], v[120:127] ; cc464078 1de2594a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[66:67], v[128:135] ; cc464080 1e02854a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[50:51], v[136:143] ; cc464088 1e22654a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[66:67], v[96:103] ; cc464060 1d828548
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[54:55], v[80:87] ; cc464050 1d426d48
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[44:45], v[88:95] ; cc464058 1d625948
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:2048 ; c405c07c 40804848 00080018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[44:45], v[184:191] ; cc4640b8 1ee2594a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[66:67], v[160:167] ; cc4640a0 1e828548
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[66:67], v[14:21] ; cc46400e 1c3a854a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[54:55], v[144:151] ; cc464090 1e426d48
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[54:55], v[176:183] ; cc4640b0 1ec26d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[44:45], v[152:159] ; cc464098 1e625948
	ds_load_b64 v[56:57], v26 offset:1280                       ; d9d80500 3800001a
	ds_load_b64 v[54:55], v26 offset:3328                       ; d9d80d00 3600001a
	ds_load_b64 v[44:45], v26 offset:5376                       ; d9d81500 2c00001a
	ds_load_b64 v[66:67], v26 offset:7424                       ; d9d81d00 4200001a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[50:51], v[168:175] ; cc4640a8 1ea26548
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[50:51], v[58:65] ; cc46403a 1cea654a
	buffer_load_b128 v[72:75], v52, s[36:39], null offen offset:2560 ; c405c07c 40804848 000a0034
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[66:67], v[104:111] ; cc464068 1da28548
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[56:57], v[112:119] ; cc464070 1dc2714a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[54:55], v[120:127] ; cc464078 1de26d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[44:45], v[128:135] ; cc464080 1e02594a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[44:45], v[96:103] ; cc464060 1d825948
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[66:67], v[136:143] ; cc464088 1e22854a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[56:57], v[80:87] ; cc464050 1d427148
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[54:55], v[88:95] ; cc464058 1d626d48
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:2560 ; c405c07c 40804848 000a0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[54:55], v[184:191] ; cc4640b8 1ee26d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[44:45], v[160:167] ; cc4640a0 1e825948
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[44:45], v[14:21] ; cc46400e 1c3a594a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[56:57], v[144:151] ; cc464090 1e427148
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[56:57], v[176:183] ; cc4640b0 1ec2714a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[54:55], v[152:159] ; cc464098 1e626d48
	ds_load_b64 v[50:51], v26 offset:1536                       ; d9d80600 3200001a
	ds_load_b64 v[56:57], v26 offset:3584                       ; d9d80e00 3800001a
	ds_load_b64 v[54:55], v26 offset:5632                       ; d9d81600 3600001a
	ds_load_b64 v[44:45], v26 offset:7680                       ; d9d81e00 2c00001a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[66:67], v[168:175] ; cc4640a8 1ea28548
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[66:67], v[58:65] ; cc46403a 1cea854a
	buffer_load_b128 v[72:75], v52, s[36:39], null offen offset:3072 ; c405c07c 40804848 000c0034
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[44:45], v[104:111] ; cc464068 1da25948
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[50:51], v[112:119] ; cc464070 1dc2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[56:57], v[120:127] ; cc464078 1de2714a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[54:55], v[128:135] ; cc464080 1e026d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[44:45], v[136:143] ; cc464088 1e22594a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[54:55], v[96:103] ; cc464060 1d826d48
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[50:51], v[80:87] ; cc464050 1d426548
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[56:57], v[88:95] ; cc464058 1d627148
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:3072 ; c405c07c 40804848 000c0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[56:57], v[184:191] ; cc4640b8 1ee2714a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[54:55], v[160:167] ; cc4640a0 1e826d48
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[44:45], v[168:175] ; cc4640a8 1ea25948
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[50:51], v[144:151] ; cc464090 1e426548
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[50:51], v[176:183] ; cc4640b0 1ec2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[56:57], v[152:159] ; cc464098 1e627148
	ds_load_b64 v[66:67], v26 offset:1792                       ; d9d80700 4200001a
	ds_load_b64 v[50:51], v26 offset:3840                       ; d9d80f00 3200001a
	ds_load_b64 v[56:57], v26 offset:5888                       ; d9d81700 3800001a
	ds_load_b64 v[72:73], v26 offset:7936                       ; d9d81f00 4800001a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[54:55], v[14:21] ; cc46400e 1c3a6d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[44:45], v[58:65] ; cc46403a 1cea594a
	v_dual_mov_b32 v75, v27 :: v_dual_mov_b32 v74, v25          ; ca10011b 4b4a0119
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[52:55], v52, s[36:39], null offen offset:3584 ; c405c07c 40804834 000e0034
	buffer_load_b128 v[24:27], v24, s[36:39], null offen offset:3584 ; c405c07c 40804818 000e0018
	s_wait_loadcnt_dscnt 0x102                                  ; bfc80102
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[50:51], v[88:95] ; cc464058 1d626534
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[56:57], v[96:103] ; cc464060 1d827134
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[66:67], v[112:119] ; cc464070 1dc28536
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[50:51], v[120:127] ; cc464078 1de26536
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[72:73], v[104:111] ; cc464068 1da29134
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[56:57], v[128:135] ; cc464080 1e027136
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[52:53], v[66:67], v[80:87] ; cc464050 1d428534
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[54:55], v[72:73], v[136:143] ; cc464088 1e229136
	v_maxmin_num_f32 v44, -4.0, v80, 4.0                        ; d669002c 03daa0f7
	v_maxmin_num_f32 v52, -4.0, v81, 4.0                        ; d6690034 03daa2f7
	v_maxmin_num_f32 v54, -4.0, v82, 4.0                        ; d6690036 03daa4f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
	v_fma_mix_f32 v45, 0xab28, |v44|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe58ff 3728ab28
	v_fma_mix_f32 v53, 0xab28, |v52|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206235 0bfe68ff 3728ab28
	v_fma_mix_f32 v55, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe6cff 3728ab28
	v_dual_fmaak_f32 v53, v53, v52, 0x3f650000 :: v_dual_fmaak_f32 v44, v44, v45, 0x3f650000 ; c8426935 352c5b2c 3f650000
	v_maxmin_num_f32 v45, -4.0, v85, 4.0                        ; d669002d 03daaaf7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v81, v81, v53 :: v_dual_mul_f32 v80, v80, v44 ; c8c66b51 51505950
	v_maxmin_num_f32 v53, -4.0, v86, 4.0                        ; d6690035 03daacf7
	v_fma_mix_f32 v52, 0xab28, |v45|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206234 0bfe5aff 3728ab28
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v80, -4.0, v83, 4.0                        ; d6690050 03daa6f7
	v_fmaak_f32 v52, v52, v45, 0x3f650000                       ; 5a685b34 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_dual_fmaak_f32 v81, v81, v80, 0x3f650000 :: v_dual_fmaak_f32 v54, v54, v55, 0x3f650000 ; c842a151 51366f36 3f650000
	v_maxmin_num_f32 v55, -4.0, v87, 4.0                        ; d6690037 03daaef7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_dual_mul_f32 v83, v83, v81 :: v_dual_mul_f32 v82, v82, v54 ; c8c6a353 53526d52
	v_fma_mix_f32 v54, 0xab28, |v53|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206236 0bfe6aff 3728ab28
	v_maxmin_num_f32 v81, -4.0, v88, 4.0                        ; d6690051 03dab0f7
	v_fma_mix_f32 v80, 0xab28, |v55|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe6eff 3728ab28
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v82, -4.0, v84, 4.0                        ; d6690052 03daa8f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v80, v80, v55, 0x3f650000 :: v_dual_fmaak_f32 v53, v53, v54, 0x3f650000 ; c8426f50 50346d35 3f650000
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v86, v86, v53 :: v_dual_mul_f32 v87, v87, v80 ; c8c66b56 5656a157
	v_fmaak_f32 v82, v82, v83, 0x3f650000                       ; 5aa4a752 3f650000
	v_maxmin_num_f32 v83, -4.0, v89, 4.0                        ; d6690053 03dab2f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_mul_f32 v84, v84, v82 :: v_dual_mul_f32 v85, v85, v52 ; c8c6a554 54546955
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v85, -4.0, v90, 4.0                        ; d6690055 03dab4f7
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v87, -4.0, v91, 4.0                        ; d6690057 03dab6f7
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v54, -4.0, v94, 4.0                        ; d6690036 03dabcf7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v80, -4.0, v95, 4.0                        ; d6690050 03dabef7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 ; c842a551 5154a754 3f650000
	v_fma_mix_f32 v55, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe6cff 3728ab28
	v_dual_mul_f32 v89, v89, v84 :: v_dual_mul_f32 v88, v88, v81 ; c8c6a959 5958a358
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_maxmin_num_f32 v82, -4.0, v96, 4.0                        ; d6690052 03dac0f7
	v_maxmin_num_f32 v84, -4.0, v97, 4.0                        ; d6690054 03dac2f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v89, -4.0, v92, 4.0                        ; d6690059 03dab8f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v81, v81, v80, 0x3f650000 :: v_dual_fmaak_f32 v54, v54, v55, 0x3f650000 ; c842a151 51366f36 3f650000
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af58 5854ad55 3f650000
	v_maxmin_num_f32 v86, -4.0, v98, 4.0                        ; d6690056 03dac4f7
	v_dual_mul_f32 v95, v95, v81 :: v_dual_mul_f32 v94, v94, v54 ; c8c6a35f 5f5e6d5e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v91, v91, v88 :: v_dual_mul_f32 v90, v90, v85 ; c8c6b15b 5b5aab5a
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v99, 4.0                        ; d6690058 03dac6f7
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v93, 4.0                        ; d669005b 03dabaf7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_fmaak_f32 v85, v85, v84, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v83, 0x3f650000 ; c842a955 5552a752 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v53, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206235 0bfeb6ff 3728ab28
	v_fmaak_f32 v89, v89, v90, 0x3f650000                       ; 5ab2b559 3f650000
	v_maxmin_num_f32 v90, -4.0, v100, 4.0                       ; d669005a 03dac8f7
	v_dual_mul_f32 v97, v97, v85 :: v_dual_mul_f32 v96, v96, v82 ; c8c6ab61 6160a560
	v_dual_fmaak_f32 v53, v53, v91, 0x3f650000 :: v_dual_mul_f32 v92, v92, v89 ; c846b735 355cb35c 3f650000
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v96, -4.0, v103, 4.0                       ; d6690060 03dacef7
	v_mul_f32_e32 v93, v93, v53                                 ; 10ba6b5d
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v87, 0x3f650000 ; c842b159 5956af56 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v92, -4.0, v101, 4.0                       ; d669005c 03dacaf7
	v_maxmin_num_f32 v94, -4.0, v102, 4.0                       ; d669005e 03daccf7
	v_dual_mul_f32 v99, v99, v89 :: v_dual_mul_f32 v98, v98, v86 ; c8c6b363 6362ad62
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v98, -4.0, v104, 4.0                       ; d6690062 03dad0f7
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 ; c842b95d 5d5ab75a 3f650000
	v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c842c161 615ebf5e 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_dual_mul_f32 v101, v101, v93 :: v_dual_mul_f32 v100, v100, v90 ; c8c6bb65 6564b564
	v_dual_mul_f32 v103, v103, v97 :: v_dual_mul_f32 v102, v102, v94 ; c8c6c367 6766bd66
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870252
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v100, -4.0, v105, 4.0                      ; d6690064 03dad2f7
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v102, -4.0, v106, 4.0                      ; d6690066 03dad4f7
	v_maxmin_num_f32 v81, -4.0, v109, 4.0                       ; d6690051 03dadaf7
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_maxmin_num_f32 v83, -4.0, v110, 4.0                       ; d6690053 03dadcf7
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v111, 4.0                       ; d6690055 03dadef7
	v_dual_fmaak_f32 v101, v101, v100, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v99, 0x3f650000 ; c842c965 6562c762 3f650000
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v112, 4.0                       ; d6690057 03dae0f7
	v_fmaak_f32 v82, v82, v81, 0x3f650000                       ; 5aa4a352 3f650000
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v113, 4.0                       ; d6690059 03dae2f7
	v_dual_mul_f32 v105, v105, v101 :: v_dual_mul_f32 v104, v104, v98 ; c8c6cb69 6968c568
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 :: v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 ; c842ab56 5652a953 3f650000
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v114, 4.0                       ; d669005b 03dae4f7
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v104, -4.0, v107, 4.0                      ; d6690068 03dad6f7
	v_maxmin_num_f32 v93, -4.0, v115, 4.0                       ; d669005d 03dae6f7
	v_dual_mul_f32 v110, v110, v83 :: v_dual_mul_f32 v111, v111, v86 ; c8c6a76e 6e6ead6f
	v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 :: v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 ; c842b35a 5a56b157 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v116, 4.0                       ; d669005f 03dae8f7
	v_maxmin_num_f32 v97, -4.0, v117, 4.0                       ; d6690061 03daeaf7
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_mul_f32 v113, v113, v90 :: v_dual_mul_f32 v112, v112, v87 ; c8c6b571 7170af70
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v118, 4.0                       ; d6690063 03daecf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v105, v105, v104, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 ; c842d169 6966cf66 3f650000
	v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 :: v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 ; c842bb5e 5e5ab95b 3f650000
	v_maxmin_num_f32 v101, -4.0, v119, 4.0                      ; d6690065 03daeef7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c842c362 625ec15f 3f650000
	v_maxmin_num_f32 v103, -4.0, v120, 4.0                      ; d6690067 03daf0f7
	v_dual_mul_f32 v107, v107, v105 :: v_dual_mul_f32 v106, v106, v102 ; c8c6d36b 6b6acd6a
	v_dual_mul_f32 v115, v115, v94 :: v_dual_mul_f32 v114, v114, v91 ; c8c6bd73 7372b772
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v105, -4.0, v121, 4.0                      ; d6690069 03daf2f7
	v_dual_mul_f32 v117, v117, v98 :: v_dual_mul_f32 v116, v116, v95 ; c8c6c575 7574bf74
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[24:25], v[66:67], v[144:151] ; cc464090 1e428518
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[24:25], v[50:51], v[152:159] ; cc464098 1e626518
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v106, -4.0, v108, 4.0                      ; d669006a 03dad8f7
	v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 :: v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 ; c842cb66 6662c963 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[24:25], v[56:57], v[160:167] ; cc4640a0 1e827118
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[24:25], v[72:73], v[168:175] ; cc4640a8 1ea29118
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[26:27], v[66:67], v[176:183] ; cc4640b0 1ec2851a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[26:27], v[50:51], v[184:191] ; cc4640b8 1ee2651a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[26:27], v[56:57], v[14:21] ; cc46400e 1c3a711a
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[26:27], v[72:73], v[58:65] ; cc46403a 1cea911a
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_dual_mul_f32 v119, v119, v102 :: v_dual_mul_f32 v118, v118, v99 ; c8c6cd77 7776c776
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fmaak_f32 v106, v106, v107, 0x3f650000                    ; 5ad4d76a 3f650000
	v_maxmin_num_f32 v107, -4.0, v122, 4.0                      ; d669006b 03daf4f7
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_mul_f32 v108, v106, v108 :: v_dual_mul_f32 v109, v109, v82 ; c8c6d96a 6c6ca56d
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_maxmin_num_f32 v113, -4.0, v125, 4.0                      ; d6690071 03dafaf7
	v_maxmin_num_f32 v115, -4.0, v126, 4.0                      ; d6690073 03dafcf7
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v109, -4.0, v123, 4.0                      ; d669006d 03daf6f7
	v_maxmin_num_f32 v111, -4.0, v124, 4.0                      ; d669006f 03daf8f7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_maxmin_num_f32 v117, -4.0, v127, 4.0                      ; d6690075 03dafef7
	v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 :: v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 ; c842d36a 6a66d167 3f650000
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v128, 4.0                      ; d6690077 03db00f7
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_dual_mul_f32 v121, v121, v106 :: v_dual_mul_f32 v120, v120, v103 ; c8c6d579 7978cf78
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 :: v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 ; c842db6e 6e6ad96b 3f650000
	v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 :: v_dual_fmaak_f32 v111, v111, v112, 0x3f650000 ; c842e372 726ee16f 3f650000
	v_dual_fmaak_f32 v118, v118, v117, 0x3f650000 :: v_dual_fmaak_f32 v115, v115, v116, 0x3f650000 ; c842eb76 7672e973 3f650000
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v121, -4.0, v129, 4.0                      ; d6690079 03db02f7
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_dual_mul_f32 v123, v123, v110 :: v_dual_mul_f32 v122, v122, v107 ; c8c6dd7b 7b7ad77a
	v_dual_mul_f32 v125, v125, v114 :: v_dual_mul_f32 v124, v124, v111 ; c8c6e57d 7d7cdf7c
	v_dual_mul_f32 v127, v127, v118 :: v_dual_mul_f32 v126, v126, v115 ; c8c6ed7f 7f7ee77e
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v123, -4.0, v130, 4.0                      ; d669007b 03db04f7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v125, -4.0, v131, 4.0                      ; d669007d 03db06f7
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v127, -4.0, v132, 4.0                      ; d669007f 03db08f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 :: v_dual_fmaak_f32 v119, v119, v120, 0x3f650000 ; c842f37a 7a76f177 3f650000
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v129, v129, v122 :: v_dual_mul_f32 v128, v128, v119 ; c8c6f581 8180ef80
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c842f97b 7b7efb7e 3f650000
	v_maxmin_num_f32 v51, -4.0, v136, 4.0                       ; d6690033 03db10f7
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v129, -4.0, v133, 4.0                      ; d6690081 03db0af7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v57, -4.0, v137, 4.0                       ; d6690039 03db12f7
	v_dual_mul_f32 v131, v131, v126 :: v_dual_mul_f32 v130, v130, v123 ; c8c6fd83 8382f782
	v_fma_mix_f32 v56, 0xab28, |v51|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206238 0bfe66ff 3728ab28
	v_maxmin_num_f32 v67, -4.0, v138, 4.0                       ; d6690043 03db14f7
	v_maxmin_num_f32 v73, -4.0, v139, 4.0                       ; d6690049 03db16f7
	v_fma_mix_f32 v66, 0xab28, |v57|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206242 0bfe72ff 3728ab28
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v131, -4.0, v134, 4.0                      ; d6690083 03db0cf7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_fma_mix_f32 v72, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe86ff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v140, 4.0                       ; d6690055 03db18f7
	v_fma_mix_f32 v84, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfe92ff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v141, 4.0                       ; d6690057 03db1af7
	v_dual_fmaak_f32 v51, v51, v56, 0x3f650000 :: v_dual_fmaak_f32 v66, v66, v57, 0x3f650000 ; c8427133 33427342 3f650000
	v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 :: v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 ; c8430382 827f017f 3f650000
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_dual_fmaak_f32 v67, v67, v72, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v73, 0x3f650000 ; c8429143 43549354 3f650000
	v_maxmin_num_f32 v89, -4.0, v142, 4.0                       ; d6690059 03db1cf7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v143, 4.0                       ; d669005b 03db1ef7
	v_dual_mul_f32 v133, v133, v130 :: v_dual_mul_f32 v132, v132, v127 ; c8c70585 8584ff84
	v_dual_mul_f32 v139, v139, v84 :: v_dual_mul_f32 v136, v136, v51 ; c8c6a98b 8b886788
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v144, 4.0                       ; d669005d 03db20f7
	v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 ; c842ad55 5558af58 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v145, 4.0                       ; d669005f 03db22f7
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v133, -4.0, v135, 4.0                      ; d6690085 03db0ef7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_mul_f32 v141, v141, v88 :: v_dual_mul_f32 v138, v138, v67 ; c8c6b18d 8d8a878a
	v_maxmin_num_f32 v97, -4.0, v146, 4.0                       ; d6690061 03db24f7
	v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842b559 595cb75c 3f650000
	v_maxmin_num_f32 v99, -4.0, v147, 4.0                       ; d6690063 03db26f7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_fma_mix_f32 v50, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206232 0bff0aff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v148, 4.0                      ; d6690065 03db28f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v149, 4.0                      ; d6690067 03db2af7
	v_dual_mul_f32 v143, v143, v92 :: v_dual_mul_f32 v140, v140, v85 ; c8c6b98f 8f8cab8c
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842bd5d 5d60bf60 3f650000
	v_dual_fmaak_f32 v50, v50, v133, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 ; c8430b32 32830983 3f650000
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v105, -4.0, v150, 4.0                      ; d6690069 03db2cf7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v151, 4.0                      ; d669006b 03db2ef7
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 ; c842c561 6164c764 3f650000
	v_dual_mul_f32 v145, v145, v96 :: v_dual_mul_f32 v142, v142, v89 ; c8c6c191 918eb38e
	v_dual_mul_f32 v137, v137, v66 :: v_dual_mul_f32 v134, v134, v131 ; c8c68589 89870786
	v_mul_f32_e32 v135, v135, v50                               ; 110e6587
	v_maxmin_num_f32 v109, -4.0, v152, 4.0                      ; d669006d 03db30f7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 ; c842cd65 6568cf68 3f650000
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_maxmin_num_f32 v111, -4.0, v153, 4.0                      ; d669006f 03db32f7
	v_dual_mul_f32 v147, v147, v100 :: v_dual_mul_f32 v144, v144, v93 ; c8c6c993 9390bb90
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_maxmin_num_f32 v113, -4.0, v154, 4.0                      ; d6690071 03db34f7
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_maxmin_num_f32 v115, -4.0, v155, 4.0                      ; d6690073 03db36f7
	v_dual_mul_f32 v149, v149, v104 :: v_dual_mul_f32 v146, v146, v97 ; c8c6d195 9592c392
	v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 ; c842d569 696cd76c 3f650000
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v117, -4.0, v156, 4.0                      ; d6690075 03db38f7
	v_maxmin_num_f32 v119, -4.0, v157, 4.0                      ; d6690077 03db3af7
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_maxmin_num_f32 v121, -4.0, v158, 4.0                      ; d6690079 03db3cf7
	v_dual_mul_f32 v151, v151, v108 :: v_dual_mul_f32 v148, v148, v101 ; c8c6d997 9794cb94
	v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 ; c842dd6d 6d70df70 3f650000
	v_maxmin_num_f32 v123, -4.0, v159, 4.0                      ; d669007b 03db3ef7
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v160, 4.0                      ; d669007d 03db40f7
	v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 ; c842e571 7174e774 3f650000
	v_maxmin_num_f32 v127, -4.0, v161, 4.0                      ; d669007f 03db42f7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_dual_mul_f32 v153, v153, v112 :: v_dual_mul_f32 v150, v150, v105 ; c8c6e199 9996d396
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v162, 4.0                      ; d6690081 03db44f7
	v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 ; c842ed75 7578ef78 3f650000
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v163, 4.0                      ; d6690083 03db46f7
	v_dual_mul_f32 v155, v155, v116 :: v_dual_mul_f32 v152, v152, v109 ; c8c6e99b 9b98db98
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_maxmin_num_f32 v133, -4.0, v164, 4.0                      ; d6690085 03db48f7
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c842f579 797cf77c 3f650000
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_dual_mul_f32 v157, v157, v120 :: v_dual_mul_f32 v154, v154, v113 ; c8c6f19d 9d9ae39a
	v_maxmin_num_f32 v135, -4.0, v165, 4.0                      ; d6690087 03db4af7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 ; c842fd7d 7d80ff80 3f650000
	v_maxmin_num_f32 v137, -4.0, v166, 4.0                      ; d6690089 03db4cf7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_dual_mul_f32 v159, v159, v124 :: v_dual_mul_f32 v156, v156, v117 ; c8c6f99f 9f9ceb9c
	s_lshr_b32 s11, s11, 2                                      ; 850b820b
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 ; c8430d85 85890f88 3f650000
	v_dual_mul_f32 v164, v133, v164 :: v_dual_lshlrev_b32 v139, 10, v1 ; c8e34985 a48a028a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add3_u32 v140, v74, s11, v139                             ; d655008c 062c174a
	v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 :: v_dual_lshlrev_b32 v140, 2, v140 ; c8631589 898d1882 3f650000
	buffer_load_b128 v[84:87], v140, s[36:39], null offen       ; c405c07c 40804854 0000008c
	v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 ; c8430581 81850784 3f650000
	v_dual_mul_f32 v161, v161, v128 :: v_dual_mul_f32 v158, v158, v121 ; c8c701a1 a19ef39e
	v_maxmin_num_f32 v141, -4.0, v167, 4.0                      ; d669008d 03db4ef7
	buffer_load_b128 v[88:91], v140, s[36:39], null offen offset:512 ; c405c07c 40804858 0002008c
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_maxmin_num_f32 v143, -4.0, v168, 4.0                      ; d669008f 03db50f7
	v_mul_f32_e32 v166, v166, v137                              ; 114d13a6
	v_maxmin_num_f32 v145, -4.0, v169, 4.0                      ; d6690091 03db52f7
	v_maxmin_num_f32 v147, -4.0, v170, 4.0                      ; d6690093 03db54f7
	v_dual_mul_f32 v165, v165, v136 :: v_dual_mul_f32 v162, v162, v129 ; c8c711a5 a5a303a2
	v_dual_mul_f32 v163, v163, v132 :: v_dual_mul_f32 v160, v160, v125 ; c8c709a3 a3a0fba0
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	buffer_load_b128 v[96:99], v140, s[36:39], null offen offset:1024 ; c405c07c 40804860 0004008c
	v_maxmin_num_f32 v149, -4.0, v171, 4.0                      ; d6690095 03db56f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_maxmin_num_f32 v151, -4.0, v172, 4.0                      ; d6690097 03db58f7
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_maxmin_num_f32 v153, -4.0, v173, 4.0                      ; d6690099 03db5af7
	buffer_load_b128 v[100:103], v140, s[36:39], null offen offset:1536 ; c405c07c 40804864 0006008c
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 :: v_dual_fmaak_f32 v143, v143, v144, 0x3f650000 ; c8431b8e 8e8f218f 3f650000
	v_maxmin_num_f32 v155, -4.0, v174, 4.0                      ; d669009b 03db5cf7
	v_dual_fmaak_f32 v147, v147, v148, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v145, 0x3f650000 ; c8432993 93932392 3f650000
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v175, 4.0                      ; d669009d 03db5ef7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_fmaak_f32 v150, v150, v149, 0x3f650000                    ; 5b2d2b96 3f650000
	buffer_load_b128 v[104:107], v140, s[36:39], null offen offset:2048 ; c405c07c 40804868 0008008c
	v_dual_mul_f32 v168, v168, v143 :: v_dual_mul_f32 v167, v167, v142 ; c8c71fa8 a8a71da7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_maxmin_num_f32 v159, -4.0, v176, 4.0                      ; d669009f 03db60f7
	v_dual_mul_f32 v170, v170, v147 :: v_dual_mul_f32 v169, v169, v146 ; c8c727aa aaa925a9
	v_maxmin_num_f32 v161, -4.0, v177, 4.0                      ; d66900a1 03db62f7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 :: v_dual_fmaak_f32 v151, v151, v152, 0x3f650000 ; c843339a 9a973197 3f650000
	v_mul_f32_e32 v171, v171, v150                              ; 11572dab
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	buffer_load_b128 v[108:111], v140, s[36:39], null offen offset:2560 ; c405c07c 4080486c 000a008c
	v_maxmin_num_f32 v163, -4.0, v178, 4.0                      ; d66900a3 03db64f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 :: v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 ; c8433b9e 9e9b399b 3f650000
	v_maxmin_num_f32 v165, -4.0, v179, 4.0                      ; d66900a5 03db66f7
	v_dual_mul_f32 v173, v173, v154 :: v_dual_mul_f32 v172, v172, v151 ; c8c735ad adad2fac
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_maxmin_num_f32 v167, -4.0, v180, 4.0                      ; d66900a7 03db68f7
	buffer_load_b128 v[112:115], v140, s[36:39], null offen offset:3072 ; c405c07c 40804870 000c008c
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v169, -4.0, v181, 4.0                      ; d66900a9 03db6af7
	v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 :: v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 ; c84343a2 a29f419f 3f650000
	v_dual_mul_f32 v175, v175, v158 :: v_dual_mul_f32 v174, v174, v155 ; c8c73daf afaf37ae
	v_maxmin_num_f32 v171, -4.0, v182, 4.0                      ; d66900ab 03db6cf7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_fmaak_f32 v163, v163, v164, 0x3f650000                    ; 5b4749a3 3f650000
	buffer_load_b128 v[116:119], v140, s[36:39], null offen offset:3584 ; c405c07c 40804874 000e008c
	v_maxmin_num_f32 v173, -4.0, v183, 4.0                      ; d66900ad 03db6ef7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_mul_f32 v177, v177, v162 :: v_dual_mul_f32 v176, v176, v159 ; c8c745b1 b1b13fb0
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_maxmin_num_f32 v175, -4.0, v184, 4.0                      ; d66900af 03db70f7
	v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84351a7 a7a74ba6 3f650000
	v_mul_f32_e32 v178, v178, v163                              ; 116547b2
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_maxmin_num_f32 v177, -4.0, v185, 4.0                      ; d66900b1 03db72f7
	v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 ; c84359ab abab53aa 3f650000
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_dual_mul_f32 v180, v180, v167 :: v_dual_mul_f32 v179, v179, v166 ; c8c74fb4 b4b34db3
	v_fmaak_f32 v174, v174, v173, 0x3f650000                    ; 5b5d5bae 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v182, v182, v171 :: v_dual_mul_f32 v181, v181, v170 ; c8c757b6 b6b555b5
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_maxmin_num_f32 v179, -4.0, v186, 4.0                      ; d66900b3 03db74f7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_mul_f32_e32 v183, v183, v174                              ; 116f5db7
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_maxmin_num_f32 v181, -4.0, v187, 4.0                      ; d66900b5 03db76f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_dual_fmaak_f32 v178, v178, v177, 0x3f650000 :: v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 ; c84363b2 b2af61af 3f650000
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_maxmin_num_f32 v183, -4.0, v188, 4.0                      ; d66900b7 03db78f7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_dual_mul_f32 v185, v185, v178 :: v_dual_mul_f32 v184, v184, v175 ; c8c765b9 b9b95fb8
	v_dual_fmaak_f32 v179, v179, v180, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v181, 0x3f650000 ; c84369b3 b3b76bb6 3f650000
	v_maxmin_num_f32 v123, -4.0, v14, 4.0                       ; d669007b 03da1cf7
(invalid instruction)                                        ; d7690078
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_maxmin_num_f32 v185, -4.0, v189, 4.0                      ; d66900b9 03db7af7
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_dual_mul_f32 v187, v187, v182 :: v_dual_mul_f32 v186, v186, v179 ; c8c76dbb bbbb67ba
	v_maxmin_num_f32 v125, -4.0, v15, 4.0                       ; d669007d 03da1ef7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v16, 4.0                       ; d669007f 03da20f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694078
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v187, -4.0, v190, 4.0                      ; d66900bb 03db7cf7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v17, 4.0                       ; d6690081 03da22f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v18, 4.0                       ; d6690083 03da24f7
	v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 :: v_dual_fmaak_f32 v183, v183, v184, 0x3f650000 ; c84373ba bab771b7 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 :: v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 ; c842fb7e 7e7f017f 3f650000
	v_maxmin_num_f32 v133, -4.0, v19, 4.0                       ; d6690085 03da26f7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_mul_f32 v189, v189, v186 :: v_dual_mul_f32 v188, v188, v183 ; c8c775bd bdbd6fbc
	v_maxmin_num_f32 v135, -4.0, v20, 4.0                       ; d6690087 03da28f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 ; c8430382 82830983 3f650000
	v_lshrrev_b32_e32 v75, 4, v75                               ; 32969684
(invalid instruction)                                        ; d7690079
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_maxmin_num_f32 v189, -4.0, v191, 4.0                      ; d66900bd 03db7ef7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_dual_mul_f32 v18, v18, v131 :: v_dual_mul_f32 v15, v15, v126 ; c8c70712 120efd0f
	v_dual_mul_f32 v17, v17, v130 :: v_dual_and_b32 v0, 0xffffffe0, v0 ; c8e50511 110000ff ffffffe0
	v_maxmin_num_f32 v137, -4.0, v21, 4.0                       ; d6690089 03da2af7
	v_fma_mix_f32 v122, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bff7aff 3728ab28
	v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 :: v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 ; c8430b86 86871187 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v122, v122, v189, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 ; c8437b7a 7a7af97b 3f650000
	v_dual_mul_f32 v20, v135, v20 :: v_dual_lshlrev_b32 v75, 3, v75 ; c8e22987 144a9683
	v_dual_mul_f32 v16, v16, v127 :: v_dual_mul_f32 v191, v191, v122 ; c8c6ff10 10bef5bf
	v_mul_f32_e32 v14, v14, v123                                ; 101cf70e
	v_fmaak_f32 v187, v187, v188, 0x3f650000                    ; 5b7779bb 3f650000
	v_add3_u32 v138, v75, s8, v0                                ; d655008a 0400114b
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_dual_mul_f32 v19, v134, v19 :: v_dual_lshlrev_b32 v138, 2, v138 ; c8e22786 138b1482
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v138, s[32:35], null offen       ; c405c07c 40804010 0000008a
	buffer_load_b128 v[124:127], v138, s[32:35], null offen offset:16 ; c405c07c 4080407c 0000108a
	v_maxmin_num_f32 v141, -4.0, v58, 4.0                       ; d669008d 03da74f7
	v_fma_mix_f32 v140, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff12ff 3728ab28
	v_maxmin_num_f32 v143, -4.0, v59, 4.0                       ; d669008f 03da76f7
	v_mul_f32_e32 v190, v190, v187                              ; 117d77be
	v_maxmin_num_f32 v145, -4.0, v60, 4.0                       ; d6690091 03da78f7
	v_maxmin_num_f32 v147, -4.0, v61, 4.0                       ; d6690093 03da7af7
	v_maxmin_num_f32 v149, -4.0, v62, 4.0                       ; d6690095 03da7cf7
	v_maxmin_num_f32 v151, -4.0, v63, 4.0                       ; d6690097 03da7ef7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
(invalid instruction)                                        ; d7694079
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v153, -4.0, v64, 4.0                       ; d6690099 03da80f7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v65, 4.0                       ; d669009b 03da82f7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v137, 0x3f650000 ; c8431d8d 8d8d138c 3f650000
	v_fmaak_f32 v144, v144, v143, 0x3f650000                    ; 5b211f90 3f650000
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8432794 94912591 3f650000
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432f98 98952d95 3f650000
	v_dual_mul_f32 v58, v58, v141 :: v_dual_mul_f32 v21, v21, v140 ; c8c71b3a 3a151915
	v_mul_f32_e32 v59, v59, v144                                ; 1077213b
	v_dual_mul_f32 v61, v61, v148 :: v_dual_mul_f32 v60, v60, v145 ; c8c7293d 3d3d233c
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c843379c 9c993599 3f650000
	v_dual_mul_f32 v63, v63, v152 :: v_dual_mul_f32 v62, v62, v149 ; c8c7313f 3f3f2b3e
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
	v_dual_mul_f32 v65, v65, v156 :: v_dual_mul_f32 v64, v64, v153 ; c8c73941 41413340
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[68:69], 0 ; cc464090 1a028954
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[86:87], v[22:23], 0 ; cc4640a8 1a022d56
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[86:87], v[36:37], 0 ; cc46403a 1a024956
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[22:23], 0 ; cc464080 1a022d54
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[86:87], v[70:71], 0 ; cc4640b8 1a028d56
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[84:85], v[36:37], 0 ; cc4640a0 1a024954
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[86:87], v[68:69], 0 ; cc4640b0 1a028956
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[84:85], v[70:71], 0 ; cc464098 1a028d54
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[88:89], v[46:47], v[144:151] ; cc464090 1e425d58
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[90:91], v[38:39], v[168:175] ; cc4640a8 1ea24d5a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[88:89], v[38:39], v[128:135] ; cc464080 1e024d58
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[90:91], v[46:47], v[176:183] ; cc4640b0 1ec25d5a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[10:11], v[144:151] ; cc464090 1e421560
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[98:99], v[8:9], v[168:175] ; cc4640a8 1ea21162
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[96:97], v[8:9], v[128:135] ; cc464080 1e021160
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[90:91], v[6:7], v[58:65] ; cc46403a 1cea0d5a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[88:89], v[6:7], v[160:167] ; cc4640a0 1e820d58
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[98:99], v[10:11], v[176:183] ; cc4640b0 1ec21562
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[102:103], v[30:31], v[168:175] ; cc4640a8 1ea23d66
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[100:101], v[30:31], v[128:135] ; cc464080 1e023d64
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[98:99], v[28:29], v[58:65] ; cc46403a 1cea3962
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[96:97], v[28:29], v[160:167] ; cc4640a0 1e823960
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v138, s[32:35], null offen offset:64 ; c405c07c 40804008 0000408a
	buffer_load_b128 v[28:31], v138, s[32:35], null offen offset:80 ; c405c07c 4080401c 0000508a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[90:91], v[42:43], v[184:191] ; cc4640b8 1ee2555a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[88:89], v[42:43], v[152:159] ; cc464098 1e625558
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[32:33], v[144:151] ; cc464090 1e424164
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[100:101], v[40:41], v[160:167] ; cc4640a0 1e825164
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[12:13], v[184:191] ; cc4640b8 1ee21962
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[12:13], v[152:159] ; cc464098 1e621960
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[102:103], v[32:33], v[176:183] ; cc4640b0 1ec24166
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[102:103], v[40:41], v[58:65] ; cc46403a 1cea5166
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[104:105], v[44:45], v[128:135] ; cc464080 1e025968
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[102:103], v[34:35], v[184:191] ; cc4640b8 1ee24566
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[104:105], v[52:53], v[144:151] ; cc464090 1e426968
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[100:101], v[34:35], v[152:159] ; cc464098 1e624564
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[104:105], v[80:81], v[160:167] ; cc4640a0 1e82a168
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[106:107], v[44:45], v[168:175] ; cc4640a8 1ea2596a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[106:107], v[52:53], v[176:183] ; cc4640b0 1ec2696a
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[106:107], v[80:81], v[58:65] ; cc46403a 1ceaa16a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[106:107], v[54:55], v[184:191] ; cc4640b8 1ee26d6a
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[108:109], v[82:83], v[128:135] ; cc464080 1e02a56c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[24:25], v[144:151] ; cc464090 1e42316c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[104:105], v[54:55], v[152:159] ; cc464098 1e626d68
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[108:109], v[50:51], v[160:167] ; cc4640a0 1e82656c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[110:111], v[82:83], v[168:175] ; cc4640a8 1ea2a56e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[110:111], v[24:25], v[176:183] ; cc4640b0 1ec2316e
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[110:111], v[50:51], v[58:65] ; cc46403a 1cea656e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[26:27], v[184:191] ; cc4640b8 1ee2356e
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[112:113], v[56:57], v[128:135] ; cc464080 1e027170
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[112:113], v[66:67], v[144:151] ; cc464090 1e428570
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[26:27], v[152:159] ; cc464098 1e62356c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[112:113], v[92:93], v[160:167] ; cc4640a0 1e82b970
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[114:115], v[56:57], v[168:175] ; cc4640a8 1ea27172
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[66:67], v[176:183] ; cc4640b0 1ec28572
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[114:115], v[92:93], v[58:65] ; cc46403a 1ceab972
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[72:73], v[184:191] ; cc4640b8 1ee29172
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[116:117], v[94:95], v[128:135] ; cc464080 1e02bd74
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[116:117], v[120:121], v[144:151] ; cc464090 1e42f174
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[72:73], v[152:159] ; cc464098 1e629170
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[116:117], v[20:21], v[160:167] ; cc4640a0 1e822974
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[118:119], v[94:95], v[168:175] ; cc4640a8 1ea2bd76
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[118:119], v[120:121], v[176:183] ; cc4640b0 1ec2f176
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[118:119], v[20:21], v[58:65] ; cc46403a 1cea2976
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[14:15], v[184:191] ; cc4640b8 1ee21d76
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[14:15], v[152:159] ; cc464098 1e621d74
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_add3_u32 v157, v74, s4, v139                              ; d655009d 062c094a
	v_lshlrev_b32_e32 v157, 2, v157                             ; 313b3a82
	buffer_load_b128 v[24:27], v157, s[36:39], null offen       ; c405c07c 40804818 0000009d
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_add_nc_u32_e32 v158, 0x2000, v76                          ; 4b3c98ff 00002000
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	ds_store_2addr_b64 v158, v[6:7], v[22:23] offset1:32        ; d9382000 0016069e
	buffer_load_b128 v[40:43], v157, s[36:39], null offen offset:512 ; c405c07c 40804828 0002009d
	v_add_nc_u32_e32 v159, 0x2800, v76                          ; 4b3e98ff 00002800
	v_add_nc_u32_e32 v160, 0x3000, v76                          ; 4b4098ff 00003000
	v_add_nc_u32_e32 v161, 0x3800, v76                          ; 4b4298ff 00003800
	ds_store_2addr_b64 v159, v[12:13], v[32:33] offset1:32      ; d9382000 00200c9f
	ds_store_2addr_b64 v160, v[14:15], v[34:35] offset1:32      ; d9382000 00220ea0
	ds_store_2addr_b64 v161, v[20:21], v[36:37] offset1:32      ; d9382000 002414a1
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	buffer_load_b128 v[12:15], v157, s[36:39], null offen offset:1024 ; c405c07c 4080480c 0004009d
	v_mad_u32_u24 v162, s55, 0x500, v2                          ; d60b00a2 0409fe37 00000500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v162, v162, v49                            ; 4b4463a2
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[6:7], v162                                    ; d9d80000 060000a2
	ds_load_b64 v[20:21], v162 offset:2048                      ; d9d80800 140000a2
	ds_load_b64 v[22:23], v162 offset:4096                      ; d9d81000 160000a2
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[32:33], v6                           ; 7e40dd06
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v57, v33, v17 :: v_dual_mul_f32 v56, v32, v16 ; c8c62321 39382120
	v_cvt_pk_f32_fp8_e32 v[32:33], v134                         ; 7e40dd86
	v_dual_mul_f32 v59, v33, v19 :: v_dual_mul_f32 v58, v32, v18 ; c8c62721 3b3a2520
	buffer_load_b128 v[32:35], v157, s[36:39], null offen offset:1536 ; c405c07c 40804820 0006009d
	v_cvt_pk_f32_fp8_e32 v[36:37], v7                           ; 7e48dd07
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v61, v37, v125 :: v_dual_mul_f32 v60, v36, v124 ; c8c6fb25 3d3cf924
	ds_load_b64 v[36:37], v162 offset:6144                      ; d9d81800 240000a2
	buffer_load_b128 v[44:47], v157, s[36:39], null offen offset:2048 ; c405c07c 4080482c 0008009d
	ds_load_b64 v[38:39], v162 offset:256                       ; d9d80100 260000a2
	buffer_load_b128 v[52:55], v157, s[36:39], null offen offset:2560 ; c405c07c 40804834 000a009d
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v63, v7, v127 :: v_dual_mul_f32 v62, v6, v126 ; c8c6ff07 3f3efd06
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[6:7], v20                            ; 7e0cdd14
	v_dual_mul_f32 v65, v7, v17 :: v_dual_mul_f32 v64, v6, v16  ; c8c62307 41402106
	v_cvt_pk_f32_fp8_e32 v[6:7], v148                           ; 7e0cdd94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v67, v7, v19 :: v_dual_mul_f32 v66, v6, v18  ; c8c62707 43422506
	v_cvt_pk_f32_fp8_e32 v[6:7], v21                            ; 7e0cdd15
	v_cvt_pk_f32_fp8_e32 v[20:21], v149                         ; 7e28dd95
	v_dual_mul_f32 v69, v7, v125 :: v_dual_mul_f32 v68, v6, v124 ; c8c6fb07 4544f906
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v22                            ; 7e0cdd16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v81, v7, v17 :: v_dual_mul_f32 v80, v6, v16  ; c8c62307 51502106
	v_cvt_pk_f32_fp8_e32 v[6:7], v150                           ; 7e0cdd96
	v_dual_mul_f32 v83, v7, v19 :: v_dual_mul_f32 v82, v6, v18  ; c8c62707 53522506
	v_cvt_pk_f32_fp8_e32 v[6:7], v23                            ; 7e0cdd17
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v71, v21, v127 :: v_dual_mul_f32 v84, v6, v124 ; c8c6ff15 4754f906
	v_dual_mul_f32 v85, v7, v125 :: v_dual_mul_f32 v70, v20, v126 ; c8c6fb07 5546fd14
	v_cvt_pk_f32_fp8_e32 v[6:7], v151                           ; 7e0cdd97
	buffer_load_b128 v[20:23], v157, s[36:39], null offen offset:3072 ; c405c07c 40804814 000c009d
	ds_load_b64 v[50:51], v162 offset:2304                      ; d9d80900 320000a2
	v_dual_mul_f32 v87, v7, v127 :: v_dual_mul_f32 v86, v6, v126 ; c8c6ff07 5756fd06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v36                            ; 7e0cdd24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v89, v7, v17                                  ; 10b22307
	v_mul_f32_e32 v88, v6, v16                                  ; 10b02106
	v_cvt_pk_f32_fp8_e32 v[6:7], v164                           ; 7e0cdda4
	v_dual_mul_f32 v91, v7, v19 :: v_dual_mul_f32 v90, v6, v18  ; c8c62707 5b5a2506
	buffer_load_b128 v[16:19], v157, s[36:39], null offen offset:3584 ; c405c07c 40804810 000e009d
	v_cvt_pk_f32_fp8_e32 v[6:7], v37                            ; 7e0cdd25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v93, v7, v125 :: v_dual_mul_f32 v92, v6, v124 ; c8c6fb07 5d5cf906
	v_cvt_pk_f32_fp8_e32 v[6:7], v165                           ; 7e0cdda5
	v_dual_mul_f32 v95, v7, v127 :: v_dual_mul_f32 v94, v6, v126 ; c8c6ff07 5f5efd06
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[6:7], v38                            ; 7e0cdd26
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v97, v7, v9 :: v_dual_mul_f32 v96, v6, v8    ; c8c61307 61601106
	v_cvt_pk_f32_fp8_e32 v[6:7], v166                           ; 7e0cdda6
	v_dual_mul_f32 v99, v7, v11 :: v_dual_mul_f32 v98, v6, v10  ; c8c61707 63621506
	v_cvt_pk_f32_fp8_e32 v[6:7], v39                            ; 7e0cdd27
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v101, v7, v29 :: v_dual_mul_f32 v100, v6, v28 ; c8c63b07 65643906
	v_cvt_pk_f32_fp8_e32 v[6:7], v167                           ; 7e0cdda7
	ds_load_b64 v[36:37], v162 offset:4352                      ; d9d81100 240000a2
	ds_load_b64 v[38:39], v162 offset:6400                      ; d9d81900 260000a2
	v_dual_mul_f32 v103, v7, v31 :: v_dual_mul_f32 v102, v6, v30 ; c8c63f07 67663d06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v50                            ; 7e0cdd32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v105, v7, v9 :: v_dual_mul_f32 v104, v6, v8  ; c8c61307 69681106
	v_cvt_pk_f32_fp8_e32 v[6:7], v178                           ; 7e0cddb2
	v_dual_mul_f32 v107, v7, v11 :: v_dual_mul_f32 v106, v6, v10 ; c8c61707 6b6a1506
	v_cvt_pk_f32_fp8_e32 v[6:7], v51                            ; 7e0cdd33
	v_add_lshl_u32 v163, s10, v1, 2                             ; d64700a3 020a020a
	buffer_load_b32 v163, v163, s[32:35], null offen            ; c405007c 408040a3 000000a3
	v_dual_mul_f32 v109, v7, v29 :: v_dual_mul_f32 v108, v6, v28 ; c8c63b07 6d6c3906
	v_cvt_pk_f32_fp8_e32 v[6:7], v179                           ; 7e0cddb3
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_mad_u32_u24 v164, 0xc00, v1, s5                           ; d60b00a4 001602ff 00000c00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v111, v7, v31 :: v_dual_mul_f32 v110, v6, v30 ; c8c63f07 6f6e3d06
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[6:7], v36                            ; 7e0cdd24
	v_add_lshl_u32 v164, v164, v74, 2                           ; d64700a4 020a95a4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_mul_f32 v113, v7, v9 :: v_dual_mul_f32 v112, v6, v8  ; c8c61307 71701106
	v_cvt_pk_f32_fp8_e32 v[6:7], v164                           ; 7e0cdda4
	v_dual_mul_f32 v115, v7, v11 :: v_dual_mul_f32 v114, v6, v10 ; c8c61707 73721506
	v_cvt_pk_f32_fp8_e32 v[6:7], v37                            ; 7e0cdd25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v117, v7, v29 :: v_dual_mul_f32 v116, v6, v28 ; c8c63b07 75743906
	v_cvt_pk_f32_fp8_e32 v[6:7], v165                           ; 7e0cdda5
	v_dual_mul_f32 v119, v7, v31 :: v_dual_mul_f32 v118, v6, v30 ; c8c63f07 77763d06
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[6:7], v38                            ; 7e0cdd26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v121, v7, v9 :: v_dual_mul_f32 v120, v6, v8  ; c8c61307 79781106
	v_cvt_pk_f32_fp8_e32 v[6:7], v166                           ; 7e0cdda6
	v_dual_mul_f32 v123, v7, v11 :: v_dual_mul_f32 v122, v6, v10 ; c8c61707 7b7a1506
	buffer_load_b128 v[8:11], v164, s[36:39], null offen        ; c405c07c 40804808 000000a4
	v_cvt_pk_f32_fp8_e32 v[6:7], v39                            ; 7e0cdd27
	v_lshl_add_u32 v165, s55, 10, v49                           ; d64600a5 04c51437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_mul_f32 v125, v7, v29 :: v_dual_mul_f32 v124, v6, v28 ; c8c63b07 7d7c3906
	v_cvt_pk_f32_fp8_e32 v[6:7], v167                           ; 7e0cdda7
	v_dual_mul_f32 v127, v7, v31 :: v_dual_mul_f32 v126, v6, v30 ; c8c63f07 7f7e3d06
	ds_load_b64 v[6:7], v165 offset:8192                        ; d9d82000 060000a5
	ds_load_b64 v[28:29], v165 offset:10240                     ; d9d82800 1c0000a5
	ds_load_b64 v[30:31], v165 offset:12288                     ; d9d83000 1e0000a5
	ds_load_b64 v[36:37], v165 offset:14336                     ; d9d83800 240000a5
	ds_load_b64 v[38:39], v165 offset:8448                      ; d9d82100 260000a5
	ds_load_b64 v[50:51], v165 offset:10496                     ; d9d82900 320000a5
	buffer_load_b128 v[128:131], v164, s[36:39], null offen offset:4096 ; c405c07c 40804880 001000a4
	ds_load_b64 v[72:73], v165 offset:12544                     ; d9d83100 480000a5
	ds_load_b64 v[132:133], v165 offset:14592                   ; d9d83900 840000a5
	ds_load_b64 v[134:135], v165 offset:8704                    ; d9d82200 860000a5
	ds_load_b64 v[136:137], v165 offset:10752                   ; d9d82a00 880000a5
	ds_load_b64 v[140:141], v165 offset:12800                   ; d9d83200 8c0000a5
	ds_load_b64 v[142:143], v165 offset:14848                   ; d9d83a00 8e0000a5
	buffer_load_b128 v[144:147], v164, s[36:39], null offen offset:512 ; c405c07c 40804890 000200a4
	ds_load_b64 v[148:149], v165 offset:8960                    ; d9d82300 940000a5
	ds_load_b64 v[150:151], v165 offset:11008                   ; d9d82b00 960000a5
	ds_load_b64 v[152:153], v165 offset:13056                   ; d9d83300 980000a5
	ds_load_b64 v[154:155], v165 offset:15104                   ; d9d83b00 9a0000a5
	buffer_load_b128 v[168:171], v164, s[36:39], null offen offset:4608 ; c405c07c 408048a8 001200a4
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[6:7], v[56:63] ; cc464038 1ce20d18
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[6:7], v[96:103] ; cc464060 1d820d1a
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[28:29], v[104:111] ; cc464068 1da2391a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[28:29], v[64:71] ; cc464040 1d023918
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[30:31], v[80:87] ; cc464050 1d423d18
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[30:31], v[112:119] ; cc464070 1dc23d1a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[36:37], v[88:95] ; cc464058 1d624918
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[36:37], v[120:127] ; cc464078 1de2491a
	ds_load_b64 v[6:7], v165 offset:9216                        ; d9d82400 060000a5
	ds_load_b64 v[24:25], v165 offset:11264                     ; d9d82c00 180000a5
	ds_load_b64 v[26:27], v165 offset:13312                     ; d9d83400 1a0000a5
	ds_load_b64 v[28:29], v165 offset:15360                     ; d9d83c00 1c0000a5
	s_wait_loadcnt_dscnt 0xb0f                                  ; bfc80b0f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[40:41], v[38:39], v[56:63] ; cc464038 1ce24d28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[38:39], v[96:103] ; cc464060 1d824d2a
	buffer_load_b128 v[36:39], v164, s[36:39], null offen offset:1024 ; c405c07c 40804824 000400a4
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[50:51], v[104:111] ; cc464068 1da2652a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[40:41], v[50:51], v[64:71] ; cc464040 1d026528
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[72:73], v[80:87] ; cc464050 1d429128
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[72:73], v[112:119] ; cc464070 1dc2912a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[132:133], v[88:95] ; cc464058 1d630928
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[132:133], v[120:127] ; cc464078 1de3092a
	ds_load_b64 v[30:31], v165 offset:9472                      ; d9d82500 1e0000a5
	ds_load_b64 v[40:41], v165 offset:11520                     ; d9d82d00 280000a5
	ds_load_b64 v[42:43], v165 offset:13568                     ; d9d83500 2a0000a5
	ds_load_b64 v[50:51], v165 offset:15616                     ; d9d83d00 320000a5
	buffer_load_b128 v[172:175], v164, s[36:39], null offen offset:5120 ; c405c07c 408048ac 001400a4
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[12:13], v[134:135], v[56:63] ; cc464038 1ce30d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[14:15], v[134:135], v[96:103] ; cc464060 1d830d0e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[136:137], v[104:111] ; cc464068 1da3110e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[12:13], v[136:137], v[64:71] ; cc464040 1d03110c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[140:141], v[80:87] ; cc464050 1d43190c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[140:141], v[112:119] ; cc464070 1dc3190e
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[142:143], v[88:95] ; cc464058 1d631d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[142:143], v[120:127] ; cc464078 1de31d0e
	ds_load_b64 v[12:13], v165 offset:9728                      ; d9d82600 0c0000a5
	ds_load_b64 v[14:15], v165 offset:11776                     ; d9d82e00 0e0000a5
	ds_load_b64 v[72:73], v165 offset:13824                     ; d9d83600 480000a5
	ds_load_b64 v[132:133], v165 offset:15872                   ; d9d83e00 840000a5
	buffer_load_b128 v[140:143], v164, s[36:39], null offen offset:1536 ; c405c07c 4080488c 000600a4
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[32:33], v[148:149], v[56:63] ; cc464038 1ce32920
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[148:149], v[96:103] ; cc464060 1d832922
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[34:35], v[150:151], v[104:111] ; cc464068 1da32d22
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[32:33], v[150:151], v[64:71] ; cc464040 1d032d20
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[152:153], v[80:87] ; cc464050 1d433120
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[152:153], v[112:119] ; cc464070 1dc33122
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[154:155], v[88:95] ; cc464058 1d633520
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[154:155], v[120:127] ; cc464078 1de33522
	ds_load_b64 v[32:33], v165 offset:9984                      ; d9d82700 200000a5
	ds_load_b64 v[34:35], v165 offset:12032                     ; d9d82f00 220000a5
	ds_load_b64 v[134:135], v165 offset:14080                   ; d9d83700 860000a5
	ds_load_b64 v[136:137], v165 offset:16128                   ; d9d83f00 880000a5
	s_wait_loadcnt_dscnt 0xb0f                                  ; bfc80b0f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[6:7], v[56:63] ; cc464038 1ce20d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[6:7], v[96:103] ; cc464060 1d820d2e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[24:25], v[104:111] ; cc464068 1da2312e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[44:45], v[24:25], v[64:71] ; cc464040 1d02312c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[26:27], v[80:87] ; cc464050 1d42352c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[26:27], v[112:119] ; cc464070 1dc2352e
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[28:29], v[88:95] ; cc464058 1d62392c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[28:29], v[120:127] ; cc464078 1de2392e
	s_wait_loadcnt_dscnt 0xa0b                                  ; bfc80a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[52:53], v[30:31], v[56:63] ; cc464038 1ce23d34
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[54:55], v[30:31], v[96:103] ; cc464060 1d823d36
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[54:55], v[40:41], v[104:111] ; cc464068 1da25136
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[52:53], v[40:41], v[64:71] ; cc464040 1d025134
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[52:53], v[42:43], v[80:87] ; cc464050 1d425534
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[42:43], v[112:119] ; cc464070 1dc25536
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[50:51], v[88:95] ; cc464058 1d626534
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[50:51], v[120:127] ; cc464078 1de26536
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[20:21], v[12:13], v[56:63] ; cc464038 1ce21914
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[22:23], v[12:13], v[96:103] ; cc464060 1d821916
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[14:15], v[104:111] ; cc464068 1da21d16
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[14:15], v[64:71] ; cc464040 1d021d14
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[72:73], v[80:87] ; cc464050 1d429114
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[72:73], v[112:119] ; cc464070 1dc29116
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[132:133], v[88:95] ; cc464058 1d630914
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[132:133], v[120:127] ; cc464078 1de30916
	s_wait_loadcnt_dscnt 0x803                                  ; bfc80803
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[16:17], v[32:33], v[56:63] ; cc464038 1ce24110
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[18:19], v[32:33], v[96:103] ; cc464060 1d824112
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[34:35], v[104:111] ; cc464068 1da24512
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[16:17], v[34:35], v[64:71] ; cc464040 1d024510
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[134:135], v[80:87] ; cc464050 1d430d10
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[134:135], v[112:119] ; cc464070 1dc30d12
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[136:137], v[88:95] ; cc464058 1d631110
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[136:137], v[120:127] ; cc464078 1de31112
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v76, v[6:7], v[18:19] offset1:32         ; d9382000 0012064c
	ds_store_2addr_b64 v77, v[12:13], v[20:21] offset1:32       ; d9382000 00140c4d
	ds_store_2addr_b64 v78, v[14:15], v[22:23] offset1:32       ; d9382000 00160e4e
	ds_store_2addr_b64 v79, v[16:17], v[24:25] offset1:32       ; d9382000 0018104f
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_lshl_add_u32 v166, s55, 11, v49                           ; d64600a6 04c51637
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[6:7], v166                                    ; d9d80000 060000a6
	ds_load_b64 v[12:13], v166 offset:2048                      ; d9d80800 0c0000a6
	ds_load_b64 v[14:15], v166 offset:4096                      ; d9d81000 0e0000a6
	ds_load_b64 v[16:17], v166 offset:6144                      ; d9d81800 100000a6
	ds_load_b64 v[18:19], v166 offset:256                       ; d9d80100 120000a6
	ds_load_b64 v[20:21], v166 offset:2304                      ; d9d80900 140000a6
	ds_load_b64 v[22:23], v166 offset:4352                      ; d9d81100 160000a6
	ds_load_b64 v[24:25], v166 offset:6400                      ; d9d81900 180000a6
	s_wait_loadcnt_dscnt 0x607                                  ; bfc80607
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[8:9], v[6:7], 0     ; cc464028 1a020d08
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[10:11], v[6:7], 0   ; cc464058 1a020d0a
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[8:9], v[12:13], 0   ; cc464038 1a021908
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[10:11], v[12:13], 0 ; cc464060 1a02190a
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[14:15], 0 ; cc464068 1a021d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[14:15], 0   ; cc464040 1a021d08
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[16:17], 0 ; cc464070 1a02210a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[16:17], 0   ; cc464050 1a022108
	ds_load_b64 v[8:9], v166 offset:512                         ; d9d80200 080000a6
	ds_load_b64 v[10:11], v166 offset:2560                      ; d9d80a00 0a0000a6
	ds_load_b64 v[26:27], v166 offset:4608                      ; d9d81200 1a0000a6
	ds_load_b64 v[28:29], v166 offset:6656                      ; d9d81a00 1c0000a6
	v_mov_b32_e32 v30, v139                                     ; 7e3c038b
	v_dual_mov_b32 v32, v49 :: v_dual_mov_b32 v31, v48          ; ca100131 201e0130
	v_dual_mov_b32 v34, v75 :: v_dual_mov_b32 v33, v74          ; ca10014b 2220014a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[128:129], v[14:15], 0 ; cc4640b8 1a021d80
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[130:131], v[14:15], 0 ; cc464048 1a021d82
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[128:129], v[6:7], 0 ; cc464078 1a020d80
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[128:129], v[12:13], 0 ; cc4640b0 1a021980
	v_wmma_f32_16x16x16_fp8_fp8 v[148:155], v[128:129], v[16:17], 0 ; cc464094 1a022180
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[130:131], v[6:7], 0 ; cc464084 1a020d82
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[130:131], v[12:13], 0 ; cc464030 1a021982
	s_wait_loadcnt_dscnt 0x407                                  ; bfc80407
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[144:145], v[18:19], v[40:47] ; cc464028 1ca22590
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[144:145], v[20:21], v[56:63] ; cc464038 1ce22990
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[144:145], v[22:23], v[64:71] ; cc464040 1d022d90
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[146:147], v[18:19], v[88:95] ; cc464058 1d622592
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[146:147], v[20:21], v[96:103] ; cc464060 1d822992
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[144:145], v[24:25], v[80:87] ; cc464050 1d423190
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[146:147], v[22:23], v[104:111] ; cc464068 1da22d92
	s_wait_dscnt 0x3                                            ; bfc60003
	v_dual_mov_b32 v14, v8 :: v_dual_mov_b32 v15, v9            ; ca100108 0e0e0109
	s_wait_dscnt 0x2                                            ; bfc60002
	v_dual_mov_b32 v128, v10 :: v_dual_mov_b32 v129, v11        ; ca10010a 8080010b
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[130:131], v[16:17], 0 ; cc464006 1a022182
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[146:147], v[24:25], v[112:119] ; cc464070 1dc23192
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[168:169], v[18:19], v[120:127] ; cc464078 1de225a8
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[168:169], v[20:21], v[176:183] ; cc4640b0 1ec229a8
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[168:169], v[22:23], v[184:191] ; cc4640b8 1ee22da8
	v_wmma_f32_16x16x16_fp8_fp8 v[148:155], v[168:169], v[24:25], v[148:155] ; cc464094 1e5231a8
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[170:171], v[18:19], v[132:139] ; cc464084 1e1225aa
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[170:171], v[20:21], v[48:55] ; cc464030 1cc229aa
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[170:171], v[22:23], v[72:79] ; cc464048 1d222daa
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[170:171], v[24:25], v[6:13] ; cc464006 1c1a31aa
	ds_load_b64 v[16:17], v166 offset:768                       ; d9d80300 100000a6
	ds_load_b64 v[130:131], v166 offset:2816                    ; d9d80b00 820000a6
	ds_load_b64 v[144:145], v166 offset:4864                    ; d9d81300 900000a6
	ds_load_b64 v[146:147], v166 offset:6912                    ; d9d81b00 920000a6
	ds_load_b64 v[18:19], v166 offset:1024                      ; d9d80400 120000a6
	ds_load_b64 v[20:21], v166 offset:3072                      ; d9d80c00 140000a6
	ds_load_b64 v[22:23], v166 offset:5120                      ; d9d81400 160000a6
	ds_load_b64 v[24:25], v166 offset:7168                      ; d9d81c00 180000a6
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[36:37], v[14:15], v[40:47] ; cc464028 1ca21d24
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[36:37], v[128:129], v[56:63] ; cc464038 1ce30124
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[36:37], v[26:27], v[64:71] ; cc464040 1d023524
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[28:29], v[80:87] ; cc464050 1d423924
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[38:39], v[14:15], v[88:95] ; cc464058 1d621d26
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[128:129], v[96:103] ; cc464060 1d830126
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[26:27], v[104:111] ; cc464068 1da23526
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[28:29], v[112:119] ; cc464070 1dc23926
	v_mov_b32_e32 v35, v158                                     ; 7e46039e
	v_mov_b32_e32 v167, v159                                    ; 7f4e039f
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[36:39], v164, s[36:39], null offen offset:5632 ; c405c07c 40804824 001600a4
	buffer_load_b128 v[168:171], v164, s[36:39], null offen offset:2048 ; c405c07c 408048a8 000800a4
	buffer_load_b128 v[156:159], v164, s[36:39], null offen offset:6144 ; c405c07c 4080489c 001800a4
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[172:173], v[14:15], v[120:127] ; cc464078 1de21dac
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[128:129], v[176:183] ; cc4640b0 1ec301ac
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[172:173], v[26:27], v[184:191] ; cc4640b8 1ee235ac
	v_wmma_f32_16x16x16_fp8_fp8 v[148:155], v[172:173], v[28:29], v[148:155] ; cc464094 1e5239ac
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[174:175], v[14:15], v[132:139] ; cc464084 1e121dae
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[174:175], v[128:129], v[48:55] ; cc464030 1cc301ae
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[174:175], v[26:27], v[72:79] ; cc464048 1d2235ae
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[174:175], v[28:29], v[6:13] ; cc464006 1c1a39ae
	ds_load_b64 v[14:15], v166 offset:1280                      ; d9d80500 0e0000a6
	ds_load_b64 v[128:129], v166 offset:3328                    ; d9d80d00 800000a6
	ds_load_b64 v[26:27], v166 offset:5376                      ; d9d81500 1a0000a6
	ds_load_b64 v[28:29], v166 offset:7424                      ; d9d81d00 1c0000a6
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[140:141], v[16:17], v[40:47] ; cc464028 1ca2218c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[140:141], v[130:131], v[56:63] ; cc464038 1ce3058c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[140:141], v[144:145], v[64:71] ; cc464040 1d03218c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[140:141], v[146:147], v[80:87] ; cc464050 1d43258c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[142:143], v[16:17], v[88:95] ; cc464058 1d62218e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[142:143], v[130:131], v[96:103] ; cc464060 1d83058e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[142:143], v[144:145], v[104:111] ; cc464068 1da3218e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[142:143], v[146:147], v[112:119] ; cc464070 1dc3258e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[140:143], v164, s[36:39], null offen offset:2560 ; c405c07c 4080488c 000a00a4
	buffer_load_b128 v[172:175], v164, s[36:39], null offen offset:6656 ; c405c07c 408048ac 001a00a4
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[36:37], v[130:131], v[176:183] ; cc4640b0 1ec30524
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[16:17], v[120:127] ; cc464078 1de22124
	v_wmma_f32_16x16x16_fp8_fp8 v[148:155], v[36:37], v[146:147], v[148:155] ; cc464094 1e532524
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[38:39], v[146:147], v[6:13] ; cc464006 1c1b2526
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[36:37], v[144:145], v[184:191] ; cc4640b8 1ee32124
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[38:39], v[16:17], v[132:139] ; cc464084 1e122126
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[38:39], v[130:131], v[48:55] ; cc464030 1cc30526
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[38:39], v[144:145], v[72:79] ; cc464048 1d232126
	ds_load_b64 v[16:17], v166 offset:1536                      ; d9d80600 100000a6
	ds_load_b64 v[36:37], v166 offset:3584                      ; d9d80e00 240000a6
	ds_load_b64 v[130:131], v166 offset:5632                    ; d9d81600 820000a6
	ds_load_b64 v[38:39], v166 offset:7680                      ; d9d81e00 260000a6
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[168:169], v[20:21], v[56:63] ; cc464038 1ce229a8
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[168:169], v[22:23], v[64:71] ; cc464040 1d022da8
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[168:169], v[24:25], v[80:87] ; cc464050 1d4231a8
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[168:169], v[18:19], v[40:47] ; cc464028 1ca225a8
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[170:171], v[18:19], v[88:95] ; cc464058 1d6225aa
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[170:171], v[20:21], v[96:103] ; cc464060 1d8229aa
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[170:171], v[22:23], v[104:111] ; cc464068 1da22daa
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[24:25], v[112:119] ; cc464070 1dc231aa
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[144:147], v164, s[36:39], null offen offset:3072 ; c405c07c 40804890 000c00a4
	buffer_load_b128 v[168:171], v164, s[36:39], null offen offset:7168 ; c405c07c 408048a8 001c00a4
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[156:157], v[18:19], v[120:127] ; cc464078 1de2259c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[156:157], v[20:21], v[176:183] ; cc4640b0 1ec2299c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[156:157], v[22:23], v[184:191] ; cc4640b8 1ee22d9c
	v_wmma_f32_16x16x16_fp8_fp8 v[148:155], v[156:157], v[24:25], v[148:155] ; cc464094 1e52319c
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[158:159], v[18:19], v[132:139] ; cc464084 1e12259e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[158:159], v[20:21], v[48:55] ; cc464030 1cc2299e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[158:159], v[22:23], v[72:79] ; cc464048 1d222d9e
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[158:159], v[24:25], v[6:13] ; cc464006 1c1a319e
	ds_load_b64 v[18:19], v166 offset:1792                      ; d9d80700 120000a6
	ds_load_b64 v[20:21], v166 offset:3840                      ; d9d80f00 140000a6
	ds_load_b64 v[22:23], v166 offset:5888                      ; d9d81700 160000a6
	ds_load_b64 v[24:25], v166 offset:7936                      ; d9d81f00 180000a6
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[140:141], v[14:15], v[40:47] ; cc464028 1ca21d8c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[140:141], v[128:129], v[56:63] ; cc464038 1ce3018c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[140:141], v[26:27], v[64:71] ; cc464040 1d02358c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[140:141], v[28:29], v[80:87] ; cc464050 1d42398c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[142:143], v[14:15], v[88:95] ; cc464058 1d621d8e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[142:143], v[128:129], v[96:103] ; cc464060 1d83018e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[142:143], v[26:27], v[104:111] ; cc464068 1da2358e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[142:143], v[28:29], v[112:119] ; cc464070 1dc2398e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[140:143], v164, s[36:39], null offen offset:3584 ; c405c07c 4080488c 000e00a4
	buffer_load_b128 v[156:159], v164, s[36:39], null offen offset:7680 ; c405c07c 4080489c 001e00a4
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[172:173], v[14:15], v[120:127] ; cc464078 1de21dac
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[128:129], v[176:183] ; cc4640b0 1ec301ac
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[172:173], v[26:27], v[184:191] ; cc4640b8 1ee235ac
	v_wmma_f32_16x16x16_fp8_fp8 v[148:155], v[172:173], v[28:29], v[148:155] ; cc464094 1e5239ac
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[174:175], v[14:15], v[132:139] ; cc464084 1e121dae
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[174:175], v[128:129], v[48:55] ; cc464030 1cc301ae
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[174:175], v[26:27], v[72:79] ; cc464048 1d2235ae
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[174:175], v[28:29], v[6:13] ; cc464006 1c1a39ae
	v_mad_u32_u24 v32, s55, 0x820, v32                          ; d60b0020 0481fe37 00000820
	ds_load_b64 v[14:15], v32                                   ; d9d80000 0e000020
	ds_load_b64 v[26:27], v32 offset:2048                       ; d9d80800 1a000020
	ds_load_b64 v[28:29], v32 offset:4096                       ; d9d81000 1c000020
	ds_load_b64 v[128:129], v32 offset:6144                     ; d9d81800 80000020
	buffer_load_b128 v[172:175], v164, s[36:39], null offen offset:8192 ; c405c07c 408048ac 002000a4
	s_wait_loadcnt_dscnt 0x408                                  ; bfc80408
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[144:145], v[38:39], v[80:87] ; cc464050 1d424d90
	s_mov_b32 s57, 0x76543210                                   ; beb900ff 76543210
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[146:147], v[16:17], v[88:95] ; cc464058 1d622192
	s_mov_b32 s58, 0xfedcba98                                   ; beba00ff fedcba98
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[146:147], v[36:37], v[96:103] ; cc464060 1d824992
	s_movk_i32 s59, 0x410                                       ; b03b0410
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[144:145], v[36:37], v[56:63] ; cc464038 1ce24990
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[146:147], v[130:131], v[104:111] ; cc464068 1da30592
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[144:145], v[16:17], v[40:47] ; cc464028 1ca22190
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[146:147], v[38:39], v[112:119] ; cc464070 1dc24d92
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[144:145], v[130:131], v[64:71] ; cc464040 1d030590
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[168:169], v[36:37], v[176:183] ; cc4640b0 1ec249a8
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[168:169], v[16:17], v[120:127] ; cc464078 1de221a8
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[170:171], v[16:17], v[132:139] ; cc464084 1e1221aa
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[170:171], v[36:37], v[48:55] ; cc464030 1cc249aa
	ds_load_b64 v[144:145], v32 offset:256                      ; d9d80100 90000020
	ds_load_b64 v[146:147], v32 offset:2304                     ; d9d80900 92000020
	ds_load_b64 v[16:17], v32 offset:4352                       ; d9d81100 10000020
	ds_load_b64 v[36:37], v32 offset:6400                       ; d9d81900 24000020
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[168:169], v[130:131], v[184:191] ; cc4640b8 1ee305a8
	v_wmma_f32_16x16x16_fp8_fp8 v[148:155], v[168:169], v[38:39], v[148:155] ; cc464094 1e524da8
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[170:171], v[130:131], v[72:79] ; cc464048 1d2305aa
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[170:171], v[38:39], v[6:13] ; cc464006 1c1a4daa
	buffer_load_b128 v[168:171], v164, s[36:39], null offen offset:8704 ; c405c07c 408048a8 002200a4
	ds_load_b64 v[38:39], v32 offset:512                        ; d9d80200 26000020
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[140:141], v[20:21], v[56:63] ; cc464038 1ce2298c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[142:143], v[20:21], v[96:103] ; cc464060 1d82298e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[142:143], v[18:19], v[88:95] ; cc464058 1d62258e
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[140:141], v[18:19], v[40:47] ; cc464028 1ca2258c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[140:141], v[22:23], v[64:71] ; cc464040 1d022d8c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[140:141], v[24:25], v[80:87] ; cc464050 1d42318c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[142:143], v[22:23], v[104:111] ; cc464068 1da22d8e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[142:143], v[24:25], v[112:119] ; cc464070 1dc2318e
	v_dual_mul_f32 v131, v91, v91 :: v_dual_mul_f32 v130, v89, v89 ; c8c6b75b 8382b359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v131, v43, v43 :: v_dual_fmac_f32 v130, v41, v41 ; c800572b 83825329
	v_dual_fmac_f32 v131, v47, v47 :: v_dual_fmac_f32 v130, v45, v45 ; c8005f2f 83825b2d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v131, v95, v95 :: v_dual_fmac_f32 v130, v93, v93 ; c800bf5f 8382bb5d
	v_dual_fmac_f32 v131, v42, v42 :: v_dual_fmac_f32 v130, v40, v40 ; c800552a 83825128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v131, v90, v90 :: v_dual_fmac_f32 v130, v88, v88 ; c800b55a 8382b158
	v_dual_fmac_f32 v131, v46, v46 :: v_dual_fmac_f32 v130, v44, v44 ; c8005d2e 8382592c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v131, v94, v94 :: v_dual_fmac_f32 v130, v92, v92 ; c800bd5e 8382b95c
	v_fma_mixlo_f16 v140, 1.0, v130, v131                       ; cc21008c 060f04f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; d5eb008d
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                    ; 0201018c
	v_dual_mul_f32 v166, v99, v99 :: v_dual_mul_f32 v143, v97, v97 ; c8c6c763 a68ec361
	v_permlanex16_b32 v141, v141, s57, s58 op_sel:[1,1]         ; d65c188d 00e8738d
	v_dual_fmac_f32 v166, v59, v59 :: v_dual_fmac_f32 v143, v57, v57 ; c800773b a68e7339
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d532008c
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_fmac_f32 v166, v63, v63 :: v_dual_fmac_f32 v143, v61, v61 ; c8007f3f a68e7b3d
(invalid instruction)                                        ; d531008c
	v_cndmask_b32_e32 v1, s59, v140, vcc_lo                     ; 0203183b
	v_dual_fmac_f32 v166, v103, v103 :: v_dual_fmac_f32 v143, v101, v101 ; c800cf67 a68ecb65
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d58b008e
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                    ; 0201018c
	v_dual_fmac_f32 v166, v58, v58 :: v_dual_fmac_f32 v143, v56, v56 ; c800753a a68e7138
	v_rsq_f32_e32 v142, v142                                    ; 7f1c5d8e
	v_dual_fmac_f32 v166, v98, v98 :: v_dual_fmac_f32 v143, v96, v96 ; c800c562 a68ec160
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870125
	v_mul_f32_e32 v142, v142, v163                              ; 111d478e
	v_dual_fmac_f32 v166, v62, v62 :: v_dual_fmac_f32 v143, v60, v60 ; c8007d3e a68e793c
	v_dual_mul_f32 v90, v90, v142 :: v_dual_mul_f32 v91, v91, v142 ; c8c71d5a 5a5b1d5b
	v_dual_mul_f32 v92, v92, v142 :: v_dual_mul_f32 v93, v93, v142 ; c8c71d5c 5c5d1d5d
	v_dual_mul_f32 v95, v95, v142 :: v_dual_mul_f32 v94, v94, v142 ; c8c71d5f 5f5f1d5e
	v_dual_mul_f32 v45, v45, v142 :: v_dual_mul_f32 v44, v44, v142 ; c8c71d2d 2d2d1d2c
	v_dual_mul_f32 v88, v88, v142 :: v_dual_mul_f32 v89, v89, v142 ; c8c71d58 58591d59
	v_dual_mul_f32 v47, v47, v142 :: v_dual_mul_f32 v46, v46, v142 ; c8c71d2f 2f2f1d2e
	v_dual_mul_f32 v41, v41, v142 :: v_dual_mul_f32 v40, v40, v142 ; c8c71d29 29291d28
	v_dual_mul_f32 v43, v43, v142 :: v_dual_mul_f32 v42, v42, v142 ; c8c71d2b 2b2b1d2a
	v_dual_fmac_f32 v166, v102, v102 :: v_dual_fmac_f32 v143, v100, v100 ; c800cd66 a68ec964
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_fma_mixlo_f16 v44, 1.0, v143, v166                        ; cc21002c 069b1ef2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v45, v44                                  ; 7e5ad72c
	v_permlanex16_b32 v45, v45, s57, s58 op_sel:[1,1]           ; d65c182d 00e8732d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v44, v44, v45                                 ; 64585b2c
	v_max_num_f16_e32 v44, s59, v44                             ; 6258583b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v46, v44                                  ; 7e5c172c
	v_rsq_f32_e32 v46, v46                                      ; 7e5c5d2e
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v46, v46, v163                                ; 105d472e
	v_dual_mul_f32 v56, v56, v46 :: v_dual_mul_f32 v57, v57, v46 ; c8c65d38 38385d39
	v_dual_mul_f32 v96, v96, v46 :: v_dual_mul_f32 v97, v97, v46 ; c8c65d60 60605d61
	v_dual_mul_f32 v98, v98, v46 :: v_dual_mul_f32 v99, v99, v46 ; c8c65d62 62625d63
	v_dual_mul_f32 v63, v63, v46 :: v_dual_mul_f32 v62, v62, v46 ; c8c65d3f 3f3e5d3e
	v_dual_mul_f32 v58, v58, v46 :: v_dual_mul_f32 v59, v59, v46 ; c8c65d3a 3a3a5d3b
	v_dual_mul_f32 v60, v60, v46 :: v_dual_mul_f32 v61, v61, v46 ; c8c65d3c 3c3c5d3d
	v_dual_mul_f32 v100, v100, v46 :: v_dual_mul_f32 v101, v101, v46 ; c8c65d64 64645d65
	v_dual_mul_f32 v103, v103, v46 :: v_dual_mul_f32 v102, v102, v46 ; c8c65d67 67665d66
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	v_dual_mul_f32 v47, v105, v105 :: v_dual_mul_f32 v58, v107, v107 ; c8c6d369 2f3ad76b
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_fmac_f32 v58, v67, v67 :: v_dual_fmac_f32 v47, v65, v65 ; c8008743 3a2e8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v58, v71, v71 :: v_dual_fmac_f32 v47, v69, v69 ; c8008f47 3a2e8b45
	v_dual_fmac_f32 v58, v111, v111 :: v_dual_fmac_f32 v47, v109, v109 ; c800df6f 3a2edb6d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v58, v66, v66 :: v_dual_fmac_f32 v47, v64, v64 ; c8008542 3a2e8140
	v_dual_fmac_f32 v58, v106, v106 :: v_dual_fmac_f32 v47, v104, v104 ; c800d56a 3a2ed168
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v58, v70, v70 :: v_dual_fmac_f32 v47, v68, v68 ; c8008d46 3a2e8944
	v_dual_fmac_f32 v58, v110, v110 :: v_dual_fmac_f32 v47, v108, v108 ; c800dd6e 3a2ed96c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v59, 1.0, v47, v58                          ; cc21003b 04ea5ef2
	v_cvt_u32_u16_e32 v60, v59                                  ; 7e78d73b
	v_dual_mul_f32 v63, v115, v115 :: v_dual_mul_f32 v62, v113, v113 ; c8c6e773 3f3ee371
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_permlanex16_b32 v60, v60, s57, s58 op_sel:[1,1]           ; d65c183c 00e8733c
	v_dual_fmac_f32 v63, v83, v83 :: v_dual_fmac_f32 v62, v81, v81 ; c800a753 3f3ea351
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[156:157], v[18:19], v[120:127] ; cc464078 1de2259c
	v_add_f16_e32 v59, v59, v60                                 ; 6476793b
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[156:157], v[20:21], v[176:183] ; cc4640b0 1ec2299c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[156:157], v[22:23], v[184:191] ; cc4640b8 1ee22d9c
	v_max_num_f16_e32 v59, s59, v59                             ; 6276763b
	v_wmma_f32_16x16x16_fp8_fp8 v[148:155], v[156:157], v[24:25], v[148:155] ; cc464094 1e52319c
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[158:159], v[18:19], v[132:139] ; cc464084 1e12259e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[158:159], v[20:21], v[48:55] ; cc464030 1cc2299e
	v_cvt_f32_f16_e32 v61, v59                                  ; 7e7a173b
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[158:159], v[22:23], v[72:79] ; cc464048 1d222d9e
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[158:159], v[24:25], v[6:13] ; cc464006 1c1a319e
	v_dual_fmac_f32 v63, v87, v87 :: v_dual_fmac_f32 v62, v85, v85 ; c800af57 3f3eab55
	v_rsq_f32_e32 v61, v61                                      ; 7e7a5d3d
	v_dual_fmac_f32 v63, v119, v119 :: v_dual_fmac_f32 v62, v117, v117 ; c800ef77 3f3eeb75
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmac_f32 v63, v82, v82 :: v_dual_fmac_f32 v62, v80, v80 ; c800a552 3f3ea150
	v_mul_f32_e32 v61, v61, v163                                ; 107b473d
	v_dual_fmac_f32 v63, v114, v114 :: v_dual_fmac_f32 v62, v112, v112 ; c800e572 3f3ee170
	v_dual_mul_f32 v71, v71, v61 :: v_dual_mul_f32 v70, v70, v61 ; c8c67b47 47467b46
	v_dual_mul_f32 v105, v105, v61 :: v_dual_mul_f32 v104, v104, v61 ; c8c67b69 69687b68
	v_dual_mul_f32 v107, v107, v61 :: v_dual_mul_f32 v106, v106, v61 ; c8c67b6b 6b6a7b6a
	v_dual_mul_f32 v109, v109, v61 :: v_dual_mul_f32 v108, v108, v61 ; c8c67b6d 6d6c7b6c
	v_dual_mul_f32 v66, v66, v61 :: v_dual_mul_f32 v67, v67, v61 ; c8c67b42 42427b43
	v_dual_mul_f32 v64, v64, v61 :: v_dual_mul_f32 v65, v65, v61 ; c8c67b40 40407b41
	v_dual_mul_f32 v68, v68, v61 :: v_dual_mul_f32 v69, v69, v61 ; c8c67b44 44447b45
	v_dual_mul_f32 v111, v111, v61 :: v_dual_mul_f32 v110, v110, v61 ; c8c67b6f 6f6e7b6e
	v_dual_fmac_f32 v63, v86, v86 :: v_dual_fmac_f32 v62, v84, v84 ; c800ad56 3f3ea954
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_fmac_f32 v63, v118, v118 :: v_dual_fmac_f32 v62, v116, v116 ; c800ed76 3f3ee974
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v64, 1.0, v62, v63                          ; cc210040 04fe7cf2
	v_cvt_u32_u16_e32 v65, v64                                  ; 7e82d740
	v_dual_mul_f32 v68, v135, v135 :: v_dual_mul_f32 v67, v133, v133 ; c8c70f87 44430b85
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v65, v65, s57, s58 op_sel:[1,1]           ; d65c1841 00e87341
	v_dual_fmac_f32 v68, v123, v123 :: v_dual_fmac_f32 v67, v121, v121 ; c800f77b 4442f379
	v_add_f16_e32 v64, v64, v65                                 ; 64808340
	v_dual_fmac_f32 v68, v127, v127 :: v_dual_fmac_f32 v67, v125, v125 ; c800ff7f 4442fb7d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_max_num_f16_e32 v64, s59, v64                             ; 6280803b
	v_dual_fmac_f32 v68, v139, v139 :: v_dual_fmac_f32 v67, v137, v137 ; c801178b 44431389
	v_cvt_f32_f16_e32 v66, v64                                  ; 7e841740
	v_dual_fmac_f32 v68, v122, v122 :: v_dual_fmac_f32 v67, v120, v120 ; c800f57a 4442f178
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a2
	v_rsq_f32_e32 v66, v66                                      ; 7e845d42
	v_dual_fmac_f32 v68, v134, v134 :: v_dual_fmac_f32 v67, v132, v132 ; c8010d86 44430984
	v_mul_f32_e32 v66, v66, v163                                ; 10854742
	v_dual_fmac_f32 v68, v126, v126 :: v_dual_fmac_f32 v67, v124, v124 ; c800fd7e 4442f97c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v116, v116, v66 :: v_dual_mul_f32 v117, v117, v66 ; c8c68574 74748575
	v_dual_mul_f32 v85, v85, v66 :: v_dual_mul_f32 v84, v84, v66 ; c8c68555 55548554
	v_dual_mul_f32 v87, v87, v66 :: v_dual_mul_f32 v86, v86, v66 ; c8c68557 57568556
	v_dual_mul_f32 v119, v119, v66 :: v_dual_mul_f32 v118, v118, v66 ; c8c68577 77768576
	v_dual_mul_f32 v114, v114, v66 :: v_dual_mul_f32 v115, v115, v66 ; c8c68572 72728573
	v_dual_mul_f32 v81, v81, v66 :: v_dual_mul_f32 v80, v80, v66 ; c8c68551 51508550
	v_dual_mul_f32 v112, v112, v66 :: v_dual_mul_f32 v113, v113, v66 ; c8c68570 70708571
	v_dual_mul_f32 v83, v83, v66 :: v_dual_mul_f32 v82, v82, v66 ; c8c68553 53528552
	v_dual_fmac_f32 v68, v138, v138 :: v_dual_fmac_f32 v67, v136, v136 ; c801158a 44431188
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	buffer_load_b128 v[60:63], v164, s[36:39], null offen offset:9216 ; c405c07c 4080483c 002400a4
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_fma_mixlo_f16 v69, 1.0, v67, v68                          ; cc210045 051286f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v70, v69                                  ; 7e8cd745
	v_permlanex16_b32 v70, v70, s57, s58 op_sel:[1,1]           ; d65c1846 00e87346
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v69, v69, v70                                 ; 648a8d45
	v_max_num_f16_e32 v69, s59, v69                             ; 628a8a3b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(TRANS32_DEP_1) ; bf8702c1
	v_cvt_f32_f16_e32 v71, v69                                  ; 7e8e1745
	buffer_load_b128 v[64:67], v164, s[36:39], null offen offset:9728 ; c405c07c 40804840 002600a4
	v_mul_f32_e32 v80, v49, v49                                 ; 10a06331
	v_rsq_f32_e32 v71, v71                                      ; 7e8e5d47
	v_dual_mul_f32 v120, v120, v71 :: v_dual_mul_f32 v121, v121, v71 ; c8c68f78 78788f79
	v_dual_mul_f32 v125, v125, v71 :: v_dual_mul_f32 v124, v124, v71 ; c8c68f7d 7d7c8f7c
	v_dual_fmac_f32 v80, v177, v177 :: v_dual_mul_f32 v139, v139, v71 ; c80763b1 508a8f8b
	v_mul_f32_e32 v138, v138, v71                               ; 11148f8a
	v_dual_mul_f32 v137, v137, v71 :: v_dual_mul_f32 v136, v136, v71 ; c8c68f89 89888f88
	v_dual_mul_f32 v127, v127, v71 :: v_dual_mul_f32 v126, v126, v71 ; c8c68f7f 7f7e8f7e
	v_dual_mul_f32 v133, v133, v71 :: v_dual_mul_f32 v132, v132, v71 ; c8c68f85 85848f84
	v_dual_mul_f32 v135, v135, v71 :: v_dual_mul_f32 v134, v134, v71 ; c8c68f87 87868f86
	v_dual_mul_f32 v122, v122, v71 :: v_dual_mul_f32 v123, v123, v71 ; c8c68f7a 7a7a8f7b
	buffer_load_b128 v[68:71], v164, s[36:39], null offen offset:10240 ; c405c07c 40804844 002800a4
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_fmac_f32 v80, v181, v181 :: v_dual_mul_f32 v81, v51, v51 ; c8076bb5 50506733
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_fmac_f32 v80, v53, v53 :: v_dual_fmac_f32 v81, v179, v179 ; c8006b35 505167b3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v80, v176, v176 :: v_dual_fmac_f32 v81, v183, v183 ; c80161b0 50516fb7
	v_dual_fmac_f32 v80, v48, v48 :: v_dual_fmac_f32 v81, v55, v55 ; c8006130 50506f37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v81, v178, v178                              ; 56a365b2
	v_fmac_f32_e32 v81, v50, v50                                ; 56a26532
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v81, v182, v182 :: v_dual_fmac_f32 v80, v180, v180 ; c8016db6 515169b4
	v_dual_fmac_f32 v81, v54, v54 :: v_dual_fmac_f32 v80, v52, v52 ; c8006d36 51506934
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v82, 1.0, v80, v81                          ; cc210052 0546a0f2
	v_cvt_u32_u16_e32 v83, v82                                  ; 7ea6d752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v83, v83, s57, s58 op_sel:[1,1]           ; d65c1853 00e87353
	v_add_f16_e32 v82, v82, v83                                 ; 64a4a752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v82, s59, v82                             ; 62a4a43b
	v_cvt_f32_f16_e32 v84, v82                                  ; 7ea81752
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[80:83], v164, s[36:39], null offen offset:10752 ; c405c07c 40804850 002a00a4
	buffer_load_b128 v[88:91], v164, s[36:39], null offen offset:11264 ; c405c07c 40804858 002c00a4
	v_rsq_f32_e32 v84, v84                                      ; 7ea85d54
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_mul_f32_e32 v178, v178, v84                               ; 1164a9b2
	v_mul_f32_e32 v53, v53, v84                                 ; 106aa935
	v_dual_mul_f32 v177, v177, v84 :: v_dual_mul_f32 v176, v176, v84 ; c8c6a9b1 b1b0a9b0
	v_dual_mul_f32 v180, v180, v84 :: v_dual_mul_f32 v179, v179, v84 ; c8c6a9b4 b4b2a9b3
	v_dual_mul_f32 v182, v182, v84 :: v_dual_mul_f32 v181, v181, v84 ; c8c6a9b6 b6b4a9b5
	v_dual_mul_f32 v85, v73, v73 :: v_dual_mul_f32 v52, v52, v84 ; c8c69349 5534a934
	v_mul_f32_e32 v51, v51, v84                                 ; 1066a933
	v_mul_f32_e32 v55, v55, v84                                 ; 106ea937
	v_dual_mul_f32 v48, v48, v84 :: v_dual_mul_f32 v183, v183, v84 ; c8c6a930 30b6a9b7
	v_dual_mul_f32 v50, v50, v84 :: v_dual_mul_f32 v49, v49, v84 ; c8c6a932 3230a931
	v_dual_fmac_f32 v85, v185, v185 :: v_dual_mul_f32 v54, v54, v84 ; c80773b9 5536a936
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	buffer_load_b128 v[52:55], v164, s[36:39], null offen offset:11776 ; c405c07c 40804834 002e00a4
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	v_dual_fmac_f32 v85, v189, v189 :: v_dual_mul_f32 v92, v75, v75 ; c8077bbd 555c974b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v85, v77, v77 :: v_dual_fmac_f32 v92, v187, v187 ; c8009b4d 555d77bb
	v_fmac_f32_e32 v92, v191, v191                              ; 56b97fbf
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v92, v79, v79                                ; 56b89f4f
	v_dual_fmac_f32 v92, v186, v186 :: v_dual_fmac_f32 v85, v184, v184 ; c80175ba 5c5571b8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v92, v74, v74 :: v_dual_fmac_f32 v85, v72, v72 ; c800954a 5c549148
	v_dual_fmac_f32 v92, v190, v190 :: v_dual_fmac_f32 v85, v188, v188 ; c8017dbe 5c5579bc
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v92, v78, v78 :: v_dual_fmac_f32 v85, v76, v76 ; c8009d4e 5c54994c
	v_fma_mixlo_f16 v93, 1.0, v85, v92                          ; cc21005d 0572aaf2
	v_dual_mul_f32 v97, v9, v9 :: v_dual_mul_f32 v96, v7, v7    ; c8c61309 61600f07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_u32_u16_e32 v94, v93                                  ; 7ebcd75d
	v_dual_fmac_f32 v97, v151, v151 :: v_dual_fmac_f32 v96, v149, v149 ; c8012f97 61612b95
	v_permlanex16_b32 v94, v94, s57, s58 op_sel:[1,1]           ; d65c185e 00e8735e
	v_dual_fmac_f32 v97, v155, v155 :: v_dual_fmac_f32 v96, v153, v153 ; c801379b 61613399
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_add_f16_e32 v93, v93, v94                                 ; 64babd5d
	v_dual_fmac_f32 v97, v13, v13 :: v_dual_fmac_f32 v96, v11, v11 ; c8001b0d 6160170b
	v_max_num_f16_e32 v93, s59, v93                             ; 62baba3b
	v_dual_fmac_f32 v97, v150, v150 :: v_dual_fmac_f32 v96, v148, v148 ; c8012d96 61612994
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v95, v93                                  ; 7ebe175d
	v_dual_fmac_f32 v97, v8, v8 :: v_dual_fmac_f32 v96, v6, v6  ; c8001108 61600d06
	v_rsq_f32_e32 v95, v95                                      ; 7ebe5d5f
	v_dual_fmac_f32 v97, v154, v154 :: v_dual_fmac_f32 v96, v152, v152 ; c801359a 61613198
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v186, v186, v95 :: v_dual_mul_f32 v187, v187, v95 ; c8c6bfba bababfbb
	v_dual_mul_f32 v188, v188, v95 :: v_dual_mul_f32 v189, v189, v95 ; c8c6bfbc bcbcbfbd
	v_dual_mul_f32 v79, v79, v95 :: v_dual_mul_f32 v78, v78, v95 ; c8c6bf4f 4f4ebf4e
	v_dual_mul_f32 v184, v184, v95 :: v_dual_mul_f32 v185, v185, v95 ; c8c6bfb8 b8b8bfb9
	v_dual_mul_f32 v190, v190, v95 :: v_dual_mul_f32 v191, v191, v95 ; c8c6bfbe bebebfbf
	v_dual_mul_f32 v72, v72, v95 :: v_dual_mul_f32 v73, v73, v95 ; c8c6bf48 4848bf49
	v_dual_mul_f32 v75, v75, v95 :: v_dual_mul_f32 v74, v74, v95 ; c8c6bf4b 4b4abf4a
	v_dual_mul_f32 v77, v77, v95 :: v_dual_mul_f32 v76, v76, v95 ; c8c6bf4d 4d4cbf4c
	v_dual_fmac_f32 v97, v12, v12 :: v_dual_fmac_f32 v96, v10, v10 ; c800190c 6160150a
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	v_lshl_add_u32 v1, v1, 12, s7                               ; d6460001 001d1901
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_lshl_add_u32 v4, v4, 6, v1                                ; d6460004 04050d04
	v_add_lshl_u32 v4, v4, v3, 2                                ; d6470004 020a0704
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[76:79], v4, s[32:35], null offen         ; c405c07c 4080404c 00000004
	buffer_load_b128 v[92:95], v4, s[32:35], null offen offset:16 ; c405c07c 4080405c 00001004
	v_fma_mixlo_f16 v98, 1.0, v96, v97                          ; cc210062 0586c0f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v99, v98                                  ; 7ec6d762
	v_permlanex16_b32 v99, v99, s57, s58 op_sel:[1,1]           ; d65c1863 00e87363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v98, v98, v99                                 ; 64c4c762
	v_max_num_f16_e32 v98, s59, v98                             ; 62c4c43b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(TRANS32_DEP_1) ; bf8702d1
	v_cvt_f32_f16_e32 v100, v98                                 ; 7ec81762
	ds_load_b64 v[84:85], v32 offset:2560                       ; d9d80a00 54000020
	ds_load_b64 v[96:97], v32 offset:4608                       ; d9d81200 60000020
	ds_load_b64 v[98:99], v32 offset:6656                       ; d9d81a00 62000020
	v_rsq_f32_e32 v100, v100                                    ; 7ec85d64
	v_dual_mul_f32 v149, v149, v100 :: v_dual_mul_f32 v148, v148, v100 ; c8c6c995 9594c994
	v_dual_mul_f32 v153, v153, v100 :: v_dual_mul_f32 v152, v152, v100 ; c8c6c999 9998c998
	v_dual_mul_f32 v9, v9, v100 :: v_dual_mul_f32 v8, v8, v100  ; c8c6c909 0908c908
	v_dual_mul_f32 v11, v11, v100 :: v_dual_mul_f32 v10, v10, v100 ; c8c6c90b 0b0ac90a
	v_dual_mul_f32 v7, v7, v100 :: v_dual_mul_f32 v6, v6, v100  ; c8c6c907 0706c906
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	buffer_load_b128 v[8:11], v4, s[32:35], null offen offset:64 ; c405c07c 40804008 00004004
	v_dual_mul_f32 v13, v13, v100 :: v_dual_mul_f32 v12, v12, v100 ; c8c6c90d 0d0cc90c
	v_dual_mul_f32 v151, v151, v100 :: v_dual_mul_f32 v150, v150, v100 ; c8c6c997 9796c996
	v_dual_mul_f32 v155, v155, v100 :: v_dual_mul_f32 v154, v154, v100 ; c8c6c99b 9b9ac99a
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
	ds_load_b64 v[12:13], v32 offset:768                        ; d9d80300 0c000020
	ds_load_b64 v[100:101], v32 offset:2816                     ; d9d80b00 64000020
	ds_load_b64 v[102:103], v32 offset:4864                     ; d9d81300 66000020
	ds_load_b64 v[104:105], v32 offset:6912                     ; d9d81b00 68000020
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	s_wait_loadcnt_dscnt 0xa0f                                  ; bfc80a0f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[172:173], 0 ; cc464070 1a03590e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[14:15], v[174:175], 0 ; cc4640b0 1a035d0e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[172:173], 0 ; cc464078 1a03591a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[26:27], v[174:175], 0 ; cc4640b8 1a035d1a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_dual_mov_b32 v27, v129 :: v_dual_mov_b32 v26, v128        ; ca100181 1b1a0180
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[28:29], v[172:173], 0 ; cc464088 1a03591c
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[128:129], v[172:173], 0 ; cc464098 1a035980
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v15, v105 :: v_dual_mov_b32 v14, v104        ; ca100169 0f0e0168
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[174:175], 0 ; cc464068 1a035d1c
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[144:145], v[168:169], v[112:119] ; cc464070 1dc35190
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[144:145], v[170:171], v[176:183] ; cc4640b0 1ec35590
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[146:147], v[168:169], v[120:127] ; cc464078 1de35192
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[174:175], 0 ; cc464080 1a035d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[146:147], v[170:171], v[184:191] ; cc4640b8 1ee35592
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[16:17], v[168:169], v[136:143] ; cc464088 1e235110
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[36:37], v[168:169], v[152:159] ; cc464098 1e635124
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[170:171], v[104:111] ; cc464068 1da35510
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[36:37], v[170:171], v[128:135] ; cc464080 1e035524
	ds_load_b64 v[26:27], v32 offset:1024                       ; d9d80400 1a000020
	ds_load_b64 v[28:29], v32 offset:3072                       ; d9d80c00 1c000020
	ds_load_b64 v[148:149], v32 offset:5120                     ; d9d81400 94000020
	ds_load_b64 v[150:151], v32 offset:7168                     ; d9d81c00 96000020
	ds_load_b64 v[16:17], v32 offset:1280                       ; d9d80500 10000020
	ds_load_b64 v[36:37], v32 offset:3328                       ; d9d80d00 24000020
	ds_load_b64 v[144:145], v32 offset:5376                     ; d9d81500 90000020
	ds_load_b64 v[146:147], v32 offset:7424                     ; d9d81d00 92000020
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[60:61], v[112:119] ; cc464070 1dc27926
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[84:85], v[60:61], v[120:127] ; cc464078 1de27954
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[62:63], v[176:183] ; cc4640b0 1ec27d26
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[84:85], v[62:63], v[184:191] ; cc4640b8 1ee27d54
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[96:97], v[60:61], v[136:143] ; cc464088 1e227960
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[98:99], v[60:61], v[152:159] ; cc464098 1e627962
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[96:97], v[62:63], v[104:111] ; cc464068 1da27d60
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[98:99], v[62:63], v[128:135] ; cc464080 1e027d62
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[64:65], v[112:119] ; cc464070 1dc2810c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[100:101], v[64:65], v[120:127] ; cc464078 1de28164
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[66:67], v[176:183] ; cc4640b0 1ec2850c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[100:101], v[66:67], v[184:191] ; cc4640b8 1ee28564
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[102:103], v[64:65], v[136:143] ; cc464088 1e228166
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[14:15], v[64:65], v[152:159] ; cc464098 1e62810e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[102:103], v[66:67], v[104:111] ; cc464068 1da28566
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[66:67], v[128:135] ; cc464080 1e02850e
	ds_load_b64 v[38:39], v32 offset:1536                       ; d9d80600 26000020
	ds_load_b64 v[60:61], v32 offset:3584                       ; d9d80e00 3c000020
	ds_load_b64 v[62:63], v32 offset:5632                       ; d9d81600 3e000020
	ds_load_b64 v[84:85], v32 offset:7680                       ; d9d81e00 54000020
	ds_load_b64 v[12:13], v32 offset:1792                       ; d9d80700 0c000020
	ds_load_b64 v[14:15], v32 offset:3840                       ; d9d80f00 0e000020
	ds_load_b64 v[64:65], v32 offset:5888                       ; d9d81700 40000020
	ds_load_b64 v[66:67], v32 offset:7936                       ; d9d81f00 42000020
	v_mov_b32_e32 v1, v165                                      ; 7e0203a5
	s_clause 0x4                                                ; bf850004
	buffer_load_b128 v[96:99], v4, s[32:35], null offen offset:80 ; c405c07c 40804060 00005004
	buffer_load_b128 v[100:103], v4, s[32:35], null offen offset:128 ; c405c07c 40804064 00008004
	buffer_load_b128 v[168:171], v4, s[32:35], null offen offset:144 ; c405c07c 408040a8 00009004
	buffer_load_b128 v[172:175], v4, s[32:35], null offen offset:192 ; c405c07c 408040ac 0000c004
	buffer_load_b128 v[163:166], v4, s[32:35], null offen offset:208 ; c405c07c 408040a3 0000d004
	s_wait_loadcnt_dscnt 0xb0f                                  ; bfc80b0f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[68:69], v[112:119] ; cc464070 1dc2891a
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[68:69], v[120:127] ; cc464078 1de2891c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[148:149], v[68:69], v[136:143] ; cc464088 1e228994
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[150:151], v[68:69], v[152:159] ; cc464098 1e628996
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[26:27], v[70:71], v[176:183] ; cc4640b0 1ec28d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[28:29], v[70:71], v[184:191] ; cc4640b8 1ee28d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[148:149], v[70:71], v[104:111] ; cc464068 1da28d94
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[150:151], v[70:71], v[128:135] ; cc464080 1e028d96
	s_wait_loadcnt_dscnt 0xa0b                                  ; bfc80a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[80:81], v[112:119] ; cc464070 1dc2a110
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[80:81], v[120:127] ; cc464078 1de2a124
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[144:145], v[80:81], v[136:143] ; cc464088 1e22a190
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[146:147], v[80:81], v[152:159] ; cc464098 1e62a192
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[82:83], v[176:183] ; cc4640b0 1ec2a510
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[36:37], v[82:83], v[184:191] ; cc4640b8 1ee2a524
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[144:145], v[82:83], v[104:111] ; cc464068 1da2a590
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[146:147], v[82:83], v[128:135] ; cc464080 1e02a592
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[88:89], v[112:119] ; cc464070 1dc2b126
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[60:61], v[88:89], v[120:127] ; cc464078 1de2b13c
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[62:63], v[88:89], v[136:143] ; cc464088 1e22b13e
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[84:85], v[88:89], v[152:159] ; cc464098 1e62b154
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[90:91], v[176:183] ; cc4640b0 1ec2b526
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[60:61], v[90:91], v[184:191] ; cc4640b8 1ee2b53c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[62:63], v[90:91], v[104:111] ; cc464068 1da2b53e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[90:91], v[128:135] ; cc464080 1e02b554
	s_wait_loadcnt_dscnt 0x803                                  ; bfc80803
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[52:53], v[112:119] ; cc464070 1dc2690c
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[52:53], v[120:127] ; cc464078 1de2690e
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[64:65], v[52:53], v[136:143] ; cc464088 1e226940
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[52:53], v[152:159] ; cc464098 1e626942
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[54:55], v[176:183] ; cc4640b0 1ec26d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[14:15], v[54:55], v[184:191] ; cc4640b8 1ee26d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[64:65], v[54:55], v[104:111] ; cc464068 1da26d40
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[54:55], v[128:135] ; cc464080 1e026d42
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[40:41], 0 ; cc464040 1a025118
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[86:87], v[40:41], 0 ; cc464068 1a025156
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[40:41], 0 ; cc464070 1a025132
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[40:41], 0 ; cc464078 1a02514a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[58:59], v[42:43], v[64:71] ; cc464040 1d02553a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[42:43], v[104:111] ; cc464068 1da25530
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[72:73], v[42:43], v[112:119] ; cc464070 1dc25548
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[6:7], v[42:43], v[120:127] ; cc464078 1de25506
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v4, s[32:35], null offen offset:4096 ; c405c07c 40804028 00100004
	buffer_load_b128 v[60:63], v4, s[32:35], null offen offset:4112 ; c405c07c 4080403c 00101004
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s60, 0x3d380000                                   ; bebc00ff 3d380000
	s_movk_i32 s61, 0x3e47                                      ; b03d3e47
	s_movk_i32 s62, 0x3c20                                      ; b03e3c20
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v32, s60, v64, v76                          ; cc210020 0532803c
	v_fma_mixhi_f16 v32, s60, v65, v77                          ; cc220020 0536823c
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v55, s60, v68, v92                          ; cc210037 0572883c
	v_fma_mixhi_f16 v55, s60, v69, v93                          ; cc220037 05768a3c
	v_fma_mixlo_f16 v54, s60, v66, v78                          ; cc210036 053a843c
	v_fma_mixhi_f16 v54, s60, v67, v79                          ; cc220036 053e863c
	v_fma_mixlo_f16 v64, s60, v70, v94                          ; cc210040 057a8c3c
	v_fma_mixhi_f16 v64, s60, v71, v95                          ; cc220040 057e8e3c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v4, s[32:35], null offen offset:4160 ; c405c07c 40804044 00104004
	buffer_load_b128 v[76:79], v4, s[32:35], null offen offset:4176 ; c405c07c 4080404c 00105004
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v65, s60, v104, v8                          ; cc210041 0422d03c
	v_fma_mixhi_f16 v65, s60, v105, v9                          ; cc220041 0426d23c
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v62                               ; 0a007d20
	v_fma_mixlo_f16 v66, s60, v106, v10                         ; cc210042 042ad43c
	v_fma_mixhi_f16 v66, s60, v107, v11                         ; cc220042 042ed63c
(invalid instruction)                                        ; cc1c0037
	v_subrev_f32_e32 v0, v55, v62                               ; 0a007d37
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v67, s60, v108, v96                         ; cc210043 0582d83c
(invalid instruction)                                        ; cc1c0036
	v_subrev_f32_e32 v0, v54, v62                               ; 0a007d36
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v4, s[32:35], null offen offset:4224 ; c405c07c 40804008 00108004
	buffer_load_b128 v[88:91], v4, s[32:35], null offen offset:4240 ; c405c07c 40804058 00109004
	v_fma_mixhi_f16 v67, s60, v109, v97                         ; cc220043 0586da3c
(invalid instruction)                                        ; cc1c0040
	v_subrev_f32_e32 v0, v64, v62                               ; 0a007d40
	v_fma_mixlo_f16 v80, s60, v110, v98                         ; cc210050 058adc3c
	v_fma_mixhi_f16 v80, s60, v111, v99                         ; cc220050 058ede3c
(invalid instruction)                                        ; cc1c0041
	v_subrev_f32_e32 v0, v65, v62                               ; 0a007d41
(invalid instruction)                                        ; cc1b0020
	v_subrev_f32_e32 v0, v32, v61                               ; 0a007b20
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v62                               ; 0a007d42
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v81, s60, v112, v100                        ; cc210051 0592e03c
(invalid instruction)                                        ; cc1b0037
	v_subrev_f32_e32 v0, v55, v61                               ; 0a007b37
	v_fma_mixhi_f16 v81, s60, v113, v101                        ; cc220051 0596e23c
(invalid instruction)                                        ; cc1b0036
	v_subrev_f32_e32 v0, v54, v61                               ; 0a007b36
	v_fma_mixlo_f16 v82, s60, v114, v102                        ; cc210052 059ae43c
	v_fma_mixhi_f16 v82, s60, v115, v103                        ; cc220052 059ee63c
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v62                               ; 0a007d43
(invalid instruction)                                        ; cc1b0040
	v_subrev_f32_e32 v0, v64, v61                               ; 0a007b40
	s_mov_b32 s63, 0x7ff88000                                   ; bebf00ff 7ff88000
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v62                               ; 0a007d50
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[92:95], v4, s[32:35], null offen offset:4288 ; c405c07c 4080405c 0010c004
	buffer_load_b128 v[96:99], v4, s[32:35], null offen offset:4304 ; c405c07c 40804060 0010d004
(invalid instruction)                                        ; cc1b0041
	v_subrev_f32_e32 v0, v65, v61                               ; 0a007b41
(invalid instruction)                                        ; cc1b0042
	v_subrev_f32_e32 v0, v66, v61                               ; 0a007b42
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v84, s60, v116, v168                        ; cc210054 06a2e83c
	v_fma_mixhi_f16 v84, s60, v117, v169                        ; cc220054 06a6ea3c
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v62                               ; 0a007d51
	v_lshl_add_u32 v32, v32, 5, s63                             ; d6460020 00fd0b20
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v62                               ; 0a007d52
	v_fma_mixlo_f16 v85, s60, v118, v170                        ; cc210055 06aaec3c
(invalid instruction)                                        ; cc1b0043
	v_subrev_f32_e32 v0, v67, v61                               ; 0a007b43
	v_fma_mixhi_f16 v85, s60, v119, v171                        ; cc220055 06aeee3c
(invalid instruction)                                        ; cc1b0050
	v_subrev_f32_e32 v0, v80, v61                               ; 0a007b50
	v_lshl_add_u32 v65, v65, 5, s63                             ; d6460041 00fd0b41
	v_lshl_add_u32 v54, v54, 5, s63                             ; d6460036 00fd0b36
	v_lshl_add_u32 v66, v66, 5, s63                             ; d6460042 00fd0b42
(invalid instruction)                                        ; cc1c0054
	v_subrev_f32_e32 v0, v84, v62                               ; 0a007d54
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v101, s60, v120, v172                       ; cc210065 06b2f03c
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v61                               ; 0a007b51
	v_fma_mixhi_f16 v101, s60, v121, v173                       ; cc220065 06b6f23c
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v61                               ; 0a007b52
	v_fma_mixlo_f16 v102, s60, v122, v174                       ; cc210066 06baf43c
	v_fma_mixhi_f16 v102, s60, v123, v175                       ; cc220066 06bef63c
(invalid instruction)                                        ; cc1c0055
	v_subrev_f32_e32 v0, v85, v62                               ; 0a007d55
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[32:33], v[65:66]                ; 1a028320
(invalid instruction)                                        ; cc0f0064
	v_min_num_f64_e32 v[1:2], v[54:55], v[66:67]                ; 1a028536
(invalid instruction)                                        ; cc1b0054
	v_subrev_f32_e32 v0, v84, v61                               ; 0a007b54
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v103, s60, v124, v163                       ; cc210067 068ef83c
	v_lshl_add_u32 v81, v81, 5, s63                             ; d6460051 00fd0b51
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v62                              ; 0a007d65
	v_fma_mixhi_f16 v103, s60, v125, v164                       ; cc220067 0692fa3c
	v_lshl_add_u32 v82, v82, 5, s63                             ; d6460052 00fd0b52
(invalid instruction)                                        ; cc1c0066
	v_subrev_f32_e32 v0, v102, v62                              ; 0a007d66
	v_fma_mixlo_f16 v104, s60, v126, v165                       ; cc210068 0696fc3c
(invalid instruction)                                        ; cc1b0055
	v_subrev_f32_e32 v0, v85, v61                               ; 0a007b55
	v_fma_mixhi_f16 v104, s60, v127, v166                       ; cc220068 069afe3c
	v_lshl_add_u32 v55, v55, 5, s63                             ; d6460037 00fd0b37
	v_lshl_add_u32 v67, v67, 5, s63                             ; d6460043 00fd0b43
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[81:82]                ; 1a02a353
(invalid instruction)                                        ; cc1b0065
	v_subrev_f32_e32 v0, v101, v61                              ; 0a007b65
(invalid instruction)                                        ; cc1c0067
	v_subrev_f32_e32 v0, v103, v62                              ; 0a007d67
	v_lshl_add_u32 v84, v84, 5, s63                             ; d6460054 00fd0b54
(invalid instruction)                                        ; cc0f0064
	v_min_num_f64_e32 v[1:2], v[100:101], v[82:83]              ; 1a02a564
(invalid instruction)                                        ; cc1b0066
	v_subrev_f32_e32 v0, v102, v61                              ; 0a007b66
	v_lshl_add_u32 v64, v64, 5, s63                             ; d6460040 00fd0b40
	v_lshl_add_u32 v80, v80, 5, s63                             ; d6460050 00fd0b50
(invalid instruction)                                        ; cc1c0068
	v_subrev_f32_e32 v0, v104, v62                              ; 0a007d68
	v_lshl_add_u32 v85, v85, 5, s63                             ; d6460055 00fd0b55
(invalid instruction)                                        ; cc0f0069
	v_min_num_f64_e32 v[1:2], v[55:56], v[67:68]                ; 1a028737
	v_lshl_add_u32 v101, v101, 5, s63                           ; d6460065 00fd0b65
(invalid instruction)                                        ; cc1b0067
	v_subrev_f32_e32 v0, v103, v61                              ; 0a007b67
	v_lshl_add_u32 v102, v102, 5, s63                           ; d6460066 00fd0b66
(invalid instruction)                                        ; cc0f006a
	v_min_num_f64_e32 v[1:2], v[64:65], v[80:81]                ; 1a02a140
(invalid instruction)                                        ; cc1b0068
	v_subrev_f32_e32 v0, v104, v61                              ; 0a007b68
(invalid instruction)                                        ; cc0f0069
	v_min_num_f64_e32 v[1:2], v[105:106], v[84:85]              ; 1a02a969
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[101:102]              ; 1a02cb53
	v_lshl_add_u32 v103, v103, 5, s63                           ; d6460067 00fd0b67
(invalid instruction)                                        ; cc0f0064
	v_min_num_f64_e32 v[1:2], v[100:101], v[102:103]            ; 1a02cd64
(invalid instruction)                                        ; cc0f006a
	v_min_num_f64_e32 v[1:2], v[106:107], v[85:86]              ; 1a02ab6a
	v_lshl_add_u32 v104, v104, 5, s63                           ; d6460068 00fd0b68
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; cc0f0069
	v_min_num_f64_e32 v[1:2], v[105:106], v[103:104]            ; 1a02cf69
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[100:101]              ; 1a02c953
(invalid instruction)                                        ; cc0f006a
	v_min_num_f64_e32 v[1:2], v[106:107], v[104:105]            ; 1a02d16a
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[105:106]              ; 1a02d353
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[106:107]              ; 1a02d553
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v107, v83, s57, s58 op_sel:[1,1]          ; d65c186b 00e87353
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[107:108]              ; 1a02d753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v108, v83, v211/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64d9a753
	v_max_num_f16_e32 v108, s56, v108                           ; 62d8d838
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v109, v108                                ; 7eda176c
	v_rcp_f32_e32 v109, v109                                    ; 7eda556d
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v110, v32, v109, neg(0) op_sel_hi:[1,0,0]     ; cc20006e 8a02db20
	v_fma_mix_f32 v115, v66, v109, neg(0) op_sel_hi:[1,0,0]     ; cc200073 8a02db42
	v_fma_mix_f32 v32, v32, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a02db20
	v_fma_mix_f32 v112, v55, v109, neg(0) op_sel_hi:[1,0,0]     ; cc200070 8a02db37
	v_fma_mix_f32 v55, v55, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200837 8a02db37
	v_fma_mix_f32 v113, v64, v109, neg(0) op_sel_hi:[1,0,0]     ; cc200071 8a02db40
	v_fma_mix_f32 v64, v64, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200840 8a02db40
	v_fma_mix_f32 v114, v65, v109, neg(0) op_sel_hi:[1,0,0]     ; cc200072 8a02db41
	v_fma_mix_f32 v65, v65, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200841 8a02db41
	v_fma_mix_f32 v111, v54, v109, neg(0) op_sel_hi:[1,0,0]     ; cc20006f 8a02db36
	v_fma_mix_f32 v54, v54, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200836 8a02db36
	v_fma_mix_f32 v66, v66, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200842 8a02db42
	v_fma_mix_f32 v116, v67, v109, neg(0) op_sel_hi:[1,0,0]     ; cc200074 8a02db43
	v_fma_mix_f32 v67, v67, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200843 8a02db43
	v_fma_mix_f32 v117, v80, v109, neg(0) op_sel_hi:[1,0,0]     ; cc200075 8a02db50
	v_fma_mix_f32 v80, v80, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200850 8a02db50
(invalid instruction)                                        ; d769006a
	v_cndmask_b32_e32 v1, v110, v32, vcc_lo                     ; 0202416e
	v_fma_mix_f32 v118, v81, v109, neg(0) op_sel_hi:[1,0,0]     ; cc200076 8a02db51
(invalid instruction)                                        ; d769006b
	v_cndmask_b32_e32 v1, v112, v55, vcc_lo                     ; 02026f70
	v_fma_mix_f32 v81, v81, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200851 8a02db51
	v_fma_mix_f32 v119, v82, v109, neg(0) op_sel_hi:[1,0,0]     ; cc200077 8a02db52
(invalid instruction)                                        ; d769406b
	v_cndmask_b32_e32 v1, v113, v64, vcc_lo                     ; 02028171
	v_fma_mix_f32 v82, v82, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200852 8a02db52
	v_fma_mix_f32 v120, v84, v109, neg(0) op_sel_hi:[1,0,0]     ; cc200078 8a02db54
	v_fma_mix_f32 v84, v84, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200854 8a02db54
(invalid instruction)                                        ; d769406a
	v_cndmask_b32_e32 v1, v111, v54, vcc_lo                     ; 02026d6f
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v114, v65, vcc_lo                     ; 02028372
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v115, v66, vcc_lo                     ; 02028573
	v_fma_mix_f32 v121, v85, v109, neg(0) op_sel_hi:[1,0,0]     ; cc200079 8a02db55
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v116, v67, vcc_lo                     ; 02028774
	v_fma_mix_f32 v85, v85, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200855 8a02db55
	v_fma_mix_f32 v122, v101, v109, neg(0) op_sel_hi:[1,0,0]    ; cc20007a 8a02db65
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v117, v80, vcc_lo                     ; 0202a175
	v_fma_mix_f32 v101, v101, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200865 8a02db65
	v_fma_mix_f32 v123, v102, v109, neg(0) op_sel_hi:[1,0,0]    ; cc20007b 8a02db66
	v_fma_mix_f32 v102, v102, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200866 8a02db66
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v118, v81, vcc_lo                     ; 0202a376
	v_fma_mix_f32 v124, v103, v109, neg(0) op_sel_hi:[1,0,0]    ; cc20007c 8a02db67
	v_fma_mix_f32 v103, v103, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200867 8a02db67
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v119, v82, vcc_lo                     ; 0202a577
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v120, v84, vcc_lo                     ; 0202a978
	v_fma_mix_f32 v125, v104, v109, neg(0) op_sel_hi:[1,0,0]    ; cc20007d 8a02db68
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v122, v101, vcc_lo                    ; 0202cb7a
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v123, v102, vcc_lo                    ; 0202cd7b
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v124, v103, vcc_lo                    ; 0202cf7c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[80:83], v4, s[32:35], null offen offset:8192 ; c405c07c 40804050 00200004
	buffer_load_b128 v[100:103], v4, s[32:35], null offen offset:8208 ; c405c07c 40804064 00201004
	v_fma_mix_f32 v104, v104, v109, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200868 8a02db68
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[44:45], 0 ; cc464070 1a025918
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[44:45], 0 ; cc464080 1a025932
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[44:45], 0 ; cc464088 1a02594a
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v121, v85, vcc_lo                     ; 0202ab79
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v125, v104, vcc_lo                    ; 0202d17d
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[86:87], v[44:45], 0 ; cc464078 1a025956
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[56:57], v[112:119] ; cc464070 1dc2713a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[56:57], v[128:135] ; cc464080 1e027148
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[6:7], v[56:57], v[136:143] ; cc464088 1e227106
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[56:57], v[120:127] ; cc464078 1de27130
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v145, s60, v114, v42                        ; cc210091 04aae43c
	v_fma_mixlo_f16 v144, s60, v112, v40                        ; cc210090 04a2e03c
	v_fma_mixhi_f16 v145, s60, v115, v43                        ; cc220091 04aee63c
	v_fma_mixhi_f16 v144, s60, v113, v41                        ; cc220090 04a6e23c
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v146, s60, v116, v60                        ; cc210092 04f2e83c
	v_fma_mixlo_f16 v147, s60, v118, v62                        ; cc210093 04faec3c
	v_fma_mixhi_f16 v147, s60, v119, v63                        ; cc220093 04feee3c
	v_fma_mixhi_f16 v146, s60, v117, v61                        ; cc220092 04f6ea3c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v4, s[32:35], null offen offset:8256 ; c405c07c 40804028 00204004
	buffer_load_b128 v[60:63], v4, s[32:35], null offen offset:8272 ; c405c07c 4080403c 00205004
(invalid instruction)                                        ; cc1c0091
	v_subrev_f32_e32 v0, v145, v62                              ; 0a007d91
(invalid instruction)                                        ; cc1c0090
	v_subrev_f32_e32 v0, v144, v62                              ; 0a007d90
(invalid instruction)                                        ; cc1c0093
	v_subrev_f32_e32 v0, v147, v62                              ; 0a007d93
(invalid instruction)                                        ; cc1c0092
	v_subrev_f32_e32 v0, v146, v62                              ; 0a007d92
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b0091
	v_subrev_f32_e32 v0, v145, v61                              ; 0a007b91
(invalid instruction)                                        ; cc1b0090
	v_subrev_f32_e32 v0, v144, v61                              ; 0a007b90
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v149, s60, v122, v70                        ; cc210095 051af43c
(invalid instruction)                                        ; cc1b0093
	v_subrev_f32_e32 v0, v147, v61                              ; 0a007b93
	v_fma_mixlo_f16 v148, s60, v120, v68                        ; cc210094 0512f03c
	v_fma_mixhi_f16 v148, s60, v121, v69                        ; cc220094 0516f23c
	v_fma_mixhi_f16 v149, s60, v123, v71                        ; cc220095 051ef63c
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v151, s60, v126, v78                        ; cc210097 053afc3c
	v_fma_mixhi_f16 v151, s60, v127, v79                        ; cc220097 053efe3c
	v_fma_mixlo_f16 v150, s60, v124, v76                        ; cc210096 0532f83c
	v_fma_mixhi_f16 v150, s60, v125, v77                        ; cc220096 0536fa3c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v4, s[32:35], null offen offset:8320 ; c405c07c 40804044 00208004
	buffer_load_b128 v[76:79], v4, s[32:35], null offen offset:8336 ; c405c07c 4080404c 00209004
(invalid instruction)                                        ; cc1b0092
	v_subrev_f32_e32 v0, v146, v61                              ; 0a007b92
(invalid instruction)                                        ; cc1c0094
	v_subrev_f32_e32 v0, v148, v62                              ; 0a007d94
(invalid instruction)                                        ; cc1c0095
	v_subrev_f32_e32 v0, v149, v62                              ; 0a007d95
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v153, s60, v130, v10                        ; cc210099 042b043c
	v_fma_mixhi_f16 v153, s60, v131, v11                        ; cc220099 042f063c
	v_fma_mixlo_f16 v152, s60, v128, v8                         ; cc210098 0423003c
	v_fma_mixhi_f16 v152, s60, v129, v9                         ; cc220098 0427023c
(invalid instruction)                                        ; cc1c0097
	v_subrev_f32_e32 v0, v151, v62                              ; 0a007d97
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v154, s60, v132, v88                        ; cc21009a 0563083c
(invalid instruction)                                        ; cc1c0096
	v_subrev_f32_e32 v0, v150, v62                              ; 0a007d96
	v_fma_mixhi_f16 v154, s60, v133, v89                        ; cc22009a 05670a3c
	v_fma_mixlo_f16 v155, s60, v134, v90                        ; cc21009b 056b0c3c
	v_fma_mixhi_f16 v155, s60, v135, v91                        ; cc22009b 056f0e3c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v4, s[32:35], null offen offset:8384 ; c405c07c 40804008 0020c004
	buffer_load_b128 v[88:91], v4, s[32:35], null offen offset:8400 ; c405c07c 40804058 0020d004
(invalid instruction)                                        ; cc1b0094
	v_subrev_f32_e32 v0, v148, v61                              ; 0a007b94
(invalid instruction)                                        ; cc1b0095
	v_subrev_f32_e32 v0, v149, v61                              ; 0a007b95
(invalid instruction)                                        ; cc1c0099
	v_subrev_f32_e32 v0, v153, v62                              ; 0a007d99
(invalid instruction)                                        ; cc1c0098
	v_subrev_f32_e32 v0, v152, v62                              ; 0a007d98
(invalid instruction)                                        ; cc1b0097
	v_subrev_f32_e32 v0, v151, v61                              ; 0a007b97
(invalid instruction)                                        ; cc1b0096
	v_subrev_f32_e32 v0, v150, v61                              ; 0a007b96
(invalid instruction)                                        ; cc1c009a
	v_subrev_f32_e32 v0, v154, v62                              ; 0a007d9a
(invalid instruction)                                        ; cc1c009b
	v_subrev_f32_e32 v0, v155, v62                              ; 0a007d9b
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v157, s60, v138, v94                        ; cc21009d 057b143c
	v_fma_mixhi_f16 v157, s60, v139, v95                        ; cc22009d 057f163c
	v_fma_mixlo_f16 v156, s60, v136, v92                        ; cc21009c 0573103c
	v_fma_mixhi_f16 v156, s60, v137, v93                        ; cc22009c 0577123c
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v158, s60, v140, v96                        ; cc21009e 0583183c
	v_fma_mixhi_f16 v158, s60, v141, v97                        ; cc22009e 05871a3c
(invalid instruction)                                        ; cc1b0099
	v_subrev_f32_e32 v0, v153, v61                              ; 0a007b99
	v_fma_mixlo_f16 v159, s60, v142, v98                        ; cc21009f 058b1c3c
(invalid instruction)                                        ; cc1b0098
	v_subrev_f32_e32 v0, v152, v61                              ; 0a007b98
	v_fma_mixhi_f16 v159, s60, v143, v99                        ; cc22009f 058f1e3c
(invalid instruction)                                        ; cc1b009a
	v_subrev_f32_e32 v0, v154, v61                              ; 0a007b9a
(invalid instruction)                                        ; cc1b009b
	v_subrev_f32_e32 v0, v155, v61                              ; 0a007b9b
	v_lshl_add_u32 v144, v144, 5, s63                           ; d6460090 00fd0b90
	v_lshl_add_u32 v148, v148, 5, s63                           ; d6460094 00fd0b94
(invalid instruction)                                        ; cc1c009d
	v_subrev_f32_e32 v0, v157, v62                              ; 0a007d9d
(invalid instruction)                                        ; cc1c009c
	v_subrev_f32_e32 v0, v156, v62                              ; 0a007d9c
(invalid instruction)                                        ; cc1c009e
	v_subrev_f32_e32 v0, v158, v62                              ; 0a007d9e
	v_lshl_add_u32 v145, v145, 5, s63                           ; d6460091 00fd0b91
	v_lshl_add_u32 v149, v149, 5, s63                           ; d6460095 00fd0b95
	v_lshl_add_u32 v152, v152, 5, s63                           ; d6460098 00fd0b98
	v_lshl_add_u32 v153, v153, 5, s63                           ; d6460099 00fd0b99
(invalid instruction)                                        ; cc1c009f
	v_subrev_f32_e32 v0, v159, v62                              ; 0a007d9f
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[144:145], v[148:149]            ; 1a032990
	v_lshl_add_u32 v146, v146, 5, s63                           ; d6460092 00fd0b92
	v_lshl_add_u32 v150, v150, 5, s63                           ; d6460096 00fd0b96
(invalid instruction)                                        ; cc1b009d
	v_subrev_f32_e32 v0, v157, v61                              ; 0a007b9d
(invalid instruction)                                        ; cc1b009c
	v_subrev_f32_e32 v0, v156, v61                              ; 0a007b9c
(invalid instruction)                                        ; cc1b009e
	v_subrev_f32_e32 v0, v158, v61                              ; 0a007b9e
	v_lshl_add_u32 v154, v154, 5, s63                           ; d646009a 00fd0b9a
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[145:146], v[149:150]            ; 1a032b91
	v_lshl_add_u32 v147, v147, 5, s63                           ; d6460093 00fd0b93
	v_lshl_add_u32 v151, v151, 5, s63                           ; d6460097 00fd0b97
(invalid instruction)                                        ; cc1b009f
	v_subrev_f32_e32 v0, v159, v61                              ; 0a007b9f
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[152:153]            ; 1a0331a3
	v_lshl_add_u32 v155, v155, 5, s63                           ; d646009b 00fd0b9b
(invalid instruction)                                        ; cc0f00a5
	v_min_num_f64_e32 v[1:2], v[146:147], v[150:151]            ; 1a032d92
	v_lshl_add_u32 v157, v157, 5, s63                           ; d646009d 00fd0b9d
	v_lshl_add_u32 v156, v156, 5, s63                           ; d646009c 00fd0b9c
	v_lshl_add_u32 v158, v158, 5, s63                           ; d646009e 00fd0b9e
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[153:154]            ; 1a0333a4
(invalid instruction)                                        ; cc0f00a6
	v_min_num_f64_e32 v[1:2], v[147:148], v[151:152]            ; 1a032f93
	v_lshl_add_u32 v159, v159, 5, s63                           ; d646009f 00fd0b9f
(invalid instruction)                                        ; cc0f00a5
	v_min_num_f64_e32 v[1:2], v[165:166], v[154:155]            ; 1a0335a5
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[156:157]            ; 1a0339a3
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[157:158]            ; 1a033ba4
(invalid instruction)                                        ; cc0f00a6
	v_min_num_f64_e32 v[1:2], v[166:167], v[155:156]            ; 1a0337a6
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f00a5
	v_min_num_f64_e32 v[1:2], v[165:166], v[158:159]            ; 1a033da5
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[164:165]            ; 1a0349a3
(invalid instruction)                                        ; cc0f00a6
	v_min_num_f64_e32 v[1:2], v[166:167], v[159:160]            ; 1a033fa6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[165:166]            ; 1a034ba3
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[166:167]            ; 1a034da3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v168, v163, s57, s58 op_sel:[1,1]         ; d65c18a8 00e873a3
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[168:169]            ; 1a0351a3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53210a9
	v_cndmask_b32_e32 v1, v163, v163, vcc_lo                    ; 020347a3
(invalid instruction)                                        ; d53100a9
	v_cndmask_b32_e32 v1, s56, v169, vcc_lo                     ; 02035238
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00aa
	v_cndmask_b32_e32 v0, v169, v128, vcc_lo                    ; 020101a9
	v_rcp_f32_e32 v170, v170                                    ; 7f5455aa
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v176, v149, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000b0 8a035595
	v_fma_mix_f32 v172, v145, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000ac 8a035591
	v_fma_mix_f32 v145, v145, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a035591
	v_fma_mix_f32 v171, v144, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000ab 8a035590
	v_fma_mix_f32 v144, v144, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200890 8a035590
	v_fma_mix_f32 v173, v146, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000ad 8a035592
	v_fma_mix_f32 v146, v146, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200892 8a035592
	v_fma_mix_f32 v175, v148, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000af 8a035594
	v_fma_mix_f32 v148, v148, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200894 8a035594
	v_fma_mix_f32 v174, v147, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000ae 8a035593
	v_fma_mix_f32 v147, v147, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200893 8a035593
	v_fma_mix_f32 v149, v149, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a035595
	v_fma_mix_f32 v177, v150, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000b1 8a035596
	v_fma_mix_f32 v150, v150, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200896 8a035596
	v_fma_mix_f32 v178, v151, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000b2 8a035597
	v_fma_mix_f32 v151, v151, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a035597
	v_fma_mix_f32 v179, v152, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000b3 8a035598
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v171, v144, vcc_lo                    ; 020321ab
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v172, v145, vcc_lo                    ; 020323ac
	v_fma_mix_f32 v152, v152, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200898 8a035598
	v_fma_mix_f32 v180, v153, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000b4 8a035599
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v173, v146, vcc_lo                    ; 020325ad
	v_fma_mix_f32 v153, v153, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a035599
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v175, v148, vcc_lo                    ; 020329af
	v_fma_mix_f32 v181, v154, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000b5 8a03559a
	v_fma_mix_f32 v154, v154, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089a 8a03559a
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v174, v147, vcc_lo                    ; 020327ae
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v176, v149, vcc_lo                    ; 02032bb0
	v_fma_mix_f32 v182, v155, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000b6 8a03559b
	v_fma_mix_f32 v155, v155, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089b 8a03559b
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v177, v150, vcc_lo                    ; 02032db1
	v_fma_mix_f32 v183, v156, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000b7 8a03559c
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v178, v151, vcc_lo                    ; 02032fb2
	v_fma_mix_f32 v156, v156, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089c 8a03559c
	v_fma_mix_f32 v184, v157, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000b8 8a03559d
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v179, v152, vcc_lo                    ; 020331b3
	v_fma_mix_f32 v157, v157, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a03559d
	v_fma_mix_f32 v185, v158, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000b9 8a03559e
	v_fma_mix_f32 v158, v158, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089e 8a03559e
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v180, v153, vcc_lo                    ; 020333b4
	v_fma_mix_f32 v186, v159, v170, neg(0) op_sel_hi:[1,0,0]    ; cc2000ba 8a03559f
	v_fma_mix_f32 v159, v159, v170, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089f 8a03559f
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[96:99], v4, s[32:35], null offen offset:12288 ; c405c07c 40804060 00300004
	buffer_load_b128 v[108:111], v4, s[32:35], null offen offset:12304 ; c405c07c 4080406c 00301004
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v181, v154, vcc_lo                    ; 020335b5
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[46:47], 0 ; cc464070 1a025d18
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[86:87], v[46:47], 0 ; cc464078 1a025d56
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[46:47], 0 ; cc464080 1a025d32
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v182, v155, vcc_lo                    ; 020337b6
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[46:47], 0 ; cc464088 1a025d4a
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v183, v156, vcc_lo                    ; 020339b7
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v184, v157, vcc_lo                    ; 02033bb8
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v185, v158, vcc_lo                    ; 02033db9
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v186, v159, vcc_lo                    ; 02033fba
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[18:19], v[112:119] ; cc464070 1dc2253a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[18:19], v[120:127] ; cc464078 1de22530
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[18:19], v[128:135] ; cc464080 1e022548
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[6:7], v[18:19], v[136:143] ; cc464088 1e222506
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v189, s60, v116, v100                       ; cc2100bd 0592e83c
	v_fma_mixhi_f16 v189, s60, v117, v101                       ; cc2200bd 0596ea3c
	v_fma_mixlo_f16 v187, s60, v112, v80                        ; cc2100bb 0542e03c
	v_fma_mixhi_f16 v187, s60, v113, v81                        ; cc2200bb 0546e23c
	v_fma_mixlo_f16 v190, s60, v118, v102                       ; cc2100be 059aec3c
	v_fma_mixhi_f16 v190, s60, v119, v103                       ; cc2200be 059eee3c
	v_fma_mixlo_f16 v188, s60, v114, v82                        ; cc2100bc 054ae43c
	v_fma_mixhi_f16 v188, s60, v115, v83                        ; cc2200bc 054ee63c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[80:83], v4, s[32:35], null offen offset:12352 ; c405c07c 40804050 00304004
	buffer_load_b128 v[100:103], v4, s[32:35], null offen offset:12368 ; c405c07c 40804064 00305004
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v62                              ; 0a007dbd
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v62                              ; 0a007dbb
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v62                              ; 0a007dbe
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v62                              ; 0a007dbc
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b00bd
	v_subrev_f32_e32 v0, v189, v61                              ; 0a007bbd
(invalid instruction)                                        ; cc1b00bb
	v_subrev_f32_e32 v0, v187, v61                              ; 0a007bbb
(invalid instruction)                                        ; cc1b00be
	v_subrev_f32_e32 v0, v190, v61                              ; 0a007bbe
(invalid instruction)                                        ; cc1b00bc
	v_subrev_f32_e32 v0, v188, v61                              ; 0a007bbc
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v191, s60, v120, v40                        ; cc2100bf 04a2f03c
	v_fma_mixhi_f16 v191, s60, v121, v41                        ; cc2200bf 04a6f23c
	v_fma_mixlo_f16 v18, s60, v122, v42                         ; cc210012 04aaf43c
	v_fma_mixhi_f16 v18, s60, v123, v43                         ; cc220012 04aef63c
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v32, s60, v126, v62                         ; cc210020 04fafc3c
	v_fma_mixlo_f16 v19, s60, v124, v60                         ; cc210013 04f2f83c
	v_fma_mixhi_f16 v19, s60, v125, v61                         ; cc220013 04f6fa3c
	v_fma_mixhi_f16 v32, s60, v127, v63                         ; cc220020 04fefe3c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v4, s[32:35], null offen offset:12416 ; c405c07c 40804028 00308004
	buffer_load_b128 v[60:63], v4, s[32:35], null offen offset:12432 ; c405c07c 4080403c 00309004
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v62                              ; 0a007dbf
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v62                               ; 0a007d12
(invalid instruction)                                        ; cc1c0013
	v_subrev_f32_e32 v0, v19, v62                               ; 0a007d13
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v62                               ; 0a007d20
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v61                              ; 0a007bbf
(invalid instruction)                                        ; cc1b0012
	v_subrev_f32_e32 v0, v18, v61                               ; 0a007b12
(invalid instruction)                                        ; cc1b0013
	v_subrev_f32_e32 v0, v19, v61                               ; 0a007b13
(invalid instruction)                                        ; cc1b0020
	v_subrev_f32_e32 v0, v32, v61                               ; 0a007b20
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v47, s60, v130, v70                         ; cc21002f 051b043c
	v_fma_mixlo_f16 v46, s60, v128, v68                         ; cc21002e 0513003c
	v_fma_mixhi_f16 v46, s60, v129, v69                         ; cc22002e 0517023c
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v68, s60, v132, v76                         ; cc210044 0533083c
	v_fma_mixhi_f16 v68, s60, v133, v77                         ; cc220044 05370a3c
	v_fma_mixlo_f16 v69, s60, v134, v78                         ; cc210045 053b0c3c
	v_fma_mixhi_f16 v69, s60, v135, v79                         ; cc220045 053f0e3c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[76:79], v4, s[32:35], null offen offset:12480 ; c405c07c 4080404c 0030c004
	buffer_load_b128 v[112:115], v4, s[32:35], null offen offset:12496 ; c405c07c 40804070 0030d004
	v_fma_mixhi_f16 v47, s60, v131, v71                         ; cc22002f 051f063c
	v_add3_u32 v34, v34, s9, v0                                 ; d6550022 04001322
(invalid instruction)                                        ; cc1c002e
	v_subrev_f32_e32 v0, v46, v62                               ; 0a007d2e
(invalid instruction)                                        ; cc1c0044
	v_subrev_f32_e32 v0, v68, v62                               ; 0a007d44
(invalid instruction)                                        ; cc1c0045
	v_subrev_f32_e32 v0, v69, v62                               ; 0a007d45
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v70, s60, v136, v8                          ; cc210046 0423103c
	v_fma_mixlo_f16 v71, s60, v138, v10                         ; cc210047 042b143c
	v_fma_mixhi_f16 v70, s60, v137, v9                          ; cc220046 0427123c
	v_fma_mixhi_f16 v71, s60, v139, v11                         ; cc220047 042f163c
(invalid instruction)                                        ; cc1c002f
	v_subrev_f32_e32 v0, v47, v62                               ; 0a007d2f
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v88, s60, v140, v88                         ; cc210058 0563183c
	v_fma_mixhi_f16 v88, s60, v141, v89                         ; cc220058 05671a3c
	v_lshlrev_b32_e32 v34, 2, v34                               ; 30444482
(invalid instruction)                                        ; cc1b002e
	v_subrev_f32_e32 v0, v46, v61                               ; 0a007b2e
	v_fma_mixlo_f16 v89, s60, v142, v90                         ; cc210059 056b1c3c
(invalid instruction)                                        ; cc1b0044
	v_subrev_f32_e32 v0, v68, v61                               ; 0a007b44
	v_fma_mixhi_f16 v89, s60, v143, v91                         ; cc220059 056f1e3c
(invalid instruction)                                        ; cc1b0045
	v_subrev_f32_e32 v0, v69, v61                               ; 0a007b45
	v_lshl_add_u32 v187, v187, 5, s63                           ; d64600bb 00fd0bbb
(invalid instruction)                                        ; cc1c0046
	v_subrev_f32_e32 v0, v70, v62                               ; 0a007d46
	v_lshl_add_u32 v191, v191, 5, s63                           ; d64600bf 00fd0bbf
(invalid instruction)                                        ; cc1c0047
	v_subrev_f32_e32 v0, v71, v62                               ; 0a007d47
(invalid instruction)                                        ; cc1b002f
	v_subrev_f32_e32 v0, v47, v61                               ; 0a007b2f
(invalid instruction)                                        ; cc1c0058
	v_subrev_f32_e32 v0, v88, v62                               ; 0a007d58
	v_lshl_add_u32 v188, v188, 5, s63                           ; d64600bc 00fd0bbc
	v_lshl_add_u32 v46, v46, 5, s63                             ; d646002e 00fd0b2e
	v_lshl_add_u32 v18, v18, 5, s63                             ; d6460012 00fd0b12
(invalid instruction)                                        ; cc1c0059
	v_subrev_f32_e32 v0, v89, v62                               ; 0a007d59
(invalid instruction)                                        ; cc1b0046
	v_subrev_f32_e32 v0, v70, v61                               ; 0a007b46
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[187:188], v[191:192]            ; 1a037fbb
	v_lshl_add_u32 v189, v189, 5, s63                           ; d64600bd 00fd0bbd
(invalid instruction)                                        ; cc1b0047
	v_subrev_f32_e32 v0, v71, v61                               ; 0a007b47
	v_lshl_add_u32 v19, v19, 5, s63                             ; d6460013 00fd0b13
	v_lshl_add_u32 v47, v47, 5, s63                             ; d646002f 00fd0b2f
(invalid instruction)                                        ; cc1b0058
	v_subrev_f32_e32 v0, v88, v61                               ; 0a007b58
	v_lshl_add_u32 v68, v68, 5, s63                             ; d6460044 00fd0b44
(invalid instruction)                                        ; cc0f005b
	v_min_num_f64_e32 v[1:2], v[188:189], v[18:19]              ; 1a0225bc
(invalid instruction)                                        ; cc1b0059
	v_subrev_f32_e32 v0, v89, v61                               ; 0a007b59
	v_lshl_add_u32 v190, v190, 5, s63                           ; d64600be 00fd0bbe
	v_lshl_add_u32 v32, v32, 5, s63                             ; d6460020 00fd0b20
	v_lshl_add_u32 v70, v70, 5, s63                             ; d6460046 00fd0b46
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[46:47]                ; 1a025d5a
	v_lshl_add_u32 v69, v69, 5, s63                             ; d6460045 00fd0b45
	v_lshl_add_u32 v71, v71, 5, s63                             ; d6460047 00fd0b47
(invalid instruction)                                        ; cc0f005e
	v_min_num_f64_e32 v[1:2], v[189:190], v[19:20]              ; 1a0227bd
	v_lshl_add_u32 v88, v88, 5, s63                             ; d6460058 00fd0b58
(invalid instruction)                                        ; cc0f005b
	v_min_num_f64_e32 v[1:2], v[91:92], v[47:48]                ; 1a025f5b
	v_lshl_add_u32 v89, v89, 5, s63                             ; d6460059 00fd0b59
(invalid instruction)                                        ; cc0f005f
	v_min_num_f64_e32 v[1:2], v[190:191], v[32:33]              ; 1a0241be
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[70:71]                ; 1a028d5a
(invalid instruction)                                        ; cc0f005e
	v_min_num_f64_e32 v[1:2], v[94:95], v[68:69]                ; 1a02895e
(invalid instruction)                                        ; cc0f005b
	v_min_num_f64_e32 v[1:2], v[91:92], v[71:72]                ; 1a028f5b
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f005f
	v_min_num_f64_e32 v[1:2], v[95:96], v[69:70]                ; 1a028b5f
(invalid instruction)                                        ; cc0f005e
	v_min_num_f64_e32 v[1:2], v[94:95], v[88:89]                ; 1a02b15e
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[91:92]                ; 1a02b75a
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f005f
	v_min_num_f64_e32 v[1:2], v[95:96], v[89:90]                ; 1a02b35f
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[94:95]                ; 1a02bd5a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[95:96]                ; 1a02bf5a
	v_permlanex16_b32 v104, v90, s57, s58 op_sel:[1,1]          ; d65c1868 00e8735a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[104:105]              ; 1a02d15a
	v_add_f16_e32 v105, v90, v218/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64d3b55a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v105, s56, v105                           ; 62d2d238
	v_cvt_f32_f16_e32 v116, v105                                ; 7ee81769
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v116, v116                                    ; 7ee85574
	v_fma_mix_f32 v121, v191, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200079 8a02e9bf
	v_fma_mix_f32 v122, v18, v116, neg(0) op_sel_hi:[1,0,0]     ; cc20007a 8a02e912
	v_fma_mix_f32 v117, v187, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200075 8a02e9bb
	v_fma_mix_f32 v120, v190, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200078 8a02e9be
	v_fma_mix_f32 v118, v188, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200076 8a02e9bc
	v_fma_mix_f32 v187, v187, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a02e9bb
	v_fma_mix_f32 v191, v191, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a02e9bf
	v_fma_mix_f32 v119, v189, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200077 8a02e9bd
	v_fma_mix_f32 v189, v189, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a02e9bd
	v_fma_mix_f32 v188, v188, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a02e9bc
	v_fma_mix_f32 v190, v190, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a02e9be
	v_fma_mix_f32 v18, v18, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200812 8a02e912
	v_fma_mix_f32 v123, v19, v116, neg(0) op_sel_hi:[1,0,0]     ; cc20007b 8a02e913
	v_fma_mix_f32 v19, v19, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200813 8a02e913
	v_fma_mix_f32 v124, v32, v116, neg(0) op_sel_hi:[1,0,0]     ; cc20007c 8a02e920
	v_fma_mix_f32 v32, v32, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a02e920
	v_fma_mix_f32 v125, v46, v116, neg(0) op_sel_hi:[1,0,0]     ; cc20007d 8a02e92e
	v_fma_mix_f32 v46, v46, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082e 8a02e92e
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v117, v187, vcc_lo                    ; 02037775
	v_fma_mix_f32 v126, v47, v116, neg(0) op_sel_hi:[1,0,0]     ; cc20007e 8a02e92f
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v121, v191, vcc_lo                    ; 02037f79
	v_fma_mix_f32 v47, v47, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082f 8a02e92f
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v119, v189, vcc_lo                    ; 02037b77
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v118, v188, vcc_lo                    ; 02037976
	v_fma_mix_f32 v127, v68, v116, neg(0) op_sel_hi:[1,0,0]     ; cc20007f 8a02e944
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v120, v190, vcc_lo                    ; 02037d78
	v_fma_mix_f32 v68, v68, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200844 8a02e944
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v122, v18, vcc_lo                     ; 0202257a
	v_fma_mix_f32 v128, v69, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200080 8a02e945
	v_fma_mix_f32 v69, v69, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200845 8a02e945
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v123, v19, vcc_lo                     ; 0202277b
	v_fma_mix_f32 v129, v70, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200081 8a02e946
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v124, v32, vcc_lo                     ; 0202417c
	v_fma_mix_f32 v70, v70, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200846 8a02e946
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v125, v46, vcc_lo                     ; 02025d7d
	v_fma_mix_f32 v130, v71, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200082 8a02e947
	v_fma_mix_f32 v71, v71, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200847 8a02e947
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v126, v47, vcc_lo                     ; 02025f7e
	v_fma_mix_f32 v131, v88, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200083 8a02e958
	v_fma_mix_f32 v88, v88, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200858 8a02e958
	v_fma_mix_f32 v132, v89, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200084 8a02e959
	v_fma_mix_f32 v89, v89, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200859 8a02e959
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v127, v68, vcc_lo                     ; 0202897f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[20:21], 0 ; cc464078 1a022918
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v128, v69, vcc_lo                     ; 02028b80
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[50:51], v[20:21], 0 ; cc464088 1a022932
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[74:75], v[20:21], 0 ; cc464090 1a02294a
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v129, v70, vcc_lo                     ; 02028d81
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v130, v71, vcc_lo                     ; 02028f82
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v131, v88, vcc_lo                     ; 0202b183
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v132, v89, vcc_lo                     ; 0202b384
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[86:87], v[20:21], 0 ; cc464080 1a022956
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[58:59], v[22:23], v[120:127] ; cc464078 1de22d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[72:73], v[22:23], v[136:143] ; cc464088 1e222d48
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[6:7], v[22:23], v[144:151] ; cc464090 1e422d06
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[48:49], v[22:23], v[128:135] ; cc464080 1e022d30
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v153, s60, v122, v98                        ; cc210099 058af43c
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v154, s60, v124, v108                       ; cc21009a 05b2f83c
	v_fma_mixlo_f16 v152, s60, v120, v96                        ; cc210098 0582f03c
	v_fma_mixhi_f16 v152, s60, v121, v97                        ; cc220098 0586f23c
	v_fma_mixlo_f16 v155, s60, v126, v110                       ; cc21009b 05bafc3c
	v_fma_mixhi_f16 v155, s60, v127, v111                       ; cc22009b 05befe3c
	v_fma_mixhi_f16 v154, s60, v125, v109                       ; cc22009a 05b6fa3c
	v_fma_mixhi_f16 v153, s60, v123, v99                        ; cc220099 058ef63c
(invalid instruction)                                        ; cc1c0098
	v_subrev_f32_e32 v0, v152, v62                              ; 0a007d98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c009b
	v_subrev_f32_e32 v0, v155, v62                              ; 0a007d9b
(invalid instruction)                                        ; cc1c009a
	v_subrev_f32_e32 v0, v154, v62                              ; 0a007d9a
(invalid instruction)                                        ; cc1c0099
	v_subrev_f32_e32 v0, v153, v62                              ; 0a007d99
(invalid instruction)                                        ; cc1b0098
	v_subrev_f32_e32 v0, v152, v61                              ; 0a007b98
(invalid instruction)                                        ; cc1b009b
	v_subrev_f32_e32 v0, v155, v61                              ; 0a007b9b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v156, s60, v128, v80                        ; cc21009c 0543003c
	v_fma_mixhi_f16 v156, s60, v129, v81                        ; cc22009c 0547023c
(invalid instruction)                                        ; cc1b009a
	v_subrev_f32_e32 v0, v154, v61                              ; 0a007b9a
	v_fma_mixlo_f16 v157, s60, v130, v82                        ; cc21009d 054b043c
	v_fma_mixhi_f16 v157, s60, v131, v83                        ; cc22009d 054f063c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v158, s60, v132, v100                       ; cc21009e 0593083c
	v_fma_mixhi_f16 v158, s60, v133, v101                       ; cc22009e 05970a3c
	v_fma_mixlo_f16 v159, s60, v134, v102                       ; cc21009f 059b0c3c
	v_fma_mixhi_f16 v159, s60, v135, v103                       ; cc22009f 059f0e3c
(invalid instruction)                                        ; cc1b0099
	v_subrev_f32_e32 v0, v153, v61                              ; 0a007b99
(invalid instruction)                                        ; cc1c009c
	v_subrev_f32_e32 v0, v156, v62                              ; 0a007d9c
(invalid instruction)                                        ; cc1c009d
	v_subrev_f32_e32 v0, v157, v62                              ; 0a007d9d
(invalid instruction)                                        ; cc1c009e
	v_subrev_f32_e32 v0, v158, v62                              ; 0a007d9e
(invalid instruction)                                        ; cc1c009f
	v_subrev_f32_e32 v0, v159, v62                              ; 0a007d9f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b009c
	v_subrev_f32_e32 v0, v156, v61                              ; 0a007b9c
(invalid instruction)                                        ; cc1b009d
	v_subrev_f32_e32 v0, v157, v61                              ; 0a007b9d
(invalid instruction)                                        ; cc1b009e
	v_subrev_f32_e32 v0, v158, v61                              ; 0a007b9e
(invalid instruction)                                        ; cc1b009f
	v_subrev_f32_e32 v0, v159, v61                              ; 0a007b9f
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v164, s60, v138, v42                        ; cc2100a4 04ab143c
	v_fma_mixlo_f16 v163, s60, v136, v40                        ; cc2100a3 04a3103c
	v_fma_mixhi_f16 v163, s60, v137, v41                        ; cc2200a3 04a7123c
	v_fma_mixhi_f16 v164, s60, v139, v43                        ; cc2200a4 04af163c
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v165, s60, v140, v60                        ; cc2100a5 04f3183c
	v_fma_mixlo_f16 v166, s60, v142, v62                        ; cc2100a6 04fb1c3c
	buffer_load_b128 v[20:23], v34, s[32:35], null offen        ; c405c07c 40804014 00000022
	v_fma_mixhi_f16 v165, s60, v141, v61                        ; cc2200a5 04f71a3c
	v_fma_mixhi_f16 v166, s60, v143, v63                        ; cc2200a6 04ff1e3c
(invalid instruction)                                        ; cc1c00a3
	v_subrev_f32_e32 v0, v163, v62                              ; 0a007da3
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v62                              ; 0a007da4
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v62                              ; 0a007da5
(invalid instruction)                                        ; cc1c00a6
	v_subrev_f32_e32 v0, v166, v62                              ; 0a007da6
(invalid instruction)                                        ; cc1b00a3
	v_subrev_f32_e32 v0, v163, v61                              ; 0a007ba3
	buffer_load_b128 v[40:43], v34, s[32:35], null offen offset:16 ; c405c07c 40804028 00001022
(invalid instruction)                                        ; cc1b00a4
	v_subrev_f32_e32 v0, v164, v61                              ; 0a007ba4
(invalid instruction)                                        ; cc1b00a5
	v_subrev_f32_e32 v0, v165, v61                              ; 0a007ba5
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v168, s60, v144, v76                        ; cc2100a8 0533203c
	v_fma_mixhi_f16 v168, s60, v145, v77                        ; cc2200a8 0537223c
	v_fma_mixlo_f16 v169, s60, v146, v78                        ; cc2100a9 053b243c
	v_fma_mixhi_f16 v169, s60, v147, v79                        ; cc2200a9 053f263c
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v171, s60, v150, v114                       ; cc2100ab 05cb2c3c
(invalid instruction)                                        ; cc1b00a6
	v_subrev_f32_e32 v0, v166, v61                              ; 0a007ba6
	v_fma_mixlo_f16 v170, s60, v148, v112                       ; cc2100aa 05c3283c
	v_fma_mixhi_f16 v170, s60, v149, v113                       ; cc2200aa 05c72a3c
	v_fma_mixhi_f16 v171, s60, v151, v115                       ; cc2200ab 05cf2e3c
	v_lshl_add_u32 v152, v152, 5, s63                           ; d6460098 00fd0b98
	v_lshl_add_u32 v156, v156, 5, s63                           ; d646009c 00fd0b9c
	v_lshl_add_u32 v163, v163, 5, s63                           ; d64600a3 00fd0ba3
(invalid instruction)                                        ; cc1c00a8
	v_subrev_f32_e32 v0, v168, v62                              ; 0a007da8
	v_lshl_add_u32 v153, v153, 5, s63                           ; d6460099 00fd0b99
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v62                              ; 0a007da9
	v_lshl_add_u32 v157, v157, 5, s63                           ; d646009d 00fd0b9d
	v_lshl_add_u32 v164, v164, 5, s63                           ; d64600a4 00fd0ba4
(invalid instruction)                                        ; cc1c00aa
	v_subrev_f32_e32 v0, v170, v62                              ; 0a007daa
(invalid instruction)                                        ; cc1c00ab
	v_subrev_f32_e32 v0, v171, v62                              ; 0a007dab
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[152:153], v[156:157]            ; 1a033998
	v_lshl_add_u32 v154, v154, 5, s63                           ; d646009a 00fd0b9a
	v_lshl_add_u32 v158, v158, 5, s63                           ; d646009e 00fd0b9e
(invalid instruction)                                        ; cc1b00a8
	v_subrev_f32_e32 v0, v168, v61                              ; 0a007ba8
	v_lshl_add_u32 v165, v165, 5, s63                           ; d64600a5 00fd0ba5
(invalid instruction)                                        ; cc1b00a9
	v_subrev_f32_e32 v0, v169, v61                              ; 0a007ba9
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[153:154], v[157:158]            ; 1a033b99
(invalid instruction)                                        ; cc1b00aa
	v_subrev_f32_e32 v0, v170, v61                              ; 0a007baa
	v_lshl_add_u32 v155, v155, 5, s63                           ; d646009b 00fd0b9b
	v_lshl_add_u32 v159, v159, 5, s63                           ; d646009f 00fd0b9f
(invalid instruction)                                        ; cc1b00ab
	v_subrev_f32_e32 v0, v171, v61                              ; 0a007bab
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[163:164]            ; 1a0347ac
	v_lshl_add_u32 v166, v166, 5, s63                           ; d64600a6 00fd0ba6
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[154:155], v[158:159]            ; 1a033d9a
	v_lshl_add_u32 v168, v168, 5, s63                           ; d64600a8 00fd0ba8
	v_lshl_add_u32 v169, v169, 5, s63                           ; d64600a9 00fd0ba9
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[164:165]            ; 1a0349ad
	v_lshl_add_u32 v170, v170, 5, s63                           ; d64600aa 00fd0baa
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[155:156], v[159:160]            ; 1a033f9b
	v_lshl_add_u32 v171, v171, 5, s63                           ; d64600ab 00fd0bab
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[174:175], v[165:166]            ; 1a034bae
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[168:169]            ; 1a0351ac
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[169:170]            ; 1a0353ad
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[166:167]            ; 1a034daf
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[174:175], v[170:171]            ; 1a0355ae
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[173:174]            ; 1a035bac
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[171:172]            ; 1a0357af
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[174:175]            ; 1a035dac
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[175:176]            ; 1a035fac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v176, v172, s57, s58 op_sel:[1,1]         ; d65c18b0 00e873ac
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[176:177]            ; 1a0361ac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53210b1
	v_cndmask_b32_e32 v1, v172, v172, vcc_lo                    ; 020359ac
(invalid instruction)                                        ; d53100b1
	v_cndmask_b32_e32 v1, s56, v177, vcc_lo                     ; 02036238
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00b2
	v_cndmask_b32_e32 v0, v177, v128, vcc_lo                    ; 020101b1
	v_rcp_f32_e32 v178, v178                                    ; 7f6455b2
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v181, v154, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b5 8a03659a
	v_fma_mix_f32 v154, v154, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089a 8a03659a
	v_fma_mix_f32 v182, v155, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b6 8a03659b
	v_fma_mix_f32 v155, v155, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089b 8a03659b
	v_fma_mix_f32 v179, v152, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b3 8a036598
	v_fma_mix_f32 v152, v152, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200898 8a036598
	v_fma_mix_f32 v183, v156, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b7 8a03659c
	buffer_load_b128 v[48:51], v34, s[32:35], null offen offset:64 ; c405c07c 40804030 00004022
	v_fma_mix_f32 v156, v156, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089c 8a03659c
	v_fma_mix_f32 v180, v153, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b4 8a036599
	v_fma_mix_f32 v153, v153, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a036599
	v_fma_mix_f32 v184, v157, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b8 8a03659d
	v_fma_mix_f32 v157, v157, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a03659d
	v_fma_mix_f32 v185, v158, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b9 8a03659e
	v_fma_mix_f32 v158, v158, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089e 8a03659e
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v181, v154, vcc_lo                    ; 020335b5
	buffer_load_b128 v[60:63], v34, s[32:35], null offen offset:80 ; c405c07c 4080403c 00005022
	v_fma_mix_f32 v186, v159, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000ba 8a03659f
	v_fma_mix_f32 v159, v159, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089f 8a03659f
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v182, v155, vcc_lo                    ; 020337b6
	v_fma_mix_f32 v187, v163, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bb 8a0365a3
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v179, v152, vcc_lo                    ; 020331b3
	v_fma_mix_f32 v163, v163, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a3 8a0365a3
	v_fma_mix_f32 v188, v164, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bc 8a0365a4
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v183, v156, vcc_lo                    ; 020339b7
	v_fma_mix_f32 v164, v164, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a4 8a0365a4
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v180, v153, vcc_lo                    ; 020333b4
	s_lshr_b32 s6, s6, 2                                        ; 85068206
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v184, v157, vcc_lo                    ; 02033bb8
	v_fma_mix_f32 v189, v165, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bd 8a0365a5
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v185, v158, vcc_lo                    ; 02033db9
	v_fma_mix_f32 v165, v165, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a0365a5
	v_fma_mix_f32 v190, v166, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000be 8a0365a6
	v_fma_mix_f32 v166, v166, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a6 8a0365a6
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v186, v159, vcc_lo                    ; 02033fba
	v_fma_mix_f32 v191, v168, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0365a8
	v_fma_mix_f32 v168, v168, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a8 8a0365a8
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v187, v163, vcc_lo                    ; 020347bb
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v33, v33, s6, v30                                ; d6550021 04780d21
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v188, v164, vcc_lo                    ; 020349bc
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v189, v165, vcc_lo                    ; 02034bbd
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[12:13], v[106:107], 0 ; cc464048 1a02d50c
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v190, v166, vcc_lo                    ; 02034dbe
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[44:45], 0 ; cc464060 1a02590c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[8:9], 0 ; cc464070 1a02110c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[12:13], v[6:7], 0 ; cc464078 1a020d0c
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v191, v168, vcc_lo                    ; 020351bf
	v_fma_mix_f32 v191, v169, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0365a9
	v_fma_mix_f32 v169, v169, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a0365a9
	v_lshlrev_b32_e32 v33, 2, v33                               ; 30424282
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[16:17], v[54:55], v[72:79] ; cc464048 1d226d10
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[56:57], v[96:103] ; cc464060 1d827110
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[10:11], v[112:119] ; cc464070 1dc21510
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v191, v169, vcc_lo                    ; 020353bf
	v_fma_mix_f32 v191, v170, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0365aa
	v_fma_mix_f32 v170, v170, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008aa 8a0365aa
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[24:25], v[120:127] ; cc464078 1de23110
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[64:65], v[72:79] ; cc464048 1d22811c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[84:85], v[96:103] ; cc464060 1d82a91c
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v191, v170, vcc_lo                    ; 020355bf
	v_fma_mix_f32 v191, v171, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0365ab
	v_fma_mix_f32 v171, v171, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ab 8a0365ab
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[18:19], v[112:119] ; cc464070 1dc2251c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[58:59], v[120:127] ; cc464078 1de2751c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[38:39], v[66:67], v[72:79] ; cc464048 1d228526
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v191, v171, vcc_lo                    ; 020357bf
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[92:93], v[96:103] ; cc464060 1d82b926
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[46:47], v[112:119] ; cc464070 1dc25d26
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[68:69], v[120:127] ; cc464078 1de28926
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[106:107], 0 ; cc464048 1a02d50e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[14:15], v[44:45], 0 ; cc464060 1a02590e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[8:9], 0 ; cc464068 1a02110e
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[10:11], v[104:111] ; cc464068 1da2151a
	buffer_load_b128 v[8:11], v33, s[36:39], null offen         ; c405c07c 40804808 00000021
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[6:7], 0 ; cc464070 1a020d0e
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[54:55], v[72:79] ; cc464048 1d226d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[56:57], v[96:103] ; cc464060 1d82711a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[18:19], v[104:111] ; cc464068 1da22524
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[24:25], v[112:119] ; cc464070 1dc2311a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[36:37], v[64:65], v[72:79] ; cc464048 1d228124
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[84:85], v[96:103] ; cc464060 1d82a924
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[46:47], v[104:111] ; cc464068 1da25d34
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[58:59], v[112:119] ; cc464070 1dc27524
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[52:53], v[66:67], v[72:79] ; cc464048 1d228534
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[92:93], v[96:103] ; cc464060 1d82b934
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[52:53], v[68:69], v[112:119] ; cc464070 1dc28934
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	ds_store_2addr_b64 v35, v[12:13], v[6:7] offset1:32         ; d9382000 00060c23
	buffer_load_b128 v[12:15], v33, s[36:39], null offen offset:512 ; c405c07c 4080480c 00020021
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	ds_store_2addr_b64 v167, v[16:17], v[6:7] offset1:32        ; d9382000 000610a7
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	ds_store_2addr_b64 v160, v[28:29], v[6:7] offset1:32        ; d9382000 00061ca0
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	ds_store_2addr_b64 v161, v[38:39], v[6:7] offset1:32        ; d9382000 000626a1
	buffer_load_b128 v[16:19], v33, s[36:39], null offen offset:1024 ; c405c07c 40804810 00040021
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[6:7], v162                                    ; d9d80000 060000a2
	ds_load_b64 v[24:25], v162 offset:2048                      ; d9d80800 180000a2
	ds_load_b64 v[26:27], v162 offset:4096                      ; d9d81000 1a0000a2
	buffer_load_b128 v[36:39], v33, s[36:39], null offen offset:1536 ; c405c07c 40804824 00060021
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[28:29], v6                           ; 7e38dd06
	s_wait_loadcnt 0x7                                          ; bfc00007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v65, v29, v21 :: v_dual_mul_f32 v64, v28, v20 ; c8c62b1d 4140291c
	v_cvt_pk_f32_fp8_e32 v[28:29], v134                         ; 7e38dd86
	v_dual_mul_f32 v67, v29, v23 :: v_dual_mul_f32 v66, v28, v22 ; c8c62f1d 43422d1c
	v_cvt_pk_f32_fp8_e32 v[28:29], v7                           ; 7e38dd07
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v69, v29, v41 :: v_dual_mul_f32 v68, v28, v40 ; c8c6531d 4544511c
	ds_load_b64 v[28:29], v162 offset:6144                      ; d9d81800 1c0000a2
	buffer_load_b128 v[44:47], v33, s[36:39], null offen offset:2048 ; c405c07c 4080482c 00080021
	ds_load_b64 v[34:35], v162 offset:256                       ; d9d80100 220000a2
	buffer_load_b128 v[52:55], v33, s[36:39], null offen offset:2560 ; c405c07c 40804834 000a0021
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v71, v7, v43 :: v_dual_mul_f32 v70, v6, v42  ; c8c65707 47465506
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[6:7], v24                            ; 7e0cdd18
	v_dual_mul_f32 v73, v7, v21 :: v_dual_mul_f32 v72, v6, v20  ; c8c62b07 49482906
	v_cvt_pk_f32_fp8_e32 v[6:7], v152                           ; 7e0cdd98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v75, v7, v23 :: v_dual_mul_f32 v74, v6, v22  ; c8c62f07 4b4a2d06
	v_cvt_pk_f32_fp8_e32 v[6:7], v25                            ; 7e0cdd19
	v_cvt_pk_f32_fp8_e32 v[24:25], v153                         ; 7e30dd99
	v_dual_mul_f32 v77, v7, v41 :: v_dual_mul_f32 v76, v6, v40  ; c8c65307 4d4c5106
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v26                            ; 7e0cdd1a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v81, v7, v21 :: v_dual_mul_f32 v80, v6, v20  ; c8c62b07 51502906
	v_cvt_pk_f32_fp8_e32 v[6:7], v154                           ; 7e0cdd9a
	v_dual_mul_f32 v83, v7, v23 :: v_dual_mul_f32 v82, v6, v22  ; c8c62f07 53522d06
	v_cvt_pk_f32_fp8_e32 v[6:7], v27                            ; 7e0cdd1b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v79, v25, v43 :: v_dual_mul_f32 v84, v6, v40 ; c8c65719 4f545106
	v_dual_mul_f32 v85, v7, v41 :: v_dual_mul_f32 v78, v24, v42 ; c8c65307 554e5518
	v_cvt_pk_f32_fp8_e32 v[6:7], v155                           ; 7e0cdd9b
	buffer_load_b128 v[24:27], v33, s[36:39], null offen offset:3072 ; c405c07c 40804818 000c0021
	ds_load_b64 v[56:57], v162 offset:2304                      ; d9d80900 380000a2
	v_dual_mul_f32 v87, v7, v43 :: v_dual_mul_f32 v86, v6, v42  ; c8c65707 57565506
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v28                            ; 7e0cdd1c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v89, v7, v21                                  ; 10b22b07
	v_mul_f32_e32 v88, v6, v20                                  ; 10b02906
	v_cvt_pk_f32_fp8_e32 v[6:7], v156                           ; 7e0cdd9c
	v_dual_mul_f32 v91, v7, v23 :: v_dual_mul_f32 v90, v6, v22  ; c8c62f07 5b5a2d06
	buffer_load_b128 v[20:23], v33, s[36:39], null offen offset:3584 ; c405c07c 40804814 000e0021
	v_cvt_pk_f32_fp8_e32 v[6:7], v29                            ; 7e0cdd1d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v93, v7, v41 :: v_dual_mul_f32 v92, v6, v40  ; c8c65307 5d5c5106
	v_cvt_pk_f32_fp8_e32 v[6:7], v157                           ; 7e0cdd9d
	ds_load_b64 v[28:29], v162 offset:4352                      ; d9d81100 1c0000a2
	ds_load_b64 v[32:33], v162 offset:6400                      ; d9d81900 200000a2
	v_dual_mul_f32 v95, v7, v43 :: v_dual_mul_f32 v94, v6, v42  ; c8c65707 5f5e5506
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[6:7], v34                            ; 7e0cdd22
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v97, v7, v49 :: v_dual_mul_f32 v96, v6, v48  ; c8c66307 61606106
	v_cvt_pk_f32_fp8_e32 v[6:7], v162                           ; 7e0cdda2
	v_dual_mul_f32 v99, v7, v51 :: v_dual_mul_f32 v98, v6, v50  ; c8c66707 63626506
	v_cvt_pk_f32_fp8_e32 v[6:7], v35                            ; 7e0cdd23
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v101, v7, v61 :: v_dual_mul_f32 v100, v6, v60 ; c8c67b07 65647906
	v_cvt_pk_f32_fp8_e32 v[6:7], v163                           ; 7e0cdda3
	v_dual_mul_f32 v103, v7, v63 :: v_dual_mul_f32 v102, v6, v62 ; c8c67f07 67667d06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v56                            ; 7e0cdd38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v105, v7, v49 :: v_dual_mul_f32 v104, v6, v48 ; c8c66307 69686106
	v_cvt_pk_f32_fp8_e32 v[6:7], v184                           ; 7e0cddb8
	v_dual_mul_f32 v107, v7, v51 :: v_dual_mul_f32 v106, v6, v50 ; c8c66707 6b6a6506
	v_cvt_pk_f32_fp8_e32 v[6:7], v57                            ; 7e0cdd39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v109, v7, v61 :: v_dual_mul_f32 v108, v6, v60 ; c8c67b07 6d6c7906
	v_cvt_pk_f32_fp8_e32 v[6:7], v185                           ; 7e0cddb9
	v_dual_mul_f32 v111, v7, v63 :: v_dual_mul_f32 v110, v6, v62 ; c8c67f07 6f6e7d06
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[6:7], v28                            ; 7e0cdd1c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v7, v49 :: v_dual_mul_f32 v112, v6, v48 ; c8c66307 71706106
	v_cvt_pk_f32_fp8_e32 v[6:7], v156                           ; 7e0cdd9c
	v_dual_mul_f32 v115, v7, v51 :: v_dual_mul_f32 v114, v6, v50 ; c8c66707 73726506
	v_cvt_pk_f32_fp8_e32 v[6:7], v29                            ; 7e0cdd1d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v117, v7, v61 :: v_dual_mul_f32 v116, v6, v60 ; c8c67b07 75747906
	v_cvt_pk_f32_fp8_e32 v[6:7], v157                           ; 7e0cdd9d
	ds_load_b64 v[34:35], v1 offset:8192                        ; d9d82000 22000001
	ds_load_b64 v[40:41], v1 offset:10240                       ; d9d82800 28000001
	ds_load_b64 v[42:43], v1 offset:12288                       ; d9d83000 2a000001
	ds_load_b64 v[56:57], v1 offset:14336                       ; d9d83800 38000001
	ds_load_b64 v[28:29], v1 offset:8448                        ; d9d82100 1c000001
	ds_load_b64 v[58:59], v1 offset:10496                       ; d9d82900 3a000001
	ds_load_b64 v[122:123], v1 offset:12544                     ; d9d83100 7a000001
	ds_load_b64 v[124:125], v1 offset:14592                     ; d9d83900 7c000001
	v_dual_mul_f32 v119, v7, v63 :: v_dual_mul_f32 v118, v6, v62 ; c8c67f07 77767d06
	s_wait_dscnt 0x8                                            ; bfc60008
	v_cvt_pk_f32_fp8_e32 v[6:7], v32                            ; 7e0cdd20
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v121, v7, v49                                 ; 10f26307
	v_mul_f32_e32 v120, v6, v48                                 ; 10f06106
	v_cvt_pk_f32_fp8_e32 v[6:7], v160                           ; 7e0cdda0
	s_wait_loadcnt_dscnt 0x707                                  ; bfc80707
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[34:35], v[64:71] ; cc464040 1d024508
	v_dual_mul_f32 v131, v7, v51 :: v_dual_mul_f32 v130, v6, v50 ; c8c66707 83826506
	v_cvt_pk_f32_fp8_e32 v[6:7], v33                            ; 7e0cdd21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v133, v7, v61 :: v_dual_mul_f32 v132, v6, v60 ; c8c67b07 85847906
	v_cvt_pk_f32_fp8_e32 v[6:7], v161                           ; 7e0cdda1
	v_dual_mul_f32 v127, v7, v63 :: v_dual_mul_f32 v126, v6, v62 ; c8c67f07 7f7e7d06
	ds_load_b64 v[32:33], v1 offset:8704                        ; d9d82200 20000001
	ds_load_b64 v[48:49], v1 offset:10752                       ; d9d82a00 30000001
	ds_load_b64 v[50:51], v1 offset:12800                       ; d9d83200 32000001
	ds_load_b64 v[60:61], v1 offset:14848                       ; d9d83a00 3c000001
	ds_load_b64 v[6:7], v1 offset:8960                          ; d9d82300 06000001
	ds_load_b64 v[62:63], v1 offset:11008                       ; d9d82b00 3e000001
	ds_load_b64 v[128:129], v1 offset:13056                     ; d9d83300 80000001
	ds_load_b64 v[134:135], v1 offset:15104                     ; d9d83b00 86000001
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[40:41], v[72:79] ; cc464048 1d225108
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[42:43], v[80:87] ; cc464050 1d425508
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[56:57], v[88:95] ; cc464058 1d627108
	s_wait_dscnt 0x9                                            ; bfc60009
	v_dual_mov_b32 v9, v123 :: v_dual_mov_b32 v8, v122          ; ca10017b 0908017a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[10:11], v[34:35], v[96:103] ; cc464060 1d82450a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_dual_mov_b32 v35, v125 :: v_dual_mov_b32 v34, v124        ; ca10017d 2322017c
	v_dual_mov_b32 v123, v131 :: v_dual_mov_b32 v122, v130      ; ca100183 7b7a0182
	v_dual_mov_b32 v125, v133 :: v_dual_mov_b32 v124, v132      ; ca100185 7d7c0184
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[40:41], v[104:111] ; cc464068 1da2510a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[42:43], v[112:119] ; cc464070 1dc2550a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[56:57], v[120:127] ; cc464078 1de2710a
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[8:9], v[80:87] ; cc464050 1d42110c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[12:13], v[28:29], v[64:71] ; cc464040 1d02390c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[12:13], v[58:59], v[72:79] ; cc464048 1d22750c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[34:35], v[88:95] ; cc464058 1d62450c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[14:15], v[28:29], v[96:103] ; cc464060 1d82390e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[58:59], v[104:111] ; cc464068 1da2750e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[8:9], v[112:119] ; cc464070 1dc2110e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[34:35], v[120:127] ; cc464078 1de2450e
	ds_load_b64 v[10:11], v1 offset:9216                        ; d9d82400 0a000001
	ds_load_b64 v[40:41], v1 offset:11264                       ; d9d82c00 28000001
	ds_load_b64 v[42:43], v1 offset:13312                       ; d9d83400 2a000001
	ds_load_b64 v[56:57], v1 offset:15360                       ; d9d83c00 38000001
	ds_load_b64 v[8:9], v1 offset:9472                          ; d9d82500 08000001
	ds_load_b64 v[12:13], v1 offset:11520                       ; d9d82d00 0c000001
	ds_load_b64 v[14:15], v1 offset:13568                       ; d9d83500 0e000001
	ds_load_b64 v[28:29], v1 offset:15616                       ; d9d83d00 1c000001
	s_wait_loadcnt_dscnt 0x50d                                  ; bfc8050d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[50:51], v[80:87] ; cc464050 1d426510
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[16:17], v[32:33], v[64:71] ; cc464040 1d024110
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[16:17], v[48:49], v[72:79] ; cc464048 1d226110
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[60:61], v[88:95] ; cc464058 1d627910
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[18:19], v[32:33], v[96:103] ; cc464060 1d824112
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[48:49], v[104:111] ; cc464068 1da26112
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[50:51], v[112:119] ; cc464070 1dc26512
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[60:61], v[120:127] ; cc464078 1de27912
	s_wait_loadcnt_dscnt 0x409                                  ; bfc80409
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[128:129], v[80:87] ; cc464050 1d430124
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[36:37], v[6:7], v[64:71] ; cc464040 1d020d24
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[36:37], v[62:63], v[72:79] ; cc464048 1d227d24
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[134:135], v[88:95] ; cc464058 1d630d24
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[6:7], v[96:103] ; cc464060 1d820d26
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[62:63], v[104:111] ; cc464068 1da27d26
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[128:129], v[112:119] ; cc464070 1dc30126
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[134:135], v[120:127] ; cc464078 1de30d26
	ds_load_b64 v[16:17], v1 offset:9728                        ; d9d82600 10000001
	ds_load_b64 v[18:19], v1 offset:11776                       ; d9d82e00 12000001
	ds_load_b64 v[32:33], v1 offset:13824                       ; d9d83600 20000001
	ds_load_b64 v[34:35], v1 offset:15872                       ; d9d83e00 22000001
	ds_load_b64 v[6:7], v1 offset:9984                          ; d9d82700 06000001
	ds_load_b64 v[36:37], v1 offset:12032                       ; d9d82f00 24000001
	ds_load_b64 v[38:39], v1 offset:14080                       ; d9d83700 26000001
	ds_load_b64 v[0:1], v1 offset:16128                         ; d9d83f00 00000001
	s_wait_loadcnt_dscnt 0x30d                                  ; bfc8030d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[42:43], v[80:87] ; cc464050 1d42552c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[44:45], v[10:11], v[64:71] ; cc464040 1d02152c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[44:45], v[40:41], v[72:79] ; cc464048 1d22512c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[56:57], v[88:95] ; cc464058 1d62712c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[10:11], v[96:103] ; cc464060 1d82152e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[40:41], v[104:111] ; cc464068 1da2512e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[42:43], v[112:119] ; cc464070 1dc2552e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[56:57], v[120:127] ; cc464078 1de2712e
	s_wait_loadcnt_dscnt 0x209                                  ; bfc80209
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[52:53], v[14:15], v[80:87] ; cc464050 1d421d34
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[52:53], v[8:9], v[64:71] ; cc464040 1d021134
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[52:53], v[12:13], v[72:79] ; cc464048 1d221934
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[28:29], v[88:95] ; cc464058 1d623934
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[54:55], v[8:9], v[96:103] ; cc464060 1d821136
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[54:55], v[12:13], v[104:111] ; cc464068 1da21936
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[14:15], v[112:119] ; cc464070 1dc21d36
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[28:29], v[120:127] ; cc464078 1de23936
	s_wait_loadcnt_dscnt 0x105                                  ; bfc80105
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[32:33], v[80:87] ; cc464050 1d424118
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[16:17], v[64:71] ; cc464040 1d022118
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[18:19], v[72:79] ; cc464048 1d222518
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[34:35], v[88:95] ; cc464058 1d624518
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[16:17], v[96:103] ; cc464060 1d82211a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[18:19], v[104:111] ; cc464068 1da2251a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[32:33], v[112:119] ; cc464070 1dc2411a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[34:35], v[120:127] ; cc464078 1de2451a
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[38:39], v[80:87] ; cc464050 1d424d14
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[6:7], v[64:71] ; cc464040 1d020d14
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[20:21], v[36:37], v[72:79] ; cc464048 1d224914
	s_cmp_lg_i32 s46, 0                                         ; bf01802e
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[0:1], v[88:95] ; cc464058 1d620114
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[22:23], v[6:7], v[96:103] ; cc464060 1d820d16
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[36:37], v[104:111] ; cc464068 1da24916
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[38:39], v[112:119] ; cc464070 1dc24d16
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[0:1], v[120:127] ; cc464078 1de20116
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_cbranch_scc1 BB3                                          ; bfa20008
BB1:
	v_add3_u32 v4, v2, s2, s26                                  ; d6550004 00680502
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v3, v4, v5                                   ; d6550004 04160903
	buffer_store_b64 v[0:1], v4, s[20:23], null offen           ; c406c07c 40802800 00000004
BB3:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_lg_i32 s49, 0                                         ; bf018031
	s_cbranch_scc1 BB6                                          ; bfa20008
BB4:
	v_add3_u32 v4, v2, s2, s24                                  ; d6550004 00600502
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v3, v4, v5                                   ; d6550004 04160903
	buffer_store_b64 v[0:1], v4, s[20:23], null offen           ; c406c07c 40802800 00000004
BB6:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_cmp_lg_i32 s52, 0                                         ; bf018034
	s_cbranch_scc1 BB9                                          ; bfa20008
BB7:
	v_add3_u32 v4, v2, s2, s18                                  ; d6550004 00480502
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v3, v4, v5                                   ; d6550004 04160903
	buffer_store_b64 v[0:1], v4, s[20:23], null offen           ; c406c07c 40802800 00000004
BB9:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_mov_b32 s3, src_scc                                       ; be8300fd
	s_cmp_lg_i32 s54, 0                                         ; bf018036
	s_cbranch_scc1 BB12                                         ; bfa20008
BB10:
	v_add3_u32 v2, v2, s2, s40                                  ; d6550002 00a00502
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[0:1], v2, s[20:23], null offen           ; c406c07c 40802800 00000002
BB12:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_mov_b32 s63, src_scc                                      ; bebf00fd
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s0, s63                                           ; be80003f
	s_cbranch_scc1 BB15                                         ; bfa20008
BB13:
	v_add3_u32 v2, v31, s2, s26                                 ; d6550002 0068051f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[0:1], v2, s[20:23], null offen           ; c406c07c 40802800 00000002
BB15:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc1 BB18                                         ; bfa20008
BB16:
	v_add3_u32 v2, v31, s2, s24                                 ; d6550002 0060051f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[0:1], v2, s[20:23], null offen           ; c406c07c 40802800 00000002
BB18:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_cmp_lg_i32 s3, 0                                          ; bf018003
	s_cbranch_scc1 BB21                                         ; bfa20008
BB19:
	v_add3_u32 v2, v31, s2, s18                                 ; d6550002 0048051f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[0:1], v2, s[20:23], null offen           ; c406c07c 40802800 00000002
BB21:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB24                                         ; bfa20008
BB22:
	v_add3_u32 v31, v31, s2, s40                                ; d655001f 00a0051f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v3, v3, v31, v5                                  ; d6550003 04163f03
	buffer_store_b64 v[0:1], v3, s[20:23], null offen           ; c406c07c 40802800 00000003
BB24:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
