BB0:
	v_and_b32_e32 v1, 7, v0                                     ; 36020087
	v_lshrrev_b32_e32 v0, 10, v0                                ; 3200008a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshl_add_u32 v1, ttmp9, 3, v1                             ; d6460001 04050675
	v_lshl_add_u32 v0, ttmp7, 3, v0                             ; d6460000 04010673
	v_cmp_le_i32_e32 vcc_lo, s1, v1                             ; 7c860201
(invalid instruction)                                        ; d4430009
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                        ; 02020002
	s_nor_b32 exec_lo, vcc_lo, s9                               ; 8f7e096a
	s_cbranch_execz BB66                                        ; bfa50a29
BB1:
	s_cmp_eq_i32 s6, 0                                          ; bf008006
	s_cbranch_scc0 BB3                                          ; bfa1005f
BB2:
	s_mov_b32 s10, s0                                           ; be8a0000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_load_b256 s[16:23], s[10:11], 0x40                        ; f4006405 f8000040
	v_sub_nc_u32_e32 v2, 0, v1                                  ; 4c040280
	v_med3_i32 v3, -1, v1, 1                                    ; d6200003 020602c1
	s_add_co_u32 s3, s3, -1                                     ; 8003c103
	v_sub_nc_u32_e32 v4, 0, v0                                  ; 4c080080
	v_med3_i32 v5, -1, v0, 1                                    ; d6200005 020600c1
	s_add_co_u32 s4, s4, -1                                     ; 8004c104
	v_max_i32_e32 v2, v1, v2                                    ; 24040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_max_i32_e32 v4, v0, v4                                    ; 24080900
	v_lshrrev_b32_e32 v2, 1, v2                                 ; 32040481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshrrev_b32_e32 v4, 1, v4                                 ; 32080881
(invalid instruction)                                        ; d72c0003
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                        ; 02020503
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v1, v5, v4, vcc_lo                        ; 02020905
	v_add_nc_u32_e32 v8, -1, v3                                 ; 4a1006c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_maxmin_i32 v6, 0, v3, s3                                  ; d6640006 000e0680
	v_add_nc_u32_e32 v3, 1, v3                                  ; 4a060681
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add_nc_u32_e32 v9, -1, v5                                 ; 4a120ac1
	v_maxmin_i32 v7, 0, v5, s4                                  ; d6640007 00120a80
	v_add_nc_u32_e32 v5, 1, v5                                  ; 4a0a0a81
	v_maxmin_i32 v8, 0, v8, s3                                  ; d6640008 000e1080
	v_maxmin_i32 v3, 0, v3, s3                                  ; d6640003 000e0680
	v_maxmin_i32 v9, 0, v9, s4                                  ; d6640009 00121280
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_maxmin_i32 v5, 0, v5, s4                                  ; d6640005 00120a80
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x4                                                ; bf850004
	image_load v[10:11], [v6, v7], s[16:23] dmask:0x3 dim:SQ_RSRC_IMG_2D ; d0c00001 0000200a 00000706
	image_load v[12:13], [v8, v7], s[16:23] dmask:0x3 dim:SQ_RSRC_IMG_2D ; d0c00001 0000200c 00000708
	image_load v[2:3], [v3, v7], s[16:23] dmask:0x3 dim:SQ_RSRC_IMG_2D ; d0c00001 00002002 00000703
	image_load v[8:9], [v6, v9], s[16:23] dmask:0x3 dim:SQ_RSRC_IMG_2D ; d0c00001 00002008 00000906
	image_load v[4:5], [v6, v5], s[16:23] dmask:0x3 dim:SQ_RSRC_IMG_2D ; d0c00001 00002004 00000506
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mul_f32 v11, 2.0, v11 :: v_dual_mul_f32 v10, 2.0, v10 ; c8c616f4 0b0a14f4
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v13, 2.0, v13 :: v_dual_mul_f32 v12, 2.0, v12 ; c8c61af4 0d0c18f4
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v3, 2.0, v3 :: v_dual_mul_f32 v2, 2.0, v2    ; c8c606f4 030204f4
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_dual_mul_f32 v9, 2.0, v9 :: v_dual_mul_f32 v8, 2.0, v8    ; c8c612f4 090810f4
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mul_f32 v5, 2.0, v5 :: v_dual_mul_f32 v4, 2.0, v4    ; c8c60af4 050408f4
	v_rndne_f32_e32 v10, v10                                    ; 7e14470a
	v_rndne_f32_e32 v11, v11                                    ; 7e16470b
	v_rndne_f32_e32 v13, v13                                    ; 7e1a470d
	v_rndne_f32_e32 v12, v12                                    ; 7e18470c
	v_rndne_f32_e32 v2, v2                                      ; 7e044702
	v_rndne_f32_e32 v3, v3                                      ; 7e064703
	v_rndne_f32_e32 v8, v8                                      ; 7e104708
	v_rndne_f32_e32 v9, v9                                      ; 7e124709
	v_rndne_f32_e32 v4, v4                                      ; 7e084704
	s_mov_b32 s3, 6                                             ; be830086
	v_rndne_f32_e32 v5, v5                                      ; 7e0a4705
	v_cvt_i32_f32_e32 v10, v10                                  ; 7e14110a
	v_cvt_i32_f32_e32 v11, v11                                  ; 7e16110b
	v_cvt_i32_f32_e32 v13, v13                                  ; 7e1a110d
	v_cvt_i32_f32_e32 v12, v12                                  ; 7e18110c
	v_cvt_i32_f32_e32 v2, v2                                    ; 7e041102
	v_cvt_i32_f32_e32 v3, v3                                    ; 7e061103
	v_cvt_i32_f32_e32 v8, v8                                    ; 7e101108
	v_cvt_i32_f32_e32 v9, v9                                    ; 7e121109
	v_cvt_i32_f32_e32 v4, v4                                    ; 7e081104
	v_cvt_i32_f32_e32 v5, v5                                    ; 7e0a1105
	s_branch BB4                                                ; bfa00001
BB3:
	s_mov_b32 s3, 1                                             ; be830081
BB4:
	v_mov_b32_e32 v6, 0                                         ; 7e0c0280
	v_dual_mov_b32 v14, 0x7f61b1e6 :: v_dual_mov_b32 v7, 0      ; ca1000ff 0e060080 7f61b1e6
	s_mov_b32 s4, 0                                             ; be840080
BB5:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_i32 s4, s3                                         ; bf030304
	s_cbranch_scc1 BB17                                         ; bfa2017c
BB7:
	s_cmp_lt_i32 s4, 3                                          ; bf048304
	s_cbranch_scc0 BB9                                          ; bfa1000f
BB8:
	s_cmp_lt_i32 s4, 2                                          ; bf048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_cmp_lt_i32 s4, 1                                          ; bf048104
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v16, v13, v11 :: v_dual_cndmask_b32 v15, v12, v10 ; ca52170d 100e150c
	s_cselect_b32 s6, -1, 0                                     ; 980680c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cndmask_b32_e64 v15, v15, 0, s6                           ; d501000f 0019010f
	v_cndmask_b32_e64 v16, v16, 0, s6                           ; d5010010 00190110
	s_branch BB10                                               ; bfa0000c
BB9:
	s_cmp_lt_i32 s4, 5                                          ; bf048504
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_cmp_lt_i32 s4, 4                                          ; bf048404
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v16, v5, v9 :: v_dual_cndmask_b32 v15, v4, v8 ; ca521305 100e1104
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_cndmask_b32 v16, v16, v3 :: v_dual_cndmask_b32 v15, v15, v2 ; ca520710 100e050f
BB10:
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_add_nc_u32_e32 v17, v1, v15                               ; 4a221f01
	v_add_nc_u32_e32 v18, v0, v16                               ; 4a242100
	v_add_nc_u32_e32 v20, -2, v17                               ; 4a2822c2
	v_add_nc_u32_e32 v21, 2, v17                                ; 4a2a2282
	v_add_nc_u32_e32 v19, -2, v18                               ; 4a2624c2
	v_add_nc_u32_e32 v22, 2, v18                                ; 4a2c2482
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; d4430006
	v_cndmask_b32_e32 v1, s1, v21, vcc_lo                       ; 02022a01
	v_min_i32_e32 v20, v20, v19                                 ; 22282714
	v_cmp_gt_i32_e32 vcc_lo, 0, v20                             ; 7c882880
	s_or_b32 s6, vcc_lo, s6                                     ; 8c06066a
	v_cmp_le_i32_e32 vcc_lo, s2, v22                            ; 7c862c02
	s_nor_b32 s6, s6, vcc_lo                                    ; 8f066a06
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_saveexec_b32 s6, s6                                   ; be862006
	s_cbranch_execz BB14                                        ; bfa50140
BB11:
	s_mov_b32 s10, s0                                           ; be8a0000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_load_b512 s[16:31], s[10:11], 0x0                         ; f4008405 f8000000
	v_add_nc_u32_e32 v19, -2, v1                                ; 4a2602c2
	v_add_nc_u32_e32 v26, 1, v1                                 ; 4a340281
	v_add_nc_u32_e32 v21, -2, v0                                ; 4a2a00c2
	s_add_co_u32 s9, s1, -1                                     ; 8009c101
	v_add_nc_u32_e32 v28, 2, v1                                 ; 4a380282
	s_add_co_u32 s10, s2, -1                                    ; 800ac102
	v_add_nc_u32_e32 v23, -1, v1                                ; 4a2e02c1
	v_add_nc_u32_e32 v30, -1, v0                                ; 4a3c00c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_maxmin_i32 v20, 0, v19, s9                                ; d6640014 00262680
	v_add_nc_u32_e32 v19, v19, v15                              ; 4a261f13
	v_maxmin_i32 v27, 0, v26, s9                                ; d664001b 00263480
	v_add_nc_u32_e32 v26, v26, v15                              ; 4a341f1a
	v_maxmin_i32 v25, 0, v1, s9                                 ; d6640019 00260280
	v_maxmin_i32 v22, 0, v21, s10                               ; d6640016 002a2a80
	v_add_nc_u32_e32 v21, v21, v16                              ; 4a2a2115
	v_maxmin_i32 v17, 0, v17, s9                                ; d6640011 00262280
	v_maxmin_i32 v29, 0, v28, s9                                ; d664001d 00263880
	v_add_nc_u32_e32 v28, v28, v15                              ; 4a381f1c
	v_maxmin_i32 v24, 0, v23, s9                                ; d6640018 00262e80
	v_add_nc_u32_e32 v23, v23, v15                              ; 4a2e1f17
	v_maxmin_i32 v32, 0, v0, s10                                ; d6640020 002a0080
	v_maxmin_i32 v31, 0, v30, s10                               ; d664001f 002a3c80
	v_add_nc_u32_e32 v30, v30, v16                              ; 4a3c211e
	v_maxmin_i32 v18, 0, v18, s10                               ; d6640012 002a2480
	v_maxmin_i32 v19, 0, v19, s9                                ; d6640013 00262680
	v_maxmin_i32 v26, 0, v26, s9                                ; d664001a 00263480
	v_maxmin_i32 v21, 0, v21, s10                               ; d6640015 002a2a80
	v_maxmin_i32 v28, 0, v28, s9                                ; d664001c 00263880
	v_maxmin_i32 v23, 0, v23, s9                                ; d6640017 00262e80
	v_maxmin_i32 v30, 0, v30, s10                               ; d664001e 002a3c80
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0xe                                                ; bf85000e
	image_load v33, [v19, v21], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003021 00001513
	image_load v34, [v23, v21], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003022 00001517
	image_load v35, [v17, v21], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003023 00001511
	image_load v36, [v26, v21], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003024 0000151a
	image_load v21, [v28, v21], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003015 0000151c
	image_load v37, [v19, v30], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003025 00001e13
	image_load v38, [v23, v30], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003026 00001e17
	image_load v39, [v17, v30], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003027 00001e11
	image_load v40, [v26, v30], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003028 00001e1a
	image_load v30, [v28, v30], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301e 00001e1c
	image_load v41, [v19, v18], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003029 00001213
	image_load v42, [v23, v18], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000302a 00001217
	image_load v43, [v17, v18], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000302b 00001211
	image_load v44, [v26, v18], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000302c 0000121a
	image_load v18, [v28, v18], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003012 0000121c
	v_add_nc_u32_e32 v45, 1, v0                                 ; 4a5a0081
	v_add_nc_u32_e32 v51, 2, v0                                 ; 4a660082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
	v_maxmin_i32 v46, 0, v45, s10                               ; d664002e 002a5a80
	v_add_nc_u32_e32 v45, v45, v16                              ; 4a5a212d
	v_maxmin_i32 v52, 0, v51, s10                               ; d6640034 002a6680
	v_add_nc_u32_e32 v51, v51, v16                              ; 4a662133
	v_maxmin_i32 v45, 0, v45, s10                               ; d664002d 002a5a80
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_maxmin_i32 v51, 0, v51, s10                               ; d6640033 002a6680
	s_clause 0x8                                                ; bf850008
	image_load v47, [v19, v45], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000302f 00002d13
	image_load v48, [v23, v45], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003030 00002d17
	image_load v49, [v17, v45], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003031 00002d11
	image_load v50, [v26, v45], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003032 00002d1a
	image_load v45, [v28, v45], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000302d 00002d1c
	image_load v19, [v19, v51], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003013 00003313
	image_load v23, [v23, v51], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003017 00003317
	image_load v17, [v17, v51], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003011 00003311
	image_load v26, [v26, v51], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301a 0000331a
	s_clause 0x18                                               ; bf850018
	image_load v53, [v20, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002035 00001614
	image_load v54, [v24, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002036 00001618
	image_load v55, [v25, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002037 00001619
	image_load v56, [v27, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002038 0000161b
	image_load v22, [v29, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002016 0000161d
	image_load v57, [v20, v31], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002039 00001f14
	image_load v58, [v24, v31], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203a 00001f18
	image_load v59, [v25, v31], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203b 00001f19
	image_load v60, [v27, v31], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203c 00001f1b
	image_load v31, [v29, v31], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000201f 00001f1d
	image_load v61, [v20, v32], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203d 00002014
	image_load v62, [v24, v32], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203e 00002018
	image_load v63, [v25, v32], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203f 00002019
	image_load v64, [v27, v32], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002040 0000201b
	image_load v32, [v29, v32], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002020 0000201d
	image_load v65, [v20, v46], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002041 00002e14
	image_load v66, [v24, v46], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002042 00002e18
	image_load v67, [v25, v46], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002043 00002e19
	image_load v68, [v27, v46], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002044 00002e1b
	image_load v46, [v29, v46], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202e 00002e1d
	image_load v20, [v20, v52], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002014 00003414
	image_load v24, [v24, v52], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002018 00003418
	image_load v25, [v25, v52], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002019 00003419
	image_load v27, [v27, v52], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000201b 0000341b
	image_load v29, [v29, v52], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000201d 0000341d
	image_load v28, [v28, v51], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301c 0000331c
	s_wait_loadcnt 0x18                                         ; bfc00018
	v_sub_f32_e32 v54, v54, v34                                 ; 086c4536
	s_wait_loadcnt 0x16                                         ; bfc00016
	v_dual_sub_f32 v56, v56, v36 :: v_dual_sub_f32 v53, v53, v33 ; c94a4938 38344335
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_dual_sub_f32 v22, v22, v21 :: v_dual_sub_f32 v55, v55, v35 ; c94a2b16 16364737
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_dual_sub_f32 v58, v58, v38 :: v_dual_sub_f32 v57, v57, v37 ; c94a4d3a 3a384b39
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_sub_f32 v60, v60, v40 :: v_dual_sub_f32 v31, v31, v30 ; c94a513c 3c1e3d1f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d5030335
	v_cndmask_b32_e32 v1, v53, v54, vcc_lo                      ; 02026d35
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_dual_sub_f32 v62, v62, v42 :: v_dual_sub_f32 v59, v59, v39 ; c94a553e 3e3a4f3b
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_dual_sub_f32 v64, v64, v44 :: v_dual_sub_f32 v61, v61, v41 ; c94a5940 403c533d
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_dual_sub_f32 v32, v32, v18 :: v_dual_sub_f32 v63, v63, v43 ; c94a2520 203e573f
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_dual_sub_f32 v66, v66, v48 :: v_dual_sub_f32 v65, v65, v47 ; c94a6142 42405f41
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v55, vcc_lo                      ; 02026f35
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_subrev_f32 v46, v45, v46 :: v_dual_sub_f32 v67, v67, v49 ; c98a5d2d 2e426343
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_sub_f32 v25, v25, v17 :: v_dual_sub_f32 v68, v68, v50 ; c94a2319 19446544
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_sub_f32 v27, v27, v26 :: v_dual_sub_f32 v20, v20, v19 ; c94a351b 1b142714
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v56, vcc_lo                      ; 02027135
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_sub_f32 v29, v29, v28 :: v_dual_sub_f32 v24, v24, v23 ; c94a391d 1d182f18
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v22, vcc_lo                      ; 02022d35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v57, vcc_lo                      ; 02027335
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v58, vcc_lo                      ; 02027535
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v59, vcc_lo                      ; 02027735
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v60, vcc_lo                      ; 02027935
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v31, vcc_lo                      ; 02023f35
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v61, vcc_lo                      ; 02027b35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v62, vcc_lo                      ; 02027d35
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v63, vcc_lo                      ; 02027f35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v64, vcc_lo                      ; 02028135
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v32, vcc_lo                      ; 02024135
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v65, vcc_lo                      ; 02028335
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v66, vcc_lo                      ; 02028535
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v67, vcc_lo                      ; 02028735
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v68, vcc_lo                      ; 02028935
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v46, vcc_lo                      ; 02025d35
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v20, vcc_lo                      ; 02022935
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v24, vcc_lo                      ; 02023135
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v25, vcc_lo                      ; 02023335
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v27, vcc_lo                      ; 02023735
(invalid instruction)                                        ; d5030235
	v_cndmask_b32_e32 v1, v53, v29, vcc_lo                      ; 02023b35
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v53, 0x3d23d70a, v53                          ; 106a6aff 3d23d70a
BB14:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 exec_lo, s6, exec_lo                         ; 917e7e06
	v_mov_b32_e32 v53, 0x7f61b1e6                               ; 7e6a02ff 7f61b1e6
BB16:
	s_mov_b32 exec_lo, s6                                       ; befe0006
	s_add_co_u32 s4, s4, 1                                      ; 80048104
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmp_lt_f32_e32 vcc_lo, v53, v14                           ; 7c221d35
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v14, v14, v53, vcc_lo                     ; 021c6b0e
	v_dual_cndmask_b32 v6, v6, v16 :: v_dual_cndmask_b32 v7, v7, v15 ; ca522106 06061f07
	s_branch BB5                                                ; bfa0fe81
BB17:
	s_sub_co_i32 s3, 0, s5                                      ; 81830580
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s4, s3                                            ; be840003
	s_branch BB18                                               ; bfa00001
BB33:
	s_add_co_u32 s4, s4, 1                                      ; 80048104
BB18:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s5, s4                                         ; bf040405
	s_cbranch_scc1 BB34                                         ; bfa2016f
BB20:
	s_mov_b32 s6, s3                                            ; be860003
	s_nop 0                                                     ; bf800000
	(then repeated 4 times)
BB21:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s5, s6                                         ; bf040605
	s_cbranch_scc1 BB33                                         ; bfa2fff3
BB23:
	s_max_u32 s9, s6, s4                                        ; 8a890406
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s9, 0                                          ; bf018009
	s_cbranch_scc0 BB32                                         ; bfa10160
BB24:
	v_add_nc_u32_e32 v2, s6, v7                                 ; 4a040e06
	v_add_nc_u32_e32 v3, s4, v6                                 ; 4a060c04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_add_nc_u32_e32 v4, v1, v2                                 ; 4a080501
	v_add_nc_u32_e32 v5, v0, v3                                 ; 4a0a0700
	v_add_nc_u32_e32 v9, -2, v4                                 ; 4a1208c2
	v_add_nc_u32_e32 v10, 2, v4                                 ; 4a140882
	v_add_nc_u32_e32 v8, -2, v5                                 ; 4a100ac2
	v_add_nc_u32_e32 v11, 2, v5                                 ; 4a160a82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; d4430009
	v_cndmask_b32_e32 v1, s1, v10, vcc_lo                       ; 02021401
	v_min_i32_e32 v9, v9, v8                                    ; 22121109
	v_cmp_gt_i32_e32 vcc_lo, 0, v9                              ; 7c881280
	s_or_b32 s9, vcc_lo, s9                                     ; 8c09096a
	v_cmp_le_i32_e32 vcc_lo, s2, v11                            ; 7c861602
	s_nor_b32 s9, s9, vcc_lo                                    ; 8f096a09
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_saveexec_b32 s9, s9                                   ; be892009
	s_cbranch_execz BB28                                        ; bfa50141
BB25:
	s_mov_b32 s10, s0                                           ; be8a0000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_load_b512 s[16:31], s[10:11], 0x0                         ; f4008405 f8000000
	v_add_nc_u32_e32 v8, -2, v1                                 ; 4a1002c2
	v_add_nc_u32_e32 v10, -2, v0                                ; 4a1400c2
	s_add_co_u32 s10, s1, -1                                    ; 800ac101
	s_add_co_u32 s11, s2, -1                                    ; 800bc102
	v_add_nc_u32_e32 v12, -1, v1                                ; 4a1802c1
	v_add_nc_u32_e32 v16, 1, v1                                 ; 4a200281
	v_add_nc_u32_e32 v18, 2, v1                                 ; 4a240282
	v_add_nc_u32_e32 v20, -1, v0                                ; 4a2800c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_maxmin_i32 v9, 0, v8, s10                                 ; d6640009 002a1080
	v_add_nc_u32_e32 v8, v8, v2                                 ; 4a100508
	v_maxmin_i32 v11, 0, v10, s11                               ; d664000b 002e1480
	v_add_nc_u32_e32 v10, v10, v3                               ; 4a14070a
	v_maxmin_i32 v15, 0, v1, s10                                ; d664000f 002a0280
	v_maxmin_i32 v4, 0, v4, s10                                 ; d6640004 002a0880
	v_maxmin_i32 v13, 0, v12, s10                               ; d664000d 002a1880
	v_add_nc_u32_e32 v12, v12, v2                               ; 4a18050c
	v_maxmin_i32 v17, 0, v16, s10                               ; d6640011 002a2080
	v_add_nc_u32_e32 v16, v16, v2                               ; 4a200510
	v_maxmin_i32 v19, 0, v18, s10                               ; d6640013 002a2480
	v_add_nc_u32_e32 v18, v18, v2                               ; 4a240512
	v_maxmin_i32 v22, 0, v0, s11                                ; d6640016 002e0080
	v_maxmin_i32 v21, 0, v20, s11                               ; d6640015 002e2880
	v_add_nc_u32_e32 v20, v20, v3                               ; 4a280714
	v_maxmin_i32 v5, 0, v5, s11                                 ; d6640005 002e0a80
	v_maxmin_i32 v8, 0, v8, s10                                 ; d6640008 002a1080
	v_maxmin_i32 v10, 0, v10, s11                               ; d664000a 002e1480
	v_maxmin_i32 v12, 0, v12, s10                               ; d664000c 002a1880
	v_maxmin_i32 v16, 0, v16, s10                               ; d6640010 002a2080
	v_maxmin_i32 v18, 0, v18, s10                               ; d6640012 002a2480
	v_maxmin_i32 v20, 0, v20, s11                               ; d6640014 002e2880
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0xe                                                ; bf85000e
	image_load v23, [v8, v10], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003017 00000a08
	image_load v24, [v12, v10], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003018 00000a0c
	image_load v25, [v4, v10], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003019 00000a04
	image_load v26, [v16, v10], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301a 00000a10
	image_load v10, [v18, v10], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000300a 00000a12
	image_load v27, [v8, v20], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301b 00001408
	image_load v28, [v12, v20], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301c 0000140c
	image_load v29, [v4, v20], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301d 00001404
	image_load v30, [v16, v20], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301e 00001410
	image_load v20, [v18, v20], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003014 00001412
	image_load v31, [v8, v5], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301f 00000508
	image_load v32, [v12, v5], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003020 0000050c
	image_load v33, [v4, v5], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003021 00000504
	image_load v34, [v16, v5], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003022 00000510
	image_load v5, [v18, v5], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003005 00000512
	v_add_nc_u32_e32 v35, 1, v0                                 ; 4a460081
	v_add_nc_u32_e32 v41, 2, v0                                 ; 4a520082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
	v_maxmin_i32 v36, 0, v35, s11                               ; d6640024 002e4680
	v_add_nc_u32_e32 v35, v35, v3                               ; 4a460723
	v_maxmin_i32 v42, 0, v41, s11                               ; d664002a 002e5280
	v_add_nc_u32_e32 v41, v41, v3                               ; 4a520729
	v_maxmin_i32 v35, 0, v35, s11                               ; d6640023 002e4680
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_maxmin_i32 v41, 0, v41, s11                               ; d6640029 002e5280
	s_clause 0x8                                                ; bf850008
	image_load v37, [v8, v35], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003025 00002308
	image_load v38, [v12, v35], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003026 0000230c
	image_load v39, [v4, v35], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003027 00002304
	image_load v40, [v16, v35], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003028 00002310
	image_load v35, [v18, v35], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003023 00002312
	image_load v8, [v8, v41], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003008 00002908
	image_load v12, [v12, v41], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000300c 0000290c
	image_load v4, [v4, v41], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003004 00002904
	image_load v16, [v16, v41], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003010 00002910
	s_clause 0x18                                               ; bf850018
	image_load v43, [v9, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202b 00000b09
	image_load v44, [v13, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202c 00000b0d
	image_load v45, [v15, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202d 00000b0f
	image_load v46, [v17, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202e 00000b11
	image_load v11, [v19, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200b 00000b13
	image_load v47, [v9, v21], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202f 00001509
	image_load v48, [v13, v21], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002030 0000150d
	image_load v49, [v15, v21], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002031 0000150f
	image_load v50, [v17, v21], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002032 00001511
	image_load v21, [v19, v21], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002015 00001513
	image_load v51, [v9, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002033 00001609
	image_load v52, [v13, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002034 0000160d
	image_load v53, [v15, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002035 0000160f
	image_load v54, [v17, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002036 00001611
	image_load v22, [v19, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002016 00001613
	image_load v55, [v9, v36], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002037 00002409
	image_load v56, [v13, v36], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002038 0000240d
	image_load v57, [v15, v36], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002039 0000240f
	image_load v58, [v17, v36], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203a 00002411
	image_load v36, [v19, v36], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002024 00002413
	image_load v9, [v9, v42], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002009 00002a09
	image_load v13, [v13, v42], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200d 00002a0d
	image_load v15, [v15, v42], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200f 00002a0f
	image_load v17, [v17, v42], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002011 00002a11
	image_load v19, [v19, v42], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002013 00002a13
	image_load v18, [v18, v41], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003012 00002912
	s_wait_loadcnt 0x19                                         ; bfc00019
	v_sub_f32_e32 v43, v43, v23                                 ; 08562f2b
	s_wait_loadcnt 0x17                                         ; bfc00017
	v_sub_f32_e32 v45, v45, v25                                 ; 085a332d
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_sub_f32_e32 v11, v11, v10                                 ; 0816150b
	s_wait_loadcnt 0x14                                         ; bfc00014
	v_sub_f32_e32 v47, v47, v27                                 ; 085e372f
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_dual_sub_f32 v49, v49, v29 :: v_dual_sub_f32 v44, v44, v24 ; c94a3b31 312c312c
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_sub_f32_e32 v21, v21, v20                                 ; 082a2915
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_dual_sub_f32 v51, v51, v31 :: v_dual_sub_f32 v46, v46, v26 ; c94a3f33 332e352e
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_dual_sub_f32 v53, v53, v33 :: v_dual_sub_f32 v48, v48, v28 ; c94a4335 35303930
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
(invalid instruction)                                        ; d503032b
	v_cndmask_b32_e32 v1, v43, v44, vcc_lo                      ; 0202592b
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_dual_sub_f32 v55, v55, v37 :: v_dual_sub_f32 v50, v50, v30 ; c94a4b37 37323d32
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_dual_sub_f32 v57, v57, v39 :: v_dual_sub_f32 v52, v52, v32 ; c94a4f39 39344134
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v45, vcc_lo                      ; 02025b2b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_sub_f32 v9, v9, v8 :: v_dual_sub_f32 v54, v54, v34   ; c94a1109 09364536
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_sub_f32 v13, v13, v12 :: v_dual_sub_f32 v22, v22, v5 ; c94a190d 0d160b16
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_sub_f32 v15, v15, v4 :: v_dual_sub_f32 v56, v56, v38 ; c94a090f 0f384d38
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_subrev_f32 v17, v16, v17 :: v_dual_sub_f32 v58, v58, v40 ; c98a2310 113a513a
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v46, vcc_lo                      ; 02025d2b
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_sub_f32 v19, v19, v18 :: v_dual_sub_f32 v36, v36, v35 ; c94a2513 13244724
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v11, vcc_lo                      ; 0202172b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v47, vcc_lo                      ; 02025f2b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v48, vcc_lo                      ; 0202612b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v49, vcc_lo                      ; 0202632b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v50, vcc_lo                      ; 0202652b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v21, vcc_lo                      ; 02022b2b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v51, vcc_lo                      ; 0202672b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v52, vcc_lo                      ; 0202692b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v53, vcc_lo                      ; 02026b2b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v54, vcc_lo                      ; 02026d2b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v22, vcc_lo                      ; 02022d2b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v55, vcc_lo                      ; 02026f2b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v56, vcc_lo                      ; 0202712b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v57, vcc_lo                      ; 0202732b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v58, vcc_lo                      ; 0202752b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v36, vcc_lo                      ; 0202492b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v9, vcc_lo                       ; 0202132b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v13, vcc_lo                      ; 02021b2b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v15, vcc_lo                      ; 02021f2b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v17, vcc_lo                      ; 0202232b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v19, vcc_lo                      ; 0202272b
	v_mul_f32_e32 v43, 0x3d23d70a, v43                          ; 105656ff 3d23d70a
BB28:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 exec_lo, s9, exec_lo                         ; 917e7e09
	v_mov_b32_e32 v43, 0x7f61b1e6                               ; 7e5602ff 7f61b1e6
BB30:
	s_mov_b32 exec_lo, s9                                       ; befe0009
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmp_lt_f32_e32 vcc_lo, v43, v14                           ; 7c221d2b
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v14, v14, v43, vcc_lo                     ; 021c570e
	v_dual_cndmask_b32 v6, v6, v3 :: v_dual_cndmask_b32 v7, v7, v2 ; ca520706 06060507
BB32:
	s_add_co_u32 s6, s6, 1                                      ; 80068106
	s_branch BB21                                               ; bfa0fe97
BB34:
	v_cvt_f32_i32_e32 v2, v7                                    ; 7e040b07
	v_cvt_f32_i32_e32 v3, v6                                    ; 7e060b06
	s_cmp_lg_i32 s7, 0                                          ; bf018007
	s_cbranch_scc0 BB61                                         ; bfa106c1
BB35:
	v_add_nc_u32_e32 v4, -1, v7                                 ; 4a080ec1
	v_add_nc_u32_e32 v8, v0, v6                                 ; 4a100d00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_add_nc_u32_e32 v5, v1, v4                                 ; 4a0a0901
	v_add_nc_u32_e32 v9, -2, v8                                 ; 4a1210c2
	v_add_nc_u32_e32 v12, 2, v8                                 ; 4a181082
	v_add_nc_u32_e32 v10, -2, v5                                ; 4a140ac2
	v_add_nc_u32_e32 v11, 2, v5                                 ; 4a160a82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_min_i32_e32 v10, v10, v9                                  ; 2214130a
(invalid instruction)                                        ; d4430003
	v_cndmask_b32_e32 v1, s1, v11, vcc_lo                       ; 02021601
	v_cmp_gt_i32_e32 vcc_lo, 0, v10                             ; 7c881480
	s_or_b32 s3, vcc_lo, s3                                     ; 8c03036a
	v_cmp_le_i32_e32 vcc_lo, s2, v12                            ; 7c861802
	s_nor_b32 s3, s3, vcc_lo                                    ; 8f036a03
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_saveexec_b32 s3, s3                                   ; be832003
	s_cbranch_execz BB39                                        ; bfa50142
BB36:
	s_mov_b32 s4, s0                                            ; be840000
	s_movk_i32 s5, 0x8000                                       ; b0058000
	s_load_b512 s[16:31], s[4:5], 0x0                           ; f4008402 f8000000
	v_add_nc_u32_e32 v10, -2, v1                                ; 4a1402c2
	v_add_nc_u32_e32 v15, -1, v1                                ; 4a1e02c1
	v_add_nc_u32_e32 v12, -2, v0                                ; 4a1800c2
	s_add_co_u32 s4, s1, -1                                     ; 8004c101
	s_add_co_u32 s5, s2, -1                                     ; 8005c102
	v_add_nc_u32_e32 v18, 1, v1                                 ; 4a240281
	v_add_nc_u32_e32 v20, 2, v1                                 ; 4a280282
	v_add_nc_u32_e32 v22, -1, v0                                ; 4a2c00c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_maxmin_i32 v11, 0, v10, s4                                ; d664000b 00121480
	v_add_nc_u32_e32 v10, v10, v4                               ; 4a14090a
	v_maxmin_i32 v16, 0, v15, s4                                ; d6640010 00121e80
	v_add_nc_u32_e32 v15, v15, v4                               ; 4a1e090f
	v_maxmin_i32 v17, 0, v1, s4                                 ; d6640011 00120280
	v_maxmin_i32 v13, 0, v12, s5                                ; d664000d 00161880
	v_add_nc_u32_e32 v12, v12, v6                               ; 4a180d0c
	v_maxmin_i32 v5, 0, v5, s4                                  ; d6640005 00120a80
	v_maxmin_i32 v19, 0, v18, s4                                ; d6640013 00122480
	v_add_nc_u32_e32 v18, v18, v4                               ; 4a240912
	v_maxmin_i32 v21, 0, v20, s4                                ; d6640015 00122880
	v_add_nc_u32_e32 v20, v20, v4                               ; 4a280914
	v_maxmin_i32 v24, 0, v0, s5                                 ; d6640018 00160080
	v_maxmin_i32 v23, 0, v22, s5                                ; d6640017 00162c80
	v_add_nc_u32_e32 v22, v22, v6                               ; 4a2c0d16
	v_maxmin_i32 v25, 0, v8, s5                                 ; d6640019 00161080
	v_maxmin_i32 v10, 0, v10, s4                                ; d664000a 00121480
	v_maxmin_i32 v15, 0, v15, s4                                ; d664000f 00121e80
	v_maxmin_i32 v12, 0, v12, s5                                ; d664000c 00161880
	v_maxmin_i32 v18, 0, v18, s4                                ; d6640012 00122480
	v_maxmin_i32 v20, 0, v20, s4                                ; d6640014 00122880
	v_maxmin_i32 v22, 0, v22, s5                                ; d6640016 00162c80
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0xe                                                ; bf85000e
	image_load v26, [v10, v12], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301a 00000c0a
	image_load v27, [v15, v12], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301b 00000c0f
	image_load v28, [v5, v12], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301c 00000c05
	image_load v29, [v18, v12], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301d 00000c12
	image_load v12, [v20, v12], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000300c 00000c14
	image_load v30, [v10, v22], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301e 0000160a
	image_load v31, [v15, v22], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301f 0000160f
	image_load v32, [v5, v22], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003020 00001605
	image_load v33, [v18, v22], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003021 00001612
	image_load v22, [v20, v22], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003016 00001614
	image_load v34, [v10, v25], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003022 0000190a
	image_load v35, [v15, v25], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003023 0000190f
	image_load v36, [v5, v25], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003024 00001905
	image_load v37, [v18, v25], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003025 00001912
	image_load v25, [v20, v25], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003019 00001914
	v_add_nc_u32_e32 v38, 1, v0                                 ; 4a4c0081
	v_add_nc_u32_e32 v44, 2, v0                                 ; 4a580082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
	v_maxmin_i32 v39, 0, v38, s5                                ; d6640027 00164c80
	v_add_nc_u32_e32 v38, v38, v6                               ; 4a4c0d26
	v_maxmin_i32 v45, 0, v44, s5                                ; d664002d 00165880
	v_add_nc_u32_e32 v44, v44, v6                               ; 4a580d2c
	v_maxmin_i32 v38, 0, v38, s5                                ; d6640026 00164c80
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_maxmin_i32 v44, 0, v44, s5                                ; d664002c 00165880
	s_clause 0x8                                                ; bf850008
	image_load v40, [v10, v38], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003028 0000260a
	image_load v41, [v15, v38], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003029 0000260f
	image_load v42, [v5, v38], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000302a 00002605
	image_load v43, [v18, v38], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000302b 00002612
	image_load v38, [v20, v38], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003026 00002614
	image_load v10, [v10, v44], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000300a 00002c0a
	image_load v15, [v15, v44], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000300f 00002c0f
	image_load v5, [v5, v44], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003005 00002c05
	image_load v18, [v18, v44], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003012 00002c12
	s_clause 0x18                                               ; bf850018
	image_load v46, [v11, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202e 00000d0b
	image_load v47, [v16, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202f 00000d10
	image_load v48, [v17, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002030 00000d11
	image_load v49, [v19, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002031 00000d13
	image_load v13, [v21, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200d 00000d15
	image_load v50, [v11, v23], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002032 0000170b
	image_load v51, [v16, v23], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002033 00001710
	image_load v52, [v17, v23], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002034 00001711
	image_load v53, [v19, v23], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002035 00001713
	image_load v23, [v21, v23], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002017 00001715
	image_load v54, [v11, v24], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002036 0000180b
	image_load v55, [v16, v24], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002037 00001810
	image_load v56, [v17, v24], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002038 00001811
	image_load v57, [v19, v24], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002039 00001813
	image_load v24, [v21, v24], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002018 00001815
	image_load v58, [v11, v39], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203a 0000270b
	image_load v59, [v16, v39], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203b 00002710
	image_load v60, [v17, v39], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203c 00002711
	image_load v61, [v19, v39], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203d 00002713
	image_load v39, [v21, v39], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002027 00002715
	image_load v11, [v11, v45], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200b 00002d0b
	image_load v16, [v16, v45], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002010 00002d10
	image_load v17, [v17, v45], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002011 00002d11
	image_load v19, [v19, v45], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002013 00002d13
	image_load v21, [v21, v45], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002015 00002d15
	image_load v20, [v20, v44], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003014 00002c14
	s_wait_loadcnt 0x18                                         ; bfc00018
	v_sub_f32_e32 v47, v47, v27                                 ; 085e372f
	s_wait_loadcnt 0x16                                         ; bfc00016
	v_sub_f32_e32 v49, v49, v29                                 ; 08623b31
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_sub_f32_e32 v13, v13, v12                                 ; 081a190d
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_sub_f32_e32 v51, v51, v31                                 ; 08663f33
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_dual_sub_f32 v53, v53, v33 :: v_dual_sub_f32 v46, v46, v26 ; c94a4335 352e352e
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_sub_f32_e32 v23, v23, v22                                 ; 082e2d17
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_dual_sub_f32 v55, v55, v35 :: v_dual_sub_f32 v48, v48, v28 ; c94a4737 37303930
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_dual_sub_f32 v57, v57, v37 :: v_dual_sub_f32 v50, v50, v30 ; c94a4b39 39323d32
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d503032e
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_dual_sub_f32 v59, v59, v41 :: v_dual_sub_f32 v52, v52, v32 ; c94a533b 3b344134
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_sub_f32 v61, v61, v43 :: v_dual_sub_f32 v54, v54, v34 ; c94a573d 3d364536
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_sub_f32 v39, v39, v38 :: v_dual_sub_f32 v56, v56, v36 ; c94a4d27 27384938
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_sub_f32 v11, v11, v10 :: v_dual_sub_f32 v24, v24, v25 ; c94a150b 0b183318
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v48, vcc_lo                      ; 0202612e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_sub_f32 v17, v17, v5 :: v_dual_sub_f32 v58, v58, v40 ; c94a0b11 113a513a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_subrev_f32 v19, v18, v19 :: v_dual_sub_f32 v60, v60, v42 ; c98a2712 133c553c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_sub_f32 v21, v21, v20 :: v_dual_sub_f32 v16, v16, v15 ; c94a2915 15101f10
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v49, vcc_lo                      ; 0202632e
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v13, vcc_lo                      ; 02021b2e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v50, vcc_lo                      ; 0202652e
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v51, vcc_lo                      ; 0202672e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v52, vcc_lo                      ; 0202692e
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v53, vcc_lo                      ; 02026b2e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v23, vcc_lo                      ; 02022f2e
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v54, vcc_lo                      ; 02026d2e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v55, vcc_lo                      ; 02026f2e
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v56, vcc_lo                      ; 0202712e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v57, vcc_lo                      ; 0202732e
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v24, vcc_lo                      ; 0202312e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v58, vcc_lo                      ; 0202752e
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v59, vcc_lo                      ; 0202772e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v60, vcc_lo                      ; 0202792e
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v61, vcc_lo                      ; 02027b2e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v39, vcc_lo                      ; 02024f2e
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v11, vcc_lo                      ; 0202172e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v16, vcc_lo                      ; 0202212e
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v17, vcc_lo                      ; 0202232e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v19, vcc_lo                      ; 0202272e
(invalid instruction)                                        ; d503022e
	v_cndmask_b32_e32 v1, v46, v21, vcc_lo                      ; 02022b2e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v46, 0x3d23d70a, v46                          ; 105c5cff 3d23d70a
BB39:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 exec_lo, s3, exec_lo                         ; 917e7e03
	v_mov_b32_e32 v46, 0x7f61b1e6                               ; 7e5c02ff 7f61b1e6
BB41:
	s_mov_b32 exec_lo, s3                                       ; befe0003
	v_add_nc_u32_e32 v4, 1, v7                                  ; 4a080e81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v5, v1, v4                                 ; 4a0a0901
	v_add_nc_u32_e32 v10, -2, v5                                ; 4a140ac2
	v_add_nc_u32_e32 v11, 2, v5                                 ; 4a160a82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_min_i32_e32 v10, v10, v9                                  ; 2214130a
(invalid instruction)                                        ; d4430005
	v_cndmask_b32_e32 v1, s1, v11, vcc_lo                       ; 02021601
(invalid instruction)                                        ; d4440004
	v_cndmask_b32_e32 v1, 0, v10, vcc_lo                        ; 02021480
	s_or_b32 s4, s4, s5                                         ; 8c040504
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_nor_b32 s4, s4, vcc_lo                                    ; 8f046a04
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 exec_lo, s4, exec_lo                              ; 8b7e7e04
	s_cbranch_execz BB45                                        ; bfa50142
BB42:
	s_mov_b32 s4, s0                                            ; be840000
	s_movk_i32 s5, 0x8000                                       ; b0058000
	s_load_b512 s[16:31], s[4:5], 0x0                           ; f4008402 f8000000
	v_add_nc_u32_e32 v9, -2, v1                                 ; 4a1202c2
	v_add_nc_u32_e32 v11, -2, v0                                ; 4a1600c2
	s_add_co_u32 s4, s1, -1                                     ; 8004c101
	s_add_co_u32 s5, s2, -1                                     ; 8005c102
	v_add_nc_u32_e32 v13, -1, v1                                ; 4a1a02c1
	v_add_nc_u32_e32 v17, 1, v1                                 ; 4a220281
	v_add_nc_u32_e32 v19, 2, v1                                 ; 4a260282
	v_add_nc_u32_e32 v21, -1, v0                                ; 4a2a00c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_maxmin_i32 v10, 0, v9, s4                                 ; d664000a 00121280
	v_add_nc_u32_e32 v9, v9, v4                                 ; 4a120909
	v_maxmin_i32 v12, 0, v11, s5                                ; d664000c 00161680
	v_add_nc_u32_e32 v11, v11, v6                               ; 4a160d0b
	v_maxmin_i32 v16, 0, v1, s4                                 ; d6640010 00120280
	v_maxmin_i32 v5, 0, v5, s4                                  ; d6640005 00120a80
	v_maxmin_i32 v15, 0, v13, s4                                ; d664000f 00121a80
	v_add_nc_u32_e32 v13, v13, v4                               ; 4a1a090d
	v_maxmin_i32 v18, 0, v17, s4                                ; d6640012 00122280
	v_add_nc_u32_e32 v17, v17, v4                               ; 4a220911
	v_maxmin_i32 v20, 0, v19, s4                                ; d6640014 00122680
	v_add_nc_u32_e32 v19, v19, v4                               ; 4a260913
	v_maxmin_i32 v23, 0, v0, s5                                 ; d6640017 00160080
	v_maxmin_i32 v22, 0, v21, s5                                ; d6640016 00162a80
	v_add_nc_u32_e32 v21, v21, v6                               ; 4a2a0d15
	v_maxmin_i32 v8, 0, v8, s5                                  ; d6640008 00161080
	v_maxmin_i32 v9, 0, v9, s4                                  ; d6640009 00121280
	v_maxmin_i32 v11, 0, v11, s5                                ; d664000b 00161680
	v_maxmin_i32 v13, 0, v13, s4                                ; d664000d 00121a80
	v_maxmin_i32 v17, 0, v17, s4                                ; d6640011 00122280
	v_maxmin_i32 v19, 0, v19, s4                                ; d6640013 00122680
	v_maxmin_i32 v21, 0, v21, s5                                ; d6640015 00162a80
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0xe                                                ; bf85000e
	image_load v24, [v9, v11], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003018 00000b09
	image_load v25, [v13, v11], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003019 00000b0d
	image_load v26, [v5, v11], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301a 00000b05
	image_load v27, [v17, v11], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301b 00000b11
	image_load v11, [v19, v11], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000300b 00000b13
	image_load v28, [v9, v21], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301c 00001509
	image_load v29, [v13, v21], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301d 0000150d
	image_load v30, [v5, v21], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301e 00001505
	image_load v31, [v17, v21], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301f 00001511
	image_load v21, [v19, v21], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003015 00001513
	image_load v32, [v9, v8], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003020 00000809
	image_load v33, [v13, v8], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003021 0000080d
	image_load v34, [v5, v8], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003022 00000805
	image_load v35, [v17, v8], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003023 00000811
	image_load v8, [v19, v8], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003008 00000813
	v_add_nc_u32_e32 v36, 1, v0                                 ; 4a480081
	v_add_nc_u32_e32 v42, 2, v0                                 ; 4a540082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
	v_maxmin_i32 v37, 0, v36, s5                                ; d6640025 00164880
	v_add_nc_u32_e32 v36, v36, v6                               ; 4a480d24
	v_maxmin_i32 v43, 0, v42, s5                                ; d664002b 00165480
	v_add_nc_u32_e32 v42, v42, v6                               ; 4a540d2a
	v_maxmin_i32 v36, 0, v36, s5                                ; d6640024 00164880
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_maxmin_i32 v42, 0, v42, s5                                ; d664002a 00165480
	s_clause 0x8                                                ; bf850008
	image_load v38, [v9, v36], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003026 00002409
	image_load v39, [v13, v36], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003027 0000240d
	image_load v40, [v5, v36], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003028 00002405
	image_load v41, [v17, v36], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003029 00002411
	image_load v36, [v19, v36], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003024 00002413
	image_load v9, [v9, v42], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003009 00002a09
	image_load v13, [v13, v42], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000300d 00002a0d
	image_load v5, [v5, v42], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003005 00002a05
	image_load v17, [v17, v42], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003011 00002a11
	s_clause 0x18                                               ; bf850018
	image_load v44, [v10, v12], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202c 00000c0a
	image_load v45, [v15, v12], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202d 00000c0f
	image_load v47, [v16, v12], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202f 00000c10
	image_load v48, [v18, v12], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002030 00000c12
	image_load v12, [v20, v12], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200c 00000c14
	image_load v49, [v10, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002031 0000160a
	image_load v50, [v15, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002032 0000160f
	image_load v51, [v16, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002033 00001610
	image_load v52, [v18, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002034 00001612
	image_load v22, [v20, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002016 00001614
	image_load v53, [v10, v23], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002035 0000170a
	image_load v54, [v15, v23], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002036 0000170f
	image_load v55, [v16, v23], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002037 00001710
	image_load v56, [v18, v23], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002038 00001712
	image_load v23, [v20, v23], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002017 00001714
	image_load v57, [v10, v37], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002039 0000250a
	image_load v58, [v15, v37], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203a 0000250f
	image_load v59, [v16, v37], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203b 00002510
	image_load v60, [v18, v37], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203c 00002512
	image_load v37, [v20, v37], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002025 00002514
	image_load v10, [v10, v43], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200a 00002b0a
	image_load v15, [v15, v43], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200f 00002b0f
	image_load v16, [v16, v43], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002010 00002b10
	image_load v18, [v18, v43], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002012 00002b12
	image_load v20, [v20, v43], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002014 00002b14
	image_load v19, [v19, v42], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003013 00002a13
	s_wait_loadcnt 0x19                                         ; bfc00019
	v_sub_f32_e32 v44, v44, v24                                 ; 0858312c
	s_wait_loadcnt 0x16                                         ; bfc00016
	v_sub_f32_e32 v48, v48, v27                                 ; 08603730
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_dual_sub_f32 v12, v12, v11 :: v_dual_sub_f32 v45, v45, v25 ; c94a170c 0c2c332d
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_sub_f32_e32 v50, v50, v29                                 ; 08643b32
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_dual_sub_f32 v52, v52, v31 :: v_dual_sub_f32 v47, v47, v26 ; c94a3f34 342e352f
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_sub_f32 v22, v22, v21 :: v_dual_sub_f32 v49, v49, v28 ; c94a2b16 16303931
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d503032c
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_dual_sub_f32 v54, v54, v33 :: v_dual_sub_f32 v51, v51, v30 ; c94a4336 36323d33
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_dual_sub_f32 v56, v56, v35 :: v_dual_sub_f32 v53, v53, v32 ; c94a4738 38344135
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_dual_sub_f32 v58, v58, v39 :: v_dual_sub_f32 v55, v55, v34 ; c94a4f3a 3a364537
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v47, vcc_lo                      ; 02025f2c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_sub_f32 v60, v60, v41 :: v_dual_sub_f32 v23, v23, v8 ; c94a533c 3c161117
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_sub_f32 v10, v10, v9 :: v_dual_sub_f32 v57, v57, v38 ; c94a130a 0a384d39
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_sub_f32 v16, v16, v5 :: v_dual_sub_f32 v59, v59, v40 ; c94a0b10 103a513b
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v48, vcc_lo                      ; 0202612c
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_sub_f32 v18, v18, v17 :: v_dual_sub_f32 v37, v37, v36 ; c94a2312 12244925
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_sub_f32 v20, v20, v19 :: v_dual_sub_f32 v15, v15, v13 ; c94a2714 140e1b0f
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v12, vcc_lo                      ; 0202192c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v49, vcc_lo                      ; 0202632c
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v50, vcc_lo                      ; 0202652c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v51, vcc_lo                      ; 0202672c
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v52, vcc_lo                      ; 0202692c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v22, vcc_lo                      ; 02022d2c
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v53, vcc_lo                      ; 02026b2c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                      ; 02026d2c
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                      ; 02026f2c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v56, vcc_lo                      ; 0202712c
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v23, vcc_lo                      ; 02022f2c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v57, vcc_lo                      ; 0202732c
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v58, vcc_lo                      ; 0202752c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v59, vcc_lo                      ; 0202772c
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v60, vcc_lo                      ; 0202792c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                      ; 02024b2c
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v10, vcc_lo                      ; 0202152c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v15, vcc_lo                      ; 02021f2c
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v16, vcc_lo                      ; 0202212c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v18, vcc_lo                      ; 0202252c
(invalid instruction)                                        ; d503022c
	v_cndmask_b32_e32 v1, v44, v20, vcc_lo                      ; 0202292c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v44, 0x3d23d70a, v44                          ; 105858ff 3d23d70a
BB45:
	s_and_not1_b32 exec_lo, s3, exec_lo                         ; 917e7e03
	v_mov_b32_e32 v44, 0x7f61b1e6                               ; 7e5802ff 7f61b1e6
BB47:
	s_mov_b32 exec_lo, s3                                       ; befe0003
	v_add_nc_u32_e32 v4, v1, v7                                 ; 4a080f01
	v_add_nc_u32_e32 v5, -1, v6                                 ; 4a0a0cc1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_add_nc_u32_e32 v10, -2, v4                                ; 4a1408c2
	v_add_nc_u32_e32 v11, 2, v4                                 ; 4a160882
	v_add_nc_u32_e32 v8, v0, v5                                 ; 4a100b00
(invalid instruction)                                        ; d4430004
	v_cndmask_b32_e32 v1, s1, v11, vcc_lo                       ; 02021601
	v_add_nc_u32_e32 v9, -2, v8                                 ; 4a1210c2
	v_add_nc_u32_e32 v12, 2, v8                                 ; 4a181082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_min_i32_e32 v9, v10, v9                                   ; 2212130a
	v_cmp_gt_i32_e32 vcc_lo, 0, v9                              ; 7c881280
	s_or_b32 s5, vcc_lo, s4                                     ; 8c05046a
	v_cmp_le_i32_e32 vcc_lo, s2, v12                            ; 7c861802
	s_nor_b32 s5, s5, vcc_lo                                    ; 8f056a05
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 exec_lo, s5, exec_lo                              ; 8b7e7e05
	s_cbranch_execz BB51                                        ; bfa50141
BB48:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b512 s[16:31], s[6:7], 0x0                           ; f4008403 f8000000
	v_add_nc_u32_e32 v9, -2, v1                                 ; 4a1202c2
	v_add_nc_u32_e32 v12, -2, v0                                ; 4a1800c2
	s_add_co_u32 s5, s1, -1                                     ; 8005c101
	s_add_co_u32 s6, s2, -1                                     ; 8006c102
	v_add_nc_u32_e32 v15, -1, v1                                ; 4a1e02c1
	v_add_nc_u32_e32 v19, 1, v1                                 ; 4a260281
	v_add_nc_u32_e32 v21, 2, v1                                 ; 4a2a0282
	v_add_nc_u32_e32 v23, -1, v0                                ; 4a2e00c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_maxmin_i32 v11, 0, v9, s5                                 ; d664000b 00161280
	v_add_nc_u32_e32 v9, v9, v7                                 ; 4a120f09
	v_maxmin_i32 v13, 0, v12, s6                                ; d664000d 001a1880
	v_add_nc_u32_e32 v12, v12, v5                               ; 4a180b0c
	v_maxmin_i32 v17, 0, v1, s5                                 ; d6640011 00160280
	v_maxmin_i32 v18, 0, v4, s5                                 ; d6640012 00160880
	v_maxmin_i32 v16, 0, v15, s5                                ; d6640010 00161e80
	v_add_nc_u32_e32 v15, v15, v7                               ; 4a1e0f0f
	v_maxmin_i32 v20, 0, v19, s5                                ; d6640014 00162680
	v_add_nc_u32_e32 v19, v19, v7                               ; 4a260f13
	v_maxmin_i32 v22, 0, v21, s5                                ; d6640016 00162a80
	v_add_nc_u32_e32 v21, v21, v7                               ; 4a2a0f15
	v_maxmin_i32 v25, 0, v0, s6                                 ; d6640019 001a0080
	v_maxmin_i32 v24, 0, v23, s6                                ; d6640018 001a2e80
	v_add_nc_u32_e32 v23, v23, v5                               ; 4a2e0b17
	v_maxmin_i32 v8, 0, v8, s6                                  ; d6640008 001a1080
	v_maxmin_i32 v9, 0, v9, s5                                  ; d6640009 00161280
	v_maxmin_i32 v12, 0, v12, s6                                ; d664000c 001a1880
	v_maxmin_i32 v15, 0, v15, s5                                ; d664000f 00161e80
	v_maxmin_i32 v19, 0, v19, s5                                ; d6640013 00162680
	v_maxmin_i32 v21, 0, v21, s5                                ; d6640015 00162a80
	v_maxmin_i32 v23, 0, v23, s6                                ; d6640017 001a2e80
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0xe                                                ; bf85000e
	image_load v26, [v9, v12], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301a 00000c09
	image_load v27, [v15, v12], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301b 00000c0f
	image_load v28, [v18, v12], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301c 00000c12
	image_load v29, [v19, v12], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301d 00000c13
	image_load v12, [v21, v12], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000300c 00000c15
	image_load v30, [v9, v23], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301e 00001709
	image_load v31, [v15, v23], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301f 0000170f
	image_load v32, [v18, v23], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003020 00001712
	image_load v33, [v19, v23], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003021 00001713
	image_load v23, [v21, v23], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003017 00001715
	image_load v34, [v9, v8], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003022 00000809
	image_load v35, [v15, v8], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003023 0000080f
	image_load v36, [v18, v8], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003024 00000812
	image_load v37, [v19, v8], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003025 00000813
	image_load v8, [v21, v8], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003008 00000815
	v_add_nc_u32_e32 v38, 1, v0                                 ; 4a4c0081
	v_add_nc_u32_e32 v45, 2, v0                                 ; 4a5a0082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
	v_maxmin_i32 v39, 0, v38, s6                                ; d6640027 001a4c80
	v_add_nc_u32_e32 v38, v38, v5                               ; 4a4c0b26
	v_maxmin_i32 v47, 0, v45, s6                                ; d664002f 001a5a80
	v_add_nc_u32_e32 v45, v45, v5                               ; 4a5a0b2d
	v_maxmin_i32 v38, 0, v38, s6                                ; d6640026 001a4c80
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_maxmin_i32 v45, 0, v45, s6                                ; d664002d 001a5a80
	s_clause 0x8                                                ; bf850008
	image_load v40, [v9, v38], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003028 00002609
	image_load v41, [v15, v38], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003029 0000260f
	image_load v42, [v18, v38], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000302a 00002612
	image_load v43, [v19, v38], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000302b 00002613
	image_load v38, [v21, v38], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003026 00002615
	image_load v9, [v9, v45], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003009 00002d09
	image_load v15, [v15, v45], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000300f 00002d0f
	image_load v18, [v18, v45], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003012 00002d12
	image_load v19, [v19, v45], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003013 00002d13
	s_clause 0x18                                               ; bf850018
	image_load v48, [v11, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002030 00000d0b
	image_load v49, [v16, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002031 00000d10
	image_load v50, [v17, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002032 00000d11
	image_load v51, [v20, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002033 00000d14
	image_load v13, [v22, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200d 00000d16
	image_load v52, [v11, v24], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002034 0000180b
	image_load v53, [v16, v24], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002035 00001810
	image_load v54, [v17, v24], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002036 00001811
	image_load v55, [v20, v24], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002037 00001814
	image_load v24, [v22, v24], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002018 00001816
	image_load v56, [v11, v25], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002038 0000190b
	image_load v57, [v16, v25], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002039 00001910
	image_load v58, [v17, v25], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203a 00001911
	image_load v59, [v20, v25], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203b 00001914
	image_load v25, [v22, v25], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002019 00001916
	image_load v60, [v11, v39], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203c 0000270b
	image_load v61, [v16, v39], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203d 00002710
	image_load v62, [v17, v39], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203e 00002711
	image_load v63, [v20, v39], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203f 00002714
	image_load v39, [v22, v39], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002027 00002716
	image_load v11, [v11, v47], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200b 00002f0b
	image_load v16, [v16, v47], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002010 00002f10
	image_load v17, [v17, v47], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002011 00002f11
	image_load v20, [v20, v47], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002014 00002f14
	image_load v22, [v22, v47], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002016 00002f16
	image_load v21, [v21, v45], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003015 00002d15
	s_wait_loadcnt 0x18                                         ; bfc00018
	v_sub_f32_e32 v49, v49, v27                                 ; 08623731
	s_wait_loadcnt 0x16                                         ; bfc00016
	v_dual_sub_f32 v51, v51, v29 :: v_dual_sub_f32 v48, v48, v26 ; c94a3b33 33303530
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_dual_subrev_f32 v13, v12, v13 :: v_dual_sub_f32 v50, v50, v28 ; c98a1b0c 0d323932
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_dual_sub_f32 v53, v53, v31 :: v_dual_sub_f32 v52, v52, v30 ; c94a3f35 35343d34
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_dual_sub_f32 v55, v55, v33 :: v_dual_sub_f32 v54, v54, v32 ; c94a4337 37364136
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d5030330
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_dual_subrev_f32 v57, v35, v57 :: v_dual_sub_f32 v24, v24, v23 ; c98a7323 39182f18
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_dual_sub_f32 v59, v59, v37 :: v_dual_sub_f32 v56, v56, v34 ; c94a4b3b 3b384538
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_dual_subrev_f32 v25, v8, v25 :: v_dual_sub_f32 v58, v58, v36 ; c98a3308 193a493a
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v50, vcc_lo                      ; 02026530
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_dual_sub_f32 v61, v61, v41 :: v_dual_sub_f32 v60, v60, v40 ; c94a533d 3d3c513c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_sub_f32 v63, v63, v43 :: v_dual_sub_f32 v62, v62, v42 ; c94a573f 3f3e553e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_sub_f32 v16, v16, v15 :: v_dual_sub_f32 v39, v39, v38 ; c94a1f10 10264d27
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v51, vcc_lo                      ; 02026730
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_sub_f32 v20, v20, v19 :: v_dual_sub_f32 v11, v11, v9 ; c94a2714 140a130b
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_sub_f32 v22, v22, v21 :: v_dual_sub_f32 v17, v17, v18 ; c94a2b16 16102511
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v13, vcc_lo                      ; 02021b30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v52, vcc_lo                      ; 02026930
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v53, vcc_lo                      ; 02026b30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v54, vcc_lo                      ; 02026d30
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v55, vcc_lo                      ; 02026f30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v24, vcc_lo                      ; 02023130
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v56, vcc_lo                      ; 02027130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v57, vcc_lo                      ; 02027330
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v58, vcc_lo                      ; 02027530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v59, vcc_lo                      ; 02027730
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v25, vcc_lo                      ; 02023330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v60, vcc_lo                      ; 02027930
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v61, vcc_lo                      ; 02027b30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v62, vcc_lo                      ; 02027d30
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v63, vcc_lo                      ; 02027f30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v39, vcc_lo                      ; 02024f30
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v11, vcc_lo                      ; 02021730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v16, vcc_lo                      ; 02022130
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v17, vcc_lo                      ; 02022330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v20, vcc_lo                      ; 02022930
(invalid instruction)                                        ; d5030230
	v_cndmask_b32_e32 v1, v48, v22, vcc_lo                      ; 02022d30
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v48, 0x3d23d70a, v48                          ; 106060ff 3d23d70a
BB51:
	s_and_not1_b32 exec_lo, s3, exec_lo                         ; 917e7e03
	v_mov_b32_e32 v48, 0x7f61b1e6                               ; 7e6002ff 7f61b1e6
BB53:
	s_mov_b32 exec_lo, s3                                       ; befe0003
	v_add_nc_u32_e32 v6, 1, v6                                  ; 4a0c0c81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v5, v0, v6                                 ; 4a0a0d00
	v_add_nc_u32_e32 v8, -2, v5                                 ; 4a100ac2
	v_add_nc_u32_e32 v9, 2, v5                                  ; 4a120a82
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_min_i32_e32 v8, v8, v10                                   ; 22101508
	v_cmp_gt_i32_e32 vcc_lo, 0, v8                              ; 7c881080
	s_or_b32 s4, vcc_lo, s4                                     ; 8c04046a
	v_cmp_le_i32_e32 vcc_lo, s2, v9                             ; 7c861202
	s_nor_b32 s4, s4, vcc_lo                                    ; 8f046a04
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 exec_lo, s4, exec_lo                              ; 8b7e7e04
	s_cbranch_execz BB57                                        ; bfa50144
BB54:
	s_mov_b32 s4, s0                                            ; be840000
	s_movk_i32 s5, 0x8000                                       ; b0058000
	s_load_b512 s[16:31], s[4:5], 0x0                           ; f4008402 f8000000
	v_add_nc_u32_e32 v8, -2, v1                                 ; 4a1002c2
	v_add_nc_u32_e32 v10, -2, v0                                ; 4a1400c2
	s_add_co_u32 s4, s1, -1                                     ; 8004c101
	s_add_co_u32 s5, s2, -1                                     ; 8005c102
	v_add_nc_u32_e32 v12, -1, v1                                ; 4a1802c1
	v_add_nc_u32_e32 v16, 1, v1                                 ; 4a200281
	v_add_nc_u32_e32 v18, 2, v1                                 ; 4a240282
	v_add_nc_u32_e32 v20, -1, v0                                ; 4a2800c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_maxmin_i32 v9, 0, v8, s4                                  ; d6640009 00121080
	v_add_nc_u32_e32 v8, v8, v7                                 ; 4a100f08
	v_maxmin_i32 v11, 0, v10, s5                                ; d664000b 00161480
	v_add_nc_u32_e32 v10, v10, v6                               ; 4a140d0a
	v_maxmin_i32 v15, 0, v1, s4                                 ; d664000f 00120280
	v_maxmin_i32 v4, 0, v4, s4                                  ; d6640004 00120880
	v_maxmin_i32 v13, 0, v12, s4                                ; d664000d 00121880
	v_add_nc_u32_e32 v12, v12, v7                               ; 4a180f0c
	v_maxmin_i32 v17, 0, v16, s4                                ; d6640011 00122080
	v_add_nc_u32_e32 v16, v16, v7                               ; 4a200f10
	v_maxmin_i32 v19, 0, v18, s4                                ; d6640013 00122480
	v_add_nc_u32_e32 v18, v18, v7                               ; 4a240f12
	v_maxmin_i32 v22, 0, v0, s5                                 ; d6640016 00160080
	v_maxmin_i32 v21, 0, v20, s5                                ; d6640015 00162880
	v_add_nc_u32_e32 v20, v20, v6                               ; 4a280d14
	v_maxmin_i32 v5, 0, v5, s5                                  ; d6640005 00160a80
	v_maxmin_i32 v8, 0, v8, s4                                  ; d6640008 00121080
	v_maxmin_i32 v10, 0, v10, s5                                ; d664000a 00161480
	v_maxmin_i32 v12, 0, v12, s4                                ; d664000c 00121880
	v_maxmin_i32 v16, 0, v16, s4                                ; d6640010 00122080
	v_maxmin_i32 v18, 0, v18, s4                                ; d6640012 00122480
	v_maxmin_i32 v20, 0, v20, s5                                ; d6640014 00162880
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0xe                                                ; bf85000e
	image_load v23, [v8, v10], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003017 00000a08
	image_load v24, [v12, v10], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003018 00000a0c
	image_load v25, [v4, v10], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003019 00000a04
	image_load v26, [v16, v10], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301a 00000a10
	image_load v10, [v18, v10], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000300a 00000a12
	image_load v27, [v8, v20], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301b 00001408
	image_load v28, [v12, v20], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301c 0000140c
	image_load v29, [v4, v20], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301d 00001404
	image_load v30, [v16, v20], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301e 00001410
	image_load v20, [v18, v20], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003014 00001412
	image_load v31, [v8, v5], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000301f 00000508
	image_load v32, [v12, v5], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003020 0000050c
	image_load v33, [v4, v5], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003021 00000504
	image_load v34, [v16, v5], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003022 00000510
	image_load v5, [v18, v5], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003005 00000512
	v_add_nc_u32_e32 v35, 1, v0                                 ; 4a460081
	v_add_nc_u32_e32 v41, 2, v0                                 ; 4a520082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
	v_maxmin_i32 v36, 0, v35, s5                                ; d6640024 00164680
	v_add_nc_u32_e32 v35, v35, v6                               ; 4a460d23
	v_maxmin_i32 v42, 0, v41, s5                                ; d664002a 00165280
	v_add_nc_u32_e32 v41, v41, v6                               ; 4a520d29
	v_maxmin_i32 v35, 0, v35, s5                                ; d6640023 00164680
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_maxmin_i32 v41, 0, v41, s5                                ; d6640029 00165280
	s_clause 0x8                                                ; bf850008
	image_load v37, [v8, v35], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003025 00002308
	image_load v38, [v12, v35], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003026 0000230c
	image_load v39, [v4, v35], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003027 00002304
	image_load v40, [v16, v35], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003028 00002310
	image_load v35, [v18, v35], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003023 00002312
	image_load v8, [v8, v41], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003008 00002908
	image_load v12, [v12, v41], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000300c 0000290c
	image_load v4, [v4, v41], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003004 00002904
	image_load v16, [v16, v41], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003010 00002910
	s_clause 0x18                                               ; bf850018
	image_load v43, [v9, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202b 00000b09
	image_load v45, [v13, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202d 00000b0d
	image_load v47, [v15, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000202f 00000b0f
	image_load v49, [v17, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002031 00000b11
	image_load v11, [v19, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200b 00000b13
	image_load v50, [v9, v21], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002032 00001509
	image_load v51, [v13, v21], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002033 0000150d
	image_load v52, [v15, v21], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002034 0000150f
	image_load v53, [v17, v21], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002035 00001511
	image_load v21, [v19, v21], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002015 00001513
	image_load v54, [v9, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002036 00001609
	image_load v55, [v13, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002037 0000160d
	image_load v56, [v15, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002038 0000160f
	image_load v57, [v17, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002039 00001611
	image_load v22, [v19, v22], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002016 00001613
	image_load v58, [v9, v36], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203a 00002409
	image_load v59, [v13, v36], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203b 0000240d
	image_load v60, [v15, v36], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203c 0000240f
	image_load v61, [v17, v36], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000203d 00002411
	image_load v36, [v19, v36], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002024 00002413
	image_load v9, [v9, v42], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002009 00002a09
	image_load v13, [v13, v42], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200d 00002a0d
	image_load v15, [v15, v42], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200f 00002a0f
	image_load v17, [v17, v42], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002011 00002a11
	image_load v19, [v19, v42], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002013 00002a13
	image_load v18, [v18, v41], s[24:31] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00003012 00002912
	s_wait_loadcnt 0x19                                         ; bfc00019
	v_sub_f32_e32 v43, v43, v23                                 ; 08562f2b
	s_wait_loadcnt 0x18                                         ; bfc00018
	v_sub_f32_e32 v45, v45, v24                                 ; 085a312d
	s_wait_loadcnt 0x17                                         ; bfc00017
	v_sub_f32_e32 v47, v47, v25                                 ; 085e332f
	s_wait_loadcnt 0x16                                         ; bfc00016
	v_sub_f32_e32 v49, v49, v26                                 ; 08623531
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_sub_f32_e32 v11, v11, v10                                 ; 0816150b
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_sub_f32_e32 v51, v51, v28                                 ; 08663933
(invalid instruction)                                        ; d503032b
	v_cndmask_b32_e32 v1, v43, v45, vcc_lo                      ; 02025b2b
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_sub_f32_e32 v53, v53, v30                                 ; 086a3d35
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_sub_f32_e32 v21, v21, v20                                 ; 082a2915
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_sub_f32_e32 v55, v55, v32                                 ; 086e4137
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v47, vcc_lo                      ; 02025f2b
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_dual_sub_f32 v57, v57, v34 :: v_dual_sub_f32 v50, v50, v27 ; c94a4539 39323732
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_dual_sub_f32 v59, v59, v38 :: v_dual_sub_f32 v52, v52, v29 ; c94a4d3b 3b343b34
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_sub_f32 v61, v61, v40 :: v_dual_sub_f32 v54, v54, v31 ; c94a513d 3d363f36
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v49, vcc_lo                      ; 0202632b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_sub_f32 v9, v9, v8 :: v_dual_sub_f32 v56, v56, v33   ; c94a1109 09384338
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_sub_f32 v13, v13, v12 :: v_dual_sub_f32 v22, v22, v5 ; c94a190d 0d160b16
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_sub_f32 v15, v15, v4 :: v_dual_sub_f32 v58, v58, v37 ; c94a090f 0f3a4b3a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_sub_f32 v17, v17, v16 :: v_dual_sub_f32 v60, v60, v39 ; c94a2111 113c4f3c
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v11, vcc_lo                      ; 0202172b
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_sub_f32 v19, v19, v18 :: v_dual_sub_f32 v36, v36, v35 ; c94a2513 13244724
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v50, vcc_lo                      ; 0202652b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v51, vcc_lo                      ; 0202672b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v52, vcc_lo                      ; 0202692b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v53, vcc_lo                      ; 02026b2b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v21, vcc_lo                      ; 02022b2b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v54, vcc_lo                      ; 02026d2b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v55, vcc_lo                      ; 02026f2b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v56, vcc_lo                      ; 0202712b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v57, vcc_lo                      ; 0202732b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v22, vcc_lo                      ; 02022d2b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v58, vcc_lo                      ; 0202752b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v59, vcc_lo                      ; 0202772b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                      ; 0202792b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v61, vcc_lo                      ; 02027b2b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v36, vcc_lo                      ; 0202492b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v9, vcc_lo                       ; 0202132b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v13, vcc_lo                      ; 02021b2b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v15, vcc_lo                      ; 02021f2b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v17, vcc_lo                      ; 0202232b
(invalid instruction)                                        ; d503022b
	v_cndmask_b32_e32 v1, v43, v19, vcc_lo                      ; 0202272b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v43, 0x3d23d70a, v43                          ; 105656ff 3d23d70a
BB57:
	s_and_not1_b32 exec_lo, s3, exec_lo                         ; 917e7e03
	v_mov_b32_e32 v43, 0x7f61b1e6                               ; 7e5602ff 7f61b1e6
BB59:
	s_mov_b32 s4, s0                                            ; be840000
	s_movk_i32 s5, 0x8000                                       ; b0058000
	s_load_b256 s[16:23], s[4:5], 0x0                           ; f4006402 f8000000
	s_mov_b32 exec_lo, s3                                       ; befe0003
	s_add_co_u32 s3, s1, -1                                     ; 8003c101
	s_add_co_u32 s4, s2, -1                                     ; 8004c102
	v_add_nc_u32_e32 v4, -2, v1                                 ; 4a0802c2
	v_add_nc_u32_e32 v5, -2, v0                                 ; 4a0a00c2
	v_add_nc_u32_e32 v6, -1, v1                                 ; 4a0c02c1
	v_add_nc_u32_e32 v9, 2, v1                                  ; 4a120282
	v_add_nc_u32_e32 v8, 1, v1                                  ; 4a100281
	v_add_nc_u32_e32 v13, 2, v0                                 ; 4a1a0082
	v_add_nc_u32_e32 v10, -1, v0                                ; 4a1400c1
	v_add_nc_u32_e32 v12, 1, v0                                 ; 4a180081
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_maxmin_i32 v7, 0, v1, s3                                  ; d6640007 000e0280
	v_maxmin_i32 v11, 0, v0, s4                                 ; d664000b 00120080
	v_maxmin_i32 v4, 0, v4, s3                                  ; d6640004 000e0880
	v_maxmin_i32 v5, 0, v5, s4                                  ; d6640005 00120a80
	v_maxmin_i32 v6, 0, v6, s3                                  ; d6640006 000e0c80
	v_maxmin_i32 v9, 0, v9, s3                                  ; d6640009 000e1280
	v_maxmin_i32 v8, 0, v8, s3                                  ; d6640008 000e1080
	v_maxmin_i32 v13, 0, v13, s4                                ; d664000d 00121a80
	v_maxmin_i32 v10, 0, v10, s4                                ; d664000a 00121480
	v_maxmin_i32 v12, 0, v12, s4                                ; d664000c 00121880
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x18                                               ; bf850018
	image_load v15, [v4, v5], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200f 00000504
	image_load v16, [v6, v5], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002010 00000506
	image_load v17, [v7, v5], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002011 00000507
	image_load v18, [v8, v5], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002012 00000508
	image_load v5, [v9, v5], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002005 00000509
	image_load v19, [v4, v10], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002013 00000a04
	image_load v20, [v6, v10], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002014 00000a06
	image_load v21, [v7, v10], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002015 00000a07
	image_load v22, [v8, v10], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002016 00000a08
	image_load v10, [v9, v10], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200a 00000a09
	image_load v23, [v4, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002017 00000b04
	image_load v24, [v6, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002018 00000b06
	image_load v25, [v7, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002019 00000b07
	image_load v26, [v8, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000201a 00000b08
	image_load v11, [v9, v11], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200b 00000b09
	image_load v27, [v4, v12], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000201b 00000c04
	image_load v28, [v6, v12], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000201c 00000c06
	image_load v29, [v7, v12], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000201d 00000c07
	image_load v30, [v8, v12], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000201e 00000c08
	image_load v12, [v9, v12], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 0000200c 00000c09
	image_load v4, [v4, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002004 00000d04
	image_load v6, [v6, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002006 00000d06
	image_load v7, [v7, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002007 00000d07
	image_load v8, [v8, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002008 00000d08
	image_load v9, [v9, v13], s[16:23] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00002009 00000d09
	v_dual_add_f32 v32, v48, v43 :: v_dual_add_f32 v31, v46, v44 ; c9085730 201e592e
	v_cmp_neq_f32_e32 vcc_lo, 0, v14                            ; 7c3a1c80
	s_mov_b32 s5, 0x7f61b1e6                                    ; be8500ff 7f61b1e6
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d4140007
	v_cndmask_b32_e32 v1, s5, v44, vcc_lo                       ; 02025805
(invalid instruction)                                        ; d4140006
	v_cndmask_b32_e32 v1, s5, v46, vcc_lo                       ; 02025c05
(invalid instruction)                                        ; d414000a
	v_cndmask_b32_e32 v1, s5, v48, vcc_lo                       ; 02026005
(invalid instruction)                                        ; d5040030
	v_min_num_f64_e32 v[1:2], v[48:49], v[43:44]                ; 1a025730
	v_dual_fmac_f32 v32, -2.0, v14 :: v_dual_fmac_f32 v31, -2.0, v14 ; c8001cf5 201e1cf5
(invalid instruction)                                        ; d504002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[44:45]                ; 1a02592e
	s_and_b32 s6, vcc_lo, s6                                    ; 8b06066a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s6, s6, s7                                        ; 8b060706
(invalid instruction)                                        ; d4110009
	v_cndmask_b32_e32 v1, 0x358637bd, v31, vcc_lo               ; 02023eff 358637bd
	v_rcp_f32_e32 v31, v31                                      ; 7e3e551f
	s_and_b32 s6, s6, s9                                        ; 8b060906
	s_and_b32 s10, vcc_lo, s10                                  ; 8b0a0a6a
	v_cmp_gt_f32_e32 vcc_lo, s5, v43                            ; 7c285605
	s_and_b32 s10, s10, vcc_lo                                  ; 8b0a6a0a
	v_cmp_lt_f32_e32 vcc_lo, 0x358637bd, v32                    ; 7c2240ff 358637bd
	v_rcp_f32_e32 v32, v32                                      ; 7e405520
	s_and_b32 vcc_lo, s10, vcc_lo                               ; 8b6a6a0a
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v48, v48, v32                                 ; 10604130
	v_maxmin_num_f32 v48, -1.0, v48, 1.0                        ; d6690030 03ca60f3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v48, v3, v48                                  ; 06606103
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v3, v3, v48, vcc_lo                       ; 02066103
	s_wait_loadcnt 0x17                                         ; bfc00017
	v_dual_mul_f32 v46, v46, v31 :: v_dual_add_f32 v33, v15, v16 ; c8c83f2e 2e20210f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_maxmin_num_f32 v46, -1.0, v46, 1.0                        ; d669002e 03ca5cf3
	s_mov_b32 s11, 0x3d23d70a                                   ; be8b00ff 3d23d70a
	v_cmp_le_f32_e32 vcc_lo, s5, v14                            ; 7c261c05
	s_cvt_f32_u32 s1, s1                                        ; be816501
	s_wait_loadcnt 0x16                                         ; bfc00016
	v_dual_add_f32 v33, v33, v17 :: v_dual_add_f32 v46, v2, v46 ; c9082321 212e5d02
	s_cvt_f32_u32 s2, s2                                        ; be826502
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840001
	v_cndmask_b32_e32 v0, s1, v128, vcc_lo                      ; 02010001
	v_cndmask_b32_e64 v2, v2, v46, s6                           ; d5010002 001a5d02
(invalid instruction)                                        ; d6840002
	v_cndmask_b32_e32 v0, s2, v128, vcc_lo                      ; 02010002
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_add_f32_e32 v33, v33, v18                                 ; 06422521
	s_wait_loadcnt 0x14                                         ; bfc00014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v33, v33, v5                                  ; 06420b21
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_add_f32_e32 v33, v33, v19                                 ; 06422721
	s_wait_loadcnt 0x12                                         ; bfc00012
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v33, v33, v20                                 ; 06422921
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_add_f32_e32 v33, v33, v21                                 ; 06422b21
	s_wait_loadcnt 0x10                                         ; bfc00010
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v33, v33, v22                                 ; 06422d21
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_add_f32_e32 v33, v33, v10                                 ; 06421521
	s_wait_loadcnt 0xe                                          ; bfc0000e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v33, v33, v23                                 ; 06422f21
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_add_f32_e32 v33, v33, v24                                 ; 06423121
	s_wait_loadcnt 0xc                                          ; bfc0000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v33, v33, v25                                 ; 06423321
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_add_f32_e32 v33, v33, v26                                 ; 06423521
	s_wait_loadcnt 0xa                                          ; bfc0000a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v33, v33, v11                                 ; 06421721
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_add_f32_e32 v33, v33, v27                                 ; 06423721
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v33, v33, v28                                 ; 06423921
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_add_f32_e32 v33, v33, v29                                 ; 06423b21
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v33, v33, v30                                 ; 06423d21
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_add_f32_e32 v33, v33, v12                                 ; 06421921
	s_wait_loadcnt 0x4                                          ; bfc00004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v33, v33, v4                                  ; 06420921
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_add_f32_e32 v33, v33, v6                                  ; 06420d21
	s_wait_loadcnt 0x2                                          ; bfc00002
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v33, v33, v7                                  ; 06420f21
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_add_f32_e32 v33, v33, v8                                  ; 06421121
	s_wait_loadcnt 0x0                                          ; bfc00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v33, v33, v9                                  ; 06421321
	v_fma_f32 v17, -s11, v33, v17                               ; d6130011 2446420b
	v_fma_f32 v16, -s11, v33, v16                               ; d6130010 2442420b
	v_fma_f32 v19, -s11, v33, v19                               ; d6130013 244e420b
	v_fma_f32 v20, -s11, v33, v20                               ; d6130014 2452420b
	v_fma_f32 v18, -s11, v33, v18                               ; d6130012 244a420b
	v_fma_f32 v21, -s11, v33, v21                               ; d6130015 2456420b
	v_fma_f32 v5, -s11, v33, v5                                 ; d6130005 2416420b
	v_fma_f32 v22, -s11, v33, v22                               ; d6130016 245a420b
	v_fma_f32 v15, -s11, v33, v15                               ; d613000f 243e420b
	v_fma_f32 v10, -s11, v33, v10                               ; d613000a 242a420b
	v_fma_f32 v23, -s11, v33, v23                               ; d6130017 245e420b
	v_fma_f32 v24, -s11, v33, v24                               ; d6130018 2462420b
	v_fma_f32 v25, -s11, v33, v25                               ; d6130019 2466420b
	v_fma_f32 v26, -s11, v33, v26                               ; d613001a 246a420b
	v_fma_f32 v11, -s11, v33, v11                               ; d613000b 242e420b
(invalid instruction)                                        ; d503030f
	v_cndmask_b32_e32 v1, v15, v16, vcc_lo                      ; 0202210f
	v_fma_f32 v27, -s11, v33, v27                               ; d613001b 246e420b
	v_fma_f32 v28, -s11, v33, v28                               ; d613001c 2472420b
	v_fma_f32 v29, -s11, v33, v29                               ; d613001d 2476420b
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v17, vcc_lo                      ; 0202230f
	v_fma_f32 v30, -s11, v33, v30                               ; d613001e 247a420b
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v18, vcc_lo                      ; 0202250f
	v_fma_f32 v12, -s11, v33, v12                               ; d613000c 2432420b
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v5, vcc_lo                       ; 02020b0f
	v_fma_f32 v4, -s11, v33, v4                                 ; d6130004 2412420b
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                      ; 0202270f
	v_fma_f32 v6, -s11, v33, v6                                 ; d6130006 241a420b
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v20, vcc_lo                      ; 0202290f
	v_fma_f32 v7, -s11, v33, v7                                 ; d6130007 241e420b
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v21, vcc_lo                      ; 02022b0f
	v_fma_f32 v8, -s11, v33, v8                                 ; d6130008 2422420b
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v22, vcc_lo                      ; 02022d0f
	v_fma_f32 v33, -s11, v33, v9                                ; d6130021 2426420b
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v10, vcc_lo                      ; 0202150f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v23, vcc_lo                      ; 02022f0f
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v24, vcc_lo                      ; 0202310f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v25, vcc_lo                      ; 0202330f
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v26, vcc_lo                      ; 0202350f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v11, vcc_lo                      ; 0202170f
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v27, vcc_lo                      ; 0202370f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v28, vcc_lo                      ; 0202390f
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v29, vcc_lo                      ; 02023b0f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v30, vcc_lo                      ; 02023d0f
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v12, vcc_lo                      ; 0202190f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v4, vcc_lo                       ; 0202090f
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v6, vcc_lo                       ; 02020d0f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v7, vcc_lo                       ; 02020f0f
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v8, vcc_lo                       ; 0202110f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d503020f
	v_cndmask_b32_e32 v1, v15, v33, vcc_lo                      ; 0202430f
	v_mul_f32_e32 v15, s11, v15                                 ; 101e1e0b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v34, s8, v15                                  ; 10441e08
(invalid instruction)                                        ; d414000c
	v_cndmask_b32_e32 v1, 0x3c23d70a, v15, vcc_lo               ; 02021eff 3c23d70a
	s_or_b32 s12, vcc_lo, s12                                   ; 8c0c0c6a
	v_cmp_lt_f32_e32 vcc_lo, v34, v14                           ; 7c221d22
	s_nor_b32 vcc_lo, s12, vcc_lo                               ; 8f6a6a0c
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_cndmask_b32 v2, 0, v2 ; ca520680 03020480
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v3, s2, v3 :: v_dual_mul_f32 v2, s1, v2      ; c8c60602 03020401
BB61:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b256 s[0:7], s[0:1], 0x60                            ; f4006000 f8000060
	s_wait_kmcnt 0x0                                            ; bfc70000
	image_store v2, v1, s[0:7] dmask:0x3 dim:SQ_RSRC_IMG_2D     ; d0c18001 00000002 00000001
BB66:
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
