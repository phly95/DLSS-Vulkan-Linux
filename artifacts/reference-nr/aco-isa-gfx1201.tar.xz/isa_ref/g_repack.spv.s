BB0:
	v_lshl_add_u32 v0, ttmp9, 6, v0                             ; d6460000 04010c75
	s_mul_i32 s4, s3, s4                                        ; 96040403
	s_lshr_b32 s5, s5, 4                                        ; 85058405
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mul_i32 s4, s4, s5                                        ; 96040504
	v_cmpx_gt_u32_e32 s4, v0                                    ; 7d980004
	s_cbranch_execz BB6                                         ; bfa50077
BB1:
	s_mov_b32 s4, s1                                            ; be840001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[8:11], s[0:1], 0x0                            ; f4004200 f8000000
	s_cvt_f32_u32 s7, s5                                        ; be876505
(invalid instruction)                                        ; d6840007
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                      ; 02010007
	s_cvt_f32_u32 s15, s3                                       ; be8f6503
(invalid instruction)                                        ; d684000f
	v_cndmask_b32_e32 v0, s15, v128, vcc_lo                     ; 0201000f
	s_mul_f32 s7, s7, 0x4f7ffffe                                ; a207ff07 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s7, s7                                        ; be876707
	s_mul_f32 s15, s15, 0x4f7ffffe                              ; a20fff0f 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s12, s5, s7                                       ; 960c0705
	s_cvt_u32_f32 s15, s15                                      ; be8f670f
	s_sub_co_i32 s12, 0, s12                                    ; 818c0c80
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s16, s3, s15                                      ; 96100f03
	s_mul_hi_u32 s12, s7, s12                                   ; 968c0c07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s7, s7, s12                                    ; 80070c07
	s_sub_co_i32 s16, 0, s16                                    ; 81901080
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d0001
	v_cndmask_b32_e32 v0, v0, v7, vcc_lo                        ; 02000f00
	s_mul_hi_u32 s16, s15, s16                                  ; 9690100f
	s_add_co_u32 s15, s15, s16                                  ; 800f100f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v1, v5, vcc_lo                        ; 02000b01
	v_sub_nc_u32_e32 v0, v0, v2                                 ; 4c000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d7026a03
	v_cndmask_b32_e32 v1, s5, v0, vcc_lo                        ; 02020005
	v_subrev_co_ci_u32_e64 v1, s13, -1, v1, vcc_lo              ; d5220d01 01aa02c1
	v_cndmask_b32_e32 v3, v3, v0, vcc_lo                        ; 02060103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
(invalid instruction)                                        ; d7026a04
	v_cndmask_b32_e32 v1, s5, v3, vcc_lo                        ; 02020605
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v4, v4, v3, vcc_lo                        ; 02080704
	v_subrev_co_ci_u32_e64 v1, s14, -1, v1, vcc_lo              ; d5220e01 01aa02c1
(invalid instruction)                                        ; d72d0005
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                       ; 02001f01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v5, v3, vcc_lo                        ; 02000705
	v_sub_nc_u32_e32 v6, v1, v6                                 ; 4c0c0d01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
(invalid instruction)                                        ; d7026a07
	v_cndmask_b32_e32 v1, s3, v6, vcc_lo                        ; 02020c03
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v7, v7, v6, vcc_lo                        ; 020e0d07
	v_subrev_co_ci_u32_e32 v5, vcc_lo, -1, v5, vcc_lo           ; 440a0ac1
(invalid instruction)                                        ; d7021108
	v_cndmask_b32_e32 v1, s3, v7, vcc_lo                        ; 02020e03
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_cmp_eq_i32 s6, 0                                          ; bf008006
	v_cndmask_b32_e64 v8, v8, v7, s17                           ; d5010008 00460f08
	v_subrev_co_ci_u32_e64 v5, vcc_lo, -1, v5, s17              ; d5226a05 00460ac1
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_and_b32 s4, s4, -16                                       ; 8b04d004
	v_lshrrev_b32_e32 v10, 2, v8                                ; 32141082
	v_and_b32_e32 v8, 3, v8                                     ; 36101083
	v_lshrrev_b32_e32 v9, 2, v5                                 ; 32120a82
	v_and_b32_e32 v5, 3, v5                                     ; 360a0a83
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; d72c0009
	v_cndmask_b32_e32 v0, v9, v3, vcc_lo                        ; 02000709
	v_add_lshl_u32 v9, v9, v10, 4                               ; d6470009 02121509
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v5, v5, 2, v9                                ; d6460005 04250505
	v_add_nc_u32_e32 v5, v5, v8                                 ; 4a0a1105
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cndmask_b32_e32 v11, v1, v5, vcc_lo                       ; 02160b01
	v_cndmask_b32_e32 v5, v5, v1, vcc_lo                        ; 020a0305
	v_lshrrev_b32_e32 v13, 4, v11                               ; 321a1684
	v_and_b32_e32 v11, 15, v11                                  ; 3616168f
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v13, v5, vcc_lo                       ; 02000b0d
	v_add_lshl_u32 v13, v13, v4, 8                              ; d647000d 0222090d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v11, v11, 4, v13                             ; d646000b 0435090b
	v_add_nc_u32_e32 v11, s4, v11                               ; 4a161604
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b128 v[0:3], v11, s[8:11], null offen           ; c405c07c 40801000 0000000b
	s_and_b32 s2, s2, -16                                       ; 8b02d002
	v_lshrrev_b32_e32 v12, 4, v5                                ; 32180a84
	v_and_b32_e32 v5, 15, v5                                    ; 360a0a8f
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v0, v12, v5, vcc_lo                       ; 02000b0c
	v_add_lshl_u32 v12, v12, v4, 8                              ; d647000c 0222090c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshl_add_u32 v5, v5, 4, v12                               ; d6460005 04310905
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_nc_u32_e32 v5, s2, v5                                 ; 4a0a0a02
	s_wait_loadcnt 0x0                                          ; bfc00000
	buffer_store_b128 v[0:3], v5, s[8:11], null offen           ; c407407c 40801000 00000005
BB6:
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
