BB0:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s16, s1                                           ; be900001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	s_load_b256 s[32:39], s[0:1], 0x30                          ; f4006800 f8000030
	s_lshl1_add_u32 s14, ttmp9, s14                             ; 870e0e75
	s_pack_ll_b32_b16 s17, ttmp7, 0                             ; 99118073
(invalid instruction)                                        ; d71f0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_lshrrev_b32_e32 v1, 5, v0                                 ; 32020085
	s_lshl1_add_u32 s17, s17, s15                               ; 87110f11
	s_max_i32 s18, s14, 0                                       ; 8a12800e
	s_add_co_u32 s19, s12, -1                                   ; 8013c10c
	v_and_b32_e32 v4, 15, v3                                    ; 3608068f
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_lshlrev_b32_e32 v2, 9, v1                                 ; 30040289
	s_min_i32 s18, s18, s19                                     ; 89121312
	s_max_i32 s24, s17, 0                                       ; 8a188011
	s_add_co_u32 s25, s13, -1                                   ; 8019c10d
	v_lshlrev_b32_e32 v5, 4, v4                                 ; 300a0884
	v_lshlrev_b32_e32 v3, 3, v3                                 ; 30060683
	v_add_nc_u32_e32 v7, 0x100, v2                              ; 4a0e04ff 00000100
	s_min_i32 s24, s24, s25                                     ; 89181918
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s24, s24, s12                                     ; 96180c18
	s_add_co_u32 s26, s24, s18                                  ; 801a1218
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s26, s26, 12                                     ; 841a8c1a
	s_add_co_u32 s27, s16, s26                                  ; 801b1a10
	s_add_co_u32 s28, s14, 1                                    ; 801c810e
	v_add3_u32 v6, v5, s27, v2                                  ; d6550006 04083705
	v_add3_u32 v8, v5, s27, v7                                  ; d6550008 041c3705
	s_max_i32 s29, s28, 0                                       ; 8a1d801c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_min_i32 s29, s29, s19                                     ; 891d131d
	v_add_nc_u32_e32 v6, v6, v3                                 ; 4a0c0706
	v_add_nc_u32_e32 v8, v8, v3                                 ; 4a100708
	s_add_co_u32 s24, s24, s29                                  ; 80181d18
	s_lshl_b32 s24, s24, 12                                     ; 84188c18
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s30, s16, s24                                  ; 801e1810
	s_add_co_u32 s31, s17, 1                                    ; 801f8111
	v_add3_u32 v9, v5, s30, v2                                  ; d6550009 04083d05
	v_add3_u32 v10, v5, s30, v7                                 ; d655000a 041c3d05
	s_max_i32 s40, s31, 0                                       ; 8a28801f
	s_min_i32 s40, s40, s25                                     ; 89281928
	v_add_nc_u32_e32 v9, v9, v3                                 ; 4a120709
	v_add_nc_u32_e32 v10, v10, v3                               ; 4a14070a
	s_mul_i32 s40, s40, s12                                     ; 96280c28
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s18, s40, s18                                  ; 80121228
	s_lshl_b32 s18, s18, 12                                     ; 84128c12
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s41, s16, s18                                  ; 80291210
	s_add_co_u32 s40, s40, s29                                  ; 80281d28
	v_add3_u32 v11, v5, s41, v2                                 ; d655000b 04085305
	v_add3_u32 v12, v5, s41, v7                                 ; d655000c 041c5305
	s_lshl_b32 s40, s40, 12                                     ; 84288c28
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s16, s40                                  ; 80102810
	v_add_nc_u32_e32 v11, v11, v3                               ; 4a16070b
	v_add_nc_u32_e32 v12, v12, v3                               ; 4a18070c
	v_add3_u32 v14, v5, s16, v7                                 ; d655000e 041c2105
	v_add3_u32 v13, v5, s16, v2                                 ; d655000d 04082105
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v3                               ; 4a1c070e
	v_add_nc_u32_e32 v13, v13, v3                               ; 4a1a070d
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[16:17], v6, s[20:23], null offen          ; c405407c 40802810 00000006
	buffer_load_b64 v[18:19], v8, s[20:23], null offen          ; c405407c 40802812 00000008
	buffer_load_b64 v[8:9], v9, s[20:23], null offen            ; c405407c 40802808 00000009
	buffer_load_b64 v[20:21], v10, s[20:23], null offen         ; c405407c 40802814 0000000a
	buffer_load_b64 v[10:11], v11, s[20:23], null offen         ; c405407c 4080280a 0000000b
	buffer_load_b64 v[22:23], v12, s[20:23], null offen         ; c405407c 40802816 0000000c
	buffer_load_b64 v[12:13], v13, s[20:23], null offen         ; c405407c 4080280c 0000000d
	buffer_load_b64 v[14:15], v14, s[20:23], null offen         ; c405407c 4080280e 0000000e
	v_lshlrev_b32_e32 v24, 3, v1                                ; 30300283
	v_and_b32_e32 v27, 31, v0                                   ; 3636009f
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_add_nc_u32_e32 v29, 2, v24                                ; 4a3a3082
	v_med3_i32 v26, -1, v24, 1                                  ; d620001a 020630c1
	v_sub_nc_u32_e32 v25, 0, v24                                ; 4c323080
	v_lshlrev_b32_e32 v28, 2, v27                               ; 30383682
	v_sub_nc_u32_e32 v30, 0, v29                                ; 4c3c3a80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_max_i32_e32 v25, v24, v25                                 ; 24323318
	v_max_i32_e32 v30, v29, v30                                 ; 243c3d1d
	v_med3_i32 v29, -1, v29, 1                                  ; d620001d 02063ac1
	v_lshrrev_b32_e32 v25, 1, v25                               ; 32323281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_lshrrev_b32_e32 v30, 1, v30                               ; 323c3c81
(invalid instruction)                                        ; d72c001a
	v_cndmask_b32_e32 v1, v26, v25, vcc_lo                      ; 0202331a
(invalid instruction)                                        ; d72c001d
	v_cndmask_b32_e32 v1, v29, v30, vcc_lo                      ; 02023d1d
	v_lshl_add_u32 v26, v26, 11, s3                             ; d646001a 000d171a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshl_add_u32 v29, v29, 11, s3                             ; d646001d 000d171d
	v_add_lshl_u32 v26, v26, v28, 2                             ; d647001a 020a391a
	v_add_lshl_u32 v29, v29, v28, 2                             ; d647001d 020a391d
	s_clause 0xa                                                ; bf85000a
	buffer_load_b128 v[32:35], v26, s[36:39], null offen        ; c405c07c 40804820 0000001a
	buffer_load_b128 v[36:39], v29, s[36:39], null offen        ; c405c07c 40804824 0000001d
	buffer_load_b128 v[40:43], v26, s[36:39], null offen offset:512 ; c405c07c 40804828 0002001a
	buffer_load_b128 v[44:47], v29, s[36:39], null offen offset:512 ; c405c07c 4080482c 0002001d
	buffer_load_b128 v[48:51], v26, s[36:39], null offen offset:1024 ; c405c07c 40804830 0004001a
	buffer_load_b128 v[52:55], v29, s[36:39], null offen offset:1024 ; c405c07c 40804834 0004001d
	buffer_load_b128 v[56:59], v26, s[36:39], null offen offset:1536 ; c405c07c 40804838 0006001a
	buffer_load_b128 v[60:63], v29, s[36:39], null offen offset:1536 ; c405c07c 4080483c 0006001d
	buffer_load_b128 v[64:67], v26, s[36:39], null offen offset:2048 ; c405c07c 40804840 0008001a
	buffer_load_b128 v[68:71], v29, s[36:39], null offen offset:2048 ; c405c07c 40804844 0008001d
	buffer_load_b128 v[72:75], v26, s[36:39], null offen offset:2560 ; c405c07c 40804848 000a001a
	v_add_nc_u32_e32 v31, v5, v3                                ; 4a3e0705
	s_min_i32 s42, s14, s17                                     ; 892a110e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_cmp_lt_i32 s42, 0                                         ; bf04802a
	v_add_nc_u32_e32 v76, v2, v31                               ; 4a983f02
	s_cselect_b32 s43, -1, 0                                    ; 982b80c1
	s_cmp_ge_i32 s14, s12                                       ; bf030c0e
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s44, -1, 0                                    ; 982c80c1
	v_add_nc_u32_e32 v79, 0x3000, v76                           ; 4a9e98ff 00003000
	v_add_nc_u32_e32 v77, 0x1000, v76                           ; 4a9a98ff 00001000
	v_add_nc_u32_e32 v78, 0x2000, v76                           ; 4a9c98ff 00002000
	s_or_b32 s43, s43, s44                                      ; 8c2b2c2b
	s_cmp_ge_i32 s17, s13                                       ; bf030d11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s45, -1, 0                                    ; 982d80c1
	s_or_b32 s43, s43, s45                                      ; 8c2b2d2b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mov_b32 s46, src_scc                                      ; beae00fd
	s_min_i32 s17, s28, s17                                     ; 8911111c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s17, 0                                         ; bf048011
	s_cselect_b32 s47, -1, 0                                    ; 982f80c1
	s_cmp_ge_i32 s28, s12                                       ; bf030c1c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s48, -1, 0                                    ; 983080c1
	s_or_b32 s47, s47, s48                                      ; 8c2f302f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s47, s47, s45                                      ; 8c2f2d2f
	s_pack_hh_b32_b16 s55, ttmp7, 0                             ; 9a378073
	s_mov_b32 s49, src_scc                                      ; beb100fd
	s_min_i32 s14, s14, s31                                     ; 890e1f0e
	s_movk_i32 s56, 0x400                                       ; b0380400
	v_lshl_add_u32 v80, s55, 4, v31                             ; d6460050 047d0837
	s_cmp_lt_i32 s14, 0                                         ; bf04800e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s50, -1, 0                                    ; 983280c1
	s_or_b32 s50, s50, s44                                      ; 8c322c32
	s_cmp_ge_i32 s31, s13                                       ; bf030d1f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s51, -1, 0                                    ; 983380c1
	s_or_b32 s50, s50, s51                                      ; 8c323332
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_mov_b32 s52, src_scc                                      ; beb400fd
	s_min_i32 s28, s28, s31                                     ; 891c1f1c
	s_cmp_lt_i32 s28, 0                                         ; bf04801c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s53, -1, 0                                    ; 983580c1
	s_or_b32 s53, s53, s48                                      ; 8c353035
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s53, s53, s51                                      ; 8c353335
	s_mov_b32 s54, src_scc                                      ; beb600fd
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v82, v16, 0, s43                          ; d5010052 00ad0110
	v_cndmask_b32_e64 v83, v17, 0, s43                          ; d5010053 00ad0111
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_cndmask_b32_e64 v17, v19, 0, s43                          ; d5010011 00ad0113
	v_cndmask_b32_e64 v16, v18, 0, s43                          ; d5010010 00ad0112
	ds_store_2addr_b64 v76, v[82:83], v[16:17] offset1:32       ; d9382000 0010524c
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_cndmask_b32_e64 v17, v9, 0, s47                           ; d5010011 00bd0109
	v_cndmask_b32_e64 v16, v8, 0, s47                           ; d5010010 00bd0108
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_cndmask_b32_e64 v8, v20, 0, s47                           ; d5010008 00bd0114
	v_cndmask_b32_e64 v9, v21, 0, s47                           ; d5010009 00bd0115
	ds_store_2addr_b64 v77, v[16:17], v[8:9] offset1:32         ; d9382000 0008104d
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_cndmask_b32_e64 v8, v10, 0, s50                           ; d5010008 00c9010a
	v_cndmask_b32_e64 v9, v11, 0, s50                           ; d5010009 00c9010b
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_cndmask_b32_e64 v10, v22, 0, s50                          ; d501000a 00c90116
	v_cndmask_b32_e64 v11, v23, 0, s50                          ; d501000b 00c90117
	ds_store_2addr_b64 v78, v[8:9], v[10:11] offset1:32         ; d9382000 000a084e
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_cndmask_b32_e64 v8, v12, 0, s53                           ; d5010008 00d5010c
	v_cndmask_b32_e64 v9, v13, 0, s53                           ; d5010009 00d5010d
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_cndmask_b32_e64 v11, v15, 0, s53                          ; d501000b 00d5010f
	v_cndmask_b32_e64 v10, v14, 0, s53                          ; d501000a 00d5010e
	ds_store_2addr_b64 v79, v[8:9], v[10:11] offset1:32         ; d9382000 000a084f
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[8:9], v80                                     ; d9d80000 08000050
	ds_load_b64 v[10:11], v80 offset:4096                       ; d9d81000 0a000050
	ds_load_b64 v[12:13], v80 offset:8192                       ; d9d82000 0c000050
	ds_load_b64 v[14:15], v80 offset:12288                      ; d9d83000 0e000050
	ds_load_b64 v[16:17], v80 offset:256                        ; d9d80100 10000050
	ds_load_b64 v[18:19], v80 offset:4352                       ; d9d81100 12000050
	ds_load_b64 v[20:21], v80 offset:8448                       ; d9d82100 14000050
	ds_load_b64 v[22:23], v80 offset:12544                      ; d9d83100 16000050
	ds_load_b64 v[82:83], v80 offset:512                        ; d9d80200 52000050
	v_mov_b32_e32 v81, v7                                       ; 7ea20307
	v_mov_b32_e32 v25, v28                                      ; 7e32031c
	v_dual_mov_b32 v85, v31 :: v_dual_mov_b32 v84, v29          ; ca10011f 5554011d
	s_wait_loadcnt_dscnt 0xa08                                  ; bfc80a08
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[8:9], 0  ; cc464060 1a021122
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[8:9], 0   ; cc464058 1a021120
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[10:11], 0 ; cc464080 1a021522
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[10:11], 0 ; cc464078 1a021520
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[12:13], 0 ; cc464098 1a021920
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[34:35], v[12:13], 0 ; cc4640a0 1a021922
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[12:13], 0 ; cc4640b0 1a021926
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[36:37], v[10:11], 0 ; cc464088 1a021524
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[32:33], v[14:15], 0 ; cc4640b8 1a021d20
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[8:9], 0 ; cc464070 1a021126
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[8:9], 0 ; cc464068 1a021124
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[10:11], 0 ; cc464090 1a021526
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[36:37], v[12:13], 0 ; cc4640a8 1a021924
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[34:35], v[14:15], 0  ; cc464006 1a021d22
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[36:37], v[14:15], 0 ; cc46401c 1a021d24
	v_dual_mov_b32 v37, v15 :: v_dual_mov_b32 v36, v14          ; ca10010f 2524010e
	s_wait_loadcnt_dscnt 0x804                                  ; bfc80804
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[16:17], v[96:103] ; cc464060 1d82212a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[16:17], v[88:95] ; cc464058 1d622128
	s_wait_dscnt 0x3                                            ; bfc60003
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[18:19], v[120:127] ; cc464078 1de22528
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[18:19], v[128:135] ; cc464080 1e02252a
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[20:21], v[152:159] ; cc464098 1e622928
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[44:45], v[18:19], v[136:143] ; cc464088 1e22252c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[42:43], v[20:21], v[160:167] ; cc4640a0 1e82292a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[16:17], v[112:119] ; cc464070 1dc2212e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[20:21], v[176:183] ; cc4640b0 1ec2292e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[16:17], v[104:111] ; cc464068 1da2212c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[18:19], v[144:151] ; cc464090 1e42252e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[20:21], v[168:175] ; cc4640a8 1ea2292c
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[38:39], v[36:37], 0 ; cc46400e 1a024926
	s_wait_loadcnt_dscnt 0x600                                  ; bfc80600
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[82:83], v[96:103] ; cc464060 1d82a532
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[40:41], v[22:23], v[184:191] ; cc4640b8 1ee22d28
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[82:83], v[88:95] ; cc464058 1d62a530
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[42:43], v[22:23], v[6:13] ; cc464006 1c1a2d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[44:45], v[22:23], v[28:35] ; cc46401c 1c722d2c
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[82:83], v[104:111] ; cc464068 1da2a534
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[82:83], v[112:119] ; cc464070 1dc2a536
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[46:47], v[22:23], v[14:21] ; cc46400e 1c3a2d2e
	ds_load_b64 v[36:37], v80 offset:4608                       ; d9d81200 24000050
	ds_load_b64 v[38:39], v80 offset:8704                       ; d9d82200 26000050
	ds_load_b64 v[40:41], v80 offset:12800                      ; d9d83200 28000050
	ds_load_b64 v[42:43], v80 offset:768                        ; d9d80300 2a000050
	ds_load_b64 v[44:45], v80 offset:4864                       ; d9d81300 2c000050
	ds_load_b64 v[22:23], v80 offset:8960                       ; d9d82300 16000050
	ds_load_b64 v[46:47], v80 offset:13056                      ; d9d83300 2e000050
	ds_load_b64 v[82:83], v80 offset:1024                       ; d9d80400 52000050
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[36:37], v[128:135] ; cc464080 1e024932
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[36:37], v[144:151] ; cc464090 1e424936
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[36:37], v[120:127] ; cc464078 1de24930
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[36:37], v[136:143] ; cc464088 1e224934
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[38:39], v[152:159] ; cc464098 1e624d30
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[38:39], v[176:183] ; cc4640b0 1ec24d36
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[38:39], v[160:167] ; cc4640a0 1e824d32
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[38:39], v[168:175] ; cc4640a8 1ea24d34
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[48:49], v[40:41], v[184:191] ; cc4640b8 1ee25130
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[52:53], v[40:41], v[28:35] ; cc46401c 1c725134
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[50:51], v[40:41], v[6:13] ; cc464006 1c1a5132
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[54:55], v[40:41], v[14:21] ; cc46400e 1c3a5136
	ds_load_b64 v[36:37], v80 offset:5120                       ; d9d81400 24000050
	ds_load_b64 v[38:39], v80 offset:9216                       ; d9d82400 26000050
	ds_load_b64 v[48:49], v80 offset:13312                      ; d9d83400 30000050
	ds_load_b64 v[50:51], v80 offset:1280                       ; d9d80500 32000050
	ds_load_b64 v[52:53], v80 offset:5376                       ; d9d81500 34000050
	ds_load_b64 v[40:41], v80 offset:9472                       ; d9d82500 28000050
	ds_load_b64 v[54:55], v80 offset:13568                      ; d9d83500 36000050
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[42:43], v[88:95] ; cc464058 1d625538
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[42:43], v[96:103] ; cc464060 1d82553a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[44:45], v[120:127] ; cc464078 1de25938
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[44:45], v[128:135] ; cc464080 1e02593a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[22:23], v[152:159] ; cc464098 1e622d38
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[22:23], v[160:167] ; cc4640a0 1e822d3a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[46:47], v[184:191] ; cc4640b8 1ee25d38
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[42:43], v[104:111] ; cc464068 1da2553c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[44:45], v[136:143] ; cc464088 1e22593c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[22:23], v[168:175] ; cc4640a8 1ea22d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[42:43], v[112:119] ; cc464070 1dc2553e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[44:45], v[144:151] ; cc464090 1e42593e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[22:23], v[176:183] ; cc4640b0 1ec22d3e
	ds_load_b64 v[56:57], v80 offset:1536                       ; d9d80600 38000050
	ds_load_b64 v[42:43], v80 offset:5632                       ; d9d81600 2a000050
	ds_load_b64 v[44:45], v80 offset:9728                       ; d9d82600 2c000050
	ds_load_b64 v[22:23], v80 offset:13824                      ; d9d83600 16000050
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[60:61], v[46:47], v[28:35] ; cc46401c 1c725d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[58:59], v[46:47], v[6:13] ; cc464006 1c1a5d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[62:63], v[46:47], v[14:21] ; cc46400e 1c3a5d3e
	ds_load_b64 v[46:47], v80 offset:1792                       ; d9d80700 2e000050
	ds_load_b64 v[58:59], v80 offset:5888                       ; d9d81700 3a000050
	s_wait_loadcnt_dscnt 0x20c                                  ; bfc8020c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[36:37], v[120:127] ; cc464078 1de24940
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[82:83], v[88:95] ; cc464058 1d62a540
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[38:39], v[152:159] ; cc464098 1e624d40
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[36:37], v[128:135] ; cc464080 1e024942
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[38:39], v[160:167] ; cc4640a0 1e824d42
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[36:37], v[136:143] ; cc464088 1e224944
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[38:39], v[168:175] ; cc4640a8 1ea24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[36:37], v[144:151] ; cc464090 1e424946
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[38:39], v[176:183] ; cc4640b0 1ec24d46
	ds_load_b64 v[36:37], v80 offset:9984                       ; d9d82700 24000050
	ds_load_b64 v[38:39], v80 offset:14080                      ; d9d83700 26000050
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[48:49], v[184:191] ; cc4640b8 1ee26140
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[82:83], v[96:103] ; cc464060 1d82a542
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[82:83], v[104:111] ; cc464068 1da2a544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[82:83], v[112:119] ; cc464070 1dc2a546
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[68:69], v[48:49], v[28:35] ; cc46401c 1c726144
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[66:67], v[48:49], v[6:13] ; cc464006 1c1a6142
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[48:49], v[14:21] ; cc46400e 1c3a6146
	v_dual_mov_b32 v49, v81 :: v_dual_mov_b32 v48, v80          ; ca100151 31300150
	s_wait_loadcnt_dscnt 0xb                                    ; bfc8000b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[50:51], v[88:95] ; cc464058 1d626548
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[52:53], v[120:127] ; cc464078 1de26948
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[40:41], v[152:159] ; cc464098 1e625148
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[52:53], v[128:135] ; cc464080 1e02694a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[72:73], v[54:55], v[184:191] ; cc4640b8 1ee26d48
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[74:75], v[40:41], v[160:167] ; cc4640a0 1e82514a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[74:75], v[50:51], v[96:103] ; cc464060 1d82654a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[74:75], v[54:55], v[6:13] ; cc464006 1c1a6d4a
	s_clause 0x4                                                ; bf850004
	buffer_load_b128 v[60:63], v84, s[36:39], null offen offset:2560 ; c405c07c 4080483c 000a0054
	buffer_load_b128 v[64:67], v26, s[36:39], null offen offset:3072 ; c405c07c 40804840 000c001a
	buffer_load_b128 v[68:71], v84, s[36:39], null offen offset:3072 ; c405c07c 40804844 000c0054
	buffer_load_b128 v[80:83], v26, s[36:39], null offen offset:3584 ; c405c07c 40804850 000e001a
	buffer_load_b128 v[72:75], v84, s[36:39], null offen offset:3584 ; c405c07c 40804848 000e0054
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[40:41], v[176:183] ; cc4640b0 1ec2513e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[52:53], v[144:151] ; cc464090 1e42693e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[40:41], v[168:175] ; cc4640a8 1ea2513c
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[60:61], v[54:55], v[28:35] ; cc46401c 1c726d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[50:51], v[104:111] ; cc464068 1da2653c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[50:51], v[112:119] ; cc464070 1dc2653e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[52:53], v[136:143] ; cc464088 1e22693c
	ds_load_b64 v[60:61], v48 offset:2048                       ; d9d80800 3c000030
	ds_load_b64 v[50:51], v48 offset:6144                       ; d9d81800 32000030
	ds_load_b64 v[52:53], v48 offset:10240                      ; d9d82800 34000030
	ds_load_b64 v[40:41], v48 offset:14336                      ; d9d83800 28000030
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[62:63], v[54:55], v[14:21] ; cc46400e 1c3a6d3e
	v_dual_mov_b32 v55, v85 :: v_dual_mov_b32 v54, v84          ; ca100155 37360154
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[56:57], v[88:95] ; cc464058 1d627140
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[42:43], v[120:127] ; cc464078 1de25540
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[44:45], v[152:159] ; cc464098 1e625940
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[22:23], v[184:191] ; cc4640b8 1ee22d40
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[56:57], v[96:103] ; cc464060 1d827142
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[42:43], v[128:135] ; cc464080 1e025542
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[44:45], v[160:167] ; cc4640a0 1e825942
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[66:67], v[22:23], v[6:13] ; cc464006 1c1a2d42
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[84:87], v26, s[36:39], null offen offset:4096 ; c405c07c 40804854 0010001a
	buffer_load_b128 v[64:67], v54, s[36:39], null offen offset:4096 ; c405c07c 40804840 00100036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[56:57], v[104:111] ; cc464068 1da27144
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[44:45], v[168:175] ; cc4640a8 1ea25944
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[42:43], v[136:143] ; cc464088 1e225544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[56:57], v[112:119] ; cc464070 1dc27146
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[42:43], v[144:151] ; cc464090 1e425546
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[44:45], v[176:183] ; cc4640b0 1ec25946
	ds_load_b64 v[62:63], v48 offset:2304                       ; d9d80900 3e000030
	ds_load_b64 v[56:57], v48 offset:6400                       ; d9d81900 38000030
	ds_load_b64 v[42:43], v48 offset:10496                      ; d9d82900 2a000030
	ds_load_b64 v[44:45], v48 offset:14592                      ; d9d83900 2c000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[68:69], v[22:23], v[28:35] ; cc46401c 1c722d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[22:23], v[14:21] ; cc46400e 1c3a2d46
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[80:81], v[46:47], v[88:95] ; cc464058 1d625d50
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[58:59], v[120:127] ; cc464078 1de27550
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[80:81], v[36:37], v[152:159] ; cc464098 1e624950
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[80:81], v[38:39], v[184:191] ; cc4640b8 1ee24d50
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[82:83], v[46:47], v[96:103] ; cc464060 1d825d52
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[58:59], v[128:135] ; cc464080 1e027552
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[82:83], v[36:37], v[160:167] ; cc4640a0 1e824952
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[82:83], v[38:39], v[6:13] ; cc464006 1c1a4d52
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v26, s[36:39], null offen offset:4608 ; c405c07c 40804844 0012001a
	buffer_load_b128 v[80:83], v54, s[36:39], null offen offset:4608 ; c405c07c 40804850 00120036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[46:47], v[104:111] ; cc464068 1da25d48
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[72:73], v[58:59], v[136:143] ; cc464088 1e227548
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[36:37], v[168:175] ; cc4640a8 1ea24948
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[46:47], v[112:119] ; cc464070 1dc25d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[74:75], v[58:59], v[144:151] ; cc464090 1e42754a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[36:37], v[176:183] ; cc4640b0 1ec2494a
	ds_load_b64 v[22:23], v48 offset:2560                       ; d9d80a00 16000030
	ds_load_b64 v[46:47], v48 offset:6656                       ; d9d81a00 2e000030
	ds_load_b64 v[58:59], v48 offset:10752                      ; d9d82a00 3a000030
	ds_load_b64 v[36:37], v48 offset:14848                      ; d9d83a00 24000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[72:73], v[38:39], v[28:35] ; cc46401c 1c724d48
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[38:39], v[14:21] ; cc46400e 1c3a4d4a
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[86:87], v[50:51], v[128:135] ; cc464080 1e026556
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[84:85], v[52:53], v[152:159] ; cc464098 1e626954
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[84:85], v[40:41], v[184:191] ; cc4640b8 1ee25154
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[86:87], v[60:61], v[96:103] ; cc464060 1d827956
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[86:87], v[52:53], v[160:167] ; cc4640a0 1e826956
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[84:85], v[50:51], v[120:127] ; cc464078 1de26554
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[84:85], v[60:61], v[88:95] ; cc464058 1d627954
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[86:87], v[40:41], v[6:13] ; cc464006 1c1a5156
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v26, s[36:39], null offen offset:5120 ; c405c07c 40804848 0014001a
	buffer_load_b128 v[84:87], v54, s[36:39], null offen offset:5120 ; c405c07c 40804854 00140036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[64:65], v[60:61], v[104:111] ; cc464068 1da27940
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[60:61], v[112:119] ; cc464070 1dc27942
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[64:65], v[50:51], v[136:143] ; cc464088 1e226540
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[64:65], v[52:53], v[168:175] ; cc4640a8 1ea26940
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[66:67], v[50:51], v[144:151] ; cc464090 1e426542
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[66:67], v[52:53], v[176:183] ; cc4640b0 1ec26942
	ds_load_b64 v[38:39], v48 offset:2816                       ; d9d80b00 26000030
	ds_load_b64 v[60:61], v48 offset:6912                       ; d9d81b00 3c000030
	ds_load_b64 v[50:51], v48 offset:11008                      ; d9d82b00 32000030
	ds_load_b64 v[52:53], v48 offset:15104                      ; d9d83b00 34000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[64:65], v[40:41], v[28:35] ; cc46401c 1c725140
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[66:67], v[40:41], v[14:21] ; cc46400e 1c3a5142
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[70:71], v[44:45], v[6:13] ; cc464006 1c1a5946
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[68:69], v[44:45], v[184:191] ; cc4640b8 1ee25944
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[56:57], v[120:127] ; cc464078 1de27144
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[62:63], v[96:103] ; cc464060 1d827d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[42:43], v[152:159] ; cc464098 1e625544
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[56:57], v[128:135] ; cc464080 1e027146
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[70:71], v[42:43], v[160:167] ; cc4640a0 1e825546
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[62:63], v[88:95] ; cc464058 1d627d44
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[64:67], v26, s[36:39], null offen offset:5632 ; c405c07c 40804840 0016001a
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:5632 ; c405c07c 40804844 00160036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[80:81], v[56:57], v[136:143] ; cc464088 1e227150
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[80:81], v[42:43], v[168:175] ; cc4640a8 1ea25550
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[80:81], v[62:63], v[104:111] ; cc464068 1da27d50
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[62:63], v[112:119] ; cc464070 1dc27d52
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[82:83], v[56:57], v[144:151] ; cc464090 1e427152
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[82:83], v[42:43], v[176:183] ; cc4640b0 1ec25552
	ds_load_b64 v[40:41], v48 offset:3072                       ; d9d80c00 28000030
	ds_load_b64 v[62:63], v48 offset:7168                       ; d9d81c00 3e000030
	ds_load_b64 v[56:57], v48 offset:11264                      ; d9d82c00 38000030
	ds_load_b64 v[42:43], v48 offset:15360                      ; d9d83c00 2a000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[80:81], v[44:45], v[28:35] ; cc46401c 1c725950
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[82:83], v[44:45], v[14:21] ; cc46400e 1c3a5952
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[72:73], v[36:37], v[184:191] ; cc4640b8 1ee24948
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[74:75], v[36:37], v[6:13] ; cc464006 1c1a494a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[74:75], v[22:23], v[96:103] ; cc464060 1d822d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[58:59], v[152:159] ; cc464098 1e627548
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[46:47], v[128:135] ; cc464080 1e025d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[74:75], v[58:59], v[160:167] ; cc4640a0 1e82754a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[46:47], v[120:127] ; cc464078 1de25d48
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[22:23], v[88:95] ; cc464058 1d622d48
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[80:83], v26, s[36:39], null offen offset:6144 ; c405c07c 40804850 0018001a
	buffer_load_b128 v[72:75], v54, s[36:39], null offen offset:6144 ; c405c07c 40804848 00180036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[84:85], v[46:47], v[136:143] ; cc464088 1e225d54
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[84:85], v[22:23], v[104:111] ; cc464068 1da22d54
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[84:85], v[58:59], v[168:175] ; cc4640a8 1ea27554
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[86:87], v[22:23], v[112:119] ; cc464070 1dc22d56
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[86:87], v[46:47], v[144:151] ; cc464090 1e425d56
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[86:87], v[58:59], v[176:183] ; cc4640b0 1ec27556
	ds_load_b64 v[44:45], v48 offset:3328                       ; d9d80d00 2c000030
	ds_load_b64 v[22:23], v48 offset:7424                       ; d9d81d00 16000030
	ds_load_b64 v[46:47], v48 offset:11520                      ; d9d82d00 2e000030
	ds_load_b64 v[58:59], v48 offset:15616                      ; d9d83d00 3a000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[84:85], v[36:37], v[28:35] ; cc46401c 1c724954
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[86:87], v[36:37], v[14:21] ; cc46400e 1c3a4956
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[52:53], v[184:191] ; cc4640b8 1ee26940
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[66:67], v[52:53], v[6:13] ; cc464006 1c1a6942
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[38:39], v[96:103] ; cc464060 1d824d42
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[60:61], v[128:135] ; cc464080 1e027942
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[50:51], v[152:159] ; cc464098 1e626540
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[50:51], v[160:167] ; cc4640a0 1e826542
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[60:61], v[120:127] ; cc464078 1de27940
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[38:39], v[88:95] ; cc464058 1d624d40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[84:87], v26, s[36:39], null offen offset:6656 ; c405c07c 40804854 001a001a
	buffer_load_b128 v[64:67], v54, s[36:39], null offen offset:6656 ; c405c07c 40804840 001a0036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[60:61], v[136:143] ; cc464088 1e227944
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[50:51], v[168:175] ; cc4640a8 1ea26544
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[38:39], v[104:111] ; cc464068 1da24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[38:39], v[112:119] ; cc464070 1dc24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[60:61], v[144:151] ; cc464090 1e427946
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[50:51], v[176:183] ; cc4640b0 1ec26546
	ds_load_b64 v[36:37], v48 offset:3584                       ; d9d80e00 24000030
	ds_load_b64 v[38:39], v48 offset:7680                       ; d9d81e00 26000030
	ds_load_b64 v[60:61], v48 offset:11776                      ; d9d82e00 3c000030
	ds_load_b64 v[50:51], v48 offset:15872                      ; d9d83e00 32000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[68:69], v[52:53], v[28:35] ; cc46401c 1c726944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[52:53], v[14:21] ; cc46400e 1c3a6946
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[80:81], v[42:43], v[184:191] ; cc4640b8 1ee25550
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[82:83], v[42:43], v[6:13] ; cc464006 1c1a5552
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[82:83], v[40:41], v[96:103] ; cc464060 1d825152
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[80:81], v[56:57], v[152:159] ; cc464098 1e627150
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[62:63], v[128:135] ; cc464080 1e027d52
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[82:83], v[56:57], v[160:167] ; cc4640a0 1e827152
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[62:63], v[120:127] ; cc464078 1de27d50
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[80:81], v[40:41], v[88:95] ; cc464058 1d625150
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v26, s[36:39], null offen offset:7168 ; c405c07c 40804844 001c001a
	buffer_load_b128 v[80:83], v54, s[36:39], null offen offset:7168 ; c405c07c 40804850 001c0036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[72:73], v[62:63], v[136:143] ; cc464088 1e227d48
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[56:57], v[168:175] ; cc4640a8 1ea27148
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[40:41], v[104:111] ; cc464068 1da25148
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[40:41], v[112:119] ; cc464070 1dc2514a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[74:75], v[62:63], v[144:151] ; cc464090 1e427d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[56:57], v[176:183] ; cc4640b0 1ec2714a
	ds_load_b64 v[52:53], v48 offset:3840                       ; d9d80f00 34000030
	ds_load_b64 v[40:41], v48 offset:7936                       ; d9d81f00 28000030
	ds_load_b64 v[62:63], v48 offset:12032                      ; d9d82f00 3e000030
	ds_load_b64 v[56:57], v48 offset:16128                      ; d9d83f00 38000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[72:73], v[42:43], v[28:35] ; cc46401c 1c725548
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[42:43], v[14:21] ; cc46400e 1c3a554a
	buffer_load_b128 v[72:75], v26, s[36:39], null offen offset:7680 ; c405c07c 40804848 001e001a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_mov_b32_e32 v26, v86                                      ; 7e340356
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[84:85], v[58:59], v[184:191] ; cc4640b8 1ee27554
	v_mov_b32_e32 v42, v87                                      ; 7e540357
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[84:85], v[44:45], v[88:95] ; cc464058 1d625954
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[84:85], v[46:47], v[152:159] ; cc464098 1e625d54
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[84:85], v[22:23], v[120:127] ; cc464078 1de22d54
	buffer_load_b128 v[84:87], v54, s[36:39], null offen offset:7680 ; c405c07c 40804854 001e0036
	v_mad_u32_u24 v43, s55, 0x50, v55                           ; d60b002b 04ddfe37 00000050
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[64:65], v[22:23], v[136:143] ; cc464088 1e222d40
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[64:65], v[44:45], v[104:111] ; cc464068 1da25940
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[64:65], v[46:47], v[168:175] ; cc4640a8 1ea25d40
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[64:65], v[58:59], v[28:35] ; cc46401c 1c727540
	v_swap_b32 v27, v42                                         ; 7e36cb2a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[26:27], v[46:47], v[160:167] ; cc4640a0 1e825d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[26:27], v[58:59], v[6:13] ; cc464006 1c1a751a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[44:45], v[96:103] ; cc464060 1d82591a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[22:23], v[128:135] ; cc464080 1e022d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[44:45], v[112:119] ; cc464070 1dc25942
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[66:67], v[22:23], v[144:151] ; cc464090 1e422d42
	ds_load_b64 v[26:27], v43                                   ; d9d80000 1a00002b
	ds_load_b64 v[64:65], v43 offset:4096                       ; d9d81000 4000002b
	ds_load_b64 v[44:45], v43 offset:8192                       ; d9d82000 2c00002b
	ds_load_b64 v[22:23], v43 offset:12288                      ; d9d83000 1600002b
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[66:67], v[46:47], v[176:183] ; cc4640b0 1ec25d42
	v_add_nc_u32_e32 v46, 4, v24                                ; 4a5c3084
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[66:67], v[58:59], v[14:21] ; cc46400e 1c3a7542
	v_mov_b32_e32 v58, v49                                      ; 7e740331
	v_sub_nc_u32_e32 v47, 0, v46                                ; 4c5e5c80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v47, v46, v47                                 ; 245e5f2e
	v_med3_i32 v46, -1, v46, 1                                  ; d620002e 02065cc1
	v_lshrrev_b32_e32 v47, 1, v47                               ; 325e5e81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c002e
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	v_lshl_add_u32 v46, v46, 11, s3                             ; d646002e 000d172e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v46, v46, v25, 2                             ; d647002e 020a332e
	v_mov_b32_e32 v54, v46                                      ; 7e6c032e
	buffer_load_b128 v[46:49], v46, s[36:39], null offen        ; c405c07c 4080482e 0000002e
	v_add_nc_u32_e32 v24, 6, v24                                ; 4a303086
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v59, 0, v24                                ; 4c763080
	v_max_i32_e32 v59, v24, v59                                 ; 24767718
	v_med3_i32 v24, -1, v24, 1                                  ; d6200018 020630c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_lshrrev_b32_e32 v59, 1, v59                               ; 32767681
(invalid instruction)                                        ; d72c0018
	v_cndmask_b32_e32 v1, v24, v59, vcc_lo                      ; 02027718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v24, v24, 11, s3                             ; d6460018 000d1718
	v_add_lshl_u32 v24, v24, v25, 2                             ; d6470018 020a3318
	s_wait_loadcnt_dscnt 0x408                                  ; bfc80408
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[68:69], v[50:51], v[184:191] ; cc4640b8 1ee26544
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[38:39], v[120:127] ; cc464078 1de24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[36:37], v[88:95] ; cc464058 1d624944
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[36:37], v[96:103] ; cc464060 1d824946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[38:39], v[128:135] ; cc464080 1e024d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[70:71], v[60:61], v[160:167] ; cc4640a0 1e827946
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[60:61], v[152:159] ; cc464098 1e627944
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[70:71], v[50:51], v[6:13] ; cc464006 1c1a6546
	buffer_load_b128 v[68:71], v24, s[36:39], null offen        ; c405c07c 40804844 00000018
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[80:81], v[60:61], v[168:175] ; cc4640a8 1ea27950
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[80:81], v[38:39], v[136:143] ; cc464088 1e224d50
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[80:81], v[36:37], v[104:111] ; cc464068 1da24950
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[36:37], v[112:119] ; cc464070 1dc24952
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[82:83], v[38:39], v[144:151] ; cc464090 1e424d52
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[82:83], v[60:61], v[176:183] ; cc4640b0 1ec27952
	ds_load_b64 v[66:67], v43 offset:256                        ; d9d80100 4200002b
	ds_load_b64 v[36:37], v43 offset:4352                       ; d9d81100 2400002b
	ds_load_b64 v[38:39], v43 offset:8448                       ; d9d82100 2600002b
	ds_load_b64 v[60:61], v43 offset:12544                      ; d9d83100 3c00002b
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[80:81], v[50:51], v[28:35] ; cc46401c 1c726550
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[52:53], v[88:95] ; cc464058 1d626948
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[40:41], v[120:127] ; cc464078 1de25148
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[62:63], v[152:159] ; cc464098 1e627d48
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[72:73], v[56:57], v[184:191] ; cc4640b8 1ee27148
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[74:75], v[52:53], v[96:103] ; cc464060 1d82694a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[40:41], v[128:135] ; cc464080 1e02514a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[74:75], v[62:63], v[160:167] ; cc4640a0 1e827d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[74:75], v[56:57], v[6:13] ; cc464006 1c1a714a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[82:83], v[50:51], v[14:21] ; cc46400e 1c3a6552
	v_maxmin_num_f32 v74, -4.0, v89, 4.0                        ; d669004a 03dab2f7
	v_maxmin_num_f32 v82, -4.0, v91, 4.0                        ; d6690052 03dab6f7
	v_maxmin_num_f32 v80, -4.0, v90, 4.0                        ; d6690050 03dab4f7
	v_maxmin_num_f32 v72, -4.0, v88, 4.0                        ; d6690048 03dab0f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
	v_fma_mix_f32 v75, 0xab28, |v74|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624b 0bfe94ff 3728ab28
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_fma_mix_f32 v73, 0xab28, |v72|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206249 0bfe90ff 3728ab28
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c842a553 5350a350 3f650000
	v_dual_fmaak_f32 v75, v75, v74, 0x3f650000 :: v_dual_fmaak_f32 v72, v72, v73, 0x3f650000 ; c842954b 4b489348 3f650000
	v_maxmin_num_f32 v59, -4.0, v95, 4.0                        ; d669003b 03dabef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870253
	v_dual_mul_f32 v91, v91, v83 :: v_dual_mul_f32 v90, v90, v80 ; c8c6a75b 5b5aa15a
	v_dual_mul_f32 v89, v89, v75 :: v_dual_mul_f32 v88, v88, v72 ; c8c69759 59589158
	v_maxmin_num_f32 v73, -4.0, v120, 4.0                       ; d6690049 03daf0f7
	v_fma_mix_f32 v72, 0xab28, |v59|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe76ff 3728ab28
	v_maxmin_num_f32 v75, -4.0, v121, 4.0                       ; d669004b 03daf2f7
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v92, 4.0                        ; d6690058 03dab8f7
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v90, -4.0, v93, 4.0                        ; d669005a 03dabaf7
	v_fma_mix_f32 v74, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe92ff 3728ab28
	v_fmaak_f32 v72, v72, v59, 0x3f650000                       ; 5a907748 3f650000
	v_fma_mix_f32 v80, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe96ff 3728ab28
	v_maxmin_num_f32 v81, -4.0, v122, 4.0                       ; d6690051 03daf4f7
	v_maxmin_num_f32 v83, -4.0, v123, 4.0                       ; d6690053 03daf6f7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_dual_fmaak_f32 v80, v80, v75, 0x3f650000 :: v_dual_fmaak_f32 v73, v73, v74, 0x3f650000 ; c8429750 50489549 3f650000
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	v_maxmin_num_f32 v89, -4.0, v124, 4.0                       ; d6690059 03daf8f7
	v_dual_mul_f32 v120, v120, v73 :: v_dual_mul_f32 v121, v121, v80 ; c8c69378 7878a179
	v_dual_mul_f32 v93, v93, v91 :: v_dual_mul_f32 v92, v92, v88 ; c8c6b75d 5d5cb15c
	v_maxmin_num_f32 v91, -4.0, v125, 4.0                       ; d669005b 03dafaf7
	v_fma_mix_f32 v88, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfea6ff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v92, -4.0, v94, 4.0                        ; d669005c 03dabcf7
	v_dual_fmaak_f32 v88, v88, v83, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 ; c842a758 5850a551 3f650000
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_mul_f32 v123, v123, v88 :: v_dual_mul_f32 v122, v122, v81 ; c8c6b17b 7b7aa37a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmaak_f32 v92, v92, v93, 0x3f650000                       ; 5ab8bb5c 3f650000
	v_maxmin_num_f32 v93, -4.0, v126, 4.0                       ; d669005d 03dafcf7
	v_dual_mul_f32 v94, v92, v94 :: v_dual_mul_f32 v95, v95, v72 ; c8c6bd5c 5e5e915f
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v152, 4.0                      ; d6690079 03db30f7
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v123, -4.0, v153, 4.0                      ; d669007b 03db32f7
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v127, 4.0                       ; d669005f 03dafef7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c842b75c 5c58b559 3f650000
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v120, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfebeff 3728ab28
	v_dual_mul_f32 v125, v125, v92 :: v_dual_mul_f32 v124, v124, v89 ; c8c6b97d 7d7cb37c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v120, v120, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf78 785cbd5d 3f650000
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v125, -4.0, v154, 4.0                      ; d669007d 03db34f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_mul_f32 v127, v127, v120 :: v_dual_mul_f32 v126, v126, v93 ; c8c6f17f 7f7ebb7e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c842f579 797cf77c 3f650000
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v127, -4.0, v155, 4.0                      ; d669007f 03db36f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v82, -4.0, v159, 4.0                       ; d6690052 03db3ef7
	v_dual_mul_f32 v153, v153, v124 :: v_dual_mul_f32 v152, v152, v121 ; c8c6f999 9998f398
	v_maxmin_num_f32 v80, -4.0, v158, 4.0                       ; d6690050 03db3cf7
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v153, -4.0, v156, 4.0                      ; d6690099 03db38f7
	v_fma_mix_f32 v152, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bfefeff 3728ab28
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[86:87], v[52:53], v[112:119] ; cc464070 1dc26956
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[86:87], v[40:41], v[144:151] ; cc464090 1e425156
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[86:87], v[62:63], v[176:183] ; cc4640b0 1ec27d56
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[86:87], v[56:57], v[14:21] ; cc46400e 1c3a7156
	v_dual_fmaak_f32 v152, v152, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842ff98 987cfd7d 3f650000
	v_maxmin_num_f32 v86, -4.0, v185, 4.0                       ; d6690056 03db72f7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[84:85], v[52:53], v[104:111] ; cc464068 1da26954
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[84:85], v[40:41], v[136:143] ; cc464088 1e225154
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[84:85], v[62:63], v[168:175] ; cc4640a8 1ea27d54
	v_dual_mul_f32 v155, v155, v152 :: v_dual_mul_f32 v154, v154, v125 ; c8c7319b 9b9afb9a
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[84:85], v[56:57], v[28:35] ; cc46401c 1c727154
	v_maxmin_num_f32 v84, -4.0, v184, 4.0                       ; d6690054 03db70f7
	v_maxmin_num_f32 v90, -4.0, v187, 4.0                       ; d669005a 03db76f7
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v155, -4.0, v157, 4.0                      ; d669009b 03db3af7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v186, 4.0                       ; d6690058 03db74f7
	v_maxmin_num_f32 v94, -4.0, v189, 4.0                       ; d669005e 03db7af7
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v188, 4.0                       ; d669005c 03db78f7
	v_fma_mix_f32 v59, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623b 0bff36ff 3728ab28
	v_fmaak_f32 v153, v153, v154, 0x3f650000                    ; 5b333599 3f650000
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_maxmin_num_f32 v122, -4.0, v191, 4.0                      ; d669007a 03db7ef7
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v120, -4.0, v190, 4.0                      ; d6690078 03db7cf7
	v_fmaak_f32 v59, v59, v155, 0x3f650000                      ; 5a77373b 3f650000
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_mul_f32 v156, v156, v153 ; c846a553 539d339c 3f650000
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_maxmin_num_f32 v126, -4.0, v97, 4.0                       ; d669007e 03dac2f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_mul_f32_e32 v157, v157, v59                               ; 113a779d
	v_maxmin_num_f32 v124, -4.0, v96, 4.0                       ; d669007c 03dac0f7
	v_dual_mul_f32 v159, v159, v83 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c8c2a79f 9f50a350 3f650000
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v99, 4.0                       ; d669009a 03dac6f7
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_mul_f32 v158, v158, v80 ; c846ad57 579ea19e 3f650000
	v_maxmin_num_f32 v152, -4.0, v98, 4.0                       ; d6690098 03dac4f7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_mul_f32 v185, v185, v87 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c8c2afb9 b954ab54 3f650000
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v101, 4.0                      ; d669009e 03dacaf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_mul_f32 v184, v184, v84 ; c846b55b 5bb8a9b8 3f650000
	v_maxmin_num_f32 v156, -4.0, v100, 4.0                      ; d669009c 03dac8f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_dual_mul_f32 v187, v187, v91 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c8c2b7bb bb58b358 3f650000
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_mul_f32 v186, v186, v88 ; c846bd5f 5fbab1ba 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870241
	v_dual_mul_f32 v189, v189, v95 :: v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 ; c8c2bfbd bd5cbb5c 3f650000
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v186, -4.0, v103, 4.0                      ; d66900ba 03dacef7
	v_maxmin_num_f32 v184, -4.0, v102, 4.0                      ; d66900b8 03daccf7
	v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 :: v_dual_mul_f32 v188, v188, v92 ; c846f57b 7bbcb9bc 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_dual_mul_f32 v191, v191, v123 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8c2f7bf bf78f378 3f650000
	v_maxmin_num_f32 v188, -4.0, v128, 4.0                      ; d66900bc 03db00f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_mul_f32 v190, v190, v120 ; c846fd7f 7fbef1be 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v190, -4.0, v129, 4.0                      ; d66900be 03db02f7
	v_dual_mul_f32 v97, v97, v127 :: v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 ; c8c2ff61 617cfb7c 3f650000
	v_maxmin_num_f32 v59, -4.0, v131, 4.0                       ; d669003b 03db06f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_mul_f32 v96, v96, v124 ; c847359b 9b60f960 3f650000
	v_fma_mix_f32 v62, 0xab28, |v59|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623e 0bfe76ff 3728ab28
	v_maxmin_num_f32 v63, -4.0, v132, 4.0                       ; d669003f 03db08f7
	v_dual_mul_f32 v99, v99, v155 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c8c33763 63993398 3f650000
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v81, -4.0, v133, 4.0                       ; d6690051 03db0af7
	v_fma_mix_f32 v80, 0xab28, |v63|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_mul_f32 v98, v98, v152 ; c8473d9f 9f633162 3f650000
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_maxmin_num_f32 v83, -4.0, v134, 4.0                       ; d6690053 03db0cf7
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_mul_f32 v101, v101, v159 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8c33f65 659d3b9c 3f650000
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v85, -4.0, v135, 4.0                       ; d6690055 03db0ef7
	v_dual_fmaak_f32 v63, v63, v80, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 ; c842a13f 3f52a352 3f650000
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_mul_f32 v100, v100, v156 ; c84775bb bb653964 3f650000
	v_maxmin_num_f32 v87, -4.0, v160, 4.0                       ; d6690057 03db40f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v161, 4.0                       ; d6690059 03db42f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_mul_f32 v103, v103, v187 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8c37767 67b973b8 3f650000
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842a953 5356ab56 3f650000
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v162, 4.0                       ; d669005b 03db44f7
	v_maxmin_num_f32 v93, -4.0, v163, 4.0                       ; d669005d 03db46f7
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_mul_f32 v102, v102, v184 ; c8477dbf bf677166 3f650000
	v_dual_mul_f32 v135, v135, v86 :: v_dual_mul_f32 v132, v132, v63 ; c8c6ad87 87847f84
	v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b157 575ab35a 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v164, 4.0                       ; d669005f 03db48f7
	v_dual_mul_f32 v129, v129, v191 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8c37f81 81bd7bbc 3f650000
	v_maxmin_num_f32 v191, -4.0, v130, 4.0                      ; d66900bf 03db04f7
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v97, -4.0, v165, 4.0                       ; d6690061 03db4af7
	v_dual_mul_f32 v161, v161, v90 :: v_dual_mul_f32 v134, v134, v83 ; c8c6b5a1 a186a786
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842b95b 5b5ebb5e 3f650000
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v166, 4.0                       ; d6690063 03db4cf7
	v_fma_mix_f32 v57, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206239 0bff7eff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v167, 4.0                      ; d6690065 03db4ef7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_mul_f32 v163, v163, v94 :: v_dual_mul_f32 v160, v160, v87 ; c8c6bda3 a3a0afa0
	v_maxmin_num_f32 v103, -4.0, v6, 4.0                        ; d6690067 03da0cf7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_dual_fmaak_f32 v191, v191, v57, 0x3f650000 :: v_dual_fmaak_f32 v62, v62, v59, 0x3f650000 ; c84273bf bf3e773e 3f650000
	v_maxmin_num_f32 v121, -4.0, v7, 4.0                        ; d6690079 03da0ef7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 ; c842c15f 5f62c362 3f650000
	v_fma_mix_f32 v120, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeceff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v8, 4.0                        ; d669007b 03da10f7
	v_dual_mul_f32 v133, v133, v82 :: v_dual_mul_f32 v130, v130, v191 ; c8c6a585 85837f82
	v_dual_mul_f32 v131, v131, v62 :: v_dual_mul_f32 v128, v128, v188 ; c8c67d83 83817980
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_maxmin_num_f32 v125, -4.0, v9, 4.0                        ; d669007d 03da12f7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c842c963 6366cb66 3f650000
	v_dual_mul_f32 v165, v165, v98 :: v_dual_mul_f32 v162, v162, v91 ; c8c6c5a5 a5a2b7a2
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v10, 4.0                       ; d669007f 03da14f7
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v129, -4.0, v11, 4.0                       ; d6690081 03da16f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_dual_fmaak_f32 v103, v103, v120, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f167 677af37a 3f650000
	v_dual_mul_f32 v167, v167, v102 :: v_dual_mul_f32 v164, v164, v95 ; c8c6cda7 a7a4bfa4
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_maxmin_num_f32 v131, -4.0, v12, 4.0                       ; d6690083 03da18f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v133, -4.0, v13, 4.0                       ; d6690085 03da1af7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c842f97b 7b7efb7e 3f650000
	v_maxmin_num_f32 v135, -4.0, v104, 4.0                      ; d6690087 03dad0f7
	v_dual_mul_f32 v7, v7, v122 :: v_dual_mul_f32 v166, v166, v99 ; c8c6f507 07a6c7a6
	v_maxmin_num_f32 v153, -4.0, v105, 4.0                      ; d6690099 03dad2f7
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v106, 4.0                      ; d669009b 03dad4f7
	v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 ; c843017f 7f830382 3f650000
	v_dual_mul_f32 v9, v9, v126 :: v_dual_mul_f32 v6, v6, v103  ; c8c6fd09 0906cf06
	v_fma_mix_f32 v152, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff0eff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v107, 4.0                      ; d669009d 03dad6f7
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 ; c8430983 83870b86 3f650000
	v_maxmin_num_f32 v159, -4.0, v108, 4.0                      ; d669009f 03dad8f7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_mul_f32 v11, v11, v130 :: v_dual_mul_f32 v8, v8, v123 ; c8c7050b 0b08f708
	v_maxmin_num_f32 v161, -4.0, v109, 4.0                      ; d66900a1 03dadaf7
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v110, 4.0                      ; d66900a3 03dadcf7
	v_dual_fmaak_f32 v135, v135, v152, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c8433187 879b339a 3f650000
	v_dual_mul_f32 v13, v13, v134 :: v_dual_mul_f32 v10, v10, v127 ; c8c70d0d 0d0aff0a
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v111, 4.0                      ; d66900a5 03dadef7
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v136, 4.0                      ; d66900a7 03db10f7
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 ; c843399b 9b9f3b9e 3f650000
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v137, 4.0                      ; d66900b9 03db12f7
	v_dual_mul_f32 v105, v105, v154 :: v_dual_mul_f32 v12, v12, v131 ; c8c73569 690d070c
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c843419f 9fa343a2 3f650000
	v_maxmin_num_f32 v187, -4.0, v138, 4.0                      ; d66900bb 03db14f7
	v_fma_mix_f32 v184, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff4eff 3728ab28
	v_dual_mul_f32 v107, v107, v158 :: v_dual_mul_f32 v104, v104, v135 ; c8c73d6b 6b690f68
	v_maxmin_num_f32 v189, -4.0, v139, 4.0                      ; d66900bd 03db16f7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
	v_maxmin_num_f32 v191, -4.0, v140, 4.0                      ; d66900bf 03db18f7
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84349a3 a3a74ba6 3f650000
	v_dual_mul_f32 v109, v109, v162 :: v_dual_mul_f32 v106, v106, v155 ; c8c7456d 6d6b376a
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v12, -4.0, v141, 4.0                       ; d669000c 03db1af7
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_fmaak_f32 v167, v167, v184, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84371a7 a7bb73ba 3f650000
	v_maxmin_num_f32 v59, -4.0, v142, 4.0                       ; d669003b 03db1cf7
	v_fma_mix_f32 v11, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620b 0bff7eff 3728ab28
	v_dual_mul_f32 v111, v111, v166 :: v_dual_mul_f32 v108, v108, v159 ; c8c74d6f 6f6d3f6c
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v81, -4.0, v143, 4.0                       ; d6690051 03db1ef7
	v_fma_mix_f32 v13, 0xab28, |v12|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bfe18ff 3728ab28
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c84379bb bbbf7bbe 3f650000
	v_maxmin_num_f32 v83, -4.0, v168, 4.0                       ; d6690053 03db50f7
	v_dual_mul_f32 v137, v137, v186 :: v_dual_mul_f32 v110, v110, v163 ; c8c77589 896f476e
	v_fma_mix_f32 v80, 0xab28, |v59|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe76ff 3728ab28
	v_fmaak_f32 v191, v191, v11, 0x3f650000                     ; 5b7e17bf 3f650000
	v_maxmin_num_f32 v85, -4.0, v169, 4.0                       ; d6690055 03db52f7
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_dual_fmaak_f32 v13, v13, v12, 0x3f650000 :: v_dual_mul_f32 v138, v138, v187 ; c846190d 0d8b778a 3f650000
	v_dual_mul_f32 v139, v139, v190 :: v_dual_mul_f32 v136, v136, v167 ; c8c77d8b 8b894f88
	v_maxmin_num_f32 v87, -4.0, v170, 4.0                       ; d6690057 03db54f7
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v171, 4.0                       ; d6690059 03db56f7
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v172, 4.0                       ; d669005b 03db58f7
	v_dual_fmaak_f32 v59, v59, v80, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 ; c842a13b 3b52a352 3f650000
	v_dual_mul_f32 v141, v141, v13 :: v_dual_mul_f32 v140, v140, v191 ; c8c61b8d 8d8d7f8c
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_maxmin_num_f32 v93, -4.0, v173, 4.0                       ; d669005d 03db5af7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v174, 4.0                       ; d669005f 03db5cf7
	v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842a953 5356ab56 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_mul_f32 v143, v143, v82 :: v_dual_mul_f32 v142, v142, v59 ; c8c6a58f 8f8e778e
	v_maxmin_num_f32 v97, -4.0, v175, 4.0                       ; d6690061 03db5ef7
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v28, 4.0                        ; d6690063 03da38f7
	v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 :: v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 ; c842b35a 5a56b157 3f650000
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v29, 4.0                       ; d6690065 03da3af7
	v_dual_mul_f32 v169, v169, v86 :: v_dual_mul_f32 v168, v168, v83 ; c8c6ada9 a9a8a7a8
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v30, 4.0                       ; d6690067 03da3cf7
	v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 :: v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 ; c842bb5e 5e5ab95b 3f650000
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v105, -4.0, v31, 4.0                       ; d6690069 03da3ef7
	v_dual_mul_f32 v171, v171, v90 :: v_dual_mul_f32 v170, v170, v87 ; c8c6b5ab abaaafaa
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_maxmin_num_f32 v107, -4.0, v32, 4.0                       ; d669006b 03da40f7
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c842c362 625ec15f 3f650000
	v_maxmin_num_f32 v109, -4.0, v33, 4.0                       ; d669006d 03da42f7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_mul_f32 v173, v173, v94 :: v_dual_mul_f32 v172, v172, v91 ; c8c6bdad adacb7ac
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 :: v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 ; c842cb66 6662c963 3f650000
	v_maxmin_num_f32 v111, -4.0, v34, 4.0                       ; d669006f 03da44f7
	v_maxmin_num_f32 v121, -4.0, v35, 4.0                       ; d6690079 03da46f7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_dual_mul_f32 v175, v175, v98 :: v_dual_mul_f32 v174, v174, v95 ; c8c6c5af afaebfae
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 :: v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 ; c842d36a 6a66d167 3f650000
	v_maxmin_num_f32 v123, -4.0, v112, 4.0                      ; d669007b 03dae0f7
	v_dual_mul_f32 v29, v29, v102 :: v_dual_mul_f32 v28, v28, v99 ; c8c6cd1d 1d1cc71c
	v_maxmin_num_f32 v125, -4.0, v113, 4.0                      ; d669007d 03dae2f7
	v_fma_mix_f32 v120, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfedeff 3728ab28
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_maxmin_num_f32 v127, -4.0, v114, 4.0                      ; d669007f 03dae4f7
	v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 :: v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 ; c842db6e 6e6ad96b 3f650000
	v_dual_mul_f32 v31, v31, v106 :: v_dual_mul_f32 v30, v30, v103 ; c8c6d51f 1f1ecf1e
	v_maxmin_num_f32 v129, -4.0, v115, 4.0                      ; d6690081 03dae6f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 :: v_dual_fmaak_f32 v111, v111, v120, 0x3f650000 ; c842f37a 7a6ef16f 3f650000
	v_maxmin_num_f32 v131, -4.0, v116, 4.0                      ; d6690083 03dae8f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v133, -4.0, v117, 4.0                      ; d6690085 03daeaf7
	v_dual_mul_f32 v33, v33, v110 :: v_dual_mul_f32 v32, v32, v107 ; c8c6dd21 2120d720
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v118, 4.0                      ; d6690087 03daecf7
	v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 ; c842fb7e 7e7af97b 3f650000
	v_dual_mul_f32 v35, v35, v122 :: v_dual_mul_f32 v34, v34, v111 ; c8c6f523 2322df22
	v_maxmin_num_f32 v137, -4.0, v119, 4.0                      ; d6690089 03daeef7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	v_maxmin_num_f32 v139, -4.0, v144, 4.0                      ; d669008b 03db20f7
	v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 :: v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 ; c8430382 827f017f 3f650000
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_maxmin_num_f32 v141, -4.0, v145, 4.0                      ; d669008d 03db22f7
	v_dual_mul_f32 v113, v113, v126 :: v_dual_mul_f32 v112, v112, v123 ; c8c6fd71 7170f770
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 ; c8430b86 86830983 3f650000
	v_maxmin_num_f32 v143, -4.0, v146, 4.0                      ; d669008f 03db24f7
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_mul_f32 v115, v115, v130 :: v_dual_mul_f32 v114, v114, v127 ; c8c70573 7372ff72
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 :: v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 ; c843138a 8a871187 3f650000
	v_maxmin_num_f32 v153, -4.0, v148, 4.0                      ; d6690099 03db28f7
	v_dual_mul_f32 v117, v117, v134 :: v_dual_mul_f32 v116, v116, v131 ; c8c70d75 75750774
	v_maxmin_num_f32 v155, -4.0, v149, 4.0                      ; d669009b 03db2af7
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 :: v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 ; c8431b8e 8e8b198b 3f650000
	v_maxmin_num_f32 v157, -4.0, v150, 4.0                      ; d669009d 03db2cf7
	v_dual_mul_f32 v119, v119, v138 :: v_dual_mul_f32 v118, v118, v135 ; c8c71577 77770f76
	v_maxmin_num_f32 v159, -4.0, v151, 4.0                      ; d669009f 03db2ef7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_mul_f32 v145, v145, v142 :: v_dual_mul_f32 v144, v144, v139 ; c8c71d91 91911790
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v176, 4.0                      ; d66900a1 03db60f7
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v177, 4.0                      ; d66900a3 03db62f7
	v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 ; c8433599 999d379c 3f650000
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v145, -4.0, v147, 4.0                      ; d6690091 03db26f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v178, 4.0                      ; d66900a5 03db64f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v179, 4.0                      ; d66900a7 03db66f7
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c8433fa0 a09d3d9d 3f650000
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_dual_mul_f32 v149, v149, v156 :: v_dual_mul_f32 v148, v148, v153 ; c8c73995 95953394
	v_fma_mix_f32 v152, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff22ff 3728ab28
	v_maxmin_num_f32 v169, -4.0, v180, 4.0                      ; d66900a9 03db68f7
	v_maxmin_num_f32 v171, -4.0, v181, 4.0                      ; d66900ab 03db6af7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_mul_f32 v151, v151, v160 :: v_dual_mul_f32 v150, v150, v157 ; c8c74197 97973b96
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c84347a4 a4a145a1 3f650000
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v173, -4.0, v182, 4.0                      ; d66900ad 03db6cf7
	v_dual_fmaak_f32 v143, v143, v144, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v145, 0x3f650000 ; c843218f 8f992398 3f650000
	v_maxmin_num_f32 v175, -4.0, v183, 4.0                      ; d66900af 03db6ef7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 ; c8434fa8 a8a54da5 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_dual_mul_f32 v177, v177, v164 :: v_dual_mul_f32 v176, v176, v161 ; c8c749b1 b1b143b0
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_mul_f32 v147, v147, v152 :: v_dual_mul_f32 v146, v146, v143 ; c8c73193 93931f92
	v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 ; c84357ac aca955a9 3f650000
	v_dual_mul_f32 v179, v179, v168 :: v_dual_mul_f32 v178, v178, v165 ; c8c751b3 b3b34bb2
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_maxmin_num_f32 v177, -4.0, v14, 4.0                       ; d66900b1 03da1cf7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_dual_mul_f32 v181, v181, v172 :: v_dual_mul_f32 v180, v180, v169 ; c8c759b5 b5b553b4
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_maxmin_num_f32 v179, -4.0, v15, 4.0                       ; d66900b3 03da1ef7
	v_maxmin_num_f32 v185, -4.0, v18, 4.0                       ; d66900b9 03da24f7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v187, -4.0, v19, 4.0                       ; d66900bb 03da26f7
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 ; c8435fb0 b0ad5dad 3f650000
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_maxmin_num_f32 v181, -4.0, v16, 4.0                       ; d66900b5 03da20f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v20, 4.0                       ; d66900bd 03da28f7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_dual_mul_f32 v183, v183, v176 :: v_dual_mul_f32 v182, v182, v173 ; c8c761b7 b7b75bb6
	v_maxmin_num_f32 v191, -4.0, v21, 4.0                       ; d66900bf 03da2af7
	v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 ; c84365b1 b1b567b4 3f650000
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 ; c84377bc bcb975b9 3f650000
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[26:27], 0 ; cc464050 1a02352e
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_maxmin_num_f32 v183, -4.0, v17, 4.0                       ; d66900b7 03da22f7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_dual_mul_f32 v15, v15, v180 :: v_dual_mul_f32 v14, v14, v177 ; c8c7690f 0f0f630e
	v_dual_mul_f32 v19, v19, v188 :: v_dual_mul_f32 v18, v18, v185 ; c8c77913 13137312
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[26:27], 0 ; cc464070 1a023530
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[26:27], 0 ; cc464090 1a023544
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[46:47], v[64:65], 0 ; cc464058 1a02812e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[64:65], 0 ; cc464078 1a028130
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[64:65], 0 ; cc464098 1a028144
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[44:45], 0 ; cc464060 1a02592e
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[22:23], 0 ; cc464068 1a022d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[48:49], v[44:45], 0 ; cc464080 1a025930
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[48:49], v[22:23], 0 ; cc464088 1a022d30
	v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 ; c8436db5 b5b96fb8 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[44:45], 0 ; cc4640a0 1a025944
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[22:23], 0 ; cc4640a8 1a022d44
	v_dual_mul_f32 v17, v17, v184 :: v_dual_mul_f32 v16, v16, v181 ; c8c77111 11116b10
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[26:27], 0 ; cc4640b0 1a023546
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_fma_mix_f32 v16, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206210 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v191, 0x3f650000 ; c8437dbd bd117f10 3f650000
	v_dual_mul_f32 v21, v21, v16 :: v_dual_mul_f32 v20, v20, v189 ; c8c62115 15157b14
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[64:65], 0 ; cc4640b8 1a028146
	v_dual_mov_b32 v64, v43 :: v_dual_mov_b32 v59, v42          ; ca10012b 403a012a
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mov_b32 v27, v15 :: v_dual_mov_b32 v26, v14          ; ca10010f 1b1a010e
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[44:45], 0 ; cc46400e 1a025946
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[22:23], 0 ; cc46402a 1a022d46
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:512 ; c405c07c 40804844 00020036
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[38:39], v[128:135] ; cc464080 1e024d46
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[60:61], v[136:143] ; cc464088 1e227946
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[60:61], v[104:111] ; cc464068 1da27944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[66:67], v[112:119] ; cc464070 1dc28546
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[36:37], v[120:127] ; cc464078 1de24946
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[36:37], v[88:95] ; cc464058 1d624944
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[66:67], v[80:87] ; cc464050 1d428544
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[38:39], v[96:103] ; cc464060 1d824d44
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:512 ; c405c07c 40804844 00020018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[36:37], v[184:191] ; cc4640b8 1ee24946
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[38:39], v[160:167] ; cc4640a0 1e824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[38:39], v[14:21] ; cc46400e 1c3a4d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[36:37], v[152:159] ; cc464098 1e624944
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[66:67], v[144:151] ; cc464090 1e428544
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[66:67], v[176:183] ; cc4640b0 1ec28546
	ds_load_b64 v[22:23], v64 offset:512                        ; d9d80200 16000040
	ds_load_b64 v[66:67], v64 offset:4608                       ; d9d81200 42000040
	ds_load_b64 v[36:37], v64 offset:8704                       ; d9d82200 24000040
	ds_load_b64 v[38:39], v64 offset:12800                      ; d9d83200 26000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[60:61], v[168:175] ; cc4640a8 1ea27944
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[60:61], v[42:49] ; cc46402a 1caa7946
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:1024 ; c405c07c 40804844 00040036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[38:39], v[104:111] ; cc464068 1da24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[22:23], v[112:119] ; cc464070 1dc22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[66:67], v[120:127] ; cc464078 1de28546
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[36:37], v[96:103] ; cc464060 1d824944
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[36:37], v[128:135] ; cc464080 1e024946
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[38:39], v[136:143] ; cc464088 1e224d46
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[22:23], v[80:87] ; cc464050 1d422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[66:67], v[88:95] ; cc464058 1d628544
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:1024 ; c405c07c 40804844 00040018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[66:67], v[184:191] ; cc4640b8 1ee28546
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[22:23], v[144:151] ; cc464090 1e422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[36:37], v[160:167] ; cc4640a0 1e824944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[36:37], v[14:21] ; cc46400e 1c3a4946
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[22:23], v[176:183] ; cc4640b0 1ec22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[66:67], v[152:159] ; cc464098 1e628544
	ds_load_b64 v[60:61], v64 offset:768                        ; d9d80300 3c000040
	ds_load_b64 v[22:23], v64 offset:4864                       ; d9d81300 16000040
	ds_load_b64 v[66:67], v64 offset:8960                       ; d9d82300 42000040
	ds_load_b64 v[36:37], v64 offset:13056                      ; d9d83300 24000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[38:39], v[168:175] ; cc4640a8 1ea24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[38:39], v[42:49] ; cc46402a 1caa4d46
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:1536 ; c405c07c 40804844 00060036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[36:37], v[104:111] ; cc464068 1da24944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[60:61], v[112:119] ; cc464070 1dc27946
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[22:23], v[120:127] ; cc464078 1de22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[66:67], v[128:135] ; cc464080 1e028546
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[36:37], v[136:143] ; cc464088 1e224946
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[60:61], v[80:87] ; cc464050 1d427944
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[22:23], v[88:95] ; cc464058 1d622d44
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[66:67], v[96:103] ; cc464060 1d828544
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:1536 ; c405c07c 40804844 00060018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[22:23], v[184:191] ; cc4640b8 1ee22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[66:67], v[160:167] ; cc4640a0 1e828544
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[60:61], v[144:151] ; cc464090 1e427944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[66:67], v[14:21] ; cc46400e 1c3a8546
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[60:61], v[176:183] ; cc4640b0 1ec27946
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[22:23], v[152:159] ; cc464098 1e622d44
	ds_load_b64 v[38:39], v64 offset:1024                       ; d9d80400 26000040
	ds_load_b64 v[60:61], v64 offset:5120                       ; d9d81400 3c000040
	ds_load_b64 v[22:23], v64 offset:9216                       ; d9d82400 16000040
	ds_load_b64 v[66:67], v64 offset:13312                      ; d9d83400 42000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[36:37], v[168:175] ; cc4640a8 1ea24944
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[36:37], v[42:49] ; cc46402a 1caa4946
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:2048 ; c405c07c 40804844 00080036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[66:67], v[104:111] ; cc464068 1da28544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[38:39], v[112:119] ; cc464070 1dc24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[60:61], v[120:127] ; cc464078 1de27946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[22:23], v[128:135] ; cc464080 1e022d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[66:67], v[136:143] ; cc464088 1e228546
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[22:23], v[96:103] ; cc464060 1d822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[38:39], v[80:87] ; cc464050 1d424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[60:61], v[88:95] ; cc464058 1d627944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:2048 ; c405c07c 40804844 00080018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[60:61], v[184:191] ; cc4640b8 1ee27946
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[22:23], v[160:167] ; cc4640a0 1e822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[22:23], v[14:21] ; cc46400e 1c3a2d46
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[38:39], v[144:151] ; cc464090 1e424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[38:39], v[176:183] ; cc4640b0 1ec24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[60:61], v[152:159] ; cc464098 1e627944
	ds_load_b64 v[36:37], v64 offset:1280                       ; d9d80500 24000040
	ds_load_b64 v[38:39], v64 offset:5376                       ; d9d81500 26000040
	ds_load_b64 v[60:61], v64 offset:9472                       ; d9d82500 3c000040
	ds_load_b64 v[22:23], v64 offset:13568                      ; d9d83500 16000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[66:67], v[168:175] ; cc4640a8 1ea28544
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[66:67], v[42:49] ; cc46402a 1caa8546
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:2560 ; c405c07c 40804844 000a0036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[22:23], v[104:111] ; cc464068 1da22d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[36:37], v[112:119] ; cc464070 1dc24946
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[38:39], v[120:127] ; cc464078 1de24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[60:61], v[128:135] ; cc464080 1e027946
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[22:23], v[136:143] ; cc464088 1e222d46
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[60:61], v[96:103] ; cc464060 1d827944
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[36:37], v[80:87] ; cc464050 1d424944
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[38:39], v[88:95] ; cc464058 1d624d44
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:2560 ; c405c07c 40804844 000a0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[38:39], v[184:191] ; cc4640b8 1ee24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[60:61], v[160:167] ; cc4640a0 1e827944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[60:61], v[14:21] ; cc46400e 1c3a7946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[36:37], v[144:151] ; cc464090 1e424944
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[36:37], v[176:183] ; cc4640b0 1ec24946
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[38:39], v[152:159] ; cc464098 1e624d44
	ds_load_b64 v[66:67], v64 offset:1536                       ; d9d80600 42000040
	ds_load_b64 v[36:37], v64 offset:5632                       ; d9d81600 24000040
	ds_load_b64 v[38:39], v64 offset:9728                       ; d9d82600 26000040
	ds_load_b64 v[60:61], v64 offset:13824                      ; d9d83600 3c000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[22:23], v[168:175] ; cc4640a8 1ea22d44
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[22:23], v[42:49] ; cc46402a 1caa2d46
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:3072 ; c405c07c 40804844 000c0036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[60:61], v[104:111] ; cc464068 1da27944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[66:67], v[112:119] ; cc464070 1dc28546
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[36:37], v[120:127] ; cc464078 1de24946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[38:39], v[128:135] ; cc464080 1e024d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[60:61], v[136:143] ; cc464088 1e227946
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[38:39], v[96:103] ; cc464060 1d824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[66:67], v[80:87] ; cc464050 1d428544
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[36:37], v[88:95] ; cc464058 1d624944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:3072 ; c405c07c 40804844 000c0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[36:37], v[184:191] ; cc4640b8 1ee24946
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[38:39], v[160:167] ; cc4640a0 1e824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[38:39], v[14:21] ; cc46400e 1c3a4d46
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[66:67], v[144:151] ; cc464090 1e428544
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[66:67], v[176:183] ; cc4640b0 1ec28546
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[36:37], v[152:159] ; cc464098 1e624944
	ds_load_b64 v[22:23], v64 offset:1792                       ; d9d80700 16000040
	ds_load_b64 v[66:67], v64 offset:5888                       ; d9d81700 42000040
	ds_load_b64 v[36:37], v64 offset:9984                       ; d9d82700 24000040
	ds_load_b64 v[38:39], v64 offset:14080                      ; d9d83700 26000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[60:61], v[168:175] ; cc4640a8 1ea27944
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[60:61], v[42:49] ; cc46402a 1caa7946
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:3584 ; c405c07c 40804844 000e0036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[38:39], v[104:111] ; cc464068 1da24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[22:23], v[112:119] ; cc464070 1dc22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[66:67], v[120:127] ; cc464078 1de28546
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[36:37], v[128:135] ; cc464080 1e024946
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[38:39], v[136:143] ; cc464088 1e224d46
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[36:37], v[96:103] ; cc464060 1d824944
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[22:23], v[80:87] ; cc464050 1d422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[66:67], v[88:95] ; cc464058 1d628544
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:3584 ; c405c07c 40804844 000e0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[66:67], v[184:191] ; cc4640b8 1ee28546
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[36:37], v[160:167] ; cc4640a0 1e824944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[36:37], v[14:21] ; cc46400e 1c3a4946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[22:23], v[144:151] ; cc464090 1e422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[22:23], v[176:183] ; cc4640b0 1ec22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[66:67], v[152:159] ; cc464098 1e628544
	ds_load_b64 v[60:61], v64 offset:2048                       ; d9d80800 3c000040
	ds_load_b64 v[22:23], v64 offset:6144                       ; d9d81800 16000040
	ds_load_b64 v[66:67], v64 offset:10240                      ; d9d82800 42000040
	ds_load_b64 v[36:37], v64 offset:14336                      ; d9d83800 24000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[38:39], v[168:175] ; cc4640a8 1ea24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[38:39], v[42:49] ; cc46402a 1caa4d46
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:4096 ; c405c07c 40804844 00100036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[36:37], v[104:111] ; cc464068 1da24944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[60:61], v[112:119] ; cc464070 1dc27946
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[22:23], v[120:127] ; cc464078 1de22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[66:67], v[128:135] ; cc464080 1e028546
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[36:37], v[136:143] ; cc464088 1e224946
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[66:67], v[96:103] ; cc464060 1d828544
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[60:61], v[80:87] ; cc464050 1d427944
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[22:23], v[88:95] ; cc464058 1d622d44
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:4096 ; c405c07c 40804844 00100018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[22:23], v[184:191] ; cc4640b8 1ee22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[66:67], v[160:167] ; cc4640a0 1e828544
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[66:67], v[14:21] ; cc46400e 1c3a8546
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[60:61], v[144:151] ; cc464090 1e427944
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[60:61], v[176:183] ; cc4640b0 1ec27946
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[22:23], v[152:159] ; cc464098 1e622d44
	ds_load_b64 v[38:39], v64 offset:2304                       ; d9d80900 26000040
	ds_load_b64 v[60:61], v64 offset:6400                       ; d9d81900 3c000040
	ds_load_b64 v[22:23], v64 offset:10496                      ; d9d82900 16000040
	ds_load_b64 v[66:67], v64 offset:14592                      ; d9d83900 42000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[36:37], v[168:175] ; cc4640a8 1ea24944
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[36:37], v[42:49] ; cc46402a 1caa4946
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:4608 ; c405c07c 40804844 00120036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[66:67], v[104:111] ; cc464068 1da28544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[38:39], v[112:119] ; cc464070 1dc24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[60:61], v[120:127] ; cc464078 1de27946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[22:23], v[128:135] ; cc464080 1e022d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[66:67], v[136:143] ; cc464088 1e228546
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[22:23], v[96:103] ; cc464060 1d822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[38:39], v[80:87] ; cc464050 1d424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[60:61], v[88:95] ; cc464058 1d627944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:4608 ; c405c07c 40804844 00120018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[60:61], v[184:191] ; cc4640b8 1ee27946
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[22:23], v[160:167] ; cc4640a0 1e822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[22:23], v[14:21] ; cc46400e 1c3a2d46
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[38:39], v[144:151] ; cc464090 1e424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[38:39], v[176:183] ; cc4640b0 1ec24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[60:61], v[152:159] ; cc464098 1e627944
	ds_load_b64 v[36:37], v64 offset:2560                       ; d9d80a00 24000040
	ds_load_b64 v[38:39], v64 offset:6656                       ; d9d81a00 26000040
	ds_load_b64 v[60:61], v64 offset:10752                      ; d9d82a00 3c000040
	ds_load_b64 v[22:23], v64 offset:14848                      ; d9d83a00 16000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[66:67], v[168:175] ; cc4640a8 1ea28544
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[66:67], v[42:49] ; cc46402a 1caa8546
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:5120 ; c405c07c 40804844 00140036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[22:23], v[104:111] ; cc464068 1da22d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[36:37], v[112:119] ; cc464070 1dc24946
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[38:39], v[120:127] ; cc464078 1de24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[60:61], v[128:135] ; cc464080 1e027946
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[22:23], v[136:143] ; cc464088 1e222d46
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[60:61], v[96:103] ; cc464060 1d827944
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[36:37], v[80:87] ; cc464050 1d424944
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[38:39], v[88:95] ; cc464058 1d624d44
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:5120 ; c405c07c 40804844 00140018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[38:39], v[184:191] ; cc4640b8 1ee24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[60:61], v[160:167] ; cc4640a0 1e827944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[60:61], v[14:21] ; cc46400e 1c3a7946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[36:37], v[144:151] ; cc464090 1e424944
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[36:37], v[176:183] ; cc4640b0 1ec24946
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[38:39], v[152:159] ; cc464098 1e624d44
	ds_load_b64 v[66:67], v64 offset:2816                       ; d9d80b00 42000040
	ds_load_b64 v[36:37], v64 offset:6912                       ; d9d81b00 24000040
	ds_load_b64 v[38:39], v64 offset:11008                      ; d9d82b00 26000040
	ds_load_b64 v[60:61], v64 offset:15104                      ; d9d83b00 3c000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[22:23], v[168:175] ; cc4640a8 1ea22d44
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[22:23], v[42:49] ; cc46402a 1caa2d46
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:5632 ; c405c07c 40804844 00160036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[60:61], v[104:111] ; cc464068 1da27944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[66:67], v[112:119] ; cc464070 1dc28546
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[36:37], v[120:127] ; cc464078 1de24946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[38:39], v[128:135] ; cc464080 1e024d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[60:61], v[136:143] ; cc464088 1e227946
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[38:39], v[96:103] ; cc464060 1d824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[66:67], v[80:87] ; cc464050 1d428544
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[36:37], v[88:95] ; cc464058 1d624944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:5632 ; c405c07c 40804844 00160018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[36:37], v[184:191] ; cc4640b8 1ee24946
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[38:39], v[160:167] ; cc4640a0 1e824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[38:39], v[14:21] ; cc46400e 1c3a4d46
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[66:67], v[144:151] ; cc464090 1e428544
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[66:67], v[176:183] ; cc4640b0 1ec28546
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[36:37], v[152:159] ; cc464098 1e624944
	ds_load_b64 v[22:23], v64 offset:3072                       ; d9d80c00 16000040
	ds_load_b64 v[66:67], v64 offset:7168                       ; d9d81c00 42000040
	ds_load_b64 v[36:37], v64 offset:11264                      ; d9d82c00 24000040
	ds_load_b64 v[38:39], v64 offset:15360                      ; d9d83c00 26000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[60:61], v[168:175] ; cc4640a8 1ea27944
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[60:61], v[42:49] ; cc46402a 1caa7946
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:6144 ; c405c07c 40804844 00180036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[38:39], v[104:111] ; cc464068 1da24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[22:23], v[112:119] ; cc464070 1dc22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[66:67], v[120:127] ; cc464078 1de28546
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[36:37], v[128:135] ; cc464080 1e024946
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[38:39], v[136:143] ; cc464088 1e224d46
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[36:37], v[96:103] ; cc464060 1d824944
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[22:23], v[80:87] ; cc464050 1d422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[66:67], v[88:95] ; cc464058 1d628544
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:6144 ; c405c07c 40804844 00180018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[66:67], v[184:191] ; cc4640b8 1ee28546
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[36:37], v[160:167] ; cc4640a0 1e824944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[36:37], v[14:21] ; cc46400e 1c3a4946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[22:23], v[144:151] ; cc464090 1e422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[22:23], v[176:183] ; cc4640b0 1ec22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[66:67], v[152:159] ; cc464098 1e628544
	ds_load_b64 v[60:61], v64 offset:3328                       ; d9d80d00 3c000040
	ds_load_b64 v[22:23], v64 offset:7424                       ; d9d81d00 16000040
	ds_load_b64 v[66:67], v64 offset:11520                      ; d9d82d00 42000040
	ds_load_b64 v[36:37], v64 offset:15616                      ; d9d83d00 24000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[38:39], v[168:175] ; cc4640a8 1ea24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[38:39], v[42:49] ; cc46402a 1caa4d46
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:6656 ; c405c07c 40804844 001a0036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[36:37], v[104:111] ; cc464068 1da24944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[60:61], v[112:119] ; cc464070 1dc27946
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[22:23], v[120:127] ; cc464078 1de22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[66:67], v[128:135] ; cc464080 1e028546
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[36:37], v[136:143] ; cc464088 1e224946
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[66:67], v[96:103] ; cc464060 1d828544
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[60:61], v[80:87] ; cc464050 1d427944
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[22:23], v[88:95] ; cc464058 1d622d44
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:6656 ; c405c07c 40804844 001a0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[22:23], v[184:191] ; cc4640b8 1ee22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[66:67], v[160:167] ; cc4640a0 1e828544
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[66:67], v[14:21] ; cc46400e 1c3a8546
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[60:61], v[144:151] ; cc464090 1e427944
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[60:61], v[176:183] ; cc4640b0 1ec27946
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[22:23], v[152:159] ; cc464098 1e622d44
	ds_load_b64 v[38:39], v64 offset:3584                       ; d9d80e00 26000040
	ds_load_b64 v[60:61], v64 offset:7680                       ; d9d81e00 3c000040
	ds_load_b64 v[22:23], v64 offset:11776                      ; d9d82e00 16000040
	ds_load_b64 v[66:67], v64 offset:15872                      ; d9d83e00 42000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[36:37], v[168:175] ; cc4640a8 1ea24944
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[36:37], v[42:49] ; cc46402a 1caa4946
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:7168 ; c405c07c 40804844 001c0036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[66:67], v[104:111] ; cc464068 1da28544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[38:39], v[112:119] ; cc464070 1dc24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[60:61], v[120:127] ; cc464078 1de27946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[22:23], v[128:135] ; cc464080 1e022d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[66:67], v[136:143] ; cc464088 1e228546
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[22:23], v[96:103] ; cc464060 1d822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[38:39], v[80:87] ; cc464050 1d424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[60:61], v[88:95] ; cc464058 1d627944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:7168 ; c405c07c 40804844 001c0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[60:61], v[184:191] ; cc4640b8 1ee27946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[38:39], v[144:151] ; cc464090 1e424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[38:39], v[176:183] ; cc4640b0 1ec24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[60:61], v[152:159] ; cc464098 1e627944
	ds_load_b64 v[36:37], v64 offset:3840                       ; d9d80f00 24000040
	ds_load_b64 v[38:39], v64 offset:7936                       ; d9d81f00 26000040
	ds_load_b64 v[60:61], v64 offset:12032                      ; d9d82f00 3c000040
	ds_load_b64 v[64:65], v64 offset:16128                      ; d9d83f00 40000040
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[22:23], v[160:167] ; cc4640a0 1e822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[66:67], v[168:175] ; cc4640a8 1ea28544
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[22:23], v[14:21] ; cc46400e 1c3a2d46
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[66:67], v[42:49] ; cc46402a 1caa8546
	v_mov_b32_e32 v66, v25                                      ; 7e840319
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:7680 ; c405c07c 40804844 001e0036
	buffer_load_b128 v[22:25], v24, s[36:39], null offen offset:7680 ; c405c07c 40804816 001e0018
	s_lshr_b32 s11, s11, 2                                      ; 850b820b
	s_wait_loadcnt_dscnt 0x102                                  ; bfc80102
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[38:39], v[88:95] ; cc464058 1d624d44
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[64:65], v[136:143] ; cc464088 1e228146
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[38:39], v[120:127] ; cc464078 1de24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[60:61], v[96:103] ; cc464060 1d827944
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[64:65], v[104:111] ; cc464068 1da28144
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[60:61], v[128:135] ; cc464080 1e027946
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[36:37], v[112:119] ; cc464070 1dc24946
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[36:37], v[80:87] ; cc464050 1d424944
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_maxmin_num_f32 v67, -4.0, v80, 4.0                        ; d6690043 03daa0f7
	v_maxmin_num_f32 v69, -4.0, v81, 4.0                        ; d6690045 03daa2f7
	v_maxmin_num_f32 v71, -4.0, v82, 4.0                        ; d6690047 03daa4f7
	v_fma_mix_f32 v68, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206244 0bfe86ff 3728ab28
	v_fma_mix_f32 v70, 0xab28, |v69|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe8aff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v70, v70, v69, 0x3f650000 :: v_dual_fmaak_f32 v67, v67, v68, 0x3f650000 ; c8428b46 46428943 3f650000
	v_dual_mul_f32 v81, v81, v70 :: v_dual_mul_f32 v80, v80, v67 ; c8c68d51 51508750
	v_maxmin_num_f32 v67, -4.0, v84, 4.0                        ; d6690043 03daa8f7
	v_maxmin_num_f32 v70, -4.0, v85, 4.0                        ; d6690046 03daaaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v81, -4.0, v83, 4.0                        ; d6690051 03daa6f7
	v_fma_mix_f32 v80, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe8eff 3728ab28
	v_fma_mix_f32 v69, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe86ff 3728ab28
	v_fma_mix_f32 v54, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206236 0bfea2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmaak_f32 v54, v54, v81, 0x3f650000 :: v_dual_fmaak_f32 v71, v71, v80, 0x3f650000 ; c842a336 3646a147 3f650000
	v_maxmin_num_f32 v80, -4.0, v86, 4.0                        ; d6690050 03daacf7
	v_mul_f32_e32 v83, v83, v54                                 ; 10a66d53
	v_dual_fmaak_f32 v67, v67, v69, 0x3f650000 :: v_dual_mul_f32 v82, v82, v71 ; c8468b43 43528f52 3f650000
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v82, -4.0, v87, 4.0                        ; d6690052 03daaef7
	v_fmaak_f32 v71, v71, v70, 0x3f650000                       ; 5a8e8d47 3f650000
	v_maxmin_num_f32 v54, -4.0, v91, 4.0                        ; d6690036 03dab6f7
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_dual_mul_f32 v85, v71, v85 :: v_dual_mul_f32 v84, v84, v67 ; c8c6ab47 55548754
	v_fma_mix_f32 v67, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206243 0bfe6cff 3728ab28
	v_maxmin_num_f32 v71, -4.0, v92, 4.0                        ; d6690047 03dab8f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c842a553 5350a350 3f650000
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v84, -4.0, v88, 4.0                        ; d6690054 03dab0f7
	v_maxmin_num_f32 v81, -4.0, v93, 4.0                        ; d6690051 03dabaf7
	v_dual_mul_f32 v87, v87, v83 :: v_dual_mul_f32 v86, v86, v80 ; c8c6a757 5756a156
	v_fma_mix_f32 v80, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe8eff 3728ab28
	v_maxmin_num_f32 v83, -4.0, v94, 4.0                        ; d6690053 03dabcf7
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v86, -4.0, v89, 4.0                        ; d6690056 03dab2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v71, v71, v80, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 ; c842a147 4752a352 3f650000
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v93, v93, v82 :: v_dual_mul_f32 v92, v92, v71 ; c8c6a55d 5d5c8f5c
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c842ad57 5754ab54 3f650000
	v_maxmin_num_f32 v85, -4.0, v95, 4.0                        ; d6690055 03dabef7
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v89, v89, v87 :: v_dual_mul_f32 v88, v88, v84 ; c8c6af59 5958a958
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v96, 4.0                        ; d6690057 03dac0f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v90, 4.0                        ; d6690058 03dab4f7
	v_maxmin_num_f32 v93, -4.0, v99, 4.0                        ; d669005d 03dac6f7
	v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842a953 5356ab56 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_dual_mul_f32 v95, v95, v86 :: v_dual_mul_f32 v94, v94, v83 ; c8c6ad5f 5f5ea75e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmaak_f32 v67, v67, v54, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c8426d43 4358b358 3f650000
	v_maxmin_num_f32 v89, -4.0, v97, 4.0                        ; d6690059 03dac2f7
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v100, 4.0                       ; d669005f 03dac8f7
	v_dual_mul_f32 v91, v91, v67 :: v_dual_mul_f32 v90, v90, v88 ; c8c6875b 5b5ab15a
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v98, 4.0                        ; d669005b 03dac4f7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 :: v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 ; c842b35a 5a56b157 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842b95b 5b5ebb5e 3f650000
	v_dual_mul_f32 v97, v97, v90 :: v_dual_mul_f32 v96, v96, v87 ; c8c6b561 6160af60
	v_maxmin_num_f32 v67, -4.0, v104, 4.0                       ; d6690043 03dad0f7
	v_dual_mul_f32 v99, v99, v94 :: v_dual_mul_f32 v98, v98, v91 ; c8c6bd63 6362b762
	v_maxmin_num_f32 v83, -4.0, v105, 4.0                       ; d6690053 03dad2f7
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v101, 4.0                       ; d6690061 03dacaf7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_fma_mix_f32 v82, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfe86ff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v106, 4.0                       ; d6690055 03dad4f7
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v102, 4.0                       ; d6690063 03daccf7
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v107, 4.0                       ; d6690057 03dad6f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v108, 4.0                       ; d6690059 03dad8f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v109, 4.0                       ; d669005b 03dadaf7
	v_dual_fmaak_f32 v67, v67, v82, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 ; c842a543 4354a754 3f650000
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c842c362 625ec15f 3f650000
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v110, 4.0                       ; d669005d 03dadcf7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_mul_f32 v105, v105, v84 :: v_dual_mul_f32 v104, v104, v67 ; c8c6a969 69688768
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af58 5854ad55 3f650000
	v_dual_mul_f32 v101, v101, v98 :: v_dual_mul_f32 v100, v100, v95 ; c8c6c565 6564bf64
	v_maxmin_num_f32 v95, -4.0, v111, 4.0                       ; d669005f 03dadef7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v112, 4.0                       ; d6690061 03dae0f7
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c842b75c 5c58b559 3f650000
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_mul_f32 v107, v107, v88 :: v_dual_mul_f32 v106, v106, v85 ; c8c6b16b 6b6aab6a
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v101, -4.0, v103, 4.0                      ; d6690065 03dacef7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_mul_f32 v109, v109, v92 :: v_dual_mul_f32 v108, v108, v89 ; c8c6b96d 6d6cb36c
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_fma_mix_f32 v54, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206236 0bfecaff 3728ab28
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v105, -4.0, v116, 4.0                      ; d6690069 03dae8f7
	v_dual_fmaak_f32 v54, v54, v101, 0x3f650000 :: v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 ; c842cb36 3662c963 3f650000
	v_maxmin_num_f32 v101, -4.0, v114, 4.0                      ; d6690065 03dae4f7
	v_maxmin_num_f32 v107, -4.0, v117, 4.0                      ; d669006b 03daeaf7
	v_dual_mul_f32 v111, v111, v96 :: v_dual_mul_f32 v110, v110, v93 ; c8c6c16f 6f6ebb6e
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_mul_f32 v103, v103, v54 :: v_dual_mul_f32 v102, v102, v99 ; c8c66d67 6766c766
	v_maxmin_num_f32 v99, -4.0, v113, 4.0                       ; d6690063 03dae2f7
	v_maxmin_num_f32 v109, -4.0, v118, 4.0                      ; d669006d 03daecf7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v111, -4.0, v119, 4.0                      ; d669006f 03daeef7
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v103, -4.0, v115, 4.0                      ; d6690067 03dae6f7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[22:23], v[36:37], v[144:151] ; cc464090 1e424916
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 :: v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 ; c842d76c 6c68d569 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[22:23], v[38:39], v[152:159] ; cc464098 1e624d16
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[22:23], v[60:61], v[160:167] ; cc4640a0 1e827916
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 :: v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 ; c842c764 6460c561 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[64:65], v[168:175] ; cc4640a8 1ea28116
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[24:25], v[36:37], v[176:183] ; cc4640b0 1ec24918
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[24:25], v[38:39], v[184:191] ; cc4640b8 1ee24d18
	v_dual_mul_f32 v117, v117, v108 :: v_dual_mul_f32 v116, v116, v105 ; c8c6d975 7574d374
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[24:25], v[60:61], v[14:21] ; cc46400e 1c3a7918
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[24:25], v[64:65], v[42:49] ; cc46402a 1caa8118
	v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 :: v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 ; c842cf68 6864cd65 3f650000
	v_dual_mul_f32 v113, v113, v100 :: v_dual_mul_f32 v112, v112, v97 ; c8c6c971 7170c370
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v117, -4.0, v122, 4.0                      ; d6690075 03daf4f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_mul_f32 v115, v115, v104 :: v_dual_mul_f32 v114, v114, v101 ; c8c6d173 7372cb72
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_maxmin_num_f32 v113, -4.0, v120, 4.0                      ; d6690071 03daf0f7
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v115, -4.0, v121, 4.0                      ; d6690073 03daf2f7
	v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 :: v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 ; c842df70 706cdd6d 3f650000
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_dual_mul_f32 v119, v119, v112 :: v_dual_mul_f32 v118, v118, v109 ; c8c6e177 7776db76
	v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 ; c842e571 7174e774 3f650000
	v_maxmin_num_f32 v24, -4.0, v126, 4.0                       ; d6690018 03dafcf7
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v119, -4.0, v123, 4.0                      ; d6690077 03daf6f7
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_maxmin_num_f32 v36, -4.0, v127, 4.0                       ; d6690024 03dafef7
	v_dual_mul_f32 v121, v121, v116 :: v_dual_mul_f32 v120, v120, v113 ; c8c6e979 7978e378
	v_maxmin_num_f32 v38, -4.0, v128, 4.0                       ; d6690026 03db00f7
	v_fma_mix_f32 v25, 0xab28, |v24|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe30ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v37, 0xab28, |v36|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfe48ff 3728ab28
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v121, -4.0, v124, 4.0                      ; d6690079 03daf8f7
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_maxmin_num_f32 v61, -4.0, v130, 4.0                       ; d669003d 03db04f7
	v_fma_mix_f32 v39, 0xab28, |v38|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206227 0bfe4cff 3728ab28
	v_maxmin_num_f32 v54, -4.0, v129, 4.0                       ; d6690036 03db02f7
	v_maxmin_num_f32 v65, -4.0, v131, 4.0                       ; d6690041 03db06f7
	v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842ef78 7874ed75 3f650000
	v_fma_mix_f32 v64, 0xab28, |v61|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206240 0bfe7aff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
	v_fma_mix_f32 v60, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623c 0bfe6cff 3728ab28
	v_fma_mix_f32 v67, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206243 0bfe82ff 3728ab28
	v_maxmin_num_f32 v86, -4.0, v132, 4.0                       ; d6690056 03db08f7
	v_dual_mul_f32 v123, v123, v120 :: v_dual_mul_f32 v122, v122, v117 ; c8c6f17b 7b7aeb7a
	v_dual_fmaak_f32 v67, v67, v65, 0x3f650000 :: v_dual_fmaak_f32 v60, v60, v54, 0x3f650000 ; c8428343 433c6d3c 3f650000
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v133, 4.0                       ; d6690058 03db0af7
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v123, -4.0, v125, 4.0                      ; d669007b 03dafaf7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v90, -4.0, v134, 4.0                       ; d669005a 03db0cf7
	v_dual_fmaak_f32 v86, v86, v87, 0x3f650000 :: v_dual_mul_f32 v129, v129, v60 ; c846af56 56807981 3f650000
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v135, 4.0                       ; d669005c 03db0ef7
	v_fma_mix_f32 v23, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206217 0bfef6ff 3728ab28
	v_fmaak_f32 v121, v121, v122, 0x3f650000                    ; 5af2f579 3f650000
	v_maxmin_num_f32 v94, -4.0, v136, 4.0                       ; d669005e 03db10f7
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_mul_f32 v132, v132, v86 ; c846b159 5984ad84 3f650000
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v96, -4.0, v137, 4.0                       ; d6690060 03db12f7
	v_dual_fmaak_f32 v23, v23, v123, 0x3f650000 :: v_dual_mul_f32 v124, v124, v121 ; c846f717 177cf37c 3f650000
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_maxmin_num_f32 v98, -4.0, v138, 4.0                       ; d6690062 03db14f7
	v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 :: v_dual_mul_f32 v133, v133, v89 ; c846b75a 5a84b385 3f650000
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_maxmin_num_f32 v100, -4.0, v139, 4.0                      ; d6690064 03db16f7
	v_dual_mul_f32 v125, v125, v23 :: v_dual_fmaak_f32 v24, v24, v25, 0x3f650000 ; c8c22f7d 7d183318 3f650000
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_mul_f32 v134, v134, v90 ; c846b95d 5d86b586 3f650000
	v_maxmin_num_f32 v102, -4.0, v140, 4.0                      ; d6690066 03db18f7
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_maxmin_num_f32 v104, -4.0, v141, 4.0                      ; d6690068 03db1af7
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_fmaak_f32 v37, v36, v37, 0x3f650000 :: v_dual_mul_f32 v126, v126, v24 ; c8464b24 257e317e 3f650000
	v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 :: v_dual_mul_f32 v135, v135, v93 ; c846bf5e 5e86bb87 3f650000
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_maxmin_num_f32 v106, -4.0, v142, 4.0                      ; d669006a 03db1cf7
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_maxmin_num_f32 v108, -4.0, v143, 4.0                      ; d669006c 03db1ef7
	v_dual_fmaak_f32 v38, v38, v39, 0x3f650000 :: v_dual_mul_f32 v127, v127, v37 ; c8464f26 267e4b7f 3f650000
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 :: v_dual_mul_f32 v136, v136, v94 ; c846c161 6188bd88 3f650000
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v144, 4.0                      ; d669006e 03db20f7
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v145, 4.0                      ; d6690070 03db22f7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_fmaak_f32 v61, v61, v64, 0x3f650000 :: v_dual_mul_f32 v128, v128, v38 ; c846813d 3d804d80 3f650000
	v_dual_fmaak_f32 v98, v98, v99, 0x3f650000 :: v_dual_mul_f32 v137, v137, v97 ; c846c762 6288c389 3f650000
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_maxmin_num_f32 v114, -4.0, v146, 4.0                      ; d6690072 03db24f7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v116, -4.0, v147, 4.0                      ; d6690074 03db26f7
	v_dual_mul_f32 v131, v131, v67 :: v_dual_mul_f32 v130, v130, v61 ; c8c68783 83827b82
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_fmaak_f32 v101, v101, v100, 0x3f650000 :: v_dual_mul_f32 v138, v138, v98 ; c846c965 658ac58a 3f650000
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v118, -4.0, v148, 4.0                      ; d6690076 03db28f7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v120, -4.0, v149, 4.0                      ; d6690078 03db2af7
	v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 :: v_dual_mul_f32 v139, v139, v101 ; c846cf66 668acb8b 3f650000
	v_maxmin_num_f32 v122, -4.0, v150, 4.0                      ; d669007a 03db2cf7
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_maxmin_num_f32 v124, -4.0, v151, 4.0                      ; d669007c 03db2ef7
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_fmaak_f32 v105, v105, v104, 0x3f650000 :: v_dual_mul_f32 v140, v140, v102 ; c846d169 698ccd8c 3f650000
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_maxmin_num_f32 v126, -4.0, v152, 4.0                      ; d669007e 03db30f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_dual_fmaak_f32 v106, v106, v107, 0x3f650000 :: v_dual_mul_f32 v141, v141, v105 ; c846d76a 6a8cd38d 3f650000
	v_maxmin_num_f32 v128, -4.0, v153, 4.0                      ; d6690080 03db32f7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_mul_f32 v142, v142, v106 ; c846d96d 6d8ed58e 3f650000
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v154, 4.0                      ; d6690082 03db34f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 :: v_dual_mul_f32 v143, v143, v109 ; c846df6e 6e8edb8f 3f650000
	v_maxmin_num_f32 v132, -4.0, v155, 4.0                      ; d6690084 03db36f7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_mul_f32 v144, v144, v110 ; c846e171 7190dd90 3f650000
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v134, -4.0, v156, 4.0                      ; d6690086 03db38f7
	v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 :: v_dual_mul_f32 v145, v145, v113 ; c846e772 7290e391 3f650000
	v_maxmin_num_f32 v136, -4.0, v157, 4.0                      ; d6690088 03db3af7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v117, v117, v116, 0x3f650000 :: v_dual_mul_f32 v146, v146, v114 ; c846e975 7592e592 3f650000
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v138, -4.0, v158, 4.0                      ; d669008a 03db3cf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 :: v_dual_mul_f32 v147, v147, v117 ; c846ef76 7692eb93 3f650000
	v_maxmin_num_f32 v140, -4.0, v159, 4.0                      ; d669008c 03db3ef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_mul_f32 v148, v148, v118 ; c846f179 7994ed94 3f650000
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v160, 4.0                      ; d669008e 03db40f7
	v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 :: v_dual_mul_f32 v149, v149, v121 ; c846f77a 7a94f395 3f650000
	v_maxmin_num_f32 v144, -4.0, v161, 4.0                      ; d6690090 03db42f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 :: v_dual_mul_f32 v150, v150, v122 ; c846f97d 7d96f596 3f650000
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v162, 4.0                      ; d6690092 03db44f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v126, v126, v127, 0x3f650000 :: v_dual_mul_f32 v151, v151, v125 ; c846ff7e 7e96fb97 3f650000
	v_maxmin_num_f32 v148, -4.0, v163, 4.0                      ; d6690094 03db46f7
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_mul_f32 v152, v152, v126 ; c8470181 8198fd98 3f650000
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v164, 4.0                      ; d6690096 03db48f7
	v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 :: v_dual_mul_f32 v153, v153, v129 ; c8470782 82990399 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v152, -4.0, v165, 4.0                      ; d6690098 03db4af7
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_mul_f32 v154, v154, v130 ; c8470985 859b059a 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 :: v_dual_mul_f32 v155, v155, v133 ; c8470f86 869b0b9b 3f650000
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v154, -4.0, v166, 4.0                      ; d669009a 03db4cf7
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_mul_f32 v156, v156, v134 ; c8471189 899d0d9c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_mul_f32 v157, v157, v137 ; c847178a 8a9d139d 3f650000
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_lshl_add_u32 v156, v1, 10, s11                            ; d646009c 002d1501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
	v_add_lshl_u32 v156, v156, v66, 2                           ; d647009c 020a859c
	buffer_load_b128 v[88:91], v156, s[36:39], null offen       ; c405c07c 40804858 0000009c
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_mul_f32 v158, v158, v138 ; c847198d 8d9f159e 3f650000
	v_maxmin_num_f32 v157, -4.0, v167, 4.0                      ; d669009d 03db4ef7
	v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 :: v_dual_mul_f32 v159, v159, v141 ; c8471f8e 8e9f1b9f 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_maxmin_num_f32 v159, -4.0, v168, 4.0                      ; d669009f 03db50f7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	buffer_load_b128 v[92:95], v156, s[36:39], null offen offset:512 ; c405c07c 4080485c 0002009c
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v160, v160, v142 ; c8472191 91a11da0 3f650000
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_mul_f32 v161, v161, v145 ; c8472792 92a123a1 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_maxmin_num_f32 v161, -4.0, v169, 4.0                      ; d66900a1 03db52f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v162, v162, v146 ; c8472995 95a325a2 3f650000
	v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 :: v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 ; c8433b9e 9e9f419f 3f650000
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_mul_f32 v163, v163, v149 ; c8472f96 96a32ba3 3f650000
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v168, v168, v159 :: v_dual_mul_f32 v167, v167, v158 ; c8c73fa8 a8a73da7
	buffer_load_b128 v[96:99], v156, s[36:39], null offen offset:1024 ; c405c07c 40804860 0004009c
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_maxmin_num_f32 v163, -4.0, v170, 4.0                      ; d66900a3 03db54f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v164, v164, v150 ; c8473199 99a52da4 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_mul_f32 v165, v165, v153 ; c847379a 9aa533a5 3f650000
	v_mul_f32_e32 v166, v166, v154                              ; 114d35a6
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_maxmin_num_f32 v165, -4.0, v171, 4.0                      ; d66900a5 03db56f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	buffer_load_b128 v[100:103], v156, s[36:39], null offen offset:1536 ; c405c07c 40804864 0006009c
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_maxmin_num_f32 v167, -4.0, v172, 4.0                      ; d66900a7 03db58f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c84349a3 a3a343a2 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmaak_f32 v166, v166, v165, 0x3f650000                    ; 5b4d4ba6 3f650000
	v_dual_mul_f32 v170, v170, v163 :: v_dual_mul_f32 v169, v169, v162 ; c8c747aa aaa945a9
	v_mul_f32_e32 v171, v171, v166                              ; 11574dab
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	buffer_load_b128 v[104:107], v156, s[36:39], null offen offset:2048 ; c405c07c 40804868 0008009c
	v_maxmin_num_f32 v169, -4.0, v173, 4.0                      ; d66900a9 03db5af7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_maxmin_num_f32 v67, -4.0, v176, 4.0                       ; d6690043 03db60f7
	v_maxmin_num_f32 v109, -4.0, v177, 4.0                      ; d669006d 03db62f7
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_maxmin_num_f32 v171, -4.0, v174, 4.0                      ; d66900ab 03db5cf7
	v_maxmin_num_f32 v111, -4.0, v178, 4.0                      ; d669006f 03db64f7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_fma_mix_f32 v108, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfe86ff 3728ab28
	buffer_load_b128 v[116:119], v156, s[36:39], null offen offset:2560 ; c405c07c 40804874 000a009c
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_maxmin_num_f32 v113, -4.0, v179, 4.0                      ; d6690071 03db66f7
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 :: v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 ; c84353aa aaa751a7 3f650000
	v_maxmin_num_f32 v115, -4.0, v180, 4.0                      ; d6690073 03db68f7
	v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 :: v_dual_fmaak_f32 v67, v67, v108, 0x3f650000 ; c842db6e 6e42d943 3f650000
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_fmaak_f32 v111, v111, v112, 0x3f650000                    ; 5adee16f 3f650000
	v_dual_mul_f32 v173, v173, v170 :: v_dual_mul_f32 v172, v172, v167 ; c8c755ad adad4fac
	v_fma_mix_f32 v120, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfee6ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v115, v115, v120, 0x3f650000 :: v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 ; c842f173 7372e372 3f650000
	v_dual_mul_f32 v180, v180, v115 :: v_dual_mul_f32 v179, v179, v114 ; c8c6e7b4 b4b2e5b3
	buffer_load_b128 v[112:115], v156, s[36:39], null offen offset:3072 ; c405c07c 40804870 000c009c
	v_maxmin_num_f32 v121, -4.0, v181, 4.0                      ; d6690079 03db6af7
	v_dual_mul_f32 v177, v177, v110 :: v_dual_mul_f32 v176, v176, v67 ; c8c6ddb1 b1b087b0
	v_mul_f32_e32 v178, v178, v111                              ; 1164dfb2
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_maxmin_num_f32 v173, -4.0, v175, 4.0                      ; d66900ad 03db5ef7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v182, 4.0                      ; d669007b 03db6cf7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f97b 7b7af37a 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v182, v182, v123 :: v_dual_mul_f32 v181, v181, v122 ; c8c6f7b6 b6b4f5b5
	buffer_load_b128 v[120:123], v156, s[36:39], null offen offset:3584 ; c405c07c 40804878 000e009c
	v_maxmin_num_f32 v125, -4.0, v183, 4.0                      ; d669007d 03db6ef7
	v_maxmin_num_f32 v127, -4.0, v184, 4.0                      ; d669007f 03db70f7
(invalid instruction)                                        ; d769006c
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d769406c
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_fma_mix_f32 v54, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206236 0bff5aff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v185, 4.0                      ; d6690081 03db72f7
	v_maxmin_num_f32 v131, -4.0, v186, 4.0                      ; d6690083 03db74f7
(invalid instruction)                                        ; d769006d
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_maxmin_num_f32 v133, -4.0, v187, 4.0                      ; d6690085 03db76f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v188, 4.0                      ; d6690087 03db78f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_dual_fmaak_f32 v54, v54, v173, 0x3f650000 :: v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 ; c8435b36 36ab59ab 3f650000
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v137, -4.0, v189, 4.0                      ; d6690089 03db7af7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v190, 4.0                      ; d669008b 03db7cf7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c843017f 7f7efb7e 3f650000
	v_dual_mul_f32 v175, v175, v54 :: v_dual_mul_f32 v174, v174, v171 ; c8c66daf afaf57ae
	v_maxmin_num_f32 v141, -4.0, v191, 4.0                      ; d669008d 03db7ef7
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 ; c8430382 82830983 3f650000
	v_maxmin_num_f32 v143, -4.0, v14, 4.0                       ; d669008f 03da1cf7
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 :: v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 ; c8430b86 86871187 3f650000
	v_mul_f32_e32 v184, v184, v127                              ; 1170ffb8
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_maxmin_num_f32 v145, -4.0, v15, 4.0                       ; d6690091 03da1ef7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_maxmin_num_f32 v147, -4.0, v16, 4.0                       ; d6690093 03da20f7
	v_dual_mul_f32 v186, v186, v131 :: v_dual_mul_f32 v183, v183, v126 ; c8c707ba bab6fdb7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 :: v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 ; c843138a 8a8b198b 3f650000
	v_dual_mul_f32 v188, v188, v135 :: v_dual_mul_f32 v185, v185, v130 ; c8c70fbc bcb905b9
	v_maxmin_num_f32 v149, -4.0, v17, 4.0                       ; d6690095 03da22f7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_maxmin_num_f32 v151, -4.0, v18, 4.0                       ; d6690097 03da24f7
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
(invalid instruction)                                        ; d769406d
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 :: v_dual_fmaak_f32 v143, v143, v144, 0x3f650000 ; c8431b8e 8e8f218f 3f650000
	v_maxmin_num_f32 v153, -4.0, v19, 4.0                       ; d6690099 03da26f7
	v_dual_mul_f32 v190, v190, v139 :: v_dual_mul_f32 v187, v187, v134 ; c8c717be bebb0dbb
(invalid instruction)                                        ; d769006e
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v20, 4.0                       ; d669009b 03da28f7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_lshrrev_b32_e32 v59, 4, v59                               ; 32767684
	v_dual_fmaak_f32 v146, v146, v145, 0x3f650000 :: v_dual_fmaak_f32 v147, v147, v148, 0x3f650000 ; c8432392 92932993 3f650000
	v_dual_mul_f32 v14, v14, v143 :: v_dual_mul_f32 v189, v189, v138 ; c8c71f0e 0ebd15bd
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
(invalid instruction)                                        ; d769406e
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_fmaak_f32 v150, v150, v149, 0x3f650000 :: v_dual_fmaak_f32 v151, v151, v152, 0x3f650000 ; c8432b96 96973197 3f650000
	v_dual_mul_f32 v16, v16, v147 :: v_dual_mul_f32 v191, v191, v142 ; c8c72710 10bf1dbf
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 :: v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 ; c843339a 9a9b399b 3f650000
	v_dual_mul_f32 v17, v17, v150 :: v_dual_and_b32 v0, 0xffffffe0, v0 ; c8e52d11 110000ff ffffffe0
	v_dual_mul_f32 v18, v18, v151 :: v_dual_mul_f32 v15, v15, v146 ; c8c72f12 120f250f
	v_dual_mul_f32 v20, v155, v20 :: v_dual_lshlrev_b32 v59, 3, v59 ; c8e2299b 143a7683
	v_maxmin_num_f32 v157, -4.0, v21, 4.0                       ; d669009d 03da2af7
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_add3_u32 v158, v59, s8, v0                                ; d655009e 0400113b
	v_dual_mul_f32 v19, v154, v19 :: v_dual_lshlrev_b32 v158, 2, v158 ; c8e2279a 139f3c82
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v158, s[32:35], null offen       ; c405c07c 40804010 0000009e
	buffer_load_b128 v[124:127], v158, s[32:35], null offen offset:16 ; c405c07c 4080407c 0000109e
	v_maxmin_num_f32 v160, -4.0, v42, 4.0                       ; d66900a0 03da54f7
(invalid instruction)                                        ; d769006f
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d769406f
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v162, -4.0, v43, 4.0                       ; d66900a2 03da56f7
	v_fma_mix_f32 v159, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3aff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v44, 4.0                       ; d66900a4 03da58f7
	v_maxmin_num_f32 v166, -4.0, v45, 4.0                       ; d66900a6 03da5af7
	v_maxmin_num_f32 v168, -4.0, v46, 4.0                       ; d66900a8 03da5cf7
	v_maxmin_num_f32 v170, -4.0, v47, 4.0                       ; d66900aa 03da5ef7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v48, 4.0                       ; d66900ac 03da60f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v49, 4.0                       ; d66900ae 03da62f7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_dual_fmaak_f32 v160, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v159, v159, v157, 0x3f650000 ; c84341a1 a09f3b9f 3f650000
	v_fmaak_f32 v163, v163, v162, 0x3f650000                    ; 5b4745a3 3f650000
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c84355ab aba953a8 3f650000
	v_dual_mul_f32 v42, v42, v160 :: v_dual_mul_f32 v21, v21, v159 ; c8c7412a 2a153f15
	v_mul_f32_e32 v43, v43, v163                                ; 1057472b
	v_dual_mul_f32 v45, v45, v167 :: v_dual_mul_f32 v44, v44, v164 ; c8c74f2d 2d2d492c
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 ; c8435daf afad5bac 3f650000
	v_dual_mul_f32 v47, v47, v171 :: v_dual_mul_f32 v46, v46, v168 ; c8c7572f 2f2f512e
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
	v_dual_mul_f32 v49, v49, v175 :: v_dual_mul_f32 v48, v48, v172 ; c8c75f31 31315930
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[88:89], v[40:41], 0 ; cc4640a0 1a025158
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[88:89], v[74:75], 0 ; cc464090 1a029558
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[90:91], v[74:75], 0 ; cc4640b8 1a02955a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[88:89], v[50:51], 0 ; cc464080 1a026558
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[90:91], v[50:51], 0 ; cc4640a8 1a02655a
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[90:91], v[40:41], 0 ; cc46402c 1a02515a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[90:91], v[72:73], 0 ; cc4640b0 1a02915a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[88:89], v[72:73], 0 ; cc464088 1a029158
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[92:93], v[6:7], v[160:167] ; cc4640a0 1e820d5c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[52:53], v[128:135] ; cc464080 1e02695c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[94:95], v[52:53], v[168:175] ; cc4640a8 1ea2695e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[94:95], v[56:57], v[176:183] ; cc4640b0 1ec2715e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[92:93], v[56:57], v[136:143] ; cc464088 1e22715c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[96:97], v[8:9], v[128:135] ; cc464080 1e021160
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[98:99], v[8:9], v[168:175] ; cc4640a8 1ea21162
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[92:93], v[62:63], v[144:151] ; cc464090 1e427d5c
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[94:95], v[6:7], v[44:51] ; cc46402c 1cb20d5e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[96:97], v[28:29], v[160:167] ; cc4640a0 1e823960
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[98:99], v[10:11], v[176:183] ; cc4640b0 1ec21562
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[96:97], v[10:11], v[136:143] ; cc464088 1e221560
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[100:101], v[30:31], v[128:135] ; cc464080 1e023d64
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[102:103], v[30:31], v[168:175] ; cc4640a8 1ea23d66
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[98:99], v[28:29], v[44:51] ; cc46402c 1cb23962
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v158, s[32:35], null offen offset:64 ; c405c07c 40804008 0000409e
	buffer_load_b128 v[28:31], v158, s[32:35], null offen offset:80 ; c405c07c 4080401c 0000509e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[94:95], v[62:63], v[184:191] ; cc4640b8 1ee27d5e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[12:13], v[144:151] ; cc464090 1e421960
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[100:101], v[26:27], v[160:167] ; cc4640a0 1e823564
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[100:101], v[32:33], v[136:143] ; cc464088 1e224164
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[102:103], v[32:33], v[176:183] ; cc4640b0 1ec24166
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[102:103], v[26:27], v[44:51] ; cc46402c 1cb23566
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[12:13], v[184:191] ; cc4640b8 1ee21962
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[104:105], v[68:69], v[128:135] ; cc464080 1e028968
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[34:35], v[144:151] ; cc464090 1e424564
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[104:105], v[82:83], v[160:167] ; cc4640a0 1e82a568
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[104:105], v[70:71], v[136:143] ; cc464088 1e228d68
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[106:107], v[70:71], v[176:183] ; cc4640b0 1ec28d6a
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[106:107], v[82:83], v[44:51] ; cc46402c 1cb2a56a
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[102:103], v[34:35], v[184:191] ; cc4640b8 1ee24566
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[104:105], v[80:81], v[144:151] ; cc464090 1e42a168
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[116:117], v[36:37], v[160:167] ; cc4640a0 1e824974
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[106:107], v[68:69], v[168:175] ; cc4640a8 1ea2896a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[116:117], v[22:23], v[136:143] ; cc464088 1e222d74
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[116:117], v[84:85], v[128:135] ; cc464080 1e02a974
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[118:119], v[22:23], v[176:183] ; cc4640b0 1ec22d76
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[118:119], v[36:37], v[44:51] ; cc46402c 1cb24976
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[106:107], v[80:81], v[184:191] ; cc4640b8 1ee2a16a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[116:117], v[24:25], v[144:151] ; cc464090 1e423174
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[112:113], v[86:87], v[160:167] ; cc4640a0 1e82ad70
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[118:119], v[84:85], v[168:175] ; cc4640a8 1ea2a976
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[60:61], v[136:143] ; cc464088 1e227970
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[112:113], v[38:39], v[128:135] ; cc464080 1e024d70
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[60:61], v[176:183] ; cc4640b0 1ec27972
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[114:115], v[86:87], v[44:51] ; cc46402c 1cb2ad72
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[24:25], v[184:191] ; cc4640b8 1ee23176
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[112:113], v[64:65], v[144:151] ; cc464090 1e428170
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[120:121], v[20:21], v[160:167] ; cc4640a0 1e822978
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[114:115], v[38:39], v[168:175] ; cc4640a8 1ea24d72
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[120:121], v[110:111], v[136:143] ; cc464088 1e22dd78
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[120:121], v[108:109], v[128:135] ; cc464080 1e02d978
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[122:123], v[110:111], v[176:183] ; cc4640b0 1ec2dd7a
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[122:123], v[20:21], v[44:51] ; cc46402c 1cb2297a
	v_lshlrev_b32_e32 v21, 11, v1                               ; 302a028b
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[64:65], v[184:191] ; cc4640b8 1ee28172
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[120:121], v[14:15], v[144:151] ; cc464090 1e421d78
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[122:123], v[108:109], v[168:175] ; cc4640a8 1ea2d97a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_add3_u32 v22, v66, s4, v21                                ; d6550016 04540942
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v22, 2, v22                               ; 302c2c82
	buffer_load_b128 v[24:27], v22, s[36:39], null offen        ; c405c07c 40804818 00000016
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[122:123], v[14:15], v[184:191] ; cc4640b8 1ee21d7a
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_add_nc_u32_e32 v23, 0x4000, v76                           ; 4a2e98ff 00004000
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	ds_store_2addr_b64 v23, v[6:7], v[34:35] offset1:32         ; d9382000 00220617
	buffer_load_b128 v[44:47], v22, s[36:39], null offen offset:512 ; c405c07c 4080482c 00020016
	v_add_nc_u32_e32 v32, 0x5000, v76                           ; 4a4098ff 00005000
	v_add_nc_u32_e32 v34, 0x6000, v76                           ; 4a4498ff 00006000
	v_add_nc_u32_e32 v35, 0x7000, v76                           ; 4a4698ff 00007000
	v_dual_mov_b32 v6, v21 :: v_dual_mov_b32 v21, v33           ; ca100115 06140121
	ds_store_2addr_b64 v32, v[12:13], v[36:37] offset1:32       ; d9382000 00240c20
	ds_store_2addr_b64 v34, v[14:15], v[38:39] offset1:32       ; d9382000 00260e22
	ds_store_2addr_b64 v35, v[20:21], v[40:41] offset1:32       ; d9382000 00281423
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	buffer_load_b128 v[12:15], v22, s[36:39], null offen offset:1024 ; c405c07c 4080480c 00040016
	v_mad_u32_u24 v7, s55, 0x500, v2                            ; d60b0007 0409fe37 00000500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v7, v7, v55                                ; 4a0e6f07
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[20:21], v7                                    ; d9d80000 14000007
	ds_load_b64 v[36:37], v7 offset:4096                        ; d9d81000 24000007
	ds_load_b64 v[38:39], v7 offset:8192                        ; d9d82000 26000007
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[40:41], v20                          ; 7e50dd14
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v81, v41, v17 :: v_dual_mul_f32 v80, v40, v16 ; c8c62329 51502128
	v_cvt_pk_f32_fp8_e32 v[40:41], v148                         ; 7e50dd94
	v_dual_mul_f32 v83, v41, v19 :: v_dual_mul_f32 v82, v40, v18 ; c8c62729 53522528
	buffer_load_b128 v[40:43], v22, s[36:39], null offen offset:1536 ; c405c07c 40804828 00060016
	v_cvt_pk_f32_fp8_e32 v[48:49], v21                          ; 7e60dd15
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v85, v49, v125 :: v_dual_mul_f32 v84, v48, v124 ; c8c6fb31 5554f930
	ds_load_b64 v[48:49], v7 offset:12288                       ; d9d83000 30000007
	buffer_load_b128 v[60:63], v22, s[36:39], null offen offset:2048 ; c405c07c 4080483c 00080016
	ds_load_b64 v[50:51], v7 offset:256                         ; d9d80100 32000007
	buffer_load_b128 v[68:71], v22, s[36:39], null offen offset:2560 ; c405c07c 40804844 000a0016
	v_cvt_pk_f32_fp8_e32 v[20:21], v149                         ; 7e28dd95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v87, v21, v127 :: v_dual_mul_f32 v86, v20, v126 ; c8c6ff15 5756fd14
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[20:21], v36                          ; 7e28dd24
	v_dual_mul_f32 v89, v21, v17 :: v_dual_mul_f32 v88, v20, v16 ; c8c62315 59582114
	v_cvt_pk_f32_fp8_e32 v[20:21], v164                         ; 7e28dda4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v91, v21, v19 :: v_dual_mul_f32 v90, v20, v18 ; c8c62715 5b5a2514
	v_cvt_pk_f32_fp8_e32 v[20:21], v37                          ; 7e28dd25
	v_cvt_pk_f32_fp8_e32 v[36:37], v165                         ; 7e48dda5
	v_dual_mul_f32 v93, v21, v125 :: v_dual_mul_f32 v92, v20, v124 ; c8c6fb15 5d5cf914
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[20:21], v38                          ; 7e28dd26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v97, v21, v17 :: v_dual_mul_f32 v96, v20, v16 ; c8c62315 61602114
	v_cvt_pk_f32_fp8_e32 v[20:21], v166                         ; 7e28dda6
	v_dual_mul_f32 v99, v21, v19 :: v_dual_mul_f32 v98, v20, v18 ; c8c62715 63622514
	v_cvt_pk_f32_fp8_e32 v[20:21], v39                          ; 7e28dd27
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v95, v37, v127 :: v_dual_mul_f32 v100, v20, v124 ; c8c6ff25 5f64f914
	v_dual_mul_f32 v101, v21, v125 :: v_dual_mul_f32 v94, v36, v126 ; c8c6fb15 655efd24
	v_cvt_pk_f32_fp8_e32 v[20:21], v167                         ; 7e28dda7
	buffer_load_b128 v[36:39], v22, s[36:39], null offen offset:3072 ; c405c07c 40804824 000c0016
	ds_load_b64 v[52:53], v7 offset:4352                        ; d9d81100 34000007
	buffer_load_b128 v[72:75], v22, s[36:39], null offen offset:3584 ; c405c07c 40804848 000e0016
	v_dual_mul_f32 v103, v21, v127 :: v_dual_mul_f32 v102, v20, v126 ; c8c6ff15 6766fd14
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[20:21], v48                          ; 7e28dd30
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v105, v21, v17                                ; 10d22315
	v_mul_f32_e32 v104, v20, v16                                ; 10d02114
	v_cvt_pk_f32_fp8_e32 v[16:17], v176                         ; 7e20ddb0
	v_dual_mul_f32 v107, v17, v19 :: v_dual_mul_f32 v106, v16, v18 ; c8c62711 6b6a2510
	ds_load_b64 v[18:19], v7 offset:8448                        ; d9d82100 12000007
	buffer_load_b128 v[116:119], v22, s[36:39], null offen offset:4096 ; c405c07c 40804874 00100016
	ds_load_b64 v[20:21], v7 offset:12544                       ; d9d83100 14000007
	v_cvt_pk_f32_fp8_e32 v[16:17], v49                          ; 7e20dd31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v109, v17, v125 :: v_dual_mul_f32 v108, v16, v124 ; c8c6fb11 6d6cf910
	v_cvt_pk_f32_fp8_e32 v[16:17], v177                         ; 7e20ddb1
	v_dual_mul_f32 v111, v17, v127 :: v_dual_mul_f32 v110, v16, v126 ; c8c6ff11 6f6efd10
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[16:17], v50                          ; 7e20dd32
	s_wait_loadcnt 0xa                                          ; bfc0000a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v17, v9 :: v_dual_mul_f32 v112, v16, v8 ; c8c61311 71701110
	v_cvt_pk_f32_fp8_e32 v[16:17], v178                         ; 7e20ddb2
	v_dual_mul_f32 v115, v17, v11 :: v_dual_mul_f32 v114, v16, v10 ; c8c61711 73721510
	v_cvt_pk_f32_fp8_e32 v[16:17], v51                          ; 7e20dd33
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v125, v17, v29 :: v_dual_mul_f32 v124, v16, v28 ; c8c63b11 7d7c3910
	v_cvt_pk_f32_fp8_e32 v[16:17], v179                         ; 7e20ddb3
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v22, s[36:39], null offen offset:4608 ; c405c07c 40804830 00120016
	buffer_load_b128 v[120:123], v22, s[36:39], null offen offset:5120 ; c405c07c 40804878 00140016
	v_dual_mul_f32 v127, v17, v31 :: v_dual_mul_f32 v126, v16, v30 ; c8c63f11 7f7e3d10
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[16:17], v52                          ; 7e20dd34
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
	v_dual_mul_f32 v129, v17, v9 :: v_dual_mul_f32 v128, v16, v8 ; c8c61311 81801110
	v_cvt_pk_f32_fp8_e32 v[16:17], v180                         ; 7e20ddb4
	buffer_load_b128 v[144:147], v22, s[36:39], null offen offset:5632 ; c405c07c 40804890 00160016
	v_dual_mul_f32 v131, v17, v11 :: v_dual_mul_f32 v130, v16, v10 ; c8c61711 83821510
	v_cvt_pk_f32_fp8_e32 v[16:17], v53                          ; 7e20dd35
	v_dual_mul_f32 v133, v17, v29 :: v_dual_mul_f32 v132, v16, v28 ; c8c63b11 85843910
	v_cvt_pk_f32_fp8_e32 v[16:17], v181                         ; 7e20ddb5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v135, v17, v31 :: v_dual_mul_f32 v134, v16, v30 ; c8c63f11 87863d10
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[16:17], v18                          ; 7e20dd12
	v_dual_mul_f32 v137, v17, v9 :: v_dual_mul_f32 v136, v16, v8 ; c8c61311 89881110
	v_cvt_pk_f32_fp8_e32 v[16:17], v146                         ; 7e20dd92
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v139, v17, v11 :: v_dual_mul_f32 v138, v16, v10 ; c8c61711 8b8a1510
	v_cvt_pk_f32_fp8_e32 v[16:17], v19                          ; 7e20dd13
	v_dual_mul_f32 v141, v17, v29 :: v_dual_mul_f32 v140, v16, v28 ; c8c63b11 8d8c3910
	v_cvt_pk_f32_fp8_e32 v[16:17], v147                         ; 7e20dd93
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v143, v17, v31 :: v_dual_mul_f32 v142, v16, v30 ; c8c63f11 8f8e3d10
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[16:17], v20                          ; 7e20dd14
	v_dual_mul_f32 v153, v17, v9 :: v_dual_mul_f32 v152, v16, v8 ; c8c61311 99981110
	buffer_load_b128 v[16:19], v22, s[36:39], null offen offset:6144 ; c405c07c 40804810 00180016
	v_cvt_pk_f32_fp8_e32 v[8:9], v148                           ; 7e10dd94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v155, v9, v11 :: v_dual_mul_f32 v154, v8, v10 ; c8c61709 9b9a1508
	v_cvt_pk_f32_fp8_e32 v[8:9], v21                            ; 7e10dd15
	v_dual_mul_f32 v157, v9, v29 :: v_dual_mul_f32 v156, v8, v28 ; c8c63b09 9d9c3908
	v_cvt_pk_f32_fp8_e32 v[8:9], v149                           ; 7e10dd95
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v159, v9, v31 :: v_dual_mul_f32 v158, v8, v30 ; c8c63f09 9f9e3d08
	v_lshl_add_u32 v8, s55, 10, v55                             ; d6460008 04dd1437
	ds_load_b64 v[10:11], v8 offset:16384                       ; d9d84000 0a000008
	ds_load_b64 v[20:21], v8 offset:20480                       ; d9d85000 14000008
	ds_load_b64 v[28:29], v8 offset:24576                       ; d9d86000 1c000008
	ds_load_b64 v[30:31], v8 offset:28672                       ; d9d87000 1e000008
	ds_load_b64 v[52:53], v8 offset:16640                       ; d9d84100 34000008
	ds_load_b64 v[56:57], v8 offset:20736                       ; d9d85100 38000008
	ds_load_b64 v[64:65], v8 offset:24832                       ; d9d86100 40000008
	ds_load_b64 v[148:149], v8 offset:28928                     ; d9d87100 94000008
	ds_load_b64 v[150:151], v8 offset:16896                     ; d9d84200 96000008
	ds_load_b64 v[160:161], v8 offset:20992                     ; d9d85200 a0000008
	ds_load_b64 v[162:163], v8 offset:25088                     ; d9d86200 a2000008
	ds_load_b64 v[164:165], v8 offset:29184                     ; d9d87200 a4000008
	buffer_load_b128 v[168:171], v22, s[36:39], null offen offset:6656 ; c405c07c 408048a8 001a0016
	ds_load_b64 v[166:167], v8 offset:17152                     ; d9d84300 a6000008
	ds_load_b64 v[172:173], v8 offset:21248                     ; d9d85300 ac000008
	ds_load_b64 v[174:175], v8 offset:25344                     ; d9d86300 ae000008
	ds_load_b64 v[176:177], v8 offset:29440                     ; d9d87300 b0000008
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_mov_b32 v183, v119 :: v_dual_mov_b32 v182, v118      ; ca100177 b7b60176
	v_dual_mov_b32 v119, v127 :: v_dual_mov_b32 v118, v126      ; ca10017f 7776017e
	v_dual_mov_b32 v181, v117 :: v_dual_mov_b32 v180, v116      ; ca100175 b5b40174
	v_dual_mov_b32 v117, v125 :: v_dual_mov_b32 v116, v124      ; ca10017d 7574017c
	buffer_load_b128 v[124:127], v22, s[36:39], null offen offset:7168 ; c405c07c 4080487c 001c0016
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[10:11], v[80:87] ; cc464050 1d421518
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[10:11], v[112:119] ; cc464070 1dc2151a
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[20:21], v[88:95] ; cc464058 1d622918
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[20:21], v[128:135] ; cc464080 1e02291a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[28:29], v[136:143] ; cc464088 1e22391a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[28:29], v[96:103] ; cc464060 1d823918
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[30:31], v[104:111] ; cc464068 1da23d18
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[26:27], v[30:31], v[152:159] ; cc464098 1e623d1a
	ds_load_b64 v[10:11], v8 offset:17408                       ; d9d84400 0a000008
	ds_load_b64 v[20:21], v8 offset:21504                       ; d9d85400 14000008
	ds_load_b64 v[24:25], v8 offset:25600                       ; d9d86400 18000008
	ds_load_b64 v[26:27], v8 offset:29696                       ; d9d87400 1a000008
	buffer_load_b128 v[28:31], v22, s[36:39], null offen offset:7680 ; c405c07c 4080481c 001e0016
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[52:53], v[80:87] ; cc464050 1d42692c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[56:57], v[88:95] ; cc464058 1d62712c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[56:57], v[128:135] ; cc464080 1e02712e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[64:65], v[136:143] ; cc464088 1e22812e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[64:65], v[96:103] ; cc464060 1d82812c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[52:53], v[112:119] ; cc464070 1dc2692e
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[148:149], v[104:111] ; cc464068 1da3292c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[148:149], v[152:159] ; cc464098 1e63292e
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[150:151], v[80:87] ; cc464050 1d432d0c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[160:161], v[88:95] ; cc464058 1d63410c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[160:161], v[128:135] ; cc464080 1e03410e
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[14:15], v[162:163], v[136:143] ; cc464088 1e23450e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[162:163], v[96:103] ; cc464060 1d83450c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[150:151], v[112:119] ; cc464070 1dc32d0e
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[164:165], v[104:111] ; cc464068 1da3490c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[14:15], v[164:165], v[152:159] ; cc464098 1e63490e
	ds_load_b64 v[44:45], v8 offset:17664                       ; d9d84500 2c000008
	ds_load_b64 v[46:47], v8 offset:21760                       ; d9d85500 2e000008
	ds_load_b64 v[52:53], v8 offset:25856                       ; d9d86500 34000008
	ds_load_b64 v[56:57], v8 offset:29952                       ; d9d87500 38000008
	ds_load_b64 v[12:13], v8 offset:17920                       ; d9d84600 0c000008
	ds_load_b64 v[14:15], v8 offset:22016                       ; d9d85600 0e000008
	ds_load_b64 v[64:65], v8 offset:26112                       ; d9d86600 40000008
	ds_load_b64 v[148:149], v8 offset:30208                     ; d9d87600 94000008
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[166:167], v[80:87] ; cc464050 1d434d28
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[172:173], v[88:95] ; cc464058 1d635928
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[172:173], v[128:135] ; cc464080 1e03592a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[174:175], v[96:103] ; cc464060 1d835d28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[174:175], v[136:143] ; cc464088 1e235d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[166:167], v[112:119] ; cc464070 1dc34d2a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[176:177], v[104:111] ; cc464068 1da36128
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[42:43], v[176:177], v[152:159] ; cc464098 1e63612a
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[10:11], v[80:87] ; cc464050 1d42153c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[60:61], v[20:21], v[88:95] ; cc464058 1d62293c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[20:21], v[128:135] ; cc464080 1e02293e
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[60:61], v[24:25], v[96:103] ; cc464060 1d82313c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[62:63], v[24:25], v[136:143] ; cc464088 1e22313e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[10:11], v[112:119] ; cc464070 1dc2153e
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[26:27], v[104:111] ; cc464068 1da2353c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[26:27], v[152:159] ; cc464098 1e62353e
	ds_load_b64 v[40:41], v8 offset:18176                       ; d9d84700 28000008
	ds_load_b64 v[42:43], v8 offset:22272                       ; d9d85700 2a000008
	ds_load_b64 v[150:151], v8 offset:26368                     ; d9d86700 96000008
	ds_load_b64 v[160:161], v8 offset:30464                     ; d9d87700 a0000008
	ds_load_b64 v[10:11], v8 offset:18432                       ; d9d84800 0a000008
	ds_load_b64 v[20:21], v8 offset:22528                       ; d9d85800 14000008
	ds_load_b64 v[24:25], v8 offset:26624                       ; d9d86800 18000008
	ds_load_b64 v[26:27], v8 offset:30720                       ; d9d87800 1a000008
	v_add_lshl_u32 v9, s10, v1, 2                               ; d6470009 020a020a
	buffer_load_b32 v9, v9, s[32:35], null offen                ; c405007c 40804009 00000009
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[44:45], v[80:87] ; cc464050 1d425944
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[46:47], v[88:95] ; cc464058 1d625d44
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[52:53], v[96:103] ; cc464060 1d826944
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[46:47], v[128:135] ; cc464080 1e025d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[52:53], v[136:143] ; cc464088 1e226946
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[44:45], v[112:119] ; cc464070 1dc25946
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[56:57], v[104:111] ; cc464068 1da27144
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[70:71], v[56:57], v[152:159] ; cc464098 1e627146
	ds_load_b64 v[44:45], v8 offset:18688                       ; d9d84900 2c000008
	ds_load_b64 v[46:47], v8 offset:22784                       ; d9d85900 2e000008
	ds_load_b64 v[52:53], v8 offset:26880                       ; d9d86900 34000008
	ds_load_b64 v[56:57], v8 offset:30976                       ; d9d87900 38000008
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[12:13], v[80:87] ; cc464050 1d421924
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[14:15], v[88:95] ; cc464058 1d621d24
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[38:39], v[14:15], v[128:135] ; cc464080 1e021d26
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[12:13], v[112:119] ; cc464070 1dc21926
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_mad_u32_u24 v22, 0x1800, v1, s5                           ; d60b0016 001602ff 00001800
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v22, v22, v66, 2                             ; d6470016 020a8516
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v22, s[36:39], null offen        ; c405c07c 4080483c 00000016
	buffer_load_b128 v[12:15], v22, s[36:39], null offen offset:8192 ; c405c07c 4080480c 00200016
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[64:65], v[96:103] ; cc464060 1d828124
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[38:39], v[64:65], v[136:143] ; cc464088 1e228126
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[148:149], v[104:111] ; cc464068 1da32924
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[38:39], v[148:149], v[152:159] ; cc464098 1e632926
	ds_load_b64 v[36:37], v8 offset:18944                       ; d9d84a00 24000008
	ds_load_b64 v[38:39], v8 offset:23040                       ; d9d85a00 26000008
	ds_load_b64 v[64:65], v8 offset:27136                       ; d9d86a00 40000008
	ds_load_b64 v[68:69], v8 offset:31232                       ; d9d87a00 44000008
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[40:41], v[80:87] ; cc464050 1d425148
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[42:43], v[88:95] ; cc464058 1d625548
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[42:43], v[128:135] ; cc464080 1e02554a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[40:41], v[112:119] ; cc464070 1dc2514a
	buffer_load_b128 v[40:43], v22, s[36:39], null offen offset:512 ; c405c07c 40804828 00020016
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[150:151], v[96:103] ; cc464060 1d832d48
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[150:151], v[136:143] ; cc464088 1e232d4a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[160:161], v[104:111] ; cc464068 1da34148
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[160:161], v[152:159] ; cc464098 1e63414a
	ds_load_b64 v[70:71], v8 offset:19200                       ; d9d84b00 46000008
	ds_load_b64 v[72:73], v8 offset:23296                       ; d9d85b00 48000008
	ds_load_b64 v[74:75], v8 offset:27392                       ; d9d86b00 4a000008
	ds_load_b64 v[148:149], v8 offset:31488                     ; d9d87b00 94000008
	buffer_load_b128 v[160:163], v22, s[36:39], null offen offset:8704 ; c405c07c 408048a0 00220016
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[180:181], v[10:11], v[80:87] ; cc464050 1d4215b4
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[180:181], v[20:21], v[88:95] ; cc464058 1d6229b4
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[182:183], v[20:21], v[128:135] ; cc464080 1e0229b6
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[182:183], v[10:11], v[112:119] ; cc464070 1dc215b6
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[180:181], v[24:25], v[96:103] ; cc464060 1d8231b4
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[182:183], v[24:25], v[136:143] ; cc464088 1e2231b6
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[180:181], v[26:27], v[104:111] ; cc464068 1da235b4
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[182:183], v[26:27], v[152:159] ; cc464098 1e6235b6
	ds_load_b64 v[10:11], v8 offset:19456                       ; d9d84c00 0a000008
	ds_load_b64 v[20:21], v8 offset:23552                       ; d9d85c00 14000008
	ds_load_b64 v[24:25], v8 offset:27648                       ; d9d86c00 18000008
	ds_load_b64 v[26:27], v8 offset:31744                       ; d9d87c00 1a000008
	buffer_load_b128 v[164:167], v22, s[36:39], null offen offset:1024 ; c405c07c 408048a4 00040016
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[44:45], v[80:87] ; cc464050 1d425930
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[46:47], v[88:95] ; cc464058 1d625d30
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[46:47], v[128:135] ; cc464080 1e025d32
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[44:45], v[112:119] ; cc464070 1dc25932
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[48:49], v[52:53], v[96:103] ; cc464060 1d826930
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[50:51], v[52:53], v[136:143] ; cc464088 1e226932
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[56:57], v[104:111] ; cc464068 1da27130
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[50:51], v[56:57], v[152:159] ; cc464098 1e627132
	ds_load_b64 v[44:45], v8 offset:19712                       ; d9d84d00 2c000008
	ds_load_b64 v[46:47], v8 offset:23808                       ; d9d85d00 2e000008
	ds_load_b64 v[48:49], v8 offset:27904                       ; d9d86d00 30000008
	ds_load_b64 v[50:51], v8 offset:32000                       ; d9d87d00 32000008
	buffer_load_b128 v[172:175], v22, s[36:39], null offen offset:9216 ; c405c07c 408048ac 00240016
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[120:121], v[36:37], v[80:87] ; cc464050 1d424978
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[120:121], v[38:39], v[88:95] ; cc464058 1d624d78
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[122:123], v[38:39], v[128:135] ; cc464080 1e024d7a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[122:123], v[36:37], v[112:119] ; cc464070 1dc2497a
	ds_load_b64 v[36:37], v8 offset:19968                       ; d9d84e00 24000008
	ds_load_b64 v[38:39], v8 offset:24064                       ; d9d85e00 26000008
	ds_load_b64 v[52:53], v8 offset:28160                       ; d9d86e00 34000008
	ds_load_b64 v[56:57], v8 offset:32256                       ; d9d87e00 38000008
	s_wait_dscnt 0x11                                           ; bfc60011
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[120:121], v[64:65], v[96:103] ; cc464060 1d828178
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[122:123], v[64:65], v[136:143] ; cc464088 1e22817a
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[120:121], v[68:69], v[104:111] ; cc464068 1da28978
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[122:123], v[68:69], v[152:159] ; cc464098 1e62897a
	buffer_load_b128 v[120:123], v22, s[36:39], null offen offset:1536 ; c405c07c 40804878 00060016
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[144:145], v[70:71], v[80:87] ; cc464050 1d428d90
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[144:145], v[72:73], v[88:95] ; cc464058 1d629190
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[146:147], v[72:73], v[128:135] ; cc464080 1e029192
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[146:147], v[70:71], v[112:119] ; cc464070 1dc28d92
	ds_load_b64 v[64:65], v8 offset:20224                       ; d9d84f00 40000008
	ds_load_b64 v[68:69], v8 offset:24320                       ; d9d85f00 44000008
	ds_load_b64 v[70:71], v8 offset:28416                       ; d9d86f00 46000008
	ds_load_b64 v[72:73], v8 offset:32512                       ; d9d87f00 48000008
	s_wait_dscnt 0x11                                           ; bfc60011
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[144:145], v[74:75], v[96:103] ; cc464060 1d829590
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[146:147], v[74:75], v[136:143] ; cc464088 1e229592
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[144:145], v[148:149], v[104:111] ; cc464068 1da32990
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[146:147], v[148:149], v[152:159] ; cc464098 1e632992
	s_wait_loadcnt_dscnt 0xb0f                                  ; bfc80b0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[10:11], v[80:87] ; cc464050 1d421510
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[20:21], v[88:95] ; cc464058 1d622910
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[20:21], v[128:135] ; cc464080 1e022912
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[10:11], v[112:119] ; cc464070 1dc21512
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[24:25], v[96:103] ; cc464060 1d823110
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[24:25], v[136:143] ; cc464088 1e223112
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[26:27], v[104:111] ; cc464068 1da23510
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[18:19], v[26:27], v[152:159] ; cc464098 1e623512
	s_wait_loadcnt_dscnt 0xa0b                                  ; bfc80a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[168:169], v[44:45], v[80:87] ; cc464050 1d4259a8
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[168:169], v[46:47], v[88:95] ; cc464058 1d625da8
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[170:171], v[46:47], v[128:135] ; cc464080 1e025daa
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[44:45], v[112:119] ; cc464070 1dc259aa
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[168:169], v[48:49], v[96:103] ; cc464060 1d8261a8
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[170:171], v[48:49], v[136:143] ; cc464088 1e2261aa
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[168:169], v[50:51], v[104:111] ; cc464068 1da265a8
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[170:171], v[50:51], v[152:159] ; cc464098 1e6265aa
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[124:125], v[36:37], v[80:87] ; cc464050 1d42497c
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[124:125], v[38:39], v[88:95] ; cc464058 1d624d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[126:127], v[38:39], v[128:135] ; cc464080 1e024d7e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[126:127], v[36:37], v[112:119] ; cc464070 1dc2497e
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[124:125], v[52:53], v[96:103] ; cc464060 1d82697c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[126:127], v[52:53], v[136:143] ; cc464088 1e22697e
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[124:125], v[56:57], v[104:111] ; cc464068 1da2717c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[126:127], v[56:57], v[152:159] ; cc464098 1e62717e
	s_wait_loadcnt_dscnt 0x803                                  ; bfc80803
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[64:65], v[80:87] ; cc464050 1d42811c
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[68:69], v[88:95] ; cc464058 1d62891c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[68:69], v[128:135] ; cc464080 1e02891e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[64:65], v[112:119] ; cc464070 1dc2811e
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[70:71], v[96:103] ; cc464060 1d828d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[70:71], v[136:143] ; cc464088 1e228d1e
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[72:73], v[104:111] ; cc464068 1da2911c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[30:31], v[72:73], v[152:159] ; cc464098 1e62911e
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v76, v[10:11], v[24:25] offset1:32       ; d9382000 00180a4c
	ds_store_2addr_b64 v77, v[16:17], v[26:27] offset1:32       ; d9382000 001a104d
	ds_store_2addr_b64 v78, v[18:19], v[28:29] offset1:32       ; d9382000 001c124e
	ds_store_2addr_b64 v79, v[20:21], v[30:31] offset1:32       ; d9382000 001e144f
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_lshl_add_u32 v24, s55, 11, v55                            ; d6460018 04dd1637
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[10:11], v24                                   ; d9d80000 0a000018
	ds_load_b64 v[16:17], v24 offset:4096                       ; d9d81000 10000018
	ds_load_b64 v[18:19], v24 offset:8192                       ; d9d82000 12000018
	ds_load_b64 v[20:21], v24 offset:12288                      ; d9d83000 14000018
	ds_load_b64 v[26:27], v24 offset:256                        ; d9d80100 1a000018
	ds_load_b64 v[28:29], v24 offset:4352                       ; d9d81100 1c000018
	ds_load_b64 v[30:31], v24 offset:8448                       ; d9d82100 1e000018
	ds_load_b64 v[36:37], v24 offset:12544                      ; d9d83100 24000018
	ds_load_b64 v[38:39], v24 offset:512                        ; d9d80200 26000018
	ds_load_b64 v[44:45], v24 offset:4608                       ; d9d81200 2c000018
	ds_load_b64 v[46:47], v24 offset:8704                       ; d9d82200 2e000018
	ds_load_b64 v[48:49], v24 offset:12800                      ; d9d83200 30000018
	v_mov_b32_e32 v25, v55                                      ; 7e320337
	v_mov_b32_e32 v33, v66                                      ; 7e420342
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_mov_b32 v69, v15 :: v_dual_mov_b32 v68, v14          ; ca10010f 4544010e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mov_b32 v169, v121 :: v_dual_mov_b32 v168, v120      ; ca100179 a9a80178
	v_dual_mov_b32 v171, v123 :: v_dual_mov_b32 v170, v122      ; ca10017b abaa017a
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[62:63], v[10:11], 0 ; cc464068 1a02153e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[60:61], v[10:11], 0 ; cc464048 1a02153c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[12:13], v[10:11], 0 ; cc464090 1a02150c
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[14:15], v[10:11], 0 ; cc464032 1a02150e
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[16:17], 0 ; cc464070 1a02213e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[12:13], v[16:17], 0 ; cc464098 1a02210c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[16:17], 0 ; cc464050 1a02213c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[18:19], 0 ; cc4640b0 1a02250c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[18:19], 0 ; cc464080 1a02253e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[60:61], v[18:19], 0 ; cc464058 1a02253c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[12:13], v[20:21], 0 ; cc4640b8 1a02290c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[60:61], v[20:21], 0 ; cc464060 1a02293c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[62:63], v[20:21], 0 ; cc464088 1a02293e
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[14:15], v[16:17], 0 ; cc46403c 1a02210e
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[68:69], v[18:19], 0 ; cc46400a 1a022544
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[20:21], 0 ; cc464078 1a022944
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[40:41], v[26:27], v[72:79] ; cc464048 1d223528
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[26:27], v[104:111] ; cc464068 1da2352a
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[28:29], v[112:119] ; cc464070 1dc2392a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[28:29], v[80:87] ; cc464050 1d423928
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[30:31], v[128:135] ; cc464080 1e023d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[30:31], v[88:95] ; cc464058 1d623d28
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[160:161], v[26:27], v[144:151] ; cc464090 1e4235a0
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[36:37], v[96:103] ; cc464060 1d824928
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[160:161], v[28:29], v[152:159] ; cc464098 1e6239a0
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[36:37], v[136:143] ; cc464088 1e22492a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[160:161], v[30:31], v[176:183] ; cc4640b0 1ec23da0
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[160:161], v[36:37], v[184:191] ; cc4640b8 1ee249a0
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[162:163], v[26:27], v[50:57] ; cc464032 1cca35a2
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[162:163], v[28:29], v[60:67] ; cc46403c 1cf239a2
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[162:163], v[30:31], v[10:17] ; cc46400a 1c2a3da2
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[162:163], v[36:37], v[120:127] ; cc464078 1de249a2
	ds_load_b64 v[18:19], v24 offset:768                        ; d9d80300 12000018
	ds_load_b64 v[20:21], v24 offset:4864                       ; d9d81300 14000018
	ds_load_b64 v[40:41], v24 offset:8960                       ; d9d82300 28000018
	ds_load_b64 v[42:43], v24 offset:13056                      ; d9d83300 2a000018
	ds_load_b64 v[26:27], v24 offset:1024                       ; d9d80400 1a000018
	ds_load_b64 v[28:29], v24 offset:5120                       ; d9d81400 1c000018
	ds_load_b64 v[30:31], v24 offset:9216                       ; d9d82400 1e000018
	ds_load_b64 v[36:37], v24 offset:13312                      ; d9d83400 24000018
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[164:165], v[38:39], v[72:79] ; cc464048 1d224da4
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[164:165], v[44:45], v[80:87] ; cc464050 1d4259a4
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[164:165], v[46:47], v[88:95] ; cc464058 1d625da4
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[164:165], v[48:49], v[96:103] ; cc464060 1d8261a4
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[166:167], v[38:39], v[104:111] ; cc464068 1da24da6
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[166:167], v[44:45], v[112:119] ; cc464070 1dc259a6
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[166:167], v[46:47], v[128:135] ; cc464080 1e025da6
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[166:167], v[48:49], v[136:143] ; cc464088 1e2261a6
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[68:71], v22, s[36:39], null offen offset:9728 ; c405c07c 40804844 00260016
	buffer_load_b128 v[160:163], v22, s[36:39], null offen offset:2048 ; c405c07c 408048a0 00080016
	buffer_load_b128 v[164:167], v22, s[36:39], null offen offset:10240 ; c405c07c 408048a4 00280016
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[172:173], v[38:39], v[144:151] ; cc464090 1e424dac
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[172:173], v[44:45], v[152:159] ; cc464098 1e6259ac
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[46:47], v[176:183] ; cc4640b0 1ec25dac
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[172:173], v[48:49], v[184:191] ; cc4640b8 1ee261ac
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[174:175], v[38:39], v[50:57] ; cc464032 1cca4dae
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[174:175], v[44:45], v[60:67] ; cc46403c 1cf259ae
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[174:175], v[46:47], v[10:17] ; cc46400a 1c2a5dae
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[174:175], v[48:49], v[120:127] ; cc464078 1de261ae
	ds_load_b64 v[38:39], v24 offset:1280                       ; d9d80500 26000018
	ds_load_b64 v[44:45], v24 offset:5376                       ; d9d81500 2c000018
	ds_load_b64 v[46:47], v24 offset:9472                       ; d9d82500 2e000018
	ds_load_b64 v[48:49], v24 offset:13568                      ; d9d83500 30000018
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[168:169], v[18:19], v[72:79] ; cc464048 1d2225a8
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[168:169], v[20:21], v[80:87] ; cc464050 1d4229a8
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[168:169], v[40:41], v[88:95] ; cc464058 1d6251a8
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[168:169], v[42:43], v[96:103] ; cc464060 1d8255a8
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[170:171], v[18:19], v[104:111] ; cc464068 1da225aa
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[20:21], v[112:119] ; cc464070 1dc229aa
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[170:171], v[40:41], v[128:135] ; cc464080 1e0251aa
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[170:171], v[42:43], v[136:143] ; cc464088 1e2255aa
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[168:171], v22, s[36:39], null offen offset:2560 ; c405c07c 408048a8 000a0016
	buffer_load_b128 v[172:175], v22, s[36:39], null offen offset:10752 ; c405c07c 408048ac 002a0016
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[68:69], v[42:43], v[184:191] ; cc4640b8 1ee25544
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[70:71], v[18:19], v[50:57] ; cc464032 1cca2546
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[68:69], v[40:41], v[176:183] ; cc4640b0 1ec25144
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[20:21], v[152:159] ; cc464098 1e622944
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[70:71], v[20:21], v[60:67] ; cc46403c 1cf22946
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[42:43], v[120:127] ; cc464078 1de25546
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[70:71], v[40:41], v[10:17] ; cc46400a 1c2a5146
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[18:19], v[144:151] ; cc464090 1e422544
	ds_load_b64 v[18:19], v24 offset:1536                       ; d9d80600 12000018
	ds_load_b64 v[20:21], v24 offset:5632                       ; d9d81600 14000018
	ds_load_b64 v[40:41], v24 offset:9728                       ; d9d82600 28000018
	ds_load_b64 v[42:43], v24 offset:13824                      ; d9d83600 2a000018
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[160:161], v[26:27], v[72:79] ; cc464048 1d2235a0
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[30:31], v[88:95] ; cc464058 1d623da0
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[160:161], v[28:29], v[80:87] ; cc464050 1d4239a0
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[160:161], v[36:37], v[96:103] ; cc464060 1d8249a0
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[162:163], v[26:27], v[104:111] ; cc464068 1da235a2
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[162:163], v[28:29], v[112:119] ; cc464070 1dc239a2
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[162:163], v[30:31], v[128:135] ; cc464080 1e023da2
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[162:163], v[36:37], v[136:143] ; cc464088 1e2249a2
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v22, s[36:39], null offen offset:3072 ; c405c07c 40804844 000c0016
	buffer_load_b128 v[160:163], v22, s[36:39], null offen offset:11264 ; c405c07c 408048a0 002c0016
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[164:165], v[28:29], v[152:159] ; cc464098 1e6239a4
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[164:165], v[30:31], v[176:183] ; cc4640b0 1ec23da4
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[164:165], v[36:37], v[184:191] ; cc4640b8 1ee249a4
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[166:167], v[26:27], v[50:57] ; cc464032 1cca35a6
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[166:167], v[28:29], v[60:67] ; cc46403c 1cf239a6
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[164:165], v[26:27], v[144:151] ; cc464090 1e4235a4
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[166:167], v[30:31], v[10:17] ; cc46400a 1c2a3da6
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[166:167], v[36:37], v[120:127] ; cc464078 1de249a6
	ds_load_b64 v[26:27], v24 offset:1792                       ; d9d80700 1a000018
	ds_load_b64 v[28:29], v24 offset:5888                       ; d9d81700 1c000018
	ds_load_b64 v[30:31], v24 offset:9984                       ; d9d82700 1e000018
	ds_load_b64 v[36:37], v24 offset:14080                      ; d9d83700 24000018
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[168:169], v[38:39], v[72:79] ; cc464048 1d224da8
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[168:169], v[44:45], v[80:87] ; cc464050 1d4259a8
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[168:169], v[46:47], v[88:95] ; cc464058 1d625da8
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[168:169], v[48:49], v[96:103] ; cc464060 1d8261a8
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[170:171], v[38:39], v[104:111] ; cc464068 1da24daa
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[44:45], v[112:119] ; cc464070 1dc259aa
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[170:171], v[46:47], v[128:135] ; cc464080 1e025daa
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[170:171], v[48:49], v[136:143] ; cc464088 1e2261aa
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[164:167], v22, s[36:39], null offen offset:3584 ; c405c07c 408048a4 000e0016
	buffer_load_b128 v[168:171], v22, s[36:39], null offen offset:11776 ; c405c07c 408048a8 002e0016
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[172:173], v[44:45], v[152:159] ; cc464098 1e6259ac
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[46:47], v[176:183] ; cc4640b0 1ec25dac
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[172:173], v[38:39], v[144:151] ; cc464090 1e424dac
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[172:173], v[48:49], v[184:191] ; cc4640b8 1ee261ac
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[174:175], v[38:39], v[50:57] ; cc464032 1cca4dae
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[174:175], v[44:45], v[60:67] ; cc46403c 1cf259ae
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[174:175], v[46:47], v[10:17] ; cc46400a 1c2a5dae
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[174:175], v[48:49], v[120:127] ; cc464078 1de261ae
	ds_load_b64 v[38:39], v24 offset:2048                       ; d9d80800 26000018
	ds_load_b64 v[44:45], v24 offset:6144                       ; d9d81800 2c000018
	ds_load_b64 v[46:47], v24 offset:10240                      ; d9d82800 2e000018
	ds_load_b64 v[48:49], v24 offset:14336                      ; d9d83800 30000018
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[40:41], v[128:135] ; cc464080 1e025146
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[42:43], v[96:103] ; cc464060 1d825544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[20:21], v[112:119] ; cc464070 1dc22946
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[20:21], v[80:87] ; cc464050 1d422944
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[42:43], v[136:143] ; cc464088 1e225546
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[18:19], v[104:111] ; cc464068 1da22546
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[68:69], v[18:19], v[72:79] ; cc464048 1d222544
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[40:41], v[88:95] ; cc464058 1d625144
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v22, s[36:39], null offen offset:4096 ; c405c07c 40804844 00100016
	buffer_load_b128 v[172:175], v22, s[36:39], null offen offset:12288 ; c405c07c 408048ac 00300016
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[160:161], v[18:19], v[144:151] ; cc464090 1e4225a0
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[160:161], v[20:21], v[152:159] ; cc464098 1e6229a0
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[160:161], v[42:43], v[184:191] ; cc4640b8 1ee255a0
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[160:161], v[40:41], v[176:183] ; cc4640b0 1ec251a0
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[162:163], v[18:19], v[50:57] ; cc464032 1cca25a2
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[162:163], v[20:21], v[60:67] ; cc46403c 1cf229a2
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[162:163], v[40:41], v[10:17] ; cc46400a 1c2a51a2
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[162:163], v[42:43], v[120:127] ; cc464078 1de255a2
	ds_load_b64 v[18:19], v24 offset:2304                       ; d9d80900 12000018
	ds_load_b64 v[20:21], v24 offset:6400                       ; d9d81900 14000018
	ds_load_b64 v[40:41], v24 offset:10496                      ; d9d82900 28000018
	ds_load_b64 v[42:43], v24 offset:14592                      ; d9d83900 2a000018
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[166:167], v[26:27], v[104:111] ; cc464068 1da235a6
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[164:165], v[30:31], v[88:95] ; cc464058 1d623da4
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[166:167], v[28:29], v[112:119] ; cc464070 1dc239a6
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[164:165], v[36:37], v[96:103] ; cc464060 1d8249a4
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[166:167], v[30:31], v[128:135] ; cc464080 1e023da6
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[166:167], v[36:37], v[136:143] ; cc464088 1e2249a6
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[164:165], v[26:27], v[72:79] ; cc464048 1d2235a4
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[164:165], v[28:29], v[80:87] ; cc464050 1d4239a4
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[160:163], v22, s[36:39], null offen offset:4608 ; c405c07c 408048a0 00120016
	buffer_load_b128 v[164:167], v22, s[36:39], null offen offset:12800 ; c405c07c 408048a4 00320016
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[168:169], v[28:29], v[152:159] ; cc464098 1e6239a8
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[168:169], v[30:31], v[176:183] ; cc4640b0 1ec23da8
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[170:171], v[26:27], v[50:57] ; cc464032 1cca35aa
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[168:169], v[36:37], v[184:191] ; cc4640b8 1ee249a8
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[168:169], v[26:27], v[144:151] ; cc464090 1e4235a8
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[170:171], v[28:29], v[60:67] ; cc46403c 1cf239aa
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[170:171], v[30:31], v[10:17] ; cc46400a 1c2a3daa
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[170:171], v[36:37], v[120:127] ; cc464078 1de249aa
	ds_load_b64 v[26:27], v24 offset:2560                       ; d9d80a00 1a000018
	ds_load_b64 v[28:29], v24 offset:6656                       ; d9d81a00 1c000018
	ds_load_b64 v[30:31], v24 offset:10752                      ; d9d82a00 1e000018
	ds_load_b64 v[36:37], v24 offset:14848                      ; d9d83a00 24000018
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[38:39], v[104:111] ; cc464068 1da24d46
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[48:49], v[96:103] ; cc464060 1d826144
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[44:45], v[112:119] ; cc464070 1dc25946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[46:47], v[128:135] ; cc464080 1e025d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[48:49], v[136:143] ; cc464088 1e226146
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[46:47], v[88:95] ; cc464058 1d625d44
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[68:69], v[38:39], v[72:79] ; cc464048 1d224d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[44:45], v[80:87] ; cc464050 1d425944
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v22, s[36:39], null offen offset:5120 ; c405c07c 40804844 00140016
	buffer_load_b128 v[168:171], v22, s[36:39], null offen offset:13312 ; c405c07c 408048a8 00340016
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[172:173], v[44:45], v[152:159] ; cc464098 1e6259ac
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[46:47], v[176:183] ; cc4640b0 1ec25dac
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[174:175], v[38:39], v[50:57] ; cc464032 1cca4dae
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[172:173], v[48:49], v[184:191] ; cc4640b8 1ee261ac
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[172:173], v[38:39], v[144:151] ; cc464090 1e424dac
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[174:175], v[44:45], v[60:67] ; cc46403c 1cf259ae
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[174:175], v[46:47], v[10:17] ; cc46400a 1c2a5dae
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[174:175], v[48:49], v[120:127] ; cc464078 1de261ae
	ds_load_b64 v[38:39], v24 offset:2816                       ; d9d80b00 26000018
	ds_load_b64 v[44:45], v24 offset:6912                       ; d9d81b00 2c000018
	ds_load_b64 v[46:47], v24 offset:11008                      ; d9d82b00 2e000018
	ds_load_b64 v[48:49], v24 offset:15104                      ; d9d83b00 30000018
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[162:163], v[18:19], v[104:111] ; cc464068 1da225a2
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[160:161], v[42:43], v[96:103] ; cc464060 1d8255a0
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[162:163], v[20:21], v[112:119] ; cc464070 1dc229a2
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[162:163], v[40:41], v[128:135] ; cc464080 1e0251a2
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[40:41], v[88:95] ; cc464058 1d6251a0
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[162:163], v[42:43], v[136:143] ; cc464088 1e2255a2
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[160:161], v[18:19], v[72:79] ; cc464048 1d2225a0
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[160:161], v[20:21], v[80:87] ; cc464050 1d4229a0
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[160:163], v22, s[36:39], null offen offset:5632 ; c405c07c 408048a0 00160016
	buffer_load_b128 v[172:175], v22, s[36:39], null offen offset:13824 ; c405c07c 408048ac 00360016
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[164:165], v[20:21], v[152:159] ; cc464098 1e6229a4
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[164:165], v[40:41], v[176:183] ; cc4640b0 1ec251a4
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[166:167], v[18:19], v[50:57] ; cc464032 1cca25a6
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[164:165], v[42:43], v[184:191] ; cc4640b8 1ee255a4
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[164:165], v[18:19], v[144:151] ; cc464090 1e4225a4
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[166:167], v[20:21], v[60:67] ; cc46403c 1cf229a6
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[166:167], v[40:41], v[10:17] ; cc46400a 1c2a51a6
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[166:167], v[42:43], v[120:127] ; cc464078 1de255a6
	ds_load_b64 v[18:19], v24 offset:3072                       ; d9d80c00 12000018
	ds_load_b64 v[20:21], v24 offset:7168                       ; d9d81c00 14000018
	ds_load_b64 v[40:41], v24 offset:11264                      ; d9d82c00 28000018
	ds_load_b64 v[42:43], v24 offset:15360                      ; d9d83c00 2a000018
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[26:27], v[104:111] ; cc464068 1da23546
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[36:37], v[96:103] ; cc464060 1d824944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[28:29], v[112:119] ; cc464070 1dc23946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[30:31], v[128:135] ; cc464080 1e023d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[36:37], v[136:143] ; cc464088 1e224946
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[30:31], v[88:95] ; cc464058 1d623d44
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[68:69], v[26:27], v[72:79] ; cc464048 1d223544
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[28:29], v[80:87] ; cc464050 1d423944
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v22, s[36:39], null offen offset:6144 ; c405c07c 40804844 00180016
	buffer_load_b128 v[164:167], v22, s[36:39], null offen offset:14336 ; c405c07c 408048a4 00380016
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[168:169], v[28:29], v[152:159] ; cc464098 1e6239a8
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[168:169], v[30:31], v[176:183] ; cc4640b0 1ec23da8
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[170:171], v[26:27], v[50:57] ; cc464032 1cca35aa
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[168:169], v[36:37], v[184:191] ; cc4640b8 1ee249a8
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[168:169], v[26:27], v[144:151] ; cc464090 1e4235a8
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[170:171], v[28:29], v[60:67] ; cc46403c 1cf239aa
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[170:171], v[30:31], v[10:17] ; cc46400a 1c2a3daa
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[170:171], v[36:37], v[120:127] ; cc464078 1de249aa
	ds_load_b64 v[26:27], v24 offset:3328                       ; d9d80d00 1a000018
	ds_load_b64 v[28:29], v24 offset:7424                       ; d9d81d00 1c000018
	ds_load_b64 v[30:31], v24 offset:11520                      ; d9d82d00 1e000018
	ds_load_b64 v[36:37], v24 offset:15616                      ; d9d83d00 24000018
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[162:163], v[38:39], v[104:111] ; cc464068 1da24da2
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[160:161], v[48:49], v[96:103] ; cc464060 1d8261a0
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[162:163], v[44:45], v[112:119] ; cc464070 1dc259a2
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[162:163], v[46:47], v[128:135] ; cc464080 1e025da2
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[162:163], v[48:49], v[136:143] ; cc464088 1e2261a2
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[46:47], v[88:95] ; cc464058 1d625da0
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[160:161], v[38:39], v[72:79] ; cc464048 1d224da0
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[160:161], v[44:45], v[80:87] ; cc464050 1d4259a0
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[160:163], v22, s[36:39], null offen offset:6656 ; c405c07c 408048a0 001a0016
	buffer_load_b128 v[168:171], v22, s[36:39], null offen offset:14848 ; c405c07c 408048a8 003a0016
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[172:173], v[44:45], v[152:159] ; cc464098 1e6259ac
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[46:47], v[176:183] ; cc4640b0 1ec25dac
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[174:175], v[38:39], v[50:57] ; cc464032 1cca4dae
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[172:173], v[48:49], v[184:191] ; cc4640b8 1ee261ac
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[172:173], v[38:39], v[144:151] ; cc464090 1e424dac
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[174:175], v[44:45], v[60:67] ; cc46403c 1cf259ae
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[174:175], v[46:47], v[10:17] ; cc46400a 1c2a5dae
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[174:175], v[48:49], v[120:127] ; cc464078 1de261ae
	ds_load_b64 v[38:39], v24 offset:3584                       ; d9d80e00 26000018
	ds_load_b64 v[44:45], v24 offset:7680                       ; d9d81e00 2c000018
	ds_load_b64 v[46:47], v24 offset:11776                      ; d9d82e00 2e000018
	ds_load_b64 v[48:49], v24 offset:15872                      ; d9d83e00 30000018
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[18:19], v[104:111] ; cc464068 1da22546
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[42:43], v[96:103] ; cc464060 1d825544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[20:21], v[112:119] ; cc464070 1dc22946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[40:41], v[128:135] ; cc464080 1e025146
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[42:43], v[136:143] ; cc464088 1e225546
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[40:41], v[88:95] ; cc464058 1d625144
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[68:69], v[18:19], v[72:79] ; cc464048 1d222544
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[20:21], v[80:87] ; cc464050 1d422944
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v22, s[36:39], null offen offset:7168 ; c405c07c 40804844 001c0016
	buffer_load_b128 v[172:175], v22, s[36:39], null offen offset:15360 ; c405c07c 408048ac 003c0016
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[164:165], v[20:21], v[152:159] ; cc464098 1e6229a4
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[164:165], v[40:41], v[176:183] ; cc4640b0 1ec251a4
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[166:167], v[18:19], v[50:57] ; cc464032 1cca25a6
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[164:165], v[42:43], v[184:191] ; cc4640b8 1ee255a4
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[164:165], v[18:19], v[144:151] ; cc464090 1e4225a4
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[166:167], v[20:21], v[60:67] ; cc46403c 1cf229a6
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[166:167], v[40:41], v[10:17] ; cc46400a 1c2a51a6
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[166:167], v[42:43], v[120:127] ; cc464078 1de255a6
	ds_load_b64 v[18:19], v24 offset:3840                       ; d9d80f00 12000018
	ds_load_b64 v[20:21], v24 offset:7936                       ; d9d81f00 14000018
	ds_load_b64 v[40:41], v24 offset:12032                      ; d9d82f00 28000018
	ds_load_b64 v[42:43], v24 offset:16128                      ; d9d83f00 2a000018
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[162:163], v[26:27], v[104:111] ; cc464068 1da235a2
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[160:161], v[36:37], v[96:103] ; cc464060 1d8249a0
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[162:163], v[28:29], v[112:119] ; cc464070 1dc239a2
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[162:163], v[30:31], v[128:135] ; cc464080 1e023da2
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[162:163], v[36:37], v[136:143] ; cc464088 1e2249a2
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[30:31], v[88:95] ; cc464058 1d623da0
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[160:161], v[26:27], v[72:79] ; cc464048 1d2235a0
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[160:161], v[28:29], v[80:87] ; cc464050 1d4239a0
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[160:163], v22, s[36:39], null offen offset:7680 ; c405c07c 408048a0 001e0016
	buffer_load_b128 v[164:167], v22, s[36:39], null offen offset:15872 ; c405c07c 408048a4 003e0016
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[168:169], v[28:29], v[152:159] ; cc464098 1e6239a8
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[168:169], v[30:31], v[176:183] ; cc4640b0 1ec23da8
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[170:171], v[26:27], v[50:57] ; cc464032 1cca35aa
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[168:169], v[36:37], v[184:191] ; cc4640b8 1ee249a8
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[170:171], v[28:29], v[60:67] ; cc46403c 1cf239aa
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[168:169], v[26:27], v[144:151] ; cc464090 1e4235a8
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[170:171], v[30:31], v[10:17] ; cc46400a 1c2a3daa
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[170:171], v[36:37], v[120:127] ; cc464078 1de249aa
	v_mad_u32_u24 v25, s55, 0x820, v25                          ; d60b0019 0465fe37 00000820
	ds_load_b64 v[26:27], v25                                   ; d9d80000 1a000019
	ds_load_b64 v[28:29], v25 offset:4096                       ; d9d81000 1c000019
	ds_load_b64 v[30:31], v25 offset:8192                       ; d9d82000 1e000019
	ds_load_b64 v[36:37], v25 offset:12288                      ; d9d83000 24000019
	buffer_load_b128 v[168:171], v22, s[36:39], null offen offset:16384 ; c405c07c 408048a8 00400016
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[68:69], v[38:39], v[72:79] ; cc464048 1d224d44
	s_mov_b32 s57, 0x76543210                                   ; beb900ff 76543210
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[44:45], v[80:87] ; cc464050 1d425944
	s_mov_b32 s58, 0xfedcba98                                   ; beba00ff fedcba98
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[46:47], v[88:95] ; cc464058 1d625d44
	s_movk_i32 s59, 0x410                                       ; b03b0410
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[48:49], v[96:103] ; cc464060 1d826144
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[44:45], v[112:119] ; cc464070 1dc25946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[46:47], v[128:135] ; cc464080 1e025d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[48:49], v[136:143] ; cc464088 1e226146
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[38:39], v[104:111] ; cc464068 1da24d46
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[172:173], v[44:45], v[152:159] ; cc464098 1e6259ac
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[172:173], v[38:39], v[144:151] ; cc464090 1e424dac
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[174:175], v[38:39], v[50:57] ; cc464032 1cca4dae
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[174:175], v[44:45], v[60:67] ; cc46403c 1cf259ae
	ds_load_b64 v[68:69], v25 offset:256                        ; d9d80100 44000019
	ds_load_b64 v[70:71], v25 offset:4352                       ; d9d81100 46000019
	ds_load_b64 v[38:39], v25 offset:8448                       ; d9d82100 26000019
	ds_load_b64 v[44:45], v25 offset:12544                      ; d9d83100 2c000019
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[46:47], v[176:183] ; cc4640b0 1ec25dac
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[172:173], v[48:49], v[184:191] ; cc4640b8 1ee261ac
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[174:175], v[46:47], v[10:17] ; cc46400a 1c2a5dae
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[174:175], v[48:49], v[120:127] ; cc464078 1de261ae
	buffer_load_b128 v[172:175], v22, s[36:39], null offen offset:16896 ; c405c07c 408048ac 00420016
	ds_load_b64 v[46:47], v25 offset:512                        ; d9d80200 2e000019
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[40:41], v[88:95] ; cc464058 1d6251a0
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[160:161], v[20:21], v[80:87] ; cc464050 1d4229a0
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[162:163], v[20:21], v[112:119] ; cc464070 1dc229a2
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[160:161], v[42:43], v[96:103] ; cc464060 1d8255a0
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[162:163], v[18:19], v[104:111] ; cc464068 1da225a2
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[160:161], v[18:19], v[72:79] ; cc464048 1d2225a0
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[162:163], v[40:41], v[128:135] ; cc464080 1e0251a2
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[162:163], v[42:43], v[136:143] ; cc464088 1e2255a2
	v_dual_mul_f32 v49, v107, v107 :: v_dual_mul_f32 v48, v105, v105 ; c8c6d76b 3130d369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v49, v75, v75 :: v_dual_fmac_f32 v48, v73, v73 ; c800974b 31309349
	v_dual_fmac_f32 v49, v79, v79 :: v_dual_fmac_f32 v48, v77, v77 ; c8009f4f 31309b4d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v49, v111, v111 :: v_dual_fmac_f32 v48, v109, v109 ; c800df6f 3130db6d
	v_dual_fmac_f32 v49, v74, v74 :: v_dual_fmac_f32 v48, v72, v72 ; c800954a 31309148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v49, v106, v106 :: v_dual_fmac_f32 v48, v104, v104 ; c800d56a 3130d168
	v_dual_fmac_f32 v49, v78, v78 :: v_dual_fmac_f32 v48, v76, v76 ; c8009d4e 3130994c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v49, v110, v110 :: v_dual_fmac_f32 v48, v108, v108 ; c800dd6e 3130d96c
	v_fma_mixlo_f16 v160, 1.0, v48, v49                         ; cc2100a0 04c660f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; d5eb00a1
	v_cndmask_b32_e32 v0, v160, v128, vcc_lo                    ; 020101a0
	v_dual_mul_f32 v24, v115, v115 :: v_dual_mul_f32 v163, v113, v113 ; c8c6e773 18a2e371
	v_permlanex16_b32 v161, v161, s57, s58 op_sel:[1,1]         ; d65c18a1 00e873a1
	v_dual_fmac_f32 v24, v83, v83 :: v_dual_fmac_f32 v163, v81, v81 ; c800a753 18a2a351
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d53200a0
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_dual_fmac_f32 v24, v87, v87 :: v_dual_fmac_f32 v163, v85, v85 ; c800af57 18a2ab55
(invalid instruction)                                        ; d53100a0
	v_cndmask_b32_e32 v1, s59, v160, vcc_lo                     ; 0203403b
	v_dual_fmac_f32 v24, v119, v119 :: v_dual_fmac_f32 v163, v117, v117 ; c800ef77 18a2eb75
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d58b00a2
	v_cndmask_b32_e32 v0, v160, v128, vcc_lo                    ; 020101a0
	v_dual_fmac_f32 v24, v82, v82 :: v_dual_fmac_f32 v163, v80, v80 ; c800a552 18a2a150
	v_rsq_f32_e32 v162, v162                                    ; 7f445da2
	v_dual_fmac_f32 v24, v114, v114 :: v_dual_fmac_f32 v163, v112, v112 ; c800e572 18a2e170
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870125
	v_mul_f32_e32 v162, v162, v9                                ; 114413a2
	v_dual_fmac_f32 v24, v86, v86 :: v_dual_fmac_f32 v163, v84, v84 ; c800ad56 18a2a954
	v_dual_mul_f32 v106, v106, v162 :: v_dual_mul_f32 v107, v107, v162 ; c8c7456a 6a6b456b
	v_dual_mul_f32 v108, v108, v162 :: v_dual_mul_f32 v109, v109, v162 ; c8c7456c 6c6d456d
	v_dual_mul_f32 v111, v111, v162 :: v_dual_mul_f32 v110, v110, v162 ; c8c7456f 6f6f456e
	v_dual_mul_f32 v77, v77, v162 :: v_dual_mul_f32 v76, v76, v162 ; c8c7454d 4d4d454c
	v_dual_mul_f32 v79, v79, v162 :: v_dual_mul_f32 v78, v78, v162 ; c8c7454f 4f4f454e
	v_dual_mul_f32 v73, v73, v162 :: v_dual_mul_f32 v72, v72, v162 ; c8c74549 49494548
	v_dual_mul_f32 v104, v104, v162 :: v_dual_mul_f32 v105, v105, v162 ; c8c74568 68694569
	v_dual_mul_f32 v75, v75, v162 :: v_dual_mul_f32 v74, v74, v162 ; c8c7454b 4b4b454a
	v_dual_fmac_f32 v24, v118, v118 :: v_dual_fmac_f32 v163, v116, v116 ; c800ed76 18a2e974
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_fma_mixlo_f16 v74, 1.0, v163, v24                         ; cc21004a 046346f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v75, v74                                  ; 7e96d74a
	v_permlanex16_b32 v75, v75, s57, s58 op_sel:[1,1]           ; d65c184b 00e8734b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v74, v74, v75                                 ; 6494974a
	v_max_num_f16_e32 v74, s59, v74                             ; 6294943b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v76, v74                                  ; 7e98174a
	v_rsq_f32_e32 v76, v76                                      ; 7e985d4c
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v76, v76, v9                                  ; 1098134c
	v_dual_mul_f32 v84, v84, v76 :: v_dual_mul_f32 v85, v85, v76 ; c8c69954 54549955
	v_dual_mul_f32 v119, v119, v76 :: v_dual_mul_f32 v118, v118, v76 ; c8c69977 77769976
	v_dual_mul_f32 v87, v87, v76 :: v_dual_mul_f32 v86, v86, v76 ; c8c69957 57569956
	v_dual_mul_f32 v112, v112, v76 :: v_dual_mul_f32 v113, v113, v76 ; c8c69970 70709971
	v_dual_mul_f32 v80, v80, v76 :: v_dual_mul_f32 v81, v81, v76 ; c8c69950 50509951
	v_dual_mul_f32 v82, v82, v76 :: v_dual_mul_f32 v83, v83, v76 ; c8c69952 52529953
	v_dual_mul_f32 v114, v114, v76 :: v_dual_mul_f32 v115, v115, v76 ; c8c69972 72729973
	v_dual_mul_f32 v116, v116, v76 :: v_dual_mul_f32 v117, v117, v76 ; c8c69974 74749975
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_dual_mul_f32 v80, v131, v131 :: v_dual_mul_f32 v77, v129, v129 ; c8c70783 504d0381
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_fmac_f32 v80, v91, v91 :: v_dual_fmac_f32 v77, v89, v89 ; c800b75b 504cb359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v80, v95, v95 :: v_dual_fmac_f32 v77, v93, v93 ; c800bf5f 504cbb5d
	v_dual_fmac_f32 v80, v135, v135 :: v_dual_fmac_f32 v77, v133, v133 ; c8010f87 504d0b85
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v80, v90, v90 :: v_dual_fmac_f32 v77, v88, v88 ; c800b55a 504cb158
	v_dual_fmac_f32 v80, v130, v130 :: v_dual_fmac_f32 v77, v128, v128 ; c8010582 504d0180
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v80, v94, v94 :: v_dual_fmac_f32 v77, v92, v92 ; c800bd5e 504cb95c
	v_dual_fmac_f32 v80, v134, v134 :: v_dual_fmac_f32 v77, v132, v132 ; c8010d86 504d0984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v81, 1.0, v77, v80                          ; cc210051 05429af2
	v_cvt_u32_u16_e32 v82, v81                                  ; 7ea4d751
	v_dual_mul_f32 v85, v139, v139 :: v_dual_mul_f32 v84, v137, v137 ; c8c7178b 55551389
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_permlanex16_b32 v82, v82, s57, s58 op_sel:[1,1]           ; d65c1852 00e87352
	v_dual_fmac_f32 v85, v99, v99 :: v_dual_fmac_f32 v84, v97, v97 ; c800c763 5554c361
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[164:165], v[18:19], v[144:151] ; cc464090 1e4225a4
	v_add_f16_e32 v81, v81, v82                                 ; 64a2a551
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[164:165], v[20:21], v[152:159] ; cc464098 1e6229a4
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[164:165], v[40:41], v[176:183] ; cc4640b0 1ec251a4
	v_max_num_f16_e32 v81, s59, v81                             ; 62a2a23b
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[164:165], v[42:43], v[184:191] ; cc4640b8 1ee255a4
	v_wmma_f32_16x16x16_fp8_fp8 v[50:57], v[166:167], v[18:19], v[50:57] ; cc464032 1cca25a6
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[166:167], v[20:21], v[60:67] ; cc46403c 1cf229a6
	v_cvt_f32_f16_e32 v83, v81                                  ; 7ea61751
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[166:167], v[40:41], v[10:17] ; cc46400a 1c2a51a6
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[166:167], v[42:43], v[120:127] ; cc464078 1de255a6
	v_dual_fmac_f32 v85, v103, v103 :: v_dual_fmac_f32 v84, v101, v101 ; c800cf67 5554cb65
	v_rsq_f32_e32 v83, v83                                      ; 7ea65d53
	v_dual_fmac_f32 v85, v143, v143 :: v_dual_fmac_f32 v84, v141, v141 ; c8011f8f 55551b8d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmac_f32 v85, v98, v98 :: v_dual_fmac_f32 v84, v96, v96 ; c800c562 5554c160
	v_mul_f32_e32 v83, v83, v9                                  ; 10a61353
	v_dual_fmac_f32 v85, v138, v138 :: v_dual_fmac_f32 v84, v136, v136 ; c801158a 55551188
	v_dual_mul_f32 v95, v95, v83 :: v_dual_mul_f32 v94, v94, v83 ; c8c6a75f 5f5ea75e
	v_dual_mul_f32 v129, v129, v83 :: v_dual_mul_f32 v128, v128, v83 ; c8c6a781 8180a780
	v_dual_mul_f32 v131, v131, v83 :: v_dual_mul_f32 v130, v130, v83 ; c8c6a783 8382a782
	v_dual_mul_f32 v90, v90, v83 :: v_dual_mul_f32 v91, v91, v83 ; c8c6a75a 5a5aa75b
	v_dual_mul_f32 v133, v133, v83 :: v_dual_mul_f32 v132, v132, v83 ; c8c6a785 8584a784
	v_dual_mul_f32 v88, v88, v83 :: v_dual_mul_f32 v89, v89, v83 ; c8c6a758 5858a759
	v_dual_mul_f32 v135, v135, v83 :: v_dual_mul_f32 v134, v134, v83 ; c8c6a787 8786a786
	v_dual_mul_f32 v92, v92, v83 :: v_dual_mul_f32 v93, v93, v83 ; c8c6a75c 5c5ca75d
	v_dual_fmac_f32 v85, v102, v102 :: v_dual_fmac_f32 v84, v100, v100 ; c800cd66 5554c964
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_dual_fmac_f32 v85, v142, v142 :: v_dual_fmac_f32 v84, v140, v140 ; c8011d8e 5555198c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v86, 1.0, v84, v85                          ; cc210056 0556a8f2
	v_cvt_u32_u16_e32 v87, v86                                  ; 7eaed756
	v_dual_mul_f32 v90, v53, v53 :: v_dual_mul_f32 v89, v51, v51 ; c8c66b35 5a586733
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v87, v87, s57, s58 op_sel:[1,1]           ; d65c1857 00e87357
	v_dual_fmac_f32 v90, v147, v147 :: v_dual_fmac_f32 v89, v145, v145 ; c8012793 5a592391
	v_add_f16_e32 v86, v86, v87                                 ; 64acaf56
	v_dual_fmac_f32 v90, v151, v151 :: v_dual_fmac_f32 v89, v149, v149 ; c8012f97 5a592b95
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_max_num_f16_e32 v86, s59, v86                             ; 62acac3b
	v_dual_fmac_f32 v90, v57, v57 :: v_dual_fmac_f32 v89, v55, v55 ; c8007339 5a586f37
	v_cvt_f32_f16_e32 v88, v86                                  ; 7eb01756
	v_dual_fmac_f32 v90, v146, v146 :: v_dual_fmac_f32 v89, v144, v144 ; c8012592 5a592190
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a2
	v_rsq_f32_e32 v88, v88                                      ; 7eb05d58
	v_dual_fmac_f32 v90, v52, v52 :: v_dual_fmac_f32 v89, v50, v50 ; c8006934 5a586532
	v_mul_f32_e32 v88, v88, v9                                  ; 10b01358
	v_dual_fmac_f32 v90, v150, v150 :: v_dual_fmac_f32 v89, v148, v148 ; c8012d96 5a592994
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v136, v136, v88 :: v_dual_mul_f32 v137, v137, v88 ; c8c6b188 8888b189
	v_dual_mul_f32 v140, v140, v88 :: v_dual_mul_f32 v141, v141, v88 ; c8c6b18c 8c8cb18d
	v_dual_mul_f32 v97, v97, v88 :: v_dual_mul_f32 v96, v96, v88 ; c8c6b161 6160b160
	v_dual_mul_f32 v143, v143, v88 :: v_dual_mul_f32 v142, v142, v88 ; c8c6b18f 8f8eb18e
	v_dual_mul_f32 v138, v138, v88 :: v_dual_mul_f32 v139, v139, v88 ; c8c6b18a 8a8ab18b
	v_dual_mul_f32 v99, v99, v88 :: v_dual_mul_f32 v98, v98, v88 ; c8c6b163 6362b162
	v_dual_mul_f32 v101, v101, v88 :: v_dual_mul_f32 v100, v100, v88 ; c8c6b165 6564b164
	v_dual_mul_f32 v103, v103, v88 :: v_dual_mul_f32 v102, v102, v88 ; c8c6b167 6766b166
	v_dual_fmac_f32 v90, v56, v56 :: v_dual_fmac_f32 v89, v54, v54 ; c8007138 5a586d36
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	buffer_load_b128 v[80:83], v22, s[36:39], null offen offset:17408 ; c405c07c 40804850 00440016
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mixlo_f16 v91, 1.0, v89, v90                          ; cc21005b 056ab2f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v92, v91                                  ; 7eb8d75b
	v_permlanex16_b32 v92, v92, s57, s58 op_sel:[1,1]           ; d65c185c 00e8735c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v91, v91, v92                                 ; 64b6b95b
	v_max_num_f16_e32 v91, s59, v91                             ; 62b6b63b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
	v_cvt_f32_f16_e32 v93, v91                                  ; 7eba175b
	buffer_load_b128 v[84:87], v22, s[36:39], null offen offset:17920 ; c405c07c 40804854 00460016
	v_mul_f32_e32 v94, v61, v61                                 ; 10bc7b3d
	v_rsq_f32_e32 v93, v93                                      ; 7eba5d5d
	v_fmac_f32_e32 v94, v153, v153                              ; 56bd3399
	v_dual_fmac_f32 v94, v157, v157 :: v_dual_mul_f32 v95, v63, v63 ; c8073b9d 5e5e7f3f
	v_dual_mul_f32 v144, v144, v93 :: v_dual_mul_f32 v145, v145, v93 ; c8c6bb90 9090bb91
	v_dual_mul_f32 v151, v151, v93 :: v_dual_mul_f32 v150, v150, v93 ; c8c6bb97 9796bb96
	v_dual_mul_f32 v51, v51, v93 :: v_dual_mul_f32 v50, v50, v93 ; c8c6bb33 3332bb32
	v_dual_mul_f32 v53, v53, v93 :: v_dual_mul_f32 v52, v52, v93 ; c8c6bb35 3534bb34
	v_dual_mul_f32 v55, v55, v93 :: v_dual_mul_f32 v54, v54, v93 ; c8c6bb37 3736bb36
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	buffer_load_b128 v[52:55], v22, s[36:39], null offen offset:18432 ; c405c07c 40804834 00480016
	v_dual_mul_f32 v57, v57, v93 :: v_dual_mul_f32 v56, v56, v93 ; c8c6bb39 3938bb38
	v_dual_mul_f32 v146, v146, v93 :: v_dual_mul_f32 v147, v147, v93 ; c8c6bb92 9292bb93
	v_dual_mul_f32 v149, v149, v93 :: v_dual_mul_f32 v148, v148, v93 ; c8c6bb95 9594bb94
	v_dual_fmac_f32 v94, v65, v65 :: v_dual_fmac_f32 v95, v155, v155 ; c8008341 5e5f379b
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	buffer_load_b128 v[88:91], v22, s[36:39], null offen offset:18944 ; c405c07c 40804858 004a0016
	v_dual_fmac_f32 v94, v152, v152 :: v_dual_fmac_f32 v95, v159, v159 ; c8013198 5e5f3f9f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v94, v60, v60 :: v_dual_fmac_f32 v95, v67, v67 ; c800793c 5e5e8743
	v_fmac_f32_e32 v95, v154, v154                              ; 56bf359a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v95, v62, v62                                ; 56be7d3e
	v_dual_fmac_f32 v95, v158, v158 :: v_dual_fmac_f32 v94, v156, v156 ; c8013d9e 5f5f399c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v95, v66, v66 :: v_dual_fmac_f32 v94, v64, v64 ; c8008542 5f5e8140
	v_fma_mixlo_f16 v96, 1.0, v94, v95                          ; cc210060 057ebcf2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v97, v96                                  ; 7ec2d760
	v_permlanex16_b32 v97, v97, s57, s58 op_sel:[1,1]           ; d65c1861 00e87361
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_add_f16_e32 v96, v96, v97                                 ; 64c0c360
	buffer_load_b128 v[92:95], v22, s[36:39], null offen offset:19456 ; c405c07c 4080485c 004c0016
	v_max_num_f16_e32 v96, s59, v96                             ; 62c0c03b
	v_cvt_f32_f16_e32 v98, v96                                  ; 7ec41760
	v_dual_mul_f32 v99, v11, v11 :: v_dual_mul_f32 v100, v13, v13 ; c8c6170b 63641b0d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870292
	v_rsq_f32_e32 v98, v98                                      ; 7ec45d62
	v_dual_mul_f32 v60, v60, v98 :: v_dual_mul_f32 v159, v159, v98 ; c8c6c53c 3c9ec59f
	v_dual_mul_f32 v156, v156, v98 :: v_dual_mul_f32 v155, v155, v98 ; c8c6c59c 9c9ac59b
	v_mul_f32_e32 v154, v154, v98                               ; 1134c59a
	v_dual_fmac_f32 v99, v177, v177 :: v_dual_mul_f32 v64, v64, v98 ; c80763b1 6340c540
	v_dual_mul_f32 v153, v153, v98 :: v_dual_mul_f32 v152, v152, v98 ; c8c6c599 9998c598
	v_mul_f32_e32 v67, v67, v98                                 ; 1086c543
	v_dual_mul_f32 v62, v62, v98 :: v_dual_mul_f32 v61, v61, v98 ; c8c6c53e 3e3cc53d
	v_mul_f32_e32 v65, v65, v98                                 ; 1082c541
	v_dual_fmac_f32 v99, v181, v181 :: v_dual_fmac_f32 v100, v179, v179 ; c8016bb5 636567b3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_dual_fmac_f32 v99, v15, v15 :: v_dual_mul_f32 v66, v66, v98 ; c8061f0f 6342c542
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	buffer_load_b128 v[64:67], v22, s[36:39], null offen offset:19968 ; c405c07c 40804840 004e0016
	v_mul_f32_e32 v63, v63, v98                                 ; 107ec53f
	v_dual_mul_f32 v158, v158, v98 :: v_dual_mul_f32 v157, v157, v98 ; c8c6c59e 9e9cc59d
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_fmac_f32_e32 v100, v183, v183                             ; 56c96fb7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v100, v17, v17                               ; 56c82311
	v_dual_fmac_f32 v100, v178, v178 :: v_dual_fmac_f32 v99, v176, v176 ; c80165b2 646361b0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v100, v12, v12 :: v_dual_fmac_f32 v99, v10, v10 ; c800190c 6462150a
	v_dual_fmac_f32 v100, v182, v182 :: v_dual_fmac_f32 v99, v180, v180 ; c8016db6 646369b4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v100, v16, v16 :: v_dual_fmac_f32 v99, v14, v14 ; c8002110 64621d0e
	v_fma_mixlo_f16 v101, 1.0, v99, v100                        ; cc210065 0592c6f2
	buffer_load_b128 v[96:99], v22, s[36:39], null offen offset:20480 ; c405c07c 40804860 00500016
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	buffer_load_b128 v[104:107], v22, s[36:39], null offen offset:20992 ; c405c07c 40804868 00520016
	v_cvt_u32_u16_e32 v102, v101                                ; 7eccd765
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v102, v102, s57, s58 op_sel:[1,1]         ; d65c1866 00e87366
	v_add_f16_e32 v101, v101, v102                              ; 64cacd65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v101, s59, v101                           ; 62caca3b
	v_cvt_f32_f16_e32 v103, v101                                ; 7ece1765
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v103, v103                                    ; 7ece5d67
	v_dual_mul_f32 v14, v14, v103 :: v_dual_mul_f32 v13, v13, v103 ; c8c6cf0e 0e0ccf0d
	v_dual_mul_f32 v16, v16, v103 :: v_dual_mul_f32 v17, v17, v103 ; c8c6cf10 1010cf11
	v_mul_f32_e32 v12, v12, v103                                ; 1018cf0c
	v_dual_mul_f32 v181, v181, v103 :: v_dual_mul_f32 v180, v180, v103 ; c8c6cfb5 b5b4cfb4
	v_mul_f32_e32 v10, v10, v103                                ; 1014cf0a
	v_dual_mul_f32 v108, v121, v121 :: v_dual_mul_f32 v11, v11, v103 ; c8c6f379 6c0acf0b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
	v_dual_fmac_f32 v108, v185, v185 :: v_dual_mul_f32 v15, v15, v103 ; c80773b9 6c0ecf0f
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
	buffer_load_b128 v[12:15], v22, s[36:39], null offen offset:21504 ; c405c07c 4080480c 00540016
	v_dual_mul_f32 v177, v177, v103 :: v_dual_mul_f32 v176, v176, v103 ; c8c6cfb1 b1b0cfb0
	v_dual_mul_f32 v183, v183, v103 :: v_dual_mul_f32 v182, v182, v103 ; c8c6cfb7 b7b6cfb6
	v_dual_mul_f32 v179, v179, v103 :: v_dual_mul_f32 v178, v178, v103 ; c8c6cfb3 b3b2cfb2
	v_mul_f32_e32 v109, v123, v123                              ; 10daf77b
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_fmac_f32_e32 v109, v187, v187                             ; 56db77bb
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v109, v191, v191 :: v_dual_fmac_f32 v108, v189, v189 ; c8017fbf 6d6d7bbd
	v_dual_fmac_f32 v109, v127, v127 :: v_dual_fmac_f32 v108, v125, v125 ; c800ff7f 6d6cfb7d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v109, v186, v186 :: v_dual_fmac_f32 v108, v184, v184 ; c80175ba 6d6d71b8
	v_dual_fmac_f32 v109, v122, v122 :: v_dual_fmac_f32 v108, v120, v120 ; c800f57a 6d6cf178
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v109, v190, v190 :: v_dual_fmac_f32 v108, v188, v188 ; c8017dbe 6d6d79bc
	v_dual_fmac_f32 v109, v126, v126 :: v_dual_fmac_f32 v108, v124, v124 ; c800fd7e 6d6cf97c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v110, 1.0, v108, v109                       ; cc21006e 05b6d8f2
	v_cvt_u32_u16_e32 v111, v110                                ; 7eded76e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v111, v111, s57, s58 op_sel:[1,1]         ; d65c186f 00e8736f
	v_add_f16_e32 v110, v110, v111                              ; 64dcdf6e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v110, s59, v110                           ; 62dcdc3b
	v_cvt_f32_f16_e32 v112, v110                                ; 7ee0176e
	ds_load_b64 v[102:103], v25 offset:4608                     ; d9d81200 66000019
	ds_load_b64 v[108:109], v25 offset:8704                     ; d9d82200 6c000019
	ds_load_b64 v[110:111], v25 offset:12800                    ; d9d83200 6e000019
	v_rsq_f32_e32 v112, v112                                    ; 7ee05d70
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v187, v187, v112 :: v_dual_mul_f32 v186, v186, v112 ; c8c6e1bb bbbae1ba
	v_dual_mul_f32 v185, v185, v112 :: v_dual_mul_f32 v184, v184, v112 ; c8c6e1b9 b9b8e1b8
	v_dual_mul_f32 v125, v125, v112 :: v_dual_mul_f32 v124, v124, v112 ; c8c6e17d 7d7ce17c
	v_dual_mul_f32 v123, v123, v112 :: v_dual_mul_f32 v122, v122, v112 ; c8c6e17b 7b7ae17a
	v_dual_mul_f32 v121, v121, v112 :: v_dual_mul_f32 v120, v120, v112 ; c8c6e179 7978e178
	v_dual_mul_f32 v189, v189, v112 :: v_dual_mul_f32 v188, v188, v112 ; c8c6e1bd bdbce1bc
	v_dual_mul_f32 v127, v127, v112 :: v_dual_mul_f32 v126, v126, v112 ; c8c6e17f 7f7ee17e
	v_dual_mul_f32 v191, v191, v112 :: v_dual_mul_f32 v190, v190, v112 ; c8c6e1bf bfbee1be
	ds_load_b64 v[112:113], v25 offset:768                      ; d9d80300 70000019
	ds_load_b64 v[114:115], v25 offset:4864                     ; d9d81300 72000019
	ds_load_b64 v[116:117], v25 offset:8960                     ; d9d82300 74000019
	ds_load_b64 v[118:119], v25 offset:13056                    ; d9d83300 76000019
	s_wait_loadcnt_dscnt 0xa0e                                  ; bfc80a0e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[28:29], v[168:169], 0 ; cc464080 1a03511c
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[168:169], 0 ; cc464088 1a03511e
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[168:169], 0 ; cc464090 1a035124
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[26:27], v[170:171], 0 ; cc464098 1a03551a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[28:29], v[170:171], 0 ; cc4640a0 1a03551c
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694064
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[170:171], 0 ; cc4640b0 1a03551e
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[168:169], 0 ; cc464078 1a03511a
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[36:37], v[170:171], 0 ; cc4640b8 1a035524
	s_wait_loadcnt_dscnt 0x90a                                  ; bfc8090a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[172:173], v[128:135] ; cc464080 1e035946
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[38:39], v[172:173], v[136:143] ; cc464088 1e235926
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[44:45], v[172:173], v[144:151] ; cc464090 1e43592c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[174:175], v[152:159] ; cc464098 1e635d44
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[70:71], v[174:175], v[160:167] ; cc4640a0 1e835d46
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[174:175], v[176:183] ; cc4640b0 1ec35d26
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[172:173], v[120:127] ; cc464078 1de35944
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[44:45], v[174:175], v[184:191] ; cc4640b8 1ee35d2c
	ds_load_b64 v[26:27], v25 offset:1024                       ; d9d80400 1a000019
	ds_load_b64 v[28:29], v25 offset:5120                       ; d9d81400 1c000019
	ds_load_b64 v[30:31], v25 offset:9216                       ; d9d82400 1e000019
	ds_load_b64 v[36:37], v25 offset:13312                      ; d9d83400 24000019
	ds_load_b64 v[38:39], v25 offset:1280                       ; d9d80500 26000019
	ds_load_b64 v[44:45], v25 offset:5376                       ; d9d81500 2c000019
	ds_load_b64 v[68:69], v25 offset:9472                       ; d9d82500 44000019
	ds_load_b64 v[70:71], v25 offset:13568                      ; d9d83500 46000019
	s_wait_loadcnt_dscnt 0x80e                                  ; bfc8080e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[102:103], v[80:81], v[128:135] ; cc464080 1e02a166
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[80:81], v[136:143] ; cc464088 1e22a16c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[110:111], v[80:81], v[144:151] ; cc464090 1e42a16e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[82:83], v[152:159] ; cc464098 1e62a52e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[102:103], v[82:83], v[160:167] ; cc4640a0 1e82a566
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[108:109], v[82:83], v[176:183] ; cc4640b0 1ec2a56c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[80:81], v[120:127] ; cc464078 1de2a12e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[82:83], v[184:191] ; cc4640b8 1ee2a56e
	ds_load_b64 v[46:47], v25 offset:1536                       ; d9d80600 2e000019
	ds_load_b64 v[80:81], v25 offset:5632                       ; d9d81600 50000019
	ds_load_b64 v[82:83], v25 offset:9728                       ; d9d82600 52000019
	ds_load_b64 v[102:103], v25 offset:13824                    ; d9d83600 66000019
	s_wait_loadcnt_dscnt 0x70e                                  ; bfc8070e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[114:115], v[84:85], v[128:135] ; cc464080 1e02a972
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[116:117], v[84:85], v[136:143] ; cc464088 1e22a974
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[118:119], v[84:85], v[144:151] ; cc464090 1e42a976
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[86:87], v[152:159] ; cc464098 1e62ad70
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[112:113], v[84:85], v[120:127] ; cc464078 1de2a970
	v_dual_mov_b32 v113, v87 :: v_dual_mov_b32 v112, v86        ; ca100157 71700156
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[108:111], v22, s[36:39], null offen offset:22016 ; c405c07c 4080486c 00560016
	buffer_load_b128 v[168:171], v22, s[36:39], null offen offset:22528 ; c405c07c 408048a8 00580016
	buffer_load_b128 v[172:175], v22, s[36:39], null offen offset:23040 ; c405c07c 408048ac 005a0016
	buffer_load_b128 v[84:87], v22, s[36:39], null offen offset:23552 ; c405c07c 40804854 005c0016
	s_wait_loadcnt_dscnt 0xa0a                                  ; bfc80a0a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[28:29], v[52:53], v[128:135] ; cc464080 1e02691c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[52:53], v[136:143] ; cc464088 1e22691e
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[52:53], v[144:151] ; cc464090 1e426924
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[26:27], v[54:55], v[152:159] ; cc464098 1e626d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[116:117], v[112:113], v[176:183] ; cc4640b0 1ec2e174
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[112:113], v[184:191] ; cc4640b8 1ee2e176
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[114:115], v[112:113], v[160:167] ; cc4640a0 1e82e172
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[52:53], v[120:127] ; cc464078 1de2691a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[54:55], v[176:183] ; cc4640b0 1ec26d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[36:37], v[54:55], v[184:191] ; cc4640b8 1ee26d24
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[28:29], v[54:55], v[160:167] ; cc4640a0 1e826d1c
	ds_load_b64 v[112:113], v25 offset:1792                     ; d9d80700 70000019
	ds_load_b64 v[114:115], v25 offset:5888                     ; d9d81700 72000019
	ds_load_b64 v[116:117], v25 offset:9984                     ; d9d82700 74000019
	ds_load_b64 v[118:119], v25 offset:14080                    ; d9d83700 76000019
	ds_load_b64 v[26:27], v25 offset:2048                       ; d9d80800 1a000019
	ds_load_b64 v[28:29], v25 offset:6144                       ; d9d81800 1c000019
	ds_load_b64 v[30:31], v25 offset:10240                      ; d9d82800 1e000019
	ds_load_b64 v[36:37], v25 offset:14336                      ; d9d83800 24000019
	s_wait_loadcnt_dscnt 0x90e                                  ; bfc8090e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[44:45], v[88:89], v[128:135] ; cc464080 1e02b12c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[38:39], v[90:91], v[152:159] ; cc464098 1e62b526
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[88:89], v[120:127] ; cc464078 1de2b126
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[44:45], v[90:91], v[160:167] ; cc4640a0 1e82b52c
	ds_load_b64 v[38:39], v25 offset:2304                       ; d9d80900 26000019
	ds_load_b64 v[44:45], v25 offset:6400                       ; d9d81900 2c000019
	ds_load_b64 v[52:53], v25 offset:10496                      ; d9d82900 34000019
	ds_load_b64 v[54:55], v25 offset:14592                      ; d9d83900 36000019
	s_wait_dscnt 0x11                                           ; bfc60011
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[88:89], v[136:143] ; cc464088 1e22b144
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[88:89], v[144:151] ; cc464090 1e42b146
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[68:69], v[90:91], v[176:183] ; cc4640b0 1ec2b544
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[90:91], v[184:191] ; cc4640b8 1ee2b546
	s_wait_loadcnt_dscnt 0x80e                                  ; bfc8080e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[92:93], v[128:135] ; cc464080 1e02b950
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[94:95], v[152:159] ; cc464098 1e62bd2e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[92:93], v[120:127] ; cc464078 1de2b92e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[80:81], v[94:95], v[160:167] ; cc4640a0 1e82bd50
	ds_load_b64 v[46:47], v25 offset:2560                       ; d9d80a00 2e000019
	ds_load_b64 v[68:69], v25 offset:6656                       ; d9d81a00 44000019
	ds_load_b64 v[70:71], v25 offset:10752                      ; d9d82a00 46000019
	ds_load_b64 v[80:81], v25 offset:14848                      ; d9d83a00 50000019
	s_wait_dscnt 0x11                                           ; bfc60011
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[82:83], v[92:93], v[136:143] ; cc464088 1e22b952
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[102:103], v[92:93], v[144:151] ; cc464090 1e42b966
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[82:83], v[94:95], v[176:183] ; cc4640b0 1ec2bd52
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[102:103], v[94:95], v[184:191] ; cc4640b8 1ee2bd66
	s_wait_loadcnt_dscnt 0x70e                                  ; bfc8070e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[114:115], v[64:65], v[128:135] ; cc464080 1e028172
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[66:67], v[152:159] ; cc464098 1e628570
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[112:113], v[64:65], v[120:127] ; cc464078 1de28170
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[114:115], v[66:67], v[160:167] ; cc4640a0 1e828572
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[116:117], v[64:65], v[136:143] ; cc464088 1e228174
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[118:119], v[64:65], v[144:151] ; cc464090 1e428176
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[116:117], v[66:67], v[176:183] ; cc4640b0 1ec28574
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[66:67], v[184:191] ; cc4640b8 1ee28576
	s_wait_loadcnt_dscnt 0x60a                                  ; bfc8060a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[28:29], v[96:97], v[128:135] ; cc464080 1e02c11c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[26:27], v[98:99], v[152:159] ; cc464098 1e62c51a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[96:97], v[120:127] ; cc464078 1de2c11a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[28:29], v[98:99], v[160:167] ; cc4640a0 1e82c51c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[96:97], v[136:143] ; cc464088 1e22c11e
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[96:97], v[144:151] ; cc464090 1e42c124
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[98:99], v[176:183] ; cc4640b0 1ec2c51e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[36:37], v[98:99], v[184:191] ; cc4640b8 1ee2c524
	ds_load_b64 v[64:65], v25 offset:2816                       ; d9d80b00 40000019
	ds_load_b64 v[66:67], v25 offset:6912                       ; d9d81b00 42000019
	ds_load_b64 v[82:83], v25 offset:11008                      ; d9d82b00 52000019
	ds_load_b64 v[88:89], v25 offset:15104                      ; d9d83b00 58000019
	ds_load_b64 v[26:27], v25 offset:3072                       ; d9d80c00 1a000019
	ds_load_b64 v[28:29], v25 offset:7168                       ; d9d81c00 1c000019
	ds_load_b64 v[30:31], v25 offset:11264                      ; d9d82c00 1e000019
	ds_load_b64 v[36:37], v25 offset:15360                      ; d9d83c00 24000019
	ds_load_b64 v[90:91], v25 offset:3328                       ; d9d80d00 5a000019
	ds_load_b64 v[92:93], v25 offset:7424                       ; d9d81d00 5c000019
	ds_load_b64 v[94:95], v25 offset:11520                      ; d9d82d00 5e000019
	ds_load_b64 v[96:97], v25 offset:15616                      ; d9d83d00 60000019
	ds_load_b64 v[98:99], v25 offset:3584                       ; d9d80e00 62000019
	ds_load_b64 v[102:103], v25 offset:7680                     ; d9d81e00 66000019
	ds_load_b64 v[112:113], v25 offset:11776                    ; d9d82e00 70000019
	ds_load_b64 v[114:115], v25 offset:15872                    ; d9d83e00 72000019
	ds_load_b64 v[116:117], v25 offset:3840                     ; d9d80f00 74000019
	ds_load_b64 v[118:119], v25 offset:7936                     ; d9d81f00 76000019
	s_wait_loadcnt_dscnt 0x519                                  ; bfc80519
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[104:105], v[120:127] ; cc464078 1de2d126
	s_wait_dscnt 0x18                                           ; bfc60018
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[44:45], v[104:105], v[128:135] ; cc464080 1e02d12c
	s_wait_dscnt 0x17                                           ; bfc60017
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[104:105], v[136:143] ; cc464088 1e22d134
	s_wait_dscnt 0x16                                           ; bfc60016
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[104:105], v[144:151] ; cc464090 1e42d136
	ds_load_b64 v[104:105], v25 offset:12032                    ; d9d82f00 68000019
	ds_load_b64 v[24:25], v25 offset:16128                      ; d9d83f00 18000019
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[38:39], v[106:107], v[152:159] ; cc464098 1e62d526
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[44:45], v[106:107], v[160:167] ; cc4640a0 1e82d52c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_dual_mov_b32 v45, v37 :: v_dual_mov_b32 v44, v36          ; ca100125 2d2c0124
	buffer_load_b128 v[36:39], v22, s[36:39], null offen offset:24064 ; c405c07c 40804824 005e0016
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[52:53], v[106:107], v[176:183] ; cc4640b0 1ec2d534
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[106:107], v[184:191] ; cc4640b8 1ee2d536
	v_lshl_add_u32 v1, v1, 12, s7                               ; d6460001 001d1901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v4, v4, 6, v1                                ; d6460004 04050d04
	v_add_lshl_u32 v4, v4, v3, 2                                ; d6470004 020a0704
	buffer_load_b128 v[52:55], v4, s[32:35], null offen         ; c405c07c 40804034 00000004
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[12:13], v[120:127] ; cc464078 1de2192e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[12:13], v[128:135] ; cc464080 1e021944
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[12:13], v[136:143] ; cc464088 1e221946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[80:81], v[12:13], v[144:151] ; cc464090 1e421950
	s_wait_dscnt 0x1                                            ; bfc60001
	v_mov_b32_e32 v13, v105                                     ; 7e1a0369
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[14:15], v[152:159] ; cc464098 1e621d2e
	v_dual_mov_b32 v47, v79 :: v_dual_mov_b32 v12, v104         ; ca10014f 2f0c0168
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[14:15], v[160:167] ; cc4640a0 1e821d44
	v_dual_mov_b32 v9, v33 :: v_dual_mov_b32 v46, v78           ; ca100121 092e014e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[14:15], v[176:183] ; cc4640b0 1ec21d46
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[80:81], v[14:15], v[184:191] ; cc4640b8 1ee21d50
	v_mov_b32_e32 v15, v77                                      ; 7e1e034d
	v_dual_mov_b32 v1, v32 :: v_dual_mov_b32 v14, v76           ; ca100120 010e014c
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[108:109], v[120:127] ; cc464078 1de2d940
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[108:109], v[128:135] ; cc464080 1e02d942
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[82:83], v[108:109], v[136:143] ; cc464088 1e22d952
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[88:89], v[108:109], v[144:151] ; cc464090 1e42d958
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[110:111], v[152:159] ; cc464098 1e62dd40
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[110:111], v[160:167] ; cc4640a0 1e82dd42
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[82:83], v[110:111], v[176:183] ; cc4640b0 1ec2dd52
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[42:43], v[48:49], 0 ; cc464040 1a02612a
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[62:63], v[48:49], 0 ; cc46404c 1a02613e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[88:89], v[110:111], v[184:191] ; cc4640b8 1ee2dd58
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[56:57], v[48:49], 0 ; cc464068 1a026138
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[168:169], v[120:127] ; cc464078 1de3511a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[28:29], v[168:169], v[128:135] ; cc464080 1e03511c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[168:169], v[136:143] ; cc464088 1e23511e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[44:45], v[168:169], v[144:151] ; cc464090 1e43512c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[26:27], v[170:171], v[152:159] ; cc464098 1e63551a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[28:29], v[170:171], v[160:167] ; cc4640a0 1e83551c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[170:171], v[176:183] ; cc4640b0 1ec3551e
	v_wmma_f32_16x16x16_fp8_fp8 v[26:33], v[16:17], v[48:49], 0 ; cc46401a 1a026110
	v_dual_mov_b32 v49, v47 :: v_dual_mov_b32 v48, v46          ; ca10012f 3130012e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[44:45], v[170:171], v[184:191] ; cc4640b8 1ee3552c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[168:171], v4, s[32:35], null offen offset:16 ; c405c07c 408040a8 00001004
	buffer_load_b128 v[44:47], v4, s[32:35], null offen offset:64 ; c405c07c 4080402c 00004004
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[50:51], v[72:73], v[64:71] ; cc464040 1d029132
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[10:11], v[72:73], v[76:83] ; cc46404c 1d32910a
	s_mov_b32 s60, 0x3d380000                                   ; bebc00ff 3d380000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[72:73], v[104:111] ; cc464068 1da2913c
	s_movk_i32 s61, 0x3e47                                      ; b03d3e47
	s_movk_i32 s62, 0x3c20                                      ; b03e3c20
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[90:91], v[172:173], v[120:127] ; cc464078 1de3595a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[172:173], v[128:135] ; cc464080 1e03595c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[94:95], v[172:173], v[136:143] ; cc464088 1e23595e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[172:173], v[144:151] ; cc464090 1e435960
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[90:91], v[174:175], v[152:159] ; cc464098 1e635d5a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[92:93], v[174:175], v[160:167] ; cc4640a0 1e835d5c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[94:95], v[174:175], v[176:183] ; cc4640b0 1ec35d5e
	v_wmma_f32_16x16x16_fp8_fp8 v[26:33], v[100:101], v[72:73], v[26:33] ; cc46401a 1c6a9164
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[96:97], v[174:175], v[184:191] ; cc4640b8 1ee35d60
	s_mov_b32 s63, 0x7ff88000                                   ; bebf00ff 7ff88000
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[98:99], v[84:85], v[120:127] ; cc464078 1de2a962
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[102:103], v[84:85], v[128:135] ; cc464080 1e02a966
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[84:85], v[136:143] ; cc464088 1e22a970
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[114:115], v[84:85], v[144:151] ; cc464090 1e42a972
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[98:99], v[86:87], v[152:159] ; cc464098 1e62ad62
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[102:103], v[86:87], v[160:167] ; cc4640a0 1e82ad66
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[112:113], v[86:87], v[176:183] ; cc4640b0 1ec2ad70
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[86:87], v[184:191] ; cc4640b8 1ee2ad72
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[116:117], v[36:37], v[120:127] ; cc464078 1de24974
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[118:119], v[36:37], v[128:135] ; cc464080 1e024976
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[12:13], v[36:37], v[136:143] ; cc464088 1e22490c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[24:25], v[36:37], v[144:151] ; cc464090 1e424918
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[38:39], v[152:159] ; cc464098 1e624d74
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[118:119], v[38:39], v[160:167] ; cc4640a0 1e824d76
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[38:39], v[176:183] ; cc4640b0 1ec24d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[24:25], v[38:39], v[184:191] ; cc4640b8 1ee24d18
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_dual_mov_b32 v73, v131 :: v_dual_mov_b32 v72, v130        ; ca100183 49480182
	v_mov_b16_e32 v22.l, v36.l                                  ; 7e2c3924
	s_clause 0xc                                                ; bf85000c
	buffer_load_b128 v[84:87], v4, s[32:35], null offen offset:80 ; c405c07c 40804054 00005004
	buffer_load_b128 v[88:91], v4, s[32:35], null offen offset:128 ; c405c07c 40804058 00008004
	buffer_load_b128 v[92:95], v4, s[32:35], null offen offset:144 ; c405c07c 4080405c 00009004
	buffer_load_b128 v[96:99], v4, s[32:35], null offen offset:192 ; c405c07c 40804060 0000c004
	buffer_load_b128 v[112:115], v4, s[32:35], null offen offset:208 ; c405c07c 40804070 0000d004
	buffer_load_b128 v[116:119], v4, s[32:35], null offen offset:4096 ; c405c07c 40804074 00100004
	buffer_load_b128 v[120:123], v4, s[32:35], null offen offset:4112 ; c405c07c 40804078 00101004
	buffer_load_b128 v[124:127], v4, s[32:35], null offen offset:4160 ; c405c07c 4080407c 00104004
	buffer_load_b128 v[152:155], v4, s[32:35], null offen offset:4176 ; c405c07c 40804098 00105004
	buffer_load_b128 v[156:159], v4, s[32:35], null offen offset:4224 ; c405c07c 4080409c 00108004
	buffer_load_b128 v[172:175], v4, s[32:35], null offen offset:4240 ; c405c07c 408040ac 00109004
	buffer_load_b128 v[36:39], v4, s[32:35], null offen offset:4288 ; c405c07c 40804024 0010c004
	buffer_load_b128 v[128:131], v4, s[32:35], null offen offset:4304 ; c405c07c 40804080 0010d004
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694066
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694067
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_mov_b16_e32 v72.l, v22.l                                  ; 7e903916
(invalid instruction)                                        ; d7690084
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694084
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690085
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694085
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7690086
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694086
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690087
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694087
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690088
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694088
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690089
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694089
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769008a
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d769408a
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d769008b
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d769408b
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[74:75], 0 ; cc464090 1a02952a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[56:57], v[74:75], 0 ; cc4640a0 1a029538
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[74:75], 0 ; cc4640b0 1a02953e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[16:17], v[74:75], 0 ; cc4640b8 1a029510
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_fma_mixlo_f16 v74, s60, v64, v52                          ; cc21004a 04d2803c
	v_fma_mixhi_f16 v74, s60, v65, v53                          ; cc22004a 04d6823c
	v_dual_mov_b32 v65, v51 :: v_dual_mov_b32 v64, v50          ; ca100133 41400132
	v_fma_mixlo_f16 v75, s60, v66, v54                          ; cc21004b 04da843c
	v_fma_mixhi_f16 v75, s60, v67, v55                          ; cc22004b 04de863c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[50:51], v[48:49], v[144:151] ; cc464090 1e426132
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[60:61], v[48:49], v[160:167] ; cc4640a0 1e82613c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[10:11], v[48:49], v[176:183] ; cc4640b0 1ec2610a
(invalid instruction)                                        ; cc1c004a
	v_subrev_f32_e32 v0, v74, v62                               ; 0a007d4a
	v_dual_mov_b32 v143, v65 :: v_dual_mov_b32 v142, v64        ; ca100141 8f8e0140
(invalid instruction)                                        ; cc1c004b
	v_subrev_f32_e32 v0, v75, v62                               ; 0a007d4b
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v140, s60, v68, v168                        ; cc21008c 06a2883c
	v_fma_mixhi_f16 v140, s60, v69, v169                        ; cc22008c 06a68a3c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[100:101], v[48:49], v[184:191] ; cc4640b8 1ee26164
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[42:43], v[14:15], 0 ; cc464030 1a021d2a
	v_fma_mixlo_f16 v141, s60, v70, v170                        ; cc21008d 06aa8c3c
	v_fma_mixhi_f16 v141, s60, v71, v171                        ; cc22008d 06ae8e3c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[56:57], v[14:15], 0 ; cc464040 1a021d38
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_fma_mixlo_f16 v168, s60, v104, v44                        ; cc2100a8 04b2d03c
(invalid instruction)                                        ; cc1b004a
	v_subrev_f32_e32 v0, v74, v61                               ; 0a007b4a
(invalid instruction)                                        ; cc1b004b
	v_subrev_f32_e32 v0, v75, v61                               ; 0a007b4b
(invalid instruction)                                        ; cc1c008c
	v_subrev_f32_e32 v0, v140, v62                              ; 0a007d8c
	v_fma_mixhi_f16 v168, s60, v105, v45                        ; cc2200a8 04b6d23c
	v_fma_mixlo_f16 v169, s60, v106, v46                        ; cc2100a9 04bad43c
(invalid instruction)                                        ; cc1c008d
	v_subrev_f32_e32 v0, v141, v62                              ; 0a007d8d
	v_fma_mixhi_f16 v169, s60, v107, v47                        ; cc2200a9 04bed63c
	v_lshl_add_u32 v74, v74, 5, s63                             ; d646004a 00fd0b4a
	v_lshl_add_u32 v75, v75, 5, s63                             ; d646004b 00fd0b4b
(invalid instruction)                                        ; cc1b008c
	v_subrev_f32_e32 v0, v140, v61                              ; 0a007b8c
(invalid instruction)                                        ; cc1c00a8
	v_subrev_f32_e32 v0, v168, v62                              ; 0a007da8
(invalid instruction)                                        ; cc1b008d
	v_subrev_f32_e32 v0, v141, v61                              ; 0a007b8d
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v62                              ; 0a007da9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
	v_lshl_add_u32 v140, v140, 5, s63                           ; d646008c 00fd0b8c
(invalid instruction)                                        ; cc1b00a8
	v_subrev_f32_e32 v0, v168, v61                              ; 0a007ba8
	v_lshl_add_u32 v141, v141, 5, s63                           ; d646008d 00fd0b8d
(invalid instruction)                                        ; cc1b00a9
	v_subrev_f32_e32 v0, v169, v61                              ; 0a007ba9
	v_lshl_add_u32 v168, v168, 5, s63                           ; d64600a8 00fd0ba8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshl_add_u32 v169, v169, 5, s63                           ; d64600a9 00fd0ba9
(invalid instruction)                                        ; cc0f00aa
	v_min_num_f64_e32 v[1:2], v[74:75], v[168:169]              ; 1a03514a
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; cc0f00ab
	v_min_num_f64_e32 v[1:2], v[75:76], v[169:170]              ; 1a03534b
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v44, s60, v110, v86                         ; cc21002c 055adc3c
	v_fma_mixhi_f16 v44, s60, v111, v87                         ; cc22002c 055ede3c
	v_fma_mixlo_f16 v22, s60, v108, v84                         ; cc210016 0552d83c
	v_fma_mixhi_f16 v22, s60, v109, v85                         ; cc220016 0556da3c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[62:63], v[14:15], 0 ; cc464068 1a021d3e
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v47, s60, v76, v88                          ; cc21002f 0562983c
	v_fma_mixhi_f16 v47, s60, v77, v89                          ; cc22002f 05669a3c
	v_fma_mixlo_f16 v76, s60, v78, v90                          ; cc21004c 056a9c3c
	v_fma_mixhi_f16 v76, s60, v79, v91                          ; cc22004c 056e9e3c
(invalid instruction)                                        ; cc1c002c
	v_subrev_f32_e32 v0, v44, v62                               ; 0a007d2c
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v62                               ; 0a007d16
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[16:17], v[14:15], 0 ; cc464054 1a021d10
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[142:143], v[18:19], v[48:55] ; cc464030 1cc2258e
(invalid instruction)                                        ; cc1c002f
	v_subrev_f32_e32 v0, v47, v62                               ; 0a007d2f
(invalid instruction)                                        ; cc1c004c
	v_subrev_f32_e32 v0, v76, v62                               ; 0a007d4c
(invalid instruction)                                        ; cc1b002c
	v_subrev_f32_e32 v0, v44, v61                               ; 0a007b2c
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v61                               ; 0a007b16
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[60:61], v[18:19], v[64:71] ; cc464040 1d02253c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v77, s60, v80, v92                          ; cc21004d 0572a03c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[18:19], v[104:111] ; cc464068 1da2250a
	v_fma_mixhi_f16 v77, s60, v81, v93                          ; cc22004d 0576a23c
	v_dual_mov_b32 v15, v95 :: v_dual_mov_b32 v14, v94          ; ca10015f 0f0e015e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[78:81], v4, s[32:35], null offen offset:8192 ; c405c07c 4080404e 00200004
	buffer_load_b128 v[92:95], v4, s[32:35], null offen offset:8208 ; c405c07c 4080405c 00201004
	v_wmma_f32_16x16x16_fp8_fp8 v[84:91], v[100:101], v[18:19], v[84:91] ; cc464054 1d522564
(invalid instruction)                                        ; cc1b002f
	v_subrev_f32_e32 v0, v47, v61                               ; 0a007b2f
(invalid instruction)                                        ; cc1b004c
	v_subrev_f32_e32 v0, v76, v61                               ; 0a007b4c
	v_lshl_add_u32 v44, v44, 5, s63                             ; d646002c 00fd0b2c
	v_lshl_add_u32 v22, v22, 5, s63                             ; d6460016 00fd0b16
(invalid instruction)                                        ; cc1c004d
	v_subrev_f32_e32 v0, v77, v62                               ; 0a007d4d
	v_fma_mixlo_f16 v18, s60, v82, v14                          ; cc210012 043aa43c
	v_fma_mixhi_f16 v18, s60, v83, v15                          ; cc220012 043ea63c
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v19, s60, v26, v96                          ; cc210013 0582343c
	v_fma_mixhi_f16 v19, s60, v27, v97                          ; cc220013 0586363c
	v_lshl_add_u32 v47, v47, 5, s63                             ; d646002f 00fd0b2f
	v_lshl_add_u32 v76, v76, 5, s63                             ; d646004c 00fd0b4c
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[141:142], v[44:45]              ; 1a02598d
	v_fma_mixlo_f16 v26, s60, v28, v98                          ; cc21001a 058a383c
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[140:141], v[22:23]              ; 1a022d8c
(invalid instruction)                                        ; cc1b004d
	v_subrev_f32_e32 v0, v77, v61                               ; 0a007b4d
	v_fma_mixhi_f16 v26, s60, v29, v99                          ; cc22001a 058e3a3c
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v62                               ; 0a007d12
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v27, s60, v30, v112                         ; cc21001b 05c23c3c
(invalid instruction)                                        ; cc1c0013
	v_subrev_f32_e32 v0, v19, v62                               ; 0a007d13
	v_fma_mixhi_f16 v27, s60, v31, v113                         ; cc22001b 05c63e3c
(invalid instruction)                                        ; cc0f00aa
	v_min_num_f64_e32 v[1:2], v[170:171], v[47:48]              ; 1a025faa
(invalid instruction)                                        ; cc0f00ab
	v_min_num_f64_e32 v[1:2], v[171:172], v[76:77]              ; 1a0299ab
	v_fma_mixlo_f16 v28, s60, v32, v114                         ; cc21001c 05ca403c
	v_fma_mixhi_f16 v28, s60, v33, v115                         ; cc22001c 05ce423c
	v_lshl_add_u32 v77, v77, 5, s63                             ; d646004d 00fd0b4d
(invalid instruction)                                        ; cc1c001a
	v_subrev_f32_e32 v0, v26, v62                               ; 0a007d1a
(invalid instruction)                                        ; cc1b0012
	v_subrev_f32_e32 v0, v18, v61                               ; 0a007b12
(invalid instruction)                                        ; cc1b0013
	v_subrev_f32_e32 v0, v19, v61                               ; 0a007b13
(invalid instruction)                                        ; cc1c001b
	v_subrev_f32_e32 v0, v27, v62                               ; 0a007d1b
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v62                               ; 0a007d1c
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[77:78]                ; 1a029b2d
(invalid instruction)                                        ; cc1b001a
	v_subrev_f32_e32 v0, v26, v61                               ; 0a007b1a
	v_lshl_add_u32 v18, v18, 5, s63                             ; d6460012 00fd0b12
	v_lshl_add_u32 v19, v19, 5, s63                             ; d6460013 00fd0b13
(invalid instruction)                                        ; cc1b001b
	v_subrev_f32_e32 v0, v27, v61                               ; 0a007b1b
(invalid instruction)                                        ; cc1b001c
	v_subrev_f32_e32 v0, v28, v61                               ; 0a007b1c
	v_lshl_add_u32 v26, v26, 5, s63                             ; d646001a 00fd0b1a
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[18:19]                ; 1a02252e
(invalid instruction)                                        ; cc0f00aa
	v_min_num_f64_e32 v[1:2], v[170:171], v[19:20]              ; 1a0227aa
	v_lshl_add_u32 v27, v27, 5, s63                             ; d646001b 00fd0b1b
	v_lshl_add_u32 v28, v28, 5, s63                             ; d646001c 00fd0b1c
(invalid instruction)                                        ; cc0f00ab
	v_min_num_f64_e32 v[1:2], v[171:172], v[26:27]              ; 1a0235ab
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[27:28]                ; 1a02372d
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[28:29]                ; 1a02392e
(invalid instruction)                                        ; cc0f00aa
	v_min_num_f64_e32 v[1:2], v[170:171], v[171:172]            ; 1a0357aa
(invalid instruction)                                        ; cc0f00aa
	v_min_num_f64_e32 v[1:2], v[170:171], v[45:46]              ; 1a025baa
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00aa
	v_min_num_f64_e32 v[1:2], v[170:171], v[46:47]              ; 1a025daa
	v_permlanex16_b32 v29, v170, s57, s58 op_sel:[1,1]          ; d65c181d 00e873aa
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00aa
	v_min_num_f64_e32 v[1:2], v[170:171], v[29:30]              ; 1a023baa
(invalid instruction)                                        ; d532101e
	v_cndmask_b32_e32 v1, v170, v170, vcc_lo                    ; 020355aa
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v30, s56, v30                             ; 623c3c38
	v_cvt_f32_f16_e32 v31, v30                                  ; 7e3e171e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v31, v31                                      ; 7e3e551f
	v_fma_mix_f32 v45, v140, v31, neg(0) op_sel_hi:[1,0,0]      ; cc20002d 8a023f8c
	v_fma_mix_f32 v140, v140, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088c 8a023f8c
	v_fma_mix_f32 v32, v74, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200020 8a023f4a
	v_fma_mix_f32 v46, v141, v31, neg(0) op_sel_hi:[1,0,0]      ; cc20002e 8a023f8d
	v_fma_mix_f32 v33, v75, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200021 8a023f4b
	v_fma_mix_f32 v75, v75, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084b 8a023f4b
	v_fma_mix_f32 v74, v74, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084a 8a023f4a
	v_fma_mix_f32 v141, v141, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088d 8a023f8d
	v_fma_mix_f32 v82, v22, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200052 8a023f16
	v_fma_mix_f32 v22, v22, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a023f16
	v_fma_mix_f32 v83, v44, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200053 8a023f2c
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v45, v140, vcc_lo                     ; 0203192d
	v_fma_mix_f32 v44, v44, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082c 8a023f2c
	v_fma_mix_f32 v96, v47, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200060 8a023f2f
	v_fma_mix_f32 v47, v47, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082f 8a023f2f
	v_fma_mix_f32 v97, v76, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200061 8a023f4c
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v32, v74, vcc_lo                      ; 02029520
	v_fma_mix_f32 v74, v168, v31, neg(0) op_sel_hi:[1,0,0]      ; cc20004a 8a023fa8
	v_fma_mix_f32 v168, v168, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a8 8a023fa8
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v33, v75, vcc_lo                      ; 02029721
	v_fma_mix_f32 v75, v169, v31, neg(0) op_sel_hi:[1,0,0]      ; cc20004b 8a023fa9
	v_fma_mix_f32 v169, v169, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a023fa9
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v46, v141, vcc_lo                     ; 02031b2e
	v_fma_mix_f32 v76, v76, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084c 8a023f4c
	v_fma_mix_f32 v98, v77, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200062 8a023f4d
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v82, v22, vcc_lo                      ; 02022d52
	v_fma_mix_f32 v77, v77, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084d 8a023f4d
	v_fma_mix_f32 v99, v18, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200063 8a023f12
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v83, v44, vcc_lo                      ; 02025953
	v_fma_mix_f32 v18, v18, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200812 8a023f12
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v96, v47, vcc_lo                      ; 02025f60
	v_fma_mix_f32 v112, v19, v31, neg(0) op_sel_hi:[1,0,0]      ; cc200070 8a023f13
	v_fma_mix_f32 v19, v19, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200813 8a023f13
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v74, v168, vcc_lo                     ; 0203514a
	v_fma_mix_f32 v113, v26, v31, neg(0) op_sel_hi:[1,0,0]      ; cc200071 8a023f1a
	v_fma_mix_f32 v26, v26, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081a 8a023f1a
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v75, v169, vcc_lo                     ; 0203534b
	v_fma_mix_f32 v114, v27, v31, neg(0) op_sel_hi:[1,0,0]      ; cc200072 8a023f1b
	v_fma_mix_f32 v27, v27, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081b 8a023f1b
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v97, v76, vcc_lo                      ; 02029961
	v_fma_mix_f32 v115, v28, v31, neg(0) op_sel_hi:[1,0,0]      ; cc200073 8a023f1c
	v_fma_mix_f32 v28, v28, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a023f1c
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v98, v77, vcc_lo                      ; 02029b62
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v99, v18, vcc_lo                      ; 02022563
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v112, v19, vcc_lo                     ; 02022770
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v114, v27, vcc_lo                     ; 02023772
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v115, v28, vcc_lo                     ; 02023973
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v4, s[32:35], null offen offset:8256 ; c405c07c 4080401c 00204004
	buffer_load_b128 v[96:99], v4, s[32:35], null offen offset:8272 ; c405c07c 40804060 00205004
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v116, s60, v144, v116                       ; cc210074 05d3203c
	v_fma_mixhi_f16 v116, s60, v145, v117                       ; cc220074 05d7223c
	v_fma_mixlo_f16 v117, s60, v146, v118                       ; cc210075 05db243c
	v_fma_mixhi_f16 v117, s60, v147, v119                       ; cc220075 05df263c
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v113, v26, vcc_lo                     ; 02023571
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v118, s60, v148, v120                       ; cc210076 05e3283c
	v_fma_mixhi_f16 v118, s60, v149, v121                       ; cc220076 05e72a3c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[112:115], v4, s[32:35], null offen offset:8320 ; c405c07c 40804070 00208004
	buffer_load_b128 v[144:147], v4, s[32:35], null offen offset:8336 ; c405c07c 40804090 00209004
	v_fma_mixlo_f16 v119, s60, v150, v122                       ; cc210077 05eb2c3c
	v_fma_mixhi_f16 v119, s60, v151, v123                       ; cc220077 05ef2e3c
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v120, s60, v160, v124                       ; cc210078 05f3403c
	v_fma_mixhi_f16 v120, s60, v161, v125                       ; cc220078 05f7423c
	v_fma_mixlo_f16 v121, s60, v162, v126                       ; cc210079 05fb443c
(invalid instruction)                                        ; cc1c0074
	v_subrev_f32_e32 v0, v116, v62                              ; 0a007d74
(invalid instruction)                                        ; cc1c0075
	v_subrev_f32_e32 v0, v117, v62                              ; 0a007d75
	v_fma_mixhi_f16 v121, s60, v163, v127                       ; cc220079 05ff463c
(invalid instruction)                                        ; cc1c0076
	v_subrev_f32_e32 v0, v118, v62                              ; 0a007d76
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v122, s60, v164, v152                       ; cc21007a 0663483c
	v_fma_mixhi_f16 v122, s60, v165, v153                       ; cc22007a 06674a3c
(invalid instruction)                                        ; cc1c0077
	v_subrev_f32_e32 v0, v119, v62                              ; 0a007d77
	v_fma_mixlo_f16 v123, s60, v166, v154                       ; cc21007b 066b4c3c
	v_fma_mixhi_f16 v123, s60, v167, v155                       ; cc22007b 066f4e3c
(invalid instruction)                                        ; cc1c0078
	v_subrev_f32_e32 v0, v120, v62                              ; 0a007d78
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v124, s60, v176, v156                       ; cc21007c 0673603c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[148:151], v4, s[32:35], null offen offset:8384 ; c405c07c 40804094 0020c004
	buffer_load_b128 v[152:155], v4, s[32:35], null offen offset:8400 ; c405c07c 40804098 0020d004
(invalid instruction)                                        ; cc1b0074
	v_subrev_f32_e32 v0, v116, v61                              ; 0a007b74
	v_fma_mixhi_f16 v124, s60, v177, v157                       ; cc22007c 0677623c
(invalid instruction)                                        ; cc1b0075
	v_subrev_f32_e32 v0, v117, v61                              ; 0a007b75
(invalid instruction)                                        ; cc1c0079
	v_subrev_f32_e32 v0, v121, v62                              ; 0a007d79
(invalid instruction)                                        ; cc1b0076
	v_subrev_f32_e32 v0, v118, v61                              ; 0a007b76
	v_fma_mixlo_f16 v125, s60, v178, v158                       ; cc21007d 067b643c
(invalid instruction)                                        ; cc1c007a
	v_subrev_f32_e32 v0, v122, v62                              ; 0a007d7a
(invalid instruction)                                        ; cc1b0077
	v_subrev_f32_e32 v0, v119, v61                              ; 0a007b77
	v_fma_mixhi_f16 v125, s60, v179, v159                       ; cc22007d 067f663c
(invalid instruction)                                        ; cc1c007b
	v_subrev_f32_e32 v0, v123, v62                              ; 0a007d7b
(invalid instruction)                                        ; cc1b0078
	v_subrev_f32_e32 v0, v120, v61                              ; 0a007b78
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v126, s60, v180, v172                       ; cc21007e 06b3683c
	v_fma_mixhi_f16 v126, s60, v181, v173                       ; cc22007e 06b76a3c
(invalid instruction)                                        ; cc1c007c
	v_subrev_f32_e32 v0, v124, v62                              ; 0a007d7c
	v_fma_mixlo_f16 v127, s60, v182, v174                       ; cc21007f 06bb6c3c
	v_fma_mixhi_f16 v127, s60, v183, v175                       ; cc22007f 06bf6e3c
(invalid instruction)                                        ; cc1b0079
	v_subrev_f32_e32 v0, v121, v61                              ; 0a007b79
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v140, s60, v184, v36                        ; cc21008c 0493703c
	v_fma_mixhi_f16 v140, s60, v185, v37                        ; cc22008c 0497723c
(invalid instruction)                                        ; cc1b007a
	v_subrev_f32_e32 v0, v122, v61                              ; 0a007b7a
(invalid instruction)                                        ; cc1c007d
	v_subrev_f32_e32 v0, v125, v62                              ; 0a007d7d
	v_fma_mixlo_f16 v141, s60, v186, v38                        ; cc21008d 049b743c
(invalid instruction)                                        ; cc1b007b
	v_subrev_f32_e32 v0, v123, v61                              ; 0a007b7b
	v_fma_mixhi_f16 v141, s60, v187, v39                        ; cc22008d 049f763c
(invalid instruction)                                        ; cc1c007e
	v_subrev_f32_e32 v0, v126, v62                              ; 0a007d7e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v156, s60, v188, v128                       ; cc21009c 0603783c
(invalid instruction)                                        ; cc1b007c
	v_subrev_f32_e32 v0, v124, v61                              ; 0a007b7c
	v_fma_mixhi_f16 v156, s60, v189, v129                       ; cc22009c 06077a3c
(invalid instruction)                                        ; cc1c007f
	v_subrev_f32_e32 v0, v127, v62                              ; 0a007d7f
	v_fma_mixlo_f16 v157, s60, v190, v130                       ; cc21009d 060b7c3c
	v_fma_mixhi_f16 v157, s60, v191, v131                       ; cc22009d 060f7e3c
(invalid instruction)                                        ; cc1c008c
	v_subrev_f32_e32 v0, v140, v62                              ; 0a007d8c
(invalid instruction)                                        ; cc1b007d
	v_subrev_f32_e32 v0, v125, v61                              ; 0a007b7d
	v_lshl_add_u32 v116, v116, 5, s63                           ; d6460074 00fd0b74
	v_lshl_add_u32 v120, v120, 5, s63                           ; d6460078 00fd0b78
(invalid instruction)                                        ; cc1c008d
	v_subrev_f32_e32 v0, v141, v62                              ; 0a007d8d
(invalid instruction)                                        ; cc1b007e
	v_subrev_f32_e32 v0, v126, v61                              ; 0a007b7e
	v_lshl_add_u32 v124, v124, 5, s63                           ; d646007c 00fd0b7c
(invalid instruction)                                        ; cc1c009c
	v_subrev_f32_e32 v0, v156, v62                              ; 0a007d9c
(invalid instruction)                                        ; cc1b007f
	v_subrev_f32_e32 v0, v127, v61                              ; 0a007b7f
	v_lshl_add_u32 v117, v117, 5, s63                           ; d6460075 00fd0b75
	v_lshl_add_u32 v121, v121, 5, s63                           ; d6460079 00fd0b79
(invalid instruction)                                        ; cc1c009d
	v_subrev_f32_e32 v0, v157, v62                              ; 0a007d9d
(invalid instruction)                                        ; cc1b008c
	v_subrev_f32_e32 v0, v140, v61                              ; 0a007b8c
	v_lshl_add_u32 v125, v125, 5, s63                           ; d646007d 00fd0b7d
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[116:117], v[120:121]            ; 1a02f174
	v_lshl_add_u32 v118, v118, 5, s63                           ; d6460076 00fd0b76
(invalid instruction)                                        ; cc1b008d
	v_subrev_f32_e32 v0, v141, v61                              ; 0a007b8d
	v_lshl_add_u32 v122, v122, 5, s63                           ; d646007a 00fd0b7a
	v_lshl_add_u32 v126, v126, 5, s63                           ; d646007e 00fd0b7e
(invalid instruction)                                        ; cc1b009c
	v_subrev_f32_e32 v0, v156, v61                              ; 0a007b9c
(invalid instruction)                                        ; cc0f009f
	v_min_num_f64_e32 v[1:2], v[117:118], v[121:122]            ; 1a02f375
(invalid instruction)                                        ; cc1b009d
	v_subrev_f32_e32 v0, v157, v61                              ; 0a007b9d
	v_lshl_add_u32 v119, v119, 5, s63                           ; d6460077 00fd0b77
	v_lshl_add_u32 v140, v140, 5, s63                           ; d646008c 00fd0b8c
	v_lshl_add_u32 v123, v123, 5, s63                           ; d646007b 00fd0b7b
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[124:125]            ; 1a02f99e
	v_lshl_add_u32 v127, v127, 5, s63                           ; d646007f 00fd0b7f
	v_lshl_add_u32 v141, v141, 5, s63                           ; d646008d 00fd0b8d
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[118:119], v[122:123]            ; 1a02f576
	v_lshl_add_u32 v156, v156, 5, s63                           ; d646009c 00fd0b9c
(invalid instruction)                                        ; cc0f009f
	v_min_num_f64_e32 v[1:2], v[159:160], v[125:126]            ; 1a02fb9f
	v_lshl_add_u32 v157, v157, 5, s63                           ; d646009d 00fd0b9d
(invalid instruction)                                        ; cc0f00a1
	v_min_num_f64_e32 v[1:2], v[119:120], v[123:124]            ; 1a02f777
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[140:141]            ; 1a03199e
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[126:127]            ; 1a02fda0
(invalid instruction)                                        ; cc0f009f
	v_min_num_f64_e32 v[1:2], v[159:160], v[141:142]            ; 1a031b9f
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f00a1
	v_min_num_f64_e32 v[1:2], v[161:162], v[127:128]            ; 1a02ffa1
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[156:157]            ; 1a0339a0
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[159:160]            ; 1a033f9e
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f00a1
	v_min_num_f64_e32 v[1:2], v[161:162], v[157:158]            ; 1a033ba1
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[160:161]            ; 1a03419e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[161:162]            ; 1a03439e
	v_permlanex16_b32 v162, v158, s57, s58 op_sel:[1,1]         ; d65c18a2 00e8739e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[162:163]            ; 1a03459e
(invalid instruction)                                        ; d53210a3
	v_cndmask_b32_e32 v1, v158, v158, vcc_lo                    ; 02033d9e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53100a3
	v_cndmask_b32_e32 v1, s56, v163, vcc_lo                     ; 02034638
(invalid instruction)                                        ; d58b00a4
	v_cndmask_b32_e32 v0, v163, v128, vcc_lo                    ; 020101a3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v164, v164                                    ; 7f4855a4
	v_fma_mix_f32 v168, v119, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000a8 8a034977
	v_fma_mix_f32 v170, v121, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000aa 8a034979
	v_fma_mix_f32 v165, v116, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000a5 8a034974
	v_fma_mix_f32 v116, v116, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200874 8a034974
	v_fma_mix_f32 v166, v117, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000a6 8a034975
	v_fma_mix_f32 v117, v117, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200875 8a034975
	v_fma_mix_f32 v119, v119, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a034977
	v_fma_mix_f32 v167, v118, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000a7 8a034976
	v_fma_mix_f32 v118, v118, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200876 8a034976
	v_fma_mix_f32 v169, v120, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000a9 8a034978
	v_fma_mix_f32 v120, v120, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200878 8a034978
	v_fma_mix_f32 v121, v121, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200879 8a034979
	v_fma_mix_f32 v171, v122, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000ab 8a03497a
	v_fma_mix_f32 v122, v122, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087a 8a03497a
	v_fma_mix_f32 v172, v123, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000ac 8a03497b
	v_fma_mix_f32 v123, v123, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087b 8a03497b
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v165, v116, vcc_lo                    ; 0202e9a5
	v_fma_mix_f32 v173, v124, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000ad 8a03497c
	v_fma_mix_f32 v124, v124, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087c 8a03497c
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v166, v117, vcc_lo                    ; 0202eba6
	v_fma_mix_f32 v174, v125, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000ae 8a03497d
	v_fma_mix_f32 v125, v125, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087d 8a03497d
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v167, v118, vcc_lo                    ; 0202eda7
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v168, v119, vcc_lo                    ; 0202efa8
	v_fma_mix_f32 v175, v126, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000af 8a03497e
	v_fma_mix_f32 v126, v126, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087e 8a03497e
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v169, v120, vcc_lo                    ; 0202f1a9
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v170, v121, vcc_lo                    ; 0202f3aa
	v_fma_mix_f32 v176, v127, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000b0 8a03497f
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v171, v122, vcc_lo                    ; 0202f5ab
	v_fma_mix_f32 v127, v127, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087f 8a03497f
	v_fma_mix_f32 v177, v140, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000b1 8a03498c
	buffer_load_b128 v[116:119], v4, s[32:35], null offen offset:12288 ; c405c07c 40804074 00300004
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v172, v123, vcc_lo                    ; 0202f7ac
	buffer_load_b128 v[120:123], v4, s[32:35], null offen offset:12304 ; c405c07c 40804078 00301004
	v_fma_mix_f32 v140, v140, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088c 8a03498c
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v173, v124, vcc_lo                    ; 0202f9ad
	v_fma_mix_f32 v178, v141, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000b2 8a03498d
	v_fma_mix_f32 v141, v141, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088d 8a03498d
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v174, v125, vcc_lo                    ; 0202fbae
	v_fma_mix_f32 v179, v156, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000b3 8a03499c
	v_fma_mix_f32 v156, v156, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089c 8a03499c
	v_fma_mix_f32 v180, v157, v164, neg(0) op_sel_hi:[1,0,0]    ; cc2000b4 8a03499d
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v175, v126, vcc_lo                    ; 0202fdaf
	v_fma_mix_f32 v157, v157, v164, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a03499d
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v181, s60, v48, v78                         ; cc2100b5 053a603c
	v_fma_mixhi_f16 v181, s60, v49, v79                         ; cc2200b5 053e623c
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v176, v127, vcc_lo                    ; 0202ffb0
	v_fma_mixlo_f16 v182, s60, v50, v80                         ; cc2100b6 0542643c
	v_fma_mixhi_f16 v182, s60, v51, v81                         ; cc2200b6 0546663c
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v177, v140, vcc_lo                    ; 020319b1
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v183, s60, v52, v92                         ; cc2100b7 0572683c
	v_fma_mixhi_f16 v183, s60, v53, v93                         ; cc2200b7 05766a3c
	v_fma_mixlo_f16 v184, s60, v54, v94                         ; cc2100b8 057a6c3c
	v_fma_mixhi_f16 v184, s60, v55, v95                         ; cc2200b8 057e6e3c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v4, s[32:35], null offen offset:12352 ; c405c07c 40804030 00304004
	buffer_load_b128 v[52:55], v4, s[32:35], null offen offset:12368 ; c405c07c 40804034 00305004
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v178, v141, vcc_lo                    ; 02031bb2
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v179, v156, vcc_lo                    ; 020339b3
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v180, v157, vcc_lo                    ; 02033bb4
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v62                              ; 0a007db5
(invalid instruction)                                        ; cc1c00b6
	v_subrev_f32_e32 v0, v182, v62                              ; 0a007db6
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v62                              ; 0a007db7
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v62                              ; 0a007db8
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b00b5
	v_subrev_f32_e32 v0, v181, v61                              ; 0a007bb5
(invalid instruction)                                        ; cc1b00b6
	v_subrev_f32_e32 v0, v182, v61                              ; 0a007bb6
(invalid instruction)                                        ; cc1b00b7
	v_subrev_f32_e32 v0, v183, v61                              ; 0a007bb7
(invalid instruction)                                        ; cc1b00b8
	v_subrev_f32_e32 v0, v184, v61                              ; 0a007bb8
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v185, s60, v64, v28                         ; cc2100b9 0472803c
	v_fma_mixlo_f16 v186, s60, v66, v30                         ; cc2100ba 047a843c
	v_fma_mixhi_f16 v185, s60, v65, v29                         ; cc2200b9 0476823c
	v_fma_mixhi_f16 v186, s60, v67, v31                         ; cc2200ba 047e863c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v4, s[32:35], null offen offset:12416 ; c405c07c 4080401c 00308004
	buffer_load_b128 v[64:67], v4, s[32:35], null offen offset:12432 ; c405c07c 40804040 00309004
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v187, s60, v68, v96                         ; cc2100bb 0582883c
	v_fma_mixlo_f16 v188, s60, v70, v98                         ; cc2100bc 058a8c3c
	v_fma_mixhi_f16 v188, s60, v71, v99                         ; cc2200bc 058e8e3c
	v_fma_mixhi_f16 v187, s60, v69, v97                         ; cc2200bb 05868a3c
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v62                              ; 0a007db9
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v189, s60, v104, v112                       ; cc2100bd 05c2d03c
	v_fma_mixlo_f16 v190, s60, v106, v114                       ; cc2100be 05cad43c
	v_fma_mixhi_f16 v189, s60, v105, v113                       ; cc2200bd 05c6d23c
	v_fma_mixhi_f16 v190, s60, v107, v115                       ; cc2200be 05ced63c
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v62                              ; 0a007dba
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v191, s60, v108, v144                       ; cc2100bf 0642d83c
	v_fma_mixhi_f16 v191, s60, v109, v145                       ; cc2200bf 0646da3c
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v62                              ; 0a007dbc
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v4, s[32:35], null offen offset:12480 ; c405c07c 40804044 0030c004
	buffer_load_b128 v[76:79], v4, s[32:35], null offen offset:12496 ; c405c07c 4080404c 0030d004
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v62                              ; 0a007dbb
	v_fma_mixlo_f16 v22, s60, v110, v146                        ; cc210016 064adc3c
(invalid instruction)                                        ; cc1b00b9
	v_subrev_f32_e32 v0, v185, v61                              ; 0a007bb9
	v_fma_mixhi_f16 v22, s60, v111, v147                        ; cc220016 064ede3c
	v_add3_u32 v59, v59, s9, v0                                 ; d655003b 0400133b
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v62                              ; 0a007dbd
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v62                              ; 0a007dbe
(invalid instruction)                                        ; cc1b00ba
	v_subrev_f32_e32 v0, v186, v61                              ; 0a007bba
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v62                              ; 0a007dbf
(invalid instruction)                                        ; cc1b00bc
	v_subrev_f32_e32 v0, v188, v61                              ; 0a007bbc
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v74, s60, v84, v148                         ; cc21004a 0652a83c
	v_fma_mixhi_f16 v74, s60, v85, v149                         ; cc22004a 0656aa3c
(invalid instruction)                                        ; cc1b00bb
	v_subrev_f32_e32 v0, v187, v61                              ; 0a007bbb
	v_fma_mixlo_f16 v75, s60, v86, v150                         ; cc21004b 065aac3c
	v_fma_mixhi_f16 v75, s60, v87, v151                         ; cc22004b 065eae3c
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v62                               ; 0a007d16
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v80, s60, v88, v152                         ; cc210050 0662b03c
	v_lshlrev_b32_e32 v59, 2, v59                               ; 30767682
(invalid instruction)                                        ; cc1b00bd
	v_subrev_f32_e32 v0, v189, v61                              ; 0a007bbd
	v_fma_mixhi_f16 v80, s60, v89, v153                         ; cc220050 0666b23c
(invalid instruction)                                        ; cc1b00be
	v_subrev_f32_e32 v0, v190, v61                              ; 0a007bbe
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v61                              ; 0a007bbf
	v_fma_mixlo_f16 v81, s60, v90, v154                         ; cc210051 066ab43c
	v_fma_mixhi_f16 v81, s60, v91, v155                         ; cc220051 066eb63c
(invalid instruction)                                        ; cc1c004a
	v_subrev_f32_e32 v0, v74, v62                               ; 0a007d4a
	v_lshl_add_u32 v181, v181, 5, s63                           ; d64600b5 00fd0bb5
	v_lshl_add_u32 v185, v185, 5, s63                           ; d64600b9 00fd0bb9
(invalid instruction)                                        ; cc1c004b
	v_subrev_f32_e32 v0, v75, v62                               ; 0a007d4b
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v61                               ; 0a007b16
	v_lshl_add_u32 v189, v189, 5, s63                           ; d64600bd 00fd0bbd
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v62                               ; 0a007d50
	v_lshl_add_u32 v182, v182, 5, s63                           ; d64600b6 00fd0bb6
	v_lshl_add_u32 v186, v186, 5, s63                           ; d64600ba 00fd0bba
	v_lshl_add_u32 v190, v190, 5, s63                           ; d64600be 00fd0bbe
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v62                               ; 0a007d51
(invalid instruction)                                        ; cc1b004a
	v_subrev_f32_e32 v0, v74, v61                               ; 0a007b4a
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[181:182], v[185:186]            ; 1a0373b5
	v_lshl_add_u32 v183, v183, 5, s63                           ; d64600b7 00fd0bb7
(invalid instruction)                                        ; cc1b004b
	v_subrev_f32_e32 v0, v75, v61                               ; 0a007b4b
	v_lshl_add_u32 v187, v187, 5, s63                           ; d64600bb 00fd0bbb
	v_lshl_add_u32 v191, v191, 5, s63                           ; d64600bf 00fd0bbf
(invalid instruction)                                        ; cc1b0050
	v_subrev_f32_e32 v0, v80, v61                               ; 0a007b50
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[182:183], v[186:187]            ; 1a0375b6
	v_lshl_add_u32 v184, v184, 5, s63                           ; d64600b8 00fd0bb8
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v61                               ; 0a007b51
	v_lshl_add_u32 v188, v188, 5, s63                           ; d64600bc 00fd0bbc
	v_lshl_add_u32 v74, v74, 5, s63                             ; d646004a 00fd0b4a
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[82:83], v[189:190]              ; 1a037b52
	v_lshl_add_u32 v22, v22, 5, s63                             ; d6460016 00fd0b16
	v_lshl_add_u32 v75, v75, 5, s63                             ; d646004b 00fd0b4b
(invalid instruction)                                        ; cc0f0054
	v_min_num_f64_e32 v[1:2], v[183:184], v[187:188]            ; 1a0377b7
	v_lshl_add_u32 v80, v80, 5, s63                             ; d6460050 00fd0b50
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[190:191]              ; 1a037d53
	v_lshl_add_u32 v81, v81, 5, s63                             ; d6460051 00fd0b51
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[184:185], v[188:189]            ; 1a0379b8
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[82:83], v[74:75]                ; 1a029552
(invalid instruction)                                        ; cc0f0054
	v_min_num_f64_e32 v[1:2], v[84:85], v[191:192]              ; 1a037f54
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[83:84], v[75:76]                ; 1a029753
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[22:23]                ; 1a022d55
(invalid instruction)                                        ; cc0f0054
	v_min_num_f64_e32 v[1:2], v[84:85], v[80:81]                ; 1a02a154
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[82:83], v[83:84]                ; 1a02a752
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[81:82]                ; 1a02a355
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[82:83], v[84:85]                ; 1a02a952
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[82:83], v[85:86]                ; 1a02ab52
	v_permlanex16_b32 v86, v82, s57, s58 op_sel:[1,1]           ; d65c1856 00e87352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[82:83], v[86:87]                ; 1a02ad52
	v_add_f16_e32 v87, v82, v210/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64afa552
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v87, s56, v87                             ; 62aeae38
	v_cvt_f32_f16_e32 v88, v87                                  ; 7eb01757
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v88, v88                                      ; 7eb05558
	v_fma_mix_f32 v90, v182, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005a 8a02b1b6
	v_fma_mix_f32 v89, v181, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200059 8a02b1b5
	v_fma_mix_f32 v181, v181, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a02b1b5
	v_fma_mix_f32 v182, v182, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a02b1b6
	v_fma_mix_f32 v94, v186, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005e 8a02b1ba
	v_fma_mix_f32 v92, v184, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005c 8a02b1b8
	v_fma_mix_f32 v91, v183, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005b 8a02b1b7
	v_fma_mix_f32 v183, v183, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a02b1b7
	v_fma_mix_f32 v93, v185, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005d 8a02b1b9
	v_fma_mix_f32 v185, v185, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a02b1b9
	v_fma_mix_f32 v184, v184, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a02b1b8
	v_fma_mix_f32 v186, v186, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a02b1ba
	v_fma_mix_f32 v95, v187, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005f 8a02b1bb
	v_fma_mix_f32 v187, v187, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a02b1bb
	v_fma_mix_f32 v96, v188, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200060 8a02b1bc
	v_fma_mix_f32 v188, v188, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a02b1bc
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v89, v181, vcc_lo                     ; 02036b59
	v_fma_mix_f32 v97, v189, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200061 8a02b1bd
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v90, v182, vcc_lo                     ; 02036d5a
	v_fma_mix_f32 v189, v189, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a02b1bd
	v_fma_mix_f32 v98, v190, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200062 8a02b1be
	v_fma_mix_f32 v190, v190, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a02b1be
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v91, v183, vcc_lo                     ; 02036f5b
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v93, v185, vcc_lo                     ; 0203735d
	v_fma_mix_f32 v99, v191, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200063 8a02b1bf
	v_fma_mix_f32 v191, v191, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a02b1bf
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v92, v184, vcc_lo                     ; 0203715c
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v94, v186, vcc_lo                     ; 0203755e
	v_fma_mix_f32 v104, v22, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200068 8a02b116
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v95, v187, vcc_lo                     ; 0203775f
	v_fma_mix_f32 v22, v22, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a02b116
	v_fma_mix_f32 v105, v74, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200069 8a02b14a
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v96, v188, vcc_lo                     ; 02037960
	v_fma_mix_f32 v74, v74, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084a 8a02b14a
	v_fma_mix_f32 v106, v75, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20006a 8a02b14b
	v_fma_mix_f32 v75, v75, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084b 8a02b14b
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v97, v189, vcc_lo                     ; 02037b61
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v98, v190, vcc_lo                     ; 02037d62
	v_fma_mix_f32 v107, v80, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20006b 8a02b150
	v_fma_mix_f32 v80, v80, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200850 8a02b150
	v_fma_mix_f32 v108, v81, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20006c 8a02b151
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v99, v191, vcc_lo                     ; 02037f63
	v_fma_mix_f32 v81, v81, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200851 8a02b151
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[20:21], 0 ; cc464090 1a022938
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[20:21], 0 ; cc464098 1a02293e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[20:21], 0 ; cc4640a0 1a022910
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v104, v22, vcc_lo                     ; 02022d68
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v105, v74, vcc_lo                     ; 02029569
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v106, v75, vcc_lo                     ; 0202976a
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v107, v80, vcc_lo                     ; 0202a16b
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v108, v81, vcc_lo                     ; 0202a36c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[20:21], 0 ; cc464068 1a02292a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[40:41], v[144:151] ; cc464090 1e42513c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[10:11], v[40:41], v[152:159] ; cc464098 1e62510a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[100:101], v[40:41], v[160:167] ; cc4640a0 1e825164
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[142:143], v[40:41], v[104:111] ; cc464068 1da2518e
	s_wait_loadcnt 0x7                                          ; bfc00007
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_fma_mixlo_f16 v113, s60, v106, v118                       ; cc210071 05dad43c
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v115, s60, v110, v122                       ; cc210073 05eadc3c
	v_fma_mixlo_f16 v112, s60, v104, v116                       ; cc210070 05d2d03c
	v_fma_mixhi_f16 v112, s60, v105, v117                       ; cc220070 05d6d23c
	v_fma_mixhi_f16 v113, s60, v107, v119                       ; cc220071 05ded63c
	v_fma_mixlo_f16 v114, s60, v108, v120                       ; cc210072 05e2d83c
	v_fma_mixhi_f16 v114, s60, v109, v121                       ; cc220072 05e6da3c
	v_fma_mixhi_f16 v115, s60, v111, v123                       ; cc220073 05eede3c
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v116, s60, v144, v48                        ; cc210074 04c3203c
	v_fma_mixhi_f16 v116, s60, v145, v49                        ; cc220074 04c7223c
	v_fma_mixlo_f16 v117, s60, v146, v50                        ; cc210075 04cb243c
	v_fma_mixhi_f16 v117, s60, v147, v51                        ; cc220075 04cf263c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v118, s60, v148, v52                        ; cc210076 04d3283c
(invalid instruction)                                        ; cc1c0070
	v_subrev_f32_e32 v0, v112, v62                              ; 0a007d70
	v_fma_mixhi_f16 v118, s60, v149, v53                        ; cc220076 04d72a3c
(invalid instruction)                                        ; cc1c0071
	v_subrev_f32_e32 v0, v113, v62                              ; 0a007d71
(invalid instruction)                                        ; cc1c0072
	v_subrev_f32_e32 v0, v114, v62                              ; 0a007d72
	v_fma_mixlo_f16 v119, s60, v150, v54                        ; cc210077 04db2c3c
(invalid instruction)                                        ; cc1c0073
	v_subrev_f32_e32 v0, v115, v62                              ; 0a007d73
	v_fma_mixhi_f16 v119, s60, v151, v55                        ; cc220077 04df2e3c
(invalid instruction)                                        ; cc1c0074
	v_subrev_f32_e32 v0, v116, v62                              ; 0a007d74
(invalid instruction)                                        ; cc1c0075
	v_subrev_f32_e32 v0, v117, v62                              ; 0a007d75
(invalid instruction)                                        ; cc1b0070
	v_subrev_f32_e32 v0, v112, v61                              ; 0a007b70
(invalid instruction)                                        ; cc1c0076
	v_subrev_f32_e32 v0, v118, v62                              ; 0a007d76
(invalid instruction)                                        ; cc1b0071
	v_subrev_f32_e32 v0, v113, v61                              ; 0a007b71
(invalid instruction)                                        ; cc1b0072
	v_subrev_f32_e32 v0, v114, v61                              ; 0a007b72
(invalid instruction)                                        ; cc1b0073
	v_subrev_f32_e32 v0, v115, v61                              ; 0a007b73
(invalid instruction)                                        ; cc1c0077
	v_subrev_f32_e32 v0, v119, v62                              ; 0a007d77
(invalid instruction)                                        ; cc1b0074
	v_subrev_f32_e32 v0, v116, v61                              ; 0a007b74
(invalid instruction)                                        ; cc1b0075
	v_subrev_f32_e32 v0, v117, v61                              ; 0a007b75
(invalid instruction)                                        ; cc1b0076
	v_subrev_f32_e32 v0, v118, v61                              ; 0a007b76
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b0077
	v_subrev_f32_e32 v0, v119, v61                              ; 0a007b77
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v120, s60, v152, v28                        ; cc210078 0473303c
	v_fma_mixhi_f16 v120, s60, v153, v29                        ; cc220078 0477323c
	v_fma_mixlo_f16 v121, s60, v154, v30                        ; cc210079 047b343c
	v_fma_mixhi_f16 v121, s60, v155, v31                        ; cc220079 047f363c
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v123, s60, v158, v66                        ; cc21007b 050b3c3c
	v_fma_mixhi_f16 v123, s60, v159, v67                        ; cc22007b 050f3e3c
	buffer_load_b128 v[28:31], v59, s[32:35], null offen        ; c405c07c 4080401c 0000003b
	v_fma_mixlo_f16 v122, s60, v156, v64                        ; cc21007a 0503383c
	v_fma_mixhi_f16 v122, s60, v157, v65                        ; cc22007a 05073a3c
(invalid instruction)                                        ; cc1c0078
	v_subrev_f32_e32 v0, v120, v62                              ; 0a007d78
(invalid instruction)                                        ; cc1c0079
	v_subrev_f32_e32 v0, v121, v62                              ; 0a007d79
(invalid instruction)                                        ; cc1c007b
	v_subrev_f32_e32 v0, v123, v62                              ; 0a007d7b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c007a
	v_subrev_f32_e32 v0, v122, v62                              ; 0a007d7a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v124, s60, v160, v68                        ; cc21007c 0513403c
	buffer_load_b128 v[40:43], v59, s[32:35], null offen offset:16 ; c405c07c 40804028 0000103b
	v_fma_mixhi_f16 v124, s60, v161, v69                        ; cc22007c 0517423c
	v_fma_mixlo_f16 v125, s60, v162, v70                        ; cc21007d 051b443c
	v_fma_mixhi_f16 v125, s60, v163, v71                        ; cc22007d 051f463c
(invalid instruction)                                        ; cc1b0078
	v_subrev_f32_e32 v0, v120, v61                              ; 0a007b78
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v126, s60, v164, v76                        ; cc21007e 0533483c
	v_fma_mixhi_f16 v126, s60, v165, v77                        ; cc22007e 05374a3c
(invalid instruction)                                        ; cc1b0079
	v_subrev_f32_e32 v0, v121, v61                              ; 0a007b79
(invalid instruction)                                        ; cc1b007b
	v_subrev_f32_e32 v0, v123, v61                              ; 0a007b7b
	v_fma_mixlo_f16 v127, s60, v166, v78                        ; cc21007f 053b4c3c
	v_fma_mixhi_f16 v127, s60, v167, v79                        ; cc22007f 053f4e3c
(invalid instruction)                                        ; cc1b007a
	v_subrev_f32_e32 v0, v122, v61                              ; 0a007b7a
	v_lshl_add_u32 v112, v112, 5, s63                           ; d6460070 00fd0b70
	v_lshl_add_u32 v116, v116, 5, s63                           ; d6460074 00fd0b74
(invalid instruction)                                        ; cc1c007c
	v_subrev_f32_e32 v0, v124, v62                              ; 0a007d7c
(invalid instruction)                                        ; cc1c007d
	v_subrev_f32_e32 v0, v125, v62                              ; 0a007d7d
	v_lshl_add_u32 v120, v120, 5, s63                           ; d6460078 00fd0b78
	v_lshl_add_u32 v113, v113, 5, s63                           ; d6460071 00fd0b71
(invalid instruction)                                        ; cc1c007e
	v_subrev_f32_e32 v0, v126, v62                              ; 0a007d7e
	v_lshl_add_u32 v117, v117, 5, s63                           ; d6460075 00fd0b75
	v_lshl_add_u32 v121, v121, 5, s63                           ; d6460079 00fd0b79
(invalid instruction)                                        ; cc1c007f
	v_subrev_f32_e32 v0, v127, v62                              ; 0a007d7f
(invalid instruction)                                        ; cc0f0080
	v_min_num_f64_e32 v[1:2], v[112:113], v[116:117]            ; 1a02e970
	v_lshl_add_u32 v114, v114, 5, s63                           ; d6460072 00fd0b72
(invalid instruction)                                        ; cc1b007c
	v_subrev_f32_e32 v0, v124, v61                              ; 0a007b7c
	v_lshl_add_u32 v118, v118, 5, s63                           ; d6460076 00fd0b76
(invalid instruction)                                        ; cc1b007d
	v_subrev_f32_e32 v0, v125, v61                              ; 0a007b7d
	v_lshl_add_u32 v122, v122, 5, s63                           ; d646007a 00fd0b7a
(invalid instruction)                                        ; cc1b007e
	v_subrev_f32_e32 v0, v126, v61                              ; 0a007b7e
(invalid instruction)                                        ; cc0f0081
	v_min_num_f64_e32 v[1:2], v[113:114], v[117:118]            ; 1a02eb71
	v_lshl_add_u32 v115, v115, 5, s63                           ; d6460073 00fd0b73
(invalid instruction)                                        ; cc1b007f
	v_subrev_f32_e32 v0, v127, v61                              ; 0a007b7f
	v_lshl_add_u32 v119, v119, 5, s63                           ; d6460077 00fd0b77
(invalid instruction)                                        ; cc0f0080
	v_min_num_f64_e32 v[1:2], v[128:129], v[120:121]            ; 1a02f180
	v_lshl_add_u32 v123, v123, 5, s63                           ; d646007b 00fd0b7b
	v_lshl_add_u32 v124, v124, 5, s63                           ; d646007c 00fd0b7c
(invalid instruction)                                        ; cc0f0082
	v_min_num_f64_e32 v[1:2], v[114:115], v[118:119]            ; 1a02ed72
	v_lshl_add_u32 v125, v125, 5, s63                           ; d646007d 00fd0b7d
	v_lshl_add_u32 v126, v126, 5, s63                           ; d646007e 00fd0b7e
(invalid instruction)                                        ; cc0f0081
	v_min_num_f64_e32 v[1:2], v[129:130], v[121:122]            ; 1a02f381
	v_lshl_add_u32 v127, v127, 5, s63                           ; d646007f 00fd0b7f
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[115:116], v[119:120]            ; 1a02ef73
(invalid instruction)                                        ; cc0f0080
	v_min_num_f64_e32 v[1:2], v[128:129], v[124:125]            ; 1a02f980
(invalid instruction)                                        ; cc0f0082
	v_min_num_f64_e32 v[1:2], v[130:131], v[122:123]            ; 1a02f582
(invalid instruction)                                        ; cc0f0081
	v_min_num_f64_e32 v[1:2], v[129:130], v[125:126]            ; 1a02fb81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[131:132], v[123:124]            ; 1a02f783
(invalid instruction)                                        ; cc0f0082
	v_min_num_f64_e32 v[1:2], v[130:131], v[126:127]            ; 1a02fd82
(invalid instruction)                                        ; cc0f0080
	v_min_num_f64_e32 v[1:2], v[128:129], v[129:130]            ; 1a030380
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[131:132], v[127:128]            ; 1a02ff83
(invalid instruction)                                        ; cc0f0080
	v_min_num_f64_e32 v[1:2], v[128:129], v[130:131]            ; 1a030580
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0080
	v_min_num_f64_e32 v[1:2], v[128:129], v[131:132]            ; 1a030780
	v_permlanex16_b32 v140, v128, s57, s58 op_sel:[1,1]         ; d65c188c 00e87380
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0080
	v_min_num_f64_e32 v[1:2], v[128:129], v[140:141]            ; 1a031980
(invalid instruction)                                        ; d532108d
	v_cndmask_b32_e32 v1, v128, v128, vcc_lo                    ; 02030180
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d531008d
	v_cndmask_b32_e32 v1, s56, v141, vcc_lo                     ; 02031a38
(invalid instruction)                                        ; d58b008e
	v_cndmask_b32_e32 v0, v141, v128, vcc_lo                    ; 0201018d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v142, v142                                    ; 7f1c558e
	v_fma_mix_f32 v146, v115, v142, neg(0) op_sel_hi:[1,0,0]    ; cc200092 8a031d73
	v_fma_mix_f32 v145, v114, v142, neg(0) op_sel_hi:[1,0,0]    ; cc200091 8a031d72
	v_fma_mix_f32 v114, v114, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200872 8a031d72
	v_fma_mix_f32 v144, v113, v142, neg(0) op_sel_hi:[1,0,0]    ; cc200090 8a031d71
	v_fma_mix_f32 v113, v113, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200871 8a031d71
	v_fma_mix_f32 v147, v116, v142, neg(0) op_sel_hi:[1,0,0]    ; cc200093 8a031d74
	v_fma_mix_f32 v116, v116, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200874 8a031d74
	buffer_load_b128 v[48:51], v59, s[32:35], null offen offset:64 ; c405c07c 40804030 0000403b
	v_fma_mix_f32 v143, v112, v142, neg(0) op_sel_hi:[1,0,0]    ; cc20008f 8a031d70
	v_fma_mix_f32 v112, v112, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200870 8a031d70
	v_fma_mix_f32 v148, v117, v142, neg(0) op_sel_hi:[1,0,0]    ; cc200094 8a031d75
	v_fma_mix_f32 v115, v115, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200873 8a031d73
	v_fma_mix_f32 v117, v117, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200875 8a031d75
	v_fma_mix_f32 v149, v118, v142, neg(0) op_sel_hi:[1,0,0]    ; cc200095 8a031d76
	v_fma_mix_f32 v118, v118, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200876 8a031d76
	v_fma_mix_f32 v150, v119, v142, neg(0) op_sel_hi:[1,0,0]    ; cc200096 8a031d77
	buffer_load_b128 v[52:55], v59, s[32:35], null offen offset:80 ; c405c07c 40804034 0000503b
	v_fma_mix_f32 v119, v119, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a031d77
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v145, v114, vcc_lo                    ; 0202e591
	v_fma_mix_f32 v151, v120, v142, neg(0) op_sel_hi:[1,0,0]    ; cc200097 8a031d78
	v_fma_mix_f32 v120, v120, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200878 8a031d78
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v147, v116, vcc_lo                    ; 0202e993
	v_fma_mix_f32 v152, v121, v142, neg(0) op_sel_hi:[1,0,0]    ; cc200098 8a031d79
	v_fma_mix_f32 v121, v121, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200879 8a031d79
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v143, v112, vcc_lo                    ; 0202e18f
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v144, v113, vcc_lo                    ; 0202e390
	s_lshr_b32 s6, s6, 2                                        ; 85068206
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v146, v115, vcc_lo                    ; 0202e792
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v148, v117, vcc_lo                    ; 0202eb94
	v_fma_mix_f32 v153, v122, v142, neg(0) op_sel_hi:[1,0,0]    ; cc200099 8a031d7a
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v149, v118, vcc_lo                    ; 0202ed95
	v_fma_mix_f32 v122, v122, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087a 8a031d7a
	v_fma_mix_f32 v154, v123, v142, neg(0) op_sel_hi:[1,0,0]    ; cc20009a 8a031d7b
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v150, v119, vcc_lo                    ; 0202ef96
	v_fma_mix_f32 v123, v123, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087b 8a031d7b
	v_fma_mix_f32 v155, v124, v142, neg(0) op_sel_hi:[1,0,0]    ; cc20009b 8a031d7c
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v151, v120, vcc_lo                    ; 0202f197
	v_fma_mix_f32 v124, v124, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087c 8a031d7c
	v_fma_mix_f32 v156, v125, v142, neg(0) op_sel_hi:[1,0,0]    ; cc20009c 8a031d7d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v9, v9, s6, v6                                   ; d6550009 04180d09
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v152, v121, vcc_lo                    ; 0202f398
	v_fma_mix_f32 v125, v125, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087d 8a031d7d
	v_fma_mix_f32 v157, v126, v142, neg(0) op_sel_hi:[1,0,0]    ; cc20009d 8a031d7e
	v_fma_mix_f32 v126, v126, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087e 8a031d7e
	v_fma_mix_f32 v158, v127, v142, neg(0) op_sel_hi:[1,0,0]    ; cc20009e 8a031d7f
	v_fma_mix_f32 v127, v127, v142, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087f 8a031d7f
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v153, v122, vcc_lo                    ; 0202f599
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[12:13], v[14:15], 0 ; cc464040 1a021d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[26:27], 0 ; cc464068 1a02350c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v154, v123, vcc_lo                    ; 0202f79a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[82:83], 0 ; cc464070 1a02a50c
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v155, v124, vcc_lo                    ; 0202f99b
	v_lshlrev_b32_e32 v9, 2, v9                                 ; 30121282
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v156, v125, vcc_lo                    ; 0202fb9c
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v157, v126, vcc_lo                    ; 0202fd9d
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v158, v127, vcc_lo                    ; 0202ff9e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[12:13], v[10:11], 0 ; cc464078 1a02150c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[72:73], v[32:33], v[64:71] ; cc464040 1d024148
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[36:37], v[104:111] ; cc464068 1da24948
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[72:73], v[84:85], v[112:119] ; cc464070 1dc2a948
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[16:17], v[120:127] ; cc464078 1de22148
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[132:133], v[44:45], v[64:71] ; cc464040 1d025984
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[132:133], v[38:39], v[104:111] ; cc464068 1da24d84
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[132:133], v[86:87], v[112:119] ; cc464070 1dc2ad84
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[132:133], v[20:21], v[120:127] ; cc464078 1de22984
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[136:137], v[18:19], v[64:71] ; cc464040 1d022588
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[136:137], v[46:47], v[104:111] ; cc464068 1da25d88
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[136:137], v[90:91], v[112:119] ; cc464070 1dc2b588
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[136:137], v[56:57], v[120:127] ; cc464078 1de27188
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[14:15], 0 ; cc464048 1a021d18
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[26:27], 0 ; cc464068 1a023518
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[82:83], 0 ; cc464070 1a02a518
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[10:11], 0 ; cc464078 1a021518
	buffer_load_b128 v[24:27], v9, s[36:39], null offen         ; c405c07c 40804818 00000009
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[102:103], v[32:33], v[72:79] ; cc464048 1d224166
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[102:103], v[36:37], v[104:111] ; cc464068 1da24966
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[102:103], v[84:85], v[112:119] ; cc464070 1dc2a966
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[102:103], v[16:17], v[120:127] ; cc464078 1de22166
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[134:135], v[44:45], v[72:79] ; cc464048 1d225986
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[134:135], v[38:39], v[104:111] ; cc464068 1da24d86
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[134:135], v[86:87], v[112:119] ; cc464070 1dc2ad86
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[134:135], v[20:21], v[120:127] ; cc464078 1de22986
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[138:139], v[18:19], v[72:79] ; cc464048 1d22258a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[138:139], v[46:47], v[104:111] ; cc464068 1da25d8a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[138:139], v[90:91], v[112:119] ; cc464070 1dc2b58a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[138:139], v[56:57], v[120:127] ; cc464078 1de2718a
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	ds_store_2addr_b64 v23, v[12:13], v[10:11] offset1:32       ; d9382000 000a0c17
	buffer_load_b128 v[12:15], v9, s[36:39], null offen offset:512 ; c405c07c 4080480c 00020009
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	ds_store_2addr_b64 v1, v[60:61], v[10:11] offset1:32        ; d9382000 000a3c01
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	ds_store_2addr_b64 v34, v[62:63], v[0:1] offset1:32         ; d9382000 00003e22
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	ds_store_2addr_b64 v35, v[64:65], v[0:1] offset1:32         ; d9382000 00004023
	buffer_load_b128 v[16:19], v9, s[36:39], null offen offset:1024 ; c405c07c 40804810 00040009
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[0:1], v7                                      ; d9d80000 00000007
	ds_load_b64 v[10:11], v7 offset:4096                        ; d9d81000 0a000007
	ds_load_b64 v[20:21], v7 offset:8192                        ; d9d82000 14000007
	buffer_load_b128 v[36:39], v9, s[36:39], null offen offset:1536 ; c405c07c 40804824 00060009
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[22:23], v0                           ; 7e2cdd00
	s_wait_loadcnt 0x7                                          ; bfc00007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v33, v23, v29 :: v_dual_mul_f32 v32, v22, v28 ; c8c63b17 21203916
	v_cvt_pk_f32_fp8_e32 v[22:23], v128                         ; 7e2cdd80
	v_dual_mul_f32 v35, v23, v31 :: v_dual_mul_f32 v34, v22, v30 ; c8c63f17 23223d16
	v_cvt_pk_f32_fp8_e32 v[22:23], v1                           ; 7e2cdd01
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v69, v23, v41 :: v_dual_mul_f32 v68, v22, v40 ; c8c65317 45445116
	ds_load_b64 v[22:23], v7 offset:12288                       ; d9d83000 16000007
	buffer_load_b128 v[44:47], v9, s[36:39], null offen offset:2048 ; c405c07c 4080482c 00080009
	ds_load_b64 v[56:57], v7 offset:256                         ; d9d80100 38000007
	buffer_load_b128 v[60:63], v9, s[36:39], null offen offset:2560 ; c405c07c 4080483c 000a0009
	v_cvt_pk_f32_fp8_e32 v[0:1], v129                           ; 7e00dd81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v71, v1, v43 :: v_dual_mul_f32 v70, v0, v42  ; c8c65701 47465500
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[0:1], v10                            ; 7e00dd0a
	v_dual_mul_f32 v73, v1, v29 :: v_dual_mul_f32 v72, v0, v28  ; c8c63b01 49483900
	buffer_load_b128 v[64:67], v9, s[36:39], null offen offset:3072 ; c405c07c 40804840 000c0009
	v_cvt_pk_f32_fp8_e32 v[0:1], v138                           ; 7e00dd8a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v75, v1, v31 :: v_dual_mul_f32 v74, v0, v30  ; c8c63f01 4b4a3d00
	v_cvt_pk_f32_fp8_e32 v[0:1], v11                            ; 7e00dd0b
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	v_dual_mul_f32 v77, v1, v41 :: v_dual_mul_f32 v76, v0, v40  ; c8c65301 4d4c5100
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[0:1], v20                            ; 7e00dd14
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v81, v1, v29 :: v_dual_mul_f32 v80, v0, v28  ; c8c63b01 51503900
	v_cvt_pk_f32_fp8_e32 v[0:1], v148                           ; 7e00dd94
	v_dual_mul_f32 v83, v1, v31 :: v_dual_mul_f32 v82, v0, v30  ; c8c63f01 53523d00
	v_cvt_pk_f32_fp8_e32 v[0:1], v21                            ; 7e00dd15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_dual_mul_f32 v79, v11, v43 :: v_dual_mul_f32 v84, v0, v40 ; c8c6570b 4f545100
	v_dual_mul_f32 v85, v1, v41 :: v_dual_mul_f32 v78, v10, v42 ; c8c65301 554e550a
	ds_load_b64 v[10:11], v7 offset:4352                        ; d9d81100 0a000007
	v_cvt_pk_f32_fp8_e32 v[0:1], v149                           ; 7e00dd95
	v_dual_mul_f32 v87, v1, v43 :: v_dual_mul_f32 v86, v0, v42  ; c8c65701 57565500
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[0:1], v22                            ; 7e00dd16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v88, v0, v28                                  ; 10b03900
	v_mul_f32_e32 v89, v1, v29                                  ; 10b23b01
	v_cvt_pk_f32_fp8_e32 v[0:1], v150                           ; 7e00dd96
	v_dual_mul_f32 v91, v1, v31 :: v_dual_mul_f32 v90, v0, v30  ; c8c63f01 5b5a3d00
	v_cvt_pk_f32_fp8_e32 v[0:1], v23                            ; 7e00dd17
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v93, v1, v41 :: v_dual_mul_f32 v92, v0, v40  ; c8c65301 5d5c5100
	v_cvt_pk_f32_fp8_e32 v[0:1], v151                           ; 7e00dd97
	buffer_load_b128 v[20:23], v9, s[36:39], null offen offset:3584 ; c405c07c 40804814 000e0009
	ds_load_b64 v[28:29], v7 offset:8448                        ; d9d82100 1c000007
	v_dual_mul_f32 v95, v1, v43 :: v_dual_mul_f32 v94, v0, v42  ; c8c65701 5f5e5500
	buffer_load_b128 v[40:43], v9, s[36:39], null offen offset:4096 ; c405c07c 40804828 00100009
	ds_load_b64 v[6:7], v7 offset:12544                         ; d9d83100 06000007
	buffer_load_b128 v[108:111], v9, s[36:39], null offen offset:4608 ; c405c07c 4080486c 00120009
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[0:1], v56                            ; 7e00dd38
	s_wait_loadcnt 0xb                                          ; bfc0000b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v97, v1, v49 :: v_dual_mul_f32 v96, v0, v48  ; c8c66301 61606100
	v_cvt_pk_f32_fp8_e32 v[0:1], v184                           ; 7e00ddb8
	v_dual_mul_f32 v99, v1, v51 :: v_dual_mul_f32 v98, v0, v50  ; c8c66701 63626500
	v_cvt_pk_f32_fp8_e32 v[0:1], v57                            ; 7e00dd39
	s_wait_loadcnt 0xa                                          ; bfc0000a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v101, v1, v53 :: v_dual_mul_f32 v100, v0, v52 ; c8c66b01 65646900
	v_cvt_pk_f32_fp8_e32 v[0:1], v185                           ; 7e00ddb9
	v_dual_mul_f32 v103, v1, v55 :: v_dual_mul_f32 v102, v0, v54 ; c8c66f01 67666d00
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[0:1], v10                            ; 7e00dd0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v105, v1, v49 :: v_dual_mul_f32 v104, v0, v48 ; c8c66301 69686100
	v_cvt_pk_f32_fp8_e32 v[0:1], v138                           ; 7e00dd8a
	v_dual_mul_f32 v107, v1, v51 :: v_dual_mul_f32 v106, v0, v50 ; c8c66701 6b6a6500
	v_cvt_pk_f32_fp8_e32 v[0:1], v11                            ; 7e00dd0b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v117, v1, v53 :: v_dual_mul_f32 v116, v0, v52 ; c8c66b01 75746900
	v_cvt_pk_f32_fp8_e32 v[0:1], v139                           ; 7e00dd8b
	ds_load_b64 v[10:11], v8 offset:16384                       ; d9d84000 0a000008
	ds_load_b64 v[30:31], v8 offset:20480                       ; d9d85000 1e000008
	buffer_load_b128 v[112:115], v9, s[36:39], null offen offset:5120 ; c405c07c 40804870 00140009
	ds_load_b64 v[56:57], v8 offset:24576                       ; d9d86000 38000008
	ds_load_b64 v[120:121], v8 offset:28672                     ; d9d87000 78000008
	buffer_load_b128 v[124:127], v9, s[36:39], null offen offset:5632 ; c405c07c 4080487c 00160009
	v_dual_mul_f32 v119, v1, v55 :: v_dual_mul_f32 v118, v0, v54 ; c8c66f01 77766d00
	s_wait_dscnt 0x5                                            ; bfc60005
	v_cvt_pk_f32_fp8_e32 v[0:1], v28                            ; 7e00dd1c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v129, v1, v49 :: v_dual_mul_f32 v128, v0, v48 ; c8c66301 81806100
	v_cvt_pk_f32_fp8_e32 v[0:1], v156                           ; 7e00dd9c
	v_dual_mul_f32 v131, v1, v51 :: v_dual_mul_f32 v130, v0, v50 ; c8c66701 83826500
	v_cvt_pk_f32_fp8_e32 v[0:1], v29                            ; 7e00dd1d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v133, v1, v53 :: v_dual_mul_f32 v132, v0, v52 ; c8c66b01 85846900
	v_cvt_pk_f32_fp8_e32 v[0:1], v157                           ; 7e00dd9d
	ds_load_b64 v[28:29], v8 offset:16640                       ; d9d84100 1c000008
	ds_load_b64 v[122:123], v8 offset:20736                     ; d9d85100 7a000008
	ds_load_b64 v[138:139], v8 offset:24832                     ; d9d86100 8a000008
	ds_load_b64 v[140:141], v8 offset:28928                     ; d9d87100 8c000008
	v_dual_mul_f32 v135, v1, v55 :: v_dual_mul_f32 v134, v0, v54 ; c8c66f01 87866d00
	s_wait_dscnt 0x8                                            ; bfc60008
	v_cvt_pk_f32_fp8_e32 v[0:1], v6                             ; 7e00dd06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v137, v1, v49                                 ; 11126301
	v_mul_f32_e32 v136, v0, v48                                 ; 11106100
	v_cvt_pk_f32_fp8_e32 v[0:1], v134                           ; 7e00dd86
	v_dual_mul_f32 v147, v1, v51 :: v_dual_mul_f32 v146, v0, v50 ; c8c66701 93926500
	buffer_load_b128 v[48:51], v9, s[36:39], null offen offset:6144 ; c405c07c 40804830 00180009
	v_cvt_pk_f32_fp8_e32 v[0:1], v7                             ; 7e00dd07
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v149, v1, v53 :: v_dual_mul_f32 v148, v0, v52 ; c8c66b01 95946900
	v_cvt_pk_f32_fp8_e32 v[0:1], v135                           ; 7e00dd87
	ds_load_b64 v[6:7], v8 offset:16896                         ; d9d84200 06000008
	ds_load_b64 v[52:53], v8 offset:20992                       ; d9d85200 34000008
	ds_load_b64 v[142:143], v8 offset:25088                     ; d9d86200 8e000008
	ds_load_b64 v[144:145], v8 offset:29184                     ; d9d87200 90000008
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_dual_mov_b32 v153, v37 :: v_dual_mov_b32 v152, v36        ; ca100125 99980124
	v_dual_mov_b32 v37, v69 :: v_dual_mov_b32 v36, v68          ; ca100145 25240144
	v_dual_mov_b32 v155, v39 :: v_dual_mov_b32 v154, v38        ; ca100127 9b9a0126
	v_dual_mov_b32 v39, v71 :: v_dual_mov_b32 v38, v70          ; ca100147 27260146
	buffer_load_b128 v[68:71], v9, s[36:39], null offen offset:6656 ; c405c07c 40804844 001a0009
	v_dual_mul_f32 v151, v1, v55 :: v_dual_mul_f32 v150, v0, v54 ; c8c66f01 97966d00
	ds_load_b64 v[0:1], v8 offset:17152                         ; d9d84300 00000008
	ds_load_b64 v[54:55], v8 offset:21248                       ; d9d85300 36000008
	ds_load_b64 v[156:157], v8 offset:25344                     ; d9d86300 9c000008
	ds_load_b64 v[158:159], v8 offset:29440                     ; d9d87300 9e000008
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mov_b32 v163, v111 :: v_dual_mov_b32 v162, v110      ; ca10016f a3a2016e
	v_dual_mov_b32 v111, v119 :: v_dual_mov_b32 v110, v118      ; ca100177 6f6e0176
	v_dual_mov_b32 v161, v109 :: v_dual_mov_b32 v160, v108      ; ca10016d a1a0016c
	v_dual_mov_b32 v109, v117 :: v_dual_mov_b32 v108, v116      ; ca100175 6d6c0174
	buffer_load_b128 v[116:119], v9, s[36:39], null offen offset:7168 ; c405c07c 40804874 001c0009
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[30:31], v[72:79] ; cc464048 1d223d18
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[56:57], v[80:87] ; cc464050 1d427118
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[24:25], v[10:11], v[32:39] ; cc464020 1c821518
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[120:121], v[88:95] ; cc464058 1d62f118
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[10:11], v[96:103] ; cc464060 1d82151a
	s_wait_dscnt 0x4                                            ; bfc60004
	v_dual_mov_b32 v11, v145 :: v_dual_mov_b32 v10, v144        ; ca100191 0b0a0190
	v_dual_mov_b32 v145, v137 :: v_dual_mov_b32 v144, v136      ; ca100189 91900188
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[56:57], v[128:135] ; cc464080 1e02711a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[30:31], v[104:111] ; cc464068 1da23d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[26:27], v[120:121], v[144:151] ; cc464090 1e42f11a
	ds_load_b64 v[24:25], v8 offset:17408                       ; d9d84400 18000008
	ds_load_b64 v[26:27], v8 offset:21504                       ; d9d85400 1a000008
	ds_load_b64 v[30:31], v8 offset:25600                       ; d9d86400 1e000008
	ds_load_b64 v[56:57], v8 offset:29696                       ; d9d87400 38000008
	buffer_load_b128 v[164:167], v9, s[36:39], null offen offset:7680 ; c405c07c 408048a4 001e0009
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[12:13], v[122:123], v[72:79] ; cc464048 1d22f50c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[138:139], v[80:87] ; cc464050 1d43150c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[12:13], v[28:29], v[32:39] ; cc464020 1c82390c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[140:141], v[88:95] ; cc464058 1d63190c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[14:15], v[28:29], v[96:103] ; cc464060 1d82390e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[138:139], v[128:135] ; cc464080 1e03150e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[122:123], v[104:111] ; cc464068 1da2f50e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[14:15], v[140:141], v[144:151] ; cc464090 1e43190e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[16:17], v[52:53], v[72:79] ; cc464048 1d226910
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[142:143], v[80:87] ; cc464050 1d431d10
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[6:7], v[32:39] ; cc464020 1c820d10
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[10:11], v[88:95] ; cc464058 1d621510
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[18:19], v[6:7], v[96:103] ; cc464060 1d820d12
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[142:143], v[128:135] ; cc464080 1e031d12
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[52:53], v[104:111] ; cc464068 1da26912
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[18:19], v[10:11], v[144:151] ; cc464090 1e421512
	ds_load_b64 v[12:13], v8 offset:17664                       ; d9d84500 0c000008
	ds_load_b64 v[14:15], v8 offset:21760                       ; d9d85500 0e000008
	ds_load_b64 v[28:29], v8 offset:25856                       ; d9d86500 1c000008
	ds_load_b64 v[120:121], v8 offset:29952                     ; d9d87500 78000008
	ds_load_b64 v[6:7], v8 offset:17920                         ; d9d84600 06000008
	ds_load_b64 v[10:11], v8 offset:22016                       ; d9d85600 0a000008
	ds_load_b64 v[16:17], v8 offset:26112                       ; d9d86600 10000008
	ds_load_b64 v[18:19], v8 offset:30208                       ; d9d87600 12000008
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[152:153], v[54:55], v[72:79] ; cc464048 1d226d98
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[152:153], v[0:1], v[32:39] ; cc464020 1c820198
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[154:155], v[0:1], v[96:103] ; cc464060 1d82019a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[154:155], v[54:55], v[104:111] ; cc464068 1da26d9a
	ds_load_b64 v[0:1], v8 offset:18176                         ; d9d84700 00000008
	ds_load_b64 v[52:53], v8 offset:22272                       ; d9d85700 34000008
	ds_load_b64 v[54:55], v8 offset:26368                       ; d9d86700 36000008
	ds_load_b64 v[122:123], v8 offset:30464                     ; d9d87700 7a000008
	s_wait_dscnt 0x11                                           ; bfc60011
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[152:153], v[156:157], v[80:87] ; cc464050 1d433998
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[152:153], v[158:159], v[88:95] ; cc464058 1d633d98
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[154:155], v[156:157], v[128:135] ; cc464080 1e03399a
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[44:45], v[26:27], v[72:79] ; cc464048 1d22352c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[44:45], v[24:25], v[32:39] ; cc464020 1c82312c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[24:25], v[96:103] ; cc464060 1d82312e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[26:27], v[104:111] ; cc464068 1da2352e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[30:31], v[80:87] ; cc464050 1d423d2c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[56:57], v[88:95] ; cc464058 1d62712c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[154:155], v[158:159], v[144:151] ; cc464090 1e433d9a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[30:31], v[128:135] ; cc464080 1e023d2e
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[60:61], v[14:15], v[72:79] ; cc464048 1d221d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[60:61], v[12:13], v[32:39] ; cc464020 1c82193c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[62:63], v[12:13], v[96:103] ; cc464060 1d82193e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[62:63], v[14:15], v[104:111] ; cc464068 1da21d3e
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[28:29], v[80:87] ; cc464050 1d42393c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[56:57], v[144:151] ; cc464090 1e42712e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[28:29], v[128:135] ; cc464080 1e02393e
	ds_load_b64 v[24:25], v8 offset:18432                       ; d9d84800 18000008
	ds_load_b64 v[26:27], v8 offset:22528                       ; d9d85800 1a000008
	ds_load_b64 v[30:31], v8 offset:26624                       ; d9d86800 1e000008
	ds_load_b64 v[44:45], v8 offset:30720                       ; d9d87800 2c000008
	ds_load_b64 v[12:13], v8 offset:18688                       ; d9d84900 0c000008
	ds_load_b64 v[14:15], v8 offset:22784                       ; d9d85900 0e000008
	ds_load_b64 v[28:29], v8 offset:26880                       ; d9d86900 1c000008
	ds_load_b64 v[46:47], v8 offset:30976                       ; d9d87900 2e000008
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[60:61], v[120:121], v[88:95] ; cc464058 1d62f13c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[64:65], v[10:11], v[72:79] ; cc464048 1d221540
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[64:65], v[6:7], v[32:39] ; cc464020 1c820d40
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[6:7], v[96:103] ; cc464060 1d820d42
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[64:65], v[16:17], v[80:87] ; cc464050 1d422140
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[66:67], v[10:11], v[104:111] ; cc464068 1da21542
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[120:121], v[144:151] ; cc464090 1e42f13e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[16:17], v[128:135] ; cc464080 1e022142
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[18:19], v[88:95] ; cc464058 1d622540
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[20:21], v[52:53], v[72:79] ; cc464048 1d226914
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[20:21], v[0:1], v[32:39] ; cc464020 1c820114
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[22:23], v[0:1], v[96:103] ; cc464060 1d820116
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[54:55], v[80:87] ; cc464050 1d426d14
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[52:53], v[104:111] ; cc464068 1da26916
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[66:67], v[18:19], v[144:151] ; cc464090 1e422542
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[54:55], v[128:135] ; cc464080 1e026d16
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[122:123], v[88:95] ; cc464058 1d62f514
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[22:23], v[122:123], v[144:151] ; cc464090 1e42f516
	ds_load_b64 v[6:7], v8 offset:18944                         ; d9d84a00 06000008
	ds_load_b64 v[10:11], v8 offset:23040                       ; d9d85a00 0a000008
	ds_load_b64 v[16:17], v8 offset:27136                       ; d9d86a00 10000008
	ds_load_b64 v[18:19], v8 offset:31232                       ; d9d87a00 12000008
	ds_load_b64 v[0:1], v8 offset:19200                         ; d9d84b00 00000008
	ds_load_b64 v[20:21], v8 offset:23296                       ; d9d85b00 14000008
	ds_load_b64 v[22:23], v8 offset:27392                       ; d9d86b00 16000008
	ds_load_b64 v[52:53], v8 offset:31488                       ; d9d87b00 34000008
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[40:41], v[26:27], v[72:79] ; cc464048 1d223528
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[40:41], v[24:25], v[32:39] ; cc464020 1c823128
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[30:31], v[80:87] ; cc464050 1d423d28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[24:25], v[96:103] ; cc464060 1d82312a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[26:27], v[104:111] ; cc464068 1da2352a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[30:31], v[128:135] ; cc464080 1e023d2a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[44:45], v[88:95] ; cc464058 1d625928
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[44:45], v[144:151] ; cc464090 1e42592a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[160:161], v[14:15], v[72:79] ; cc464048 1d221da0
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[160:161], v[12:13], v[32:39] ; cc464020 1c8219a0
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[160:161], v[28:29], v[80:87] ; cc464050 1d4239a0
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[162:163], v[12:13], v[96:103] ; cc464060 1d8219a2
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[162:163], v[14:15], v[104:111] ; cc464068 1da21da2
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[162:163], v[28:29], v[128:135] ; cc464080 1e0239a2
	ds_load_b64 v[24:25], v8 offset:19456                       ; d9d84c00 18000008
	ds_load_b64 v[26:27], v8 offset:23552                       ; d9d85c00 1a000008
	ds_load_b64 v[30:31], v8 offset:27648                       ; d9d86c00 1e000008
	ds_load_b64 v[40:41], v8 offset:31744                       ; d9d87c00 28000008
	ds_load_b64 v[12:13], v8 offset:19712                       ; d9d84d00 0c000008
	ds_load_b64 v[14:15], v8 offset:23808                       ; d9d85d00 0e000008
	ds_load_b64 v[28:29], v8 offset:27904                       ; d9d86d00 1c000008
	ds_load_b64 v[42:43], v8 offset:32000                       ; d9d87d00 2a000008
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[46:47], v[88:95] ; cc464058 1d625da0
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[162:163], v[46:47], v[144:151] ; cc464090 1e425da2
	s_wait_loadcnt_dscnt 0x50e                                  ; bfc8050e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[112:113], v[10:11], v[72:79] ; cc464048 1d221570
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[112:113], v[6:7], v[32:39] ; cc464020 1c820d70
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[112:113], v[16:17], v[80:87] ; cc464050 1d422170
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[114:115], v[6:7], v[96:103] ; cc464060 1d820d72
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[114:115], v[10:11], v[104:111] ; cc464068 1da21572
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[114:115], v[16:17], v[128:135] ; cc464080 1e022172
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[112:113], v[18:19], v[88:95] ; cc464058 1d622570
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[114:115], v[18:19], v[144:151] ; cc464090 1e422572
	s_wait_loadcnt_dscnt 0x40a                                  ; bfc8040a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[124:125], v[20:21], v[72:79] ; cc464048 1d22297c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[124:125], v[0:1], v[32:39] ; cc464020 1c82017c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[124:125], v[22:23], v[80:87] ; cc464050 1d422d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[126:127], v[0:1], v[96:103] ; cc464060 1d82017e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[126:127], v[20:21], v[104:111] ; cc464068 1da2297e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[126:127], v[22:23], v[128:135] ; cc464080 1e022d7e
	ds_load_b64 v[6:7], v8 offset:19968                         ; d9d84e00 06000008
	ds_load_b64 v[10:11], v8 offset:24064                       ; d9d85e00 0a000008
	ds_load_b64 v[16:17], v8 offset:28160                       ; d9d86e00 10000008
	ds_load_b64 v[18:19], v8 offset:32256                       ; d9d87e00 12000008
	ds_load_b64 v[0:1], v8 offset:20224                         ; d9d84f00 00000008
	ds_load_b64 v[20:21], v8 offset:24320                       ; d9d85f00 14000008
	ds_load_b64 v[22:23], v8 offset:28416                       ; d9d86f00 16000008
	ds_load_b64 v[8:9], v8 offset:32512                         ; d9d87f00 08000008
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[124:125], v[52:53], v[88:95] ; cc464058 1d62697c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[126:127], v[52:53], v[144:151] ; cc464090 1e42697e
	s_wait_loadcnt_dscnt 0x30e                                  ; bfc8030e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[48:49], v[26:27], v[72:79] ; cc464048 1d223530
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[48:49], v[24:25], v[32:39] ; cc464020 1c823130
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[30:31], v[80:87] ; cc464050 1d423d30
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[24:25], v[96:103] ; cc464060 1d823132
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[50:51], v[26:27], v[104:111] ; cc464068 1da23532
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[30:31], v[128:135] ; cc464080 1e023d32
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[40:41], v[88:95] ; cc464058 1d625130
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[50:51], v[40:41], v[144:151] ; cc464090 1e425132
	s_wait_loadcnt_dscnt 0x20a                                  ; bfc8020a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[68:69], v[14:15], v[72:79] ; cc464048 1d221d44
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[68:69], v[12:13], v[32:39] ; cc464020 1c821944
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[28:29], v[80:87] ; cc464050 1d423944
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[12:13], v[96:103] ; cc464060 1d821946
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[14:15], v[104:111] ; cc464068 1da21d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[28:29], v[128:135] ; cc464080 1e023946
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[42:43], v[88:95] ; cc464058 1d625544
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[42:43], v[144:151] ; cc464090 1e425546
	s_wait_loadcnt_dscnt 0x106                                  ; bfc80106
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[116:117], v[10:11], v[72:79] ; cc464048 1d221574
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[116:117], v[6:7], v[32:39] ; cc464020 1c820d74
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[116:117], v[16:17], v[80:87] ; cc464050 1d422174
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[118:119], v[6:7], v[96:103] ; cc464060 1d820d76
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[118:119], v[10:11], v[104:111] ; cc464068 1da21576
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[118:119], v[16:17], v[128:135] ; cc464080 1e022176
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[116:117], v[18:19], v[88:95] ; cc464058 1d622574
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[118:119], v[18:19], v[144:151] ; cc464090 1e422576
	s_wait_loadcnt_dscnt 0x2                                    ; bfc80002
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[164:165], v[20:21], v[72:79] ; cc464048 1d2229a4
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[164:165], v[0:1], v[32:39] ; cc464020 1c8201a4
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[164:165], v[22:23], v[80:87] ; cc464050 1d422da4
	s_cmp_lg_i32 s46, 0                                         ; bf01802e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[166:167], v[0:1], v[96:103] ; cc464060 1d8201a6
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[166:167], v[20:21], v[104:111] ; cc464068 1da229a6
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[166:167], v[22:23], v[128:135] ; cc464080 1e022da6
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[164:165], v[8:9], v[88:95] ; cc464058 1d6211a4
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[166:167], v[8:9], v[144:151] ; cc464090 1e4211a6
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_cbranch_scc1 BB3                                          ; bfa20008
BB1:
	v_add3_u32 v4, v2, s2, s26                                  ; d6550004 00680502
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v3, v4, v5                                   ; d6550004 04160903
	buffer_store_b64 v[0:1], v4, s[20:23], null offen           ; c406c07c 40802800 00000004
BB3:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_lg_i32 s49, 0                                         ; bf018031
	s_cbranch_scc1 BB6                                          ; bfa20008
BB4:
	v_add3_u32 v4, v2, s2, s24                                  ; d6550004 00600502
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v3, v4, v5                                   ; d6550004 04160903
	buffer_store_b64 v[0:1], v4, s[20:23], null offen           ; c406c07c 40802800 00000004
BB6:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_cmp_lg_i32 s52, 0                                         ; bf018034
	s_cbranch_scc1 BB9                                          ; bfa20008
BB7:
	v_add3_u32 v4, v2, s2, s18                                  ; d6550004 00480502
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v3, v4, v5                                   ; d6550004 04160903
	buffer_store_b64 v[0:1], v4, s[20:23], null offen           ; c406c07c 40802800 00000004
BB9:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_mov_b32 s3, src_scc                                       ; be8300fd
	s_cmp_lg_i32 s54, 0                                         ; bf018036
	s_cbranch_scc1 BB12                                         ; bfa20008
BB10:
	v_add3_u32 v2, v2, s2, s40                                  ; d6550002 00a00502
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[0:1], v2, s[20:23], null offen           ; c406c07c 40802800 00000002
BB12:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_mov_b32 s63, src_scc                                      ; bebf00fd
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s0, s63                                           ; be80003f
	s_cbranch_scc1 BB15                                         ; bfa20008
BB13:
	v_add3_u32 v2, v58, s2, s26                                 ; d6550002 0068053a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[0:1], v2, s[20:23], null offen           ; c406c07c 40802800 00000002
BB15:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc1 BB18                                         ; bfa20008
BB16:
	v_add3_u32 v2, v58, s2, s24                                 ; d6550002 0060053a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[0:1], v2, s[20:23], null offen           ; c406c07c 40802800 00000002
BB18:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_cmp_lg_i32 s3, 0                                          ; bf018003
	s_cbranch_scc1 BB21                                         ; bfa20008
BB19:
	v_add3_u32 v2, v58, s2, s18                                 ; d6550002 0048053a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[0:1], v2, s[20:23], null offen           ; c406c07c 40802800 00000002
BB21:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB24                                         ; bfa20008
BB22:
	v_add3_u32 v58, v58, s2, s40                                ; d655003a 00a0053a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v3, v3, v58, v5                                  ; d6550003 04167503
	buffer_store_b64 v[0:1], v3, s[20:23], null offen           ; c406c07c 40802800 00000003
BB24:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
