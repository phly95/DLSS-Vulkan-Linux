BB0:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s10, s1                                           ; be8a0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_pack_ll_b32_b16 s21, ttmp7, 0                             ; 99158073
	s_clause 0x4                                                ; bf850004
	s_load_b128 s[12:15], s[0:1], 0x0                           ; f4004300 f8000000
	s_load_b128 s[16:19], s[10:11], 0x30                        ; f4004405 f8000030
	s_load_b32 s20, s[10:11], 0x40                              ; f4000505 f8000040
	s_load_b64 s[22:23], s[10:11], 0x20                         ; f4002585 f8000020
	s_load_b256 s[32:39], s[0:1], 0x30                          ; f4006800 f8000030
(invalid instruction)                                        ; d71f0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_lshrrev_b32_e32 v1, 5, v0                                 ; 32020085
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_and_b32_e32 v4, 15, v3                                    ; 3608068f
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_lshlrev_b32_e32 v2, 9, v1                                 ; 30040289
	v_lshlrev_b32_e32 v5, 4, v4                                 ; 300a0884
	v_lshlrev_b32_e32 v3, 3, v3                                 ; 30060683
	v_add_nc_u32_e32 v7, 0x100, v2                              ; 4a0e04ff 00000100
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl1_add_u32 s19, ttmp9, s19                             ; 87131375
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_max_i32 s24, s19, 0                                       ; 8a188013
	s_add_co_u32 s25, s17, -1                                   ; 8019c111
	s_min_i32 s24, s24, s25                                     ; 89181918
	s_add_co_u32 s26, s18, -1                                   ; 801ac112
	s_lshl1_add_u32 s21, s21, s20                               ; 87151415
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_max_i32 s27, s21, 0                                       ; 8a1b8015
	s_min_i32 s27, s27, s26                                     ; 891b1a1b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s27, s27, s17                                     ; 961b111b
	s_add_co_u32 s28, s27, s24                                  ; 801c181b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s28, s28, 12                                     ; 841c8c1c
	s_add_co_u32 s29, s2, s28                                   ; 801d1c02
	s_add_co_u32 s30, s19, 1                                    ; 801e8113
	v_add3_u32 v6, v5, s29, v2                                  ; d6550006 04083b05
	v_add3_u32 v8, v5, s29, v7                                  ; d6550008 041c3b05
	s_max_i32 s31, s30, 0                                       ; 8a1f801e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_min_i32 s31, s31, s25                                     ; 891f191f
	v_add_nc_u32_e32 v6, v6, v3                                 ; 4a0c0706
	v_add_nc_u32_e32 v8, v8, v3                                 ; 4a100708
	s_add_co_u32 s27, s27, s31                                  ; 801b1f1b
	s_lshl_b32 s27, s27, 12                                     ; 841b8c1b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s40, s2, s27                                   ; 80281b02
	s_add_co_u32 s41, s21, 1                                    ; 80298115
	v_add3_u32 v10, v5, s40, v7                                 ; d655000a 041c5105
	v_add3_u32 v9, v5, s40, v2                                  ; d6550009 04085105
	s_max_i32 s42, s41, 0                                       ; 8a2a8029
	s_min_i32 s42, s42, s26                                     ; 892a1a2a
	v_add_nc_u32_e32 v10, v10, v3                               ; 4a14070a
	v_add_nc_u32_e32 v9, v9, v3                                 ; 4a120709
	s_mul_i32 s42, s42, s17                                     ; 962a112a
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s24, s42, s24                                  ; 8018182a
	s_lshl_b32 s24, s24, 12                                     ; 84188c18
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s43, s2, s24                                   ; 802b1802
	s_add_co_u32 s42, s42, s31                                  ; 802a1f2a
	v_add3_u32 v12, v5, s43, v7                                 ; d655000c 041c5705
	v_add3_u32 v11, v5, s43, v2                                 ; d655000b 04085705
	s_lshl_b32 s42, s42, 12                                     ; 842a8c2a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s2, s2, s42                                    ; 80022a02
	v_add_nc_u32_e32 v12, v12, v3                               ; 4a18070c
	v_add_nc_u32_e32 v11, v11, v3                               ; 4a16070b
	v_add3_u32 v13, v5, s2, v2                                  ; d655000d 04080505
	v_add3_u32 v14, v5, s2, v7                                  ; d655000e 041c0505
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v13, v13, v3                               ; 4a1a070d
	v_add_nc_u32_e32 v14, v14, v3                               ; 4a1c070e
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[16:17], v6, s[12:15], null offen          ; c405407c 40801810 00000006
	buffer_load_b64 v[18:19], v8, s[12:15], null offen          ; c405407c 40801812 00000008
	buffer_load_b64 v[8:9], v9, s[12:15], null offen            ; c405407c 40801808 00000009
	buffer_load_b64 v[20:21], v10, s[12:15], null offen         ; c405407c 40801814 0000000a
	buffer_load_b64 v[10:11], v11, s[12:15], null offen         ; c405407c 4080180a 0000000b
	buffer_load_b64 v[22:23], v12, s[12:15], null offen         ; c405407c 40801816 0000000c
	buffer_load_b64 v[12:13], v13, s[12:15], null offen         ; c405407c 4080180c 0000000d
	buffer_load_b64 v[14:15], v14, s[12:15], null offen         ; c405407c 4080180e 0000000e
	v_lshlrev_b32_e32 v24, 3, v1                                ; 30300283
	v_and_b32_e32 v27, 31, v0                                   ; 3636009f
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_sub_nc_u32_e32 v25, 0, v24                                ; 4c323080
	v_med3_i32 v26, -1, v24, 1                                  ; d620001a 020630c1
	v_add_nc_u32_e32 v29, 2, v24                                ; 4a3a3082
	v_lshlrev_b32_e32 v28, 2, v27                               ; 30383682
	v_max_i32_e32 v25, v24, v25                                 ; 24323318
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_sub_nc_u32_e32 v30, 0, v29                                ; 4c3c3a80
	v_lshrrev_b32_e32 v25, 1, v25                               ; 32323281
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_max_i32_e32 v30, v29, v30                                 ; 243c3d1d
	v_med3_i32 v29, -1, v29, 1                                  ; d620001d 02063ac1
(invalid instruction)                                        ; d72c001a
	v_cndmask_b32_e32 v1, v26, v25, vcc_lo                      ; 0202331a
	v_lshrrev_b32_e32 v30, 1, v30                               ; 323c3c81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d72c001d
	v_cndmask_b32_e32 v1, v29, v30, vcc_lo                      ; 02023d1d
	v_lshl_add_u32 v26, v26, 11, s4                             ; d646001a 0011171a
	v_add_lshl_u32 v26, v26, v28, 2                             ; d647001a 020a391a
	v_lshl_add_u32 v29, v29, 11, s4                             ; d646001d 0011171d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v29, v29, v28, 2                             ; d647001d 020a391d
	s_clause 0xa                                                ; bf85000a
	buffer_load_b128 v[32:35], v26, s[36:39], null offen        ; c405c07c 40804820 0000001a
	buffer_load_b128 v[36:39], v29, s[36:39], null offen        ; c405c07c 40804824 0000001d
	buffer_load_b128 v[40:43], v26, s[36:39], null offen offset:512 ; c405c07c 40804828 0002001a
	buffer_load_b128 v[44:47], v29, s[36:39], null offen offset:512 ; c405c07c 4080482c 0002001d
	buffer_load_b128 v[48:51], v26, s[36:39], null offen offset:1024 ; c405c07c 40804830 0004001a
	buffer_load_b128 v[52:55], v29, s[36:39], null offen offset:1024 ; c405c07c 40804834 0004001d
	buffer_load_b128 v[56:59], v26, s[36:39], null offen offset:1536 ; c405c07c 40804838 0006001a
	buffer_load_b128 v[60:63], v29, s[36:39], null offen offset:1536 ; c405c07c 4080483c 0006001d
	buffer_load_b128 v[64:67], v26, s[36:39], null offen offset:2048 ; c405c07c 40804840 0008001a
	buffer_load_b128 v[68:71], v29, s[36:39], null offen offset:2048 ; c405c07c 40804844 0008001d
	buffer_load_b128 v[72:75], v26, s[36:39], null offen offset:2560 ; c405c07c 40804848 000a001a
	v_add_nc_u32_e32 v31, v5, v3                                ; 4a3e0705
	s_min_i32 s44, s19, s21                                     ; 892c1513
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_cmp_lt_i32 s44, 0                                         ; bf04802c
	v_add_nc_u32_e32 v76, v2, v31                               ; 4a983f02
	s_cselect_b32 s45, -1, 0                                    ; 982d80c1
	s_cmp_ge_i32 s19, s17                                       ; bf031113
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s46, -1, 0                                    ; 982e80c1
	v_add_nc_u32_e32 v77, 0x1000, v76                           ; 4a9a98ff 00001000
	v_add_nc_u32_e32 v78, 0x2000, v76                           ; 4a9c98ff 00002000
	v_add_nc_u32_e32 v79, 0x3000, v76                           ; 4a9e98ff 00003000
	s_or_b32 s45, s45, s46                                      ; 8c2d2e2d
	s_cmp_ge_i32 s21, s18                                       ; bf031215
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s47, -1, 0                                    ; 982f80c1
	s_or_b32 s45, s45, s47                                      ; 8c2d2f2d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_mov_b32 s48, src_scc                                      ; beb000fd
	s_min_i32 s49, s30, s21                                     ; 8931151e
	s_cmp_lt_i32 s49, 0                                         ; bf048031
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_cselect_b32 s50, -1, 0                                    ; 983280c1
	s_cmp_ge_i32 s30, s17                                       ; bf03111e
	s_cselect_b32 s51, -1, 0                                    ; 983380c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s50, s50, s51                                      ; 8c323332
	s_or_b32 s50, s50, s47                                      ; 8c322f32
	s_pack_hh_b32_b16 s59, ttmp7, 0                             ; 9a3b8073
	s_mov_b32 s52, src_scc                                      ; beb400fd
	s_min_i32 s53, s19, s41                                     ; 89352913
	v_lshl_add_u32 v80, s59, 4, v31                             ; d6460050 047d083b
	s_movk_i32 s60, 0x400                                       ; b03c0400
	s_cmp_lt_i32 s53, 0                                         ; bf048035
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s54, -1, 0                                    ; 983680c1
	s_or_b32 s54, s54, s46                                      ; 8c362e36
	s_cmp_ge_i32 s41, s18                                       ; bf031229
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s55, -1, 0                                    ; 983780c1
	s_or_b32 s54, s54, s55                                      ; 8c363736
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_mov_b32 s56, src_scc                                      ; beb800fd
	s_min_i32 s30, s30, s41                                     ; 891e291e
	s_cmp_lt_i32 s30, 0                                         ; bf04801e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s57, -1, 0                                    ; 983980c1
	s_or_b32 s57, s57, s51                                      ; 8c393339
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s57, s57, s55                                      ; 8c393739
	s_mov_b32 s58, src_scc                                      ; beba00fd
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v82, v16, 0, s45                          ; d5010052 00b50110
	v_cndmask_b32_e64 v83, v17, 0, s45                          ; d5010053 00b50111
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_cndmask_b32_e64 v17, v19, 0, s45                          ; d5010011 00b50113
	v_cndmask_b32_e64 v16, v18, 0, s45                          ; d5010010 00b50112
	ds_store_2addr_b64 v76, v[82:83], v[16:17] offset1:32       ; d9382000 0010524c
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_cndmask_b32_e64 v16, v8, 0, s50                           ; d5010010 00c90108
	v_cndmask_b32_e64 v17, v9, 0, s50                           ; d5010011 00c90109
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_cndmask_b32_e64 v8, v20, 0, s50                           ; d5010008 00c90114
	v_cndmask_b32_e64 v9, v21, 0, s50                           ; d5010009 00c90115
	ds_store_2addr_b64 v77, v[16:17], v[8:9] offset1:32         ; d9382000 0008104d
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_cndmask_b32_e64 v8, v10, 0, s54                           ; d5010008 00d9010a
	v_cndmask_b32_e64 v9, v11, 0, s54                           ; d5010009 00d9010b
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_cndmask_b32_e64 v10, v22, 0, s54                          ; d501000a 00d90116
	v_cndmask_b32_e64 v11, v23, 0, s54                          ; d501000b 00d90117
	ds_store_2addr_b64 v78, v[8:9], v[10:11] offset1:32         ; d9382000 000a084e
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_cndmask_b32_e64 v9, v13, 0, s57                           ; d5010009 00e5010d
	v_cndmask_b32_e64 v8, v12, 0, s57                           ; d5010008 00e5010c
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_cndmask_b32_e64 v10, v14, 0, s57                          ; d501000a 00e5010e
	v_cndmask_b32_e64 v11, v15, 0, s57                          ; d501000b 00e5010f
	ds_store_2addr_b64 v79, v[8:9], v[10:11] offset1:32         ; d9382000 000a084f
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[8:9], v80                                     ; d9d80000 08000050
	ds_load_b64 v[10:11], v80 offset:4096                       ; d9d81000 0a000050
	ds_load_b64 v[12:13], v80 offset:8192                       ; d9d82000 0c000050
	ds_load_b64 v[14:15], v80 offset:12288                      ; d9d83000 0e000050
	ds_load_b64 v[16:17], v80 offset:256                        ; d9d80100 10000050
	ds_load_b64 v[18:19], v80 offset:4352                       ; d9d81100 12000050
	ds_load_b64 v[20:21], v80 offset:8448                       ; d9d82100 14000050
	ds_load_b64 v[22:23], v80 offset:12544                      ; d9d83100 16000050
	ds_load_b64 v[82:83], v80 offset:512                        ; d9d80200 52000050
	v_mov_b32_e32 v81, v7                                       ; 7ea20307
	v_mov_b32_e32 v25, v28                                      ; 7e32031c
	v_dual_mov_b32 v85, v31 :: v_dual_mov_b32 v84, v29          ; ca10011f 5554011d
	s_wait_loadcnt_dscnt 0xa08                                  ; bfc80a08
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[8:9], 0  ; cc464060 1a021122
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[12:13], 0 ; cc464098 1a021920
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[10:11], 0 ; cc464080 1a021522
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[34:35], v[12:13], 0 ; cc4640a0 1a021922
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[32:33], v[14:15], 0 ; cc4640b8 1a021d20
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[10:11], 0 ; cc464078 1a021520
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[8:9], 0   ; cc464058 1a021120
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[12:13], 0 ; cc4640b0 1a021926
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[8:9], 0 ; cc464070 1a021126
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[36:37], v[10:11], 0 ; cc464088 1a021524
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[8:9], 0 ; cc464068 1a021124
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[10:11], 0 ; cc464090 1a021526
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[36:37], v[12:13], 0 ; cc4640a8 1a021924
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[34:35], v[14:15], 0  ; cc464006 1a021d22
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[36:37], v[14:15], 0 ; cc46401c 1a021d24
	v_dual_mov_b32 v37, v15 :: v_dual_mov_b32 v36, v14          ; ca10010f 2524010e
	s_wait_loadcnt_dscnt 0x804                                  ; bfc80804
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[16:17], v[96:103] ; cc464060 1d82212a
	s_wait_dscnt 0x3                                            ; bfc60003
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[18:19], v[128:135] ; cc464080 1e02252a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[18:19], v[120:127] ; cc464078 1de22528
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[16:17], v[88:95] ; cc464058 1d622128
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[20:21], v[152:159] ; cc464098 1e622928
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[42:43], v[20:21], v[160:167] ; cc4640a0 1e82292a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[16:17], v[112:119] ; cc464070 1dc2212e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[44:45], v[18:19], v[136:143] ; cc464088 1e22252c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[20:21], v[176:183] ; cc4640b0 1ec2292e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[16:17], v[104:111] ; cc464068 1da2212c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[18:19], v[144:151] ; cc464090 1e42252e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[20:21], v[168:175] ; cc4640a8 1ea2292c
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[38:39], v[36:37], 0 ; cc46400e 1a024926
	s_wait_loadcnt_dscnt 0x600                                  ; bfc80600
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[82:83], v[96:103] ; cc464060 1d82a532
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[40:41], v[22:23], v[184:191] ; cc4640b8 1ee22d28
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[42:43], v[22:23], v[6:13] ; cc464006 1c1a2d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[82:83], v[88:95] ; cc464058 1d62a530
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[44:45], v[22:23], v[28:35] ; cc46401c 1c722d2c
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[82:83], v[104:111] ; cc464068 1da2a534
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[82:83], v[112:119] ; cc464070 1dc2a536
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[46:47], v[22:23], v[14:21] ; cc46400e 1c3a2d2e
	ds_load_b64 v[36:37], v80 offset:4608                       ; d9d81200 24000050
	ds_load_b64 v[38:39], v80 offset:8704                       ; d9d82200 26000050
	ds_load_b64 v[40:41], v80 offset:12800                      ; d9d83200 28000050
	ds_load_b64 v[42:43], v80 offset:768                        ; d9d80300 2a000050
	ds_load_b64 v[44:45], v80 offset:4864                       ; d9d81300 2c000050
	ds_load_b64 v[22:23], v80 offset:8960                       ; d9d82300 16000050
	ds_load_b64 v[46:47], v80 offset:13056                      ; d9d83300 2e000050
	ds_load_b64 v[82:83], v80 offset:1024                       ; d9d80400 52000050
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[36:37], v[136:143] ; cc464088 1e224934
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[36:37], v[120:127] ; cc464078 1de24930
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[36:37], v[128:135] ; cc464080 1e024932
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[36:37], v[144:151] ; cc464090 1e424936
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[38:39], v[176:183] ; cc4640b0 1ec24d36
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[38:39], v[160:167] ; cc4640a0 1e824d32
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[38:39], v[168:175] ; cc4640a8 1ea24d34
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[38:39], v[152:159] ; cc464098 1e624d30
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[52:53], v[40:41], v[28:35] ; cc46401c 1c725134
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[48:49], v[40:41], v[184:191] ; cc4640b8 1ee25130
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[50:51], v[40:41], v[6:13] ; cc464006 1c1a5132
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[54:55], v[40:41], v[14:21] ; cc46400e 1c3a5136
	ds_load_b64 v[36:37], v80 offset:5120                       ; d9d81400 24000050
	ds_load_b64 v[38:39], v80 offset:9216                       ; d9d82400 26000050
	ds_load_b64 v[48:49], v80 offset:13312                      ; d9d83400 30000050
	ds_load_b64 v[50:51], v80 offset:1280                       ; d9d80500 32000050
	ds_load_b64 v[52:53], v80 offset:5376                       ; d9d81500 34000050
	ds_load_b64 v[40:41], v80 offset:9472                       ; d9d82500 28000050
	ds_load_b64 v[54:55], v80 offset:13568                      ; d9d83500 36000050
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[42:43], v[88:95] ; cc464058 1d625538
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[42:43], v[96:103] ; cc464060 1d82553a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[44:45], v[120:127] ; cc464078 1de25938
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[44:45], v[128:135] ; cc464080 1e02593a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[22:23], v[160:167] ; cc4640a0 1e822d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[22:23], v[152:159] ; cc464098 1e622d38
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[46:47], v[184:191] ; cc4640b8 1ee25d38
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[42:43], v[104:111] ; cc464068 1da2553c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[44:45], v[136:143] ; cc464088 1e22593c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[22:23], v[168:175] ; cc4640a8 1ea22d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[42:43], v[112:119] ; cc464070 1dc2553e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[44:45], v[144:151] ; cc464090 1e42593e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[22:23], v[176:183] ; cc4640b0 1ec22d3e
	ds_load_b64 v[56:57], v80 offset:1536                       ; d9d80600 38000050
	ds_load_b64 v[42:43], v80 offset:5632                       ; d9d81600 2a000050
	ds_load_b64 v[22:23], v80 offset:9728                       ; d9d82600 16000050
	ds_load_b64 v[44:45], v80 offset:13824                      ; d9d83600 2c000050
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[60:61], v[46:47], v[28:35] ; cc46401c 1c725d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[58:59], v[46:47], v[6:13] ; cc464006 1c1a5d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[62:63], v[46:47], v[14:21] ; cc46400e 1c3a5d3e
	ds_load_b64 v[46:47], v80 offset:1792                       ; d9d80700 2e000050
	ds_load_b64 v[58:59], v80 offset:5888                       ; d9d81700 3a000050
	s_wait_loadcnt_dscnt 0x20c                                  ; bfc8020c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[36:37], v[120:127] ; cc464078 1de24940
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[82:83], v[88:95] ; cc464058 1d62a540
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[38:39], v[152:159] ; cc464098 1e624d40
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[36:37], v[128:135] ; cc464080 1e024942
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[38:39], v[160:167] ; cc4640a0 1e824d42
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[36:37], v[136:143] ; cc464088 1e224944
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[38:39], v[168:175] ; cc4640a8 1ea24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[36:37], v[144:151] ; cc464090 1e424946
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[38:39], v[176:183] ; cc4640b0 1ec24d46
	ds_load_b64 v[36:37], v80 offset:9984                       ; d9d82700 24000050
	ds_load_b64 v[38:39], v80 offset:14080                      ; d9d83700 26000050
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[48:49], v[184:191] ; cc4640b8 1ee26140
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[82:83], v[96:103] ; cc464060 1d82a542
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[82:83], v[104:111] ; cc464068 1da2a544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[82:83], v[112:119] ; cc464070 1dc2a546
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[68:69], v[48:49], v[28:35] ; cc46401c 1c726144
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[66:67], v[48:49], v[6:13] ; cc464006 1c1a6142
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[48:49], v[14:21] ; cc46400e 1c3a6146
	v_dual_mov_b32 v49, v81 :: v_dual_mov_b32 v48, v80          ; ca100151 31300150
	s_wait_loadcnt_dscnt 0xb                                    ; bfc8000b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[50:51], v[88:95] ; cc464058 1d626548
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[52:53], v[120:127] ; cc464078 1de26948
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[40:41], v[152:159] ; cc464098 1e625148
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[52:53], v[128:135] ; cc464080 1e02694a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[72:73], v[54:55], v[184:191] ; cc4640b8 1ee26d48
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[74:75], v[40:41], v[160:167] ; cc4640a0 1e82514a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[74:75], v[50:51], v[96:103] ; cc464060 1d82654a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[74:75], v[54:55], v[6:13] ; cc464006 1c1a6d4a
	s_clause 0x4                                                ; bf850004
	buffer_load_b128 v[60:63], v84, s[36:39], null offen offset:2560 ; c405c07c 4080483c 000a0054
	buffer_load_b128 v[64:67], v26, s[36:39], null offen offset:3072 ; c405c07c 40804840 000c001a
	buffer_load_b128 v[68:71], v84, s[36:39], null offen offset:3072 ; c405c07c 40804844 000c0054
	buffer_load_b128 v[80:83], v26, s[36:39], null offen offset:3584 ; c405c07c 40804850 000e001a
	buffer_load_b128 v[72:75], v84, s[36:39], null offen offset:3584 ; c405c07c 40804848 000e0054
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[52:53], v[136:143] ; cc464088 1e22693c
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[60:61], v[54:55], v[28:35] ; cc46401c 1c726d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[40:41], v[176:183] ; cc4640b0 1ec2513e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[40:41], v[168:175] ; cc4640a8 1ea2513c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[50:51], v[104:111] ; cc464068 1da2653c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[50:51], v[112:119] ; cc464070 1dc2653e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[52:53], v[144:151] ; cc464090 1e42693e
	ds_load_b64 v[60:61], v48 offset:2048                       ; d9d80800 3c000030
	ds_load_b64 v[50:51], v48 offset:6144                       ; d9d81800 32000030
	ds_load_b64 v[52:53], v48 offset:10240                      ; d9d82800 34000030
	ds_load_b64 v[40:41], v48 offset:14336                      ; d9d83800 28000030
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[62:63], v[54:55], v[14:21] ; cc46400e 1c3a6d3e
	v_dual_mov_b32 v55, v85 :: v_dual_mov_b32 v54, v84          ; ca100155 37360154
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[56:57], v[88:95] ; cc464058 1d627140
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[42:43], v[120:127] ; cc464078 1de25540
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[22:23], v[152:159] ; cc464098 1e622d40
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[44:45], v[184:191] ; cc4640b8 1ee25940
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[56:57], v[96:103] ; cc464060 1d827142
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[42:43], v[128:135] ; cc464080 1e025542
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[22:23], v[160:167] ; cc4640a0 1e822d42
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[66:67], v[44:45], v[6:13] ; cc464006 1c1a5942
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[84:87], v26, s[36:39], null offen offset:4096 ; c405c07c 40804854 0010001a
	buffer_load_b128 v[64:67], v54, s[36:39], null offen offset:4096 ; c405c07c 40804840 00100036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[56:57], v[104:111] ; cc464068 1da27144
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[42:43], v[136:143] ; cc464088 1e225544
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[22:23], v[168:175] ; cc4640a8 1ea22d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[56:57], v[112:119] ; cc464070 1dc27146
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[42:43], v[144:151] ; cc464090 1e425546
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[22:23], v[176:183] ; cc4640b0 1ec22d46
	ds_load_b64 v[62:63], v48 offset:2304                       ; d9d80900 3e000030
	ds_load_b64 v[56:57], v48 offset:6400                       ; d9d81900 38000030
	ds_load_b64 v[42:43], v48 offset:10496                      ; d9d82900 2a000030
	ds_load_b64 v[22:23], v48 offset:14592                      ; d9d83900 16000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[68:69], v[44:45], v[28:35] ; cc46401c 1c725944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[44:45], v[14:21] ; cc46400e 1c3a5946
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[80:81], v[46:47], v[88:95] ; cc464058 1d625d50
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[58:59], v[120:127] ; cc464078 1de27550
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[80:81], v[36:37], v[152:159] ; cc464098 1e624950
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[80:81], v[38:39], v[184:191] ; cc4640b8 1ee24d50
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[82:83], v[46:47], v[96:103] ; cc464060 1d825d52
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[58:59], v[128:135] ; cc464080 1e027552
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[82:83], v[36:37], v[160:167] ; cc4640a0 1e824952
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[82:83], v[38:39], v[6:13] ; cc464006 1c1a4d52
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v26, s[36:39], null offen offset:4608 ; c405c07c 40804844 0012001a
	buffer_load_b128 v[80:83], v54, s[36:39], null offen offset:4608 ; c405c07c 40804850 00120036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[46:47], v[104:111] ; cc464068 1da25d48
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[72:73], v[58:59], v[136:143] ; cc464088 1e227548
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[36:37], v[168:175] ; cc4640a8 1ea24948
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[46:47], v[112:119] ; cc464070 1dc25d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[74:75], v[58:59], v[144:151] ; cc464090 1e42754a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[36:37], v[176:183] ; cc4640b0 1ec2494a
	ds_load_b64 v[44:45], v48 offset:2560                       ; d9d80a00 2c000030
	ds_load_b64 v[46:47], v48 offset:6656                       ; d9d81a00 2e000030
	ds_load_b64 v[58:59], v48 offset:10752                      ; d9d82a00 3a000030
	ds_load_b64 v[36:37], v48 offset:14848                      ; d9d83a00 24000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[72:73], v[38:39], v[28:35] ; cc46401c 1c724d48
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[38:39], v[14:21] ; cc46400e 1c3a4d4a
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[86:87], v[50:51], v[128:135] ; cc464080 1e026556
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[84:85], v[40:41], v[184:191] ; cc4640b8 1ee25154
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[84:85], v[52:53], v[152:159] ; cc464098 1e626954
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[86:87], v[60:61], v[96:103] ; cc464060 1d827956
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[86:87], v[52:53], v[160:167] ; cc4640a0 1e826956
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[84:85], v[60:61], v[88:95] ; cc464058 1d627954
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[84:85], v[50:51], v[120:127] ; cc464078 1de26554
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[86:87], v[40:41], v[6:13] ; cc464006 1c1a5156
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v26, s[36:39], null offen offset:5120 ; c405c07c 40804848 0014001a
	buffer_load_b128 v[84:87], v54, s[36:39], null offen offset:5120 ; c405c07c 40804854 00140036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[64:65], v[60:61], v[104:111] ; cc464068 1da27940
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[64:65], v[50:51], v[136:143] ; cc464088 1e226540
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[64:65], v[52:53], v[168:175] ; cc4640a8 1ea26940
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[60:61], v[112:119] ; cc464070 1dc27942
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[66:67], v[50:51], v[144:151] ; cc464090 1e426542
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[66:67], v[52:53], v[176:183] ; cc4640b0 1ec26942
	ds_load_b64 v[38:39], v48 offset:2816                       ; d9d80b00 26000030
	ds_load_b64 v[60:61], v48 offset:6912                       ; d9d81b00 3c000030
	ds_load_b64 v[50:51], v48 offset:11008                      ; d9d82b00 32000030
	ds_load_b64 v[52:53], v48 offset:15104                      ; d9d83b00 34000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[64:65], v[40:41], v[28:35] ; cc46401c 1c725140
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[66:67], v[40:41], v[14:21] ; cc46400e 1c3a5142
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[70:71], v[22:23], v[6:13] ; cc464006 1c1a2d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[56:57], v[120:127] ; cc464078 1de27144
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[68:69], v[22:23], v[184:191] ; cc4640b8 1ee22d44
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[62:63], v[96:103] ; cc464060 1d827d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[56:57], v[128:135] ; cc464080 1e027146
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[42:43], v[152:159] ; cc464098 1e625544
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[62:63], v[88:95] ; cc464058 1d627d44
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[70:71], v[42:43], v[160:167] ; cc4640a0 1e825546
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[64:67], v26, s[36:39], null offen offset:5632 ; c405c07c 40804840 0016001a
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:5632 ; c405c07c 40804844 00160036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[80:81], v[56:57], v[136:143] ; cc464088 1e227150
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[80:81], v[42:43], v[168:175] ; cc4640a8 1ea25550
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[80:81], v[62:63], v[104:111] ; cc464068 1da27d50
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[62:63], v[112:119] ; cc464070 1dc27d52
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[82:83], v[56:57], v[144:151] ; cc464090 1e427152
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[82:83], v[42:43], v[176:183] ; cc4640b0 1ec25552
	ds_load_b64 v[40:41], v48 offset:3072                       ; d9d80c00 28000030
	ds_load_b64 v[62:63], v48 offset:7168                       ; d9d81c00 3e000030
	ds_load_b64 v[56:57], v48 offset:11264                      ; d9d82c00 38000030
	ds_load_b64 v[42:43], v48 offset:15360                      ; d9d83c00 2a000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[80:81], v[22:23], v[28:35] ; cc46401c 1c722d50
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[82:83], v[22:23], v[14:21] ; cc46400e 1c3a2d52
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[72:73], v[36:37], v[184:191] ; cc4640b8 1ee24948
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[74:75], v[44:45], v[96:103] ; cc464060 1d82594a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[74:75], v[36:37], v[6:13] ; cc464006 1c1a494a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[46:47], v[128:135] ; cc464080 1e025d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[58:59], v[152:159] ; cc464098 1e627548
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[74:75], v[58:59], v[160:167] ; cc4640a0 1e82754a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[46:47], v[120:127] ; cc464078 1de25d48
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[44:45], v[88:95] ; cc464058 1d625948
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[80:83], v26, s[36:39], null offen offset:6144 ; c405c07c 40804850 0018001a
	buffer_load_b128 v[72:75], v54, s[36:39], null offen offset:6144 ; c405c07c 40804848 00180036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[84:85], v[46:47], v[136:143] ; cc464088 1e225d54
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[84:85], v[58:59], v[168:175] ; cc4640a8 1ea27554
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[84:85], v[44:45], v[104:111] ; cc464068 1da25954
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[86:87], v[44:45], v[112:119] ; cc464070 1dc25956
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[86:87], v[46:47], v[144:151] ; cc464090 1e425d56
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[86:87], v[58:59], v[176:183] ; cc4640b0 1ec27556
	ds_load_b64 v[22:23], v48 offset:3328                       ; d9d80d00 16000030
	ds_load_b64 v[44:45], v48 offset:7424                       ; d9d81d00 2c000030
	ds_load_b64 v[46:47], v48 offset:11520                      ; d9d82d00 2e000030
	ds_load_b64 v[58:59], v48 offset:15616                      ; d9d83d00 3a000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[84:85], v[36:37], v[28:35] ; cc46401c 1c724954
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[86:87], v[36:37], v[14:21] ; cc46400e 1c3a4956
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[52:53], v[184:191] ; cc4640b8 1ee26940
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[66:67], v[52:53], v[6:13] ; cc464006 1c1a6942
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[38:39], v[96:103] ; cc464060 1d824d42
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[60:61], v[128:135] ; cc464080 1e027942
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[50:51], v[152:159] ; cc464098 1e626540
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[50:51], v[160:167] ; cc4640a0 1e826542
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[60:61], v[120:127] ; cc464078 1de27940
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[38:39], v[88:95] ; cc464058 1d624d40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[84:87], v26, s[36:39], null offen offset:6656 ; c405c07c 40804854 001a001a
	buffer_load_b128 v[64:67], v54, s[36:39], null offen offset:6656 ; c405c07c 40804840 001a0036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[60:61], v[136:143] ; cc464088 1e227944
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[50:51], v[168:175] ; cc4640a8 1ea26544
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[38:39], v[104:111] ; cc464068 1da24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[38:39], v[112:119] ; cc464070 1dc24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[60:61], v[144:151] ; cc464090 1e427946
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[50:51], v[176:183] ; cc4640b0 1ec26546
	ds_load_b64 v[36:37], v48 offset:3584                       ; d9d80e00 24000030
	ds_load_b64 v[38:39], v48 offset:7680                       ; d9d81e00 26000030
	ds_load_b64 v[60:61], v48 offset:11776                      ; d9d82e00 3c000030
	ds_load_b64 v[50:51], v48 offset:15872                      ; d9d83e00 32000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[68:69], v[52:53], v[28:35] ; cc46401c 1c726944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[52:53], v[14:21] ; cc46400e 1c3a6946
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[80:81], v[42:43], v[184:191] ; cc4640b8 1ee25550
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[82:83], v[42:43], v[6:13] ; cc464006 1c1a5552
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[82:83], v[40:41], v[96:103] ; cc464060 1d825152
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[80:81], v[56:57], v[152:159] ; cc464098 1e627150
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[62:63], v[128:135] ; cc464080 1e027d52
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[82:83], v[56:57], v[160:167] ; cc4640a0 1e827152
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[62:63], v[120:127] ; cc464078 1de27d50
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[80:81], v[40:41], v[88:95] ; cc464058 1d625150
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v26, s[36:39], null offen offset:7168 ; c405c07c 40804844 001c001a
	buffer_load_b128 v[80:83], v54, s[36:39], null offen offset:7168 ; c405c07c 40804850 001c0036
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[72:73], v[62:63], v[136:143] ; cc464088 1e227d48
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[56:57], v[168:175] ; cc4640a8 1ea27148
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[40:41], v[104:111] ; cc464068 1da25148
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[40:41], v[112:119] ; cc464070 1dc2514a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[74:75], v[62:63], v[144:151] ; cc464090 1e427d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[56:57], v[176:183] ; cc4640b0 1ec2714a
	ds_load_b64 v[52:53], v48 offset:3840                       ; d9d80f00 34000030
	ds_load_b64 v[40:41], v48 offset:7936                       ; d9d81f00 28000030
	ds_load_b64 v[62:63], v48 offset:12032                      ; d9d82f00 3e000030
	ds_load_b64 v[56:57], v48 offset:16128                      ; d9d83f00 38000030
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[72:73], v[42:43], v[28:35] ; cc46401c 1c725548
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[42:43], v[14:21] ; cc46400e 1c3a554a
	buffer_load_b128 v[72:75], v26, s[36:39], null offen offset:7680 ; c405c07c 40804848 001e001a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_mov_b32_e32 v26, v86                                      ; 7e340356
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[84:85], v[58:59], v[184:191] ; cc4640b8 1ee27554
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[84:85], v[22:23], v[88:95] ; cc464058 1d622d54
	v_mov_b32_e32 v42, v87                                      ; 7e540357
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[84:85], v[46:47], v[152:159] ; cc464098 1e625d54
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[84:85], v[44:45], v[120:127] ; cc464078 1de25954
	buffer_load_b128 v[84:87], v54, s[36:39], null offen offset:7680 ; c405c07c 40804854 001e0036
	v_mad_u32_u24 v43, s59, 0x50, v55                           ; d60b002b 04ddfe3b 00000050
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[64:65], v[44:45], v[136:143] ; cc464088 1e225940
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[64:65], v[22:23], v[104:111] ; cc464068 1da22d40
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[64:65], v[46:47], v[168:175] ; cc4640a8 1ea25d40
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[64:65], v[58:59], v[28:35] ; cc46401c 1c727540
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[22:23], v[112:119] ; cc464070 1dc22d42
	v_swap_b32 v27, v42                                         ; 7e36cb2a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[26:27], v[46:47], v[160:167] ; cc4640a0 1e825d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[26:27], v[58:59], v[6:13] ; cc464006 1c1a751a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[22:23], v[96:103] ; cc464060 1d822d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[44:45], v[128:135] ; cc464080 1e02591a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[66:67], v[44:45], v[144:151] ; cc464090 1e425942
	ds_load_b64 v[26:27], v43                                   ; d9d80000 1a00002b
	ds_load_b64 v[64:65], v43 offset:4096                       ; d9d81000 4000002b
	ds_load_b64 v[22:23], v43 offset:8192                       ; d9d82000 1600002b
	ds_load_b64 v[44:45], v43 offset:12288                      ; d9d83000 2c00002b
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[66:67], v[46:47], v[176:183] ; cc4640b0 1ec25d42
	v_add_nc_u32_e32 v46, 4, v24                                ; 4a5c3084
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[66:67], v[58:59], v[14:21] ; cc46400e 1c3a7542
	v_mov_b32_e32 v58, v49                                      ; 7e740331
	v_sub_nc_u32_e32 v47, 0, v46                                ; 4c5e5c80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v47, v46, v47                                 ; 245e5f2e
	v_med3_i32 v46, -1, v46, 1                                  ; d620002e 02065cc1
	v_lshrrev_b32_e32 v47, 1, v47                               ; 325e5e81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c002e
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	v_lshl_add_u32 v46, v46, 11, s4                             ; d646002e 0011172e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v46, v46, v25, 2                             ; d647002e 020a332e
	v_mov_b32_e32 v54, v46                                      ; 7e6c032e
	buffer_load_b128 v[46:49], v46, s[36:39], null offen        ; c405c07c 4080482e 0000002e
	v_add_nc_u32_e32 v24, 6, v24                                ; 4a303086
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v59, 0, v24                                ; 4c763080
	v_max_i32_e32 v59, v24, v59                                 ; 24767718
	v_med3_i32 v24, -1, v24, 1                                  ; d6200018 020630c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_lshrrev_b32_e32 v59, 1, v59                               ; 32767681
(invalid instruction)                                        ; d72c0018
	v_cndmask_b32_e32 v1, v24, v59, vcc_lo                      ; 02027718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v24, v24, 11, s4                             ; d6460018 00111718
	v_add_lshl_u32 v24, v24, v25, 2                             ; d6470018 020a3318
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[36:37], v[96:103] ; cc464060 1d824946
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[68:69], v[50:51], v[184:191] ; cc4640b8 1ee26544
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[38:39], v[128:135] ; cc464080 1e024d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[70:71], v[60:61], v[160:167] ; cc4640a0 1e827946
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[36:37], v[88:95] ; cc464058 1d624944
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[60:61], v[152:159] ; cc464098 1e627944
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[70:71], v[50:51], v[6:13] ; cc464006 1c1a6546
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[38:39], v[120:127] ; cc464078 1de24d44
	buffer_load_b128 v[68:71], v24, s[36:39], null offen        ; c405c07c 40804844 00000018
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[80:81], v[60:61], v[168:175] ; cc4640a8 1ea27950
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[80:81], v[38:39], v[136:143] ; cc464088 1e224d50
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[80:81], v[36:37], v[104:111] ; cc464068 1da24950
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[36:37], v[112:119] ; cc464070 1dc24952
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[82:83], v[38:39], v[144:151] ; cc464090 1e424d52
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[82:83], v[60:61], v[176:183] ; cc4640b0 1ec27952
	ds_load_b64 v[66:67], v43 offset:256                        ; d9d80100 4200002b
	ds_load_b64 v[36:37], v43 offset:4352                       ; d9d81100 2400002b
	ds_load_b64 v[38:39], v43 offset:8448                       ; d9d82100 2600002b
	ds_load_b64 v[60:61], v43 offset:12544                      ; d9d83100 3c00002b
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[80:81], v[50:51], v[28:35] ; cc46401c 1c726550
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[52:53], v[88:95] ; cc464058 1d626948
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[74:75], v[52:53], v[96:103] ; cc464060 1d82694a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[62:63], v[152:159] ; cc464098 1e627d48
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[72:73], v[56:57], v[184:191] ; cc4640b8 1ee27148
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[40:41], v[128:135] ; cc464080 1e02514a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[40:41], v[120:127] ; cc464078 1de25148
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[74:75], v[62:63], v[160:167] ; cc4640a0 1e827d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[74:75], v[56:57], v[6:13] ; cc464006 1c1a714a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[82:83], v[50:51], v[14:21] ; cc46400e 1c3a6552
	v_maxmin_num_f32 v74, -4.0, v89, 4.0                        ; d669004a 03dab2f7
	v_maxmin_num_f32 v80, -4.0, v90, 4.0                        ; d6690050 03dab4f7
	v_maxmin_num_f32 v82, -4.0, v91, 4.0                        ; d6690052 03dab6f7
	v_maxmin_num_f32 v72, -4.0, v88, 4.0                        ; d6690048 03dab0f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
	v_fma_mix_f32 v75, 0xab28, |v74|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624b 0bfe94ff 3728ab28
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_fma_mix_f32 v73, 0xab28, |v72|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206249 0bfe90ff 3728ab28
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c842a553 5350a350 3f650000
	v_dual_fmaak_f32 v75, v75, v74, 0x3f650000 :: v_dual_fmaak_f32 v72, v72, v73, 0x3f650000 ; c842954b 4b489348 3f650000
	v_maxmin_num_f32 v59, -4.0, v95, 4.0                        ; d669003b 03dabef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870253
	v_dual_mul_f32 v91, v91, v83 :: v_dual_mul_f32 v90, v90, v80 ; c8c6a75b 5b5aa15a
	v_dual_mul_f32 v89, v89, v75 :: v_dual_mul_f32 v88, v88, v72 ; c8c69759 59589158
	v_maxmin_num_f32 v73, -4.0, v120, 4.0                       ; d6690049 03daf0f7
	v_fma_mix_f32 v72, 0xab28, |v59|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe76ff 3728ab28
	v_maxmin_num_f32 v75, -4.0, v121, 4.0                       ; d669004b 03daf2f7
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v92, 4.0                        ; d6690058 03dab8f7
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v90, -4.0, v93, 4.0                        ; d669005a 03dabaf7
	v_fma_mix_f32 v74, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe92ff 3728ab28
	v_fmaak_f32 v72, v72, v59, 0x3f650000                       ; 5a907748 3f650000
	v_fma_mix_f32 v80, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe96ff 3728ab28
	v_maxmin_num_f32 v81, -4.0, v122, 4.0                       ; d6690051 03daf4f7
	v_maxmin_num_f32 v83, -4.0, v123, 4.0                       ; d6690053 03daf6f7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_dual_fmaak_f32 v80, v80, v75, 0x3f650000 :: v_dual_fmaak_f32 v73, v73, v74, 0x3f650000 ; c8429750 50489549 3f650000
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	v_maxmin_num_f32 v89, -4.0, v124, 4.0                       ; d6690059 03daf8f7
	v_dual_mul_f32 v120, v120, v73 :: v_dual_mul_f32 v121, v121, v80 ; c8c69378 7878a179
	v_dual_mul_f32 v93, v93, v91 :: v_dual_mul_f32 v92, v92, v88 ; c8c6b75d 5d5cb15c
	v_maxmin_num_f32 v91, -4.0, v125, 4.0                       ; d669005b 03dafaf7
	v_fma_mix_f32 v88, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfea6ff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v92, -4.0, v94, 4.0                        ; d669005c 03dabcf7
	v_dual_fmaak_f32 v88, v88, v83, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 ; c842a758 5850a551 3f650000
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_mul_f32 v123, v123, v88 :: v_dual_mul_f32 v122, v122, v81 ; c8c6b17b 7b7aa37a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmaak_f32 v92, v92, v93, 0x3f650000                       ; 5ab8bb5c 3f650000
	v_maxmin_num_f32 v93, -4.0, v126, 4.0                       ; d669005d 03dafcf7
	v_dual_mul_f32 v94, v92, v94 :: v_dual_mul_f32 v95, v95, v72 ; c8c6bd5c 5e5e915f
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v152, 4.0                      ; d6690079 03db30f7
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v123, -4.0, v153, 4.0                      ; d669007b 03db32f7
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v127, 4.0                       ; d669005f 03dafef7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c842b75c 5c58b559 3f650000
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v120, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfebeff 3728ab28
	v_dual_mul_f32 v125, v125, v92 :: v_dual_mul_f32 v124, v124, v89 ; c8c6b97d 7d7cb37c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v120, v120, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf78 785cbd5d 3f650000
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v125, -4.0, v154, 4.0                      ; d669007d 03db34f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_mul_f32 v127, v127, v120 :: v_dual_mul_f32 v126, v126, v93 ; c8c6f17f 7f7ebb7e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c842f579 797cf77c 3f650000
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v127, -4.0, v155, 4.0                      ; d669007f 03db36f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v82, -4.0, v159, 4.0                       ; d6690052 03db3ef7
	v_dual_mul_f32 v153, v153, v124 :: v_dual_mul_f32 v152, v152, v121 ; c8c6f999 9998f398
	v_maxmin_num_f32 v80, -4.0, v158, 4.0                       ; d6690050 03db3cf7
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v153, -4.0, v156, 4.0                      ; d6690099 03db38f7
	v_fma_mix_f32 v152, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bfefeff 3728ab28
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[86:87], v[52:53], v[112:119] ; cc464070 1dc26956
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[86:87], v[40:41], v[144:151] ; cc464090 1e425156
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[86:87], v[62:63], v[176:183] ; cc4640b0 1ec27d56
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[86:87], v[56:57], v[14:21] ; cc46400e 1c3a7156
	v_dual_fmaak_f32 v152, v152, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842ff98 987cfd7d 3f650000
	v_maxmin_num_f32 v86, -4.0, v185, 4.0                       ; d6690056 03db72f7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[84:85], v[52:53], v[104:111] ; cc464068 1da26954
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[84:85], v[40:41], v[136:143] ; cc464088 1e225154
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[84:85], v[62:63], v[168:175] ; cc4640a8 1ea27d54
	v_dual_mul_f32 v155, v155, v152 :: v_dual_mul_f32 v154, v154, v125 ; c8c7319b 9b9afb9a
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[84:85], v[56:57], v[28:35] ; cc46401c 1c727154
	v_maxmin_num_f32 v84, -4.0, v184, 4.0                       ; d6690054 03db70f7
	v_maxmin_num_f32 v90, -4.0, v187, 4.0                       ; d669005a 03db76f7
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v155, -4.0, v157, 4.0                      ; d669009b 03db3af7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v186, 4.0                       ; d6690058 03db74f7
	v_maxmin_num_f32 v94, -4.0, v189, 4.0                       ; d669005e 03db7af7
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v59, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623b 0bff36ff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v188, 4.0                       ; d669005c 03db78f7
	v_fmaak_f32 v153, v153, v154, 0x3f650000                    ; 5b333599 3f650000
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_maxmin_num_f32 v122, -4.0, v191, 4.0                      ; d669007a 03db7ef7
	v_fmaak_f32 v59, v59, v155, 0x3f650000                      ; 5a77373b 3f650000
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v120, -4.0, v190, 4.0                      ; d6690078 03db7cf7
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_mul_f32 v156, v156, v153 ; c846a553 539d339c 3f650000
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_mul_f32_e32 v157, v157, v59                               ; 113a779d
	v_maxmin_num_f32 v126, -4.0, v97, 4.0                       ; d669007e 03dac2f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_maxmin_num_f32 v124, -4.0, v96, 4.0                       ; d669007c 03dac0f7
	v_dual_mul_f32 v159, v159, v83 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c8c2a79f 9f50a350 3f650000
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v99, 4.0                       ; d669009a 03dac6f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_mul_f32 v158, v158, v80 ; c846ad57 579ea19e 3f650000
	v_maxmin_num_f32 v152, -4.0, v98, 4.0                       ; d6690098 03dac4f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_mul_f32 v185, v185, v87 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c8c2afb9 b954ab54 3f650000
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v101, 4.0                      ; d669009e 03dacaf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_mul_f32 v184, v184, v84 ; c846b55b 5bb8a9b8 3f650000
	v_maxmin_num_f32 v156, -4.0, v100, 4.0                      ; d669009c 03dac8f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_dual_mul_f32 v187, v187, v91 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c8c2b7bb bb58b358 3f650000
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_mul_f32 v186, v186, v88 ; c846bd5f 5fbab1ba 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870241
	v_dual_mul_f32 v189, v189, v95 :: v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 ; c8c2bfbd bd5cbb5c 3f650000
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v186, -4.0, v103, 4.0                      ; d66900ba 03dacef7
	v_maxmin_num_f32 v184, -4.0, v102, 4.0                      ; d66900b8 03daccf7
	v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 :: v_dual_mul_f32 v188, v188, v92 ; c846f57b 7bbcb9bc 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_mul_f32 v191, v191, v123 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8c2f7bf bf78f378 3f650000
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_maxmin_num_f32 v188, -4.0, v128, 4.0                      ; d66900bc 03db00f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_mul_f32 v190, v190, v120 ; c846fd7f 7fbef1be 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v190, -4.0, v129, 4.0                      ; d66900be 03db02f7
	v_dual_mul_f32 v97, v97, v127 :: v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 ; c8c2ff61 617cfb7c 3f650000
	v_maxmin_num_f32 v59, -4.0, v131, 4.0                       ; d669003b 03db06f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_mul_f32 v96, v96, v124 ; c847359b 9b60f960 3f650000
	v_fma_mix_f32 v62, 0xab28, |v59|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623e 0bfe76ff 3728ab28
	v_maxmin_num_f32 v63, -4.0, v132, 4.0                       ; d669003f 03db08f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v99, v99, v155 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c8c33763 63993398 3f650000
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v81, -4.0, v133, 4.0                       ; d6690051 03db0af7
	v_fma_mix_f32 v80, 0xab28, |v63|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe7eff 3728ab28
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_mul_f32 v98, v98, v152 ; c8473d9f 9f633162 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_maxmin_num_f32 v83, -4.0, v134, 4.0                       ; d6690053 03db0cf7
	v_dual_mul_f32 v101, v101, v159 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8c33f65 659d3b9c 3f650000
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v85, -4.0, v135, 4.0                       ; d6690055 03db0ef7
	v_dual_fmaak_f32 v63, v63, v80, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 ; c842a13f 3f52a352 3f650000
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_mul_f32 v100, v100, v156 ; c84775bb bb653964 3f650000
	v_maxmin_num_f32 v87, -4.0, v160, 4.0                       ; d6690057 03db40f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v161, 4.0                       ; d6690059 03db42f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_mul_f32 v103, v103, v187 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8c37767 67b973b8 3f650000
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842a953 5356ab56 3f650000
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v162, 4.0                       ; d669005b 03db44f7
	v_maxmin_num_f32 v93, -4.0, v163, 4.0                       ; d669005d 03db46f7
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_mul_f32 v102, v102, v184 ; c8477dbf bf677166 3f650000
	v_dual_mul_f32 v135, v135, v86 :: v_dual_mul_f32 v132, v132, v63 ; c8c6ad87 87847f84
	v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b157 575ab35a 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v164, 4.0                       ; d669005f 03db48f7
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_mul_f32 v129, v129, v191 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8c37f81 81bd7bbc 3f650000
	v_maxmin_num_f32 v191, -4.0, v130, 4.0                      ; d66900bf 03db04f7
	v_maxmin_num_f32 v97, -4.0, v165, 4.0                       ; d6690061 03db4af7
	v_dual_mul_f32 v161, v161, v90 :: v_dual_mul_f32 v134, v134, v83 ; c8c6b5a1 a186a786
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842b95b 5b5ebb5e 3f650000
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v166, 4.0                       ; d6690063 03db4cf7
	v_maxmin_num_f32 v101, -4.0, v167, 4.0                      ; d6690065 03db4ef7
	v_fma_mix_f32 v57, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206239 0bff7eff 3728ab28
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_mul_f32 v163, v163, v94 :: v_dual_mul_f32 v160, v160, v87 ; c8c6bda3 a3a0afa0
	v_maxmin_num_f32 v103, -4.0, v6, 4.0                        ; d6690067 03da0cf7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v7, 4.0                        ; d6690079 03da0ef7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_dual_fmaak_f32 v191, v191, v57, 0x3f650000 :: v_dual_fmaak_f32 v62, v62, v59, 0x3f650000 ; c84273bf bf3e773e 3f650000
	v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 ; c842c15f 5f62c362 3f650000
	v_fma_mix_f32 v120, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeceff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v8, 4.0                        ; d669007b 03da10f7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c842c963 6366cb66 3f650000
	v_maxmin_num_f32 v125, -4.0, v9, 4.0                        ; d669007d 03da12f7
	v_dual_mul_f32 v133, v133, v82 :: v_dual_mul_f32 v130, v130, v191 ; c8c6a585 85837f82
	v_dual_mul_f32 v131, v131, v62 :: v_dual_mul_f32 v128, v128, v188 ; c8c67d83 83817980
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_dual_mul_f32 v165, v165, v98 :: v_dual_mul_f32 v162, v162, v91 ; c8c6c5a5 a5a2b7a2
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v10, 4.0                       ; d669007f 03da14f7
	v_dual_fmaak_f32 v103, v103, v120, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f167 677af37a 3f650000
	v_dual_mul_f32 v167, v167, v102 :: v_dual_mul_f32 v164, v164, v95 ; c8c6cda7 a7a4bfa4
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v129, -4.0, v11, 4.0                       ; d6690081 03da16f7
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_maxmin_num_f32 v131, -4.0, v12, 4.0                       ; d6690083 03da18f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v133, -4.0, v13, 4.0                       ; d6690085 03da1af7
	v_dual_mul_f32 v7, v7, v122 :: v_dual_mul_f32 v166, v166, v99 ; c8c6f507 07a6c7a6
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c842f97b 7b7efb7e 3f650000
	v_maxmin_num_f32 v135, -4.0, v104, 4.0                      ; d6690087 03dad0f7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v153, -4.0, v105, 4.0                      ; d6690099 03dad2f7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v106, 4.0                      ; d669009b 03dad4f7
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_maxmin_num_f32 v157, -4.0, v107, 4.0                      ; d669009d 03dad6f7
	v_dual_mul_f32 v9, v9, v126 :: v_dual_mul_f32 v6, v6, v103  ; c8c6fd09 0906cf06
	v_fma_mix_f32 v152, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff0eff 3728ab28
	v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 ; c843017f 7f830382 3f650000
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v159, -4.0, v108, 4.0                      ; d669009f 03dad8f7
	v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 ; c8430983 83870b86 3f650000
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v109, 4.0                      ; d66900a1 03dadaf7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
	v_dual_mul_f32 v11, v11, v130 :: v_dual_mul_f32 v8, v8, v123 ; c8c7050b 0b08f708
	v_maxmin_num_f32 v163, -4.0, v110, 4.0                      ; d66900a3 03dadcf7
	v_dual_fmaak_f32 v135, v135, v152, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c8433187 879b339a 3f650000
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v111, 4.0                      ; d66900a5 03dadef7
	v_dual_mul_f32 v13, v13, v134 :: v_dual_mul_f32 v10, v10, v127 ; c8c70d0d 0d0aff0a
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 ; c843399b 9b9f3b9e 3f650000
	v_maxmin_num_f32 v167, -4.0, v136, 4.0                      ; d66900a7 03db10f7
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v137, 4.0                      ; d66900b9 03db12f7
	v_dual_mul_f32 v105, v105, v154 :: v_dual_mul_f32 v12, v12, v131 ; c8c73569 690d070c
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c843419f 9fa343a2 3f650000
	v_dual_mul_f32 v107, v107, v158 :: v_dual_mul_f32 v104, v104, v135 ; c8c73d6b 6b690f68
	v_maxmin_num_f32 v187, -4.0, v138, 4.0                      ; d66900bb 03db14f7
	v_fma_mix_f32 v184, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff4eff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v139, 4.0                      ; d66900bd 03db16f7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84349a3 a3a74ba6 3f650000
	v_maxmin_num_f32 v191, -4.0, v140, 4.0                      ; d66900bf 03db18f7
	v_dual_mul_f32 v109, v109, v162 :: v_dual_mul_f32 v106, v106, v155 ; c8c7456d 6d6b376a
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v12, -4.0, v141, 4.0                       ; d669000c 03db1af7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_fmaak_f32 v167, v167, v184, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84371a7 a7bb73ba 3f650000
	v_maxmin_num_f32 v59, -4.0, v142, 4.0                       ; d669003b 03db1cf7
	v_dual_mul_f32 v111, v111, v166 :: v_dual_mul_f32 v108, v108, v159 ; c8c74d6f 6f6d3f6c
	v_fma_mix_f32 v11, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620b 0bff7eff 3728ab28
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v81, -4.0, v143, 4.0                       ; d6690051 03db1ef7
	v_fma_mix_f32 v13, 0xab28, |v12|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bfe18ff 3728ab28
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c84379bb bbbf7bbe 3f650000
	v_dual_mul_f32 v137, v137, v186 :: v_dual_mul_f32 v110, v110, v163 ; c8c77589 896f476e
	v_maxmin_num_f32 v83, -4.0, v168, 4.0                       ; d6690053 03db50f7
	v_fma_mix_f32 v80, 0xab28, |v59|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe76ff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v169, 4.0                       ; d6690055 03db52f7
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fmaak_f32 v191, v191, v11, 0x3f650000                     ; 5b7e17bf 3f650000
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_dual_fmaak_f32 v13, v13, v12, 0x3f650000 :: v_dual_mul_f32 v138, v138, v187 ; c846190d 0d8b778a 3f650000
	v_maxmin_num_f32 v87, -4.0, v170, 4.0                       ; d6690057 03db54f7
	v_dual_mul_f32 v139, v139, v190 :: v_dual_mul_f32 v136, v136, v167 ; c8c77d8b 8b894f88
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v171, 4.0                       ; d6690059 03db56f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v172, 4.0                       ; d669005b 03db58f7
	v_dual_fmaak_f32 v59, v59, v80, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 ; c842a13b 3b52a352 3f650000
	v_dual_mul_f32 v141, v141, v13 :: v_dual_mul_f32 v140, v140, v191 ; c8c61b8d 8d8d7f8c
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v173, 4.0                       ; d669005d 03db5af7
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v174, 4.0                       ; d669005f 03db5cf7
	v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842a953 5356ab56 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_mul_f32 v143, v143, v82 :: v_dual_mul_f32 v142, v142, v59 ; c8c6a58f 8f8e778e
	v_maxmin_num_f32 v97, -4.0, v175, 4.0                       ; d6690061 03db5ef7
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v28, 4.0                        ; d6690063 03da38f7
	v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 :: v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 ; c842b35a 5a56b157 3f650000
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v29, 4.0                       ; d6690065 03da3af7
	v_dual_mul_f32 v169, v169, v86 :: v_dual_mul_f32 v168, v168, v83 ; c8c6ada9 a9a8a7a8
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v30, 4.0                       ; d6690067 03da3cf7
	v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 :: v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 ; c842bb5e 5e5ab95b 3f650000
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v105, -4.0, v31, 4.0                       ; d6690069 03da3ef7
	v_dual_mul_f32 v171, v171, v90 :: v_dual_mul_f32 v170, v170, v87 ; c8c6b5ab abaaafaa
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_maxmin_num_f32 v107, -4.0, v32, 4.0                       ; d669006b 03da40f7
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c842c362 625ec15f 3f650000
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_maxmin_num_f32 v109, -4.0, v33, 4.0                       ; d669006d 03da42f7
	v_dual_mul_f32 v173, v173, v94 :: v_dual_mul_f32 v172, v172, v91 ; c8c6bdad adacb7ac
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 :: v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 ; c842cb66 6662c963 3f650000
	v_maxmin_num_f32 v111, -4.0, v34, 4.0                       ; d669006f 03da44f7
	v_maxmin_num_f32 v121, -4.0, v35, 4.0                       ; d6690079 03da46f7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_dual_mul_f32 v175, v175, v98 :: v_dual_mul_f32 v174, v174, v95 ; c8c6c5af afaebfae
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_maxmin_num_f32 v123, -4.0, v112, 4.0                      ; d669007b 03dae0f7
	v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 :: v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 ; c842d36a 6a66d167 3f650000
	v_maxmin_num_f32 v125, -4.0, v113, 4.0                      ; d669007d 03dae2f7
	v_dual_mul_f32 v29, v29, v102 :: v_dual_mul_f32 v28, v28, v99 ; c8c6cd1d 1d1cc71c
	v_fma_mix_f32 v120, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfedeff 3728ab28
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_maxmin_num_f32 v127, -4.0, v114, 4.0                      ; d669007f 03dae4f7
	v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 :: v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 ; c842db6e 6e6ad96b 3f650000
	v_maxmin_num_f32 v129, -4.0, v115, 4.0                      ; d6690081 03dae6f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_mul_f32 v31, v31, v106 :: v_dual_mul_f32 v30, v30, v103 ; c8c6d51f 1f1ecf1e
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
	v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 :: v_dual_fmaak_f32 v111, v111, v120, 0x3f650000 ; c842f37a 7a6ef16f 3f650000
	v_maxmin_num_f32 v131, -4.0, v116, 4.0                      ; d6690083 03dae8f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v133, -4.0, v117, 4.0                      ; d6690085 03daeaf7
	v_dual_mul_f32 v33, v33, v110 :: v_dual_mul_f32 v32, v32, v107 ; c8c6dd21 2120d720
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
	v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 ; c842fb7e 7e7af97b 3f650000
	v_maxmin_num_f32 v135, -4.0, v118, 4.0                      ; d6690087 03daecf7
	v_dual_mul_f32 v35, v35, v122 :: v_dual_mul_f32 v34, v34, v111 ; c8c6f523 2322df22
	v_maxmin_num_f32 v137, -4.0, v119, 4.0                      ; d6690089 03daeef7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 :: v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 ; c8430382 827f017f 3f650000
	v_maxmin_num_f32 v139, -4.0, v144, 4.0                      ; d669008b 03db20f7
	v_maxmin_num_f32 v141, -4.0, v145, 4.0                      ; d669008d 03db22f7
	v_dual_mul_f32 v113, v113, v126 :: v_dual_mul_f32 v112, v112, v123 ; c8c6fd71 7170f770
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 ; c8430b86 86830983 3f650000
	v_maxmin_num_f32 v143, -4.0, v146, 4.0                      ; d669008f 03db24f7
	v_dual_mul_f32 v115, v115, v130 :: v_dual_mul_f32 v114, v114, v127 ; c8c70573 7372ff72
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 :: v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 ; c843138a 8a871187 3f650000
	v_maxmin_num_f32 v153, -4.0, v148, 4.0                      ; d6690099 03db28f7
	v_dual_mul_f32 v117, v117, v134 :: v_dual_mul_f32 v116, v116, v131 ; c8c70d75 75750774
	v_maxmin_num_f32 v155, -4.0, v149, 4.0                      ; d669009b 03db2af7
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 :: v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 ; c8431b8e 8e8b198b 3f650000
	v_maxmin_num_f32 v157, -4.0, v150, 4.0                      ; d669009d 03db2cf7
	v_dual_mul_f32 v119, v119, v138 :: v_dual_mul_f32 v118, v118, v135 ; c8c71577 77770f76
	v_maxmin_num_f32 v159, -4.0, v151, 4.0                      ; d669009f 03db2ef7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_mul_f32 v145, v145, v142 :: v_dual_mul_f32 v144, v144, v139 ; c8c71d91 91911790
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v176, 4.0                      ; d66900a1 03db60f7
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v177, 4.0                      ; d66900a3 03db62f7
	v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 ; c8433599 999d379c 3f650000
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v145, -4.0, v147, 4.0                      ; d6690091 03db26f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v178, 4.0                      ; d66900a5 03db64f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v179, 4.0                      ; d66900a7 03db66f7
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c8433fa0 a09d3d9d 3f650000
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_dual_mul_f32 v149, v149, v156 :: v_dual_mul_f32 v148, v148, v153 ; c8c73995 95953394
	v_fma_mix_f32 v152, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff22ff 3728ab28
	v_maxmin_num_f32 v169, -4.0, v180, 4.0                      ; d66900a9 03db68f7
	v_maxmin_num_f32 v171, -4.0, v181, 4.0                      ; d66900ab 03db6af7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_mul_f32 v151, v151, v160 :: v_dual_mul_f32 v150, v150, v157 ; c8c74197 97973b96
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c84347a4 a4a145a1 3f650000
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v173, -4.0, v182, 4.0                      ; d66900ad 03db6cf7
	v_dual_fmaak_f32 v143, v143, v144, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v145, 0x3f650000 ; c843218f 8f992398 3f650000
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_maxmin_num_f32 v175, -4.0, v183, 4.0                      ; d66900af 03db6ef7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 ; c8434fa8 a8a54da5 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_dual_mul_f32 v177, v177, v164 :: v_dual_mul_f32 v176, v176, v161 ; c8c749b1 b1b143b0
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_mul_f32 v147, v147, v152 :: v_dual_mul_f32 v146, v146, v143 ; c8c73193 93931f92
	v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 ; c84357ac aca955a9 3f650000
	v_dual_mul_f32 v179, v179, v168 :: v_dual_mul_f32 v178, v178, v165 ; c8c751b3 b3b34bb2
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_maxmin_num_f32 v177, -4.0, v14, 4.0                       ; d66900b1 03da1cf7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_dual_mul_f32 v181, v181, v172 :: v_dual_mul_f32 v180, v180, v169 ; c8c759b5 b5b553b4
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_maxmin_num_f32 v179, -4.0, v15, 4.0                       ; d66900b3 03da1ef7
	v_maxmin_num_f32 v185, -4.0, v18, 4.0                       ; d66900b9 03da24f7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v187, -4.0, v19, 4.0                       ; d66900bb 03da26f7
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 ; c8435fb0 b0ad5dad 3f650000
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_maxmin_num_f32 v181, -4.0, v16, 4.0                       ; d66900b5 03da20f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v20, 4.0                       ; d66900bd 03da28f7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v21, 4.0                       ; d66900bf 03da2af7
	v_dual_mul_f32 v183, v183, v176 :: v_dual_mul_f32 v182, v182, v173 ; c8c761b7 b7b75bb6
	v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 ; c84365b1 b1b567b4 3f650000
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 ; c84377bc bcb975b9 3f650000
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[26:27], 0 ; cc464050 1a02352e
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_maxmin_num_f32 v183, -4.0, v17, 4.0                       ; d66900b7 03da22f7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_dual_mul_f32 v15, v15, v180 :: v_dual_mul_f32 v14, v14, v177 ; c8c7690f 0f0f630e
	v_dual_mul_f32 v19, v19, v188 :: v_dual_mul_f32 v18, v18, v185 ; c8c77913 13137312
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[26:27], 0 ; cc464070 1a023530
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[26:27], 0 ; cc464090 1a023544
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[22:23], 0 ; cc464060 1a022d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[48:49], v[22:23], 0 ; cc464080 1a022d30
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[22:23], 0 ; cc4640a0 1a022d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[46:47], v[64:65], 0 ; cc464058 1a02812e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[64:65], 0 ; cc464078 1a028130
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[64:65], 0 ; cc464098 1a028144
	v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 ; c8436db5 b5b96fb8 3f650000
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[44:45], 0 ; cc464068 1a02592e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[48:49], v[44:45], 0 ; cc464088 1a025930
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[44:45], 0 ; cc4640a8 1a025944
	v_dual_mul_f32 v17, v17, v184 :: v_dual_mul_f32 v16, v16, v181 ; c8c77111 11116b10
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[26:27], 0 ; cc4640b0 1a023546
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_fma_mix_f32 v16, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206210 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v191, 0x3f650000 ; c8437dbd bd117f10 3f650000
	v_dual_mul_f32 v21, v21, v16 :: v_dual_mul_f32 v20, v20, v189 ; c8c62115 15157b14
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[64:65], 0 ; cc4640b8 1a028146
	v_dual_mov_b32 v64, v43 :: v_dual_mov_b32 v59, v42          ; ca10012b 403a012a
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mov_b32 v27, v15 :: v_dual_mov_b32 v26, v14          ; ca10010f 1b1a010e
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[22:23], 0 ; cc46400e 1a022d46
	v_dual_mov_b32 v23, v45 :: v_dual_mov_b32 v22, v44          ; ca10012d 1716012c
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[22:23], 0 ; cc46402a 1a022d46
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:512 ; c405c07c 40804844 00020036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[60:61], v[104:111] ; cc464068 1da27944
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[66:67], v[80:87] ; cc464050 1d428544
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[36:37], v[120:127] ; cc464078 1de24946
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[38:39], v[96:103] ; cc464060 1d824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[66:67], v[112:119] ; cc464070 1dc28546
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[38:39], v[128:135] ; cc464080 1e024d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[60:61], v[136:143] ; cc464088 1e227946
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[36:37], v[88:95] ; cc464058 1d624944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:512 ; c405c07c 40804844 00020018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[36:37], v[184:191] ; cc4640b8 1ee24946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[66:67], v[144:151] ; cc464090 1e428544
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[38:39], v[14:21] ; cc46400e 1c3a4d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[38:39], v[160:167] ; cc4640a0 1e824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[36:37], v[152:159] ; cc464098 1e624944
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[66:67], v[176:183] ; cc4640b0 1ec28546
	ds_load_b64 v[22:23], v64 offset:512                        ; d9d80200 16000040
	ds_load_b64 v[66:67], v64 offset:4608                       ; d9d81200 42000040
	ds_load_b64 v[36:37], v64 offset:8704                       ; d9d82200 24000040
	ds_load_b64 v[38:39], v64 offset:12800                      ; d9d83200 26000040
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[60:61], v[42:49] ; cc46402a 1caa7946
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[60:61], v[168:175] ; cc4640a8 1ea27944
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:1024 ; c405c07c 40804844 00040036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[38:39], v[104:111] ; cc464068 1da24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[22:23], v[112:119] ; cc464070 1dc22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[66:67], v[120:127] ; cc464078 1de28546
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[36:37], v[128:135] ; cc464080 1e024946
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[38:39], v[136:143] ; cc464088 1e224d46
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[22:23], v[80:87] ; cc464050 1d422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[66:67], v[88:95] ; cc464058 1d628544
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[36:37], v[96:103] ; cc464060 1d824944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:1024 ; c405c07c 40804844 00040018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[66:67], v[184:191] ; cc4640b8 1ee28546
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[22:23], v[144:151] ; cc464090 1e422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[36:37], v[160:167] ; cc4640a0 1e824944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[36:37], v[14:21] ; cc46400e 1c3a4946
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[22:23], v[176:183] ; cc4640b0 1ec22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[66:67], v[152:159] ; cc464098 1e628544
	ds_load_b64 v[60:61], v64 offset:768                        ; d9d80300 3c000040
	ds_load_b64 v[22:23], v64 offset:4864                       ; d9d81300 16000040
	ds_load_b64 v[66:67], v64 offset:8960                       ; d9d82300 42000040
	ds_load_b64 v[36:37], v64 offset:13056                      ; d9d83300 24000040
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[38:39], v[42:49] ; cc46402a 1caa4d46
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[38:39], v[168:175] ; cc4640a8 1ea24d44
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:1536 ; c405c07c 40804844 00060036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[36:37], v[104:111] ; cc464068 1da24944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[60:61], v[112:119] ; cc464070 1dc27946
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[22:23], v[120:127] ; cc464078 1de22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[66:67], v[128:135] ; cc464080 1e028546
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[36:37], v[136:143] ; cc464088 1e224946
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[66:67], v[96:103] ; cc464060 1d828544
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[60:61], v[80:87] ; cc464050 1d427944
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[22:23], v[88:95] ; cc464058 1d622d44
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:1536 ; c405c07c 40804844 00060018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[22:23], v[184:191] ; cc4640b8 1ee22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[66:67], v[160:167] ; cc4640a0 1e828544
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[66:67], v[14:21] ; cc46400e 1c3a8546
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[60:61], v[176:183] ; cc4640b0 1ec27946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[60:61], v[144:151] ; cc464090 1e427944
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[22:23], v[152:159] ; cc464098 1e622d44
	ds_load_b64 v[38:39], v64 offset:1024                       ; d9d80400 26000040
	ds_load_b64 v[60:61], v64 offset:5120                       ; d9d81400 3c000040
	ds_load_b64 v[22:23], v64 offset:9216                       ; d9d82400 16000040
	ds_load_b64 v[66:67], v64 offset:13312                      ; d9d83400 42000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[36:37], v[168:175] ; cc4640a8 1ea24944
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[36:37], v[42:49] ; cc46402a 1caa4946
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:2048 ; c405c07c 40804844 00080036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[66:67], v[104:111] ; cc464068 1da28544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[38:39], v[112:119] ; cc464070 1dc24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[60:61], v[120:127] ; cc464078 1de27946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[22:23], v[128:135] ; cc464080 1e022d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[66:67], v[136:143] ; cc464088 1e228546
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[22:23], v[96:103] ; cc464060 1d822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[38:39], v[80:87] ; cc464050 1d424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[60:61], v[88:95] ; cc464058 1d627944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:2048 ; c405c07c 40804844 00080018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[60:61], v[184:191] ; cc4640b8 1ee27946
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[22:23], v[160:167] ; cc4640a0 1e822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[22:23], v[14:21] ; cc46400e 1c3a2d46
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[38:39], v[144:151] ; cc464090 1e424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[38:39], v[176:183] ; cc4640b0 1ec24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[60:61], v[152:159] ; cc464098 1e627944
	ds_load_b64 v[36:37], v64 offset:1280                       ; d9d80500 24000040
	ds_load_b64 v[38:39], v64 offset:5376                       ; d9d81500 26000040
	ds_load_b64 v[60:61], v64 offset:9472                       ; d9d82500 3c000040
	ds_load_b64 v[22:23], v64 offset:13568                      ; d9d83500 16000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[66:67], v[168:175] ; cc4640a8 1ea28544
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[66:67], v[42:49] ; cc46402a 1caa8546
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:2560 ; c405c07c 40804844 000a0036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[22:23], v[104:111] ; cc464068 1da22d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[36:37], v[112:119] ; cc464070 1dc24946
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[38:39], v[120:127] ; cc464078 1de24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[60:61], v[128:135] ; cc464080 1e027946
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[60:61], v[96:103] ; cc464060 1d827944
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[22:23], v[136:143] ; cc464088 1e222d46
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[36:37], v[80:87] ; cc464050 1d424944
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[38:39], v[88:95] ; cc464058 1d624d44
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:2560 ; c405c07c 40804844 000a0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[38:39], v[184:191] ; cc4640b8 1ee24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[60:61], v[160:167] ; cc4640a0 1e827944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[60:61], v[14:21] ; cc46400e 1c3a7946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[36:37], v[144:151] ; cc464090 1e424944
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[36:37], v[176:183] ; cc4640b0 1ec24946
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[38:39], v[152:159] ; cc464098 1e624d44
	ds_load_b64 v[66:67], v64 offset:1536                       ; d9d80600 42000040
	ds_load_b64 v[36:37], v64 offset:5632                       ; d9d81600 24000040
	ds_load_b64 v[38:39], v64 offset:9728                       ; d9d82600 26000040
	ds_load_b64 v[60:61], v64 offset:13824                      ; d9d83600 3c000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[22:23], v[168:175] ; cc4640a8 1ea22d44
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[22:23], v[42:49] ; cc46402a 1caa2d46
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:3072 ; c405c07c 40804844 000c0036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[60:61], v[104:111] ; cc464068 1da27944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[66:67], v[112:119] ; cc464070 1dc28546
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[36:37], v[120:127] ; cc464078 1de24946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[38:39], v[128:135] ; cc464080 1e024d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[60:61], v[136:143] ; cc464088 1e227946
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[38:39], v[96:103] ; cc464060 1d824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[66:67], v[80:87] ; cc464050 1d428544
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[36:37], v[88:95] ; cc464058 1d624944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:3072 ; c405c07c 40804844 000c0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[36:37], v[184:191] ; cc4640b8 1ee24946
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[38:39], v[160:167] ; cc4640a0 1e824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[38:39], v[14:21] ; cc46400e 1c3a4d46
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[66:67], v[144:151] ; cc464090 1e428544
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[66:67], v[176:183] ; cc4640b0 1ec28546
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[36:37], v[152:159] ; cc464098 1e624944
	ds_load_b64 v[22:23], v64 offset:1792                       ; d9d80700 16000040
	ds_load_b64 v[66:67], v64 offset:5888                       ; d9d81700 42000040
	ds_load_b64 v[36:37], v64 offset:9984                       ; d9d82700 24000040
	ds_load_b64 v[38:39], v64 offset:14080                      ; d9d83700 26000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[60:61], v[168:175] ; cc4640a8 1ea27944
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[60:61], v[42:49] ; cc46402a 1caa7946
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:3584 ; c405c07c 40804844 000e0036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[38:39], v[104:111] ; cc464068 1da24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[22:23], v[112:119] ; cc464070 1dc22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[66:67], v[120:127] ; cc464078 1de28546
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[36:37], v[128:135] ; cc464080 1e024946
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[38:39], v[136:143] ; cc464088 1e224d46
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[36:37], v[96:103] ; cc464060 1d824944
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[22:23], v[80:87] ; cc464050 1d422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[66:67], v[88:95] ; cc464058 1d628544
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:3584 ; c405c07c 40804844 000e0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[66:67], v[184:191] ; cc4640b8 1ee28546
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[36:37], v[160:167] ; cc4640a0 1e824944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[36:37], v[14:21] ; cc46400e 1c3a4946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[22:23], v[144:151] ; cc464090 1e422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[22:23], v[176:183] ; cc4640b0 1ec22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[66:67], v[152:159] ; cc464098 1e628544
	ds_load_b64 v[60:61], v64 offset:2048                       ; d9d80800 3c000040
	ds_load_b64 v[22:23], v64 offset:6144                       ; d9d81800 16000040
	ds_load_b64 v[66:67], v64 offset:10240                      ; d9d82800 42000040
	ds_load_b64 v[36:37], v64 offset:14336                      ; d9d83800 24000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[38:39], v[168:175] ; cc4640a8 1ea24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[38:39], v[42:49] ; cc46402a 1caa4d46
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:4096 ; c405c07c 40804844 00100036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[36:37], v[104:111] ; cc464068 1da24944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[60:61], v[112:119] ; cc464070 1dc27946
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[22:23], v[120:127] ; cc464078 1de22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[66:67], v[128:135] ; cc464080 1e028546
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[36:37], v[136:143] ; cc464088 1e224946
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[66:67], v[96:103] ; cc464060 1d828544
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[60:61], v[80:87] ; cc464050 1d427944
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[22:23], v[88:95] ; cc464058 1d622d44
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:4096 ; c405c07c 40804844 00100018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[22:23], v[184:191] ; cc4640b8 1ee22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[66:67], v[160:167] ; cc4640a0 1e828544
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[66:67], v[14:21] ; cc46400e 1c3a8546
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[60:61], v[144:151] ; cc464090 1e427944
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[60:61], v[176:183] ; cc4640b0 1ec27946
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[22:23], v[152:159] ; cc464098 1e622d44
	ds_load_b64 v[38:39], v64 offset:2304                       ; d9d80900 26000040
	ds_load_b64 v[60:61], v64 offset:6400                       ; d9d81900 3c000040
	ds_load_b64 v[22:23], v64 offset:10496                      ; d9d82900 16000040
	ds_load_b64 v[66:67], v64 offset:14592                      ; d9d83900 42000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[36:37], v[168:175] ; cc4640a8 1ea24944
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[36:37], v[42:49] ; cc46402a 1caa4946
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:4608 ; c405c07c 40804844 00120036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[66:67], v[104:111] ; cc464068 1da28544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[38:39], v[112:119] ; cc464070 1dc24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[60:61], v[120:127] ; cc464078 1de27946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[22:23], v[128:135] ; cc464080 1e022d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[66:67], v[136:143] ; cc464088 1e228546
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[22:23], v[96:103] ; cc464060 1d822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[38:39], v[80:87] ; cc464050 1d424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[60:61], v[88:95] ; cc464058 1d627944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:4608 ; c405c07c 40804844 00120018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[60:61], v[184:191] ; cc4640b8 1ee27946
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[22:23], v[160:167] ; cc4640a0 1e822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[22:23], v[14:21] ; cc46400e 1c3a2d46
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[38:39], v[144:151] ; cc464090 1e424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[38:39], v[176:183] ; cc4640b0 1ec24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[60:61], v[152:159] ; cc464098 1e627944
	ds_load_b64 v[36:37], v64 offset:2560                       ; d9d80a00 24000040
	ds_load_b64 v[38:39], v64 offset:6656                       ; d9d81a00 26000040
	ds_load_b64 v[60:61], v64 offset:10752                      ; d9d82a00 3c000040
	ds_load_b64 v[22:23], v64 offset:14848                      ; d9d83a00 16000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[66:67], v[168:175] ; cc4640a8 1ea28544
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[66:67], v[42:49] ; cc46402a 1caa8546
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:5120 ; c405c07c 40804844 00140036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[22:23], v[104:111] ; cc464068 1da22d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[36:37], v[112:119] ; cc464070 1dc24946
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[38:39], v[120:127] ; cc464078 1de24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[60:61], v[128:135] ; cc464080 1e027946
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[22:23], v[136:143] ; cc464088 1e222d46
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[60:61], v[96:103] ; cc464060 1d827944
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[36:37], v[80:87] ; cc464050 1d424944
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[38:39], v[88:95] ; cc464058 1d624d44
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:5120 ; c405c07c 40804844 00140018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[38:39], v[184:191] ; cc4640b8 1ee24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[60:61], v[160:167] ; cc4640a0 1e827944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[60:61], v[14:21] ; cc46400e 1c3a7946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[36:37], v[144:151] ; cc464090 1e424944
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[36:37], v[176:183] ; cc4640b0 1ec24946
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[38:39], v[152:159] ; cc464098 1e624d44
	ds_load_b64 v[66:67], v64 offset:2816                       ; d9d80b00 42000040
	ds_load_b64 v[36:37], v64 offset:6912                       ; d9d81b00 24000040
	ds_load_b64 v[38:39], v64 offset:11008                      ; d9d82b00 26000040
	ds_load_b64 v[60:61], v64 offset:15104                      ; d9d83b00 3c000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[22:23], v[168:175] ; cc4640a8 1ea22d44
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[22:23], v[42:49] ; cc46402a 1caa2d46
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:5632 ; c405c07c 40804844 00160036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[60:61], v[104:111] ; cc464068 1da27944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[66:67], v[112:119] ; cc464070 1dc28546
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[36:37], v[120:127] ; cc464078 1de24946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[38:39], v[128:135] ; cc464080 1e024d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[60:61], v[136:143] ; cc464088 1e227946
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[38:39], v[96:103] ; cc464060 1d824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[66:67], v[80:87] ; cc464050 1d428544
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[36:37], v[88:95] ; cc464058 1d624944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:5632 ; c405c07c 40804844 00160018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[36:37], v[184:191] ; cc4640b8 1ee24946
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[38:39], v[160:167] ; cc4640a0 1e824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[38:39], v[14:21] ; cc46400e 1c3a4d46
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[66:67], v[144:151] ; cc464090 1e428544
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[66:67], v[176:183] ; cc4640b0 1ec28546
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[36:37], v[152:159] ; cc464098 1e624944
	ds_load_b64 v[22:23], v64 offset:3072                       ; d9d80c00 16000040
	ds_load_b64 v[66:67], v64 offset:7168                       ; d9d81c00 42000040
	ds_load_b64 v[36:37], v64 offset:11264                      ; d9d82c00 24000040
	ds_load_b64 v[38:39], v64 offset:15360                      ; d9d83c00 26000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[60:61], v[168:175] ; cc4640a8 1ea27944
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[60:61], v[42:49] ; cc46402a 1caa7946
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:6144 ; c405c07c 40804844 00180036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[38:39], v[104:111] ; cc464068 1da24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[22:23], v[112:119] ; cc464070 1dc22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[66:67], v[120:127] ; cc464078 1de28546
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[36:37], v[128:135] ; cc464080 1e024946
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[38:39], v[136:143] ; cc464088 1e224d46
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[36:37], v[96:103] ; cc464060 1d824944
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[22:23], v[80:87] ; cc464050 1d422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[66:67], v[88:95] ; cc464058 1d628544
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:6144 ; c405c07c 40804844 00180018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[66:67], v[184:191] ; cc4640b8 1ee28546
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[36:37], v[160:167] ; cc4640a0 1e824944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[36:37], v[14:21] ; cc46400e 1c3a4946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[22:23], v[144:151] ; cc464090 1e422d44
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[22:23], v[176:183] ; cc4640b0 1ec22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[66:67], v[152:159] ; cc464098 1e628544
	ds_load_b64 v[60:61], v64 offset:3328                       ; d9d80d00 3c000040
	ds_load_b64 v[22:23], v64 offset:7424                       ; d9d81d00 16000040
	ds_load_b64 v[66:67], v64 offset:11520                      ; d9d82d00 42000040
	ds_load_b64 v[36:37], v64 offset:15616                      ; d9d83d00 24000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[38:39], v[168:175] ; cc4640a8 1ea24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[38:39], v[42:49] ; cc46402a 1caa4d46
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:6656 ; c405c07c 40804844 001a0036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[36:37], v[104:111] ; cc464068 1da24944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[60:61], v[112:119] ; cc464070 1dc27946
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[22:23], v[120:127] ; cc464078 1de22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[66:67], v[128:135] ; cc464080 1e028546
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[36:37], v[136:143] ; cc464088 1e224946
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[66:67], v[96:103] ; cc464060 1d828544
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[60:61], v[80:87] ; cc464050 1d427944
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[22:23], v[88:95] ; cc464058 1d622d44
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:6656 ; c405c07c 40804844 001a0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[22:23], v[184:191] ; cc4640b8 1ee22d46
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[66:67], v[160:167] ; cc4640a0 1e828544
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[66:67], v[14:21] ; cc46400e 1c3a8546
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[60:61], v[144:151] ; cc464090 1e427944
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[60:61], v[176:183] ; cc4640b0 1ec27946
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[22:23], v[152:159] ; cc464098 1e622d44
	ds_load_b64 v[38:39], v64 offset:3584                       ; d9d80e00 26000040
	ds_load_b64 v[60:61], v64 offset:7680                       ; d9d81e00 3c000040
	ds_load_b64 v[22:23], v64 offset:11776                      ; d9d82e00 16000040
	ds_load_b64 v[66:67], v64 offset:15872                      ; d9d83e00 42000040
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[36:37], v[168:175] ; cc4640a8 1ea24944
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[36:37], v[42:49] ; cc46402a 1caa4946
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:7168 ; c405c07c 40804844 001c0036
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[66:67], v[104:111] ; cc464068 1da28544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[38:39], v[112:119] ; cc464070 1dc24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[60:61], v[120:127] ; cc464078 1de27946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[22:23], v[128:135] ; cc464080 1e022d46
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[66:67], v[136:143] ; cc464088 1e228546
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[22:23], v[96:103] ; cc464060 1d822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[38:39], v[80:87] ; cc464050 1d424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[60:61], v[88:95] ; cc464058 1d627944
	buffer_load_b128 v[68:71], v24, s[36:39], null offen offset:7168 ; c405c07c 40804844 001c0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[60:61], v[184:191] ; cc4640b8 1ee27946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[38:39], v[144:151] ; cc464090 1e424d44
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[38:39], v[176:183] ; cc4640b0 1ec24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[60:61], v[152:159] ; cc464098 1e627944
	ds_load_b64 v[36:37], v64 offset:3840                       ; d9d80f00 24000040
	ds_load_b64 v[38:39], v64 offset:7936                       ; d9d81f00 26000040
	ds_load_b64 v[60:61], v64 offset:12032                      ; d9d82f00 3c000040
	ds_load_b64 v[64:65], v64 offset:16128                      ; d9d83f00 40000040
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[22:23], v[160:167] ; cc4640a0 1e822d44
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[22:23], v[14:21] ; cc46400e 1c3a2d46
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[66:67], v[168:175] ; cc4640a8 1ea28544
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[70:71], v[66:67], v[42:49] ; cc46402a 1caa8546
	v_mov_b32_e32 v66, v25                                      ; 7e840319
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v54, s[36:39], null offen offset:7680 ; c405c07c 40804844 001e0036
	buffer_load_b128 v[22:25], v24, s[36:39], null offen offset:7680 ; c405c07c 40804816 001e0018
	s_lshr_b32 s16, s16, 2                                      ; 85108210
	s_wait_loadcnt_dscnt 0x102                                  ; bfc80102
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[38:39], v[88:95] ; cc464058 1d624d44
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[64:65], v[136:143] ; cc464088 1e228146
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[60:61], v[96:103] ; cc464060 1d827944
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[38:39], v[120:127] ; cc464078 1de24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[64:65], v[104:111] ; cc464068 1da28144
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[60:61], v[128:135] ; cc464080 1e027946
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[36:37], v[112:119] ; cc464070 1dc24946
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[36:37], v[80:87] ; cc464050 1d424944
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_maxmin_num_f32 v67, -4.0, v80, 4.0                        ; d6690043 03daa0f7
	v_maxmin_num_f32 v69, -4.0, v81, 4.0                        ; d6690045 03daa2f7
	v_maxmin_num_f32 v71, -4.0, v82, 4.0                        ; d6690047 03daa4f7
	v_fma_mix_f32 v68, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206244 0bfe86ff 3728ab28
	v_fma_mix_f32 v70, 0xab28, |v69|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe8aff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v70, v70, v69, 0x3f650000 :: v_dual_fmaak_f32 v67, v67, v68, 0x3f650000 ; c8428b46 46428943 3f650000
	v_dual_mul_f32 v81, v81, v70 :: v_dual_mul_f32 v80, v80, v67 ; c8c68d51 51508750
	v_maxmin_num_f32 v67, -4.0, v84, 4.0                        ; d6690043 03daa8f7
	v_maxmin_num_f32 v70, -4.0, v85, 4.0                        ; d6690046 03daaaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v81, -4.0, v83, 4.0                        ; d6690051 03daa6f7
	v_fma_mix_f32 v80, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe8eff 3728ab28
	v_fma_mix_f32 v69, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe86ff 3728ab28
	v_fma_mix_f32 v54, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206236 0bfea2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmaak_f32 v54, v54, v81, 0x3f650000 :: v_dual_fmaak_f32 v71, v71, v80, 0x3f650000 ; c842a336 3646a147 3f650000
	v_maxmin_num_f32 v80, -4.0, v86, 4.0                        ; d6690050 03daacf7
	v_mul_f32_e32 v83, v83, v54                                 ; 10a66d53
	v_dual_fmaak_f32 v67, v67, v69, 0x3f650000 :: v_dual_mul_f32 v82, v82, v71 ; c8468b43 43528f52 3f650000
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v82, -4.0, v87, 4.0                        ; d6690052 03daaef7
	v_fmaak_f32 v71, v71, v70, 0x3f650000                       ; 5a8e8d47 3f650000
	v_maxmin_num_f32 v54, -4.0, v91, 4.0                        ; d6690036 03dab6f7
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_dual_mul_f32 v85, v71, v85 :: v_dual_mul_f32 v84, v84, v67 ; c8c6ab47 55548754
	v_fma_mix_f32 v67, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206243 0bfe6cff 3728ab28
	v_maxmin_num_f32 v71, -4.0, v92, 4.0                        ; d6690047 03dab8f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c842a553 5350a350 3f650000
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v84, -4.0, v88, 4.0                        ; d6690054 03dab0f7
	v_maxmin_num_f32 v81, -4.0, v93, 4.0                        ; d6690051 03dabaf7
	v_dual_mul_f32 v87, v87, v83 :: v_dual_mul_f32 v86, v86, v80 ; c8c6a757 5756a156
	v_fma_mix_f32 v80, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe8eff 3728ab28
	v_maxmin_num_f32 v83, -4.0, v94, 4.0                        ; d6690053 03dabcf7
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v86, -4.0, v89, 4.0                        ; d6690056 03dab2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v71, v71, v80, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 ; c842a147 4752a352 3f650000
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v93, v93, v82 :: v_dual_mul_f32 v92, v92, v71 ; c8c6a55d 5d5c8f5c
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c842ad57 5754ab54 3f650000
	v_maxmin_num_f32 v85, -4.0, v95, 4.0                        ; d6690055 03dabef7
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v89, v89, v87 :: v_dual_mul_f32 v88, v88, v84 ; c8c6af59 5958a958
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v96, 4.0                        ; d6690057 03dac0f7
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v90, 4.0                        ; d6690058 03dab4f7
	v_maxmin_num_f32 v93, -4.0, v99, 4.0                        ; d669005d 03dac6f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842a953 5356ab56 3f650000
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v95, v95, v86 :: v_dual_mul_f32 v94, v94, v83 ; c8c6ad5f 5f5ea75e
	v_dual_fmaak_f32 v67, v67, v54, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c8426d43 4358b358 3f650000
	v_maxmin_num_f32 v89, -4.0, v97, 4.0                        ; d6690059 03dac2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870153
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v100, 4.0                       ; d669005f 03dac8f7
	v_dual_mul_f32 v91, v91, v67 :: v_dual_mul_f32 v90, v90, v88 ; c8c6875b 5b5ab15a
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v98, 4.0                        ; d669005b 03dac4f7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 :: v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 ; c842b35a 5a56b157 3f650000
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842b95b 5b5ebb5e 3f650000
	v_dual_mul_f32 v97, v97, v90 :: v_dual_mul_f32 v96, v96, v87 ; c8c6b561 6160af60
	v_maxmin_num_f32 v67, -4.0, v104, 4.0                       ; d6690043 03dad0f7
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_mul_f32 v99, v99, v94 :: v_dual_mul_f32 v98, v98, v91 ; c8c6bd63 6362b762
	v_maxmin_num_f32 v83, -4.0, v105, 4.0                       ; d6690053 03dad2f7
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v101, 4.0                       ; d6690061 03dacaf7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_fma_mix_f32 v82, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfe86ff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v106, 4.0                       ; d6690055 03dad4f7
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v102, 4.0                       ; d6690063 03daccf7
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v107, 4.0                       ; d6690057 03dad6f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v108, 4.0                       ; d6690059 03dad8f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v109, 4.0                       ; d669005b 03dadaf7
	v_dual_fmaak_f32 v67, v67, v82, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 ; c842a543 4354a754 3f650000
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c842c362 625ec15f 3f650000
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v110, 4.0                       ; d669005d 03dadcf7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_mul_f32 v105, v105, v84 :: v_dual_mul_f32 v104, v104, v67 ; c8c6a969 69688768
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af58 5854ad55 3f650000
	v_dual_mul_f32 v101, v101, v98 :: v_dual_mul_f32 v100, v100, v95 ; c8c6c565 6564bf64
	v_maxmin_num_f32 v95, -4.0, v111, 4.0                       ; d669005f 03dadef7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v112, 4.0                       ; d6690061 03dae0f7
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c842b75c 5c58b559 3f650000
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_mul_f32 v107, v107, v88 :: v_dual_mul_f32 v106, v106, v85 ; c8c6b16b 6b6aab6a
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v101, -4.0, v103, 4.0                      ; d6690065 03dacef7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_mul_f32 v109, v109, v92 :: v_dual_mul_f32 v108, v108, v89 ; c8c6b96d 6d6cb36c
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_fma_mix_f32 v54, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206236 0bfecaff 3728ab28
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v105, -4.0, v116, 4.0                      ; d6690069 03dae8f7
	v_dual_fmaak_f32 v54, v54, v101, 0x3f650000 :: v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 ; c842cb36 3662c963 3f650000
	v_maxmin_num_f32 v101, -4.0, v114, 4.0                      ; d6690065 03dae4f7
	v_maxmin_num_f32 v107, -4.0, v117, 4.0                      ; d669006b 03daeaf7
	v_dual_mul_f32 v111, v111, v96 :: v_dual_mul_f32 v110, v110, v93 ; c8c6c16f 6f6ebb6e
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_mul_f32 v103, v103, v54 :: v_dual_mul_f32 v102, v102, v99 ; c8c66d67 6766c766
	v_maxmin_num_f32 v99, -4.0, v113, 4.0                       ; d6690063 03dae2f7
	v_maxmin_num_f32 v109, -4.0, v118, 4.0                      ; d669006d 03daecf7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v111, -4.0, v119, 4.0                      ; d669006f 03daeef7
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v103, -4.0, v115, 4.0                      ; d6690067 03dae6f7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[22:23], v[36:37], v[144:151] ; cc464090 1e424916
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 :: v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 ; c842d76c 6c68d569 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[22:23], v[38:39], v[152:159] ; cc464098 1e624d16
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[22:23], v[60:61], v[160:167] ; cc4640a0 1e827916
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 :: v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 ; c842c764 6460c561 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[64:65], v[168:175] ; cc4640a8 1ea28116
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[24:25], v[36:37], v[176:183] ; cc4640b0 1ec24918
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[24:25], v[38:39], v[184:191] ; cc4640b8 1ee24d18
	v_dual_mul_f32 v117, v117, v108 :: v_dual_mul_f32 v116, v116, v105 ; c8c6d975 7574d374
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[24:25], v[60:61], v[14:21] ; cc46400e 1c3a7918
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[24:25], v[64:65], v[42:49] ; cc46402a 1caa8118
	v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 :: v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 ; c842cf68 6864cd65 3f650000
	v_dual_mul_f32 v113, v113, v100 :: v_dual_mul_f32 v112, v112, v97 ; c8c6c971 7170c370
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v117, -4.0, v122, 4.0                      ; d6690075 03daf4f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_mul_f32 v115, v115, v104 :: v_dual_mul_f32 v114, v114, v101 ; c8c6d173 7372cb72
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_maxmin_num_f32 v113, -4.0, v120, 4.0                      ; d6690071 03daf0f7
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v115, -4.0, v121, 4.0                      ; d6690073 03daf2f7
	v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 :: v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 ; c842df70 706cdd6d 3f650000
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_dual_mul_f32 v119, v119, v112 :: v_dual_mul_f32 v118, v118, v109 ; c8c6e177 7776db76
	v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 ; c842e571 7174e774 3f650000
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v119, -4.0, v123, 4.0                      ; d6690077 03daf6f7
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_maxmin_num_f32 v24, -4.0, v126, 4.0                       ; d6690018 03dafcf7
	v_maxmin_num_f32 v36, -4.0, v127, 4.0                       ; d6690024 03dafef7
	v_dual_mul_f32 v121, v121, v116 :: v_dual_mul_f32 v120, v120, v113 ; c8c6e979 7978e378
	v_maxmin_num_f32 v38, -4.0, v128, 4.0                       ; d6690026 03db00f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v25, 0xab28, |v24|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe30ff 3728ab28
	v_fma_mix_f32 v37, 0xab28, |v36|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfe48ff 3728ab28
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v121, -4.0, v124, 4.0                      ; d6690079 03daf8f7
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_maxmin_num_f32 v61, -4.0, v130, 4.0                       ; d669003d 03db04f7
	v_fma_mix_f32 v39, 0xab28, |v38|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206227 0bfe4cff 3728ab28
	v_maxmin_num_f32 v54, -4.0, v129, 4.0                       ; d6690036 03db02f7
	v_maxmin_num_f32 v65, -4.0, v131, 4.0                       ; d6690041 03db06f7
	v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842ef78 7874ed75 3f650000
	v_fma_mix_f32 v64, 0xab28, |v61|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206240 0bfe7aff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
	v_fma_mix_f32 v60, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623c 0bfe6cff 3728ab28
	v_fma_mix_f32 v67, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206243 0bfe82ff 3728ab28
	v_maxmin_num_f32 v86, -4.0, v132, 4.0                       ; d6690056 03db08f7
	v_dual_mul_f32 v123, v123, v120 :: v_dual_mul_f32 v122, v122, v117 ; c8c6f17b 7b7aeb7a
	v_dual_fmaak_f32 v67, v67, v65, 0x3f650000 :: v_dual_fmaak_f32 v60, v60, v54, 0x3f650000 ; c8428343 433c6d3c 3f650000
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v133, 4.0                       ; d6690058 03db0af7
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v123, -4.0, v125, 4.0                      ; d669007b 03dafaf7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v90, -4.0, v134, 4.0                       ; d669005a 03db0cf7
	v_dual_fmaak_f32 v86, v86, v87, 0x3f650000 :: v_dual_mul_f32 v129, v129, v60 ; c846af56 56807981 3f650000
	v_maxmin_num_f32 v92, -4.0, v135, 4.0                       ; d669005c 03db0ef7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v23, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206217 0bfef6ff 3728ab28
	v_fmaak_f32 v121, v121, v122, 0x3f650000                    ; 5af2f579 3f650000
	v_maxmin_num_f32 v94, -4.0, v136, 4.0                       ; d669005e 03db10f7
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v96, -4.0, v137, 4.0                       ; d6690060 03db12f7
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_mul_f32 v132, v132, v86 ; c846b159 5984ad84 3f650000
	v_dual_fmaak_f32 v23, v23, v123, 0x3f650000 :: v_dual_mul_f32 v124, v124, v121 ; c846f717 177cf37c 3f650000
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_maxmin_num_f32 v98, -4.0, v138, 4.0                       ; d6690062 03db14f7
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 :: v_dual_mul_f32 v133, v133, v89 ; c846b75a 5a84b385 3f650000
	v_maxmin_num_f32 v100, -4.0, v139, 4.0                      ; d6690064 03db16f7
	v_dual_mul_f32 v125, v125, v23 :: v_dual_fmaak_f32 v24, v24, v25, 0x3f650000 ; c8c22f7d 7d183318 3f650000
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_mul_f32 v134, v134, v90 ; c846b95d 5d86b586 3f650000
	v_maxmin_num_f32 v102, -4.0, v140, 4.0                      ; d6690066 03db18f7
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_dual_fmaak_f32 v37, v36, v37, 0x3f650000 :: v_dual_mul_f32 v126, v126, v24 ; c8464b24 257e317e 3f650000
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v104, -4.0, v141, 4.0                      ; d6690068 03db1af7
	v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 :: v_dual_mul_f32 v135, v135, v93 ; c846bf5e 5e86bb87 3f650000
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_maxmin_num_f32 v106, -4.0, v142, 4.0                      ; d669006a 03db1cf7
	v_dual_fmaak_f32 v38, v38, v39, 0x3f650000 :: v_dual_mul_f32 v127, v127, v37 ; c8464f26 267e4b7f 3f650000
	v_maxmin_num_f32 v108, -4.0, v143, 4.0                      ; d669006c 03db1ef7
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 :: v_dual_mul_f32 v136, v136, v94 ; c846c161 6188bd88 3f650000
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v144, 4.0                      ; d669006e 03db20f7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_fmaak_f32 v61, v61, v64, 0x3f650000 :: v_dual_mul_f32 v128, v128, v38 ; c846813d 3d804d80 3f650000
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v145, 4.0                      ; d6690070 03db22f7
	v_dual_fmaak_f32 v98, v98, v99, 0x3f650000 :: v_dual_mul_f32 v137, v137, v97 ; c846c762 6288c389 3f650000
	v_maxmin_num_f32 v114, -4.0, v146, 4.0                      ; d6690072 03db24f7
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_mul_f32 v131, v131, v67 :: v_dual_mul_f32 v130, v130, v61 ; c8c68783 83827b82
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v116, -4.0, v147, 4.0                      ; d6690074 03db26f7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_dual_fmaak_f32 v101, v101, v100, 0x3f650000 :: v_dual_mul_f32 v138, v138, v98 ; c846c965 658ac58a 3f650000
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v118, -4.0, v148, 4.0                      ; d6690076 03db28f7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v120, -4.0, v149, 4.0                      ; d6690078 03db2af7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 :: v_dual_mul_f32 v139, v139, v101 ; c846cf66 668acb8b 3f650000
	v_maxmin_num_f32 v122, -4.0, v150, 4.0                      ; d669007a 03db2cf7
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_maxmin_num_f32 v124, -4.0, v151, 4.0                      ; d669007c 03db2ef7
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_fmaak_f32 v105, v105, v104, 0x3f650000 :: v_dual_mul_f32 v140, v140, v102 ; c846d169 698ccd8c 3f650000
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_maxmin_num_f32 v126, -4.0, v152, 4.0                      ; d669007e 03db30f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_dual_fmaak_f32 v106, v106, v107, 0x3f650000 :: v_dual_mul_f32 v141, v141, v105 ; c846d76a 6a8cd38d 3f650000
	v_maxmin_num_f32 v128, -4.0, v153, 4.0                      ; d6690080 03db32f7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_mul_f32 v142, v142, v106 ; c846d96d 6d8ed58e 3f650000
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v154, 4.0                      ; d6690082 03db34f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 :: v_dual_mul_f32 v143, v143, v109 ; c846df6e 6e8edb8f 3f650000
	v_maxmin_num_f32 v132, -4.0, v155, 4.0                      ; d6690084 03db36f7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_mul_f32 v144, v144, v110 ; c846e171 7190dd90 3f650000
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v134, -4.0, v156, 4.0                      ; d6690086 03db38f7
	v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 :: v_dual_mul_f32 v145, v145, v113 ; c846e772 7290e391 3f650000
	v_maxmin_num_f32 v136, -4.0, v157, 4.0                      ; d6690088 03db3af7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v117, v117, v116, 0x3f650000 :: v_dual_mul_f32 v146, v146, v114 ; c846e975 7592e592 3f650000
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v138, -4.0, v158, 4.0                      ; d669008a 03db3cf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 :: v_dual_mul_f32 v147, v147, v117 ; c846ef76 7692eb93 3f650000
	v_maxmin_num_f32 v140, -4.0, v159, 4.0                      ; d669008c 03db3ef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_mul_f32 v148, v148, v118 ; c846f179 7994ed94 3f650000
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v160, 4.0                      ; d669008e 03db40f7
	v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 :: v_dual_mul_f32 v149, v149, v121 ; c846f77a 7a94f395 3f650000
	v_maxmin_num_f32 v144, -4.0, v161, 4.0                      ; d6690090 03db42f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 :: v_dual_mul_f32 v150, v150, v122 ; c846f97d 7d96f596 3f650000
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v162, 4.0                      ; d6690092 03db44f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v126, v126, v127, 0x3f650000 :: v_dual_mul_f32 v151, v151, v125 ; c846ff7e 7e96fb97 3f650000
	v_maxmin_num_f32 v148, -4.0, v163, 4.0                      ; d6690094 03db46f7
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_mul_f32 v152, v152, v126 ; c8470181 8198fd98 3f650000
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v164, 4.0                      ; d6690096 03db48f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 :: v_dual_mul_f32 v153, v153, v129 ; c8470782 82990399 3f650000
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v152, -4.0, v165, 4.0                      ; d6690098 03db4af7
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_mul_f32 v154, v154, v130 ; c8470985 859b059a 3f650000
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 :: v_dual_mul_f32 v155, v155, v133 ; c8470f86 869b0b9b 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v154, -4.0, v166, 4.0                      ; d669009a 03db4cf7
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_mul_f32 v156, v156, v134 ; c8471189 899d0d9c 3f650000
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_mul_f32 v157, v157, v137 ; c847178a 8a9d139d 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_lshl_add_u32 v156, v1, 10, s16                            ; d646009c 00411501
	v_add_lshl_u32 v156, v156, v66, 2                           ; d647009c 020a859c
	buffer_load_b128 v[88:91], v156, s[36:39], null offen       ; c405c07c 40804858 0000009c
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_mul_f32 v158, v158, v138 ; c847198d 8d9f159e 3f650000
	v_maxmin_num_f32 v157, -4.0, v167, 4.0                      ; d669009d 03db4ef7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 :: v_dual_mul_f32 v159, v159, v141 ; c8471f8e 8e9f1b9f 3f650000
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_maxmin_num_f32 v159, -4.0, v168, 4.0                      ; d669009f 03db50f7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	buffer_load_b128 v[92:95], v156, s[36:39], null offen offset:512 ; c405c07c 4080485c 0002009c
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v160, v160, v142 ; c8472191 91a11da0 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_mul_f32 v161, v161, v145 ; c8472792 92a123a1 3f650000
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_maxmin_num_f32 v161, -4.0, v169, 4.0                      ; d66900a1 03db52f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v162, v162, v146 ; c8472995 95a325a2 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 :: v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 ; c8433b9e 9e9f419f 3f650000
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_mul_f32 v163, v163, v149 ; c8472f96 96a32ba3 3f650000
	v_dual_mul_f32 v168, v168, v159 :: v_dual_mul_f32 v167, v167, v158 ; c8c73fa8 a8a73da7
	buffer_load_b128 v[96:99], v156, s[36:39], null offen offset:1024 ; c405c07c 40804860 0004009c
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v164, v164, v150 ; c8473199 99a52da4 3f650000
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_maxmin_num_f32 v163, -4.0, v170, 4.0                      ; d66900a3 03db54f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_mul_f32 v165, v165, v153 ; c847379a 9aa533a5 3f650000
	v_mul_f32_e32 v166, v166, v154                              ; 114d35a6
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_maxmin_num_f32 v165, -4.0, v171, 4.0                      ; d66900a5 03db56f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	buffer_load_b128 v[100:103], v156, s[36:39], null offen offset:1536 ; c405c07c 40804864 0006009c
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_maxmin_num_f32 v167, -4.0, v172, 4.0                      ; d66900a7 03db58f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c84349a3 a3a343a2 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmaak_f32 v166, v166, v165, 0x3f650000                    ; 5b4d4ba6 3f650000
	v_dual_mul_f32 v170, v170, v163 :: v_dual_mul_f32 v169, v169, v162 ; c8c747aa aaa945a9
	v_mul_f32_e32 v171, v171, v166                              ; 11574dab
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	buffer_load_b128 v[104:107], v156, s[36:39], null offen offset:2048 ; c405c07c 40804868 0008009c
	v_maxmin_num_f32 v169, -4.0, v173, 4.0                      ; d66900a9 03db5af7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_maxmin_num_f32 v67, -4.0, v176, 4.0                       ; d6690043 03db60f7
	v_maxmin_num_f32 v109, -4.0, v177, 4.0                      ; d669006d 03db62f7
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_maxmin_num_f32 v171, -4.0, v174, 4.0                      ; d66900ab 03db5cf7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_maxmin_num_f32 v111, -4.0, v178, 4.0                      ; d669006f 03db64f7
	v_fma_mix_f32 v108, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfe86ff 3728ab28
	buffer_load_b128 v[116:119], v156, s[36:39], null offen offset:2560 ; c405c07c 40804874 000a009c
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_maxmin_num_f32 v113, -4.0, v179, 4.0                      ; d6690071 03db66f7
	v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 :: v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 ; c84353aa aaa751a7 3f650000
	v_maxmin_num_f32 v115, -4.0, v180, 4.0                      ; d6690073 03db68f7
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 :: v_dual_fmaak_f32 v67, v67, v108, 0x3f650000 ; c842db6e 6e42d943 3f650000
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_dual_mul_f32 v173, v173, v170 :: v_dual_mul_f32 v172, v172, v167 ; c8c755ad adad4fac
	v_fma_mix_f32 v120, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfee6ff 3728ab28
	v_fmaak_f32 v111, v111, v112, 0x3f650000                    ; 5adee16f 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v115, v115, v120, 0x3f650000 :: v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 ; c842f173 7372e372 3f650000
	v_dual_mul_f32 v180, v180, v115 :: v_dual_mul_f32 v179, v179, v114 ; c8c6e7b4 b4b2e5b3
	buffer_load_b128 v[112:115], v156, s[36:39], null offen offset:3072 ; c405c07c 40804870 000c009c
	v_maxmin_num_f32 v121, -4.0, v181, 4.0                      ; d6690079 03db6af7
	v_dual_mul_f32 v177, v177, v110 :: v_dual_mul_f32 v176, v176, v67 ; c8c6ddb1 b1b087b0
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_maxmin_num_f32 v173, -4.0, v175, 4.0                      ; d66900ad 03db5ef7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v182, 4.0                      ; d669007b 03db6cf7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f97b 7b7af37a 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v182, v182, v123 :: v_dual_mul_f32 v181, v181, v122 ; c8c6f7b6 b6b4f5b5
	buffer_load_b128 v[120:123], v156, s[36:39], null offen offset:3584 ; c405c07c 40804878 000e009c
	v_mul_f32_e32 v178, v178, v111                              ; 1164dfb2
	v_maxmin_num_f32 v125, -4.0, v183, 4.0                      ; d669007d 03db6ef7
	v_maxmin_num_f32 v127, -4.0, v184, 4.0                      ; d669007f 03db70f7
(invalid instruction)                                        ; d769006c
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_fma_mix_f32 v54, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206236 0bff5aff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v185, 4.0                      ; d6690081 03db72f7
	v_maxmin_num_f32 v131, -4.0, v186, 4.0                      ; d6690083 03db74f7
(invalid instruction)                                        ; d769006d
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_maxmin_num_f32 v133, -4.0, v187, 4.0                      ; d6690085 03db76f7
(invalid instruction)                                        ; d769406c
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v188, 4.0                      ; d6690087 03db78f7
	v_dual_fmaak_f32 v54, v54, v173, 0x3f650000 :: v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 ; c8435b36 36ab59ab 3f650000
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_maxmin_num_f32 v137, -4.0, v189, 4.0                      ; d6690089 03db7af7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v190, 4.0                      ; d669008b 03db7cf7
	v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c843017f 7f7efb7e 3f650000
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_dual_mul_f32 v175, v175, v54 :: v_dual_mul_f32 v174, v174, v171 ; c8c66daf afaf57ae
	v_maxmin_num_f32 v141, -4.0, v191, 4.0                      ; d669008d 03db7ef7
	v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 ; c8430382 82830983 3f650000
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_maxmin_num_f32 v143, -4.0, v14, 4.0                       ; d669008f 03da1cf7
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_mul_f32_e32 v184, v184, v127                              ; 1170ffb8
	v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 :: v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 ; c8430b86 86871187 3f650000
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_maxmin_num_f32 v145, -4.0, v15, 4.0                       ; d6690091 03da1ef7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_dual_mul_f32 v186, v186, v131 :: v_dual_mul_f32 v183, v183, v126 ; c8c707ba bab6fdb7
	v_maxmin_num_f32 v147, -4.0, v16, 4.0                       ; d6690093 03da20f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 :: v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 ; c843138a 8a8b198b 3f650000
	v_maxmin_num_f32 v149, -4.0, v17, 4.0                       ; d6690095 03da22f7
	v_dual_mul_f32 v188, v188, v135 :: v_dual_mul_f32 v185, v185, v130 ; c8c70fbc bcb905b9
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_maxmin_num_f32 v151, -4.0, v18, 4.0                       ; d6690097 03da24f7
(invalid instruction)                                        ; d769406d
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 :: v_dual_fmaak_f32 v143, v143, v144, 0x3f650000 ; c8431b8e 8e8f218f 3f650000
	v_dual_mul_f32 v190, v190, v139 :: v_dual_mul_f32 v187, v187, v134 ; c8c717be bebb0dbb
	v_maxmin_num_f32 v153, -4.0, v19, 4.0                       ; d6690099 03da26f7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
(invalid instruction)                                        ; d769006e
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_maxmin_num_f32 v155, -4.0, v20, 4.0                       ; d669009b 03da28f7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_lshrrev_b32_e32 v159, 4, v59                              ; 333e7684
	v_dual_fmaak_f32 v146, v146, v145, 0x3f650000 :: v_dual_fmaak_f32 v147, v147, v148, 0x3f650000 ; c8432392 92932993 3f650000
	v_dual_mul_f32 v14, v14, v143 :: v_dual_mul_f32 v189, v189, v138 ; c8c71f0e 0ebd15bd
(invalid instruction)                                        ; d769406e
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v21, 4.0                       ; d669009d 03da2af7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_fmaak_f32 v150, v150, v149, 0x3f650000 :: v_dual_fmaak_f32 v151, v151, v152, 0x3f650000 ; c8432b96 96973197 3f650000
	v_dual_mul_f32 v16, v16, v147 :: v_dual_mul_f32 v191, v191, v142 ; c8c72710 10bf1dbf
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 :: v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 ; c843339a 9a9b399b 3f650000
	v_dual_mul_f32 v18, v18, v151 :: v_dual_mul_f32 v15, v15, v146 ; c8c72f12 120f250f
	v_dual_mul_f32 v17, v17, v150 :: v_dual_and_b32 v158, 0xffffffe0, v0 ; c8e52d11 119e00ff ffffffe0
	v_maxmin_num_f32 v162, -4.0, v42, 4.0                       ; d66900a2 03da54f7
	v_dual_mul_f32 v20, v155, v20 :: v_dual_lshlrev_b32 v159, 3, v159 ; c8e2299b 149f3e83
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_add3_u32 v160, v159, s9, v158                             ; d65500a0 0678139f
	v_dual_mul_f32 v19, v19, v154 :: v_dual_lshlrev_b32 v160, 2, v160 ; c8e33513 13a14082
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v160, s[32:35], null offen       ; c405c07c 40804010 000000a0
	buffer_load_b128 v[124:127], v160, s[32:35], null offen offset:16 ; c405c07c 4080407c 000010a0
(invalid instruction)                                        ; d769006f
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_fma_mix_f32 v161, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff3aff 3728ab28
(invalid instruction)                                        ; d769406f
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v164, -4.0, v43, 4.0                       ; d66900a4 03da56f7
	v_maxmin_num_f32 v166, -4.0, v44, 4.0                       ; d66900a6 03da58f7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v45, 4.0                       ; d66900a8 03da5af7
	v_maxmin_num_f32 v170, -4.0, v46, 4.0                       ; d66900aa 03da5cf7
	v_maxmin_num_f32 v172, -4.0, v47, 4.0                       ; d66900ac 03da5ef7
	v_maxmin_num_f32 v174, -4.0, v48, 4.0                       ; d66900ae 03da60f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v157, 0x3f650000 ; c84347a2 a2a13ba1 3f650000
	v_maxmin_num_f32 v176, -4.0, v49, 4.0                       ; d66900b0 03da62f7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fmaak_f32 v165, v165, v164, 0x3f650000                    ; 5b4b49a5 3f650000
	v_dual_mul_f32 v42, v42, v162 :: v_dual_mul_f32 v21, v21, v161 ; c8c7452a 2a154315
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_mul_f32 v43, v43, v165 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c8c34b2b 2ba74fa6 3f650000
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_mul_f32 v44, v44, v166 ; c84751a9 a92d4d2c 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v45, v45, v169 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8c3532d 2dab57aa 3f650000
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v46, v46, v170 ; c84759ad ad2f552e 3f650000
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 :: v_dual_mul_f32 v47, v47, v173 ; c8475fae ae2f5b2f 3f650000
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_mul_f32 v48, v48, v174 ; c84761b1 b1315d30 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mov_b32 v42, v160 :: v_dual_mul_f32 v49, v49, v177   ; ca0601a0 2a316331
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[90:91], v[50:51], 0 ; cc4640b0 1a02655a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[88:89], v[40:41], 0 ; cc4640a8 1a025158
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[90:91], v[72:73], 0 ; cc4640b8 1a02915a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[90:91], v[40:41], 0 ; cc4640a0 1a02515a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[88:89], v[50:51], 0 ; cc464080 1a026558
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[90:91], v[74:75], 0 ; cc46402c 1a02955a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[88:89], v[74:75], 0 ; cc464090 1a029558
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[88:89], v[72:73], 0 ; cc464088 1a029158
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[94:95], v[52:53], v[176:183] ; cc4640b0 1ec2695e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[94:95], v[56:57], v[184:191] ; cc4640b8 1ee2715e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[52:53], v[128:135] ; cc464080 1e02695c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[92:93], v[56:57], v[136:143] ; cc464088 1e22715c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[98:99], v[8:9], v[176:183] ; cc4640b0 1ec21162
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[10:11], v[184:191] ; cc4640b8 1ee21562
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[96:97], v[8:9], v[128:135] ; cc464080 1e021160
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[92:93], v[6:7], v[168:175] ; cc4640a8 1ea20d5c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[94:95], v[6:7], v[160:167] ; cc4640a0 1e820d5e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[96:97], v[10:11], v[136:143] ; cc464088 1e221560
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[102:103], v[30:31], v[176:183] ; cc4640b0 1ec23d66
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[100:101], v[30:31], v[128:135] ; cc464080 1e023d64
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[96:97], v[28:29], v[168:175] ; cc4640a8 1ea23960
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[98:99], v[28:29], v[160:167] ; cc4640a0 1e823962
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v42, s[32:35], null offen offset:64 ; c405c07c 40804008 0000402a
	buffer_load_b128 v[28:31], v42, s[32:35], null offen offset:80 ; c405c07c 4080401c 0000502a
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[94:95], v[62:63], v[44:51] ; cc46402c 1cb27d5e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[92:93], v[62:63], v[144:151] ; cc464090 1e427d5c
	v_lshlrev_b32_e32 v43, 11, v1                               ; 3056028b
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[100:101], v[32:33], v[136:143] ; cc464088 1e224164
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[102:103], v[32:33], v[184:191] ; cc4640b8 1ee24166
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[104:105], v[68:69], v[128:135] ; cc464080 1e028968
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[100:101], v[26:27], v[168:175] ; cc4640a8 1ea23564
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[102:103], v[26:27], v[160:167] ; cc4640a0 1e823566
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[106:107], v[68:69], v[176:183] ; cc4640b0 1ec2896a
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[98:99], v[12:13], v[44:51] ; cc46402c 1cb21962
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v52, v66, s5, v43                                ; d6550034 04ac0b42
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[12:13], v[144:151] ; cc464090 1e421960
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[104:105], v[70:71], v[136:143] ; cc464088 1e228d68
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[106:107], v[70:71], v[184:191] ; cc4640b8 1ee28d6a
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[116:117], v[84:85], v[128:135] ; cc464080 1e02a974
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[104:105], v[82:83], v[168:175] ; cc4640a8 1ea2a568
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[106:107], v[82:83], v[160:167] ; cc4640a0 1e82a56a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[118:119], v[84:85], v[176:183] ; cc4640b0 1ec2a976
	v_lshlrev_b32_e32 v52, 2, v52                               ; 30686882
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[102:103], v[34:35], v[44:51] ; cc46402c 1cb24566
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[34:35], v[144:151] ; cc464090 1e424564
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[116:117], v[22:23], v[136:143] ; cc464088 1e222d74
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[22:23], v[184:191] ; cc4640b8 1ee22d76
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[112:113], v[38:39], v[128:135] ; cc464080 1e024d70
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[116:117], v[36:37], v[168:175] ; cc4640a8 1ea24974
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[118:119], v[36:37], v[160:167] ; cc4640a0 1e824976
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[38:39], v[176:183] ; cc4640b0 1ec24d72
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[106:107], v[80:81], v[44:51] ; cc46402c 1cb2a16a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[104:105], v[80:81], v[144:151] ; cc464090 1e42a168
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[60:61], v[136:143] ; cc464088 1e227970
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[60:61], v[184:191] ; cc4640b8 1ee27972
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[120:121], v[108:109], v[128:135] ; cc464080 1e02d978
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[112:113], v[86:87], v[168:175] ; cc4640a8 1ea2ad70
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[114:115], v[86:87], v[160:167] ; cc4640a0 1e82ad72
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[122:123], v[108:109], v[176:183] ; cc4640b0 1ec2d97a
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[118:119], v[24:25], v[44:51] ; cc46402c 1cb23176
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[116:117], v[24:25], v[144:151] ; cc464090 1e423174
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[120:121], v[110:111], v[136:143] ; cc464088 1e22dd78
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[122:123], v[110:111], v[184:191] ; cc4640b8 1ee2dd7a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[120:121], v[20:21], v[168:175] ; cc4640a8 1ea22978
	buffer_load_b128 v[24:27], v52, s[36:39], null offen        ; c405c07c 40804818 00000034
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[122:123], v[20:21], v[160:167] ; cc4640a0 1e82297a
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[114:115], v[64:65], v[44:51] ; cc46402c 1cb28172
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[112:113], v[64:65], v[144:151] ; cc464090 1e428170
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_add_nc_u32_e32 v53, 0x4000, v76                           ; 4a6a98ff 00004000
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[122:123], v[14:15], v[44:51] ; cc46402c 1cb21d7a
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[120:121], v[14:15], v[144:151] ; cc464090 1e421d78
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	ds_store_2addr_b64 v53, v[6:7], v[22:23] offset1:32         ; d9382000 00160635
	buffer_load_b128 v[44:47], v52, s[36:39], null offen offset:512 ; c405c07c 4080482c 00020034
	v_add_nc_u32_e32 v54, 0x5000, v76                           ; 4a6c98ff 00005000
	v_add_nc_u32_e32 v56, 0x6000, v76                           ; 4a7098ff 00006000
	v_add_nc_u32_e32 v57, 0x7000, v76                           ; 4a7298ff 00007000
	ds_store_2addr_b64 v54, v[12:13], v[32:33] offset1:32       ; d9382000 00200c36
	ds_store_2addr_b64 v56, v[14:15], v[34:35] offset1:32       ; d9382000 00220e38
	ds_store_2addr_b64 v57, v[20:21], v[36:37] offset1:32       ; d9382000 00241439
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	buffer_load_b128 v[12:15], v52, s[36:39], null offen offset:1024 ; c405c07c 4080480c 00040034
	v_mad_u32_u24 v60, s59, 0x500, v2                           ; d60b003c 0409fe3b 00000500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v60, v60, v55                              ; 4a786f3c
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[6:7], v60                                     ; d9d80000 0600003c
	ds_load_b64 v[20:21], v60 offset:4096                       ; d9d81000 1400003c
	ds_load_b64 v[22:23], v60 offset:8192                       ; d9d82000 1600003c
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[32:33], v6                           ; 7e40dd06
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v81, v33, v17 :: v_dual_mul_f32 v80, v32, v16 ; c8c62321 51502120
	v_cvt_pk_f32_fp8_e32 v[32:33], v134                         ; 7e40dd86
	v_dual_mul_f32 v83, v33, v19 :: v_dual_mul_f32 v82, v32, v18 ; c8c62721 53522520
	buffer_load_b128 v[32:35], v52, s[36:39], null offen offset:1536 ; c405c07c 40804820 00060034
	v_cvt_pk_f32_fp8_e32 v[36:37], v7                           ; 7e48dd07
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v85, v37, v125 :: v_dual_mul_f32 v84, v36, v124 ; c8c6fb25 5554f924
	ds_load_b64 v[36:37], v60 offset:12288                      ; d9d83000 2400003c
	buffer_load_b128 v[48:51], v52, s[36:39], null offen offset:2048 ; c405c07c 40804830 00080034
	ds_load_b64 v[38:39], v60 offset:256                        ; d9d80100 2600003c
	buffer_load_b128 v[68:71], v52, s[36:39], null offen offset:2560 ; c405c07c 40804844 000a0034
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v87, v7, v127 :: v_dual_mul_f32 v86, v6, v126 ; c8c6ff07 5756fd06
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[6:7], v20                            ; 7e0cdd14
	v_dual_mul_f32 v89, v7, v17 :: v_dual_mul_f32 v88, v6, v16  ; c8c62307 59582106
	v_cvt_pk_f32_fp8_e32 v[6:7], v148                           ; 7e0cdd94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v91, v7, v19 :: v_dual_mul_f32 v90, v6, v18  ; c8c62707 5b5a2506
	v_cvt_pk_f32_fp8_e32 v[6:7], v21                            ; 7e0cdd15
	v_cvt_pk_f32_fp8_e32 v[20:21], v149                         ; 7e28dd95
	v_dual_mul_f32 v93, v7, v125 :: v_dual_mul_f32 v92, v6, v124 ; c8c6fb07 5d5cf906
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v22                            ; 7e0cdd16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v97, v7, v17 :: v_dual_mul_f32 v96, v6, v16  ; c8c62307 61602106
	v_cvt_pk_f32_fp8_e32 v[6:7], v150                           ; 7e0cdd96
	v_dual_mul_f32 v99, v7, v19 :: v_dual_mul_f32 v98, v6, v18  ; c8c62707 63622506
	v_cvt_pk_f32_fp8_e32 v[6:7], v23                            ; 7e0cdd17
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v101, v7, v125 :: v_dual_mul_f32 v94, v20, v126 ; c8c6fb07 655efd14
	v_dual_mul_f32 v95, v21, v127 :: v_dual_mul_f32 v100, v6, v124 ; c8c6ff15 5f64f906
	v_cvt_pk_f32_fp8_e32 v[6:7], v151                           ; 7e0cdd97
	buffer_load_b128 v[20:23], v52, s[36:39], null offen offset:3072 ; c405c07c 40804814 000c0034
	ds_load_b64 v[40:41], v60 offset:4352                       ; d9d81100 2800003c
	v_dual_mul_f32 v103, v7, v127 :: v_dual_mul_f32 v102, v6, v126 ; c8c6ff07 6766fd06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v36                            ; 7e0cdd24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v105, v7, v17                                 ; 10d22307
	v_mul_f32_e32 v104, v6, v16                                 ; 10d02106
	v_cvt_pk_f32_fp8_e32 v[6:7], v164                           ; 7e0cdda4
	v_dual_mul_f32 v107, v7, v19 :: v_dual_mul_f32 v106, v6, v18 ; c8c62707 6b6a2506
	buffer_load_b128 v[16:19], v52, s[36:39], null offen offset:3584 ; c405c07c 40804810 000e0034
	v_cvt_pk_f32_fp8_e32 v[6:7], v37                            ; 7e0cdd25
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v109, v7, v125 :: v_dual_mul_f32 v108, v6, v124 ; c8c6fb07 6d6cf906
	v_cvt_pk_f32_fp8_e32 v[6:7], v165                           ; 7e0cdda5
	ds_load_b64 v[36:37], v60 offset:8448                       ; d9d82100 2400003c
	buffer_load_b128 v[72:75], v52, s[36:39], null offen offset:4096 ; c405c07c 40804848 00100034
	v_dual_mul_f32 v111, v7, v127 :: v_dual_mul_f32 v110, v6, v126 ; c8c6ff07 6f6efd06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v38                            ; 7e0cdd26
	s_wait_loadcnt 0xa                                          ; bfc0000a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v7, v9 :: v_dual_mul_f32 v112, v6, v8  ; c8c61307 71701106
	v_cvt_pk_f32_fp8_e32 v[6:7], v166                           ; 7e0cdda6
	v_dual_mul_f32 v115, v7, v11 :: v_dual_mul_f32 v114, v6, v10 ; c8c61707 73721506
	v_cvt_pk_f32_fp8_e32 v[6:7], v39                            ; 7e0cdd27
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v117, v7, v29 :: v_dual_mul_f32 v116, v6, v28 ; c8c63b07 75743906
	v_cvt_pk_f32_fp8_e32 v[6:7], v167                           ; 7e0cdda7
	ds_load_b64 v[38:39], v60 offset:12544                      ; d9d83100 2600003c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[124:127], v52, s[36:39], null offen offset:4608 ; c405c07c 4080487c 00120034
	buffer_load_b128 v[128:131], v52, s[36:39], null offen offset:5120 ; c405c07c 40804880 00140034
	v_dual_mul_f32 v119, v7, v31 :: v_dual_mul_f32 v118, v6, v30 ; c8c63f07 77763d06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v40                            ; 7e0cdd28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
	v_dual_mul_f32 v121, v7, v9 :: v_dual_mul_f32 v120, v6, v8  ; c8c61307 79781106
	v_cvt_pk_f32_fp8_e32 v[6:7], v168                           ; 7e0cdda8
	buffer_load_b128 v[144:147], v52, s[36:39], null offen offset:5632 ; c405c07c 40804890 00160034
	v_dual_mul_f32 v123, v7, v11 :: v_dual_mul_f32 v122, v6, v10 ; c8c61707 7b7a1506
	v_cvt_pk_f32_fp8_e32 v[6:7], v41                            ; 7e0cdd29
	v_dual_mul_f32 v133, v7, v29 :: v_dual_mul_f32 v132, v6, v28 ; c8c63b07 85843906
	v_cvt_pk_f32_fp8_e32 v[6:7], v169                           ; 7e0cdda9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
	v_dual_mul_f32 v135, v7, v31 :: v_dual_mul_f32 v134, v6, v30 ; c8c63f07 87863d06
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[6:7], v36                            ; 7e0cdd24
	v_lshl_add_u32 v61, s59, 10, v55                            ; d646003d 04dd143b
	v_dual_mul_f32 v137, v7, v9 :: v_dual_mul_f32 v136, v6, v8  ; c8c61307 89881106
	v_cvt_pk_f32_fp8_e32 v[6:7], v164                           ; 7e0cdda4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v139, v7, v11 :: v_dual_mul_f32 v138, v6, v10 ; c8c61707 8b8a1506
	v_cvt_pk_f32_fp8_e32 v[6:7], v37                            ; 7e0cdd25
	v_dual_mul_f32 v141, v7, v29 :: v_dual_mul_f32 v140, v6, v28 ; c8c63b07 8d8c3906
	v_cvt_pk_f32_fp8_e32 v[6:7], v165                           ; 7e0cdda5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v143, v7, v31 :: v_dual_mul_f32 v142, v6, v30 ; c8c63f07 8f8e3d06
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[6:7], v38                            ; 7e0cdd26
	v_dual_mul_f32 v161, v7, v9 :: v_dual_mul_f32 v160, v6, v8  ; c8c61307 a1a01106
	v_cvt_pk_f32_fp8_e32 v[6:7], v166                           ; 7e0cdda6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v163, v7, v11 :: v_dual_mul_f32 v162, v6, v10 ; c8c61707 a3a21506
	buffer_load_b128 v[8:11], v52, s[36:39], null offen offset:6144 ; c405c07c 40804808 00180034
	v_cvt_pk_f32_fp8_e32 v[6:7], v39                            ; 7e0cdd27
	v_dual_mul_f32 v165, v7, v29 :: v_dual_mul_f32 v164, v6, v28 ; c8c63b07 a5a43906
	v_cvt_pk_f32_fp8_e32 v[6:7], v167                           ; 7e0cdda7
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v167, v7, v31 :: v_dual_mul_f32 v166, v6, v30 ; c8c63f07 a7a63d06
	ds_load_b64 v[6:7], v61 offset:16384                        ; d9d84000 0600003d
	ds_load_b64 v[28:29], v61 offset:20480                      ; d9d85000 1c00003d
	ds_load_b64 v[30:31], v61 offset:24576                      ; d9d86000 1e00003d
	ds_load_b64 v[36:37], v61 offset:28672                      ; d9d87000 2400003d
	ds_load_b64 v[38:39], v61 offset:16640                      ; d9d84100 2600003d
	ds_load_b64 v[40:41], v61 offset:20736                      ; d9d85100 2800003d
	ds_load_b64 v[62:63], v61 offset:24832                      ; d9d86100 3e00003d
	ds_load_b64 v[64:65], v61 offset:28928                      ; d9d87100 4000003d
	ds_load_b64 v[148:149], v61 offset:16896                    ; d9d84200 9400003d
	ds_load_b64 v[150:151], v61 offset:20992                    ; d9d85200 9600003d
	ds_load_b64 v[152:153], v61 offset:25088                    ; d9d86200 9800003d
	ds_load_b64 v[154:155], v61 offset:29184                    ; d9d87200 9a00003d
	buffer_load_b128 v[168:171], v52, s[36:39], null offen offset:6656 ; c405c07c 408048a8 001a0034
	ds_load_b64 v[156:157], v61 offset:17152                    ; d9d84300 9c00003d
	ds_load_b64 v[172:173], v61 offset:21248                    ; d9d85300 ac00003d
	ds_load_b64 v[174:175], v61 offset:25344                    ; d9d86300 ae00003d
	ds_load_b64 v[176:177], v61 offset:29440                    ; d9d87300 b000003d
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mov_b32 v181, v125 :: v_dual_mov_b32 v180, v124      ; ca10017d b5b4017c
	v_dual_mov_b32 v125, v133 :: v_dual_mov_b32 v124, v132      ; ca100185 7d7c0184
	v_dual_mov_b32 v183, v127 :: v_dual_mov_b32 v182, v126      ; ca10017f b7b6017e
	v_dual_mov_b32 v127, v135 :: v_dual_mov_b32 v126, v134      ; ca100187 7f7e0186
	buffer_load_b128 v[132:135], v52, s[36:39], null offen offset:7168 ; c405c07c 40804884 001c0034
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[6:7], v[112:119] ; cc464070 1dc20d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[6:7], v[80:87] ; cc464050 1d420d18
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[28:29], v[88:95] ; cc464058 1d623918
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[30:31], v[96:103] ; cc464060 1d823d18
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[30:31], v[136:143] ; cc464088 1e223d1a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[36:37], v[104:111] ; cc464068 1da24918
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[26:27], v[36:37], v[160:167] ; cc4640a0 1e82491a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[28:29], v[120:127] ; cc464078 1de2391a
	ds_load_b64 v[6:7], v61 offset:17408                        ; d9d84400 0600003d
	ds_load_b64 v[24:25], v61 offset:21504                      ; d9d85400 1800003d
	ds_load_b64 v[26:27], v61 offset:25600                      ; d9d86400 1a00003d
	ds_load_b64 v[28:29], v61 offset:29696                      ; d9d87400 1c00003d
	buffer_load_b128 v[184:187], v52, s[36:39], null offen offset:7680 ; c405c07c 408048b8 001e0034
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[38:39], v[112:119] ; cc464070 1dc24d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[38:39], v[80:87] ; cc464050 1d424d2c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[40:41], v[88:95] ; cc464058 1d62512c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[40:41], v[120:127] ; cc464078 1de2512e
	ds_load_b64 v[30:31], v61 offset:17664                      ; d9d84500 1e00003d
	ds_load_b64 v[36:37], v61 offset:21760                      ; d9d85500 2400003d
	ds_load_b64 v[38:39], v61 offset:25856                      ; d9d86500 2600003d
	ds_load_b64 v[40:41], v61 offset:29952                      ; d9d87500 2800003d
	s_wait_dscnt 0x11                                           ; bfc60011
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[62:63], v[96:103] ; cc464060 1d827d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[62:63], v[136:143] ; cc464088 1e227d2e
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[64:65], v[104:111] ; cc464068 1da2812c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[46:47], v[64:65], v[160:167] ; cc4640a0 1e82812e
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[148:149], v[112:119] ; cc464070 1dc3290e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[148:149], v[80:87] ; cc464050 1d43290c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[150:151], v[88:95] ; cc464058 1d632d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[150:151], v[120:127] ; cc464078 1de32d0e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[152:153], v[96:103] ; cc464060 1d83310c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[14:15], v[152:153], v[136:143] ; cc464088 1e23310e
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[154:155], v[104:111] ; cc464068 1da3350c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[14:15], v[154:155], v[160:167] ; cc4640a0 1e83350e
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[156:157], v[112:119] ; cc464070 1dc33922
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[156:157], v[80:87] ; cc464050 1d433920
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[172:173], v[88:95] ; cc464058 1d635920
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[172:173], v[120:127] ; cc464078 1de35922
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[174:175], v[96:103] ; cc464060 1d835d20
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[34:35], v[174:175], v[136:143] ; cc464088 1e235d22
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[32:33], v[176:177], v[104:111] ; cc464068 1da36120
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[34:35], v[176:177], v[160:167] ; cc4640a0 1e836122
	ds_load_b64 v[12:13], v61 offset:17920                      ; d9d84600 0c00003d
	ds_load_b64 v[14:15], v61 offset:22016                      ; d9d85600 0e00003d
	ds_load_b64 v[44:45], v61 offset:26112                      ; d9d86600 2c00003d
	ds_load_b64 v[46:47], v61 offset:30208                      ; d9d87600 2e00003d
	ds_load_b64 v[32:33], v61 offset:18176                      ; d9d84700 2000003d
	ds_load_b64 v[34:35], v61 offset:22272                      ; d9d85700 2200003d
	ds_load_b64 v[62:63], v61 offset:26368                      ; d9d86700 3e00003d
	ds_load_b64 v[64:65], v61 offset:30464                      ; d9d87700 4000003d
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[6:7], v[80:87] ; cc464050 1d420d30
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[24:25], v[88:95] ; cc464058 1d623130
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[6:7], v[112:119] ; cc464070 1dc20d32
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[24:25], v[120:127] ; cc464078 1de23132
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[48:49], v[26:27], v[96:103] ; cc464060 1d823530
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[50:51], v[26:27], v[136:143] ; cc464088 1e223532
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[28:29], v[104:111] ; cc464068 1da23930
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[28:29], v[160:167] ; cc4640a0 1e823932
	ds_load_b64 v[6:7], v61 offset:18432                        ; d9d84800 0600003d
	ds_load_b64 v[24:25], v61 offset:22528                      ; d9d85800 1800003d
	ds_load_b64 v[26:27], v61 offset:26624                      ; d9d86800 1a00003d
	ds_load_b64 v[28:29], v61 offset:30720                      ; d9d87800 1c00003d
	v_add_lshl_u32 v67, s23, v1, 2                              ; d6470043 020a0217
	buffer_load_b32 v67, v67, s[32:35], null offen              ; c405007c 40804043 00000043
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[30:31], v[80:87] ; cc464050 1d423d44
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[36:37], v[88:95] ; cc464058 1d624944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[30:31], v[112:119] ; cc464070 1dc23d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[36:37], v[120:127] ; cc464078 1de24946
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[38:39], v[96:103] ; cc464060 1d824d44
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[38:39], v[136:143] ; cc464088 1e224d46
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[40:41], v[104:111] ; cc464068 1da25144
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[70:71], v[40:41], v[160:167] ; cc4640a0 1e825146
	ds_load_b64 v[30:31], v61 offset:18688                      ; d9d84900 1e00003d
	ds_load_b64 v[36:37], v61 offset:22784                      ; d9d85900 2400003d
	ds_load_b64 v[38:39], v61 offset:26880                      ; d9d86900 2600003d
	ds_load_b64 v[40:41], v61 offset:30976                      ; d9d87900 2800003d
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[12:13], v[80:87] ; cc464050 1d421914
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[14:15], v[88:95] ; cc464058 1d621d14
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[12:13], v[112:119] ; cc464070 1dc21916
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[14:15], v[120:127] ; cc464078 1de21d16
	v_mad_u32_u24 v68, 0x1800, v1, s6                           ; d60b0044 001a02ff 00001800
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v68, v68, v66, 2                             ; d6470044 020a8544
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v68, s[36:39], null offen        ; c405c07c 40804830 00000044
	buffer_load_b128 v[12:15], v68, s[36:39], null offen offset:8192 ; c405c07c 4080480c 00200044
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[44:45], v[96:103] ; cc464060 1d825914
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[44:45], v[136:143] ; cc464088 1e225916
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[20:21], v[46:47], v[104:111] ; cc464068 1da25d14
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[22:23], v[46:47], v[160:167] ; cc4640a0 1e825d16
	ds_load_b64 v[20:21], v61 offset:18944                      ; d9d84a00 1400003d
	ds_load_b64 v[22:23], v61 offset:23040                      ; d9d85a00 1600003d
	ds_load_b64 v[44:45], v61 offset:27136                      ; d9d86a00 2c00003d
	ds_load_b64 v[46:47], v61 offset:31232                      ; d9d87a00 2e00003d
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[32:33], v[80:87] ; cc464050 1d424110
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[34:35], v[88:95] ; cc464058 1d624510
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[32:33], v[112:119] ; cc464070 1dc24112
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[34:35], v[120:127] ; cc464078 1de24512
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[62:63], v[96:103] ; cc464060 1d827d10
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[62:63], v[136:143] ; cc464088 1e227d12
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[64:65], v[104:111] ; cc464068 1da28110
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[18:19], v[64:65], v[160:167] ; cc4640a0 1e828112
	buffer_load_b128 v[16:19], v68, s[36:39], null offen offset:512 ; c405c07c 40804810 00020044
	ds_load_b64 v[32:33], v61 offset:19200                      ; d9d84b00 2000003d
	ds_load_b64 v[34:35], v61 offset:23296                      ; d9d85b00 2200003d
	ds_load_b64 v[62:63], v61 offset:27392                      ; d9d86b00 3e00003d
	ds_load_b64 v[64:65], v61 offset:31488                      ; d9d87b00 4000003d
	buffer_load_b128 v[148:151], v68, s[36:39], null offen offset:8704 ; c405c07c 40804894 00220044
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[6:7], v[80:87] ; cc464050 1d420d48
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[24:25], v[88:95] ; cc464058 1d623148
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[6:7], v[112:119] ; cc464070 1dc20d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[24:25], v[120:127] ; cc464078 1de2314a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[26:27], v[96:103] ; cc464060 1d823548
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[26:27], v[136:143] ; cc464088 1e22354a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[28:29], v[104:111] ; cc464068 1da23948
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[74:75], v[28:29], v[160:167] ; cc4640a0 1e82394a
	ds_load_b64 v[6:7], v61 offset:19456                        ; d9d84c00 0600003d
	ds_load_b64 v[24:25], v61 offset:23552                      ; d9d85c00 1800003d
	ds_load_b64 v[26:27], v61 offset:27648                      ; d9d86c00 1a00003d
	ds_load_b64 v[28:29], v61 offset:31744                      ; d9d87c00 1c00003d
	buffer_load_b128 v[72:75], v68, s[36:39], null offen offset:1024 ; c405c07c 40804848 00040044
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[180:181], v[30:31], v[80:87] ; cc464050 1d423db4
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[180:181], v[36:37], v[88:95] ; cc464058 1d6249b4
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[182:183], v[30:31], v[112:119] ; cc464070 1dc23db6
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[182:183], v[36:37], v[120:127] ; cc464078 1de249b6
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[180:181], v[38:39], v[96:103] ; cc464060 1d824db4
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[182:183], v[38:39], v[136:143] ; cc464088 1e224db6
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[180:181], v[40:41], v[104:111] ; cc464068 1da251b4
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[182:183], v[40:41], v[160:167] ; cc4640a0 1e8251b6
	ds_load_b64 v[30:31], v61 offset:19712                      ; d9d84d00 1e00003d
	ds_load_b64 v[36:37], v61 offset:23808                      ; d9d85d00 2400003d
	ds_load_b64 v[38:39], v61 offset:27904                      ; d9d86d00 2600003d
	ds_load_b64 v[40:41], v61 offset:32000                      ; d9d87d00 2800003d
	buffer_load_b128 v[152:155], v68, s[36:39], null offen offset:9216 ; c405c07c 40804898 00240044
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[128:129], v[20:21], v[80:87] ; cc464050 1d422980
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[128:129], v[22:23], v[88:95] ; cc464058 1d622d80
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[130:131], v[20:21], v[112:119] ; cc464070 1dc22982
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[130:131], v[22:23], v[120:127] ; cc464078 1de22d82
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[128:129], v[44:45], v[96:103] ; cc464060 1d825980
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[130:131], v[44:45], v[136:143] ; cc464088 1e225982
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[128:129], v[46:47], v[104:111] ; cc464068 1da25d80
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[130:131], v[46:47], v[160:167] ; cc4640a0 1e825d82
	ds_load_b64 v[20:21], v61 offset:19968                      ; d9d84e00 1400003d
	ds_load_b64 v[22:23], v61 offset:24064                      ; d9d85e00 1600003d
	ds_load_b64 v[44:45], v61 offset:28160                      ; d9d86e00 2c00003d
	ds_load_b64 v[46:47], v61 offset:32256                      ; d9d87e00 2e00003d
	buffer_load_b128 v[128:131], v68, s[36:39], null offen offset:1536 ; c405c07c 40804880 00060044
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[144:145], v[32:33], v[80:87] ; cc464050 1d424190
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[144:145], v[34:35], v[88:95] ; cc464058 1d624590
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[146:147], v[32:33], v[112:119] ; cc464070 1dc24192
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[146:147], v[34:35], v[120:127] ; cc464078 1de24592
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[144:145], v[62:63], v[96:103] ; cc464060 1d827d90
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[146:147], v[62:63], v[136:143] ; cc464088 1e227d92
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[144:145], v[64:65], v[104:111] ; cc464068 1da28190
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[146:147], v[64:65], v[160:167] ; cc4640a0 1e828192
	ds_load_b64 v[32:33], v61 offset:20224                      ; d9d84f00 2000003d
	ds_load_b64 v[34:35], v61 offset:24320                      ; d9d85f00 2200003d
	ds_load_b64 v[62:63], v61 offset:28416                      ; d9d86f00 3e00003d
	ds_load_b64 v[64:65], v61 offset:32512                      ; d9d87f00 4000003d
	s_wait_loadcnt_dscnt 0xb0f                                  ; bfc80b0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[6:7], v[80:87] ; cc464050 1d420d08
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[24:25], v[88:95] ; cc464058 1d623108
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[6:7], v[112:119] ; cc464070 1dc20d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[24:25], v[120:127] ; cc464078 1de2310a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[26:27], v[96:103] ; cc464060 1d823508
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[26:27], v[136:143] ; cc464088 1e22350a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[28:29], v[104:111] ; cc464068 1da23908
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[10:11], v[28:29], v[160:167] ; cc4640a0 1e82390a
	s_wait_loadcnt_dscnt 0xa0b                                  ; bfc80a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[168:169], v[30:31], v[80:87] ; cc464050 1d423da8
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[168:169], v[36:37], v[88:95] ; cc464058 1d6249a8
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[30:31], v[112:119] ; cc464070 1dc23daa
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[170:171], v[36:37], v[120:127] ; cc464078 1de249aa
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[168:169], v[38:39], v[96:103] ; cc464060 1d824da8
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[170:171], v[38:39], v[136:143] ; cc464088 1e224daa
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[168:169], v[40:41], v[104:111] ; cc464068 1da251a8
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[170:171], v[40:41], v[160:167] ; cc4640a0 1e8251aa
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[132:133], v[20:21], v[80:87] ; cc464050 1d422984
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[132:133], v[22:23], v[88:95] ; cc464058 1d622d84
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[134:135], v[20:21], v[112:119] ; cc464070 1dc22986
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[134:135], v[22:23], v[120:127] ; cc464078 1de22d86
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[132:133], v[44:45], v[96:103] ; cc464060 1d825984
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[134:135], v[44:45], v[136:143] ; cc464088 1e225986
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[132:133], v[46:47], v[104:111] ; cc464068 1da25d84
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[134:135], v[46:47], v[160:167] ; cc4640a0 1e825d86
	s_wait_loadcnt_dscnt 0x803                                  ; bfc80803
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[184:185], v[32:33], v[80:87] ; cc464050 1d4241b8
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[184:185], v[34:35], v[88:95] ; cc464058 1d6245b8
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[186:187], v[32:33], v[112:119] ; cc464070 1dc241ba
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[186:187], v[34:35], v[120:127] ; cc464078 1de245ba
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[184:185], v[62:63], v[96:103] ; cc464060 1d827db8
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[186:187], v[62:63], v[136:143] ; cc464088 1e227dba
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[184:185], v[64:65], v[104:111] ; cc464068 1da281b8
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[186:187], v[64:65], v[160:167] ; cc4640a0 1e8281ba
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v76, v[6:7], v[22:23] offset1:32         ; d9382000 0016064c
	ds_store_2addr_b64 v77, v[8:9], v[24:25] offset1:32         ; d9382000 0018084d
	ds_store_2addr_b64 v78, v[10:11], v[26:27] offset1:32       ; d9382000 001a0a4e
	ds_store_2addr_b64 v79, v[20:21], v[28:29] offset1:32       ; d9382000 001c144f
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_lshl_add_u32 v69, s59, 11, v55                            ; d6460045 04dd163b
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[6:7], v69                                     ; d9d80000 06000045
	ds_load_b64 v[8:9], v69 offset:4096                         ; d9d81000 08000045
	ds_load_b64 v[10:11], v69 offset:8192                       ; d9d82000 0a000045
	ds_load_b64 v[20:21], v69 offset:12288                      ; d9d83000 14000045
	ds_load_b64 v[22:23], v69 offset:256                        ; d9d80100 16000045
	ds_load_b64 v[24:25], v69 offset:4352                       ; d9d81100 18000045
	ds_load_b64 v[26:27], v69 offset:8448                       ; d9d82100 1a000045
	ds_load_b64 v[28:29], v69 offset:12544                      ; d9d83100 1c000045
	ds_load_b64 v[30:31], v69 offset:512                        ; d9d80200 1e000045
	ds_load_b64 v[40:41], v69 offset:4608                       ; d9d81200 28000045
	ds_load_b64 v[44:45], v69 offset:8704                       ; d9d82200 2c000045
	ds_load_b64 v[46:47], v69 offset:12800                      ; d9d83200 2e000045
	s_wait_loadcnt_dscnt 0x50b                                  ; bfc8050b
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[6:7], 0 ; cc4640a0 1a020d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[50:51], v[6:7], 0 ; cc464068 1a020d32
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[48:49], v[6:7], 0   ; cc464020 1a020d30
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[12:13], v[8:9], 0 ; cc4640a8 1a02110c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[8:9], 0 ; cc464070 1a021132
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[8:9], 0   ; cc464050 1a021130
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[10:11], 0 ; cc464058 1a021530
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[10:11], 0 ; cc4640b0 1a02150c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[10:11], 0 ; cc464078 1a021532
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[50:51], v[20:21], 0 ; cc464088 1a022932
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[48:49], v[20:21], 0 ; cc464060 1a022930
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[12:13], v[20:21], 0 ; cc4640b8 1a02290c
	v_mov_b32_e32 v12, v53                                      ; 7e180335
	v_dual_mov_b32 v42, v55 :: v_dual_mov_b32 v13, v54          ; ca100137 2a0c0136
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[14:15], v[6:7], 0   ; cc464030 1a020d0e
	v_dual_mov_b32 v6, v58 :: v_dual_mov_b32 v7, v59            ; ca10013a 0606013b
	v_dual_mov_b32 v70, v60 :: v_dual_mov_b32 v71, v61          ; ca10013c 4646013d
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mov_b32 v132, v72 :: v_dual_mov_b32 v133, v73        ; ca100148 84840149
	v_dual_mov_b32 v134, v74 :: v_dual_mov_b32 v135, v75        ; ca10014a 8686014b
	v_dual_mov_b32 v144, v4 :: v_dual_mov_b32 v145, v5          ; ca100104 90900105
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[14:15], v[8:9], 0   ; cc46403a 1a02110e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[10:11], 0 ; cc464048 1a02150e
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[22:23], v[32:39] ; cc464020 1c822d10
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[24:25], v[80:87] ; cc464050 1d423110
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[26:27], v[88:95] ; cc464058 1d623510
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[22:23], v[104:111] ; cc464068 1da22d12
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[24:25], v[112:119] ; cc464070 1dc23112
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[28:29], v[96:103] ; cc464060 1d823910
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[26:27], v[120:127] ; cc464078 1de23512
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[28:29], v[136:143] ; cc464088 1e223912
	v_dual_mov_b32 v146, v6 :: v_dual_mov_b32 v147, v7          ; ca100106 92920107
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[14:15], v[20:21], 0  ; cc464004 1a02290e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[148:149], v[22:23], v[160:167] ; cc4640a0 1e822d94
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[148:149], v[24:25], v[168:175] ; cc4640a8 1ea23194
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[148:149], v[26:27], v[176:183] ; cc4640b0 1ec23594
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[148:149], v[28:29], v[184:191] ; cc4640b8 1ee23994
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[150:151], v[22:23], v[48:55] ; cc464030 1cc22d96
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[150:151], v[24:25], v[58:65] ; cc46403a 1cea3196
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[150:151], v[26:27], v[72:79] ; cc464048 1d223596
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[150:151], v[28:29], v[4:11] ; cc464004 1c123996
	ds_load_b64 v[14:15], v69 offset:768                        ; d9d80300 0e000045
	ds_load_b64 v[16:17], v69 offset:4864                       ; d9d81300 10000045
	ds_load_b64 v[18:19], v69 offset:8960                       ; d9d82300 12000045
	ds_load_b64 v[20:21], v69 offset:13056                      ; d9d83300 14000045
	ds_load_b64 v[22:23], v69 offset:1024                       ; d9d80400 16000045
	ds_load_b64 v[24:25], v69 offset:5120                       ; d9d81400 18000045
	ds_load_b64 v[26:27], v69 offset:9216                       ; d9d82400 1a000045
	ds_load_b64 v[28:29], v69 offset:13312                      ; d9d83400 1c000045
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[132:133], v[30:31], v[32:39] ; cc464020 1c823d84
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[132:133], v[40:41], v[80:87] ; cc464050 1d425184
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[132:133], v[44:45], v[88:95] ; cc464058 1d625984
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[132:133], v[46:47], v[96:103] ; cc464060 1d825d84
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[134:135], v[30:31], v[104:111] ; cc464068 1da23d86
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[134:135], v[40:41], v[112:119] ; cc464070 1dc25186
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[134:135], v[44:45], v[120:127] ; cc464078 1de25986
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[134:135], v[46:47], v[136:143] ; cc464088 1e225d86
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[152:153], v[30:31], v[160:167] ; cc4640a0 1e823d98
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[152:153], v[40:41], v[168:175] ; cc4640a8 1ea25198
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[152:153], v[44:45], v[176:183] ; cc4640b0 1ec25998
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[152:153], v[46:47], v[184:191] ; cc4640b8 1ee25d98
	v_dual_mov_b32 v153, v159 :: v_dual_mov_b32 v152, v158      ; ca10019f 9998019e
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[132:135], v68, s[36:39], null offen offset:9728 ; c405c07c 40804884 00260044
	buffer_load_b128 v[148:151], v68, s[36:39], null offen offset:2048 ; c405c07c 40804894 00080044
	buffer_load_b128 v[156:159], v68, s[36:39], null offen offset:10240 ; c405c07c 4080489c 00280044
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[154:155], v[30:31], v[48:55] ; cc464030 1cc23d9a
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[154:155], v[40:41], v[58:65] ; cc46403a 1cea519a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[154:155], v[44:45], v[72:79] ; cc464048 1d22599a
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[154:155], v[46:47], v[4:11] ; cc464004 1c125d9a
	ds_load_b64 v[30:31], v69 offset:1280                       ; d9d80500 1e000045
	ds_load_b64 v[40:41], v69 offset:5376                       ; d9d81500 28000045
	ds_load_b64 v[44:45], v69 offset:9472                       ; d9d82500 2c000045
	ds_load_b64 v[46:47], v69 offset:13568                      ; d9d83500 2e000045
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[128:129], v[14:15], v[32:39] ; cc464020 1c821d80
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[128:129], v[16:17], v[80:87] ; cc464050 1d422180
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[128:129], v[18:19], v[88:95] ; cc464058 1d622580
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[128:129], v[20:21], v[96:103] ; cc464060 1d822980
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[130:131], v[14:15], v[104:111] ; cc464068 1da21d82
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[130:131], v[16:17], v[112:119] ; cc464070 1dc22182
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[130:131], v[18:19], v[120:127] ; cc464078 1de22582
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[130:131], v[20:21], v[136:143] ; cc464088 1e222982
	v_dual_mov_b32 v155, v13 :: v_dual_mov_b32 v154, v12        ; ca10010d 9b9a010c
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[134:135], v[14:15], v[48:55] ; cc464030 1cc21d86
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[132:133], v[14:15], v[160:167] ; cc4640a0 1e821d84
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[128:131], v68, s[36:39], null offen offset:2560 ; c405c07c 40804880 000a0044
	buffer_load_b128 v[12:15], v68, s[36:39], null offen offset:10752 ; c405c07c 4080480c 002a0044
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[132:133], v[20:21], v[184:191] ; cc4640b8 1ee22984
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[132:133], v[18:19], v[176:183] ; cc4640b0 1ec22584
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[132:133], v[16:17], v[168:175] ; cc4640a8 1ea22184
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[134:135], v[16:17], v[58:65] ; cc46403a 1cea2186
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[134:135], v[20:21], v[4:11] ; cc464004 1c122986
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[134:135], v[18:19], v[72:79] ; cc464048 1d222586
	ds_load_b64 v[16:17], v69 offset:1536                       ; d9d80600 10000045
	ds_load_b64 v[18:19], v69 offset:5632                       ; d9d81600 12000045
	ds_load_b64 v[20:21], v69 offset:9728                       ; d9d82600 14000045
	ds_load_b64 v[132:133], v69 offset:13824                    ; d9d83600 84000045
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[148:149], v[24:25], v[80:87] ; cc464050 1d423194
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[148:149], v[22:23], v[32:39] ; cc464020 1c822d94
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[148:149], v[26:27], v[88:95] ; cc464058 1d623594
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[28:29], v[96:103] ; cc464060 1d823994
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[150:151], v[22:23], v[104:111] ; cc464068 1da22d96
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[150:151], v[24:25], v[112:119] ; cc464070 1dc23196
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[150:151], v[26:27], v[120:127] ; cc464078 1de23596
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[150:151], v[28:29], v[136:143] ; cc464088 1e223996
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[156:157], v[22:23], v[160:167] ; cc4640a0 1e822d9c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[156:157], v[24:25], v[168:175] ; cc4640a8 1ea2319c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[156:157], v[26:27], v[176:183] ; cc4640b0 1ec2359c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[156:157], v[28:29], v[184:191] ; cc4640b8 1ee2399c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[158:159], v[22:23], v[48:55] ; cc464030 1cc22d9e
	v_dual_mov_b32 v23, v155 :: v_dual_mov_b32 v22, v154        ; ca10019b 1716019a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[148:151], v68, s[36:39], null offen offset:3072 ; c405c07c 40804894 000c0044
	buffer_load_b128 v[154:157], v68, s[36:39], null offen offset:11264 ; c405c07c 4080489a 002c0044
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[158:159], v[24:25], v[58:65] ; cc46403a 1cea319e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[158:159], v[26:27], v[72:79] ; cc464048 1d22359e
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[158:159], v[28:29], v[4:11] ; cc464004 1c12399e
	ds_load_b64 v[24:25], v69 offset:1792                       ; d9d80700 18000045
	ds_load_b64 v[26:27], v69 offset:5888                       ; d9d81700 1a000045
	ds_load_b64 v[28:29], v69 offset:9984                       ; d9d82700 1c000045
	ds_load_b64 v[134:135], v69 offset:14080                    ; d9d83700 86000045
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[128:129], v[30:31], v[32:39] ; cc464020 1c823d80
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[130:131], v[44:45], v[120:127] ; cc464078 1de25982
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[128:129], v[40:41], v[80:87] ; cc464050 1d425180
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[128:129], v[44:45], v[88:95] ; cc464058 1d625980
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[130:131], v[46:47], v[136:143] ; cc464088 1e225d82
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[130:131], v[40:41], v[112:119] ; cc464070 1dc25182
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[128:129], v[46:47], v[96:103] ; cc464060 1d825d80
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[130:131], v[30:31], v[104:111] ; cc464068 1da23d82
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[12:13], v[40:41], v[168:175] ; cc4640a8 1ea2510c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[12:13], v[46:47], v[184:191] ; cc4640b8 1ee25d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[30:31], v[160:167] ; cc4640a0 1e823d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[44:45], v[176:183] ; cc4640b0 1ec2590c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[14:15], v[30:31], v[48:55] ; cc464030 1cc23d0e
	v_dual_mov_b32 v31, v15 :: v_dual_mov_b32 v30, v14          ; ca10010f 1f1e010e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[128:131], v68, s[36:39], null offen offset:3584 ; c405c07c 40804880 000e0044
	buffer_load_b128 v[12:15], v68, s[36:39], null offen offset:11776 ; c405c07c 4080480c 002e0044
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[30:31], v[40:41], v[58:65] ; cc46403a 1cea511e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[30:31], v[44:45], v[72:79] ; cc464048 1d22591e
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[30:31], v[46:47], v[4:11] ; cc464004 1c125d1e
	ds_load_b64 v[40:41], v69 offset:2048                       ; d9d80800 28000045
	ds_load_b64 v[44:45], v69 offset:6144                       ; d9d81800 2c000045
	ds_load_b64 v[30:31], v69 offset:10240                      ; d9d82800 1e000045
	ds_load_b64 v[46:47], v69 offset:14336                      ; d9d83800 2e000045
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[148:149], v[18:19], v[80:87] ; cc464050 1d422594
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[148:149], v[20:21], v[88:95] ; cc464058 1d622994
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[132:133], v[96:103] ; cc464060 1d830994
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[150:151], v[20:21], v[120:127] ; cc464078 1de22996
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[148:149], v[16:17], v[32:39] ; cc464020 1c822194
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[150:151], v[16:17], v[104:111] ; cc464068 1da22196
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[150:151], v[132:133], v[136:143] ; cc464088 1e230996
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[150:151], v[18:19], v[112:119] ; cc464070 1dc22596
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[154:155], v[16:17], v[160:167] ; cc4640a0 1e82219a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[154:155], v[18:19], v[168:175] ; cc4640a8 1ea2259a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[156:157], v[16:17], v[48:55] ; cc464030 1cc2219c
	v_dual_mov_b32 v17, v153 :: v_dual_mov_b32 v16, v152        ; ca100199 11100198
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[154:155], v[20:21], v[176:183] ; cc4640b0 1ec2299a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[154:155], v[132:133], v[184:191] ; cc4640b8 1ee3099a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[148:151], v68, s[36:39], null offen offset:4096 ; c405c07c 40804894 00100044
	buffer_load_b128 v[152:155], v68, s[36:39], null offen offset:12288 ; c405c07c 40804898 00300044
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[156:157], v[18:19], v[58:65] ; cc46403a 1cea259c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[156:157], v[20:21], v[72:79] ; cc464048 1d22299c
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[156:157], v[132:133], v[4:11] ; cc464004 1c13099c
	ds_load_b64 v[18:19], v69 offset:2304                       ; d9d80900 12000045
	ds_load_b64 v[20:21], v69 offset:6400                       ; d9d81900 14000045
	ds_load_b64 v[132:133], v69 offset:10496                    ; d9d82900 84000045
	ds_load_b64 v[156:157], v69 offset:14592                    ; d9d83900 9c000045
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[128:129], v[26:27], v[80:87] ; cc464050 1d423580
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[128:129], v[28:29], v[88:95] ; cc464058 1d623980
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[128:129], v[134:135], v[96:103] ; cc464060 1d830d80
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[130:131], v[26:27], v[112:119] ; cc464070 1dc23582
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[130:131], v[134:135], v[136:143] ; cc464088 1e230d82
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[130:131], v[28:29], v[120:127] ; cc464078 1de23982
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[130:131], v[24:25], v[104:111] ; cc464068 1da23182
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[128:129], v[24:25], v[32:39] ; cc464020 1c823180
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[12:13], v[26:27], v[168:175] ; cc4640a8 1ea2350c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[14:15], v[24:25], v[48:55] ; cc464030 1cc2310e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[24:25], v[160:167] ; cc4640a0 1e82310c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[28:29], v[176:183] ; cc4640b0 1ec2390c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[12:13], v[134:135], v[184:191] ; cc4640b8 1ee30d0c
	v_dual_mov_b32 v13, v23 :: v_dual_mov_b32 v12, v22          ; ca100117 0d0c0116
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[128:131], v68, s[36:39], null offen offset:4608 ; c405c07c 40804880 00120044
	buffer_load_b128 v[22:25], v68, s[36:39], null offen offset:12800 ; c405c07c 40804816 00320044
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[14:15], v[26:27], v[58:65] ; cc46403a 1cea350e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[28:29], v[72:79] ; cc464048 1d22390e
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[14:15], v[134:135], v[4:11] ; cc464004 1c130d0e
	ds_load_b64 v[26:27], v69 offset:2560                       ; d9d80a00 1a000045
	ds_load_b64 v[28:29], v69 offset:6656                       ; d9d81a00 1c000045
	ds_load_b64 v[14:15], v69 offset:10752                      ; d9d82a00 0e000045
	ds_load_b64 v[134:135], v69 offset:14848                    ; d9d83a00 86000045
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[148:149], v[44:45], v[80:87] ; cc464050 1d425994
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[148:149], v[30:31], v[88:95] ; cc464058 1d623d94
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[46:47], v[96:103] ; cc464060 1d825d94
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[150:151], v[40:41], v[104:111] ; cc464068 1da25196
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[150:151], v[46:47], v[136:143] ; cc464088 1e225d96
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[150:151], v[44:45], v[112:119] ; cc464070 1dc25996
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[150:151], v[30:31], v[120:127] ; cc464078 1de23d96
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[148:149], v[40:41], v[32:39] ; cc464020 1c825194
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[152:153], v[44:45], v[168:175] ; cc4640a8 1ea25998
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[154:155], v[40:41], v[48:55] ; cc464030 1cc2519a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[152:153], v[30:31], v[176:183] ; cc4640b0 1ec23d98
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[152:153], v[46:47], v[184:191] ; cc4640b8 1ee25d98
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[152:153], v[40:41], v[160:167] ; cc4640a0 1e825198
	v_dual_mov_b32 v153, v43 :: v_dual_mov_b32 v152, v42        ; ca10012b 9998012a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[148:151], v68, s[36:39], null offen offset:5120 ; c405c07c 40804894 00140044
	buffer_load_b128 v[40:43], v68, s[36:39], null offen offset:13312 ; c405c07c 40804828 00340044
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[154:155], v[44:45], v[58:65] ; cc46403a 1cea599a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[154:155], v[30:31], v[72:79] ; cc464048 1d223d9a
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[154:155], v[46:47], v[4:11] ; cc464004 1c125d9a
	ds_load_b64 v[44:45], v69 offset:2816                       ; d9d80b00 2c000045
	ds_load_b64 v[30:31], v69 offset:6912                       ; d9d81b00 1e000045
	ds_load_b64 v[46:47], v69 offset:11008                      ; d9d82b00 2e000045
	ds_load_b64 v[154:155], v69 offset:15104                    ; d9d83b00 9a000045
	v_dual_mov_b32 v159, v17 :: v_dual_mov_b32 v158, v16        ; ca100111 9f9e0110
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[128:129], v[20:21], v[80:87] ; cc464050 1d422980
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[128:129], v[132:133], v[88:95] ; cc464058 1d630980
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[128:129], v[156:157], v[96:103] ; cc464060 1d833980
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[130:131], v[156:157], v[136:143] ; cc464088 1e233982
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[130:131], v[18:19], v[104:111] ; cc464068 1da22582
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[130:131], v[132:133], v[120:127] ; cc464078 1de30982
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[130:131], v[20:21], v[112:119] ; cc464070 1dc22982
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[128:129], v[18:19], v[32:39] ; cc464020 1c822580
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[24:25], v[18:19], v[48:55] ; cc464030 1cc22518
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[22:23], v[18:19], v[160:167] ; cc4640a0 1e822516
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[128:131], v68, s[36:39], null offen offset:5632 ; c405c07c 40804880 00160044
	buffer_load_b128 v[16:19], v68, s[36:39], null offen offset:13824 ; c405c07c 40804810 00360044
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[20:21], v[168:175] ; cc4640a8 1ea22916
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[22:23], v[132:133], v[176:183] ; cc4640b0 1ec30916
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[22:23], v[156:157], v[184:191] ; cc4640b8 1ee33916
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[24:25], v[20:21], v[58:65] ; cc46403a 1cea2918
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[132:133], v[72:79] ; cc464048 1d230918
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[24:25], v[156:157], v[4:11] ; cc464004 1c133918
	ds_load_b64 v[20:21], v69 offset:3072                       ; d9d80c00 14000045
	ds_load_b64 v[22:23], v69 offset:7168                       ; d9d81c00 16000045
	ds_load_b64 v[24:25], v69 offset:11264                      ; d9d82c00 18000045
	ds_load_b64 v[132:133], v69 offset:15360                    ; d9d83c00 84000045
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[150:151], v[14:15], v[120:127] ; cc464078 1de21d96
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[148:149], v[14:15], v[88:95] ; cc464058 1d621d94
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[134:135], v[96:103] ; cc464060 1d830d94
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[150:151], v[134:135], v[136:143] ; cc464088 1e230d96
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[150:151], v[26:27], v[104:111] ; cc464068 1da23596
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[150:151], v[28:29], v[112:119] ; cc464070 1dc23996
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[148:149], v[26:27], v[32:39] ; cc464020 1c823594
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[148:149], v[28:29], v[80:87] ; cc464050 1d423994
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[42:43], v[26:27], v[48:55] ; cc464030 1cc2352a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[40:41], v[26:27], v[160:167] ; cc4640a0 1e823528
	v_dual_mov_b32 v27, v159 :: v_dual_mov_b32 v26, v158        ; ca10019f 1b1a019e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[148:151], v68, s[36:39], null offen offset:6144 ; c405c07c 40804894 00180044
	buffer_load_b128 v[156:159], v68, s[36:39], null offen offset:14336 ; c405c07c 4080489c 00380044
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[40:41], v[14:15], v[176:183] ; cc4640b0 1ec21d28
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[40:41], v[134:135], v[184:191] ; cc4640b8 1ee30d28
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[28:29], v[168:175] ; cc4640a8 1ea23928
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[42:43], v[28:29], v[58:65] ; cc46403a 1cea392a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[42:43], v[14:15], v[72:79] ; cc464048 1d221d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[42:43], v[134:135], v[4:11] ; cc464004 1c130d2a
	ds_load_b64 v[28:29], v69 offset:3328                       ; d9d80d00 1c000045
	ds_load_b64 v[14:15], v69 offset:7424                       ; d9d81d00 0e000045
	ds_load_b64 v[40:41], v69 offset:11520                      ; d9d82d00 28000045
	ds_load_b64 v[42:43], v69 offset:15616                      ; d9d83d00 2a000045
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[128:129], v[30:31], v[80:87] ; cc464050 1d423d80
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[130:131], v[46:47], v[120:127] ; cc464078 1de25d82
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[130:131], v[44:45], v[104:111] ; cc464068 1da25982
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[130:131], v[154:155], v[136:143] ; cc464088 1e233582
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[128:129], v[154:155], v[96:103] ; cc464060 1d833580
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[130:131], v[30:31], v[112:119] ; cc464070 1dc23d82
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[128:129], v[46:47], v[88:95] ; cc464058 1d625d80
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[128:129], v[44:45], v[32:39] ; cc464020 1c825980
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[16:17], v[30:31], v[168:175] ; cc4640a8 1ea23d10
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[18:19], v[44:45], v[48:55] ; cc464030 1cc25912
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[46:47], v[176:183] ; cc4640b0 1ec25d10
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[16:17], v[154:155], v[184:191] ; cc4640b8 1ee33510
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[44:45], v[160:167] ; cc4640a0 1e825910
	v_dual_mov_b32 v45, v19 :: v_dual_mov_b32 v44, v18          ; ca100113 2d2c0112
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[128:131], v68, s[36:39], null offen offset:6656 ; c405c07c 40804880 001a0044
	buffer_load_b128 v[16:19], v68, s[36:39], null offen offset:14848 ; c405c07c 40804810 003a0044
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[44:45], v[30:31], v[58:65] ; cc46403a 1cea3d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[44:45], v[46:47], v[72:79] ; cc464048 1d225d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[44:45], v[154:155], v[4:11] ; cc464004 1c13352c
	ds_load_b64 v[30:31], v69 offset:3584                       ; d9d80e00 1e000045
	ds_load_b64 v[46:47], v69 offset:7680                       ; d9d81e00 2e000045
	ds_load_b64 v[44:45], v69 offset:11776                      ; d9d82e00 2c000045
	ds_load_b64 v[134:135], v69 offset:15872                    ; d9d83e00 86000045
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[148:149], v[22:23], v[80:87] ; cc464050 1d422d94
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[148:149], v[24:25], v[88:95] ; cc464058 1d623194
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[132:133], v[96:103] ; cc464060 1d830994
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[150:151], v[132:133], v[136:143] ; cc464088 1e230996
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[150:151], v[20:21], v[104:111] ; cc464068 1da22996
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[150:151], v[22:23], v[112:119] ; cc464070 1dc22d96
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[150:151], v[24:25], v[120:127] ; cc464078 1de23196
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[148:149], v[20:21], v[32:39] ; cc464020 1c822994
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[156:157], v[22:23], v[168:175] ; cc4640a8 1ea22d9c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[156:157], v[24:25], v[176:183] ; cc4640b0 1ec2319c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[156:157], v[132:133], v[184:191] ; cc4640b8 1ee3099c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[156:157], v[20:21], v[160:167] ; cc4640a0 1e82299c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[148:151], v68, s[36:39], null offen offset:7168 ; c405c07c 40804894 001c0044
	buffer_load_b128 v[154:157], v68, s[36:39], null offen offset:15360 ; c405c07c 4080489a 003c0044
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[158:159], v[20:21], v[48:55] ; cc464030 1cc2299e
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[158:159], v[22:23], v[58:65] ; cc46403a 1cea2d9e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[158:159], v[24:25], v[72:79] ; cc464048 1d22319e
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[158:159], v[132:133], v[4:11] ; cc464004 1c13099e
	ds_load_b64 v[20:21], v69 offset:3840                       ; d9d80f00 14000045
	ds_load_b64 v[22:23], v69 offset:7936                       ; d9d81f00 16000045
	ds_load_b64 v[24:25], v69 offset:12032                      ; d9d82f00 18000045
	ds_load_b64 v[132:133], v69 offset:16128                    ; d9d83f00 84000045
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[128:129], v[40:41], v[88:95] ; cc464058 1d625180
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[128:129], v[42:43], v[96:103] ; cc464060 1d825580
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[130:131], v[40:41], v[120:127] ; cc464078 1de25182
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[130:131], v[28:29], v[104:111] ; cc464068 1da23982
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[130:131], v[42:43], v[136:143] ; cc464088 1e225582
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[128:129], v[28:29], v[32:39] ; cc464020 1c823980
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[130:131], v[14:15], v[112:119] ; cc464070 1dc21d82
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[128:129], v[14:15], v[80:87] ; cc464050 1d421d80
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[28:29], v[160:167] ; cc4640a0 1e823910
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[18:19], v[28:29], v[48:55] ; cc464030 1cc23912
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[40:41], v[176:183] ; cc4640b0 1ec25110
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[16:17], v[42:43], v[184:191] ; cc4640b8 1ee25510
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[16:17], v[14:15], v[168:175] ; cc4640a8 1ea21d10
	v_dual_mov_b32 v17, v27 :: v_dual_mov_b32 v16, v26          ; ca10011b 1110011a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[128:131], v68, s[36:39], null offen offset:7680 ; c405c07c 40804880 001e0044
	buffer_load_b128 v[26:29], v68, s[36:39], null offen offset:15872 ; c405c07c 4080481a 003e0044
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[18:19], v[14:15], v[58:65] ; cc46403a 1cea1d12
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[18:19], v[40:41], v[72:79] ; cc464048 1d225112
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[18:19], v[42:43], v[4:11] ; cc464004 1c125512
	v_mad_u32_u24 v18, s59, 0x820, v152                         ; d60b0012 0661fe3b 00000820
	ds_load_b64 v[14:15], v18                                   ; d9d80000 0e000012
	ds_load_b64 v[40:41], v18 offset:4096                       ; d9d81000 28000012
	ds_load_b64 v[42:43], v18 offset:8192                       ; d9d82000 2a000012
	ds_load_b64 v[158:159], v18 offset:12288                    ; d9d83000 9e000012
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[150:151], v[46:47], v[112:119] ; cc464070 1dc25d96
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[150:151], v[44:45], v[120:127] ; cc464078 1de25996
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[150:151], v[134:135], v[136:143] ; cc464088 1e230d96
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[134:135], v[96:103] ; cc464060 1d830d94
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[148:149], v[30:31], v[32:39] ; cc464020 1c823d94
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[148:149], v[44:45], v[88:95] ; cc464058 1d625994
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[148:149], v[46:47], v[80:87] ; cc464050 1d425d94
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[150:151], v[30:31], v[104:111] ; cc464068 1da23d96
	buffer_load_b128 v[148:151], v68, s[36:39], null offen offset:16384 ; c405c07c 40804894 00400044
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[154:155], v[46:47], v[168:175] ; cc4640a8 1ea25d9a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[154:155], v[44:45], v[176:183] ; cc4640b0 1ec2599a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[154:155], v[134:135], v[184:191] ; cc4640b8 1ee30d9a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[154:155], v[30:31], v[160:167] ; cc4640a0 1e823d9a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[156:157], v[30:31], v[48:55] ; cc464030 1cc23d9c
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[156:157], v[46:47], v[58:65] ; cc46403a 1cea5d9c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[156:157], v[44:45], v[72:79] ; cc464048 1d22599c
	ds_load_b64 v[154:155], v18 offset:256                      ; d9d80100 9a000012
	ds_load_b64 v[30:31], v18 offset:4352                       ; d9d81100 1e000012
	ds_load_b64 v[46:47], v18 offset:8448                       ; d9d82100 2e000012
	ds_load_b64 v[44:45], v18 offset:12544                      ; d9d83100 2c000012
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[156:157], v[134:135], v[4:11] ; cc464004 1c130d9c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_dual_mov_b32 v157, v133 :: v_dual_mov_b32 v156, v132      ; ca100185 9d9c0184
	buffer_load_b128 v[132:135], v68, s[36:39], null offen offset:16896 ; c405c07c 40804884 00420044
	s_mov_b32 s61, 0x76543210                                   ; bebd00ff 76543210
	s_mov_b32 s62, 0xfedcba98                                   ; bebe00ff fedcba98
	s_movk_i32 s63, 0x410                                       ; b03f0410
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[130:131], v[20:21], v[104:111] ; cc464068 1da22982
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[128:129], v[20:21], v[32:39] ; cc464020 1c822980
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[128:129], v[22:23], v[80:87] ; cc464050 1d422d80
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[128:129], v[24:25], v[88:95] ; cc464058 1d623180
	v_mul_f32_e32 v19, v105, v105                               ; 1026d369
	v_mul_f32_e32 v69, v107, v107                               ; 108ad76b
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[128:129], v[156:157], v[96:103] ; cc464060 1d833980
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[130:131], v[22:23], v[112:119] ; cc464070 1dc22d82
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[130:131], v[24:25], v[120:127] ; cc464078 1de23182
	v_fmac_f32_e32 v19, v33, v33                                ; 56264321
	v_fmac_f32_e32 v69, v35, v35                                ; 568a4723
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[130:131], v[156:157], v[136:143] ; cc464088 1e233982
	v_fmac_f32_e32 v19, v37, v37                                ; 56264b25
	v_fmac_f32_e32 v69, v39, v39                                ; 568a4f27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmac_f32_e32 v19, v109, v109                              ; 5626db6d
	v_fmac_f32_e32 v69, v111, v111                              ; 568adf6f
	v_fmac_f32_e32 v19, v32, v32                                ; 56264120
	v_fmac_f32_e32 v69, v34, v34                                ; 568a4522
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmac_f32_e32 v19, v104, v104                              ; 5626d168
	v_fmac_f32_e32 v69, v106, v106                              ; 568ad56a
	v_fmac_f32_e32 v19, v36, v36                                ; 56264924
	v_fmac_f32_e32 v69, v38, v38                                ; 568a4d26
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fmac_f32_e32 v19, v108, v108                              ; 5626d96c
	v_fmac_f32_e32 v69, v110, v110                              ; 568add6e
	v_fma_mixlo_f16 v128, 1.0, v19, v69                         ; cc210080 051626f2
	v_mul_f32_e32 v131, v113, v113                              ; 1106e371
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
(invalid instruction)                                        ; d5eb0081
	v_cndmask_b32_e32 v0, v128, v128, vcc_lo                    ; 02010180
	v_mul_f32_e32 v19, v115, v115                               ; 1026e773
	v_fmac_f32_e32 v131, v81, v81                               ; 5706a351
	v_permlanex16_b32 v129, v129, s61, s62 op_sel:[1,1]         ; d65c1881 00f87b81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5320080
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d5310080
	v_cndmask_b32_e32 v1, s63, v128, vcc_lo                     ; 0203003f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b0082
	v_cndmask_b32_e32 v0, v128, v128, vcc_lo                    ; 02010180
	v_rsq_f32_e32 v130, v130                                    ; 7f045d82
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v130, v130, v67                               ; 11048782
	v_mul_f32_e32 v105, v105, v130                              ; 10d30569
	v_dual_fmac_f32 v19, v83, v83 :: v_dual_mul_f32 v32, v32, v130 ; c806a753 13210520
	v_mul_f32_e32 v111, v111, v130                              ; 10df056f
	v_mul_f32_e32 v109, v109, v130                              ; 10db056d
	v_mul_f32_e32 v35, v35, v130                                ; 10470523
	v_dual_fmac_f32 v131, v85, v85 :: v_dual_mul_f32 v34, v34, v130 ; c806ab55 83230522
	v_mul_f32_e32 v33, v33, v130                                ; 10430521
	v_mul_f32_e32 v39, v39, v130                                ; 104f0527
	v_mul_f32_e32 v37, v37, v130                                ; 104b0525
	v_mul_f32_e32 v107, v107, v130                              ; 10d7056b
	v_dual_fmac_f32 v19, v87, v87 :: v_dual_mul_f32 v104, v104, v130 ; c806af57 13690568
	v_dual_fmac_f32 v131, v117, v117 :: v_dual_mul_f32 v36, v36, v130 ; c806eb75 83250524
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_fmac_f32 v19, v119, v119 :: v_dual_mul_f32 v108, v108, v130 ; c806ef77 136d056c
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_fmac_f32 v131, v80, v80 :: v_dual_mul_f32 v38, v38, v130 ; c806a150 83270526
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
	v_fmac_f32_e32 v19, v82, v82                                ; 5626a552
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	v_fmac_f32_e32 v131, v112, v112                             ; 5706e170
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_fmac_f32_e32 v19, v114, v114                              ; 5626e572
	v_dual_fmac_f32 v131, v84, v84 :: v_dual_mul_f32 v106, v106, v130 ; c806a954 836b056a
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fmac_f32_e32 v19, v86, v86                                ; 5626ad56
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_dual_fmac_f32 v131, v116, v116 :: v_dual_mul_f32 v110, v110, v130 ; c806e974 836f056e
	v_fmac_f32_e32 v19, v118, v118                              ; 5626ed76
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mixlo_f16 v36, 1.0, v131, v19                         ; cc210024 044f06f2
	v_mul_f32_e32 v39, v121, v121                               ; 104ef379
	v_cvt_u32_u16_e32 v37, v36                                  ; 7e4ad724
	v_mul_f32_e32 v69, v123, v123                               ; 108af77b
	v_fmac_f32_e32 v39, v89, v89                                ; 564eb359
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_permlanex16_b32 v37, v37, s61, s62 op_sel:[1,1]           ; d65c1825 00f87b25
	v_add_f16_e32 v36, v36, v37                                 ; 64484b24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v36, s63, v36                             ; 6248483f
	v_cvt_f32_f16_e32 v38, v36                                  ; 7e4c1724
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v38, v38                                      ; 7e4c5d26
	v_mul_f32_e32 v38, v38, v67                                 ; 104c8726
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v87, v87, v38                                 ; 10ae4d57
	v_mul_f32_e32 v117, v117, v38                               ; 10ea4d75
	v_dual_fmac_f32 v69, v91, v91 :: v_dual_mul_f32 v80, v80, v38 ; c806b75b 45504d50
	v_mul_f32_e32 v81, v81, v38                                 ; 10a24d51
	v_mul_f32_e32 v85, v85, v38                                 ; 10aa4d55
	v_mul_f32_e32 v113, v113, v38                               ; 10e24d71
	v_dual_fmac_f32 v39, v93, v93 :: v_dual_mul_f32 v82, v82, v38 ; c806bb5d 27524d52
	v_mul_f32_e32 v119, v119, v38                               ; 10ee4d77
	v_mul_f32_e32 v115, v115, v38                               ; 10e64d73
	v_mul_f32_e32 v83, v83, v38                                 ; 10a64d53
	v_dual_fmac_f32 v69, v95, v95 :: v_dual_mul_f32 v112, v112, v38 ; c806bf5f 45704d70
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_dual_fmac_f32 v39, v125, v125 :: v_dual_mul_f32 v84, v84, v38 ; c806fb7d 27544d54
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_dual_fmac_f32 v69, v127, v127 :: v_dual_mul_f32 v116, v116, v38 ; c806ff7f 45744d74
	v_dual_fmac_f32 v39, v88, v88 :: v_dual_mul_f32 v86, v86, v38 ; c806b158 27564d56
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_fmac_f32_e32 v69, v90, v90                                ; 568ab55a
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_fmac_f32_e32 v39, v120, v120                              ; 564ef178
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_fmac_f32_e32 v69, v122, v122                              ; 568af57a
	v_dual_fmac_f32 v39, v92, v92 :: v_dual_mul_f32 v114, v114, v38 ; c806b95c 27724d72
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fmac_f32_e32 v69, v94, v94                                ; 568abd5e
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmac_f32 v39, v124, v124 :: v_dual_mul_f32 v118, v118, v38 ; c806f97c 27764d76
	v_fmac_f32_e32 v69, v126, v126                              ; 568afd7e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mixlo_f16 v82, 1.0, v39, v69                          ; cc210052 05164ef2
	v_cvt_u32_u16_e32 v83, v82                                  ; 7ea6d752
	v_dual_mul_f32 v86, v139, v139 :: v_dual_mul_f32 v85, v137, v137 ; c8c7178b 56551389
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v83, v83, s61, s62 op_sel:[1,1]           ; d65c1853 00f87b53
	v_dual_fmac_f32 v86, v99, v99 :: v_dual_fmac_f32 v85, v97, v97 ; c800c763 5654c361
	v_add_f16_e32 v82, v82, v83                                 ; 64a4a752
	v_dual_fmac_f32 v86, v103, v103 :: v_dual_fmac_f32 v85, v101, v101 ; c800cf67 5654cb65
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[26:27], v[20:21], v[160:167] ; cc4640a0 1e82291a
	v_max_num_f16_e32 v82, s63, v82                             ; 62a4a43f
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[26:27], v[22:23], v[168:175] ; cc4640a8 1ea22d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[26:27], v[24:25], v[176:183] ; cc4640b0 1ec2311a
	v_cvt_f32_f16_e32 v84, v82                                  ; 7ea81752
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[26:27], v[156:157], v[184:191] ; cc4640b8 1ee3391a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[28:29], v[20:21], v[48:55] ; cc464030 1cc2291c
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[28:29], v[22:23], v[58:65] ; cc46403a 1cea2d1c
	v_rsq_f32_e32 v84, v84                                      ; 7ea85d54
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[24:25], v[72:79] ; cc464048 1d22311c
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[28:29], v[156:157], v[4:11] ; cc464004 1c13391c
	v_dual_fmac_f32 v86, v143, v143 :: v_dual_fmac_f32 v85, v141, v141 ; c8011f8f 56551b8d
	v_mul_f32_e32 v84, v84, v67                                 ; 10a88754
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmac_f32 v86, v98, v98 :: v_dual_fmac_f32 v85, v96, v96 ; c800c562 5654c160
	v_dual_mul_f32 v127, v127, v84 :: v_dual_mul_f32 v126, v126, v84 ; c8c6a97f 7f7ea97e
	v_dual_mul_f32 v89, v89, v84 :: v_dual_mul_f32 v88, v88, v84 ; c8c6a959 5958a958
	v_dual_mul_f32 v124, v124, v84 :: v_dual_mul_f32 v125, v125, v84 ; c8c6a97c 7c7ca97d
	v_dual_mul_f32 v93, v93, v84 :: v_dual_mul_f32 v92, v92, v84 ; c8c6a95d 5d5ca95c
	v_dual_mul_f32 v120, v120, v84 :: v_dual_mul_f32 v121, v121, v84 ; c8c6a978 7878a979
	v_dual_mul_f32 v122, v122, v84 :: v_dual_mul_f32 v123, v123, v84 ; c8c6a97a 7a7aa97b
	v_dual_mul_f32 v95, v95, v84 :: v_dual_mul_f32 v94, v94, v84 ; c8c6a95f 5f5ea95e
	v_dual_mul_f32 v91, v91, v84 :: v_dual_mul_f32 v90, v90, v84 ; c8c6a95b 5b5aa95a
	v_dual_fmac_f32 v86, v138, v138 :: v_dual_fmac_f32 v85, v136, v136 ; c801158a 56551188
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_dual_fmac_f32 v86, v102, v102 :: v_dual_fmac_f32 v85, v100, v100 ; c800cd66 5654c964
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v86, v142, v142 :: v_dual_fmac_f32 v85, v140, v140 ; c8011d8e 5655198c
	v_fma_mixlo_f16 v87, 1.0, v85, v86                          ; cc210057 055aaaf2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_u32_u16_e32 v88, v87                                  ; 7eb0d757
	v_dual_mul_f32 v91, v51, v51 :: v_dual_mul_f32 v90, v49, v49 ; c8c66733 5b5a6331
	v_permlanex16_b32 v88, v88, s61, s62 op_sel:[1,1]           ; d65c1858 00f87b58
	v_dual_fmac_f32 v91, v163, v163 :: v_dual_fmac_f32 v90, v161, v161 ; c80147a3 5b5b43a1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_add_f16_e32 v87, v87, v88                                 ; 64aeb157
	v_dual_fmac_f32 v91, v167, v167 :: v_dual_fmac_f32 v90, v165, v165 ; c8014fa7 5b5b4ba5
	v_max_num_f16_e32 v87, s63, v87                             ; 62aeae3f
	v_dual_fmac_f32 v91, v55, v55 :: v_dual_fmac_f32 v90, v53, v53 ; c8006f37 5b5a6b35
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v89, v87                                  ; 7eb21757
	v_dual_fmac_f32 v91, v162, v162 :: v_dual_fmac_f32 v90, v160, v160 ; c80145a2 5b5b41a0
	v_rsq_f32_e32 v89, v89                                      ; 7eb25d59
	v_dual_fmac_f32 v91, v50, v50 :: v_dual_fmac_f32 v90, v48, v48 ; c8006532 5b5a6130
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870125
	v_mul_f32_e32 v89, v89, v67                                 ; 10b28759
	v_dual_fmac_f32 v91, v166, v166 :: v_dual_fmac_f32 v90, v164, v164 ; c8014da6 5b5b49a4
	v_dual_mul_f32 v100, v100, v89 :: v_dual_mul_f32 v101, v101, v89 ; c8c6b364 6464b365
	v_dual_mul_f32 v141, v141, v89 :: v_dual_mul_f32 v140, v140, v89 ; c8c6b38d 8d8cb38c
	v_dual_mul_f32 v96, v96, v89 :: v_dual_mul_f32 v97, v97, v89 ; c8c6b360 6060b361
	v_dual_mul_f32 v139, v139, v89 :: v_dual_mul_f32 v138, v138, v89 ; c8c6b38b 8b8ab38a
	v_dual_mul_f32 v143, v143, v89 :: v_dual_mul_f32 v142, v142, v89 ; c8c6b38f 8f8eb38e
	v_dual_mul_f32 v137, v137, v89 :: v_dual_mul_f32 v136, v136, v89 ; c8c6b389 8988b388
	v_dual_mul_f32 v103, v103, v89 :: v_dual_mul_f32 v102, v102, v89 ; c8c6b367 6766b366
	v_dual_mul_f32 v98, v98, v89 :: v_dual_mul_f32 v99, v99, v89 ; c8c6b362 6262b363
	v_dual_fmac_f32 v91, v54, v54 :: v_dual_fmac_f32 v90, v52, v52 ; c8006d36 5b5a6934
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	buffer_load_b128 v[84:87], v68, s[36:39], null offen offset:17408 ; c405c07c 40804854 00440044
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_fma_mixlo_f16 v92, 1.0, v90, v91                          ; cc21005c 056eb4f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v93, v92                                  ; 7ebad75c
	v_permlanex16_b32 v93, v93, s61, s62 op_sel:[1,1]           ; d65c185d 00f87b5d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v92, v92, v93                                 ; 64b8bb5c
	v_max_num_f16_e32 v92, s63, v92                             ; 62b8b83f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v94, v92                                  ; 7ebc175c
	v_rsq_f32_e32 v94, v94                                      ; 7ebc5d5e
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b5
	v_mul_f32_e32 v160, v160, v94                               ; 1140bda0
	v_dual_mul_f32 v51, v51, v94 :: v_dual_mul_f32 v50, v50, v94 ; c8c6bd33 3332bd32
	v_dual_mul_f32 v49, v49, v94 :: v_dual_mul_f32 v48, v48, v94 ; c8c6bd31 3130bd30
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	buffer_load_b128 v[48:51], v68, s[36:39], null offen offset:17920 ; c405c07c 40804830 00460044
	v_dual_mul_f32 v53, v53, v94 :: v_dual_mul_f32 v52, v52, v94 ; c8c6bd35 3534bd34
	v_mul_f32_e32 v165, v165, v94                               ; 114abda5
	v_dual_mul_f32 v161, v161, v94 :: v_dual_mul_f32 v162, v162, v94 ; c8c6bda1 a1a2bda2
	v_dual_mul_f32 v163, v163, v94 :: v_dual_mul_f32 v164, v164, v94 ; c8c6bda3 a3a4bda4
	v_dual_mul_f32 v167, v167, v94 :: v_dual_mul_f32 v166, v166, v94 ; c8c6bda7 a7a6bda6
	v_mul_f32_e32 v55, v55, v94                                 ; 106ebd37
	v_mul_f32_e32 v95, v59, v59                                 ; 10be773b
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fmac_f32_e32 v95, v169, v169                              ; 56bf53a9
	v_dual_fmac_f32 v95, v173, v173 :: v_dual_mul_f32 v54, v54, v94 ; c8075bad 5f36bd36
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	buffer_load_b128 v[52:55], v68, s[36:39], null offen offset:18432 ; c405c07c 40804834 00480044
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_dual_fmac_f32 v95, v63, v63 :: v_dual_mul_f32 v96, v61, v61 ; c8067f3f 5f607b3d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v95, v168, v168 :: v_dual_fmac_f32 v96, v171, v171 ; c80151a8 5f6157ab
	v_dual_fmac_f32 v95, v58, v58 :: v_dual_fmac_f32 v96, v175, v175 ; c800753a 5f615faf
	buffer_load_b128 v[88:91], v68, s[36:39], null offen offset:18944 ; c405c07c 40804858 004a0044
	v_dual_fmac_f32 v95, v172, v172 :: v_dual_fmac_f32 v96, v65, v65 ; c80159ac 5f608341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v96, v170, v170                              ; 56c155aa
	v_fmac_f32_e32 v96, v60, v60                                ; 56c0793c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v96, v174, v174                              ; 56c15dae
	v_dual_fmac_f32 v96, v64, v64 :: v_dual_fmac_f32 v95, v62, v62 ; c8008140 605e7d3e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v97, 1.0, v95, v96                          ; cc210061 0582bef2
	v_cvt_u32_u16_e32 v98, v97                                  ; 7ec4d761
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v98, v98, s61, s62 op_sel:[1,1]           ; d65c1862 00f87b62
	v_add_f16_e32 v97, v97, v98                                 ; 64c2c561
	buffer_load_b128 v[92:95], v68, s[36:39], null offen offset:19456 ; c405c07c 4080485c 004c0044
	v_max_num_f16_e32 v97, s63, v97                             ; 62c2c23f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v99, v97                                  ; 7ec61761
	v_rsq_f32_e32 v99, v99                                      ; 7ec65d63
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v61, v61, v99 :: v_dual_mul_f32 v60, v60, v99 ; c8c6c73d 3d3cc73c
	v_dual_mul_f32 v171, v171, v99 :: v_dual_mul_f32 v170, v170, v99 ; c8c6c7ab abaac7aa
	v_dual_mul_f32 v175, v175, v99 :: v_dual_mul_f32 v174, v174, v99 ; c8c6c7af afaec7ae
	v_dual_mul_f32 v168, v168, v99 :: v_dual_mul_f32 v169, v169, v99 ; c8c6c7a8 a8a8c7a9
	v_dual_mul_f32 v100, v73, v73 :: v_dual_mul_f32 v63, v63, v99 ; c8c69349 643ec73f
	v_dual_mul_f32 v64, v64, v99 :: v_dual_mul_f32 v65, v65, v99 ; c8c6c740 4040c741
	v_mul_f32_e32 v62, v62, v99                                 ; 107cc73e
	v_dual_mul_f32 v59, v59, v99 :: v_dual_mul_f32 v58, v58, v99 ; c8c6c73b 3b3ac73a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	buffer_load_b128 v[60:63], v68, s[36:39], null offen offset:19968 ; c405c07c 4080483c 004e0044
	v_dual_mul_f32 v173, v173, v99 :: v_dual_mul_f32 v172, v172, v99 ; c8c6c7ad adacc7ac
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_dual_fmac_f32 v100, v177, v177 :: v_dual_mul_f32 v101, v75, v75 ; c80763b1 6464974b
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	buffer_load_b128 v[96:99], v68, s[36:39], null offen offset:20480 ; c405c07c 40804860 00500044
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_dual_fmac_f32 v100, v181, v181 :: v_dual_fmac_f32 v101, v179, v179 ; c8016bb5 646567b3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v100, v77, v77 :: v_dual_fmac_f32 v101, v183, v183 ; c8009b4d 64656fb7
	v_fmac_f32_e32 v101, v79, v79                               ; 56ca9f4f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v101, v178, v178 :: v_dual_fmac_f32 v100, v176, v176 ; c80165b2 656561b0
	v_dual_fmac_f32 v101, v74, v74 :: v_dual_fmac_f32 v100, v72, v72 ; c800954a 65649148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v101, v182, v182 :: v_dual_fmac_f32 v100, v180, v180 ; c8016db6 656569b4
	v_dual_fmac_f32 v101, v78, v78 :: v_dual_fmac_f32 v100, v76, v76 ; c8009d4e 6564994c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v102, 1.0, v100, v101                       ; cc210066 0596c8f2
	v_cvt_u32_u16_e32 v103, v102                                ; 7eced766
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v103, v103, s61, s62 op_sel:[1,1]         ; d65c1867 00f87b67
	v_add_f16_e32 v102, v102, v103                              ; 64cccf66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v102, s63, v102                           ; 62cccc3f
	v_cvt_f32_f16_e32 v104, v102                                ; 7ed01766
	buffer_load_b128 v[100:103], v68, s[36:39], null offen offset:20992 ; c405c07c 40804864 00520044
	v_dual_mul_f32 v105, v5, v5 :: v_dual_mul_f32 v106, v7, v7  ; c8c60b05 696a0f07
	v_rsq_f32_e32 v104, v104                                    ; 7ed05d68
	v_dual_fmac_f32 v105, v185, v185 :: v_dual_fmac_f32 v106, v187, v187 ; c80173b9 696b77bb
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmac_f32 v105, v189, v189 :: v_dual_fmac_f32 v106, v191, v191 ; c8017bbd 696b7fbf
	v_dual_mul_f32 v182, v182, v104 :: v_dual_mul_f32 v181, v181, v104 ; c8c6d1b6 b6b4d1b5
	v_dual_mul_f32 v180, v180, v104 :: v_dual_mul_f32 v179, v179, v104 ; c8c6d1b4 b4b2d1b3
	v_mul_f32_e32 v176, v176, v104                              ; 1160d1b0
	v_mul_f32_e32 v73, v73, v104                                ; 1092d149
	v_dual_mul_f32 v79, v79, v104 :: v_dual_mul_f32 v78, v78, v104 ; c8c6d14f 4f4ed14e
	v_dual_mul_f32 v72, v72, v104 :: v_dual_mul_f32 v183, v183, v104 ; c8c6d148 48b6d1b7
	v_dual_mul_f32 v77, v77, v104 :: v_dual_mul_f32 v76, v76, v104 ; c8c6d14d 4d4cd14c
	v_dual_mul_f32 v178, v178, v104 :: v_dual_mul_f32 v177, v177, v104 ; c8c6d1b2 b2b0d1b1
	v_dual_mul_f32 v75, v75, v104 :: v_dual_mul_f32 v74, v74, v104 ; c8c6d14b 4b4ad14a
	v_dual_fmac_f32 v105, v9, v9 :: v_dual_fmac_f32 v106, v11, v11 ; c8001309 696a170b
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_dual_fmac_f32 v106, v186, v186 :: v_dual_fmac_f32 v105, v184, v184 ; c80175ba 6a6971b8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v106, v6, v6 :: v_dual_fmac_f32 v105, v4, v4 ; c8000d06 6a680904
	v_dual_fmac_f32 v106, v190, v190 :: v_dual_fmac_f32 v105, v188, v188 ; c8017dbe 6a6979bc
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v106, v10, v10 :: v_dual_fmac_f32 v105, v8, v8 ; c800150a 6a681108
	v_fma_mixlo_f16 v107, 1.0, v105, v106                       ; cc21006b 05aad2f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v108, v107                                ; 7ed8d76b
	v_permlanex16_b32 v108, v108, s61, s62 op_sel:[1,1]         ; d65c186c 00f87b6c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v107, v107, v108                              ; 64d6d96b
	v_max_num_f16_e32 v107, s63, v107                           ; 62d6d63f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f32_f16_e32 v109, v107                                ; 7eda176b
	ds_load_b64 v[76:77], v18 offset:512                        ; d9d80200 4c000012
	ds_load_b64 v[78:79], v18 offset:4608                       ; d9d81200 4e000012
	ds_load_b64 v[104:105], v18 offset:8704                     ; d9d82200 68000012
	ds_load_b64 v[106:107], v18 offset:12800                    ; d9d83200 6a000012
	v_rsq_f32_e32 v109, v109                                    ; 7eda5d6d
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v4, v4, v109 :: v_dual_mul_f32 v5, v5, v109  ; c8c6db04 0404db05
	v_dual_mul_f32 v7, v7, v109 :: v_dual_mul_f32 v6, v6, v109  ; c8c6db07 0706db06
	v_dual_mul_f32 v184, v184, v109 :: v_dual_mul_f32 v185, v185, v109 ; c8c6dbb8 b8b8dbb9
	v_dual_mul_f32 v186, v186, v109 :: v_dual_mul_f32 v187, v187, v109 ; c8c6dbba babadbbb
	v_dual_mul_f32 v9, v9, v109 :: v_dual_mul_f32 v8, v8, v109  ; c8c6db09 0908db08
	v_dual_mul_f32 v188, v188, v109 :: v_dual_mul_f32 v189, v189, v109 ; c8c6dbbc bcbcdbbd
	v_dual_mul_f32 v11, v11, v109 :: v_dual_mul_f32 v10, v10, v109 ; c8c6db0b 0b0adb0a
	v_dual_mul_f32 v190, v190, v109 :: v_dual_mul_f32 v191, v191, v109 ; c8c6dbbe bebedbbf
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                        ; 02020b04
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	ds_load_b64 v[6:7], v18 offset:768                          ; d9d80300 06000012
	ds_load_b64 v[8:9], v18 offset:4864                         ; d9d81300 08000012
	ds_load_b64 v[10:11], v18 offset:8960                       ; d9d82300 0a000012
	ds_load_b64 v[108:109], v18 offset:13056                    ; d9d83300 6c000012
	ds_load_b64 v[128:129], v18 offset:1024                     ; d9d80400 80000012
	ds_load_b64 v[130:131], v18 offset:5120                     ; d9d81400 82000012
	s_wait_loadcnt_dscnt 0x911                                  ; bfc80911
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[148:149], 0 ; cc464070 1a03290e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[14:15], v[150:151], 0 ; cc4640a8 1a032d0e
	v_dual_mov_b32 v15, v37 :: v_dual_mov_b32 v14, v36          ; ca100125 0f0e0124
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_dual_mov_b32 v111, v39 :: v_dual_mov_b32 v110, v38        ; ca100127 6f6e0126
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[148:149], 0 ; cc464078 1a032928
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[148:149], 0 ; cc464088 1a03292a
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[158:159], v[148:149], 0 ; cc4640a0 1a03299e
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[40:41], v[150:151], 0 ; cc4640b0 1a032d28
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[42:43], v[150:151], 0 ; cc4640b8 1a032d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[158:159], v[150:151], 0 ; cc464024 1a032d9e
	s_wait_loadcnt_dscnt 0x80d                                  ; bfc8080d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[154:155], v[132:133], v[112:119] ; cc464070 1dc3099a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[132:133], v[120:127] ; cc464078 1de3091e
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[132:133], v[136:143] ; cc464088 1e23092e
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[44:45], v[132:133], v[160:167] ; cc4640a0 1e83092c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[134:135], v[176:183] ; cc4640b0 1ec30d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[46:47], v[134:135], v[184:191] ; cc4640b8 1ee30d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[44:45], v[134:135], v[36:43] ; cc464024 1c930d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[154:155], v[134:135], v[168:175] ; cc4640a8 1ea30d9a
	s_wait_loadcnt_dscnt 0x709                                  ; bfc80709
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[76:77], v[84:85], v[112:119] ; cc464070 1dc2a94c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[78:79], v[84:85], v[120:127] ; cc464078 1de2a94e
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[104:105], v[84:85], v[136:143] ; cc464088 1e22a968
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[106:107], v[84:85], v[160:167] ; cc4640a0 1e82a96a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[78:79], v[86:87], v[176:183] ; cc4640b0 1ec2ad4e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[104:105], v[86:87], v[184:191] ; cc4640b8 1ee2ad68
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[106:107], v[86:87], v[36:43] ; cc464024 1c92ad6a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[76:77], v[86:87], v[168:175] ; cc4640a8 1ea2ad4c
	ds_load_b64 v[148:149], v18 offset:9216                     ; d9d82400 94000012
	ds_load_b64 v[150:151], v18 offset:13312                    ; d9d83400 96000012
	ds_load_b64 v[30:31], v18 offset:1280                       ; d9d80500 1e000012
	ds_load_b64 v[44:45], v18 offset:5376                       ; d9d81500 2c000012
	ds_load_b64 v[46:47], v18 offset:9472                       ; d9d82500 2e000012
	ds_load_b64 v[132:133], v18 offset:13568                    ; d9d83500 84000012
	ds_load_b64 v[76:77], v18 offset:1536                       ; d9d80600 4c000012
	ds_load_b64 v[78:79], v18 offset:5632                       ; d9d81600 4e000012
	ds_load_b64 v[84:85], v18 offset:9728                       ; d9d82600 54000012
	ds_load_b64 v[86:87], v18 offset:13824                      ; d9d83600 56000012
	s_wait_loadcnt_dscnt 0x60f                                  ; bfc8060f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[6:7], v[48:49], v[112:119] ; cc464070 1dc26106
	v_dual_mov_b32 v135, v153 :: v_dual_mov_b32 v134, v152      ; ca100199 87860198
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[6:7], v[50:51], v[168:175] ; cc4640a8 1ea26506
	v_dual_mov_b32 v7, v68 :: v_dual_mov_b32 v6, v66            ; ca100144 07060142
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[104:107], v68, s[36:39], null offen offset:21504 ; c405c07c 40804868 00540044
	buffer_load_b128 v[156:159], v68, s[36:39], null offen offset:22016 ; c405c07c 4080489c 00560044
	buffer_load_b128 v[152:155], v68, s[36:39], null offen offset:22528 ; c405c07c 40804898 00580044
	buffer_load_b128 v[66:69], v68, s[36:39], null offen offset:23040 ; c405c07c 40804842 005a0044
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[8:9], v[48:49], v[120:127] ; cc464078 1de26108
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[48:49], v[136:143] ; cc464088 1e22610a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[108:109], v[48:49], v[160:167] ; cc4640a0 1e82616c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[8:9], v[50:51], v[176:183] ; cc4640b0 1ec26508
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[10:11], v[50:51], v[184:191] ; cc4640b8 1ee2650a
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[108:109], v[50:51], v[36:43] ; cc464024 1c92656c
	s_wait_loadcnt_dscnt 0x90b                                  ; bfc8090b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[128:129], v[52:53], v[112:119] ; cc464070 1dc26980
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[128:129], v[54:55], v[168:175] ; cc4640a8 1ea26d80
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[130:131], v[52:53], v[120:127] ; cc464078 1de26982
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[148:149], v[52:53], v[136:143] ; cc464088 1e226994
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[150:151], v[52:53], v[160:167] ; cc4640a0 1e826996
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[130:131], v[54:55], v[176:183] ; cc4640b0 1ec26d82
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[148:149], v[54:55], v[184:191] ; cc4640b8 1ee26d94
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[150:151], v[54:55], v[36:43] ; cc464024 1c926d96
	ds_load_b64 v[8:9], v18 offset:1792                         ; d9d80700 08000012
	ds_load_b64 v[10:11], v18 offset:5888                       ; d9d81700 0a000012
	ds_load_b64 v[48:49], v18 offset:9984                       ; d9d82700 30000012
	ds_load_b64 v[50:51], v18 offset:14080                      ; d9d83700 32000012
	ds_load_b64 v[52:53], v18 offset:2048                       ; d9d80800 34000012
	ds_load_b64 v[54:55], v18 offset:6144                       ; d9d81800 36000012
	ds_load_b64 v[108:109], v18 offset:10240                    ; d9d82800 6c000012
	ds_load_b64 v[128:129], v18 offset:14336                    ; d9d83800 80000012
	s_wait_loadcnt_dscnt 0x80f                                  ; bfc8080f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[88:89], v[112:119] ; cc464070 1dc2b11e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[88:89], v[120:127] ; cc464078 1de2b12c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[30:31], v[90:91], v[168:175] ; cc4640a8 1ea2b51e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[88:89], v[136:143] ; cc464088 1e22b12e
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[132:133], v[88:89], v[160:167] ; cc4640a0 1e82b184
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[44:45], v[90:91], v[176:183] ; cc4640b0 1ec2b52c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[46:47], v[90:91], v[184:191] ; cc4640b8 1ee2b52e
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[132:133], v[90:91], v[36:43] ; cc464024 1c92b584
	s_wait_loadcnt_dscnt 0x70b                                  ; bfc8070b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[76:77], v[92:93], v[112:119] ; cc464070 1dc2b94c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[78:79], v[92:93], v[120:127] ; cc464078 1de2b94e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[76:77], v[94:95], v[168:175] ; cc4640a8 1ea2bd4c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[84:85], v[92:93], v[136:143] ; cc464088 1e22b954
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[86:87], v[92:93], v[160:167] ; cc4640a0 1e82b956
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[78:79], v[94:95], v[176:183] ; cc4640b0 1ec2bd4e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[84:85], v[94:95], v[184:191] ; cc4640b8 1ee2bd54
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[86:87], v[94:95], v[36:43] ; cc464024 1c92bd56
	ds_load_b64 v[30:31], v18 offset:2304                       ; d9d80900 1e000012
	ds_load_b64 v[44:45], v18 offset:6400                       ; d9d81900 2c000012
	ds_load_b64 v[46:47], v18 offset:10496                      ; d9d82900 2e000012
	ds_load_b64 v[88:89], v18 offset:14592                      ; d9d83900 58000012
	ds_load_b64 v[76:77], v18 offset:2560                       ; d9d80a00 4c000012
	ds_load_b64 v[78:79], v18 offset:6656                       ; d9d81a00 4e000012
	ds_load_b64 v[84:85], v18 offset:10752                      ; d9d82a00 54000012
	ds_load_b64 v[86:87], v18 offset:14848                      ; d9d83a00 56000012
	s_wait_loadcnt_dscnt 0x60f                                  ; bfc8060f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[8:9], v[60:61], v[112:119] ; cc464070 1dc27908
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[60:61], v[120:127] ; cc464078 1de2790a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[8:9], v[62:63], v[168:175] ; cc4640a8 1ea27d08
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[48:49], v[60:61], v[136:143] ; cc464088 1e227930
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[60:61], v[160:167] ; cc4640a0 1e827932
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[10:11], v[62:63], v[176:183] ; cc4640b0 1ec27d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[48:49], v[62:63], v[184:191] ; cc4640b8 1ee27d30
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[50:51], v[62:63], v[36:43] ; cc464024 1c927d32
	ds_load_b64 v[8:9], v18 offset:2816                         ; d9d80b00 08000012
	ds_load_b64 v[10:11], v18 offset:6912                       ; d9d81b00 0a000012
	ds_load_b64 v[48:49], v18 offset:11008                      ; d9d82b00 30000012
	ds_load_b64 v[50:51], v18 offset:15104                      ; d9d83b00 32000012
	ds_load_b64 v[60:61], v18 offset:3072                       ; d9d80c00 3c000012
	ds_load_b64 v[62:63], v18 offset:7168                       ; d9d81c00 3e000012
	ds_load_b64 v[90:91], v18 offset:11264                      ; d9d82c00 5a000012
	ds_load_b64 v[92:93], v18 offset:15360                      ; d9d83c00 5c000012
	ds_load_b64 v[94:95], v18 offset:3328                       ; d9d80d00 5e000012
	ds_load_b64 v[130:131], v18 offset:7424                     ; d9d81d00 82000012
	ds_load_b64 v[132:133], v18 offset:11520                    ; d9d82d00 84000012
	ds_load_b64 v[148:149], v18 offset:15616                    ; d9d83d00 94000012
	s_wait_loadcnt_dscnt 0x517                                  ; bfc80517
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[52:53], v[96:97], v[112:119] ; cc464070 1dc2c134
	s_wait_dscnt 0x16                                           ; bfc60016
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[96:97], v[120:127] ; cc464078 1de2c136
	s_wait_dscnt 0x15                                           ; bfc60015
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[96:97], v[136:143] ; cc464088 1e22c16c
	s_wait_dscnt 0x14                                           ; bfc60014
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[128:129], v[96:97], v[160:167] ; cc4640a0 1e82c180
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[98:99], v[168:175] ; cc4640a8 1ea2c534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[98:99], v[176:183] ; cc4640b0 1ec2c536
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[108:109], v[98:99], v[184:191] ; cc4640b8 1ee2c56c
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[128:129], v[98:99], v[36:43] ; cc464024 1c92c580
	s_wait_loadcnt_dscnt 0x413                                  ; bfc80413
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[100:101], v[112:119] ; cc464070 1dc2c91e
	s_wait_dscnt 0x12                                           ; bfc60012
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[100:101], v[120:127] ; cc464078 1de2c92c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[30:31], v[102:103], v[168:175] ; cc4640a8 1ea2cd1e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[44:45], v[102:103], v[176:183] ; cc4640b0 1ec2cd2c
	ds_load_b64 v[96:97], v18 offset:3584                       ; d9d80e00 60000012
	ds_load_b64 v[52:53], v18 offset:7680                       ; d9d81e00 34000012
	ds_load_b64 v[54:55], v18 offset:11776                      ; d9d82e00 36000012
	ds_load_b64 v[108:109], v18 offset:15872                    ; d9d83e00 6c000012
	ds_load_b64 v[98:99], v18 offset:3840                       ; d9d80f00 62000012
	ds_load_b64 v[30:31], v18 offset:7936                       ; d9d81f00 1e000012
	ds_load_b64 v[44:45], v18 offset:12032                      ; d9d82f00 2c000012
	ds_load_b64 v[18:19], v18 offset:16128                      ; d9d83f00 12000012
	s_wait_dscnt 0x19                                           ; bfc60019
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[100:101], v[136:143] ; cc464088 1e22c92e
	s_wait_dscnt 0x18                                           ; bfc60018
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[88:89], v[100:101], v[160:167] ; cc4640a0 1e82c958
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[46:47], v[102:103], v[184:191] ; cc4640b8 1ee2cd2e
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[88:89], v[102:103], v[36:43] ; cc464024 1c92cd58
	s_wait_dscnt 0x1                                            ; bfc60001
	v_dual_mov_b32 v89, v45 :: v_dual_mov_b32 v88, v44          ; ca10012d 5958012c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[100:103], v7, s[36:39], null offen offset:23552 ; c405c07c 40804864 005c0007
	buffer_load_b128 v[44:47], v7, s[36:39], null offen offset:24064 ; c405c07c 4080482c 005e0007
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[84:85], v[104:105], v[136:143] ; cc464088 1e22d154
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[86:87], v[104:105], v[160:167] ; cc4640a0 1e82d156
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[76:77], v[104:105], v[112:119] ; cc464070 1dc2d14c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[78:79], v[104:105], v[120:127] ; cc464078 1de2d14e
	v_dual_mov_b32 v128, v108 :: v_dual_mov_b32 v129, v109      ; ca10016c 8080016d
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[76:77], v[106:107], v[168:175] ; cc4640a8 1ea2d54c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[84:85], v[106:107], v[184:191] ; cc4640b8 1ee2d554
	v_mov_b32_e32 v84, v72                                      ; 7ea80348
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[78:79], v[106:107], v[176:183] ; cc4640b0 1ec2d54e
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[86:87], v[106:107], v[36:43] ; cc464024 1c92d556
	v_dual_mov_b32 v86, v74 :: v_dual_mov_b32 v85, v73          ; ca10014a 56540149
	v_dual_mov_b32 v150, v110 :: v_dual_mov_b32 v151, v111      ; ca10016e 9696016f
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[48:49], v[156:157], v[136:143] ; cc464088 1e233930
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[156:157], v[160:167] ; cc4640a0 1e833932
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[8:9], v[156:157], v[112:119] ; cc464070 1dc33908
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[156:157], v[120:127] ; cc464078 1de3390a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[8:9], v[158:159], v[168:175] ; cc4640a8 1ea33d08
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[64:65], v[32:33], 0 ; cc464068 1a024140
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[48:49], v[158:159], v[184:191] ; cc4640b8 1ee33d30
	v_dual_mov_b32 v48, v6 :: v_dual_mov_b32 v87, v75           ; ca100106 3056014b
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[32:33], 0 ; cc464048 1a02411a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[10:11], v[158:159], v[176:183] ; cc4640b0 1ec33d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[50:51], v[158:159], v[36:43] ; cc464024 1c933d32
	v_dual_mov_b32 v50, v13 :: v_dual_mov_b32 v49, v12          ; ca10010d 3230010c
	v_lshl_add_u32 v51, v1, 12, s8                              ; d6460033 00211901
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[90:91], v[152:153], v[136:143] ; cc464088 1e23315a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[92:93], v[152:153], v[160:167] ; cc4640a0 1e83315c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[60:61], v[152:153], v[112:119] ; cc464070 1dc3313c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[62:63], v[152:153], v[120:127] ; cc464078 1de3313e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[154:155], v[168:175] ; cc4640a8 1ea3353c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[90:91], v[154:155], v[184:191] ; cc4640b8 1ee3355a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[154:155], v[176:183] ; cc4640b0 1ec3353e
	v_lshl_add_u32 v144, v144, 6, v51                           ; d6460090 04cd0d90
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[92:93], v[154:155], v[36:43] ; cc464024 1c93355c
	v_add_lshl_u32 v144, v144, v3, 2                            ; d6470090 020a0790
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v144, s[32:35], null offen       ; c405c07c 4080403c 00000090
	buffer_load_b128 v[90:93], v144, s[32:35], null offen offset:16 ; c405c07c 4080405a 00001090
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[82:83], v[32:33], 0  ; cc464006 1a024152
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[32:33], 0 ; cc464098 1a024156
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[34:35], v[72:79] ; cc464048 1d22451c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[84:85], v[34:35], v[104:111] ; cc464068 1da24554
	s_mov_b32 s64, 0x3d380000                                   ; bec000ff 3d380000
	s_movk_i32 s65, 0x3e47                                      ; b0413e47
	s_movk_i32 s66, 0x3c20                                      ; b0423c20
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[94:95], v[66:67], v[112:119] ; cc464070 1dc2855e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[130:131], v[66:67], v[120:127] ; cc464078 1de28582
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[132:133], v[66:67], v[136:143] ; cc464088 1e228584
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[148:149], v[66:67], v[160:167] ; cc4640a0 1e828594
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[94:95], v[68:69], v[168:175] ; cc4640a8 1ea2895e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[130:131], v[68:69], v[176:183] ; cc4640b0 1ec28982
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[132:133], v[68:69], v[184:191] ; cc4640b8 1ee28984
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[148:149], v[68:69], v[36:43] ; cc464024 1c928994
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[58:59], v[34:35], v[6:13] ; cc464006 1c1a453a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[4:5], v[34:35], v[152:159] ; cc464098 1e624504
	s_mov_b32 s67, 0x7ff88000                                   ; bec300ff 7ff88000
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[96:97], v[100:101], v[112:119] ; cc464070 1dc2c960
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[52:53], v[100:101], v[120:127] ; cc464078 1de2c934
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[52:53], v[102:103], v[176:183] ; cc4640b0 1ec2cd34
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[96:97], v[102:103], v[168:175] ; cc4640a8 1ea2cd60
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[128:129], v[100:101], v[160:167] ; cc4640a0 1e82c980
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[54:55], v[100:101], v[136:143] ; cc464088 1e22c936
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[102:103], v[184:191] ; cc4640b8 1ee2cd36
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[128:129], v[102:103], v[36:43] ; cc464024 1c92cd80
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[98:99], v[44:45], v[112:119] ; cc464070 1dc25962
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[44:45], v[120:127] ; cc464078 1de2591e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[46:47], v[176:183] ; cc4640b0 1ec25d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[98:99], v[46:47], v[168:175] ; cc4640a8 1ea25d62
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[18:19], v[44:45], v[160:167] ; cc4640a0 1e825912
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[88:89], v[44:45], v[136:143] ; cc464088 1e225958
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[88:89], v[46:47], v[184:191] ; cc4640b8 1ee25d58
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[18:19], v[46:47], v[36:43] ; cc464024 1c925d12
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_dual_mov_b32 v94, v123 :: v_dual_mov_b32 v89, v122        ; ca10017b 5e58017a
	v_mov_b32_e32 v51, v135                                     ; 7e660387
	v_mov_b32_e32 v95, v134                                     ; 7ebe0386
	v_mov_b16_e32 v88.l, v32.l                                  ; 7eb03920
	s_clause 0xc                                                ; bf85000c
	buffer_load_b128 v[44:47], v144, s[32:35], null offen offset:64 ; c405c07c 4080402c 00004090
	buffer_load_b128 v[52:55], v144, s[32:35], null offen offset:80 ; c405c07c 40804034 00005090
	buffer_load_b128 v[96:99], v144, s[32:35], null offen offset:128 ; c405c07c 40804060 00008090
	buffer_load_b128 v[100:103], v144, s[32:35], null offen offset:144 ; c405c07c 40804064 00009090
	buffer_load_b128 v[112:115], v144, s[32:35], null offen offset:192 ; c405c07c 40804070 0000c090
	buffer_load_b128 v[116:119], v144, s[32:35], null offen offset:208 ; c405c07c 40804074 0000d090
	buffer_load_b128 v[128:131], v144, s[32:35], null offen offset:4096 ; c405c07c 40804080 00100090
	buffer_load_b128 v[168:171], v144, s[32:35], null offen offset:4112 ; c405c07c 408040a8 00101090
	buffer_load_b128 v[172:175], v144, s[32:35], null offen offset:4160 ; c405c07c 408040ac 00104090
	buffer_load_b128 v[66:69], v144, s[32:35], null offen offset:4176 ; c405c07c 40804042 00105090
	buffer_load_b128 v[32:35], v144, s[32:35], null offen offset:4224 ; c405c07c 40804020 00108090
	buffer_load_b128 v[120:123], v144, s[32:35], null offen offset:4240 ; c405c07c 40804078 00109090
	buffer_load_b128 v[132:135], v144, s[32:35], null offen offset:4288 ; c405c07c 40804084 0010c090
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	v_mov_b32_e32 v38, v145                                     ; 7e4c0391
(invalid instruction)                                        ; d7694094
	v_cndmask_b32_e32 v1, v89, v94, vcc_lo                      ; 0202bd59
	v_mov_b32_e32 v94, v144                                     ; 7ebc0390
(invalid instruction)                                        ; d7690095
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694095
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d59c0094
	v_cndmask_b32_e32 v0, v88, v128, vcc_lo                     ; 02010158
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d769007c
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769407c
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769007d
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769407d
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
	buffer_load_b128 v[40:43], v94, s[32:35], null offen offset:4304 ; c405c07c 40804028 0010d05e
(invalid instruction)                                        ; d769007e
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d769407e
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d769007f
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d769407f
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
(invalid instruction)                                        ; d7690088
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694088
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690089
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694089
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[26:27], v[14:15], 0 ; cc4640a0 1a021d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[82:83], v[14:15], 0 ; cc4640b0 1a021d52
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[14:15], 0 ; cc4640b8 1a021d40
	v_wmma_f32_16x16x16_fp8_fp8 v[138:145], v[86:87], v[14:15], 0 ; cc46408a 1a021d56
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[28:29], v[80:81], v[160:167] ; cc4640a0 1e82a11c
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_fma_mixlo_f16 v39, s64, v72, v60                          ; cc210027 04f29040
	v_fma_mixhi_f16 v39, s64, v73, v61                          ; cc220027 04f69240
	v_dual_mov_b32 v61, v70 :: v_dual_mov_b32 v14, v77          ; ca100146 3d0e014d
	v_fma_mixlo_f16 v60, s64, v74, v62                          ; cc21003c 04fa9440
	v_fma_mixhi_f16 v60, s64, v75, v63                          ; cc22003c 04fe9640
	v_dual_mov_b32 v63, v76 :: v_dual_mov_b32 v62, v71          ; ca10014c 3f3e0147
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[58:59], v[80:81], v[176:183] ; cc4640b0 1ec2a13a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[84:85], v[80:81], v[184:191] ; cc4640b8 1ee2a154
	v_wmma_f32_16x16x16_fp8_fp8 v[138:145], v[4:5], v[80:81], v[138:145] ; cc46408a 1e2aa104
(invalid instruction)                                        ; cc1c0027
	v_subrev_f32_e32 v0, v39, v66                               ; 0a008527
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v66                               ; 0a00853c
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v15, s64, v63, v90                          ; cc21000f 056a7e40
	v_fma_mixlo_f16 v63, s64, v78, v92                          ; cc21003f 05729c40
	v_fma_mixhi_f16 v63, s64, v79, v93                          ; cc22003f 05769e40
	v_dual_mov_b32 v93, v13 :: v_dual_mov_b32 v92, v12          ; ca10010d 5d5c010c
	v_fma_mixhi_f16 v15, s64, v14, v91                          ; cc22000f 056e1c40
	v_dual_mov_b32 v91, v11 :: v_dual_mov_b32 v90, v10          ; ca10010b 5b5a010a
	v_wmma_f32_16x16x16_fp8_fp8 v[70:77], v[26:27], v[150:151], 0 ; cc464046 1a032d1a
(invalid instruction)                                        ; cc1b0027
	v_subrev_f32_e32 v0, v39, v65                               ; 0a008327
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v65                               ; 0a00833c
(invalid instruction)                                        ; cc1c003f
	v_subrev_f32_e32 v0, v63, v66                               ; 0a00853f
(invalid instruction)                                        ; cc1c000f
	v_subrev_f32_e32 v0, v15, v66                               ; 0a00850f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
	v_lshl_add_u32 v39, v39, 5, s67                             ; d6460027 010d0b27
	v_lshl_add_u32 v60, v60, 5, s67                             ; d646003c 010d0b3c
(invalid instruction)                                        ; cc1b003f
	v_subrev_f32_e32 v0, v63, v65                               ; 0a00833f
(invalid instruction)                                        ; cc1b000f
	v_subrev_f32_e32 v0, v15, v65                               ; 0a00830f
	v_lshl_add_u32 v63, v63, 5, s67                             ; d646003f 010d0b3f
	v_lshl_add_u32 v15, v15, 5, s67                             ; d646000f 010d0b0f
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_fma_mixlo_f16 v79, s64, v8, v46                           ; cc21004f 04ba1040
	v_fma_mixhi_f16 v79, s64, v9, v47                           ; cc22004f 04be1240
	v_fma_mixlo_f16 v78, s64, v6, v44                           ; cc21004e 04b20c40
	v_fma_mixhi_f16 v78, s64, v7, v45                           ; cc22004e 04b60e40
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v44, s64, v92, v54                          ; cc21002c 04dab840
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[82:83], v[150:151], 0 ; cc464006 1a032d52
	v_fma_mixlo_f16 v14, s64, v90, v52                          ; cc21000e 04d2b440
	v_fma_mixhi_f16 v14, s64, v91, v53                          ; cc22000e 04d6b640
	v_dual_mov_b32 v54, v95 :: v_dual_mov_b32 v53, v94          ; ca10015f 3634015e
	v_fma_mixhi_f16 v44, s64, v93, v55                          ; cc22002c 04deba40
(invalid instruction)                                        ; cc1c004f
	v_subrev_f32_e32 v0, v79, v66                               ; 0a00854f
(invalid instruction)                                        ; cc1c004e
	v_subrev_f32_e32 v0, v78, v66                               ; 0a00854e
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v47, s64, v104, v96                         ; cc21002f 0582d040
	v_fma_mixhi_f16 v47, s64, v105, v97                         ; cc22002f 0586d240
(invalid instruction)                                        ; cc1c000e
	v_subrev_f32_e32 v0, v14, v66                               ; 0a00850e
(invalid instruction)                                        ; cc1c002c
	v_subrev_f32_e32 v0, v44, v66                               ; 0a00852c
	v_fma_mixlo_f16 v52, s64, v106, v98                         ; cc210034 058ad440
	v_fma_mixhi_f16 v52, s64, v107, v99                         ; cc220034 058ed640
(invalid instruction)                                        ; cc1b004f
	v_subrev_f32_e32 v0, v79, v65                               ; 0a00834f
(invalid instruction)                                        ; cc1b004e
	v_subrev_f32_e32 v0, v78, v65                               ; 0a00834e
(invalid instruction)                                        ; cc1c002f
	v_subrev_f32_e32 v0, v47, v66                               ; 0a00852f
(invalid instruction)                                        ; cc1b000e
	v_subrev_f32_e32 v0, v14, v65                               ; 0a00830e
(invalid instruction)                                        ; cc1b002c
	v_subrev_f32_e32 v0, v44, v65                               ; 0a00832c
	v_wmma_f32_16x16x16_fp8_fp8 v[90:97], v[64:65], v[150:151], 0 ; cc46405a 1a032d40
(invalid instruction)                                        ; cc1c0034
	v_subrev_f32_e32 v0, v52, v66                               ; 0a008534
	v_lshl_add_u32 v79, v79, 5, s67                             ; d646004f 010d0b4f
	v_lshl_add_u32 v78, v78, 5, s67                             ; d646004e 010d0b4e
(invalid instruction)                                        ; cc1b002f
	v_subrev_f32_e32 v0, v47, v65                               ; 0a00832f
	v_lshl_add_u32 v14, v14, 5, s67                             ; d646000e 010d0b0e
	v_lshl_add_u32 v44, v44, 5, s67                             ; d646002c 010d0b2c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v55, s64, v108, v100                        ; cc210037 0592d840
	v_fma_mixhi_f16 v55, s64, v109, v101                        ; cc220037 0596da40
	v_fma_mixlo_f16 v98, s64, v110, v102                        ; cc210062 059adc40
	v_fma_mixhi_f16 v98, s64, v111, v103                        ; cc220062 059ede40
(invalid instruction)                                        ; cc1b0034
	v_subrev_f32_e32 v0, v52, v65                               ; 0a008334
(invalid instruction)                                        ; cc0f0051
	v_min_num_f64_e32 v[1:2], v[60:61], v[79:80]                ; 1a029f3c
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[39:40], v[78:79]                ; 1a029d27
	v_lshl_add_u32 v47, v47, 5, s67                             ; d646002f 010d0b2f
	buffer_load_b128 v[100:103], v53, s[32:35], null offen offset:8192 ; c405c07c 40804064 00200035
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[15:16], v[14:15]                ; 1a021d0f
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[63:64], v[44:45]                ; 1a02593f
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[86:87], v[150:151], 0 ; cc464068 1a032d56
(invalid instruction)                                        ; cc1c0037
	v_subrev_f32_e32 v0, v55, v66                               ; 0a008537
	v_wmma_f32_16x16x16_fp8_fp8 v[70:77], v[28:29], v[20:21], v[70:77] ; cc464046 1d1a291c
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[58:59], v[20:21], v[6:13] ; cc464006 1c1a293a
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v66                               ; 0a008562
	v_wmma_f32_16x16x16_fp8_fp8 v[90:97], v[84:85], v[20:21], v[90:97] ; cc46405a 1d6a2954
	v_lshl_add_u32 v52, v52, 5, s67                             ; d6460034 010d0b34
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[47:48]                ; 1a025f50
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v99, s64, v152, v112                        ; cc210063 05c33040
	v_fma_mixhi_f16 v99, s64, v153, v113                        ; cc220063 05c73240
(invalid instruction)                                        ; cc1b0037
	v_subrev_f32_e32 v0, v55, v65                               ; 0a008337
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[4:5], v[20:21], v[104:111] ; cc464068 1da22904
	v_fma_mixlo_f16 v112, s64, v154, v114                       ; cc210070 05cb3440
(invalid instruction)                                        ; cc1b0062
	v_subrev_f32_e32 v0, v98, v65                               ; 0a008362
	v_fma_mixhi_f16 v112, s64, v155, v115                       ; cc220070 05cf3640
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v113, s64, v156, v116                       ; cc210071 05d33840
(invalid instruction)                                        ; cc0f0051
	v_min_num_f64_e32 v[1:2], v[81:82], v[52:53]                ; 1a026951
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v66                               ; 0a008563
	v_lshl_add_u32 v55, v55, 5, s67                             ; d6460037 010d0b37
	v_fma_mixhi_f16 v113, s64, v157, v117                       ; cc220071 05d73a40
	v_fma_mixlo_f16 v114, s64, v158, v118                       ; cc210072 05db3c40
	v_fma_mixhi_f16 v114, s64, v159, v119                       ; cc220072 05df3e40
	v_lshl_add_u32 v98, v98, 5, s67                             ; d6460062 010d0b62
(invalid instruction)                                        ; cc1c0070
	v_subrev_f32_e32 v0, v112, v66                              ; 0a008570
(invalid instruction)                                        ; cc1b0063
	v_subrev_f32_e32 v0, v99, v65                               ; 0a008363
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[55:56]                ; 1a026f2d
(invalid instruction)                                        ; cc1c0071
	v_subrev_f32_e32 v0, v113, v66                              ; 0a008571
(invalid instruction)                                        ; cc1c0072
	v_subrev_f32_e32 v0, v114, v66                              ; 0a008572
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[98:99]                ; 1a02c52e
(invalid instruction)                                        ; cc1b0070
	v_subrev_f32_e32 v0, v112, v65                              ; 0a008370
	v_lshl_add_u32 v99, v99, 5, s67                             ; d6460063 010d0b63
(invalid instruction)                                        ; cc1b0071
	v_subrev_f32_e32 v0, v113, v65                              ; 0a008371
(invalid instruction)                                        ; cc1b0072
	v_subrev_f32_e32 v0, v114, v65                              ; 0a008372
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_lshl_add_u32 v112, v112, 5, s67                           ; d6460070 010d0b70
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[99:100]               ; 1a02c750
	v_lshl_add_u32 v113, v113, 5, s67                           ; d6460071 010d0b71
	v_lshl_add_u32 v114, v114, 5, s67                           ; d6460072 010d0b72
(invalid instruction)                                        ; cc0f0051
	v_min_num_f64_e32 v[1:2], v[81:82], v[112:113]              ; 1a02e151
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
(invalid instruction)                                        ; cc0f002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[113:114]              ; 1a02e32d
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[114:115]              ; 1a02e52e
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[81:82]                ; 1a02a350
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[45:46]                ; 1a025b50
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[46:47]                ; 1a025d50
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v115, v80, s61, s62 op_sel:[1,1]          ; d65c1873 00f87b50
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[115:116]              ; 1a02e750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v116, v80, v208/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64e9a150
	v_max_num_f16_e32 v116, s60, v116                           ; 62e8e83c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v117, v116                                ; 7eea1774
	v_rcp_f32_e32 v117, v117                                    ; 7eea5575
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v150, v15, v117, neg(0) op_sel_hi:[1,0,0]     ; cc200096 8a02eb0f
	v_fma_mix_f32 v15, v15, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080f 8a02eb0f
	v_fma_mix_f32 v152, v78, v117, neg(0) op_sel_hi:[1,0,0]     ; cc200098 8a02eb4e
	v_fma_mix_f32 v78, v78, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084e 8a02eb4e
	v_fma_mix_f32 v119, v60, v117, neg(0) op_sel_hi:[1,0,0]     ; cc200077 8a02eb3c
	v_fma_mix_f32 v60, v60, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083c 8a02eb3c
	v_fma_mix_f32 v151, v63, v117, neg(0) op_sel_hi:[1,0,0]     ; cc200097 8a02eb3f
	v_fma_mix_f32 v118, v39, v117, neg(0) op_sel_hi:[1,0,0]     ; cc200076 8a02eb27
	v_fma_mix_f32 v153, v79, v117, neg(0) op_sel_hi:[1,0,0]     ; cc200099 8a02eb4f
	v_fma_mix_f32 v63, v63, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083f 8a02eb3f
	v_fma_mix_f32 v39, v39, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200827 8a02eb27
	v_fma_mix_f32 v79, v79, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084f 8a02eb4f
	v_fma_mix_f32 v154, v14, v117, neg(0) op_sel_hi:[1,0,0]     ; cc20009a 8a02eb0e
	v_fma_mix_f32 v14, v14, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080e 8a02eb0e
	v_fma_mix_f32 v155, v44, v117, neg(0) op_sel_hi:[1,0,0]     ; cc20009b 8a02eb2c
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v150, v15, vcc_lo                     ; 02021f96
	v_fma_mix_f32 v44, v44, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082c 8a02eb2c
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v152, v78, vcc_lo                     ; 02029d98
	v_fma_mix_f32 v156, v47, v117, neg(0) op_sel_hi:[1,0,0]     ; cc20009c 8a02eb2f
	v_fma_mix_f32 v47, v47, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082f 8a02eb2f
	v_fma_mix_f32 v157, v52, v117, neg(0) op_sel_hi:[1,0,0]     ; cc20009d 8a02eb34
	v_fma_mix_f32 v52, v52, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200834 8a02eb34
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v154, v14, vcc_lo                     ; 02021d9a
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v155, v44, vcc_lo                     ; 0202599b
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v156, v47, vcc_lo                     ; 02025f9c
	buffer_load_b128 v[44:47], v53, s[32:35], null offen offset:8208 ; c405c07c 4080402c 00201035
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v151, v63, vcc_lo                     ; 02027f97
	v_fma_mix_f32 v158, v55, v117, neg(0) op_sel_hi:[1,0,0]     ; cc20009e 8a02eb37
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v118, v39, vcc_lo                     ; 02024f76
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v119, v60, vcc_lo                     ; 02027977
	v_fma_mix_f32 v55, v55, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200837 8a02eb37
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v153, v79, vcc_lo                     ; 02029f99
	v_fma_mix_f32 v159, v98, v117, neg(0) op_sel_hi:[1,0,0]     ; cc20009f 8a02eb62
	v_fma_mix_f32 v98, v98, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200862 8a02eb62
	v_fma_mix_f32 v39, v99, v117, neg(0) op_sel_hi:[1,0,0]      ; cc200027 8a02eb63
	v_fma_mix_f32 v99, v99, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200863 8a02eb63
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v157, v52, vcc_lo                     ; 0202699d
	v_fma_mix_f32 v52, v112, v117, neg(0) op_sel_hi:[1,0,0]     ; cc200034 8a02eb70
	v_fma_mix_f32 v112, v112, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200870 8a02eb70
	v_fma_mix_f32 v60, v114, v117, neg(0) op_sel_hi:[1,0,0]     ; cc20003c 8a02eb72
	v_fma_mix_f32 v114, v114, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200872 8a02eb72
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v158, v55, vcc_lo                     ; 02026f9e
	v_fma_mix_f32 v55, v113, v117, neg(0) op_sel_hi:[1,0,0]     ; cc200037 8a02eb71
	v_fma_mix_f32 v113, v113, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200871 8a02eb71
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v39, v99, vcc_lo                      ; 0202c727
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v52, v112, vcc_lo                     ; 0202e134
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v55, v113, vcc_lo                     ; 0202e337
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v60, v114, vcc_lo                     ; 0202e53c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[112:115], v53, s[32:35], null offen offset:8256 ; c405c07c 40804070 00204035
	buffer_load_b128 v[116:119], v53, s[32:35], null offen offset:8272 ; c405c07c 40804074 00205035
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v63, s64, v160, v128                        ; cc21003f 06034040
	v_fma_mixhi_f16 v63, s64, v161, v129                        ; cc22003f 06074240
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v159, v98, vcc_lo                     ; 0202c59f
	v_fma_mixlo_f16 v98, s64, v162, v130                        ; cc210062 060b4440
	v_fma_mixhi_f16 v98, s64, v163, v131                        ; cc220062 060f4640
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v99, s64, v164, v168                        ; cc210063 06a34840
	v_fma_mixhi_f16 v99, s64, v165, v169                        ; cc220063 06a74a40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[152:155], v53, s[32:35], null offen offset:8320 ; c405c07c 40804098 00208035
	buffer_load_b128 v[156:159], v53, s[32:35], null offen offset:8336 ; c405c07c 4080409c 00209035
	v_fma_mixlo_f16 v128, s64, v166, v170                       ; cc210080 06ab4c40
	v_fma_mixhi_f16 v128, s64, v167, v171                       ; cc220080 06af4e40
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v129, s64, v176, v172                       ; cc210081 06b36040
	v_fma_mixhi_f16 v129, s64, v177, v173                       ; cc220081 06b76240
(invalid instruction)                                        ; cc1c003f
	v_subrev_f32_e32 v0, v63, v66                               ; 0a00853f
	v_fma_mixlo_f16 v130, s64, v178, v174                       ; cc210082 06bb6440
	v_fma_mixhi_f16 v130, s64, v179, v175                       ; cc220082 06bf6640
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v66                               ; 0a008562
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v66                               ; 0a008563
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v131, s64, v180, v66                        ; cc210083 050b6840
	v_fma_mixhi_f16 v131, s64, v181, v67                        ; cc220083 050f6a40
	v_fma_mixlo_f16 v150, s64, v182, v68                        ; cc210096 05136c40
(invalid instruction)                                        ; cc1c0080
	v_subrev_f32_e32 v0, v128, v66                              ; 0a008580
	v_fma_mixhi_f16 v150, s64, v183, v69                        ; cc220096 05176e40
(invalid instruction)                                        ; cc1c0081
	v_subrev_f32_e32 v0, v129, v66                              ; 0a008581
(invalid instruction)                                        ; cc1b003f
	v_subrev_f32_e32 v0, v63, v65                               ; 0a00833f
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[160:163], v53, s[32:35], null offen offset:8384 ; c405c07c 408040a0 0020c035
	buffer_load_b128 v[168:171], v53, s[32:35], null offen offset:8400 ; c405c07c 408040a8 0020d035
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v151, s64, v184, v32                        ; cc210097 04837040
	v_fma_mixhi_f16 v151, s64, v185, v33                        ; cc220097 04877240
(invalid instruction)                                        ; cc1c0082
	v_subrev_f32_e32 v0, v130, v66                              ; 0a008582
(invalid instruction)                                        ; cc1b0062
	v_subrev_f32_e32 v0, v98, v65                               ; 0a008362
(invalid instruction)                                        ; cc1b0063
	v_subrev_f32_e32 v0, v99, v65                               ; 0a008363
	v_fma_mixlo_f16 v164, s64, v186, v34                        ; cc2100a4 048b7440
(invalid instruction)                                        ; cc1c0083
	v_subrev_f32_e32 v0, v131, v66                              ; 0a008583
	v_fma_mixhi_f16 v164, s64, v187, v35                        ; cc2200a4 048f7640
(invalid instruction)                                        ; cc1b0080
	v_subrev_f32_e32 v0, v128, v65                              ; 0a008380
(invalid instruction)                                        ; cc1c0096
	v_subrev_f32_e32 v0, v150, v66                              ; 0a008596
(invalid instruction)                                        ; cc1b0081
	v_subrev_f32_e32 v0, v129, v65                              ; 0a008381
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v165, s64, v188, v120                       ; cc2100a5 05e37840
	v_fma_mixhi_f16 v165, s64, v189, v121                       ; cc2200a5 05e77a40
(invalid instruction)                                        ; cc1c0097
	v_subrev_f32_e32 v0, v151, v66                              ; 0a008597
	v_fma_mixlo_f16 v166, s64, v190, v122                       ; cc2100a6 05eb7c40
	v_fma_mixhi_f16 v166, s64, v191, v123                       ; cc2200a6 05ef7e40
(invalid instruction)                                        ; cc1b0082
	v_subrev_f32_e32 v0, v130, v65                              ; 0a008382
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v167, s64, v138, v132                       ; cc2100a7 06131440
	v_fma_mixhi_f16 v167, s64, v139, v133                       ; cc2200a7 06171640
(invalid instruction)                                        ; cc1b0083
	v_subrev_f32_e32 v0, v131, v65                              ; 0a008383
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v66                              ; 0a0085a4
(invalid instruction)                                        ; cc1b0096
	v_subrev_f32_e32 v0, v150, v65                              ; 0a008396
	v_fma_mixlo_f16 v172, s64, v140, v134                       ; cc2100ac 061b1840
	v_fma_mixhi_f16 v172, s64, v141, v135                       ; cc2200ac 061f1a40
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v66                              ; 0a0085a5
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v173, s64, v142, v40                        ; cc2100ad 04a31c40
(invalid instruction)                                        ; cc1b0097
	v_subrev_f32_e32 v0, v151, v65                              ; 0a008397
	v_fma_mixhi_f16 v173, s64, v143, v41                        ; cc2200ad 04a71e40
(invalid instruction)                                        ; cc1c00a6
	v_subrev_f32_e32 v0, v166, v66                              ; 0a0085a6
	v_fma_mixlo_f16 v174, s64, v144, v42                        ; cc2100ae 04ab2040
(invalid instruction)                                        ; cc1c00a7
	v_subrev_f32_e32 v0, v167, v66                              ; 0a0085a7
	v_fma_mixhi_f16 v174, s64, v145, v43                        ; cc2200ae 04af2240
(invalid instruction)                                        ; cc1b00a4
	v_subrev_f32_e32 v0, v164, v65                              ; 0a0083a4
	v_lshl_add_u32 v63, v63, 5, s67                             ; d646003f 010d0b3f
	v_lshl_add_u32 v129, v129, 5, s67                           ; d6460081 010d0b81
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v66                              ; 0a0085ac
(invalid instruction)                                        ; cc1b00a5
	v_subrev_f32_e32 v0, v165, v65                              ; 0a0083a5
	v_lshl_add_u32 v151, v151, 5, s67                           ; d6460097 010d0b97
(invalid instruction)                                        ; cc1c00ad
	v_subrev_f32_e32 v0, v173, v66                              ; 0a0085ad
(invalid instruction)                                        ; cc1b00a6
	v_subrev_f32_e32 v0, v166, v65                              ; 0a0083a6
	v_lshl_add_u32 v98, v98, 5, s67                             ; d6460062 010d0b62
	v_lshl_add_u32 v130, v130, 5, s67                           ; d6460082 010d0b82
(invalid instruction)                                        ; cc1b00a7
	v_subrev_f32_e32 v0, v167, v65                              ; 0a0083a7
(invalid instruction)                                        ; cc1c00ae
	v_subrev_f32_e32 v0, v174, v66                              ; 0a0085ae
	v_lshl_add_u32 v164, v164, 5, s67                           ; d64600a4 010d0ba4
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[63:64], v[129:130]              ; 1a03033f
(invalid instruction)                                        ; cc1b00ac
	v_subrev_f32_e32 v0, v172, v65                              ; 0a0083ac
	v_lshl_add_u32 v99, v99, 5, s67                             ; d6460063 010d0b63
	v_lshl_add_u32 v131, v131, 5, s67                           ; d6460083 010d0b83
	v_lshl_add_u32 v165, v165, 5, s67                           ; d64600a5 010d0ba5
(invalid instruction)                                        ; cc1b00ad
	v_subrev_f32_e32 v0, v173, v65                              ; 0a0083ad
(invalid instruction)                                        ; cc0f00b0
	v_min_num_f64_e32 v[1:2], v[98:99], v[130:131]              ; 1a030562
	v_lshl_add_u32 v167, v167, 5, s67                           ; d64600a7 010d0ba7
	v_lshl_add_u32 v128, v128, 5, s67                           ; d6460080 010d0b80
(invalid instruction)                                        ; cc1b00ae
	v_subrev_f32_e32 v0, v174, v65                              ; 0a0083ae
	v_lshl_add_u32 v150, v150, 5, s67                           ; d6460096 010d0b96
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[151:152]            ; 1a032faf
	v_lshl_add_u32 v166, v166, 5, s67                           ; d64600a6 010d0ba6
	v_lshl_add_u32 v172, v172, 5, s67                           ; d64600ac 010d0bac
(invalid instruction)                                        ; cc0f00b1
	v_min_num_f64_e32 v[1:2], v[99:100], v[131:132]             ; 1a030763
	v_lshl_add_u32 v173, v173, 5, s67                           ; d64600ad 010d0bad
(invalid instruction)                                        ; cc0f00b0
	v_min_num_f64_e32 v[1:2], v[176:177], v[164:165]            ; 1a0349b0
	v_lshl_add_u32 v174, v174, 5, s67                           ; d64600ae 010d0bae
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[128:129], v[150:151]            ; 1a032d80
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[167:168]            ; 1a034faf
(invalid instruction)                                        ; cc0f00b1
	v_min_num_f64_e32 v[1:2], v[177:178], v[165:166]            ; 1a034bb1
(invalid instruction)                                        ; cc0f00b0
	v_min_num_f64_e32 v[1:2], v[176:177], v[172:173]            ; 1a0359b0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[178:179], v[166:167]            ; 1a034db2
(invalid instruction)                                        ; cc0f00b1
	v_min_num_f64_e32 v[1:2], v[177:178], v[173:174]            ; 1a035bb1
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[176:177]            ; 1a0361af
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[178:179], v[174:175]            ; 1a035db2
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[177:178]            ; 1a0363af
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[178:179]            ; 1a0365af
	v_permlanex16_b32 v179, v175, s61, s62 op_sel:[1,1]         ; d65c18b3 00f87baf
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[179:180]            ; 1a0367af
(invalid instruction)                                        ; d53210b4
	v_cndmask_b32_e32 v1, v175, v175, vcc_lo                    ; 02035faf
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53100b4
	v_cndmask_b32_e32 v1, s60, v180, vcc_lo                     ; 0203683c
(invalid instruction)                                        ; d58b00b5
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                    ; 020101b4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v181, v181                                    ; 7f6a55b5
	v_fma_mix_f32 v182, v63, v181, neg(0) op_sel_hi:[1,0,0]     ; cc2000b6 8a036b3f
	v_fma_mix_f32 v63, v63, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083f 8a036b3f
	v_fma_mix_f32 v183, v98, v181, neg(0) op_sel_hi:[1,0,0]     ; cc2000b7 8a036b62
	v_fma_mix_f32 v185, v128, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000b9 8a036b80
	v_fma_mix_f32 v184, v99, v181, neg(0) op_sel_hi:[1,0,0]     ; cc2000b8 8a036b63
	v_fma_mix_f32 v187, v130, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000bb 8a036b82
	v_fma_mix_f32 v186, v129, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000ba 8a036b81
	v_fma_mix_f32 v128, v128, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200880 8a036b80
	v_fma_mix_f32 v99, v99, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200863 8a036b63
	v_fma_mix_f32 v129, v129, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a036b81
	v_fma_mix_f32 v98, v98, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200862 8a036b62
	v_fma_mix_f32 v130, v130, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200882 8a036b82
	v_fma_mix_f32 v188, v131, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000bc 8a036b83
	v_fma_mix_f32 v131, v131, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200883 8a036b83
	v_fma_mix_f32 v189, v150, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000bd 8a036b96
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v182, v63, vcc_lo                     ; 02027fb6
	v_fma_mix_f32 v150, v150, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200896 8a036b96
	v_fma_mix_f32 v190, v151, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000be 8a036b97
	v_fma_mix_f32 v151, v151, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a036b97
	v_fma_mix_f32 v191, v164, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036ba4
	v_fma_mix_f32 v164, v164, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a4 8a036ba4
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v184, v99, vcc_lo                     ; 0202c7b8
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v185, v128, vcc_lo                    ; 020301b9
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v186, v129, vcc_lo                    ; 020303ba
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v183, v98, vcc_lo                     ; 0202c5b7
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v187, v130, vcc_lo                    ; 020305bb
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v188, v131, vcc_lo                    ; 020307bc
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v189, v150, vcc_lo                    ; 02032dbd
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v190, v151, vcc_lo                    ; 02032fbe
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v191, v164, vcc_lo                    ; 020349bf
	v_fma_mix_f32 v191, v165, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036ba5
	v_fma_mix_f32 v165, v165, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a036ba5
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[120:123], v53, s[32:35], null offen offset:12288 ; c405c07c 40804078 00300035
	buffer_load_b128 v[128:131], v53, s[32:35], null offen offset:12304 ; c405c07c 40804080 00301035
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v191, v165, vcc_lo                    ; 02034bbf
	v_fma_mix_f32 v191, v166, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036ba6
	v_fma_mix_f32 v166, v166, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a6 8a036ba6
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v191, v166, vcc_lo                    ; 02034dbf
	v_fma_mix_f32 v191, v167, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036ba7
	v_fma_mix_f32 v167, v167, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a7 8a036ba7
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v39, s64, v72, v102                         ; cc210027 059a9040
	v_fma_mixhi_f16 v39, s64, v73, v103                         ; cc220027 059e9240
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v191, v167, vcc_lo                    ; 02034fbf
	v_fma_mix_f32 v191, v172, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036bac
	v_fma_mix_f32 v172, v172, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ac 8a036bac
(invalid instruction)                                        ; cc1c0027
	v_subrev_f32_e32 v0, v39, v66                               ; 0a008527
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v191, v172, vcc_lo                    ; 020359bf
	v_fma_mix_f32 v191, v173, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036bad
	v_fma_mix_f32 v173, v173, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ad 8a036bad
(invalid instruction)                                        ; cc1b0027
	v_subrev_f32_e32 v0, v39, v65                               ; 0a008327
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v191, v173, vcc_lo                    ; 02035bbf
	v_fma_mix_f32 v191, v174, v181, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036bae
	v_fma_mix_f32 v174, v174, v181, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ae 8a036bae
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v191, v174, vcc_lo                    ; 02035dbf
	v_fma_mixlo_f16 v191, s64, v70, v100                        ; cc2100bf 05928c40
	v_fma_mixhi_f16 v191, s64, v71, v101                        ; cc2200bf 05968e40
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v44, s64, v74, v44                          ; cc21002c 04b29440
	v_fma_mixhi_f16 v44, s64, v75, v45                          ; cc22002c 04b69640
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v53, s[32:35], null offen offset:12352 ; c405c07c 40804044 00304035
	buffer_load_b128 v[72:75], v53, s[32:35], null offen offset:12368 ; c405c07c 40804048 00305035
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v66                              ; 0a0085bf
	v_fma_mixlo_f16 v45, s64, v76, v46                          ; cc21002d 04ba9840
	v_fma_mixhi_f16 v45, s64, v77, v47                          ; cc22002d 04be9a40
(invalid instruction)                                        ; cc1c002c
	v_subrev_f32_e32 v0, v44, v66                               ; 0a00852c
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v65                              ; 0a0083bf
(invalid instruction)                                        ; cc1c002d
	v_subrev_f32_e32 v0, v45, v66                               ; 0a00852d
(invalid instruction)                                        ; cc1b002c
	v_subrev_f32_e32 v0, v44, v65                               ; 0a00832c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; cc1b002d
	v_subrev_f32_e32 v0, v45, v65                               ; 0a00832d
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v46, s64, v6, v112                          ; cc21002e 05c20c40
	v_fma_mixlo_f16 v47, s64, v8, v114                          ; cc21002f 05ca1040
	v_fma_mixhi_f16 v47, s64, v9, v115                          ; cc22002f 05ce1240
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v52, s64, v10, v116                         ; cc210034 05d21440
	v_fma_mixhi_f16 v52, s64, v11, v117                         ; cc220034 05d61640
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v53, s[32:35], null offen offset:12416 ; c405c07c 40804008 00308035
	buffer_load_b128 v[100:103], v53, s[32:35], null offen offset:12432 ; c405c07c 40804064 00309035
	v_fma_mixhi_f16 v46, s64, v7, v113                          ; cc22002e 05c60e40
	v_fma_mixlo_f16 v55, s64, v12, v118                         ; cc210037 05da1840
	v_fma_mixhi_f16 v55, s64, v13, v119                         ; cc220037 05de1a40
(invalid instruction)                                        ; cc1c002f
	v_subrev_f32_e32 v0, v47, v66                               ; 0a00852f
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v63, s64, v92, v154                         ; cc21003f 066ab840
	v_fma_mixhi_f16 v63, s64, v93, v155                         ; cc22003f 066eba40
	v_fma_mixlo_f16 v60, s64, v90, v152                         ; cc21003c 0662b440
	v_fma_mixhi_f16 v60, s64, v91, v153                         ; cc22003c 0666b640
(invalid instruction)                                        ; cc1c0034
	v_subrev_f32_e32 v0, v52, v66                               ; 0a008534
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v66, s64, v94, v156                         ; cc210042 0672bc40
	v_fma_mixhi_f16 v66, s64, v95, v157                         ; cc220042 0676be40
(invalid instruction)                                        ; cc1c002e
	v_subrev_f32_e32 v0, v46, v66                               ; 0a00852e
	v_fma_mixlo_f16 v67, s64, v96, v158                         ; cc210043 067ac040
	v_fma_mixhi_f16 v67, s64, v97, v159                         ; cc220043 067ec240
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[92:95], v53, s[32:35], null offen offset:12480 ; c405c07c 4080405c 0030c035
	buffer_load_b128 v[96:99], v53, s[32:35], null offen offset:12496 ; c405c07c 40804060 0030d035
(invalid instruction)                                        ; cc1c0037
	v_subrev_f32_e32 v0, v55, v66                               ; 0a008537
(invalid instruction)                                        ; cc1b002f
	v_subrev_f32_e32 v0, v47, v65                               ; 0a00832f
(invalid instruction)                                        ; cc1c003f
	v_subrev_f32_e32 v0, v63, v66                               ; 0a00853f
	v_add3_u32 v16, v17, s22, v16                               ; d6550010 04402d11
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v66                               ; 0a00853c
(invalid instruction)                                        ; cc1b0034
	v_subrev_f32_e32 v0, v52, v65                               ; 0a008334
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v66                               ; 0a008542
(invalid instruction)                                        ; cc1b002e
	v_subrev_f32_e32 v0, v46, v65                               ; 0a00832e
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v66                               ; 0a008543
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v76, s64, v104, v160                        ; cc21004c 0682d040
	v_fma_mixhi_f16 v76, s64, v105, v161                        ; cc22004c 0686d240
	v_fma_mixlo_f16 v77, s64, v106, v162                        ; cc21004d 068ad440
	v_fma_mixhi_f16 v77, s64, v107, v163                        ; cc22004d 068ed640
(invalid instruction)                                        ; cc1b0037
	v_subrev_f32_e32 v0, v55, v65                               ; 0a008337
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v90, s64, v108, v168                        ; cc21005a 06a2d840
(invalid instruction)                                        ; cc1b003f
	v_subrev_f32_e32 v0, v63, v65                               ; 0a00833f
	v_fma_mixhi_f16 v90, s64, v109, v169                        ; cc22005a 06a6da40
	v_lshlrev_b32_e32 v16, 2, v16                               ; 30202082
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v65                               ; 0a00833c
	v_fma_mixlo_f16 v91, s64, v110, v170                        ; cc21005b 06aadc40
(invalid instruction)                                        ; cc1b0042
	v_subrev_f32_e32 v0, v66, v65                               ; 0a008342
	v_fma_mixhi_f16 v91, s64, v111, v171                        ; cc22005b 06aede40
(invalid instruction)                                        ; cc1b0043
	v_subrev_f32_e32 v0, v67, v65                               ; 0a008343
(invalid instruction)                                        ; cc1c004c
	v_subrev_f32_e32 v0, v76, v66                               ; 0a00854c
	v_lshl_add_u32 v191, v191, 5, s67                           ; d64600bf 010d0bbf
	v_lshl_add_u32 v46, v46, 5, s67                             ; d646002e 010d0b2e
(invalid instruction)                                        ; cc1c004d
	v_subrev_f32_e32 v0, v77, v66                               ; 0a00854d
(invalid instruction)                                        ; cc1c005a
	v_subrev_f32_e32 v0, v90, v66                               ; 0a00855a
	v_lshl_add_u32 v39, v39, 5, s67                             ; d6460027 010d0b27
	v_lshl_add_u32 v60, v60, 5, s67                             ; d646003c 010d0b3c
	v_lshl_add_u32 v47, v47, 5, s67                             ; d646002f 010d0b2f
	v_lshl_add_u32 v63, v63, 5, s67                             ; d646003f 010d0b3f
(invalid instruction)                                        ; cc1c005b
	v_subrev_f32_e32 v0, v91, v66                               ; 0a00855b
(invalid instruction)                                        ; cc1b004c
	v_subrev_f32_e32 v0, v76, v65                               ; 0a00834c
	v_lshl_add_u32 v44, v44, 5, s67                             ; d646002c 010d0b2c
	v_lshl_add_u32 v52, v52, 5, s67                             ; d6460034 010d0b34
(invalid instruction)                                        ; cc0f0068
	v_min_num_f64_e32 v[1:2], v[191:192], v[46:47]              ; 1a025dbf
(invalid instruction)                                        ; cc1b004d
	v_subrev_f32_e32 v0, v77, v65                               ; 0a00834d
(invalid instruction)                                        ; cc1b005a
	v_subrev_f32_e32 v0, v90, v65                               ; 0a00835a
	v_lshl_add_u32 v66, v66, 5, s67                             ; d6460042 010d0b42
(invalid instruction)                                        ; cc0f0069
	v_min_num_f64_e32 v[1:2], v[39:40], v[47:48]                ; 1a025f27
	v_lshl_add_u32 v45, v45, 5, s67                             ; d646002d 010d0b2d
	v_lshl_add_u32 v55, v55, 5, s67                             ; d6460037 010d0b37
(invalid instruction)                                        ; cc1b005b
	v_subrev_f32_e32 v0, v91, v65                               ; 0a00835b
	v_lshl_add_u32 v76, v76, 5, s67                             ; d646004c 010d0b4c
	v_lshl_add_u32 v67, v67, 5, s67                             ; d6460043 010d0b43
(invalid instruction)                                        ; cc0f006a
	v_min_num_f64_e32 v[1:2], v[44:45], v[52:53]                ; 1a02692c
(invalid instruction)                                        ; cc0f0068
	v_min_num_f64_e32 v[1:2], v[104:105], v[60:61]              ; 1a027968
	v_lshl_add_u32 v77, v77, 5, s67                             ; d646004d 010d0b4d
	v_lshl_add_u32 v90, v90, 5, s67                             ; d646005a 010d0b5a
(invalid instruction)                                        ; cc0f0069
	v_min_num_f64_e32 v[1:2], v[105:106], v[63:64]              ; 1a027f69
(invalid instruction)                                        ; cc0f006b
	v_min_num_f64_e32 v[1:2], v[45:46], v[55:56]                ; 1a026f2d
	v_lshl_add_u32 v91, v91, 5, s67                             ; d646005b 010d0b5b
(invalid instruction)                                        ; cc0f006a
	v_min_num_f64_e32 v[1:2], v[106:107], v[66:67]              ; 1a02856a
(invalid instruction)                                        ; cc0f0068
	v_min_num_f64_e32 v[1:2], v[104:105], v[76:77]              ; 1a029968
(invalid instruction)                                        ; cc0f0069
	v_min_num_f64_e32 v[1:2], v[105:106], v[77:78]              ; 1a029b69
(invalid instruction)                                        ; cc0f006b
	v_min_num_f64_e32 v[1:2], v[107:108], v[67:68]              ; 1a02876b
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f006a
	v_min_num_f64_e32 v[1:2], v[106:107], v[90:91]              ; 1a02b56a
(invalid instruction)                                        ; cc0f0068
	v_min_num_f64_e32 v[1:2], v[104:105], v[105:106]            ; 1a02d368
(invalid instruction)                                        ; cc0f006b
	v_min_num_f64_e32 v[1:2], v[107:108], v[91:92]              ; 1a02b76b
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f0068
	v_min_num_f64_e32 v[1:2], v[104:105], v[106:107]            ; 1a02d568
(invalid instruction)                                        ; cc0f0068
	v_min_num_f64_e32 v[1:2], v[104:105], v[107:108]            ; 1a02d768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v108, v104, s61, s62 op_sel:[1,1]         ; d65c186c 00f87b68
(invalid instruction)                                        ; cc0f0068
	v_min_num_f64_e32 v[1:2], v[104:105], v[108:109]            ; 1a02d968
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v109, v104, v232/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64dbd168
	v_max_num_f16_e32 v109, s60, v109                           ; 62dada3c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v110, v109                                ; 7edc176d
	v_rcp_f32_e32 v110, v110                                    ; 7edc556e
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v116, v47, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200074 8a02dd2f
	v_fma_mix_f32 v115, v46, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200073 8a02dd2e
	v_fma_mix_f32 v46, v46, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082e 8a02dd2e
	v_fma_mix_f32 v112, v39, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200070 8a02dd27
	v_fma_mix_f32 v113, v44, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200071 8a02dd2c
	v_fma_mix_f32 v44, v44, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082c 8a02dd2c
	v_fma_mix_f32 v111, v191, v110, neg(0) op_sel_hi:[1,0,0]    ; cc20006f 8a02ddbf
	v_fma_mix_f32 v191, v191, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a02ddbf
	v_fma_mix_f32 v114, v45, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200072 8a02dd2d
	v_fma_mix_f32 v45, v45, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082d 8a02dd2d
	v_fma_mix_f32 v39, v39, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200827 8a02dd27
	v_fma_mix_f32 v47, v47, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082f 8a02dd2f
	v_fma_mix_f32 v117, v52, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200075 8a02dd34
	v_fma_mix_f32 v52, v52, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200834 8a02dd34
	v_fma_mix_f32 v118, v55, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200076 8a02dd37
	v_fma_mix_f32 v55, v55, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200837 8a02dd37
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v115, v46, vcc_lo                     ; 02025d73
	v_fma_mix_f32 v119, v60, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200077 8a02dd3c
	v_fma_mix_f32 v60, v60, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083c 8a02dd3c
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v113, v44, vcc_lo                     ; 02025971
	v_fma_mix_f32 v132, v63, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200084 8a02dd3f
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v111, v191, vcc_lo                    ; 02037f6f
	v_fma_mix_f32 v63, v63, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083f 8a02dd3f
	v_fma_mix_f32 v133, v66, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200085 8a02dd42
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v114, v45, vcc_lo                     ; 02025b72
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v112, v39, vcc_lo                     ; 02024f70
	v_fma_mix_f32 v66, v66, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200842 8a02dd42
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v116, v47, vcc_lo                     ; 02025f74
	v_fma_mix_f32 v134, v67, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200086 8a02dd43
	v_fma_mix_f32 v67, v67, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200843 8a02dd43
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v117, v52, vcc_lo                     ; 02026975
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v118, v55, vcc_lo                     ; 02026f76
	v_fma_mix_f32 v135, v76, v110, neg(0) op_sel_hi:[1,0,0]     ; cc200087 8a02dd4c
	v_fma_mix_f32 v76, v76, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084c 8a02dd4c
	v_fma_mix_f32 v138, v77, v110, neg(0) op_sel_hi:[1,0,0]     ; cc20008a 8a02dd4d
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v119, v60, vcc_lo                     ; 02027977
	v_fma_mix_f32 v77, v77, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084d 8a02dd4d
	v_fma_mix_f32 v139, v90, v110, neg(0) op_sel_hi:[1,0,0]     ; cc20008b 8a02dd5a
	v_fma_mix_f32 v90, v90, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085a 8a02dd5a
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v132, v63, vcc_lo                     ; 02027f84
	v_fma_mix_f32 v140, v91, v110, neg(0) op_sel_hi:[1,0,0]     ; cc20008c 8a02dd5b
	v_fma_mix_f32 v91, v91, v110, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085b 8a02dd5b
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v133, v66, vcc_lo                     ; 02028585
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[22:23], 0 ; cc464068 1a022d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[22:23], 0 ; cc464070 1a022d52
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[22:23], 0 ; cc464098 1a022d40
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v134, v67, vcc_lo                     ; 02028786
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[86:87], v[22:23], 0 ; cc4640a0 1a022d56
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v135, v76, vcc_lo                     ; 02029987
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v138, v77, vcc_lo                     ; 02029b8a
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v139, v90, vcc_lo                     ; 0202b58b
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v140, v91, vcc_lo                     ; 0202b78c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[24:25], v[104:111] ; cc464068 1da2311c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[24:25], v[112:119] ; cc464070 1dc2313a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[84:85], v[24:25], v[152:159] ; cc464098 1e623154
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[4:5], v[24:25], v[160:167] ; cc4640a0 1e823104
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v142, s64, v106, v122                       ; cc21008e 05ead440
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v143, s64, v108, v128                       ; cc21008f 0602d840
	v_fma_mixlo_f16 v141, s64, v104, v120                       ; cc21008d 05e2d040
	v_fma_mixhi_f16 v142, s64, v107, v123                       ; cc22008e 05eed640
	v_fma_mixlo_f16 v144, s64, v110, v130                       ; cc210090 060adc40
	v_fma_mixhi_f16 v141, s64, v105, v121                       ; cc22008d 05e6d240
	v_fma_mixhi_f16 v143, s64, v109, v129                       ; cc22008f 0606da40
	v_fma_mixhi_f16 v144, s64, v111, v131                       ; cc220090 060ede40
(invalid instruction)                                        ; cc1c008e
	v_subrev_f32_e32 v0, v142, v66                              ; 0a00858e
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c008d
	v_subrev_f32_e32 v0, v141, v66                              ; 0a00858d
(invalid instruction)                                        ; cc1c008f
	v_subrev_f32_e32 v0, v143, v66                              ; 0a00858f
(invalid instruction)                                        ; cc1c0090
	v_subrev_f32_e32 v0, v144, v66                              ; 0a008590
(invalid instruction)                                        ; cc1b008e
	v_subrev_f32_e32 v0, v142, v65                              ; 0a00838e
(invalid instruction)                                        ; cc1b008d
	v_subrev_f32_e32 v0, v141, v65                              ; 0a00838d
(invalid instruction)                                        ; cc1b008f
	v_subrev_f32_e32 v0, v143, v65                              ; 0a00838f
(invalid instruction)                                        ; cc1b0090
	v_subrev_f32_e32 v0, v144, v65                              ; 0a008390
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v145, s64, v112, v68                        ; cc210091 0512e040
	v_fma_mixhi_f16 v145, s64, v113, v69                        ; cc220091 0516e240
	v_fma_mixlo_f16 v150, s64, v114, v70                        ; cc210096 051ae440
	v_fma_mixhi_f16 v150, s64, v115, v71                        ; cc220096 051ee640
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v151, s64, v116, v72                        ; cc210097 0522e840
	v_fma_mixhi_f16 v151, s64, v117, v73                        ; cc220097 0526ea40
	v_fma_mixlo_f16 v168, s64, v118, v74                        ; cc2100a8 052aec40
	v_fma_mixhi_f16 v168, s64, v119, v75                        ; cc2200a8 052eee40
(invalid instruction)                                        ; cc1c0091
	v_subrev_f32_e32 v0, v145, v66                              ; 0a008591
(invalid instruction)                                        ; cc1c0096
	v_subrev_f32_e32 v0, v150, v66                              ; 0a008596
(invalid instruction)                                        ; cc1c0097
	v_subrev_f32_e32 v0, v151, v66                              ; 0a008597
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c00a8
	v_subrev_f32_e32 v0, v168, v66                              ; 0a0085a8
(invalid instruction)                                        ; cc1b0091
	v_subrev_f32_e32 v0, v145, v65                              ; 0a008391
(invalid instruction)                                        ; cc1b0096
	v_subrev_f32_e32 v0, v150, v65                              ; 0a008396
(invalid instruction)                                        ; cc1b0097
	v_subrev_f32_e32 v0, v151, v65                              ; 0a008397
(invalid instruction)                                        ; cc1b00a8
	v_subrev_f32_e32 v0, v168, v65                              ; 0a0083a8
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v169, s64, v152, v8                         ; cc2100a9 04233040
	v_fma_mixhi_f16 v169, s64, v153, v9                         ; cc2200a9 04273240
	v_fma_mixlo_f16 v170, s64, v154, v10                        ; cc2100aa 042b3440
	v_fma_mixhi_f16 v170, s64, v155, v11                        ; cc2200aa 042f3640
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v171, s64, v156, v100                       ; cc2100ab 05933840
	v_fma_mixlo_f16 v172, s64, v158, v102                       ; cc2100ac 059b3c40
	buffer_load_b128 v[8:11], v16, s[32:35], null offen         ; c405c07c 40804008 00000010
	v_fma_mixhi_f16 v171, s64, v157, v101                       ; cc2200ab 05973a40
	v_fma_mixhi_f16 v172, s64, v159, v103                       ; cc2200ac 059f3e40
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v66                              ; 0a0085a9
(invalid instruction)                                        ; cc1c00aa
	v_subrev_f32_e32 v0, v170, v66                              ; 0a0085aa
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c00ab
	v_subrev_f32_e32 v0, v171, v66                              ; 0a0085ab
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v66                              ; 0a0085ac
(invalid instruction)                                        ; cc1b00a9
	v_subrev_f32_e32 v0, v169, v65                              ; 0a0083a9
	buffer_load_b128 v[24:27], v16, s[32:35], null offen offset:16 ; c405c07c 40804018 00001010
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v173, s64, v160, v92                        ; cc2100ad 05734040
	v_fma_mixhi_f16 v173, s64, v161, v93                        ; cc2200ad 05774240
(invalid instruction)                                        ; cc1b00aa
	v_subrev_f32_e32 v0, v170, v65                              ; 0a0083aa
	v_fma_mixlo_f16 v174, s64, v162, v94                        ; cc2100ae 057b4440
	v_fma_mixhi_f16 v174, s64, v163, v95                        ; cc2200ae 057f4640
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v176, s64, v166, v98                        ; cc2100b0 058b4c40
	v_fma_mixlo_f16 v175, s64, v164, v96                        ; cc2100af 05834840
	v_fma_mixhi_f16 v175, s64, v165, v97                        ; cc2200af 05874a40
	v_fma_mixhi_f16 v176, s64, v167, v99                        ; cc2200b0 058f4e40
(invalid instruction)                                        ; cc1b00ab
	v_subrev_f32_e32 v0, v171, v65                              ; 0a0083ab
(invalid instruction)                                        ; cc1b00ac
	v_subrev_f32_e32 v0, v172, v65                              ; 0a0083ac
	v_lshl_add_u32 v141, v141, 5, s67                           ; d646008d 010d0b8d
	v_lshl_add_u32 v145, v145, 5, s67                           ; d6460091 010d0b91
	v_lshl_add_u32 v169, v169, 5, s67                           ; d64600a9 010d0ba9
(invalid instruction)                                        ; cc1c00ad
	v_subrev_f32_e32 v0, v173, v66                              ; 0a0085ad
(invalid instruction)                                        ; cc1c00ae
	v_subrev_f32_e32 v0, v174, v66                              ; 0a0085ae
	v_lshl_add_u32 v142, v142, 5, s67                           ; d646008e 010d0b8e
	v_lshl_add_u32 v150, v150, 5, s67                           ; d6460096 010d0b96
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v66                              ; 0a0085af
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v66                              ; 0a0085b0
	v_lshl_add_u32 v170, v170, 5, s67                           ; d64600aa 010d0baa
(invalid instruction)                                        ; cc0f00b1
	v_min_num_f64_e32 v[1:2], v[141:142], v[145:146]            ; 1a03238d
	v_lshl_add_u32 v143, v143, 5, s67                           ; d646008f 010d0b8f
	v_lshl_add_u32 v151, v151, 5, s67                           ; d6460097 010d0b97
(invalid instruction)                                        ; cc1b00ad
	v_subrev_f32_e32 v0, v173, v65                              ; 0a0083ad
	v_lshl_add_u32 v171, v171, 5, s67                           ; d64600ab 010d0bab
(invalid instruction)                                        ; cc1b00ae
	v_subrev_f32_e32 v0, v174, v65                              ; 0a0083ae
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[142:143], v[150:151]            ; 1a032d8e
(invalid instruction)                                        ; cc1b00af
	v_subrev_f32_e32 v0, v175, v65                              ; 0a0083af
	v_lshl_add_u32 v144, v144, 5, s67                           ; d6460090 010d0b90
(invalid instruction)                                        ; cc1b00b0
	v_subrev_f32_e32 v0, v176, v65                              ; 0a0083b0
	v_lshl_add_u32 v168, v168, 5, s67                           ; d64600a8 010d0ba8
(invalid instruction)                                        ; cc0f00b1
	v_min_num_f64_e32 v[1:2], v[177:178], v[169:170]            ; 1a0353b1
	v_lshl_add_u32 v172, v172, 5, s67                           ; d64600ac 010d0bac
(invalid instruction)                                        ; cc0f00b3
	v_min_num_f64_e32 v[1:2], v[143:144], v[151:152]            ; 1a032f8f
	v_lshl_add_u32 v173, v173, 5, s67                           ; d64600ad 010d0bad
	v_lshl_add_u32 v174, v174, 5, s67                           ; d64600ae 010d0bae
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[178:179], v[170:171]            ; 1a0355b2
	v_lshl_add_u32 v175, v175, 5, s67                           ; d64600af 010d0baf
	v_lshl_add_u32 v176, v176, 5, s67                           ; d64600b0 010d0bb0
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[144:145], v[168:169]            ; 1a035190
(invalid instruction)                                        ; cc0f00b3
	v_min_num_f64_e32 v[1:2], v[179:180], v[171:172]            ; 1a0357b3
(invalid instruction)                                        ; cc0f00b1
	v_min_num_f64_e32 v[1:2], v[177:178], v[173:174]            ; 1a035bb1
(invalid instruction)                                        ; cc0f00b2
	v_min_num_f64_e32 v[1:2], v[178:179], v[174:175]            ; 1a035db2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[172:173]            ; 1a0359b4
(invalid instruction)                                        ; cc0f00b3
	v_min_num_f64_e32 v[1:2], v[179:180], v[175:176]            ; 1a035fb3
(invalid instruction)                                        ; cc0f00b1
	v_min_num_f64_e32 v[1:2], v[177:178], v[178:179]            ; 1a0365b1
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[176:177]            ; 1a0361b4
(invalid instruction)                                        ; cc0f00b1
	v_min_num_f64_e32 v[1:2], v[177:178], v[179:180]            ; 1a0367b1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00b1
	v_min_num_f64_e32 v[1:2], v[177:178], v[180:181]            ; 1a0369b1
	v_permlanex16_b32 v181, v177, s61, s62 op_sel:[1,1]         ; d65c18b5 00f87bb1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00b1
	v_min_num_f64_e32 v[1:2], v[177:178], v[181:182]            ; 1a036bb1
(invalid instruction)                                        ; d53210b6
	v_cndmask_b32_e32 v1, v177, v177, vcc_lo                    ; 020363b1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53100b6
	v_cndmask_b32_e32 v1, s60, v182, vcc_lo                     ; 02036c3c
(invalid instruction)                                        ; d58b00b7
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                    ; 020101b6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v183, v183                                    ; 7f6e55b7
	v_fma_mix_f32 v189, v150, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bd 8a036f96
	v_fma_mix_f32 v187, v144, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bb 8a036f90
	v_fma_mix_f32 v144, v144, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200890 8a036f90
	v_fma_mix_f32 v186, v143, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000ba 8a036f8f
	v_fma_mix_f32 v143, v143, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088f 8a036f8f
	v_fma_mix_f32 v185, v142, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000b9 8a036f8e
	v_fma_mix_f32 v142, v142, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088e 8a036f8e
	buffer_load_b128 v[64:67], v16, s[32:35], null offen offset:64 ; c405c07c 40804040 00004010
	v_fma_mix_f32 v188, v145, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bc 8a036f91
	v_fma_mix_f32 v145, v145, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a036f91
	v_fma_mix_f32 v184, v141, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000b8 8a036f8d
	v_fma_mix_f32 v141, v141, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088d 8a036f8d
	v_fma_mix_f32 v150, v150, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200896 8a036f96
	v_fma_mix_f32 v190, v151, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000be 8a036f97
	v_fma_mix_f32 v151, v151, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a036f97
	v_fma_mix_f32 v191, v168, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036fa8
	buffer_load_b128 v[68:71], v16, s[32:35], null offen offset:80 ; c405c07c 40804044 00005010
	v_fma_mix_f32 v168, v168, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a8 8a036fa8
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v186, v143, vcc_lo                    ; 02031fba
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v187, v144, vcc_lo                    ; 020321bb
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v188, v145, vcc_lo                    ; 020323bc
	s_lshr_b32 s7, s7, 2                                        ; 85078207
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v184, v141, vcc_lo                    ; 02031bb8
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v185, v142, vcc_lo                    ; 02031db9
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v189, v150, vcc_lo                    ; 02032dbd
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v190, v151, vcc_lo                    ; 02032fbe
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v191, v168, vcc_lo                    ; 020351bf
	v_fma_mix_f32 v191, v169, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036fa9
	v_fma_mix_f32 v169, v169, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a036fa9
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v48, v48, s7, v51                                ; d6550030 04cc0f30
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v191, v169, vcc_lo                    ; 020353bf
	v_fma_mix_f32 v191, v170, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036faa
	v_fma_mix_f32 v170, v170, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008aa 8a036faa
	v_lshlrev_b32_e32 v48, 2, v48                               ; 30606082
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v191, v170, vcc_lo                    ; 020355bf
	v_fma_mix_f32 v191, v171, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036fab
	v_fma_mix_f32 v171, v171, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ab 8a036fab
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v191, v171, vcc_lo                    ; 020357bf
	v_fma_mix_f32 v191, v172, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036fac
	v_fma_mix_f32 v172, v172, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ac 8a036fac
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[18:19], v[20:21], 0 ; cc464060 1a022912
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[32:33], 0 ; cc464068 1a024112
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[6:7], 0 ; cc464070 1a020d12
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v191, v172, vcc_lo                    ; 020359bf
	v_fma_mix_f32 v191, v173, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036fad
	v_fma_mix_f32 v173, v173, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ad 8a036fad
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[4:5], 0 ; cc464080 1a020912
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[80:81], v[96:103] ; cc464060 1d82a194
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[148:149], v[34:35], v[104:111] ; cc464068 1da24594
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v191, v173, vcc_lo                    ; 02035bbf
	v_fma_mix_f32 v191, v174, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036fae
	v_fma_mix_f32 v174, v174, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ae 8a036fae
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[148:149], v[12:13], v[112:119] ; cc464070 1dc21994
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[148:149], v[22:23], v[128:135] ; cc464080 1e022d94
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[124:125], v[14:15], v[96:103] ; cc464060 1d821d7c
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v191, v174, vcc_lo                    ; 02035dbf
	v_fma_mix_f32 v191, v175, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036faf
	v_fma_mix_f32 v175, v175, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a036faf
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[124:125], v[40:41], v[104:111] ; cc464068 1da2517c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[124:125], v[44:45], v[112:119] ; cc464070 1dc2597c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[124:125], v[28:29], v[128:135] ; cc464080 1e02397c
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v191, v175, vcc_lo                    ; 02035fbf
	v_fma_mix_f32 v191, v176, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a036fb0
	v_fma_mix_f32 v176, v176, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a036fb0
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[136:137], v[78:79], v[96:103] ; cc464060 1d829d88
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[136:137], v[42:43], v[104:111] ; cc464068 1da25588
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[136:137], v[46:47], v[112:119] ; cc464070 1dc25d88
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v191, v176, vcc_lo                    ; 020361bf
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[136:137], v[52:53], v[128:135] ; cc464080 1e026988
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[30:31], v[20:21], 0 ; cc464060 1a02291e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[32:33], 0 ; cc464068 1a02411e
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[6:7], 0 ; cc464070 1a020d1e
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[4:5], 0 ; cc464080 1a02091e
	buffer_load_b128 v[4:7], v48, s[36:39], null offen          ; c405c07c 40804804 00000030
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[88:89], v[80:81], v[96:103] ; cc464060 1d82a158
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[88:89], v[34:35], v[104:111] ; cc464068 1da24558
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[88:89], v[12:13], v[112:119] ; cc464070 1dc21958
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[88:89], v[22:23], v[128:135] ; cc464080 1e022d58
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[126:127], v[14:15], v[96:103] ; cc464060 1d821d7e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[126:127], v[40:41], v[104:111] ; cc464068 1da2517e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[126:127], v[44:45], v[112:119] ; cc464070 1dc2597e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[126:127], v[28:29], v[128:135] ; cc464080 1e02397e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[78:79], v[96:103] ; cc464060 1d829d24
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[42:43], v[104:111] ; cc464068 1da25524
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[46:47], v[112:119] ; cc464070 1dc25d24
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[36:37], v[52:53], v[128:135] ; cc464080 1e026924
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	ds_store_2addr_b64 v49, v[18:19], v[12:13] offset1:32       ; d9382000 000c1231
	buffer_load_b128 v[20:23], v48, s[36:39], null offen offset:512 ; c405c07c 40804814 00020030
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	ds_store_2addr_b64 v50, v[58:59], v[12:13] offset1:32       ; d9382000 000c3a32
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	ds_store_2addr_b64 v56, v[72:73], v[12:13] offset1:32       ; d9382000 000c4838
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	ds_store_2addr_b64 v57, v[74:75], v[12:13] offset1:32       ; d9382000 000c4a39
	buffer_load_b128 v[12:15], v48, s[36:39], null offen offset:1024 ; c405c07c 4080480c 00040030
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[18:19], v61                                   ; d9d80000 1200003d
	ds_load_b64 v[28:29], v61 offset:4096                       ; d9d81000 1c00003d
	ds_load_b64 v[30:31], v61 offset:8192                       ; d9d82000 1e00003d
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[32:33], v18                          ; 7e40dd12
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v41, v33, v9 :: v_dual_mul_f32 v40, v32, v8  ; c8c61321 29281120
	v_cvt_pk_f32_fp8_e32 v[32:33], v146                         ; 7e40dd92
	v_dual_mul_f32 v43, v33, v11 :: v_dual_mul_f32 v42, v32, v10 ; c8c61721 2b2a1520
	buffer_load_b128 v[32:35], v48, s[36:39], null offen offset:1536 ; c405c07c 40804820 00060030
	v_cvt_pk_f32_fp8_e32 v[36:37], v19                          ; 7e48dd13
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v45, v37, v25 :: v_dual_mul_f32 v44, v36, v24 ; c8c63325 2d2c3124
	ds_load_b64 v[36:37], v61 offset:12288                      ; d9d83000 2400003d
	buffer_load_b128 v[56:59], v48, s[36:39], null offen offset:2048 ; c405c07c 40804838 00080030
	ds_load_b64 v[50:51], v61 offset:256                        ; d9d80100 3200003d
	buffer_load_b128 v[84:87], v48, s[36:39], null offen offset:2560 ; c405c07c 40804854 000a0030
	v_cvt_pk_f32_fp8_e32 v[18:19], v147                         ; 7e24dd93
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v47, v19, v27 :: v_dual_mul_f32 v46, v18, v26 ; c8c63713 2f2e3512
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[18:19], v28                          ; 7e24dd1c
	v_dual_mul_f32 v73, v19, v9 :: v_dual_mul_f32 v72, v18, v8  ; c8c61313 49481112
	v_cvt_pk_f32_fp8_e32 v[18:19], v156                         ; 7e24dd9c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v75, v19, v11 :: v_dual_mul_f32 v74, v18, v10 ; c8c61713 4b4a1512
	v_cvt_pk_f32_fp8_e32 v[18:19], v29                          ; 7e24dd1d
	v_cvt_pk_f32_fp8_e32 v[28:29], v157                         ; 7e38dd9d
	v_dual_mul_f32 v77, v19, v25 :: v_dual_mul_f32 v76, v18, v24 ; c8c63313 4d4c3112
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[18:19], v30                          ; 7e24dd1e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v81, v19, v9 :: v_dual_mul_f32 v80, v18, v8  ; c8c61313 51501112
	v_cvt_pk_f32_fp8_e32 v[18:19], v158                         ; 7e24dd9e
	v_dual_mul_f32 v83, v19, v11 :: v_dual_mul_f32 v82, v18, v10 ; c8c61713 53521512
	v_cvt_pk_f32_fp8_e32 v[18:19], v31                          ; 7e24dd1f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v79, v29, v27 :: v_dual_mul_f32 v92, v18, v24 ; c8c6371d 4f5c3112
	v_dual_mul_f32 v93, v19, v25 :: v_dual_mul_f32 v78, v28, v26 ; c8c63313 5d4e351c
	v_cvt_pk_f32_fp8_e32 v[18:19], v159                         ; 7e24dd9f
	buffer_load_b128 v[28:31], v48, s[36:39], null offen offset:3072 ; c405c07c 4080481c 000c0030
	ds_load_b64 v[52:53], v61 offset:4352                       ; d9d81100 3400003d
	buffer_load_b128 v[88:91], v48, s[36:39], null offen offset:3584 ; c405c07c 40804858 000e0030
	v_dual_mul_f32 v95, v19, v27 :: v_dual_mul_f32 v94, v18, v26 ; c8c63713 5f5e3512
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[18:19], v36                          ; 7e24dd24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v97, v19, v9                                  ; 10c21313
	v_mul_f32_e32 v96, v18, v8                                  ; 10c01112
	v_cvt_pk_f32_fp8_e32 v[8:9], v164                           ; 7e10dda4
	v_dual_mul_f32 v99, v9, v11 :: v_dual_mul_f32 v98, v8, v10  ; c8c61709 63621508
	ds_load_b64 v[10:11], v61 offset:8448                       ; d9d82100 0a00003d
	v_cvt_pk_f32_fp8_e32 v[8:9], v37                            ; 7e10dd25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v101, v9, v25 :: v_dual_mul_f32 v100, v8, v24 ; c8c63309 65643108
	v_cvt_pk_f32_fp8_e32 v[8:9], v165                           ; 7e10dda5
	v_dual_mul_f32 v103, v9, v27 :: v_dual_mul_f32 v102, v8, v26 ; c8c63709 67663508
	buffer_load_b128 v[24:27], v48, s[36:39], null offen offset:4096 ; c405c07c 40804818 00100030
	ds_load_b64 v[18:19], v61 offset:12544                      ; d9d83100 1200003d
	buffer_load_b128 v[116:119], v48, s[36:39], null offen offset:4608 ; c405c07c 40804874 00120030
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[8:9], v50                            ; 7e10dd32
	s_wait_loadcnt 0xb                                          ; bfc0000b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v105, v9, v65 :: v_dual_mul_f32 v104, v8, v64 ; c8c68309 69688108
	v_cvt_pk_f32_fp8_e32 v[8:9], v178                           ; 7e10ddb2
	v_dual_mul_f32 v107, v9, v67 :: v_dual_mul_f32 v106, v8, v66 ; c8c68709 6b6a8508
	v_cvt_pk_f32_fp8_e32 v[8:9], v51                            ; 7e10dd33
	s_wait_loadcnt 0xa                                          ; bfc0000a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v109, v9, v69 :: v_dual_mul_f32 v108, v8, v68 ; c8c68b09 6d6c8908
	v_cvt_pk_f32_fp8_e32 v[8:9], v179                           ; 7e10ddb3
	ds_load_b64 v[36:37], v62 offset:16384                      ; d9d84000 2400003e
	ds_load_b64 v[50:51], v62 offset:20480                      ; d9d85000 3200003e
	buffer_load_b128 v[120:123], v48, s[36:39], null offen offset:5120 ; c405c07c 40804878 00140030
	v_dual_mul_f32 v111, v9, v71 :: v_dual_mul_f32 v110, v8, v70 ; c8c68f09 6f6e8d08
	s_wait_dscnt 0x4                                            ; bfc60004
	v_cvt_pk_f32_fp8_e32 v[8:9], v52                            ; 7e10dd34
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v9, v65 :: v_dual_mul_f32 v112, v8, v64 ; c8c68309 71708108
	v_cvt_pk_f32_fp8_e32 v[8:9], v180                           ; 7e10ddb4
	v_dual_mul_f32 v115, v9, v67 :: v_dual_mul_f32 v114, v8, v66 ; c8c68709 73728508
	v_cvt_pk_f32_fp8_e32 v[8:9], v53                            ; 7e10dd35
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v125, v9, v69 :: v_dual_mul_f32 v124, v8, v68 ; c8c68b09 7d7c8908
	v_cvt_pk_f32_fp8_e32 v[8:9], v181                           ; 7e10ddb5
	ds_load_b64 v[52:53], v62 offset:24576                      ; d9d86000 3400003e
	ds_load_b64 v[60:61], v62 offset:28672                      ; d9d87000 3c00003e
	buffer_load_b128 v[136:139], v48, s[36:39], null offen offset:5632 ; c405c07c 40804888 00160030
	v_dual_mul_f32 v127, v9, v71 :: v_dual_mul_f32 v126, v8, v70 ; c8c68f09 7f7e8d08
	s_wait_dscnt 0x5                                            ; bfc60005
	v_cvt_pk_f32_fp8_e32 v[8:9], v10                            ; 7e10dd0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v129, v9, v65 :: v_dual_mul_f32 v128, v8, v64 ; c8c68309 81808108
	v_cvt_pk_f32_fp8_e32 v[8:9], v138                           ; 7e10dd8a
	v_dual_mul_f32 v131, v9, v67 :: v_dual_mul_f32 v130, v8, v66 ; c8c68709 83828508
	v_cvt_pk_f32_fp8_e32 v[8:9], v11                            ; 7e10dd0b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v133, v9, v69 :: v_dual_mul_f32 v132, v8, v68 ; c8c68b09 85848908
	v_cvt_pk_f32_fp8_e32 v[8:9], v139                           ; 7e10dd8b
	ds_load_b64 v[10:11], v62 offset:16640                      ; d9d84100 0a00003e
	ds_load_b64 v[140:141], v62 offset:20736                    ; d9d85100 8c00003e
	ds_load_b64 v[142:143], v62 offset:24832                    ; d9d86100 8e00003e
	ds_load_b64 v[144:145], v62 offset:28928                    ; d9d87100 9000003e
	v_dual_mul_f32 v135, v9, v71 :: v_dual_mul_f32 v134, v8, v70 ; c8c68f09 87868d08
	s_wait_dscnt 0x8                                            ; bfc60008
	v_cvt_pk_f32_fp8_e32 v[8:9], v18                            ; 7e10dd12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v152, v8, v64                                 ; 11308108
	v_mul_f32_e32 v153, v9, v65                                 ; 11328309
	v_cvt_pk_f32_fp8_e32 v[8:9], v146                           ; 7e10dd92
	v_dual_mul_f32 v155, v9, v67 :: v_dual_mul_f32 v154, v8, v66 ; c8c68709 9b9a8508
	buffer_load_b128 v[64:67], v48, s[36:39], null offen offset:6144 ; c405c07c 40804840 00180030
	v_cvt_pk_f32_fp8_e32 v[8:9], v19                            ; 7e10dd13
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v157, v9, v69 :: v_dual_mul_f32 v156, v8, v68 ; c8c68b09 9d9c8908
	v_cvt_pk_f32_fp8_e32 v[8:9], v147                           ; 7e10dd93
	ds_load_b64 v[18:19], v62 offset:16896                      ; d9d84200 1200003e
	ds_load_b64 v[68:69], v62 offset:20992                      ; d9d85200 4400003e
	ds_load_b64 v[148:149], v62 offset:25088                    ; d9d86200 9400003e
	ds_load_b64 v[150:151], v62 offset:29184                    ; d9d87200 9600003e
	buffer_load_b128 v[160:163], v48, s[36:39], null offen offset:6656 ; c405c07c 408048a0 001a0030
	v_dual_mul_f32 v159, v9, v71 :: v_dual_mul_f32 v158, v8, v70 ; c8c68f09 9f9e8d08
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_dual_mov_b32 v167, v87 :: v_dual_mov_b32 v166, v86        ; ca100157 a7a60156
	v_dual_mov_b32 v87, v95 :: v_dual_mov_b32 v86, v94          ; ca10015f 5756015e
	v_dual_mov_b32 v165, v85 :: v_dual_mov_b32 v164, v84        ; ca100155 a5a40154
	v_dual_mov_b32 v85, v93 :: v_dual_mov_b32 v84, v92          ; ca10015d 5554015c
	ds_load_b64 v[8:9], v62 offset:17152                        ; d9d84300 0800003e
	ds_load_b64 v[70:71], v62 offset:21248                      ; d9d85300 4600003e
	ds_load_b64 v[92:93], v62 offset:25344                      ; d9d86300 5c00003e
	ds_load_b64 v[94:95], v62 offset:29440                      ; d9d87300 5e00003e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mov_b32 v169, v117 :: v_dual_mov_b32 v168, v116      ; ca100175 a9a80174
	v_dual_mov_b32 v117, v125 :: v_dual_mov_b32 v116, v124      ; ca10017d 7574017c
	v_dual_mov_b32 v171, v119 :: v_dual_mov_b32 v170, v118      ; ca100177 abaa0176
	v_dual_mov_b32 v119, v127 :: v_dual_mov_b32 v118, v126      ; ca10017f 7776017e
	buffer_load_b128 v[124:127], v48, s[36:39], null offen offset:7168 ; c405c07c 4080487c 001c0030
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[4:5], v[36:37], v[40:47] ; cc464028 1ca24904
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[4:5], v[50:51], v[72:79] ; cc464048 1d226504
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[4:5], v[60:61], v[96:103] ; cc464060 1d827904
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[6:7], v[36:37], v[104:111] ; cc464068 1da24906
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[6:7], v[52:53], v[128:135] ; cc464080 1e026906
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[6:7], v[60:61], v[152:159] ; cc464098 1e627906
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[4:5], v[52:53], v[80:87] ; cc464050 1d426904
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[6:7], v[50:51], v[112:119] ; cc464070 1dc26506
	ds_load_b64 v[4:5], v62 offset:17408                        ; d9d84400 0400003e
	ds_load_b64 v[6:7], v62 offset:21504                        ; d9d85400 0600003e
	ds_load_b64 v[36:37], v62 offset:25600                      ; d9d86400 2400003e
	ds_load_b64 v[50:51], v62 offset:29696                      ; d9d87400 3200003e
	buffer_load_b128 v[172:175], v48, s[36:39], null offen offset:7680 ; c405c07c 408048ac 001e0030
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[20:21], v[10:11], v[40:47] ; cc464028 1ca21514
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[20:21], v[140:141], v[72:79] ; cc464048 1d231914
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[144:145], v[96:103] ; cc464060 1d832114
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[10:11], v[104:111] ; cc464068 1da21516
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[142:143], v[128:135] ; cc464080 1e031d16
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[22:23], v[144:145], v[152:159] ; cc464098 1e632116
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[142:143], v[80:87] ; cc464050 1d431d14
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[140:141], v[112:119] ; cc464070 1dc31916
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[18:19], v[40:47] ; cc464028 1ca2250c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[12:13], v[68:69], v[72:79] ; cc464048 1d22890c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[150:151], v[96:103] ; cc464060 1d832d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[18:19], v[104:111] ; cc464068 1da2250e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[148:149], v[128:135] ; cc464080 1e03290e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[14:15], v[150:151], v[152:159] ; cc464098 1e632d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[148:149], v[80:87] ; cc464050 1d43290c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[68:69], v[112:119] ; cc464070 1dc2890e
	ds_load_b64 v[10:11], v62 offset:17664                      ; d9d84500 0a00003e
	ds_load_b64 v[20:21], v62 offset:21760                      ; d9d85500 1400003e
	ds_load_b64 v[22:23], v62 offset:25856                      ; d9d86500 1600003e
	ds_load_b64 v[48:49], v62 offset:29952                      ; d9d87500 3000003e
	ds_load_b64 v[12:13], v62 offset:17920                      ; d9d84600 0c00003e
	ds_load_b64 v[14:15], v62 offset:22016                      ; d9d85600 0e00003e
	ds_load_b64 v[18:19], v62 offset:26112                      ; d9d86600 1200003e
	ds_load_b64 v[52:53], v62 offset:30208                      ; d9d87600 3400003e
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[32:33], v[8:9], v[40:47] ; cc464028 1ca21120
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[32:33], v[70:71], v[72:79] ; cc464048 1d228d20
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[94:95], v[96:103] ; cc464060 1d82bd20
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[34:35], v[8:9], v[104:111] ; cc464068 1da21122
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[92:93], v[128:135] ; cc464080 1e02b922
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[34:35], v[94:95], v[152:159] ; cc464098 1e62bd22
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[92:93], v[80:87] ; cc464050 1d42b920
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[70:71], v[112:119] ; cc464070 1dc28d22
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[56:57], v[4:5], v[40:47] ; cc464028 1ca20938
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[56:57], v[6:7], v[72:79] ; cc464048 1d220d38
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[56:57], v[50:51], v[96:103] ; cc464060 1d826538
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[58:59], v[4:5], v[104:111] ; cc464068 1da2093a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[36:37], v[128:135] ; cc464080 1e02493a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[50:51], v[152:159] ; cc464098 1e62653a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[56:57], v[36:37], v[80:87] ; cc464050 1d424938
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[6:7], v[112:119] ; cc464070 1dc20d3a
	ds_load_b64 v[8:9], v62 offset:18176                        ; d9d84700 0800003e
	ds_load_b64 v[32:33], v62 offset:22272                      ; d9d85700 2000003e
	ds_load_b64 v[34:35], v62 offset:26368                      ; d9d86700 2200003e
	ds_load_b64 v[60:61], v62 offset:30464                      ; d9d87700 3c00003e
	ds_load_b64 v[4:5], v62 offset:18432                        ; d9d84800 0400003e
	ds_load_b64 v[6:7], v62 offset:22528                        ; d9d85800 0600003e
	ds_load_b64 v[36:37], v62 offset:26624                      ; d9d86800 2400003e
	ds_load_b64 v[50:51], v62 offset:30720                      ; d9d87800 3200003e
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[164:165], v[10:11], v[40:47] ; cc464028 1ca215a4
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[164:165], v[20:21], v[72:79] ; cc464048 1d2229a4
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[164:165], v[48:49], v[96:103] ; cc464060 1d8261a4
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[166:167], v[10:11], v[104:111] ; cc464068 1da215a6
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[166:167], v[22:23], v[128:135] ; cc464080 1e022da6
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[166:167], v[48:49], v[152:159] ; cc464098 1e6261a6
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[164:165], v[22:23], v[80:87] ; cc464050 1d422da4
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[166:167], v[20:21], v[112:119] ; cc464070 1dc229a6
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[28:29], v[12:13], v[40:47] ; cc464028 1ca2191c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[14:15], v[72:79] ; cc464048 1d221d1c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[52:53], v[96:103] ; cc464060 1d82691c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[12:13], v[104:111] ; cc464068 1da2191e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[18:19], v[128:135] ; cc464080 1e02251e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[18:19], v[80:87] ; cc464050 1d42251c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[14:15], v[112:119] ; cc464070 1dc21d1e
	ds_load_b64 v[10:11], v62 offset:18688                      ; d9d84900 0a00003e
	ds_load_b64 v[20:21], v62 offset:22784                      ; d9d85900 1400003e
	ds_load_b64 v[22:23], v62 offset:26880                      ; d9d86900 1600003e
	ds_load_b64 v[48:49], v62 offset:30976                      ; d9d87900 3000003e
	ds_load_b64 v[12:13], v62 offset:18944                      ; d9d84a00 0c00003e
	ds_load_b64 v[14:15], v62 offset:23040                      ; d9d85a00 0e00003e
	ds_load_b64 v[18:19], v62 offset:27136                      ; d9d86a00 1200003e
	ds_load_b64 v[28:29], v62 offset:31232                      ; d9d87a00 1c00003e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[30:31], v[52:53], v[152:159] ; cc464098 1e62691e
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[88:89], v[8:9], v[40:47] ; cc464028 1ca21158
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[88:89], v[32:33], v[72:79] ; cc464048 1d224158
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[90:91], v[8:9], v[104:111] ; cc464068 1da2115a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[90:91], v[34:35], v[128:135] ; cc464080 1e02455a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[88:89], v[34:35], v[80:87] ; cc464050 1d424558
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[88:89], v[60:61], v[96:103] ; cc464060 1d827958
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[90:91], v[32:33], v[112:119] ; cc464070 1dc2415a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[90:91], v[60:61], v[152:159] ; cc464098 1e62795a
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[24:25], v[4:5], v[40:47] ; cc464028 1ca20918
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[6:7], v[72:79] ; cc464048 1d220d18
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[4:5], v[104:111] ; cc464068 1da2091a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[36:37], v[128:135] ; cc464080 1e02491a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[36:37], v[80:87] ; cc464050 1d424918
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[50:51], v[96:103] ; cc464060 1d826518
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[6:7], v[112:119] ; cc464070 1dc20d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[26:27], v[50:51], v[152:159] ; cc464098 1e62651a
	ds_load_b64 v[8:9], v62 offset:19200                        ; d9d84b00 0800003e
	ds_load_b64 v[30:31], v62 offset:23296                      ; d9d85b00 1e00003e
	ds_load_b64 v[32:33], v62 offset:27392                      ; d9d86b00 2000003e
	ds_load_b64 v[34:35], v62 offset:31488                      ; d9d87b00 2200003e
	ds_load_b64 v[4:5], v62 offset:19456                        ; d9d84c00 0400003e
	ds_load_b64 v[6:7], v62 offset:23552                        ; d9d85c00 0600003e
	ds_load_b64 v[24:25], v62 offset:27648                      ; d9d86c00 1800003e
	ds_load_b64 v[26:27], v62 offset:31744                      ; d9d87c00 1a00003e
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[168:169], v[10:11], v[40:47] ; cc464028 1ca215a8
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[168:169], v[20:21], v[72:79] ; cc464048 1d2229a8
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[170:171], v[10:11], v[104:111] ; cc464068 1da215aa
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[168:169], v[22:23], v[80:87] ; cc464050 1d422da8
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[170:171], v[22:23], v[128:135] ; cc464080 1e022daa
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[168:169], v[48:49], v[96:103] ; cc464060 1d8261a8
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[20:21], v[112:119] ; cc464070 1dc229aa
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[170:171], v[48:49], v[152:159] ; cc464098 1e6261aa
	s_wait_loadcnt_dscnt 0x50b                                  ; bfc8050b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[120:121], v[12:13], v[40:47] ; cc464028 1ca21978
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[120:121], v[14:15], v[72:79] ; cc464048 1d221d78
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[122:123], v[12:13], v[104:111] ; cc464068 1da2197a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[120:121], v[18:19], v[80:87] ; cc464050 1d422578
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[122:123], v[18:19], v[128:135] ; cc464080 1e02257a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[120:121], v[28:29], v[96:103] ; cc464060 1d823978
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[122:123], v[14:15], v[112:119] ; cc464070 1dc21d7a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[122:123], v[28:29], v[152:159] ; cc464098 1e62397a
	ds_load_b64 v[10:11], v62 offset:19712                      ; d9d84d00 0a00003e
	ds_load_b64 v[20:21], v62 offset:23808                      ; d9d85d00 1400003e
	ds_load_b64 v[22:23], v62 offset:27904                      ; d9d86d00 1600003e
	ds_load_b64 v[36:37], v62 offset:32000                      ; d9d87d00 2400003e
	ds_load_b64 v[12:13], v62 offset:19968                      ; d9d84e00 0c00003e
	ds_load_b64 v[14:15], v62 offset:24064                      ; d9d85e00 0e00003e
	ds_load_b64 v[18:19], v62 offset:28160                      ; d9d86e00 1200003e
	ds_load_b64 v[28:29], v62 offset:32256                      ; d9d87e00 1c00003e
	s_wait_loadcnt_dscnt 0x40f                                  ; bfc8040f
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[136:137], v[8:9], v[40:47] ; cc464028 1ca21188
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[136:137], v[30:31], v[72:79] ; cc464048 1d223d88
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[138:139], v[8:9], v[104:111] ; cc464068 1da2118a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[136:137], v[32:33], v[80:87] ; cc464050 1d424188
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[138:139], v[32:33], v[128:135] ; cc464080 1e02418a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[136:137], v[34:35], v[96:103] ; cc464060 1d824588
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[138:139], v[30:31], v[112:119] ; cc464070 1dc23d8a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[138:139], v[34:35], v[152:159] ; cc464098 1e62458a
	ds_load_b64 v[8:9], v62 offset:20224                        ; d9d84f00 0800003e
	ds_load_b64 v[30:31], v62 offset:24320                      ; d9d85f00 1e00003e
	ds_load_b64 v[32:33], v62 offset:28416                      ; d9d86f00 2000003e
	ds_load_b64 v[34:35], v62 offset:32512                      ; d9d87f00 2200003e
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
	s_wait_loadcnt_dscnt 0x30f                                  ; bfc8030f
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[64:65], v[4:5], v[40:47] ; cc464028 1ca20940
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[66:67], v[4:5], v[104:111] ; cc464068 1da20942
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[64:65], v[6:7], v[72:79] ; cc464048 1d220d40
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[64:65], v[24:25], v[80:87] ; cc464050 1d423140
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[64:65], v[26:27], v[96:103] ; cc464060 1d823540
	s_wait_loadcnt_dscnt 0x20b                                  ; bfc8020b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[160:161], v[10:11], v[40:47] ; cc464028 1ca215a0
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[6:7], v[112:119] ; cc464070 1dc20d42
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[24:25], v[128:135] ; cc464080 1e023142
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[26:27], v[152:159] ; cc464098 1e623542
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[124:125], v[12:13], v[40:47] ; cc464028 1ca2197c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[160:161], v[20:21], v[72:79] ; cc464048 1d2229a0
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[160:161], v[22:23], v[80:87] ; cc464050 1d422da0
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[160:161], v[36:37], v[96:103] ; cc464060 1d8249a0
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[162:163], v[10:11], v[104:111] ; cc464068 1da215a2
	s_wait_loadcnt_dscnt 0x3                                    ; bfc80003
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[172:173], v[8:9], v[40:47] ; cc464028 1ca211ac
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[162:163], v[20:21], v[112:119] ; cc464070 1dc229a2
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[162:163], v[22:23], v[128:135] ; cc464080 1e022da2
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[162:163], v[36:37], v[152:159] ; cc464098 1e6249a2
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[124:125], v[14:15], v[72:79] ; cc464048 1d221d7c
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	v_cndmask_b32_e32 v191, v40, v44, vcc_lo                    ; 037e5928
	v_cndmask_b32_e32 v44, v44, v40, vcc_lo                     ; 0258512c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[124:125], v[18:19], v[80:87] ; cc464050 1d42257c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[124:125], v[28:29], v[96:103] ; cc464060 1d82397c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[126:127], v[12:13], v[104:111] ; cc464068 1da2197e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[126:127], v[14:15], v[112:119] ; cc464070 1dc21d7e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[126:127], v[18:19], v[128:135] ; cc464080 1e02257e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[126:127], v[28:29], v[152:159] ; cc464098 1e62397e
	v_add_f32_dpp v44, v44, v191 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06597efa ff0cb12c
	v_cndmask_b32_e32 v191, v41, v45, vcc_lo                    ; 037e5b29
	v_cndmask_b32_e32 v45, v45, v41, vcc_lo                     ; 025a532d
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[172:173], v[30:31], v[72:79] ; cc464048 1d223dac
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[172:173], v[32:33], v[80:87] ; cc464050 1d4241ac
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[172:173], v[34:35], v[96:103] ; cc464060 1d8245ac
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[174:175], v[8:9], v[104:111] ; cc464068 1da211ae
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[174:175], v[30:31], v[112:119] ; cc464070 1dc23dae
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[174:175], v[32:33], v[128:135] ; cc464080 1e0241ae
	v_add_f32_dpp v45, v45, v191 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 065b7efa ff0cb12d
	v_cndmask_b32_e32 v191, v42, v46, vcc_lo                    ; 037e5d2a
	v_cndmask_b32_e32 v46, v46, v42, vcc_lo                     ; 025c552e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[174:175], v[34:35], v[152:159] ; cc464098 1e6245ae
	v_cvt_f16_f32_e32 v6, v44                                   ; 7e0c152c
	v_and_b32_e32 v12, 1, v0                                    ; 36180081
	v_bfe_u32 v13, v147, 2, 1                                   ; d610000d 02050593
	v_bfe_u32 v14, v147, 3, 1                                   ; d610000e 02050793
	v_add_f32_dpp v46, v46, v191 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 065d7efa ff0cb12e
	v_cndmask_b32_e32 v191, v43, v47, vcc_lo                    ; 037e5f2b
	v_cndmask_b32_e32 v47, v47, v43, vcc_lo                     ; 025e572f
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	v_bfe_u32 v147, v147, 1, 1                                  ; d6100093 02050393
	v_cvt_f16_f32_e32 v7, v45                                   ; 7e0e152d
	v_lshl_add_u32 v12, v12, 2, v17                             ; d646000c 0445050c
	v_add_f32_dpp v47, v47, v191 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 065f7efa ff0cb12f
(invalid instruction)                                        ; d58a00bf
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v46, v46, v44, vcc_lo                     ; 025c592e
	v_lshl_add_u32 v14, v14, 2, v147                            ; d646000e 064d050e
	v_lshl_add_u32 v13, v13, 1, v12                             ; d646000d 0431030d
(invalid instruction)                                        ; d58a40bf
	v_cndmask_b32_e32 v0, v47, v128, vcc_lo                     ; 0201012f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_cvt_f16_f32_dpp v9, v46 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1214fa ff0d642e
	v_lshl_add_u32 v14, v14, 4, v2                              ; d646000e 0409090e
	v_cndmask_b32_e32 v8, v6, v191, vcc_lo                      ; 02117f06
	v_cndmask_b16 v8, v7, v191, vcc_lo                          ; d65d5008 01ab7f07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_dual_cndmask_b32 v47, v47, v45 :: v_dual_add_nc_u32 v14, v13, v14 ; ca605b2f 2f0e1d0d
(invalid instruction)                                        ; 7f1214fa
(invalid instruction)                                        ; ff0d642f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; cc0f0008
	v_min_num_f64_e32 v[1:2], v[8:9], v[9:10]                   ; 1a021308
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v10, 0, v8, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100a 920210ff 3e800000
	v_fma_mix_f32 v8, 0, v8, neg(0) op_sel_hi:[0,1,0]           ; cc200008 920210ff 3e800000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v8, v10, vcc_lo                       ; 02021508
	ds_store_b16 v14, v11                                       ; d87c0000 00000b0e
	s_cmp_lg_i32 s48, 0                                         ; bf018030
	s_cbranch_scc1 BB3                                          ; bfa20008
BB1:
	v_add3_u32 v6, v2, s3, s28                                  ; d6550006 00700702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v6, v3, v6, v38                                  ; d6550006 049a0d03
	buffer_store_b64 v[4:5], v6, s[12:15], null offen           ; c406c07c 40801804 00000006
BB3:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v7, v73, v77 :: v_dual_cndmask_b32 v6, v72, v76 ; ca529b49 07069948
	v_dual_cndmask_b32 v77, v77, v73 :: v_dual_cndmask_b32 v76, v76, v72 ; ca52934d 4d4c914c
	v_dual_cndmask_b32 v9, v75, v79 :: v_dual_cndmask_b32 v8, v74, v78 ; ca529f4b 09089d4a
	v_dual_cndmask_b32 v79, v79, v75 :: v_dual_cndmask_b32 v78, v78, v74 ; ca52974f 4f4e954e
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v76, v76, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06980cfa ff0cb14c
	v_add_f32_dpp v77, v77, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069a0efa ff0cb14d
	v_add_f32_dpp v79, v79, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069e12fa ff0cb14f
	v_add_f32_dpp v78, v78, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069c10fa ff0cb14e
	v_cvt_f16_f32_e32 v12, v76                                  ; 7e18154c
	v_cvt_f16_f32_e32 v13, v77                                  ; 7e1a154d
	v_cvt_f16_f32_e32 v11, v79                                  ; 7e16154f
	v_cvt_f16_f32_e32 v10, v78                                  ; 7e14154e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v79, v79, v77 :: v_dual_cndmask_b32 v78, v78, v76 ; ca529b4f 4f4e994e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v15, v12, v10, vcc_lo                     ; 021e150c
	v_cndmask_b16 v15, v13, v11, vcc_lo                         ; d65d400f 01aa170d
	v_cvt_f16_f32_dpp v16, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d644e
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d644f
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v18, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201012 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel_hi:[0,1,0]         ; cc20000f 92021eff 3e800000
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v15, v18, vcc_lo                      ; 0202250f
	ds_store_b16 v14, v19 offset:32                             ; d87c0020 0000130e
	s_mov_b32 s2, src_scc                                       ; be8200fd
	s_cmp_lg_i32 s52, 0                                         ; bf018034
	s_cbranch_scc1 BB6                                          ; bfa20008
BB4:
	v_add3_u32 v6, v2, s3, s27                                  ; d6550006 006c0702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v6, v3, v6, v38                                  ; d6550006 049a0d03
	buffer_store_b64 v[4:5], v6, s[12:15], null offen           ; c406c07c 40801804 00000006
BB6:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v7, v81, v85 :: v_dual_cndmask_b32 v6, v80, v84 ; ca52ab51 0706a950
	v_dual_cndmask_b32 v85, v85, v81 :: v_dual_cndmask_b32 v84, v84, v80 ; ca52a355 5554a154
	v_dual_cndmask_b32 v9, v83, v87 :: v_dual_cndmask_b32 v8, v82, v86 ; ca52af53 0908ad52
	v_dual_cndmask_b32 v87, v87, v83 :: v_dual_cndmask_b32 v86, v86, v82 ; ca52a757 5756a556
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v84, v84, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06a80cfa ff0cb154
	v_add_f32_dpp v85, v85, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06aa0efa ff0cb155
	v_add_f32_dpp v87, v87, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ae12fa ff0cb157
	v_add_f32_dpp v86, v86, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ac10fa ff0cb156
	v_cvt_f16_f32_e32 v12, v84                                  ; 7e181554
	v_cvt_f16_f32_e32 v13, v85                                  ; 7e1a1555
	v_cvt_f16_f32_e32 v11, v87                                  ; 7e161557
	v_cvt_f16_f32_e32 v10, v86                                  ; 7e141556
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v87, v87, v85 :: v_dual_cndmask_b32 v86, v86, v84 ; ca52ab57 5756a956
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v15, v12, v10, vcc_lo                     ; 021e150c
	v_cndmask_b16 v15, v13, v11, vcc_lo                         ; d65d400f 01aa170d
	v_cvt_f16_f32_dpp v16, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d6456
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d6457
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v18, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201012 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel_hi:[0,1,0]         ; cc20000f 92021eff 3e800000
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v15, v18, vcc_lo                      ; 0202250f
	ds_store_b16 v14, v19 offset:128                            ; d87c0080 0000130e
	s_mov_b32 s4, src_scc                                       ; be8400fd
	s_cmp_lg_i32 s56, 0                                         ; bf018038
	s_cbranch_scc1 BB9                                          ; bfa20008
BB7:
	v_add3_u32 v6, v2, s3, s24                                  ; d6550006 00600702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v6, v3, v6, v38                                  ; d6550006 049a0d03
	buffer_store_b64 v[4:5], v6, s[12:15], null offen           ; c406c07c 40801804 00000006
BB9:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v7, v97, v101 :: v_dual_cndmask_b32 v6, v96, v100 ; ca52cb61 0706c960
	v_dual_cndmask_b32 v101, v101, v97 :: v_dual_cndmask_b32 v100, v100, v96 ; ca52c365 6564c164
	v_dual_cndmask_b32 v9, v99, v103 :: v_dual_cndmask_b32 v8, v98, v102 ; ca52cf63 0908cd62
	v_dual_cndmask_b32 v103, v103, v99 :: v_dual_cndmask_b32 v102, v102, v98 ; ca52c767 6766c566
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v100, v100, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06c80cfa ff0cb164
	v_add_f32_dpp v101, v101, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ca0efa ff0cb165
	v_add_f32_dpp v103, v103, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ce12fa ff0cb167
	v_add_f32_dpp v102, v102, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cc10fa ff0cb166
	v_cvt_f16_f32_e32 v12, v100                                 ; 7e181564
	v_cvt_f16_f32_e32 v13, v101                                 ; 7e1a1565
	v_cvt_f16_f32_e32 v11, v103                                 ; 7e161567
	v_cvt_f16_f32_e32 v10, v102                                 ; 7e141566
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v103, v103, v101 :: v_dual_cndmask_b32 v102, v102, v100 ; ca52cb67 6766c966
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v15, v12, v10, vcc_lo                     ; 021e150c
	v_cndmask_b16 v15, v13, v11, vcc_lo                         ; d65d400f 01aa170d
	v_cvt_f16_f32_dpp v16, v102 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d6466
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d6467
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v18, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201012 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel_hi:[0,1,0]         ; cc20000f 92021eff 3e800000
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v15, v18, vcc_lo                      ; 0202250f
	ds_store_b16 v14, v19 offset:160                            ; d87c00a0 0000130e
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_cmp_lg_i32 s58, 0                                         ; bf01803a
	s_cbranch_scc1 BB12                                         ; bfa20008
BB10:
	v_add3_u32 v2, v2, s3, s42                                  ; d6550002 00a80702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v38                                  ; d6550002 049a0503
	buffer_store_b64 v[4:5], v2, s[12:15], null offen           ; c406c07c 40801804 00000002
BB12:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v2, v104, v108, vcc_lo                    ; 0204d968
	v_cndmask_b32_e32 v6, v105, v109, vcc_lo                    ; 020cdb69
	v_dual_cndmask_b32 v108, v108, v104 :: v_dual_cndmask_b32 v109, v109, v105 ; ca52d16c 6c6cd36d
	v_dual_cndmask_b32 v8, v107, v111 :: v_dual_cndmask_b32 v7, v106, v110 ; ca52df6b 0806dd6a
	v_dual_cndmask_b32 v110, v110, v106 :: v_dual_cndmask_b32 v111, v111, v107 ; ca52d56e 6e6ed76f
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v109, v109, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06da0cfa ff0cb16d
	v_add_f32_dpp v108, v108, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06d804fa ff0cb16c
	v_add_f32_dpp v111, v111, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06de10fa ff0cb16f
	v_add_f32_dpp v110, v110, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06dc0efa ff0cb16e
	v_cvt_f16_f32_e32 v12, v109                                 ; 7e18156d
	v_cvt_f16_f32_e32 v11, v108                                 ; 7e16156c
	v_cvt_f16_f32_e32 v10, v111                                 ; 7e14156f
	v_cvt_f16_f32_e32 v9, v110                                  ; 7e12156e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v111, v111, v109 :: v_dual_cndmask_b32 v110, v110, v108 ; ca52db6f 6f6ed96e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v13, v11, v9, vcc_lo                      ; 021a130b
	v_cndmask_b16 v13, v12, v10, vcc_lo                         ; d65d400d 01aa150c
	v_cvt_f16_f32_dpp v15, v110 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d646e
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d646f
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[15:16]                ; 1a021f0d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v16, 0, v13, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 92021aff 3e800000
	v_fma_mix_f32 v13, 0, v13, neg(0) op_sel_hi:[0,1,0]         ; cc20000d 92021aff 3e800000
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v13, v16, vcc_lo                      ; 0202210d
	ds_store_b16 v14, v18 offset:256                            ; d87c0100 0000120e
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_cmp_lg_i32 s2, 0                                          ; bf018002
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s2, vcc_lo                                        ; be82006a
	s_cbranch_scc1 BB15                                         ; bfa20008
BB13:
	v_add3_u32 v2, v146, s3, s28                                ; d6550002 00700792
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v38                                  ; d6550002 049a0503
	buffer_store_b64 v[4:5], v2, s[12:15], null offen           ; c406c07c 40801804 00000002
BB15:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v2, v112, v116, vcc_lo                    ; 0204e970
	v_cndmask_b32_e32 v6, v113, v117, vcc_lo                    ; 020ceb71
	v_dual_cndmask_b32 v116, v116, v112 :: v_dual_cndmask_b32 v117, v117, v113 ; ca52e174 7474e375
	v_dual_cndmask_b32 v8, v115, v119 :: v_dual_cndmask_b32 v7, v114, v118 ; ca52ef73 0806ed72
	v_dual_cndmask_b32 v118, v118, v114 :: v_dual_cndmask_b32 v119, v119, v115 ; ca52e576 7676e777
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v117, v117, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ea0cfa ff0cb175
	v_add_f32_dpp v116, v116, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06e804fa ff0cb174
	v_add_f32_dpp v119, v119, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ee10fa ff0cb177
	v_add_f32_dpp v118, v118, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ec0efa ff0cb176
	v_cvt_f16_f32_e32 v12, v117                                 ; 7e181575
	v_cvt_f16_f32_e32 v11, v116                                 ; 7e161574
	v_cvt_f16_f32_e32 v10, v119                                 ; 7e141577
	v_cvt_f16_f32_e32 v9, v118                                  ; 7e121576
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v119, v119, v117 :: v_dual_cndmask_b32 v118, v118, v116 ; ca52eb77 7776e976
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v13, v11, v9, vcc_lo                      ; 021a130b
	v_cndmask_b16 v13, v12, v10, vcc_lo                         ; d65d400d 01aa150c
	v_cvt_f16_f32_dpp v15, v118 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d6476
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d6477
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[15:16]                ; 1a021f0d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v16, 0, v13, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 92021aff 3e800000
	v_fma_mix_f32 v13, 0, v13, neg(0) op_sel_hi:[0,1,0]         ; cc20000d 92021aff 3e800000
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v13, v16, vcc_lo                      ; 0202210d
	ds_store_b16 v14, v18 offset:288                            ; d87c0120 0000120e
	s_cmp_lg_i32 s4, 0                                          ; bf018004
	s_cbranch_scc1 BB18                                         ; bfa20008
BB16:
	v_add3_u32 v2, v146, s3, s27                                ; d6550002 006c0792
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v38                                  ; d6550002 049a0503
	buffer_store_b64 v[4:5], v2, s[12:15], null offen           ; c406c07c 40801804 00000002
BB18:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v2, v128, v132, vcc_lo                    ; 02050980
	v_cndmask_b32_e32 v6, v129, v133, vcc_lo                    ; 020d0b81
	v_dual_cndmask_b32 v132, v132, v128 :: v_dual_cndmask_b32 v133, v133, v129 ; ca530184 84850385
	v_dual_cndmask_b32 v8, v131, v135 :: v_dual_cndmask_b32 v7, v130, v134 ; ca530f83 08070d82
	v_dual_cndmask_b32 v134, v134, v130 :: v_dual_cndmask_b32 v135, v135, v131 ; ca530586 86870787
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v133, v133, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070a0cfa ff0cb185
	v_add_f32_dpp v132, v132, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070804fa ff0cb184
	v_add_f32_dpp v135, v135, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070e10fa ff0cb187
	v_add_f32_dpp v134, v134, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070c0efa ff0cb186
	v_cvt_f16_f32_e32 v12, v133                                 ; 7e181585
	v_cvt_f16_f32_e32 v11, v132                                 ; 7e161584
	v_cvt_f16_f32_e32 v10, v135                                 ; 7e141587
	v_cvt_f16_f32_e32 v9, v134                                  ; 7e121586
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v135, v135, v133 :: v_dual_cndmask_b32 v134, v134, v132 ; ca530b87 87870986
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v13, v11, v9, vcc_lo                      ; 021a130b
	v_cndmask_b16 v13, v12, v10, vcc_lo                         ; d65d400d 01aa150c
	v_cvt_f16_f32_dpp v15, v134 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d6486
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d6487
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[15:16]                ; 1a021f0d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v16, 0, v13, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 92021aff 3e800000
	v_fma_mix_f32 v13, 0, v13, neg(0) op_sel_hi:[0,1,0]         ; cc20000d 92021aff 3e800000
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v13, v16, vcc_lo                      ; 0202210d
	ds_store_b16 v14, v18 offset:384                            ; d87c0180 0000120e
	s_cmp_lg_i32 s5, 0                                          ; bf018005
	s_cbranch_scc1 BB21                                         ; bfa20008
BB19:
	v_add3_u32 v2, v146, s3, s24                                ; d6550002 00600792
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v38                                  ; d6550002 049a0503
	buffer_store_b64 v[4:5], v2, s[12:15], null offen           ; c406c07c 40801804 00000002
BB21:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v2, v152, v156, vcc_lo                    ; 02053998
	v_cndmask_b32_e32 v6, v153, v157, vcc_lo                    ; 020d3b99
	v_dual_cndmask_b32 v156, v156, v152 :: v_dual_cndmask_b32 v157, v157, v153 ; ca53319c 9c9d339d
	v_dual_cndmask_b32 v8, v155, v159 :: v_dual_cndmask_b32 v7, v154, v158 ; ca533f9b 08073d9a
	v_dual_cndmask_b32 v158, v158, v154 :: v_dual_cndmask_b32 v159, v159, v155 ; ca53359e 9e9f379f
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v157, v157, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 073a0cfa ff0cb19d
	v_add_f32_dpp v156, v156, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 073804fa ff0cb19c
	v_add_f32_dpp v159, v159, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 073e10fa ff0cb19f
	v_add_f32_dpp v158, v158, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 073c0efa ff0cb19e
	v_cvt_f16_f32_e32 v12, v157                                 ; 7e18159d
	v_cvt_f16_f32_e32 v11, v156                                 ; 7e16159c
	v_cvt_f16_f32_e32 v10, v159                                 ; 7e14159f
	v_cvt_f16_f32_e32 v9, v158                                  ; 7e12159e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v159, v159, v157 :: v_dual_cndmask_b32 v158, v158, v156 ; ca533b9f 9f9f399e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v13, v11, v9, vcc_lo                      ; 021a130b
	v_cndmask_b16 v13, v12, v10, vcc_lo                         ; d65d400d 01aa150c
	v_cvt_f16_f32_dpp v15, v158 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d649e
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d649f
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[15:16]                ; 1a021f0d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v16, 0, v13, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 92021aff 3e800000
	v_fma_mix_f32 v13, 0, v13, neg(0) op_sel_hi:[0,1,0]         ; cc20000d 92021aff 3e800000
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v13, v16, vcc_lo                      ; 0202210d
	ds_store_b16 v14, v18 offset:416                            ; d87c01a0 0000120e
	s_cmp_lg_i32 s2, 0                                          ; bf018002
	s_cbranch_scc1 BB24                                         ; bfa20008
BB22:
	v_add3_u32 v146, v146, s3, s42                              ; d6550092 00a80792
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v146, v3, v146, v38                              ; d6550092 049b2503
	buffer_store_b64 v[4:5], v146, s[12:15], null offen         ; c406c07c 40801804 00000092
BB24:
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_and_b32_e32 v2, 3, v0                                     ; 36040083
	v_bfe_u32 v0, v0, 2, 2                                      ; d6100000 02090500
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_lshl_add_u32 v2, s19, 1, v2                               ; d6460002 04090213
	v_lshl_add_u32 v0, s21, 1, v0                               ; d6460000 04010215
	v_min_i32_e32 v4, v2, v0                                    ; 22080102
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_le_i32_e32 0, v4                                     ; 7d860880
	s_barrier_wait 0xffff                                       ; bf94ffff
	s_cbranch_execz BB30                                        ; bfa50006
BB25:
	s_load_b32 s2, s[10:11], 0x48                               ; f4000085 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s2, s2, 2                                        ; 84028202
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmp_gt_i32_e32 vcc_lo, s2, v2                             ; 7c880402
BB30:
	s_and_b32 s2, vcc_lo, exec_lo                               ; 8b027e6a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, s2                                       ; befe0002
	s_cbranch_execz BB36                                        ; bfa50006
BB31:
	s_load_b32 s2, s[10:11], 0x4c                               ; f4000085 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s2, s2, 2                                        ; 84028202
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmp_gt_i32_e32 vcc_lo, s2, v0                             ; 7c880002
BB36:
	s_load_b32 s3, s[10:11], 0x6c                               ; f40000c5 f800006c
	s_and_b32 s2, vcc_lo, exec_lo                               ; 8b027e6a
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_eq_i32 s3, 0                                          ; bf008003
	s_cbranch_scc0 BB38                                         ; bfa10003
BB37:
	s_load_b32 s4, s[10:11], 0x64                               ; f4000105 f8000064
	s_branch BB39                                               ; bfa00001
BB38:
	s_mov_b32 s4, s3                                            ; be840003
BB39:
	s_clause 0x2                                                ; bf850002
	s_load_b128 s[12:15], s[0:1], 0x20                          ; f4004300 f8000020
	s_load_b256 s[16:23], s[10:11], 0x5c                        ; f4006405 f800005c
	s_load_b96 s[24:26], s[10:11], 0x50                         ; f400a605 f8000050
	v_mad_u32_u24 v54, s59, 0x600, v54                          ; d60b0036 04d9fe3b 00000600
	v_max_i32_e32 v2, 0, v2                                     ; 24040480
	v_max_i32_e32 v0, 0, v0                                     ; 24000080
	s_cmp_lg_i32 s3, 0                                          ; bf018003
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s19, 2                                         ; bf018213
	s_mov_b32 s6, src_scc                                       ; be8600fd
	s_cmp_eq_i32 s16, s17                                       ; bf001110
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s7, s6, src_scc                                   ; 8b07fd06
	s_cmp_eq_i32 s4, s18                                        ; bf001204
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s7, s7, src_scc                                   ; 8b07fd07
	s_mov_b32 s7, 0                                             ; be870080
	s_mov_b32 s8, src_scc                                       ; be8800fd
	s_lshr_b32 s21, s21, 4                                      ; 85158415
	s_cmp_lg_i32 s22, 0                                         ; bf018016
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s9, -1, 0                                     ; 980980c1
	s_branch BB40                                               ; bfa00003
	s_nop 0                                                     ; bf800000
BB84:
	s_mov_b32 s5, s17                                           ; be850011
	s_mov_b32 s6, s16                                           ; be860010
BB40:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v4, v1, 2, s7                                ; d6460004 001d0501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshlrev_b32_e32 v5, 12, v4                                ; 300a088c
	v_add3_u32 v13, s24, 0x700, v5                              ; d655000d 0415fe18 00000700
	v_add3_u32 v6, v38, s24, v5                                 ; d6550006 04143126
	v_add3_u32 v7, s24, 0x100, v5                               ; d6550007 0415fe18 00000100
	v_add3_u32 v8, s24, 0x200, v5                               ; d6550008 0415fe18 00000200
	v_add3_u32 v9, s24, 0x300, v5                               ; d6550009 0415fe18 00000300
	v_add3_u32 v10, s24, 0x400, v5                              ; d655000a 0415fe18 00000400
	v_add3_u32 v11, s24, 0x500, v5                              ; d655000b 0415fe18 00000500
	v_add3_u32 v12, s24, 0x600, v5                              ; d655000c 0415fe18 00000600
	v_add3_u32 v14, s24, 0x800, v5                              ; d655000e 0415fe18 00000800
	v_add3_u32 v15, s24, 0x900, v5                              ; d655000f 0415fe18 00000900
	v_add3_u32 v16, s24, 0xa00, v5                              ; d6550010 0415fe18 00000a00
	v_add3_u32 v13, v3, v13, v38                                ; d655000d 049a1b03
	v_add_nc_u32_e32 v6, v6, v3                                 ; 4a0c0706
	v_add3_u32 v18, s24, 0xb00, v5                              ; d6550012 0415fe18 00000b00
	v_add3_u32 v7, v3, v7, v38                                  ; d6550007 049a0f03
	v_add3_u32 v19, s24, 0xc00, v5                              ; d6550013 0415fe18 00000c00
	v_add3_u32 v8, v3, v8, v38                                  ; d6550008 049a1103
	v_add3_u32 v9, v3, v9, v38                                  ; d6550009 049a1303
	v_add3_u32 v20, s24, 0xd00, v5                              ; d6550014 0415fe18 00000d00
	v_add3_u32 v10, v3, v10, v38                                ; d655000a 049a1503
	v_add3_u32 v11, v3, v11, v38                                ; d655000b 049a1703
	v_add3_u32 v21, s24, 0xe00, v5                              ; d6550015 0415fe18 00000e00
	v_add3_u32 v12, v3, v12, v38                                ; d655000c 049a1903
	v_add3_u32 v14, v3, v14, v38                                ; d655000e 049a1d03
	v_add3_u32 v5, s24, 0xf00, v5                               ; d6550005 0415fe18 00000f00
	v_add3_u32 v15, v3, v15, v38                                ; d655000f 049a1f03
	v_add3_u32 v16, v3, v16, v38                                ; d6550010 049a2103
	v_add3_u32 v18, v3, v18, v38                                ; d6550012 049a2503
	v_add3_u32 v19, v3, v19, v38                                ; d6550013 049a2703
	v_add3_u32 v20, v3, v20, v38                                ; d6550014 049a2903
	v_add3_u32 v21, v3, v21, v38                                ; d6550015 049a2b03
	v_add3_u32 v5, v3, v5, v38                                  ; d6550005 049a0b03
	s_clause 0xf                                                ; bf85000f
	buffer_load_b64 v[22:23], v6, s[12:15], null offen          ; c405407c 40801816 00000006
	buffer_load_b64 v[6:7], v7, s[12:15], null offen            ; c405407c 40801806 00000007
	buffer_load_b64 v[24:25], v8, s[12:15], null offen          ; c405407c 40801818 00000008
	buffer_load_b64 v[8:9], v9, s[12:15], null offen            ; c405407c 40801808 00000009
	buffer_load_b64 v[26:27], v10, s[12:15], null offen         ; c405407c 4080181a 0000000a
	buffer_load_b64 v[10:11], v11, s[12:15], null offen         ; c405407c 4080180a 0000000b
	buffer_load_b64 v[28:29], v12, s[12:15], null offen         ; c405407c 4080181c 0000000c
	buffer_load_b64 v[12:13], v13, s[12:15], null offen         ; c405407c 4080180c 0000000d
	buffer_load_b64 v[30:31], v14, s[12:15], null offen         ; c405407c 4080181e 0000000e
	buffer_load_b64 v[14:15], v15, s[12:15], null offen         ; c405407c 4080180e 0000000f
	buffer_load_b64 v[32:33], v16, s[12:15], null offen         ; c405407c 40801820 00000010
	buffer_load_b64 v[34:35], v18, s[12:15], null offen         ; c405407c 40801822 00000012
	buffer_load_b64 v[18:19], v19, s[12:15], null offen         ; c405407c 40801812 00000013
	buffer_load_b64 v[36:37], v20, s[12:15], null offen         ; c405407c 40801824 00000014
	buffer_load_b64 v[20:21], v21, s[12:15], null offen         ; c405407c 40801814 00000015
	buffer_load_b64 v[40:41], v5, s[12:15], null offen          ; c405407c 40801828 00000005
	ds_load_b64 v[42:43], v54                                   ; d9d80000 2a000036
	ds_load_b64 v[44:45], v54 offset:256                        ; d9d80100 2c000036
	ds_load_b64 v[46:47], v54 offset:512                        ; d9d80200 2e000036
	ds_load_b64 v[48:49], v54 offset:768                        ; d9d80300 30000036
	ds_load_b64 v[50:51], v54 offset:1024                       ; d9d80400 32000036
	ds_load_b64 v[52:53], v54 offset:1280                       ; d9d80500 34000036
	ds_load_b64 v[56:57], v54 offset:1536                       ; d9d80600 38000036
	ds_load_b64 v[58:59], v54 offset:1792                       ; d9d80700 3a000036
	ds_load_b64 v[60:61], v54 offset:2048                       ; d9d80800 3c000036
	ds_load_b64 v[62:63], v54 offset:2304                       ; d9d80900 3e000036
	ds_load_b64 v[64:65], v54 offset:2560                       ; d9d80a00 40000036
	ds_load_b64 v[66:67], v54 offset:2816                       ; d9d80b00 42000036
	ds_load_b64 v[68:69], v54 offset:3072                       ; d9d80c00 44000036
	ds_load_b64 v[70:71], v54 offset:3328                       ; d9d80d00 46000036
	ds_load_b64 v[72:73], v54 offset:3584                       ; d9d80e00 48000036
	ds_load_b64 v[74:75], v54 offset:3840                       ; d9d80f00 4a000036
	s_wait_loadcnt_dscnt 0xf0f                                  ; bfc80f0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[22:23], v[42:43], 0 ; cc464050 1a025516
	s_wait_loadcnt_dscnt 0xe0e                                  ; bfc80e0e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[6:7], v[44:45], v[80:87] ; cc464050 1d425906
	s_wait_loadcnt_dscnt 0xd0d                                  ; bfc80d0d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[46:47], v[80:87] ; cc464050 1d425d18
	s_wait_loadcnt_dscnt 0xc0c                                  ; bfc80c0c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[48:49], v[80:87] ; cc464050 1d426108
	s_wait_loadcnt_dscnt 0xb0b                                  ; bfc80b0b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[26:27], v[50:51], v[80:87] ; cc464050 1d42651a
	s_wait_loadcnt_dscnt 0xa0a                                  ; bfc80a0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[10:11], v[52:53], v[80:87] ; cc464050 1d42690a
	s_wait_loadcnt_dscnt 0x909                                  ; bfc80909
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[56:57], v[80:87] ; cc464050 1d42711c
	s_wait_loadcnt_dscnt 0x808                                  ; bfc80808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[58:59], v[80:87] ; cc464050 1d42750c
	s_wait_loadcnt_dscnt 0x707                                  ; bfc80707
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[30:31], v[60:61], v[80:87] ; cc464050 1d42791e
	s_cmp_lg_i32 s8, 0                                          ; bf018008
	s_wait_loadcnt_dscnt 0x606                                  ; bfc80606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[14:15], v[62:63], v[80:87] ; cc464050 1d427d0e
	s_wait_loadcnt_dscnt 0x505                                  ; bfc80505
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[64:65], v[80:87] ; cc464050 1d428120
	s_wait_loadcnt_dscnt 0x404                                  ; bfc80404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[34:35], v[66:67], v[80:87] ; cc464050 1d428522
	s_wait_loadcnt_dscnt 0x303                                  ; bfc80303
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[68:69], v[80:87] ; cc464050 1d428912
	s_wait_loadcnt_dscnt 0x202                                  ; bfc80202
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[70:71], v[80:87] ; cc464050 1d428d24
	s_wait_loadcnt_dscnt 0x101                                  ; bfc80101
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[72:73], v[80:87] ; cc464050 1d429114
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[74:75], v[80:87] ; cc464050 1d429528
	v_cvt_f16_f32_e32 v29, v87                                  ; 7e3a1557
	v_cvt_f16_f32_e32 v27, v85                                  ; 7e361555
	v_cvt_f16_f32_e32 v22, v80                                  ; 7e2c1550
	v_cvt_f16_f32_e32 v24, v82                                  ; 7e301552
	v_cvt_f16_f32_e32 v23, v81                                  ; 7e2e1551
	v_cvt_f16_f32_e32 v25, v83                                  ; 7e321553
	v_cvt_f16_f32_e32 v26, v84                                  ; 7e341554
	v_cvt_f16_f32_e32 v28, v86                                  ; 7e381556
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc1 BB45                                         ; bfa20063
BB41:
	s_mov_b32 s8, src_scc                                       ; be8800fd
	s_cmp_eq_i32 s19, 2                                         ; bf008213
	s_cbranch_scc0 BB43                                         ; bfa1000c
BB42:
	s_load_b64 s[16:17], s[10:11], 0x60                         ; f4002405 f8000060
	s_wait_kmcnt 0x0                                            ; bfc70000
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v0, v4, v17, vcc_lo                       ; 02002304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v4, v4, v0                                 ; 4a080104
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v0, v4, v16, vcc_lo                       ; 02002104
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v4, v4, v2                                 ; 4a080504
	s_branch BB44                                               ; bfa0000b
BB43:
	s_load_b32 s16, s[10:11], 0x5c                              ; f4000405 f800005c
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v0, v4, v4, vcc_lo                        ; 02000904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_nc_u32_e32 v4, v4, v0                                 ; 4a080104
	s_wait_kmcnt 0x0                                            ; bfc70000
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v0, v4, v16, vcc_lo                       ; 02002104
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v4, v4, v2                                 ; 4a080504
BB44:
	s_load_b64 s[16:17], s[10:11], 0x60                         ; f4002405 f8000060
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s17, s16, s17                                     ; 96111110
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_f32_u32 s18, s17                                      ; be926511
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840012
	v_cndmask_b32_e32 v0, s18, v128, vcc_lo                     ; 02010012
	s_cvt_f32_u32 s29, s16                                      ; be9d6510
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d684001d
	v_cndmask_b32_e32 v0, s29, v128, vcc_lo                     ; 0201001d
	s_mul_f32 s18, s18, 0x4f7ffffe                              ; a212ff12 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s18, s18                                      ; be926712
	s_mul_f32 s29, s29, 0x4f7ffffe                              ; a21dff1d 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s20, s17, s18                                     ; 96141211
	s_cvt_u32_f32 s29, s29                                      ; be9d671d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s20, 0, s20                                    ; 81941480
	s_mul_i32 s30, s16, s29                                     ; 961e1d10
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s20, s18, s20                                  ; 96941412
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s18, s18, s20                                  ; 80121412
	s_sub_co_i32 s30, 0, s30                                    ; 819e1e80
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d0005
	v_cndmask_b32_e32 v0, v4, v18, vcc_lo                       ; 02002504
	s_mul_hi_u32 s30, s29, s30                                  ; 969e1e1d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_add_co_u32 s29, s29, s30                                  ; 801d1e1d
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v5, v17, vcc_lo                       ; 02002305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v4, v4, v6                                 ; 4c080d04
(invalid instruction)                                        ; d7026a07
	v_cndmask_b32_e32 v1, s17, v4, vcc_lo                       ; 02020811
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v7, v7, v4, vcc_lo                        ; 020e0907
	v_subrev_co_ci_u32_e64 v5, s27, -1, v5, vcc_lo              ; d5221b05 01aa0ac1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d7026a08
	v_cndmask_b32_e32 v1, s17, v7, vcc_lo                       ; 02020e11
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v8, v8, v7, vcc_lo                        ; 02100f08
	v_subrev_co_ci_u32_e64 v4, s28, -1, v5, vcc_lo              ; d5221c04 01aa0ac1
(invalid instruction)                                        ; d72d0009
	v_cndmask_b32_e32 v0, v8, v29, vcc_lo                       ; 02003b08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c000a
	v_cndmask_b32_e32 v0, v9, v16, vcc_lo                       ; 02002109
	v_sub_nc_u32_e32 v8, v8, v10                                ; 4c101508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
(invalid instruction)                                        ; d7026a0b
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                       ; 02021010
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v11, v11, v8, vcc_lo                      ; 0216110b
	v_subrev_co_ci_u32_e32 v9, vcc_lo, -1, v9, vcc_lo           ; 441212c1
(invalid instruction)                                        ; d702100c
	v_cndmask_b32_e32 v1, s16, v11, vcc_lo                      ; 02021610
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v12, v12, v11, s16                        ; d501000c 0042170c
	v_subrev_co_ci_u32_e64 v9, vcc_lo, -1, v9, s16              ; d5226a09 004212c1
	s_branch BB46                                               ; bfa00003
BB45:
	v_dual_mov_b32 v12, v2 :: v_dual_mov_b32 v9, v0             ; ca100102 0c080100
	s_mov_b32 s8, src_scc                                       ; be8800fd
BB46:
	s_cmp_lg_i32 s6, 0                                          ; bf018006
	s_cbranch_scc0 BB54                                         ; bfa10009
BB47:
	v_cmpx_gt_u32_e32 s4, v0                                    ; 7d980004
	s_cbranch_execz BB50                                        ; bfa50004
BB48:
	s_load_b32 s6, s[10:11], 0x5c                               ; f4000185 f800005c
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_cmp_le_u32_e32 vcc_lo, s6, v2                             ; 7c960406
BB50:
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_or_not1_b32 s17, vcc_lo, exec_lo                          ; 92117e6a
	s_branch BB55                                               ; bfa00002
BB54:
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_mov_b32 s17, 0                                            ; be910080
BB55:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_not_b32 exec_lo, s17                                      ; befe1e11
	s_cbranch_execz BB61                                        ; bfa50006
BB56:
	s_load_b32 s6, s[10:11], 0x58                               ; f4000185 f8000058
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 2                                        ; 84068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmp_le_u32_e32 vcc_lo, s6, v12                            ; 7c961806
BB61:
	s_and_not1_b32 s6, exec_lo, vcc_lo                          ; 91066a7e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, s6                                       ; befe0006
	s_cbranch_execz BB67                                        ; bfa50006
BB62:
	s_load_b32 s6, s[10:11], 0x70                               ; f4000185 f8000070
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshr_b32 s6, s6, 4                                        ; 85068406
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmp_le_u32_e32 vcc_lo, s6, v4                             ; 7c960806
BB67:
	s_and_not1_b32 s6, exec_lo, vcc_lo                          ; 91066a7e
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_cmp_lg_i32 s5, 0                                          ; bf018005
	s_cbranch_scc0 BB75                                         ; bfa1000a
BB68:
	v_cmpx_gt_u32_e32 s3, v9                                    ; 7d981203
	s_cbranch_execz BB74                                        ; bfa50004
BB69:
	s_load_b32 s5, s[10:11], 0x5c                               ; f4000145 f800005c
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_cmp_le_u32_e32 vcc_lo, s5, v12                            ; 7c961805
BB74:
	s_mov_b32 s17, src_scc                                      ; be9100fd
	s_or_not1_b32 s18, vcc_lo, exec_lo                          ; 92127e6a
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_branch BB76                                               ; bfa00002
BB75:
	s_mov_b32 s17, src_scc                                      ; be9100fd
	s_mov_b32 s18, 0                                            ; be920080
BB76:
	v_cmp_le_u32_e32 vcc_lo, s22, v12                           ; 7c961816
(invalid instruction)                                        ; d44b0005
	v_cndmask_b32_e32 v1, s23, v9, vcc_lo                       ; 02021217
	v_lshrrev_b32_e32 v6, 2, v12                                ; 320c1882
	v_lshrrev_b32_e32 v5, 2, v9                                 ; 320a1282
	s_or_b32 s5, vcc_lo, s5                                     ; 8c05056a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v0, v5, v26, vcc_lo                       ; 02003505
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s5, s9, s5                                        ; 8b050509
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_nor_b32 vcc_lo, s5, s18                                   ; 8f6a1205
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v29, 0, v29, vcc_lo                       ; 023a3a80
	v_dual_cndmask_b32 v27, 0, v27 :: v_dual_cndmask_b32 v28, 0, v28 ; ca523680 1b1c3880
	v_dual_cndmask_b32 v25, 0, v25 :: v_dual_cndmask_b32 v26, 0, v26 ; ca523280 191a3480
	v_dual_cndmask_b32 v23, 0, v23 :: v_dual_and_b32 v12, 3, v12 ; ca642e80 170c1883
	v_dual_cndmask_b32 v22, 0, v22 :: v_dual_and_b32 v9, 3, v9  ; ca642c80 16081283
	v_dual_cndmask_b32 v24, 0, v24 :: v_dual_add_nc_u32 v5, v5, v6 ; ca603080 18040d05
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v9, v9, 2, v12                               ; d6460009 04310509
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v0, v5, v21, vcc_lo                       ; 02002b05
	s_and_b32 exec_lo, s2, s6                                   ; 8b7e0602
	s_cbranch_execz BB82                                        ; bfa5001f
BB77:
	s_load_b128 s[28:31], s[0:1], 0x50                          ; f4004700 f8000050
	s_and_b32 s5, s25, -4                                       ; 8b05c419
	v_cvt_f32_f16_e32 v6, v23                                   ; 7e0c1717
	v_cvt_f32_f16_e32 v7, v22                                   ; 7e0e1716
	v_cvt_f32_f16_e32 v8, v25                                   ; 7e101719
	v_cvt_f32_f16_e32 v10, v24                                  ; 7e141718
	v_cvt_f32_f16_e32 v11, v27                                  ; 7e16171b
	v_cvt_f32_f16_e32 v12, v26                                  ; 7e18171a
	v_cvt_f32_f16_e32 v13, v29                                  ; 7e1a171d
	v_cvt_f32_f16_e32 v14, v28                                  ; 7e1c171c
	v_add_lshl_u32 v5, v5, v4, 8                                ; d6470005 02220905
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v7, v6, vcc_lo                        ; 02020d07
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v10, v8, vcc_lo                       ; 0202110a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v12, v11, vcc_lo                      ; 0202170c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v14, v13, vcc_lo                      ; 02021b0e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_nc_u32_e32 v5, s5, v5                                 ; 4a0a0a05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v9, v9, 4, v5                                ; d6460009 04150909
	v_add_nc_u32_e32 v9, v9, v17                                ; 4a122309
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b64 v[6:7], v9, s[28:31], null offen           ; c406c07c 40803806 00000009
BB82:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_add_co_u32 s7, s7, 1                                      ; 80078107
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_i32 s7, 4                                          ; bf038407
	s_cbranch_scc0 BB84                                         ; bfa1fe3a
BB85:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
