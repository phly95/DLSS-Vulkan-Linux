BB0:
	s_mov_b32 s14, s1                                           ; be8e0001
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b32 s1, s[14:15], 0x54                               ; f4000047 f8000054
	v_and_b32_e32 v1, 7, v0                                     ; 36020087
	v_lshrrev_b32_e32 v2, 3, v0                                 ; 32040083
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v1, ttmp9, 3, v1                             ; d6460001 04050675
	v_lshl_add_u32 v3, ttmp7, 3, v2                             ; d6460003 04090673
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_eq_i32 s1, 0                                          ; bf008001
	s_cbranch_scc0 BB2                                          ; bfa10006
BB1:
	s_load_b32 s11, s[14:15], 0x34                              ; f40002c7 f8000034
	s_mov_b32 s12, src_scc                                      ; be8c00fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s11, s11, 2                                      ; 840b820b
	s_branch BB3                                                ; bfa00002
BB2:
	s_mov_b32 s11, s1                                           ; be8b0001
	s_mov_b32 s12, src_scc                                      ; be8c00fd
BB3:
	s_load_b32 s16, s[14:15], 0x58                              ; f4000407 f8000058
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_eq_i32 s16, 0                                         ; bf008010
	s_cbranch_scc0 BB5                                          ; bfa10006
BB4:
	s_load_b32 s17, s[14:15], 0x38                              ; f4000447 f8000038
	s_mov_b32 s18, src_scc                                      ; be9200fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s17, s17, 2                                      ; 84118211
	s_branch BB6                                                ; bfa00002
BB5:
	s_mov_b32 s17, s16                                          ; be910010
	s_mov_b32 s18, src_scc                                      ; be9200fd
BB6:
	s_mov_b32 s20, s1                                           ; be940001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x2                                                ; bf850002
	s_load_b32 s19, s[14:15], 0x7c                              ; f40004c7 f800007c
	s_load_b256 s[24:31], s[0:1], 0x80                          ; f4006600 f8000080
	s_load_b128 s[32:35], s[0:1], 0xb0                          ; f4004800 f80000b0
	s_lshl1_add_u32 s21, s11, -2                                ; 8715c20b
	v_cmp_gt_u32_e32 vcc_lo, s11, v1                            ; 7c98020b
	s_cvt_f32_u32 s11, s11                                      ; be8b650b
	s_lshl1_add_u32 s22, s17, -2                                ; 8716c211
	s_bitcmp1_b32 s13, 0                                        ; bf0d800d
	v_sub_nc_u32_e32 v4, s21, v1                                ; 4c080215
	v_sub_nc_u32_e32 v5, s22, v3                                ; 4c0a0616
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d684000b
	v_cndmask_b32_e32 v0, s11, v128, vcc_lo                     ; 0201000b
	s_mov_b32 s23, src_scc                                      ; be9700fd
	v_cndmask_b32_e32 v4, v4, v1, vcc_lo                        ; 02080304
	v_cmp_gt_u32_e32 vcc_lo, s17, v3                            ; 7c980611
	s_cvt_f32_u32 s17, s17                                      ; be916511
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d2
	v_cvt_f32_i32_e32 v4, v4                                    ; 7e080b04
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840011
	v_cndmask_b32_e32 v0, s17, v128, vcc_lo                     ; 02010011
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v5, v5, v3, vcc_lo                        ; 020a0705
	v_cvt_f32_i32_e32 v5, v5                                    ; 7e0a0b05
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_and_b32 s36, s35, -2.0                                    ; 8b24f523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a1
	v_dual_add_f32 v7, 0.5, v5 :: v_dual_add_f32 v6, 0.5, v4    ; c9080af0 070608f0
	s_cmp_eq_i32 s36, -2.0                                      ; bf00f524
	s_and_b32 s37, s23, src_scc                                 ; 8b25fd17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c1
	v_dual_mul_f32 v7, s17, v7 :: v_dual_mul_f32 v6, s11, v6    ; c8c60e11 07060c0b
	s_mov_b32 s38, src_scc                                      ; bea600fd
	s_and_b32 s39, s35, 0x3fffffff                              ; 8b27ff23 3fffffff
	s_cmp_lg_i32 s38, 0                                         ; bf018026
	s_cselect_b32 s35, s39, s35                                 ; 98232327
	image_sample_lz v[8:10], [v6, v7], s[24:31], s[32:35] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 10003008 00000706
	s_cmp_lg_i32 s19, 0                                         ; bf018013
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_cvt_f16_f32_e32 v11, v8                                   ; 7e161508
(invalid instruction)                                        ; 7f161509
	v_cvt_f16_f32_e32 v12, v10                                  ; 7e18150a
	s_cbranch_scc0 BB8                                          ; bfa10011
BB7:
	s_load_b128 s[36:39], s[0:1], 0x40                          ; f4004900 f8000040
	s_mov_b32 s13, src_scc                                      ; be8d00fd
	s_lshl_b32 s21, s10, 3                                      ; 8415830a
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72c0008
	v_cndmask_b32_e32 v0, v3, v21, vcc_lo                       ; 02002b03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v8, v8, v1, 1                                ; d6470008 02060308
	v_add_lshl_u32 v8, s19, v8, 2                               ; d6470008 020a1013
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b64 v[8:9], v8, s[36:39], null offen            ; c405407c 40804808 00000008
	s_branch BB9                                                ; bfa00089
BB8:
	s_clause 0x1                                                ; bf850001
	s_load_b32 s13, s[14:15], 0x5c                              ; f4000347 f800005c
	s_load_b32 s36, s[14:15], 0x74                              ; f4000907 f8000074
(invalid instruction)                                        ; d72c0008
	v_cndmask_b32_e32 v1, 0x8da6b343, v1, vcc_lo                ; 020202ff 8da6b343
(invalid instruction)                                        ; d72c0009
	v_cndmask_b32_e32 v1, 0xd8163841, v3, vcc_lo                ; 020206ff d8163841
	s_mov_b32 s21, 0x108ef2d9                                   ; be9500ff 108ef2d9
	s_mov_b32 s22, 0x33800000                                   ; be9600ff 33800000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s13, s13, 0x9e3779b9                              ; 960dff0d 9e3779b9
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_xor3_b32 v9, v9, s13, v8                                  ; d6400009 04201b09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v9, 0x243f6a88, v9                            ; 3a1212ff 243f6a88
	v_lshrrev_b32_e32 v10, 28, v9                               ; 3214129c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v10, 4, v10                                ; 4a141484
	v_lshrrev_b32_e32 v10, v10, v9                              ; 3214130a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_xor_b32_e32 v10, v10, v9                                  ; 3a14130a
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72c000a
	v_cndmask_b32_e32 v1, s21, v10, vcc_lo                      ; 02021415
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v13, 22, v10                              ; 321a1496
	v_xor_b32_e32 v13, v13, v10                                 ; 3a1a150d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v1, 0x2c9277b5, v13, vcc_lo               ; 02021aff 2c9277b5
(invalid instruction)                                        ; d72c0011
	v_cndmask_b32_e32 v1, 0xfa6dc5f9, v13, vcc_lo               ; 02021aff fa6dc5f9
(invalid instruction)                                        ; d72c0014
	v_cndmask_b32_e32 v1, 0xcaa5b80d, v13, vcc_lo               ; 02021aff caa5b80d
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v1, 0x83232c31, v13, vcc_lo               ; 02021aff 83232c31
	v_add_nc_u32_e32 v14, 0xac564b05, v14                       ; 4a1c1cff ac564b05
	v_add_nc_u32_e32 v17, 0x4712a88e, v17                       ; 4a2222ff 4712a88e
	v_add_nc_u32_e32 v20, 0x21dd796b, v20                       ; 4a2828ff 21dd796b
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_lshrrev_b32_e32 v15, 28, v14                              ; 321e1c9c
	v_lshrrev_b32_e32 v18, 28, v17                              ; 3224229c
	v_add_nc_u32_e32 v13, 0x3463e0ac, v13                       ; 4a1a1aff 3463e0ac
	v_lshrrev_b32_e32 v21, 28, v20                              ; 322a289c
	v_add_nc_u32_e32 v15, 4, v15                                ; 4a1e1e84
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_lshrrev_b32_e32 v23, 28, v13                              ; 322e1a9c
	v_add_nc_u32_e32 v21, 4, v21                                ; 4a2a2a84
	v_lshrrev_b32_e32 v15, v15, v14                             ; 321e1d0f
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_add_nc_u32_e32 v23, 4, v23                                ; 4a2e2e84
	v_xor_b32_e32 v15, v15, v14                                 ; 3a1e1d0f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c000f
	v_cndmask_b32_e32 v1, s21, v15, vcc_lo                      ; 02021e15
	v_lshrrev_b32_e32 v16, 8, v15                               ; 32201e88
	v_lshrrev_b32_e32 v15, 30, v15                              ; 321e1e9e
	v_lshrrev_b32_e32 v21, v21, v20                             ; 322a2915
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_xad_u32 v15, v15, v16, 1                                  ; d645000f 0206210f
	v_xor_b32_e32 v21, v21, v20                                 ; 3a2a2915
	v_cvt_f32_u32_e32 v15, v15                                  ; 7e1e0d0f
(invalid instruction)                                        ; d72c0015
	v_cndmask_b32_e32 v1, s21, v21, vcc_lo                      ; 02022a15
	v_dual_mul_f32 v15, s22, v15 :: v_dual_add_nc_u32 v18, 4, v18 ; c8e01e16 0f122484
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v18, v18, v17                             ; 32242312
	v_log_f32_e32 v15, v15                                      ; 7e1e4f0f
	v_lshrrev_b32_e32 v23, v23, v13                             ; 322e1b17
	v_lshrrev_b32_e32 v22, 8, v21                               ; 322c2a88
	v_lshrrev_b32_e32 v21, 30, v21                              ; 322a2a9e
	v_xor_b32_e32 v18, v18, v17                                 ; 3a242312
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_xor_b32_e32 v23, v23, v13                                 ; 3a2e1b17
(invalid instruction)                                        ; d72c0012
	v_cndmask_b32_e32 v1, s21, v18, vcc_lo                      ; 02022415
(invalid instruction)                                        ; d72c0017
	v_cndmask_b32_e32 v1, s21, v23, vcc_lo                      ; 02022e15
	v_xad_u32 v21, v21, v22, 1                                  ; d6450015 02062d15
	v_lshrrev_b32_e32 v19, 8, v18                               ; 32262488
	v_lshrrev_b32_e32 v18, 30, v18                              ; 3224249e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_cvt_f32_u32_e32 v21, v21                                  ; 7e2a0d15
	v_lshrrev_b32_e32 v24, 8, v23                               ; 32302e88
	v_lshrrev_b32_e32 v23, 30, v23                              ; 322e2e9e
	v_xad_u32 v18, v18, v19, 1                                  ; d6450012 02062712
	v_mul_f32_e32 v21, s22, v21                                 ; 102a2a16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_xad_u32 v23, v23, v24, 1                                  ; d6450017 02063117
	v_cvt_f32_u32_e32 v18, v18                                  ; 7e240d12
	v_log_f32_e32 v21, v21                                      ; 7e2a4f15
	v_cvt_f32_u32_e32 v23, v23                                  ; 7e2e0d17
	s_mov_b32 s13, src_scc                                      ; be8d00fd
	v_dual_mul_f32 v15, 0xbfb17218, v15 :: v_dual_mul_f32 v18, s22, v18 ; c8c61eff 0f122416 bfb17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_mul_f32_e32 v23, s22, v23                                 ; 102e2e16
	v_sqrt_f32_e32 v15, v15                                     ; 7e1e670f
	v_cos_f32_e32 v25, v18                                      ; 7e326d12
	v_sin_f32_e32 v18, v18                                      ; 7e246b12
	v_mul_f32_e32 v21, 0xbfb17218, v21                          ; 102a2aff bfb17218
	v_cos_f32_e32 v23, v23                                      ; 7e2e6d17
	v_mul_f32_e32 v25, v15, v25                                 ; 1032330f
	v_sqrt_f32_e32 v21, v21                                     ; 7e2a6715
	v_mul_f32_e32 v15, v15, v18                                 ; 101e250f
	v_fma_mixlo_f16 v8, s36, v25, neg(0) op_sel_hi:[0,0,1]      ; cc214008 82023224
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mixhi_f16 v8, s36, v15, neg(0) op_sel_hi:[0,0,1]      ; cc224008 82021e24
	v_mul_f32_e32 v21, v21, v23                                 ; 102a2f15
	v_fma_mixlo_f16 v9, s36, v21, neg(0) op_sel_hi:[0,0,1]      ; cc214009 82022a24
BB9:
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[36:39], s[0:1], 0x60                          ; f4004900 f8000060
	s_load_b32 s21, s[14:15], 0x78                              ; f4000547 f8000078
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s37, 14                                       ; bea5108e
	s_buffer_load_b32 s22, s[36:39], 0x0                        ; f4020592 f8000000
(invalid instruction)                                        ; cc0f000b
	v_subrev_f32_e32 v0, v11, v241                              ; 0a01e30b
	v_add_f16_e32 v12, -0.5, v12                                ; 641818f1
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; cc10000a
	v_subrev_f32_e32 v0, v11, v255                              ; 0a01ff0b
(invalid instruction)                                        ; 00003000
(invalid instruction)                                        ; 6b1818ff
(invalid instruction)                                        ; 00003000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_neq_f32 s22, 0                                        ; bf4d8016
	s_cbranch_scc0 BB14                                         ; bfa1012c
BB10:
	s_buffer_load_b256 s[40:47], s[36:39], 0x10                 ; f4026a12 f8000010
	s_mov_b32 s22, src_scc                                      ; be9600fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_neq_f32 s42, 0                                        ; bf4d802a
	s_cbranch_scc0 BB12                                         ; bfa10058
BB11:
	s_clause 0x1                                                ; bf850001
	s_load_b256 s[48:55], s[0:1], 0x140                         ; f4006c00 f8000140
	s_load_b128 s[56:59], s[0:1], 0x170                         ; f4004e00 f8000170
	v_add_f32_e32 v11, -0.5, v4                                 ; 061608f1
	v_add_f32_e32 v13, -0.5, v5                                 ; 061a0af1
	v_dual_add_f32 v5, 0x3fc00000, v5 :: v_dual_add_f32 v4, 0x3fc00000, v4 ; c9080aff 050408ff 3fc00000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d3
	v_mul_f32_e32 v11, s11, v11                                 ; 1016160b
	v_mul_f32_e32 v13, s17, v13                                 ; 101a1a11
	v_dual_mul_f32 v5, s17, v5 :: v_dual_mul_f32 v4, s11, v4    ; c8c60a11 0504080b
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_and_b32 s42, s59, -2.0                                    ; 8b2af53b
	s_cmp_eq_i32 s42, -2.0                                      ; bf00f52a
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s60, s23, src_scc                                 ; 8b3cfd17
	s_mov_b32 s61, src_scc                                      ; bebd00fd
	s_and_b32 s62, s59, 0x3fffffff                              ; 8b3eff3b 3fffffff
	s_cmp_lg_i32 s61, 0                                         ; bf01803d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s59, s62, s59                                 ; 983b3b3e
	s_clause 0x4                                                ; bf850004
	image_sample_lz v14, [v6, v7], s[48:55], s[56:59] dmask:0x1 dim:SQ_RSRC_IMG_2D ; e447c001 1c00600e 00000706
	image_sample_lz v15, [v11, v13], s[48:55], s[56:59] dmask:0x1 dim:SQ_RSRC_IMG_2D ; e447c001 1c00600f 00000d0b
	image_sample_lz v16, [v4, v13], s[48:55], s[56:59] dmask:0x1 dim:SQ_RSRC_IMG_2D ; e447c001 1c006010 00000d04
	image_sample_lz v17, [v11, v5], s[48:55], s[56:59] dmask:0x1 dim:SQ_RSRC_IMG_2D ; e447c001 1c006011 0000050b
	image_sample_lz v18, [v4, v5], s[48:55], s[56:59] dmask:0x1 dim:SQ_RSRC_IMG_2D ; e447c001 1c006012 00000504
	s_cmp_neq_f32 s43, 0                                        ; bf4d802b
	s_wait_samplecnt 0x3                                        ; bfc20003
	v_cmp_lt_f32_e32 vcc_lo, v14, v15                           ; 7c221f0e
(invalid instruction)                                        ; d411003f
	v_cndmask_b32_e32 v1, v15, v14, vcc_lo                      ; 02021d0f
	s_cselect_b32 vcc_lo, vcc_lo, s63                           ; 986a3f6a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v14, v14, v15, vcc_lo                     ; 021c1f0e
	v_cndmask_b32_e32 v19, v6, v11, vcc_lo                      ; 02261706
	s_wait_samplecnt 0x2                                        ; bfc20002
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b2
(invalid instruction)                                        ; d4110040
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                      ; 0202210e
(invalid instruction)                                        ; d4110041
	v_cndmask_b32_e32 v1, v16, v14, vcc_lo                      ; 02021d10
	s_cselect_b32 s64, s64, s65                                 ; 98404140
	v_cndmask_b32_e64 v19, v19, v4, s64                         ; d5010013 01020913
	s_or_b32 vcc_lo, s64, vcc_lo                                ; 8c6a6a40
	s_cmp_neq_f32 s43, 0                                        ; bf4d802b
	v_cndmask_b32_e64 v14, v14, v16, s64                        ; d501000e 0102210e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v13, v7, v13, vcc_lo                      ; 021a1b07
	s_wait_samplecnt 0x1                                        ; bfc20001
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_cmp_lt_f32_e32 vcc_lo, v14, v17                           ; 7c22230e
(invalid instruction)                                        ; d4110043
	v_cndmask_b32_e32 v1, v17, v14, vcc_lo                      ; 02021d11
	s_cselect_b32 vcc_lo, vcc_lo, s67                           ; 986a436a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v19, v19, v11 :: v_dual_cndmask_b32 v14, v14, v17 ; ca521713 130e230e
	s_wait_samplecnt 0x0                                        ; bfc20000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b1
(invalid instruction)                                        ; d4110044
	v_cndmask_b32_e32 v1, v14, v18, vcc_lo                      ; 0202250e
(invalid instruction)                                        ; d4110045
	v_cndmask_b32_e32 v1, v18, v14, vcc_lo                      ; 02021d12
	s_cselect_b32 s68, s68, s69                                 ; 98444544
	s_or_b32 vcc_lo, s68, vcc_lo                                ; 8c6a6a44
	v_cndmask_b32_e64 v19, v19, v4, s68                         ; d5010013 01120913
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v13, v13, v5, vcc_lo                      ; 021a0b0d
	s_branch BB13                                               ; bfa00002
BB12:
	v_mov_b32_e32 v13, v7                                       ; 7e1a0307
	v_mov_b32_e32 v19, v6                                       ; 7e260306
BB13:
	s_clause 0x3                                                ; bf850003
	s_load_b256 s[48:55], s[0:1], 0xc0                          ; f4006c00 f80000c0
	s_load_b128 s[56:59], s[0:1], 0xf0                          ; f4004e00 f80000f0
	s_load_b256 s[64:71], s[0:1], 0x100                         ; f4007000 f8000100
	s_load_b128 s[60:63], s[0:1], 0x130                         ; f4004f00 f8000130
	v_fma_f32 v13, s45, v13, s47                                ; d613000d 00be1a2d
	v_fma_f32 v19, s44, v19, s46                                ; d6130013 00ba262c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_and_b32 s11, s59, -2.0                                    ; 8b0bf53b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_eq_i32 s11, -2.0                                      ; bf00f50b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s17, s23, src_scc                                 ; 8b11fd17
	s_mov_b32 s42, src_scc                                      ; beaa00fd
	s_and_b32 s43, s59, 0x3fffffff                              ; 8b2bff3b 3fffffff
	s_cmp_lg_i32 s42, 0                                         ; bf01802a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s59, s43, s59                                 ; 983b3b2b
	image_sample_lz v[4:5], [v19, v13], s[48:55], s[56:59] dmask:0x3 dim:SQ_RSRC_IMG_2D ; e4c7c001 1c006004 00000d13
	s_buffer_load_b64 s[42:43], s[36:39], 0x4                   ; f4022a92 f8000004
	s_mov_b32 s44, 0x40200000                                   ; beac00ff 40200000
	s_add_f32 s45, s40, -0.5                                    ; a02df128
	s_add_f32 s46, s41, -0.5                                    ; a02ef129
	s_wait_samplecnt 0x0                                        ; bfc20000
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_fmac_f32_e32 v7, s43, v5                                  ; 560e0a2b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_f32 v11, s41, v7, -0.5                                ; d613000b 03c60e29
	v_floor_f32_e32 v11, v11                                    ; 7e16490b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v13, 0.5, v11                                 ; 061a16f0
	v_fma_f32 v7, s41, v7, -v13 clamp                           ; d6138007 84360e29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v14, v7, v7                                   ; 101c0f07
	v_mul_f32_e32 v15, v14, v7                                  ; 101e0f0e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d5030007
(invalid instruction)                                        ; 7a021f07
	v_fma_f32 v16, 0x3fc00000, v15, 1.0                         ; d6130010 03ca1eff 3fc00000
(invalid instruction)                                        ; d504000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[14:15]                ; 1a021d0f
(invalid instruction)                                        ; d6840029
	v_cndmask_b32_e32 v0, s41, v128, vcc_lo                     ; 02010029
	s_and_b32 s47, s63, -2.0                                    ; 8b2ff53f
	v_add_f32_e32 v7, v7, v14                                   ; 060e1d07
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_eq_i32 s47, -2.0                                      ; bf00f52f
	v_fma_f32 v16, -s44, v14, v16                               ; d6130010 24421c2c
	s_and_b32 s48, s23, src_scc                                 ; 8b30fd17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_sub_f32_e32 v17, 1.0, v7                                  ; 08220ef2
	s_mov_b32 s49, src_scc                                      ; beb100fd
	s_and_b32 s50, s63, 0x3fffffff                              ; 8b32ff3f 3fffffff
	s_cmp_lg_i32 s49, 0                                         ; bf018031
	v_sub_f32_e32 v17, v17, v16                                 ; 08222111
	s_cselect_b32 s63, s50, s63                                 ; 983f3f32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_sub_f32 v17, v17, v15 :: v_dual_fmac_f32 v6, s42, v4 ; c9401f11 1106082a
	v_fma_f32 v4, s40, v6, -0.5                                 ; d6130004 03c60c28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_floor_f32_e32 v4, v4                                      ; 7e084904
	v_dual_add_f32 v5, 0.5, v4 :: v_dual_add_f32 v16, v16, v17  ; c90808f0 05102310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1) ; bf8702b1
	v_fma_f32 v6, s40, v6, -v5 clamp                            ; d6138006 84160c28
(invalid instruction)                                        ; d6840028
	v_cndmask_b32_e32 v0, s40, v128, vcc_lo                     ; 02010028
	v_rcp_f32_e32 v19, v16                                      ; 7e265510
	v_dual_fmac_f32 v13, v17, v19 :: v_dual_add_f32 v18, -0.5, v4 ; c8082711 0d1208f1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_maxmin_num_f32 v13, 0.5, v13, s46                         ; d669000d 00ba1af0
	v_maxmin_num_f32 v18, 0.5, v18, s45                         ; d6690012 00b624f0
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_dual_mul_f32 v13, s41, v13 :: v_dual_mul_f32 v18, s40, v18 ; c8c61a29 0d122428
	image_sample_lz v[20:22], [v18, v13], s[64:71], s[60:63] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1e008014 00000d12
	v_mul_f32_e32 v23, v6, v6                                   ; 102e0d06
	v_add_f32_e32 v27, -0.5, v11                                ; 063616f1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_mul_f32_e32 v24, v23, v6                                  ; 10300d17
	v_dual_add_f32 v11, s44, v11 :: v_dual_add_f32 v4, s44, v4  ; c908162c 0b04082c
	v_maxmin_num_f32 v27, 0.5, v27, s46                         ; d669001b 00ba36f0
(invalid instruction)                                        ; d5030006
(invalid instruction)                                        ; 7a023106
	v_fma_f32 v25, 0x3fc00000, v24, 1.0                         ; d6130019 03ca30ff 3fc00000
(invalid instruction)                                        ; d5040018
	v_min_num_f64_e32 v[1:2], v[24:25], v[23:24]                ; 1a022f18
	v_maxmin_num_f32 v11, 0.5, v11, s46                         ; d669000b 00ba16f0
	v_maxmin_num_f32 v4, 0.5, v4, s45                           ; d6690004 00b608f0
	v_mul_f32_e32 v27, s41, v27                                 ; 10363629
	v_add_f32_e32 v6, v6, v23                                   ; 060c2f06
	v_fma_f32 v25, -s44, v23, v25                               ; d6130019 24662e2c
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v11, s41, v11 :: v_dual_mul_f32 v4, s40, v4  ; c8c61629 0b040828
	v_sub_f32_e32 v26, 1.0, v6                                  ; 08340cf2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_f32_e32 v26, v26, v25                                 ; 0834331a
	v_sub_f32_e32 v26, v26, v24                                 ; 0834311a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v25, v25, v26                                 ; 06323519
	v_rcp_f32_e32 v28, v25                                      ; 7e385519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_fmac_f32_e32 v5, v26, v28                                 ; 560a391a
	v_maxmin_num_f32 v5, 0.5, v5, s45                           ; d6690005 00b60af0
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v5, s40, v5                                   ; 100a0a28
	s_clause 0x3                                                ; bf850003
	image_sample_lz v[29:31], [v5, v27], s[64:71], s[60:63] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1e00801d 00001b05
	image_sample_lz v[32:34], [v5, v13], s[64:71], s[60:63] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1e008020 00000d05
	image_sample_lz v[35:37], [v5, v11], s[64:71], s[60:63] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1e008023 00000b05
	image_sample_lz v[38:40], [v4, v13], s[64:71], s[60:63] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1e008026 00000d04
	v_mul_f32_e32 v24, v24, v16                                 ; 10302118
	v_mul_f32_e32 v6, v6, v16                                   ; 100c2106
	s_wait_samplecnt 0x4                                        ; bfc20004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v22, v22, v6 :: v_dual_mul_f32 v7, v7, v25   ; c8c60d16 16063307
	v_mul_f32_e32 v20, v20, v6                                  ; 10280d14
	v_dual_mul_f32 v21, v21, v6 :: v_dual_add_f32 v6, v6, v7    ; c8c80d15 15060f06
	s_wait_samplecnt 0x3                                        ; bfc20003
	v_dual_fmac_f32 v22, v31, v7 :: v_dual_mul_f32 v41, v25, v16 ; c8060f1f 16282119
	v_fmac_f32_e32 v20, v29, v7                                 ; 56280f1d
	s_wait_samplecnt 0x2                                        ; bfc20002
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_fmac_f32_e32 v22, v34, v41                                ; 562c5322
	v_dual_add_f32 v6, v41, v6 :: v_dual_mul_f32 v15, v15, v25  ; c9060d29 060e330f
	v_fmac_f32_e32 v20, v32, v41                                ; 56285320
	s_wait_samplecnt 0x1                                        ; bfc20001
	v_dual_fmac_f32 v22, v15, v37 :: v_dual_fmac_f32 v21, v30, v7 ; c8004b0f 16140f1e
	v_fmac_f32_e32 v20, v35, v15                                ; 56281f23
	s_wait_samplecnt 0x0                                        ; bfc20000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fmac_f32_e32 v22, v40, v24                                ; 562c3128
	v_dual_add_f32 v6, v6, v15 :: v_dual_fmac_f32 v21, v33, v41 ; c9001f06 06145321
	v_dual_fmac_f32 v20, v38, v24 :: v_dual_fmac_f32 v21, v36, v15 ; c8003126 14141f24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_add_f32 v6, v6, v24 :: v_dual_fmac_f32 v21, v39, v24 ; c9003106 06143127
	v_rcp_f32_e32 v6, v6                                        ; 7e0c5506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870135
	v_fma_mixlo_f16 v42, v20, v6, neg(0) op_sel_hi:[0,0,1]      ; cc21402a 82020d14
	v_fma_mixhi_f16 v42, v21, v6, neg(0) op_sel_hi:[0,0,1]      ; cc22402a 82020d15
	v_fma_mixlo_f16 v43, v22, v6, neg(0) op_sel_hi:[0,0,1]      ; cc21402b 82020d16
(invalid instruction)                                        ; cc0f002a
	v_subrev_f32_e32 v0, v42, v241                              ; 0a01e32a
	v_add_f16_e32 v43, -0.5, v43                                ; 645656f1
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; cc10002a
	v_subrev_f32_e32 v0, v42, v255                              ; 0a01ff2a
(invalid instruction)                                        ; 00003000
(invalid instruction)                                        ; 6b0856ff
(invalid instruction)                                        ; 00003000
	s_branch BB15                                               ; bfa00003
BB14:
	v_mov_b32_e32 v42, v10                                      ; 7e54030a
	s_mov_b32 s22, src_scc                                      ; be9600fd
	v_mov_b16_e32 v4.h, v12.h                                   ; 7f08398c
BB15:
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[40:43], s[14:15], 0x60                        ; f4004a07 f8000060
	s_load_b32 s11, s[14:15], 0x70                              ; f40002c7 f8000070
	v_lshlrev_b32_e32 v2, 2, v2                                 ; 30040482
	v_and_b32_e32 v6, 3, v0                                     ; 360c0083
	v_bfe_u32 v5, v1, 2, 1                                      ; d6100005 02050501
	v_bfe_u32 v3, v3, 2, 1                                      ; d6100003 02050503
	s_cvt_f16_f32 s21, s21                                      ; be956815
	v_alignbyte_b32 v11, v42, v12, 2                            ; d617000b 020a192a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_lshl_add_u32 v3, v3, 1, v5                                ; d6460003 04150303
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_mov_b16_e32 v17.h, s21                                    ; 7f223815
	v_lshl_add_u32 v3, v3, 4, v2                                ; d6460003 04090903
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v9.h, v17.h                                   ; 7f123991
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_lshl_u32 v3, v3, v6, 5                                ; d6470003 02160d03
	ds_store_b128 v3, v[8:11]                                   ; db7c0000 00000803
	v_add_nc_u32_e32 v7, 32, v0                                 ; 4a0e00a0
	v_perm_b32 v12, v4, v42, 0x7060302                          ; d644000c 03fe5504 07060302
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cvt_f16_f32 s41, s41                                      ; bea96829
	s_cvt_f16_f32 s42, s42                                      ; beaa682a
	s_cvt_f16_f32 s43, s43                                      ; beab682b
	s_cvt_f16_f32 s40, s40                                      ; bea86828
	s_cvt_f16_f32 s11, s11                                      ; be8b680b
	v_lshrrev_b32_e32 v7, 3, v7                                 ; 320e0e83
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_pack_ll_b32_b16 s42, s42, s43                             ; 992a2b2a
	s_pack_ll_b32_b16 s40, s40, s41                             ; 99282928
	s_pack_ll_b32_b16 s11, s11, 0                               ; 990b800b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_mov_b32_e32 v13, s40                                      ; 7e1a0228
	v_lshl_add_u32 v8, ttmp7, 3, v7                             ; d6460008 041d0673
	v_dual_mov_b32 v15, s11 :: v_dual_mov_b32 v14, s42          ; ca10000b 0f0e002a
	ds_store_b128 v3, v[12:15] offset:16                        ; db7c0010 00000c03
	s_cmp_lg_i32 s12, 0                                         ; bf01800c
	s_cbranch_scc0 BB18                                         ; bfa10006
BB16:
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s12, s12, 2                                      ; 840c820c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s20, s12                                          ; be94000c
BB18:
	s_cmp_lg_i32 s18, 0                                         ; bf018012
	s_cbranch_scc0 BB21                                         ; bfa10004
BB19:
	s_load_b32 s12, s[14:15], 0x38                              ; f4000307 f8000038
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s16, s12, 2                                      ; 8410820c
BB21:
	s_lshl1_add_u32 s12, s20, -2                                ; 870cc214
	v_cmp_gt_u32_e32 vcc_lo, s20, v1                            ; 7c980214
	s_cvt_f32_u32 s20, s20                                      ; be946514
	s_lshl1_add_u32 s17, s16, -2                                ; 8711c210
	v_sub_nc_u32_e32 v2, s12, v1                                ; 4c04020c
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_sub_nc_u32_e32 v3, s17, v8                                ; 4c061011
(invalid instruction)                                        ; d6840014
	v_cndmask_b32_e32 v0, s20, v128, vcc_lo                     ; 02010014
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_cndmask_b32_e32 v2, v2, v1, vcc_lo                        ; 02040302
	v_cmp_gt_u32_e32 vcc_lo, s16, v8                            ; 7c981010
	s_cvt_f32_u32 s16, s16                                      ; be906510
	v_cvt_f32_i32_e32 v2, v2                                    ; 7e040b02
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v3, v3, v8, vcc_lo                        ; 02061103
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840010
	v_cndmask_b32_e32 v0, s16, v128, vcc_lo                     ; 02010010
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_cvt_f32_i32_e32 v3, v3                                    ; 7e060b03
	v_dual_add_f32 v9, 0.5, v3 :: v_dual_add_f32 v4, 0.5, v2    ; c90806f0 090404f0
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v9, s16, v9 :: v_dual_mul_f32 v4, s20, v4    ; c8c61210 09040814
	image_sample_lz v[10:12], [v4, v9], s[24:31], s[32:35] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1000300a 00000904
	s_cmp_lg_i32 s13, 0                                         ; bf01800d
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_cvt_f16_f32_e32 v13, v10                                  ; 7e1a150a
	v_cvt_f16_f32_e32 v14, v12                                  ; 7e1c150c
(invalid instruction)                                        ; 7f1a150b
	s_cbranch_scc0 BB23                                         ; bfa10010
BB22:
	s_load_b128 s[24:27], s[0:1], 0x40                          ; f4004600 f8000040
	s_lshl_b32 s12, s10, 3                                      ; 840c830a
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72c000a
	v_cndmask_b32_e32 v0, v8, v12, vcc_lo                       ; 02001908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v10, v10, v1, 1                              ; d647000a 0206030a
	v_add_lshl_u32 v10, s19, v10, 2                             ; d647000a 020a1413
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b64 v[10:11], v10, s[24:27], null offen         ; c405407c 4080300a 0000000a
	s_branch BB24                                               ; bfa00086
BB23:
	s_clause 0x1                                                ; bf850001
	s_load_b32 s12, s[14:15], 0x5c                              ; f4000307 f800005c
	s_load_b32 s18, s[14:15], 0x74                              ; f4000487 f8000074
(invalid instruction)                                        ; d72c0001
	v_cndmask_b32_e32 v1, 0x8da6b343, v1, vcc_lo                ; 020202ff 8da6b343
(invalid instruction)                                        ; d72c000a
	v_cndmask_b32_e32 v1, 0xd8163841, v8, vcc_lo                ; 020210ff d8163841
	s_mov_b32 s13, 0x108ef2d9                                   ; be8d00ff 108ef2d9
	s_mov_b32 s17, 0x33800000                                   ; be9100ff 33800000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s12, s12, 0x9e3779b9                              ; 960cff0c 9e3779b9
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_xor3_b32 v10, v10, s12, v1                                ; d640000a 0404190a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v10, 0x243f6a88, v10                          ; 3a1414ff 243f6a88
	v_lshrrev_b32_e32 v11, 28, v10                              ; 3216149c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v11, 4, v11                                ; 4a161684
	v_lshrrev_b32_e32 v11, v11, v10                             ; 3216150b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v11, v11, v10                                 ; 3a16150b
(invalid instruction)                                        ; d72c000b
	v_cndmask_b32_e32 v1, s13, v11, vcc_lo                      ; 0202160d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v12, 22, v11                              ; 32181696
	v_xor_b32_e32 v12, v12, v11                                 ; 3a18170c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d72c000f
	v_cndmask_b32_e32 v1, 0x2c9277b5, v12, vcc_lo               ; 020218ff 2c9277b5
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v1, 0xfa6dc5f9, v12, vcc_lo               ; 020218ff fa6dc5f9
(invalid instruction)                                        ; d72c0016
	v_cndmask_b32_e32 v1, 0xcaa5b80d, v12, vcc_lo               ; 020218ff caa5b80d
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v1, 0x83232c31, v12, vcc_lo               ; 020218ff 83232c31
	v_add_nc_u32_e32 v15, 0xac564b05, v15                       ; 4a1e1eff ac564b05
	v_add_nc_u32_e32 v19, 0x4712a88e, v19                       ; 4a2626ff 4712a88e
	v_add_nc_u32_e32 v22, 0x21dd796b, v22                       ; 4a2c2cff 21dd796b
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_lshrrev_b32_e32 v16, 28, v15                              ; 32201e9c
	v_lshrrev_b32_e32 v20, 28, v19                              ; 3228269c
	v_add_nc_u32_e32 v12, 0x3463e0ac, v12                       ; 4a1818ff 3463e0ac
	v_lshrrev_b32_e32 v23, 28, v22                              ; 322e2c9c
	v_add_nc_u32_e32 v16, 4, v16                                ; 4a202084
	v_add_nc_u32_e32 v20, 4, v20                                ; 4a282884
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_lshrrev_b32_e32 v16, v16, v15                             ; 32201f10
	v_lshrrev_b32_e32 v20, v20, v19                             ; 32282714
	v_lshrrev_b32_e32 v25, 28, v12                              ; 3232189c
	v_xor_b32_e32 v16, v16, v15                                 ; 3a201f10
	v_xor_b32_e32 v20, v20, v19                                 ; 3a282714
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
(invalid instruction)                                        ; d72c0010
	v_cndmask_b32_e32 v1, s13, v16, vcc_lo                      ; 0202200d
(invalid instruction)                                        ; d72c0014
	v_cndmask_b32_e32 v1, s13, v20, vcc_lo                      ; 0202280d
	v_lshrrev_b32_e32 v18, 8, v16                               ; 32242088
	v_lshrrev_b32_e32 v16, 30, v16                              ; 3220209e
	v_lshrrev_b32_e32 v21, 8, v20                               ; 322a2888
	v_lshrrev_b32_e32 v20, 30, v20                              ; 3228289e
	v_xad_u32 v16, v16, v18, 1                                  ; d6450010 02062510
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_xad_u32 v20, v20, v21, 1                                  ; d6450014 02062b14
	v_cvt_f32_u32_e32 v16, v16                                  ; 7e200d10
	v_cvt_f32_u32_e32 v20, v20                                  ; 7e280d14
	v_dual_mul_f32 v16, s17, v16 :: v_dual_add_nc_u32 v23, 4, v23 ; c8e02011 10162e84
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_mul_f32_e32 v20, s17, v20                                 ; 10282811
	v_log_f32_e32 v16, v16                                      ; 7e204f10
	v_lshrrev_b32_e32 v23, v23, v22                             ; 322e2d17
	v_cos_f32_e32 v27, v20                                      ; 7e366d14
	v_xor_b32_e32 v23, v23, v22                                 ; 3a2e2d17
	v_dual_mul_f32 v16, 0xbfb17218, v16 :: v_dual_add_nc_u32 v25, 4, v25 ; c8e020ff 10183284 bfb17218
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d72c0017
	v_cndmask_b32_e32 v1, s13, v23, vcc_lo                      ; 02022e0d
	v_sqrt_f32_e32 v16, v16                                     ; 7e206710
	v_lshrrev_b32_e32 v25, v25, v12                             ; 32321919
	v_sin_f32_e32 v20, v20                                      ; 7e286b14
	v_lshrrev_b32_e32 v24, 8, v23                               ; 32302e88
	v_lshrrev_b32_e32 v23, 30, v23                              ; 322e2e9e
	v_xor_b32_e32 v25, v25, v12                                 ; 3a321919
	v_mul_f32_e32 v27, v16, v27                                 ; 10363710
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c3
	v_xad_u32 v23, v23, v24, 1                                  ; d6450017 02063117
(invalid instruction)                                        ; d72c0019
	v_cndmask_b32_e32 v1, s13, v25, vcc_lo                      ; 0202320d
	v_fma_mixlo_f16 v10, s18, v27, neg(0) op_sel_hi:[0,0,1]     ; cc21400a 82023612
	v_cvt_f32_u32_e32 v23, v23                                  ; 7e2e0d17
	v_mul_f32_e32 v23, s17, v23                                 ; 102e2e11
	v_lshrrev_b32_e32 v26, 8, v25                               ; 32343288
	v_lshrrev_b32_e32 v25, 30, v25                              ; 3232329e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
	v_log_f32_e32 v23, v23                                      ; 7e2e4f17
	v_xad_u32 v25, v25, v26, 1                                  ; d6450019 02063519
	v_cvt_f32_u32_e32 v25, v25                                  ; 7e320d19
	v_mul_f32_e32 v23, 0xbfb17218, v23                          ; 102e2eff bfb17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(TRANS32_DEP_1) ; bf8702b2
	v_mul_f32_e32 v25, s17, v25                                 ; 10323211
	v_sqrt_f32_e32 v23, v23                                     ; 7e2e6717
	v_cos_f32_e32 v25, v25                                      ; 7e326d19
	v_dual_mul_f32 v23, v23, v25 :: v_dual_mul_f32 v16, v16, v20 ; c8c63317 17102910
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_fma_mixlo_f16 v11, s18, v23, neg(0) op_sel_hi:[0,0,1]     ; cc21400b 82022e12
	v_fma_mixhi_f16 v10, s18, v16, neg(0) op_sel_hi:[0,0,1]     ; cc22400a 82022012
BB24:
	v_add_f16_e32 v14, -0.5, v14                                ; 641c1cf1
(invalid instruction)                                        ; cc0f000d
	v_subrev_f32_e32 v0, v13, v241                              ; 0a01e30d
	s_cmp_lg_i32 s22, 0                                         ; bf018016
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; 6b281cff
(invalid instruction)                                        ; 00003000
(invalid instruction)                                        ; cc10000c
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 00003000
	s_cbranch_scc0 BB29                                         ; bfa1012d
BB25:
	s_buffer_load_b256 s[24:31], s[36:39], 0x10                 ; f4026612 f8000010
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_neq_f32 s26, 0                                        ; bf4d801a
	s_cbranch_scc0 BB27                                         ; bfa1005b
BB26:
	s_clause 0x1                                                ; bf850001
	s_load_b256 s[48:55], s[0:1], 0x140                         ; f4006c00 f8000140
	s_load_b128 s[32:35], s[0:1], 0x170                         ; f4004800 f8000170
	v_add_f32_e32 v1, -0.5, v2                                  ; 060204f1
	v_add_f32_e32 v13, -0.5, v3                                 ; 061a06f1
	v_dual_add_f32 v3, 0x3fc00000, v3 :: v_dual_add_f32 v2, 0x3fc00000, v2 ; c90806ff 030204ff 3fc00000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_mul_f32_e32 v1, s20, v1                                   ; 10020214
	v_mul_f32_e32 v13, s16, v13                                 ; 101a1a10
	v_dual_mul_f32 v3, s16, v3 :: v_dual_mul_f32 v2, s20, v2    ; c8c60610 03020414
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_and_b32 s12, s35, -2.0                                    ; 8b0cf523
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_eq_i32 s12, -2.0                                      ; bf00f50c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s13, s23, src_scc                                 ; 8b0dfd17
	s_mov_b32 s17, src_scc                                      ; be9100fd
	s_and_b32 s18, s35, 0x3fffffff                              ; 8b12ff23 3fffffff
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s17, 0                                         ; bf018011
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s35, s18, s35                                 ; 98232312
	s_clause 0x4                                                ; bf850004
	image_sample_lz v14, [v4, v9], s[48:55], s[32:35] dmask:0x1 dim:SQ_RSRC_IMG_2D ; e447c001 1000600e 00000904
	image_sample_lz v15, [v1, v13], s[48:55], s[32:35] dmask:0x1 dim:SQ_RSRC_IMG_2D ; e447c001 1000600f 00000d01
	image_sample_lz v16, [v2, v13], s[48:55], s[32:35] dmask:0x1 dim:SQ_RSRC_IMG_2D ; e447c001 10006010 00000d02
	image_sample_lz v18, [v1, v3], s[48:55], s[32:35] dmask:0x1 dim:SQ_RSRC_IMG_2D ; e447c001 10006012 00000301
	image_sample_lz v19, [v2, v3], s[48:55], s[32:35] dmask:0x1 dim:SQ_RSRC_IMG_2D ; e447c001 10006013 00000302
	s_cmp_neq_f32 s27, 0                                        ; bf4d801b
	s_wait_samplecnt 0x3                                        ; bfc20003
	v_cmp_lt_f32_e32 vcc_lo, v14, v15                           ; 7c221f0e
(invalid instruction)                                        ; d4110013
	v_cndmask_b32_e32 v1, v15, v14, vcc_lo                      ; 02021d0f
	s_cselect_b32 vcc_lo, vcc_lo, s19                           ; 986a136a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v21, v4, v1 :: v_dual_cndmask_b32 v14, v14, v15 ; ca520304 150e1f0e
	s_wait_samplecnt 0x2                                        ; bfc20002
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d4110014
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                      ; 0202210e
(invalid instruction)                                        ; d4110015
	v_cndmask_b32_e32 v1, v16, v14, vcc_lo                      ; 02021d10
	s_cselect_b32 s20, s20, s21                                 ; 98141514
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 vcc_lo, s20, vcc_lo                                ; 8c6a6a14
	s_cmp_neq_f32 s27, 0                                        ; bf4d801b
	v_cndmask_b32_e64 v14, v14, v16, s20                        ; d501000e 0052210e
	v_cndmask_b32_e64 v21, v21, v2, s20                         ; d5010015 00520515
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v13, v9, v13, vcc_lo                      ; 021a1b09
	s_wait_samplecnt 0x1                                        ; bfc20001
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_cmp_lt_f32_e32 vcc_lo, v14, v18                           ; 7c22250e
(invalid instruction)                                        ; d411001a
	v_cndmask_b32_e32 v1, v18, v14, vcc_lo                      ; 02021d12
	s_cselect_b32 vcc_lo, vcc_lo, s26                           ; 986a1a6a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v21, v21, v1 :: v_dual_cndmask_b32 v14, v14, v18 ; ca520315 150e250e
	s_wait_samplecnt 0x0                                        ; bfc20000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b1
(invalid instruction)                                        ; d411001b
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                      ; 0202270e
(invalid instruction)                                        ; d4110020
	v_cndmask_b32_e32 v1, v19, v14, vcc_lo                      ; 02021d13
	s_cselect_b32 s27, s27, s32                                 ; 981b201b
	s_or_b32 vcc_lo, s27, vcc_lo                                ; 8c6a6a1b
	v_cndmask_b32_e64 v21, v21, v2, s27                         ; d5010015 006e0515
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v13, v13, v3, vcc_lo                      ; 021a070d
	s_branch BB28                                               ; bfa00002
BB27:
	v_mov_b32_e32 v13, v9                                       ; 7e1a0309
	v_mov_b32_e32 v21, v4                                       ; 7e2a0304
BB28:
	s_clause 0x3                                                ; bf850003
	s_load_b256 s[48:55], s[0:1], 0xc0                          ; f4006c00 f80000c0
	s_load_b128 s[16:19], s[0:1], 0xf0                          ; f4004400 f80000f0
	s_load_b256 s[56:63], s[0:1], 0x100                         ; f4006e00 f8000100
	s_load_b128 s[32:35], s[0:1], 0x130                         ; f4004800 f8000130
	v_fma_f32 v13, s29, v13, s31                                ; d613000d 007e1a1d
	v_fma_f32 v21, s28, v21, s30                                ; d6130015 007a2a1c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_and_b32 s12, s19, -2.0                                    ; 8b0cf513
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_eq_i32 s12, -2.0                                      ; bf00f50c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s13, s23, src_scc                                 ; 8b0dfd17
	s_mov_b32 s20, src_scc                                      ; be9400fd
	s_and_b32 s21, s19, 0x3fffffff                              ; 8b15ff13 3fffffff
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s20, 0                                         ; bf018014
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s19, s21, s19                                 ; 98131315
	image_sample_lz v[2:3], [v21, v13], s[48:55], s[16:19] dmask:0x3 dim:SQ_RSRC_IMG_2D ; e4c7c001 08006002 00000d15
	s_buffer_load_b64 s[12:13], s[36:39], 0x4                   ; f4022312 f8000004
	s_mov_b32 s22, 0x40200000                                   ; be9600ff 40200000
	s_add_f32 s26, s24, -0.5                                    ; a01af118
	s_add_f32 s27, s25, -0.5                                    ; a01bf119
	s_wait_samplecnt 0x0                                        ; bfc20000
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_fmac_f32_e32 v9, s13, v3                                  ; 5612060d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_f32 v3, s25, v9, -0.5                                 ; d6130003 03c61219
	v_floor_f32_e32 v3, v3                                      ; 7e064903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v13, 0.5, v3                                  ; 061a06f0
	v_fma_f32 v9, s25, v9, -v13 clamp                           ; d6138009 84361219
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v14, v9, v9                                   ; 101c1309
	v_dual_mul_f32 v15, v14, v9 :: v_dual_fmac_f32 v4, s12, v2  ; c8c0130e 0f04040c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_fma_f32 v1, s24, v4, -0.5                                 ; d6130001 03c60818
(invalid instruction)                                        ; d5030009
(invalid instruction)                                        ; 7a021f09
	v_fma_f32 v16, 0x3fc00000, v15, 1.0                         ; d6130010 03ca1eff 3fc00000
(invalid instruction)                                        ; d504000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[14:15]                ; 1a021d0f
(invalid instruction)                                        ; d6840019
	v_cndmask_b32_e32 v0, s25, v128, vcc_lo                     ; 02010019
	s_and_b32 s28, s35, -2.0                                    ; 8b1cf523
	v_floor_f32_e32 v1, v1                                      ; 7e024901
	v_fma_f32 v16, -s22, v14, v16                               ; d6130010 24421c16
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_eq_i32 s28, -2.0                                      ; bf00f51c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s23, s23, src_scc                                 ; 8b17fd17
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v2, 0.5, v1    ; c9081d09 090202f0
	s_mov_b32 s29, src_scc                                      ; be9d00fd
	s_and_b32 s30, s35, 0x3fffffff                              ; 8b1eff23 3fffffff
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s29, 0                                         ; bf01801d
	v_fma_f32 v4, s24, v4, -v2 clamp                            ; d6138004 840a0818
(invalid instruction)                                        ; d6840018
	v_cndmask_b32_e32 v0, s24, v128, vcc_lo                     ; 02010018
	v_sub_f32_e32 v18, 1.0, v9                                  ; 082412f2
	s_cselect_b32 s35, s30, s35                                 ; 9823231e
	v_sub_f32_e32 v18, v18, v16                                 ; 08242112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_f32_e32 v18, v18, v15                                 ; 08241f12
	v_dual_add_f32 v16, v16, v18 :: v_dual_add_f32 v19, -0.5, v1 ; c9082510 101202f1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_rcp_f32_e32 v21, v16                                      ; 7e2a5510
	v_maxmin_num_f32 v19, 0.5, v19, s26                         ; d6690013 006a26f0
	v_mul_f32_e32 v19, s24, v19                                 ; 10262618
	v_fmac_f32_e32 v13, v18, v21                                ; 561a2b12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_maxmin_num_f32 v13, 0.5, v13, s27                         ; d669000d 006e1af0
	v_mul_f32_e32 v13, s25, v13                                 ; 101a1a19
	image_sample_lz v[22:24], [v19, v13], s[56:63], s[32:35] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 10007016 00000d13
	v_mul_f32_e32 v25, v4, v4                                   ; 10320904
	v_add_f32_e32 v29, -0.5, v3                                 ; 063a06f1
	v_add_f32_e32 v1, s22, v1                                   ; 06020216
	v_add_f32_e32 v3, s22, v3                                   ; 06060616
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_mul_f32_e32 v26, v25, v4                                  ; 10340919
	v_maxmin_num_f32 v29, 0.5, v29, s27                         ; d669001d 006e3af0
	v_maxmin_num_f32 v1, 0.5, v1, s26                           ; d6690001 006a02f0
	v_maxmin_num_f32 v3, 0.5, v3, s27                           ; d6690003 006e06f0
(invalid instruction)                                        ; d5030004
(invalid instruction)                                        ; 7a023504
	v_fma_f32 v27, 0x3fc00000, v26, 1.0                         ; d613001b 03ca34ff 3fc00000
(invalid instruction)                                        ; d504001a
	v_min_num_f64_e32 v[1:2], v[26:27], v[25:26]                ; 1a02331a
	v_mul_f32_e32 v29, s25, v29                                 ; 103a3a19
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_add_f32_e32 v4, v4, v25                                   ; 06083304
	v_fma_f32 v27, -s22, v25, v27                               ; d613001b 246e3216
	v_sub_f32_e32 v28, 1.0, v4                                  ; 083808f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_f32_e32 v28, v28, v27                                 ; 0838371c
	v_sub_f32_e32 v28, v28, v26                                 ; 0838351c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v27, v27, v28                                 ; 0636391b
	v_rcp_f32_e32 v30, v27                                      ; 7e3c551b
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_dual_mul_f32 v3, s25, v3 :: v_dual_fmac_f32 v2, v28, v30  ; c8c00619 03023d1c
	v_maxmin_num_f32 v2, 0.5, v2, s26                           ; d6690002 006a04f0
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v1, s24, v1 :: v_dual_mul_f32 v2, s24, v2    ; c8c60218 01020418
	s_clause 0x3                                                ; bf850003
	image_sample_lz v[31:33], [v2, v29], s[56:63], s[32:35] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1000701f 00001d02
	image_sample_lz v[34:36], [v2, v13], s[56:63], s[32:35] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 10007022 00000d02
	image_sample_lz v[37:39], [v2, v3], s[56:63], s[32:35] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 10007025 00000302
	image_sample_lz v[40:42], [v1, v13], s[56:63], s[32:35] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 10007028 00000d01
	v_mul_f32_e32 v26, v26, v16                                 ; 1034211a
	v_mul_f32_e32 v4, v4, v16                                   ; 10082104
	s_wait_samplecnt 0x4                                        ; bfc20004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_mul_f32_e32 v22, v22, v4                                  ; 102c0916
	v_dual_mul_f32 v24, v24, v4 :: v_dual_mul_f32 v9, v9, v27   ; c8c60918 18083709
	v_dual_mul_f32 v23, v23, v4 :: v_dual_add_f32 v4, v4, v9    ; c8c80917 17041304
	s_wait_samplecnt 0x3                                        ; bfc20003
	v_dual_fmac_f32 v22, v9, v31 :: v_dual_mul_f32 v43, v27, v16 ; c8063f09 162a211b
	v_dual_fmac_f32 v24, v33, v9 :: v_dual_mul_f32 v15, v15, v27 ; c8061321 180e370f
	s_wait_samplecnt 0x2                                        ; bfc20002
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_fmac_f32_e32 v22, v34, v43                                ; 562c5722
	v_dual_fmac_f32 v24, v43, v36 :: v_dual_fmac_f32 v23, v32, v9 ; c800492b 18161320
	s_wait_samplecnt 0x1                                        ; bfc20001
	v_fmac_f32_e32 v22, v37, v15                                ; 562c1f25
	v_fmac_f32_e32 v24, v39, v15                                ; 56301f27
	v_dual_add_f32 v4, v4, v43 :: v_dual_fmac_f32 v23, v35, v43 ; c9005704 04165723
	s_wait_samplecnt 0x0                                        ; bfc20000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
	v_fmac_f32_e32 v24, v42, v26                                ; 5630352a
	v_dual_fmac_f32 v22, v40, v26 :: v_dual_fmac_f32 v23, v38, v15 ; c8003528 16161f26
	v_add_f32_e32 v4, v4, v15                                   ; 06081f04
	v_dual_add_f32 v4, v4, v26 :: v_dual_fmac_f32 v23, v41, v26 ; c9003504 04163529
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v4, v4                                        ; 7e085504
	v_fma_mixlo_f16 v44, v22, v4, neg(0) op_sel_hi:[0,0,1]      ; cc21402c 82020916
	v_fma_mixhi_f16 v44, v23, v4, neg(0) op_sel_hi:[0,0,1]      ; cc22402c 82020917
	v_fma_mixlo_f16 v45, v24, v4, neg(0) op_sel_hi:[0,0,1]      ; cc21402d 82020918
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc0f002c
	v_subrev_f32_e32 v0, v44, v241                              ; 0a01e32c
	v_add_f16_e32 v45, -0.5, v45                                ; 645a5af1
(invalid instruction)                                        ; cc10002c
	v_subrev_f32_e32 v0, v44, v255                              ; 0a01ff2c
(invalid instruction)                                        ; 00003000
(invalid instruction)                                        ; 6b305aff
(invalid instruction)                                        ; 00003000
	s_branch BB30                                               ; bfa00002
BB29:
	v_mov_b32_e32 v44, v12                                      ; 7e58030c
	v_mov_b16_e32 v24.h, v20.h                                  ; 7f303994
BB30:
	v_and_b32_e32 v7, 3, v7                                     ; 360e0e83
	v_bfe_u32 v8, v8, 2, 1                                      ; d6100008 02050508
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v11.h, v17.h                                  ; 7f163991
	v_mov_b32_e32 v25, s40                                      ; 7e320228
	v_dual_mov_b32 v27, s11 :: v_dual_mov_b32 v26, s42          ; ca10000b 1b1a002a
	v_alignbyte_b32 v13, v44, v20, 2                            ; d617000d 020a292c
	v_mov_b16_e32 v24.l, v44.h                                  ; 7e3039ac
	v_lshlrev_b32_e32 v7, 2, v7                                 ; 300e0e82
	v_lshl_add_u32 v8, v8, 1, v5                                ; d6460008 04150308
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v8, v8, 4, v7                                ; d6460008 041d0908
	v_add_lshl_u32 v8, v8, v6, 5                                ; d6470008 02160d08
	ds_store_b128 v8, v[10:13]                                  ; db7c0000 00000a08
	ds_store_b128 v8, v[24:27] offset:16                        ; db7c0010 00001808
	s_load_b32 s11, s[14:15], 0x50                              ; f40002c7 f8000050
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v5, v3, v1, 1                                ; d6470005 02060303
	ds_load_b64 v[8:9], v5                                      ; d9d80000 08000005
	ds_load_b64 v[10:11], v5 offset:8                           ; d9d80008 0a000005
	ds_load_b64 v[12:13], v5 offset:512                         ; d9d80200 0c000005
	ds_load_b64 v[14:15], v5 offset:520                         ; d9d80208 0e000005
	ds_load_b64 v[16:17], v5 offset:1024                        ; d9d80400 10000005
	ds_load_b64 v[18:19], v5 offset:1032                        ; d9d80408 12000005
	ds_load_b64 v[20:21], v5 offset:1536                        ; d9d80600 14000005
	ds_load_b64 v[22:23], v5 offset:1544                        ; d9d80608 16000005
	s_clause 0x1                                                ; bf850001
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_load_b128 s[16:19], s[0:1], 0x40                          ; f4004400 f8000040
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_add3_u32 v4, v1, s11, v3                                  ; d6550004 040c1701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
	v_lshlrev_b32_e32 v4, 1, v4                                 ; 30080881
	buffer_load_b128 v[24:27], v4, s[16:19], null offen         ; c405c07c 40802018 00000004
	s_cmp_eq_i32 s12, 0                                         ; bf00800c
	s_wait_loadcnt_dscnt 0x6                                    ; bfc80006
	v_wmma_f32_16x16x16_f16 v[32:39], v[24:27], v[8:11], 0      ; cc404020 1a021118
	v_cvt_f16_f32_e32 v24, v36                                  ; 7e301524
(invalid instruction)                                        ; 7f301525
	v_cvt_f16_f32_e32 v6, v32                                   ; 7e0c1520
(invalid instruction)                                        ; 7f0c1521
	v_cvt_f16_f32_e32 v25, v38                                  ; 7e321526
(invalid instruction)                                        ; 7f321527
	v_cvt_f16_f32_e32 v7, v34                                   ; 7e0e1522
(invalid instruction)                                        ; 7f0e1523
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB35                                         ; bfa1000f
BB31:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB34                                         ; bfa10007
BB32:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v5, 0                                         ; 7e0a0280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v5, off, s[20:23], s2                       ; c4060002 00802805 00000000
BB34:
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0                ; ca100080 07060080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	s_branch BB36                                               ; bfa00001
BB35:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB36:
	buffer_load_b128 v[28:31], v4, s[16:19], null offen offset:512 ; c405c07c 4080201c 00020004
	v_cvt_f32_f16_e32 v5, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a1786
	v_cvt_f32_f16_e32 v26, v6                                   ; 7e341706
	v_cvt_f32_f16_e32 v27, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e361787
	v_cvt_f32_f16_e32 v32, v7                                   ; 7e401707
	v_cvt_f32_f16_e32 v33, v152/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e421798
	v_cvt_f32_f16_e32 v34, v24                                  ; 7e441718
	v_cvt_f32_f16_e32 v35, v153/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e461799
	v_cvt_f32_f16_e32 v36, v25                                  ; 7e481719
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v26, v5, vcc_lo                       ; 02020b1a
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v32, v27, vcc_lo                      ; 02023720
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v34, v33, vcc_lo                      ; 02024322
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v36, v35, vcc_lo                      ; 02024724
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[32:39], v[28:31], v[8:11], 0      ; cc404020 1a02111c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v41, v34                                  ; 7e521522
(invalid instruction)                                        ; 7f521523
	v_cvt_f16_f32_e32 v42, v36                                  ; 7e541524
(invalid instruction)                                        ; 7f541525
	v_cvt_f16_f32_e32 v43, v38                                  ; 7e561526
(invalid instruction)                                        ; 7f561527
	v_cvt_f16_f32_e32 v40, v32                                  ; 7e501520
(invalid instruction)                                        ; 7f501521
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB41                                         ; bfa1000f
BB37:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB40                                         ; bfa10007
BB38:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v5, 0                                         ; 7e0a0280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v5, off, s[20:23], s2                       ; c4060002 00802805 00000000
BB40:
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	s_branch BB42                                               ; bfa00001
BB41:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB42:
	buffer_load_b128 v[8:11], v4, s[16:19], null offen          ; c405c07c 40802008 00000004
	v_cvt_f32_f16_e32 v5, v168/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a17a8
	v_cvt_f32_f16_e32 v28, v40                                  ; 7e381728
	v_cvt_f32_f16_e32 v29, v169/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3a17a9
	v_cvt_f32_f16_e32 v30, v41                                  ; 7e3c1729
	v_cvt_f32_f16_e32 v31, v170/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3e17aa
	v_cvt_f32_f16_e32 v32, v42                                  ; 7e40172a
	v_cvt_f32_f16_e32 v33, v171/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4217ab
	v_cvt_f32_f16_e32 v34, v43                                  ; 7e44172b
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v28, v5, vcc_lo                       ; 02020b1c
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v30, v29, vcc_lo                      ; 02023b1e
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v32, v31, vcc_lo                      ; 02023f20
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v34, v33, vcc_lo                      ; 02024322
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt_dscnt 0x4                                    ; bfc80004
	v_wmma_f32_16x16x16_f16 v[32:39], v[8:11], v[12:15], 0      ; cc404020 1a021908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v45, v34                                  ; 7e5a1522
(invalid instruction)                                        ; 7f5a1523
	v_cvt_f16_f32_e32 v46, v36                                  ; 7e5c1524
(invalid instruction)                                        ; 7f5c1525
	v_cvt_f16_f32_e32 v47, v38                                  ; 7e5e1526
(invalid instruction)                                        ; 7f5e1527
	v_cvt_f16_f32_e32 v44, v32                                  ; 7e581520
(invalid instruction)                                        ; 7f581521
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB47                                         ; bfa1000f
BB43:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB46                                         ; bfa10007
BB44:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v5, 0                                         ; 7e0a0280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v5, off, s[20:23], s2                       ; c4060002 00802805 00000000
BB46:
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	s_branch BB48                                               ; bfa00001
BB47:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB48:
	buffer_load_b128 v[8:11], v4, s[16:19], null offen offset:512 ; c405c07c 40802008 00020004
	v_cvt_f32_f16_e32 v5, v172/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a17ac
	v_cvt_f32_f16_e32 v30, v44                                  ; 7e3c172c
	v_cvt_f32_f16_e32 v31, v173/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3e17ad
	v_cvt_f32_f16_e32 v32, v45                                  ; 7e40172d
	v_cvt_f32_f16_e32 v33, v174/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4217ae
	v_cvt_f32_f16_e32 v34, v46                                  ; 7e44172e
	v_cvt_f32_f16_e32 v35, v175/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4617af
	v_cvt_f32_f16_e32 v36, v47                                  ; 7e48172f
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v30, v5, vcc_lo                       ; 02020b1e
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v32, v31, vcc_lo                      ; 02023f20
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v34, v33, vcc_lo                      ; 02024322
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v36, v35, vcc_lo                      ; 02024724
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[32:39], v[8:11], v[12:15], 0      ; cc404020 1a021908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v49, v34                                  ; 7e621522
(invalid instruction)                                        ; 7f621523
	v_cvt_f16_f32_e32 v50, v36                                  ; 7e641524
(invalid instruction)                                        ; 7f641525
	v_cvt_f16_f32_e32 v51, v38                                  ; 7e661526
(invalid instruction)                                        ; 7f661527
	v_cvt_f16_f32_e32 v48, v32                                  ; 7e601520
(invalid instruction)                                        ; 7f601521
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB53                                         ; bfa1000f
BB49:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB52                                         ; bfa10007
BB50:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v5, 0                                         ; 7e0a0280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v5, off, s[20:23], s2                       ; c4060002 00802805 00000000
BB52:
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	s_branch BB54                                               ; bfa00001
BB53:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB54:
	buffer_load_b128 v[8:11], v4, s[16:19], null offen          ; c405c07c 40802008 00000004
	v_cvt_f32_f16_e32 v5, v176/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a17b0
	v_cvt_f32_f16_e32 v12, v48                                  ; 7e181730
	v_cvt_f32_f16_e32 v13, v177/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1a17b1
	v_cvt_f32_f16_e32 v14, v49                                  ; 7e1c1731
	v_cvt_f32_f16_e32 v15, v178/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e17b2
	v_cvt_f32_f16_e32 v32, v50                                  ; 7e401732
	v_cvt_f32_f16_e32 v33, v179/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4217b3
	v_cvt_f32_f16_e32 v34, v51                                  ; 7e441733
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v12, v5, vcc_lo                       ; 02020b0c
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v14, v13, vcc_lo                      ; 02021b0e
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v32, v15, vcc_lo                      ; 02021f20
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v34, v33, vcc_lo                      ; 02024322
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt_dscnt 0x2                                    ; bfc80002
	v_wmma_f32_16x16x16_f16 v[32:39], v[8:11], v[16:19], 0      ; cc404020 1a022108
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v53, v34                                  ; 7e6a1522
(invalid instruction)                                        ; 7f6a1523
	v_cvt_f16_f32_e32 v54, v36                                  ; 7e6c1524
(invalid instruction)                                        ; 7f6c1525
	v_cvt_f16_f32_e32 v55, v38                                  ; 7e6e1526
(invalid instruction)                                        ; 7f6e1527
	v_cvt_f16_f32_e32 v52, v32                                  ; 7e681520
(invalid instruction)                                        ; 7f681521
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB59                                         ; bfa1000f
BB55:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB58                                         ; bfa10007
BB56:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v5, 0                                         ; 7e0a0280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v5, off, s[20:23], s2                       ; c4060002 00802805 00000000
BB58:
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	s_branch BB60                                               ; bfa00001
BB59:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB60:
	buffer_load_b128 v[8:11], v4, s[16:19], null offen offset:512 ; c405c07c 40802008 00020004
	v_cvt_f32_f16_e32 v5, v180/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a17b4
	v_cvt_f32_f16_e32 v14, v52                                  ; 7e1c1734
	v_cvt_f32_f16_e32 v15, v181/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e17b5
	v_cvt_f32_f16_e32 v32, v53                                  ; 7e401735
	v_cvt_f32_f16_e32 v33, v182/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4217b6
	v_cvt_f32_f16_e32 v34, v54                                  ; 7e441736
	v_cvt_f32_f16_e32 v35, v183/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4617b7
	v_cvt_f32_f16_e32 v36, v55                                  ; 7e481737
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                       ; 02020b0e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v32, v15, vcc_lo                      ; 02021f20
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v34, v33, vcc_lo                      ; 02024322
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v36, v35, vcc_lo                      ; 02024724
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[32:39], v[8:11], v[16:19], 0      ; cc404020 1a022108
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v57, v34                                  ; 7e721522
(invalid instruction)                                        ; 7f721523
	v_cvt_f16_f32_e32 v58, v36                                  ; 7e741524
(invalid instruction)                                        ; 7f741525
	v_cvt_f16_f32_e32 v59, v38                                  ; 7e761526
(invalid instruction)                                        ; 7f761527
	v_cvt_f16_f32_e32 v56, v32                                  ; 7e701520
(invalid instruction)                                        ; 7f701521
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB65                                         ; bfa1000f
BB61:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB64                                         ; bfa10007
BB62:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v5, 0                                         ; 7e0a0280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v5, off, s[20:23], s2                       ; c4060002 00802805 00000000
BB64:
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	s_branch BB66                                               ; bfa00001
BB65:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB66:
	buffer_load_b128 v[8:11], v4, s[16:19], null offen          ; c405c07c 40802008 00000004
	v_cvt_f32_f16_e32 v5, v184/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a17b8
	v_cvt_f32_f16_e32 v16, v56                                  ; 7e201738
	v_cvt_f32_f16_e32 v17, v185/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2217b9
	v_cvt_f32_f16_e32 v18, v57                                  ; 7e241739
	v_cvt_f32_f16_e32 v19, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2617ba
	v_cvt_f32_f16_e32 v32, v58                                  ; 7e40173a
	v_cvt_f32_f16_e32 v33, v187/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4217bb
	v_cvt_f32_f16_e32 v34, v59                                  ; 7e44173b
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v16, v5, vcc_lo                       ; 02020b10
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v18, v17, vcc_lo                      ; 02022312
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v32, v19, vcc_lo                      ; 02022720
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v34, v33, vcc_lo                      ; 02024322
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_f16 v[32:39], v[8:11], v[20:23], 0      ; cc404020 1a022908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v61, v34                                  ; 7e7a1522
(invalid instruction)                                        ; 7f7a1523
	v_cvt_f16_f32_e32 v62, v36                                  ; 7e7c1524
(invalid instruction)                                        ; 7f7c1525
	v_cvt_f16_f32_e32 v63, v38                                  ; 7e7e1526
(invalid instruction)                                        ; 7f7e1527
	v_cvt_f16_f32_e32 v60, v32                                  ; 7e781520
(invalid instruction)                                        ; 7f781521
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB71                                         ; bfa1000f
BB67:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB70                                         ; bfa10007
BB68:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v5, 0                                         ; 7e0a0280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v5, off, s[20:23], s2                       ; c4060002 00802805 00000000
BB70:
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v60, 0              ; ca100080 3d3c0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v62, 0              ; ca100080 3f3e0080
	s_branch BB72                                               ; bfa00001
BB71:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB72:
	buffer_load_b128 v[8:11], v4, s[16:19], null offen offset:512 ; c405c07c 40802008 00020004
	v_cvt_f32_f16_e32 v4, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0817bc
	v_cvt_f32_f16_e32 v5, v60                                   ; 7e0a173c
	v_cvt_f32_f16_e32 v18, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2417bd
	v_cvt_f32_f16_e32 v19, v61                                  ; 7e26173d
	v_cvt_f32_f16_e32 v32, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4017be
	v_cvt_f32_f16_e32 v33, v62                                  ; 7e42173e
	v_cvt_f32_f16_e32 v34, v191/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417bf
	v_cvt_f32_f16_e32 v35, v63                                  ; 7e46173f
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v5, v4, vcc_lo                        ; 02020905
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v19, v18, vcc_lo                      ; 02022513
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v33, v32, vcc_lo                      ; 02024121
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[32:39], v[8:11], v[20:23], 0      ; cc404020 1a022908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v65, v34                                  ; 7e821522
(invalid instruction)                                        ; 7f821523
	v_cvt_f16_f32_e32 v66, v36                                  ; 7e841524
(invalid instruction)                                        ; 7f841525
	v_cvt_f16_f32_e32 v67, v38                                  ; 7e861526
(invalid instruction)                                        ; 7f861527
	v_cvt_f16_f32_e32 v64, v32                                  ; 7e801520
(invalid instruction)                                        ; 7f801521
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB78                                         ; bfa1000d
BB73:
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB76                                         ; bfa10007
BB74:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v8, 0                                         ; 7e100280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v8, off, s[20:23], s2                       ; c4060002 00802808 00000000
BB76:
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v64, 0              ; ca100080 41400080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0              ; ca100080 43420080
BB78:
	v_lshlrev_b32_e32 v8, 2, v0                                 ; 30100082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v9, s3, v8, 2                                ; d6470009 020a1003
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[20:23], v9, s[16:19], null offen         ; c405c07c 40802014 00000009
	buffer_load_b128 v[32:35], v9, s[16:19], null offen offset:512 ; c405c07c 40802020 00020009
	buffer_load_b128 v[36:39], v9, s[16:19], null offen offset:1024 ; c405c07c 40802024 00040009
	buffer_load_b128 v[68:71], v9, s[16:19], null offen offset:1536 ; c405c07c 40802044 00060009
	buffer_load_b128 v[72:75], v9, s[16:19], null offen offset:2048 ; c405c07c 40802048 00080009
	buffer_load_b128 v[76:79], v9, s[16:19], null offen offset:2560 ; c405c07c 4080204c 000a0009
	v_cvt_f32_f16_e32 v10, v192/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1417c0
	v_cvt_f32_f16_e32 v11, v64                                  ; 7e161740
	v_cvt_f32_f16_e32 v83, v67                                  ; 7ea61743
	v_cvt_f32_f16_e32 v80, v194/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea017c2
	v_cvt_f32_f16_e32 v81, v66                                  ; 7ea21742
	v_cvt_f32_f16_e32 v82, v195/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea417c3
	v_cvt_f32_f16_e32 v18, v193/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2417c1
	v_cvt_f32_f16_e32 v19, v65                                  ; 7e261741
	s_movk_i32 s3, 0x400                                        ; b0030400
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v11, v10, vcc_lo                      ; 0202150b
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v81, v80, vcc_lo                      ; 0202a151
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v83, v82, vcc_lo                      ; 0202a553
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v19, v18, vcc_lo                      ; 02022513
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[20:21], v[4:5], 0 ; cc464068 1a020914
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[14:15], 0 ; cc464060 1a021d14
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[26:27], 0 ; cc464050 1a023514
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[30:31], 0 ; cc464058 1a023d14
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[26:27], 0 ; cc464070 1a023516
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[30:31], 0 ; cc464078 1a023d16
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[14:15], 0 ; cc464080 1a021d16
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[4:5], 0 ; cc464088 1a020916
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[28:29], v[80:87] ; cc464050 1d423920
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[12:13], v[88:95] ; cc464058 1d621920
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[16:17], v[96:103] ; cc464060 1d822120
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[32:33], v[10:11], v[104:111] ; cc464068 1da21520
	v_maxmin_num_f32 v152, -4.0, v84, 4.0                       ; d6690098 03daa8f7
	v_maxmin_num_f32 v144, -4.0, v80, 4.0                       ; d6690090 03daa0f7
	v_maxmin_num_f32 v146, -4.0, v81, 4.0                       ; d6690092 03daa2f7
	v_maxmin_num_f32 v150, -4.0, v83, 4.0                       ; d6690096 03daa6f7
	v_maxmin_num_f32 v148, -4.0, v82, 4.0                       ; d6690094 03daa4f7
	v_maxmin_num_f32 v154, -4.0, v85, 4.0                       ; d669009a 03daaaf7
	v_maxmin_num_f32 v156, -4.0, v86, 4.0                       ; d669009c 03daacf7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v87, 4.0                       ; d669009e 03daaef7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v88, 4.0                       ; d66900a0 03dab0f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v89, 4.0                       ; d66900a2 03dab2f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_maxmin_num_f32 v164, -4.0, v90, 4.0                       ; d66900a4 03dab4f7
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8433199 999b379a 3f650000
	v_maxmin_num_f32 v166, -4.0, v91, 4.0                       ; d66900a6 03dab6f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c843399d 9d9f3f9e 3f650000
	v_dual_mul_f32 v81, v81, v147 :: v_dual_mul_f32 v80, v80, v144 ; c8c72751 51512150
	v_maxmin_num_f32 v168, -4.0, v92, 4.0                       ; d66900a8 03dab8f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_mul_f32 v83, v83, v151 :: v_dual_mul_f32 v82, v82, v148 ; c8c72f53 53532952
	v_dual_mul_f32 v85, v85, v154 :: v_dual_mul_f32 v84, v84, v153 ; c8c73555 55553354
	v_maxmin_num_f32 v170, -4.0, v93, 4.0                       ; d66900aa 03dabaf7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
	v_dual_mul_f32 v87, v87, v158 :: v_dual_mul_f32 v86, v86, v157 ; c8c73d57 57573b56
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v172, -4.0, v94, 4.0                       ; d66900ac 03dabcf7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v95, 4.0                       ; d66900ae 03dabef7
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	v_maxmin_num_f32 v176, -4.0, v96, 4.0                       ; d66900b0 03dac0f7
	v_dual_mul_f32 v89, v89, v163 :: v_dual_mul_f32 v88, v88, v160 ; c8c74759 59594158
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v178, -4.0, v97, 4.0                       ; d66900b2 03dac2f7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v98, 4.0                       ; d66900b4 03dac4f7
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84351a9 a9ab57aa 3f650000
	v_maxmin_num_f32 v182, -4.0, v99, 4.0                       ; d66900b6 03dac6f7
	v_dual_mul_f32 v91, v91, v167 :: v_dual_mul_f32 v90, v90, v164 ; c8c74f5b 5b5b495a
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v100, 4.0                      ; d66900b8 03dac8f7
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84359ad adaf5fae 3f650000
	v_maxmin_num_f32 v186, -4.0, v101, 4.0                      ; d66900ba 03dacaf7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_dual_mul_f32 v93, v93, v170 :: v_dual_mul_f32 v92, v92, v169 ; c8c7555d 5d5d535c
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v188, -4.0, v102, 4.0                      ; d66900bc 03daccf7
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84365b3 b3b163b0 3f650000
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v103, 4.0                      ; d66900be 03dacef7
	v_dual_mul_f32 v95, v95, v174 :: v_dual_mul_f32 v94, v94, v173 ; c8c75d5f 5f5f5b5e
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c8436db7 b7b56bb4 3f650000
	v_maxmin_num_f32 v33, -4.0, v105, 4.0                       ; d6690021 03dad2f7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_mul_f32 v97, v97, v179 :: v_dual_mul_f32 v96, v96, v176 ; c8c76761 61616160
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v81, -4.0, v106, 4.0                       ; d6690051 03dad4f7
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84371b9 b9bb77ba 3f650000
	v_maxmin_num_f32 v83, -4.0, v107, 4.0                       ; d6690053 03dad6f7
	v_dual_mul_f32 v99, v99, v183 :: v_dual_mul_f32 v98, v98, v180 ; c8c76f63 63636962
	v_fma_mix_f32 v80, 0xab28, |v33|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe42ff 3728ab28
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c84379bd bdbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v104, 4.0                      ; d66900bf 03dad0f7
	v_maxmin_num_f32 v85, -4.0, v108, 4.0                       ; d6690055 03dad8f7
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_dual_mul_f32 v101, v101, v186 :: v_dual_mul_f32 v100, v100, v185 ; c8c77565 65657364
	v_maxmin_num_f32 v87, -4.0, v109, 4.0                       ; d6690057 03dadaf7
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_dual_mul_f32 v103, v103, v190 :: v_dual_mul_f32 v102, v102, v189 ; c8c77d67 67677b66
	v_maxmin_num_f32 v89, -4.0, v110, 4.0                       ; d6690059 03dadcf7
	v_fma_mix_f32 v32, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206220 0bff7eff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v111, 4.0                       ; d669005b 03dadef7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 ; c842a754 5450a551 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[28:29], v[112:119] ; cc464070 1dc23922
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_fmaak_f32 v80, v80, v33, 0x3f650000 :: v_dual_fmaak_f32 v191, v191, v32, 0x3f650000 ; c8424350 50be41bf 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842b157 5756ab56 3f650000
	v_dual_mul_f32 v107, v107, v84 :: v_dual_mul_f32 v106, v106, v81 ; c8c6a96b 6b6aa36a
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v105, v105, v80 :: v_dual_mul_f32 v104, v104, v191 ; c8c6a169 69697f68
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b95b 5b5ab35a 3f650000
	v_dual_mul_f32 v109, v109, v87 :: v_dual_mul_f32 v108, v108, v86 ; c8c6af6d 6d6cad6c
	v_maxmin_num_f32 v97, -4.0, v114, 4.0                       ; d6690061 03dae4f7
	v_maxmin_num_f32 v93, -4.0, v112, 4.0                       ; d669005d 03dae0f7
	v_maxmin_num_f32 v99, -4.0, v115, 4.0                       ; d6690063 03dae6f7
	v_maxmin_num_f32 v95, -4.0, v113, 4.0                       ; d669005f 03dae2f7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[12:13], v[120:127] ; cc464078 1de21922
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[16:17], v[128:135] ; cc464080 1e022122
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_dual_mul_f32 v111, v111, v91 :: v_dual_mul_f32 v110, v110, v90 ; c8c6b76f 6f6eb56e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[34:35], v[10:11], v[136:143] ; cc464088 1e221522
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v116, 4.0                      ; d6690065 03dae8f7
	v_maxmin_num_f32 v103, -4.0, v117, 4.0                      ; d6690067 03daeaf7
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v105, -4.0, v118, 4.0                      ; d6690069 03daecf7
	v_maxmin_num_f32 v107, -4.0, v119, 4.0                      ; d669006b 03daeef7
	v_maxmin_num_f32 v109, -4.0, v120, 4.0                      ; d669006d 03daf0f7
	v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 ; c842c561 6164c764 3f650000
	v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842bd5d 5d60bf60 3f650000
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v111, -4.0, v121, 4.0                      ; d669006f 03daf2f7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_dual_mul_f32 v115, v115, v100 :: v_dual_mul_f32 v114, v114, v97 ; c8c6c973 7372c372
	v_dual_mul_f32 v113, v113, v96 :: v_dual_mul_f32 v112, v112, v93 ; c8c6c171 7170bb70
	v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c842d167 6766cb66 3f650000
	v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 ; c842d96b 6b6ad36a 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v113, -4.0, v122, 4.0                      ; d6690071 03daf4f7
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v115, -4.0, v123, 4.0                      ; d6690073 03daf6f7
	v_dual_mul_f32 v117, v117, v103 :: v_dual_mul_f32 v116, v116, v102 ; c8c6cf75 7574cd74
	v_dual_mul_f32 v119, v119, v107 :: v_dual_mul_f32 v118, v118, v106 ; c8c6d777 7776d576
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 ; c842dd6d 6d70df70 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v117, -4.0, v124, 4.0                      ; d6690075 03daf8f7
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v119, -4.0, v125, 4.0                      ; d6690077 03dafaf7
	v_dual_mul_f32 v121, v121, v112 :: v_dual_mul_f32 v120, v120, v109 ; c8c6e179 7978db78
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 ; c842e571 7174e774 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v121, -4.0, v126, 4.0                      ; d6690079 03dafcf7
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_dual_mul_f32 v123, v123, v116 :: v_dual_mul_f32 v122, v122, v113 ; c8c6e97b 7b7ae37a
	v_dual_fmaak_f32 v119, v119, v120, 0x3f650000 :: v_dual_fmaak_f32 v118, v118, v117, 0x3f650000 ; c842f177 7776eb76 3f650000
	v_maxmin_num_f32 v145, -4.0, v130, 4.0                      ; d6690091 03db04f7
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v123, -4.0, v127, 4.0                      ; d669007b 03dafef7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v147, -4.0, v131, 4.0                      ; d6690093 03db06f7
	v_dual_mul_f32 v125, v125, v119 :: v_dual_mul_f32 v124, v124, v118 ; c8c6ef7d 7d7ced7c
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_maxmin_num_f32 v149, -4.0, v132, 4.0                      ; d6690095 03db08f7
	v_maxmin_num_f32 v151, -4.0, v133, 4.0                      ; d6690097 03db0af7
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v125, -4.0, v128, 4.0                      ; d669007d 03db00f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_maxmin_num_f32 v153, -4.0, v134, 4.0                      ; d6690099 03db0cf7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 ; c8432591 91952794 3f650000
	v_maxmin_num_f32 v155, -4.0, v135, 4.0                      ; d669009b 03db0ef7
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f97b 7b7af37a 3f650000
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v136, 4.0                      ; d669009d 03db10f7
	v_dual_fmaak_f32 v151, v151, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v149, 0x3f650000 ; c8433197 97972b96 3f650000
	v_dual_mul_f32 v131, v131, v148 :: v_dual_mul_f32 v130, v130, v145 ; c8c72983 83832382
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_maxmin_num_f32 v159, -4.0, v137, 4.0                      ; d669009f 03db12f7
	v_dual_mul_f32 v127, v127, v123 :: v_dual_mul_f32 v126, v126, v122 ; c8c6f77f 7f7ef57e
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_mul_f32 v133, v133, v151 :: v_dual_mul_f32 v132, v132, v150 ; c8c72f85 85852d84
	v_maxmin_num_f32 v161, -4.0, v138, 4.0                      ; d66900a1 03db14f7
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
	v_maxmin_num_f32 v163, -4.0, v139, 4.0                      ; d66900a3 03db16f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v127, -4.0, v129, 4.0                      ; d669007f 03db02f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v140, 4.0                      ; d66900a5 03db18f7
	v_dual_mul_f32 v135, v135, v155 :: v_dual_mul_f32 v134, v134, v154 ; c8c73787 87873586
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v141, 4.0                      ; d66900a7 03db1af7
	v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 ; c8433d9d 9da13fa0 3f650000
	v_fma_mix_f32 v144, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bfefeff 3728ab28
	v_maxmin_num_f32 v169, -4.0, v142, 4.0                      ; d66900a9 03db1cf7
	v_maxmin_num_f32 v171, -4.0, v143, 4.0                      ; d66900ab 03db1ef7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 ; c84345a1 a1a547a4 3f650000
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_mul_f32 v137, v137, v160 :: v_dual_mul_f32 v136, v136, v157 ; c8c74189 89893b88
	v_dual_fmaak_f32 v144, v144, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842ff90 907cfd7d 3f650000
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[26:27], 0 ; cc464058 1a023524
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_mul_f32 v139, v139, v164 :: v_dual_mul_f32 v138, v138, v161 ; c8c7498b 8b8b438a
	v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84351a7 a7a74ba6 3f650000
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_dual_mul_f32 v129, v129, v144 :: v_dual_mul_f32 v128, v128, v125 ; c8c72181 8180fb80
	v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 ; c84359ab abab53aa 3f650000
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v141, v141, v167 :: v_dual_mul_f32 v140, v140, v166 ; c8c74f8d 8d8d4d8c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[28:29], v[88:95] ; cc464058 1d623944
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[30:31], 0 ; cc464060 1a023d24
	v_dual_mul_f32 v143, v143, v171 :: v_dual_mul_f32 v142, v142, v170 ; c8c7578f 8f8f558e
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[14:15], 0 ; cc464068 1a021d24
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[4:5], 0 ; cc464070 1a020924
	v_maxmin_num_f32 v177, -4.0, v90, 4.0                       ; d66900b1 03dab4f7
	v_maxmin_num_f32 v175, -4.0, v89, 4.0                       ; d66900af 03dab2f7
	v_maxmin_num_f32 v173, -4.0, v88, 4.0                       ; d66900ad 03dab0f7
	v_maxmin_num_f32 v179, -4.0, v91, 4.0                       ; d66900b3 03dab6f7
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[12:13], v[96:103] ; cc464060 1d821944
	v_maxmin_num_f32 v181, -4.0, v92, 4.0                       ; d66900b5 03dab8f7
	v_maxmin_num_f32 v183, -4.0, v93, 4.0                       ; d66900b7 03dabaf7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[16:17], v[104:111] ; cc464068 1da22144
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[68:69], v[10:11], v[112:119] ; cc464070 1dc21544
	v_maxmin_num_f32 v185, -4.0, v94, 4.0                       ; d66900b9 03dabcf7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_maxmin_num_f32 v187, -4.0, v95, 4.0                       ; d66900bb 03dabef7
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 ; c8435fb0 b0ad5dad 3f650000
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 ; c84367b4 b4b165b1 3f650000
	v_maxmin_num_f32 v189, -4.0, v96, 4.0                       ; d66900bd 03dac0f7
	v_maxmin_num_f32 v191, -4.0, v97, 4.0                       ; d66900bf 03dac2f7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_dual_fmaak_f32 v183, v183, v184, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v181, 0x3f650000 ; c84371b7 b7b76bb6 3f650000
	v_maxmin_num_f32 v69, -4.0, v98, 4.0                        ; d6690045 03dac4f7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_dual_mul_f32 v89, v89, v176 :: v_dual_mul_f32 v88, v88, v173 ; c8c76159 59595b58
	v_maxmin_num_f32 v87, -4.0, v99, 4.0                        ; d6690057 03dac6f7
	v_dual_mul_f32 v91, v91, v180 :: v_dual_mul_f32 v90, v90, v177 ; c8c7695b 5b5b635a
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_fma_mix_f32 v68, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206244 0bff7eff 3728ab28
	v_dual_mul_f32 v93, v93, v183 :: v_dual_mul_f32 v92, v92, v182 ; c8c76f5d 5d5d6d5c
	v_fma_mix_f32 v86, 0xab28, |v69|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfe8aff 3728ab28
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84379bb bbbb73ba 3f650000
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v89, -4.0, v100, 4.0                       ; d6690059 03dac8f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v101, 4.0                       ; d669005b 03dacaf7
	v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 :: v_dual_fmaak_f32 v68, v68, v191, 0x3f650000 ; c8437dbd bd457f44 3f650000
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v93, -4.0, v102, 4.0                       ; d669005d 03daccf7
	v_dual_mul_f32 v95, v95, v187 :: v_dual_mul_f32 v94, v94, v186 ; c8c7775f 5f5f755e
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_fmaak_f32 v69, v69, v86, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 ; c842ad45 4558af58 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_mul_f32 v97, v97, v68 :: v_dual_mul_f32 v96, v96, v189 ; c8c68961 61617b60
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v103, 4.0                       ; d669005f 03dacef7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_mul_f32 v99, v99, v88 :: v_dual_mul_f32 v98, v98, v69 ; c8c6b163 63628b62
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b95b 5b5ab35a 3f650000
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v104, 4.0                       ; d6690061 03dad0f7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v105, 4.0                       ; d6690063 03dad2f7
	v_dual_mul_f32 v101, v101, v91 :: v_dual_mul_f32 v100, v100, v90 ; c8c6b765 6564b564
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842c15f 5f5ebb5e 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v101, -4.0, v106, 4.0                      ; d6690065 03dad4f7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_dual_mul_f32 v103, v103, v95 :: v_dual_mul_f32 v102, v102, v94 ; c8c6bf67 6766bd66
	v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 ; c842c561 6164c764 3f650000
	v_maxmin_num_f32 v121, -4.0, v110, 4.0                      ; d6690079 03dadcf7
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v103, -4.0, v107, 4.0                      ; d6690067 03dad6f7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v111, 4.0                      ; d669007b 03dadef7
	v_dual_mul_f32 v105, v105, v100 :: v_dual_mul_f32 v104, v104, v97 ; c8c6c969 6968c368
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v112, 4.0                      ; d669007d 03dae0f7
	v_maxmin_num_f32 v127, -4.0, v113, 4.0                      ; d669007f 03dae2f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v105, -4.0, v108, 4.0                      ; d6690069 03dad8f7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v114, 4.0                      ; d6690081 03dae4f7
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f97b 7b7af37a 3f650000
	v_maxmin_num_f32 v131, -4.0, v115, 4.0                      ; d6690083 03dae6f7
	v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 :: v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 ; c842cf68 6864cd65 3f650000
	v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 ; c842fd7d 7d80ff80 3f650000
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v133, -4.0, v116, 4.0                      ; d6690085 03dae8f7
	v_dual_mul_f32 v111, v111, v123 :: v_dual_mul_f32 v110, v110, v122 ; c8c6f76f 6f6ef56e
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v117, 4.0                      ; d6690087 03daeaf7
	v_dual_mul_f32 v107, v107, v104 :: v_dual_mul_f32 v106, v106, v101 ; c8c6d16b 6b6acb6a
	v_dual_mul_f32 v113, v113, v128 :: v_dual_mul_f32 v112, v112, v125 ; c8c70171 7170fb70
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v137, -4.0, v118, 4.0                      ; d6690089 03daecf7
	v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 ; c8430581 81850784 3f650000
	v_maxmin_num_f32 v139, -4.0, v119, 4.0                      ; d669008b 03daeef7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v107, -4.0, v109, 4.0                      ; d669006b 03dadaf7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_dual_mul_f32 v115, v115, v132 :: v_dual_mul_f32 v114, v114, v129 ; c8c70973 73730372
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[26:27], 0 ; cc464060 1a023526
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 ; c8431187 87870b86 3f650000
	v_fma_mix_f32 v120, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfed6ff 3728ab28
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 ; c843198b 8b8b138a 3f650000
	v_dual_mul_f32 v117, v117, v135 :: v_dual_mul_f32 v116, v116, v134 ; c8c70f75 75750d74
	v_dual_fmaak_f32 v107, v107, v120, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 ; c842f16b 6b6ad36a 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[28:29], v[96:103] ; cc464060 1d823946
	v_dual_mul_f32 v119, v119, v139 :: v_dual_mul_f32 v118, v118, v138 ; c8c71777 77771576
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v109, v109, v107 :: v_dual_mul_f32 v108, v108, v106 ; c8c6d76d 6d6cd56c
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[14:15], 0 ; cc464070 1a021d26
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[4:5], 0 ; cc464078 1a020926
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[30:31], 0 ; cc464068 1a023d26
	v_maxmin_num_f32 v141, -4.0, v96, 4.0                       ; d669008d 03dac0f7
	v_maxmin_num_f32 v143, -4.0, v97, 4.0                       ; d669008f 03dac2f7
	v_maxmin_num_f32 v145, -4.0, v98, 4.0                       ; d6690091 03dac4f7
	v_maxmin_num_f32 v147, -4.0, v99, 4.0                       ; d6690093 03dac6f7
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[16:17], v[112:119] ; cc464070 1dc22146
	v_maxmin_num_f32 v149, -4.0, v100, 4.0                      ; d6690095 03dac8f7
	v_maxmin_num_f32 v151, -4.0, v101, 4.0                      ; d6690097 03dacaf7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[10:11], v[120:127] ; cc464078 1de21546
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[12:13], v[104:111] ; cc464068 1da21946
	v_maxmin_num_f32 v153, -4.0, v102, 4.0                      ; d6690099 03daccf7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v103, 4.0                      ; d669009b 03dacef7
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c8431f90 908d1d8d 3f650000
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8432794 94912591 3f650000
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_fmaak_f32 v151, v151, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v149, 0x3f650000 ; c8433197 97972b96 3f650000
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_mul_f32 v97, v97, v144 :: v_dual_mul_f32 v96, v96, v141 ; c8c72161 61611b60
	v_dual_mul_f32 v99, v99, v148 :: v_dual_mul_f32 v98, v98, v145 ; c8c72963 63632362
	v_maxmin_num_f32 v163, -4.0, v107, 4.0                      ; d66900a3 03dad6f7
	v_maxmin_num_f32 v157, -4.0, v104, 4.0                      ; d669009d 03dad0f7
	v_maxmin_num_f32 v159, -4.0, v105, 4.0                      ; d669009f 03dad2f7
	v_maxmin_num_f32 v161, -4.0, v106, 4.0                      ; d66900a1 03dad4f7
	v_dual_mul_f32 v101, v101, v151 :: v_dual_mul_f32 v100, v100, v150 ; c8c72f65 65652d64
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
	v_maxmin_num_f32 v165, -4.0, v108, 4.0                      ; d66900a5 03dad8f7
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v109, 4.0                      ; d66900a7 03dadaf7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v169, -4.0, v110, 4.0                      ; d66900a9 03dadcf7
	v_dual_mul_f32 v103, v103, v155 :: v_dual_mul_f32 v102, v102, v154 ; c8c73767 67673566
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v111, 4.0                      ; d66900ab 03dadef7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 ; c8433d9d 9da13fa0 3f650000
	v_maxmin_num_f32 v173, -4.0, v112, 4.0                      ; d66900ad 03dae0f7
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 ; c84345a1 a1a547a4 3f650000
	v_maxmin_num_f32 v175, -4.0, v113, 4.0                      ; d66900af 03dae2f7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_maxmin_num_f32 v177, -4.0, v114, 4.0                      ; d66900b1 03dae4f7
	v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84351a7 a7a74ba6 3f650000
	v_dual_mul_f32 v105, v105, v160 :: v_dual_mul_f32 v104, v104, v157 ; c8c74169 69693b68
	v_maxmin_num_f32 v179, -4.0, v115, 4.0                      ; d66900b3 03dae6f7
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_mul_f32 v107, v107, v164 :: v_dual_mul_f32 v106, v106, v161 ; c8c7496b 6b6b436a
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_maxmin_num_f32 v181, -4.0, v116, 4.0                      ; d66900b5 03dae8f7
	v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 ; c84359ab abab53aa 3f650000
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_dual_mul_f32 v109, v109, v167 :: v_dual_mul_f32 v108, v108, v166 ; c8c74f6d 6d6d4d6c
	v_maxmin_num_f32 v183, -4.0, v117, 4.0                      ; d66900b7 03daeaf7
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v185, -4.0, v118, 4.0                      ; d66900b9 03daecf7
	v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 ; c8435dad adb15fb0 3f650000
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_maxmin_num_f32 v187, -4.0, v119, 4.0                      ; d66900bb 03daeef7
	v_dual_mul_f32 v111, v111, v171 :: v_dual_mul_f32 v110, v110, v170 ; c8c7576f 6f6f556e
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v120, 4.0                      ; d66900bd 03daf0f7
	v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 ; c84365b1 b1b567b4 3f650000
	v_maxmin_num_f32 v191, -4.0, v121, 4.0                      ; d66900bf 03daf2f7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_dual_mul_f32 v113, v113, v176 :: v_dual_mul_f32 v112, v112, v173 ; c8c76171 71715b70
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v93, -4.0, v122, 4.0                       ; d669005d 03daf4f7
	v_dual_fmaak_f32 v183, v183, v184, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v181, 0x3f650000 ; c84371b7 b7b76bb6 3f650000
	v_maxmin_num_f32 v95, -4.0, v123, 4.0                       ; d669005f 03daf6f7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_mul_f32 v115, v115, v180 :: v_dual_mul_f32 v114, v114, v177 ; c8c76973 73736372
	v_fma_mix_f32 v92, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bff7eff 3728ab28
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v97, -4.0, v124, 4.0                       ; d6690061 03daf8f7
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84379bb bbbb73ba 3f650000
	v_maxmin_num_f32 v99, -4.0, v125, 4.0                       ; d6690063 03dafaf7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_mul_f32 v117, v117, v183 :: v_dual_mul_f32 v116, v116, v182 ; c8c76f75 75756d74
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v191, 0x3f650000 ; c8437dbd bd5d7f5c 3f650000
	v_maxmin_num_f32 v101, -4.0, v126, 4.0                      ; d6690065 03dafcf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v127, 4.0                      ; d6690067 03dafef7
	v_dual_mul_f32 v119, v119, v187 :: v_dual_mul_f32 v118, v118, v186 ; c8c77777 77777576
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842bd5d 5d60bf60 3f650000
	v_dual_mul_f32 v121, v121, v92 :: v_dual_mul_f32 v120, v120, v189 ; c8c6b979 79797b78
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 ; c842c963 6362c362 3f650000
	v_dual_mul_f32 v123, v123, v96 :: v_dual_mul_f32 v122, v122, v93 ; c8c6c17b 7b7abb7a
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c842d167 6766cb66 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v125, v125, v99 :: v_dual_mul_f32 v124, v124, v98 ; c8c6c77d 7d7cc57c
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[30:31], 0 ; cc464068 1a023d48
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v127, v127, v103 :: v_dual_mul_f32 v126, v126, v102 ; c8c6cf7f 7f7ecd7e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[26:27], 0 ; cc464060 1a023548
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[72:73], v[14:15], 0 ; cc464070 1a021d48
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[4:5], 0 ; cc464078 1a020948
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[76:77], v[12:13], v[104:111] ; cc464068 1da2194c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[76:77], v[28:29], v[96:103] ; cc464060 1d82394c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[76:77], v[16:17], v[112:119] ; cc464070 1dc2214c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[76:77], v[10:11], v[120:127] ; cc464078 1de2154c
	v_maxmin_num_f32 v136, -4.0, v100, 4.0                      ; d6690088 03dac8f7
	v_maxmin_num_f32 v130, -4.0, v97, 4.0                       ; d6690082 03dac2f7
	v_maxmin_num_f32 v134, -4.0, v99, 4.0                       ; d6690086 03dac6f7
	v_maxmin_num_f32 v132, -4.0, v98, 4.0                       ; d6690084 03dac4f7
	v_maxmin_num_f32 v128, -4.0, v96, 4.0                       ; d6690080 03dac0f7
	v_maxmin_num_f32 v138, -4.0, v101, 4.0                      ; d669008a 03dacaf7
	v_maxmin_num_f32 v140, -4.0, v102, 4.0                      ; d669008c 03daccf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v103, 4.0                      ; d669008e 03dacef7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v104, 4.0                      ; d6690090 03dad0f7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v105, 4.0                      ; d6690092 03dad2f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_fmaak_f32 v128, v128, v129, 0x3f650000                    ; 5b010380 3f650000
	v_maxmin_num_f32 v148, -4.0, v106, 4.0                      ; d6690094 03dad4f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v108, 4.0                      ; d6690098 03dad8f7
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 ; c843178a 8a8d198d 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_mul_f32 v96, v96, v128 :: v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 ; c8c30160 60830583 3f650000
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v107, 4.0                      ; d6690096 03dad6f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 :: v_dual_mul_f32 v101, v101, v138 ; c8471f8e 8e651565 3f650000
	v_maxmin_num_f32 v154, -4.0, v109, 4.0                      ; d669009a 03dadaf7
	v_dual_mul_f32 v97, v97, v131 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8c30761 61850b84 3f650000
	v_maxmin_num_f32 v156, -4.0, v110, 4.0                      ; d669009c 03dadcf7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 :: v_dual_mul_f32 v103, v103, v142 ; c8472390 90671d67 3f650000
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_mul_f32 v98, v132, v98 :: v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 ; c8c2c584 62891189 3f650000
	v_maxmin_num_f32 v158, -4.0, v111, 4.0                      ; d669009e 03dadef7
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_mul_f32 v104, v104, v144 ; c8472593 93692168 3f650000
	v_maxmin_num_f32 v160, -4.0, v112, 4.0                      ; d66900a0 03dae0f7
	v_dual_mul_f32 v100, v100, v137 :: v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 ; c8c31364 64870d87 3f650000
	v_maxmin_num_f32 v162, -4.0, v113, 4.0                      ; d66900a2 03dae2f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c843379a 9a9d399d 3f650000
	v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 :: v_dual_mul_f32 v105, v105, v147 ; c8472b94 94692769 3f650000
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v114, 4.0                      ; d66900a4 03dae4f7
	v_dual_mul_f32 v102, v102, v141 :: v_dual_mul_f32 v99, v99, v135 ; c8c71b66 66630f63
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v116, 4.0                      ; d66900a8 03dae8f7
	v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 :: v_dual_mul_f32 v109, v109, v154 ; c8473f9e 9e6d356d 3f650000
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_fmaak_f32 v153, v152, v153, 0x3f650000 :: v_dual_mul_f32 v106, v106, v148 ; c8473398 996b296a 3f650000
	v_maxmin_num_f32 v166, -4.0, v115, 4.0                      ; d66900a6 03dae6f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v170, -4.0, v117, 4.0                      ; d66900aa 03daeaf7
	v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 :: v_dual_mul_f32 v111, v111, v158 ; c84743a0 a06f3d6f 3f650000
	v_maxmin_num_f32 v172, -4.0, v118, 4.0                      ; d66900ac 03daecf7
	v_dual_mul_f32 v108, v108, v153 :: v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 ; c8c3336c 6c972d97 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v119, 4.0                      ; d66900ae 03daeef7
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_mul_f32 v112, v112, v160 ; c84745a3 a3714170 3f650000
	v_maxmin_num_f32 v176, -4.0, v120, 4.0                      ; d66900b0 03daf0f7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_dual_mul_f32 v110, v110, v157 :: v_dual_mul_f32 v107, v107, v151 ; c8c73b6e 6e6b2f6b
	v_maxmin_num_f32 v178, -4.0, v121, 4.0                      ; d66900b2 03daf2f7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 :: v_dual_mul_f32 v113, v113, v163 ; c8474ba4 a4714771 3f650000
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	buffer_load_b128 v[96:99], v9, s[16:19], null offen offset:3072 ; c405c07c 40802060 000c0009
	v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 ; c84357aa aaad59ad 3f650000
	v_maxmin_num_f32 v180, -4.0, v122, 4.0                      ; d66900b4 03daf4f7
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	buffer_load_b128 v[104:107], v9, s[16:19], null offen offset:3584 ; c405c07c 40802068 000e0009
	v_dual_fmaak_f32 v169, v168, v169, 0x3f650000 :: v_dual_mul_f32 v114, v114, v164 ; c84753a8 a9734972 3f650000
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v182, -4.0, v123, 4.0                      ; d66900b6 03daf6f7
	v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 :: v_dual_mul_f32 v117, v117, v170 ; c8475fae ae755575 3f650000
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v124, 4.0                      ; d66900b8 03daf8f7
	v_maxmin_num_f32 v186, -4.0, v125, 4.0                      ; d66900ba 03dafaf7
	v_dual_mul_f32 v116, v116, v169 :: v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 ; c8c35374 74a74da7 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 :: v_dual_mul_f32 v119, v119, v174 ; c84763b0 b0775d77 3f650000
	v_maxmin_num_f32 v188, -4.0, v126, 4.0                      ; d66900bc 03dafcf7
	v_fmaak_f32 v180, v180, v181, 0x3f650000                    ; 5b696bb4 3f650000
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v127, 4.0                      ; d66900be 03dafef7
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v118, v118, v173 :: v_dual_mul_f32 v115, v115, v167 ; c8c75b76 76734f73
	v_fmaak_f32 v183, v183, v182, 0x3f650000                    ; 5b6f6db7 3f650000
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_mul_f32 v120, v120, v176 ; c84765b3 b3796178 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84371b9 b9bb77ba 3f650000
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[26:27], 0 ; cc464070 1a02354a
	v_mul_f32_e32 v123, v123, v183                              ; 10f76f7b
	v_dual_mul_f32 v122, v122, v180 :: v_dual_mul_f32 v121, v121, v179 ; c8c7697a 7a796779
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[14:15], 0 ; cc464080 1a021d4a
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c84379bd bdbf7fbe 3f650000
	v_mul_f32_e32 v125, v125, v186                              ; 10fb757d
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[4:5], 0 ; cc464088 1a02094a
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694064
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[78:79], v[28:29], v[112:119] ; cc464070 1dc2394e
	v_dual_mul_f32 v127, v127, v190 :: v_dual_mul_f32 v124, v124, v185 ; c8c77d7f 7f7d737c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[78:79], v[16:17], v[128:135] ; cc464080 1e02214e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[78:79], v[10:11], v[136:143] ; cc464088 1e22154e
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v191, -4.0, v112, 4.0                      ; d66900bf 03dae0f7
	v_maxmin_num_f32 v102, -4.0, v115, 4.0                      ; d6690066 03dae6f7
	v_maxmin_num_f32 v108, -4.0, v116, 4.0                      ; d669006c 03dae8f7
	v_maxmin_num_f32 v110, -4.0, v117, 4.0                      ; d669006e 03daeaf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v9, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206209 0bff7eff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v191, v9, v191, 0x3f650000 :: v_dual_mul_f32 v126, v126, v189 ; c8477f09 bf7f7b7e 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842d96d 6d6edf6e 3f650000
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[30:31], 0 ; cc464078 1a023d4a
	v_maxmin_num_f32 v74, -4.0, v113, 4.0                       ; d669004a 03dae2f7
	v_dual_mul_f32 v117, v117, v110 :: v_dual_mul_f32 v116, v116, v109 ; c8c6dd75 7574db74
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_fma_mix_f32 v75, 0xab28, |v74|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624b 0bfe94ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[78:79], v[12:13], v[120:127] ; cc464078 1de2194e
	v_maxmin_num_f32 v78, -4.0, v114, 4.0                       ; d669004e 03dae4f7
	v_fmaak_f32 v75, v75, v74, 0x3f650000                       ; 5a96954b 3f650000
	v_fma_mix_f32 v79, 0xab28, |v78|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624f 0bfe9cff 3728ab28
	v_dual_mul_f32 v113, v75, v113 :: v_dual_mul_f32 v112, v112, v191 ; c8c6e34b 71717f70
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v78, v78, v79, 0x3f650000 ; c842cd67 674e9f4e 3f650000
	v_maxmin_num_f32 v116, -4.0, v120, 4.0                      ; d6690074 03daf0f7
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v118, 4.0                      ; d6690070 03daecf7
	v_dual_mul_f32 v115, v115, v103 :: v_dual_mul_f32 v114, v114, v78 ; c8c6cf73 73729d72
	v_maxmin_num_f32 v144, -4.0, v123, 4.0                      ; d6690090 03daf6f7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v119, 4.0                      ; d6690072 03daeef7
	v_maxmin_num_f32 v146, -4.0, v124, 4.0                      ; d6690092 03daf8f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v125, 4.0                      ; d6690094 03dafaf7
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v126, 4.0                      ; d6690096 03dafcf7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v127, 4.0                      ; d6690098 03dafef7
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 ; c842e171 7172e772 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432593 93952b94 3f650000
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v128, 4.0                      ; d669009a 03db00f7
	v_dual_mul_f32 v119, v119, v114 :: v_dual_mul_f32 v118, v118, v113 ; c8c6e577 7776e376
	v_maxmin_num_f32 v156, -4.0, v129, 4.0                      ; d669009c 03db02f7
	v_dual_mul_f32 v125, v125, v148 :: v_dual_mul_f32 v124, v124, v147 ; c8c7297d 7d7d277c
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c8432d97 97993398 3f650000
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v121, 4.0                      ; d6690076 03daf2f7
	v_maxmin_num_f32 v158, -4.0, v130, 4.0                      ; d669009e 03db04f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v160, -4.0, v131, 4.0                      ; d66900a0 03db06f7
	v_dual_mul_f32 v127, v127, v152 :: v_dual_mul_f32 v126, v126, v151 ; c8c7317f 7f7f2f7e
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v132, 4.0                      ; d66900a2 03db08f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c843399d 9d9b379a 3f650000
	v_maxmin_num_f32 v164, -4.0, v133, 4.0                      ; d66900a4 03db0af7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_fmaak_f32 v119, v119, v118, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c842ed77 7774eb74 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v134, 4.0                      ; d66900a6 03db0cf7
	v_dual_mul_f32 v129, v129, v157 :: v_dual_mul_f32 v128, v128, v154 ; c8c73b81 81813580
	v_maxmin_num_f32 v168, -4.0, v135, 4.0                      ; d66900a8 03db0ef7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84341a1 a19f3f9e 3f650000
	v_dual_mul_f32 v121, v121, v119 :: v_dual_mul_f32 v120, v120, v116 ; c8c6ef79 7978e978
	v_maxmin_num_f32 v170, -4.0, v136, 4.0                      ; d66900aa 03db10f7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v172, -4.0, v137, 4.0                      ; d66900ac 03db12f7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c84345a3 a3a54ba4 3f650000
	v_dual_mul_f32 v131, v131, v161 :: v_dual_mul_f32 v130, v130, v158 ; c8c74383 83833d82
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v122, 4.0                      ; d6690078 03daf4f7
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v138, 4.0                      ; d66900ae 03db14f7
	v_maxmin_num_f32 v176, -4.0, v139, 4.0                      ; d66900b0 03db16f7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c8434da7 a7a953a8 3f650000
	v_dual_mul_f32 v133, v133, v164 :: v_dual_mul_f32 v132, v132, v163 ; c8c74985 85854784
(invalid instruction)                                        ; d7694066
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v178, -4.0, v140, 4.0                      ; d66900b2 03db18f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v141, 4.0                      ; d66900b4 03db1af7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84359ad adab57aa 3f650000
	v_dual_mul_f32 v135, v135, v168 :: v_dual_mul_f32 v134, v134, v167 ; c8c75187 87874f86
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v182, -4.0, v142, 4.0                      ; d66900b6 03db1cf7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v143, 4.0                      ; d66900b8 03db1ef7
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8432191 9178f378 3f650000
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84361b1 b1af5fae 3f650000
	v_dual_mul_f32 v137, v137, v173 :: v_dual_mul_f32 v136, v136, v170 ; c8c75b89 89895588
(invalid instruction)                                        ; d7694067
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_mul_f32 v123, v123, v145 :: v_dual_mul_f32 v122, v122, v120 ; c8c7237b 7b7af17a
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c84365b3 b3b56bb4 3f650000
	v_dual_mul_f32 v139, v139, v177 :: v_dual_mul_f32 v138, v138, v174 ; c8c7638b 8b8b5d8a
(invalid instruction)                                        ; d769006c
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8436db7 b7b973b8 3f650000
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v141, v141, v180 :: v_dual_mul_f32 v140, v140, v179 ; c8c7698d 8d8d678c
(invalid instruction)                                        ; d769406c
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v143, v143, v184 :: v_dual_mul_f32 v142, v142, v183 ; c8c7718f 8f8f6f8e
(invalid instruction)                                        ; d769006d
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769406d
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[96:97], v[4:5], 0 ; cc464088 1a020960
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[96:97], v[26:27], 0 ; cc464070 1a023560
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[96:97], v[30:31], 0 ; cc464078 1a023d60
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[96:97], v[14:15], 0 ; cc464080 1a021d60
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[104:105], v[10:11], v[136:143] ; cc464088 1e221568
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[104:105], v[28:29], v[112:119] ; cc464070 1dc23968
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[104:105], v[12:13], v[120:127] ; cc464078 1de21968
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[104:105], v[16:17], v[128:135] ; cc464080 1e022168
	v_maxmin_num_f32 v105, -4.0, v117, 4.0                      ; d6690069 03daeaf7
	v_maxmin_num_f32 v188, -4.0, v113, 4.0                      ; d66900bc 03dae2f7
	v_maxmin_num_f32 v97, -4.0, v116, 4.0                       ; d6690061 03dae8f7
	v_maxmin_num_f32 v186, -4.0, v112, 4.0                      ; d66900ba 03dae0f7
	v_maxmin_num_f32 v190, -4.0, v114, 4.0                      ; d66900be 03dae4f7
	v_maxmin_num_f32 v111, -4.0, v118, 4.0                      ; d669006f 03daecf7
	v_fma_mix_f32 v110, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfed2ff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v104, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfec2ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_fmaak_f32 v105, v105, v110, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v97, 0x3f650000 ; c842dd69 6968c368 3f650000
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84379bd bdbb77ba 3f650000
	v_dual_mul_f32 v117, v117, v105 :: v_dual_mul_f32 v116, v116, v104 ; c8c6d375 7574d174
	v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 :: v_dual_mul_f32 v113, v113, v189 ; c8477fbe be717b71 3f650000
	v_maxmin_num_f32 v191, -4.0, v115, 4.0                      ; d66900bf 03dae6f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
(invalid instruction)                                        ; d7690061
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v117, -4.0, v121, 4.0                      ; d6690075 03daf2f7
	v_fma_mix_f32 v9, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206209 0bff7eff 3728ab28
	v_dual_fmaak_f32 v9, v9, v191, 0x3f650000 :: v_dual_mul_f32 v112, v112, v186 ; c8477f09 09717570 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
(invalid instruction)                                        ; d7690060
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v113, -4.0, v119, 4.0                      ; d6690071 03daeef7
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_dual_mul_f32 v115, v115, v9 :: v_dual_mul_f32 v114, v114, v190 ; c8c61373 73737d72
(invalid instruction)                                        ; d7694060
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v115, -4.0, v120, 4.0                      ; d6690073 03daf0f7
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v145, -4.0, v124, 4.0                      ; d6690091 03daf8f7
	v_maxmin_num_f32 v147, -4.0, v125, 4.0                      ; d6690093 03dafaf7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 ; c842e571 7170df70 3f650000
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_maxmin_num_f32 v149, -4.0, v126, 4.0                      ; d6690095 03dafcf7
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_maxmin_num_f32 v151, -4.0, v127, 4.0                      ; d6690097 03dafef7
	v_dual_mul_f32 v119, v119, v113 :: v_dual_mul_f32 v118, v118, v112 ; c8c6e377 7776e176
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_fmaak_f32 v147, v147, v148, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v145, 0x3f650000 ; c8432993 93932392 3f650000
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_maxmin_num_f32 v153, -4.0, v128, 4.0                      ; d6690099 03db00f7
(invalid instruction)                                        ; d7694061
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v122, 4.0                      ; d6690077 03daf4f7
	v_maxmin_num_f32 v155, -4.0, v129, 4.0                      ; d669009b 03db02f7
	v_dual_mul_f32 v125, v125, v147 :: v_dual_mul_f32 v124, v124, v146 ; c8c7277d 7d7d257c
	v_dual_fmaak_f32 v151, v151, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v149, 0x3f650000 ; c8433197 97972b96 3f650000
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v130, 4.0                      ; d669009d 03db04f7
	v_dual_fmaak_f32 v118, v118, v117, 0x3f650000 :: v_dual_fmaak_f32 v115, v115, v116, 0x3f650000 ; c842eb76 7672e973 3f650000
	v_maxmin_num_f32 v159, -4.0, v131, 4.0                      ; d669009f 03db06f7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_mul_f32 v127, v127, v151 :: v_dual_mul_f32 v126, v126, v150 ; c8c72f7f 7f7f2d7e
	v_maxmin_num_f32 v161, -4.0, v132, 4.0                      ; d66900a1 03db08f7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_mul_f32 v121, v121, v118 :: v_dual_mul_f32 v120, v120, v115 ; c8c6ed79 7978e778
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v133, 4.0                      ; d66900a3 03db0af7
	v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 ; c8433599 999d379c 3f650000
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v134, 4.0                      ; d66900a5 03db0cf7
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v121, -4.0, v123, 4.0                      ; d6690079 03daf6f7
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 ; c8433d9d 9da13fa0 3f650000
	v_maxmin_num_f32 v167, -4.0, v135, 4.0                      ; d66900a7 03db0ef7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_dual_mul_f32 v129, v129, v156 :: v_dual_mul_f32 v128, v128, v153 ; c8c73981 81813380
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v169, -4.0, v136, 4.0                      ; d66900a9 03db10f7
	v_maxmin_num_f32 v171, -4.0, v137, 4.0                      ; d66900ab 03db12f7
	v_fma_mix_f32 v144, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bfef2ff 3728ab28
	v_dual_mul_f32 v131, v131, v160 :: v_dual_mul_f32 v130, v130, v157 ; c8c74183 83833b82
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c84349a3 a3a343a2 3f650000
	s_load_b128 s[20:23], s[0:1], 0x30                          ; f4004500 f8000030
(invalid instruction)                                        ; d769006e
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_lshrrev_b32_e32 v173, 4, v0                               ; 335a0084
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshlrev_b32_e32 v173, 3, v173                             ; 315b5a83
	v_add_lshl_u32 v174, s8, v173, 2                            ; d64700ae 020b5a08
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b128 v[112:115], v174, s[20:23], null offen     ; c405c07c 40802870 000000ae
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_fmaak_f32 v144, v144, v121, 0x3f650000 :: v_dual_fmaak_f32 v119, v119, v120, 0x3f650000 ; c842f390 9076f177 3f650000
(invalid instruction)                                        ; d769406e
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_mul_f32 v123, v123, v144 :: v_dual_mul_f32 v122, v122, v119 ; c8c7217b 7b7aef7a
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	buffer_load_b128 v[120:123], v174, s[20:23], null offen offset:16 ; c405c07c 40802878 000010ae
	v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84351a7 a7a74ba6 3f650000
	v_maxmin_num_f32 v175, -4.0, v138, 4.0                      ; d66900af 03db14f7
	v_dual_mul_f32 v133, v133, v163 :: v_dual_mul_f32 v132, v132, v162 ; c8c74785 85854584
	v_maxmin_num_f32 v177, -4.0, v139, 4.0                      ; d66900b1 03db16f7
	v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 ; c84355a9 a9ad57ac 3f650000
	v_maxmin_num_f32 v179, -4.0, v140, 4.0                      ; d66900b3 03db18f7
	v_maxmin_num_f32 v181, -4.0, v141, 4.0                      ; d66900b5 03db1af7
	v_dual_mul_f32 v135, v135, v167 :: v_dual_mul_f32 v134, v134, v166 ; c8c74f87 87874d86
	v_maxmin_num_f32 v183, -4.0, v142, 4.0                      ; d66900b7 03db1cf7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
(invalid instruction)                                        ; d769006f
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v185, -4.0, v143, 4.0                      ; d66900b9 03db1ef7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_dual_mul_f32 v137, v137, v172 :: v_dual_mul_f32 v136, v136, v169 ; c8c75989 89895388
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
(invalid instruction)                                        ; d769406f
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fmaak_f32 v175, v175, v176, 0x3f650000                    ; 5b5f61af 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[98:99], v[26:27], 0 ; cc464080 1a023562
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[98:99], v[14:15], 0 ; cc464090 1a021d62
	v_fmaak_f32 v178, v178, v177, 0x3f650000                    ; 5b6563b2 3f650000
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add_lshl_u32 v187, s4, v8, 2                              ; d64700bb 020a1004
	buffer_load_b128 v[124:127], v187, s[16:19], null offen     ; c405c07c 4080207c 000000bb
(invalid instruction)                                        ; d7690074
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[98:99], v[4:5], 0 ; cc464098 1a020962
	v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 ; c8436db5 b5b567b4 3f650000
	v_mul_f32_e32 v138, v138, v175                              ; 11155f8a
	v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 ; c84375b9 b9b96fb8 3f650000
	v_mul_f32_e32 v139, v139, v178                              ; 1117658b
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v141, v141, v181 :: v_dual_mul_f32 v140, v140, v180 ; c8c76b8d 8d8d698c
	v_dual_mul_f32 v143, v143, v185 :: v_dual_mul_f32 v142, v142, v184 ; c8c7738f 8f8f718e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[106:107], v[28:29], v[128:135] ; cc464080 1e02396a
(invalid instruction)                                        ; d7694074
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690075
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694075
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[98:99], v[30:31], 0 ; cc464088 1a023d62
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[106:107], v[12:13], v[136:143] ; cc464088 1e22196a
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[12:15], v187, s[16:19], null offen offset:512 ; c405c07c 4080200c 000200bb
	buffer_load_b128 v[28:31], v187, s[16:19], null offen offset:1024 ; c405c07c 4080201c 000400bb
	buffer_load_b128 v[160:163], v187, s[16:19], null offen offset:1536 ; c405c07c 408020a0 000600bb
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[106:107], v[16:17], v[144:151] ; cc464090 1e42216a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[106:107], v[10:11], v[152:159] ; cc464098 1e62156a
	v_maxmin_num_f32 v190, -4.0, v129, 4.0                      ; d66900be 03db02f7
	v_maxmin_num_f32 v188, -4.0, v128, 4.0                      ; d66900bc 03db00f7
	v_maxmin_num_f32 v9, -4.0, v131, 4.0                        ; d6690009 03db06f7
	v_maxmin_num_f32 v11, -4.0, v132, 4.0                       ; d669000b 03db08f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v10, 0xab28, |v9|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620a 0bfe12ff 3728ab28
	v_fmaak_f32 v188, v188, v189, 0x3f650000                    ; 5b797bbc 3f650000
	v_fmaak_f32 v10, v10, v9, 0x3f650000                        ; 5a14130a 3f650000
	v_maxmin_num_f32 v17, -4.0, v133, 4.0                       ; d6690011 03db0af7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_mul_f32 v128, v128, v188 :: v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 ; c8c37980 80bf7dbf 3f650000
	v_mul_f32_e32 v131, v131, v10                               ; 11061583
	v_mul_f32_e32 v129, v129, v191                              ; 11037f81
	v_maxmin_num_f32 v191, -4.0, v130, 4.0                      ; d66900bf 03db04f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_fma_mix_f32 v16, 0xab28, |v11|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206210 0bfe16ff 3728ab28
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	v_fmaak_f32 v191, v191, v5, 0x3f650000                      ; 5b7e0bbf 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v130, v130, v191                              ; 11057f82
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[128:131], v187, s[16:19], null offen offset:2048 ; c405c07c 40802080 000800bb
	buffer_load_b128 v[164:167], v187, s[16:19], null offen offset:2560 ; c405c07c 408020a4 000a00bb
	buffer_load_b128 v[168:171], v187, s[16:19], null offen offset:3072 ; c405c07c 408020a8 000c00bb
	v_maxmin_num_f32 v27, -4.0, v134, 4.0                       ; d669001b 03db0cf7
	v_fma_mix_f32 v26, 0xab28, |v17|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe22ff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v135, 4.0                       ; d6690063 03db0ef7
	v_fmaak_f32 v16, v16, v11, 0x3f650000                       ; 5a201710 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v98, 0xab28, |v27|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfe36ff 3728ab28
	v_fma_mix_f32 v106, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfec6ff 3728ab28
	v_dual_mul_f32 v132, v132, v16 :: v_dual_fmaak_f32 v17, v17, v26, 0x3f650000 ; c8c22184 84103511 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fmaak_f32 v98, v98, v27, 0x3f650000                       ; 5ac43762 3f650000
	v_fmaak_f32 v99, v99, v106, 0x3f650000                      ; 5ac6d563 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v134, v134, v98 :: v_dual_mul_f32 v133, v133, v17 ; c8c6c586 86842385
	v_mul_f32_e32 v135, v135, v99                               ; 110ec787
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	buffer_load_b128 v[132:135], v187, s[16:19], null offen offset:3584 ; c405c07c 40802084 000e00bb
	v_maxmin_num_f32 v107, -4.0, v136, 4.0                      ; d669006b 03db10f7
	v_maxmin_num_f32 v119, -4.0, v137, 4.0                      ; d6690077 03db12f7
	v_maxmin_num_f32 v175, -4.0, v138, 4.0                      ; d66900af 03db14f7
	v_maxmin_num_f32 v177, -4.0, v139, 4.0                      ; d66900b1 03db16f7
	v_maxmin_num_f32 v179, -4.0, v140, 4.0                      ; d66900b3 03db18f7
	v_maxmin_num_f32 v181, -4.0, v141, 4.0                      ; d66900b5 03db1af7
	v_maxmin_num_f32 v183, -4.0, v142, 4.0                      ; d66900b7 03db1cf7
	v_fma_mix_f32 v118, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfed6ff 3728ab28
	v_fma_mix_f32 v172, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bfeeeff 3728ab28
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fmaak_f32 v107, v107, v118, 0x3f650000                    ; 5ad6ed6b 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v119, 0x3f650000 ; c84361af afacefac 3f650000
	v_mul_f32_e32 v136, v136, v107                              ; 1110d788
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_dual_fmaak_f32 v178, v178, v177, 0x3f650000 :: v_dual_mul_f32 v137, v137, v172 ; c84763b2 b2895989 3f650000
	v_mul_f32_e32 v138, v138, v175                              ; 11155f8a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_mul_f32 v139, v139, v178 ; c84767b4 b48b658b 3f650000
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[136:139], v174, s[20:23], null offen offset:64 ; c405c07c 40802888 000040ae
	buffer_load_b128 v[176:179], v174, s[20:23], null offen offset:80 ; c405c07c 408028b0 000050ae
	v_maxmin_num_f32 v185, -4.0, v143, 4.0                      ; d66900b9 03db1ef7
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_maxmin_num_f32 v187, -4.0, v144, 4.0                      ; d66900bb 03db20f7
	v_maxmin_num_f32 v189, -4.0, v145, 4.0                      ; d66900bd 03db22f7
	v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 :: v_dual_mul_f32 v140, v140, v180 ; c8476db5 b58d698c 3f650000
	v_maxmin_num_f32 v191, -4.0, v146, 4.0                      ; d66900bf 03db24f7
	v_maxmin_num_f32 v17, -4.0, v147, 4.0                       ; d6690011 03db26f7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v27, -4.0, v148, 4.0                       ; d669001b 03db28f7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v149, 4.0                       ; d6690063 03db2af7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_mul_f32 v141, v141, v181 ; c8476fb8 b88d6b8d 3f650000
	v_fma_mix_f32 v9, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206209 0bff7eff 3728ab28
	v_fma_mix_f32 v26, 0xab28, |v17|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe22ff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v150, 4.0                      ; d669006b 03db2cf7
	v_fmaak_f32 v185, v185, v186, 0x3f650000                    ; 5b7375b9 3f650000
	v_fma_mix_f32 v98, 0xab28, |v27|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfe36ff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v151, 4.0                      ; d6690077 03db2ef7
	v_fma_mix_f32 v106, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfec6ff 3728ab28
	v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 :: v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 ; c8437bbe bebb79bb 3f650000
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_fmaak_f32 v26, v17, v26, 0x3f650000 :: v_dual_fmaak_f32 v191, v191, v9, 0x3f650000 ; c8423511 1abe13bf 3f650000
	v_maxmin_num_f32 v141, -4.0, v152, 4.0                      ; d669008d 03db30f7
	v_fma_mix_f32 v118, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfed6ff 3728ab28
	v_dual_mul_f32 v143, v143, v185 :: v_dual_mul_f32 v142, v142, v184 ; c8c7738f 8f8f718e
	v_fma_mix_f32 v140, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bfeeeff 3728ab28
	v_dual_fmaak_f32 v99, v99, v106, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v27, 0x3f650000 ; c842d563 63623762 3f650000
	v_dual_mul_f32 v145, v145, v190 :: v_dual_mul_f32 v144, v144, v187 ; c8c77d91 91917790
	v_dual_mul_f32 v147, v147, v26 :: v_dual_mul_f32 v146, v146, v191 ; c8c63593 93937f92
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_maxmin_num_f32 v143, -4.0, v153, 4.0                      ; d669008f 03db32f7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_dual_fmaak_f32 v119, v119, v140, 0x3f650000 :: v_dual_fmaak_f32 v118, v118, v107, 0x3f650000 ; c8431977 7776d776 3f650000
	v_dual_mul_f32 v149, v149, v99 :: v_dual_mul_f32 v148, v148, v98 ; c8c6c795 9594c594
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v145, -4.0, v154, 4.0                      ; d6690091 03db34f7
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_maxmin_num_f32 v147, -4.0, v155, 4.0                      ; d6690093 03db36f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_dual_mul_f32 v151, v151, v119 :: v_dual_mul_f32 v150, v150, v118 ; c8c6ef97 9796ed96
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v149, -4.0, v156, 4.0                      ; d6690095 03db38f7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 ; c8431d8d 8d911f90 3f650000
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_maxmin_num_f32 v151, -4.0, v157, 4.0                      ; d6690097 03db3af7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 ; c8432591 91952794 3f650000
	s_mov_b64 s[24:25], s[20:21]                                ; be980114
	v_dual_mul_f32 v153, v153, v144 :: v_dual_mul_f32 v152, v152, v141 ; c8c72199 99991b98
	s_mov_b64 s[26:27], s[22:23]                                ; be9a0116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v155, v155, v148 :: v_dual_mul_f32 v154, v154, v145 ; c8c7299b 9b9b239a
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v153, -4.0, v158, 4.0                      ; d6690099 03db3cf7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mix_f32 v145, v6, v113, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a02e306
	v_fma_mix_f32 v144, v6, v112, neg(0) op_sel_hi:[1,0,0]      ; cc200090 8a02e106
	v_fma_mix_f32 v147, v7, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200893 8a02e707
	v_fma_mix_f32 v146, v7, v114, neg(0) op_sel_hi:[1,0,0]      ; cc200092 8a02e507
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v155, -4.0, v159, 4.0                      ; d669009b 03db3ef7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_fmaak_f32 v151, v151, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v149, 0x3f650000 ; c8433197 97972b96 3f650000
	v_fma_mix_f32 v152, v44, v112, neg(0) op_sel_hi:[1,0,0]     ; cc200098 8a02e12c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v157, v157, v151 :: v_dual_mul_f32 v156, v156, v150 ; c8c72f9d 9d9d2d9c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mix_f32 v150, v25, v122, neg(0) op_sel_hi:[1,0,0]     ; cc200096 8a02f519
	v_fma_mix_f32 v149, v24, v121, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a02f318
	v_fma_mix_f32 v148, v24, v120, neg(0) op_sel_hi:[1,0,0]     ; cc200094 8a02f118
	v_fma_mix_f32 v151, v25, v123, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a02f719
	v_fma_mix_f32 v184, v52, v112, neg(0) op_sel_hi:[1,0,0]     ; cc2000b8 8a02e134
	v_fma_mix_f32 v185, v52, v113, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a02e334
	v_fma_mix_f32 v186, v53, v114, neg(0) op_sel_hi:[1,0,0]     ; cc2000ba 8a02e535
	v_fma_mix_f32 v187, v53, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a02e735
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_fma_mix_f32 v157, v46, v121, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a02f32e
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v172, s5, v8, 2                              ; d64700ac 020a1005
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
	v_fma_mix_f32 v153, v44, v113, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a02e32c
	v_fma_mix_f32 v156, v46, v120, neg(0) op_sel_hi:[1,0,0]     ; cc20009c 8a02f12e
	v_fma_mix_f32 v188, v54, v120, neg(0) op_sel_hi:[1,0,0]     ; cc2000bc 8a02f136
	v_fma_mix_f32 v189, v54, v121, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a02f336
	v_fma_mix_f32 v190, v55, v122, neg(0) op_sel_hi:[1,0,0]     ; cc2000be 8a02f537
	v_fma_mix_f32 v191, v55, v123, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a02f737
	v_dual_mul_f32 v159, v159, v155 :: v_dual_mul_f32 v158, v158, v154 ; c8c7379f 9f9f359e
	v_fma_mix_f32 v154, v45, v114, neg(0) op_sel_hi:[1,0,0]     ; cc20009a 8a02e52d
	v_fma_mix_f32 v155, v45, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089b 8a02e72d
	v_fma_mix_f32 v112, v60, v112, neg(0) op_sel_hi:[1,0,0]     ; cc200070 8a02e13c
	v_fma_mix_f32 v113, v60, v113, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200871 8a02e33c
	v_fma_mix_f32 v114, v61, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200072 8a02e53d
	v_fma_mix_f32 v115, v61, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200873 8a02e73d
	v_fma_mix_f32 v120, v62, v120, neg(0) op_sel_hi:[1,0,0]     ; cc200078 8a02f13e
	v_fma_mix_f32 v121, v62, v121, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200879 8a02f33e
	v_fma_mix_f32 v118, v63, v122, neg(0) op_sel_hi:[1,0,0]     ; cc200076 8a02f53f
	v_fma_mix_f32 v119, v63, v123, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a02f73f
	v_dual_mov_b32 v7, v117 :: v_dual_mov_b32 v6, v116          ; ca100175 07060174
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_fma_mix_f32 v159, v47, v123, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089f 8a02f72f
	v_fma_mix_f32 v158, v47, v122, neg(0) op_sel_hi:[1,0,0]     ; cc20009e 8a02f52f
	v_dual_mov_b32 v117, v121 :: v_dual_mov_b32 v116, v120      ; ca100179 75740178
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[124:125], v[32:33], v[112:119] ; cc464070 1dc2417c
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[44:47], v172, s[16:19], null offen       ; c405c07c 4080202c 000000ac
	buffer_load_b128 v[52:55], v172, s[16:19], null offen offset:1024 ; c405c07c 40802034 000400ac
	buffer_load_b128 v[60:63], v172, s[16:19], null offen offset:2048 ; c405c07c 4080203c 000800ac
	buffer_load_b128 v[140:143], v172, s[16:19], null offen offset:512 ; c405c07c 4080208c 000200ac
	buffer_load_b128 v[120:123], v172, s[16:19], null offen offset:1536 ; c405c07c 40802078 000600ac
	buffer_load_b128 v[180:183], v172, s[16:19], null offen offset:2560 ; c405c07c 408020b4 000a00ac
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[124:125], v[20:21], v[152:159] ; cc464098 1e62297c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[124:125], v[22:23], v[184:191] ; cc4640b8 1ee22d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[124:125], v[18:19], v[144:151] ; cc464090 1e42257c
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[84:85], v[112:119] ; cc464070 1dc2a90c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[12:13], v[80:81], v[152:159] ; cc464098 1e62a10c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[12:13], v[34:35], v[144:151] ; cc464090 1e42450c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[12:13], v[82:83], v[184:191] ; cc4640b8 1ee2a50c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[88:89], v[112:119] ; cc464070 1dc2b11c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[28:29], v[68:69], v[152:159] ; cc464098 1e62891c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[28:29], v[36:37], v[144:151] ; cc464090 1e42491c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[160:161], v[92:93], v[112:119] ; cc464070 1dc2b9a0
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[160:161], v[70:71], v[152:159] ; cc464098 1e628da0
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[160:161], v[38:39], v[144:151] ; cc464090 1e424da0
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[128:129], v[100:101], v[112:119] ; cc464070 1dc2c980
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[128:129], v[76:77], v[152:159] ; cc464098 1e629980
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[128:129], v[72:73], v[144:151] ; cc464090 1e429180
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[164:165], v[108:109], v[112:119] ; cc464070 1dc2d9a4
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[164:165], v[78:79], v[152:159] ; cc464098 1e629da4
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[164:165], v[74:75], v[144:151] ; cc464090 1e4295a4
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[168:169], v[6:7], v[112:119] ; cc464070 1dc20da8
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[168:169], v[104:105], v[152:159] ; cc464098 1e62d1a8
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[168:169], v[96:97], v[144:151] ; cc464090 1e42c1a8
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[132:133], v[26:27], v[112:119] ; cc464070 1dc23584
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[132:133], v[10:11], v[152:159] ; cc464098 1e621584
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[132:133], v[4:5], v[144:151] ; cc464090 1e420984
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690062
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694062
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690063
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694063
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mix_f32 v174, v40, v136, neg(0) op_sel_hi:[1,0,0]     ; cc2000ae 8a031128
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_fma_mix_f32 v175, v40, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a031328
	s_load_b32 s4, s[14:15], 0x24                               ; f4000107 f8000024
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	s_bitset0_b32 s25, 14                                       ; be99108e
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s4, s4, 2                                        ; 84048204
	s_buffer_load_b32 s4, s[24:27], s4 offset:0x0               ; f402010c 08000000
	v_fma_mix_f32 v9, v41, v138, neg(0) op_sel_hi:[1,0,0]       ; cc200009 8a031529
	v_fma_mix_f32 v41, v41, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200829 8a031729
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[28:29], v[86:87], v[184:191] ; cc4640b8 1ee2ad1c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[160:161], v[90:91], v[184:191] ; cc4640b8 1ee2b5a0
	v_fma_mix_f32 v160, v56, v136, neg(0) op_sel_hi:[1,0,0]     ; cc2000a0 8a031138
	v_fma_mix_f32 v161, v56, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a1 8a031338
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[128:129], v[94:95], v[184:191] ; cc4640b8 1ee2bd80
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mix_f32 v128, v50, v176, neg(0) op_sel_hi:[1,0,0]     ; cc200080 8a036132
	v_fma_mix_f32 v129, v50, v177, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a036332
	v_fma_mix_f32 v40, v42, v176, neg(0) op_sel_hi:[1,0,0]      ; cc200028 8a03612a
	v_fma_mix_f32 v42, v42, v177, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082a 8a03632a
	v_fma_mix_f32 v106, v43, v178, neg(0) op_sel_hi:[1,0,0]     ; cc20006a 8a03652b
	v_fma_mix_f32 v43, v43, v179, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082b 8a03672b
	v_fma_mix_f32 v107, v48, v136, neg(0) op_sel_hi:[1,0,0]     ; cc20006b 8a031130
	v_fma_mix_f32 v48, v48, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200830 8a031330
	v_fma_mix_f32 v124, v49, v138, neg(0) op_sel_hi:[1,0,0]     ; cc20007c 8a031531
	v_fma_mix_f32 v125, v49, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087d 8a031731
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[164:165], v[102:103], v[184:191] ; cc4640b8 1ee2cda4
	v_fma_mix_f32 v164, v57, v138, neg(0) op_sel_hi:[1,0,0]     ; cc2000a4 8a031539
	v_fma_mix_f32 v165, v57, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a031739
	v_dual_mov_b32 v57, v39 :: v_dual_mov_b32 v56, v38          ; ca100127 39380126
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[168:169], v[110:111], v[184:191] ; cc4640b8 1ee2dda8
	v_fma_mix_f32 v168, v58, v176, neg(0) op_sel_hi:[1,0,0]     ; cc2000a8 8a03613a
	v_fma_mix_f32 v169, v58, v177, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a03633a
	v_fma_mix_f32 v172, v59, v178, neg(0) op_sel_hi:[1,0,0]     ; cc2000ac 8a03653b
	v_fma_mix_f32 v59, v59, v179, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083b 8a03673b
	v_fma_mix_f32 v136, v64, v136, neg(0) op_sel_hi:[1,0,0]     ; cc200088 8a031140
	v_fma_mix_f32 v137, v64, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200889 8a031340
	v_fma_mix_f32 v138, v65, v138, neg(0) op_sel_hi:[1,0,0]     ; cc20008a 8a031541
	v_fma_mix_f32 v139, v65, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088b 8a031741
	v_fma_mix_f32 v176, v66, v176, neg(0) op_sel_hi:[1,0,0]     ; cc2000b0 8a036142
	v_fma_mix_f32 v177, v66, v177, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a036342
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[132:133], v[16:17], v[184:191] ; cc4640b8 1ee22184
	v_fma_mix_f32 v132, v51, v178, neg(0) op_sel_hi:[1,0,0]     ; cc200084 8a036533
	v_fma_mix_f32 v133, v51, v179, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200885 8a036733
	v_dual_mov_b32 v51, v37 :: v_dual_mov_b32 v50, v36          ; ca100125 33320124
	v_dual_mov_b32 v36, v174 :: v_dual_mov_b32 v39, v41         ; ca1001ae 24260129
	v_dual_mov_b32 v38, v9 :: v_dual_mov_b32 v41, v42           ; ca100109 2628012a
	v_dual_mov_b32 v42, v106 :: v_dual_mov_b32 v37, v175        ; ca10016a 2a2401af
	v_fma_mix_f32 v178, v67, v178, neg(0) op_sel_hi:[1,0,0]     ; cc2000b2 8a036543
	v_fma_mix_f32 v179, v67, v179, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a036743
	v_swap_b32 v130, v132                                       ; 7f04cb84
	v_dual_mov_b32 v175, v139 :: v_dual_mov_b32 v174, v138      ; ca10018b afae018a
	v_swap_b32 v131, v133                                       ; 7f06cb85
	v_swap_b32 v59, v167                                        ; 7e76cba7
	v_swap_b32 v166, v172                                       ; 7f4ccbac
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[126:127], v[18:19], v[36:43] ; cc464024 1c92257e
	v_dual_mov_b32 v19, v127 :: v_dual_mov_b32 v18, v126        ; ca10017f 1312017e
	v_dual_mov_b32 v127, v125 :: v_dual_mov_b32 v126, v124      ; ca10017d 7f7e017c
	v_dual_mov_b32 v125, v48 :: v_dual_mov_b32 v124, v107       ; ca100130 7d7c016b
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_swap_b32 v137, v173                                       ; 7f12cbad
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_swap_b32 v136, v172                                       ; 7f10cbac
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[18:19], v[20:21], v[124:131] ; cc46407c 1df22912
	v_dual_mov_b32 v20, v163 :: v_dual_mov_b32 v9, v162         ; ca1001a3 140801a2
	v_dual_mov_b32 v162, v164 :: v_dual_mov_b32 v163, v165      ; ca1001a4 a2a201a5
	v_dual_mov_b32 v165, v169 :: v_dual_mov_b32 v164, v168      ; ca1001a9 a5a401a8
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[18:19], v[22:23], v[160:167] ; cc4640a0 1e822d12
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[14:15], v[34:35], v[36:43] ; cc464024 1c92450e
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[18:19], v[32:33], v[172:179] ; cc4640ac 1eb24112
	v_dual_mov_b32 v58, v136 :: v_dual_mov_b32 v19, v9          ; ca100188 3a120109
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[14:15], v[80:81], v[124:131] ; cc46407c 1df2a10e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[14:15], v[82:83], v[160:167] ; cc4640a0 1e82a50e
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[30:31], v[50:51], v[36:43] ; cc464024 1c92651e
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[14:15], v[84:85], v[172:179] ; cc4640ac 1eb2a90e
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[30:31], v[68:69], v[124:131] ; cc46407c 1df2891e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[30:31], v[86:87], v[160:167] ; cc4640a0 1e82ad1e
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[19:20], v[56:57], v[36:43] ; cc464024 1c927113
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[30:31], v[88:89], v[172:179] ; cc4640ac 1eb2b11e
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[19:20], v[70:71], v[124:131] ; cc46407c 1df28d13
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[19:20], v[90:91], v[160:167] ; cc4640a0 1e82b513
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[132:133], v[72:73], v[36:43] ; cc464024 1c929184
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[19:20], v[92:93], v[172:179] ; cc4640ac 1eb2b913
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[12:13], 0 ; cc464040 1a02192e
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[132:133], v[76:77], v[124:131] ; cc46407c 1df29984
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[54:55], v[12:13], 0 ; cc464050 1a021936
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[132:133], v[94:95], v[160:167] ; cc4640a0 1e82bd84
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[58:59], v[74:75], v[36:43] ; cc464024 1c92953a
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[132:133], v[100:101], v[172:179] ; cc4640ac 1eb2c984
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[58:59], v[78:79], v[124:131] ; cc46407c 1df29d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[102:103], v[160:167] ; cc4640a0 1e82cd3a
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[170:171], v[96:97], v[36:43] ; cc464024 1c92c1aa
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[58:59], v[108:109], v[172:179] ; cc4640ac 1eb2d93a
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[170:171], v[104:105], v[124:131] ; cc46407c 1df2d1aa
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[170:171], v[110:111], v[160:167] ; cc4640a0 1e82ddaa
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[52:53], v[12:13], 0 ; cc464048 1a021934
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[134:135], v[4:5], v[36:43] ; cc464024 1c920986
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[170:171], v[6:7], v[172:179] ; cc4640ac 1eb20daa
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[134:135], v[10:11], v[124:131] ; cc46407c 1df21586
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[134:135], v[16:17], v[160:167] ; cc4640a0 1e822186
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[12:13], 0 ; cc464010 1a02192c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[134:135], v[26:27], v[172:179] ; cc4640ac 1eb23586
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[120:121], v[4:5], v[72:79] ; cc464048 1d220978
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[122:123], v[4:5], v[80:87] ; cc464050 1d42097a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[142:143], v[4:5], v[64:71] ; cc464040 1d02098e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[140:141], v[4:5], v[16:23] ; cc464010 1c42098c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[60:61], 0 ; cc464058 1a02790c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[62:63], 0 ; cc464068 1a027d0c
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v31, v83, v83 :: v_dual_mul_f32 v26, v65, v65 ; c8c6a753 1f1a8341
	v_dual_mul_f32 v30, v67, v67 :: v_dual_mul_f32 v27, v81, v81 ; c8c68743 1e1aa351
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[4:5], v[180:181], v[88:95] ; cc464058 1d636904
	v_dual_fmac_f32 v31, v75, v75 :: v_dual_fmac_f32 v26, v17, v17 ; c800974b 1f1a2311
	v_dual_fmac_f32 v30, v19, v19 :: v_dual_fmac_f32 v27, v73, v73 ; c8002713 1e1a9349
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[4:5], v[182:183], v[104:111] ; cc464068 1da36d04
	s_mov_b32 s5, 0x76543210                                    ; be8500ff 76543210
	v_dual_fmac_f32 v31, v79, v79 :: v_dual_fmac_f32 v26, v21, v21 ; c8009f4f 1f1a2b15
	v_dual_fmac_f32 v30, v23, v23 :: v_dual_fmac_f32 v27, v77, v77 ; c8002f17 1e1a9b4d
	s_mov_b32 s8, 0xfedcba98                                    ; be8800ff fedcba98
	s_movk_i32 s10, 0x410                                       ; b00a0410
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v31, v87, v87 :: v_dual_fmac_f32 v26, v69, v69 ; c800af57 1f1a8b45
	v_dual_fmac_f32 v30, v71, v71 :: v_dual_fmac_f32 v27, v85, v85 ; c8008f47 1e1aab55
	v_dual_fmac_f32 v31, v74, v74 :: v_dual_fmac_f32 v26, v16, v16 ; c800954a 1f1a2110
	v_dual_fmac_f32 v27, v72, v72 :: v_dual_fmac_f32 v30, v18, v18 ; c8009148 1b1e2512
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v31, v82, v82 :: v_dual_fmac_f32 v26, v64, v64 ; c800a552 1f1a8140
	v_dual_fmac_f32 v27, v80, v80 :: v_dual_fmac_f32 v30, v66, v66 ; c800a150 1b1e8542
	v_dual_fmac_f32 v31, v78, v78 :: v_dual_fmac_f32 v26, v20, v20 ; c8009d4e 1f1a2914
	v_dual_fmac_f32 v27, v76, v76 :: v_dual_fmac_f32 v30, v22, v22 ; c800994c 1b1e2d16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v31, v86, v86 :: v_dual_fmac_f32 v26, v68, v68 ; c800ad56 1f1a8944
	v_dual_fmac_f32 v27, v84, v84 :: v_dual_fmac_f32 v30, v70, v70 ; c800a954 1b1e8d46
	v_fma_mixlo_f16 v32, 1.0, v26, v30                          ; cc210020 047a34f2
	v_fma_mixhi_f16 v32, 1.0, v27, v31                          ; cc220020 047e36f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v33, v32, s5, s8 op_sel:[1,1]             ; d65c1821 00200b20
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[32:33], v[33:34]                ; 1a024320
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v10                               ; 0a001520
	v_cvt_f32_f16_e32 v34, v32                                  ; 7e441720
	v_cvt_f32_f16_e32 v32, v160/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4017a0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(TRANS32_DEP_2) ; bf870332
	v_rsq_f32_e32 v34, v34                                      ; 7e445d22
	v_rsq_f32_e32 v32, v32                                      ; 7e405d20
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_mul_f32_e32 v34, s4, v34                                  ; 10444404
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v75, v75, v32 :: v_dual_mul_f32 v72, v72, v32 ; c8c6414b 4b484148
	v_dual_mul_f32 v77, v77, v32 :: v_dual_mul_f32 v74, v74, v32 ; c8c6414d 4d4a414a
	v_dual_mul_f32 v79, v79, v32 :: v_dual_mul_f32 v76, v76, v32 ; c8c6414f 4f4c414c
	v_dual_mul_f32 v71, v71, v34 :: v_dual_mul_f32 v68, v68, v34 ; c8c64547 47444544
	v_dual_mul_f32 v73, v73, v32 :: v_dual_mul_f32 v22, v22, v34 ; c8c64149 49164516
	v_mul_f32_e32 v17, v17, v34                                 ; 10224511
	v_dual_mul_f32 v69, v69, v34 :: v_dual_mul_f32 v66, v66, v34 ; c8c64545 45424542
	v_dual_mul_f32 v81, v81, v32 :: v_dual_mul_f32 v70, v70, v34 ; c8c64151 51464546
	v_dual_mul_f32 v67, v67, v34 :: v_dual_mul_f32 v64, v64, v34 ; c8c64543 43404540
	v_dual_mul_f32 v21, v21, v34 :: v_dual_mul_f32 v18, v18, v34 ; c8c64515 15124512
	v_dual_mul_f32 v19, v19, v34 :: v_dual_mul_f32 v16, v16, v34 ; c8c64513 13104510
	v_dual_mul_f32 v23, v23, v34 :: v_dual_mul_f32 v20, v20, v34 ; c8c64517 17144514
	v_dual_mul_f32 v65, v65, v34 :: v_dual_mul_f32 v78, v78, v32 ; c8c64541 414e414e
	v_dual_mul_f32 v83, v83, v32 :: v_dual_mul_f32 v80, v80, v32 ; c8c64153 53504150
	v_dual_mul_f32 v85, v85, v32 :: v_dual_mul_f32 v82, v82, v32 ; c8c64155 55524152
	v_dual_mul_f32 v87, v87, v32 :: v_dual_mul_f32 v84, v84, v32 ; c8c64157 57544154
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_dual_mov_b32 v35, v137 :: v_dual_mul_f32 v86, v86, v32    ; ca060189 23564156
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[46:47], v[24:25], 0 ; cc464048 1a02312e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[54:55], v[24:25], 0 ; cc464058 1a023136
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[44:45], v[24:25], 0 ; cc464040 1a02312c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[52:53], v[24:25], 0 ; cc464050 1a023134
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[142:143], v[6:7], v[72:79] ; cc464048 1d220d8e
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[60:61], 0 ; cc464068 1a027918
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[122:123], v[6:7], v[88:95] ; cc464058 1d620d7a
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[24:25], v[62:63], 0 ; cc464084 1a027d18
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[140:141], v[6:7], v[64:71] ; cc464040 1d020d8c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[120:121], v[6:7], v[80:87] ; cc464050 1d420d78
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[6:7], v[180:181], v[104:111] ; cc464068 1da36906
	v_dual_mul_f32 v49, v89, v89 :: v_dual_mul_f32 v50, v75, v75 ; c8c6b359 3132974b
	v_dual_mul_f32 v51, v91, v91 :: v_dual_mul_f32 v48, v73, v73 ; c8c6b75b 33309349
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[6:7], v[182:183], v[132:139] ; cc464084 1e136d06
	v_dual_fmac_f32 v49, v81, v81 :: v_dual_fmac_f32 v50, v67, v67 ; c800a351 31328743
	v_dual_fmac_f32 v51, v83, v83 :: v_dual_fmac_f32 v48, v65, v65 ; c800a753 33308341
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v49, v85, v85 :: v_dual_fmac_f32 v50, v71, v71 ; c800ab55 31328f47
	v_dual_fmac_f32 v51, v87, v87 :: v_dual_fmac_f32 v48, v69, v69 ; c800af57 33308b45
	v_dual_fmac_f32 v50, v79, v79 :: v_dual_fmac_f32 v49, v93, v93 ; c8009f4f 3230bb5d
	v_dual_fmac_f32 v51, v95, v95 :: v_dual_fmac_f32 v48, v77, v77 ; c800bf5f 33309b4d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v49, v80, v80 :: v_dual_fmac_f32 v50, v66, v66 ; c800a150 31328542
	v_dual_fmac_f32 v51, v82, v82 :: v_dual_fmac_f32 v48, v64, v64 ; c800a552 33308140
	v_dual_fmac_f32 v49, v88, v88 :: v_dual_fmac_f32 v50, v74, v74 ; c800b158 3132954a
	v_dual_fmac_f32 v51, v90, v90 :: v_dual_fmac_f32 v48, v72, v72 ; c800b55a 33309148
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v49, v84, v84 :: v_dual_fmac_f32 v50, v70, v70 ; c800a954 31328d46
	v_dual_fmac_f32 v51, v86, v86 :: v_dual_fmac_f32 v48, v68, v68 ; c800ad56 33308944
	v_dual_fmac_f32 v49, v92, v92 :: v_dual_fmac_f32 v50, v78, v78 ; c800b95c 31329d4e
	v_dual_fmac_f32 v51, v94, v94 :: v_dual_fmac_f32 v48, v76, v76 ; c800bd5e 3330994c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v56, 1.0, v48, v50                          ; cc210038 04ca60f2
	v_fma_mixhi_f16 v56, 1.0, v49, v51                          ; cc220038 04ce62f2
	v_permlanex16_b32 v57, v56, s5, s8 op_sel:[1,1]             ; d65c1839 00200b38
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; cc0f0038
	v_min_num_f64_e32 v[1:2], v[56:57], v[57:58]                ; 1a027338
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; cc1c0038
	v_subrev_f32_e32 v0, v56, v10                               ; 0a001538
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v58, v56                                  ; 7e741738
	v_cvt_f32_f16_e32 v56, v184/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7017b8
	v_rsq_f32_e32 v58, v58                                      ; 7e745d3a
	v_rsq_f32_e32 v56, v56                                      ; 7e705d38
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_mul_f32_e32 v58, s4, v58                                  ; 10747404
	v_dual_mul_f32 v82, v82, v56 :: v_dual_mul_f32 v83, v83, v56 ; c8c67152 52527153
	v_dual_mul_f32 v87, v87, v56 :: v_dual_mul_f32 v86, v86, v56 ; c8c67157 57567156
	v_dual_mul_f32 v80, v80, v56 :: v_dual_mul_f32 v81, v81, v56 ; c8c67150 50507151
	v_dual_mul_f32 v85, v85, v56 :: v_dual_mul_f32 v84, v84, v56 ; c8c67155 55547154
	v_dual_mul_f32 v79, v79, v58 :: v_dual_mul_f32 v78, v78, v58 ; c8c6754f 4f4e754e
	v_dual_mul_f32 v77, v77, v58 :: v_dual_mul_f32 v76, v76, v58 ; c8c6754d 4d4c754c
	v_dual_mul_f32 v67, v67, v58 :: v_dual_mul_f32 v66, v66, v58 ; c8c67543 43427542
	v_dual_mul_f32 v89, v89, v56 :: v_dual_mul_f32 v88, v88, v56 ; c8c67159 59587158
	v_dual_mul_f32 v71, v71, v58 :: v_dual_mul_f32 v70, v70, v58 ; c8c67547 47467546
	v_dual_mul_f32 v65, v65, v58 :: v_dual_mul_f32 v64, v64, v58 ; c8c67541 41407540
	v_dual_mul_f32 v73, v73, v58 :: v_dual_mul_f32 v72, v72, v58 ; c8c67549 49487548
	v_dual_mul_f32 v69, v69, v58 :: v_dual_mul_f32 v68, v68, v58 ; c8c67545 45447544
	v_dual_mul_f32 v75, v75, v58 :: v_dual_mul_f32 v74, v74, v58 ; c8c6754b 4b4a754a
	v_dual_mul_f32 v91, v91, v56 :: v_dual_mul_f32 v90, v90, v56 ; c8c6715b 5b5a715a
	v_dual_mul_f32 v93, v93, v56 :: v_dual_mul_f32 v92, v92, v56 ; c8c6715d 5d5c715c
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_mul_f32 v95, v95, v56 :: v_dual_mul_f32 v94, v94, v56 ; c8c6715f 5f5e715e
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[46:47], v[28:29], 0 ; cc464048 1a02392e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[44:45], v[28:29], 0 ; cc464040 1a02392c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[52:53], v[28:29], 0 ; cc464050 1a023934
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[54:55], v[28:29], 0 ; cc464058 1a023936
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[142:143], v[10:11], v[72:79] ; cc464048 1d22158e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[60:61], 0 ; cc464068 1a02791c
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[28:29], v[62:63], 0 ; cc464084 1a027d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[140:141], v[10:11], v[64:71] ; cc464040 1d02158c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[120:121], v[10:11], v[80:87] ; cc464050 1d421578
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[122:123], v[10:11], v[88:95] ; cc464058 1d62157a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[180:181], v[104:111] ; cc464068 1da3690a
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[10:11], v[182:183], v[132:139] ; cc464084 1e136d0a
	v_dual_mul_f32 v100, v91, v91 :: v_dual_mul_f32 v59, v73, v73 ; c8c6b75b 643a9349
	v_dual_mul_f32 v97, v75, v75 :: v_dual_mul_f32 v96, v89, v89 ; c8c6974b 6160b359
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v100, v83, v83 :: v_dual_fmac_f32 v59, v65, v65 ; c800a753 643a8341
	v_dual_fmac_f32 v97, v67, v67 :: v_dual_fmac_f32 v96, v81, v81 ; c8008743 6160a351
	v_dual_fmac_f32 v100, v87, v87 :: v_dual_fmac_f32 v59, v69, v69 ; c800af57 643a8b45
	v_dual_fmac_f32 v97, v71, v71 :: v_dual_fmac_f32 v96, v85, v85 ; c8008f47 6160ab55
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v100, v95, v95 :: v_dual_fmac_f32 v59, v77, v77 ; c800bf5f 643a9b4d
	v_dual_fmac_f32 v97, v79, v79 :: v_dual_fmac_f32 v96, v93, v93 ; c8009f4f 6160bb5d
	v_dual_fmac_f32 v100, v82, v82 :: v_dual_fmac_f32 v59, v64, v64 ; c800a552 643a8140
	v_dual_fmac_f32 v96, v80, v80 :: v_dual_fmac_f32 v97, v66, v66 ; c800a150 60608542
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v100, v90, v90 :: v_dual_fmac_f32 v59, v72, v72 ; c800b55a 643a9148
	v_dual_fmac_f32 v96, v88, v88 :: v_dual_fmac_f32 v97, v74, v74 ; c800b158 6060954a
	v_dual_fmac_f32 v100, v86, v86 :: v_dual_fmac_f32 v59, v68, v68 ; c800ad56 643a8944
	v_dual_fmac_f32 v96, v84, v84 :: v_dual_fmac_f32 v97, v70, v70 ; c800a954 60608d46
	v_lshl_add_u32 v2, v2, 6, s7                                ; d6460002 001d0d02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
	v_dual_fmac_f32 v100, v94, v94 :: v_dual_fmac_f32 v59, v76, v76 ; c800bd5e 643a994c
	v_dual_fmac_f32 v96, v92, v92 :: v_dual_fmac_f32 v97, v78, v78 ; c800b95c 60609d4e
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
	v_fma_mixlo_f16 v101, 1.0, v59, v97                         ; cc210065 058676f2
	v_fma_mixhi_f16 v101, 1.0, v96, v100                        ; cc220065 0592c0f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v102, v101, s5, s8 op_sel:[1,1]           ; d65c1866 00200b65
(invalid instruction)                                        ; cc0f0065
	v_min_num_f64_e32 v[1:2], v[101:102], v[102:103]            ; 1a02cd65
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v10                              ; 0a001565
	v_cvt_f32_f16_e32 v103, v101                                ; 7ece1765
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v103, v103                                    ; 7ece5d67
	v_mul_f32_e32 v103, s4, v103                                ; 10cece04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v64, v64, v103 :: v_dual_mul_f32 v65, v65, v103 ; c8c6cf40 4040cf41
	v_dual_mul_f32 v66, v66, v103 :: v_dual_mul_f32 v67, v67, v103 ; c8c6cf42 4242cf43
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v2, s[20:23], null offen         ; c405c07c 40802838 00000002
	buffer_load_b128 v[64:67], v2, s[20:23], null offen offset:16 ; c405c07c 40802840 00001002
	v_cvt_f32_f16_e32 v101, v229/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eca17e5
	v_dual_mul_f32 v71, v71, v103 :: v_dual_mul_f32 v70, v70, v103 ; c8c6cf47 4746cf46
	v_dual_mul_f32 v68, v68, v103 :: v_dual_mul_f32 v69, v69, v103 ; c8c6cf44 4444cf45
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	buffer_load_b128 v[68:71], v2, s[20:23], null offen offset:4096 ; c405c07c 40802844 00100002
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_mul_f32 v73, v73, v103 :: v_dual_mul_f32 v72, v72, v103 ; c8c6cf49 4948cf48
	v_rsq_f32_e32 v101, v101                                    ; 7eca5d65
	v_dual_mul_f32 v75, v75, v103 :: v_dual_mul_f32 v74, v74, v103 ; c8c6cf4b 4b4acf4a
	v_dual_mul_f32 v77, v77, v103 :: v_dual_mul_f32 v76, v76, v103 ; c8c6cf4d 4d4ccf4c
	v_dual_mul_f32 v79, v79, v103 :: v_dual_mul_f32 v78, v78, v103 ; c8c6cf4f 4f4ecf4e
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	v_dual_mov_b32 v9, v164 :: v_dual_mov_b32 v34, v165         ; ca1001a4 092201a5
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_dual_mul_f32 v87, v87, v101 :: v_dual_mul_f32 v86, v86, v101 ; c8c6cb57 5756cb56
	v_dual_mul_f32 v93, v93, v101 :: v_dual_mul_f32 v92, v92, v101 ; c8c6cb5d 5d5ccb5c
	v_dual_mul_f32 v89, v89, v101 :: v_dual_mul_f32 v88, v88, v101 ; c8c6cb59 5958cb58
	v_dual_mul_f32 v95, v95, v101 :: v_dual_mul_f32 v94, v94, v101 ; c8c6cb5f 5f5ecb5e
	v_dual_mul_f32 v91, v91, v101 :: v_dual_mul_f32 v90, v90, v101 ; c8c6cb5b 5b5acb5a
	v_dual_mul_f32 v83, v83, v101 :: v_dual_mul_f32 v82, v82, v101 ; c8c6cb53 5352cb52
	v_dual_mul_f32 v85, v85, v101 :: v_dual_mul_f32 v84, v84, v101 ; c8c6cb55 5554cb54
	v_dual_mul_f32 v81, v81, v101 :: v_dual_mul_f32 v80, v80, v101 ; c8c6cb51 5150cb50
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[98:99], 0 ; cc464068 1a02c534
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[54:55], v[98:99], 0 ; cc464084 1a02c536
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[46:47], v[98:99], 0 ; cc464058 1a02c52e
	v_dual_mov_b32 v47, v167 :: v_dual_mov_b32 v46, v166        ; ca1001a7 2f2e01a6
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[98:99], 0 ; cc464050 1a02c52c
	v_dual_mov_b32 v45, v99 :: v_dual_mov_b32 v44, v98          ; ca100163 2d2c0162
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[120:121], v[14:15], v[104:111] ; cc464068 1da21d78
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[122:123], v[14:15], v[132:139] ; cc464084 1e121d7a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[142:143], v[14:15], v[88:95] ; cc464058 1d621d8e
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[44:45], v[62:63], 0 ; cc4640a4 1a027d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[60:61], 0 ; cc464060 1a02792c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[140:141], v[14:15], v[80:87] ; cc464050 1d421d8c
	v_dual_mul_f32 v54, v91, v91 :: v_dual_mul_f32 v53, v133, v133 ; c8c6b75b 36350b85
	v_dual_mul_f32 v55, v135, v135 :: v_dual_mul_f32 v52, v89, v89 ; c8c70f87 3734b359
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[14:15], v[182:183], v[164:171] ; cc4640a4 1e936d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[14:15], v[180:181], v[96:103] ; cc464060 1d83690e
	v_dual_fmac_f32 v55, v107, v107 :: v_dual_fmac_f32 v52, v81, v81 ; c800d76b 3734a351
	v_dual_fmac_f32 v54, v83, v83 :: v_dual_fmac_f32 v53, v105, v105 ; c800a753 3634d369
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v55, v111, v111 :: v_dual_fmac_f32 v52, v85, v85 ; c800df6f 3734ab55
	v_dual_fmac_f32 v54, v87, v87 :: v_dual_fmac_f32 v53, v109, v109 ; c800af57 3634db6d
	v_dual_fmac_f32 v55, v139, v139 :: v_dual_fmac_f32 v52, v93, v93 ; c801178b 3734bb5d
	v_dual_fmac_f32 v54, v95, v95 :: v_dual_fmac_f32 v53, v137, v137 ; c800bf5f 36351389
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v55, v106, v106 :: v_dual_fmac_f32 v52, v80, v80 ; c800d56a 3734a150
	v_dual_fmac_f32 v53, v104, v104 :: v_dual_fmac_f32 v54, v82, v82 ; c800d168 3536a552
	v_dual_fmac_f32 v55, v134, v134 :: v_dual_fmac_f32 v52, v88, v88 ; c8010d86 3734b158
	v_dual_fmac_f32 v53, v132, v132 :: v_dual_fmac_f32 v54, v90, v90 ; c8010984 3536b55a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v55, v110, v110 :: v_dual_fmac_f32 v52, v84, v84 ; c800dd6e 3734a954
	v_dual_fmac_f32 v53, v108, v108 :: v_dual_fmac_f32 v54, v86, v86 ; c800d96c 3536ad56
	v_dual_fmac_f32 v55, v138, v138 :: v_dual_fmac_f32 v52, v92, v92 ; c801158a 3734b95c
	v_dual_fmac_f32 v53, v136, v136 :: v_dual_fmac_f32 v54, v94, v94 ; c8011188 3536bd5e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v60, 1.0, v52, v54                          ; cc21003c 04da68f2
	v_fma_mixhi_f16 v60, 1.0, v53, v55                          ; cc22003c 04de6af2
	v_permlanex16_b32 v61, v60, s5, s8 op_sel:[1,1]             ; d65c183d 00200b3c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c1
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[60:61], v[61:62]                ; 1a027b3c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_mov_b32_e32 v15, v46                                      ; 7e1e032e
	v_mov_b32_e32 v61, v47                                      ; 7e7a032f
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v10                               ; 0a00153c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v62, v60                                  ; 7e7c173c
	v_rsq_f32_e32 v62, v62                                      ; 7e7c5d3e
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v62, s4, v62                                  ; 107c7c04
	v_dual_mul_f32 v83, v83, v62 :: v_dual_mul_f32 v82, v82, v62 ; c8c67d53 53527d52
	v_dual_mul_f32 v81, v81, v62 :: v_dual_mul_f32 v80, v80, v62 ; c8c67d51 51507d50
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[52:55], v2, s[20:23], null offen offset:4112 ; c405c07c 40802834 00101002
	buffer_load_b128 v[80:83], v2, s[20:23], null offen offset:8192 ; c405c07c 40802850 00200002
	buffer_load_b128 v[120:123], v2, s[20:23], null offen offset:8208 ; c405c07c 40802878 00201002
	buffer_load_b128 v[140:143], v2, s[20:23], null offen offset:12288 ; c405c07c 4080288c 00300002
	buffer_load_b128 v[180:183], v2, s[20:23], null offen offset:12304 ; c405c07c 408028b4 00301002
	buffer_load_b128 v[44:47], v2, s[20:23], null offen offset:64 ; c405c07c 4080282c 00004002
	v_cvt_f32_f16_e32 v60, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7817bc
	v_dual_mul_f32 v86, v86, v62 :: v_dual_mul_f32 v85, v85, v62 ; c8c67d56 56547d55
	v_mul_f32_e32 v84, v84, v62                                 ; 10a87d54
	v_dual_mul_f32 v89, v89, v62 :: v_dual_mul_f32 v88, v88, v62 ; c8c67d59 59587d58
	v_dual_mul_f32 v91, v91, v62 :: v_dual_mul_f32 v90, v90, v62 ; c8c67d5b 5b5a7d5a
	v_dual_mul_f32 v93, v93, v62 :: v_dual_mul_f32 v92, v92, v62 ; c8c67d5d 5d5c7d5c
	v_dual_mov_b32 v78, v14 :: v_dual_mul_f32 v87, v87, v62     ; ca06010e 4e567d57
	v_dual_mul_f32 v95, v95, v62 :: v_dual_mul_f32 v94, v94, v62 ; c8c67d5f 5f5e7d5e
	v_rsq_f32_e32 v60, v60                                      ; 7e785d3c
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_dual_mul_f32 v104, v104, v60 :: v_dual_mul_f32 v105, v105, v60 ; c8c67968 68687969
	v_dual_mul_f32 v137, v137, v60 :: v_dual_mul_f32 v136, v136, v60 ; c8c67989 89887988
	v_dual_mul_f32 v106, v106, v60 :: v_dual_mul_f32 v107, v107, v60 ; c8c6796a 6a6a796b
	v_dual_mul_f32 v133, v133, v60 :: v_dual_mul_f32 v132, v132, v60 ; c8c67985 85847984
	v_dual_mul_f32 v139, v139, v60 :: v_dual_mul_f32 v138, v138, v60 ; c8c6798b 8b8a798a
	v_dual_mul_f32 v135, v135, v60 :: v_dual_mul_f32 v134, v134, v60 ; c8c67987 87867986
	v_dual_mul_f32 v108, v108, v60 :: v_dual_mul_f32 v109, v109, v60 ; c8c6796c 6c6c796d
	v_dual_mul_f32 v110, v110, v60 :: v_dual_mul_f32 v111, v111, v60 ; c8c6796e 6e6e796f
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[4:5], 0  ; cc464060 1a02090c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[6:7], 0 ; cc464068 1a020d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[12:13], v[10:11], 0 ; cc464084 1a02150c
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[12:13], v[78:79], 0 ; cc4640a4 1a029d0c
	s_mov_b32 s11, 0x3d380000                                   ; be8b00ff 3d380000
	s_movk_i32 s13, 0x3e47                                      ; b00d3e47
	s_movk_i32 s24, 0x3c20                                      ; b0183c20
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[18:19], v[96:103] ; cc464060 1d822514
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[20:21], v[30:31], v[104:111] ; cc464068 1da23d14
	v_wmma_f32_16x16x16_fp8_fp8 v[132:139], v[20:21], v[72:73], v[132:139] ; cc464084 1e129114
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[20:21], v[88:89], v[164:171] ; cc4640a4 1e92b114
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_mixlo_f16 v92, s11, v96, v56                          ; cc21005c 04e2c00b
	v_fma_mixhi_f16 v92, s11, v97, v57                          ; cc22005c 04e6c20b
	v_fma_mixlo_f16 v93, s11, v98, v58                          ; cc21005d 04eac40b
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v96, s11, v104, v68                         ; cc210060 0512d00b
	v_fma_mixhi_f16 v96, s11, v105, v69                         ; cc220060 0516d20b
	v_fma_mixhi_f16 v93, s11, v99, v59                          ; cc22005d 04eec60b
	v_fma_mixlo_f16 v94, s11, v100, v64                         ; cc21005e 0502c80b
	v_fma_mixhi_f16 v94, s11, v101, v65                         ; cc22005e 0506ca0b
(invalid instruction)                                        ; cc1c005c
	v_subrev_f32_e32 v0, v92, v24                               ; 0a00315c
	v_fma_mixlo_f16 v95, s11, v102, v66                         ; cc21005f 050acc0b
	v_fma_mixhi_f16 v95, s11, v103, v67                         ; cc22005f 050ece0b
(invalid instruction)                                        ; cc1c0060
	v_subrev_f32_e32 v0, v96, v24                               ; 0a003160
(invalid instruction)                                        ; cc1c005d
	v_subrev_f32_e32 v0, v93, v24                               ; 0a00315d
	v_fma_mixlo_f16 v97, s11, v106, v70                         ; cc210061 051ad40b
	v_fma_mixhi_f16 v97, s11, v107, v71                         ; cc220061 051ed60b
(invalid instruction)                                        ; cc1c005e
	v_subrev_f32_e32 v0, v94, v24                               ; 0a00315e
(invalid instruction)                                        ; cc1b005c
	v_subrev_f32_e32 v0, v92, v13                               ; 0a001b5c
(invalid instruction)                                        ; cc1c005f
	v_subrev_f32_e32 v0, v95, v24                               ; 0a00315f
(invalid instruction)                                        ; cc1b0060
	v_subrev_f32_e32 v0, v96, v13                               ; 0a001b60
(invalid instruction)                                        ; cc1b005d
	v_subrev_f32_e32 v0, v93, v13                               ; 0a001b5d
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[4:5], 0   ; cc464040 1a020918
(invalid instruction)                                        ; cc1c0061
	v_subrev_f32_e32 v0, v97, v24                               ; 0a003161
(invalid instruction)                                        ; cc1b005e
	v_subrev_f32_e32 v0, v94, v13                               ; 0a001b5e
(invalid instruction)                                        ; cc1b005f
	v_subrev_f32_e32 v0, v95, v13                               ; 0a001b5f
	v_mov_b32_e32 v12, v96                                      ; 7e180360
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b0061
	v_subrev_f32_e32 v0, v97, v13                               ; 0a001b61
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[32:33], v[18:19], v[64:71] ; cc464040 1d022520
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v98, s11, v108, v52                         ; cc210062 04d2d80b
	v_fma_mixhi_f16 v98, s11, v109, v53                         ; cc220062 04d6da0b
	v_fma_mixlo_f16 v99, s11, v110, v54                         ; cc210063 04dadc0b
	v_fma_mixhi_f16 v99, s11, v111, v55                         ; cc220063 04dede0b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[6:7], 0 ; cc464068 1a020d18
	v_wmma_f32_16x16x16_fp8_fp8 v[52:59], v[24:25], v[10:11], 0 ; cc464034 1a021518
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v21, s11, v132, v80                         ; cc210015 0543080b
	v_fma_mixhi_f16 v21, s11, v133, v81                         ; cc220015 05470a0b
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v24                               ; 0a003162
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v24                               ; 0a003163
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[32:33], v[30:31], v[104:111] ; cc464068 1da23d20
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v24                               ; 0a003115
(invalid instruction)                                        ; cc1b0062
	v_subrev_f32_e32 v0, v98, v13                               ; 0a001b62
(invalid instruction)                                        ; cc1b0063
	v_subrev_f32_e32 v0, v99, v13                               ; 0a001b63
	v_wmma_f32_16x16x16_fp8_fp8 v[52:59], v[32:33], v[72:73], v[52:59] ; cc464034 1cd29120
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v13                               ; 0a001b15
	v_mov_b32_e32 v14, v98                                      ; 7e1c0362
	v_dual_mov_b32 v20, v99 :: v_dual_mov_b32 v13, v97          ; ca100163 140c0161
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[78:79], 0 ; cc464060 1a029d18
	v_fma_mixlo_f16 v24, s11, v134, v82                         ; cc210018 054b0c0b
	v_fma_mixhi_f16 v24, s11, v135, v83                         ; cc220018 054f0e0b
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v25, s11, v136, v120                        ; cc210019 05e3100b
	v_fma_mixhi_f16 v25, s11, v137, v121                        ; cc220019 05e7120b
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v60, s11, v166, v142                        ; cc21003c 063b4c0b
	v_fma_mixhi_f16 v60, s11, v167, v143                        ; cc22003c 063f4e0b
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v80, s11, v168, v180                        ; cc210050 06d3500b
(invalid instruction)                                        ; cc1c0018
	v_subrev_f32_e32 v0, v24, v24                               ; 0a003118
	v_fma_mixhi_f16 v80, s11, v169, v181                        ; cc220050 06d7520b
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v24                               ; 0a003119
	v_fma_mixlo_f16 v81, s11, v170, v182                        ; cc210051 06db540b
	v_fma_mixhi_f16 v81, s11, v171, v183                        ; cc220051 06df560b
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v24                               ; 0a00313c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[88:89], v[96:103] ; cc464060 1d82b120
	v_fma_mixlo_f16 v32, s11, v138, v122                        ; cc210020 05eb140b
	v_fma_mixhi_f16 v32, s11, v139, v123                        ; cc220020 05ef160b
	v_fma_mixlo_f16 v33, s11, v164, v140                        ; cc210021 0633480b
	v_fma_mixhi_f16 v33, s11, v165, v141                        ; cc220021 06374a0b
(invalid instruction)                                        ; cc1b0018
	v_subrev_f32_e32 v0, v24, v13                               ; 0a001b18
	s_clause 0x6                                                ; bf850006
	buffer_load_b128 v[120:123], v2, s[20:23], null offen offset:80 ; c405c07c 40802878 00005002
	buffer_load_b128 v[132:135], v2, s[20:23], null offen offset:4160 ; c405c07c 40802884 00104002
	buffer_load_b128 v[136:139], v2, s[20:23], null offen offset:4176 ; c405c07c 40802888 00105002
	buffer_load_b128 v[140:143], v2, s[20:23], null offen offset:8256 ; c405c07c 4080288c 00204002
	buffer_load_b128 v[164:167], v2, s[20:23], null offen offset:8272 ; c405c07c 408028a4 00205002
	buffer_load_b128 v[168:171], v2, s[20:23], null offen offset:12352 ; c405c07c 408028a8 00304002
	buffer_load_b128 v[180:183], v2, s[20:23], null offen offset:12368 ; c405c07c 408028b4 00305002
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v24                               ; 0a003150
(invalid instruction)                                        ; cc1b0019
	v_subrev_f32_e32 v0, v25, v13                               ; 0a001b19
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v13                               ; 0a001b3c
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v24                               ; 0a003120
(invalid instruction)                                        ; cc1c0021
	v_subrev_f32_e32 v0, v33, v24                               ; 0a003121
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v24                               ; 0a003151
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v82, s11, v64, v44                          ; cc210052 04b2800b
	v_fma_mixhi_f16 v82, s11, v65, v45                          ; cc220052 04b6820b
(invalid instruction)                                        ; cc1b0050
	v_subrev_f32_e32 v0, v80, v13                               ; 0a001b50
	v_fma_mixlo_f16 v83, s11, v66, v46                          ; cc210053 04ba840b
(invalid instruction)                                        ; cc1b0020
	v_subrev_f32_e32 v0, v32, v13                               ; 0a001b20
	v_fma_mixhi_f16 v83, s11, v67, v47                          ; cc220053 04be860b
(invalid instruction)                                        ; cc1b0021
	v_subrev_f32_e32 v0, v33, v13                               ; 0a001b21
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v13                               ; 0a001b51
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v24                               ; 0a003152
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v24                               ; 0a003153
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v13                               ; 0a001b52
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; cc1b0053
	v_subrev_f32_e32 v0, v83, v13                               ; 0a001b53
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v120, s11, v68, v120                        ; cc210078 05e2880b
	v_fma_mixhi_f16 v120, s11, v69, v121                        ; cc220078 05e68a0b
	v_fma_mixlo_f16 v121, s11, v70, v122                        ; cc210079 05ea8c0b
	v_fma_mixhi_f16 v121, s11, v71, v123                        ; cc220079 05ee8e0b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v122, s11, v104, v132                       ; cc21007a 0612d00b
	v_mov_b32_e32 v132, v40                                     ; 7f080328
	v_fma_mixhi_f16 v122, s11, v105, v133                       ; cc22007a 0616d20b
	v_fma_mixlo_f16 v123, s11, v106, v134                       ; cc21007b 061ad40b
	v_dual_mov_b32 v134, v42 :: v_dual_mov_b32 v133, v41        ; ca10012a 86840129
	v_fma_mixhi_f16 v123, s11, v107, v135                       ; cc22007b 061ed60b
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v136, s11, v108, v136                       ; cc210088 0622d80b
	v_fma_mixhi_f16 v136, s11, v109, v137                       ; cc220088 0626da0b
	v_fma_mixlo_f16 v137, s11, v110, v138                       ; cc210089 062adc0b
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v138, s11, v52, v140                        ; cc21008a 0632680b
	v_dual_mov_b32 v140, v55 :: v_dual_mov_b32 v135, v43        ; ca100137 8c86012b
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[28:29], v[4:5], 0   ; cc464040 1a02091c
(invalid instruction)                                        ; cc1c0078
	v_subrev_f32_e32 v0, v120, v24                              ; 0a003178
(invalid instruction)                                        ; cc1c0079
	v_subrev_f32_e32 v0, v121, v24                              ; 0a003179
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[28:29], v[6:7], 0   ; cc464028 1a020d1c
	v_fma_mixhi_f16 v137, s11, v111, v139                       ; cc220089 062ede0b
(invalid instruction)                                        ; cc1c007a
	v_subrev_f32_e32 v0, v122, v24                              ; 0a00317a
	v_fma_mixhi_f16 v138, s11, v53, v141                        ; cc22008a 06366a0b
	v_fma_mixlo_f16 v139, s11, v54, v142                        ; cc21008b 063a6c0b
	buffer_load_b128 v[52:55], v2, s[20:23], null offen offset:128 ; c405c07c 40802834 00008002
(invalid instruction)                                        ; cc1c007b
	v_subrev_f32_e32 v0, v123, v24                              ; 0a00317b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[10:11], 0 ; cc464068 1a02151c
(invalid instruction)                                        ; cc1c0088
	v_subrev_f32_e32 v0, v136, v24                              ; 0a003188
(invalid instruction)                                        ; cc1b0078
	v_subrev_f32_e32 v0, v120, v13                              ; 0a001b78
(invalid instruction)                                        ; cc1b0079
	v_subrev_f32_e32 v0, v121, v13                              ; 0a001b79
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v141, s11, v56, v164                        ; cc21008d 0692700b
	v_fma_mixhi_f16 v141, s11, v57, v165                        ; cc22008d 0696720b
	v_dual_mov_b32 v57, v162 :: v_dual_mov_b32 v56, v161        ; ca1001a2 393801a1
	v_fma_mixhi_f16 v139, s11, v140, v143                       ; cc22008b 063f180b
	v_fma_mixlo_f16 v142, s11, v58, v166                        ; cc21008e 069a740b
(invalid instruction)                                        ; cc1c0089
	v_subrev_f32_e32 v0, v137, v24                              ; 0a003189
(invalid instruction)                                        ; cc1b007a
	v_subrev_f32_e32 v0, v122, v13                              ; 0a001b7a
(invalid instruction)                                        ; cc1c008a
	v_subrev_f32_e32 v0, v138, v24                              ; 0a00318a
(invalid instruction)                                        ; cc1b007b
	v_subrev_f32_e32 v0, v123, v13                              ; 0a001b7b
	v_dual_mov_b32 v143, v160 :: v_dual_mov_b32 v58, v163       ; ca1001a0 8f3a01a3
	v_fma_mixhi_f16 v142, s11, v59, v167                        ; cc22008e 069e760b
(invalid instruction)                                        ; cc1b0088
	v_subrev_f32_e32 v0, v136, v13                              ; 0a001b88
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[28:29], v[78:79], 0 ; cc4640a0 1a029d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[74:75], v[18:19], v[64:71] ; cc464040 1d02254a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[74:75], v[30:31], v[40:47] ; cc464028 1ca23d4a
(invalid instruction)                                        ; cc1c008d
	v_subrev_f32_e32 v0, v141, v24                              ; 0a00318d
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[74:75], v[72:73], v[104:111] ; cc464068 1da2914a
(invalid instruction)                                        ; cc1c008b
	v_subrev_f32_e32 v0, v139, v24                              ; 0a00318b
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v59, s11, v96, v168                         ; cc21003b 06a2c00b
	v_fma_mixhi_f16 v59, s11, v97, v169                         ; cc22003b 06a6c20b
(invalid instruction)                                        ; cc1b0089
	v_subrev_f32_e32 v0, v137, v13                              ; 0a001b89
(invalid instruction)                                        ; cc1b008a
	v_subrev_f32_e32 v0, v138, v13                              ; 0a001b8a
(invalid instruction)                                        ; cc1c008e
	v_subrev_f32_e32 v0, v142, v24                              ; 0a00318e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[74:75], v[88:89], v[160:167] ; cc4640a0 1e82b14a
	v_fma_mixlo_f16 v74, s11, v98, v170                         ; cc21004a 06aac40b
	v_fma_mixhi_f16 v74, s11, v99, v171                         ; cc22004a 06aec60b
(invalid instruction)                                        ; cc1b008d
	v_subrev_f32_e32 v0, v141, v13                              ; 0a001b8d
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v75, s11, v100, v180                        ; cc21004b 06d2c80b
	v_fma_mixhi_f16 v75, s11, v101, v181                        ; cc22004b 06d6ca0b
	v_fma_mixlo_f16 v96, s11, v102, v182                        ; cc210060 06dacc0b
	v_fma_mixhi_f16 v96, s11, v103, v183                        ; cc220060 06dece0b
(invalid instruction)                                        ; cc1b008b
	v_subrev_f32_e32 v0, v139, v13                              ; 0a001b8b
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v24                               ; 0a00313b
(invalid instruction)                                        ; cc1b008e
	v_subrev_f32_e32 v0, v142, v13                              ; 0a001b8e
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[100:103], v2, s[20:23], null offen offset:144 ; c405c07c 40802864 00009002
	buffer_load_b128 v[168:171], v2, s[20:23], null offen offset:4224 ; c405c07c 408028a8 00108002
	buffer_load_b128 v[180:183], v2, s[20:23], null offen offset:4240 ; c405c07c 408028b4 00109002
(invalid instruction)                                        ; cc1c004a
	v_subrev_f32_e32 v0, v74, v24                               ; 0a00314a
	v_mov_b32_e32 v29, v67                                      ; 7e3a0343
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v97, s11, v64, v52                          ; cc210061 04d2800b
	v_fma_mixlo_f16 v98, s11, v66, v54                          ; cc210062 04da840b
	v_mov_b32_e32 v28, v55                                      ; 7e380337
	v_fma_mixhi_f16 v97, s11, v65, v53                          ; cc220061 04d6820b
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[52:55], v2, s[20:23], null offen offset:8320 ; c405c07c 40802834 00208002
	buffer_load_b128 v[64:67], v2, s[20:23], null offen offset:8336 ; c405c07c 40802840 00209002
(invalid instruction)                                        ; cc1c004b
	v_subrev_f32_e32 v0, v75, v24                               ; 0a00314b
(invalid instruction)                                        ; cc1c0060
	v_subrev_f32_e32 v0, v96, v24                               ; 0a003160
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v13                               ; 0a001b3b
(invalid instruction)                                        ; cc1b004a
	v_subrev_f32_e32 v0, v74, v13                               ; 0a001b4a
	v_fma_mixhi_f16 v98, s11, v29, v28                          ; cc220062 04723a0b
(invalid instruction)                                        ; cc1c0061
	v_subrev_f32_e32 v0, v97, v24                               ; 0a003161
(invalid instruction)                                        ; cc1b004b
	v_subrev_f32_e32 v0, v75, v13                               ; 0a001b4b
(invalid instruction)                                        ; cc1b0060
	v_subrev_f32_e32 v0, v96, v13                               ; 0a001b60
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v24                               ; 0a003162
(invalid instruction)                                        ; cc1b0061
	v_subrev_f32_e32 v0, v97, v13                               ; 0a001b61
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v68, s11, v68, v100                         ; cc210044 0592880b
	v_mov_b32_e32 v28, v43                                      ; 7e38032b
	v_fma_mixhi_f16 v68, s11, v69, v101                         ; cc220044 05968a0b
(invalid instruction)                                        ; cc1b0062
	v_subrev_f32_e32 v0, v98, v13                               ; 0a001b62
	v_fma_mixlo_f16 v69, s11, v70, v102                         ; cc210045 059a8c0b
	v_fma_mixhi_f16 v69, s11, v71, v103                         ; cc220045 059e8e0b
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v70, s11, v40, v168                         ; cc210046 06a2500b
	v_fma_mixhi_f16 v70, s11, v41, v169                         ; cc220046 06a6520b
	v_fma_mixlo_f16 v71, s11, v42, v170                         ; cc210047 06aa540b
	v_mov_b32_e32 v29, v171                                     ; 7e3a03ab
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[100:103], v2, s[20:23], null offen offset:12416 ; c405c07c 40802864 00308002
	buffer_load_b128 v[40:43], v2, s[20:23], null offen offset:12432 ; c405c07c 40802828 00309002
	buffer_load_b128 v[168:171], v2, s[20:23], null offen offset:192 ; c405c07c 408028a8 0000c002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v44, s11, v44, v180                         ; cc21002c 06d2580b
	v_fma_mixhi_f16 v44, s11, v45, v181                         ; cc22002c 06d65a0b
	v_fma_mixlo_f16 v45, s11, v46, v182                         ; cc21002d 06da5c0b
	v_fma_mixhi_f16 v45, s11, v47, v183                         ; cc22002d 06de5e0b
	v_dual_mov_b32 v47, v177 :: v_dual_mov_b32 v46, v176        ; ca1001b1 2f2e01b0
(invalid instruction)                                        ; cc1c0044
	v_subrev_f32_e32 v0, v68, v24                               ; 0a003144
	v_dual_mov_b32 v140, v179 :: v_dual_mov_b32 v99, v178       ; ca1001b3 8c6201b2
(invalid instruction)                                        ; cc1c0045
	v_subrev_f32_e32 v0, v69, v24                               ; 0a003145
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[84:85], v[4:5], 0 ; cc4640b0 1a020954
(invalid instruction)                                        ; cc1c0046
	v_subrev_f32_e32 v0, v70, v24                               ; 0a003146
	v_fma_mixhi_f16 v71, s11, v28, v29                          ; cc220047 0476380b
	v_dual_mov_b32 v29, v57 :: v_dual_mov_b32 v28, v56          ; ca100139 1d1c0138
(invalid instruction)                                        ; cc1c002c
	v_subrev_f32_e32 v0, v44, v24                               ; 0a00312c
(invalid instruction)                                        ; cc1c002d
	v_subrev_f32_e32 v0, v45, v24                               ; 0a00312d
(invalid instruction)                                        ; cc1b0044
	v_subrev_f32_e32 v0, v68, v13                               ; 0a001b44
(invalid instruction)                                        ; cc1b0045
	v_subrev_f32_e32 v0, v69, v13                               ; 0a001b45
(invalid instruction)                                        ; cc1b0046
	v_subrev_f32_e32 v0, v70, v13                               ; 0a001b46
(invalid instruction)                                        ; cc1c0047
	v_subrev_f32_e32 v0, v71, v24                               ; 0a003147
(invalid instruction)                                        ; cc1b002c
	v_subrev_f32_e32 v0, v44, v13                               ; 0a001b2c
(invalid instruction)                                        ; cc1b002d
	v_subrev_f32_e32 v0, v45, v13                               ; 0a001b2d
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; cc1b0047
	v_subrev_f32_e32 v0, v71, v13                               ; 0a001b47
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v5, s11, v106, v54                          ; cc210005 04dad40b
	v_fma_mixlo_f16 v4, s11, v104, v52                          ; cc210004 04d2d00b
	v_fma_mixhi_f16 v4, s11, v105, v53                          ; cc220004 04d6d20b
	v_dual_mov_b32 v105, v59 :: v_dual_mov_b32 v104, v58        ; ca10013b 6968013a
	v_fma_mixhi_f16 v5, s11, v107, v55                          ; cc220005 04ded60b
	v_wmma_f32_16x16x16_fp8_fp8 v[52:59], v[84:85], v[6:7], 0   ; cc464034 1a020d54
	v_dual_mov_b32 v7, v69 :: v_dual_mov_b32 v6, v68            ; ca100145 07060144
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v106, s11, v108, v64                        ; cc21006a 0502d80b
	v_fma_mixlo_f16 v107, s11, v110, v66                        ; cc21006b 050adc0b
	v_fma_mixhi_f16 v107, s11, v111, v67                        ; cc22006b 050ede0b
	v_fma_mixhi_f16 v106, s11, v109, v65                        ; cc22006a 0506da0b
	v_dual_mov_b32 v109, v71 :: v_dual_mov_b32 v108, v70        ; ca100147 6d6c0146
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[84:85], v[10:11], 0 ; cc464040 1a021554
	v_dual_mov_b32 v11, v97 :: v_dual_mov_b32 v10, v96          ; ca100161 0b0a0160
(invalid instruction)                                        ; cc1c0004
	v_subrev_f32_e32 v0, v4, v24                                ; 0a003104
(invalid instruction)                                        ; cc1c0005
	v_subrev_f32_e32 v0, v5, v24                                ; 0a003105
(invalid instruction)                                        ; cc1c006b
	v_subrev_f32_e32 v0, v107, v24                              ; 0a00316b
(invalid instruction)                                        ; cc1c006a
	v_subrev_f32_e32 v0, v106, v24                              ; 0a00316a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[18:19], v[176:183] ; cc4640b0 1ec2253e
	v_wmma_f32_16x16x16_fp8_fp8 v[52:59], v[62:63], v[30:31], v[52:59] ; cc464034 1cd23d3e
(invalid instruction)                                        ; cc1b0004
	v_subrev_f32_e32 v0, v4, v13                                ; 0a001b04
(invalid instruction)                                        ; cc1b0005
	v_subrev_f32_e32 v0, v5, v13                                ; 0a001b05
(invalid instruction)                                        ; cc1b006b
	v_subrev_f32_e32 v0, v107, v13                              ; 0a001b6b
(invalid instruction)                                        ; cc1b006a
	v_subrev_f32_e32 v0, v106, v13                              ; 0a001b6a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[62:63], v[72:73], v[64:71] ; cc464040 1d02913e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v110, s11, v160, v100                       ; cc21006e 0593400b
	v_fma_mixhi_f16 v110, s11, v161, v101                       ; cc22006e 0597420b
	v_dual_mov_b32 v161, v99 :: v_dual_mov_b32 v160, v98        ; ca100163 a1a00162
	v_fma_mixlo_f16 v111, s11, v162, v102                       ; cc21006f 059b440b
	v_fma_mixhi_f16 v111, s11, v163, v103                       ; cc22006f 059f460b
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[84:85], v[78:79], 0 ; cc464060 1a029d54
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v162, s11, v164, v40                        ; cc2100a2 04a3480b
	v_fma_mixlo_f16 v163, s11, v166, v42                        ; cc2100a3 04ab4c0b
	v_fma_mixhi_f16 v163, s11, v167, v43                        ; cc2200a3 04af4e0b
	v_fma_mixhi_f16 v162, s11, v165, v41                        ; cc2200a2 04a74a0b
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v164, s11, v176, v168                       ; cc2100a4 06a3600b
	v_fma_mixhi_f16 v164, s11, v177, v169                       ; cc2200a4 06a7620b
(invalid instruction)                                        ; cc1c006e
	v_subrev_f32_e32 v0, v110, v24                              ; 0a00316e
	v_fma_mixlo_f16 v165, s11, v178, v170                       ; cc2100a5 06ab640b
(invalid instruction)                                        ; cc1c006f
	v_subrev_f32_e32 v0, v111, v24                              ; 0a00316f
	v_mov_b32_e32 v170, v179                                    ; 7f5403b3
	v_dual_mov_b32 v19, v29 :: v_dual_mov_b32 v18, v28          ; ca10011d 1312011c
	v_dual_mov_b32 v73, v61 :: v_dual_mov_b32 v72, v60          ; ca10013d 4948013c
(invalid instruction)                                        ; cc1c00a3
	v_subrev_f32_e32 v0, v163, v24                              ; 0a0031a3
	v_dual_mov_b32 v85, v81 :: v_dual_mov_b32 v84, v80          ; ca100151 55540150
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[62:63], v[88:89], v[96:103] ; cc464060 1d82b13e
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[40:43], v2, s[20:23], null offen offset:208 ; c405c07c 40802828 0000d002
	buffer_load_b128 v[166:169], v2, s[20:23], null offen offset:4288 ; c405c07c 408028a6 0010c002
	buffer_load_b128 v[176:179], v2, s[20:23], null offen offset:4304 ; c405c07c 408028b0 0010d002
	buffer_load_b128 v[28:31], v2, s[20:23], null offen offset:8384 ; c405c07c 4080281c 0020c002
	buffer_load_b128 v[60:63], v2, s[20:23], null offen offset:8400 ; c405c07c 4080283c 0020d002
	buffer_load_b128 v[78:81], v2, s[20:23], null offen offset:12480 ; c405c07c 4080284e 0030c002
	v_fma_mixhi_f16 v165, s11, v170, v171                       ; cc2200a5 06af540b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v88, s11, v180, v40                         ; cc210058 04a3680b
	v_dual_mov_b32 v89, v172 :: v_dual_mov_b32 v40, v173        ; ca1001ac 592801ad
	buffer_load_b128 v[170:173], v2, s[20:23], null offen offset:12496 ; c405c07c 408028aa 0030d002
(invalid instruction)                                        ; cc1c00a2
	v_subrev_f32_e32 v0, v162, v24                              ; 0a0031a2
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v24                              ; 0a0031a4
(invalid instruction)                                        ; cc1b006e
	v_subrev_f32_e32 v0, v110, v13                              ; 0a001b6e
(invalid instruction)                                        ; cc1b006f
	v_subrev_f32_e32 v0, v111, v13                              ; 0a001b6f
(invalid instruction)                                        ; cc1b00a3
	v_subrev_f32_e32 v0, v163, v13                              ; 0a001ba3
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v24                              ; 0a0031a5
	v_fma_mixhi_f16 v88, s11, v181, v41                         ; cc220058 04a76a0b
	v_fma_mixlo_f16 v41, s11, v182, v42                         ; cc210029 04ab6c0b
	v_fma_mixhi_f16 v41, s11, v183, v43                         ; cc220029 04af6e0b
	s_mov_b32 s25, 0x7ff88000                                   ; be9900ff 7ff88000
(invalid instruction)                                        ; cc1b00a2
	v_subrev_f32_e32 v0, v162, v13                              ; 0a001ba2
(invalid instruction)                                        ; cc1b00a4
	v_subrev_f32_e32 v0, v164, v13                              ; 0a001ba4
(invalid instruction)                                        ; cc1b00a5
	v_subrev_f32_e32 v0, v165, v13                              ; 0a001ba5
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v93, v93, 5, s25                             ; d646005d 00650b5d
	v_lshl_add_u32 v92, v92, 5, s25                             ; d646005c 00650b5c
	v_lshl_add_u32 v160, v160, 5, s25                           ; d64600a0 00650ba0
	v_lshl_add_u32 v83, v83, 5, s25                             ; d6460053 00650b53
(invalid instruction)                                        ; cc1c0058
	v_subrev_f32_e32 v0, v88, v24                               ; 0a003158
	v_lshl_add_u32 v11, v11, 5, s25                             ; d646000b 00650b0b
	v_lshl_add_u32 v82, v82, 5, s25                             ; d6460052 00650b52
(invalid instruction)                                        ; cc1c0029
	v_subrev_f32_e32 v0, v41, v24                               ; 0a003129
	v_lshl_add_u32 v94, v94, 5, s25                             ; d646005e 00650b5e
	v_lshl_add_u32 v164, v164, 5, s25                           ; d64600a4 00650ba4
	v_lshl_add_u32 v120, v120, 5, s25                           ; d6460078 00650b78
	v_lshl_add_u32 v165, v165, 5, s25                           ; d64600a5 00650ba5
	v_lshl_add_u32 v6, v6, 5, s25                               ; d6460006 00650b06
(invalid instruction)                                        ; cc0f002b
	v_min_num_f64_e32 v[1:2], v[93:94], v[83:84]                ; 1a02a75d
	v_lshl_add_u32 v95, v95, 5, s25                             ; d646005f 00650b5f
(invalid instruction)                                        ; cc1b0058
	v_subrev_f32_e32 v0, v88, v13                               ; 0a001b58
	v_lshl_add_u32 v121, v121, 5, s25                           ; d6460079 00650b79
(invalid instruction)                                        ; cc0f002a
	v_min_num_f64_e32 v[1:2], v[92:93], v[82:83]                ; 1a02a55c
(invalid instruction)                                        ; cc1b0029
	v_subrev_f32_e32 v0, v41, v13                               ; 0a001b29
	v_lshl_add_u32 v7, v7, 5, s25                               ; d6460007 00650b07
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[94:95], v[120:121]              ; 1a02f15e
(invalid instruction)                                        ; cc0f002b
	v_min_num_f64_e32 v[1:2], v[43:44], v[160:161]              ; 1a03412b
	v_lshl_add_u32 v88, v88, 5, s25                             ; d6460058 00650b58
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[95:96], v[121:122]              ; 1a02f35f
(invalid instruction)                                        ; cc0f002a
	v_min_num_f64_e32 v[1:2], v[42:43], v[11:12]                ; 1a02172a
	v_lshl_add_u32 v41, v41, 5, s25                             ; d6460029 00650b29
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[6:7]                ; 1a020db4
(invalid instruction)                                        ; cc0f002b
	v_min_num_f64_e32 v[1:2], v[43:44], v[165:166]              ; 1a034b2b
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[181:182], v[7:8]                ; 1a020fb5
(invalid instruction)                                        ; cc0f002a
	v_min_num_f64_e32 v[1:2], v[42:43], v[164:165]              ; 1a03492a
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[88:89]              ; 1a02b1b4
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[181:182], v[41:42]              ; 1a0253b5
(invalid instruction)                                        ; cc0f002a
	v_min_num_f64_e32 v[1:2], v[42:43], v[43:44]                ; 1a02572a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f002a
	v_min_num_f64_e32 v[1:2], v[42:43], v[180:181]              ; 1a03692a
(invalid instruction)                                        ; cc0f002a
	v_min_num_f64_e32 v[1:2], v[42:43], v[181:182]              ; 1a036b2a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v182, v42, s5, s8 op_sel:[1,1]            ; d65c18b6 00200b2a
(invalid instruction)                                        ; cc0f002a
	v_min_num_f64_e32 v[1:2], v[42:43], v[182:183]              ; 1a036d2a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53210b7
	v_cndmask_b32_e32 v1, v42, v42, vcc_lo                      ; 0202552a
(invalid instruction)                                        ; d53100b7
	v_cndmask_b32_e32 v1, s3, v183, vcc_lo                      ; 02036e03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b0002
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                    ; 020101b7
	v_rcp_f32_e32 v2, v2                                        ; 7e045502
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v42, v92, v2, neg(0) op_sel_hi:[1,0,0]        ; cc20002a 8a02055c
	v_fma_mix_f32 v43, v93, v2, neg(0) op_sel_hi:[1,0,0]        ; cc20002b 8a02055d
	v_fma_mix_f32 v93, v93, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085d 8a02055d
	v_fma_mix_f32 v92, v92, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085c 8a02055c
	v_fma_mix_f32 v180, v120, v2, neg(0) op_sel_hi:[1,0,0]      ; cc2000b4 8a020578
	v_fma_mix_f32 v120, v120, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200878 8a020578
	v_fma_mix_f32 v181, v121, v2, neg(0) op_sel_hi:[1,0,0]      ; cc2000b5 8a020579
	v_fma_mix_f32 v121, v121, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200879 8a020579
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v42, v92, vcc_lo                      ; 0202b92a
	v_fma_mix_f32 v92, v94, v2, neg(0) op_sel_hi:[1,0,0]        ; cc20005c 8a02055e
	v_fma_mix_f32 v94, v94, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085e 8a02055e
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v43, v93, vcc_lo                      ; 0202bb2b
	v_fma_mix_f32 v93, v95, v2, neg(0) op_sel_hi:[1,0,0]        ; cc20005d 8a02055f
	v_fma_mix_f32 v95, v95, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085f 8a02055f
	v_fma_mix_f32 v182, v11, v2, neg(0) op_sel_hi:[1,0,0]       ; cc2000b6 8a02050b
	v_fma_mix_f32 v11, v11, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080b 8a02050b
	v_fma_mix_f32 v183, v160, v2, neg(0) op_sel_hi:[1,0,0]      ; cc2000b7 8a0205a0
	v_fma_mix_f32 v160, v160, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a0 8a0205a0
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v92, v94, vcc_lo                      ; 0202bd5c
	v_fma_mix_f32 v94, v82, v2, neg(0) op_sel_hi:[1,0,0]        ; cc20005e 8a020552
	v_fma_mix_f32 v82, v82, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200852 8a020552
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v93, v95, vcc_lo                      ; 0202bf5d
	v_fma_mix_f32 v95, v83, v2, neg(0) op_sel_hi:[1,0,0]        ; cc20005f 8a020553
	v_fma_mix_f32 v83, v83, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200853 8a020553
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v180, v120, vcc_lo                    ; 0202f1b4
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v181, v121, vcc_lo                    ; 0202f3b5
	v_fma_mix_f32 v120, v165, v2, neg(0) op_sel_hi:[1,0,0]      ; cc200078 8a0205a5
	v_fma_mix_f32 v165, v165, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a0205a5
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v94, v82, vcc_lo                      ; 0202a55e
	v_fma_mix_f32 v94, v7, v2, neg(0) op_sel_hi:[1,0,0]         ; cc20005e 8a020507
	v_fma_mix_f32 v7, v7, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200807 8a020507
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v182, v11, vcc_lo                     ; 020217b6
	v_fma_mix_f32 v11, v6, v2, neg(0) op_sel_hi:[1,0,0]         ; cc20000b 8a020506
	v_fma_mix_f32 v6, v6, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200806 8a020506
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v183, v160, vcc_lo                    ; 020341b7
	v_fma_mix_f32 v121, v88, v2, neg(0) op_sel_hi:[1,0,0]       ; cc200079 8a020558
	v_fma_mix_f32 v88, v88, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200858 8a020558
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v95, v83, vcc_lo                      ; 0202a75f
	v_fma_mix_f32 v95, v164, v2, neg(0) op_sel_hi:[1,0,0]       ; cc20005f 8a0205a4
	v_fma_mix_f32 v164, v164, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a4 8a0205a4
	v_fma_mix_f32 v160, v41, v2, neg(0) op_sel_hi:[1,0,0]       ; cc2000a0 8a020529
	v_fma_mix_f32 v41, v41, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200829 8a020529
	v_lshl_add_u32 v12, v12, 5, s25                             ; d646000c 00650b0c
	v_lshl_add_u32 v122, v122, 5, s25                           ; d646007a 00650b7a
	v_lshl_add_u32 v108, v108, 5, s25                           ; d646006c 00650b6c
	v_lshl_add_u32 v13, v13, 5, s25                             ; d646000d 00650b0d
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v11, v6, vcc_lo                       ; 02020d0b
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v94, v7, vcc_lo                       ; 02020f5e
	v_lshl_add_u32 v123, v123, 5, s25                           ; d646007b 00650b7b
	v_lshl_add_u32 v109, v109, 5, s25                           ; d646006d 00650b6d
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v121, v88, vcc_lo                     ; 0202b179
	v_lshl_add_u32 v14, v14, 5, s25                             ; d646000e 00650b0e
	v_lshl_add_u32 v136, v136, 5, s25                           ; d6460088 00650b88
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v95, v164, vcc_lo                     ; 0203495f
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v120, v165, vcc_lo                    ; 02034b78
	v_lshl_add_u32 v44, v44, 5, s25                             ; d646002c 00650b2c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v160, v41, vcc_lo                     ; 020253a0
	v_lshl_add_u32 v20, v20, 5, s25                             ; d6460014 00650b14
	v_lshl_add_u32 v137, v137, 5, s25                           ; d6460089 00650b89
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[12:13], v[122:123]              ; 1a02f50c
	v_lshl_add_u32 v45, v45, 5, s25                             ; d646002d 00650b2d
	v_lshl_add_u32 v21, v21, 5, s25                             ; d6460015 00650b15
	v_lshl_add_u32 v138, v138, 5, s25                           ; d646008a 00650b8a
(invalid instruction)                                        ; cc0f00a5
	v_min_num_f64_e32 v[1:2], v[13:14], v[123:124]              ; 1a02f70d
	v_lshl_add_u32 v4, v4, 5, s25                               ; d6460004 00650b04
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[14:15], v[136:137]              ; 1a03110e
	v_lshl_add_u32 v24, v24, 5, s25                             ; d6460018 00650b18
	v_lshl_add_u32 v139, v139, 5, s25                           ; d646008b 00650b8b
	v_lshl_add_u32 v5, v5, 5, s25                               ; d6460005 00650b05
	v_lshl_add_u32 v25, v25, 5, s25                             ; d6460019 00650b19
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[20:21], v[137:138]              ; 1a031314
	v_lshl_add_u32 v141, v141, 5, s25                           ; d646008d 00650b8d
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[108:109]            ; 1a02d9a4
	v_lshl_add_u32 v106, v106, 5, s25                           ; d646006a 00650b6a
	v_lshl_add_u32 v32, v32, 5, s25                             ; d6460020 00650b20
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[21:22], v[138:139]              ; 1a031515
	v_lshl_add_u32 v142, v142, 5, s25                           ; d646008e 00650b8e
(invalid instruction)                                        ; cc0f00a5
	v_min_num_f64_e32 v[1:2], v[165:166], v[109:110]            ; 1a02dba5
	v_lshl_add_u32 v107, v107, 5, s25                           ; d646006b 00650b6b
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[44:45]              ; 1a0259b4
	v_lshl_add_u32 v33, v33, 5, s25                             ; d6460021 00650b21
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[24:25], v[139:140]              ; 1a031718
	v_lshl_add_u32 v105, v105, 5, s25                           ; d6460069 00650b69
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[181:182], v[45:46]              ; 1a025bb5
	v_lshl_add_u32 v110, v110, 5, s25                           ; d646006e 00650b6e
(invalid instruction)                                        ; cc0f0002
	v_min_num_f64_e32 v[1:2], v[25:26], v[141:142]              ; 1a031b19
	v_lshl_add_u32 v72, v72, 5, s25                             ; d6460048 00650b48
	v_lshl_add_u32 v74, v74, 5, s25                             ; d646004a 00650b4a
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[4:5]                ; 1a0209b6
	v_lshl_add_u32 v111, v111, 5, s25                           ; d646006f 00650b6f
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[32:33], v[142:143]              ; 1a031d20
	v_lshl_add_u32 v84, v84, 5, s25                             ; d6460054 00650b54
	v_lshl_add_u32 v75, v75, 5, s25                             ; d646004b 00650b4b
	v_lshl_add_u32 v162, v162, 5, s25                           ; d64600a2 00650ba2
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[5:6]                ; 1a020bb7
	v_lshl_add_u32 v85, v85, 5, s25                             ; d6460055 00650b55
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[33:34], v[105:106]              ; 1a02d321
	v_lshl_add_u32 v10, v10, 5, s25                             ; d646000a 00650b0a
	v_lshl_add_u32 v163, v163, 5, s25                           ; d64600a3 00650ba3
(invalid instruction)                                        ; cc0f0002
	v_min_num_f64_e32 v[1:2], v[2:3], v[106:107]                ; 1a02d502
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v120, s11, v52, v166                        ; cc210078 069a680b
	v_fma_mixhi_f16 v120, s11, v53, v167                        ; cc220078 069e6a0b
(invalid instruction)                                        ; cc0f0058
	v_min_num_f64_e32 v[1:2], v[72:73], v[74:75]                ; 1a029548
	v_fma_mixlo_f16 v121, s11, v54, v168                        ; cc210079 06a26c0b
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[107:108]              ; 1a02d70b
	v_fma_mixhi_f16 v121, s11, v55, v169                        ; cc220079 06a66e0b
(invalid instruction)                                        ; cc0f005e
	v_min_num_f64_e32 v[1:2], v[84:85], v[75:76]                ; 1a029754
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v160, s11, v56, v176                        ; cc2100a0 06c2700b
	v_fma_mixhi_f16 v160, s11, v57, v177                        ; cc2200a0 06c6720b
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[41:42], v[110:111]              ; 1a02dd29
(invalid instruction)                                        ; cc0f005f
	v_min_num_f64_e32 v[1:2], v[85:86], v[10:11]                ; 1a021555
	v_fma_mixlo_f16 v166, s11, v58, v178                        ; cc2100a6 06ca740b
	v_fma_mixhi_f16 v166, s11, v59, v179                        ; cc2200a6 06ce760b
(invalid instruction)                                        ; cc1c0078
	v_subrev_f32_e32 v0, v120, v24                              ; 0a003178
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v167, s11, v64, v28                         ; cc2100a7 0472800b
(invalid instruction)                                        ; cc0f0058
	v_min_num_f64_e32 v[1:2], v[88:89], v[111:112]              ; 1a02df58
	v_fma_mixhi_f16 v167, s11, v65, v29                         ; cc2200a7 0476820b
(invalid instruction)                                        ; cc1c0079
	v_subrev_f32_e32 v0, v121, v24                              ; 0a003179
	v_fma_mixlo_f16 v168, s11, v66, v30                         ; cc2100a8 047a840b
(invalid instruction)                                        ; cc0f005e
	v_min_num_f64_e32 v[1:2], v[94:95], v[162:163]              ; 1a03455e
	v_fma_mixhi_f16 v168, s11, v67, v31                         ; cc2200a8 047e860b
(invalid instruction)                                        ; cc1c00a0
	v_subrev_f32_e32 v0, v160, v24                              ; 0a0031a0
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v169, s11, v68, v60                         ; cc2100a9 04f2880b
	v_fma_mixhi_f16 v169, s11, v69, v61                         ; cc2200a9 04f68a0b
(invalid instruction)                                        ; cc1c00a6
	v_subrev_f32_e32 v0, v166, v24                              ; 0a0031a6
(invalid instruction)                                        ; cc1b0078
	v_subrev_f32_e32 v0, v120, v13                              ; 0a001b78
	v_fma_mixlo_f16 v176, s11, v70, v62                         ; cc2100b0 04fa8c0b
	v_fma_mixhi_f16 v176, s11, v71, v63                         ; cc2200b0 04fe8e0b
(invalid instruction)                                        ; cc1c00a7
	v_subrev_f32_e32 v0, v167, v24                              ; 0a0031a7
(invalid instruction)                                        ; cc1b0079
	v_subrev_f32_e32 v0, v121, v13                              ; 0a001b79
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v177, s11, v96, v78                         ; cc2100b1 053ac00b
	v_fma_mixhi_f16 v177, s11, v97, v79                         ; cc2200b1 053ec20b
(invalid instruction)                                        ; cc1c00a8
	v_subrev_f32_e32 v0, v168, v24                              ; 0a0031a8
(invalid instruction)                                        ; cc1b00a0
	v_subrev_f32_e32 v0, v160, v13                              ; 0a001ba0
	v_fma_mixlo_f16 v178, s11, v98, v80                         ; cc2100b2 0542c40b
	v_fma_mixhi_f16 v178, s11, v99, v81                         ; cc2200b2 0546c60b
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v24                              ; 0a0031a9
(invalid instruction)                                        ; cc1b00a6
	v_subrev_f32_e32 v0, v166, v13                              ; 0a001ba6
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v24                              ; 0a0031b0
(invalid instruction)                                        ; cc1b00a7
	v_subrev_f32_e32 v0, v167, v13                              ; 0a001ba7
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v24                              ; 0a0031b1
(invalid instruction)                                        ; cc1b00a8
	v_subrev_f32_e32 v0, v168, v13                              ; 0a001ba8
	v_lshl_add_u32 v120, v120, 5, s25                           ; d6460078 00650b78
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v24                              ; 0a0031b2
(invalid instruction)                                        ; cc1b00a9
	v_subrev_f32_e32 v0, v169, v13                              ; 0a001ba9
	v_lshl_add_u32 v121, v121, 5, s25                           ; d6460079 00650b79
	v_lshl_add_u32 v160, v160, 5, s25                           ; d64600a0 00650ba0
(invalid instruction)                                        ; cc1b00b0
	v_subrev_f32_e32 v0, v176, v13                              ; 0a001bb0
(invalid instruction)                                        ; cc1b00b1
	v_subrev_f32_e32 v0, v177, v13                              ; 0a001bb1
	v_lshl_add_u32 v166, v166, 5, s25                           ; d64600a6 00650ba6
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[120:121]            ; 1a02f1a4
(invalid instruction)                                        ; cc1b00b2
	v_subrev_f32_e32 v0, v178, v13                              ; 0a001bb2
(invalid instruction)                                        ; cc0f00a5
	v_min_num_f64_e32 v[1:2], v[165:166], v[121:122]            ; 1a02f3a5
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[160:161]            ; 1a0341b4
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[181:182], v[166:167]            ; 1a034db5
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[165:166]            ; 1a034ba4
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[180:181]            ; 1a0369a4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[181:182]            ; 1a036ba4
	v_permlanex16_b32 v29, v164, s5, s8 op_sel:[1,1]            ; d65c181d 00200ba4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[29:30]              ; 1a023ba4
(invalid instruction)                                        ; d532101e
	v_cndmask_b32_e32 v1, v164, v164, vcc_lo                    ; 020349a4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v30, s3, v30                              ; 623c3c03
	v_cvt_f32_f16_e32 v31, v30                                  ; 7e3e171e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_rcp_f32_e32 v31, v31                                      ; 7e3e551f
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v28, s11, v102, v172                        ; cc21001c 06b2cc0b
	v_fma_mixlo_f16 v179, s11, v100, v170                       ; cc2100b3 06aac80b
	v_fma_mixhi_f16 v28, s11, v103, v173                        ; cc22001c 06b6ce0b
	v_fma_mixhi_f16 v179, s11, v101, v171                       ; cc2200b3 06aeca0b
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v24                               ; 0a00311c
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v24                              ; 0a0031b3
	v_fma_mix_f32 v54, v14, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200036 8a023f0e
	v_fma_mix_f32 v52, v12, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200034 8a023f0c
	v_fma_mix_f32 v53, v13, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200035 8a023f0d
	v_fma_mix_f32 v55, v20, v31, neg(0) op_sel_hi:[1,0,0]       ; cc200037 8a023f14
	v_fma_mix_f32 v12, v12, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080c 8a023f0c
	v_fma_mix_f32 v20, v20, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a023f14
	v_fma_mix_f32 v13, v13, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080d 8a023f0d
	v_fma_mix_f32 v14, v14, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080e 8a023f0e
	v_fma_mix_f32 v56, v122, v31, neg(0) op_sel_hi:[1,0,0]      ; cc200038 8a023f7a
	v_fma_mix_f32 v122, v122, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087a 8a023f7a
	v_fma_mix_f32 v57, v123, v31, neg(0) op_sel_hi:[1,0,0]      ; cc200039 8a023f7b
	v_fma_mix_f32 v123, v123, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087b 8a023f7b
(invalid instruction)                                        ; cc1b001c
	v_subrev_f32_e32 v0, v28, v13                               ; 0a001b1c
	v_fma_mix_f32 v58, v136, v31, neg(0) op_sel_hi:[1,0,0]      ; cc20003a 8a023f88
(invalid instruction)                                        ; cc1b00b3
	v_subrev_f32_e32 v0, v179, v13                              ; 0a001bb3
	v_fma_mix_f32 v136, v136, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200888 8a023f88
	v_fma_mix_f32 v59, v137, v31, neg(0) op_sel_hi:[1,0,0]      ; cc20003b 8a023f89
	v_fma_mix_f32 v137, v137, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200889 8a023f89
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v52, v12, vcc_lo                      ; 02021934
	v_fma_mix_f32 v60, v108, v31, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a023f6c
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v53, v13, vcc_lo                      ; 02021b35
	v_fma_mix_f32 v108, v108, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086c 8a023f6c
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v54, v14, vcc_lo                      ; 02021d36
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v55, v20, vcc_lo                      ; 02022937
	v_fma_mix_f32 v61, v109, v31, neg(0) op_sel_hi:[1,0,0]      ; cc20003d 8a023f6d
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v56, v122, vcc_lo                     ; 0202f538
	v_fma_mix_f32 v109, v109, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086d 8a023f6d
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v57, v123, vcc_lo                     ; 0202f739
	v_fma_mix_f32 v62, v44, v31, neg(0) op_sel_hi:[1,0,0]       ; cc20003e 8a023f2c
	v_fma_mix_f32 v44, v44, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082c 8a023f2c
	v_fma_mix_f32 v63, v45, v31, neg(0) op_sel_hi:[1,0,0]       ; cc20003f 8a023f2d
	v_fma_mix_f32 v45, v45, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082d 8a023f2d
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v58, v136, vcc_lo                     ; 0203113a
	v_fma_mix_f32 v64, v120, v31, neg(0) op_sel_hi:[1,0,0]      ; cc200040 8a023f78
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v59, v137, vcc_lo                     ; 0203133b
	v_fma_mix_f32 v120, v120, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200878 8a023f78
	v_fma_mix_f32 v65, v121, v31, neg(0) op_sel_hi:[1,0,0]      ; cc200041 8a023f79
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v60, v108, vcc_lo                     ; 0202d93c
	v_fma_mix_f32 v121, v121, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200879 8a023f79
	v_fma_mix_f32 v66, v160, v31, neg(0) op_sel_hi:[1,0,0]      ; cc200042 8a023fa0
	v_fma_mix_f32 v160, v160, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a0 8a023fa0
	v_fma_mix_f32 v67, v166, v31, neg(0) op_sel_hi:[1,0,0]      ; cc200043 8a023fa6
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v61, v109, vcc_lo                     ; 0202db3d
	v_fma_mix_f32 v166, v166, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a6 8a023fa6
	v_lshl_add_u32 v167, v167, 5, s25                           ; d64600a7 00650ba7
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v62, v44, vcc_lo                      ; 0202593e
	v_lshl_add_u32 v168, v168, 5, s25                           ; d64600a8 00650ba8
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v63, v45, vcc_lo                      ; 02025b3f
	v_lshl_add_u32 v169, v169, 5, s25                           ; d64600a9 00650ba9
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v64, v120, vcc_lo                     ; 0202f140
	v_lshl_add_u32 v176, v176, 5, s25                           ; d64600b0 00650bb0
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v65, v121, vcc_lo                     ; 0202f341
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v66, v160, vcc_lo                     ; 02034142
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v67, v166, vcc_lo                     ; 02034d43
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[167:168]            ; 1a034fb6
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[168:169]            ; 1a0351b7
(invalid instruction)                                        ; cc0f0002
	v_min_num_f64_e32 v[1:2], v[2:3], v[169:170]                ; 1a035302
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[176:177]              ; 1a03610b
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[183:184]            ; 1a036fb6
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[2:3]                ; 1a0205b6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[11:12]              ; 1a0217b6
	v_permlanex16_b32 v68, v182, s5, s8 op_sel:[1,1]            ; d65c1844 00200bb6
	v_add_lshl_u32 v81, s9, v35, 2                              ; d6470051 020a4609
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[68:69]              ; 1a0289b6
	buffer_load_b128 v[56:59], v81, s[20:23], null offen        ; c405c07c 40802838 00000051
(invalid instruction)                                        ; d5321045
	v_cndmask_b32_e32 v1, v182, v182, vcc_lo                    ; 02036db6
	v_max_num_f16_e32 v69, s3, v69                              ; 628a8a03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v70, v69                                  ; 7e8c1745
	v_rcp_f32_e32 v70, v70                                      ; 7e8c5546
	buffer_load_b128 v[60:63], v81, s[20:23], null offen offset:16 ; c405c07c 4080283c 00001051
	v_fma_mix_f32 v79, v25, v70, neg(0) op_sel_hi:[1,0,0]       ; cc20004f 8a028d19
	v_fma_mix_f32 v80, v32, v70, neg(0) op_sel_hi:[1,0,0]       ; cc200050 8a028d20
	v_fma_mix_f32 v32, v32, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a028d20
	v_fma_mix_f32 v96, v138, v70, neg(0) op_sel_hi:[1,0,0]      ; cc200060 8a028d8a
	v_fma_mix_f32 v71, v21, v70, neg(0) op_sel_hi:[1,0,0]       ; cc200047 8a028d15
	v_fma_mix_f32 v21, v21, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a028d15
	v_fma_mix_f32 v97, v139, v70, neg(0) op_sel_hi:[1,0,0]      ; cc200061 8a028d8b
	v_fma_mix_f32 v25, v25, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a028d19
	v_fma_mix_f32 v138, v138, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088a 8a028d8a
	v_fma_mix_f32 v78, v24, v70, neg(0) op_sel_hi:[1,0,0]       ; cc20004e 8a028d18
	v_fma_mix_f32 v24, v24, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200818 8a028d18
	v_fma_mix_f32 v139, v139, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088b 8a028d8b
	v_fma_mix_f32 v98, v141, v70, neg(0) op_sel_hi:[1,0,0]      ; cc200062 8a028d8d
	v_fma_mix_f32 v141, v141, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088d 8a028d8d
	v_fma_mix_f32 v99, v142, v70, neg(0) op_sel_hi:[1,0,0]      ; cc200063 8a028d8e
	v_fma_mix_f32 v142, v142, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088e 8a028d8e
	v_fma_mix_f32 v100, v4, v70, neg(0) op_sel_hi:[1,0,0]       ; cc200064 8a028d04
	v_fma_mix_f32 v4, v4, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200804 8a028d04
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v71, v21, vcc_lo                      ; 02022b47
	v_fma_mix_f32 v101, v5, v70, neg(0) op_sel_hi:[1,0,0]       ; cc200065 8a028d05
	v_fma_mix_f32 v5, v5, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200805 8a028d05
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v79, v25, vcc_lo                      ; 0202334f
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v80, v32, vcc_lo                      ; 02024150
	v_fma_mix_f32 v102, v106, v70, neg(0) op_sel_hi:[1,0,0]     ; cc200066 8a028d6a
	v_fma_mix_f32 v106, v106, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086a 8a028d6a
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v78, v24, vcc_lo                      ; 0202314e
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v96, v138, vcc_lo                     ; 02031560
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v97, v139, vcc_lo                     ; 02031761
	v_fma_mix_f32 v103, v107, v70, neg(0) op_sel_hi:[1,0,0]     ; cc200067 8a028d6b
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v8, s6, v8, 2                                ; d6470008 020a1006
	buffer_load_b128 v[64:67], v8, s[16:19], null offen         ; c405c07c 40802040 00000008
	v_fma_mix_f32 v107, v107, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086b 8a028d6b
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v98, v141, vcc_lo                     ; 02031b62
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v99, v142, vcc_lo                     ; 02031d63
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v100, v4, vcc_lo                      ; 02020964
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v101, v5, vcc_lo                      ; 02020b65
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v102, v106, vcc_lo                    ; 0202d566
	v_fma_mix_f32 v106, v167, v70, neg(0) op_sel_hi:[1,0,0]     ; cc20006a 8a028da7
	v_fma_mix_f32 v167, v167, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a7 8a028da7
	v_fma_mix_f32 v108, v169, v70, neg(0) op_sel_hi:[1,0,0]     ; cc20006c 8a028da9
	v_fma_mix_f32 v169, v169, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a028da9
	v_fma_mix_f32 v109, v176, v70, neg(0) op_sel_hi:[1,0,0]     ; cc20006d 8a028db0
	v_fma_mix_f32 v176, v176, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a028db0
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v103, v107, vcc_lo                    ; 0202d767
	v_fma_mix_f32 v107, v168, v70, neg(0) op_sel_hi:[1,0,0]     ; cc20006b 8a028da8
	v_fma_mix_f32 v168, v168, v70, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a8 8a028da8
	buffer_load_b128 v[68:71], v8, s[16:19], null offen offset:512 ; c405c07c 40802044 00020008
	v_lshl_add_u32 v177, v177, 5, s25                           ; d64600b1 00650bb1
	v_mov_b32_e32 v2, v104                                      ; 7e040368
	v_lshl_add_u32 v178, v178, 5, s25                           ; d64600b2 00650bb2
	v_lshl_add_u32 v179, v179, 5, s25                           ; d64600b3 00650bb3
(invalid instruction)                                        ; cc0f005f
	v_min_num_f64_e32 v[1:2], v[95:96], v[163:164]              ; 1a03475f
	v_lshl_add_u32 v28, v28, 5, s25                             ; d646001c 00650b1c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v106, v167, vcc_lo                    ; 02034f6a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v108, v169, vcc_lo                    ; 0203536c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v109, v176, vcc_lo                    ; 0203616d
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v107, v168, vcc_lo                    ; 0203516b
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[41:42], v[177:178]              ; 1a036329
(invalid instruction)                                        ; cc0f0058
	v_min_num_f64_e32 v[1:2], v[88:89], v[178:179]              ; 1a036558
(invalid instruction)                                        ; cc0f005e
	v_min_num_f64_e32 v[1:2], v[94:95], v[179:180]              ; 1a03675e
(invalid instruction)                                        ; cc0f005f
	v_min_num_f64_e32 v[1:2], v[95:96], v[28:29]                ; 1a02395f
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[41:42], v[88:89]                ; 1a02b129
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[41:42], v[94:95]                ; 1a02bd29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[41:42], v[95:96]                ; 1a02bf29
	v_permlanex16_b32 v120, v41, s5, s8 op_sel:[1,1]            ; d65c1878 00200b29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[41:42], v[120:121]              ; 1a02f129
	v_add_f16_e32 v121, v41, v169/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64f35329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v121, s3, v121                            ; 62f2f203
	v_cvt_f32_f16_e32 v122, v121                                ; 7ef41779
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v122, v122                                    ; 7ef4557a
	v_fma_mix_f32 v138, v85, v122, neg(0) op_sel_hi:[1,0,0]     ; cc20008a 8a02f555
	v_fma_mix_f32 v85, v85, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200855 8a02f555
	v_fma_mix_f32 v123, v33, v122, neg(0) op_sel_hi:[1,0,0]     ; cc20007b 8a02f521
	v_fma_mix_f32 v137, v84, v122, neg(0) op_sel_hi:[1,0,0]     ; cc200089 8a02f554
	v_fma_mix_f32 v136, v72, v122, neg(0) op_sel_hi:[1,0,0]     ; cc200088 8a02f548
	v_fma_mix_f32 v141, v74, v122, neg(0) op_sel_hi:[1,0,0]     ; cc20008d 8a02f54a
	v_fma_mix_f32 v84, v84, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200854 8a02f554
	v_fma_mix_f32 v33, v33, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200821 8a02f521
	v_fma_mix_f32 v72, v72, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200848 8a02f548
	v_fma_mix_f32 v139, v105, v122, neg(0) op_sel_hi:[1,0,0]    ; cc20008b 8a02f569
	v_fma_mix_f32 v105, v105, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200869 8a02f569
	v_fma_mix_f32 v74, v74, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084a 8a02f54a
	v_fma_mix_f32 v142, v75, v122, neg(0) op_sel_hi:[1,0,0]     ; cc20008e 8a02f54b
	v_fma_mix_f32 v75, v75, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084b 8a02f54b
	v_fma_mix_f32 v160, v10, v122, neg(0) op_sel_hi:[1,0,0]     ; cc2000a0 8a02f50a
	v_fma_mix_f32 v10, v10, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080a 8a02f50a
	v_fma_mix_f32 v164, v110, v122, neg(0) op_sel_hi:[1,0,0]    ; cc2000a4 8a02f56e
	v_fma_mix_f32 v110, v110, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086e 8a02f56e
	v_fma_mix_f32 v165, v111, v122, neg(0) op_sel_hi:[1,0,0]    ; cc2000a5 8a02f56f
	v_fma_mix_f32 v111, v111, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086f 8a02f56f
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v123, v33, vcc_lo                     ; 0202437b
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v137, v84, vcc_lo                     ; 0202a989
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v138, v85, vcc_lo                     ; 0202ab8a
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v136, v72, vcc_lo                     ; 02029188
	v_fma_mix_f32 v166, v162, v122, neg(0) op_sel_hi:[1,0,0]    ; cc2000a6 8a02f5a2
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v139, v105, vcc_lo                    ; 0202d38b
	v_fma_mix_f32 v162, v162, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a2 8a02f5a2
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v141, v74, vcc_lo                     ; 0202958d
	v_fma_mix_f32 v167, v163, v122, neg(0) op_sel_hi:[1,0,0]    ; cc2000a7 8a02f5a3
	v_fma_mix_f32 v163, v163, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a3 8a02f5a3
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v142, v75, vcc_lo                     ; 0202978e
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v160, v10, vcc_lo                     ; 020215a0
	v_fma_mix_f32 v168, v177, v122, neg(0) op_sel_hi:[1,0,0]    ; cc2000a8 8a02f5b1
	v_fma_mix_f32 v177, v177, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a02f5b1
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v164, v110, vcc_lo                    ; 0202dda4
	v_fma_mix_f32 v169, v178, v122, neg(0) op_sel_hi:[1,0,0]    ; cc2000a9 8a02f5b2
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v165, v111, vcc_lo                    ; 0202dfa5
	v_fma_mix_f32 v178, v178, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a02f5b2
	v_fma_mix_f32 v170, v179, v122, neg(0) op_sel_hi:[1,0,0]    ; cc2000aa 8a02f5b3
	v_fma_mix_f32 v179, v179, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a02f5b3
	v_fma_mix_f32 v171, v28, v122, neg(0) op_sel_hi:[1,0,0]     ; cc2000ab 8a02f51c
	v_fma_mix_f32 v28, v28, v122, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a02f51c
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v166, v162, vcc_lo                    ; 020345a6
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[42:43], 0 ; cc464060 1a025510
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v167, v163, vcc_lo                    ; 020347a7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[32:33], 0 ; cc464068 1a024110
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v168, v177, vcc_lo                    ; 020363a8
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v169, v178, vcc_lo                    ; 020365a9
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v170, v179, vcc_lo                    ; 020367aa
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[52:53], 0 ; cc4640b0 1a026910
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v171, v28, vcc_lo                     ; 020239ab
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[16:17], v[20:21], 0 ; cc4640a4 1a022910
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[92:93], v[96:103] ; cc464060 1d82b91a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[78:79], v[104:111] ; cc464068 1da29d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[26:27], v[12:13], v[176:183] ; cc4640b0 1ec2191a
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[26:27], v[24:25], v[164:171] ; cc4640a4 1e92311a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[82:83], v[96:103] ; cc464060 1d82a532
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[50:51], v[10:11], v[104:111] ; cc464068 1da21532
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[50:51], v[54:55], v[176:183] ; cc4640b0 1ec26d32
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[50:51], v[30:31], v[164:171] ; cc4640a4 1e923d32
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[86:87], v[6:7], v[96:103] ; cc464060 1d820d56
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[86:87], v[74:75], v[104:111] ; cc464068 1da29556
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[86:87], v[44:45], v[176:183] ; cc4640b0 1ec25956
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[86:87], v[4:5], v[164:171] ; cc4640a4 1e920956
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_load_b128 s[4:7], s[14:15], 0x3c                          ; f4004107 f800003c
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[22:23], v[42:43], 0 ; cc464060 1a025516
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[52:53], 0 ; cc464068 1a026916
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[22:23], v[20:21], 0 ; cc4640b0 1a022916
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[48:49], v[92:93], v[96:103] ; cc464060 1d82b930
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[22:23], v[32:33], 0 ; cc4640a4 1a024116
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[12:13], v[104:111] ; cc464068 1da21930
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[48:49], v[24:25], v[176:183] ; cc4640b0 1ec23130
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[76:77], v[82:83], v[96:103] ; cc464060 1d82a54c
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[48:49], v[78:79], v[164:171] ; cc4640a4 1e929d30
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[76:77], v[54:55], v[104:111] ; cc464068 1da26d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[76:77], v[30:31], v[176:183] ; cc4640b0 1ec23d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[90:91], v[6:7], v[96:103] ; cc464060 1d820d5a
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[76:77], v[10:11], v[164:171] ; cc4640a4 1e92154c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[90:91], v[44:45], v[104:111] ; cc464068 1da2595a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[90:91], v[4:5], v[176:183] ; cc4640b0 1ec2095a
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_mul_f32_e32 v96, v144, v56                                ; 10c07190
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_dual_mul_f32 v98, v146, v58 :: v_dual_mul_f32 v97, v145, v57 ; c8c67592 62607391
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v100, v148, v60 :: v_dual_mul_f32 v99, v147, v59 ; c8c67994 64627793
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_mul_f32 v102, v150, v62 :: v_dual_mul_f32 v101, v149, v61 ; c8c67d96 66647b95
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[90:91], v[74:75], v[164:171] ; cc4640a4 1e92955a
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_mul_f32 v104, v152, v56 :: v_dual_mul_f32 v103, v151, v63 ; c8c67198 68667f97
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	s_load_b256 s[24:31], s[0:1], 0x0                           ; f4006600 f8000000
	v_dual_mul_f32 v106, v154, v58 :: v_dual_mul_f32 v105, v153, v57 ; c8c6759a 6a687399
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_dual_mul_f32 v108, v156, v60 :: v_dual_mul_f32 v107, v155, v59 ; c8c6799c 6c6a779b
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_mul_f32 v110, v158, v62 :: v_dual_mul_f32 v109, v157, v61 ; c8c67d9e 6e6c7b9d
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_dual_mul_f32 v144, v184, v56 :: v_dual_mul_f32 v111, v159, v63 ; c8c671b8 906e7f9f
	v_mul_f32_e32 v146, v186, v58                               ; 112475ba
	v_dual_mul_f32 v148, v188, v60 :: v_dual_mul_f32 v145, v185, v57 ; c8c679bc 949073b9
	v_dual_mul_f32 v150, v190, v62 :: v_dual_mul_f32 v147, v187, v59 ; c8c67dbe 969277bb
	v_dual_mul_f32 v152, v112, v56 :: v_dual_mul_f32 v149, v189, v61 ; c8c67170 98947bbd
	v_dual_mul_f32 v154, v114, v58 :: v_dual_mul_f32 v151, v191, v63 ; c8c67572 9a967fbf
	v_dual_mul_f32 v156, v116, v60 :: v_dual_mul_f32 v153, v113, v57 ; c8c67974 9c987371
	v_dual_mul_f32 v158, v118, v62 :: v_dual_mul_f32 v155, v115, v59 ; c8c67d76 9e9a7773
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[64:65], v[16:17], v[96:103] ; cc464060 1d822140
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[64:65], v[26:27], v[104:111] ; cc464068 1da23540
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[64:65], v[28:29], v[144:151] ; cc464090 1e423940
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[4:5], v[96:103] ; cc464060 1d820944
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl1_add_u32 s32, ttmp9, s4                              ; 87200475
	s_lshl_b32 s33, ttmp7, 1                                    ; 84218173
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[6:7], v[104:111] ; cc464068 1da20d44
	s_add_co_u32 s34, s33, s5                                   ; 80220521
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[10:11], v[144:151] ; cc464090 1e421544
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v14, v97, v101 :: v_dual_mul_f32 v159, v119, v63 ; ca46cb61 0e9e7f77
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_cndmask_b32 v8, v96, v100 :: v_dual_mul_f32 v157, v117, v61 ; ca46c960 089c7b75
	buffer_load_b128 v[52:55], v81, s[20:23], null offen offset:64 ; c405c07c 40802834 00004051
	v_dual_cndmask_b32 v22, v98, v102 :: v_dual_cndmask_b32 v23, v99, v103 ; ca52cd62 1616cf63
	v_dual_cndmask_b32 v102, v102, v98 :: v_dual_cndmask_b32 v103, v103, v99 ; ca52c566 6666c767
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_cndmask_b32 v100, v100, v96 :: v_dual_cndmask_b32 v101, v101, v97 ; ca52c164 6464c365
	buffer_load_b128 v[56:59], v81, s[20:23], null offen offset:80 ; c405c07c 40802838 00005051
	s_mov_b32 s35, 0xf0f0f0f0                                   ; bea300ff f0f0f0f0
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[50:51], v[152:159] ; cc464098 1e626540
	v_and_b32_e32 v48, 1, v0                                    ; 36600081
	v_add_f32_dpp v103, v103, v23 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ce2efa ff0cb167
	v_bfe_u32 v41, v0, 1, 1                                     ; d6100029 02050300
	v_add_f32_dpp v102, v102, v22 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cc2cfa ff0cb166
	v_add_f32_dpp v101, v101, v14 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ca1cfa ff0cb165
	v_add_f32_dpp v100, v100, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06c810fa ff0cb164
	v_bfe_u32 v42, v0, 3, 1                                     ; d610002a 02050700
	v_bfe_u32 v0, v0, 2, 1                                      ; d6100000 02050500
	v_lshlrev_b32_e32 v48, 2, v48                               ; 30606082
	v_cvt_f16_f32_e32 v25, v103                                 ; 7e321567
	s_ashr_i32 s36, s34, 1                                      ; 86248122
	s_ashr_i32 s37, s32, 1                                      ; 86258120
	v_cvt_f16_f32_e32 v24, v102                                 ; 7e301566
	v_cndmask_b32_e64 v103, v103, v101, s35                     ; d5010067 008ecb67
	v_cvt_f16_f32_e32 v31, v101                                 ; 7e3e1565
	v_cvt_f16_f32_e32 v30, v100                                 ; 7e3c1564
	v_cndmask_b32_e64 v102, v102, v100, s35                     ; d5010066 008ec966
	v_lshl_add_u32 v42, v42, 2, v41                             ; d646002a 04a5052a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[12:13], v[152:159] ; cc464098 1e621944
	v_lshlrev_b32_e32 v0, 1, v0                                 ; 30000081
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s36, s36, s7                                      ; 96240724
	s_mov_b32 s40, 0x3e800000                                   ; bea800ff 3e800000
	v_cndmask_b32_e64 v32, v30, v24, s35                        ; d5010020 008e311e
	v_cndmask_b16 v32, v31, v25, s35                            ; d65d4020 008e331f
	v_cvt_f16_f32_dpp v33, v102 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e4214fa ff0d6466
(invalid instruction)                                        ; 7f4214fa
(invalid instruction)                                        ; ff0d6467
	v_lshl_add_u32 v42, v42, 4, v35                             ; d646002a 048d092a
	s_bitset0_b32 s6, 0                                         ; be861080
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s38, s36, s37                                  ; 80262524
	s_and_b32 s4, s4, 1                                         ; 8b048104
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[32:33], v[33:34]                ; 1a024320
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s4, s4, 5                                        ; 84048504
	s_and_b32 s5, s5, 1                                         ; 8b058105
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s5, s5, 7                                        ; 84058705
	v_fma_mix_f32 v43, s40, v32, neg(0) op_sel_hi:[0,1,0]       ; cc20002b 92024028
	v_fma_mix_f32 v32, s40, v32, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201020 92024028
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s39, s5, s4                                    ; 80270405
	s_lshl_b32 s38, s38, 9                                      ; 84268926
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c9
	s_add_co_u32 s41, s6, s38                                   ; 80292606
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v43, v32, vcc_lo                      ; 0202412b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v45, v42, s41, s39                               ; d655002d 009c532a
	v_add3_u32 v45, v0, v45, v48                                ; d655002d 04c25b00
	buffer_store_b16 v44, v45, s[28:31], null offen             ; c406407c 4080382c 0000002d
	s_mul_i32 s42, s33, s12                                     ; 962a0c21
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl1_add_u32 s42, ttmp9, s42                             ; 872a2a75
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s42, s42, 9                                      ; 842a892a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s43, s2, s42                                   ; 802b2a02
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v49, v1, s43, v3                                 ; d6550031 040c5701
	buffer_store_b64 v[20:21], v49, s[24:27], null offen        ; c406c07c 40803014 00000031
	v_dual_cndmask_b32 v61, v105, v109 :: v_dual_cndmask_b32 v60, v104, v108 ; ca52db69 3d3cd968
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_dual_cndmask_b32 v109, v109, v105 :: v_dual_cndmask_b32 v108, v108, v104 ; ca52d36d 6d6cd16c
	v_dual_cndmask_b32 v63, v107, v111 :: v_dual_cndmask_b32 v62, v106, v110 ; ca52df6b 3f3edd6a
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_cndmask_b32 v111, v111, v107 :: v_dual_cndmask_b32 v110, v110, v106 ; ca52d76f 6f6ed56e
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v108, v108, v60 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06d878fa ff0cb16c
	s_add_co_u32 s32, s32, 1                                    ; 80208120
	v_add_f32_dpp v109, v109, v61 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06da7afa ff0cb16d
	v_add_f32_dpp v111, v111, v63 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06de7efa ff0cb16f
	v_add_f32_dpp v110, v110, v62 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06dc7cfa ff0cb16e
	s_ashr_i32 s44, s32, 1                                      ; 862c8120
	v_cvt_f16_f32_e32 v68, v108                                 ; 7e88156c
	v_cvt_f16_f32_e32 v69, v109                                 ; 7e8a156d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s36, s36, s44                                  ; 80242c24
	s_and_b32 s32, s32, 1                                       ; 8b208120
	v_cvt_f16_f32_e32 v65, v111                                 ; 7e82156f
	v_cndmask_b32_e64 v111, v111, v109, s35                     ; d501006f 008edb6f
	v_cvt_f16_f32_e32 v64, v110                                 ; 7e80156e
	v_cndmask_b32_e64 v110, v110, v108, s35                     ; d501006e 008ed96e
	s_lshl_b32 s32, s32, 5                                      ; 84208520
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s5, s5, s32                                    ; 80052005
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s36, s36, 9                                      ; 84248924
	v_cndmask_b32_e64 v72, v68, v64, s35                        ; d5010048 008e8144
	v_cndmask_b16 v72, v69, v65, s35                            ; d65d4048 008e8345
	v_cvt_f16_f32_dpp v74, v110 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e9414fa ff0d646e
(invalid instruction)                                        ; 7f9414fa
(invalid instruction)                                        ; ff0d646f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s45, s6, s36                                   ; 802d2406
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v77, v42, s45, s5                                ; d655004d 00145b2a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc0f0048
	v_min_num_f64_e32 v[1:2], v[72:73], v[74:75]                ; 1a029548
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_add3_u32 v77, v0, v77, v48                                ; d655004d 04c29b00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mix_f32 v75, s40, v72, neg(0) op_sel_hi:[0,1,0]       ; cc20004b 92029028
	v_fma_mix_f32 v72, s40, v72, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201048 92029028
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v75, v72, vcc_lo                      ; 0202914b
	buffer_store_b16 v76, v77, s[28:31], null offen             ; c406407c 4080384c 0000004d
	s_addk_co_i32 s42, 0x200                                    ; b7aa0200
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s42, s2, s42                                   ; 802a2a02
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v78, v1, s42, v3                                 ; d655004e 040c5501
	buffer_store_b64 v[20:21], v78, s[24:27], null offen        ; c406c07c 40803014 0000004e
	v_dual_cndmask_b32 v80, v145, v149 :: v_dual_cndmask_b32 v79, v144, v148 ; ca532b91 504f2990
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_dual_cndmask_b32 v149, v149, v145 :: v_dual_cndmask_b32 v148, v148, v144 ; ca532395 95952194
	v_dual_cndmask_b32 v82, v147, v151 :: v_dual_cndmask_b32 v81, v146, v150 ; ca532f93 52512d92
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_dual_cndmask_b32 v151, v151, v147 :: v_dual_cndmask_b32 v150, v150, v146 ; ca532797 97972596
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_add_co_u32 s34, s34, 1                                    ; 80228122
	v_add_f32_dpp v148, v148, v79 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 07289efa ff0cb194
	v_add_f32_dpp v149, v149, v80 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 072aa0fa ff0cb195
	v_add_f32_dpp v151, v151, v82 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 072ea4fa ff0cb197
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_ashr_i32 s46, s34, 1                                      ; 862e8122
	v_add_f32_dpp v150, v150, v81 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 072ca2fa ff0cb196
	v_cvt_f16_f32_e32 v85, v148                                 ; 7eaa1594
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s46, s46, s7                                      ; 962e072e
	v_cvt_f16_f32_e32 v86, v149                                 ; 7eac1595
	v_cvt_f16_f32_e32 v84, v151                                 ; 7ea81597
	v_cndmask_b32_e64 v151, v151, v149, s35                     ; d5010097 008f2b97
	v_cvt_f16_f32_e32 v83, v150                                 ; 7ea61596
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s46, s37                                  ; 8025252e
	s_and_b32 s34, s34, 1                                       ; 8b228122
	v_cndmask_b32_e64 v150, v150, v148, s35                     ; d5010096 008f2996
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s34, s34, 7                                      ; 84228722
	v_cndmask_b32_e64 v87, v85, v83, s35                        ; d5010057 008ea755
	v_cndmask_b16 v87, v86, v84, s35                            ; d65d4057 008ea956
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s34, s4                                    ; 80040422
	s_lshl_b32 s37, s37, 9                                      ; 84258925
	v_cvt_f16_f32_dpp v88, v150 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7eb014fa ff0d6496
(invalid instruction)                                        ; 7fb014fa
(invalid instruction)                                        ; ff0d6497
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s47, s6, s37                                   ; 802f2506
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v92, v42, s47, s4                                ; d655005c 00105f2a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc0f0057
	v_min_num_f64_e32 v[1:2], v[87:88], v[88:89]                ; 1a02b157
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_add3_u32 v92, v0, v92, v48                                ; d655005c 04c2b900
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mix_f32 v90, s40, v87, neg(0) op_sel_hi:[0,1,0]       ; cc20005a 9202ae28
	v_fma_mix_f32 v87, s40, v87, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201057 9202ae28
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v90, v87, vcc_lo                      ; 0202af5a
	buffer_store_b16 v91, v92, s[28:31], null offen             ; c406407c 4080385b 0000005c
	s_add_co_u32 s33, s33, 1                                    ; 80218121
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s33, s33, s12                                     ; 96210c21
	s_lshl1_add_u32 s33, ttmp9, s33                             ; 87212175
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s33, s33, 9                                      ; 84218921
	s_add_co_u32 s48, s2, s33                                   ; 80302102
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add3_u32 v93, v1, s48, v3                                 ; d655005d 040c6101
	buffer_store_b64 v[20:21], v93, s[24:27], null offen        ; c406c07c 40803014 0000005d
	v_dual_cndmask_b32 v95, v153, v157 :: v_dual_cndmask_b32 v94, v152, v156 ; ca533b99 5f5f3998
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_dual_cndmask_b32 v157, v157, v153 :: v_dual_cndmask_b32 v156, v156, v152 ; ca53339d 9d9d319c
	v_dual_cndmask_b32 v97, v155, v159 :: v_dual_cndmask_b32 v96, v154, v158 ; ca533f9b 61613d9a
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_dual_cndmask_b32 v159, v159, v155 :: v_dual_cndmask_b32 v158, v158, v154 ; ca53379f 9f9f359e
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v156, v156, v94 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 0738bcfa ff0cb19c
	s_add_co_u32 s46, s46, s44                                  ; 802e2c2e
	v_add_f32_dpp v157, v157, v95 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 073abefa ff0cb19d
	s_add_co_u32 s34, s34, s32                                  ; 80222022
	v_add_f32_dpp v158, v158, v96 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 073cc0fa ff0cb19e
	v_add_f32_dpp v159, v159, v97 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 073ec2fa ff0cb19f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s46, s46, 9                                      ; 842e892e
	v_cvt_f16_f32_e32 v100, v156                                ; 7ec8159c
	v_cvt_f16_f32_e32 v101, v157                                ; 7eca159d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s49, s6, s46                                   ; 80312e06
	v_cvt_f16_f32_e32 v98, v158                                 ; 7ec4159e
	v_cndmask_b32_e64 v158, v158, v156, s35                     ; d501009e 008f399e
	v_cvt_f16_f32_e32 v99, v159                                 ; 7ec6159f
	v_cndmask_b32_e64 v159, v159, v157, s35                     ; d501009f 008f3b9f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v106, v42, s49, s34                              ; d655006a 0088632a
	v_cndmask_b32_e64 v102, v100, v98, s35                      ; d5010066 008ec564
	v_cvt_f16_f32_dpp v103, v158 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7ece14fa ff0d649e
	v_cndmask_b16 v102, v101, v99, s35                          ; d65d4066 008ec765
(invalid instruction)                                        ; 7fce14fa
(invalid instruction)                                        ; ff0d649f
	v_add3_u32 v106, v0, v106, v48                              ; d655006a 04c2d500
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[103:104]            ; 1a02cf66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v104, s40, v102, neg(0) op_sel_hi:[0,1,0]     ; cc200068 9202cc28
	v_fma_mix_f32 v102, s40, v102, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201066 9202cc28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b1
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v104, v102, vcc_lo                    ; 0202cd68
	buffer_store_b16 v105, v106, s[28:31], null offen           ; c406407c 40803869 0000006a
	s_addk_co_i32 s33, 0x200                                    ; b7a10200
	s_add_co_u32 s2, s2, s33                                    ; 80022102
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v107, v1, s2, v3                                 ; d655006b 040c0501
	buffer_store_b64 v[20:21], v107, s[24:27], null offen       ; c406c07c 40803014 0000006b
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_dual_mul_f32 v97, v125, v53 :: v_dual_mul_f32 v96, v124, v52 ; c8c66b7d 6160697c
	v_dual_mul_f32 v83, v39, v55 :: v_dual_mul_f32 v82, v38, v54 ; c8c66f27 53526d26
	v_dual_mul_f32 v99, v127, v55 :: v_dual_mul_f32 v98, v126, v54 ; c8c66f7f 63626d7e
	v_dual_mul_f32 v105, v18, v53 :: v_dual_mul_f32 v104, v143, v52 ; c8c66b12 6968698f
	v_dual_mul_f32 v33, v40, v53 :: v_dual_mul_f32 v32, v89, v52 ; c8c66b28 21206959
	v_dual_mul_f32 v107, v2, v55 :: v_dual_mul_f32 v106, v19, v54 ; c8c66f02 6b6a6d13
	v_dual_mul_f32 v81, v37, v53 :: v_dual_mul_f32 v80, v36, v52 ; c8c66b25 51506924
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mul_f32 v37, v47, v57 :: v_dual_mul_f32 v36, v46, v56 ; c8c6732f 2524712e
	v_dual_mul_f32 v109, v34, v57 :: v_dual_mul_f32 v108, v9, v56 ; c8c67322 6d6c7109
	v_dual_mul_f32 v35, v175, v55 :: v_dual_mul_f32 v34, v174, v54 ; c8c66faf 23226dae
	v_dual_mul_f32 v101, v129, v57 :: v_dual_mul_f32 v100, v128, v56 ; c8c67381 65647180
	v_dual_mul_f32 v39, v140, v59 :: v_dual_mul_f32 v38, v161, v58 ; c8c6778c 272675a1
	v_dual_mul_f32 v103, v131, v59 :: v_dual_mul_f32 v102, v130, v58 ; c8c67783 67667582
	v_dual_mul_f32 v85, v133, v57 :: v_dual_mul_f32 v84, v132, v56 ; c8c67385 55547184
	v_dual_mul_f32 v87, v135, v59 :: v_dual_mul_f32 v86, v134, v58 ; c8c67787 57567586
	v_dual_mul_f32 v111, v73, v59 :: v_dual_mul_f32 v110, v15, v58 ; c8c67749 6f6e750f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[26:27], v[96:103] ; cc464060 1d823542
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[66:67], v[16:17], v[80:87] ; cc464050 1d422142
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[66:67], v[28:29], v[104:111] ; cc464068 1da23942
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[66:67], v[50:51], v[32:39] ; cc464020 1c826542
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[6:7], v[96:103] ; cc464060 1d820d46
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[70:71], v[4:5], v[80:87] ; cc464050 1d420946
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[10:11], v[104:111] ; cc464068 1da21546
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[70:71], v[12:13], v[32:39] ; cc464020 1c821946
	v_dual_cndmask_b32 v113, v81, v85 :: v_dual_cndmask_b32 v112, v80, v84 ; ca52ab51 7170a950
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_dual_cndmask_b32 v85, v85, v81 :: v_dual_cndmask_b32 v84, v84, v80 ; ca52a355 5554a154
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_dual_cndmask_b32 v115, v83, v87 :: v_dual_cndmask_b32 v114, v82, v86 ; ca52af53 7372ad52
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_cndmask_b32 v87, v87, v83 :: v_dual_cndmask_b32 v86, v86, v82 ; ca52a757 5756a556
	v_add_f32_dpp v85, v85, v113 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06aae2fa ff0cb155
	v_add_f32_dpp v84, v84, v112 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06a8e0fa ff0cb154
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_add_f32_dpp v87, v87, v115 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06aee6fa ff0cb157
	v_add_f32_dpp v86, v86, v114 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ace4fa ff0cb156
	s_movk_i32 s50, 0x100                                       ; b0320100
	v_cvt_f16_f32_e32 v119, v85                                 ; 7eee1555
	v_cvt_f16_f32_e32 v118, v84                                 ; 7eec1554
	s_add_co_u32 s38, s38, s50                                  ; 80263226
	v_cvt_f16_f32_e32 v117, v87                                 ; 7eea1557
	v_cndmask_b32_e64 v87, v87, v85, s35                        ; d5010057 008eab57
	v_cvt_f16_f32_e32 v116, v86                                 ; 7ee81556
	v_cndmask_b32_e64 v86, v86, v84, s35                        ; d5010056 008ea956
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s38, s6, s38                                   ; 80262606
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v124, v42, s38, s39                              ; d655007c 009c4d2a
	v_cndmask_b32_e64 v120, v118, v116, s35                     ; d5010078 008ee976
	v_cndmask_b16 v120, v119, v117, s35                         ; d65d4078 008eeb77
	v_cvt_f16_f32_dpp v121, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7ef214fa ff0d6456
(invalid instruction)                                        ; 7ff214fa
(invalid instruction)                                        ; ff0d6457
	v_add3_u32 v124, v0, v124, v48                              ; d655007c 04c2f900
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f0078
	v_min_num_f64_e32 v[1:2], v[120:121], v[121:122]            ; 1a02f378
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v122, s40, v120, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20107a 9202f028
	v_fma_mix_f32 v120, s40, v120, neg(0) op_sel_hi:[0,1,0]     ; cc200078 9202f028
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d769007b
	v_cndmask_b32_e32 v1, v120, v122, vcc_lo                    ; 0202f578
	buffer_store_b16 v123, v124, s[28:31], null offen           ; c406407c 4080387b 0000007c
	v_add3_u32 v125, v3, s43, s50                               ; d655007d 00c85703
	v_add_nc_u32_e32 v125, v125, v1                             ; 4afa037d
	buffer_store_b64 v[4:5], v125, s[24:27], null offen         ; c406c07c 40803004 0000007d
	v_dual_cndmask_b32 v127, v97, v101 :: v_dual_cndmask_b32 v126, v96, v100 ; ca52cb61 7f7ec960
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_cndmask_b32 v101, v101, v97 :: v_dual_cndmask_b32 v100, v100, v96 ; ca52c365 6564c164
	v_dual_cndmask_b32 v129, v99, v103 :: v_dual_cndmask_b32 v128, v98, v102 ; ca52cf63 8180cd62
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_cndmask_b32 v103, v103, v99 :: v_dual_cndmask_b32 v102, v102, v98 ; ca52c767 6766c566
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v101, v101, v127 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cafefa ff0cb165
	v_add_f32_dpp v100, v100, v126 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06c8fcfa ff0cb164
	v_add_f32_dpp v102, v102, v128 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cd00fa ff0cb166
	v_add_f32_dpp v103, v103, v129 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cf02fa ff0cb167
	s_add_co_u32 s36, s36, s50                                  ; 80243224
(invalid instruction)                                        ; d58a0085
	v_cndmask_b32_e32 v0, v101, v128, vcc_lo                    ; 02010165
(invalid instruction)                                        ; d58a0084
	v_cndmask_b32_e32 v0, v100, v128, vcc_lo                    ; 02010164
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s36, s6, s36                                   ; 80242406
(invalid instruction)                                        ; d58a0082
	v_cndmask_b32_e32 v0, v102, v128, vcc_lo                    ; 02010166
	v_cndmask_b32_e64 v102, v102, v100, s35                     ; d5010066 008ec966
(invalid instruction)                                        ; d58a0083
	v_cndmask_b32_e32 v0, v103, v128, vcc_lo                    ; 02010167
	v_cndmask_b32_e64 v103, v103, v101, s35                     ; d5010067 008ecb67
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v138, v42, s36, s5                               ; d655008a 0014492a
	v_cndmask_b32_e64 v134, v132, v130, s35                     ; d5010086 008f0584
(invalid instruction)                                        ; d58a0087
	v_cndmask_b32_dpp v0, v102, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6466
	v_cndmask_b16 v134, v133, v131, s35                         ; d65d4086 008f0785
(invalid instruction)                                        ; d58a4087
	v_cndmask_b32_dpp v0, v103, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6467
	v_add3_u32 v138, v0, v138, v48                              ; d655008a 04c31500
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f0086
	v_min_num_f64_e32 v[1:2], v[134:135], v[135:136]            ; 1a030f86
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v136, s40, v134, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201088 92030c28
	v_fma_mix_f32 v134, s40, v134, neg(0) op_sel_hi:[0,1,0]     ; cc200086 92030c28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690089
	v_cndmask_b32_e32 v1, v134, v136, vcc_lo                    ; 02031186
	buffer_store_b16 v137, v138, s[28:31], null offen           ; c406407c 40803889 0000008a
	v_add3_u32 v139, v3, s42, s50                               ; d655008b 00c85503
	v_add_nc_u32_e32 v139, v139, v1                             ; 4b16038b
	buffer_store_b64 v[4:5], v139, s[24:27], null offen         ; c406c07c 40803004 0000008b
	v_dual_cndmask_b32 v141, v105, v109 :: v_dual_cndmask_b32 v140, v104, v108 ; ca52db69 8d8cd968
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_dual_cndmask_b32 v109, v109, v105 :: v_dual_cndmask_b32 v108, v108, v104 ; ca52d36d 6d6cd16c
	v_dual_cndmask_b32 v143, v107, v111 :: v_dual_cndmask_b32 v142, v106, v110 ; ca52df6b 8f8edd6a
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_cndmask_b32 v111, v111, v107 :: v_dual_cndmask_b32 v110, v110, v106 ; ca52d76f 6f6ed56e
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v109, v109, v141 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06db1afa ff0cb16d
	v_add_f32_dpp v108, v108, v140 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06d918fa ff0cb16c
	v_add_f32_dpp v110, v110, v142 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06dd1cfa ff0cb16e
	v_add_f32_dpp v111, v111, v143 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06df1efa ff0cb16f
	s_add_co_u32 s37, s37, s50                                  ; 80253225
(invalid instruction)                                        ; d58a0093
	v_cndmask_b32_e32 v0, v109, v128, vcc_lo                    ; 0201016d
(invalid instruction)                                        ; d58a0092
	v_cndmask_b32_e32 v0, v108, v128, vcc_lo                    ; 0201016c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s6, s37                                   ; 80252506
(invalid instruction)                                        ; d58a0090
	v_cndmask_b32_e32 v0, v110, v128, vcc_lo                    ; 0201016e
	v_cndmask_b32_e64 v110, v110, v108, s35                     ; d501006e 008ed96e
(invalid instruction)                                        ; d58a0091
	v_cndmask_b32_e32 v0, v111, v128, vcc_lo                    ; 0201016f
	v_cndmask_b32_e64 v111, v111, v109, s35                     ; d501006f 008edb6f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v152, v42, s37, s4                               ; d6550098 00104b2a
	v_cndmask_b32_e64 v148, v146, v144, s35                     ; d5010094 008f2192
(invalid instruction)                                        ; d58a0095
	v_cndmask_b32_dpp v0, v110, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d646e
	v_cndmask_b16 v148, v147, v145, s35                         ; d65d4094 008f2393
(invalid instruction)                                        ; d58a4095
	v_cndmask_b32_dpp v0, v111, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d646f
	v_add3_u32 v152, v0, v152, v48                              ; d6550098 04c33100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f0094
	v_min_num_f64_e32 v[1:2], v[148:149], v[149:150]            ; 1a032b94
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v150, s40, v148, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201096 92032828
	v_fma_mix_f32 v148, s40, v148, neg(0) op_sel_hi:[0,1,0]     ; cc200094 92032828
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690097
	v_cndmask_b32_e32 v1, v148, v150, vcc_lo                    ; 02032d94
	buffer_store_b16 v151, v152, s[28:31], null offen           ; c406407c 40803897 00000098
	v_add3_u32 v153, v3, s48, s50                               ; d6550099 00c86103
	v_add_nc_u32_e32 v153, v153, v1                             ; 4b320399
	buffer_store_b64 v[4:5], v153, s[24:27], null offen         ; c406c07c 40803004 00000099
	v_dual_cndmask_b32 v155, v33, v37 :: v_dual_cndmask_b32 v154, v32, v36 ; ca524b21 9b9a4920
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
	v_dual_cndmask_b32 v37, v37, v33 :: v_dual_cndmask_b32 v36, v36, v32 ; ca524325 25244124
	v_dual_cndmask_b32 v157, v35, v39 :: v_dual_cndmask_b32 v156, v34, v38 ; ca524f23 9d9c4d22
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	v_dual_cndmask_b32 v39, v39, v35 :: v_dual_cndmask_b32 v38, v38, v34 ; ca524727 27264526
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v37, v37, v155 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064b36fa ff0cb125
	v_add_f32_dpp v36, v36, v154 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064934fa ff0cb124
	v_add_f32_dpp v38, v38, v156 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064d38fa ff0cb126
	v_add_f32_dpp v39, v39, v157 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064f3afa ff0cb127
	s_add_co_u32 s46, s46, s50                                  ; 802e322e
(invalid instruction)                                        ; d58a00a1
	v_cndmask_b32_e32 v0, v37, v128, vcc_lo                     ; 02010125
(invalid instruction)                                        ; d58a00a0
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s46                                    ; 80062e06
(invalid instruction)                                        ; d58a009e
	v_cndmask_b32_e32 v0, v38, v128, vcc_lo                     ; 02010126
	v_cndmask_b32_e64 v38, v38, v36, s35                        ; d5010026 008e4926
(invalid instruction)                                        ; d58a009f
	v_cndmask_b32_e32 v0, v39, v128, vcc_lo                     ; 02010127
	v_cndmask_b32_e64 v39, v39, v37, s35                        ; d5010027 008e4b27
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v42, v42, s6, s34                                ; d655002a 00880d2a
	v_cndmask_b32_e64 v162, v160, v158, s35                     ; d50100a2 008f3da0
(invalid instruction)                                        ; d58a00a3
	v_cndmask_b32_dpp v0, v38, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6426
	v_cndmask_b16 v162, v161, v159, s35                         ; d65d40a2 008f3fa1
(invalid instruction)                                        ; d58a40a3
	v_cndmask_b32_dpp v0, v39, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6427
	v_add3_u32 v0, v0, v42, v48                                 ; d6550000 04c25500
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[162:163], v[163:164]            ; 1a0347a2
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v164, s40, v162, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc2010a4 92034428
	v_fma_mix_f32 v162, s40, v162, neg(0) op_sel_hi:[0,1,0]     ; cc2000a2 92034428
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d76900a5
	v_cndmask_b32_e32 v1, v162, v164, vcc_lo                    ; 020349a2
	buffer_store_b16 v165, v0, s[28:31], null offen             ; c406407c 408038a5 00000000
	v_add3_u32 v3, v3, s2, s50                                  ; d6550003 00c80503
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	buffer_store_b64 v[4:5], v3, s[24:27], null offen           ; c406c07c 40803004 00000003
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
