BB0:
	v_and_b32_e32 v1, 7, v0                                     ; 36020087
	v_lshrrev_b32_e32 v0, 10, v0                                ; 3200008a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshl_add_u32 v1, ttmp9, 3, v1                             ; d6460001 04050675
	v_lshl_add_u32 v0, ttmp7, 3, v0                             ; d6460000 04010673
	v_cmp_le_i32_e32 vcc_lo, s1, v1                             ; 7c860201
(invalid instruction)                                        ; d4430002
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                        ; 02020002
	s_nor_b32 exec_lo, vcc_lo, s2                               ; 8f7e026a
	s_cbranch_execz BB9                                         ; bfa500e5
BB1:
	s_add_co_u32 s3, s3, -1                                     ; 8003c103
	s_add_co_u32 s4, s4, -1                                     ; 8004c104
	s_cmp_eq_i32 s5, 0                                          ; bf008005
	s_cbranch_scc0 BB3                                          ; bfa100b0
BB2:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b256 s[8:15], s[6:7], 0x0                            ; f4006203 f8000000
	v_lshlrev_b32_e32 v2, 2, v1                                 ; 30040282
	v_lshlrev_b32_e32 v4, 2, v0                                 ; 30080082
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v7, 2, v2                                  ; 4a0e0482
	v_add_nc_u32_e32 v6, 1, v2                                  ; 4a0c0481
	v_maxmin_i32 v3, 0, v2, s3                                  ; d6640003 000e0480
	v_add_nc_u32_e32 v2, 3, v2                                  ; 4a040483
	v_add_nc_u32_e32 v9, 2, v4                                  ; 4a120882
	v_add_nc_u32_e32 v8, 1, v4                                  ; 4a100881
	v_maxmin_i32 v5, 0, v4, s4                                  ; d6640005 00120880
	v_add_nc_u32_e32 v4, 3, v4                                  ; 4a080883
	v_maxmin_i32 v7, 0, v7, s3                                  ; d6640007 000e0e80
	v_maxmin_i32 v6, 0, v6, s3                                  ; d6640006 000e0c80
	v_maxmin_i32 v2, 0, v2, s3                                  ; d6640002 000e0480
	v_maxmin_i32 v9, 0, v9, s4                                  ; d6640009 00121280
	v_maxmin_i32 v8, 0, v8, s4                                  ; d6640008 00121080
	v_maxmin_i32 v4, 0, v4, s4                                  ; d6640004 00120880
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0xf                                                ; bf85000f
	image_load v[10:12], [v3, v5], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 0000100a 00000503
	image_load v[13:15], [v6, v5], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 0000100d 00000506
	image_load v[16:18], [v7, v5], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 00001010 00000507
	image_load v[19:21], [v2, v5], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 00001013 00000502
	image_load v[22:24], [v3, v8], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 00001016 00000803
	image_load v[25:27], [v6, v8], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 00001019 00000806
	image_load v[28:30], [v7, v8], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 0000101c 00000807
	image_load v[31:33], [v2, v8], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 0000101f 00000802
	image_load v[34:36], [v3, v9], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 00001022 00000903
	image_load v[37:39], [v6, v9], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 00001025 00000906
	image_load v[40:42], [v7, v9], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 00001028 00000907
	image_load v[43:45], [v2, v9], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 0000102b 00000902
	image_load v[46:48], [v3, v4], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 0000102e 00000403
	image_load v[49:51], [v6, v4], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 00001031 00000406
	image_load v[52:54], [v7, v4], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 00001034 00000407
	image_load v[55:57], [v2, v4], s[8:15] dmask:0x7 dim:SQ_RSRC_IMG_2D ; d1c00001 00001037 00000402
	s_mov_b32 s1, 0x3f371759                                    ; be8100ff 3f371759
	s_mov_b32 s2, 0x3d93dd98                                    ; be8200ff 3d93dd98
	s_mov_b32 s3, 0x3e59b3d0                                    ; be8300ff 3e59b3d0
	s_wait_loadcnt 0xe                                          ; bfc0000e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_mul_f32_e32 v14, s1, v14                                  ; 101c1c01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s2, v15                                 ; 561c1e02
	v_fmac_f32_e32 v14, s3, v13                                 ; 561c1a03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s2, v12                                 ; 561c1802
	v_fmac_f32_e32 v14, s1, v11                                 ; 561c1601
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fmac_f32_e32 v14, s3, v10                                 ; 561c1403
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_fmac_f32_e32 v14, s2, v18                                 ; 561c2402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s1, v17                                 ; 561c2201
	v_fmac_f32_e32 v14, s3, v16                                 ; 561c2003
	s_wait_loadcnt 0xc                                          ; bfc0000c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s2, v21                                 ; 561c2a02
	v_fmac_f32_e32 v14, s1, v20                                 ; 561c2801
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fmac_f32_e32 v14, s3, v19                                 ; 561c2603
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fmac_f32_e32 v14, s2, v24                                 ; 561c3002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s1, v23                                 ; 561c2e01
	v_fmac_f32_e32 v14, s3, v22                                 ; 561c2c03
	s_wait_loadcnt 0xa                                          ; bfc0000a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s2, v27                                 ; 561c3602
	v_fmac_f32_e32 v14, s1, v26                                 ; 561c3401
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fmac_f32_e32 v14, s3, v25                                 ; 561c3203
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fmac_f32_e32 v14, s2, v30                                 ; 561c3c02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s1, v29                                 ; 561c3a01
	v_fmac_f32_e32 v14, s3, v28                                 ; 561c3803
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s2, v33                                 ; 561c4202
	v_fmac_f32_e32 v14, s1, v32                                 ; 561c4001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fmac_f32_e32 v14, s3, v31                                 ; 561c3e03
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fmac_f32_e32 v14, s2, v36                                 ; 561c4802
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s1, v35                                 ; 561c4601
	v_fmac_f32_e32 v14, s3, v34                                 ; 561c4403
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s2, v39                                 ; 561c4e02
	v_fmac_f32_e32 v14, s1, v38                                 ; 561c4c01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fmac_f32_e32 v14, s3, v37                                 ; 561c4a03
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fmac_f32_e32 v14, s2, v42                                 ; 561c5402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s1, v41                                 ; 561c5201
	v_fmac_f32_e32 v14, s3, v40                                 ; 561c5003
	s_wait_loadcnt 0x4                                          ; bfc00004
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s2, v45                                 ; 561c5a02
	v_fmac_f32_e32 v14, s1, v44                                 ; 561c5801
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fmac_f32_e32 v14, s3, v43                                 ; 561c5603
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fmac_f32_e32 v14, s2, v48                                 ; 561c6002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s1, v47                                 ; 561c5e01
	v_fmac_f32_e32 v14, s3, v46                                 ; 561c5c03
	s_wait_loadcnt 0x2                                          ; bfc00002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s2, v51                                 ; 561c6602
	v_fmac_f32_e32 v14, s1, v50                                 ; 561c6401
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fmac_f32_e32 v14, s3, v49                                 ; 561c6203
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fmac_f32_e32 v14, s2, v54                                 ; 561c6c02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s1, v53                                 ; 561c6a01
	v_fmac_f32_e32 v14, s3, v52                                 ; 561c6803
	s_wait_loadcnt 0x0                                          ; bfc00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s2, v57                                 ; 561c7202
	v_fmac_f32_e32 v14, s1, v56                                 ; 561c7001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v14, s3, v55                                 ; 561c6e03
	v_mul_f32_e32 v14, 0x3d800000, v14                          ; 101c1cff 3d800000
	s_branch BB4                                                ; bfa0002a
BB3:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b256 s[8:15], s[6:7], 0x40                           ; f4006203 f8000040
	v_lshlrev_b32_e32 v2, 1, v1                                 ; 30040281
	v_lshlrev_b32_e32 v4, 1, v0                                 ; 30080081
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
	v_maxmin_i32 v3, 0, v2, s3                                  ; d6640003 000e0480
	v_add_nc_u32_e32 v2, 1, v2                                  ; 4a040481
	v_maxmin_i32 v5, 0, v4, s4                                  ; d6640005 00120880
	v_add_nc_u32_e32 v4, 1, v4                                  ; 4a080881
	v_maxmin_i32 v2, 0, v2, s3                                  ; d6640002 000e0480
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_maxmin_i32 v4, 0, v4, s4                                  ; d6640004 00120880
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	image_load v6, [v3, v5], s[8:15] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00001006 00000503
	image_load v5, [v2, v5], s[8:15] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00001005 00000502
	image_load v3, [v3, v4], s[8:15] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00001003 00000403
	image_load v2, [v2, v4], s[8:15] dmask:0x1 dim:SQ_RSRC_IMG_2D ; d0400001 00001002 00000402
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_add_f32_e32 v6, v6, v5                                    ; 060c0b06
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f32_e32 v6, v6, v3                                    ; 060c0706
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_add_f32_e32 v6, v6, v2                                    ; 060c0506
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v14, 0x3e800000, v6                           ; 101c0cff 3e800000
BB4:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b256 s[0:7], s[0:1], 0x60                            ; f4006000 f8000060
	s_wait_kmcnt 0x0                                            ; bfc70000
	image_store v14, v1, s[0:7] dmask:0x1 dim:SQ_RSRC_IMG_2D    ; d0418001 0000000e 00000001
BB9:
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
