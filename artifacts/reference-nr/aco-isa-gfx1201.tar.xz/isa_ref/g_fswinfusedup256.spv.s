BB0:
	s_mov_b32 s10, s1                                           ; be8a0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_clause 0x3                                                ; bf850003
	s_load_b128 s[12:15], s[0:1], 0x0                           ; f4004300 f8000000
	s_load_b128 s[16:19], s[10:11], 0x34                        ; f4004405 f8000034
	s_load_b64 s[20:21], s[10:11], 0x68                         ; f4002505 f8000068
	s_load_b64 s[22:23], s[10:11], 0x50                         ; f4002585 f8000050
	v_and_b32_e32 v1, 3, v0                                     ; 36020083
	v_and_b32_e32 v2, 15, v0                                    ; 3604008f
	v_and_b32_e32 v4, 31, v0                                    ; 3608009f
	s_pack_ll_b32_b16 s24, ttmp7, 0                             ; 99188073
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_lshrrev_b32_e32 v3, 2, v2                                 ; 32060482
	v_lshrrev_b32_e32 v5, 4, v4                                 ; 320a0884
	v_lshlrev_b32_e32 v5, 3, v5                                 ; 300a0a83
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s25, s18, 1                                      ; 84198112
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_lshl2_add_u32 s25, ttmp9, s25                             ; 87991975
	s_lshl_b32 s26, s19, 1                                      ; 841a8113
	v_add_nc_u32_e32 v6, s25, v1                                ; 4a0c0219
	s_lshl2_add_u32 s26, s24, s26                               ; 879a1a18
	s_lshl2_add_u32 s27, s20, -1                                ; 879bc114
	s_lshl2_add_u32 s21, s21, -1                                ; 8795c115
	s_and_b32 s28, s22, -4                                      ; 8b1cc416
	v_add_nc_u32_e32 v3, s26, v3                                ; 4a06061a
	v_maxmin_i32 v6, 0, v6, s27                                 ; d6640006 006e0c80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_maxmin_i32 v3, 0, v3, s21                                 ; d6640003 00560680
	v_lshrrev_b32_e32 v8, 2, v6                                 ; 32100c82
	v_and_b32_e32 v6, 3, v6                                     ; 360c0c83
	v_lshrrev_b32_e32 v7, 2, v3                                 ; 320e0682
	v_and_b32_e32 v3, 3, v3                                     ; 36060683
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d72c0007
	v_cndmask_b32_e32 v0, v7, v20, vcc_lo                       ; 02002907
	v_lshl_add_u32 v3, v3, 2, v6                                ; d6460003 04190503
	v_lshlrev_b32_e32 v3, 4, v3                                 ; 30060684
	v_add_lshl_u32 v7, v7, v8, 13                               ; d6470007 02361107
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v16, 0x400, v7                             ; 4a200eff 00000400
	v_add3_u32 v9, v3, s28, v7                                  ; d6550009 041c3903
	v_add_nc_u32_e32 v12, 0x200, v7                             ; 4a180eff 00000200
	v_add_nc_u32_e32 v10, 0x100, v7                             ; 4a140eff 00000100
	v_add_nc_u32_e32 v14, 0x300, v7                             ; 4a1c0eff 00000300
	v_add_nc_u32_e32 v18, 0x500, v7                             ; 4a240eff 00000500
	v_add3_u32 v17, v3, s22, v16                                ; d6550011 04402d03
	v_add3_u32 v16, v3, s28, v16                                ; d6550010 04403903
	v_add_nc_u32_e32 v9, v9, v5                                 ; 4a120b09
	v_add_nc_u32_e32 v20, 0x600, v7                             ; 4a280eff 00000600
	v_add3_u32 v13, v3, s22, v12                                ; d655000d 04302d03
	v_add3_u32 v12, v3, s28, v12                                ; d655000c 04303903
	v_add3_u32 v11, v3, s22, v10                                ; d655000b 04282d03
	v_add3_u32 v10, v3, s28, v10                                ; d655000a 04283903
	v_add3_u32 v15, v3, s22, v14                                ; d655000f 04382d03
	v_add3_u32 v14, v3, s28, v14                                ; d655000e 04383903
	v_add_nc_u32_e32 v22, 0x700, v7                             ; 4a2c0eff 00000700
	v_add3_u32 v19, v3, s22, v18                                ; d6550013 04482d03
	v_add3_u32 v18, v3, s28, v18                                ; d6550012 04483903
	v_add_nc_u32_e32 v16, v16, v5                               ; 4a200b10
	v_add_nc_u32_e32 v24, 0x800, v7                             ; 4a300eff 00000800
	v_add3_u32 v21, v3, s22, v20                                ; d6550015 04502d03
	v_add3_u32 v20, v3, s28, v20                                ; d6550014 04503903
	v_add_nc_u32_e32 v12, v12, v5                               ; 4a180b0c
	v_add_nc_u32_e32 v10, v10, v5                               ; 4a140b0a
	v_add_nc_u32_e32 v26, 0x900, v7                             ; 4a340eff 00000900
	v_add_nc_u32_e32 v14, v14, v5                               ; 4a1c0b0e
	v_add3_u32 v23, v3, s22, v22                                ; d6550017 04582d03
	v_add3_u32 v22, v3, s28, v22                                ; d6550016 04583903
	v_add_nc_u32_e32 v28, 0xa00, v7                             ; 4a380eff 00000a00
	v_add_nc_u32_e32 v18, v18, v5                               ; 4a240b12
	v_add3_u32 v25, v3, s22, v24                                ; d6550019 04602d03
	v_add3_u32 v24, v3, s28, v24                                ; d6550018 04603903
	v_add_nc_u32_e32 v30, 0xb00, v7                             ; 4a3c0eff 00000b00
	v_add_nc_u32_e32 v20, v20, v5                               ; 4a280b14
	v_add3_u32 v27, v3, s22, v26                                ; d655001b 04682d03
	v_add3_u32 v26, v3, s28, v26                                ; d655001a 04683903
	v_add_nc_u32_e32 v32, 0xc00, v7                             ; 4a400eff 00000c00
	v_add_nc_u32_e32 v22, v22, v5                               ; 4a2c0b16
	v_add3_u32 v29, v3, s22, v28                                ; d655001d 04702d03
	v_add3_u32 v28, v3, s28, v28                                ; d655001c 04703903
	v_add_nc_u32_e32 v34, 0xd00, v7                             ; 4a440eff 00000d00
	v_add_nc_u32_e32 v24, v24, v5                               ; 4a300b18
	v_add3_u32 v31, v3, s22, v30                                ; d655001f 04782d03
	v_add3_u32 v30, v3, s28, v30                                ; d655001e 04783903
	v_add_nc_u32_e32 v36, 0xe00, v7                             ; 4a480eff 00000e00
	v_add_nc_u32_e32 v26, v26, v5                               ; 4a340b1a
	v_add3_u32 v33, v3, s22, v32                                ; d6550021 04802d03
	v_add3_u32 v32, v3, s28, v32                                ; d6550020 04803903
	v_add_nc_u32_e32 v38, 0xf00, v7                             ; 4a4c0eff 00000f00
	v_add_nc_u32_e32 v28, v28, v5                               ; 4a380b1c
	v_add_nc_u32_e32 v40, 0x1000, v7                            ; 4a500eff 00001000
	v_add3_u32 v35, v3, s22, v34                                ; d6550023 04882d03
	v_add3_u32 v34, v3, s28, v34                                ; d6550022 04883903
	v_add_nc_u32_e32 v30, v30, v5                               ; 4a3c0b1e
	v_add3_u32 v37, v3, s22, v36                                ; d6550025 04902d03
	v_add3_u32 v36, v3, s28, v36                                ; d6550024 04903903
	v_add_nc_u32_e32 v42, 0x1100, v7                            ; 4a540eff 00001100
	v_add_nc_u32_e32 v32, v32, v5                               ; 4a400b20
	v_add_nc_u32_e32 v44, 0x1200, v7                            ; 4a580eff 00001200
	v_add3_u32 v39, v3, s22, v38                                ; d6550027 04982d03
	v_add3_u32 v38, v3, s28, v38                                ; d6550026 04983903
	v_add3_u32 v41, v3, s22, v40                                ; d6550029 04a02d03
	v_add3_u32 v40, v3, s28, v40                                ; d6550028 04a03903
	v_add_nc_u32_e32 v34, v34, v5                               ; 4a440b22
	v_add_nc_u32_e32 v46, 0x1300, v7                            ; 4a5c0eff 00001300
	v_add_nc_u32_e32 v36, v36, v5                               ; 4a480b24
	v_add3_u32 v43, v3, s22, v42                                ; d655002b 04a82d03
	v_add3_u32 v42, v3, s28, v42                                ; d655002a 04a83903
	v_add_nc_u32_e32 v48, 0x1400, v7                            ; 4a600eff 00001400
	v_add3_u32 v45, v3, s22, v44                                ; d655002d 04b02d03
	v_add3_u32 v44, v3, s28, v44                                ; d655002c 04b03903
	v_add_nc_u32_e32 v50, 0x1500, v7                            ; 4a640eff 00001500
	v_add_nc_u32_e32 v38, v38, v5                               ; 4a4c0b26
	v_add_nc_u32_e32 v40, v40, v5                               ; 4a500b28
	v_add3_u32 v47, v3, s22, v46                                ; d655002f 04b82d03
	v_add3_u32 v46, v3, s28, v46                                ; d655002e 04b83903
	v_add_nc_u32_e32 v52, 0x1600, v7                            ; 4a680eff 00001600
	v_add_nc_u32_e32 v42, v42, v5                               ; 4a540b2a
	v_add3_u32 v49, v3, s22, v48                                ; d6550031 04c02d03
	v_add3_u32 v48, v3, s28, v48                                ; d6550030 04c03903
	s_load_b64 s[20:21], s[10:11], 0x74                         ; f4002505 f8000074
	v_add_nc_u32_e32 v54, 0x1700, v7                            ; 4a6c0eff 00001700
	v_add_nc_u32_e32 v44, v44, v5                               ; 4a580b2c
	v_add3_u32 v51, v3, s22, v50                                ; d6550033 04c82d03
	v_add3_u32 v50, v3, s28, v50                                ; d6550032 04c83903
	v_add_nc_u32_e32 v56, 0x1800, v7                            ; 4a700eff 00001800
	v_add_nc_u32_e32 v58, 0x1900, v7                            ; 4a740eff 00001900
	v_add_nc_u32_e32 v46, v46, v5                               ; 4a5c0b2e
	v_add_nc_u32_e32 v60, 0x1a00, v7                            ; 4a780eff 00001a00
	v_add3_u32 v53, v3, s22, v52                                ; d6550035 04d02d03
	v_add3_u32 v52, v3, s28, v52                                ; d6550034 04d03903
	v_add_nc_u32_e32 v62, 0x1b00, v7                            ; 4a7c0eff 00001b00
	v_add_nc_u32_e32 v64, 0x1c00, v7                            ; 4a800eff 00001c00
	v_add_nc_u32_e32 v66, 0x1d00, v7                            ; 4a840eff 00001d00
	v_add_nc_u32_e32 v68, 0x1e00, v7                            ; 4a880eff 00001e00
	v_add_nc_u32_e32 v48, v48, v5                               ; 4a600b30
	v_add3_u32 v70, v3, s22, v7                                 ; d6550046 041c2d03
	v_add3_u32 v55, v3, s22, v54                                ; d6550037 04d82d03
	v_add_nc_u32_e32 v7, 0x1f00, v7                             ; 4a0e0eff 00001f00
	v_add3_u32 v54, v3, s28, v54                                ; d6550036 04d83903
	v_add_nc_u32_e32 v50, v50, v5                               ; 4a640b32
	v_add3_u32 v57, v3, s22, v56                                ; d6550039 04e02d03
	v_add3_u32 v56, v3, s28, v56                                ; d6550038 04e03903
	v_add3_u32 v59, v3, s22, v58                                ; d655003b 04e82d03
	v_add3_u32 v58, v3, s28, v58                                ; d655003a 04e83903
	v_add3_u32 v61, v3, s22, v60                                ; d655003d 04f02d03
	v_add3_u32 v60, v3, s28, v60                                ; d655003c 04f03903
	v_add_nc_u32_e32 v52, v52, v5                               ; 4a680b34
	v_add3_u32 v63, v3, s22, v62                                ; d655003f 04f82d03
	v_add3_u32 v62, v3, s28, v62                                ; d655003e 04f83903
	v_add3_u32 v65, v3, s22, v64                                ; d6550041 05002d03
	v_add3_u32 v64, v3, s28, v64                                ; d6550040 05003903
	v_add3_u32 v67, v3, s22, v66                                ; d6550043 05082d03
	v_add3_u32 v66, v3, s28, v66                                ; d6550042 05083903
	v_add3_u32 v69, v3, s22, v68                                ; d6550045 05102d03
	v_add3_u32 v68, v3, s28, v68                                ; d6550044 05103903
	v_add_nc_u32_e32 v54, v54, v5                               ; 4a6c0b36
	v_add3_u32 v71, v3, s22, v7                                 ; d6550047 041c2d03
	v_add3_u32 v3, v3, s28, v7                                  ; d6550003 041c3903
	v_add_nc_u32_e32 v56, v56, v5                               ; 4a700b38
	v_add_nc_u32_e32 v58, v58, v5                               ; 4a740b3a
	v_add_nc_u32_e32 v60, v60, v5                               ; 4a780b3c
	s_clause 0x9                                                ; bf850009
	buffer_load_b96 v[72:74], v9, s[12:15], null offen          ; c405807c 40801848 00000009
	buffer_load_b96 v[75:77], v10, s[12:15], null offen         ; c405807c 4080184b 0000000a
	buffer_load_b96 v[78:80], v12, s[12:15], null offen         ; c405807c 4080184e 0000000c
	buffer_load_b96 v[81:83], v14, s[12:15], null offen         ; c405807c 40801851 0000000e
	buffer_load_b96 v[84:86], v16, s[12:15], null offen         ; c405807c 40801854 00000010
	buffer_load_b96 v[87:89], v18, s[12:15], null offen         ; c405807c 40801857 00000012
	buffer_load_b96 v[90:92], v20, s[12:15], null offen         ; c405807c 4080185a 00000014
	buffer_load_b96 v[93:95], v22, s[12:15], null offen         ; c405807c 4080185d 00000016
	buffer_load_b96 v[96:98], v24, s[12:15], null offen         ; c405807c 40801860 00000018
	buffer_load_b96 v[99:101], v26, s[12:15], null offen        ; c405807c 40801863 0000001a
	s_load_b128 s[28:31], s[0:1], 0x20                          ; f4004700 f8000020
	v_add_nc_u32_e32 v62, v62, v5                               ; 4a7c0b3e
	v_add_nc_u32_e32 v64, v64, v5                               ; 4a800b40
	v_add_nc_u32_e32 v66, v66, v5                               ; 4a840b42
	v_add_nc_u32_e32 v68, v68, v5                               ; 4a880b44
	v_add_nc_u32_e32 v3, v3, v5                                 ; 4a060b03
	s_clause 0x15                                               ; bf850015
	buffer_load_b96 v[102:104], v28, s[12:15], null offen       ; c405807c 40801866 0000001c
	buffer_load_b96 v[105:107], v30, s[12:15], null offen       ; c405807c 40801869 0000001e
	buffer_load_b96 v[108:110], v32, s[12:15], null offen       ; c405807c 4080186c 00000020
	buffer_load_b96 v[111:113], v34, s[12:15], null offen       ; c405807c 4080186f 00000022
	buffer_load_b96 v[114:116], v36, s[12:15], null offen       ; c405807c 40801872 00000024
	buffer_load_b96 v[117:119], v38, s[12:15], null offen       ; c405807c 40801875 00000026
	buffer_load_b96 v[120:122], v40, s[12:15], null offen       ; c405807c 40801878 00000028
	buffer_load_b96 v[123:125], v42, s[12:15], null offen       ; c405807c 4080187b 0000002a
	buffer_load_b96 v[126:128], v44, s[12:15], null offen       ; c405807c 4080187e 0000002c
	buffer_load_b96 v[129:131], v46, s[12:15], null offen       ; c405807c 40801881 0000002e
	buffer_load_b96 v[132:134], v48, s[12:15], null offen       ; c405807c 40801884 00000030
	buffer_load_b96 v[135:137], v50, s[12:15], null offen       ; c405807c 40801887 00000032
	buffer_load_b96 v[138:140], v52, s[12:15], null offen       ; c405807c 4080188a 00000034
	buffer_load_b96 v[141:143], v54, s[12:15], null offen       ; c405807c 4080188d 00000036
	buffer_load_b96 v[144:146], v56, s[12:15], null offen       ; c405807c 40801890 00000038
	buffer_load_b96 v[147:149], v58, s[12:15], null offen       ; c405807c 40801893 0000003a
	buffer_load_b96 v[150:152], v60, s[12:15], null offen       ; c405807c 40801896 0000003c
	buffer_load_b96 v[153:155], v62, s[12:15], null offen       ; c405807c 40801899 0000003e
	buffer_load_b96 v[156:158], v64, s[12:15], null offen       ; c405807c 4080189c 00000040
	buffer_load_b96 v[159:161], v66, s[12:15], null offen       ; c405807c 4080189f 00000042
	buffer_load_b96 v[162:164], v68, s[12:15], null offen       ; c405807c 408018a2 00000044
	buffer_load_b96 v[165:167], v3, s[12:15], null offen        ; c405807c 408018a5 00000003
(invalid instruction)                                        ; d71f00aa
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_lshrrev_b32_e32 v168, 5, v0                               ; 33500085
	v_add_nc_u32_e32 v70, v70, v5                               ; 4a8c0b46
	v_add_nc_u32_e32 v11, v11, v5                               ; 4a160b0b
	v_add_nc_u32_e32 v13, v13, v5                               ; 4a1a0b0d
	v_add_nc_u32_e32 v15, v15, v5                               ; 4a1e0b0f
	v_add_nc_u32_e32 v17, v17, v5                               ; 4a220b11
	v_add_nc_u32_e32 v19, v19, v5                               ; 4a260b13
	v_add_nc_u32_e32 v21, v21, v5                               ; 4a2a0b15
	v_add_nc_u32_e32 v23, v23, v5                               ; 4a2e0b17
	v_add_nc_u32_e32 v25, v25, v5                               ; 4a320b19
	v_add_nc_u32_e32 v27, v27, v5                               ; 4a360b1b
	v_add_nc_u32_e32 v29, v29, v5                               ; 4a3a0b1d
	v_add_nc_u32_e32 v31, v31, v5                               ; 4a3e0b1f
	v_and_b32_e32 v171, 15, v170                                ; 3757548f
	v_add_nc_u32_e32 v33, v33, v5                               ; 4a420b21
	v_lshrrev_b32_e32 v170, 4, v170                             ; 33555484
	v_add_nc_u32_e32 v35, v35, v5                               ; 4a460b23
	v_lshlrev_b32_e32 v169, 14, v168                            ; 3153508e
	v_add_nc_u32_e32 v37, v37, v5                               ; 4a4a0b25
	v_lshlrev_b32_e32 v172, 4, v171                             ; 31595684
	v_lshlrev_b32_e32 v170, 3, v170                             ; 31555483
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add3_u32 v177, s21, 0x400, v169                           ; d65500b1 06a5fe15 00000400
	v_add3_u32 v180, s21, 0x700, v169                           ; d65500b4 06a5fe15 00000700
	v_add3_u32 v176, s21, 0x300, v169                           ; d65500b0 06a5fe15 00000300
	v_add3_u32 v174, s21, 0x100, v169                           ; d65500ae 06a5fe15 00000100
	v_add3_u32 v179, s21, 0x600, v169                           ; d65500b3 06a5fe15 00000600
	v_add3_u32 v178, s21, 0x500, v169                           ; d65500b2 06a5fe15 00000500
	v_add3_u32 v175, s21, 0x200, v169                           ; d65500af 06a5fe15 00000200
	v_add3_u32 v181, s21, 0x800, v169                           ; d65500b5 06a5fe15 00000800
	v_add3_u32 v173, v172, s21, v169                            ; d65500ad 06a42bac
	v_add3_u32 v182, s21, 0x900, v169                           ; d65500b6 06a5fe15 00000900
	v_add3_u32 v183, s21, 0xa00, v169                           ; d65500b7 06a5fe15 00000a00
	v_add3_u32 v177, v170, v177, v172                           ; d65500b1 06b363aa
	v_add3_u32 v180, v170, v180, v172                           ; d65500b4 06b369aa
	v_add3_u32 v184, s21, 0xb00, v169                           ; d65500b8 06a5fe15 00000b00
	v_add3_u32 v176, v170, v176, v172                           ; d65500b0 06b361aa
	v_add3_u32 v185, s21, 0xc00, v169                           ; d65500b9 06a5fe15 00000c00
	v_add3_u32 v174, v170, v174, v172                           ; d65500ae 06b35daa
	v_add3_u32 v179, v170, v179, v172                           ; d65500b3 06b367aa
	v_add3_u32 v178, v170, v178, v172                           ; d65500b2 06b365aa
	v_add3_u32 v186, s21, 0xd00, v169                           ; d65500ba 06a5fe15 00000d00
	v_add3_u32 v175, v170, v175, v172                           ; d65500af 06b35faa
	v_add3_u32 v187, s21, 0xe00, v169                           ; d65500bb 06a5fe15 00000e00
	v_add3_u32 v181, v170, v181, v172                           ; d65500b5 06b36baa
	v_add_nc_u32_e32 v173, v173, v170                           ; 4b5b55ad
	v_add3_u32 v182, v170, v182, v172                           ; d65500b6 06b36daa
	v_add3_u32 v188, s21, 0xf00, v169                           ; d65500bc 06a5fe15 00000f00
	v_add3_u32 v183, v170, v183, v172                           ; d65500b7 06b36faa
	v_add3_u32 v189, s21, 0x1000, v169                          ; d65500bd 06a5fe15 00001000
	v_add3_u32 v184, v170, v184, v172                           ; d65500b8 06b371aa
	v_add3_u32 v190, s21, 0x1100, v169                          ; d65500be 06a5fe15 00001100
	v_add3_u32 v191, s21, 0x1200, v169                          ; d65500bf 06a5fe15 00001200
	v_add3_u32 v185, v170, v185, v172                           ; d65500b9 06b373aa
	v_add3_u32 v3, s21, 0x1300, v169                            ; d6550003 06a5fe15 00001300
	v_add3_u32 v6, s21, 0x1400, v169                            ; d6550006 06a5fe15 00001400
	v_add3_u32 v186, v170, v186, v172                           ; d65500ba 06b375aa
	v_add3_u32 v7, s21, 0x1500, v169                            ; d6550007 06a5fe15 00001500
	v_add3_u32 v187, v170, v187, v172                           ; d65500bb 06b377aa
	v_add3_u32 v8, s21, 0x1600, v169                            ; d6550008 06a5fe15 00001600
	v_add3_u32 v9, s21, 0x1700, v169                            ; d6550009 06a5fe15 00001700
	v_add3_u32 v188, v170, v188, v172                           ; d65500bc 06b379aa
	v_add3_u32 v10, s21, 0x1800, v169                           ; d655000a 06a5fe15 00001800
	v_add3_u32 v189, v170, v189, v172                           ; d65500bd 06b37baa
	v_add3_u32 v12, s21, 0x1900, v169                           ; d655000c 06a5fe15 00001900
	v_add3_u32 v190, v170, v190, v172                           ; d65500be 06b37daa
	v_add3_u32 v191, v170, v191, v172                           ; d65500bf 06b37faa
	v_add_nc_u32_e32 v39, v39, v5                               ; 4a4e0b27
	v_add_nc_u32_e32 v41, v41, v5                               ; 4a520b29
	v_add3_u32 v3, v170, v3, v172                               ; d6550003 06b207aa
	v_add_nc_u32_e32 v43, v43, v5                               ; 4a560b2b
	v_add3_u32 v6, v170, v6, v172                               ; d6550006 06b20daa
	v_add_nc_u32_e32 v45, v45, v5                               ; 4a5a0b2d
	v_add_nc_u32_e32 v47, v47, v5                               ; 4a5e0b2f
	v_add3_u32 v7, v170, v7, v172                               ; d6550007 06b20faa
	v_add_nc_u32_e32 v49, v49, v5                               ; 4a620b31
	v_add_nc_u32_e32 v51, v51, v5                               ; 4a660b33
	v_add3_u32 v8, v170, v8, v172                               ; d6550008 06b211aa
	v_add3_u32 v9, v170, v9, v172                               ; d6550009 06b213aa
	v_add_nc_u32_e32 v53, v53, v5                               ; 4a6a0b35
	v_add_nc_u32_e32 v55, v55, v5                               ; 4a6e0b37
	v_add3_u32 v10, v170, v10, v172                             ; d655000a 06b215aa
	v_add_nc_u32_e32 v57, v57, v5                               ; 4a720b39
	v_add_nc_u32_e32 v59, v59, v5                               ; 4a760b3b
	v_add_nc_u32_e32 v61, v61, v5                               ; 4a7a0b3d
	v_add3_u32 v12, v170, v12, v172                             ; d655000c 06b219aa
	v_add_nc_u32_e32 v63, v63, v5                               ; 4a7e0b3f
	v_add_nc_u32_e32 v65, v65, v5                               ; 4a820b41
	v_add_nc_u32_e32 v67, v67, v5                               ; 4a860b43
	v_add_nc_u32_e32 v69, v69, v5                               ; 4a8a0b45
	v_add_nc_u32_e32 v71, v71, v5                               ; 4a8e0b47
	v_add3_u32 v14, s21, 0x1a00, v169                           ; d655000e 06a5fe15 00001a00
	v_add3_u32 v16, s21, 0x1b00, v169                           ; d6550010 06a5fe15 00001b00
	v_add3_u32 v18, s21, 0x1c00, v169                           ; d6550012 06a5fe15 00001c00
	v_add3_u32 v20, s21, 0x1d00, v169                           ; d6550014 06a5fe15 00001d00
	v_add3_u32 v22, s21, 0x1e00, v169                           ; d6550016 06a5fe15 00001e00
	v_add3_u32 v14, v170, v14, v172                             ; d655000e 06b21daa
	v_add3_u32 v16, v170, v16, v172                             ; d6550010 06b221aa
	v_add3_u32 v18, v170, v18, v172                             ; d6550012 06b225aa
	v_add3_u32 v24, s21, 0x1f00, v169                           ; d6550018 06a5fe15 00001f00
	v_add3_u32 v20, v170, v20, v172                             ; d6550014 06b229aa
	v_add3_u32 v22, v170, v22, v172                             ; d6550016 06b22daa
	v_add3_u32 v26, s21, 0x2000, v169                           ; d655001a 06a5fe15 00002000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_add3_u32 v24, v170, v24, v172                             ; d6550018 06b231aa
	v_add3_u32 v26, v170, v26, v172                             ; d655001a 06b235aa
	s_wait_loadcnt 0x1f                                         ; bfc0001f
	v_alignbyte_b32 v72, v73, v72, v70                          ; d6170048 051a9149
	v_alignbyte_b32 v73, v74, v73, v70                          ; d6170049 051a934a
	v_add3_u32 v28, s21, 0x2100, v169                           ; d655001c 06a5fe15 00002100
	s_wait_loadcnt 0x1e                                         ; bfc0001e
	v_alignbyte_b32 v74, v76, v75, v11                          ; d617004a 042e974c
	v_alignbyte_b32 v75, v77, v76, v11                          ; d617004b 042e994d
	s_wait_loadcnt 0x1d                                         ; bfc0001d
	v_alignbyte_b32 v76, v79, v78, v13                          ; d617004c 04369d4f
	v_alignbyte_b32 v77, v80, v79, v13                          ; d617004d 04369f50
	s_wait_loadcnt 0x1c                                         ; bfc0001c
	v_alignbyte_b32 v79, v83, v82, v15                          ; d617004f 043ea553
	v_alignbyte_b32 v78, v82, v81, v15                          ; d617004e 043ea352
	s_wait_loadcnt 0x1b                                         ; bfc0001b
	v_alignbyte_b32 v81, v86, v85, v17                          ; d6170051 0446ab56
	v_alignbyte_b32 v80, v85, v84, v17                          ; d6170050 0446a955
	v_add3_u32 v30, s21, 0x2200, v169                           ; d655001e 06a5fe15 00002200
	s_wait_loadcnt 0x1a                                         ; bfc0001a
	v_alignbyte_b32 v83, v89, v88, v19                          ; d6170053 044eb159
	v_alignbyte_b32 v82, v88, v87, v19                          ; d6170052 044eaf58
	s_wait_loadcnt 0x19                                         ; bfc00019
	v_alignbyte_b32 v85, v92, v91, v21                          ; d6170055 0456b75c
	v_alignbyte_b32 v84, v91, v90, v21                          ; d6170054 0456b55b
	s_wait_loadcnt 0x18                                         ; bfc00018
	v_alignbyte_b32 v87, v95, v94, v23                          ; d6170057 045ebd5f
	v_alignbyte_b32 v86, v94, v93, v23                          ; d6170056 045ebb5e
	v_add3_u32 v28, v170, v28, v172                             ; d655001c 06b239aa
	s_wait_loadcnt 0x17                                         ; bfc00017
	v_alignbyte_b32 v88, v97, v96, v25                          ; d6170058 0466c161
	v_alignbyte_b32 v89, v98, v97, v25                          ; d6170059 0466c362
	s_wait_loadcnt 0x16                                         ; bfc00016
	v_alignbyte_b32 v91, v101, v100, v27                        ; d617005b 046ec965
	v_alignbyte_b32 v90, v100, v99, v27                         ; d617005a 046ec764
	v_add3_u32 v32, s21, 0x2300, v169                           ; d6550020 06a5fe15 00002300
	v_add3_u32 v34, s21, 0x2400, v169                           ; d6550022 06a5fe15 00002400
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_alignbyte_b32 v93, v104, v103, v29                        ; d617005d 0476cf68
	v_alignbyte_b32 v92, v103, v102, v29                        ; d617005c 0476cd67
	v_add3_u32 v30, v170, v30, v172                             ; d655001e 06b23daa
	v_add3_u32 v36, s21, 0x2500, v169                           ; d6550024 06a5fe15 00002500
	s_wait_loadcnt 0x14                                         ; bfc00014
	v_alignbyte_b32 v94, v106, v105, v31                        ; d617005e 047ed36a
	v_alignbyte_b32 v95, v107, v106, v31                        ; d617005f 047ed56b
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_alignbyte_b32 v96, v109, v108, v33                        ; d6170060 0486d96d
	v_alignbyte_b32 v97, v110, v109, v33                        ; d6170061 0486db6e
	v_add3_u32 v38, s21, 0x2600, v169                           ; d6550026 06a5fe15 00002600
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_alignbyte_b32 v98, v112, v111, v35                        ; d6170062 048edf70
	v_alignbyte_b32 v99, v113, v112, v35                        ; d6170063 048ee171
	v_add3_u32 v40, s21, 0x2700, v169                           ; d6550028 06a5fe15 00002700
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_alignbyte_b32 v100, v115, v114, v37                       ; d6170064 0496e573
	v_alignbyte_b32 v101, v116, v115, v37                       ; d6170065 0496e774
	v_add3_u32 v42, s21, 0x2800, v169                           ; d655002a 06a5fe15 00002800
	v_add3_u32 v32, v170, v32, v172                             ; d6550020 06b241aa
	v_add3_u32 v34, v170, v34, v172                             ; d6550022 06b245aa
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_alignbyte_b32 v102, v118, v117, v39                       ; d6170066 049eeb76
	v_alignbyte_b32 v103, v119, v118, v39                       ; d6170067 049eed77
	v_add3_u32 v44, s21, 0x2900, v169                           ; d655002c 06a5fe15 00002900
	v_add3_u32 v36, v170, v36, v172                             ; d6550024 06b249aa
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_alignbyte_b32 v104, v121, v120, v41                       ; d6170068 04a6f179
	v_alignbyte_b32 v105, v122, v121, v41                       ; d6170069 04a6f37a
	v_add3_u32 v46, s21, 0x2a00, v169                           ; d655002e 06a5fe15 00002a00
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_alignbyte_b32 v106, v124, v123, v43                       ; d617006a 04aef77c
	v_add3_u32 v38, v170, v38, v172                             ; d6550026 06b24daa
	v_alignbyte_b32 v107, v125, v124, v43                       ; d617006b 04aef97d
	v_add3_u32 v48, s21, 0x2b00, v169                           ; d6550030 06a5fe15 00002b00
	v_add3_u32 v40, v170, v40, v172                             ; d6550028 06b251aa
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_alignbyte_b32 v108, v127, v126, v45                       ; d617006c 04b6fd7f
	v_alignbyte_b32 v109, v128, v127, v45                       ; d617006d 04b6ff80
	v_add3_u32 v50, s21, 0x2c00, v169                           ; d6550032 06a5fe15 00002c00
	v_add3_u32 v42, v170, v42, v172                             ; d655002a 06b255aa
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_alignbyte_b32 v110, v130, v129, v47                       ; d617006e 04bf0382
	v_alignbyte_b32 v111, v131, v130, v47                       ; d617006f 04bf0583
	v_add3_u32 v52, s21, 0x2d00, v169                           ; d6550034 06a5fe15 00002d00
	v_add3_u32 v44, v170, v44, v172                             ; d655002c 06b259aa
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_alignbyte_b32 v112, v133, v132, v49                       ; d6170070 04c70985
	v_alignbyte_b32 v113, v134, v133, v49                       ; d6170071 04c70b86
	v_add3_u32 v54, s21, 0x2e00, v169                           ; d6550036 06a5fe15 00002e00
	v_add3_u32 v46, v170, v46, v172                             ; d655002e 06b25daa
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_alignbyte_b32 v114, v136, v135, v51                       ; d6170072 04cf0f88
	v_alignbyte_b32 v115, v137, v136, v51                       ; d6170073 04cf1189
	v_add3_u32 v56, s21, 0x2f00, v169                           ; d6550038 06a5fe15 00002f00
	v_add3_u32 v48, v170, v48, v172                             ; d6550030 06b261aa
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_alignbyte_b32 v116, v139, v138, v53                       ; d6170074 04d7158b
	v_alignbyte_b32 v117, v140, v139, v53                       ; d6170075 04d7178c
	v_add3_u32 v58, s21, 0x3000, v169                           ; d655003a 06a5fe15 00003000
	v_add3_u32 v50, v170, v50, v172                             ; d6550032 06b265aa
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_alignbyte_b32 v118, v142, v141, v55                       ; d6170076 04df1b8e
	v_alignbyte_b32 v119, v143, v142, v55                       ; d6170077 04df1d8f
	v_add3_u32 v60, s21, 0x3100, v169                           ; d655003c 06a5fe15 00003100
	v_add3_u32 v52, v170, v52, v172                             ; d6550034 06b269aa
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_alignbyte_b32 v120, v145, v144, v57                       ; d6170078 04e72191
	v_alignbyte_b32 v121, v146, v145, v57                       ; d6170079 04e72392
	v_add3_u32 v62, s21, 0x3200, v169                           ; d655003e 06a5fe15 00003200
	v_add3_u32 v54, v170, v54, v172                             ; d6550036 06b26daa
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_alignbyte_b32 v122, v148, v147, v59                       ; d617007a 04ef2794
	v_alignbyte_b32 v123, v149, v148, v59                       ; d617007b 04ef2995
	v_add3_u32 v64, s21, 0x3300, v169                           ; d6550040 06a5fe15 00003300
	v_add3_u32 v56, v170, v56, v172                             ; d6550038 06b271aa
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_alignbyte_b32 v124, v151, v150, v61                       ; d617007c 04f72d97
	v_alignbyte_b32 v125, v152, v151, v61                       ; d617007d 04f72f98
	v_add3_u32 v66, s21, 0x3400, v169                           ; d6550042 06a5fe15 00003400
	v_add3_u32 v58, v170, v58, v172                             ; d655003a 06b275aa
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_alignbyte_b32 v126, v154, v153, v63                       ; d617007e 04ff339a
	v_alignbyte_b32 v127, v155, v154, v63                       ; d617007f 04ff359b
	v_add3_u32 v68, s21, 0x3500, v169                           ; d6550044 06a5fe15 00003500
	v_add3_u32 v60, v170, v60, v172                             ; d655003c 06b279aa
	v_add3_u32 v62, v170, v62, v172                             ; d655003e 06b27daa
	v_add3_u32 v64, v170, v64, v172                             ; d6550040 06b281aa
	v_add3_u32 v66, v170, v66, v172                             ; d6550042 06b285aa
	v_add3_u32 v68, v170, v68, v172                             ; d6550044 06b289aa
	s_clause 0x1f                                               ; bf85001f
	buffer_load_b64 v[128:129], v173, s[28:31], null offen      ; c405407c 40803880 000000ad
	buffer_load_b64 v[130:131], v174, s[28:31], null offen      ; c405407c 40803882 000000ae
	buffer_load_b64 v[132:133], v175, s[28:31], null offen      ; c405407c 40803884 000000af
	buffer_load_b64 v[134:135], v176, s[28:31], null offen      ; c405407c 40803886 000000b0
	buffer_load_b64 v[136:137], v177, s[28:31], null offen      ; c405407c 40803888 000000b1
	buffer_load_b64 v[138:139], v178, s[28:31], null offen      ; c405407c 4080388a 000000b2
	buffer_load_b64 v[140:141], v179, s[28:31], null offen      ; c405407c 4080388c 000000b3
	buffer_load_b64 v[142:143], v180, s[28:31], null offen      ; c405407c 4080388e 000000b4
	buffer_load_b64 v[144:145], v181, s[28:31], null offen      ; c405407c 40803890 000000b5
	buffer_load_b64 v[146:147], v182, s[28:31], null offen      ; c405407c 40803892 000000b6
	buffer_load_b64 v[148:149], v183, s[28:31], null offen      ; c405407c 40803894 000000b7
	buffer_load_b64 v[150:151], v184, s[28:31], null offen      ; c405407c 40803896 000000b8
	buffer_load_b64 v[152:153], v185, s[28:31], null offen      ; c405407c 40803898 000000b9
	buffer_load_b64 v[154:155], v186, s[28:31], null offen      ; c405407c 4080389a 000000ba
	buffer_load_b64 v[174:175], v187, s[28:31], null offen      ; c405407c 408038ae 000000bb
	buffer_load_b64 v[176:177], v188, s[28:31], null offen      ; c405407c 408038b0 000000bc
	buffer_load_b64 v[178:179], v189, s[28:31], null offen      ; c405407c 408038b2 000000bd
	buffer_load_b64 v[180:181], v190, s[28:31], null offen      ; c405407c 408038b4 000000be
	buffer_load_b64 v[182:183], v191, s[28:31], null offen      ; c405407c 408038b6 000000bf
	buffer_load_b64 v[184:185], v3, s[28:31], null offen        ; c405407c 408038b8 00000003
	buffer_load_b64 v[186:187], v6, s[28:31], null offen        ; c405407c 408038ba 00000006
	buffer_load_b64 v[6:7], v7, s[28:31], null offen            ; c405407c 40803806 00000007
	buffer_load_b64 v[188:189], v8, s[28:31], null offen        ; c405407c 408038bc 00000008
	buffer_load_b64 v[8:9], v9, s[28:31], null offen            ; c405407c 40803808 00000009
	buffer_load_b64 v[10:11], v10, s[28:31], null offen         ; c405407c 4080380a 0000000a
	buffer_load_b64 v[12:13], v12, s[28:31], null offen         ; c405407c 4080380c 0000000c
	buffer_load_b64 v[14:15], v14, s[28:31], null offen         ; c405407c 4080380e 0000000e
	buffer_load_b64 v[16:17], v16, s[28:31], null offen         ; c405407c 40803810 00000010
	buffer_load_b64 v[18:19], v18, s[28:31], null offen         ; c405407c 40803812 00000012
	buffer_load_b64 v[20:21], v20, s[28:31], null offen         ; c405407c 40803814 00000014
	buffer_load_b64 v[22:23], v22, s[28:31], null offen         ; c405407c 40803816 00000016
	buffer_load_b64 v[24:25], v24, s[28:31], null offen         ; c405407c 40803818 00000018
	s_clause 0x13                                               ; bf850013
	buffer_load_b64 v[26:27], v26, s[28:31], null offen         ; c405407c 4080381a 0000001a
	buffer_load_b64 v[28:29], v28, s[28:31], null offen         ; c405407c 4080381c 0000001c
	buffer_load_b64 v[30:31], v30, s[28:31], null offen         ; c405407c 4080381e 0000001e
	buffer_load_b64 v[32:33], v32, s[28:31], null offen         ; c405407c 40803820 00000020
	buffer_load_b64 v[34:35], v34, s[28:31], null offen         ; c405407c 40803822 00000022
	buffer_load_b64 v[36:37], v36, s[28:31], null offen         ; c405407c 40803824 00000024
	buffer_load_b64 v[38:39], v38, s[28:31], null offen         ; c405407c 40803826 00000026
	buffer_load_b64 v[40:41], v40, s[28:31], null offen         ; c405407c 40803828 00000028
	buffer_load_b64 v[42:43], v42, s[28:31], null offen         ; c405407c 4080382a 0000002a
	buffer_load_b64 v[44:45], v44, s[28:31], null offen         ; c405407c 4080382c 0000002c
	buffer_load_b64 v[46:47], v46, s[28:31], null offen         ; c405407c 4080382e 0000002e
	buffer_load_b64 v[48:49], v48, s[28:31], null offen         ; c405407c 40803830 00000030
	buffer_load_b64 v[50:51], v50, s[28:31], null offen         ; c405407c 40803832 00000032
	buffer_load_b64 v[52:53], v52, s[28:31], null offen         ; c405407c 40803834 00000034
	buffer_load_b64 v[54:55], v54, s[28:31], null offen         ; c405407c 40803836 00000036
	buffer_load_b64 v[56:57], v56, s[28:31], null offen         ; c405407c 40803838 00000038
	buffer_load_b64 v[58:59], v58, s[28:31], null offen         ; c405407c 4080383a 0000003a
	buffer_load_b64 v[60:61], v60, s[28:31], null offen         ; c405407c 4080383c 0000003c
	buffer_load_b64 v[62:63], v62, s[28:31], null offen         ; c405407c 4080383e 0000003e
	buffer_load_b64 v[190:191], v64, s[28:31], null offen       ; c405407c 408038be 00000040
	v_mov_b32_e32 v70, v2                                       ; 7e8c0302
	v_mov_b32_e32 v173, v65                                     ; 7f5a0341
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[2:3], v66, s[28:31], null offen           ; c405407c 40803802 00000042
	buffer_load_b64 v[64:65], v68, s[28:31], null offen         ; c405407c 40803840 00000044
	s_wait_loadcnt 0x37                                         ; bfc00037
	v_alignbyte_b32 v66, v163, v162, v69                        ; d6170042 051745a3
	s_wait_loadcnt 0x36                                         ; bfc00036
	v_alignbyte_b32 v68, v166, v165, v71                        ; d6170044 051f4ba6
	v_alignbyte_b32 v156, v157, v156, v173                      ; d617009c 06b7399d
	v_alignbyte_b32 v157, v158, v157, v173                      ; d617009d 06b73b9e
	v_alignbyte_b32 v158, v160, v159, v67                       ; d617009e 050f3fa0
	v_alignbyte_b32 v159, v161, v160, v67                       ; d617009f 050f41a1
	v_alignbyte_b32 v67, v164, v163, v69                        ; d6170043 051747a4
	v_alignbyte_b32 v69, v167, v166, v71                        ; d6170045 051f4da7
	v_add3_u32 v71, s21, 0x3600, v169                           ; d6550047 06a5fe15 00003600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870151
	v_add3_u32 v71, v170, v71, v172                             ; d6550047 06b28faa
	s_wait_loadcnt 0x35                                         ; bfc00035
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[128:129], v[72:73], 0 ; cc4640a0 1a029180
	v_add3_u32 v128, s21, 0x3700, v169                          ; d6550080 06a5fe15 00003700
	v_add3_u32 v129, s21, 0x3800, v169                          ; d6550081 06a5fe15 00003800
	v_add3_u32 v128, v170, v128, v172                           ; d6550080 06b301aa
	v_add3_u32 v129, v170, v129, v172                           ; d6550081 06b303aa
	s_wait_loadcnt 0x34                                         ; bfc00034
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[130:131], v[74:75], v[160:167] ; cc4640a0 1e829582
	v_add3_u32 v130, s21, 0x3900, v169                          ; d6550082 06a5fe15 00003900
	v_add3_u32 v131, s21, 0x3a00, v169                          ; d6550083 06a5fe15 00003a00
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add3_u32 v130, v170, v130, v172                           ; d6550082 06b305aa
	v_add3_u32 v131, v170, v131, v172                           ; d6550083 06b307aa
	s_wait_loadcnt 0x33                                         ; bfc00033
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[132:133], v[76:77], v[160:167] ; cc4640a0 1e829984
	v_add3_u32 v132, s21, 0x3b00, v169                          ; d6550084 06a5fe15 00003b00
	v_add3_u32 v133, s21, 0x3c00, v169                          ; d6550085 06a5fe15 00003c00
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add3_u32 v132, v170, v132, v172                           ; d6550084 06b309aa
	v_add3_u32 v133, v170, v133, v172                           ; d6550085 06b30baa
	s_wait_loadcnt 0x32                                         ; bfc00032
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[134:135], v[78:79], v[160:167] ; cc4640a0 1e829d86
	v_add3_u32 v134, s21, 0x3d00, v169                          ; d6550086 06a5fe15 00003d00
	v_add3_u32 v135, s21, 0x3e00, v169                          ; d6550087 06a5fe15 00003e00
	v_add3_u32 v169, s21, 0x3f00, v169                          ; d65500a9 06a5fe15 00003f00
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_add3_u32 v134, v170, v134, v172                           ; d6550086 06b30daa
	v_add3_u32 v135, v170, v135, v172                           ; d6550087 06b30faa
	v_add3_u32 v169, v170, v169, v172                           ; d65500a9 06b353aa
	s_wait_loadcnt 0x31                                         ; bfc00031
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[136:137], v[80:81], v[160:167] ; cc4640a0 1e82a188
	s_wait_loadcnt 0x30                                         ; bfc00030
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[138:139], v[82:83], v[160:167] ; cc4640a0 1e82a58a
	s_wait_loadcnt 0x2f                                         ; bfc0002f
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[140:141], v[84:85], v[160:167] ; cc4640a0 1e82a98c
	s_wait_loadcnt 0x2e                                         ; bfc0002e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[142:143], v[86:87], v[160:167] ; cc4640a0 1e82ad8e
	s_wait_loadcnt 0x2d                                         ; bfc0002d
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[144:145], v[88:89], v[160:167] ; cc4640a0 1e82b190
	s_wait_loadcnt 0x2c                                         ; bfc0002c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[146:147], v[90:91], v[160:167] ; cc4640a0 1e82b592
	s_clause 0x9                                                ; bf850009
	buffer_load_b64 v[136:137], v71, s[28:31], null offen       ; c405407c 40803888 00000047
	buffer_load_b64 v[138:139], v128, s[28:31], null offen      ; c405407c 4080388a 00000080
	buffer_load_b64 v[128:129], v129, s[28:31], null offen      ; c405407c 40803880 00000081
	buffer_load_b64 v[140:141], v130, s[28:31], null offen      ; c405407c 4080388c 00000082
	buffer_load_b64 v[130:131], v131, s[28:31], null offen      ; c405407c 40803882 00000083
	buffer_load_b64 v[142:143], v132, s[28:31], null offen      ; c405407c 4080388e 00000084
	buffer_load_b64 v[132:133], v133, s[28:31], null offen      ; c405407c 40803884 00000085
	buffer_load_b64 v[144:145], v134, s[28:31], null offen      ; c405407c 40803890 00000086
	buffer_load_b64 v[134:135], v135, s[28:31], null offen      ; c405407c 40803886 00000087
	buffer_load_b64 v[146:147], v169, s[28:31], null offen      ; c405407c 40803892 000000a9
	s_clause 0x1                                                ; bf850001
	s_load_b64 s[26:27], s[10:11], 0x5c                         ; f4002685 f800005c
	s_load_b128 s[28:31], s[0:1], 0x40                          ; f4004700 f8000040
	v_and_b32_e32 v0, 0xffffffe0, v0                            ; 360000ff ffffffe0
	s_wait_loadcnt 0x35                                         ; bfc00035
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[148:149], v[92:93], v[160:167] ; cc4640a0 1e82b994
	s_wait_loadcnt 0x34                                         ; bfc00034
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[150:151], v[94:95], v[160:167] ; cc4640a0 1e82bd96
	v_mov_b32_e32 v151, v172                                    ; 7f2e03ac
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_add3_u32 v148, s26, v0, v5                                ; d6550094 0416001a
	v_lshlrev_b32_e32 v148, 1, v148                             ; 31292881
	s_wait_loadcnt 0x33                                         ; bfc00033
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[152:153], v[96:97], v[160:167] ; cc4640a0 1e82c198
	v_and_b32_e32 v149, -4, v148                                ; 372b28c4
	s_wait_loadcnt 0x32                                         ; bfc00032
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[154:155], v[98:99], v[160:167] ; cc4640a0 1e82c59a
	s_wait_loadcnt 0x31                                         ; bfc00031
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[174:175], v[100:101], v[160:167] ; cc4640a0 1e82c9ae
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[152:155], v149, s[28:31], null offen     ; c405c07c 40803898 00000095
	buffer_load_d16_hi_b16 v150, v148, s[28:31], null offen offset:14 ; c408c07c 40803896 00000e94
	buffer_load_b128 v[172:175], v149, s[28:31], null offen offset:32 ; c405c07c 408038ac 00002095
	buffer_load_d16_hi_b16 v71, v148, s[28:31], null offen offset:46 ; c408c07c 40803847 00002e94
	v_add_nc_u32_e32 v169, 32, v148                             ; 4b5328a0
	s_wait_loadcnt 0x34                                         ; bfc00034
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[176:177], v[102:103], v[160:167] ; cc4640a0 1e82cdb0
	s_wait_loadcnt 0x33                                         ; bfc00033
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[178:179], v[104:105], v[160:167] ; cc4640a0 1e82d1b2
	s_wait_loadcnt 0x32                                         ; bfc00032
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[180:181], v[106:107], v[160:167] ; cc4640a0 1e82d5b4
	s_wait_loadcnt 0x31                                         ; bfc00031
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[182:183], v[108:109], v[160:167] ; cc4640a0 1e82d9b6
	s_wait_loadcnt 0x30                                         ; bfc00030
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[184:185], v[110:111], v[160:167] ; cc4640a0 1e82ddb8
	s_wait_loadcnt 0x2f                                         ; bfc0002f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[186:187], v[112:113], v[160:167] ; cc4640a0 1e82e1ba
	s_wait_loadcnt 0x2e                                         ; bfc0002e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[6:7], v[114:115], v[160:167] ; cc4640a0 1e82e506
	s_wait_loadcnt 0x2d                                         ; bfc0002d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[188:189], v[116:117], v[160:167] ; cc4640a0 1e82e9bc
	s_wait_loadcnt 0x2c                                         ; bfc0002c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[8:9], v[118:119], v[160:167] ; cc4640a0 1e82ed08
	s_wait_loadcnt 0x2b                                         ; bfc0002b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[10:11], v[120:121], v[160:167] ; cc4640a0 1e82f10a
	s_wait_loadcnt 0x2a                                         ; bfc0002a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[122:123], v[160:167] ; cc4640a0 1e82f50c
	s_wait_loadcnt 0x29                                         ; bfc00029
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[14:15], v[124:125], v[160:167] ; cc4640a0 1e82f90e
	s_wait_loadcnt 0x28                                         ; bfc00028
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[126:127], v[160:167] ; cc4640a0 1e82fd10
	s_wait_loadcnt 0x27                                         ; bfc00027
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[18:19], v[156:157], v[160:167] ; cc4640a0 1e833912
	s_wait_loadcnt 0x26                                         ; bfc00026
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[20:21], v[158:159], v[160:167] ; cc4640a0 1e833d14
	s_wait_loadcnt 0x25                                         ; bfc00025
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[22:23], v[66:67], v[160:167] ; cc4640a0 1e828516
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_alignbyte_b32 v152, v153, v152, v148                      ; d6170098 06533199
	v_alignbyte_b32 v153, v154, v153, v148                      ; d6170099 0653339a
	v_alignbyte_b32 v154, v155, v154, v148                      ; d617009a 0653359b
	v_alignbyte_b32 v155, v155, v155, v148                      ; d617009b 0653379b
	v_lshlrev_b32_e32 v148, 9, v168                             ; 31295089
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_add3_u32 v149, v170, v148, v151                           ; d6550095 065f29aa
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[24:25], v[68:69], v[160:167] ; cc4640a0 1e828918
	v_lshlrev_b32_e32 v176, 1, v149                             ; 31612a81
	v_cvt_f16_f32_e32 v11, v166                                 ; 7e1615a6
(invalid instruction)                                        ; 7f1615a7
	v_cvt_f16_f32_e32 v8, v160                                  ; 7e1015a0
(invalid instruction)                                        ; 7f1015a1
	v_cvt_f16_f32_e32 v9, v162                                  ; 7e1215a2
(invalid instruction)                                        ; 7f1215a3
	v_cvt_f16_f32_e32 v10, v164                                 ; 7e1415a4
(invalid instruction)                                        ; 7f1415a5
	ds_store_b128 v176, v[8:11]                                 ; db7c0000 000008b0
	v_lshlrev_b32_e32 v177, 1, v168                             ; 31635081
	v_lshlrev_b32_e32 v178, 4, v70                              ; 31648c84
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[26:27], v[72:73], 0  ; cc464008 1a02911a
	s_lshl1_add_u32 s18, ttmp9, s18                             ; 87121275
	s_lshl1_add_u32 s24, s24, s19                               ; 87181318
	s_add_co_u32 s32, s16, -1                                   ; 8020c110
	s_add_co_u32 s33, s17, -1                                   ; 8021c111
	s_and_b32 s23, s23, -4                                      ; 8b17c417
	v_lshrrev_b32_e32 v70, 3, v70                               ; 328c8c83
	v_lshrrev_b32_e32 v1, 1, v1                                 ; 32020281
	s_cmp_eq_i32 s20, 0                                         ; bf008014
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[28:29], v[74:75], v[8:15] ; cc464008 1c22951c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[30:31], v[76:77], v[8:15] ; cc464008 1c22991e
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[32:33], v[78:79], v[8:15] ; cc464008 1c229d20
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[34:35], v[80:81], v[8:15] ; cc464008 1c22a122
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[36:37], v[82:83], v[8:15] ; cc464008 1c22a524
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[38:39], v[84:85], v[8:15] ; cc464008 1c22a926
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[40:41], v[86:87], v[8:15] ; cc464008 1c22ad28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[42:43], v[88:89], v[8:15] ; cc464008 1c22b12a
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[44:45], v[90:91], v[8:15] ; cc464008 1c22b52c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[46:47], v[92:93], v[8:15] ; cc464008 1c22b92e
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[48:49], v[94:95], v[8:15] ; cc464008 1c22bd30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[50:51], v[96:97], v[8:15] ; cc464008 1c22c132
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[52:53], v[98:99], v[8:15] ; cc464008 1c22c534
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[54:55], v[100:101], v[8:15] ; cc464008 1c22c936
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[56:57], v[102:103], v[8:15] ; cc464008 1c22cd38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[58:59], v[104:105], v[8:15] ; cc464008 1c22d13a
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[60:61], v[106:107], v[8:15] ; cc464008 1c22d53c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[62:63], v[108:109], v[8:15] ; cc464008 1c22d93e
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[190:191], v[110:111], v[8:15] ; cc464008 1c22ddbe
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[2:3], v[112:113], v[8:15] ; cc464008 1c22e102
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[64:65], v[114:115], v[8:15] ; cc464008 1c22e540
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[136:137], v[116:117], v[8:15] ; cc464008 1c22e988
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[138:139], v[118:119], v[8:15] ; cc464008 1c22ed8a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[128:129], v[120:121], v[8:15] ; cc464008 1c22f180
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[140:141], v[122:123], v[8:15] ; cc464008 1c22f58c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[130:131], v[124:125], v[8:15] ; cc464008 1c22f982
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[142:143], v[126:127], v[8:15] ; cc464008 1c22fd8e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[132:133], v[156:157], v[8:15] ; cc464008 1c233984
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[144:145], v[158:159], v[8:15] ; cc464008 1c233d90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[134:135], v[66:67], v[8:15] ; cc464008 1c228586
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[146:147], v[68:69], v[8:15] ; cc464008 1c228992
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v18, v12                                  ; 7e24150c
(invalid instruction)                                        ; 7f24150d
	v_cvt_f16_f32_e32 v17, v10                                  ; 7e22150a
(invalid instruction)                                        ; 7f22150b
	v_cvt_f16_f32_e32 v16, v8                                   ; 7e201508
	v_cvt_f16_f32_e32 v19, v14                                  ; 7e26150e
(invalid instruction)                                        ; 7f26150f
(invalid instruction)                                        ; 7f201509
	ds_store_b128 v176, v[16:19] offset:512                     ; db7c0200 000010b0
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_wait_loadcnt 0x2                                          ; bfc00002
(invalid instruction)                                        ; d59c489b
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                    ; 02010196
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_alignbyte_b32 v172, v173, v172, v169                      ; d61700ac 06a759ad
	v_alignbyte_b32 v173, v174, v173, v169                      ; d61700ad 06a75bae
	v_alignbyte_b32 v174, v175, v174, v169                      ; d61700ae 06a75daf
	v_alignbyte_b32 v175, v175, v175, v169                      ; d61700af 06a75faf
	s_wait_loadcnt 0x0                                          ; bfc00000
(invalid instruction)                                        ; d59c48af
	v_cndmask_b32_e32 v0, v71, v128, vcc_lo                     ; 02010147
	s_barrier_wait 0xffff                                       ; bf94ffff
	s_mov_b32 s19, 0                                            ; be930080
	s_branch BB1                                                ; bfa00004
	s_nop 0                                                     ; bf800000
	(then repeated 2 times)
BB6:
	s_cmp_lg_i32 s39, 0                                         ; bf018027
BB1:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s22, src_scc                                      ; be9600fd
	s_and_b32 s25, s19, 1                                       ; 8b198113
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s26, s18, s25                                  ; 801a1912
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_max_i32 s34, s26, 0                                       ; 8a22801a
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_min_i32 s34, s34, s32                                     ; 89222022
	s_lshr_b32 s35, s19, 1                                      ; 85238113
	s_add_co_u32 s35, s24, s35                                  ; 80232318
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_max_i32 s36, s35, 0                                       ; 8a248023
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s36, s36, s33                                     ; 89242124
	s_cmp_lg_i32 s22, 0                                         ; bf018016
	s_cbranch_scc0 BB3                                          ; bfa10003
BB2:
	s_load_b32 s21, s[10:11], 0x60                              ; f4000545 f8000060
	s_branch BB4                                                ; bfa00001
BB3:
	s_mov_b32 s21, s20                                          ; be950014
BB4:
	s_mov_b32 s37, src_scc                                      ; bea500fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s21, s36, s21                                     ; 96151524
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s21, s21, s34                                  ; 80152215
	s_cmp_lg_i32 s37, 0                                         ; bf018025
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v2, s21, 4, v177                             ; d6460002 06c50815
	s_cselect_b32 s38, s27, s20                                 ; 9826141b
	s_mov_b32 s39, src_scc                                      ; bea700fd
	s_mul_i32 s36, s36, s38                                     ; 96242624
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870151
	v_lshl_add_u32 v2, v2, 8, s23                               ; d6460002 005d1102
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s36, s36, s34                                  ; 80242224
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v3, s36, 4, v177                             ; d6460003 06c50824
	v_add3_u32 v2, v5, v2, v178                                 ; d6550002 06ca0505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_lshl_add_u32 v3, v3, 8, 0x100                             ; d6460003 03fd1103 00000100
	v_add3_u32 v3, v178, s23, v3                                ; d6550003 040c2fb2
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v3, v3, v5                                 ; 4a060b03
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[6:7], v2, s[12:15], null offen            ; c405407c 40801806 00000002
	buffer_load_b64 v[2:3], v3, s[12:15], null offen            ; c405407c 40801802 00000003
	s_and_b32 s40, s19, -2                                      ; 8b28c213
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v8, s40, v70, 2                              ; d6470008 020a8c28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v8, s25, 1, v8                               ; d6460008 04210219
	v_add_lshl_u32 v8, v8, v1, 4                                ; d6470008 02120308
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add3_u32 v8, v5, v148, v8                                 ; d6550008 04232905
	v_lshlrev_b32_e32 v8, 1, v8                                 ; 30101081
	ds_load_b64 v[10:11], v8                                    ; d9d80000 0a000008
	ds_load_b64 v[12:13], v8 offset:8                           ; d9d80008 0c000008
	v_lshl_add_u32 v9, s19, 4, v177                             ; d6460009 06c50813
	s_min_i32 s41, s26, s35                                     ; 8929231a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s41, 0                                         ; bf048029
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b1
	v_lshl_add_u32 v9, v9, 8, v151                              ; d6460009 065d1109
	s_cselect_b32 s42, -1, 0                                    ; 982a80c1
	s_cmp_ge_i32 s26, s16                                       ; bf03101a
	s_cselect_b32 s43, -1, 0                                    ; 982b80c1
	v_add_nc_u32_e32 v9, v9, v170                               ; 4a135509
	s_or_b32 s42, s42, s43                                      ; 8c2a2b2a
	s_cmp_ge_i32 s35, s17                                       ; bf031123
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s44, -1, 0                                    ; 982c80c1
	s_nor_b32 vcc_lo, s42, s44                                  ; 8f6a2c2a
	s_add_co_u32 s19, s19, 1                                    ; 80138113
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_i32 s19, 4                                         ; bf038413
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_pk_f32_fp8_e32 v[14:15], v6                           ; 7e1cdd06
	v_cvt_pk_f32_fp8_e32 v[16:17], v134                         ; 7e20dd86
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_cvt_pk_rtz_f16_f32_e32 v14, v14, v15                      ; 5e1c1f0e
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	s_wait_dscnt 0x1                                            ; bfc60001
	v_pk_fmac_f16 v10, v14, v152                                ; 7815310e
	v_pk_fmac_f16 v11, v16, v153                                ; 78173310
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
	v_cvt_f32_f16_e32 v14, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1c178a
	v_cvt_f32_f16_e32 v10, v10                                  ; 7e14170a
	v_cvt_f32_f16_e32 v16, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e20178b
	v_cvt_f32_f16_e32 v11, v11                                  ; 7e16170b
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v10, v14, vcc_lo                      ; 02021d0a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v11, v16, vcc_lo                      ; 0202210b
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_cvt_pk_f32_fp8_e32 v[10:11], v7                           ; 7e14dd07
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
	v_cvt_pk_rtz_f16_f32_e32 v6, v6, v7                         ; 5e0c0f06
	s_wait_dscnt 0x0                                            ; bfc60000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_pk_fmac_f16 v12, v10, v154                                ; 7819350a
	v_pk_fmac_f16 v13, v6, v155                                 ; 781b3706
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_f32_f16_e32 v17, v140/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e22178c
	v_cvt_f32_f16_e32 v12, v12                                  ; 7e18170c
	v_cvt_f32_f16_e32 v19, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e26178d
	v_cvt_f32_f16_e32 v13, v13                                  ; 7e1a170d
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v12, v17, vcc_lo                      ; 0202230c
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v13, v19, vcc_lo                      ; 0202270d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_cndmask_b32 v7, 0, v18 :: v_dual_cndmask_b32 v6, 0, v15 ; ca522480 07061e80
	ds_store_b64 v9, v[6:7] offset:16384                        ; d9344000 00000609
	ds_load_b64 v[6:7], v8 offset:512                           ; d9d80200 06000008
	ds_load_b64 v[10:11], v8 offset:520                         ; d9d80208 0a000008
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_pk_f32_fp8_e32 v[12:13], v2                           ; 7e18dd02
	v_cvt_pk_f32_fp8_e32 v[14:15], v130                         ; 7e1cdd82
	v_cvt_pk_f32_fp8_e32 v[16:17], v3                           ; 7e20dd03
	v_cvt_pk_f32_fp8_e32 v[2:3], v131                           ; 7e04dd83
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_cvt_pk_rtz_f16_f32_e32 v12, v12, v13                      ; 5e181b0c
	v_cvt_pk_rtz_f16_f32_e32 v14, v14, v15                      ; 5e1c1f0e
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	v_cvt_pk_rtz_f16_f32_e32 v2, v2, v3                         ; 5e040702
	s_wait_dscnt 0x1                                            ; bfc60001
	v_pk_fmac_f16 v6, v12, v172                                 ; 780d590c
	v_pk_fmac_f16 v7, v14, v173                                 ; 780f5b0e
	s_wait_dscnt 0x0                                            ; bfc60000
	v_pk_fmac_f16 v10, v16, v174                                ; 78155d10
	v_pk_fmac_f16 v11, v2, v175                                 ; 78175f02
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_f32_f16_e32 v20, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e281786
	v_cvt_f32_f16_e32 v6, v6                                    ; 7e0c1706
	v_cvt_f32_f16_e32 v22, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2c1787
	v_cvt_f32_f16_e32 v7, v7                                    ; 7e0e1707
	v_cvt_f32_f16_e32 v23, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2e178a
	v_cvt_f32_f16_e32 v10, v10                                  ; 7e14170a
	v_cvt_f32_f16_e32 v25, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e32178b
	v_cvt_f32_f16_e32 v11, v11                                  ; 7e16170b
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v6, v20, vcc_lo                       ; 02022906
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v7, v22, vcc_lo                       ; 02022d07
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v10, v23, vcc_lo                      ; 02022f0a
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                      ; 0202330b
	v_dual_cndmask_b32 v7, 0, v24 :: v_dual_cndmask_b32 v6, 0, v21 ; ca523080 07062a80
	ds_store_b64 v9, v[6:7] offset:16640                        ; d9344100 00000609
	s_cbranch_scc0 BB6                                          ; bfa1ff41
BB7:
	v_lshlrev_b32_e32 v1, 3, v168                               ; 30035083
	v_lshlrev_b32_e32 v4, 2, v4                                 ; 30080882
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_add_nc_u32_e32 v6, 2, v1                                  ; 4a0c0282
	v_sub_nc_u32_e32 v2, 0, v1                                  ; 4c040280
	v_med3_i32 v3, -1, v1, 1                                    ; d6200003 020602c1
	v_sub_nc_u32_e32 v7, 0, v6                                  ; 4c0e0c80
	v_max_i32_e32 v2, v1, v2                                    ; 24040501
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_max_i32_e32 v7, v6, v7                                    ; 240e0f06
	v_med3_i32 v6, -1, v6, 1                                    ; d6200006 02060cc1
	v_lshrrev_b32_e32 v2, 1, v2                                 ; 32040481
	v_lshrrev_b32_e32 v7, 1, v7                                 ; 320e0e81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
(invalid instruction)                                        ; d72c0003
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                        ; 02020503
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
	v_lshl_add_u32 v3, v3, 11, s3                               ; d6460003 000d1703
	v_lshl_add_u32 v6, v6, 11, s3                               ; d6460006 000d1706
	v_add_lshl_u32 v3, v3, v4, 2                                ; d6470003 020a0903
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_lshl_u32 v6, v6, v4, 2                                ; d6470006 020a0906
	s_clause 0x6                                                ; bf850006
	buffer_load_b128 v[8:11], v3, s[28:31], null offen          ; c405c07c 40803808 00000003
	buffer_load_b128 v[12:15], v6, s[28:31], null offen         ; c405c07c 4080380c 00000006
	buffer_load_b128 v[16:19], v3, s[28:31], null offen offset:512 ; c405c07c 40803810 00020003
	buffer_load_b128 v[20:23], v6, s[28:31], null offen offset:512 ; c405c07c 40803814 00020006
	buffer_load_b128 v[24:27], v3, s[28:31], null offen offset:1024 ; c405c07c 40803818 00040003
	buffer_load_b128 v[28:31], v6, s[28:31], null offen offset:1024 ; c405c07c 4080381c 00040006
	buffer_load_b128 v[32:35], v3, s[28:31], null offen offset:1536 ; c405c07c 40803820 00060003
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_pack_hh_b32_b16 s19, ttmp7, 0                             ; 9a138073
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v36, s19, v171, 4                            ; d6470024 02135613
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_add_nc_u32_e32 v36, v36, v170                             ; 4a495524
	s_barrier_wait 0xffff                                       ; bf94ffff
	v_lshl_add_u32 v38, s19, 4, v151                            ; d6460026 065d0813
	v_add_nc_u32_e32 v38, v38, v170                             ; 4a4d5526
	ds_load_b64 v[36:37], v36 offset:16384                      ; d9d84000 24000024
	ds_load_b64 v[40:41], v38 offset:20480                      ; d9d85000 28000026
	ds_load_b64 v[42:43], v38 offset:24576                      ; d9d86000 2a000026
	ds_load_b64 v[44:45], v38 offset:28672                      ; d9d87000 2c000026
	s_load_b32 s20, s[10:11], 0x24                              ; f4000505 f8000024
	ds_load_b64 v[46:47], v38 offset:16640                      ; d9d84100 2e000026
	ds_load_b64 v[48:49], v38 offset:20736                      ; d9d85100 30000026
	ds_load_b64 v[50:51], v38 offset:24832                      ; d9d86100 32000026
	ds_load_b64 v[52:53], v38 offset:28928                      ; d9d87100 34000026
	ds_load_b64 v[54:55], v38 offset:16896                      ; d9d84200 36000026
	ds_load_b64 v[56:57], v38 offset:20992                      ; d9d85200 38000026
	ds_load_b64 v[58:59], v38 offset:25088                      ; d9d86200 3a000026
	ds_load_b64 v[60:61], v38 offset:29184                      ; d9d87200 3c000026
	ds_load_b64 v[62:63], v38 offset:17152                      ; d9d84300 3e000026
	ds_load_b64 v[64:65], v38 offset:21248                      ; d9d85300 40000026
	ds_load_b64 v[66:67], v38 offset:25344                      ; d9d86300 42000026
	ds_load_b64 v[68:69], v38 offset:29440                      ; d9d87300 44000026
	v_mov_b32_e32 v2, v6                                        ; 7e040306
	s_wait_loadcnt_dscnt 0x60f                                  ; bfc8060f
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[36:37], 0   ; cc464048 1a024908
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[42:43], 0   ; cc464058 1a025508
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[36:37], 0 ; cc464068 1a02490a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[40:41], 0 ; cc464070 1a02510a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[44:45], 0 ; cc464080 1a02590a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[44:45], 0  ; cc464060 1a025908
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[40:41], 0   ; cc464050 1a025108
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[42:43], 0 ; cc464078 1a02550a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[12:13], v[40:41], 0 ; cc464098 1a02510c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[42:43], 0 ; cc4640a0 1a02550c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[14:15], v[36:37], 0 ; cc4640b8 1a02490e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[44:45], 0 ; cc4640b0 1a02590c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[12:13], v[36:37], 0 ; cc464088 1a02490c
	v_dual_mov_b32 v36, v148 :: v_dual_mov_b32 v37, v149        ; ca100194 24240195
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[14:15], v[40:41], 0  ; cc464006 1a02510e
	v_dual_mov_b32 v40, v168 :: v_dual_mov_b32 v39, v151        ; ca1001a8 28260197
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[14:15], v[42:43], 0 ; cc464090 1a02550e
	v_dual_mov_b32 v42, v171 :: v_dual_mov_b32 v41, v170        ; ca1001ab 2a2801aa
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[14:15], v[44:45], 0 ; cc4640a8 1a02590e
	v_mov_b32_e32 v14, v42                                      ; 7e1c032a
	buffer_load_b128 v[42:45], v2, s[28:31], null offen offset:1536 ; c405c07c 4080382a 00060002
	s_wait_loadcnt_dscnt 0x50b                                  ; bfc8050b
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[16:17], v[46:47], v[72:79] ; cc464048 1d225d10
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[50:51], v[88:95] ; cc464058 1d626510
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[48:49], v[80:87] ; cc464050 1d426110
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[52:53], v[96:103] ; cc464060 1d826910
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[46:47], v[104:111] ; cc464068 1da25d12
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[48:49], v[112:119] ; cc464070 1dc26112
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[50:51], v[120:127] ; cc464078 1de26512
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[52:53], v[128:135] ; cc464080 1e026912
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[20:21], v[46:47], v[136:143] ; cc464088 1e225d14
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[20:21], v[48:49], v[152:159] ; cc464098 1e626114
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[20:21], v[50:51], v[160:167] ; cc4640a0 1e826514
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[20:21], v[52:53], v[176:183] ; cc4640b0 1ec26914
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[22:23], v[46:47], v[184:191] ; cc4640b8 1ee25d16
	ds_load_b64 v[16:17], v38 offset:17408                      ; d9d84400 10000026
	ds_load_b64 v[18:19], v38 offset:21504                      ; d9d85400 12000026
	ds_load_b64 v[20:21], v38 offset:25600                      ; d9d86400 14000026
	ds_load_b64 v[46:47], v38 offset:29696                      ; d9d87400 2e000026
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[22:23], v[48:49], v[6:13] ; cc464006 1c1a6116
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[22:23], v[50:51], v[144:151] ; cc464090 1e426516
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[52:53], v[168:175] ; cc4640a8 1ea26916
	s_wait_dscnt 0x1                                            ; bfc60001
	v_dual_mov_b32 v53, v21 :: v_dual_mov_b32 v52, v20          ; ca100115 35340114
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v3, s[28:31], null offen offset:2048 ; c405c07c 40803830 00080003
	buffer_load_b128 v[20:23], v2, s[28:31], null offen offset:2048 ; c405c07c 40803814 00080002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[54:55], v[72:79] ; cc464048 1d226d18
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[56:57], v[80:87] ; cc464050 1d427118
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[58:59], v[88:95] ; cc464058 1d627518
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[60:61], v[96:103] ; cc464060 1d827918
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[54:55], v[104:111] ; cc464068 1da26d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[56:57], v[112:119] ; cc464070 1dc2711a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[58:59], v[120:127] ; cc464078 1de2751a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[60:61], v[128:135] ; cc464080 1e02791a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[28:29], v[54:55], v[136:143] ; cc464088 1e226d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[28:29], v[56:57], v[152:159] ; cc464098 1e62711c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[28:29], v[58:59], v[160:167] ; cc4640a0 1e82751c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[28:29], v[60:61], v[176:183] ; cc4640b0 1ec2791c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[30:31], v[54:55], v[184:191] ; cc4640b8 1ee26d1e
	ds_load_b64 v[24:25], v38 offset:17664                      ; d9d84500 18000026
	ds_load_b64 v[26:27], v38 offset:21760                      ; d9d85500 1a000026
	ds_load_b64 v[28:29], v38 offset:25856                      ; d9d86500 1c000026
	ds_load_b64 v[54:55], v38 offset:29952                      ; d9d87500 36000026
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[30:31], v[56:57], v[6:13] ; cc464006 1c1a711e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[30:31], v[58:59], v[144:151] ; cc464090 1e42751e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[30:31], v[60:61], v[168:175] ; cc4640a8 1ea2791e
	s_wait_dscnt 0x1                                            ; bfc60001
	v_dual_mov_b32 v61, v29 :: v_dual_mov_b32 v60, v28          ; ca10011d 3d3c011c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v3, s[28:31], null offen offset:2560 ; c405c07c 40803838 000a0003
	buffer_load_b128 v[28:31], v2, s[28:31], null offen offset:2560 ; c405c07c 4080381c 000a0002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[32:33], v[62:63], v[72:79] ; cc464048 1d227d20
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[64:65], v[80:87] ; cc464050 1d428120
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[66:67], v[88:95] ; cc464058 1d628520
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[68:69], v[96:103] ; cc464060 1d828920
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[34:35], v[62:63], v[104:111] ; cc464068 1da27d22
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[64:65], v[112:119] ; cc464070 1dc28122
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[66:67], v[120:127] ; cc464078 1de28522
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[68:69], v[128:135] ; cc464080 1e028922
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[68:69], v[176:183] ; cc4640b0 1ec2892a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[62:63], v[136:143] ; cc464088 1e227d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[42:43], v[64:65], v[152:159] ; cc464098 1e62812a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[42:43], v[66:67], v[160:167] ; cc4640a0 1e82852a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[44:45], v[62:63], v[184:191] ; cc4640b8 1ee27d2c
	ds_load_b64 v[32:33], v38 offset:17920                      ; d9d84600 20000026
	ds_load_b64 v[34:35], v38 offset:22016                      ; d9d85600 22000026
	ds_load_b64 v[42:43], v38 offset:26112                      ; d9d86600 2a000026
	ds_load_b64 v[62:63], v38 offset:30208                      ; d9d87600 3e000026
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[68:69], v[168:175] ; cc4640a8 1ea2892c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[44:45], v[66:67], v[144:151] ; cc464090 1e42852c
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[44:45], v[64:65], v[6:13] ; cc464006 1c1a812c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[64:67], v3, s[28:31], null offen offset:3072 ; c405c07c 40803840 000c0003
	buffer_load_b128 v[68:71], v2, s[28:31], null offen offset:3072 ; c405c07c 40803844 000c0002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[52:53], v[88:95] ; cc464058 1d626930
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[48:49], v[46:47], v[96:103] ; cc464060 1d825d30
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[18:19], v[80:87] ; cc464050 1d422530
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[50:51], v[16:17], v[104:111] ; cc464068 1da22132
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[48:49], v[16:17], v[72:79] ; cc464048 1d222130
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[20:21], v[18:19], v[152:159] ; cc464098 1e622514
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[22:23], v[16:17], v[184:191] ; cc4640b8 1ee22116
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[20:21], v[16:17], v[136:143] ; cc464088 1e222114
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[20:21], v[52:53], v[160:167] ; cc4640a0 1e826914
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[20:21], v[46:47], v[176:183] ; cc4640b0 1ec25d14
	ds_load_b64 v[44:45], v38 offset:18176                      ; d9d84700 2c000026
	ds_load_b64 v[48:49], v38 offset:22272                      ; d9d85700 30000026
	ds_load_b64 v[20:21], v38 offset:26368                      ; d9d86700 14000026
	ds_load_b64 v[16:17], v38 offset:30464                      ; d9d87700 10000026
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[52:53], v[120:127] ; cc464078 1de26932
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[18:19], v[112:119] ; cc464070 1dc22532
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[46:47], v[128:135] ; cc464080 1e025d32
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[22:23], v[18:19], v[6:13] ; cc464006 1c1a2516
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[22:23], v[52:53], v[144:151] ; cc464090 1e426916
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[46:47], v[168:175] ; cc4640a8 1ea25d16
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v23, v17 :: v_dual_mov_b32 v22, v16          ; ca100111 17160110
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[50:53], v3, s[28:31], null offen offset:3584 ; c405c07c 40803832 000e0003
	buffer_load_b128 v[16:19], v2, s[28:31], null offen offset:3584 ; c405c07c 40803810 000e0002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[56:57], v[54:55], v[96:103] ; cc464060 1d826d38
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[26:27], v[112:119] ; cc464070 1dc2353a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[56:57], v[24:25], v[72:79] ; cc464048 1d223138
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[58:59], v[24:25], v[104:111] ; cc464068 1da2313a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[56:57], v[26:27], v[80:87] ; cc464050 1d423538
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[60:61], v[88:95] ; cc464058 1d627938
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[28:29], v[54:55], v[176:183] ; cc4640b0 1ec26d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[28:29], v[24:25], v[136:143] ; cc464088 1e22311c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[28:29], v[26:27], v[152:159] ; cc464098 1e62351c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[28:29], v[60:61], v[160:167] ; cc4640a0 1e82791c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[30:31], v[24:25], v[184:191] ; cc4640b8 1ee2311e
	ds_load_b64 v[46:47], v38 offset:18432                      ; d9d84800 2e000026
	ds_load_b64 v[56:57], v38 offset:22528                      ; d9d85800 38000026
	ds_load_b64 v[28:29], v38 offset:26624                      ; d9d86800 1c000026
	ds_load_b64 v[24:25], v38 offset:30720                      ; d9d87800 18000026
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[58:59], v[60:61], v[120:127] ; cc464078 1de2793a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[54:55], v[128:135] ; cc464080 1e026d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[30:31], v[26:27], v[6:13] ; cc464006 1c1a351e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[30:31], v[60:61], v[144:151] ; cc464090 1e42791e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[30:31], v[54:55], v[168:175] ; cc4640a8 1ea26d1e
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v31, v25 :: v_dual_mov_b32 v30, v24          ; ca100119 1f1e0118
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[58:61], v3, s[28:31], null offen offset:4096 ; c405c07c 4080383a 00100003
	buffer_load_b128 v[24:27], v2, s[28:31], null offen offset:4096 ; c405c07c 40803818 00100002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[64:65], v[32:33], v[72:79] ; cc464048 1d224140
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[66:67], v[42:43], v[120:127] ; cc464078 1de25542
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[64:65], v[34:35], v[80:87] ; cc464050 1d424540
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[42:43], v[88:95] ; cc464058 1d625540
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[64:65], v[62:63], v[96:103] ; cc464060 1d827d40
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[62:63], v[128:135] ; cc464080 1e027d42
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[66:67], v[32:33], v[104:111] ; cc464068 1da24142
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[34:35], v[112:119] ; cc464070 1dc24542
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[32:33], v[184:191] ; cc4640b8 1ee24146
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[32:33], v[136:143] ; cc464088 1e224144
	ds_load_b64 v[54:55], v38 offset:18688                      ; d9d84900 36000026
	ds_load_b64 v[64:65], v38 offset:22784                      ; d9d85900 40000026
	ds_load_b64 v[66:67], v38 offset:26880                      ; d9d86900 42000026
	ds_load_b64 v[32:33], v38 offset:30976                      ; d9d87900 20000026
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[34:35], v[152:159] ; cc464098 1e624544
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[42:43], v[160:167] ; cc4640a0 1e825544
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[68:69], v[62:63], v[176:183] ; cc4640b0 1ec27d44
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[70:71], v[34:35], v[6:13] ; cc464006 1c1a4546
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[42:43], v[144:151] ; cc464090 1e425546
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[70:71], v[62:63], v[168:175] ; cc4640a8 1ea27d46
	v_dual_mov_b32 v34, v41 :: v_dual_mov_b32 v15, v40          ; ca100129 220e0128
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v3, s[28:31], null offen offset:4608 ; c405c07c 40803844 00120003
	buffer_load_b128 v[40:43], v2, s[28:31], null offen offset:4608 ; c405c07c 40803828 00120002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[50:51], v[48:49], v[80:87] ; cc464050 1d426132
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[50:51], v[20:21], v[88:95] ; cc464058 1d622932
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[52:53], v[48:49], v[112:119] ; cc464070 1dc26134
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[52:53], v[20:21], v[120:127] ; cc464078 1de22934
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[22:23], v[96:103] ; cc464060 1d822d32
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[52:53], v[22:23], v[128:135] ; cc464080 1e022d34
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[50:51], v[44:45], v[72:79] ; cc464048 1d225932
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[44:45], v[104:111] ; cc464068 1da25934
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[16:17], v[44:45], v[136:143] ; cc464088 1e225910
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[48:49], v[152:159] ; cc464098 1e626110
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[20:21], v[160:167] ; cc4640a0 1e822910
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[22:23], v[176:183] ; cc4640b0 1ec22d10
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[18:19], v[44:45], v[184:191] ; cc4640b8 1ee25912
	ds_load_b64 v[50:51], v38 offset:18944                      ; d9d84a00 32000026
	ds_load_b64 v[52:53], v38 offset:23040                      ; d9d85a00 34000026
	ds_load_b64 v[16:17], v38 offset:27136                      ; d9d86a00 10000026
	ds_load_b64 v[44:45], v38 offset:31232                      ; d9d87a00 2c000026
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[18:19], v[48:49], v[6:13] ; cc464006 1c1a6112
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[18:19], v[20:21], v[144:151] ; cc464090 1e422912
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[18:19], v[22:23], v[168:175] ; cc4640a8 1ea22d12
	s_wait_dscnt 0x1                                            ; bfc60001
	v_dual_mov_b32 v49, v17 :: v_dual_mov_b32 v48, v16          ; ca100111 31300110
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v3, s[28:31], null offen offset:5120 ; c405c07c 40803814 00140003
	buffer_load_b128 v[16:19], v2, s[28:31], null offen offset:5120 ; c405c07c 40803810 00140002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[58:59], v[56:57], v[80:87] ; cc464050 1d42713a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[58:59], v[28:29], v[88:95] ; cc464058 1d62393a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[30:31], v[96:103] ; cc464060 1d823d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[30:31], v[128:135] ; cc464080 1e023d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[60:61], v[56:57], v[112:119] ; cc464070 1dc2713c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[46:47], v[104:111] ; cc464068 1da25d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[58:59], v[46:47], v[72:79] ; cc464048 1d225d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[60:61], v[28:29], v[120:127] ; cc464078 1de2393c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[24:25], v[46:47], v[136:143] ; cc464088 1e225d18
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[24:25], v[56:57], v[152:159] ; cc464098 1e627118
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[24:25], v[28:29], v[160:167] ; cc4640a0 1e823918
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[24:25], v[30:31], v[176:183] ; cc4640b0 1ec23d18
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[26:27], v[46:47], v[184:191] ; cc4640b8 1ee25d1a
	ds_load_b64 v[58:59], v38 offset:19200                      ; d9d84b00 3a000026
	ds_load_b64 v[60:61], v38 offset:23296                      ; d9d85b00 3c000026
	ds_load_b64 v[24:25], v38 offset:27392                      ; d9d86b00 18000026
	ds_load_b64 v[46:47], v38 offset:31488                      ; d9d87b00 2e000026
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[26:27], v[56:57], v[6:13] ; cc464006 1c1a711a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[26:27], v[28:29], v[144:151] ; cc464090 1e42391a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[26:27], v[30:31], v[168:175] ; cc4640a8 1ea23d1a
	s_wait_dscnt 0x1                                            ; bfc60001
	v_dual_mov_b32 v57, v25 :: v_dual_mov_b32 v56, v24          ; ca100119 39380118
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v3, s[28:31], null offen offset:5632 ; c405c07c 4080381c 00160003
	buffer_load_b128 v[24:27], v2, s[28:31], null offen offset:5632 ; c405c07c 40803818 00160002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[64:65], v[80:87] ; cc464050 1d428144
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[66:67], v[120:127] ; cc464078 1de28546
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[66:67], v[88:95] ; cc464058 1d628544
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[32:33], v[96:103] ; cc464060 1d824144
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[54:55], v[104:111] ; cc464068 1da26d46
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[68:69], v[54:55], v[72:79] ; cc464048 1d226d44
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[40:41], v[54:55], v[136:143] ; cc464088 1e226d28
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[64:65], v[152:159] ; cc464098 1e628128
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[40:41], v[66:67], v[160:167] ; cc4640a0 1e828528
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[40:41], v[32:33], v[176:183] ; cc4640b0 1ec24128
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[42:43], v[54:55], v[184:191] ; cc4640b8 1ee26d2a
	ds_load_b64 v[62:63], v38 offset:19456                      ; d9d84c00 3e000026
	ds_load_b64 v[68:69], v38 offset:23552                      ; d9d85c00 44000026
	ds_load_b64 v[40:41], v38 offset:27648                      ; d9d86c00 28000026
	ds_load_b64 v[54:55], v38 offset:31744                      ; d9d87c00 36000026
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[64:65], v[112:119] ; cc464070 1dc28146
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[32:33], v[128:135] ; cc464080 1e024146
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[42:43], v[64:65], v[6:13] ; cc464006 1c1a812a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[66:67], v[144:151] ; cc464090 1e42852a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[42:43], v[32:33], v[168:175] ; cc4640a8 1ea2412a
	v_mov_b32_e32 v42, v34                                      ; 7e540322
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[64:67], v3, s[28:31], null offen offset:6144 ; c405c07c 40803840 00180003
	buffer_load_b128 v[32:35], v2, s[28:31], null offen offset:6144 ; c405c07c 40803820 00180002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[48:49], v[120:127] ; cc464078 1de26116
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[50:51], v[104:111] ; cc464068 1da26516
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[20:21], v[50:51], v[72:79] ; cc464048 1d226514
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[52:53], v[80:87] ; cc464050 1d426914
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[44:45], v[128:135] ; cc464080 1e025916
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[52:53], v[112:119] ; cc464070 1dc26916
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[48:49], v[88:95] ; cc464058 1d626114
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[44:45], v[96:103] ; cc464060 1d825914
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[16:17], v[50:51], v[136:143] ; cc464088 1e226510
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[52:53], v[152:159] ; cc464098 1e626910
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[18:19], v[50:51], v[184:191] ; cc4640b8 1ee26512
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[48:49], v[160:167] ; cc4640a0 1e826110
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[44:45], v[176:183] ; cc4640b0 1ec25910
	ds_load_b64 v[20:21], v38 offset:19712                      ; d9d84d00 14000026
	ds_load_b64 v[22:23], v38 offset:23808                      ; d9d85d00 16000026
	ds_load_b64 v[16:17], v38 offset:27904                      ; d9d86d00 10000026
	ds_load_b64 v[50:51], v38 offset:32000                      ; d9d87d00 32000026
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[18:19], v[52:53], v[6:13] ; cc464006 1c1a6912
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[18:19], v[48:49], v[144:151] ; cc464090 1e426112
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[18:19], v[44:45], v[168:175] ; cc4640a8 1ea25912
	v_mov_b32_e32 v18, v42                                      ; 7e24032a
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v53, v51 :: v_dual_mov_b32 v52, v50          ; ca100133 35340132
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[42:45], v3, s[28:31], null offen offset:6656 ; c405c07c 4080382a 001a0003
	buffer_load_b128 v[48:51], v2, s[28:31], null offen offset:6656 ; c405c07c 40803830 001a0002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[58:59], v[72:79] ; cc464048 1d22751c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[46:47], v[128:135] ; cc464080 1e025d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[60:61], v[80:87] ; cc464050 1d42791c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[56:57], v[88:95] ; cc464058 1d62711c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[46:47], v[96:103] ; cc464060 1d825d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[60:61], v[112:119] ; cc464070 1dc2791e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[58:59], v[104:111] ; cc464068 1da2751e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[56:57], v[120:127] ; cc464078 1de2711e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[24:25], v[58:59], v[136:143] ; cc464088 1e227518
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[24:25], v[60:61], v[152:159] ; cc464098 1e627918
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[24:25], v[56:57], v[160:167] ; cc4640a0 1e827118
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[24:25], v[46:47], v[176:183] ; cc4640b0 1ec25d18
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[26:27], v[58:59], v[184:191] ; cc4640b8 1ee2751a
	ds_load_b64 v[28:29], v38 offset:19968                      ; d9d84e00 1c000026
	ds_load_b64 v[30:31], v38 offset:24064                      ; d9d85e00 1e000026
	ds_load_b64 v[24:25], v38 offset:28160                      ; d9d86e00 18000026
	ds_load_b64 v[58:59], v38 offset:32256                      ; d9d87e00 3a000026
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[26:27], v[46:47], v[168:175] ; cc4640a8 1ea25d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[26:27], v[60:61], v[6:13] ; cc464006 1c1a791a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[26:27], v[56:57], v[144:151] ; cc464090 1e42711a
	s_wait_dscnt 0x1                                            ; bfc60001
	v_dual_mov_b32 v47, v25 :: v_dual_mov_b32 v46, v24          ; ca100119 2f2e0118
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v61, v59 :: v_dual_mov_b32 v60, v58          ; ca10013b 3d3c013a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[24:27], v3, s[28:31], null offen offset:7168 ; c405c07c 40803818 001c0003
	buffer_load_b128 v[56:59], v2, s[28:31], null offen offset:7168 ; c405c07c 40803838 001c0002
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[54:55], v[128:135] ; cc464080 1e026d42
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[68:69], v[112:119] ; cc464070 1dc28942
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[64:65], v[62:63], v[72:79] ; cc464048 1d227d40
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[64:65], v[68:69], v[80:87] ; cc464050 1d428940
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[40:41], v[88:95] ; cc464058 1d625140
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[66:67], v[40:41], v[120:127] ; cc464078 1de25142
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[64:65], v[54:55], v[96:103] ; cc464060 1d826d40
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[66:67], v[62:63], v[104:111] ; cc464068 1da27d42
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[32:33], v[40:41], v[160:167] ; cc4640a0 1e825120
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[32:33], v[62:63], v[136:143] ; cc464088 1e227d20
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[68:69], v[152:159] ; cc464098 1e628920
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[32:33], v[54:55], v[176:183] ; cc4640b0 1ec26d20
	ds_load_b64 v[64:65], v38 offset:20224                      ; d9d84f00 40000026
	ds_load_b64 v[66:67], v38 offset:24320                      ; d9d85f00 42000026
	ds_load_b64 v[32:33], v38 offset:28416                      ; d9d86f00 20000026
	ds_load_b64 v[70:71], v38 offset:32512                      ; d9d87f00 46000026
	v_mov_b32_e32 v19, v39                                      ; 7e260327
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[34:35], v[62:63], v[184:191] ; cc4640b8 1ee27d22
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[34:35], v[40:41], v[144:151] ; cc464090 1e425122
	v_dual_mov_b32 v63, v1 :: v_dual_mov_b32 v62, v0            ; ca100101 3f3e0100
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[38:41], v3, s[28:31], null offen offset:7680 ; c405c07c 40803826 001e0003
	buffer_load_b128 v[0:3], v2, s[28:31], null offen offset:7680 ; c405c07c 40803800 001e0002
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[34:35], v[68:69], v[6:13] ; cc464006 1c1a8922
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[34:35], v[54:55], v[168:175] ; cc4640a8 1ea26d22
	v_mad_u32_u24 v68, s19, 0x50, v19                           ; d60b0044 044dfe13 00000050
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v68, v68, v18                              ; 4a882544
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[20:21], v[104:111] ; cc464068 1da2292c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[42:43], v[16:17], v[88:95] ; cc464058 1d62212a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[22:23], v[112:119] ; cc464070 1dc22d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[16:17], v[120:127] ; cc464078 1de2212c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[52:53], v[96:103] ; cc464060 1d82692a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[44:45], v[52:53], v[128:135] ; cc464080 1e02692c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[42:43], v[20:21], v[72:79] ; cc464048 1d22292a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[42:43], v[22:23], v[80:87] ; cc464050 1d422d2a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[48:49], v[16:17], v[160:167] ; cc4640a0 1e822130
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[22:23], v[152:159] ; cc464098 1e622d30
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[48:49], v[20:21], v[136:143] ; cc464088 1e222930
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[48:49], v[52:53], v[176:183] ; cc4640b0 1ec26930
	ds_load_b64 v[34:35], v68 offset:16384                      ; d9d84000 22000044
	ds_load_b64 v[42:43], v68 offset:20480                      ; d9d85000 2a000044
	ds_load_b64 v[44:45], v68 offset:24576                      ; d9d86000 2c000044
	ds_load_b64 v[48:49], v68 offset:28672                      ; d9d87000 30000044
	v_add_nc_u32_e32 v69, 4, v63                                ; 4a8a7e84
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[50:51], v[20:21], v[184:191] ; cc4640b8 1ee22932
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[50:51], v[22:23], v[6:13] ; cc464006 1c1a2d32
	v_sub_nc_u32_e32 v20, 0, v69                                ; 4c288a80
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_max_i32_e32 v20, v69, v20                                 ; 24282945
	v_med3_i32 v69, -1, v69, 1                                  ; d6200045 02068ac1
	v_add_nc_u32_e32 v63, 6, v63                                ; 4a7e7e86
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[50:51], v[16:17], v[144:151] ; cc464090 1e422132
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[50:51], v[52:53], v[168:175] ; cc4640a8 1ea26932
	v_lshrrev_b32_e32 v20, 1, v20                               ; 32282881
	v_sub_nc_u32_e32 v50, 0, v63                                ; 4c647e80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
(invalid instruction)                                        ; d72c0045
	v_cndmask_b32_e32 v1, v69, v20, vcc_lo                      ; 02022945
	v_max_i32_e32 v50, v63, v50                                 ; 2464653f
	v_med3_i32 v63, -1, v63, 1                                  ; d620003f 02067ec1
	v_lshrrev_b32_e32 v50, 1, v50                               ; 32646481
	v_lshl_add_u32 v69, v69, 11, s3                             ; d6460045 000d1745
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d72c003f
	v_cndmask_b32_e32 v1, v63, v50, vcc_lo                      ; 0202653f
	v_add_lshl_u32 v69, v69, v4, 2                              ; d6470045 020a0945
	v_lshl_add_u32 v63, v63, 11, s3                             ; d646003f 000d173f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v63, v63, v4, 2                              ; d647003f 020a093f
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v69, s[28:31], null offen        ; c405c07c 40803814 00000045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen        ; c405c07c 40803834 0000003f
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[28:29], v[72:79] ; cc464048 1d223918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[30:31], v[80:87] ; cc464050 1d423d18
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[46:47], v[88:95] ; cc464058 1d625d18
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[60:61], v[96:103] ; cc464060 1d827918
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[28:29], v[104:111] ; cc464068 1da2391a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[30:31], v[112:119] ; cc464070 1dc23d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[46:47], v[120:127] ; cc464078 1de25d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[60:61], v[128:135] ; cc464080 1e02791a
	ds_load_b64 v[16:17], v68 offset:16640                      ; d9d84100 10000044
	ds_load_b64 v[24:25], v68 offset:20736                      ; d9d85100 18000044
	ds_load_b64 v[26:27], v68 offset:24832                      ; d9d86100 1a000044
	ds_load_b64 v[50:51], v68 offset:28928                      ; d9d87100 32000044
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[56:57], v[28:29], v[136:143] ; cc464088 1e223938
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[30:31], v[152:159] ; cc464098 1e623d38
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[58:59], v[28:29], v[184:191] ; cc4640b8 1ee2393a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[58:59], v[30:31], v[6:13] ; cc464006 1c1a3d3a
	buffer_load_b128 v[28:31], v69, s[28:31], null offen offset:512 ; c405c07c 4080381c 00020045
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[56:57], v[46:47], v[160:167] ; cc4640a0 1e825d38
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[56:57], v[60:61], v[176:183] ; cc4640b0 1ec27938
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[58:59], v[46:47], v[144:151] ; cc464090 1e425d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[58:59], v[60:61], v[168:175] ; cc4640a8 1ea2793a
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[38:39], v[64:65], v[72:79] ; cc464048 1d228126
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[38:39], v[66:67], v[80:87] ; cc464050 1d428526
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[38:39], v[32:33], v[88:95] ; cc464058 1d624126
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[70:71], v[96:103] ; cc464060 1d828d26
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[64:65], v[104:111] ; cc464068 1da28128
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[66:67], v[112:119] ; cc464070 1dc28528
	v_maxmin_num_f32 v56, -4.0, v72, 4.0                        ; d6690038 03da90f7
	v_maxmin_num_f32 v60, -4.0, v74, 4.0                        ; d669003c 03da94f7
	v_maxmin_num_f32 v58, -4.0, v73, 4.0                        ; d669003a 03da92f7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[32:33], v[120:127] ; cc464078 1de24128
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[40:41], v[70:71], v[128:135] ; cc464080 1e028d28
	v_fma_mix_f32 v57, 0xab28, |v56|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206239 0bfe70ff 3728ab28
	v_fma_mix_f32 v61, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623d 0bfe78ff 3728ab28
	v_fma_mix_f32 v59, 0xab28, |v58|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623b 0bfe74ff 3728ab28
	v_maxmin_num_f32 v39, -4.0, v77, 4.0                        ; d6690027 03da9af7
	v_maxmin_num_f32 v41, -4.0, v78, 4.0                        ; d6690029 03da9cf7
	v_maxmin_num_f32 v47, -4.0, v79, 4.0                        ; d669002f 03da9ef7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_fmaak_f32 v59, v59, v58, 0x3f650000 :: v_dual_fmaak_f32 v56, v56, v57, 0x3f650000 ; c842753b 3b387338 3f650000
	v_fma_mix_f32 v40, 0xab28, |v39|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206228 0bfe4eff 3728ab28
	v_fma_mix_f32 v46, 0xab28, |v41|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622e 0bfe52ff 3728ab28
	v_maxmin_num_f32 v57, -4.0, v80, 4.0                        ; d6690039 03daa0f7
	v_dual_mul_f32 v73, v73, v59 :: v_dual_mul_f32 v72, v72, v56 ; c8c67749 49487148
	v_fma_mix_f32 v56, 0xab28, |v47|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206238 0bfe5eff 3728ab28
	v_fmaak_f32 v40, v40, v39, 0x3f650000                       ; 5a504f28 3f650000
	v_maxmin_num_f32 v59, -4.0, v81, 4.0                        ; d669003b 03daa2f7
	v_fma_mix_f32 v58, 0xab28, |v57|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623a 0bfe72ff 3728ab28
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	v_maxmin_num_f32 v72, -4.0, v75, 4.0                        ; d6690048 03da96f7
	v_dual_fmaak_f32 v56, v56, v47, 0x3f650000 :: v_dual_fmaak_f32 v41, v41, v46, 0x3f650000 ; c8425f38 38285d29 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fma_mix_f32 v73, 0xab28, |v72|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206249 0bfe90ff 3728ab28
	v_dual_mul_f32 v78, v78, v41 :: v_dual_mul_f32 v79, v79, v56 ; c8c6534e 4e4e714f
	v_dual_fmaak_f32 v73, v73, v72, 0x3f650000 :: v_dual_fmaak_f32 v60, v60, v61, 0x3f650000 ; c8429149 493c7b3c 3f650000
	v_maxmin_num_f32 v61, -4.0, v82, 4.0                        ; d669003d 03daa4f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_dual_mul_f32 v75, v75, v73 :: v_dual_mul_f32 v74, v74, v60 ; c8c6934b 4b4a794a
	v_maxmin_num_f32 v73, -4.0, v83, 4.0                        ; d6690049 03daa6f7
	v_fma_mix_f32 v60, 0xab28, |v59|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623c 0bfe76ff 3728ab28
	v_fma_mix_f32 v72, 0xab28, |v61|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe7aff 3728ab28
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_maxmin_num_f32 v74, -4.0, v76, 4.0                        ; d669004a 03da98f7
	v_dual_fmaak_f32 v60, v60, v59, 0x3f650000 :: v_dual_fmaak_f32 v57, v57, v58, 0x3f650000 ; c842773c 3c387539 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fma_mix_f32 v75, 0xab28, |v74|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624b 0bfe94ff 3728ab28
	v_dual_mul_f32 v81, v81, v60 :: v_dual_mul_f32 v80, v80, v57 ; c8c67951 51507350
	v_fmaak_f32 v74, v74, v75, 0x3f650000                       ; 5a94974a 3f650000
	v_maxmin_num_f32 v75, -4.0, v84, 4.0                        ; d669004b 03daa8f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_dual_mul_f32 v76, v76, v74 :: v_dual_mul_f32 v77, v77, v40 ; c8c6954c 4c4c514d
	v_fma_mix_f32 v74, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe92ff 3728ab28
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v81, -4.0, v87, 4.0                        ; d6690051 03daaef7
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_maxmin_num_f32 v77, -4.0, v85, 4.0                        ; d669004d 03daaaf7
	v_maxmin_num_f32 v79, -4.0, v86, 4.0                        ; d669004f 03daacf7
	v_fma_mix_f32 v76, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624c 0bfe96ff 3728ab28
	v_dual_fmaak_f32 v74, v74, v73, 0x3f650000 :: v_dual_fmaak_f32 v61, v61, v72, 0x3f650000 ; c842934a 4a3c913d 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_fma_mix_f32 v78, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe9aff 3728ab28
	v_fma_mix_f32 v80, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe9eff 3728ab28
	v_dual_mul_f32 v83, v83, v74 :: v_dual_mul_f32 v82, v82, v61 ; c8c69553 53527b52
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v78, v78, v77, 0x3f650000 :: v_dual_fmaak_f32 v75, v75, v76, 0x3f650000 ; c8429b4e 4e4a994b 3f650000
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v83, -4.0, v88, 4.0                        ; d6690053 03dab0f7
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_dual_mul_f32 v85, v85, v78 :: v_dual_mul_f32 v84, v84, v75 ; c8c69d55 55549754
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmaak_f32 v79, v79, v80, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 ; c842a14f 4f52a352 3f650000
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v85, -4.0, v89, 4.0                        ; d6690055 03dab2f7
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v56, -4.0, v92, 4.0                        ; d6690038 03dab8f7
	v_maxmin_num_f32 v58, -4.0, v93, 4.0                        ; d669003a 03dabaf7
	v_dual_mul_f32 v87, v87, v82 :: v_dual_mul_f32 v86, v86, v79 ; c8c6a557 57569f56
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mix_f32 v57, 0xab28, |v56|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206239 0bfe70ff 3728ab28
	v_fma_mix_f32 v59, 0xab28, |v58|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623b 0bfe74ff 3728ab28
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[0:1], v[64:65], v[136:143] ; cc464088 1e228100
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v87, -4.0, v90, 4.0                        ; d6690057 03dab4f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_dual_fmaak_f32 v59, v59, v58, 0x3f650000 :: v_dual_fmaak_f32 v56, v56, v57, 0x3f650000 ; c842753b 3b387338 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[2:3], v[64:65], v[184:191] ; cc4640b8 1ee28102
	v_maxmin_num_f32 v60, -4.0, v94, 4.0                        ; d669003c 03dabcf7
	v_maxmin_num_f32 v64, -4.0, v95, 4.0                        ; d6690040 03dabef7
	v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 :: v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 ; c842ab56 5652a953 3f650000
	v_dual_mul_f32 v93, v93, v59 :: v_dual_mul_f32 v92, v92, v56 ; c8c6775d 5d5c715c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[0:1], v[66:67], v[152:159] ; cc464098 1e628500
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[0:1], v[32:33], v[160:167] ; cc4640a0 1e824100
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[0:1], v[70:71], v[176:183] ; cc4640b0 1ec28d00
	v_fma_mix_f32 v61, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623d 0bfe78ff 3728ab28
	v_fma_mix_f32 v65, 0xab28, |v64|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe80ff 3728ab28
	v_dual_mul_f32 v89, v89, v86 :: v_dual_mul_f32 v88, v88, v83 ; c8c6ad59 5958a758
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[2:3], v[66:67], v[6:13] ; cc464006 1c1a8502
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[2:3], v[32:33], v[144:151] ; cc464090 1e424102
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[2:3], v[70:71], v[168:175] ; cc4640a8 1ea28d02
	v_maxmin_num_f32 v66, -4.0, v96, 4.0                        ; d6690042 03dac0f7
	v_maxmin_num_f32 v70, -4.0, v97, 4.0                        ; d6690046 03dac2f7
	v_dual_fmaak_f32 v65, v65, v64, 0x3f650000 :: v_dual_fmaak_f32 v60, v60, v61, 0x3f650000 ; c8428141 413c7b3c 3f650000
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v89, -4.0, v91, 4.0                        ; d6690059 03dab6f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_maxmin_num_f32 v72, -4.0, v98, 4.0                        ; d6690048 03dac4f7
	v_maxmin_num_f32 v74, -4.0, v99, 4.0                        ; d669004a 03dac6f7
	v_fma_mix_f32 v67, 0xab28, |v66|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206243 0bfe84ff 3728ab28
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_dual_mul_f32 v95, v95, v65 :: v_dual_mul_f32 v94, v94, v60 ; c8c6835f 5f5e795e
	v_maxmin_num_f32 v76, -4.0, v100, 4.0                       ; d669004c 03dac8f7
	v_fma_mix_f32 v47, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622f 0bfeb2ff 3728ab28
	v_fmaak_f32 v87, v87, v88, 0x3f650000                       ; 5aaeb157 3f650000
	v_maxmin_num_f32 v78, -4.0, v101, 4.0                       ; d669004e 03dacaf7
	v_fma_mix_f32 v73, 0xab28, |v72|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206249 0bfe90ff 3728ab28
	v_fma_mix_f32 v75, 0xab28, |v74|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624b 0bfe94ff 3728ab28
	v_dual_fmaak_f32 v71, v71, v70, 0x3f650000 :: v_dual_fmaak_f32 v66, v66, v67, 0x3f650000 ; c8428d47 47428742 3f650000
	v_maxmin_num_f32 v80, -4.0, v102, 4.0                       ; d6690050 03daccf7
	v_fma_mix_f32 v77, 0xab28, |v76|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624d 0bfe98ff 3728ab28
	v_maxmin_num_f32 v82, -4.0, v103, 4.0                       ; d6690052 03dacef7
	v_dual_fmaak_f32 v47, v47, v89, 0x3f650000 :: v_dual_mul_f32 v90, v90, v87 ; c846b32f 2f5aaf5a 3f650000
	v_fma_mix_f32 v79, 0xab28, |v78|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624f 0bfe9cff 3728ab28
	v_dual_fmaak_f32 v75, v75, v74, 0x3f650000 :: v_dual_fmaak_f32 v72, v72, v73, 0x3f650000 ; c842954b 4b489348 3f650000
	v_dual_mul_f32 v97, v97, v71 :: v_dual_mul_f32 v96, v96, v66 ; c8c68f61 61608560
	v_maxmin_num_f32 v84, -4.0, v104, 4.0                       ; d6690054 03dad0f7
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_maxmin_num_f32 v86, -4.0, v105, 4.0                       ; d6690056 03dad2f7
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_mul_f32_e32 v91, v91, v47                                 ; 10b65f5b
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_dual_fmaak_f32 v79, v79, v78, 0x3f650000 :: v_dual_fmaak_f32 v76, v76, v77, 0x3f650000 ; c8429d4f 4f4c9b4c 3f650000
	v_dual_mul_f32 v99, v99, v75 :: v_dual_mul_f32 v98, v98, v72 ; c8c69763 63629162
	v_maxmin_num_f32 v88, -4.0, v106, 4.0                       ; d6690058 03dad4f7
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c842a553 5350a350 3f650000
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v90, -4.0, v107, 4.0                       ; d669005a 03dad6f7
	v_maxmin_num_f32 v92, -4.0, v108, 4.0                       ; d669005c 03dad8f7
	v_dual_mul_f32 v101, v101, v79 :: v_dual_mul_f32 v100, v100, v76 ; c8c69f65 65649964
	v_maxmin_num_f32 v94, -4.0, v109, 4.0                       ; d669005e 03dadaf7
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c842ad57 5754ab54 3f650000
	v_maxmin_num_f32 v96, -4.0, v110, 4.0                       ; d6690060 03dadcf7
	v_dual_mul_f32 v103, v103, v83 :: v_dual_mul_f32 v102, v102, v80 ; c8c6a767 6766a166
	v_maxmin_num_f32 v98, -4.0, v111, 4.0                       ; d6690062 03dadef7
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_maxmin_num_f32 v100, -4.0, v112, 4.0                      ; d6690064 03dae0f7
	v_dual_mul_f32 v105, v105, v87 :: v_dual_mul_f32 v104, v104, v84 ; c8c6af69 6968a968
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v102, -4.0, v113, 4.0                      ; d6690066 03dae2f7
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 ; c842bd5f 5f5cbb5c 3f650000
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v104, -4.0, v114, 4.0                      ; d6690068 03dae4f7
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v97, 0x3f650000 ; c842c563 6360c360 3f650000
	v_dual_mul_f32 v107, v107, v91 :: v_dual_mul_f32 v106, v106, v88 ; c8c6b76b 6b6ab16a
	v_dual_mul_f32 v109, v109, v95 :: v_dual_mul_f32 v108, v108, v92 ; c8c6bf6d 6d6cb96c
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c842cd67 6764cb64 3f650000
	v_dual_mul_f32 v111, v111, v99 :: v_dual_mul_f32 v110, v110, v96 ; c8c6c76f 6f6ec16e
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v106, -4.0, v115, 4.0                      ; d669006a 03dae6f7
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v108, -4.0, v116, 4.0                      ; d669006c 03dae8f7
	v_dual_mul_f32 v113, v113, v103 :: v_dual_mul_f32 v112, v112, v100 ; c8c6cf71 7170c970
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v110, -4.0, v117, 4.0                      ; d669006e 03daeaf7
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v118, 4.0                      ; d6690070 03daecf7
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 ; c842d56b 6b68d368 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
	v_dual_mul_f32 v115, v115, v107 :: v_dual_mul_f32 v114, v114, v104 ; c8c6d773 7372d172
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v108 ; c8c6df75 7574d974
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v119, 4.0                      ; d6690072 03daeef7
	v_maxmin_num_f32 v57, -4.0, v123, 4.0                       ; d6690039 03daf6f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v116, -4.0, v120, 4.0                      ; d6690074 03daf0f7
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_fma_mix_f32 v58, 0xab28, |v57|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623a 0bfe72ff 3728ab28
	v_maxmin_num_f32 v59, -4.0, v124, 4.0                       ; d669003b 03daf8f7
	v_maxmin_num_f32 v61, -4.0, v125, 4.0                       ; d669003d 03dafaf7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_fmaak_f32 v58, v58, v57, 0x3f650000                       ; 5a74733a 3f650000
	v_fma_mix_f32 v60, 0xab28, |v59|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623c 0bfe76ff 3728ab28
	v_maxmin_num_f32 v65, -4.0, v126, 4.0                       ; d6690041 03dafcf7
	v_fma_mix_f32 v64, 0xab28, |v61|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206240 0bfe7aff 3728ab28
	v_maxmin_num_f32 v67, -4.0, v127, 4.0                       ; d6690043 03dafef7
	v_dual_mul_f32 v119, v119, v115 :: v_dual_mul_f32 v118, v118, v112 ; c8c6e777 7776e176
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v66, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206242 0bfe82ff 3728ab28
	v_dual_fmaak_f32 v64, v64, v61, 0x3f650000 :: v_dual_fmaak_f32 v59, v59, v60, 0x3f650000 ; c8427b40 403a793b 3f650000
	v_fma_mix_f32 v70, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe86ff 3728ab28
	v_maxmin_num_f32 v71, -4.0, v128, 4.0                       ; d6690047 03db00f7
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v121, 4.0                      ; d6690076 03daf2f7
	v_maxmin_num_f32 v73, -4.0, v129, 4.0                       ; d6690049 03db02f7
	v_dual_mul_f32 v124, v124, v59 :: v_dual_mul_f32 v125, v125, v64 ; c8c6777c 7c7c817d
	v_dual_fmaak_f32 v70, v70, v67, 0x3f650000 :: v_dual_fmaak_f32 v65, v65, v66, 0x3f650000 ; c8428746 46408541 3f650000
	v_maxmin_num_f32 v75, -4.0, v130, 4.0                       ; d669004b 03db04f7
	v_fma_mix_f32 v72, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe8eff 3728ab28
	v_maxmin_num_f32 v77, -4.0, v131, 4.0                       ; d669004d 03db06f7
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fma_mix_f32 v74, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe92ff 3728ab28
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_mul_f32 v127, v127, v70 :: v_dual_mul_f32 v126, v126, v65 ; c8c68d7f 7f7e837e
	v_fma_mix_f32 v76, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624c 0bfe96ff 3728ab28
	v_maxmin_num_f32 v79, -4.0, v132, 4.0                       ; d669004f 03db08f7
	v_fma_mix_f32 v78, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe9aff 3728ab28
	v_maxmin_num_f32 v81, -4.0, v133, 4.0                       ; d6690051 03db0af7
	v_dual_fmaak_f32 v119, v119, v118, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c842ed77 7774eb74 3f650000
	v_dual_fmaak_f32 v74, v74, v73, 0x3f650000 :: v_dual_fmaak_f32 v71, v71, v72, 0x3f650000 ; c842934a 4a469147 3f650000
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fma_mix_f32 v80, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe9eff 3728ab28
	v_maxmin_num_f32 v83, -4.0, v134, 4.0                       ; d6690053 03db0cf7
	v_dual_fmaak_f32 v78, v78, v77, 0x3f650000 :: v_dual_fmaak_f32 v75, v75, v76, 0x3f650000 ; c8429b4e 4e4a994b 3f650000
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v135, 4.0                       ; d6690055 03db0ef7
	v_dual_mul_f32 v121, v121, v119 :: v_dual_mul_f32 v120, v120, v116 ; c8c6ef79 7978e978
	v_dual_mul_f32 v129, v129, v74 :: v_dual_mul_f32 v128, v128, v71 ; c8c69581 81808f80
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v136, 4.0                       ; d6690057 03db10f7
	v_dual_mul_f32 v131, v131, v78 :: v_dual_mul_f32 v130, v130, v75 ; c8c69d83 83829782
	v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 :: v_dual_fmaak_f32 v79, v79, v80, 0x3f650000 ; c842a352 524ea14f 3f650000
	v_maxmin_num_f32 v89, -4.0, v137, 4.0                       ; d6690059 03db12f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v122, 4.0                      ; d6690078 03daf4f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v138, 4.0                       ; d669005b 03db14f7
	v_maxmin_num_f32 v93, -4.0, v139, 4.0                       ; d669005d 03db16f7
	v_dual_mul_f32 v133, v133, v82 :: v_dual_mul_f32 v132, v132, v79 ; c8c6a585 85849f84
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 :: v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 ; c842ab56 5652a953 3f650000
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v140, 4.0                       ; d669005f 03db18f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v141, 4.0                       ; d6690061 03db1af7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 :: v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 ; c842b35a 5a56b157 3f650000
	v_dual_mul_f32 v135, v135, v86 :: v_dual_mul_f32 v134, v134, v83 ; c8c6ad87 8786a786
	v_fmaak_f32 v120, v120, v121, 0x3f650000                    ; 5af0f378 3f650000
	v_maxmin_num_f32 v99, -4.0, v142, 4.0                       ; d6690063 03db1cf7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v143, 4.0                      ; d6690065 03db1ef7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 :: v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 ; c842bb5e 5e5ab95b 3f650000
	v_dual_mul_f32 v137, v137, v90 :: v_dual_mul_f32 v136, v136, v87 ; c8c6b589 8988af88
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v103, -4.0, v152, 4.0                      ; d6690067 03db30f7
	v_dual_mul_f32 v122, v122, v120 :: v_dual_mul_f32 v123, v123, v58 ; c8c6f17a 7a7a757b
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v105, -4.0, v153, 4.0                      ; d6690069 03db32f7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c842c362 625ec15f 3f650000
	v_dual_mul_f32 v139, v139, v94 :: v_dual_mul_f32 v138, v138, v91 ; c8c6bd8b 8b8ab78a
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_maxmin_num_f32 v107, -4.0, v154, 4.0                      ; d669006b 03db34f7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_maxmin_num_f32 v109, -4.0, v155, 4.0                      ; d669006d 03db36f7
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 :: v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 ; c842cb66 6662c963 3f650000
	v_maxmin_num_f32 v111, -4.0, v156, 4.0                      ; d669006f 03db38f7
	v_dual_mul_f32 v141, v141, v98 :: v_dual_mul_f32 v140, v140, v95 ; c8c6c58d 8d8cbf8c
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_maxmin_num_f32 v113, -4.0, v157, 4.0                      ; d6690071 03db3af7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_maxmin_num_f32 v115, -4.0, v158, 4.0                      ; d6690073 03db3cf7
	v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 :: v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 ; c842d36a 6a66d167 3f650000
	v_maxmin_num_f32 v117, -4.0, v159, 4.0                      ; d6690075 03db3ef7
	v_dual_mul_f32 v143, v143, v102 :: v_dual_mul_f32 v142, v142, v99 ; c8c6cd8f 8f8ec78e
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v160, 4.0                      ; d6690077 03db40f7
	v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 :: v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 ; c842db6e 6e6ad96b 3f650000
	v_maxmin_num_f32 v121, -4.0, v161, 4.0                      ; d6690079 03db42f7
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_dual_mul_f32 v153, v153, v106 :: v_dual_mul_f32 v152, v152, v103 ; c8c6d599 9998cf98
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_maxmin_num_f32 v123, -4.0, v162, 4.0                      ; d669007b 03db44f7
	v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 :: v_dual_fmaak_f32 v111, v111, v112, 0x3f650000 ; c842e372 726ee16f 3f650000
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v163, 4.0                      ; d669007d 03db46f7
	v_dual_mul_f32 v155, v155, v110 :: v_dual_mul_f32 v154, v154, v107 ; c8c6dd9b 9b9ad79a
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_dual_fmaak_f32 v118, v118, v117, 0x3f650000 :: v_dual_fmaak_f32 v115, v115, v116, 0x3f650000 ; c842eb76 7672e973 3f650000
	v_maxmin_num_f32 v127, -4.0, v164, 4.0                      ; d669007f 03db48f7
	v_maxmin_num_f32 v129, -4.0, v165, 4.0                      ; d6690081 03db4af7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_mul_f32 v157, v157, v114 :: v_dual_mul_f32 v156, v156, v111 ; c8c6e59d 9d9cdf9c
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 :: v_dual_fmaak_f32 v119, v119, v120, 0x3f650000 ; c842f37a 7a76f177 3f650000
	v_maxmin_num_f32 v131, -4.0, v166, 4.0                      ; d6690083 03db4cf7
	v_dual_mul_f32 v159, v159, v118 :: v_dual_mul_f32 v158, v158, v115 ; c8c6ed9f 9f9ee79e
	v_maxmin_num_f32 v133, -4.0, v167, 4.0                      ; d6690085 03db4ef7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_maxmin_num_f32 v135, -4.0, v176, 4.0                      ; d6690087 03db60f7
	v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 ; c842fb7e 7e7af97b 3f650000
	v_maxmin_num_f32 v137, -4.0, v177, 4.0                      ; d6690089 03db62f7
	v_dual_mul_f32 v161, v161, v122 :: v_dual_mul_f32 v160, v160, v119 ; c8c6f5a1 a1a0efa0
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 :: v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 ; c8430382 827f017f 3f650000
	v_maxmin_num_f32 v139, -4.0, v178, 4.0                      ; d669008b 03db64f7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_maxmin_num_f32 v141, -4.0, v179, 4.0                      ; d669008d 03db66f7
	v_dual_mul_f32 v163, v163, v126 :: v_dual_mul_f32 v162, v162, v123 ; c8c6fda3 a3a2f7a2
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_maxmin_num_f32 v143, -4.0, v180, 4.0                      ; d669008f 03db68f7
	v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 ; c8430b86 86830983 3f650000
	v_dual_mul_f32 v165, v165, v130 :: v_dual_mul_f32 v164, v164, v127 ; c8c705a5 a5a4ffa4
	v_maxmin_num_f32 v153, -4.0, v181, 4.0                      ; d6690099 03db6af7
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 :: v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 ; c843138a 8a871187 3f650000
	v_maxmin_num_f32 v155, -4.0, v182, 4.0                      ; d669009b 03db6cf7
	v_fma_mix_f32 v152, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff1eff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v183, 4.0                      ; d669009d 03db6ef7
	v_dual_mul_f32 v167, v167, v134 :: v_dual_mul_f32 v166, v166, v131 ; c8c70da7 a7a707a6
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 :: v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 ; c8431b8e 8e8b198b 3f650000
	v_maxmin_num_f32 v159, -4.0, v184, 4.0                      ; d669009f 03db70f7
	v_dual_mul_f32 v177, v177, v138 :: v_dual_mul_f32 v176, v176, v135 ; c8c715b1 b1b10fb0
	v_maxmin_num_f32 v161, -4.0, v185, 4.0                      ; d66900a1 03db72f7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_maxmin_num_f32 v163, -4.0, v186, 4.0                      ; d66900a3 03db74f7
	v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 :: v_dual_fmaak_f32 v143, v143, v152, 0x3f650000 ; c843339a 9a8f318f 3f650000
	v_dual_mul_f32 v179, v179, v142 :: v_dual_mul_f32 v178, v178, v139 ; c8c71db3 b3b317b2
	v_maxmin_num_f32 v165, -4.0, v187, 4.0                      ; d66900a5 03db76f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 :: v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 ; c8433b9e 9e9b399b 3f650000
	v_maxmin_num_f32 v167, -4.0, v188, 4.0                      ; d66900a7 03db78f7
	v_maxmin_num_f32 v177, -4.0, v189, 4.0                      ; d66900b1 03db7af7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_dual_mul_f32 v181, v181, v154 :: v_dual_mul_f32 v180, v180, v143 ; c8c735b5 b5b51fb4
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v179, -4.0, v190, 4.0                      ; d66900b3 03db7cf7
	v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 :: v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 ; c84343a2 a29f419f 3f650000
	v_dual_mul_f32 v183, v183, v158 :: v_dual_mul_f32 v182, v182, v155 ; c8c73db7 b7b737b6
	v_fma_mix_f32 v176, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff4eff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_maxmin_num_f32 v181, -4.0, v191, 4.0                      ; d66900b5 03db7ef7
	v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 :: v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 ; c8434ba6 a6a349a3 3f650000
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_dual_mul_f32 v185, v185, v162 :: v_dual_mul_f32 v184, v184, v159 ; c8c745b9 b9b93fb8
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_maxmin_num_f32 v183, -4.0, v6, 4.0                        ; d66900b7 03da0cf7
	v_dual_fmaak_f32 v178, v178, v177, 0x3f650000 :: v_dual_fmaak_f32 v167, v167, v176, 0x3f650000 ; c84363b2 b2a761a7 3f650000
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_dual_mul_f32 v187, v187, v166 :: v_dual_mul_f32 v186, v186, v163 ; c8c74dbb bbbb47ba
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_maxmin_num_f32 v185, -4.0, v7, 4.0                        ; d66900b9 03da0ef7
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_dual_mul_f32 v189, v189, v178 :: v_dual_mul_f32 v188, v188, v167 ; c8c765bd bdbd4fbc
	v_dual_fmaak_f32 v182, v182, v181, 0x3f650000 :: v_dual_fmaak_f32 v179, v179, v180, 0x3f650000 ; c8436bb6 b6b369b3 3f650000
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v187, -4.0, v8, 4.0                        ; d66900bb 03da10f7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_maxmin_num_f32 v189, -4.0, v9, 4.0                        ; d66900bd 03da12f7
	v_dual_mul_f32 v191, v191, v182 :: v_dual_mul_f32 v190, v190, v179 ; c8c76dbf bfbf67be
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 :: v_dual_fmaak_f32 v183, v183, v184, 0x3f650000 ; c84373ba bab771b7 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d3
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v191, -4.0, v10, 4.0                       ; d66900bf 03da14f7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_maxmin_num_f32 v74, -4.0, v13, 4.0                        ; d669004a 03da1af7
	v_dual_mul_f32 v7, v7, v186 :: v_dual_mul_f32 v6, v6, v183  ; c8c77507 07076f06
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c84379bb bbbf7bbe 3f650000
	v_fma_mix_f32 v75, 0xab28, |v74|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624b 0bfe94ff 3728ab28
	v_maxmin_num_f32 v76, -4.0, v144, 4.0                       ; d669004c 03db20f7
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
	v_fma_mix_f32 v7, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bff7eff 3728ab28
	v_maxmin_num_f32 v78, -4.0, v145, 4.0                       ; d669004e 03db22f7
	v_dual_mul_f32 v9, v9, v190 :: v_dual_mul_f32 v8, v8, v187  ; c8c77d09 09097708
	v_maxmin_num_f32 v80, -4.0, v146, 4.0                       ; d6690050 03db24f7
	v_fma_mix_f32 v77, 0xab28, |v76|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624d 0bfe98ff 3728ab28
	v_maxmin_num_f32 v82, -4.0, v147, 4.0                       ; d6690052 03db26f7
	v_fmaak_f32 v191, v191, v7, 0x3f650000                      ; 5b7e0fbf 3f650000
	v_fma_mix_f32 v79, 0xab28, |v78|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624f 0bfe9cff 3728ab28
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
	v_maxmin_num_f32 v8, -4.0, v11, 4.0                         ; d6690008 03da16f7
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_maxmin_num_f32 v84, -4.0, v148, 4.0                       ; d6690054 03db28f7
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_maxmin_num_f32 v86, -4.0, v149, 4.0                       ; d6690056 03db2af7
	v_dual_fmaak_f32 v79, v79, v78, 0x3f650000 :: v_dual_fmaak_f32 v76, v76, v77, 0x3f650000 ; c8429d4f 4f4c9b4c 3f650000
	v_fma_mix_f32 v9, 0xab28, |v8|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206209 0bfe10ff 3728ab28
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c842a553 5350a350 3f650000
	v_maxmin_num_f32 v88, -4.0, v150, 4.0                       ; d6690058 03db2cf7
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_maxmin_num_f32 v90, -4.0, v151, 4.0                       ; d669005a 03db2ef7
	v_dual_mul_f32 v145, v145, v79 :: v_dual_mul_f32 v144, v144, v76 ; c8c69f91 91909990
	v_fmaak_f32 v9, v9, v8, 0x3f650000                          ; 5a121109 3f650000
	v_dual_mul_f32 v147, v147, v83 :: v_dual_mul_f32 v146, v146, v80 ; c8c6a793 9392a192
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v168, 4.0                       ; d669005c 03db50f7
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c842ad57 5754ab54 3f650000
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_maxmin_num_f32 v94, -4.0, v169, 4.0                       ; d669005e 03db52f7
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_dual_mul_f32 v11, v11, v9 :: v_dual_mul_f32 v10, v10, v191 ; c8c6130b 0b0b7f0a
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v96, -4.0, v170, 4.0                       ; d6690060 03db54f7
	v_dual_mul_f32 v149, v149, v87 :: v_dual_mul_f32 v148, v148, v84 ; c8c6af95 9594a994
	v_maxmin_num_f32 v98, -4.0, v171, 4.0                       ; d6690062 03db56f7
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	v_maxmin_num_f32 v10, -4.0, v12, 4.0                        ; d669000a 03da18f7
	v_maxmin_num_f32 v100, -4.0, v172, 4.0                      ; d6690064 03db58f7
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v102, -4.0, v173, 4.0                      ; d6690066 03db5af7
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_dual_mul_f32 v151, v151, v91 :: v_dual_mul_f32 v150, v150, v88 ; c8c6b797 9796b196
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 ; c842bd5f 5f5cbb5c 3f650000
	v_maxmin_num_f32 v104, -4.0, v174, 4.0                      ; d6690068 03db5cf7
	v_fma_mix_f32 v11, 0xab28, |v10|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620b 0bfe14ff 3728ab28
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_maxmin_num_f32 v106, -4.0, v175, 4.0                      ; d669006a 03db5ef7
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v97, 0x3f650000 ; c842c563 6360c360 3f650000
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_dual_mul_f32 v169, v169, v95 :: v_dual_mul_f32 v168, v168, v92 ; c8c6bfa9 a9a8b9a8
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	s_wait_loadcnt_dscnt 0x207                                  ; bfc80207
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[34:35], 0 ; cc464050 1a024514
	v_dual_fmaak_f32 v75, v75, v74, 0x3f650000 :: v_dual_fmaak_f32 v10, v10, v11, 0x3f650000 ; c842954b 4b0a170a 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[34:35], 0 ; cc464070 1a024516
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[34:35], 0 ; cc464090 1a024534
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c842cd67 6764cb64 3f650000
	v_dual_mul_f32 v171, v171, v99 :: v_dual_mul_f32 v170, v170, v96 ; c8c6c7ab abaac1aa
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[34:35], 0 ; cc4640b0 1a024536
	s_wait_dscnt 0x3                                            ; bfc60003
	v_dual_mov_b32 v35, v17 :: v_dual_mov_b32 v34, v16          ; ca100111 23220110
	v_dual_mul_f32 v13, v13, v75 :: v_dual_mul_f32 v12, v12, v10 ; c8c6970d 0d0c150c
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[42:43], 0 ; cc464058 1a025514
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[42:43], 0 ; cc464078 1a025516
	v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 ; c842d56b 6b68d368 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[42:43], 0 ; cc464098 1a025534
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[42:43], 0 ; cc4640b8 1a025536
	v_dual_mov_b32 v43, v19 :: v_dual_mov_b32 v42, v18          ; ca100113 2b2a0112
	v_dual_mul_f32 v173, v173, v103 :: v_dual_mul_f32 v172, v172, v100 ; c8c6cfad adacc9ac
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[44:45], 0 ; cc464060 1a025914
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[44:45], 0 ; cc464080 1a025916
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
	v_dual_mov_b32 v13, v73 :: v_dual_mov_b32 v12, v72          ; ca100149 0d0c0148
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[48:49], 0 ; cc464088 1a026116
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[44:45], 0 ; cc4640a0 1a025934
	v_dual_mul_f32 v175, v175, v107 :: v_dual_mul_f32 v174, v174, v104 ; c8c6d7af afaed1ae
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[20:21], v[48:49], 0 ; cc464068 1a026114
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[44:45], 0 ; cc464048 1a025936
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[48:49], 0 ; cc464010 1a026136
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[48:49], 0 ; cc4640a8 1a026134
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:512 ; c405c07c 40803834 0002003f
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[34:35], v[80:87] ; cc464050 1d42451c
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[24:25], v[88:95] ; cc464058 1d62311c
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[26:27], v[96:103] ; cc464060 1d82351c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[34:35], v[112:119] ; cc464070 1dc2451e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[24:25], v[120:127] ; cc464078 1de2311e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[26:27], v[128:135] ; cc464080 1e02351e
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[50:51], v[136:143] ; cc464088 1e22651e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[50:51], v[104:111] ; cc464068 1da2651c
	ds_load_b64 v[44:45], v68 offset:16896                      ; d9d84200 2c000044
	ds_load_b64 v[28:29], v68 offset:20992                      ; d9d85200 1c000044
	ds_load_b64 v[30:31], v68 offset:25088                      ; d9d86200 1e000044
	ds_load_b64 v[48:49], v68 offset:29184                      ; d9d87200 30000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[26:27], v[160:167] ; cc4640a0 1e823534
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[24:25], v[152:159] ; cc464098 1e623134
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[26:27], v[72:79] ; cc464048 1d223536
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[24:25], v[184:191] ; cc4640b8 1ee23136
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[50:51], v[16:23] ; cc464010 1c426536
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[50:51], v[168:175] ; cc4640a8 1ea26534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[34:35], v[176:183] ; cc4640b0 1ec24536
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[34:35], v[144:151] ; cc464090 1e424534
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[24:27], v69, s[28:31], null offen offset:1024 ; c405c07c 40803818 00040045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:1024 ; c405c07c 40803834 0004003f
	s_wait_loadcnt_dscnt 0x103                                  ; bfc80103
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[44:45], v[112:119] ; cc464070 1dc2591a
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[28:29], v[120:127] ; cc464078 1de2391a
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[30:31], v[128:135] ; cc464080 1e023d1a
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[48:49], v[136:143] ; cc464088 1e22611a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[44:45], v[80:87] ; cc464050 1d425918
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[48:49], v[104:111] ; cc464068 1da26118
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[30:31], v[96:103] ; cc464060 1d823d18
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[28:29], v[88:95] ; cc464058 1d623918
	ds_load_b64 v[34:35], v68 offset:17152                      ; d9d84300 22000044
	ds_load_b64 v[24:25], v68 offset:21248                      ; d9d85300 18000044
	ds_load_b64 v[26:27], v68 offset:25344                      ; d9d86300 1a000044
	ds_load_b64 v[50:51], v68 offset:29440                      ; d9d87300 32000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[48:49], v[168:175] ; cc4640a8 1ea26134
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[44:45], v[144:151] ; cc464090 1e425934
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[28:29], v[152:159] ; cc464098 1e623934
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[30:31], v[160:167] ; cc4640a0 1e823d34
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[44:45], v[176:183] ; cc4640b0 1ec25936
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[28:29], v[184:191] ; cc4640b8 1ee23936
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[30:31], v[72:79] ; cc464048 1d223d36
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[48:49], v[16:23] ; cc464010 1c426136
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v69, s[28:31], null offen offset:1536 ; c405c07c 4080381c 00060045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:1536 ; c405c07c 40803834 0006003f
	s_wait_loadcnt_dscnt 0x103                                  ; bfc80103
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[34:35], v[112:119] ; cc464070 1dc2451e
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[26:27], v[96:103] ; cc464060 1d82351c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[50:51], v[104:111] ; cc464068 1da2651c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[24:25], v[120:127] ; cc464078 1de2311e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[24:25], v[88:95] ; cc464058 1d62311c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[26:27], v[128:135] ; cc464080 1e02351e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[34:35], v[80:87] ; cc464050 1d42451c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[50:51], v[136:143] ; cc464088 1e22651e
	ds_load_b64 v[44:45], v68 offset:17408                      ; d9d84400 2c000044
	ds_load_b64 v[28:29], v68 offset:21504                      ; d9d85400 1c000044
	ds_load_b64 v[30:31], v68 offset:25600                      ; d9d86400 1e000044
	ds_load_b64 v[48:49], v68 offset:29696                      ; d9d87400 30000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[34:35], v[144:151] ; cc464090 1e424534
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[24:25], v[152:159] ; cc464098 1e623134
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[26:27], v[160:167] ; cc4640a0 1e823534
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[50:51], v[168:175] ; cc4640a8 1ea26534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[34:35], v[176:183] ; cc4640b0 1ec24536
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[24:25], v[184:191] ; cc4640b8 1ee23136
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[26:27], v[72:79] ; cc464048 1d223536
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[50:51], v[16:23] ; cc464010 1c426536
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[24:27], v69, s[28:31], null offen offset:2048 ; c405c07c 40803818 00080045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:2048 ; c405c07c 40803834 0008003f
	s_wait_loadcnt_dscnt 0x100                                  ; bfc80100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[48:49], v[104:111] ; cc464068 1da26118
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[30:31], v[96:103] ; cc464060 1d823d18
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[44:45], v[112:119] ; cc464070 1dc2591a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[28:29], v[120:127] ; cc464078 1de2391a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[30:31], v[128:135] ; cc464080 1e023d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[48:49], v[136:143] ; cc464088 1e22611a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[28:29], v[88:95] ; cc464058 1d623918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[44:45], v[80:87] ; cc464050 1d425918
	ds_load_b64 v[34:35], v68 offset:17664                      ; d9d84500 22000044
	ds_load_b64 v[24:25], v68 offset:21760                      ; d9d85500 18000044
	ds_load_b64 v[26:27], v68 offset:25856                      ; d9d86500 1a000044
	ds_load_b64 v[50:51], v68 offset:29952                      ; d9d87500 32000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[44:45], v[144:151] ; cc464090 1e425934
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[28:29], v[152:159] ; cc464098 1e623934
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[30:31], v[160:167] ; cc4640a0 1e823d34
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[48:49], v[168:175] ; cc4640a8 1ea26134
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[44:45], v[176:183] ; cc4640b0 1ec25936
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[28:29], v[184:191] ; cc4640b8 1ee23936
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[30:31], v[72:79] ; cc464048 1d223d36
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[48:49], v[16:23] ; cc464010 1c426136
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v69, s[28:31], null offen offset:2560 ; c405c07c 4080381c 000a0045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:2560 ; c405c07c 40803834 000a003f
	s_wait_loadcnt_dscnt 0x100                                  ; bfc80100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[50:51], v[104:111] ; cc464068 1da2651c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[34:35], v[112:119] ; cc464070 1dc2451e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[24:25], v[120:127] ; cc464078 1de2311e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[26:27], v[128:135] ; cc464080 1e02351e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[50:51], v[136:143] ; cc464088 1e22651e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[26:27], v[96:103] ; cc464060 1d82351c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[24:25], v[88:95] ; cc464058 1d62311c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[34:35], v[80:87] ; cc464050 1d42451c
	ds_load_b64 v[44:45], v68 offset:17920                      ; d9d84600 2c000044
	ds_load_b64 v[28:29], v68 offset:22016                      ; d9d85600 1c000044
	ds_load_b64 v[30:31], v68 offset:26112                      ; d9d86600 1e000044
	ds_load_b64 v[48:49], v68 offset:30208                      ; d9d87600 30000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[34:35], v[144:151] ; cc464090 1e424534
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[24:25], v[152:159] ; cc464098 1e623134
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[26:27], v[160:167] ; cc4640a0 1e823534
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[50:51], v[168:175] ; cc4640a8 1ea26534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[34:35], v[176:183] ; cc4640b0 1ec24536
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[24:25], v[184:191] ; cc4640b8 1ee23136
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[26:27], v[72:79] ; cc464048 1d223536
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[50:51], v[16:23] ; cc464010 1c426536
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[24:27], v69, s[28:31], null offen offset:3072 ; c405c07c 40803818 000c0045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:3072 ; c405c07c 40803834 000c003f
	s_wait_loadcnt_dscnt 0x100                                  ; bfc80100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[48:49], v[104:111] ; cc464068 1da26118
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[44:45], v[112:119] ; cc464070 1dc2591a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[28:29], v[120:127] ; cc464078 1de2391a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[30:31], v[128:135] ; cc464080 1e023d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[48:49], v[136:143] ; cc464088 1e22611a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[30:31], v[96:103] ; cc464060 1d823d18
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[28:29], v[88:95] ; cc464058 1d623918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[44:45], v[80:87] ; cc464050 1d425918
	ds_load_b64 v[34:35], v68 offset:18176                      ; d9d84700 22000044
	ds_load_b64 v[24:25], v68 offset:22272                      ; d9d85700 18000044
	ds_load_b64 v[26:27], v68 offset:26368                      ; d9d86700 1a000044
	ds_load_b64 v[50:51], v68 offset:30464                      ; d9d87700 32000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[44:45], v[144:151] ; cc464090 1e425934
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[28:29], v[152:159] ; cc464098 1e623934
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[30:31], v[160:167] ; cc4640a0 1e823d34
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[48:49], v[168:175] ; cc4640a8 1ea26134
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[44:45], v[176:183] ; cc4640b0 1ec25936
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[28:29], v[184:191] ; cc4640b8 1ee23936
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[30:31], v[72:79] ; cc464048 1d223d36
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[48:49], v[16:23] ; cc464010 1c426136
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v69, s[28:31], null offen offset:3584 ; c405c07c 4080381c 000e0045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:3584 ; c405c07c 40803834 000e003f
	s_wait_loadcnt_dscnt 0x100                                  ; bfc80100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[50:51], v[104:111] ; cc464068 1da2651c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[34:35], v[112:119] ; cc464070 1dc2451e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[24:25], v[120:127] ; cc464078 1de2311e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[26:27], v[96:103] ; cc464060 1d82351c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[26:27], v[128:135] ; cc464080 1e02351e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[50:51], v[136:143] ; cc464088 1e22651e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[24:25], v[88:95] ; cc464058 1d62311c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[34:35], v[80:87] ; cc464050 1d42451c
	ds_load_b64 v[44:45], v68 offset:18432                      ; d9d84800 2c000044
	ds_load_b64 v[28:29], v68 offset:22528                      ; d9d85800 1c000044
	ds_load_b64 v[30:31], v68 offset:26624                      ; d9d86800 1e000044
	ds_load_b64 v[48:49], v68 offset:30720                      ; d9d87800 30000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[34:35], v[144:151] ; cc464090 1e424534
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[24:25], v[152:159] ; cc464098 1e623134
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[26:27], v[160:167] ; cc4640a0 1e823534
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[50:51], v[168:175] ; cc4640a8 1ea26534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[34:35], v[176:183] ; cc4640b0 1ec24536
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[24:25], v[184:191] ; cc4640b8 1ee23136
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[26:27], v[72:79] ; cc464048 1d223536
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[50:51], v[16:23] ; cc464010 1c426536
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[24:27], v69, s[28:31], null offen offset:4096 ; c405c07c 40803818 00100045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:4096 ; c405c07c 40803834 0010003f
	s_wait_loadcnt_dscnt 0x100                                  ; bfc80100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[48:49], v[104:111] ; cc464068 1da26118
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[44:45], v[112:119] ; cc464070 1dc2591a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[28:29], v[120:127] ; cc464078 1de2391a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[30:31], v[128:135] ; cc464080 1e023d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[48:49], v[136:143] ; cc464088 1e22611a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[30:31], v[96:103] ; cc464060 1d823d18
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[28:29], v[88:95] ; cc464058 1d623918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[44:45], v[80:87] ; cc464050 1d425918
	ds_load_b64 v[34:35], v68 offset:18688                      ; d9d84900 22000044
	ds_load_b64 v[24:25], v68 offset:22784                      ; d9d85900 18000044
	ds_load_b64 v[26:27], v68 offset:26880                      ; d9d86900 1a000044
	ds_load_b64 v[50:51], v68 offset:30976                      ; d9d87900 32000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[44:45], v[144:151] ; cc464090 1e425934
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[28:29], v[152:159] ; cc464098 1e623934
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[30:31], v[160:167] ; cc4640a0 1e823d34
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[48:49], v[168:175] ; cc4640a8 1ea26134
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[44:45], v[176:183] ; cc4640b0 1ec25936
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[28:29], v[184:191] ; cc4640b8 1ee23936
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[30:31], v[72:79] ; cc464048 1d223d36
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[48:49], v[16:23] ; cc464010 1c426136
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v69, s[28:31], null offen offset:4608 ; c405c07c 4080381c 00120045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:4608 ; c405c07c 40803834 0012003f
	s_wait_loadcnt_dscnt 0x100                                  ; bfc80100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[50:51], v[104:111] ; cc464068 1da2651c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[34:35], v[112:119] ; cc464070 1dc2451e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[24:25], v[120:127] ; cc464078 1de2311e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[26:27], v[128:135] ; cc464080 1e02351e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[50:51], v[136:143] ; cc464088 1e22651e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[26:27], v[96:103] ; cc464060 1d82351c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[24:25], v[88:95] ; cc464058 1d62311c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[34:35], v[80:87] ; cc464050 1d42451c
	ds_load_b64 v[44:45], v68 offset:18944                      ; d9d84a00 2c000044
	ds_load_b64 v[28:29], v68 offset:23040                      ; d9d85a00 1c000044
	ds_load_b64 v[30:31], v68 offset:27136                      ; d9d86a00 1e000044
	ds_load_b64 v[48:49], v68 offset:31232                      ; d9d87a00 30000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[34:35], v[144:151] ; cc464090 1e424534
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[24:25], v[152:159] ; cc464098 1e623134
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[26:27], v[160:167] ; cc4640a0 1e823534
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[50:51], v[168:175] ; cc4640a8 1ea26534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[34:35], v[176:183] ; cc4640b0 1ec24536
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[24:25], v[184:191] ; cc4640b8 1ee23136
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[26:27], v[72:79] ; cc464048 1d223536
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[50:51], v[16:23] ; cc464010 1c426536
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[24:27], v69, s[28:31], null offen offset:5120 ; c405c07c 40803818 00140045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:5120 ; c405c07c 40803834 0014003f
	s_wait_loadcnt_dscnt 0x100                                  ; bfc80100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[48:49], v[104:111] ; cc464068 1da26118
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[44:45], v[112:119] ; cc464070 1dc2591a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[28:29], v[120:127] ; cc464078 1de2391a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[30:31], v[128:135] ; cc464080 1e023d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[48:49], v[136:143] ; cc464088 1e22611a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[30:31], v[96:103] ; cc464060 1d823d18
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[28:29], v[88:95] ; cc464058 1d623918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[44:45], v[80:87] ; cc464050 1d425918
	ds_load_b64 v[34:35], v68 offset:19200                      ; d9d84b00 22000044
	ds_load_b64 v[24:25], v68 offset:23296                      ; d9d85b00 18000044
	ds_load_b64 v[26:27], v68 offset:27392                      ; d9d86b00 1a000044
	ds_load_b64 v[50:51], v68 offset:31488                      ; d9d87b00 32000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[44:45], v[144:151] ; cc464090 1e425934
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[28:29], v[152:159] ; cc464098 1e623934
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[30:31], v[160:167] ; cc4640a0 1e823d34
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[48:49], v[168:175] ; cc4640a8 1ea26134
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[44:45], v[176:183] ; cc4640b0 1ec25936
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[28:29], v[184:191] ; cc4640b8 1ee23936
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[30:31], v[72:79] ; cc464048 1d223d36
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[48:49], v[16:23] ; cc464010 1c426136
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v69, s[28:31], null offen offset:5632 ; c405c07c 4080381c 00160045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:5632 ; c405c07c 40803834 0016003f
	s_wait_loadcnt_dscnt 0x100                                  ; bfc80100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[50:51], v[104:111] ; cc464068 1da2651c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[34:35], v[112:119] ; cc464070 1dc2451e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[24:25], v[120:127] ; cc464078 1de2311e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[26:27], v[128:135] ; cc464080 1e02351e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[50:51], v[136:143] ; cc464088 1e22651e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[26:27], v[96:103] ; cc464060 1d82351c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[24:25], v[88:95] ; cc464058 1d62311c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[34:35], v[80:87] ; cc464050 1d42451c
	ds_load_b64 v[44:45], v68 offset:19456                      ; d9d84c00 2c000044
	ds_load_b64 v[28:29], v68 offset:23552                      ; d9d85c00 1c000044
	ds_load_b64 v[30:31], v68 offset:27648                      ; d9d86c00 1e000044
	ds_load_b64 v[48:49], v68 offset:31744                      ; d9d87c00 30000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[34:35], v[144:151] ; cc464090 1e424534
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[24:25], v[152:159] ; cc464098 1e623134
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[26:27], v[160:167] ; cc4640a0 1e823534
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[50:51], v[168:175] ; cc4640a8 1ea26534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[34:35], v[176:183] ; cc4640b0 1ec24536
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[24:25], v[184:191] ; cc4640b8 1ee23136
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[26:27], v[72:79] ; cc464048 1d223536
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[50:51], v[16:23] ; cc464010 1c426536
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[24:27], v69, s[28:31], null offen offset:6144 ; c405c07c 40803818 00180045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:6144 ; c405c07c 40803834 0018003f
	s_wait_loadcnt_dscnt 0x100                                  ; bfc80100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[48:49], v[104:111] ; cc464068 1da26118
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[44:45], v[112:119] ; cc464070 1dc2591a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[28:29], v[120:127] ; cc464078 1de2391a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[30:31], v[128:135] ; cc464080 1e023d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[48:49], v[136:143] ; cc464088 1e22611a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[30:31], v[96:103] ; cc464060 1d823d18
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[28:29], v[88:95] ; cc464058 1d623918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[44:45], v[80:87] ; cc464050 1d425918
	ds_load_b64 v[34:35], v68 offset:19712                      ; d9d84d00 22000044
	ds_load_b64 v[24:25], v68 offset:23808                      ; d9d85d00 18000044
	ds_load_b64 v[26:27], v68 offset:27904                      ; d9d86d00 1a000044
	ds_load_b64 v[50:51], v68 offset:32000                      ; d9d87d00 32000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[44:45], v[144:151] ; cc464090 1e425934
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[28:29], v[152:159] ; cc464098 1e623934
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[30:31], v[160:167] ; cc4640a0 1e823d34
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[48:49], v[168:175] ; cc4640a8 1ea26134
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[44:45], v[176:183] ; cc4640b0 1ec25936
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[28:29], v[184:191] ; cc4640b8 1ee23936
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[30:31], v[72:79] ; cc464048 1d223d36
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[48:49], v[16:23] ; cc464010 1c426136
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v69, s[28:31], null offen offset:6656 ; c405c07c 4080381c 001a0045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:6656 ; c405c07c 40803834 001a003f
	s_wait_loadcnt_dscnt 0x100                                  ; bfc80100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[50:51], v[104:111] ; cc464068 1da2651c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[34:35], v[112:119] ; cc464070 1dc2451e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[24:25], v[120:127] ; cc464078 1de2311e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[26:27], v[128:135] ; cc464080 1e02351e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[50:51], v[136:143] ; cc464088 1e22651e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[26:27], v[96:103] ; cc464060 1d82351c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[24:25], v[88:95] ; cc464058 1d62311c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[34:35], v[80:87] ; cc464050 1d42451c
	ds_load_b64 v[44:45], v68 offset:19968                      ; d9d84e00 2c000044
	ds_load_b64 v[28:29], v68 offset:24064                      ; d9d85e00 1c000044
	ds_load_b64 v[30:31], v68 offset:28160                      ; d9d86e00 1e000044
	ds_load_b64 v[48:49], v68 offset:32256                      ; d9d87e00 30000044
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[34:35], v[144:151] ; cc464090 1e424534
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[24:25], v[152:159] ; cc464098 1e623134
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[26:27], v[160:167] ; cc4640a0 1e823534
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[50:51], v[168:175] ; cc4640a8 1ea26534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[34:35], v[176:183] ; cc4640b0 1ec24536
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[24:25], v[184:191] ; cc4640b8 1ee23136
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[26:27], v[72:79] ; cc464048 1d223536
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[50:51], v[16:23] ; cc464010 1c426536
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[24:27], v69, s[28:31], null offen offset:7168 ; c405c07c 40803818 001c0045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:7168 ; c405c07c 40803834 001c003f
	s_wait_loadcnt_dscnt 0x100                                  ; bfc80100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[48:49], v[104:111] ; cc464068 1da26118
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[44:45], v[112:119] ; cc464070 1dc2591a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[28:29], v[120:127] ; cc464078 1de2391a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[30:31], v[128:135] ; cc464080 1e023d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[48:49], v[136:143] ; cc464088 1e22611a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[30:31], v[96:103] ; cc464060 1d823d18
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[28:29], v[88:95] ; cc464058 1d623918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[44:45], v[80:87] ; cc464050 1d425918
	ds_load_b64 v[34:35], v68 offset:20224                      ; d9d84f00 22000044
	ds_load_b64 v[24:25], v68 offset:24320                      ; d9d85f00 18000044
	ds_load_b64 v[26:27], v68 offset:28416                      ; d9d86f00 1a000044
	ds_load_b64 v[50:51], v68 offset:32512                      ; d9d87f00 32000044
	s_load_b32 s21, s[10:11], 0x30                              ; f4000545 f8000030
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[44:45], v[144:151] ; cc464090 1e425934
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[28:29], v[152:159] ; cc464098 1e623934
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[30:31], v[160:167] ; cc4640a0 1e823d34
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[48:49], v[168:175] ; cc4640a8 1ea26134
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[44:45], v[176:183] ; cc4640b0 1ec25936
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[28:29], v[184:191] ; cc4640b8 1ee23936
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[30:31], v[72:79] ; cc464048 1d223d36
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[48:49], v[16:23] ; cc464010 1c426136
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v69, s[28:31], null offen offset:7680 ; c405c07c 4080381c 001e0045
	buffer_load_b128 v[52:55], v63, s[28:31], null offen offset:7680 ; c405c07c 40803834 001e003f
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v69, v51 :: v_dual_mov_b32 v68, v50          ; ca100133 45440132
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshr_b32 s21, s21, 2                                      ; 85158215
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v44, v15, 10, s21                            ; d646002c 0055150f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v44, v44, v4, 2                              ; d647002c 020a092c
	buffer_load_b128 v[48:51], v44, s[28:31], null offen        ; c405c07c 40803830 0000002c
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[34:35], v[80:87] ; cc464050 1d42451c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[34:35], v[112:119] ; cc464070 1dc2451e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[26:27], v[96:103] ; cc464060 1d82351c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[68:69], v[104:111] ; cc464068 1da2891c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[24:25], v[88:95] ; cc464058 1d62311c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[24:25], v[120:127] ; cc464078 1de2311e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[26:27], v[128:135] ; cc464080 1e02351e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[68:69], v[136:143] ; cc464088 1e22891e
	v_maxmin_num_f32 v28, -4.0, v81, 4.0                        ; d669001c 03daa2f7
	v_maxmin_num_f32 v45, -4.0, v80, 4.0                        ; d669002d 03daa0f7
	v_maxmin_num_f32 v30, -4.0, v82, 4.0                        ; d669001e 03daa4f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
	v_fma_mix_f32 v63, 0xab28, |v45|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623f 0bfe5aff 3728ab28
	v_fma_mix_f32 v31, 0xab28, |v30|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621f 0bfe3cff 3728ab28
	v_fmaak_f32 v45, v45, v63, 0x3f650000                       ; 5a5a7f2d 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 :: v_dual_mul_f32 v80, v80, v45 ; c846391d 1d505b50 3f650000
	v_maxmin_num_f32 v45, -4.0, v83, 4.0                        ; d669002d 03daa6f7
	v_mul_f32_e32 v81, v81, v29                                 ; 10a23b51
	v_fma_mix_f32 v63, 0xab28, |v45|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623f 0bfe5aff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v80, -4.0, v84, 4.0                        ; d6690050 03daa8f7
	v_dual_fmaak_f32 v63, v63, v45, 0x3f650000 :: v_dual_fmaak_f32 v30, v30, v31, 0x3f650000 ; c8425b3f 3f1e3f1e 3f650000
	v_maxmin_num_f32 v45, -4.0, v88, 4.0                        ; d669002d 03dab0f7
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_dual_mul_f32 v83, v83, v63 :: v_dual_mul_f32 v82, v82, v30 ; c8c67f53 53523d52
	v_maxmin_num_f32 v30, -4.0, v87, 4.0                        ; d669001e 03daaef7
	v_fma_mix_f32 v63, 0xab28, |v45|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623f 0bfe5aff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v82, -4.0, v85, 4.0                        ; d6690052 03daaaf7
	v_fma_mix_f32 v31, 0xab28, |v30|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621f 0bfe3cff 3728ab28
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_dual_fmaak_f32 v31, v31, v30, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c8423d1f 1f50a350 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_fmaak_f32 v83, v83, v82, 0x3f650000                       ; 5aa6a553 3f650000
	v_maxmin_num_f32 v82, -4.0, v90, 4.0                        ; d6690052 03dab4f7
	v_dual_mul_f32 v87, v87, v31 :: v_dual_mul_f32 v84, v84, v80 ; c8c63f57 5754a154
	v_maxmin_num_f32 v80, -4.0, v89, 4.0                        ; d6690050 03dab2f7
	v_mul_f32_e32 v85, v85, v83                                 ; 10aaa755
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v84, -4.0, v86, 4.0                        ; d6690054 03daacf7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_dual_fmaak_f32 v45, v45, v63, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c8427f2d 2d54ab54 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v81, v81, v80, 0x3f650000 :: v_dual_mul_f32 v88, v88, v45 ; c846a151 51585b58 3f650000
	v_dual_mul_f32 v89, v89, v81 :: v_dual_mul_f32 v86, v86, v84 ; c8c6a359 5956a956
	v_maxmin_num_f32 v84, -4.0, v91, 4.0                        ; d6690054 03dab6f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870252
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v93, 4.0                        ; d6690058 03dabaf7
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v86, -4.0, v92, 4.0                        ; d6690056 03dab8f7
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_maxmin_num_f32 v45, -4.0, v97, 4.0                        ; d669002d 03dac2f7
	v_dual_fmaak_f32 v85, v85, v84, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v83, 0x3f650000 ; c842a955 5552a752 3f650000
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v87, 0x3f650000 ; c842b159 5956af56 3f650000
	v_fma_mix_f32 v63, 0xab28, |v45|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623f 0bfe5aff 3728ab28
	v_maxmin_num_f32 v81, -4.0, v98, 4.0                        ; d6690051 03dac4f7
	v_dual_mul_f32 v91, v91, v85 :: v_dual_mul_f32 v90, v90, v82 ; c8c6ab5b 5b5aa55a
	v_maxmin_num_f32 v83, -4.0, v99, 4.0                        ; d6690053 03dac6f7
	v_dual_mul_f32 v93, v93, v89 :: v_dual_mul_f32 v92, v92, v86 ; c8c6b35d 5d5cad5c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v90, -4.0, v94, 4.0                        ; d669005a 03dabcf7
	v_maxmin_num_f32 v85, -4.0, v100, 4.0                       ; d6690055 03dac8f7
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v92, -4.0, v95, 4.0                        ; d669005c 03dabef7
	v_maxmin_num_f32 v87, -4.0, v101, 4.0                       ; d6690057 03dacaf7
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v102, 4.0                       ; d6690059 03daccf7
	v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 ; c842a551 5154a754 3f650000
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_dual_mul_f32 v99, v99, v84 :: v_dual_mul_f32 v98, v98, v81 ; c8c6a963 6362a362
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 ; c842b95d 5d5ab75a 3f650000
	v_maxmin_num_f32 v91, -4.0, v103, 4.0                       ; d669005b 03dacef7
	v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 ; c842ad55 5558af58 3f650000
	v_dual_mul_f32 v95, v95, v93 :: v_dual_mul_f32 v94, v94, v90 ; c8c6bb5f 5f5eb55e
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v104, 4.0                       ; d669005d 03dad0f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_mul_f32 v101, v101, v88 :: v_dual_mul_f32 v100, v100, v85 ; c8c6b165 6564ab64
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v94, -4.0, v96, 4.0                        ; d669005e 03dac0f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c842b75c 5c58b559 3f650000
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_mul_f32 v103, v103, v92 :: v_dual_mul_f32 v102, v102, v89 ; c8c6b967 6766b366
	v_dual_fmaak_f32 v63, v63, v45, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c8425b3f 3f5ebf5e 3f650000
	v_maxmin_num_f32 v95, -4.0, v105, 4.0                       ; d669005f 03dad2f7
	v_maxmin_num_f32 v101, -4.0, v108, 4.0                      ; d6690065 03dad8f7
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v103, -4.0, v109, 4.0                      ; d6690067 03dadaf7
	v_dual_mul_f32 v97, v97, v63 :: v_dual_mul_f32 v96, v96, v94 ; c8c67f61 6160bd60
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d3
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v97, -4.0, v106, 4.0                       ; d6690061 03dad4f7
	v_maxmin_num_f32 v99, -4.0, v107, 4.0                       ; d6690063 03dad6f7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 :: v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 ; c842c764 6460c561 3f650000
	v_dual_mul_f32 v105, v105, v96 :: v_dual_mul_f32 v104, v104, v93 ; c8c6c169 6968bb68
	v_dual_mul_f32 v107, v107, v100 :: v_dual_mul_f32 v106, v106, v97 ; c8c6c96b 6b6ac36a
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_maxmin_num_f32 v105, -4.0, v110, 4.0                      ; d6690069 03dadcf7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v107, -4.0, v111, 4.0                      ; d669006b 03dadef7
	v_maxmin_num_f32 v63, -4.0, v114, 4.0                       ; d669003f 03dae4f7
	v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 ; c842cd65 6568cf68 3f650000
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_maxmin_num_f32 v86, -4.0, v115, 4.0                       ; d6690056 03dae6f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_fma_mix_f32 v85, 0xab28, |v63|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfe7eff 3728ab28
	v_dual_mul_f32 v109, v109, v104 :: v_dual_mul_f32 v108, v108, v101 ; c8c6d16d 6d6ccb6c
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v116, 4.0                       ; d6690058 03dae8f7
	v_fmaak_f32 v63, v63, v85, 0x3f650000                       ; 5a7eab3f 3f650000
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v109, -4.0, v112, 4.0                      ; d669006d 03dae0f7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_maxmin_num_f32 v90, -4.0, v117, 4.0                       ; d669005a 03daeaf7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_mul_f32 v114, v114, v63 ; c846ad57 57727f72 3f650000
	v_maxmin_num_f32 v92, -4.0, v118, 4.0                       ; d669005c 03daecf7
	v_maxmin_num_f32 v94, -4.0, v119, 4.0                       ; d669005e 03daeef7
	v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 :: v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 ; c842d76c 6c68d569 3f650000
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_dual_mul_f32 v111, v111, v108 :: v_dual_mul_f32 v110, v110, v105 ; c8c6d96f 6f6ed36e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[34:35], v[144:151] ; cc464090 1e424534
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[24:25], v[152:159] ; cc464098 1e623134
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 ; c842bd5f 5f5cbb5c 3f650000
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v111, -4.0, v113, 4.0                      ; d669006f 03dae2f7
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[26:27], v[160:167] ; cc4640a0 1e823534
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[68:69], v[168:175] ; cc4640a8 1ea28934
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[34:35], v[176:183] ; cc4640b0 1ec24536
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[24:25], v[184:191] ; cc4640b8 1ee23136
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[26:27], v[72:79] ; cc464048 1d223536
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[68:69], v[16:23] ; cc464010 1c428936
	v_maxmin_num_f32 v96, -4.0, v120, 4.0                       ; d6690060 03daf0f7
	v_dual_mul_f32 v117, v117, v91 :: v_dual_mul_f32 v116, v116, v88 ; c8c6b775 7574b174
	v_dual_mul_f32 v119, v119, v95 :: v_dual_mul_f32 v118, v118, v92 ; c8c6bf77 7776b976
	v_fma_mix_f32 v45, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfedeff 3728ab28
	v_fmaak_f32 v109, v109, v110, 0x3f650000                    ; 5adadd6d 3f650000
	v_maxmin_num_f32 v98, -4.0, v121, 4.0                       ; d6690062 03daf2f7
	v_maxmin_num_f32 v100, -4.0, v122, 4.0                      ; d6690064 03daf4f7
	v_maxmin_num_f32 v102, -4.0, v123, 4.0                      ; d6690066 03daf6f7
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v104, -4.0, v124, 4.0                      ; d6690068 03daf8f7
	v_fmaak_f32 v45, v45, v111, 0x3f650000                      ; 5a5adf2d 3f650000
	v_maxmin_num_f32 v106, -4.0, v125, 4.0                      ; d669006a 03dafaf7
	v_dual_mul_f32 v115, v115, v87 :: v_dual_mul_f32 v112, v112, v109 ; c8c6af73 7370db70
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_maxmin_num_f32 v108, -4.0, v126, 4.0                      ; d669006c 03dafcf7
	v_maxmin_num_f32 v110, -4.0, v127, 4.0                      ; d669006e 03dafef7
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_mul_f32_e32 v113, v113, v45                               ; 10e25b71
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v97, 0x3f650000 ; c842c563 6360c360 3f650000
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c842cd67 6764cb64 3f650000
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v112, -4.0, v128, 4.0                      ; d6690070 03db00f7
	v_maxmin_num_f32 v114, -4.0, v129, 4.0                      ; d6690072 03db02f7
	v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 ; c842d56b 6b68d368 3f650000
	v_maxmin_num_f32 v116, -4.0, v130, 4.0                      ; d6690074 03db04f7
	v_dual_mul_f32 v121, v121, v99 :: v_dual_mul_f32 v120, v120, v96 ; c8c6c779 7978c178
	v_dual_mul_f32 v123, v123, v103 :: v_dual_mul_f32 v122, v122, v100 ; c8c6cf7b 7b7ac97a
	v_maxmin_num_f32 v118, -4.0, v131, 4.0                      ; d6690076 03db06f7
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_dual_mul_f32 v125, v125, v107 :: v_dual_mul_f32 v124, v124, v104 ; c8c6d77d 7d7cd17c
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v132, 4.0                      ; d6690078 03db08f7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v122, -4.0, v133, 4.0                      ; d669007a 03db0af7
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_dual_mul_f32 v127, v127, v111 :: v_dual_mul_f32 v126, v126, v108 ; c8c6df7f 7f7ed97e
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v134, 4.0                      ; d669007c 03db0cf7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_dual_fmaak_f32 v119, v119, v118, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c842ed77 7774eb74 3f650000
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v135, 4.0                      ; d669007e 03db0ef7
	v_dual_mul_f32 v129, v129, v115 :: v_dual_mul_f32 v128, v128, v112 ; c8c6e781 8180e180
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c842f57b 7b78f378 3f650000
	v_dual_mul_f32 v131, v131, v119 :: v_dual_mul_f32 v130, v130, v116 ; c8c6ef83 8382e982
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v128, -4.0, v136, 4.0                      ; d6690080 03db10f7
	v_dual_mul_f32 v133, v133, v123 :: v_dual_mul_f32 v132, v132, v120 ; c8c6f785 8584f184
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v130, -4.0, v137, 4.0                      ; d6690082 03db12f7
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 ; c842fd7f 7f7cfb7c 3f650000
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v132, -4.0, v138, 4.0                      ; d6690084 03db14f7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_mul_f32 v135, v135, v127 :: v_dual_mul_f32 v134, v134, v124 ; c8c6ff87 8786f986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v134, -4.0, v139, 4.0                      ; d6690086 03db16f7
	v_dual_mul_f32 v137, v137, v131 :: v_dual_mul_f32 v136, v136, v128 ; c8c70789 89890188
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_maxmin_num_f32 v45, -4.0, v143, 4.0                       ; d669002d 03db1ef7
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_maxmin_num_f32 v136, -4.0, v140, 4.0                      ; d6690088 03db18f7
	v_maxmin_num_f32 v53, -4.0, v144, 4.0                       ; d6690035 03db20f7
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430d87 87850b84 3f650000
	v_fma_mix_f32 v52, 0xab28, |v45|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206234 0bfe5aff 3728ab28
	v_maxmin_num_f32 v55, -4.0, v145, 4.0                       ; d6690037 03db22f7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v68, -4.0, v146, 4.0                       ; d6690044 03db24f7
	v_fma_mix_f32 v54, 0xab28, |v53|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206236 0bfe6aff 3728ab28
	v_dual_mul_f32 v139, v139, v135 :: v_dual_mul_f32 v138, v138, v132 ; c8c70f8b 8b8b098a
	v_fma_mix_f32 v63, 0xab28, |v55|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623f 0bfe6eff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v69, 0xab28, |v68|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe88ff 3728ab28
	v_maxmin_num_f32 v86, -4.0, v147, 4.0                       ; d6690056 03db26f7
	v_dual_fmaak_f32 v52, v52, v45, 0x3f650000 :: v_dual_fmaak_f32 v53, v53, v54, 0x3f650000 ; c8425b34 34346d35 3f650000
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_maxmin_num_f32 v138, -4.0, v141, 4.0                      ; d669008a 03db1af7
	v_maxmin_num_f32 v88, -4.0, v148, 4.0                       ; d6690058 03db28f7
	v_dual_fmaak_f32 v68, v68, v69, 0x3f650000 :: v_dual_fmaak_f32 v63, v63, v55, 0x3f650000 ; c8428b44 443e6f3f 3f650000
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_maxmin_num_f32 v90, -4.0, v149, 4.0                       ; d669005a 03db2af7
	v_dual_mul_f32 v144, v144, v53 :: v_dual_mul_f32 v143, v143, v52 ; c8c66b90 908e698f
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v150, 4.0                       ; d669005c 03db2cf7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_dual_mul_f32 v146, v146, v68 :: v_dual_mul_f32 v145, v145, v63 ; c8c68992 92907f91
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_maxmin_num_f32 v94, -4.0, v151, 4.0                       ; d669005e 03db2ef7
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c843158b 8b891388 3f650000
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v96, -4.0, v152, 4.0                       ; d6690060 03db30f7
	v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 :: v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 ; c842b358 5856ad57 3f650000
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_maxmin_num_f32 v98, -4.0, v153, 4.0                       ; d6690062 03db32f7
	v_dual_mul_f32 v141, v141, v139 :: v_dual_mul_f32 v140, v140, v136 ; c8c7178d 8d8d118c
	v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 :: v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 ; c842bb5c 5c5ab55b 3f650000
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_maxmin_num_f32 v100, -4.0, v154, 4.0                      ; d6690064 03db34f7
	v_dual_mul_f32 v148, v148, v88 :: v_dual_mul_f32 v147, v147, v87 ; c8c6b194 9492af93
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_maxmin_num_f32 v140, -4.0, v142, 4.0                      ; d669008c 03db1cf7
	v_maxmin_num_f32 v102, -4.0, v155, 4.0                      ; d6690066 03db36f7
	v_dual_mul_f32 v150, v150, v92 :: v_dual_mul_f32 v149, v149, v91 ; c8c6b996 9694b795
	v_dual_fmaak_f32 v96, v96, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 ; c842c360 605ebd5f 3f650000
	v_maxmin_num_f32 v104, -4.0, v156, 4.0                      ; d6690068 03db38f7
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_maxmin_num_f32 v106, -4.0, v157, 4.0                      ; d669006a 03db3af7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_maxmin_num_f32 v108, -4.0, v158, 4.0                      ; d669006c 03db3cf7
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_dual_mul_f32 v152, v152, v96 :: v_dual_mul_f32 v151, v151, v95 ; c8c6c198 9896bf97
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 :: v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 ; c842cb64 6462c563 3f650000
	v_maxmin_num_f32 v110, -4.0, v159, 4.0                      ; d669006e 03db3ef7
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_fmaak_f32 v140, v140, v141, 0x3f650000                    ; 5b191b8c 3f650000
	v_maxmin_num_f32 v112, -4.0, v160, 4.0                      ; d6690070 03db40f7
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 :: v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 ; c842d368 6866cd67 3f650000
	v_dual_mul_f32 v154, v154, v100 :: v_dual_mul_f32 v153, v153, v99 ; c8c6c99a 9a98c799
	v_maxmin_num_f32 v114, -4.0, v161, 4.0                      ; d6690072 03db42f7
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_maxmin_num_f32 v116, -4.0, v162, 4.0                      ; d6690074 03db44f7
	v_mul_f32_e32 v142, v142, v140                              ; 111d198e
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 :: v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 ; c842db6c 6c6ad56b 3f650000
	v_maxmin_num_f32 v118, -4.0, v163, 4.0                      ; d6690076 03db46f7
	v_dual_mul_f32 v156, v156, v104 :: v_dual_mul_f32 v155, v155, v103 ; c8c6d19c 9c9acf9b
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v120, -4.0, v164, 4.0                      ; d6690078 03db48f7
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 :: v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 ; c842e370 706edd6f 3f650000
	v_dual_mul_f32 v158, v158, v108 :: v_dual_mul_f32 v157, v157, v107 ; c8c6d99e 9e9cd79d
	v_maxmin_num_f32 v122, -4.0, v165, 4.0                      ; d669007a 03db4af7
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v124, -4.0, v166, 4.0                      ; d669007c 03db4cf7
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 :: v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 ; c842eb74 7472e573 3f650000
	v_maxmin_num_f32 v126, -4.0, v167, 4.0                      ; d669007e 03db4ef7
	v_dual_mul_f32 v160, v160, v112 :: v_dual_mul_f32 v159, v159, v111 ; c8c6e1a0 a09edf9f
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_maxmin_num_f32 v128, -4.0, v168, 4.0                      ; d6690080 03db50f7
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	buffer_load_b128 v[88:91], v44, s[28:31], null offen offset:512 ; c405c07c 40803858 0002002c
	v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 :: v_dual_fmaak_f32 v119, v119, v118, 0x3f650000 ; c842f378 7876ed77 3f650000
	v_dual_mul_f32 v162, v162, v116 :: v_dual_mul_f32 v161, v161, v115 ; c8c6e9a2 a2a0e7a1
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v169, 4.0                      ; d6690082 03db52f7
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_maxmin_num_f32 v132, -4.0, v170, 4.0                      ; d6690084 03db54f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 ; c842fb7c 7c7af57b 3f650000
	v_maxmin_num_f32 v134, -4.0, v171, 4.0                      ; d6690086 03db56f7
	buffer_load_b128 v[92:95], v44, s[28:31], null offen offset:1024 ; c405c07c 4080385c 0004002c
	v_dual_mul_f32 v164, v164, v120 :: v_dual_mul_f32 v163, v163, v119 ; c8c6f1a4 a4a2efa3
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v172, 4.0                      ; d6690088 03db58f7
	v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 :: v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 ; c8430380 807efd7f 3f650000
	v_maxmin_num_f32 v138, -4.0, v173, 4.0                      ; d669008a 03db5af7
	v_dual_mul_f32 v166, v166, v124 :: v_dual_mul_f32 v165, v165, v123 ; c8c6f9a6 a6a4f7a5
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	buffer_load_b128 v[96:99], v44, s[28:31], null offen offset:1536 ; c405c07c 40803860 0006002c
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_maxmin_num_f32 v140, -4.0, v174, 4.0                      ; d669008c 03db5cf7
	v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 ; c8430b84 84830583 3f650000
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v175, 4.0                      ; d669008e 03db5ef7
	v_dual_mul_f32 v168, v168, v128 :: v_dual_mul_f32 v167, v167, v127 ; c8c701a8 a8a6ffa7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	buffer_load_b128 v[100:103], v44, s[28:31], null offen offset:2048 ; c405c07c 40803864 0008002c
	v_fmaak_f32 v135, v135, v134, 0x3f650000                    ; 5b0f0d87 3f650000
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v176, 4.0                      ; d6690090 03db60f7
	v_dual_mul_f32 v170, v170, v132 :: v_dual_mul_f32 v169, v169, v131 ; c8c709aa aaa907a9
	v_maxmin_num_f32 v146, -4.0, v177, 4.0                      ; d6690092 03db62f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c843158b 8b891388 3f650000
	v_mul_f32_e32 v171, v171, v135                              ; 11570fab
	buffer_load_b128 v[108:111], v44, s[28:31], null offen offset:2560 ; c405c07c 4080386c 000a002c
	v_maxmin_num_f32 v148, -4.0, v178, 4.0                      ; d6690094 03db64f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v179, 4.0                      ; d6690096 03db66f7
	v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 ; c8431d8f 8f8d1b8c 3f650000
	v_dual_mul_f32 v173, v173, v139 :: v_dual_mul_f32 v172, v172, v136 ; c8c717ad adad11ac
	v_maxmin_num_f32 v152, -4.0, v180, 4.0                      ; d6690098 03db68f7
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	buffer_load_b128 v[112:115], v44, s[28:31], null offen offset:3072 ; c405c07c 40803870 000c002c
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_maxmin_num_f32 v154, -4.0, v181, 4.0                      ; d669009a 03db6af7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_mul_f32 v175, v175, v143 :: v_dual_mul_f32 v174, v174, v140 ; c8c71faf afaf19ae
	v_maxmin_num_f32 v156, -4.0, v182, 4.0                      ; d669009c 03db6cf7
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v183, 4.0                      ; d669009e 03db6ef7
	buffer_load_b128 v[116:119], v44, s[28:31], null offen offset:3584 ; c405c07c 40803874 000e002c
	v_fmaak_f32 v148, v148, v149, 0x3f650000                    ; 5b292b94 3f650000
	v_dual_mul_f32 v177, v177, v147 :: v_dual_mul_f32 v176, v176, v144 ; c8c727b1 b1b121b0
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v184, 4.0                      ; d66900a0 03db70f7
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v185, 4.0                      ; d66900a2 03db72f7
	v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 :: v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 ; c8433398 98972d97 3f650000
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v186, 4.0                      ; d66900a4 03db74f7
	v_mul_f32_e32 v178, v178, v148                              ; 116529b2
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v187, 4.0                      ; d66900a6 03db76f7
	v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 :: v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 ; c8433b9c 9c9b359b 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v188, 4.0                      ; d66900a8 03db78f7
	v_dual_mul_f32 v180, v180, v152 :: v_dual_mul_f32 v179, v179, v151 ; c8c731b4 b4b32fb3
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v170, -4.0, v189, 4.0                      ; d66900aa 03db7af7
	v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 :: v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 ; c84343a0 a09f3d9f 3f650000
	v_maxmin_num_f32 v172, -4.0, v190, 4.0                      ; d66900ac 03db7cf7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_mul_f32 v182, v182, v156 :: v_dual_mul_f32 v181, v181, v155 ; c8c739b6 b6b537b5
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_maxmin_num_f32 v174, -4.0, v191, 4.0                      ; d66900ae 03db7ef7
	v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 :: v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 ; c8434ba4 a4a345a3 3f650000
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v72, 4.0                       ; d66900b0 03da90f7
	v_dual_mul_f32 v184, v184, v160 :: v_dual_mul_f32 v183, v183, v159 ; c8c741b8 b8b73fb7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 :: v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 ; c84353a8 a8a74da7 3f650000
	v_maxmin_num_f32 v178, -4.0, v73, 4.0                       ; d66900b2 03da92f7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v74, 4.0                       ; d66900b4 03da94f7
	v_dual_mul_f32 v186, v186, v164 :: v_dual_mul_f32 v185, v185, v163 ; c8c749ba bab947b9
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 :: v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 ; c8435bac acab55ab 3f650000
	v_maxmin_num_f32 v182, -4.0, v75, 4.0                       ; d66900b6 03da96f7
	v_dual_mul_f32 v188, v188, v168 :: v_dual_mul_f32 v187, v187, v167 ; c8c751bc bcbb4fbb
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_maxmin_num_f32 v184, -4.0, v76, 4.0                       ; d66900b8 03da98f7
	v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 :: v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 ; c84363b0 b0af5daf 3f650000
	v_dual_mul_f32 v190, v190, v172 :: v_dual_mul_f32 v189, v189, v171 ; c8c759be bebd57bd
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v186, -4.0, v77, 4.0                       ; d66900ba 03da9af7
	v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 :: v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 ; c8436bb4 b4b365b3 3f650000
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	s_load_b128 s[36:39], s[0:1], 0x30                          ; f4004900 f8000030
	v_dual_mul_f32 v72, v72, v176 :: v_dual_mul_f32 v191, v191, v175 ; c8c76148 48bf5fbf
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_add3_u32 v190, v5, s8, v62                                ; d65500be 04f81105
	v_lshlrev_b32_e32 v190, 2, v190                             ; 317d7c82
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b128 v[120:123], v190, s[36:39], null offen     ; c405c07c 40804878 000000be
	v_maxmin_num_f32 v188, -4.0, v78, 4.0                       ; d66900bc 03da9cf7
	v_maxmin_num_f32 v191, -4.0, v79, 4.0                       ; d66900bf 03da9ef7
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_mul_f32 v74, v74, v180 :: v_dual_mul_f32 v73, v73, v179 ; c8c7694a 4a496749
	v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 :: v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 ; c84373b8 b8b76db7 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v63, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623f 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	v_dual_mul_f32 v76, v76, v184 :: v_dual_mul_f32 v75, v75, v183 ; c8c7714c 4c4b6f4b
	v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 :: v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 ; c8437bbc bcbb75bb 3f650000
	v_fmaak_f32 v63, v63, v191, 0x3f650000                      ; 5a7f7f3f 3f650000
	v_dual_mul_f32 v78, v78, v188 :: v_dual_mul_f32 v77, v77, v187 ; c8c7794e 4e4d774d
	v_mul_f32_e32 v79, v79, v63                                 ; 109e7f4f
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	buffer_load_b128 v[76:79], v190, s[36:39], null offen offset:16 ; c405c07c 4080484c 000010be
	v_maxmin_num_f32 v106, -4.0, v17, 4.0                       ; d669006a 03da22f7
	v_maxmin_num_f32 v124, -4.0, v18, 4.0                       ; d669007c 03da24f7
	v_maxmin_num_f32 v126, -4.0, v19, 4.0                       ; d669007e 03da26f7
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_maxmin_num_f32 v74, -4.0, v16, 4.0                        ; d669004a 03da20f7
	v_maxmin_num_f32 v128, -4.0, v20, 4.0                       ; d6690080 03da28f7
	v_maxmin_num_f32 v130, -4.0, v21, 4.0                       ; d6690082 03da2af7
	v_maxmin_num_f32 v132, -4.0, v22, 4.0                       ; d6690084 03da2cf7
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_maxmin_num_f32 v134, -4.0, v23, 4.0                       ; d6690086 03da2ef7
	v_fma_mix_f32 v75, 0xab28, |v74|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624b 0bfe94ff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[48:49], v[40:41], 0 ; cc464088 1a025130
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fmaak_f32 v74, v74, v75, 0x3f650000                       ; 5a94974a 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[48:49], v[46:47], 0 ; cc464090 1a025d30
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[0:1], 0 ; cc464098 1a020130
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[38:39], 0 ; cc4640a0 1a024d32
	v_dual_fmaak_f32 v107, v106, v107, 0x3f650000 :: v_dual_mul_f32 v16, v16, v74 ; c846d76a 6b109510 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[50:51], v[40:41], 0 ; cc4640a8 1a025132
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[50:51], v[46:47], 0 ; cc4640b0 1a025d32
	v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 :: v_dual_mul_f32 v17, v17, v107 ; c846fb7c 7c10d711 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_mul_f32 v18, v18, v124 ; c846fd7f 7f12f912 3f650000
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 :: v_dual_mul_f32 v19, v19, v127 ; c8470380 8012ff13 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_mul_f32 v20, v20, v128 ; c8470583 83150114 3f650000
	v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 :: v_dual_mul_f32 v21, v21, v131 ; c8470b84 84150715 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_mul_f32 v22, v22, v132 ; c8470d87 87170916 3f650000
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	v_dual_mov_b32 v18, v190 :: v_dual_mul_f32 v23, v23, v135   ; ca0601be 12170f17
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[48:49], v[38:39], 0 ; cc464080 1a024d30
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[50:51], v[0:1], 0 ; cc4640b8 1a020132
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[88:89], v[2:3], v[128:135] ; cc464080 1e020558
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[90:91], v[2:3], v[160:167] ; cc4640a0 1e82055a
	buffer_load_b128 v[0:3], v18, s[36:39], null offen offset:64 ; c405c07c 40804800 00004012
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[88:89], v[58:59], v[152:159] ; cc464098 1e627558
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[90:91], v[58:59], v[184:191] ; cc4640b8 1ee2755a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[88:89], v[32:33], v[136:143] ; cc464088 1e224158
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[88:89], v[56:57], v[144:151] ; cc464090 1e427158
	buffer_load_b128 v[20:23], v18, s[36:39], null offen offset:80 ; c405c07c 40804814 00005012
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[90:91], v[32:33], v[168:175] ; cc4640a8 1ea2415a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[90:91], v[56:57], v[176:183] ; cc4640b0 1ec2715a
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[60:61], v[128:135] ; cc464080 1e02795c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[94:95], v[60:61], v[160:167] ; cc4640a0 1e82795e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[92:93], v[70:71], v[152:159] ; cc464098 1e628d5c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[94:95], v[70:71], v[184:191] ; cc4640b8 1ee28d5e
	v_lshlrev_b32_e32 v19, 11, v15                              ; 30261e8b
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[92:93], v[64:65], v[136:143] ; cc464088 1e22815c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[92:93], v[66:67], v[144:151] ; cc464090 1e42855c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[94:95], v[64:65], v[168:175] ; cc4640a8 1ea2815e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[94:95], v[66:67], v[176:183] ; cc4640b0 1ec2855e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[96:97], v[12:13], v[128:135] ; cc464080 1e021960
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[10:11], v[152:159] ; cc464098 1e621560
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[98:99], v[12:13], v[160:167] ; cc4640a0 1e821962
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[96:97], v[6:7], v[136:143] ; cc464088 1e220d60
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[10:11], v[184:191] ; cc4640b8 1ee21562
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[8:9], v[144:151] ; cc464090 1e421160
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[98:99], v[6:7], v[168:175] ; cc4640a8 1ea20d62
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[98:99], v[8:9], v[176:183] ; cc4640b0 1ec21162
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[100:101], v[28:29], v[128:135] ; cc464080 1e023964
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[100:101], v[82:83], v[152:159] ; cc464098 1e62a564
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[102:103], v[28:29], v[160:167] ; cc4640a0 1e823966
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[100:101], v[30:31], v[136:143] ; cc464088 1e223d64
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[102:103], v[82:83], v[184:191] ; cc4640b8 1ee2a566
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[80:81], v[144:151] ; cc464090 1e42a164
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[102:103], v[30:31], v[168:175] ; cc4640a8 1ea23d66
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[102:103], v[80:81], v[176:183] ; cc4640b0 1ec2a166
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[108:109], v[84:85], v[128:135] ; cc464080 1e02a96c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[34:35], v[152:159] ; cc464098 1e62456c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[110:111], v[84:85], v[160:167] ; cc4640a0 1e82a96e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[24:25], v[136:143] ; cc464088 1e22316c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[34:35], v[184:191] ; cc4640b8 1ee2456e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[26:27], v[144:151] ; cc464090 1e42356c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[110:111], v[24:25], v[168:175] ; cc4640a8 1ea2316e
	v_add3_u32 v24, v4, s4, v19                                 ; d6550018 044c0904
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[110:111], v[26:27], v[176:183] ; cc4640b0 1ec2356e
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[112:113], v[52:53], v[128:135] ; cc464080 1e026970
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[86:87], v[152:159] ; cc464098 1e62ad70
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[114:115], v[52:53], v[160:167] ; cc4640a0 1e826972
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[54:55], v[136:143] ; cc464088 1e226d70
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[86:87], v[184:191] ; cc4640b8 1ee2ad72
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[112:113], v[68:69], v[144:151] ; cc464090 1e428970
	v_lshlrev_b32_e32 v24, 2, v24                               ; 30303082
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[114:115], v[54:55], v[168:175] ; cc4640a8 1ea26d72
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[68:69], v[176:183] ; cc4640b0 1ec28972
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[116:117], v[104:105], v[128:135] ; cc464080 1e02d174
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[16:17], v[152:159] ; cc464098 1e622174
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[118:119], v[104:105], v[160:167] ; cc4640a0 1e82d176
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[116:117], v[44:45], v[136:143] ; cc464088 1e225974
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[16:17], v[184:191] ; cc4640b8 1ee22176
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[116:117], v[72:73], v[144:151] ; cc464090 1e429174
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[118:119], v[44:45], v[168:175] ; cc4640a8 1ea25976
	buffer_load_b128 v[28:31], v24, s[28:31], null offen        ; c405c07c 4080381c 00000018
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[118:119], v[72:73], v[176:183] ; cc4640b0 1ec29176
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	ds_store_2addr_b64 v37, v[6:7], v[16:17] offset1:32         ; d9382000 00100625
	buffer_load_b128 v[44:47], v24, s[28:31], null offen offset:512 ; c405c07c 4080382c 00020018
	v_add_nc_u32_e32 v25, 0x1000, v37                           ; 4a324aff 00001000
	ds_store_2addr_b64 v25, v[8:9], v[26:27] offset1:32         ; d9382000 001a0819
	v_add_nc_u32_e32 v26, 0x2000, v37                           ; 4a344aff 00002000
	v_add_nc_u32_e32 v27, 0x3000, v37                           ; 4a364aff 00003000
	ds_store_2addr_b64 v26, v[10:11], v[32:33] offset1:32       ; d9382000 00200a1a
	ds_store_2addr_b64 v27, v[12:13], v[34:35] offset1:32       ; d9382000 00220c1b
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_mad_u32_u24 v32, s19, 0x500, v36                          ; d60b0020 0491fe13 00000500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v32, v42, v32, v43                               ; d6550020 04ae412a
	s_barrier_wait 0xffff                                       ; bf94ffff
	buffer_load_b128 v[8:11], v24, s[28:31], null offen offset:1024 ; c405c07c 40803808 00040018
	ds_load_b64 v[6:7], v32 offset:16384                        ; d9d84000 06000020
	ds_load_b64 v[12:13], v32 offset:20480                      ; d9d85000 0c000020
	ds_load_b64 v[16:17], v32 offset:24576                      ; d9d86000 10000020
	buffer_load_b128 v[52:55], v24, s[28:31], null offen offset:1536 ; c405c07c 40803834 00060018
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[34:35], v6                           ; 7e44dd06
	s_wait_loadcnt 0x7                                          ; bfc00007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v49, v35, v121 :: v_dual_mul_f32 v48, v34, v120 ; c8c6f323 3130f122
	v_cvt_pk_f32_fp8_e32 v[34:35], v134                         ; 7e44dd86
	v_dual_mul_f32 v51, v35, v123 :: v_dual_mul_f32 v50, v34, v122 ; c8c6f723 3332f522
	v_cvt_pk_f32_fp8_e32 v[34:35], v7                           ; 7e44dd07
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v69, v35, v77 :: v_dual_mul_f32 v68, v34, v76 ; c8c69b23 45449922
	ds_load_b64 v[34:35], v32 offset:28672                      ; d9d87000 22000020
	buffer_load_b128 v[56:59], v24, s[28:31], null offen offset:2048 ; c405c07c 40803838 00080018
	ds_load_b64 v[38:39], v32 offset:16640                      ; d9d84100 26000020
	buffer_load_b128 v[64:67], v24, s[28:31], null offen offset:2560 ; c405c07c 40803840 000a0018
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v71, v7, v79 :: v_dual_mul_f32 v70, v6, v78  ; c8c69f07 47469d06
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[6:7], v12                            ; 7e0cdd0c
	v_dual_mul_f32 v81, v7, v121 :: v_dual_mul_f32 v80, v6, v120 ; c8c6f307 5150f106
	v_cvt_pk_f32_fp8_e32 v[6:7], v140                           ; 7e0cdd8c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
	v_dual_mul_f32 v83, v7, v123 :: v_dual_mul_f32 v82, v6, v122 ; c8c6f707 5352f506
	buffer_load_b128 v[72:75], v24, s[28:31], null offen offset:3072 ; c405c07c 40803848 000c0018
	v_cvt_pk_f32_fp8_e32 v[6:7], v13                            ; 7e0cdd0d
	v_cvt_pk_f32_fp8_e32 v[12:13], v141                         ; 7e18dd8d
	v_dual_mul_f32 v85, v7, v77 :: v_dual_mul_f32 v84, v6, v76  ; c8c69b07 55549906
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v16                            ; 7e0cdd10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v89, v7, v121 :: v_dual_mul_f32 v88, v6, v120 ; c8c6f307 5958f106
	v_cvt_pk_f32_fp8_e32 v[6:7], v144                           ; 7e0cdd90
	v_mul_f32_e32 v91, v7, v123                                 ; 10b6f707
	v_mul_f32_e32 v90, v6, v122                                 ; 10b4f506
	v_cvt_pk_f32_fp8_e32 v[6:7], v17                            ; 7e0cdd11
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v93, v7, v77 :: v_dual_mul_f32 v86, v12, v78 ; c8c69b07 5d569d0c
	v_dual_mul_f32 v87, v13, v79 :: v_dual_mul_f32 v92, v6, v76 ; c8c69f0d 575c9906
	ds_load_b64 v[12:13], v32 offset:20736                      ; d9d85100 0c000020
	buffer_load_b128 v[104:107], v24, s[28:31], null offen offset:3584 ; c405c07c 40803868 000e0018
	v_cvt_pk_f32_fp8_e32 v[6:7], v145                           ; 7e0cdd91
	ds_load_b64 v[16:17], v32 offset:24832                      ; d9d86100 10000020
	v_dual_mul_f32 v95, v7, v79 :: v_dual_mul_f32 v94, v6, v78  ; c8c69f07 5f5e9d06
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[6:7], v34                            ; 7e0cdd22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v97, v7, v121                                 ; 10c2f307
	v_mul_f32_e32 v96, v6, v120                                 ; 10c0f106
	v_cvt_pk_f32_fp8_e32 v[6:7], v162                           ; 7e0cdda2
	v_dual_mul_f32 v99, v7, v123 :: v_dual_mul_f32 v98, v6, v122 ; c8c6f707 6362f506
	v_cvt_pk_f32_fp8_e32 v[6:7], v35                            ; 7e0cdd23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v101, v7, v77 :: v_dual_mul_f32 v100, v6, v76 ; c8c69b07 65649906
	v_cvt_pk_f32_fp8_e32 v[6:7], v163                           ; 7e0cdda3
	v_mul_f32_e32 v102, v6, v78                                 ; 10cc9d06
	v_mul_f32_e32 v103, v7, v79                                 ; 10ce9f07
	buffer_load_b128 v[76:79], v24, s[28:31], null offen offset:4096 ; c405c07c 4080384c 00100018
	ds_load_b64 v[34:35], v32 offset:28928                      ; d9d87100 22000020
	buffer_load_b128 v[108:111], v24, s[28:31], null offen offset:4608 ; c405c07c 4080386c 00120018
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[6:7], v38                            ; 7e0cdd26
	s_wait_loadcnt 0xb                                          ; bfc0000b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v7, v1 :: v_dual_mul_f32 v112, v6, v0  ; c8c60307 71700106
	v_cvt_pk_f32_fp8_e32 v[6:7], v166                           ; 7e0cdda6
	v_dual_mul_f32 v115, v7, v3 :: v_dual_mul_f32 v114, v6, v2  ; c8c60707 73720506
	v_cvt_pk_f32_fp8_e32 v[6:7], v39                            ; 7e0cdd27
	s_wait_loadcnt 0xa                                          ; bfc0000a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v117, v7, v21 :: v_dual_mul_f32 v116, v6, v20 ; c8c62b07 75742906
	buffer_load_b128 v[132:135], v24, s[28:31], null offen offset:5120 ; c405c07c 40803884 00140018
	v_cvt_pk_f32_fp8_e32 v[6:7], v167                           ; 7e0cdda7
	v_dual_mul_f32 v119, v7, v23 :: v_dual_mul_f32 v118, v6, v22 ; c8c62f07 77762d06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v12                            ; 7e0cdd0c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v121, v7, v1 :: v_dual_mul_f32 v120, v6, v0  ; c8c60307 79780106
	v_cvt_pk_f32_fp8_e32 v[6:7], v140                           ; 7e0cdd8c
	v_mul_f32_e32 v122, v6, v2                                  ; 10f40506
	v_mul_f32_e32 v123, v7, v3                                  ; 10f60707
	buffer_load_b128 v[136:139], v24, s[28:31], null offen offset:5632 ; c405c07c 40803888 00160018
	v_cvt_pk_f32_fp8_e32 v[6:7], v13                            ; 7e0cdd0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v125, v7, v21 :: v_dual_mul_f32 v124, v6, v20 ; c8c62b07 7d7c2906
	v_cvt_pk_f32_fp8_e32 v[6:7], v141                           ; 7e0cdd8d
	v_dual_mul_f32 v127, v7, v23 :: v_dual_mul_f32 v126, v6, v22 ; c8c62f07 7f7e2d06
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[6:7], v16                            ; 7e0cdd10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v129, v7, v1 :: v_dual_mul_f32 v128, v6, v0  ; c8c60307 81800106
	v_cvt_pk_f32_fp8_e32 v[6:7], v144                           ; 7e0cdd90
	v_lshl_add_u32 v33, s19, 10, v43                            ; d6460021 04ad1413
	v_dual_mul_f32 v131, v7, v3 :: v_dual_mul_f32 v130, v6, v2  ; c8c60707 83820506
	v_cvt_pk_f32_fp8_e32 v[6:7], v17                            ; 7e0cdd11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v141, v7, v21 :: v_dual_mul_f32 v140, v6, v20 ; c8c62b07 8d8c2906
	v_cvt_pk_f32_fp8_e32 v[6:7], v145                           ; 7e0cdd91
	v_dual_mul_f32 v143, v7, v23 :: v_dual_mul_f32 v142, v6, v22 ; c8c62f07 8f8e2d06
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[6:7], v34                            ; 7e0cdd22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v145, v7, v1                                  ; 11220307
	v_mul_f32_e32 v144, v6, v0                                  ; 11200106
	v_cvt_pk_f32_fp8_e32 v[0:1], v162                           ; 7e00dda2
	v_dual_mul_f32 v147, v1, v3 :: v_dual_mul_f32 v146, v0, v2  ; c8c60701 93920500
	v_cvt_pk_f32_fp8_e32 v[0:1], v35                            ; 7e00dd23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v149, v1, v21 :: v_dual_mul_f32 v148, v0, v20 ; c8c62b01 95942900
	v_cvt_pk_f32_fp8_e32 v[0:1], v163                           ; 7e00dda3
	v_mul_f32_e32 v151, v1, v23                                 ; 112e2f01
	v_dual_mul_f32 v150, v0, v22 :: v_dual_add_nc_u32 v33, v42, v33 ; c8e02d00 9620432a
	buffer_load_b128 v[0:3], v24, s[28:31], null offen offset:6144 ; c405c07c 40803800 00180018
	ds_load_b64 v[6:7], v33                                     ; d9d80000 06000021
	ds_load_b64 v[12:13], v33 offset:4096                       ; d9d81000 0c000021
	ds_load_b64 v[16:17], v33 offset:8192                       ; d9d82000 10000021
	ds_load_b64 v[20:21], v33 offset:12288                      ; d9d83000 14000021
	ds_load_b64 v[22:23], v33 offset:256                        ; d9d80100 16000021
	ds_load_b64 v[34:35], v33 offset:4352                       ; d9d81100 22000021
	ds_load_b64 v[38:39], v33 offset:8448                       ; d9d82100 26000021
	ds_load_b64 v[40:41], v33 offset:12544                      ; d9d83100 28000021
	ds_load_b64 v[60:61], v33 offset:512                        ; d9d80200 3c000021
	ds_load_b64 v[152:153], v33 offset:4608                     ; d9d81200 98000021
	ds_load_b64 v[154:155], v33 offset:8704                     ; d9d82200 9a000021
	ds_load_b64 v[156:157], v33 offset:12800                    ; d9d83200 9c000021
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_dual_mov_b32 v161, v53 :: v_dual_mov_b32 v160, v52        ; ca100135 a1a00134
	v_dual_mov_b32 v53, v69 :: v_dual_mov_b32 v52, v68          ; ca100145 35340144
	v_dual_mov_b32 v163, v55 :: v_dual_mov_b32 v162, v54        ; ca100137 a3a20136
	v_dual_mov_b32 v55, v71 :: v_dual_mov_b32 v54, v70          ; ca100147 37360146
	buffer_load_b128 v[68:71], v24, s[28:31], null offen offset:6656 ; c405c07c 40803844 001a0018
	ds_load_b64 v[158:159], v33 offset:768                      ; d9d80300 9e000021
	ds_load_b64 v[164:165], v33 offset:4864                     ; d9d81300 a4000021
	ds_load_b64 v[166:167], v33 offset:8960                     ; d9d82300 a6000021
	ds_load_b64 v[168:169], v33 offset:13056                    ; d9d83300 a8000021
	buffer_load_b128 v[172:175], v24, s[28:31], null offen offset:7168 ; c405c07c 408038ac 001c0018
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[6:7], v[112:119] ; cc464070 1dc20d1e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[12:13], v[80:87] ; cc464050 1d42191c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[16:17], v[88:95] ; cc464058 1d62211c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[20:21], v[96:103] ; cc464060 1d82291c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[28:29], v[6:7], v[48:55] ; cc464030 1cc20d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[12:13], v[120:127] ; cc464078 1de2191e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[30:31], v[20:21], v[144:151] ; cc464090 1e42291e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mov_b32 v177, v133 :: v_dual_mov_b32 v176, v132      ; ca100185 b1b00184
	v_dual_mov_b32 v133, v141 :: v_dual_mov_b32 v132, v140      ; ca10018d 8584018c
	v_dual_mov_b32 v179, v135 :: v_dual_mov_b32 v178, v134      ; ca100187 b3b20186
	v_dual_mov_b32 v135, v143 :: v_dual_mov_b32 v134, v142      ; ca10018f 8786018e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[16:17], v[128:135] ; cc464080 1e02211e
	ds_load_b64 v[6:7], v33 offset:1024                         ; d9d80400 06000021
	ds_load_b64 v[12:13], v33 offset:5120                       ; d9d81400 0c000021
	ds_load_b64 v[16:17], v33 offset:9216                       ; d9d82400 10000021
	ds_load_b64 v[20:21], v33 offset:13312                      ; d9d83400 14000021
	buffer_load_b128 v[28:31], v24, s[28:31], null offen offset:7680 ; c405c07c 4080381c 001e0018
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[34:35], v[80:87] ; cc464050 1d42452c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[38:39], v[88:95] ; cc464058 1d624d2c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[40:41], v[96:103] ; cc464060 1d82512c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[22:23], v[112:119] ; cc464070 1dc22d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[44:45], v[22:23], v[48:55] ; cc464030 1cc22d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[34:35], v[120:127] ; cc464078 1de2452e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[40:41], v[144:151] ; cc464090 1e42512e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[38:39], v[128:135] ; cc464080 1e024d2e
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[152:153], v[80:87] ; cc464050 1d433108
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[154:155], v[88:95] ; cc464058 1d633508
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[156:157], v[96:103] ; cc464060 1d833908
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[60:61], v[112:119] ; cc464070 1dc2790a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[8:9], v[60:61], v[48:55] ; cc464030 1cc27908
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[152:153], v[120:127] ; cc464078 1de3310a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[10:11], v[156:157], v[144:151] ; cc464090 1e43390a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[154:155], v[128:135] ; cc464080 1e03350a
	ds_load_b64 v[22:23], v33 offset:1280                       ; d9d80500 16000021
	ds_load_b64 v[34:35], v33 offset:5376                       ; d9d81500 22000021
	ds_load_b64 v[38:39], v33 offset:9472                       ; d9d82500 26000021
	ds_load_b64 v[40:41], v33 offset:13568                      ; d9d83500 28000021
	ds_load_b64 v[8:9], v33 offset:1536                         ; d9d80600 08000021
	ds_load_b64 v[10:11], v33 offset:5632                       ; d9d81600 0a000021
	ds_load_b64 v[44:45], v33 offset:9728                       ; d9d82600 2c000021
	ds_load_b64 v[46:47], v33 offset:13824                      ; d9d83600 2e000021
	ds_load_b64 v[60:61], v33 offset:1792                       ; d9d80700 3c000021
	ds_load_b64 v[140:141], v33 offset:5888                     ; d9d81700 8c000021
	ds_load_b64 v[142:143], v33 offset:9984                     ; d9d82700 8e000021
	ds_load_b64 v[152:153], v33 offset:14080                    ; d9d83700 98000021
	s_wait_dscnt 0x12                                           ; bfc60012
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[160:161], v[164:165], v[80:87] ; cc464050 1d4349a0
	s_wait_dscnt 0x11                                           ; bfc60011
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[160:161], v[166:167], v[88:95] ; cc464058 1d634da0
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[160:161], v[168:169], v[96:103] ; cc464060 1d8351a0
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[162:163], v[158:159], v[112:119] ; cc464070 1dc33da2
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[160:161], v[158:159], v[48:55] ; cc464030 1cc33da0
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[162:163], v[164:165], v[120:127] ; cc464078 1de349a2
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[162:163], v[168:169], v[144:151] ; cc464090 1e4351a2
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[162:163], v[166:167], v[128:135] ; cc464080 1e034da2
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[56:57], v[12:13], v[80:87] ; cc464050 1d421938
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[16:17], v[88:95] ; cc464058 1d622138
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[56:57], v[20:21], v[96:103] ; cc464060 1d822938
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[6:7], v[112:119] ; cc464070 1dc20d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[56:57], v[6:7], v[48:55] ; cc464030 1cc20d38
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[58:59], v[12:13], v[120:127] ; cc464078 1de2193a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[58:59], v[20:21], v[144:151] ; cc464090 1e42293a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[16:17], v[128:135] ; cc464080 1e02213a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[64:65], v[34:35], v[80:87] ; cc464050 1d424540
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[22:23], v[112:119] ; cc464070 1dc22d42
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[64:65], v[22:23], v[48:55] ; cc464030 1cc22d40
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[66:67], v[34:35], v[120:127] ; cc464078 1de24542
	ds_load_b64 v[6:7], v33 offset:2048                         ; d9d80800 06000021
	ds_load_b64 v[12:13], v33 offset:6144                       ; d9d81800 0c000021
	ds_load_b64 v[16:17], v33 offset:10240                      ; d9d82800 10000021
	ds_load_b64 v[20:21], v33 offset:14336                      ; d9d83800 14000021
	ds_load_b64 v[22:23], v33 offset:2304                       ; d9d80900 16000021
	ds_load_b64 v[34:35], v33 offset:6400                       ; d9d81900 22000021
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[38:39], v[88:95] ; cc464058 1d624d40
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[38:39], v[128:135] ; cc464080 1e024d42
	v_add_lshl_u32 v38, s20, v15, 2                             ; d6470026 020a1e14
	buffer_load_b32 v38, v38, s[36:39], null offen              ; c405007c 40804826 00000026
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[64:65], v[40:41], v[96:103] ; cc464060 1d825140
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[66:67], v[40:41], v[144:151] ; cc464090 1e425142
	ds_load_b64 v[40:41], v33 offset:10496                      ; d9d82900 28000021
	ds_load_b64 v[56:57], v33 offset:14592                      ; d9d83900 38000021
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_mad_u32_u24 v39, 0x1800, v15, s5                          ; d60b0027 00161eff 00001800
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v39, v39, v4, 2                              ; d6470027 020a0927
	buffer_load_b128 v[64:67], v39, s[28:31], null offen        ; c405c07c 40803840 00000027
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[10:11], v[80:87] ; cc464050 1d421548
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[72:73], v[8:9], v[48:55] ; cc464030 1cc21148
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[8:9], v[112:119] ; cc464070 1dc2114a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[10:11], v[120:127] ; cc464078 1de2154a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[44:45], v[88:95] ; cc464058 1d625948
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[44:45], v[128:135] ; cc464080 1e02594a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[46:47], v[96:103] ; cc464060 1d825d48
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[74:75], v[46:47], v[144:151] ; cc464090 1e425d4a
	ds_load_b64 v[8:9], v33 offset:2560                         ; d9d80a00 08000021
	ds_load_b64 v[10:11], v33 offset:6656                       ; d9d81a00 0a000021
	ds_load_b64 v[44:45], v33 offset:10752                      ; d9d82a00 2c000021
	ds_load_b64 v[46:47], v33 offset:14848                      ; d9d83a00 2e000021
	buffer_load_b128 v[72:75], v39, s[28:31], null offen offset:8192 ; c405c07c 40803848 00200027
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[104:105], v[140:141], v[80:87] ; cc464050 1d431968
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[104:105], v[60:61], v[48:55] ; cc464030 1cc27968
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[106:107], v[60:61], v[112:119] ; cc464070 1dc2796a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[106:107], v[140:141], v[120:127] ; cc464078 1de3196a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[104:105], v[142:143], v[88:95] ; cc464058 1d631d68
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[106:107], v[142:143], v[128:135] ; cc464080 1e031d6a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[104:105], v[152:153], v[96:103] ; cc464060 1d833168
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[106:107], v[152:153], v[144:151] ; cc464090 1e43316a
	ds_load_b64 v[58:59], v33 offset:2816                       ; d9d80b00 3a000021
	ds_load_b64 v[60:61], v33 offset:6912                       ; d9d81b00 3c000021
	ds_load_b64 v[104:105], v33 offset:11008                    ; d9d82b00 68000021
	ds_load_b64 v[106:107], v33 offset:15104                    ; d9d83b00 6a000021
	buffer_load_b128 v[140:143], v39, s[28:31], null offen offset:512 ; c405c07c 4080388c 00020027
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[76:77], v[6:7], v[48:55] ; cc464030 1cc20d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[78:79], v[6:7], v[112:119] ; cc464070 1dc20d4e
	ds_load_b64 v[6:7], v33 offset:3072                         ; d9d80c00 06000021
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[76:77], v[12:13], v[80:87] ; cc464050 1d42194c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[78:79], v[12:13], v[120:127] ; cc464078 1de2194e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[76:77], v[16:17], v[88:95] ; cc464058 1d62214c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[78:79], v[16:17], v[128:135] ; cc464080 1e02214e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[76:77], v[20:21], v[96:103] ; cc464060 1d82294c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[78:79], v[20:21], v[144:151] ; cc464090 1e42294e
	buffer_load_b128 v[76:79], v39, s[28:31], null offen offset:8704 ; c405c07c 4080384c 00220027
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[108:109], v[22:23], v[48:55] ; cc464030 1cc22d6c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[110:111], v[22:23], v[112:119] ; cc464070 1dc22d6e
	ds_load_b64 v[12:13], v33 offset:7168                       ; d9d81c00 0c000021
	ds_load_b64 v[16:17], v33 offset:11264                      ; d9d82c00 10000021
	ds_load_b64 v[20:21], v33 offset:15360                      ; d9d83c00 14000021
	ds_load_b64 v[22:23], v33 offset:3328                       ; d9d80d00 16000021
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[108:109], v[34:35], v[80:87] ; cc464050 1d42456c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[110:111], v[34:35], v[120:127] ; cc464078 1de2456e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[108:109], v[40:41], v[88:95] ; cc464058 1d62516c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[110:111], v[40:41], v[128:135] ; cc464080 1e02516e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[108:109], v[56:57], v[96:103] ; cc464060 1d82716c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[110:111], v[56:57], v[144:151] ; cc464090 1e42716e
	buffer_load_b128 v[108:111], v39, s[28:31], null offen offset:1024 ; c405c07c 4080386c 00040027
	ds_load_b64 v[34:35], v33 offset:7424                       ; d9d81d00 22000021
	ds_load_b64 v[40:41], v33 offset:11520                      ; d9d82d00 28000021
	ds_load_b64 v[56:57], v33 offset:15616                      ; d9d83d00 38000021
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[176:177], v[8:9], v[48:55] ; cc464030 1cc211b0
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[178:179], v[8:9], v[112:119] ; cc464070 1dc211b2
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[176:177], v[10:11], v[80:87] ; cc464050 1d4215b0
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[178:179], v[10:11], v[120:127] ; cc464078 1de215b2
	buffer_load_b128 v[8:11], v39, s[28:31], null offen offset:9216 ; c405c07c 40803808 00240027
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[176:177], v[44:45], v[88:95] ; cc464058 1d6259b0
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[178:179], v[44:45], v[128:135] ; cc464080 1e0259b2
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[176:177], v[46:47], v[96:103] ; cc464060 1d825db0
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[178:179], v[46:47], v[144:151] ; cc464090 1e425db2
	ds_load_b64 v[44:45], v33 offset:3584                       ; d9d80e00 2c000021
	ds_load_b64 v[46:47], v33 offset:7680                       ; d9d81e00 2e000021
	ds_load_b64 v[152:153], v33 offset:11776                    ; d9d82e00 98000021
	ds_load_b64 v[154:155], v33 offset:15872                    ; d9d83e00 9a000021
	buffer_load_b128 v[156:159], v39, s[28:31], null offen offset:1536 ; c405c07c 4080389c 00060027
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[136:137], v[58:59], v[48:55] ; cc464030 1cc27588
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[138:139], v[58:59], v[112:119] ; cc464070 1dc2758a
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[136:137], v[60:61], v[80:87] ; cc464050 1d427988
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[138:139], v[60:61], v[120:127] ; cc464078 1de2798a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[136:137], v[104:105], v[88:95] ; cc464058 1d62d188
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[138:139], v[104:105], v[128:135] ; cc464080 1e02d18a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[136:137], v[106:107], v[96:103] ; cc464060 1d82d588
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[138:139], v[106:107], v[144:151] ; cc464090 1e42d58a
	ds_load_b64 v[58:59], v33 offset:3840                       ; d9d80f00 3a000021
	ds_load_b64 v[60:61], v33 offset:7936                       ; d9d81f00 3c000021
	ds_load_b64 v[104:105], v33 offset:12032                    ; d9d82f00 68000021
	ds_load_b64 v[106:107], v33 offset:16128                    ; d9d83f00 6a000021
	buffer_load_b128 v[136:139], v39, s[28:31], null offen offset:9728 ; c405c07c 40803888 00260027
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[0:1], v[6:7], v[48:55] ; cc464030 1cc20d00
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[0:1], v[12:13], v[80:87] ; cc464050 1d421900
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[2:3], v[6:7], v[112:119] ; cc464070 1dc20d02
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[0:1], v[16:17], v[88:95] ; cc464058 1d622100
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[2:3], v[12:13], v[120:127] ; cc464078 1de21902
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[2:3], v[16:17], v[128:135] ; cc464080 1e022102
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[0:1], v[20:21], v[96:103] ; cc464060 1d822900
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[2:3], v[20:21], v[144:151] ; cc464090 1e422902
	s_wait_loadcnt_dscnt 0xb0b                                  ; bfc80b0b
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[68:69], v[22:23], v[48:55] ; cc464030 1cc22d44
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[34:35], v[80:87] ; cc464050 1d424544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[22:23], v[112:119] ; cc464070 1dc22d46
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[40:41], v[88:95] ; cc464058 1d625144
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[34:35], v[120:127] ; cc464078 1de24546
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[40:41], v[128:135] ; cc464080 1e025146
	v_add_nc_u32_e32 v40, 0x4000, v37                           ; 4a504aff 00004000
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[56:57], v[96:103] ; cc464060 1d827144
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[56:57], v[144:151] ; cc464090 1e427146
	s_wait_loadcnt_dscnt 0xa07                                  ; bfc80a07
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[172:173], v[44:45], v[48:55] ; cc464030 1cc259ac
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[172:173], v[46:47], v[80:87] ; cc464050 1d425dac
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[174:175], v[44:45], v[112:119] ; cc464070 1dc259ae
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[172:173], v[152:153], v[88:95] ; cc464058 1d6331ac
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[174:175], v[46:47], v[120:127] ; cc464078 1de25dae
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[174:175], v[152:153], v[128:135] ; cc464080 1e0331ae
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[172:173], v[154:155], v[96:103] ; cc464060 1d8335ac
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[174:175], v[154:155], v[144:151] ; cc464090 1e4335ae
	s_wait_loadcnt_dscnt 0x903                                  ; bfc80903
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[28:29], v[58:59], v[48:55] ; cc464030 1cc2751c
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[60:61], v[80:87] ; cc464050 1d42791c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[58:59], v[112:119] ; cc464070 1dc2751e
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[104:105], v[88:95] ; cc464058 1d62d11c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[60:61], v[120:127] ; cc464078 1de2791e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[104:105], v[128:135] ; cc464080 1e02d11e
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[106:107], v[96:103] ; cc464060 1d82d51c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[30:31], v[106:107], v[144:151] ; cc464090 1e42d51e
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_nc_u32_e32 v41, 0x5000, v37                           ; 4a524aff 00005000
	v_add_nc_u32_e32 v44, 0x6000, v37                           ; 4a584aff 00006000
	v_add_nc_u32_e32 v45, 0x7000, v37                           ; 4a5a4aff 00007000
	ds_store_2addr_b64 v40, v[0:1], v[16:17] offset1:32         ; d9382000 00100028
	ds_store_2addr_b64 v41, v[2:3], v[20:21] offset1:32         ; d9382000 00140229
	ds_store_2addr_b64 v44, v[6:7], v[22:23] offset1:32         ; d9382000 0016062c
	ds_store_2addr_b64 v45, v[12:13], v[28:29] offset1:32       ; d9382000 001c0c2d
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_lshl_add_u32 v46, s19, 11, v43                            ; d646002e 04ad1613
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v46, v46, v42                              ; 4a5c552e
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[0:1], v46 offset:16384                        ; d9d84000 0000002e
	ds_load_b64 v[2:3], v46 offset:20480                        ; d9d85000 0200002e
	ds_load_b64 v[6:7], v46 offset:24576                        ; d9d86000 0600002e
	ds_load_b64 v[12:13], v46 offset:28672                      ; d9d87000 0c00002e
	ds_load_b64 v[16:17], v46 offset:16640                      ; d9d84100 1000002e
	ds_load_b64 v[20:21], v46 offset:20736                      ; d9d85100 1400002e
	ds_load_b64 v[22:23], v46 offset:24832                      ; d9d86100 1600002e
	ds_load_b64 v[28:29], v46 offset:28928                      ; d9d87100 1c00002e
	ds_load_b64 v[30:31], v46 offset:16896                      ; d9d84200 1e00002e
	ds_load_b64 v[34:35], v46 offset:20992                      ; d9d85200 2200002e
	ds_load_b64 v[40:41], v46 offset:25088                      ; d9d86200 2800002e
	ds_load_b64 v[44:45], v46 offset:29184                      ; d9d87200 2c00002e
	v_dual_mov_b32 v104, v4 :: v_dual_mov_b32 v47, v62          ; ca100104 682e013e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mov_b32 v18, v104 :: v_dual_mov_b32 v105, v5         ; ca100168 12680105
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_dual_mov_b32 v106, v158 :: v_dual_mov_b32 v107, v159      ; ca10019e 6a6a019f
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[0:1], 0 ; cc4640b8 1a02014a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[0:1], 0 ; cc464070 1a020142
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[64:65], v[0:1], 0   ; cc464030 1a020140
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[2:3], 0 ; cc4640a0 1a020548
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[64:65], v[2:3], 0   ; cc464050 1a020540
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[66:67], v[2:3], 0 ; cc464078 1a020542
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[6:7], 0   ; cc464058 1a020d40
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[6:7], 0 ; cc4640a8 1a020d48
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[6:7], 0 ; cc464080 1a020d42
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[72:73], v[12:13], 0 ; cc4640b0 1a021948
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[64:65], v[12:13], 0 ; cc464060 1a021940
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[66:67], v[12:13], 0 ; cc464090 1a021942
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[72:73], v[0:1], 0   ; cc464040 1a020148
	v_mov_b32_e32 v72, v6                                       ; 7e900306
	v_dual_mov_b32 v24, v105 :: v_dual_mov_b32 v73, v7          ; ca100169 18480107
	v_dual_mov_b32 v104, v156 :: v_dual_mov_b32 v105, v157      ; ca10019c 6868019d
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[74:75], v[2:3], 0   ; cc464038 1a02054a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[12:13], 0 ; cc464098 1a02194a
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[140:141], v[16:17], v[48:55] ; cc464030 1cc2218c
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[140:141], v[20:21], v[80:87] ; cc464050 1d42298c
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[140:141], v[22:23], v[88:95] ; cc464058 1d622d8c
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[140:141], v[28:29], v[96:103] ; cc464060 1d82398c
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[74:75], v[72:73], 0   ; cc464000 1a02914a
	ds_load_b64 v[12:13], v46 offset:17152                      ; d9d84300 0c00002e
	ds_load_b64 v[72:73], v46 offset:21248                      ; d9d85300 4800002e
	ds_load_b64 v[74:75], v46 offset:25344                      ; d9d86300 4a00002e
	ds_load_b64 v[140:141], v46 offset:29440                    ; d9d87300 8c00002e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[142:143], v[16:17], v[112:119] ; cc464070 1dc2218e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[142:143], v[20:21], v[120:127] ; cc464078 1de2298e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[142:143], v[22:23], v[128:135] ; cc464080 1e022d8e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[76:77], v[20:21], v[160:167] ; cc4640a0 1e82294c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[76:77], v[16:17], v[64:71] ; cc464040 1d02214c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[76:77], v[22:23], v[168:175] ; cc4640a8 1ea22d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[76:77], v[28:29], v[176:183] ; cc4640b0 1ec2394c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[78:79], v[16:17], v[184:191] ; cc4640b8 1ee2214e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[78:79], v[20:21], v[56:63] ; cc464038 1ce2294e
	v_dual_mov_b32 v77, v19 :: v_dual_mov_b32 v76, v18          ; ca100113 4d4c0112
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[78:79], v[22:23], v[0:7] ; cc464000 1c022d4e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v39, s[28:31], null offen offset:2048 ; c405c07c 40803814 00080027
	buffer_load_b128 v[16:19], v39, s[28:31], null offen offset:10240 ; c405c07c 40803810 00280027
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[142:143], v[28:29], v[144:151] ; cc464090 1e42398e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[78:79], v[28:29], v[152:159] ; cc464098 1e62394e
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[108:109], v[30:31], v[48:55] ; cc464030 1cc23d6c
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[108:109], v[34:35], v[80:87] ; cc464050 1d42456c
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[108:109], v[40:41], v[88:95] ; cc464058 1d62516c
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[108:109], v[44:45], v[96:103] ; cc464060 1d82596c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[110:111], v[30:31], v[112:119] ; cc464070 1dc23d6e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[110:111], v[34:35], v[120:127] ; cc464078 1de2456e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[110:111], v[40:41], v[128:135] ; cc464080 1e02516e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[30:31], v[64:71] ; cc464040 1d023d08
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[8:9], v[34:35], v[160:167] ; cc4640a0 1e824508
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[8:9], v[40:41], v[168:175] ; cc4640a8 1ea25108
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[8:9], v[44:45], v[176:183] ; cc4640b0 1ec25908
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[110:111], v[44:45], v[144:151] ; cc464090 1e42596e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[10:11], v[30:31], v[184:191] ; cc4640b8 1ee23d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[10:11], v[34:35], v[56:63] ; cc464038 1ce2450a
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[10:11], v[40:41], v[0:7] ; cc464000 1c02510a
	ds_load_b64 v[28:29], v46 offset:17408                      ; d9d84400 1c00002e
	ds_load_b64 v[78:79], v46 offset:21504                      ; d9d85400 4e00002e
	ds_load_b64 v[108:109], v46 offset:25600                    ; d9d86400 6c00002e
	ds_load_b64 v[110:111], v46 offset:29696                    ; d9d87400 6e00002e
	ds_load_b64 v[8:9], v46 offset:17664                        ; d9d84500 0800002e
	ds_load_b64 v[30:31], v46 offset:21760                      ; d9d85500 1e00002e
	ds_load_b64 v[34:35], v46 offset:25856                      ; d9d86500 2200002e
	ds_load_b64 v[40:41], v46 offset:29952                      ; d9d87500 2800002e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[10:11], v[44:45], v[152:159] ; cc464098 1e62590a
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[104:105], v[12:13], v[48:55] ; cc464030 1cc21968
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[104:105], v[72:73], v[80:87] ; cc464050 1d429168
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[104:105], v[74:75], v[88:95] ; cc464058 1d629568
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[104:105], v[140:141], v[96:103] ; cc464060 1d831968
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[106:107], v[12:13], v[112:119] ; cc464070 1dc2196a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[106:107], v[72:73], v[120:127] ; cc464078 1de2916a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[106:107], v[74:75], v[128:135] ; cc464080 1e02956a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[106:107], v[140:141], v[144:151] ; cc464090 1e43196a
	v_dual_mov_b32 v11, v47 :: v_dual_mov_b32 v10, v46          ; ca10012f 0b0a012e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[104:107], v39, s[28:31], null offen offset:2560 ; c405c07c 40803868 000a0027
	buffer_load_b128 v[44:47], v39, s[28:31], null offen offset:10752 ; c405c07c 4080382c 002a0027
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[136:137], v[12:13], v[64:71] ; cc464040 1d021988
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[136:137], v[72:73], v[160:167] ; cc4640a0 1e829188
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[136:137], v[74:75], v[168:175] ; cc4640a8 1ea29588
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[136:137], v[140:141], v[176:183] ; cc4640b0 1ec31988
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[138:139], v[12:13], v[184:191] ; cc4640b8 1ee2198a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[138:139], v[72:73], v[56:63] ; cc464038 1ce2918a
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[138:139], v[74:75], v[0:7] ; cc464000 1c02958a
	ds_load_b64 v[136:137], v10 offset:17920                    ; d9d84600 8800000a
	ds_load_b64 v[12:13], v10 offset:22016                      ; d9d85600 0c00000a
	ds_load_b64 v[72:73], v10 offset:26112                      ; d9d86600 4800000a
	ds_load_b64 v[74:75], v10 offset:30208                      ; d9d87600 4a00000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[138:139], v[140:141], v[152:159] ; cc464098 1e63198a
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[108:109], v[88:95] ; cc464058 1d62d914
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[78:79], v[120:127] ; cc464078 1de29d16
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[22:23], v[110:111], v[144:151] ; cc464090 1e42dd16
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[110:111], v[96:103] ; cc464060 1d82dd14
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[20:21], v[28:29], v[48:55] ; cc464030 1cc23914
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[28:29], v[112:119] ; cc464070 1dc23916
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[108:109], v[128:135] ; cc464080 1e02d916
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[78:79], v[80:87] ; cc464050 1d429d14
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[140:143], v39, s[28:31], null offen offset:3072 ; c405c07c 4080388c 000c0027
	buffer_load_b128 v[20:23], v39, s[28:31], null offen offset:11264 ; c405c07c 40803814 002c0027
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[16:17], v[28:29], v[64:71] ; cc464040 1d023910
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[16:17], v[108:109], v[168:175] ; cc4640a8 1ea2d910
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[78:79], v[160:167] ; cc4640a0 1e829d10
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[110:111], v[176:183] ; cc4640b0 1ec2dd10
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[18:19], v[28:29], v[184:191] ; cc4640b8 1ee23912
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[18:19], v[78:79], v[56:63] ; cc464038 1ce29d12
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[18:19], v[108:109], v[0:7] ; cc464000 1c02d912
	ds_load_b64 v[16:17], v10 offset:18176                      ; d9d84700 1000000a
	ds_load_b64 v[28:29], v10 offset:22272                      ; d9d85700 1c00000a
	ds_load_b64 v[78:79], v10 offset:26368                      ; d9d86700 4e00000a
	ds_load_b64 v[108:109], v10 offset:30464                    ; d9d87700 6c00000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[18:19], v[110:111], v[152:159] ; cc464098 1e62dd12
	s_wait_dscnt 0x3                                            ; bfc60003
	v_dual_mov_b32 v111, v17 :: v_dual_mov_b32 v110, v16        ; ca100111 6f6e0110
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[106:107], v[40:41], v[144:151] ; cc464090 1e42516a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[104:105], v[30:31], v[80:87] ; cc464050 1d423d68
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[104:105], v[34:35], v[88:95] ; cc464058 1d624568
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[104:105], v[40:41], v[96:103] ; cc464060 1d825168
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[106:107], v[8:9], v[112:119] ; cc464070 1dc2116a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[106:107], v[30:31], v[120:127] ; cc464078 1de23d6a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[104:105], v[8:9], v[48:55] ; cc464030 1cc21168
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[106:107], v[34:35], v[128:135] ; cc464080 1e02456a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v39, s[28:31], null offen offset:3584 ; c405c07c 40803810 000e0027
	buffer_load_b128 v[104:107], v39, s[28:31], null offen offset:11776 ; c405c07c 40803868 002e0027
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[44:45], v[30:31], v[160:167] ; cc4640a0 1e823d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[34:35], v[168:175] ; cc4640a8 1ea2452c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[44:45], v[8:9], v[64:71] ; cc464040 1d02112c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[44:45], v[40:41], v[176:183] ; cc4640b0 1ec2512c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[46:47], v[8:9], v[184:191] ; cc4640b8 1ee2112e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[46:47], v[30:31], v[56:63] ; cc464038 1ce23d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[46:47], v[34:35], v[0:7] ; cc464000 1c02452e
	ds_load_b64 v[44:45], v10 offset:18432                      ; d9d84800 2c00000a
	ds_load_b64 v[8:9], v10 offset:22528                        ; d9d85800 0800000a
	ds_load_b64 v[30:31], v10 offset:26624                      ; d9d86800 1e00000a
	ds_load_b64 v[34:35], v10 offset:30720                      ; d9d87800 2200000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[40:41], v[152:159] ; cc464098 1e62512e
	v_dual_mov_b32 v47, v43 :: v_dual_mov_b32 v46, v42          ; ca10012b 2f2e012a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[140:141], v[72:73], v[88:95] ; cc464058 1d62918c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[140:141], v[74:75], v[96:103] ; cc464060 1d82958c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[142:143], v[74:75], v[144:151] ; cc464090 1e42958e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[140:141], v[12:13], v[80:87] ; cc464050 1d42198c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[142:143], v[136:137], v[112:119] ; cc464070 1dc3118e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[142:143], v[12:13], v[120:127] ; cc464078 1de2198e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[142:143], v[72:73], v[128:135] ; cc464080 1e02918e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[140:141], v[136:137], v[48:55] ; cc464030 1cc3118c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v39, s[28:31], null offen offset:4096 ; c405c07c 40803828 00100027
	buffer_load_b128 v[140:143], v39, s[28:31], null offen offset:12288 ; c405c07c 4080388c 00300027
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[20:21], v[12:13], v[160:167] ; cc4640a0 1e821914
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[20:21], v[72:73], v[168:175] ; cc4640a8 1ea29114
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[20:21], v[74:75], v[176:183] ; cc4640b0 1ec29514
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[136:137], v[64:71] ; cc464040 1d031114
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[22:23], v[136:137], v[184:191] ; cc4640b8 1ee31116
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[22:23], v[12:13], v[56:63] ; cc464038 1ce21916
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[22:23], v[72:73], v[0:7] ; cc464000 1c029116
	ds_load_b64 v[20:21], v10 offset:18688                      ; d9d84900 1400000a
	ds_load_b64 v[136:137], v10 offset:22784                    ; d9d85900 8800000a
	ds_load_b64 v[12:13], v10 offset:26880                      ; d9d86900 0c00000a
	ds_load_b64 v[72:73], v10 offset:30976                      ; d9d87900 4800000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[22:23], v[74:75], v[152:159] ; cc464098 1e629516
	v_dual_mov_b32 v75, v25 :: v_dual_mov_b32 v74, v24          ; ca100119 4b4a0118
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[78:79], v[88:95] ; cc464058 1d629d10
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[18:19], v[108:109], v[144:151] ; cc464090 1e42d912
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[108:109], v[96:103] ; cc464060 1d82d910
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[28:29], v[80:87] ; cc464050 1d423910
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[110:111], v[112:119] ; cc464070 1dc2dd12
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[28:29], v[120:127] ; cc464078 1de23912
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[78:79], v[128:135] ; cc464080 1e029d12
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[16:17], v[110:111], v[48:55] ; cc464030 1cc2dd10
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[22:25], v39, s[28:31], null offen offset:4608 ; c405c07c 40803816 00120027
	buffer_load_b128 v[16:19], v39, s[28:31], null offen offset:12800 ; c405c07c 40803810 00320027
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[104:105], v[28:29], v[160:167] ; cc4640a0 1e823968
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[104:105], v[78:79], v[168:175] ; cc4640a8 1ea29d68
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[104:105], v[108:109], v[176:183] ; cc4640b0 1ec2d968
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[104:105], v[110:111], v[64:71] ; cc464040 1d02dd68
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[106:107], v[110:111], v[184:191] ; cc4640b8 1ee2dd6a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[106:107], v[28:29], v[56:63] ; cc464038 1ce2396a
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[106:107], v[78:79], v[0:7] ; cc464000 1c029d6a
	ds_load_b64 v[104:105], v10 offset:18944                    ; d9d84a00 6800000a
	ds_load_b64 v[110:111], v10 offset:23040                    ; d9d85a00 6e00000a
	ds_load_b64 v[28:29], v10 offset:27136                      ; d9d86a00 1c00000a
	ds_load_b64 v[78:79], v10 offset:31232                      ; d9d87a00 4e00000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[106:107], v[108:109], v[152:159] ; cc464098 1e62d96a
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[34:35], v[96:103] ; cc464060 1d824528
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[44:45], v[112:119] ; cc464070 1dc2592a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[30:31], v[88:95] ; cc464058 1d623d28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[8:9], v[120:127] ; cc464078 1de2112a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[30:31], v[128:135] ; cc464080 1e023d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[34:35], v[144:151] ; cc464090 1e42452a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[8:9], v[80:87] ; cc464050 1d421128
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[40:41], v[44:45], v[48:55] ; cc464030 1cc25928
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[106:109], v39, s[28:31], null offen offset:5120 ; c405c07c 4080386a 00140027
	buffer_load_b128 v[40:43], v39, s[28:31], null offen offset:13312 ; c405c07c 40803828 00340027
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[140:141], v[30:31], v[168:175] ; cc4640a8 1ea23d8c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[140:141], v[44:45], v[64:71] ; cc464040 1d02598c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[140:141], v[8:9], v[160:167] ; cc4640a0 1e82118c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[142:143], v[44:45], v[184:191] ; cc4640b8 1ee2598e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[142:143], v[8:9], v[56:63] ; cc464038 1ce2118e
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[142:143], v[30:31], v[0:7] ; cc464000 1c023d8e
	ds_load_b64 v[138:139], v10 offset:19200                    ; d9d84b00 8a00000a
	ds_load_b64 v[44:45], v10 offset:23296                      ; d9d85b00 2c00000a
	ds_load_b64 v[8:9], v10 offset:27392                        ; d9d86b00 0800000a
	ds_load_b64 v[30:31], v10 offset:31488                      ; d9d87b00 1e00000a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[140:141], v[34:35], v[176:183] ; cc4640b0 1ec2458c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[142:143], v[34:35], v[152:159] ; cc464098 1e62458e
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[22:23], v[72:73], v[96:103] ; cc464060 1d829116
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[22:23], v[12:13], v[88:95] ; cc464058 1d621916
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[24:25], v[72:73], v[144:151] ; cc464090 1e429118
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[20:21], v[112:119] ; cc464070 1dc22918
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[136:137], v[120:127] ; cc464078 1de31118
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[24:25], v[12:13], v[128:135] ; cc464080 1e021918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[22:23], v[136:137], v[80:87] ; cc464050 1d431116
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[22:23], v[20:21], v[48:55] ; cc464030 1cc22916
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[140:143], v39, s[28:31], null offen offset:5632 ; c405c07c 4080388c 00160027
	buffer_load_b128 v[22:25], v39, s[28:31], null offen offset:13824 ; c405c07c 40803816 00360027
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[136:137], v[160:167] ; cc4640a0 1e831110
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[16:17], v[12:13], v[168:175] ; cc4640a8 1ea21910
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[16:17], v[20:21], v[64:71] ; cc464040 1d022910
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[72:73], v[176:183] ; cc4640b0 1ec29110
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[18:19], v[20:21], v[184:191] ; cc4640b8 1ee22912
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[18:19], v[12:13], v[0:7] ; cc464000 1c021912
	ds_load_b64 v[16:17], v10 offset:19456                      ; d9d84c00 1000000a
	ds_load_b64 v[20:21], v10 offset:23552                      ; d9d85c00 1400000a
	ds_load_b64 v[34:35], v10 offset:27648                      ; d9d86c00 2200000a
	ds_load_b64 v[12:13], v10 offset:31744                      ; d9d87c00 0c00000a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[18:19], v[136:137], v[56:63] ; cc464038 1ce31112
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[18:19], v[72:73], v[152:159] ; cc464098 1e629112
	v_dual_mov_b32 v19, v75 :: v_dual_mov_b32 v18, v74          ; ca10014b 1312014a
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[106:107], v[28:29], v[88:95] ; cc464058 1d62396a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[106:107], v[78:79], v[96:103] ; cc464060 1d829d6a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[106:107], v[110:111], v[80:87] ; cc464050 1d42dd6a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[78:79], v[144:151] ; cc464090 1e429d6c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[108:109], v[104:105], v[112:119] ; cc464070 1dc2d16c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[108:109], v[110:111], v[120:127] ; cc464078 1de2dd6c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[108:109], v[28:29], v[128:135] ; cc464080 1e02396c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[106:107], v[104:105], v[48:55] ; cc464030 1cc2d16a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v39, s[28:31], null offen offset:6144 ; c405c07c 40803848 00180027
	buffer_load_b128 v[106:109], v39, s[28:31], null offen offset:14336 ; c405c07c 4080386a 00380027
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[40:41], v[104:105], v[64:71] ; cc464040 1d02d128
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[40:41], v[78:79], v[176:183] ; cc4640b0 1ec29d28
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[40:41], v[110:111], v[160:167] ; cc4640a0 1e82dd28
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[28:29], v[168:175] ; cc4640a8 1ea23928
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[42:43], v[104:105], v[184:191] ; cc4640b8 1ee2d12a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[42:43], v[110:111], v[56:63] ; cc464038 1ce2dd2a
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[42:43], v[28:29], v[0:7] ; cc464000 1c02392a
	ds_load_b64 v[40:41], v10 offset:19712                      ; d9d84d00 2800000a
	ds_load_b64 v[104:105], v10 offset:23808                    ; d9d85d00 6800000a
	ds_load_b64 v[110:111], v10 offset:27904                    ; d9d86d00 6e00000a
	ds_load_b64 v[28:29], v10 offset:32000                      ; d9d87d00 1c00000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[42:43], v[78:79], v[152:159] ; cc464098 1e629d2a
	v_dual_mov_b32 v43, v77 :: v_dual_mov_b32 v42, v76          ; ca10014d 2b2a014c
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[140:141], v[8:9], v[88:95] ; cc464058 1d62118c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[140:141], v[30:31], v[96:103] ; cc464060 1d823d8c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[142:143], v[138:139], v[112:119] ; cc464070 1dc3158e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[140:141], v[44:45], v[80:87] ; cc464050 1d42598c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[142:143], v[30:31], v[144:151] ; cc464090 1e423d8e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[142:143], v[44:45], v[120:127] ; cc464078 1de2598e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[142:143], v[8:9], v[128:135] ; cc464080 1e02118e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[140:141], v[138:139], v[48:55] ; cc464030 1cc3158c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[76:79], v39, s[28:31], null offen offset:6656 ; c405c07c 4080384c 001a0027
	buffer_load_b128 v[140:143], v39, s[28:31], null offen offset:14848 ; c405c07c 4080388c 003a0027
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[22:23], v[44:45], v[160:167] ; cc4640a0 1e825916
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[8:9], v[168:175] ; cc4640a8 1ea21116
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[22:23], v[30:31], v[176:183] ; cc4640b0 1ec23d16
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[22:23], v[138:139], v[64:71] ; cc464040 1d031516
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[44:45], v[56:63] ; cc464038 1ce25918
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[24:25], v[8:9], v[0:7] ; cc464000 1c021118
	ds_load_b64 v[22:23], v10 offset:19968                      ; d9d84e00 1600000a
	ds_load_b64 v[136:137], v10 offset:24064                    ; d9d85e00 8800000a
	ds_load_b64 v[44:45], v10 offset:28160                      ; d9d86e00 2c00000a
	ds_load_b64 v[8:9], v10 offset:32256                        ; d9d87e00 0800000a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[24:25], v[138:139], v[184:191] ; cc4640b8 1ee31518
	v_dual_mov_b32 v139, v27 :: v_dual_mov_b32 v138, v26        ; ca10011b 8b8a011a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[24:25], v[30:31], v[152:159] ; cc464098 1e623d18
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[34:35], v[88:95] ; cc464058 1d624548
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[34:35], v[128:135] ; cc464080 1e02454a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[74:75], v[12:13], v[144:151] ; cc464090 1e42194a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[12:13], v[96:103] ; cc464060 1d821948
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[20:21], v[80:87] ; cc464050 1d422948
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[16:17], v[112:119] ; cc464070 1dc2214a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[20:21], v[120:127] ; cc464078 1de2294a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[72:73], v[16:17], v[48:55] ; cc464030 1cc22148
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[24:27], v39, s[28:31], null offen offset:7168 ; c405c07c 40803818 001c0027
	buffer_load_b128 v[72:75], v39, s[28:31], null offen offset:15360 ; c405c07c 40803848 003c0027
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[106:107], v[16:17], v[64:71] ; cc464040 1d02216a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[106:107], v[20:21], v[160:167] ; cc4640a0 1e82296a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[106:107], v[34:35], v[168:175] ; cc4640a8 1ea2456a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[108:109], v[16:17], v[184:191] ; cc4640b8 1ee2216c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[108:109], v[20:21], v[56:63] ; cc464038 1ce2296c
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[108:109], v[34:35], v[0:7] ; cc464000 1c02456c
	ds_load_b64 v[30:31], v10 offset:20224                      ; d9d84f00 1e00000a
	ds_load_b64 v[16:17], v10 offset:24320                      ; d9d85f00 1000000a
	ds_load_b64 v[20:21], v10 offset:28416                      ; d9d86f00 1400000a
	ds_load_b64 v[34:35], v10 offset:32512                      ; d9d87f00 2200000a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[106:107], v[12:13], v[176:183] ; cc4640b0 1ec2196a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[12:13], v[152:159] ; cc464098 1e62196c
	s_wait_loadcnt_dscnt 0x308                                  ; bfc80308
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[76:77], v[28:29], v[96:103] ; cc464060 1d82394c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[78:79], v[28:29], v[144:151] ; cc464090 1e42394e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[78:79], v[40:41], v[112:119] ; cc464070 1dc2514e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[78:79], v[104:105], v[120:127] ; cc464078 1de2d14e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[76:77], v[110:111], v[88:95] ; cc464058 1d62dd4c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[78:79], v[110:111], v[128:135] ; cc464080 1e02dd4e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[76:77], v[40:41], v[48:55] ; cc464030 1cc2514c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[76:77], v[104:105], v[80:87] ; cc464050 1d42d14c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[106:109], v39, s[28:31], null offen offset:7680 ; c405c07c 4080386a 001e0027
	buffer_load_b128 v[76:79], v39, s[28:31], null offen offset:15872 ; c405c07c 4080384c 003e0027
	v_mad_u32_u24 v10, s19, 0x820, v47                          ; d60b000a 04bdfe13 00000820
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[140:141], v[40:41], v[64:71] ; cc464040 1d02518c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[140:141], v[104:105], v[160:167] ; cc4640a0 1e82d18c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[140:141], v[110:111], v[168:175] ; cc4640a8 1ea2dd8c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[142:143], v[40:41], v[184:191] ; cc4640b8 1ee2518e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[142:143], v[104:105], v[56:63] ; cc464038 1ce2d18e
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[142:143], v[110:111], v[0:7] ; cc464000 1c02dd8e
	v_add_nc_u32_e32 v10, v10, v46                              ; 4a145d0a
	ds_load_b64 v[12:13], v10 offset:16384                      ; d9d84000 0c00000a
	ds_load_b64 v[40:41], v10 offset:20480                      ; d9d85000 2800000a
	ds_load_b64 v[104:105], v10 offset:24576                    ; d9d86000 6800000a
	ds_load_b64 v[110:111], v10 offset:28672                    ; d9d87000 6e00000a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[140:141], v[28:29], v[176:183] ; cc4640b0 1ec2398c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[142:143], v[28:29], v[152:159] ; cc464098 1e62398e
	buffer_load_b128 v[140:143], v39, s[28:31], null offen offset:16384 ; c405c07c 4080388c 00400027
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[22:23], v[112:119] ; cc464070 1dc22d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[24:25], v[22:23], v[48:55] ; cc464030 1cc22d18
	s_mov_b32 s22, 0x76543210                                   ; be9600ff 76543210
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[136:137], v[80:87] ; cc464050 1d431118
	s_mov_b32 s23, 0xfedcba98                                   ; be9700ff fedcba98
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[136:137], v[120:127] ; cc464078 1de3111a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[44:45], v[88:95] ; cc464058 1d625918
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[44:45], v[128:135] ; cc464080 1e02591a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[8:9], v[96:103] ; cc464060 1d821118
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[26:27], v[8:9], v[144:151] ; cc464090 1e42111a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[72:73], v[22:23], v[64:71] ; cc464040 1d022d48
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[22:23], v[184:191] ; cc4640b8 1ee22d4a
	ds_load_b64 v[24:25], v10 offset:16640                      ; d9d84100 1800000a
	ds_load_b64 v[26:27], v10 offset:20736                      ; d9d85100 1a00000a
	ds_load_b64 v[28:29], v10 offset:24832                      ; d9d86100 1c00000a
	ds_load_b64 v[22:23], v10 offset:28928                      ; d9d87100 1600000a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[44:45], v[168:175] ; cc4640a8 1ea25948
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[136:137], v[160:167] ; cc4640a0 1e831148
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[72:73], v[8:9], v[176:183] ; cc4640b0 1ec21148
	v_dual_mov_b32 v73, v47 :: v_dual_mov_b32 v72, v46          ; ca10012f 4948012e
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[74:75], v[44:45], v[0:7] ; cc464000 1c02594a
	buffer_load_b128 v[44:47], v39, s[28:31], null offen offset:16896 ; c405c07c 4080382c 00420027
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[74:75], v[136:137], v[56:63] ; cc464038 1ce3114a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[8:9], v[152:159] ; cc464098 1e62114a
	ds_load_b64 v[8:9], v10 offset:16896                        ; d9d84200 0800000a
	ds_load_b64 v[74:75], v10 offset:20992                      ; d9d85200 4a00000a
	s_movk_i32 s25, 0x410                                       ; b0190410
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[106:107], v[34:35], v[96:103] ; cc464060 1d82456a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[108:109], v[30:31], v[112:119] ; cc464070 1dc23d6c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[34:35], v[144:151] ; cc464090 1e42456c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[106:107], v[30:31], v[48:55] ; cc464030 1cc23d6a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[106:107], v[20:21], v[88:95] ; cc464058 1d62296a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[106:107], v[16:17], v[80:87] ; cc464050 1d42216a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[108:109], v[16:17], v[120:127] ; cc464078 1de2216c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[108:109], v[20:21], v[128:135] ; cc464080 1e02296c
	v_dual_mul_f32 v107, v115, v115 :: v_dual_mul_f32 v106, v113, v113 ; c8c6e773 6b6ae371
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v107, v51, v51 :: v_dual_fmac_f32 v106, v49, v49 ; c8006733 6b6a6331
	v_dual_fmac_f32 v107, v55, v55 :: v_dual_fmac_f32 v106, v53, v53 ; c8006f37 6b6a6b35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v107, v119, v119 :: v_dual_fmac_f32 v106, v117, v117 ; c800ef77 6b6aeb75
	v_dual_fmac_f32 v107, v50, v50 :: v_dual_fmac_f32 v106, v48, v48 ; c8006532 6b6a6130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v107, v114, v114 :: v_dual_fmac_f32 v106, v112, v112 ; c800e572 6b6ae170
	v_dual_fmac_f32 v107, v54, v54 :: v_dual_fmac_f32 v106, v52, v52 ; c8006d36 6b6a6934
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v107, v118, v118 :: v_dual_fmac_f32 v106, v116, v116 ; c800ed76 6b6ae974
	v_fma_mixlo_f16 v108, 1.0, v106, v107                       ; cc21006c 05aed4f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v109, v108                                ; 7edad76c
	v_permlanex16_b32 v109, v109, s22, s23 op_sel:[1,1]         ; d65c186d 005c2d6d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_f16_e32 v108, v108, v109                              ; 64d8db6c
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_max_num_f16_e32 v108, s25, v108                           ; 62d8d819
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v136, v108                                ; 7f10176c
	v_rsq_f32_e32 v136, v136                                    ; 7f105d88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v136, v136, v38                               ; 11104d88
	v_dual_mul_f32 v53, v53, v136 :: v_dual_mul_f32 v52, v52, v136 ; c8c71135 35351134
	v_dual_mul_f32 v116, v116, v136 :: v_dual_mul_f32 v117, v117, v136 ; c8c71174 74751175
	v_dual_mul_f32 v55, v55, v136 :: v_dual_mul_f32 v54, v54, v136 ; c8c71137 37371136
	v_dual_mul_f32 v49, v49, v136 :: v_dual_mul_f32 v48, v48, v136 ; c8c71131 31311130
	v_dual_mul_f32 v51, v51, v136 :: v_dual_mul_f32 v50, v50, v136 ; c8c71133 33331132
	v_dual_mul_f32 v112, v112, v136 :: v_dual_mul_f32 v113, v113, v136 ; c8c71170 70711171
	v_dual_mul_f32 v119, v119, v136 :: v_dual_mul_f32 v118, v118, v136 ; c8c71177 77771176
	v_dual_mul_f32 v114, v114, v136 :: v_dual_mul_f32 v115, v115, v136 ; c8c71172 72731173
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
	v_dual_mul_f32 v137, v121, v121 :: v_dual_mul_f32 v52, v123, v123 ; c8c6f379 8934f77b
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmac_f32 v137, v81, v81 :: v_dual_fmac_f32 v52, v83, v83 ; c800a351 8934a753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v52, v87, v87 :: v_dual_fmac_f32 v137, v85, v85 ; c800af57 3488ab55
	v_dual_fmac_f32 v52, v127, v127 :: v_dual_fmac_f32 v137, v125, v125 ; c800ff7f 3488fb7d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v52, v82, v82 :: v_dual_fmac_f32 v137, v80, v80 ; c800a552 3488a150
	v_dual_fmac_f32 v52, v122, v122 :: v_dual_fmac_f32 v137, v120, v120 ; c800f57a 3488f178
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v52, v86, v86 :: v_dual_fmac_f32 v137, v84, v84 ; c800ad56 3488a954
	v_dual_fmac_f32 v52, v126, v126 :: v_dual_fmac_f32 v137, v124, v124 ; c800fd7e 3488f97c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v53, 1.0, v137, v52                         ; cc210035 04d312f2
	v_cvt_u32_u16_e32 v54, v53                                  ; 7e6cd735
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v54, v54, s22, s23 op_sel:[1,1]           ; d65c1836 005c2d36
	v_add_f16_e32 v53, v53, v54                                 ; 646a6d35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v53, s25, v53                             ; 626a6a19
	v_cvt_f32_f16_e32 v55, v53                                  ; 7e6e1735
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v55, v55                                      ; 7e6e5d37
	v_mul_f32_e32 v55, v55, v38                                 ; 106e4d37
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v121, v121, v55 :: v_dual_mul_f32 v120, v120, v55 ; c8c66f79 79786f78
	v_dual_mul_f32 v82, v82, v55 :: v_dual_mul_f32 v83, v83, v55 ; c8c66f52 52526f53
	v_dual_mul_f32 v80, v80, v55 :: v_dual_mul_f32 v81, v81, v55 ; c8c66f50 50506f51
	v_dual_mul_f32 v123, v123, v55 :: v_dual_mul_f32 v122, v122, v55 ; c8c66f7b 7b7a6f7a
	v_dual_mul_f32 v84, v84, v55 :: v_dual_mul_f32 v85, v85, v55 ; c8c66f54 54546f55
	v_dual_mul_f32 v125, v125, v55 :: v_dual_mul_f32 v124, v124, v55 ; c8c66f7d 7d7c6f7c
	v_dual_mul_f32 v127, v127, v55 :: v_dual_mul_f32 v126, v126, v55 ; c8c66f7f 7f7e6f7e
	v_dual_mul_f32 v87, v87, v55 :: v_dual_mul_f32 v86, v86, v55 ; c8c66f57 57566f56
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_dual_mul_f32 v83, v131, v131 :: v_dual_mul_f32 v82, v129, v129 ; c8c70783 53530381
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_dual_fmac_f32 v83, v91, v91 :: v_dual_fmac_f32 v82, v89, v89 ; c800b75b 5352b359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v83, v95, v95 :: v_dual_fmac_f32 v82, v93, v93 ; c800bf5f 5352bb5d
	v_dual_fmac_f32 v83, v135, v135 :: v_dual_fmac_f32 v82, v133, v133 ; c8010f87 53530b85
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v83, v90, v90 :: v_dual_fmac_f32 v82, v88, v88 ; c800b55a 5352b158
	v_dual_fmac_f32 v83, v130, v130 :: v_dual_fmac_f32 v82, v128, v128 ; c8010582 53530180
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v83, v94, v94 :: v_dual_fmac_f32 v82, v92, v92 ; c800bd5e 5352b95c
	v_dual_fmac_f32 v83, v134, v134 :: v_dual_fmac_f32 v82, v132, v132 ; c8010d86 53530984
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[76:77], v[30:31], v[64:71] ; cc464040 1d023d4c
	v_fma_mixlo_f16 v84, 1.0, v82, v83                          ; cc210054 054ea4f2
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[76:77], v[16:17], v[160:167] ; cc4640a0 1e82214c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[76:77], v[20:21], v[168:175] ; cc4640a8 1ea2294c
	v_cvt_u32_u16_e32 v85, v84                                  ; 7eaad754
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[76:77], v[34:35], v[176:183] ; cc4640b0 1ec2454c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[78:79], v[30:31], v[184:191] ; cc4640b8 1ee23d4e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[78:79], v[16:17], v[56:63] ; cc464038 1ce2214e
	v_permlanex16_b32 v85, v85, s22, s23 op_sel:[1,1]           ; d65c1855 005c2d55
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[78:79], v[20:21], v[0:7] ; cc464000 1c02294e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[78:79], v[34:35], v[152:159] ; cc464098 1e62454e
	v_add_f16_e32 v84, v84, v85                                 ; 64a8ab54
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v84, s25, v84                             ; 62a8a819
	v_cvt_f32_f16_e32 v86, v84                                  ; 7eac1754
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v86, v86                                      ; 7eac5d56
	v_mul_f32_e32 v86, v86, v38                                 ; 10ac4d56
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v89, v89, v86 :: v_dual_mul_f32 v88, v88, v86 ; c8c6ad59 5958ad58
	v_dual_mul_f32 v135, v135, v86 :: v_dual_mul_f32 v134, v134, v86 ; c8c6ad87 8786ad86
	v_dual_mul_f32 v128, v128, v86 :: v_dual_mul_f32 v129, v129, v86 ; c8c6ad80 8080ad81
	v_dual_mul_f32 v130, v130, v86 :: v_dual_mul_f32 v131, v131, v86 ; c8c6ad82 8282ad83
	v_dual_mul_f32 v93, v93, v86 :: v_dual_mul_f32 v92, v92, v86 ; c8c6ad5d 5d5cad5c
	v_dual_mul_f32 v132, v132, v86 :: v_dual_mul_f32 v133, v133, v86 ; c8c6ad84 8484ad85
	v_dual_mul_f32 v95, v95, v86 :: v_dual_mul_f32 v94, v94, v86 ; c8c6ad5f 5f5ead5e
	v_dual_mul_f32 v91, v91, v86 :: v_dual_mul_f32 v90, v90, v86 ; c8c6ad5b 5b5aad5a
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_dual_mul_f32 v88, v147, v147 :: v_dual_mul_f32 v87, v145, v145 ; c8c72793 58572391
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_dual_fmac_f32 v88, v99, v99 :: v_dual_fmac_f32 v87, v97, v97 ; c800c763 5856c361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v88, v103, v103 :: v_dual_fmac_f32 v87, v101, v101 ; c800cf67 5856cb65
	v_dual_fmac_f32 v88, v151, v151 :: v_dual_fmac_f32 v87, v149, v149 ; c8012f97 58572b95
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v88, v98, v98 :: v_dual_fmac_f32 v87, v96, v96 ; c800c562 5856c160
	v_dual_fmac_f32 v88, v146, v146 :: v_dual_fmac_f32 v87, v144, v144 ; c8012592 58572190
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v88, v102, v102 :: v_dual_fmac_f32 v87, v100, v100 ; c800cd66 5856c964
	v_dual_fmac_f32 v88, v150, v150 :: v_dual_fmac_f32 v87, v148, v148 ; c8012d96 58572994
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v89, 1.0, v87, v88                          ; cc210059 0562aef2
	v_cvt_u32_u16_e32 v90, v89                                  ; 7eb4d759
	v_dual_mul_f32 v93, v187, v187 :: v_dual_mul_f32 v92, v185, v185 ; c8c777bb 5d5d73b9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v90, v90, s22, s23 op_sel:[1,1]           ; d65c185a 005c2d5a
	v_dual_fmac_f32 v93, v67, v67 :: v_dual_fmac_f32 v92, v65, v65 ; c8008743 5d5c8341
	v_add_f16_e32 v89, v89, v90                                 ; 64b2b559
	v_dual_fmac_f32 v93, v71, v71 :: v_dual_fmac_f32 v92, v69, v69 ; c8008f47 5d5c8b45
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_max_num_f16_e32 v89, s25, v89                             ; 62b2b219
	v_dual_fmac_f32 v93, v191, v191 :: v_dual_fmac_f32 v92, v189, v189 ; c8017fbf 5d5d7bbd
	v_cvt_f32_f16_e32 v91, v89                                  ; 7eb61759
	v_dual_fmac_f32 v93, v66, v66 :: v_dual_fmac_f32 v92, v64, v64 ; c8008542 5d5c8140
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a2
	v_rsq_f32_e32 v91, v91                                      ; 7eb65d5b
	v_dual_fmac_f32 v93, v186, v186 :: v_dual_fmac_f32 v92, v184, v184 ; c80175ba 5d5d71b8
	v_mul_f32_e32 v91, v91, v38                                 ; 10b64d5b
	v_dual_fmac_f32 v93, v70, v70 :: v_dual_fmac_f32 v92, v68, v68 ; c8008d46 5d5c8944
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v96, v96, v91 :: v_dual_mul_f32 v97, v97, v91 ; c8c6b760 6060b761
	v_dual_mul_f32 v98, v98, v91 :: v_dual_mul_f32 v99, v99, v91 ; c8c6b762 6262b763
	v_dual_mul_f32 v100, v100, v91 :: v_dual_mul_f32 v101, v101, v91 ; c8c6b764 6464b765
	v_dual_mul_f32 v145, v145, v91 :: v_dual_mul_f32 v144, v144, v91 ; c8c6b791 9190b790
	v_dual_mul_f32 v147, v147, v91 :: v_dual_mul_f32 v146, v146, v91 ; c8c6b793 9392b792
	v_dual_mul_f32 v149, v149, v91 :: v_dual_mul_f32 v148, v148, v91 ; c8c6b795 9594b794
	v_dual_mul_f32 v103, v103, v91 :: v_dual_mul_f32 v102, v102, v91 ; c8c6b767 6766b766
	v_dual_mul_f32 v151, v151, v91 :: v_dual_mul_f32 v150, v150, v91 ; c8c6b797 9796b796
	v_dual_fmac_f32 v93, v190, v190 :: v_dual_fmac_f32 v92, v188, v188 ; c8017dbe 5d5d79bc
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	buffer_load_b128 v[76:79], v39, s[28:31], null offen offset:17408 ; c405c07c 4080384c 00440027
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_fma_mixlo_f16 v94, 1.0, v92, v93                          ; cc21005e 0576b8f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v95, v94                                  ; 7ebed75e
	v_permlanex16_b32 v95, v95, s22, s23 op_sel:[1,1]           ; d65c185f 005c2d5f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v94, v94, v95                                 ; 64bcbf5e
	v_max_num_f16_e32 v94, s25, v94                             ; 62bcbc19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v96, v94                                  ; 7ec0175e
	v_rsq_f32_e32 v96, v96                                      ; 7ec05d60
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870135
	v_dual_mul_f32 v70, v70, v96 :: v_dual_mul_f32 v69, v69, v96 ; c8c6c146 4644c145
	v_mul_f32_e32 v68, v68, v96                                 ; 1088c144
	v_dual_mul_f32 v184, v184, v96 :: v_dual_mul_f32 v71, v71, v96 ; c8c6c1b8 b846c147
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	buffer_load_b128 v[68:71], v39, s[28:31], null offen offset:17920 ; c405c07c 40803844 00460027
	v_dual_mul_f32 v65, v65, v96 :: v_dual_mul_f32 v64, v64, v96 ; c8c6c141 4140c140
	v_dual_mul_f32 v67, v67, v96 :: v_dual_mul_f32 v66, v66, v96 ; c8c6c143 4342c142
	v_dual_mul_f32 v188, v188, v96 :: v_dual_mul_f32 v187, v187, v96 ; c8c6c1bc bcbac1bb
	buffer_load_b128 v[84:87], v39, s[28:31], null offen offset:18432 ; c405c07c 40803854 00480027
	v_dual_mul_f32 v186, v186, v96 :: v_dual_mul_f32 v185, v185, v96 ; c8c6c1ba bab8c1b9
	v_mul_f32_e32 v189, v189, v96                               ; 117ac1bd
	v_mul_f32_e32 v191, v191, v96                               ; 117ec1bf
	v_dual_mul_f32 v97, v57, v57 :: v_dual_mul_f32 v190, v190, v96 ; c8c67339 61bec1be
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_dual_fmac_f32 v97, v161, v161 :: v_dual_mul_f32 v98, v59, v59 ; c80743a1 6162773b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_fmac_f32 v97, v165, v165 :: v_dual_fmac_f32 v98, v163, v163 ; c8014ba5 616347a3
	buffer_load_b128 v[88:91], v39, s[28:31], null offen offset:18944 ; c405c07c 40803858 004a0027
	v_dual_fmac_f32 v97, v61, v61 :: v_dual_fmac_f32 v98, v167, v167 ; c8007b3d 61634fa7
	v_dual_fmac_f32 v97, v160, v160 :: v_dual_fmac_f32 v98, v63, v63 ; c80141a0 61627f3f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v98, v162, v162                              ; 56c545a2
	v_dual_fmac_f32 v98, v58, v58 :: v_dual_fmac_f32 v97, v56, v56 ; c800753a 62607138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v98, v166, v166 :: v_dual_fmac_f32 v97, v164, v164 ; c8014da6 626149a4
	v_dual_fmac_f32 v98, v62, v62 :: v_dual_fmac_f32 v97, v60, v60 ; c8007d3e 6260793c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v99, 1.0, v97, v98                          ; cc210063 058ac2f2
	v_cvt_u32_u16_e32 v100, v99                                 ; 7ec8d763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v100, v100, s22, s23 op_sel:[1,1]         ; d65c1864 005c2d64
	v_add_f16_e32 v99, v99, v100                                ; 64c6c963
	buffer_load_b128 v[92:95], v39, s[28:31], null offen offset:19456 ; c405c07c 4080385c 004c0027
	v_max_num_f16_e32 v99, s25, v99                             ; 62c6c619
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v101, v99                                 ; 7eca1763
	v_mul_f32_e32 v102, v1, v1                                  ; 10cc0301
	v_rsq_f32_e32 v101, v101                                    ; 7eca5d65
	v_dual_fmac_f32 v102, v169, v169 :: v_dual_mul_f32 v103, v3, v3 ; c80753a9 66660703
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmac_f32 v102, v173, v173 :: v_dual_fmac_f32 v103, v171, v171 ; c8015bad 666757ab
	v_mul_f32_e32 v160, v160, v101                              ; 1140cba0
	v_dual_mul_f32 v165, v165, v101 :: v_dual_mul_f32 v164, v164, v101 ; c8c6cba5 a5a4cba4
	v_dual_mul_f32 v167, v167, v101 :: v_dual_mul_f32 v166, v166, v101 ; c8c6cba7 a7a6cba6
	v_dual_mul_f32 v63, v63, v101 :: v_dual_mul_f32 v62, v62, v101 ; c8c6cb3f 3f3ecb3e
	v_dual_mul_f32 v57, v57, v101 :: v_dual_mul_f32 v56, v56, v101 ; c8c6cb39 3938cb38
	v_dual_mul_f32 v61, v61, v101 :: v_dual_mul_f32 v60, v60, v101 ; c8c6cb3d 3d3ccb3c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	buffer_load_b128 v[60:63], v39, s[28:31], null offen offset:19968 ; c405c07c 4080383c 004e0027
	v_dual_mul_f32 v163, v163, v101 :: v_dual_mul_f32 v162, v162, v101 ; c8c6cba3 a3a2cba2
	v_mul_f32_e32 v161, v161, v101                              ; 1142cba1
	v_dual_mul_f32 v59, v59, v101 :: v_dual_mul_f32 v58, v58, v101 ; c8c6cb3b 3b3acb3a
	v_fmac_f32_e32 v103, v175, v175                             ; 56cf5faf
	buffer_load_b128 v[96:99], v39, s[28:31], null offen offset:20480 ; c405c07c 40803860 00500027
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	v_dual_fmac_f32 v103, v7, v7 :: v_dual_fmac_f32 v102, v5, v5 ; c8000f07 67660b05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v103, v170, v170 :: v_dual_fmac_f32 v102, v168, v168 ; c80155aa 676751a8
	v_dual_fmac_f32 v103, v2, v2 :: v_dual_fmac_f32 v102, v0, v0 ; c8000502 67660100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v103, v174, v174 :: v_dual_fmac_f32 v102, v172, v172 ; c8015dae 676759ac
	v_dual_fmac_f32 v103, v6, v6 :: v_dual_fmac_f32 v102, v4, v4 ; c8000d06 67660904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_fma_mixlo_f16 v106, 1.0, v102, v103                       ; cc21006a 059eccf2
	buffer_load_b128 v[100:103], v39, s[28:31], null offen offset:20992 ; c405c07c 40803864 00520027
	v_cvt_u32_u16_e32 v107, v106                                ; 7ed6d76a
	v_permlanex16_b32 v107, v107, s22, s23 op_sel:[1,1]         ; d65c186b 005c2d6b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v106, v106, v107                              ; 64d4d76a
	v_max_num_f16_e32 v106, s25, v106                           ; 62d4d419
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v108, v106                                ; 7ed8176a
	v_rsq_f32_e32 v108, v108                                    ; 7ed85d6c
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_mul_f32_e32 v1, v1, v108                                  ; 1002d901
	v_dual_mul_f32 v171, v171, v108 :: v_dual_mul_f32 v170, v170, v108 ; c8c6d9ab abaad9aa
	v_dual_mul_f32 v5, v5, v108 :: v_dual_mul_f32 v2, v2, v108  ; c8c6d905 0502d902
	v_dual_mul_f32 v7, v7, v108 :: v_dual_mul_f32 v4, v4, v108  ; c8c6d907 0704d904
	v_dual_mul_f32 v109, v153, v153 :: v_dual_mul_f32 v6, v6, v108 ; c8c73399 6d06d906
	v_dual_mul_f32 v3, v3, v108 :: v_dual_mul_f32 v0, v0, v108  ; c8c6d903 0300d900
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                        ; 02020300
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                        ; 02020b04
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
	buffer_load_b128 v[4:7], v39, s[28:31], null offen offset:21504 ; c405c07c 40803804 00540027
	v_dual_mul_f32 v175, v175, v108 :: v_dual_mul_f32 v174, v174, v108 ; c8c6d9af afaed9ae
	v_dual_mul_f32 v173, v173, v108 :: v_dual_mul_f32 v172, v172, v108 ; c8c6d9ad adacd9ac
	v_dual_mul_f32 v169, v169, v108 :: v_dual_mul_f32 v168, v168, v108 ; c8c6d9a9 a9a8d9a8
	v_mul_f32_e32 v112, v155, v155                              ; 10e1379b
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v2, v3, vcc_lo                        ; 02020702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d4
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_dual_fmac_f32 v112, v179, v179 :: v_dual_fmac_f32 v109, v177, v177 ; c80167b3 706d63b1
	v_dual_fmac_f32 v112, v183, v183 :: v_dual_fmac_f32 v109, v181, v181 ; c8016fb7 706d6bb5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v112, v159, v159 :: v_dual_fmac_f32 v109, v157, v157 ; c8013f9f 706d3b9d
	v_dual_fmac_f32 v112, v178, v178 :: v_dual_fmac_f32 v109, v176, v176 ; c80165b2 706d61b0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v112, v154, v154 :: v_dual_fmac_f32 v109, v152, v152 ; c801359a 706d3198
	v_dual_fmac_f32 v112, v182, v182 :: v_dual_fmac_f32 v109, v180, v180 ; c8016db6 706d69b4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v112, v158, v158 :: v_dual_fmac_f32 v109, v156, v156 ; c8013d9e 706d399c
	v_fma_mixlo_f16 v113, 1.0, v109, v112                       ; cc210071 05c2daf2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v114, v113                                ; 7ee4d771
	v_permlanex16_b32 v114, v114, s22, s23 op_sel:[1,1]         ; d65c1872 005c2d72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_add_f16_e32 v113, v113, v114                              ; 64e2e571
	ds_load_b64 v[106:107], v10 offset:25088                    ; d9d86200 6a00000a
	ds_load_b64 v[108:109], v10 offset:29184                    ; d9d87200 6c00000a
	v_max_num_f16_e32 v113, s25, v113                           ; 62e2e219
	v_cvt_f32_f16_e32 v115, v113                                ; 7ee61771
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v115, v115                                    ; 7ee65d73
	v_dual_mul_f32 v155, v155, v115 :: v_dual_mul_f32 v154, v154, v115 ; c8c6e79b 9b9ae79a
	v_dual_mul_f32 v176, v176, v115 :: v_dual_mul_f32 v177, v177, v115 ; c8c6e7b0 b0b0e7b1
	v_dual_mul_f32 v178, v178, v115 :: v_dual_mul_f32 v179, v179, v115 ; c8c6e7b2 b2b2e7b3
	v_dual_mul_f32 v180, v180, v115 :: v_dual_mul_f32 v181, v181, v115 ; c8c6e7b4 b4b4e7b5
	v_dual_mul_f32 v182, v182, v115 :: v_dual_mul_f32 v183, v183, v115 ; c8c6e7b6 b6b6e7b7
	v_dual_mul_f32 v152, v152, v115 :: v_dual_mul_f32 v153, v153, v115 ; c8c6e798 9898e799
	v_dual_mul_f32 v157, v157, v115 :: v_dual_mul_f32 v156, v156, v115 ; c8c6e79d 9d9ce79c
	v_dual_mul_f32 v159, v159, v115 :: v_dual_mul_f32 v158, v158, v115 ; c8c6e79f 9f9ee79e
	ds_load_b64 v[112:113], v10 offset:17152                    ; d9d84300 7000000a
	ds_load_b64 v[114:115], v10 offset:21248                    ; d9d85300 7200000a
	ds_load_b64 v[116:117], v10 offset:25344                    ; d9d86300 7400000a
	ds_load_b64 v[118:119], v10 offset:29440                    ; d9d87300 7600000a
	s_wait_loadcnt_dscnt 0xa0f                                  ; bfc80a0f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[12:13], v[140:141], 0 ; cc464078 1a03190c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[40:41], v[140:141], 0 ; cc464080 1a031928
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[104:105], v[140:141], 0 ; cc464090 1a031968
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[142:143], 0 ; cc4640a0 1a031d0c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[142:143], 0 ; cc4640a8 1a031d28
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[104:105], v[142:143], 0 ; cc4640b0 1a031d68
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[142:143], 0 ; cc4640b8 1a031d6e
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[110:111], v[140:141], 0 ; cc464098 1a03196e
	s_wait_loadcnt_dscnt 0x90b                                  ; bfc8090b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[44:45], v[120:127] ; cc464078 1de25918
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[44:45], v[128:135] ; cc464080 1e02591a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[28:29], v[44:45], v[144:151] ; cc464090 1e42591c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[24:25], v[46:47], v[160:167] ; cc4640a0 1e825d18
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[26:27], v[46:47], v[168:175] ; cc4640a8 1ea25d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[28:29], v[46:47], v[176:183] ; cc4640b0 1ec25d1c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[22:23], v[46:47], v[184:191] ; cc4640b8 1ee25d16
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[22:23], v[44:45], v[152:159] ; cc464098 1e625916
	ds_load_b64 v[12:13], v10 offset:17408                      ; d9d84400 0c00000a
	ds_load_b64 v[40:41], v10 offset:21504                      ; d9d85400 2800000a
	ds_load_b64 v[104:105], v10 offset:25600                    ; d9d86400 6800000a
	ds_load_b64 v[110:111], v10 offset:29696                    ; d9d87400 6e00000a
	ds_load_b64 v[22:23], v10 offset:17664                      ; d9d84500 1600000a
	ds_load_b64 v[24:25], v10 offset:21760                      ; d9d85500 1800000a
	ds_load_b64 v[26:27], v10 offset:25856                      ; d9d86500 1a00000a
	ds_load_b64 v[28:29], v10 offset:29952                      ; d9d87500 1c00000a
	s_wait_loadcnt_dscnt 0x80f                                  ; bfc8080f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[8:9], v[76:77], v[120:127] ; cc464078 1de29908
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[76:77], v[128:135] ; cc464080 1e02994a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[8:9], v[78:79], v[160:167] ; cc4640a0 1e829d08
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[74:75], v[78:79], v[168:175] ; cc4640a8 1ea29d4a
	ds_load_b64 v[8:9], v10 offset:17920                        ; d9d84600 0800000a
	ds_load_b64 v[44:45], v10 offset:22016                      ; d9d85600 2c00000a
	ds_load_b64 v[46:47], v10 offset:26112                      ; d9d86600 2e00000a
	ds_load_b64 v[74:75], v10 offset:30208                      ; d9d87600 4a00000a
	s_wait_dscnt 0x11                                           ; bfc60011
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[106:107], v[76:77], v[144:151] ; cc464090 1e42996a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[106:107], v[78:79], v[176:183] ; cc4640b0 1ec29d6a
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[108:109], v[78:79], v[184:191] ; cc4640b8 1ee29d6c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[76:77], v[152:159] ; cc464098 1e62996c
	s_wait_loadcnt_dscnt 0x70f                                  ; bfc8070f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[112:113], v[68:69], v[120:127] ; cc464078 1de28970
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[114:115], v[68:69], v[128:135] ; cc464080 1e028972
	v_mov_b32_e32 v38, v138                                     ; 7e4c038a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[116:117], v[68:69], v[144:151] ; cc464090 1e428974
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[118:119], v[68:69], v[152:159] ; cc464098 1e628976
	v_mov_b32_e32 v68, v139                                     ; 7e88038b
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[76:79], v39, s[28:31], null offen offset:22016 ; c405c07c 4080384c 00560027
	buffer_load_b128 v[140:143], v39, s[28:31], null offen offset:22528 ; c405c07c 4080388c 00580027
	buffer_load_b128 v[106:109], v39, s[28:31], null offen offset:23040 ; c405c07c 4080386a 005a0027
	buffer_load_b128 v[136:139], v39, s[28:31], null offen offset:23552 ; c405c07c 40803888 005c0027
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[112:113], v[70:71], v[160:167] ; cc4640a0 1e828d70
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[114:115], v[70:71], v[168:175] ; cc4640a8 1ea28d72
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[116:117], v[70:71], v[176:183] ; cc4640b0 1ec28d74
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[70:71], v[184:191] ; cc4640b8 1ee28d76
	s_wait_loadcnt_dscnt 0xa0b                                  ; bfc80a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[12:13], v[84:85], v[120:127] ; cc464078 1de2a90c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[40:41], v[84:85], v[128:135] ; cc464080 1e02a928
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[104:105], v[84:85], v[144:151] ; cc464090 1e42a968
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[110:111], v[84:85], v[152:159] ; cc464098 1e62a96e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[86:87], v[160:167] ; cc4640a0 1e82ad0c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[86:87], v[168:175] ; cc4640a8 1ea2ad28
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[104:105], v[86:87], v[176:183] ; cc4640b0 1ec2ad68
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[86:87], v[184:191] ; cc4640b8 1ee2ad6e
	ds_load_b64 v[70:71], v10 offset:18176                      ; d9d84700 4600000a
	ds_load_b64 v[112:113], v10 offset:22272                    ; d9d85700 7000000a
	ds_load_b64 v[114:115], v10 offset:26368                    ; d9d86700 7200000a
	ds_load_b64 v[116:117], v10 offset:30464                    ; d9d87700 7400000a
	ds_load_b64 v[12:13], v10 offset:18432                      ; d9d84800 0c00000a
	ds_load_b64 v[40:41], v10 offset:22528                      ; d9d85800 2800000a
	ds_load_b64 v[84:85], v10 offset:26624                      ; d9d86800 5400000a
	ds_load_b64 v[86:87], v10 offset:30720                      ; d9d87800 5600000a
	s_wait_loadcnt_dscnt 0x90f                                  ; bfc8090f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[88:89], v[120:127] ; cc464078 1de2b116
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[24:25], v[88:89], v[128:135] ; cc464080 1e02b118
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[26:27], v[88:89], v[144:151] ; cc464090 1e42b11a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[28:29], v[88:89], v[152:159] ; cc464098 1e62b11c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[22:23], v[90:91], v[160:167] ; cc4640a0 1e82b516
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[24:25], v[90:91], v[168:175] ; cc4640a8 1ea2b518
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[26:27], v[90:91], v[176:183] ; cc4640b0 1ec2b51a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[28:29], v[90:91], v[184:191] ; cc4640b8 1ee2b51c
	s_wait_loadcnt_dscnt 0x80b                                  ; bfc8080b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[8:9], v[92:93], v[120:127] ; cc464078 1de2b908
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[44:45], v[92:93], v[128:135] ; cc464080 1e02b92c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[92:93], v[144:151] ; cc464090 1e42b92e
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[92:93], v[152:159] ; cc464098 1e62b94a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[8:9], v[94:95], v[160:167] ; cc4640a0 1e82bd08
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[94:95], v[168:175] ; cc4640a8 1ea2bd2c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[94:95], v[176:183] ; cc4640b0 1ec2bd2e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[94:95], v[184:191] ; cc4640b8 1ee2bd4a
	ds_load_b64 v[22:23], v10 offset:18688                      ; d9d84900 1600000a
	ds_load_b64 v[24:25], v10 offset:22784                      ; d9d85900 1800000a
	ds_load_b64 v[26:27], v10 offset:26880                      ; d9d86900 1a00000a
	ds_load_b64 v[28:29], v10 offset:30976                      ; d9d87900 1c00000a
	ds_load_b64 v[8:9], v10 offset:18944                        ; d9d84a00 0800000a
	ds_load_b64 v[44:45], v10 offset:23040                      ; d9d85a00 2c00000a
	ds_load_b64 v[46:47], v10 offset:27136                      ; d9d86a00 2e00000a
	ds_load_b64 v[74:75], v10 offset:31232                      ; d9d87a00 4a00000a
	s_wait_loadcnt_dscnt 0x70f                                  ; bfc8070f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[60:61], v[120:127] ; cc464078 1de27946
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[112:113], v[60:61], v[128:135] ; cc464080 1e027970
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[114:115], v[60:61], v[144:151] ; cc464090 1e427972
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[60:61], v[152:159] ; cc464098 1e627974
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[70:71], v[62:63], v[160:167] ; cc4640a0 1e827d46
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[112:113], v[62:63], v[168:175] ; cc4640a8 1ea27d70
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[62:63], v[176:183] ; cc4640b0 1ec27d72
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[116:117], v[62:63], v[184:191] ; cc4640b8 1ee27d74
	s_wait_loadcnt_dscnt 0x60b                                  ; bfc8060b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[12:13], v[96:97], v[120:127] ; cc464078 1de2c10c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[40:41], v[96:97], v[128:135] ; cc464080 1e02c128
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[96:97], v[144:151] ; cc464090 1e42c154
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[96:97], v[152:159] ; cc464098 1e62c156
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[98:99], v[160:167] ; cc4640a0 1e82c50c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[98:99], v[168:175] ; cc4640a8 1ea2c528
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[84:85], v[98:99], v[176:183] ; cc4640b0 1ec2c554
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[86:87], v[98:99], v[184:191] ; cc4640b8 1ee2c556
	ds_load_b64 v[60:61], v10 offset:19200                      ; d9d84b00 3c00000a
	ds_load_b64 v[62:63], v10 offset:23296                      ; d9d85b00 3e00000a
	ds_load_b64 v[70:71], v10 offset:27392                      ; d9d86b00 4600000a
	ds_load_b64 v[88:89], v10 offset:31488                      ; d9d87b00 5800000a
	ds_load_b64 v[12:13], v10 offset:19456                      ; d9d84c00 0c00000a
	ds_load_b64 v[40:41], v10 offset:23552                      ; d9d85c00 2800000a
	ds_load_b64 v[84:85], v10 offset:27648                      ; d9d86c00 5400000a
	ds_load_b64 v[86:87], v10 offset:31744                      ; d9d87c00 5600000a
	ds_load_b64 v[90:91], v10 offset:19712                      ; d9d84d00 5a00000a
	ds_load_b64 v[92:93], v10 offset:23808                      ; d9d85d00 5c00000a
	ds_load_b64 v[94:95], v10 offset:27904                      ; d9d86d00 5e00000a
	ds_load_b64 v[96:97], v10 offset:32000                      ; d9d87d00 6000000a
	ds_load_b64 v[98:99], v10 offset:19968                      ; d9d84e00 6200000a
	ds_load_b64 v[104:105], v10 offset:24064                    ; d9d85e00 6800000a
	ds_load_b64 v[110:111], v10 offset:28160                    ; d9d86e00 6e00000a
	ds_load_b64 v[112:113], v10 offset:32256                    ; d9d87e00 7000000a
	ds_load_b64 v[114:115], v10 offset:20224                    ; d9d84f00 7200000a
	ds_load_b64 v[116:117], v10 offset:24320                    ; d9d85f00 7400000a
	s_wait_loadcnt_dscnt 0x519                                  ; bfc80519
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[100:101], v[120:127] ; cc464078 1de2c916
	s_wait_dscnt 0x18                                           ; bfc60018
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[24:25], v[100:101], v[128:135] ; cc464080 1e02c918
	s_wait_dscnt 0x17                                           ; bfc60017
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[26:27], v[100:101], v[144:151] ; cc464090 1e42c91a
	s_wait_dscnt 0x16                                           ; bfc60016
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[28:29], v[100:101], v[152:159] ; cc464098 1e62c91c
	ds_load_b64 v[100:101], v10 offset:28416                    ; d9d86f00 6400000a
	ds_load_b64 v[118:119], v10 offset:32512                    ; d9d87f00 7600000a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[22:23], v[102:103], v[160:167] ; cc4640a0 1e82cd16
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[24:25], v[102:103], v[168:175] ; cc4640a8 1ea2cd18
	buffer_load_b128 v[22:25], v39, s[28:31], null offen offset:24064 ; c405c07c 40803816 005e0027
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[26:27], v[102:103], v[176:183] ; cc4640b0 1ec2cd1a
	v_lshl_add_u32 v15, v15, 12, s7                             ; d646000f 001d190f
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[28:29], v[102:103], v[184:191] ; cc4640b8 1ee2cd1c
	v_mov_b32_e32 v69, v11                                      ; 7e8a030b
	s_wait_dscnt 0x1                                            ; bfc60001
	v_dual_mov_b32 v11, v101 :: v_dual_mov_b32 v10, v100        ; ca100165 0b0a0164
	v_lshl_add_u32 v14, v14, 6, v15                             ; d646000e 043d0d0e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v14, v14, v72, 2                             ; d647000e 020a910e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[26:29], v14, s[36:39], null offen        ; c405c07c 4080481a 0000000e
	buffer_load_b128 v[100:103], v14, s[36:39], null offen offset:16 ; c405c07c 40804864 0000100e
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[8:9], v[4:5], v[120:127] ; cc464078 1de20908
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[44:45], v[4:5], v[128:135] ; cc464080 1e02092c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[4:5], v[144:151] ; cc464090 1e42092e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[4:5], v[152:159] ; cc464098 1e62094a
	v_dual_mov_b32 v5, v73 :: v_dual_mov_b32 v4, v72            ; ca100149 05040148
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[6:7], v[168:175] ; cc4640a8 1ea20d2c
	v_dual_mov_b32 v45, v3 :: v_dual_mov_b32 v44, v2            ; ca100103 2d2c0102
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[8:9], v[6:7], v[160:167] ; cc4640a0 1e820d08
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[6:7], v[176:183] ; cc4640b0 1ec20d2e
	v_dual_mov_b32 v47, v57 :: v_dual_mov_b32 v46, v56          ; ca100139 2f2e0138
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[6:7], v[184:191] ; cc4640b8 1ee20d4a
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[60:61], v[76:77], v[120:127] ; cc464078 1de2993c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[76:77], v[128:135] ; cc464080 1e02993e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[76:77], v[144:151] ; cc464090 1e429946
	v_mov_b32_e32 v15, v4                                       ; 7e1e0304
	v_mov_b32_e32 v39, v5                                       ; 7e4e0305
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[88:89], v[76:77], v[152:159] ; cc464098 1e629958
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[60:61], v[78:79], v[160:167] ; cc4640a0 1e829d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[88:89], v[78:79], v[184:191] ; cc4640b8 1ee29d58
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[12:13], v[140:141], v[120:127] ; cc464078 1de3190c
	v_dual_mov_b32 v89, v15 :: v_dual_mov_b32 v88, v14          ; ca10010f 5958010e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[142:143], v[160:167] ; cc4640a0 1e831d0c
	buffer_load_b128 v[12:15], v14, s[36:39], null offen offset:64 ; c405c07c 4080480c 0000400e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[62:63], v[78:79], v[168:175] ; cc4640a8 1ea29d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[66:67], v[48:49], 0   ; cc464002 1a026142
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[78:79], v[176:183] ; cc4640b0 1ec29d46
	v_dual_mov_b32 v79, v59 :: v_dual_mov_b32 v78, v58          ; ca10013b 4f4e013a
	v_wmma_f32_16x16x16_fp8_fp8 v[70:77], v[54:55], v[48:49], 0 ; cc464046 1a026136
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[40:41], v[140:141], v[128:135] ; cc464080 1e031928
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[140:141], v[144:151] ; cc464090 1e431954
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[140:141], v[152:159] ; cc464098 1e631956
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[86:87], v[142:143], v[184:191] ; cc4640b8 1ee31d56
	v_dual_mov_b32 v141, v89 :: v_dual_mov_b32 v140, v88        ; ca100159 8d8c0158
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[142:143], v[168:175] ; cc4640a8 1ea31d28
	v_dual_mov_b32 v41, v83 :: v_dual_mov_b32 v40, v82          ; ca100153 29280152
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[46:47], v[50:51], v[2:9] ; cc464002 1c0a652e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[78:79], v[48:49], 0 ; cc464038 1a02614e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[84:85], v[142:143], v[176:183] ; cc4640b0 1ec31d54
	v_wmma_f32_16x16x16_fp8_fp8 v[82:89], v[44:45], v[48:49], 0 ; cc464052 1a02612c
	v_wmma_f32_16x16x16_fp8_fp8 v[70:77], v[64:65], v[50:51], v[70:77] ; cc464046 1d1a6540
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[0:1], v[50:51], v[56:63] ; cc464038 1ce26500
	v_wmma_f32_16x16x16_fp8_fp8 v[82:89], v[40:41], v[50:51], v[82:89] ; cc464052 1d4a6528
	buffer_load_b128 v[48:51], v140, s[36:39], null offen offset:80 ; c405c07c 40804830 0000508c
	s_mov_b32 s26, 0x3d380000                                   ; be9a00ff 3d380000
	s_movk_i32 s27, 0x3e47                                      ; b01b3e47
	s_movk_i32 s34, 0x3c20                                      ; b0223c20
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[90:91], v[106:107], v[120:127] ; cc464078 1de2d55a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[106:107], v[128:135] ; cc464080 1e02d55c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[94:95], v[106:107], v[144:151] ; cc464090 1e42d55e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[106:107], v[152:159] ; cc464098 1e62d560
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[90:91], v[108:109], v[160:167] ; cc4640a0 1e82d95a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[92:93], v[108:109], v[168:175] ; cc4640a8 1ea2d95c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[96:97], v[108:109], v[184:191] ; cc4640b8 1ee2d960
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[94:95], v[108:109], v[176:183] ; cc4640b0 1ec2d95e
	s_mov_b32 s35, 0x7ff88000                                   ; bea300ff 7ff88000
	s_movk_i32 s40, 0x400                                       ; b0280400
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[98:99], v[136:137], v[120:127] ; cc464078 1de31162
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[104:105], v[136:137], v[128:135] ; cc464080 1e031168
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[110:111], v[136:137], v[144:151] ; cc464090 1e43116e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[136:137], v[152:159] ; cc464098 1e631170
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[98:99], v[138:139], v[160:167] ; cc4640a0 1e831562
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[104:105], v[138:139], v[168:175] ; cc4640a8 1ea31568
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[112:113], v[138:139], v[184:191] ; cc4640b8 1ee31570
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[110:111], v[138:139], v[176:183] ; cc4640b0 1ec3156e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[54:55], v[52:53], 0 ; cc464068 1a026936
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[114:115], v[22:23], v[120:127] ; cc464078 1de22d72
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[116:117], v[22:23], v[128:135] ; cc464080 1e022d74
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[10:11], v[22:23], v[144:151] ; cc464090 1e422d0a
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[118:119], v[22:23], v[152:159] ; cc464098 1e622d76
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[114:115], v[24:25], v[160:167] ; cc4640a0 1e823172
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[116:117], v[24:25], v[168:175] ; cc4640a8 1ea23174
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[24:25], v[184:191] ; cc4640b8 1ee23176
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[10:11], v[24:25], v[176:183] ; cc4640b0 1ec2310a
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	s_clause 0xb                                                ; bf85000b
	buffer_load_b128 v[92:95], v140, s[36:39], null offen offset:128 ; c405c07c 4080485c 0000808c
	buffer_load_b128 v[96:99], v140, s[36:39], null offen offset:144 ; c405c07c 40804860 0000908c
	buffer_load_b128 v[112:115], v140, s[36:39], null offen offset:192 ; c405c07c 40804870 0000c08c
	buffer_load_b128 v[116:119], v140, s[36:39], null offen offset:208 ; c405c07c 40804874 0000d08c
	buffer_load_b128 v[120:123], v140, s[36:39], null offen offset:4096 ; c405c07c 40804878 0010008c
	buffer_load_b128 v[124:127], v140, s[36:39], null offen offset:4112 ; c405c07c 4080487c 0010108c
	buffer_load_b128 v[128:131], v140, s[36:39], null offen offset:4160 ; c405c07c 40804880 0010408c
	buffer_load_b128 v[132:135], v140, s[36:39], null offen offset:4176 ; c405c07c 40804884 0010508c
	buffer_load_b128 v[136:139], v140, s[36:39], null offen offset:4224 ; c405c07c 40804888 0010808c
	buffer_load_b128 v[160:163], v140, s[36:39], null offen offset:4240 ; c405c07c 408048a0 0010908c
	buffer_load_b128 v[164:167], v140, s[36:39], null offen offset:4288 ; c405c07c 408048a4 0010c08c
	buffer_load_b128 v[168:171], v140, s[36:39], null offen offset:4304 ; c405c07c 408048a8 0010d08c
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d769008e
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769408e
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769008f
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769408f
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690090
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694090
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690091
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694091
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690092
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694092
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690093
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694093
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690094
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694094
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690095
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694095
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[52:53], 0 ; cc464098 1a026942
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[78:79], v[52:53], 0 ; cc4640b0 1a02694e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[44:45], v[52:53], 0 ; cc4640b8 1a02692c
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_fma_mixlo_f16 v70, s26, v70, v26                          ; cc210046 046a8c1a
	v_fma_mixhi_f16 v70, s26, v71, v27                          ; cc220046 046e8e1a
	v_dual_mov_b32 v27, v79 :: v_dual_mov_b32 v26, v78          ; ca10014f 1b1a014e
	v_fma_mixlo_f16 v71, s26, v72, v28                          ; cc210047 0472901a
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v72, s26, v74, v100                         ; cc210048 0592941a
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_fma_mixlo_f16 v100, s26, v2, v12                          ; cc210064 0432041a
	v_fma_mixhi_f16 v100, s26, v3, v13                          ; cc220064 0436061a
	v_dual_mov_b32 v13, v7 :: v_dual_mov_b32 v12, v6            ; ca100107 0d0c0106
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[64:65], v[80:81], v[104:111] ; cc464068 1da2a140
	v_fma_mixhi_f16 v72, s26, v75, v101                         ; cc220048 0596961a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[80:81], v[152:159] ; cc464098 1e62a12e
	v_fma_mixlo_f16 v101, s26, v4, v14                          ; cc210065 043a081a
	v_fma_mixhi_f16 v101, s26, v5, v15                          ; cc220065 043e0a1a
	v_dual_mov_b32 v15, v9 :: v_dual_mov_b32 v14, v8            ; ca100109 0f0e0108
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[0:1], v[80:81], v[176:183] ; cc4640b0 1ec2a100
	v_fma_mixhi_f16 v71, s26, v73, v29                          ; cc220047 0476921a
(invalid instruction)                                        ; cc1c0046
	v_subrev_f32_e32 v0, v70, v34                               ; 0a004546
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[40:41], v[80:81], v[184:191] ; cc4640b8 1ee2a128
(invalid instruction)                                        ; cc1c0048
	v_subrev_f32_e32 v0, v72, v34                               ; 0a004548
	v_fma_mixlo_f16 v73, s26, v76, v102                         ; cc210049 059a981a
	v_fma_mixhi_f16 v73, s26, v77, v103                         ; cc220049 059e9a1a
(invalid instruction)                                        ; cc1c0047
	v_subrev_f32_e32 v0, v71, v34                               ; 0a004547
(invalid instruction)                                        ; cc1b0046
	v_subrev_f32_e32 v0, v70, v27                               ; 0a003746
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v28, s26, v12, v48                          ; cc21001c 04c2181a
	v_fma_mixhi_f16 v28, s26, v13, v49                          ; cc22001c 04c61a1a
	v_dual_mov_b32 v13, v61 :: v_dual_mov_b32 v12, v60          ; ca10013d 0d0c013c
	v_dual_mov_b32 v53, v179 :: v_dual_mov_b32 v52, v178        ; ca1001b3 353401b2
	v_dual_mov_b32 v151, v177 :: v_dual_mov_b32 v150, v176      ; ca1001b1 979601b0
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[54:55], v[16:17], 0 ; cc4640ac 1a022136
	v_wmma_f32_16x16x16_fp8_fp8 v[74:81], v[66:67], v[16:17], 0 ; cc46404a 1a022142
	v_fma_mixlo_f16 v29, s26, v14, v50                          ; cc21001d 04ca1c1a
	v_fma_mixhi_f16 v29, s26, v15, v51                          ; cc22001d 04ce1e1a
(invalid instruction)                                        ; cc1b0048
	v_subrev_f32_e32 v0, v72, v27                               ; 0a003748
	v_dual_mov_b32 v15, v63 :: v_dual_mov_b32 v14, v62          ; ca10013f 0f0e013e
(invalid instruction)                                        ; cc1c0049
	v_subrev_f32_e32 v0, v73, v34                               ; 0a004549
(invalid instruction)                                        ; cc1c0064
	v_subrev_f32_e32 v0, v100, v34                              ; 0a004564
(invalid instruction)                                        ; cc1b0047
	v_subrev_f32_e32 v0, v71, v27                               ; 0a003747
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v34                              ; 0a004565
	v_lshl_add_u32 v70, v70, 5, s35                             ; d6460046 008d0b46
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[26:27], v[16:17], 0   ; cc464002 1a02211a
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v34                               ; 0a00451c
(invalid instruction)                                        ; cc1c001d
	v_subrev_f32_e32 v0, v29, v34                               ; 0a00451d
	v_lshl_add_u32 v72, v72, 5, s35                             ; d6460048 008d0b48
(invalid instruction)                                        ; cc1b0049
	v_subrev_f32_e32 v0, v73, v27                               ; 0a003749
(invalid instruction)                                        ; cc1b0064
	v_subrev_f32_e32 v0, v100, v27                              ; 0a003764
	v_lshl_add_u32 v71, v71, 5, s35                             ; d6460047 008d0b47
(invalid instruction)                                        ; cc1b0065
	v_subrev_f32_e32 v0, v101, v27                              ; 0a003765
(invalid instruction)                                        ; cc1b001c
	v_subrev_f32_e32 v0, v28, v27                               ; 0a00371c
(invalid instruction)                                        ; cc1b001d
	v_subrev_f32_e32 v0, v29, v27                               ; 0a00371d
	v_lshl_add_u32 v73, v73, 5, s35                             ; d6460049 008d0b49
	v_lshl_add_u32 v100, v100, 5, s35                           ; d6460064 008d0b64
	v_lshl_add_u32 v101, v101, 5, s35                           ; d6460065 008d0b65
	v_lshl_add_u32 v28, v28, 5, s35                             ; d646001c 008d0b1c
	v_lshl_add_u32 v29, v29, 5, s35                             ; d646001d 008d0b1d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[70:71], v[100:101]              ; 1a02c946
(invalid instruction)                                        ; cc0f0067
	v_min_num_f64_e32 v[1:2], v[71:72], v[101:102]              ; 1a02cb47
(invalid instruction)                                        ; cc0f0030
	v_min_num_f64_e32 v[1:2], v[72:73], v[28:29]                ; 1a023948
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v51, s26, v58, v94                          ; cc210033 057a741a
	v_fma_mixlo_f16 v50, s26, v56, v92                          ; cc210032 0572701a
	v_fma_mixhi_f16 v50, s26, v57, v93                          ; cc220032 0576721a
	v_fma_mixhi_f16 v51, s26, v59, v95                          ; cc220033 057e761a
	buffer_load_b128 v[92:95], v140, s[36:39], null offen offset:8192 ; c405c07c 4080485c 0020008c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[16:17], 0 ; cc464038 1a02212c
	v_wmma_f32_16x16x16_fp8_fp8 v[172:179], v[64:65], v[20:21], v[172:179] ; cc4640ac 1eb22940
(invalid instruction)                                        ; cc0f0031
	v_min_num_f64_e32 v[1:2], v[73:74], v[29:30]                ; 1a023b49
	v_wmma_f32_16x16x16_fp8_fp8 v[74:81], v[46:47], v[20:21], v[74:81] ; cc46404a 1d2a292e
	v_wmma_f32_16x16x16_fp8_fp8 v[2:9], v[0:1], v[20:21], v[2:9] ; cc464002 1c0a2900
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v16, s26, v12, v96                          ; cc210010 0582181a
	v_fma_mixhi_f16 v16, s26, v13, v97                          ; cc220010 05861a1a
(invalid instruction)                                        ; cc1c0032
	v_subrev_f32_e32 v0, v50, v34                               ; 0a004532
(invalid instruction)                                        ; cc1c0033
	v_subrev_f32_e32 v0, v51, v34                               ; 0a004533
	v_fma_mixlo_f16 v17, s26, v14, v98                          ; cc210011 058a1c1a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[40:41], v[20:21], v[56:63] ; cc464038 1ce22928
	v_fma_mixhi_f16 v17, s26, v15, v99                          ; cc220011 058e1e1a
(invalid instruction)                                        ; cc1c0010
	v_subrev_f32_e32 v0, v16, v34                               ; 0a004510
(invalid instruction)                                        ; cc1b0032
	v_subrev_f32_e32 v0, v50, v27                               ; 0a003732
(invalid instruction)                                        ; cc1b0033
	v_subrev_f32_e32 v0, v51, v27                               ; 0a003733
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v20, s26, v82, v112                         ; cc210014 05c2a41a
	v_fma_mixhi_f16 v20, s26, v83, v113                         ; cc220014 05c6a61a
	v_fma_mixlo_f16 v21, s26, v84, v114                         ; cc210015 05caa81a
	v_fma_mixhi_f16 v21, s26, v85, v115                         ; cc220015 05ceaa1a
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v34                               ; 0a004511
(invalid instruction)                                        ; cc1b0010
	v_subrev_f32_e32 v0, v16, v27                               ; 0a003710
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v82, s26, v86, v116                         ; cc210052 05d2ac1a
	v_lshl_add_u32 v50, v50, 5, s35                             ; d6460032 008d0b32
	v_fma_mixhi_f16 v82, s26, v87, v117                         ; cc220052 05d6ae1a
	v_lshl_add_u32 v51, v51, 5, s35                             ; d6460033 008d0b33
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v34                               ; 0a004514
	v_fma_mixlo_f16 v83, s26, v88, v118                         ; cc210053 05dab01a
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v34                               ; 0a004515
	v_fma_mixhi_f16 v83, s26, v89, v119                         ; cc220053 05deb21a
(invalid instruction)                                        ; cc1b0011
	v_subrev_f32_e32 v0, v17, v27                               ; 0a003711
	v_lshl_add_u32 v16, v16, 5, s35                             ; d6460010 008d0b10
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[50:51]              ; 1a026566
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v34                               ; 0a004552
(invalid instruction)                                        ; cc0f0067
	v_min_num_f64_e32 v[1:2], v[103:104], v[51:52]              ; 1a026767
(invalid instruction)                                        ; cc1b0014
	v_subrev_f32_e32 v0, v20, v27                               ; 0a003714
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v27                               ; 0a003715
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v34                               ; 0a004553
	v_lshl_add_u32 v17, v17, 5, s35                             ; d6460011 008d0b11
(invalid instruction)                                        ; cc0f0030
	v_min_num_f64_e32 v[1:2], v[48:49], v[16:17]                ; 1a022130
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v27                               ; 0a003752
	v_lshl_add_u32 v20, v20, 5, s35                             ; d6460014 008d0b14
	v_lshl_add_u32 v21, v21, 5, s35                             ; d6460015 008d0b15
(invalid instruction)                                        ; cc1b0053
	v_subrev_f32_e32 v0, v83, v27                               ; 0a003753
(invalid instruction)                                        ; cc0f0031
	v_min_num_f64_e32 v[1:2], v[49:50], v[17:18]                ; 1a022331
	v_lshl_add_u32 v82, v82, 5, s35                             ; d6460052 008d0b52
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[20:21]              ; 1a022966
(invalid instruction)                                        ; cc0f0067
	v_min_num_f64_e32 v[1:2], v[103:104], v[21:22]              ; 1a022b67
	v_lshl_add_u32 v83, v83, 5, s35                             ; d6460053 008d0b53
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f0030
	v_min_num_f64_e32 v[1:2], v[48:49], v[82:83]                ; 1a02a530
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[103:104]            ; 1a02cf66
(invalid instruction)                                        ; cc0f0031
	v_min_num_f64_e32 v[1:2], v[49:50], v[83:84]                ; 1a02a731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[48:49]              ; 1a026166
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[49:50]              ; 1a026366
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v84, v102, s22, s23 op_sel:[1,1]          ; d65c1854 005c2d66
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[84:85]              ; 1a02a966
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v85, v102, v230/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64abcd66
	v_max_num_f16_e32 v85, s40, v85                             ; 62aaaa28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v86, v85                                  ; 7eac1755
	v_rcp_f32_e32 v86, v86                                      ; 7eac5556
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v97, v100, v86, neg(0) op_sel_hi:[1,0,0]      ; cc200061 8a02ad64
	v_fma_mix_f32 v89, v72, v86, neg(0) op_sel_hi:[1,0,0]       ; cc200059 8a02ad48
	v_fma_mix_f32 v98, v101, v86, neg(0) op_sel_hi:[1,0,0]      ; cc200062 8a02ad65
	v_fma_mix_f32 v72, v72, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200848 8a02ad48
	v_fma_mix_f32 v100, v100, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200864 8a02ad64
	v_fma_mix_f32 v87, v70, v86, neg(0) op_sel_hi:[1,0,0]       ; cc200057 8a02ad46
	v_fma_mix_f32 v70, v70, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200846 8a02ad46
	v_fma_mix_f32 v96, v73, v86, neg(0) op_sel_hi:[1,0,0]       ; cc200060 8a02ad49
	v_fma_mix_f32 v73, v73, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200849 8a02ad49
	v_fma_mix_f32 v88, v71, v86, neg(0) op_sel_hi:[1,0,0]       ; cc200058 8a02ad47
	v_fma_mix_f32 v71, v71, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200847 8a02ad47
	v_fma_mix_f32 v101, v101, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200865 8a02ad65
	v_fma_mix_f32 v99, v28, v86, neg(0) op_sel_hi:[1,0,0]       ; cc200063 8a02ad1c
	v_fma_mix_f32 v28, v28, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a02ad1c
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v89, v72, vcc_lo                      ; 02029159
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v97, v100, vcc_lo                     ; 0202c961
	v_fma_mix_f32 v100, v29, v86, neg(0) op_sel_hi:[1,0,0]      ; cc200064 8a02ad1d
	v_fma_mix_f32 v29, v29, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081d 8a02ad1d
	v_fma_mix_f32 v102, v51, v86, neg(0) op_sel_hi:[1,0,0]      ; cc200066 8a02ad33
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v87, v70, vcc_lo                      ; 02028d57
	v_fma_mix_f32 v51, v51, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200833 8a02ad33
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v96, v73, vcc_lo                      ; 02029360
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v98, v101, vcc_lo                     ; 0202cb62
	v_fma_mix_f32 v101, v50, v86, neg(0) op_sel_hi:[1,0,0]      ; cc200065 8a02ad32
	v_fma_mix_f32 v50, v50, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200832 8a02ad32
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v99, v28, vcc_lo                      ; 02023963
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v101, v50, vcc_lo                     ; 02026565
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v102, v51, vcc_lo                     ; 02026766
	buffer_load_b128 v[48:51], v140, s[36:39], null offen offset:8208 ; c405c07c 40804830 0020108c
	v_fma_mix_f32 v103, v16, v86, neg(0) op_sel_hi:[1,0,0]      ; cc200067 8a02ad10
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v88, v71, vcc_lo                      ; 02028f58
	v_fma_mix_f32 v16, v16, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200810 8a02ad10
	v_fma_mix_f32 v112, v17, v86, neg(0) op_sel_hi:[1,0,0]      ; cc200070 8a02ad11
	v_fma_mix_f32 v17, v17, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200811 8a02ad11
	v_fma_mix_f32 v113, v20, v86, neg(0) op_sel_hi:[1,0,0]      ; cc200071 8a02ad14
	v_fma_mix_f32 v20, v20, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a02ad14
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v100, v29, vcc_lo                     ; 02023b64
	v_fma_mix_f32 v114, v21, v86, neg(0) op_sel_hi:[1,0,0]      ; cc200072 8a02ad15
	v_fma_mix_f32 v21, v21, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a02ad15
	v_fma_mix_f32 v115, v82, v86, neg(0) op_sel_hi:[1,0,0]      ; cc200073 8a02ad52
	v_fma_mix_f32 v82, v82, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200852 8a02ad52
	v_fma_mix_f32 v116, v83, v86, neg(0) op_sel_hi:[1,0,0]      ; cc200074 8a02ad53
	v_fma_mix_f32 v83, v83, v86, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200853 8a02ad53
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[84:87], v140, s[36:39], null offen offset:8256 ; c405c07c 40804854 0020408c
	buffer_load_b128 v[96:99], v140, s[36:39], null offen offset:8272 ; c405c07c 40804860 0020508c
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v117, s26, v104, v120                       ; cc210075 05e2d01a
	v_fma_mixhi_f16 v117, s26, v105, v121                       ; cc220075 05e6d21a
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v103, v16, vcc_lo                     ; 02022167
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v112, v17, vcc_lo                     ; 02022370
	v_fma_mixlo_f16 v118, s26, v106, v122                       ; cc210076 05ead41a
	v_fma_mixhi_f16 v118, s26, v107, v123                       ; cc220076 05eed61a
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v113, v20, vcc_lo                     ; 02022971
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v21, vcc_lo                     ; 02022b72
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v119, s26, v108, v124                       ; cc210077 05f2d81a
	v_fma_mixhi_f16 v119, s26, v109, v125                       ; cc220077 05f6da1a
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v115, v82, vcc_lo                     ; 0202a573
	v_fma_mixlo_f16 v120, s26, v110, v126                       ; cc210078 05fadc1a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[100:103], v140, s[36:39], null offen offset:8320 ; c405c07c 40804864 0020808c
	buffer_load_b128 v[104:107], v140, s[36:39], null offen offset:8336 ; c405c07c 40804868 0020908c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v116, v83, vcc_lo                     ; 0202a774
	v_fma_mixhi_f16 v120, s26, v111, v127                       ; cc220078 05fede1a
(invalid instruction)                                        ; cc1c0075
	v_subrev_f32_e32 v0, v117, v34                              ; 0a004575
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v121, s26, v152, v128                       ; cc210079 0603301a
	v_fma_mixhi_f16 v121, s26, v153, v129                       ; cc220079 0607321a
(invalid instruction)                                        ; cc1c0076
	v_subrev_f32_e32 v0, v118, v34                              ; 0a004576
	v_fma_mixlo_f16 v122, s26, v154, v130                       ; cc21007a 060b341a
	v_fma_mixhi_f16 v122, s26, v155, v131                       ; cc22007a 060f361a
(invalid instruction)                                        ; cc1c0077
	v_subrev_f32_e32 v0, v119, v34                              ; 0a004577
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v123, s26, v156, v132                       ; cc21007b 0613381a
	v_fma_mixhi_f16 v123, s26, v157, v133                       ; cc22007b 06173a1a
(invalid instruction)                                        ; cc1c0078
	v_subrev_f32_e32 v0, v120, v34                              ; 0a004578
	v_fma_mixlo_f16 v124, s26, v158, v134                       ; cc21007c 061b3c1a
	v_fma_mixhi_f16 v124, s26, v159, v135                       ; cc22007c 061f3e1a
(invalid instruction)                                        ; cc1b0075
	v_subrev_f32_e32 v0, v117, v27                              ; 0a003775
(invalid instruction)                                        ; cc1c0079
	v_subrev_f32_e32 v0, v121, v34                              ; 0a004579
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[108:111], v140, s[36:39], null offen offset:8384 ; c405c07c 4080486c 0020c08c
	buffer_load_b128 v[112:115], v140, s[36:39], null offen offset:8400 ; c405c07c 40804870 0020d08c
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v125, s26, v150, v136                       ; cc21007d 06232c1a
(invalid instruction)                                        ; cc1b0076
	v_subrev_f32_e32 v0, v118, v27                              ; 0a003776
	v_fma_mixhi_f16 v125, s26, v151, v137                       ; cc22007d 06272e1a
(invalid instruction)                                        ; cc1c007a
	v_subrev_f32_e32 v0, v122, v34                              ; 0a00457a
(invalid instruction)                                        ; cc1b0077
	v_subrev_f32_e32 v0, v119, v27                              ; 0a003777
(invalid instruction)                                        ; cc1c007b
	v_subrev_f32_e32 v0, v123, v34                              ; 0a00457b
	v_fma_mixlo_f16 v126, s26, v52, v138                        ; cc21007e 062a681a
(invalid instruction)                                        ; cc1b0078
	v_subrev_f32_e32 v0, v120, v27                              ; 0a003778
	v_fma_mixhi_f16 v126, s26, v53, v139                        ; cc22007e 062e6a1a
(invalid instruction)                                        ; cc1c007c
	v_subrev_f32_e32 v0, v124, v34                              ; 0a00457c
(invalid instruction)                                        ; cc1b0079
	v_subrev_f32_e32 v0, v121, v27                              ; 0a003779
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v127, s26, v180, v160                       ; cc21007f 0683681a
	v_fma_mixhi_f16 v127, s26, v181, v161                       ; cc22007f 06876a1a
	v_fma_mixlo_f16 v128, s26, v182, v162                       ; cc210080 068b6c1a
	v_fma_mixhi_f16 v128, s26, v183, v163                       ; cc220080 068f6e1a
(invalid instruction)                                        ; cc1c007d
	v_subrev_f32_e32 v0, v125, v34                              ; 0a00457d
(invalid instruction)                                        ; cc1b007a
	v_subrev_f32_e32 v0, v122, v27                              ; 0a00377a
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v129, s26, v184, v164                       ; cc210081 0693701a
(invalid instruction)                                        ; cc1b007b
	v_subrev_f32_e32 v0, v123, v27                              ; 0a00377b
	v_fma_mixhi_f16 v129, s26, v185, v165                       ; cc220081 0697721a
(invalid instruction)                                        ; cc1c007e
	v_subrev_f32_e32 v0, v126, v34                              ; 0a00457e
(invalid instruction)                                        ; cc1b007c
	v_subrev_f32_e32 v0, v124, v27                              ; 0a00377c
	v_fma_mixlo_f16 v130, s26, v186, v166                       ; cc210082 069b741a
	v_fma_mixhi_f16 v130, s26, v187, v167                       ; cc220082 069f761a
(invalid instruction)                                        ; cc1c007f
	v_subrev_f32_e32 v0, v127, v34                              ; 0a00457f
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v131, s26, v188, v168                       ; cc210083 06a3781a
	v_fma_mixhi_f16 v131, s26, v189, v169                       ; cc220083 06a77a1a
(invalid instruction)                                        ; cc1c0080
	v_subrev_f32_e32 v0, v128, v34                              ; 0a004580
(invalid instruction)                                        ; cc1b007d
	v_subrev_f32_e32 v0, v125, v27                              ; 0a00377d
	v_fma_mixlo_f16 v132, s26, v190, v170                       ; cc210084 06ab7c1a
	v_fma_mixhi_f16 v132, s26, v191, v171                       ; cc220084 06af7e1a
(invalid instruction)                                        ; cc1c0081
	v_subrev_f32_e32 v0, v129, v34                              ; 0a004581
(invalid instruction)                                        ; cc1b007e
	v_subrev_f32_e32 v0, v126, v27                              ; 0a00377e
	v_lshl_add_u32 v117, v117, 5, s35                           ; d6460075 008d0b75
	v_lshl_add_u32 v121, v121, 5, s35                           ; d6460079 008d0b79
(invalid instruction)                                        ; cc1c0082
	v_subrev_f32_e32 v0, v130, v34                              ; 0a004582
(invalid instruction)                                        ; cc1b007f
	v_subrev_f32_e32 v0, v127, v27                              ; 0a00377f
(invalid instruction)                                        ; cc1c0083
	v_subrev_f32_e32 v0, v131, v34                              ; 0a004583
(invalid instruction)                                        ; cc1b0080
	v_subrev_f32_e32 v0, v128, v27                              ; 0a003780
	v_lshl_add_u32 v125, v125, 5, s35                           ; d646007d 008d0b7d
	v_lshl_add_u32 v118, v118, 5, s35                           ; d6460076 008d0b76
	v_lshl_add_u32 v122, v122, 5, s35                           ; d646007a 008d0b7a
(invalid instruction)                                        ; cc1c0084
	v_subrev_f32_e32 v0, v132, v34                              ; 0a004584
(invalid instruction)                                        ; cc1b0081
	v_subrev_f32_e32 v0, v129, v27                              ; 0a003781
	v_lshl_add_u32 v126, v126, 5, s35                           ; d646007e 008d0b7e
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[117:118], v[121:122]            ; 1a02f375
(invalid instruction)                                        ; cc1b0082
	v_subrev_f32_e32 v0, v130, v27                              ; 0a003782
	v_lshl_add_u32 v119, v119, 5, s35                           ; d6460077 008d0b77
	v_lshl_add_u32 v123, v123, 5, s35                           ; d646007b 008d0b7b
(invalid instruction)                                        ; cc1b0083
	v_subrev_f32_e32 v0, v131, v27                              ; 0a003783
	v_lshl_add_u32 v127, v127, 5, s35                           ; d646007f 008d0b7f
(invalid instruction)                                        ; cc0f0086
	v_min_num_f64_e32 v[1:2], v[118:119], v[122:123]            ; 1a02f576
	v_lshl_add_u32 v120, v120, 5, s35                           ; d6460078 008d0b78
(invalid instruction)                                        ; cc1b0084
	v_subrev_f32_e32 v0, v132, v27                              ; 0a003784
	v_lshl_add_u32 v129, v129, 5, s35                           ; d6460081 008d0b81
	v_lshl_add_u32 v124, v124, 5, s35                           ; d646007c 008d0b7c
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[133:134], v[125:126]            ; 1a02fb85
	v_lshl_add_u32 v128, v128, 5, s35                           ; d6460080 008d0b80
	v_lshl_add_u32 v130, v130, 5, s35                           ; d6460082 008d0b82
(invalid instruction)                                        ; cc0f0087
	v_min_num_f64_e32 v[1:2], v[119:120], v[123:124]            ; 1a02f777
	v_lshl_add_u32 v131, v131, 5, s35                           ; d6460083 008d0b83
(invalid instruction)                                        ; cc0f0086
	v_min_num_f64_e32 v[1:2], v[134:135], v[126:127]            ; 1a02fd86
	v_lshl_add_u32 v132, v132, 5, s35                           ; d6460084 008d0b84
(invalid instruction)                                        ; cc0f0088
	v_min_num_f64_e32 v[1:2], v[120:121], v[124:125]            ; 1a02f978
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[133:134], v[129:130]            ; 1a030385
(invalid instruction)                                        ; cc0f0087
	v_min_num_f64_e32 v[1:2], v[135:136], v[127:128]            ; 1a02ff87
(invalid instruction)                                        ; cc0f0086
	v_min_num_f64_e32 v[1:2], v[134:135], v[130:131]            ; 1a030586
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f0088
	v_min_num_f64_e32 v[1:2], v[136:137], v[128:129]            ; 1a030188
(invalid instruction)                                        ; cc0f0087
	v_min_num_f64_e32 v[1:2], v[135:136], v[131:132]            ; 1a030787
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[133:134], v[134:135]            ; 1a030d85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f0088
	v_min_num_f64_e32 v[1:2], v[136:137], v[132:133]            ; 1a030988
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[133:134], v[135:136]            ; 1a030f85
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[133:134], v[136:137]            ; 1a031185
	v_permlanex16_b32 v137, v133, s22, s23 op_sel:[1,1]         ; d65c1889 005c2d85
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[133:134], v[137:138]            ; 1a031385
(invalid instruction)                                        ; d532108a
	v_cndmask_b32_e32 v1, v133, v133, vcc_lo                    ; 02030b85
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d531008a
	v_cndmask_b32_e32 v1, s40, v138, vcc_lo                     ; 02031428
(invalid instruction)                                        ; d58b008b
	v_cndmask_b32_e32 v0, v138, v128, vcc_lo                    ; 0201018a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v139, v139                                    ; 7f16558b
	v_fma_mix_f32 v150, v117, v139, neg(0) op_sel_hi:[1,0,0]    ; cc200096 8a031775
	v_fma_mix_f32 v151, v118, v139, neg(0) op_sel_hi:[1,0,0]    ; cc200097 8a031776
	v_fma_mix_f32 v118, v118, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200876 8a031776
	v_fma_mix_f32 v155, v122, v139, neg(0) op_sel_hi:[1,0,0]    ; cc20009b 8a03177a
	v_fma_mix_f32 v154, v121, v139, neg(0) op_sel_hi:[1,0,0]    ; cc20009a 8a031779
	v_fma_mix_f32 v121, v121, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200879 8a031779
	v_fma_mix_f32 v153, v120, v139, neg(0) op_sel_hi:[1,0,0]    ; cc200099 8a031778
	v_fma_mix_f32 v117, v117, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200875 8a031775
	v_fma_mix_f32 v152, v119, v139, neg(0) op_sel_hi:[1,0,0]    ; cc200098 8a031777
	v_fma_mix_f32 v119, v119, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a031777
	v_fma_mix_f32 v120, v120, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200878 8a031778
	v_fma_mix_f32 v122, v122, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087a 8a03177a
	v_fma_mix_f32 v156, v123, v139, neg(0) op_sel_hi:[1,0,0]    ; cc20009c 8a03177b
	v_fma_mix_f32 v123, v123, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087b 8a03177b
	v_fma_mix_f32 v157, v124, v139, neg(0) op_sel_hi:[1,0,0]    ; cc20009d 8a03177c
	v_fma_mix_f32 v124, v124, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087c 8a03177c
	v_fma_mix_f32 v158, v125, v139, neg(0) op_sel_hi:[1,0,0]    ; cc20009e 8a03177d
	v_fma_mix_f32 v125, v125, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087d 8a03177d
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v154, v121, vcc_lo                    ; 0202f39a
	v_fma_mix_f32 v159, v126, v139, neg(0) op_sel_hi:[1,0,0]    ; cc20009f 8a03177e
	v_fma_mix_f32 v126, v126, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087e 8a03177e
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v150, v117, vcc_lo                    ; 0202eb96
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v151, v118, vcc_lo                    ; 0202ed97
	v_fma_mix_f32 v160, v127, v139, neg(0) op_sel_hi:[1,0,0]    ; cc2000a0 8a03177f
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v152, v119, vcc_lo                    ; 0202ef98
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v153, v120, vcc_lo                    ; 0202f199
	v_fma_mix_f32 v127, v127, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087f 8a03177f
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v155, v122, vcc_lo                    ; 0202f59b
	v_fma_mix_f32 v161, v128, v139, neg(0) op_sel_hi:[1,0,0]    ; cc2000a1 8a031780
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v156, v123, vcc_lo                    ; 0202f79c
	v_fma_mix_f32 v128, v128, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200880 8a031780
	v_fma_mix_f32 v162, v129, v139, neg(0) op_sel_hi:[1,0,0]    ; cc2000a2 8a031781
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[116:119], v140, s[36:39], null offen offset:12288 ; c405c07c 40804874 0030008c
	buffer_load_b128 v[120:123], v140, s[36:39], null offen offset:12304 ; c405c07c 40804878 0030108c
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v157, v124, vcc_lo                    ; 0202f99d
	v_fma_mix_f32 v129, v129, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a031781
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v158, v125, vcc_lo                    ; 0202fb9e
	v_fma_mix_f32 v163, v130, v139, neg(0) op_sel_hi:[1,0,0]    ; cc2000a3 8a031782
	v_fma_mix_f32 v130, v130, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200882 8a031782
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v159, v126, vcc_lo                    ; 0202fd9f
	v_fma_mix_f32 v164, v131, v139, neg(0) op_sel_hi:[1,0,0]    ; cc2000a4 8a031783
	v_fma_mix_f32 v131, v131, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200883 8a031783
	v_fma_mix_f32 v165, v132, v139, neg(0) op_sel_hi:[1,0,0]    ; cc2000a5 8a031784
	v_fma_mix_f32 v132, v132, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200884 8a031784
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v160, v127, vcc_lo                    ; 0202ffa0
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v166, s26, v172, v92                        ; cc2100a6 0573581a
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v161, v128, vcc_lo                    ; 020301a1
	v_fma_mixhi_f16 v166, s26, v173, v93                        ; cc2200a6 05775a1a
	v_fma_mixlo_f16 v167, s26, v174, v94                        ; cc2100a7 057b5c1a
	v_fma_mixhi_f16 v167, s26, v175, v95                        ; cc2200a7 057f5e1a
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v162, v129, vcc_lo                    ; 020303a2
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v169, s26, v178, v50                        ; cc2100a9 04cb641a
	v_fma_mixhi_f16 v169, s26, v179, v51                        ; cc2200a9 04cf661a
	v_fma_mixlo_f16 v168, s26, v176, v48                        ; cc2100a8 04c3601a
	v_fma_mixhi_f16 v168, s26, v177, v49                        ; cc2200a8 04c7621a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v140, s[36:39], null offen offset:12352 ; c405c07c 40804830 0030408c
	buffer_load_b128 v[92:95], v140, s[36:39], null offen offset:12368 ; c405c07c 4080485c 0030508c
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v163, v130, vcc_lo                    ; 020305a3
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v164, v131, vcc_lo                    ; 020307a4
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v165, v132, vcc_lo                    ; 020309a5
(invalid instruction)                                        ; cc1c00a6
	v_subrev_f32_e32 v0, v166, v34                              ; 0a0045a6
(invalid instruction)                                        ; cc1c00a7
	v_subrev_f32_e32 v0, v167, v34                              ; 0a0045a7
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v34                              ; 0a0045a9
(invalid instruction)                                        ; cc1c00a8
	v_subrev_f32_e32 v0, v168, v34                              ; 0a0045a8
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b00a6
	v_subrev_f32_e32 v0, v166, v27                              ; 0a0037a6
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v170, s26, v74, v84                         ; cc2100aa 0552941a
	v_fma_mixlo_f16 v171, s26, v76, v86                         ; cc2100ab 055a981a
	v_fma_mixhi_f16 v171, s26, v77, v87                         ; cc2200ab 055e9a1a
	v_fma_mixhi_f16 v170, s26, v75, v85                         ; cc2200aa 0556961a
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v173, s26, v80, v98                         ; cc2100ad 058aa01a
	v_fma_mixlo_f16 v172, s26, v78, v96                         ; cc2100ac 05829c1a
	v_fma_mixhi_f16 v172, s26, v79, v97                         ; cc2200ac 05869e1a
	v_fma_mixhi_f16 v173, s26, v81, v99                         ; cc2200ad 058ea21a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[76:79], v140, s[36:39], null offen offset:12416 ; c405c07c 4080484c 0030808c
	buffer_load_b128 v[80:83], v140, s[36:39], null offen offset:12432 ; c405c07c 40804850 0030908c
(invalid instruction)                                        ; cc1b00a7
	v_subrev_f32_e32 v0, v167, v27                              ; 0a0037a7
(invalid instruction)                                        ; cc1b00a9
	v_subrev_f32_e32 v0, v169, v27                              ; 0a0037a9
(invalid instruction)                                        ; cc1b00a8
	v_subrev_f32_e32 v0, v168, v27                              ; 0a0037a8
(invalid instruction)                                        ; cc1c00ab
	v_subrev_f32_e32 v0, v171, v34                              ; 0a0045ab
(invalid instruction)                                        ; cc1c00aa
	v_subrev_f32_e32 v0, v170, v34                              ; 0a0045aa
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v34                              ; 0a0045ac
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v175, s26, v4, v102                         ; cc2100af 059a081a
	v_fma_mixhi_f16 v175, s26, v5, v103                         ; cc2200af 059e0a1a
(invalid instruction)                                        ; cc1c00ad
	v_subrev_f32_e32 v0, v173, v34                              ; 0a0045ad
	v_fma_mixlo_f16 v174, s26, v2, v100                         ; cc2100ae 0592041a
	v_fma_mixhi_f16 v174, s26, v3, v101                         ; cc2200ae 0596061a
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v176, s26, v6, v104                         ; cc2100b0 05a20c1a
	v_fma_mixhi_f16 v176, s26, v7, v105                         ; cc2200b0 05a60e1a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[4:7], v140, s[36:39], null offen offset:12480 ; c405c07c 40804804 0030c08c
	buffer_load_b128 v[84:87], v140, s[36:39], null offen offset:12496 ; c405c07c 40804854 0030d08c
	v_fma_mixlo_f16 v177, s26, v8, v106                         ; cc2100b1 05aa101a
	v_fma_mixhi_f16 v177, s26, v9, v107                         ; cc2200b1 05ae121a
(invalid instruction)                                        ; cc1b00ab
	v_subrev_f32_e32 v0, v171, v27                              ; 0a0037ab
(invalid instruction)                                        ; cc1b00aa
	v_subrev_f32_e32 v0, v170, v27                              ; 0a0037aa
(invalid instruction)                                        ; cc1b00ac
	v_subrev_f32_e32 v0, v172, v27                              ; 0a0037ac
	v_add3_u32 v18, v18, s9, v69                                ; d6550012 05141312
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v34                              ; 0a0045af
(invalid instruction)                                        ; cc1b00ad
	v_subrev_f32_e32 v0, v173, v27                              ; 0a0037ad
(invalid instruction)                                        ; cc1c00ae
	v_subrev_f32_e32 v0, v174, v34                              ; 0a0045ae
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v34                              ; 0a0045b0
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v178, s26, v56, v108                        ; cc2100b2 05b2701a
	v_fma_mixhi_f16 v178, s26, v57, v109                        ; cc2200b2 05b6721a
	v_fma_mixlo_f16 v179, s26, v58, v110                        ; cc2100b3 05ba741a
	v_fma_mixhi_f16 v179, s26, v59, v111                        ; cc2200b3 05be761a
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v34                              ; 0a0045b1
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v180, s26, v60, v112                        ; cc2100b4 05c2781a
	v_fma_mixhi_f16 v180, s26, v61, v113                        ; cc2200b4 05c67a1a
	v_lshlrev_b32_e32 v18, 2, v18                               ; 30242482
(invalid instruction)                                        ; cc1b00af
	v_subrev_f32_e32 v0, v175, v27                              ; 0a0037af
	v_fma_mixlo_f16 v181, s26, v62, v114                        ; cc2100b5 05ca7c1a
(invalid instruction)                                        ; cc1b00ae
	v_subrev_f32_e32 v0, v174, v27                              ; 0a0037ae
	v_fma_mixhi_f16 v181, s26, v63, v115                        ; cc2200b5 05ce7e1a
(invalid instruction)                                        ; cc1b00b0
	v_subrev_f32_e32 v0, v176, v27                              ; 0a0037b0
	v_lshl_add_u32 v166, v166, 5, s35                           ; d64600a6 008d0ba6
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v34                              ; 0a0045b2
	v_lshl_add_u32 v170, v170, 5, s35                           ; d64600aa 008d0baa
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v34                              ; 0a0045b3
(invalid instruction)                                        ; cc1b00b1
	v_subrev_f32_e32 v0, v177, v27                              ; 0a0037b1
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v34                              ; 0a0045b4
	v_lshl_add_u32 v167, v167, 5, s35                           ; d64600a7 008d0ba7
	v_lshl_add_u32 v171, v171, 5, s35                           ; d64600ab 008d0bab
	v_lshl_add_u32 v174, v174, 5, s35                           ; d64600ae 008d0bae
	v_lshl_add_u32 v175, v175, 5, s35                           ; d64600af 008d0baf
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v34                              ; 0a0045b5
(invalid instruction)                                        ; cc1b00b2
	v_subrev_f32_e32 v0, v178, v27                              ; 0a0037b2
	v_lshl_add_u32 v168, v168, 5, s35                           ; d64600a8 008d0ba8
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[166:167], v[170:171]            ; 1a0355a6
(invalid instruction)                                        ; cc1b00b3
	v_subrev_f32_e32 v0, v179, v27                              ; 0a0037b3
	v_lshl_add_u32 v172, v172, 5, s35                           ; d64600ac 008d0bac
(invalid instruction)                                        ; cc1b00b4
	v_subrev_f32_e32 v0, v180, v27                              ; 0a0037b4
	v_lshl_add_u32 v176, v176, 5, s35                           ; d64600b0 008d0bb0
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[167:168], v[171:172]            ; 1a0357a7
	v_lshl_add_u32 v169, v169, 5, s35                           ; d64600a9 008d0ba9
(invalid instruction)                                        ; cc1b00b5
	v_subrev_f32_e32 v0, v181, v27                              ; 0a0037b5
	v_lshl_add_u32 v173, v173, 5, s35                           ; d64600ad 008d0bad
	v_lshl_add_u32 v178, v178, 5, s35                           ; d64600b2 008d0bb2
	v_lshl_add_u32 v177, v177, 5, s35                           ; d64600b1 008d0bb1
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[174:175]            ; 1a035db6
	v_lshl_add_u32 v179, v179, 5, s35                           ; d64600b3 008d0bb3
(invalid instruction)                                        ; cc0f00b8
	v_min_num_f64_e32 v[1:2], v[168:169], v[172:173]            ; 1a0359a8
	v_lshl_add_u32 v180, v180, 5, s35                           ; d64600b4 008d0bb4
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[175:176]            ; 1a035fb7
	v_lshl_add_u32 v181, v181, 5, s35                           ; d64600b5 008d0bb5
(invalid instruction)                                        ; cc0f00b9
	v_min_num_f64_e32 v[1:2], v[169:170], v[173:174]            ; 1a035ba9
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[178:179]            ; 1a0365b6
(invalid instruction)                                        ; cc0f00b8
	v_min_num_f64_e32 v[1:2], v[184:185], v[176:177]            ; 1a0361b8
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[179:180]            ; 1a0367b7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f00b9
	v_min_num_f64_e32 v[1:2], v[185:186], v[177:178]            ; 1a0363b9
(invalid instruction)                                        ; cc0f00b8
	v_min_num_f64_e32 v[1:2], v[184:185], v[180:181]            ; 1a0369b8
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[183:184]            ; 1a036fb6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f00b9
	v_min_num_f64_e32 v[1:2], v[185:186], v[181:182]            ; 1a036bb9
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[184:185]            ; 1a0371b6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[185:186]            ; 1a0373b6
	v_permlanex16_b32 v186, v182, s22, s23 op_sel:[1,1]         ; d65c18ba 005c2db6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[186:187]            ; 1a0375b6
(invalid instruction)                                        ; d53210bb
	v_cndmask_b32_e32 v1, v182, v182, vcc_lo                    ; 02036db6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53100bb
	v_cndmask_b32_e32 v1, s40, v187, vcc_lo                     ; 02037628
(invalid instruction)                                        ; d58b00bc
	v_cndmask_b32_e32 v0, v187, v128, vcc_lo                    ; 020101bb
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v188, v188                                    ; 7f7855bc
	v_fma_mix_f32 v190, v167, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000be 8a0379a7
	v_fma_mix_f32 v167, v167, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a7 8a0379a7
	v_fma_mix_f32 v189, v166, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bd 8a0379a6
	v_fma_mix_f32 v166, v166, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a6 8a0379a6
	v_fma_mix_f32 v191, v168, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379a8
	v_fma_mix_f32 v168, v168, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a8 8a0379a8
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d3
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v189, v166, vcc_lo                    ; 02034dbd
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v190, v167, vcc_lo                    ; 02034fbe
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v191, v168, vcc_lo                    ; 020351bf
	v_fma_mix_f32 v191, v169, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379a9
	v_fma_mix_f32 v169, v169, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a0379a9
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v191, v169, vcc_lo                    ; 020353bf
	v_fma_mix_f32 v191, v170, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379aa
	v_fma_mix_f32 v170, v170, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008aa 8a0379aa
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v191, v170, vcc_lo                    ; 020355bf
	v_fma_mix_f32 v191, v171, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379ab
	v_fma_mix_f32 v171, v171, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ab 8a0379ab
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v191, v171, vcc_lo                    ; 020357bf
	v_fma_mix_f32 v191, v172, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379ac
	v_fma_mix_f32 v172, v172, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ac 8a0379ac
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v191, v172, vcc_lo                    ; 020359bf
	v_fma_mix_f32 v191, v173, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379ad
	v_fma_mix_f32 v173, v173, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ad 8a0379ad
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v191, v173, vcc_lo                    ; 02035bbf
	v_fma_mix_f32 v191, v174, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379ae
	v_fma_mix_f32 v174, v174, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ae 8a0379ae
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v191, v174, vcc_lo                    ; 02035dbf
	v_fma_mix_f32 v191, v175, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379af
	v_fma_mix_f32 v175, v175, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a0379af
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v191, v175, vcc_lo                    ; 02035fbf
	v_fma_mix_f32 v191, v176, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379b0
	v_fma_mix_f32 v176, v176, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a0379b0
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v191, v176, vcc_lo                    ; 020361bf
	v_fma_mix_f32 v191, v177, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379b1
	v_fma_mix_f32 v177, v177, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a0379b1
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[54:55], v[30:31], 0 ; cc464060 1a023d36
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[66:67], v[30:31], 0 ; cc464068 1a023d42
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[30:31], 0 ; cc464080 1a023d1a
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v191, v177, vcc_lo                    ; 020363bf
	v_fma_mix_f32 v191, v178, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379b2
	v_fma_mix_f32 v178, v178, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a0379b2
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[44:45], v[30:31], 0 ; cc464098 1a023d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[64:65], v[34:35], v[96:103] ; cc464060 1d824540
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[34:35], v[104:111] ; cc464068 1da2452e
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v191, v178, vcc_lo                    ; 020365bf
	v_fma_mix_f32 v191, v179, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379b3
	v_fma_mix_f32 v179, v179, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a0379b3
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[0:1], v[34:35], v[128:135] ; cc464080 1e024500
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[34:35], v[152:159] ; cc464098 1e624528
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v0, s26, v98, v118                          ; cc210000 05dac41a
	v_fma_mixhi_f16 v0, s26, v99, v119                          ; cc220000 05dec61a
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v191, v179, vcc_lo                    ; 020367bf
	v_fma_mix_f32 v191, v180, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379b4
	v_fma_mix_f32 v180, v180, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a0379b4
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v1, s26, v100, v120                         ; cc210001 05e2c81a
	v_fma_mixhi_f16 v1, s26, v101, v121                         ; cc220001 05e6ca1a
	v_fma_mixlo_f16 v26, s26, v102, v122                        ; cc21001a 05eacc1a
	v_fma_mixhi_f16 v26, s26, v103, v123                        ; cc22001a 05eece1a
(invalid instruction)                                        ; cc1c0000
	v_subrev_f32_e32 v0, v0, v34                                ; 0a004500
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v191, v180, vcc_lo                    ; 020369bf
	v_fma_mix_f32 v191, v181, v188, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0379b5
	v_fma_mix_f32 v181, v181, v188, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a0379b5
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v27, s26, v104, v48                         ; cc21001b 04c2d01a
	v_fma_mixhi_f16 v27, s26, v105, v49                         ; cc22001b 04c6d21a
	v_fma_mixlo_f16 v30, s26, v106, v50                         ; cc21001e 04cad41a
(invalid instruction)                                        ; cc1c0001
	v_subrev_f32_e32 v0, v1, v34                                ; 0a004501
	v_fma_mixhi_f16 v30, s26, v107, v51                         ; cc22001e 04ced61a
(invalid instruction)                                        ; cc1c001a
	v_subrev_f32_e32 v0, v26, v34                               ; 0a00451a
(invalid instruction)                                        ; cc1b0000
	v_subrev_f32_e32 v0, v0, v27                                ; 0a003700
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v31, s26, v108, v92                         ; cc21001f 0572d81a
	v_fma_mixhi_f16 v31, s26, v109, v93                         ; cc22001f 0576da1a
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v191, v181, vcc_lo                    ; 02036bbf
	v_fma_mixlo_f16 v191, s26, v96, v116                        ; cc2100bf 05d2c01a
	v_fma_mixhi_f16 v191, s26, v97, v117                        ; cc2200bf 05d6c21a
	v_fma_mixlo_f16 v34, s26, v110, v94                         ; cc210022 057adc1a
(invalid instruction)                                        ; cc1c001b
	v_subrev_f32_e32 v0, v27, v34                               ; 0a00451b
	v_fma_mixhi_f16 v34, s26, v111, v95                         ; cc220022 057ede1a
(invalid instruction)                                        ; cc1b0001
	v_subrev_f32_e32 v0, v1, v27                                ; 0a003701
(invalid instruction)                                        ; cc1c001e
	v_subrev_f32_e32 v0, v30, v34                               ; 0a00451e
(invalid instruction)                                        ; cc1b001a
	v_subrev_f32_e32 v0, v26, v27                               ; 0a00371a
(invalid instruction)                                        ; cc1c001f
	v_subrev_f32_e32 v0, v31, v34                               ; 0a00451f
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v34                              ; 0a0045bf
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v35, s26, v128, v76                         ; cc210023 0533001a
	v_fma_mixhi_f16 v35, s26, v129, v77                         ; cc220023 0537021a
	v_fma_mixlo_f16 v40, s26, v130, v78                         ; cc210028 053b041a
	v_fma_mixhi_f16 v40, s26, v131, v79                         ; cc220028 053f061a
(invalid instruction)                                        ; cc1b001b
	v_subrev_f32_e32 v0, v27, v27                               ; 0a00371b
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v41, s26, v132, v80                         ; cc210029 0543081a
	v_fma_mixhi_f16 v41, s26, v133, v81                         ; cc220029 05470a1a
(invalid instruction)                                        ; cc1c0022
	v_subrev_f32_e32 v0, v34, v34                               ; 0a004522
(invalid instruction)                                        ; cc1b001e
	v_subrev_f32_e32 v0, v30, v27                               ; 0a00371e
	v_fma_mixlo_f16 v44, s26, v134, v82                         ; cc21002c 054b0c1a
(invalid instruction)                                        ; cc1b001f
	v_subrev_f32_e32 v0, v31, v27                               ; 0a00371f
	v_fma_mixhi_f16 v44, s26, v135, v83                         ; cc22002c 054f0e1a
	buffer_load_b128 v[48:51], v18, s[36:39], null offen        ; c405c07c 40804830 00000012
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v27                              ; 0a0037bf
(invalid instruction)                                        ; cc1c0023
	v_subrev_f32_e32 v0, v35, v34                               ; 0a004523
(invalid instruction)                                        ; cc1c0028
	v_subrev_f32_e32 v0, v40, v34                               ; 0a004528
(invalid instruction)                                        ; cc1c0029
	v_subrev_f32_e32 v0, v41, v34                               ; 0a004529
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v45, s26, v152, v4                          ; cc21002d 0413301a
(invalid instruction)                                        ; cc1b0022
	v_subrev_f32_e32 v0, v34, v27                               ; 0a003722
	v_fma_mixhi_f16 v45, s26, v153, v5                          ; cc22002d 0417321a
	v_fma_mixlo_f16 v46, s26, v154, v6                          ; cc21002e 041b341a
	v_fma_mixhi_f16 v46, s26, v155, v7                          ; cc22002e 041f361a
	buffer_load_b128 v[4:7], v18, s[36:39], null offen offset:16 ; c405c07c 40804804 00001012
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v47, s26, v156, v84                         ; cc21002f 0553381a
(invalid instruction)                                        ; cc1c002c
	v_subrev_f32_e32 v0, v44, v34                               ; 0a00452c
	v_fma_mixhi_f16 v47, s26, v157, v85                         ; cc22002f 05573a1a
(invalid instruction)                                        ; cc1b0023
	v_subrev_f32_e32 v0, v35, v27                               ; 0a003723
(invalid instruction)                                        ; cc1b0028
	v_subrev_f32_e32 v0, v40, v27                               ; 0a003728
	v_fma_mixlo_f16 v54, s26, v158, v86                         ; cc210036 055b3c1a
(invalid instruction)                                        ; cc1b0029
	v_subrev_f32_e32 v0, v41, v27                               ; 0a003729
	v_fma_mixhi_f16 v54, s26, v159, v87                         ; cc220036 055f3e1a
	v_lshl_add_u32 v191, v191, 5, s35                           ; d64600bf 008d0bbf
(invalid instruction)                                        ; cc1c002d
	v_subrev_f32_e32 v0, v45, v34                               ; 0a00452d
	v_lshl_add_u32 v27, v27, 5, s35                             ; d646001b 008d0b1b
(invalid instruction)                                        ; cc1c002e
	v_subrev_f32_e32 v0, v46, v34                               ; 0a00452e
(invalid instruction)                                        ; cc1b002c
	v_subrev_f32_e32 v0, v44, v27                               ; 0a00372c
(invalid instruction)                                        ; cc1c002f
	v_subrev_f32_e32 v0, v47, v34                               ; 0a00452f
	v_lshl_add_u32 v0, v0, 5, s35                               ; d6460000 008d0b00
	v_lshl_add_u32 v35, v35, 5, s35                             ; d6460023 008d0b23
	v_lshl_add_u32 v30, v30, 5, s35                             ; d646001e 008d0b1e
	v_lshl_add_u32 v40, v40, 5, s35                             ; d6460028 008d0b28
(invalid instruction)                                        ; cc1c0036
	v_subrev_f32_e32 v0, v54, v34                               ; 0a004536
(invalid instruction)                                        ; cc1b002d
	v_subrev_f32_e32 v0, v45, v27                               ; 0a00372d
(invalid instruction)                                        ; cc0f0037
	v_min_num_f64_e32 v[1:2], v[191:192], v[27:28]              ; 1a0237bf
	v_lshl_add_u32 v1, v1, 5, s35                               ; d6460001 008d0b01
(invalid instruction)                                        ; cc1b002e
	v_subrev_f32_e32 v0, v46, v27                               ; 0a00372e
	v_lshl_add_u32 v31, v31, 5, s35                             ; d646001f 008d0b1f
	v_lshl_add_u32 v41, v41, 5, s35                             ; d6460029 008d0b29
(invalid instruction)                                        ; cc1b002f
	v_subrev_f32_e32 v0, v47, v27                               ; 0a00372f
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[0:1], v[30:31]                  ; 1a023d00
	v_lshl_add_u32 v26, v26, 5, s35                             ; d646001a 008d0b1a
	v_lshl_add_u32 v34, v34, 5, s35                             ; d6460022 008d0b22
(invalid instruction)                                        ; cc1b0036
	v_subrev_f32_e32 v0, v54, v27                               ; 0a003736
	v_lshl_add_u32 v45, v45, 5, s35                             ; d646002d 008d0b2d
	v_lshl_add_u32 v44, v44, 5, s35                             ; d646002c 008d0b2c
(invalid instruction)                                        ; cc0f0037
	v_min_num_f64_e32 v[1:2], v[55:56], v[35:36]                ; 1a024737
	v_lshl_add_u32 v46, v46, 5, s35                             ; d646002e 008d0b2e
(invalid instruction)                                        ; cc0f003d
	v_min_num_f64_e32 v[1:2], v[1:2], v[31:32]                  ; 1a023f01
	v_lshl_add_u32 v47, v47, 5, s35                             ; d646002f 008d0b2f
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[60:61], v[40:41]                ; 1a02513c
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[26:27], v[34:35]                ; 1a02451a
	v_lshl_add_u32 v54, v54, 5, s35                             ; d6460036 008d0b36
(invalid instruction)                                        ; cc0f0037
	v_min_num_f64_e32 v[1:2], v[55:56], v[45:46]                ; 1a025b37
(invalid instruction)                                        ; cc0f003d
	v_min_num_f64_e32 v[1:2], v[61:62], v[41:42]                ; 1a02533d
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[60:61], v[46:47]                ; 1a025d3c
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[44:45]                ; 1a02593e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
(invalid instruction)                                        ; cc0f003d
	v_min_num_f64_e32 v[1:2], v[61:62], v[47:48]                ; 1a025f3d
(invalid instruction)                                        ; cc0f0037
	v_min_num_f64_e32 v[1:2], v[55:56], v[60:61]                ; 1a027937
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[54:55]                ; 1a026d3e
(invalid instruction)                                        ; cc0f0037
	v_min_num_f64_e32 v[1:2], v[55:56], v[61:62]                ; 1a027b37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0037
	v_min_num_f64_e32 v[1:2], v[55:56], v[62:63]                ; 1a027d37
	v_permlanex16_b32 v63, v55, s22, s23 op_sel:[1,1]           ; d65c183f 005c2d37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0037
	v_min_num_f64_e32 v[1:2], v[55:56], v[63:64]                ; 1a027f37
	v_add_f16_e32 v64, v55, v183/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64816f37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v64, s40, v64                             ; 62808028
	v_cvt_f32_f16_e32 v65, v64                                  ; 7e821740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v65, v65                                      ; 7e825541
	v_fma_mix_f32 v66, v191, v65, neg(0) op_sel_hi:[1,0,0]      ; cc200042 8a0283bf
	v_fma_mix_f32 v67, v0, v65, neg(0) op_sel_hi:[1,0,0]        ; cc200043 8a028300
	v_fma_mix_f32 v76, v30, v65, neg(0) op_sel_hi:[1,0,0]       ; cc20004c 8a02831e
	v_fma_mix_f32 v0, v0, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200800 8a028300
	v_fma_mix_f32 v69, v1, v65, neg(0) op_sel_hi:[1,0,0]        ; cc200045 8a028301
	v_fma_mix_f32 v1, v1, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200801 8a028301
	v_fma_mix_f32 v75, v27, v65, neg(0) op_sel_hi:[1,0,0]       ; cc20004b 8a02831b
	v_fma_mix_f32 v27, v27, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081b 8a02831b
	v_fma_mix_f32 v191, v191, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a0283bf
	v_fma_mix_f32 v30, v30, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081e 8a02831e
	v_fma_mix_f32 v77, v31, v65, neg(0) op_sel_hi:[1,0,0]       ; cc20004d 8a02831f
	v_fma_mix_f32 v31, v31, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081f 8a02831f
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v69, v1, vcc_lo                       ; 02020345
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v66, v191, vcc_lo                     ; 02037f42
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v67, v0, vcc_lo                       ; 02020143
	v_fma_mix_f32 v74, v26, v65, neg(0) op_sel_hi:[1,0,0]       ; cc20004a 8a02831a
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v75, v27, vcc_lo                      ; 0202374b
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v76, v30, vcc_lo                      ; 02023d4c
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v77, v31, vcc_lo                      ; 02023f4d
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[76:79], v18, s[36:39], null offen offset:64 ; c405c07c 4080484c 00004012
	buffer_load_b128 v[84:87], v18, s[36:39], null offen offset:80 ; c405c07c 40804854 00005012
	v_fma_mix_f32 v26, v26, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081a 8a02831a
	v_fma_mix_f32 v80, v34, v65, neg(0) op_sel_hi:[1,0,0]       ; cc200050 8a028322
	v_fma_mix_f32 v34, v34, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200822 8a028322
	v_fma_mix_f32 v81, v35, v65, neg(0) op_sel_hi:[1,0,0]       ; cc200051 8a028323
	v_fma_mix_f32 v35, v35, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200823 8a028323
	v_fma_mix_f32 v82, v40, v65, neg(0) op_sel_hi:[1,0,0]       ; cc200052 8a028328
	v_fma_mix_f32 v40, v40, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200828 8a028328
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	v_fma_mix_f32 v83, v41, v65, neg(0) op_sel_hi:[1,0,0]       ; cc200053 8a028329
	v_fma_mix_f32 v41, v41, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200829 8a028329
	v_fma_mix_f32 v88, v44, v65, neg(0) op_sel_hi:[1,0,0]       ; cc200058 8a02832c
	v_fma_mix_f32 v44, v44, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082c 8a02832c
	v_fma_mix_f32 v89, v45, v65, neg(0) op_sel_hi:[1,0,0]       ; cc200059 8a02832d
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v74, v26, vcc_lo                      ; 0202354a
	v_fma_mix_f32 v45, v45, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082d 8a02832d
	v_fma_mix_f32 v92, v46, v65, neg(0) op_sel_hi:[1,0,0]       ; cc20005c 8a02832e
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v80, v34, vcc_lo                      ; 02024550
	v_fma_mix_f32 v46, v46, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082e 8a02832e
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v81, v35, vcc_lo                      ; 02024751
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v42, v42, s6, v43                                ; d655002a 04ac0d2a
	v_fma_mix_f32 v93, v47, v65, neg(0) op_sel_hi:[1,0,0]       ; cc20005d 8a02832f
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v82, v40, vcc_lo                      ; 02025152
	v_fma_mix_f32 v47, v47, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082f 8a02832f
	v_fma_mix_f32 v94, v54, v65, neg(0) op_sel_hi:[1,0,0]       ; cc20005e 8a028336
	v_fma_mix_f32 v54, v54, v65, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200836 8a028336
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v83, v41, vcc_lo                      ; 02025353
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v88, v44, vcc_lo                      ; 02025958
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[10:11], v[12:13], 0 ; cc464060 1a02190a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[20:21], 0 ; cc464068 1a02290a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[2:3], 0 ; cc464070 1a02050a
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v89, v45, vcc_lo                      ; 02025b59
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[60:61], 0 ; cc464078 1a02790a
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v92, v46, vcc_lo                      ; 02025d5c
	v_lshlrev_b32_e32 v42, 2, v42                               ; 30545482
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v93, v47, vcc_lo                      ; 02025f5d
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v94, v54, vcc_lo                      ; 02026d5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[14:15], v[96:103] ; cc464060 1d821d18
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[52:53], v[104:111] ; cc464068 1da26918
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[8:9], v[112:119] ; cc464070 1dc21118
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[0:1], v[120:127] ; cc464078 1de20118
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[142:143], v[28:29], v[96:103] ; cc464060 1d82398e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[142:143], v[70:71], v[104:111] ; cc464068 1da28d8e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[142:143], v[56:57], v[112:119] ; cc464070 1dc2718e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[142:143], v[26:27], v[120:127] ; cc464078 1de2358e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[146:147], v[16:17], v[96:103] ; cc464060 1d822192
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[146:147], v[72:73], v[104:111] ; cc464068 1da29192
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[146:147], v[58:59], v[112:119] ; cc464070 1dc27592
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[146:147], v[30:31], v[120:127] ; cc464078 1de23d92
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[22:23], v[12:13], 0 ; cc464060 1a021916
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[20:21], 0 ; cc464068 1a022916
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[2:3], 0 ; cc464070 1a020516
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[60:61], 0 ; cc464078 1a027916
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[90:91], v[0:1], v[120:127] ; cc464078 1de2015a
	buffer_load_b128 v[0:3], v42, s[28:31], null offen          ; c405c07c 40803800 0000002a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[90:91], v[14:15], v[96:103] ; cc464060 1d821d5a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[90:91], v[52:53], v[104:111] ; cc464068 1da2695a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[90:91], v[8:9], v[112:119] ; cc464070 1dc2115a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[144:145], v[26:27], v[120:127] ; cc464078 1de23590
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[144:145], v[28:29], v[96:103] ; cc464060 1d823990
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[144:145], v[70:71], v[104:111] ; cc464068 1da28d90
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[144:145], v[56:57], v[112:119] ; cc464070 1dc27190
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[148:149], v[30:31], v[120:127] ; cc464078 1de23d94
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[16:17], v[96:103] ; cc464060 1d822194
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[148:149], v[72:73], v[104:111] ; cc464068 1da29194
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[148:149], v[58:59], v[112:119] ; cc464070 1dc27594
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	ds_store_2addr_b64 v37, v[10:11], v[8:9] offset1:32         ; d9382000 00080a25
	buffer_load_b128 v[12:15], v42, s[28:31], null offen offset:512 ; c405c07c 4080380c 0002002a
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	ds_store_2addr_b64 v19, v[24:25], v[8:9] offset1:32         ; d9382000 00081813
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	ds_store_2addr_b64 v38, v[34:35], v[8:9] offset1:32         ; d9382000 00082226
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	ds_store_2addr_b64 v68, v[40:41], v[8:9] offset1:32         ; d9382000 00082844
	buffer_load_b128 v[8:11], v42, s[28:31], null offen offset:1024 ; c405c07c 40803808 0004002a
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[16:17], v32 offset:16384                      ; d9d84000 10000020
	ds_load_b64 v[18:19], v32 offset:20480                      ; d9d85000 12000020
	ds_load_b64 v[20:21], v32 offset:24576                      ; d9d86000 14000020
	buffer_load_b128 v[28:31], v42, s[28:31], null offen offset:1536 ; c405c07c 4080381c 0006002a
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[22:23], v16                          ; 7e2cdd10
	s_wait_loadcnt 0x7                                          ; bfc00007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v25, v23, v49 :: v_dual_mul_f32 v24, v22, v48 ; c8c66317 19186116
	v_cvt_pk_f32_fp8_e32 v[22:23], v144                         ; 7e2cdd90
	v_dual_mul_f32 v27, v23, v51 :: v_dual_mul_f32 v26, v22, v50 ; c8c66717 1b1a6516
	v_cvt_pk_f32_fp8_e32 v[22:23], v17                          ; 7e2cdd11
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v61, v23, v5 :: v_dual_mul_f32 v60, v22, v4  ; c8c60b17 3d3c0916
	ds_load_b64 v[22:23], v32 offset:28672                      ; d9d87000 16000020
	buffer_load_b128 v[44:47], v42, s[28:31], null offen offset:2048 ; c405c07c 4080382c 0008002a
	ds_load_b64 v[34:35], v32 offset:16640                      ; d9d84100 22000020
	buffer_load_b128 v[52:55], v42, s[28:31], null offen offset:2560 ; c405c07c 40803834 000a002a
	v_cvt_pk_f32_fp8_e32 v[16:17], v145                         ; 7e20dd91
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v63, v17, v7 :: v_dual_mul_f32 v62, v16, v6  ; c8c60f11 3f3e0d10
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[16:17], v18                          ; 7e20dd12
	v_dual_mul_f32 v65, v17, v49 :: v_dual_mul_f32 v64, v16, v48 ; c8c66311 41406110
	v_cvt_pk_f32_fp8_e32 v[16:17], v146                         ; 7e20dd92
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v67, v17, v51 :: v_dual_mul_f32 v66, v16, v50 ; c8c66711 43426510
	v_cvt_pk_f32_fp8_e32 v[16:17], v19                          ; 7e20dd13
	v_cvt_pk_f32_fp8_e32 v[18:19], v147                         ; 7e24dd93
	v_dual_mul_f32 v69, v17, v5 :: v_dual_mul_f32 v68, v16, v4  ; c8c60b11 45440910
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[16:17], v20                          ; 7e20dd14
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v89, v17, v49 :: v_dual_mul_f32 v88, v16, v48 ; c8c66311 59586110
	v_cvt_pk_f32_fp8_e32 v[16:17], v148                         ; 7e20dd94
	v_dual_mul_f32 v91, v17, v51 :: v_dual_mul_f32 v90, v16, v50 ; c8c66711 5b5a6510
	v_cvt_pk_f32_fp8_e32 v[16:17], v21                          ; 7e20dd15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v71, v19, v7 :: v_dual_mul_f32 v92, v16, v4  ; c8c60f13 475c0910
	v_dual_mul_f32 v93, v17, v5 :: v_dual_mul_f32 v70, v18, v6  ; c8c60b11 5d460d12
	v_cvt_pk_f32_fp8_e32 v[16:17], v149                         ; 7e20dd95
	v_dual_mul_f32 v95, v17, v7 :: v_dual_mul_f32 v94, v16, v6  ; c8c60f11 5f5e0d10
	buffer_load_b128 v[16:19], v42, s[28:31], null offen offset:3072 ; c405c07c 40803810 000c002a
	ds_load_b64 v[40:41], v32 offset:20736                      ; d9d85100 28000020
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[20:21], v22                          ; 7e28dd16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v97, v21, v49                                 ; 10c26315
	v_mul_f32_e32 v96, v20, v48                                 ; 10c06114
	v_cvt_pk_f32_fp8_e32 v[20:21], v150                         ; 7e28dd96
	v_dual_mul_f32 v99, v21, v51 :: v_dual_mul_f32 v98, v20, v50 ; c8c66715 63626514
	v_cvt_pk_f32_fp8_e32 v[20:21], v23                          ; 7e28dd17
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v101, v21, v5 :: v_dual_mul_f32 v100, v20, v4 ; c8c60b15 65640914
	v_cvt_pk_f32_fp8_e32 v[4:5], v151                           ; 7e08dd97
	buffer_load_b128 v[20:23], v42, s[28:31], null offen offset:3584 ; c405c07c 40803814 000e002a
	v_dual_mul_f32 v103, v5, v7 :: v_dual_mul_f32 v102, v4, v6  ; c8c60f05 67660d04
	ds_load_b64 v[6:7], v32 offset:24832                        ; d9d86100 06000020
	buffer_load_b128 v[48:51], v42, s[28:31], null offen offset:4096 ; c405c07c 40803830 0010002a
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[4:5], v34                            ; 7e08dd22
	s_wait_loadcnt 0xa                                          ; bfc0000a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v105, v5, v77 :: v_dual_mul_f32 v104, v4, v76 ; c8c69b05 69689904
	v_cvt_pk_f32_fp8_e32 v[4:5], v162                           ; 7e08dda2
	v_dual_mul_f32 v107, v5, v79 :: v_dual_mul_f32 v106, v4, v78 ; c8c69f05 6b6a9d04
	v_cvt_pk_f32_fp8_e32 v[4:5], v35                            ; 7e08dd23
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v109, v5, v85 :: v_dual_mul_f32 v108, v4, v84 ; c8c6ab05 6d6ca904
	v_cvt_pk_f32_fp8_e32 v[4:5], v163                           ; 7e08dda3
	ds_load_b64 v[34:35], v32 offset:28928                      ; d9d87100 22000020
	buffer_load_b128 v[56:59], v42, s[28:31], null offen offset:4608 ; c405c07c 40803838 0012002a
	v_dual_mul_f32 v111, v5, v87 :: v_dual_mul_f32 v110, v4, v86 ; c8c6af05 6f6ead04
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[4:5], v40                            ; 7e08dd28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v5, v77 :: v_dual_mul_f32 v112, v4, v76 ; c8c69b05 71709904
	v_cvt_pk_f32_fp8_e32 v[4:5], v168                           ; 7e08dda8
	v_dual_mul_f32 v115, v5, v79 :: v_dual_mul_f32 v114, v4, v78 ; c8c69f05 73729d04
	v_cvt_pk_f32_fp8_e32 v[4:5], v41                            ; 7e08dd29
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v117, v5, v85 :: v_dual_mul_f32 v116, v4, v84 ; c8c6ab05 7574a904
	v_cvt_pk_f32_fp8_e32 v[4:5], v169                           ; 7e08dda9
	ds_load_b64 v[40:41], v33                                   ; d9d80000 28000021
	ds_load_b64 v[72:73], v33 offset:4096                       ; d9d81000 48000021
	buffer_load_b128 v[80:83], v42, s[28:31], null offen offset:5120 ; c405c07c 40803850 0014002a
	ds_load_b64 v[74:75], v33 offset:8192                       ; d9d82000 4a000021
	ds_load_b64 v[120:121], v33 offset:12288                    ; d9d83000 78000021
	buffer_load_b128 v[124:127], v42, s[28:31], null offen offset:5632 ; c405c07c 4080387c 0016002a
	v_dual_mul_f32 v119, v5, v87 :: v_dual_mul_f32 v118, v4, v86 ; c8c6af05 7776ad04
	s_wait_dscnt 0x5                                            ; bfc60005
	v_cvt_pk_f32_fp8_e32 v[4:5], v6                             ; 7e08dd06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v129, v5, v77 :: v_dual_mul_f32 v128, v4, v76 ; c8c69b05 81809904
	v_cvt_pk_f32_fp8_e32 v[4:5], v134                           ; 7e08dd86
	v_dual_mul_f32 v131, v5, v79 :: v_dual_mul_f32 v130, v4, v78 ; c8c69f05 83829d04
	v_cvt_pk_f32_fp8_e32 v[4:5], v7                             ; 7e08dd07
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v133, v5, v85 :: v_dual_mul_f32 v132, v4, v84 ; c8c6ab05 8584a904
	v_cvt_pk_f32_fp8_e32 v[4:5], v135                           ; 7e08dd87
	ds_load_b64 v[6:7], v33 offset:256                          ; d9d80100 06000021
	ds_load_b64 v[122:123], v33 offset:4352                     ; d9d81100 7a000021
	ds_load_b64 v[136:137], v33 offset:8448                     ; d9d82100 88000021
	ds_load_b64 v[138:139], v33 offset:12544                    ; d9d83100 8a000021
	v_dual_mul_f32 v135, v5, v87 :: v_dual_mul_f32 v134, v4, v86 ; c8c6af05 8786ad04
	s_wait_dscnt 0x8                                            ; bfc60008
	v_cvt_pk_f32_fp8_e32 v[4:5], v34                            ; 7e08dd22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v144, v4, v76                                 ; 11209904
	v_mul_f32_e32 v145, v5, v77                                 ; 11229b05
	v_cvt_pk_f32_fp8_e32 v[4:5], v162                           ; 7e08dda2
	v_dual_mul_f32 v147, v5, v79 :: v_dual_mul_f32 v146, v4, v78 ; c8c69f05 93929d04
	buffer_load_b128 v[76:79], v42, s[28:31], null offen offset:6144 ; c405c07c 4080384c 0018002a
	v_cvt_pk_f32_fp8_e32 v[4:5], v35                            ; 7e08dd23
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v149, v5, v85 :: v_dual_mul_f32 v148, v4, v84 ; c8c6ab05 9594a904
	v_cvt_pk_f32_fp8_e32 v[4:5], v163                           ; 7e08dda3
	ds_load_b64 v[34:35], v33 offset:512                        ; d9d80200 22000021
	ds_load_b64 v[84:85], v33 offset:4608                       ; d9d81200 54000021
	ds_load_b64 v[142:143], v33 offset:8704                     ; d9d82200 8e000021
	ds_load_b64 v[150:151], v33 offset:12800                    ; d9d83200 96000021
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_dual_mov_b32 v155, v31 :: v_dual_mov_b32 v154, v30        ; ca10011f 9b9a011e
	v_dual_mov_b32 v31, v63 :: v_dual_mov_b32 v30, v62          ; ca10013f 1f1e013e
	v_dual_mov_b32 v153, v29 :: v_dual_mov_b32 v152, v28        ; ca10011d 9998011c
	v_dual_mov_b32 v29, v61 :: v_dual_mov_b32 v28, v60          ; ca10013d 1d1c013c
	buffer_load_b128 v[60:63], v42, s[28:31], null offen offset:6656 ; c405c07c 4080383c 001a002a
	v_dual_mul_f32 v159, v5, v87 :: v_dual_mul_f32 v158, v4, v86 ; c8c6af05 9f9ead04
	ds_load_b64 v[4:5], v33 offset:768                          ; d9d80300 04000021
	ds_load_b64 v[86:87], v33 offset:4864                       ; d9d81300 56000021
	ds_load_b64 v[156:157], v33 offset:8960                     ; d9d82300 9c000021
	ds_load_b64 v[160:161], v33 offset:13056                    ; d9d83300 a0000021
	buffer_load_b128 v[164:167], v42, s[28:31], null offen offset:7168 ; c405c07c 408038a4 001c002a
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[0:1], v[72:73], v[64:71] ; cc464040 1d029100
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[0:1], v[74:75], v[88:95] ; cc464058 1d629500
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[0:1], v[120:121], v[96:103] ; cc464060 1d82f100
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[2:3], v[40:41], v[104:111] ; cc464068 1da25102
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[0:1], v[40:41], v[24:31] ; cc464018 1c625100
	s_wait_dscnt 0x4                                            ; bfc60004
	v_dual_mov_b32 v1, v151 :: v_dual_mov_b32 v0, v150          ; ca100197 01000196
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[2:3], v[72:73], v[112:119] ; cc464070 1dc29102
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[2:3], v[74:75], v[128:135] ; cc464080 1e029502
	v_dual_mov_b32 v151, v159 :: v_dual_mov_b32 v150, v158      ; ca10019f 9796019e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[2:3], v[120:121], v[144:151] ; cc464090 1e42f102
	ds_load_b64 v[2:3], v33 offset:1024                         ; d9d80400 02000021
	ds_load_b64 v[40:41], v33 offset:5120                       ; d9d81400 28000021
	ds_load_b64 v[72:73], v33 offset:9216                       ; d9d82400 48000021
	ds_load_b64 v[74:75], v33 offset:13312                      ; d9d83400 4a000021
	buffer_load_b128 v[168:171], v42, s[28:31], null offen offset:7680 ; c405c07c 408038a8 001e002a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[12:13], v[122:123], v[64:71] ; cc464040 1d02f50c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[136:137], v[88:95] ; cc464058 1d63110c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[138:139], v[96:103] ; cc464060 1d83150c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[6:7], v[104:111] ; cc464068 1da20d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[12:13], v[6:7], v[24:31] ; cc464018 1c620d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[122:123], v[112:119] ; cc464070 1dc2f50e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[136:137], v[128:135] ; cc464080 1e03110e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[14:15], v[138:139], v[144:151] ; cc464090 1e43150e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[84:85], v[64:71] ; cc464040 1d02a908
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[142:143], v[88:95] ; cc464058 1d631d08
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[0:1], v[96:103] ; cc464060 1d820108
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[34:35], v[104:111] ; cc464068 1da2450a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[8:9], v[34:35], v[24:31] ; cc464018 1c624508
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[84:85], v[112:119] ; cc464070 1dc2a90a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[142:143], v[128:135] ; cc464080 1e031d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[10:11], v[0:1], v[144:151] ; cc464090 1e42010a
	ds_load_b64 v[6:7], v33 offset:1280                         ; d9d80500 06000021
	ds_load_b64 v[12:13], v33 offset:5376                       ; d9d81500 0c000021
	ds_load_b64 v[14:15], v33 offset:9472                       ; d9d82500 0e000021
	ds_load_b64 v[42:43], v33 offset:13568                      ; d9d83500 2a000021
	ds_load_b64 v[0:1], v33 offset:1536                         ; d9d80600 00000021
	ds_load_b64 v[8:9], v33 offset:5632                         ; d9d81600 08000021
	ds_load_b64 v[10:11], v33 offset:9728                       ; d9d82600 0a000021
	ds_load_b64 v[34:35], v33 offset:13824                      ; d9d83600 22000021
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[152:153], v[86:87], v[64:71] ; cc464040 1d02ad98
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[154:155], v[4:5], v[104:111] ; cc464068 1da2099a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[152:153], v[4:5], v[24:31] ; cc464018 1c620998
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[154:155], v[86:87], v[112:119] ; cc464070 1dc2ad9a
	ds_load_b64 v[4:5], v33 offset:1792                         ; d9d80700 04000021
	ds_load_b64 v[84:85], v33 offset:5888                       ; d9d81700 54000021
	ds_load_b64 v[86:87], v33 offset:9984                       ; d9d82700 56000021
	ds_load_b64 v[120:121], v33 offset:14080                    ; d9d83700 78000021
	s_wait_dscnt 0x11                                           ; bfc60011
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[152:153], v[156:157], v[88:95] ; cc464058 1d633998
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[152:153], v[160:161], v[96:103] ; cc464060 1d834198
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[154:155], v[156:157], v[128:135] ; cc464080 1e03399a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[154:155], v[160:161], v[144:151] ; cc464090 1e43419a
	s_wait_loadcnt_dscnt 0xb0e                                  ; bfc80b0e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[44:45], v[40:41], v[64:71] ; cc464040 1d02512c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[2:3], v[104:111] ; cc464068 1da2052e
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[44:45], v[2:3], v[24:31] ; cc464018 1c62052c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[40:41], v[112:119] ; cc464070 1dc2512e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[72:73], v[88:95] ; cc464058 1d62912c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[74:75], v[96:103] ; cc464060 1d82952c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[72:73], v[128:135] ; cc464080 1e02912e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[74:75], v[144:151] ; cc464090 1e42952e
	s_wait_loadcnt_dscnt 0xa0a                                  ; bfc80a0a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[52:53], v[12:13], v[64:71] ; cc464040 1d021934
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[54:55], v[6:7], v[104:111] ; cc464068 1da20d36
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[52:53], v[6:7], v[24:31] ; cc464018 1c620d34
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[12:13], v[112:119] ; cc464070 1dc21936
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[14:15], v[88:95] ; cc464058 1d621d34
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[42:43], v[96:103] ; cc464060 1d825534
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[14:15], v[128:135] ; cc464080 1e021d36
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[42:43], v[144:151] ; cc464090 1e425536
	ds_load_b64 v[2:3], v33 offset:2048                         ; d9d80800 02000021
	ds_load_b64 v[40:41], v33 offset:6144                       ; d9d81800 28000021
	ds_load_b64 v[44:45], v33 offset:10240                      ; d9d82800 2c000021
	ds_load_b64 v[46:47], v33 offset:14336                      ; d9d83800 2e000021
	ds_load_b64 v[6:7], v33 offset:2304                         ; d9d80900 06000021
	ds_load_b64 v[12:13], v33 offset:6400                       ; d9d81900 0c000021
	ds_load_b64 v[14:15], v33 offset:10496                      ; d9d82900 0e000021
	ds_load_b64 v[42:43], v33 offset:14592                      ; d9d83900 2a000021
	s_wait_loadcnt_dscnt 0x90e                                  ; bfc8090e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[16:17], v[8:9], v[64:71] ; cc464040 1d021110
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[16:17], v[0:1], v[24:31] ; cc464018 1c620110
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[0:1], v[104:111] ; cc464068 1da20112
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[8:9], v[112:119] ; cc464070 1dc21112
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[10:11], v[88:95] ; cc464058 1d621510
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[34:35], v[96:103] ; cc464060 1d824510
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[10:11], v[128:135] ; cc464080 1e021512
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[18:19], v[34:35], v[144:151] ; cc464090 1e424512
	s_wait_loadcnt_dscnt 0x80a                                  ; bfc8080a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[84:85], v[64:71] ; cc464040 1d02a914
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[20:21], v[4:5], v[24:31] ; cc464018 1c620914
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[4:5], v[104:111] ; cc464068 1da20916
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[84:85], v[112:119] ; cc464070 1dc2a916
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[86:87], v[88:95] ; cc464058 1d62ad14
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[120:121], v[96:103] ; cc464060 1d82f114
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[86:87], v[128:135] ; cc464080 1e02ad16
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[22:23], v[120:121], v[144:151] ; cc464090 1e42f116
	ds_load_b64 v[0:1], v33 offset:2560                         ; d9d80a00 00000021
	ds_load_b64 v[8:9], v33 offset:6656                         ; d9d81a00 08000021
	ds_load_b64 v[10:11], v33 offset:10752                      ; d9d82a00 0a000021
	ds_load_b64 v[16:17], v33 offset:14848                      ; d9d83a00 10000021
	ds_load_b64 v[4:5], v33 offset:2816                         ; d9d80b00 04000021
	ds_load_b64 v[18:19], v33 offset:6912                       ; d9d81b00 12000021
	ds_load_b64 v[20:21], v33 offset:11008                      ; d9d82b00 14000021
	ds_load_b64 v[22:23], v33 offset:15104                      ; d9d83b00 16000021
	s_wait_loadcnt_dscnt 0x70e                                  ; bfc8070e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[48:49], v[40:41], v[64:71] ; cc464040 1d025130
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[48:49], v[2:3], v[24:31] ; cc464018 1c620530
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[50:51], v[2:3], v[104:111] ; cc464068 1da20532
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[40:41], v[112:119] ; cc464070 1dc25132
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[44:45], v[88:95] ; cc464058 1d625930
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[48:49], v[46:47], v[96:103] ; cc464060 1d825d30
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[44:45], v[128:135] ; cc464080 1e025932
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[50:51], v[46:47], v[144:151] ; cc464090 1e425d32
	s_wait_loadcnt_dscnt 0x60a                                  ; bfc8060a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[56:57], v[12:13], v[64:71] ; cc464040 1d021938
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[56:57], v[6:7], v[24:31] ; cc464018 1c620d38
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[58:59], v[6:7], v[104:111] ; cc464068 1da20d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[12:13], v[112:119] ; cc464070 1dc2193a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[14:15], v[88:95] ; cc464058 1d621d38
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[56:57], v[42:43], v[96:103] ; cc464060 1d825538
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[14:15], v[128:135] ; cc464080 1e021d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[58:59], v[42:43], v[144:151] ; cc464090 1e42553a
	ds_load_b64 v[2:3], v33 offset:3072                         ; d9d80c00 02000021
	ds_load_b64 v[34:35], v33 offset:7168                       ; d9d81c00 22000021
	ds_load_b64 v[40:41], v33 offset:11264                      ; d9d82c00 28000021
	ds_load_b64 v[44:45], v33 offset:15360                      ; d9d83c00 2c000021
	ds_load_b64 v[6:7], v33 offset:3328                         ; d9d80d00 06000021
	ds_load_b64 v[12:13], v33 offset:7424                       ; d9d81d00 0c000021
	ds_load_b64 v[14:15], v33 offset:11520                      ; d9d82d00 0e000021
	ds_load_b64 v[42:43], v33 offset:15616                      ; d9d83d00 2a000021
	s_wait_loadcnt_dscnt 0x50e                                  ; bfc8050e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[80:81], v[8:9], v[64:71] ; cc464040 1d021150
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[80:81], v[0:1], v[24:31] ; cc464018 1c620150
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[82:83], v[0:1], v[104:111] ; cc464068 1da20152
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[8:9], v[112:119] ; cc464070 1dc21152
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[80:81], v[10:11], v[88:95] ; cc464058 1d621550
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[80:81], v[16:17], v[96:103] ; cc464060 1d822150
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[10:11], v[128:135] ; cc464080 1e021552
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[82:83], v[16:17], v[144:151] ; cc464090 1e422152
	s_wait_loadcnt_dscnt 0x40a                                  ; bfc8040a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[124:125], v[18:19], v[64:71] ; cc464040 1d02257c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[124:125], v[4:5], v[24:31] ; cc464018 1c62097c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[126:127], v[4:5], v[104:111] ; cc464068 1da2097e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[126:127], v[18:19], v[112:119] ; cc464070 1dc2257e
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[124:125], v[20:21], v[88:95] ; cc464058 1d62297c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[124:125], v[22:23], v[96:103] ; cc464060 1d822d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[126:127], v[20:21], v[128:135] ; cc464080 1e02297e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[126:127], v[22:23], v[144:151] ; cc464090 1e422d7e
	ds_load_b64 v[0:1], v33 offset:3584                         ; d9d80e00 00000021
	ds_load_b64 v[8:9], v33 offset:7680                         ; d9d81e00 08000021
	ds_load_b64 v[10:11], v33 offset:11776                      ; d9d82e00 0a000021
	ds_load_b64 v[16:17], v33 offset:15872                      ; d9d83e00 10000021
	ds_load_b64 v[4:5], v33 offset:3840                         ; d9d80f00 04000021
	ds_load_b64 v[18:19], v33 offset:7936                       ; d9d81f00 12000021
	ds_load_b64 v[20:21], v33 offset:12032                      ; d9d82f00 14000021
	ds_load_b64 v[22:23], v33 offset:16128                      ; d9d83f00 16000021
	s_wait_loadcnt_dscnt 0x30e                                  ; bfc8030e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[76:77], v[34:35], v[64:71] ; cc464040 1d02454c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[76:77], v[2:3], v[24:31] ; cc464018 1c62054c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[78:79], v[2:3], v[104:111] ; cc464068 1da2054e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[78:79], v[34:35], v[112:119] ; cc464070 1dc2454e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[76:77], v[40:41], v[88:95] ; cc464058 1d62514c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[76:77], v[44:45], v[96:103] ; cc464060 1d82594c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[78:79], v[40:41], v[128:135] ; cc464080 1e02514e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[78:79], v[44:45], v[144:151] ; cc464090 1e42594e
	s_wait_loadcnt_dscnt 0x20a                                  ; bfc8020a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[60:61], v[12:13], v[64:71] ; cc464040 1d02193c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[60:61], v[6:7], v[24:31] ; cc464018 1c620d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[62:63], v[6:7], v[104:111] ; cc464068 1da20d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[12:13], v[112:119] ; cc464070 1dc2193e
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[60:61], v[14:15], v[88:95] ; cc464058 1d621d3c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[60:61], v[42:43], v[96:103] ; cc464060 1d82553c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[14:15], v[128:135] ; cc464080 1e021d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[42:43], v[144:151] ; cc464090 1e42553e
	s_wait_loadcnt_dscnt 0x106                                  ; bfc80106
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[164:165], v[8:9], v[64:71] ; cc464040 1d0211a4
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[164:165], v[0:1], v[24:31] ; cc464018 1c6201a4
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[166:167], v[0:1], v[104:111] ; cc464068 1da201a6
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[166:167], v[8:9], v[112:119] ; cc464070 1dc211a6
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[164:165], v[10:11], v[88:95] ; cc464058 1d6215a4
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[164:165], v[16:17], v[96:103] ; cc464060 1d8221a4
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[166:167], v[10:11], v[128:135] ; cc464080 1e0215a6
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[166:167], v[16:17], v[144:151] ; cc464090 1e4221a6
	s_wait_loadcnt_dscnt 0x2                                    ; bfc80002
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[168:169], v[18:19], v[64:71] ; cc464040 1d0225a8
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[168:169], v[4:5], v[24:31] ; cc464018 1c6209a8
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[170:171], v[4:5], v[104:111] ; cc464068 1da209aa
	s_min_i32 s41, s18, s24                                     ; 89291812
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[18:19], v[112:119] ; cc464070 1dc225aa
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[168:169], v[20:21], v[88:95] ; cc464058 1d6229a8
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[168:169], v[22:23], v[96:103] ; cc464060 1d822da8
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[170:171], v[20:21], v[128:135] ; cc464080 1e0229aa
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[170:171], v[22:23], v[144:151] ; cc464090 1e422daa
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s41, 0                                         ; bf048029
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
	s_mov_b32 s42, src_scc                                      ; beaa00fd
	s_cmp_ge_i32 s18, s16                                       ; bf031012
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mov_b32 s43, src_scc                                      ; beab00fd
	s_or_b32 s42, s42, src_scc                                  ; 8c2afd2a
	s_cmp_ge_i32 s24, s17                                       ; bf031118
	s_mov_b32 s44, src_scc                                      ; beac00fd
	s_or_b32 s42, s42, src_scc                                  ; 8c2afd2a
	s_cbranch_scc1 BB9                                          ; bfa20017
BB8:
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_max_i32 s1, s18, 0                                        ; 8a018012
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s1, s1, s32                                       ; 89012001
	s_max_i32 s3, s24, 0                                        ; 8a038018
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s3, s3, s33                                       ; 89032103
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s3, s3, s16                                       ; 96031003
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s3, s3, s1                                     ; 80030103
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s3, s3, 12                                       ; 84038c03
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v2, v36, s2, s3                                  ; d6550002 000c0524
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v141, v2, v39                                ; d6550002 049e058d
	buffer_store_b64 v[0:1], v2, s[12:15], null offen           ; c406c07c 40801800 00000002
	s_branch BB10                                               ; bfa00001
BB9:
	s_mov_b32 s0, src_scc                                       ; be8000fd
BB10:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_add_co_u32 s1, s18, 1                                     ; 80018112
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_min_i32 s3, s1, s24                                       ; 89031801
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s3, 0                                          ; bf048003
	s_mov_b32 s4, src_scc                                       ; be8400fd
	s_cmp_ge_i32 s1, s16                                        ; bf031001
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s4, s4, src_scc                                    ; 8c04fd04
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s4, s4, s44                                        ; 8c042c04
	s_cbranch_scc1 BB12                                         ; bfa20017
BB11:
	s_mov_b32 s3, src_scc                                       ; be8300fd
	s_max_i32 s4, s1, 0                                         ; 8a048001
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s4, s4, s32                                       ; 89042004
	s_max_i32 s6, s24, 0                                        ; 8a068018
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s6, s6, s33                                       ; 89062106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s6, s6, s16                                       ; 96061006
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s4                                     ; 80060406
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s6, s6, 12                                       ; 84068c06
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v2, v36, s2, s6                                  ; d6550002 00180524
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v141, v2, v39                                ; d6550002 049e058d
	buffer_store_b64 v[0:1], v2, s[12:15], null offen           ; c406c07c 40801800 00000002
	s_branch BB13                                               ; bfa00001
BB12:
	s_mov_b32 s3, src_scc                                       ; be8300fd
BB13:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_add_co_u32 s4, s24, 1                                     ; 80048118
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s6, s18, s4                                       ; 89060412
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s6, 0                                          ; bf048006
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_or_b32 s43, src_scc, s43                                  ; 8c2b2bfd
	s_cmp_ge_i32 s4, s17                                        ; bf031104
	s_mov_b32 s7, src_scc                                       ; be8700fd
	s_or_b32 s43, s43, src_scc                                  ; 8c2bfd2b
	s_cbranch_scc1 BB15                                         ; bfa20017
BB14:
	s_mov_b32 s6, src_scc                                       ; be8600fd
	s_max_i32 s8, s18, 0                                        ; 8a088012
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s8, s8, s32                                       ; 89082008
	s_max_i32 s9, s4, 0                                         ; 8a098004
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s9, s9, s33                                       ; 89092109
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s9, s9, s16                                       ; 96091009
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s9, s9, s8                                     ; 80090809
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s9, s9, 12                                       ; 84098c09
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v2, v36, s2, s9                                  ; d6550002 00240524
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v141, v2, v39                                ; d6550002 049e058d
	buffer_store_b64 v[0:1], v2, s[12:15], null offen           ; c406c07c 40801800 00000002
	s_branch BB16                                               ; bfa00001
BB15:
	s_mov_b32 s6, src_scc                                       ; be8600fd
BB16:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_min_i32 s8, s1, s4                                        ; 89080401
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s8, 0                                          ; bf048008
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s5, src_scc, s5                                    ; 8c0505fd
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s5, s5, s7                                         ; 8c050705
	s_cbranch_scc1 BB18                                         ; bfa20017
BB17:
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_max_i32 s7, s1, 0                                         ; 8a078001
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s7, s7, s32                                       ; 89072007
	s_max_i32 s8, s4, 0                                         ; 8a088004
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s8, s8, s33                                       ; 89082108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s8, s8, s16                                       ; 96081008
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s8, s8, s7                                     ; 80080708
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s8, s8, 12                                       ; 84088c08
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v2, v36, s2, s8                                  ; d6550002 00200524
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v141, v2, v39                                ; d6550002 049e058d
	buffer_store_b64 v[0:1], v2, s[12:15], null offen           ; c406c07c 40801800 00000002
	s_branch BB19                                               ; bfa00001
BB18:
	s_mov_b32 s5, src_scc                                       ; be8500fd
BB19:
	v_add_nc_u32_e32 v36, 0x100, v36                            ; 4a4848ff 00000100
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB22                                         ; bfa20015
BB20:
	s_max_i32 s0, s18, 0                                        ; 8a008012
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s0, s0, s32                                       ; 89002000
	s_max_i32 s7, s24, 0                                        ; 8a078018
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s7, s7, s33                                       ; 89072107
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s7, s7, s16                                       ; 96071007
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s7, s7, s0                                     ; 80070007
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s7, s7, 12                                       ; 84078c07
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v2, v36, s2, s7                                  ; d6550002 001c0524
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v141, v2, v39                                ; d6550002 049e058d
	buffer_store_b64 v[0:1], v2, s[12:15], null offen           ; c406c07c 40801800 00000002
BB22:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_cmp_lg_i32 s3, 0                                          ; bf018003
	s_cbranch_scc1 BB25                                         ; bfa20015
BB23:
	s_max_i32 s0, s1, 0                                         ; 8a008001
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s0, s0, s32                                       ; 89002000
	s_max_i32 s24, s24, 0                                       ; 8a188018
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s24, s24, s33                                     ; 89182118
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s24, s24, s16                                     ; 96181018
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s24, s24, s0                                   ; 80180018
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s24, s24, 12                                     ; 84188c18
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v2, v36, s2, s24                                 ; d6550002 00600524
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v141, v2, v39                                ; d6550002 049e058d
	buffer_store_b64 v[0:1], v2, s[12:15], null offen           ; c406c07c 40801800 00000002
BB25:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_cmp_lg_i32 s6, 0                                          ; bf018006
	s_cbranch_scc1 BB28                                         ; bfa20013
BB26:
	s_max_i32 s18, s18, 0                                       ; 8a128012
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s18, s18, s32                                     ; 89122012
	s_max_i32 s0, s4, 0                                         ; 8a008004
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_min_i32 s0, s0, s33                                       ; 89002100
	s_mul_i32 s0, s0, s16                                       ; 96001000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s18                                    ; 80001200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s0, s0, 12                                       ; 84008c00
	v_add3_u32 v2, v36, s2, s0                                  ; d6550002 00000524
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v141, v2, v39                                ; d6550002 049e058d
	buffer_store_b64 v[0:1], v2, s[12:15], null offen           ; c406c07c 40801800 00000002
BB28:
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	s_cmp_lg_i32 s5, 0                                          ; bf018005
	s_cbranch_scc1 BB31                                         ; bfa20015
BB29:
	s_max_i32 s1, s1, 0                                         ; 8a018001
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s1, s1, s32                                       ; 89012001
	s_max_i32 s4, s4, 0                                         ; 8a048004
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s4, s4, s33                                       ; 89042104
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s4, s4, s16                                       ; 96041004
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s4, s1                                     ; 80040104
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s4, s4, 12                                       ; 84048c04
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v36, v36, s2, s4                                 ; d6550024 00100524
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v141, v141, v36, v39                             ; d655008d 049e498d
	buffer_store_b64 v[0:1], v141, s[12:15], null offen         ; c406c07c 40801800 0000008d
BB31:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
