BB0:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cmp_lg_i32 s15, -1                                        ; bf01c10f
	s_cbranch_scc0 BB2                                          ; bfa1000f
BB1:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_load_b128 s[16:19], s[16:17], 0x40                        ; f4004408 f8000040
	s_lshl2_add_u32 s20, s15, 24                                ; 8794980f
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s20, s[16:19], s20 offset:0x0             ; f4020508 28000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s20, 0x54434852                                ; bf01ff14 54434852
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s16, vcc_lo, exec_lo                              ; 8b107e6a
	s_cselect_b32 s15, -1, s15                                  ; 980f0fc1
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s15, -1                                        ; bf01c10f
	s_cbranch_scc0 BB5                                          ; bfa1000e
BB4:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_load_b128 s[16:19], s[16:17], 0x40                        ; f4004408 f8000040
	s_lshl2_add_u32 s20, s15, 4                                 ; 8794840f
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s20, s[16:19], s20 offset:0x0             ; f4020508 28000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s20, 0                                         ; bf018014
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s21, -1, 0                                    ; 981580c1
	s_branch BB6                                                ; bfa00001
BB5:
	s_mov_b32 s21, 0                                            ; be950080
BB6:
	s_cmp_eq_i32 ttmp9, 0                                       ; bf008075
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s16, -1, 0                                    ; 981080c1
	s_and_b32 s21, s21, s16                                     ; 8b151015
	s_cmp_eq_i32 ttmp7, 0                                       ; bf008073
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s17, -1, 0                                    ; 981180c1
	s_and_b32 s21, s21, s17                                     ; 8b151115
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 exec_lo, s21, 1                                   ; 8b7e8115
	s_cbranch_execz BB12                                        ; bfa50012
BB7:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[16:17], 0x40                        ; f4004508 f8000040
	s_load_b128 s[16:19], s[16:17], 0x0                         ; f4004408 f8000000
	s_lshl2_add_u32 s15, s15, 16                                ; 878f900f
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_buffer_load_b32 s15, s[20:23], s15 offset:0x0             ; f40203ca 1e000000
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s15, s15, 2                                      ; 840f820f
	buffer_atomic_add_u32 v1, off, s[16:19], s15                ; c40d400f 00802001 00000000
BB12:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_lshl1_add_u32 s13, ttmp9, s13                             ; 870d0d75
	s_lshl1_add_u32 s14, ttmp7, s14                             ; 870e0e73
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_min_i32 s15, s13, s14                                     ; 890f0e0d
	s_cmp_lt_i32 s15, 0                                         ; bf04800f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_cselect_b32 s16, -1, 0                                    ; 981080c1
	s_cmp_ge_i32 s13, s11                                       ; bf030b0d
	s_cselect_b32 s17, -1, 0                                    ; 981180c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_or_b32 s16, s16, s17                                      ; 8c101110
	s_cmp_ge_i32 s14, s12                                       ; bf030c0e
	s_cselect_b32 s18, -1, 0                                    ; 981280c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s16, s16, s18                                      ; 8c101210
	s_mov_b32 s19, src_scc                                      ; be9300fd
	s_add_co_u32 s20, s13, 1                                    ; 8014810d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_min_i32 s21, s20, s14                                     ; 89150e14
	s_cmp_lt_i32 s21, 0                                         ; bf048015
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_cselect_b32 s22, -1, 0                                    ; 981680c1
	s_cmp_ge_i32 s20, s11                                       ; bf030b14
	s_cselect_b32 s23, -1, 0                                    ; 981780c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s22, s22, s23                                      ; 8c161716
	s_or_b32 s22, s22, s18                                      ; 8c161216
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mov_b32 s24, src_scc                                      ; be9800fd
	s_absdiff_i32 s25, s19, 1                                   ; 83198113
	s_cmp_lg_i32 s19, 0                                         ; bf018013
	s_cselect_b32 s26, 2, 3                                     ; 981a8382
	s_mov_b32 s27, src_scc                                      ; be9b00fd
	s_cmp_lg_i32 s24, 0                                         ; bf018018
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_cselect_b32 s25, s25, s26                                 ; 98191a19
	s_mov_b32 s28, src_scc                                      ; be9c00fd
	s_add_co_u32 s29, s14, 1                                    ; 801d810e
	s_min_i32 s30, s13, s29                                     ; 891e1d0d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s30, 0                                         ; bf04801e
	s_cselect_b32 s31, -1, 0                                    ; 981f80c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_or_b32 s31, s31, s17                                      ; 8c1f111f
	s_cmp_ge_i32 s29, s12                                       ; bf030c1d
	s_cselect_b32 s32, -1, 0                                    ; 982080c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s31, s31, s32                                      ; 8c1f201f
	s_mov_b32 s33, src_scc                                      ; bea100fd
	s_or_b32 s34, s25, 4                                        ; 8c228419
	s_cmp_lg_i32 s33, 0                                         ; bf018021
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_cselect_b32 s25, s25, s34                                 ; 98192219
	s_mov_b32 s35, src_scc                                      ; bea300fd
	s_min_i32 s36, s20, s29                                     ; 89241d14
	s_cmp_lt_i32 s36, 0                                         ; bf048024
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s37, -1, 0                                    ; 982580c1
	s_or_b32 s37, s37, s23                                      ; 8c251725
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s37, s37, s32                                      ; 8c252025
	s_mov_b32 s38, src_scc                                      ; bea600fd
	s_or_b32 s39, s25, 8                                        ; 8c278819
	s_cmp_lg_i32 s38, 0                                         ; bf018026
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s25, s25, s39                                 ; 98192719
	s_mov_b32 s40, src_scc                                      ; bea800fd
	s_cmp_lg_i32 s25, 15                                        ; bf018f19
	s_cbranch_scc0 BB17                                         ; bfa1000d
BB13:
	s_and_b32 s15, s25, 3                                       ; 8b0f8319
	s_cbranch_scc0 BB15                                         ; bfa10009
BB14:
	s_and_b32 s15, s25, 10                                      ; 8b0f8a19
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_cselect_b32 s17, 15, 5                                    ; 9811858f
	s_and_b32 s18, s25, 5                                       ; 8b128519
	s_cselect_b32 s17, s17, 10                                  ; 98118a11
	s_and_b32 s25, s25, 12                                      ; 8b198c19
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s17, s17, 3                                   ; 98118311
	s_branch BB18                                               ; bfa00003
BB15:
	s_mov_b32 s17, 12                                           ; be91008c
	s_branch BB18                                               ; bfa00001
BB17:
	s_mov_b32 s17, 15                                           ; be91008f
BB18:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_eq_i32 s17, 15                                        ; bf008f11
	s_cbranch_scc0 BB20                                         ; bfa114ee
BB19:
	s_mov_b32 s15, s1                                           ; be8f0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[0:1], 0x0                           ; f4004400 f8000000
	s_load_b256 s[32:39], s[0:1], 0x30                          ; f4006800 f8000030
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_max_i32 s13, s13, 0                                       ; 8a0d800d
	s_add_co_u32 s21, s11, -1                                   ; 8015c10b
	s_movk_i32 s24, 0x100                                       ; b0180100
	s_min_i32 s13, s13, s21                                     ; 890d150d
	s_max_i32 s14, s14, 0                                       ; 8a0e800e
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	s_min_i32 s14, s14, s12                                     ; 890e0c0e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s14, s14, s11                                     ; 960e0b0e
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_add_co_u32 s22, s14, s13                                  ; 80160d0e
	s_lshl_b32 s22, s22, 9                                      ; 84168916
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s23, s15, s22                                  ; 8017160f
	s_max_i32 s20, s20, 0                                       ; 8a148014
	v_add3_u32 v5, v3, s23, s24                                 ; d6550005 00602f03
	v_add3_u32 v4, v1, s23, v3                                  ; d6550004 040c2f01
	s_min_i32 s20, s20, s21                                     ; 89141514
	s_add_co_u32 s14, s14, s20                                  ; 800e140e
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_lshl_b32 s14, s14, 9                                      ; 840e890e
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s25, s15, s14                                  ; 80190e0f
	s_max_i32 s29, s29, 0                                       ; 8a1d801d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v7, v3, s25, s24                                 ; d6550007 00603303
	v_add3_u32 v6, v1, s25, v3                                  ; d6550006 040c3301
	s_min_i32 s29, s29, s12                                     ; 891d0c1d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mul_i32 s29, s29, s11                                     ; 961d0b1d
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	s_add_co_u32 s13, s29, s13                                  ; 800d0d1d
	s_lshl_b32 s13, s13, 9                                      ; 840d890d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s26, s15, s13                                  ; 801a0d0f
	s_add_co_u32 s29, s29, s20                                  ; 801d141d
	v_add3_u32 v9, v3, s26, s24                                 ; d6550009 00603503
	v_add3_u32 v8, v1, s26, v3                                  ; d6550008 040c3501
	s_lshl_b32 s29, s29, 9                                      ; 841d891d
	s_add_co_u32 s15, s15, s29                                  ; 800f1d0f
	v_add_nc_u32_e32 v9, v9, v1                                 ; 4a120309
	v_add3_u32 v10, v1, s15, v3                                 ; d655000a 040c1f01
	v_add3_u32 v11, v3, s15, s24                                ; d655000b 00601f03
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v11, v11, v1                               ; 4a16030b
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[12:13], v4, s[16:19], null offen          ; c405407c 4080200c 00000004
	buffer_load_b64 v[4:5], v5, s[16:19], null offen            ; c405407c 40802004 00000005
	buffer_load_b64 v[14:15], v6, s[16:19], null offen          ; c405407c 4080200e 00000006
	buffer_load_b64 v[6:7], v7, s[16:19], null offen            ; c405407c 40802006 00000007
	buffer_load_b64 v[16:17], v8, s[16:19], null offen          ; c405407c 40802010 00000008
	buffer_load_b64 v[8:9], v9, s[16:19], null offen            ; c405407c 40802008 00000009
	buffer_load_b64 v[18:19], v10, s[16:19], null offen         ; c405407c 40802012 0000000a
	buffer_load_b64 v[10:11], v11, s[16:19], null offen         ; c405407c 4080200a 0000000b
	v_lshlrev_b32_e32 v20, 2, v0                                ; 30280082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v21, s3, v20, 2                              ; d6470015 020a2803
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[24:27], v21, s[36:39], null offen        ; c405c07c 40804818 00000015
	buffer_load_b128 v[28:31], v21, s[36:39], null offen offset:512 ; c405c07c 4080481c 00020015
	buffer_load_b128 v[32:35], v21, s[36:39], null offen offset:1024 ; c405c07c 40804820 00040015
	buffer_load_b128 v[36:39], v21, s[36:39], null offen offset:1536 ; c405c07c 40804824 00060015
	buffer_load_b128 v[40:43], v21, s[36:39], null offen offset:2048 ; c405c07c 40804828 00080015
	buffer_load_b128 v[44:47], v21, s[36:39], null offen offset:2560 ; c405c07c 4080482c 000a0015
	s_movk_i32 s27, 0x400                                       ; b01b0400
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_dual_mov_b32 v23, v13 :: v_dual_mov_b32 v22, v12          ; ca10010d 1716010c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_dual_mov_b32 v49, v5 :: v_dual_mov_b32 v48, v4            ; ca100105 31300104
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_dual_mov_b32 v51, v15 :: v_dual_mov_b32 v50, v14          ; ca10010f 3332010e
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_dual_mov_b32 v53, v7 :: v_dual_mov_b32 v52, v6            ; ca100107 35340106
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_dual_mov_b32 v55, v17 :: v_dual_mov_b32 v54, v16          ; ca100111 37360110
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_dual_mov_b32 v57, v9 :: v_dual_mov_b32 v56, v8            ; ca100109 39380108
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mov_b32 v59, v19 :: v_dual_mov_b32 v58, v18          ; ca100113 3b3a0112
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mov_b32 v61, v11 :: v_dual_mov_b32 v60, v10          ; ca10010b 3d3c010a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[12:13], 0 ; cc464040 1a021918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[16:17], 0 ; cc464050 1a022118
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[18:19], 0 ; cc464058 1a022518
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[12:13], 0 ; cc464060 1a02191a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[18:19], 0 ; cc464078 1a02251a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[14:15], 0 ; cc464048 1a021d18
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[14:15], 0 ; cc464068 1a021d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[16:17], 0 ; cc464070 1a02211a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[28:29], v[4:5], v[64:71] ; cc464040 1d02091c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[8:9], v[80:87] ; cc464050 1d42111c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[10:11], v[88:95] ; cc464058 1d62151c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[6:7], v[72:79] ; cc464048 1d220d1c
	v_maxmin_num_f32 v26, -4.0, v65, 4.0                        ; d669001a 03da82f7
	v_maxmin_num_f32 v28, -4.0, v66, 4.0                        ; d669001c 03da84f7
	v_maxmin_num_f32 v24, -4.0, v64, 4.0                        ; d6690018 03da80f7
	v_maxmin_num_f32 v62, -4.0, v67, 4.0                        ; d669003e 03da86f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
	v_fma_mix_f32 v27, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe34ff 3728ab28
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
	v_fma_mix_f32 v25, 0xab28, |v24|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe30ff 3728ab28
	v_fma_mix_f32 v63, 0xab28, |v62|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623f 0bfe7cff 3728ab28
	v_dual_fmaak_f32 v27, v27, v26, 0x3f650000 :: v_dual_fmaak_f32 v24, v24, v25, 0x3f650000 ; c842351b 1b183318 3f650000
	v_dual_fmaak_f32 v63, v63, v62, 0x3f650000 :: v_dual_fmaak_f32 v28, v28, v29, 0x3f650000 ; c8427d3f 3f1c3b1c 3f650000
	v_maxmin_num_f32 v128, -4.0, v71, 4.0                       ; d6690080 03da8ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v65, v65, v27 :: v_dual_mul_f32 v64, v64, v24 ; c8c63741 41403140
	v_dual_mul_f32 v67, v67, v63 :: v_dual_mul_f32 v66, v66, v28 ; c8c67f43 43423942
	v_maxmin_num_f32 v130, -4.0, v72, 4.0                       ; d6690082 03da90f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_maxmin_num_f32 v64, -4.0, v68, 4.0                        ; d6690040 03da88f7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_maxmin_num_f32 v66, -4.0, v69, 4.0                        ; d6690042 03da8af7
	v_maxmin_num_f32 v132, -4.0, v73, 4.0                       ; d6690084 03da92f7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_maxmin_num_f32 v134, -4.0, v74, 4.0                       ; d6690086 03da94f7
	v_fma_mix_f32 v65, 0xab28, |v64|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe80ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v75, 4.0                       ; d6690088 03da96f7
	v_fma_mix_f32 v67, 0xab28, |v66|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206243 0bfe84ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v138, -4.0, v76, 4.0                       ; d669008a 03da98f7
	v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 ; c8430782 82810181 3f650000
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_fmaak_f32 v67, v67, v66, 0x3f650000 :: v_dual_fmaak_f32 v64, v64, v65, 0x3f650000 ; c8428543 43408340 3f650000
	v_maxmin_num_f32 v140, -4.0, v77, 4.0                       ; d669008c 03da9af7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v78, 4.0                       ; d669008e 03da9cf7
	v_dual_mul_f32 v72, v72, v130 :: v_dual_mul_f32 v71, v71, v129 ; c8c70548 48470347
	v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 ; c8430f86 86850985 3f650000
	v_dual_mul_f32 v69, v69, v67 :: v_dual_mul_f32 v68, v68, v64 ; c8c68745 45448144
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v79, 4.0                       ; d6690090 03da9ef7
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 ; c843178a 8a891189 3f650000
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v80, 4.0                       ; d6690092 03daa0f7
	v_dual_mul_f32 v74, v74, v134 :: v_dual_mul_f32 v73, v73, v133 ; c8c70d4a 4a490b49
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_maxmin_num_f32 v68, -4.0, v70, 4.0                        ; d6690044 03da8cf7
	v_maxmin_num_f32 v148, -4.0, v81, 4.0                       ; d6690094 03daa2f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_dual_mul_f32 v76, v76, v138 :: v_dual_mul_f32 v75, v75, v137 ; c8c7154c 4c4b134b
	v_maxmin_num_f32 v150, -4.0, v82, 4.0                       ; d6690096 03daa4f7
	v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 ; c8431f8e 8e8d198d 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	v_fma_mix_f32 v69, 0xab28, |v68|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe88ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v83, 4.0                       ; d6690098 03daa6f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_maxmin_num_f32 v154, -4.0, v84, 4.0                       ; d669009a 03daa8f7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_mul_f32 v78, v78, v142 :: v_dual_mul_f32 v77, v77, v141 ; c8c71d4e 4e4d1b4d
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 ; c8432792 92912191 3f650000
	v_maxmin_num_f32 v156, -4.0, v85, 4.0                       ; d669009c 03daaaf7
	v_fmaak_f32 v68, v68, v69, 0x3f650000                       ; 5a888b44 3f650000
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v86, 4.0                       ; d669009e 03daacf7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c8432f96 96952995 3f650000
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	v_maxmin_num_f32 v160, -4.0, v87, 4.0                       ; d66900a0 03daaef7
	v_dual_mul_f32 v80, v80, v146 :: v_dual_mul_f32 v79, v79, v145 ; c8c72550 504f234f
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_mul_f32_e32 v70, v70, v68                                 ; 108c8946
	v_maxmin_num_f32 v162, -4.0, v88, 4.0                       ; d66900a2 03dab0f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 ; c843379a 9a993199 3f650000
	v_dual_mul_f32 v82, v82, v150 :: v_dual_mul_f32 v81, v81, v149 ; c8c72d52 52512b51
	v_maxmin_num_f32 v164, -4.0, v89, 4.0                       ; d66900a4 03dab2f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v90, 4.0                       ; d66900a6 03dab4f7
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c8433f9e 9e9d399d 3f650000
	v_dual_mul_f32 v84, v84, v154 :: v_dual_mul_f32 v83, v83, v153 ; c8c73554 54533353
	v_maxmin_num_f32 v168, -4.0, v91, 4.0                       ; d66900a8 03dab6f7
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v170, -4.0, v92, 4.0                       ; d66900aa 03dab8f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v93, 4.0                       ; d66900ac 03dabaf7
	v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 ; c84347a2 a2a141a1 3f650000
	v_dual_mul_f32 v86, v86, v158 :: v_dual_mul_f32 v85, v85, v157 ; c8c73d56 56553b55
	v_maxmin_num_f32 v174, -4.0, v94, 4.0                       ; d66900ae 03dabcf7
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v95, 4.0                       ; d66900b0 03dabef7
	v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 ; c8434fa6 a6a549a5 3f650000
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[30:31], v[4:5], v[96:103] ; cc464060 1d82091e
	v_dual_mul_f32 v88, v88, v162 :: v_dual_mul_f32 v87, v87, v161 ; c8c74558 58574357
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 ; c84357aa aaa951a9 3f650000
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_dual_mul_f32 v90, v90, v166 :: v_dual_mul_f32 v89, v89, v165 ; c8c74d5a 5a594b59
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 ; c8435fae aead59ad 3f650000
	v_dual_mul_f32 v92, v92, v170 :: v_dual_mul_f32 v91, v91, v169 ; c8c7555c 5c5b535b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[6:7], v[104:111] ; cc464068 1da20d1e
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v180, -4.0, v97, 4.0                       ; d66900b4 03dac2f7
	v_maxmin_num_f32 v178, -4.0, v96, 4.0                       ; d66900b2 03dac0f7
	v_maxmin_num_f32 v182, -4.0, v98, 4.0                       ; d66900b6 03dac4f7
	v_dual_mul_f32 v94, v94, v174 :: v_dual_mul_f32 v93, v93, v173 ; c8c75d5e 5e5d5b5d
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[8:9], v[112:119] ; cc464070 1dc2111e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[10:11], v[120:127] ; cc464078 1de2151e
	v_maxmin_num_f32 v184, -4.0, v99, 4.0                       ; d66900b8 03dac6f7
	v_maxmin_num_f32 v186, -4.0, v100, 4.0                      ; d66900ba 03dac8f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v188, -4.0, v101, 4.0                      ; d66900bc 03dacaf7
	v_maxmin_num_f32 v190, -4.0, v102, 4.0                      ; d66900be 03daccf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 ; c84367b2 b2b161b1 3f650000
	v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 ; c8436fb6 b6b569b5 3f650000
	v_maxmin_num_f32 v65, -4.0, v104, 4.0                       ; d6690041 03dad0f7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v67, -4.0, v105, 4.0                       ; d6690043 03dad2f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 ; c84377ba bab971b9 3f650000
	v_dual_mul_f32 v96, v96, v178 :: v_dual_mul_f32 v95, v95, v177 ; c8c76560 605f635f
	v_dual_mul_f32 v98, v98, v182 :: v_dual_mul_f32 v97, v97, v181 ; c8c76d62 62616b61
	v_maxmin_num_f32 v69, -4.0, v106, 4.0                       ; d6690045 03dad4f7
	v_fma_mix_f32 v66, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206242 0bfe82ff 3728ab28
	v_fma_mix_f32 v68, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206244 0bfe86ff 3728ab28
	v_maxmin_num_f32 v71, -4.0, v107, 4.0                       ; d6690047 03dad6f7
	v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 :: v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 ; c8437fbe bebd79bd 3f650000
	v_maxmin_num_f32 v191, -4.0, v103, 4.0                      ; d66900bf 03dacef7
	v_dual_mul_f32 v100, v100, v186 :: v_dual_mul_f32 v99, v99, v185 ; c8c77564 64637363
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_fma_mix_f32 v70, 0xab28, |v69|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe8aff 3728ab28
	v_maxmin_num_f32 v73, -4.0, v108, 4.0                       ; d6690049 03dad8f7
	v_dual_fmaak_f32 v68, v68, v67, 0x3f650000 :: v_dual_fmaak_f32 v65, v65, v66, 0x3f650000 ; c8428744 44408541 3f650000
	v_maxmin_num_f32 v75, -4.0, v109, 4.0                       ; d669004b 03dadaf7
	v_fma_mix_f32 v72, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe8eff 3728ab28
	v_fma_mix_f32 v64, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206240 0bff7eff 3728ab28
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v77, -4.0, v110, 4.0                       ; d669004d 03dadcf7
	v_maxmin_num_f32 v79, -4.0, v111, 4.0                       ; d669004f 03dadef7
	v_fma_mix_f32 v74, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe92ff 3728ab28
	v_dual_mul_f32 v104, v104, v65 :: v_dual_mul_f32 v105, v105, v68 ; c8c68368 68688969
	v_fma_mix_f32 v76, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624c 0bfe96ff 3728ab28
	v_dual_fmaak_f32 v72, v72, v71, 0x3f650000 :: v_dual_fmaak_f32 v69, v69, v70, 0x3f650000 ; c8428f48 48448d45 3f650000
	v_maxmin_num_f32 v81, -4.0, v112, 4.0                       ; d6690051 03dae0f7
	v_dual_fmaak_f32 v64, v64, v191, 0x3f650000 :: v_dual_mul_f32 v101, v101, v189 ; c8477f40 40657b65 3f650000
	v_maxmin_num_f32 v83, -4.0, v113, 4.0                       ; d6690053 03dae2f7
	v_fma_mix_f32 v78, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe9aff 3728ab28
	v_fma_mix_f32 v80, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe9eff 3728ab28
	v_dual_fmaak_f32 v76, v76, v75, 0x3f650000 :: v_dual_fmaak_f32 v73, v73, v74, 0x3f650000 ; c842974c 4c489549 3f650000
	v_dual_mul_f32 v107, v107, v72 :: v_dual_mul_f32 v106, v106, v69 ; c8c6916b 6b6a8b6a
	v_maxmin_num_f32 v85, -4.0, v114, 4.0                       ; d6690055 03dae4f7
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_dual_mul_f32 v102, v102, v190 :: v_dual_mul_f32 v103, v103, v64 ; c8c77d66 66668167
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v87, -4.0, v115, 4.0                       ; d6690057 03dae6f7
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_dual_fmaak_f32 v80, v80, v79, 0x3f650000 :: v_dual_fmaak_f32 v77, v77, v78, 0x3f650000 ; c8429f50 504c9d4d 3f650000
	v_dual_mul_f32 v109, v109, v76 :: v_dual_mul_f32 v108, v108, v73 ; c8c6996d 6d6c936c
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v89, -4.0, v116, 4.0                       ; d6690059 03dae8f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v117, 4.0                       ; d669005b 03daeaf7
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 ; c842a754 5450a551 3f650000
	v_maxmin_num_f32 v93, -4.0, v118, 4.0                       ; d669005d 03daecf7
	v_dual_mul_f32 v111, v111, v80 :: v_dual_mul_f32 v110, v110, v77 ; c8c6a16f 6f6e9b6e
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v95, -4.0, v119, 4.0                       ; d669005f 03daeef7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v120, 4.0                       ; d6690061 03daf0f7
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af58 5854ad55 3f650000
	v_maxmin_num_f32 v99, -4.0, v121, 4.0                       ; d6690063 03daf2f7
	v_dual_mul_f32 v113, v113, v84 :: v_dual_mul_f32 v112, v112, v81 ; c8c6a971 7170a370
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v122, 4.0                      ; d6690065 03daf4f7
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c842b75c 5c58b559 3f650000
	v_maxmin_num_f32 v103, -4.0, v123, 4.0                      ; d6690067 03daf6f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_mul_f32 v115, v115, v88 :: v_dual_mul_f32 v114, v114, v85 ; c8c6b173 7372ab72
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v105, -4.0, v124, 4.0                      ; d6690069 03daf8f7
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v125, 4.0                      ; d669006b 03dafaf7
	v_dual_mul_f32 v117, v117, v92 :: v_dual_mul_f32 v116, v116, v89 ; c8c6b975 7574b374
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 :: v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 ; c842c764 6460c561 3f650000
	v_maxmin_num_f32 v109, -4.0, v126, 4.0                      ; d669006d 03dafcf7
	v_maxmin_num_f32 v111, -4.0, v127, 4.0                      ; d669006f 03dafef7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_mul_f32 v119, v119, v96 :: v_dual_mul_f32 v118, v118, v93 ; c8c6c177 7776bb76
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 :: v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 ; c842cf68 6864cd65 3f650000
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[32:33], v[12:13], 0 ; cc464048 1a021920
	v_dual_mul_f32 v121, v121, v100 :: v_dual_mul_f32 v120, v120, v97 ; c8c6c979 7978c378
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 :: v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 ; c842d76c 6c68d569 3f650000
	v_dual_mul_f32 v123, v123, v104 :: v_dual_mul_f32 v122, v122, v101 ; c8c6d17b 7b7acb7a
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 :: v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 ; c842df70 706cdd6d 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v125, v125, v108 :: v_dual_mul_f32 v124, v124, v105 ; c8c6d97d 7d7cd37c
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[36:37], v[4:5], v[72:79] ; cc464048 1d220924
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[14:15], 0 ; cc464050 1a021d20
	v_dual_mul_f32 v127, v127, v112 :: v_dual_mul_f32 v126, v126, v109 ; c8c6e17f 7f7edb7e
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[16:17], 0 ; cc464058 1a022120
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[18:19], 0 ; cc464060 1a022520
	v_maxmin_num_f32 v119, -4.0, v75, 4.0                       ; d6690077 03da96f7
	v_maxmin_num_f32 v113, -4.0, v72, 4.0                       ; d6690071 03da90f7
	v_maxmin_num_f32 v117, -4.0, v74, 4.0                       ; d6690075 03da94f7
	v_maxmin_num_f32 v115, -4.0, v73, 4.0                       ; d6690073 03da92f7
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[6:7], v[80:87] ; cc464050 1d420d24
	v_maxmin_num_f32 v121, -4.0, v76, 4.0                       ; d6690079 03da98f7
	v_maxmin_num_f32 v123, -4.0, v77, 4.0                       ; d669007b 03da9af7
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[8:9], v[88:95] ; cc464058 1d621124
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[10:11], v[96:103] ; cc464060 1d821524
	v_maxmin_num_f32 v125, -4.0, v78, 4.0                       ; d669007d 03da9cf7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v79, 4.0                       ; d669007f 03da9ef7
	v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842ef78 7874ed75 3f650000
	v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 :: v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 ; c842e774 7470e571 3f650000
	v_maxmin_num_f32 v129, -4.0, v80, 4.0                       ; d6690081 03daa0f7
	v_maxmin_num_f32 v131, -4.0, v81, 4.0                       ; d6690083 03daa2f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 :: v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 ; c842f77c 7c78f579 3f650000
	v_maxmin_num_f32 v133, -4.0, v82, 4.0                       ; d6690085 03daa4f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v83, 4.0                       ; d6690087 03daa6f7
	v_dual_mul_f32 v75, v75, v120 :: v_dual_mul_f32 v74, v74, v117 ; c8c6f14b 4b4aeb4a
	v_dual_mul_f32 v73, v73, v116 :: v_dual_mul_f32 v72, v72, v113 ; c8c6e949 4948e348
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_mul_f32 v77, v77, v124 :: v_dual_mul_f32 v76, v76, v121 ; c8c6f94d 4d4cf34c
	v_maxmin_num_f32 v137, -4.0, v84, 4.0                       ; d6690089 03daa8f7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842ff80 807cfd7d 3f650000
	v_maxmin_num_f32 v139, -4.0, v85, 4.0                       ; d669008b 03daaaf7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 ; c8430784 84810581 3f650000
	v_maxmin_num_f32 v141, -4.0, v86, 4.0                       ; d669008d 03daacf7
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	v_maxmin_num_f32 v143, -4.0, v87, 4.0                       ; d669008f 03daaef7
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_dual_mul_f32 v79, v79, v128 :: v_dual_mul_f32 v78, v78, v125 ; c8c7014f 4f4efb4e
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430f88 88850d85 3f650000
	v_maxmin_num_f32 v145, -4.0, v88, 4.0                       ; d6690091 03dab0f7
	v_maxmin_num_f32 v147, -4.0, v89, 4.0                       ; d6690093 03dab2f7
	v_dual_mul_f32 v81, v81, v132 :: v_dual_mul_f32 v80, v80, v129 ; c8c70951 51510350
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_maxmin_num_f32 v149, -4.0, v90, 4.0                       ; d6690095 03dab4f7
	v_dual_fmaak_f32 v140, v140, v139, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 ; c843178c 8c891589 3f650000
	v_dual_mul_f32 v83, v83, v136 :: v_dual_mul_f32 v82, v82, v133 ; c8c71153 53530b52
	v_maxmin_num_f32 v151, -4.0, v91, 4.0                       ; d6690097 03dab6f7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c8431f90 908d1d8d 3f650000
	v_maxmin_num_f32 v153, -4.0, v92, 4.0                       ; d6690099 03dab8f7
	v_maxmin_num_f32 v155, -4.0, v93, 4.0                       ; d669009b 03dabaf7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_mul_f32 v85, v85, v140 :: v_dual_mul_f32 v84, v84, v137 ; c8c71955 55551354
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8432794 94912591 3f650000
	v_maxmin_num_f32 v157, -4.0, v94, 4.0                       ; d669009d 03dabcf7
	v_dual_mul_f32 v87, v87, v144 :: v_dual_mul_f32 v86, v86, v141 ; c8c72157 57571b56
	v_maxmin_num_f32 v159, -4.0, v95, 4.0                       ; d669009f 03dabef7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v161, -4.0, v96, 4.0                       ; d66900a1 03dac0f7
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432f98 98952d95 3f650000
	v_dual_mul_f32 v89, v89, v148 :: v_dual_mul_f32 v88, v88, v145 ; c8c72959 59592358
	v_maxmin_num_f32 v163, -4.0, v97, 4.0                       ; d66900a3 03dac2f7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c843379c 9c993599 3f650000
	v_maxmin_num_f32 v165, -4.0, v98, 4.0                       ; d66900a5 03dac4f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v99, 4.0                       ; d66900a7 03dac6f7
	v_dual_mul_f32 v91, v91, v152 :: v_dual_mul_f32 v90, v90, v149 ; c8c7315b 5b5b2b5a
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v169, -4.0, v100, 4.0                      ; d66900a9 03dac8f7
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c8433fa0 a09d3d9d 3f650000
	v_dual_mul_f32 v93, v93, v156 :: v_dual_mul_f32 v92, v92, v153 ; c8c7395d 5d5d335c
	v_maxmin_num_f32 v171, -4.0, v101, 4.0                      ; d66900ab 03dacaf7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v173, -4.0, v102, 4.0                      ; d66900ad 03daccf7
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c84347a4 a4a145a1 3f650000
	v_maxmin_num_f32 v175, -4.0, v103, 4.0                      ; d66900af 03dacef7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_mul_f32 v95, v95, v160 :: v_dual_mul_f32 v94, v94, v157 ; c8c7415f 5f5f3b5e
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 ; c8434fa8 a8a54da5 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[34:35], v[12:13], 0 ; cc464050 1a021922
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_mul_f32 v97, v97, v164 :: v_dual_mul_f32 v96, v96, v161 ; c8c74961 61614360
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 ; c84357ac aca955a9 3f650000
	v_dual_mul_f32 v99, v99, v168 :: v_dual_mul_f32 v98, v98, v165 ; c8c75163 63634b62
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 ; c8435fb0 b0ad5dad 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v101, v101, v172 :: v_dual_mul_f32 v100, v100, v169 ; c8c75965 65655364
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[34:35], v[14:15], 0 ; cc464058 1a021d22
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[38:39], v[4:5], v[80:87] ; cc464050 1d420926
	v_dual_mul_f32 v103, v103, v176 :: v_dual_mul_f32 v102, v102, v173 ; c8c76167 67675b66
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[34:35], v[18:19], 0 ; cc464068 1a022522
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[38:39], v[6:7], v[88:95] ; cc464058 1d620d26
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[16:17], 0 ; cc464060 1a022122
	v_maxmin_num_f32 v179, -4.0, v81, 4.0                       ; d66900b3 03daa2f7
	v_maxmin_num_f32 v177, -4.0, v80, 4.0                       ; d66900b1 03daa0f7
	v_maxmin_num_f32 v181, -4.0, v82, 4.0                       ; d66900b5 03daa4f7
	v_maxmin_num_f32 v183, -4.0, v83, 4.0                       ; d66900b7 03daa6f7
	v_maxmin_num_f32 v185, -4.0, v84, 4.0                       ; d66900b9 03daa8f7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[10:11], v[104:111] ; cc464068 1da21526
	v_maxmin_num_f32 v187, -4.0, v85, 4.0                       ; d66900bb 03daaaf7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[8:9], v[96:103] ; cc464060 1d821126
	v_maxmin_num_f32 v189, -4.0, v86, 4.0                       ; d66900bd 03daacf7
	v_maxmin_num_f32 v191, -4.0, v87, 4.0                       ; d66900bf 03daaef7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 ; c84367b4 b4b165b1 3f650000
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c8436fb8 b8b56db5 3f650000
	v_maxmin_num_f32 v39, -4.0, v88, 4.0                        ; d6690027 03dab0f7
	v_maxmin_num_f32 v75, -4.0, v89, 4.0                        ; d669004b 03dab2f7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_maxmin_num_f32 v77, -4.0, v90, 4.0                        ; d669004d 03dab4f7
	v_fma_mix_f32 v38, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206226 0bff7eff 3728ab28
	v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 ; c84377bc bcb975b9 3f650000
	v_maxmin_num_f32 v79, -4.0, v91, 4.0                        ; d669004f 03dab6f7
	v_dual_mul_f32 v81, v81, v180 :: v_dual_mul_f32 v80, v80, v177 ; c8c76951 51516350
	v_dual_mul_f32 v83, v83, v184 :: v_dual_mul_f32 v82, v82, v181 ; c8c77153 53536b52
	v_fma_mix_f32 v74, 0xab28, |v39|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe4eff 3728ab28
	v_fma_mix_f32 v76, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624c 0bfe96ff 3728ab28
	v_fma_mix_f32 v78, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe9aff 3728ab28
	v_dual_fmaak_f32 v38, v38, v191, 0x3f650000 :: v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 ; c8437f26 26bd7dbd 3f650000
	v_dual_mul_f32 v85, v85, v188 :: v_dual_mul_f32 v84, v84, v185 ; c8c77955 55557354
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v81, -4.0, v92, 4.0                        ; d6690051 03dab8f7
	v_fma_mix_f32 v80, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe9eff 3728ab28
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v83, -4.0, v93, 4.0                        ; d6690053 03dabaf7
	v_dual_fmaak_f32 v76, v76, v75, 0x3f650000 :: v_dual_fmaak_f32 v39, v39, v74, 0x3f650000 ; c842974c 4c269527 3f650000
	v_dual_mul_f32 v87, v87, v38 :: v_dual_mul_f32 v86, v86, v189 ; c8c64d57 57577b56
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v85, -4.0, v94, 4.0                        ; d6690055 03dabcf7
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_dual_fmaak_f32 v80, v80, v79, 0x3f650000 :: v_dual_fmaak_f32 v77, v77, v78, 0x3f650000 ; c8429f50 504c9d4d 3f650000
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_dual_mul_f32 v89, v89, v76 :: v_dual_mul_f32 v88, v88, v39 ; c8c69959 59584f58
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v87, -4.0, v95, 4.0                        ; d6690057 03dabef7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_dual_mul_f32 v91, v91, v80 :: v_dual_mul_f32 v90, v90, v77 ; c8c6a15b 5b5a9b5a
	v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 ; c842a754 5450a551 3f650000
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v89, -4.0, v96, 4.0                        ; d6690059 03dac0f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v97, 4.0                        ; d669005b 03dac2f7
	v_dual_mul_f32 v93, v93, v84 :: v_dual_mul_f32 v92, v92, v81 ; c8c6a95d 5d5ca35c
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af58 5854ad55 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v93, -4.0, v98, 4.0                        ; d669005d 03dac4f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_mul_f32 v95, v95, v88 :: v_dual_mul_f32 v94, v94, v85 ; c8c6b15f 5f5eab5e
	v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842b559 595cb75c 3f650000
	v_maxmin_num_f32 v113, -4.0, v102, 4.0                      ; d6690071 03daccf7
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v99, 4.0                        ; d669005f 03dac6f7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v115, -4.0, v103, 4.0                      ; d6690073 03dacef7
	v_dual_mul_f32 v97, v97, v92 :: v_dual_mul_f32 v96, v96, v89 ; c8c6b961 6160b360
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v117, -4.0, v104, 4.0                      ; d6690075 03dad0f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v100, 4.0                       ; d6690061 03dac8f7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v105, 4.0                      ; d6690077 03dad2f7
	v_maxmin_num_f32 v121, -4.0, v106, 4.0                      ; d6690079 03dad4f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842e774 7474ed75 3f650000
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v107, 4.0                      ; d669007b 03dad6f7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v108, 4.0                      ; d669007d 03dad8f7
	v_dual_mul_f32 v99, v99, v96 :: v_dual_mul_f32 v98, v98, v93 ; c8c6c163 6362bb62
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 :: v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 ; c842ef78 7878f579 3f650000
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v109, 4.0                      ; d669007f 03dadaf7
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v101, 4.0                       ; d6690063 03dacaf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v110, 4.0                      ; d6690081 03dadcf7
	v_dual_mul_f32 v106, v106, v121 :: v_dual_mul_f32 v103, v103, v116 ; c8c6f36a 6a66e967
	v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842f77c 7c7cfd7d 3f650000
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v111, 4.0                      ; d6690083 03dadef7
	v_fma_mix_f32 v112, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfec6ff 3728ab28
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[12:13], 0 ; cc464050 1a021928
	v_fmaak_f32 v97, v97, v98, 0x3f650000                       ; 5ac2c561 3f650000
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_dual_mul_f32 v108, v108, v125 :: v_dual_mul_f32 v105, v105, v120 ; c8c6fb6c 6c68f169
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_fmaak_f32 v112, v112, v99, 0x3f650000 :: v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 ; c842c770 7070e571 3f650000
	v_mul_f32_e32 v100, v100, v97                               ; 10c8c364
	v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 ; c842ff80 80810581 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_mul_f32_e32 v102, v102, v113                              ; 10cce366
	v_dual_mul_f32 v104, v104, v117 :: v_dual_mul_f32 v101, v101, v112 ; c8c6eb68 6864e165
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[4:5], v[80:87] ; cc464050 1d42092c
	v_dual_mul_f32 v110, v110, v129 :: v_dual_mul_f32 v107, v107, v124 ; c8c7036e 6e6af96b
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[14:15], 0 ; cc464058 1a021d28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[16:17], 0 ; cc464060 1a022128
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v135, -4.0, v81, 4.0                       ; d6690087 03daa2f7
	v_maxmin_num_f32 v137, -4.0, v82, 4.0                       ; d6690089 03daa4f7
	v_maxmin_num_f32 v133, -4.0, v80, 4.0                       ; d6690085 03daa0f7
	v_maxmin_num_f32 v139, -4.0, v83, 4.0                       ; d669008b 03daa6f7
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[6:7], v[88:95] ; cc464058 1d620d2c
	v_maxmin_num_f32 v141, -4.0, v84, 4.0                       ; d669008d 03daa8f7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[8:9], v[96:103] ; cc464060 1d82112c
	v_maxmin_num_f32 v143, -4.0, v85, 4.0                       ; d669008f 03daaaf7
	v_maxmin_num_f32 v145, -4.0, v86, 4.0                       ; d6690091 03daacf7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 ; c8430f88 88891589 3f650000
	v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430784 84850d85 3f650000
	v_maxmin_num_f32 v147, -4.0, v87, 4.0                       ; d6690093 03daaef7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_maxmin_num_f32 v149, -4.0, v88, 4.0                       ; d6690095 03dab0f7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_dual_fmaak_f32 v140, v140, v139, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c843178c 8c8d1d8d 3f650000
	v_dual_mul_f32 v80, v80, v133 :: v_dual_mul_f32 v109, v109, v128 ; c8c70b50 506d016d
	v_dual_mul_f32 v82, v82, v137 :: v_dual_mul_f32 v111, v111, v132 ; c8c71352 526f096f
	v_maxmin_num_f32 v151, -4.0, v89, 4.0                       ; d6690097 03dab2f7
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_maxmin_num_f32 v153, -4.0, v90, 4.0                       ; d6690099 03dab4f7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8431f90 90912591 3f650000
	v_dual_mul_f32 v84, v84, v141 :: v_dual_mul_f32 v81, v81, v136 ; c8c71b54 54511151
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[18:19], 0 ; cc464068 1a022528
	v_maxmin_num_f32 v155, -4.0, v91, 4.0                       ; d669009b 03dab6f7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v92, 4.0                       ; d669009d 03dab8f7
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432794 94952d95 3f650000
	v_dual_mul_f32 v86, v86, v145 :: v_dual_mul_f32 v83, v83, v140 ; c8c72356 56531953
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v159, -4.0, v93, 4.0                       ; d669009f 03dabaf7
	v_maxmin_num_f32 v161, -4.0, v94, 4.0                       ; d66900a1 03dabcf7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c8432f98 98993599 3f650000
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_mul_f32 v88, v88, v149 :: v_dual_mul_f32 v85, v85, v144 ; c8c72b58 58552155
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v163, -4.0, v95, 4.0                       ; d66900a3 03dabef7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[10:11], v[104:111] ; cc464068 1da2152c
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v96, 4.0                       ; d66900a5 03dac0f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_mul_f32 v90, v90, v153 :: v_dual_mul_f32 v87, v87, v148 ; c8c7335a 5a572957
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c843379c 9c9d3d9d 3f650000
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v97, 4.0                       ; d66900a7 03dac2f7
	v_maxmin_num_f32 v169, -4.0, v98, 4.0                       ; d66900a9 03dac4f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c8433fa0 a0a145a1 3f650000
	v_maxmin_num_f32 v171, -4.0, v99, 4.0                       ; d66900ab 03dac6f7
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_dual_mul_f32 v92, v92, v157 :: v_dual_mul_f32 v89, v89, v152 ; c8c73b5c 5c593159
	v_maxmin_num_f32 v173, -4.0, v100, 4.0                      ; d66900ad 03dac8f7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 ; c84347a4 a4a54da5 3f650000
	v_dual_mul_f32 v94, v94, v161 :: v_dual_mul_f32 v91, v91, v156 ; c8c7435e 5e5b395b
	v_maxmin_num_f32 v175, -4.0, v101, 4.0                      ; d66900af 03dacaf7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_maxmin_num_f32 v177, -4.0, v102, 4.0                      ; d66900b1 03daccf7
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 ; c8434fa8 a8a955a9 3f650000
	v_dual_mul_f32 v96, v96, v165 :: v_dual_mul_f32 v93, v93, v160 ; c8c74b60 605d415d
	v_maxmin_num_f32 v179, -4.0, v103, 4.0                      ; d66900b3 03dacef7
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v181, -4.0, v104, 4.0                      ; d66900b5 03dad0f7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v183, -4.0, v105, 4.0                      ; d66900b7 03dad2f7
	v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 ; c84357ac acad5dad 3f650000
	v_dual_mul_f32 v98, v98, v169 :: v_dual_mul_f32 v95, v95, v164 ; c8c75362 625f495f
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	buffer_load_b128 v[80:83], v21, s[36:39], null offen offset:3072 ; c405c07c 40804850 000c0015
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v106, 4.0                      ; d66900b9 03dad4f7
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 ; c8435fb0 b0b165b1 3f650000
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	buffer_load_b128 v[88:91], v21, s[36:39], null offen offset:3584 ; c405c07c 40804858 000e0015
	v_dual_mul_f32 v100, v100, v173 :: v_dual_mul_f32 v97, v97, v168 ; c8c75b64 64615161
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v187, -4.0, v107, 4.0                      ; d66900bb 03dad6f7
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c84367b4 b4b56db5 3f650000
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_dual_mul_f32 v102, v102, v177 :: v_dual_mul_f32 v99, v99, v172 ; c8c76366 66635963
	v_maxmin_num_f32 v189, -4.0, v108, 4.0                      ; d66900bd 03dad8f7
	v_maxmin_num_f32 v191, -4.0, v109, 4.0                      ; d66900bf 03dadaf7
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_mul_f32 v103, v103, v180 ; c8476fb8 b8676967 3f650000
	v_dual_mul_f32 v104, v104, v181 :: v_dual_mul_f32 v101, v101, v176 ; c8c76b68 68656165
	v_maxmin_num_f32 v86, -4.0, v110, 4.0                       ; d6690056 03dadcf7
	v_fmaak_f32 v185, v185, v186, 0x3f650000                    ; 5b7375b9 3f650000
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v92, -4.0, v111, 4.0                       ; d669005c 03dadef7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_fma_mix_f32 v21, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bff7eff 3728ab28
	v_fmaak_f32 v188, v188, v187, 0x3f650000                    ; 5b7977bc 3f650000
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[12:13], 0 ; cc464060 1a02192a
	v_dual_mul_f32 v105, v105, v184 :: v_dual_mul_f32 v106, v106, v185 ; c8c77169 696b736a
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_fmaak_f32 v189, v189, v190, 0x3f650000                    ; 5b7b7dbd 3f650000
	v_mul_f32_e32 v107, v107, v188                              ; 10d7796b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v87, 0x3f650000 ; c842b95d 5d56af56 3f650000
	v_dual_fmaak_f32 v21, v21, v191, 0x3f650000 :: v_dual_mul_f32 v108, v108, v189 ; c8477f15 156d7b6c 3f650000
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[4:5], v[96:103] ; cc464060 1d82092e
	v_dual_mul_f32 v111, v111, v93 :: v_dual_mul_f32 v110, v110, v86 ; c8c6bb6f 6f6ead6e
	v_mul_f32_e32 v109, v109, v21                               ; 10da2b6d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[16:17], 0 ; cc464070 1a02212a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[18:19], 0 ; cc464078 1a02252a
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[14:15], 0 ; cc464068 1a021d2a
	v_maxmin_num_f32 v94, -4.0, v96, 4.0                        ; d669005e 03dac0f7
	v_maxmin_num_f32 v128, -4.0, v97, 4.0                       ; d6690080 03dac2f7
	v_maxmin_num_f32 v132, -4.0, v99, 4.0                       ; d6690084 03dac6f7
	v_maxmin_num_f32 v130, -4.0, v98, 4.0                       ; d6690082 03dac4f7
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[8:9], v[112:119] ; cc464070 1dc2112e
	v_maxmin_num_f32 v134, -4.0, v100, 4.0                      ; d6690086 03dac8f7
	v_maxmin_num_f32 v136, -4.0, v101, 4.0                      ; d6690088 03dacaf7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[10:11], v[120:127] ; cc464078 1de2152e
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[6:7], v[104:111] ; cc464068 1da20d2e
	v_maxmin_num_f32 v138, -4.0, v102, 4.0                      ; d669008a 03daccf7
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v140, -4.0, v103, 4.0                      ; d669008c 03dacef7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c8430181 815ebf5e 3f650000
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8430985 85830782 3f650000
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c8431189 89870f86 3f650000
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_dual_mul_f32 v97, v97, v129 :: v_dual_mul_f32 v96, v96, v94 ; c8c70361 6160bd60
	v_dual_mul_f32 v99, v99, v133 :: v_dual_mul_f32 v98, v98, v130 ; c8c70b63 63630562
	v_maxmin_num_f32 v142, -4.0, v104, 4.0                      ; d669008e 03dad0f7
	v_maxmin_num_f32 v148, -4.0, v107, 4.0                      ; d6690094 03dad6f7
	v_maxmin_num_f32 v144, -4.0, v105, 4.0                      ; d6690090 03dad2f7
	v_maxmin_num_f32 v146, -4.0, v106, 4.0                      ; d6690092 03dad4f7
	v_dual_mul_f32 v101, v101, v137 :: v_dual_mul_f32 v100, v100, v134 ; c8c71365 65650d64
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c843198d 8d8b178a 3f650000
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v150, -4.0, v108, 4.0                      ; d6690096 03dad8f7
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v109, 4.0                      ; d6690098 03dadaf7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v154, -4.0, v110, 4.0                      ; d669009a 03dadcf7
	v_dual_mul_f32 v103, v103, v141 :: v_dual_mul_f32 v102, v102, v138 ; c8c71b67 67671566
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v111, 4.0                      ; d669009c 03dadef7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v112, 4.0                      ; d669009e 03dae0f7
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432191 918f1f8e 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8432995 95932792 3f650000
	v_maxmin_num_f32 v160, -4.0, v113, 4.0                      ; d66900a0 03dae2f7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v114, 4.0                      ; d66900a2 03dae4f7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8433199 99972f96 3f650000
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v115, 4.0                      ; d66900a4 03dae6f7
	v_dual_mul_f32 v105, v105, v145 :: v_dual_mul_f32 v104, v104, v142 ; c8c72369 69691d68
	v_dual_mul_f32 v107, v107, v149 :: v_dual_mul_f32 v106, v106, v146 ; c8c72b6b 6b6b256a
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c843399d 9d9b379a 3f650000
	v_maxmin_num_f32 v166, -4.0, v116, 4.0                      ; d66900a6 03dae8f7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_mul_f32 v109, v109, v153 :: v_dual_mul_f32 v108, v108, v150 ; c8c7336d 6d6d2d6c
	v_maxmin_num_f32 v168, -4.0, v117, 4.0                      ; d66900a8 03daeaf7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v170, -4.0, v118, 4.0                      ; d66900aa 03daecf7
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84341a1 a19f3f9e 3f650000
	v_dual_mul_f32 v111, v111, v157 :: v_dual_mul_f32 v110, v110, v154 ; c8c73b6f 6f6f356e
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v119, 4.0                      ; d66900ac 03daeef7
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84349a5 a5a347a2 3f650000
	v_maxmin_num_f32 v174, -4.0, v120, 4.0                      ; d66900ae 03daf0f7
	v_maxmin_num_f32 v176, -4.0, v121, 4.0                      ; d66900b0 03daf2f7
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_dual_mul_f32 v113, v113, v161 :: v_dual_mul_f32 v112, v112, v158 ; c8c74371 71713d70
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_maxmin_num_f32 v178, -4.0, v122, 4.0                      ; d66900b2 03daf4f7
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84351a9 a9a74fa6 3f650000
	v_dual_mul_f32 v115, v115, v165 :: v_dual_mul_f32 v114, v114, v162 ; c8c74b73 73734572
	v_maxmin_num_f32 v180, -4.0, v123, 4.0                      ; d66900b4 03daf6f7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v182, -4.0, v124, 4.0                      ; d66900b6 03daf8f7
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84359ad adab57aa 3f650000
	v_maxmin_num_f32 v184, -4.0, v125, 4.0                      ; d66900b8 03dafaf7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_dual_mul_f32 v117, v117, v169 :: v_dual_mul_f32 v116, v116, v166 ; c8c75375 75754d74
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v186, -4.0, v126, 4.0                      ; d66900ba 03dafcf7
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84361b1 b1af5fae 3f650000
	v_maxmin_num_f32 v188, -4.0, v127, 4.0                      ; d66900bc 03dafef7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_mul_f32 v119, v119, v173 :: v_dual_mul_f32 v118, v118, v170 ; c8c75b77 77775576
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84369b5 b5b367b2 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_mul_f32 v121, v121, v177 :: v_dual_mul_f32 v120, v120, v174 ; c8c76379 79795d78
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84371b9 b9b76fb6 3f650000
	v_dual_mul_f32 v123, v123, v181 :: v_dual_mul_f32 v122, v122, v178 ; c8c76b7b 7b7b657a
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84379bd bdbb77ba 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_dual_mul_f32 v125, v125, v185 :: v_dual_mul_f32 v124, v124, v182 ; c8c7737d 7d7d6d7c
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[80:81], v[14:15], 0 ; cc464068 1a021d50
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[80:81], v[16:17], 0 ; cc464070 1a022150
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[80:81], v[12:13], 0 ; cc464060 1a021950
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[88:89], v[6:7], v[104:111] ; cc464068 1da20d58
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[88:89], v[8:9], v[112:119] ; cc464070 1dc21158
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[88:89], v[4:5], v[96:103] ; cc464060 1d820958
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_maxmin_num_f32 v190, -4.0, v96, 4.0                       ; d66900be 03dac0f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v127, v127, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b7f 7fbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v97, 4.0                       ; d66900bf 03dac2f7
	v_maxmin_num_f32 v95, -4.0, v100, 4.0                       ; d669005f 03dac8f7
	v_fma_mix_f32 v21, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v21, v21, v191, 0x3f650000 :: v_dual_mul_f32 v126, v126, v186 ; c8477f15 157f757e 3f650000
	v_dual_mul_f32 v97, v97, v21 :: v_dual_mul_f32 v96, v96, v190 ; c8c62b61 61617d60
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[18:19], 0 ; cc464078 1a022550
	v_maxmin_num_f32 v81, -4.0, v98, 4.0                        ; d6690051 03dac4f7
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v101, 4.0                       ; d6690061 03dacaf7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[88:89], v[10:11], v[120:127] ; cc464078 1de21558
	v_maxmin_num_f32 v89, -4.0, v99, 4.0                        ; d6690059 03dac6f7
	v_fma_mix_f32 v88, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfea2ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v104, 4.0                      ; d6690081 03dad0f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v94, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfeb2ff 3728ab28
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v105, 4.0                      ; d6690083 03dad2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_dual_fmaak_f32 v94, v94, v89, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v88, 0x3f650000 ; c842b35e 5e50b151 3f650000
	v_maxmin_num_f32 v133, -4.0, v106, 4.0                      ; d6690085 03dad4f7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_mul_f32 v99, v99, v94 :: v_dual_mul_f32 v98, v98, v81 ; c8c6bd63 6362a362
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v102, 4.0                       ; d6690063 03daccf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430784 84850d85 3f650000
	v_maxmin_num_f32 v135, -4.0, v107, 4.0                      ; d6690087 03dad6f7
	v_maxmin_num_f32 v137, -4.0, v108, 4.0                      ; d6690089 03dad8f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c842c362 625ec15f 3f650000
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v109, 4.0                      ; d669008b 03dadaf7
	v_maxmin_num_f32 v141, -4.0, v110, 4.0                      ; d669008d 03dadcf7
	v_dual_mul_f32 v101, v101, v98 :: v_dual_mul_f32 v100, v100, v95 ; c8c6c565 6564bf64
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 ; c8430f88 88891589 3f650000
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v101, -4.0, v103, 4.0                      ; d6690065 03dacef7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v143, -4.0, v111, 4.0                      ; d669008f 03dadef7
	v_maxmin_num_f32 v145, -4.0, v112, 4.0                      ; d6690091 03dae0f7
	v_dual_mul_f32 v108, v108, v137 :: v_dual_mul_f32 v105, v105, v132 ; c8c7136c 6c690969
	v_dual_fmaak_f32 v140, v140, v139, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c843178c 8c8d1d8d 3f650000
	v_maxmin_num_f32 v147, -4.0, v113, 4.0                      ; d6690093 03dae2f7
	v_fma_mix_f32 v128, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfecaff 3728ab28
	v_fmaak_f32 v99, v99, v100, 0x3f650000                      ; 5ac6c963 3f650000
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_maxmin_num_f32 v149, -4.0, v114, 4.0                      ; d6690095 03dae4f7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_dual_mul_f32 v110, v110, v141 :: v_dual_mul_f32 v107, v107, v136 ; c8c71b6e 6e6b116b
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_dual_fmaak_f32 v128, v128, v101, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 ; c842cb80 80810581 3f650000
	v_maxmin_num_f32 v151, -4.0, v115, 4.0                      ; d6690097 03dae6f7
	v_mul_f32_e32 v102, v102, v99                               ; 10ccc766
	v_maxmin_num_f32 v153, -4.0, v116, 4.0                      ; d6690099 03dae8f7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8431f90 90912591 3f650000
	v_mul_f32_e32 v104, v104, v129                              ; 10d10368
	v_dual_mul_f32 v106, v106, v133 :: v_dual_mul_f32 v103, v103, v128 ; c8c70b6a 6a670167
	v_maxmin_num_f32 v155, -4.0, v117, 4.0                      ; d669009b 03daeaf7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v118, 4.0                      ; d669009d 03daecf7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432794 94952d95 3f650000
	v_dual_mul_f32 v112, v112, v145 :: v_dual_mul_f32 v109, v109, v140 ; c8c72370 706d196d
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v159, -4.0, v119, 4.0                      ; d669009f 03daeef7
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v120, 4.0                      ; d66900a1 03daf0f7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c8432f98 98993599 3f650000
	v_dual_mul_f32 v114, v114, v149 :: v_dual_mul_f32 v111, v111, v144 ; c8c72b72 726f216f
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v163, -4.0, v121, 4.0                      ; d66900a3 03daf2f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_lshrrev_b32_e32 v0, 4, v0                                 ; 32000084
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c843379c 9c9d3d9d 3f650000
	v_dual_mul_f32 v116, v116, v153 :: v_dual_mul_f32 v113, v113, v148 ; c8c73374 74712971
	s_mov_b64 s[40:41], s[32:33]                                ; bea80120
	s_mov_b64 s[42:43], s[34:35]                                ; beaa0122
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c8433fa0 a0a145a1 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v119, v160, v119 :: v_dual_lshlrev_b32 v0, 3, v0 ; c8e2efa0 77000083
	v_add_lshl_u32 v165, s8, v0, 2                              ; d64700a5 020a0008
	buffer_load_b128 v[96:99], v165, s[40:43], null offen       ; c405c07c 40805060 000000a5
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	buffer_load_b128 v[104:107], v165, s[40:43], null offen offset:16 ; c405c07c 40805068 000010a5
	v_maxmin_num_f32 v166, -4.0, v122, 4.0                      ; d66900a6 03daf4f7
	v_maxmin_num_f32 v168, -4.0, v123, 4.0                      ; d66900a8 03daf6f7
	v_dual_mul_f32 v118, v118, v157 :: v_dual_mul_f32 v115, v115, v152 ; c8c73b76 76733173
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_mul_f32_e32 v120, v120, v161                              ; 10f14378
	v_maxmin_num_f32 v170, -4.0, v124, 4.0                      ; d66900aa 03daf8f7
	v_maxmin_num_f32 v172, -4.0, v125, 4.0                      ; d66900ac 03dafaf7
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_mul_f32 v117, v117, v156 ; c84747a4 a4753975 3f650000
	v_maxmin_num_f32 v174, -4.0, v126, 4.0                      ; d66900ae 03dafcf7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v176, -4.0, v127, 4.0                      ; d66900b0 03dafef7
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[12:13], 0 ; cc464070 1a021952
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 :: v_dual_mul_f32 v121, v121, v164 ; c8474fa6 a6794979 3f650000
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fmaak_f32 v170, v170, v171, 0x3f650000                    ; 5b5557aa 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 ; c8435fae aead59ad 3f650000
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_mul_f32 v122, v122, v166 ; c84751a9 a97b4d7a 3f650000
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[90:91], v[4:5], v[112:119] ; cc464070 1dc2095a
	v_dual_mul_f32 v126, v126, v174 :: v_dual_mul_f32 v125, v125, v173 ; c8c75d7e 7e7d5b7d
	v_dual_mul_f32 v124, v124, v170 :: v_dual_mul_f32 v123, v123, v169 ; c8c7557c 7c7b537b
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[16:17], 0 ; cc464080 1a022152
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[82:83], v[18:19], 0 ; cc464088 1a022552
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694064
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v180, -4.0, v113, 4.0                      ; d66900b4 03dae2f7
	v_maxmin_num_f32 v182, -4.0, v114, 4.0                      ; d66900b6 03dae4f7
	v_maxmin_num_f32 v178, -4.0, v112, 4.0                      ; d66900b2 03dae0f7
	v_maxmin_num_f32 v184, -4.0, v115, 4.0                      ; d66900b8 03dae6f7
	v_maxmin_num_f32 v186, -4.0, v116, 4.0                      ; d66900ba 03dae8f7
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[90:91], v[8:9], v[128:135] ; cc464080 1e02115a
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[90:91], v[10:11], v[136:143] ; cc464088 1e22155a
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add_lshl_u32 v188, s4, v20, 2                             ; d64700bc 020a2804
	buffer_load_b128 v[8:11], v188, s[36:39], null offen        ; c405c07c 40804808 000000bc
	v_maxmin_num_f32 v189, -4.0, v117, 4.0                      ; d66900bd 03daeaf7
	v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 ; c8436fb6 b6b569b5 3f650000
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 ; c84367b2 b2b161b1 3f650000
	v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 ; c84377ba bab971b9 3f650000
	v_maxmin_num_f32 v191, -4.0, v118, 4.0                      ; d66900bf 03daecf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_dual_mul_f32 v112, v112, v178 :: v_dual_mul_f32 v127, v127, v177 ; c8c76570 707f637f
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[82:83], v[14:15], 0 ; cc464078 1a021d52
	buffer_load_b128 v[12:15], v188, s[36:39], null offen offset:512 ; c405c07c 4080480c 000200bc
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_mul_f32 v114, v114, v182 :: v_dual_mul_f32 v113, v113, v181 ; c8c76d72 72716b71
	buffer_load_b128 v[108:111], v188, s[36:39], null offen offset:1024 ; c405c07c 4080486c 000400bc
	v_dual_mul_f32 v116, v116, v186 :: v_dual_mul_f32 v115, v115, v185 ; c8c77574 74737373
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[90:91], v[6:7], v[120:127] ; cc464078 1de20d5a
	v_maxmin_num_f32 v7, -4.0, v119, 4.0                        ; d6690007 03daeef7
	v_fma_mix_f32 v16, 0xab28, |v7|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206210 0bfe0eff 3728ab28
	v_maxmin_num_f32 v19, -4.0, v121, 4.0                       ; d6690013 03daf2f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_fmaak_f32 v16, v16, v7, 0x3f650000                        ; 5a200f10 3f650000
	v_maxmin_num_f32 v17, -4.0, v120, 4.0                       ; d6690011 03daf0f7
	v_fma_mix_f32 v21, 0xab28, |v19|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfe26ff 3728ab28
	v_fma_mix_f32 v6, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206206 0bff7eff 3728ab28
	v_mul_f32_e32 v119, v119, v16                               ; 10ee2177
	v_fma_mix_f32 v18, 0xab28, |v17|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206212 0bfe22ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v17, v17, v18, 0x3f650000                       ; 5a222511 3f650000
	v_dual_fmaak_f32 v21, v21, v19, 0x3f650000 :: v_dual_mul_f32 v120, v120, v17 ; c8462715 15782378 3f650000
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v188, s[36:39], null offen offset:1536 ; c405c07c 40804810 000600bc
	buffer_load_b128 v[112:115], v188, s[36:39], null offen offset:2048 ; c405c07c 40804870 000800bc
	v_maxmin_num_f32 v82, -4.0, v122, 4.0                       ; d6690052 03daf4f7
	v_dual_fmaak_f32 v191, v191, v6, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c8420dbf bfbf7bbe 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v118, v118, v191 :: v_dual_mul_f32 v117, v117, v190 ; c8c77f76 76757d75
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[116:119], v188, s[36:39], null offen offset:2560 ; c405c07c 40804874 000a00bc
	buffer_load_b128 v[144:147], v188, s[36:39], null offen offset:3072 ; c405c07c 40804890 000c00bc
	v_maxmin_num_f32 v90, -4.0, v123, 4.0                       ; d669005a 03daf6f7
	v_maxmin_num_f32 v102, -4.0, v124, 4.0                      ; d6690066 03daf8f7
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_fmaak_f32 v82, v82, v83, 0x3f650000                       ; 5aa4a752 3f650000
	v_fmaak_f32 v91, v91, v90, 0x3f650000                       ; 5ab6b55b 3f650000
	v_fmaak_f32 v102, v102, v103, 0x3f650000                    ; 5acccf66 3f650000
	v_dual_mul_f32 v122, v122, v82 :: v_dual_mul_f32 v121, v121, v21 ; c8c6a57a 7a782b79
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_mul_f32_e32 v123, v123, v91                               ; 10f6b77b
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v125, 4.0                      ; d6690078 03dafaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v122, -4.0, v126, 4.0                      ; d669007a 03dafcf7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_dual_mul_f32 v124, v124, v102 :: v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 ; c8c2cd7c 7c78f179 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fmaak_f32 v122, v122, v123, 0x3f650000                    ; 5af4f77a 3f650000
	v_dual_mul_f32 v126, v126, v122 :: v_dual_mul_f32 v125, v125, v121 ; c8c6f57e 7e7cf37d
	buffer_load_b128 v[120:123], v188, s[36:39], null offen offset:3584 ; c405c07c 40804878 000e00bc
	v_maxmin_num_f32 v148, -4.0, v129, 4.0                      ; d6690094 03db02f7
	v_maxmin_num_f32 v150, -4.0, v130, 4.0                      ; d6690096 03db04f7
	v_maxmin_num_f32 v152, -4.0, v131, 4.0                      ; d6690098 03db06f7
	v_maxmin_num_f32 v154, -4.0, v132, 4.0                      ; d669009a 03db08f7
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v127, 4.0                      ; d669007c 03dafef7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v133, 4.0                      ; d669009c 03db0af7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v125, v125, v124, 0x3f650000                    ; 5afaf97d 3f650000
	v_mul_f32_e32 v127, v127, v125                              ; 10fefb7f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v128, 4.0                      ; d669007e 03db00f7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v126, v126, v127, 0x3f650000                    ; 5afcff7e 3f650000
	v_mul_f32_e32 v128, v128, v126                              ; 1100fd80
	v_maxmin_num_f32 v158, -4.0, v134, 4.0                      ; d669009e 03db0cf7
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c8432f96 96952995 3f650000
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 ; c843379a 9a993199 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_mul_f32 v130, v130, v150 :: v_dual_mul_f32 v129, v129, v149 ; c8c72d82 82812b81
	v_dual_mul_f32 v132, v132, v154 :: v_dual_mul_f32 v131, v131, v153 ; c8c73584 84833383
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[124:127], v165, s[40:43], null offen offset:64 ; c405c07c 4080507c 000040a5
	buffer_load_b128 v[128:131], v165, s[40:43], null offen offset:80 ; c405c07c 40805080 000050a5
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v135, 4.0                      ; d66900a0 03db0ef7
	v_maxmin_num_f32 v162, -4.0, v136, 4.0                      ; d66900a2 03db10f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v137, 4.0                      ; d66900a4 03db12f7
	v_maxmin_num_f32 v166, -4.0, v138, 4.0                      ; d66900a6 03db14f7
	v_maxmin_num_f32 v168, -4.0, v139, 4.0                      ; d66900a8 03db16f7
	v_maxmin_num_f32 v170, -4.0, v140, 4.0                      ; d66900aa 03db18f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c8433f9e 9e9d399d 3f650000
	v_maxmin_num_f32 v172, -4.0, v141, 4.0                      ; d66900ac 03db1af7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fmaak_f32 v161, v161, v160, 0x3f650000                    ; 5b4341a1 3f650000
	v_maxmin_num_f32 v174, -4.0, v142, 4.0                      ; d66900ae 03db1cf7
	v_maxmin_num_f32 v176, -4.0, v143, 4.0                      ; d66900b0 03db1ef7
	v_dual_mul_f32 v134, v134, v158 :: v_dual_mul_f32 v133, v133, v157 ; c8c73d86 86853b85
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84349a5 a5a347a2 3f650000
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84351a9 a9a74fa6 3f650000
	v_cvt_pk_f32_fp8_e32 v[102:103], v22                        ; 7eccdd16
	v_mul_f32_e32 v135, v135, v161                              ; 110f4387
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84359ad adab57aa 3f650000
	v_dual_mul_f32 v137, v137, v165 :: v_dual_mul_f32 v136, v136, v162 ; c8c74b89 89894588
	v_dual_mul_f32 v139, v139, v169 :: v_dual_mul_f32 v138, v138, v166 ; c8c7538b 8b8b4d8a
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84361b1 b1af5fae 3f650000
	v_dual_mul_f32 v141, v141, v173 :: v_dual_mul_f32 v140, v140, v170 ; c8c75b8d 8d8d558c
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_dual_mul_f32 v137, v103, v97 :: v_dual_mul_f32 v136, v102, v96 ; c8c6c367 8988c166
	v_cvt_pk_f32_fp8_e32 v[102:103], v150                       ; 7eccdd96
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v143, v143, v177 :: v_dual_mul_f32 v142, v142, v174 ; c8c7638f 8f8f5d8e
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
	v_dual_mul_f32 v139, v103, v99 :: v_dual_mul_f32 v138, v102, v98 ; c8c6c767 8b8ac566
	v_cvt_pk_f32_fp8_e32 v[102:103], v23                        ; 7eccdd17
	v_cvt_pk_f32_fp8_e32 v[22:23], v151                         ; 7e2cdd97
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_dual_mul_f32 v141, v103, v105 :: v_dual_mul_f32 v140, v102, v104 ; c8c6d367 8d8cd166
	v_dual_mul_f32 v143, v23, v107 :: v_dual_mul_f32 v142, v22, v106 ; c8c6d717 8f8ed516
	v_cvt_pk_f32_fp8_e32 v[22:23], v50                          ; 7e2cdd32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v153, v23, v97 :: v_dual_mul_f32 v152, v22, v96 ; c8c6c317 9998c116
	v_cvt_pk_f32_fp8_e32 v[22:23], v178                         ; 7e2cddb2
	v_dual_mul_f32 v155, v23, v99 :: v_dual_mul_f32 v154, v22, v98 ; c8c6c717 9b9ac516
	v_cvt_pk_f32_fp8_e32 v[22:23], v51                          ; 7e2cdd33
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v157, v23, v105 :: v_dual_mul_f32 v156, v22, v104 ; c8c6d317 9d9cd116
	v_cvt_pk_f32_fp8_e32 v[22:23], v179                         ; 7e2cddb3
	v_dual_mul_f32 v159, v23, v107 :: v_dual_mul_f32 v158, v22, v106 ; c8c6d717 9f9ed516
	v_cvt_pk_f32_fp8_e32 v[22:23], v54                          ; 7e2cdd36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v161, v23, v97 :: v_dual_mul_f32 v160, v22, v96 ; c8c6c317 a1a0c116
	v_cvt_pk_f32_fp8_e32 v[22:23], v182                         ; 7e2cddb6
	v_dual_mul_f32 v163, v23, v99 :: v_dual_mul_f32 v162, v22, v98 ; c8c6c717 a3a2c516
	v_cvt_pk_f32_fp8_e32 v[22:23], v55                          ; 7e2cdd37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v165, v23, v105 :: v_dual_mul_f32 v164, v22, v104 ; c8c6d317 a5a4d116
	v_cvt_pk_f32_fp8_e32 v[22:23], v183                         ; 7e2cddb7
	v_dual_mul_f32 v167, v23, v107 :: v_dual_mul_f32 v166, v22, v106 ; c8c6d717 a7a6d516
	v_cvt_pk_f32_fp8_e32 v[22:23], v58                          ; 7e2cdd3a
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[8:9], v[26:27], v[152:159] ; cc464098 1e623508
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[8:9], v[24:25], v[136:143] ; cc464088 1e223108
	v_dual_mul_f32 v169, v23, v97 :: v_dual_mul_f32 v168, v22, v96 ; c8c6c317 a9a8c116
	v_cvt_pk_f32_fp8_e32 v[22:23], v186                         ; 7e2cddba
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[8:9], v[28:29], v[160:167] ; cc4640a0 1e823908
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v178, s5, v20, 2                             ; d64700b2 020a2805
	v_dual_mul_f32 v171, v23, v99 :: v_dual_mul_f32 v170, v22, v98 ; c8c6c717 abaac516
	buffer_load_b128 v[96:99], v178, s[36:39], null offen       ; c405c07c 40804860 000000b2
	v_cvt_pk_f32_fp8_e32 v[22:23], v59                          ; 7e2cdd3b
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[12:13], v[64:65], v[152:159] ; cc464098 1e62810c
	v_dual_mul_f32 v173, v23, v105 :: v_dual_mul_f32 v172, v22, v104 ; c8c6d317 adacd116
	v_cvt_pk_f32_fp8_e32 v[22:23], v187                         ; 7e2cddbb
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v175, v23, v107 :: v_dual_mul_f32 v174, v22, v106 ; c8c6d717 afaed516
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[8:9], v[62:63], v[168:175] ; cc4640a8 1ea27d08
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[104:107], v178, s[36:39], null offen offset:1024 ; c405c07c 40804868 000400b2
	buffer_load_b128 v[132:135], v178, s[36:39], null offen offset:2048 ; c405c07c 40804884 000800b2
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[12:13], v[30:31], v[136:143] ; cc464088 1e223d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[66:67], v[160:167] ; cc4640a0 1e82850c
	buffer_load_b128 v[148:151], v178, s[36:39], null offen offset:512 ; c405c07c 40804894 000200b2
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[36:37], v[152:159] ; cc464098 1e62496c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[12:13], v[68:69], v[168:175] ; cc4640a8 1ea2890c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[32:33], v[136:143] ; cc464088 1e22416c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[108:109], v[70:71], v[160:167] ; cc4640a0 1e828d6c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[38:39], v[152:159] ; cc464098 1e624d10
	buffer_load_b128 v[180:183], v178, s[36:39], null offen offset:1536 ; c405c07c 408048b4 000600b2
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[108:109], v[72:73], v[168:175] ; cc4640a8 1ea2916c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[16:17], v[34:35], v[136:143] ; cc464088 1e224510
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[74:75], v[160:167] ; cc4640a0 1e829510
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[44:45], v[152:159] ; cc464098 1e625970
	buffer_load_b128 v[176:179], v178, s[36:39], null offen offset:2560 ; c405c07c 408048b0 000a00b2
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[16:17], v[76:77], v[168:175] ; cc4640a8 1ea29910
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[40:41], v[136:143] ; cc464088 1e225170
	v_cvt_pk_f32_fp8_e32 v[50:51], v48                          ; 7e64dd30
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[112:113], v[78:79], v[160:167] ; cc4640a0 1e829d70
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[46:47], v[152:159] ; cc464098 1e625d74
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[112:113], v[84:85], v[168:175] ; cc4640a8 1ea2a970
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[116:117], v[42:43], v[136:143] ; cc464088 1e225574
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[116:117], v[86:87], v[160:167] ; cc4640a0 1e82ad74
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[144:145], v[88:89], v[152:159] ; cc464098 1e62b190
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[116:117], v[92:93], v[168:175] ; cc4640a8 1ea2b974
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mul_f32 v185, v51, v125 :: v_dual_mul_f32 v184, v50, v124 ; c8c6fb33 b9b8f932
	v_cvt_pk_f32_fp8_e32 v[50:51], v176                         ; 7e64ddb0
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[144:145], v[80:81], v[136:143] ; cc464088 1e22a190
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[144:145], v[94:95], v[160:167] ; cc4640a0 1e82bd90
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[120:121], v[6:7], v[152:159] ; cc464098 1e620d78
	v_dual_mul_f32 v187, v51, v127 :: v_dual_mul_f32 v186, v50, v126 ; c8c6ff33 bbbafd32
	v_cvt_pk_f32_fp8_e32 v[50:51], v49                          ; 7e64dd31
	v_cvt_pk_f32_fp8_e32 v[48:49], v177                         ; 7e60ddb1
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[144:145], v[100:101], v[168:175] ; cc4640a8 1ea2c990
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[120:121], v[4:5], v[136:143] ; cc464088 1e220978
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[120:121], v[82:83], v[160:167] ; cc4640a0 1e82a578
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v189, v51, v129 :: v_dual_mul_f32 v188, v50, v128 ; c8c70333 bdbd0132
	v_dual_mul_f32 v191, v49, v131 :: v_dual_mul_f32 v190, v48, v130 ; c8c70731 bfbf0530
	v_cvt_pk_f32_fp8_e32 v[48:49], v52                          ; 7e60dd34
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[120:121], v[90:91], v[168:175] ; cc4640a8 1ea2b578
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_cvt_pk_f32_fp8_e32 v[50:51], v180                         ; 7e64ddb4
	v_dual_mul_f32 v49, v49, v125 :: v_dual_mul_f32 v48, v48, v124 ; c8c6fb31 3130f930
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	s_bitset0_b32 s33, 14                                       ; bea1108e
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_buffer_load_b32 s10, s[32:35], s10 offset:0x0             ; f4020290 14000000
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_cvt_pk_f32_fp8_e32 v[54:55], v53                          ; 7e6cdd35
	v_cvt_pk_f32_fp8_e32 v[58:59], v181                         ; 7e74ddb5
	v_cvt_pk_f32_fp8_e32 v[102:103], v56                        ; 7eccdd38
	v_cvt_pk_f32_fp8_e32 v[108:109], v184                       ; 7ed8ddb8
	v_dual_mul_f32 v51, v51, v127 :: v_dual_mul_f32 v50, v50, v126 ; c8c6ff33 3332fd32
	v_cvt_pk_f32_fp8_e32 v[112:113], v57                        ; 7ee0dd39
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_cvt_pk_f32_fp8_e32 v[56:57], v185                         ; 7e70ddb9
	v_cvt_pk_f32_fp8_e32 v[116:117], v60                        ; 7ee8dd3c
	v_cvt_pk_f32_fp8_e32 v[120:121], v188                       ; 7ef0ddbc
	v_dual_mul_f32 v55, v55, v129 :: v_dual_mul_f32 v52, v54, v128 ; c8c70337 37350136
	v_dual_mul_f32 v59, v59, v131 :: v_dual_mul_f32 v54, v58, v130 ; c8c7073b 3b37053a
	v_dual_mul_f32 v103, v103, v125 :: v_dual_mul_f32 v102, v102, v124 ; c8c6fb67 6766f966
	v_mul_f32_e32 v109, v109, v127                              ; 10daff6d
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[10:11], v[24:25], v[184:191] ; cc4640b8 1ee2310a
	v_mul_f32_e32 v113, v113, v129                              ; 10e30371
	v_dual_mul_f32 v57, v57, v131 :: v_dual_mul_f32 v108, v108, v126 ; c8c70739 396cfd6c
	v_dual_mul_f32 v117, v117, v125 :: v_dual_mul_f32 v112, v112, v128 ; c8c6fb75 75710170
	v_dual_mul_f32 v121, v121, v127 :: v_dual_mul_f32 v116, v116, v124 ; c8c6ff79 7974f974
	v_cvt_pk_f32_fp8_e32 v[124:125], v61                        ; 7ef8dd3d
	v_cvt_pk_f32_fp8_e32 v[60:61], v189                         ; 7e78ddbd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_dual_mul_f32 v125, v125, v129 :: v_dual_mul_f32 v56, v56, v130 ; c8c7037d 7d390538
	v_dual_mov_b32 v53, v55 :: v_dual_mul_f32 v124, v124, v128  ; ca060137 357d017c
	v_dual_mul_f32 v127, v61, v131 :: v_dual_mul_f32 v120, v120, v126 ; c8c7073d 7f78fd78
	v_dual_mov_b32 v55, v59 :: v_dual_mul_f32 v126, v60, v130   ; ca06013b 377f053c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[10:11], v[26:27], v[48:55] ; cc464030 1cc2350a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[14:15], v[30:31], v[184:191] ; cc4640b8 1ee23d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[14:15], v[64:65], v[48:55] ; cc464030 1cc2810e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[32:33], v[184:191] ; cc4640b8 1ee2416e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mov_b32 v27, v107 :: v_dual_mov_b32 v26, v106        ; ca10016b 1b1a016a
	v_dual_mov_b32 v107, v113 :: v_dual_mov_b32 v106, v112      ; ca100171 6b6a0170
	v_dual_mov_b32 v25, v105 :: v_dual_mov_b32 v24, v104        ; ca100169 19180168
	v_dual_mov_b32 v105, v109 :: v_dual_mov_b32 v104, v108      ; ca10016d 6968016c
	v_dual_mov_b32 v109, v57 :: v_dual_mov_b32 v108, v56        ; ca100139 6d6c0138
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[110:111], v[36:37], v[48:55] ; cc464030 1cc2496e
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[10:11], v[28:29], v[102:109] ; cc464066 1d9a390a
	v_dual_mov_b32 v21, v122 :: v_dual_mov_b32 v28, v123        ; ca10017a 151c017b
	v_dual_mov_b32 v123, v121 :: v_dual_mov_b32 v122, v120      ; ca100179 7b7a0178
	v_dual_mov_b32 v121, v117 :: v_dual_mov_b32 v120, v116      ; ca100175 79780174
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[18:19], v[34:35], v[184:191] ; cc4640b8 1ee24512
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[18:19], v[38:39], v[48:55] ; cc464030 1cc24d12
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[62:63], v[120:127] ; cc464078 1de27d0a
	v_dual_mov_b32 v11, v28 :: v_dual_mov_b32 v10, v21          ; ca10011c 0b0a0115
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[14:15], v[66:67], v[102:109] ; cc464066 1d9a850e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[40:41], v[184:191] ; cc4640b8 1ee25172
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[114:115], v[44:45], v[48:55] ; cc464030 1cc25972
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[68:69], v[120:127] ; cc464078 1de2890e
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[110:111], v[70:71], v[102:109] ; cc464066 1d9a8d6e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[42:43], v[184:191] ; cc4640b8 1ee25576
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[26:27], v[8:9], 0   ; cc464040 1a02111a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[118:119], v[46:47], v[48:55] ; cc464030 1cc25d76
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[98:99], v[8:9], 0   ; cc464028 1a021162
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[110:111], v[72:73], v[120:127] ; cc464078 1de2916e
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[18:19], v[74:75], v[102:109] ; cc464066 1d9a9512
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[146:147], v[80:81], v[184:191] ; cc4640b8 1ee2a192
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[146:147], v[88:89], v[48:55] ; cc464030 1cc2b192
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[76:77], v[120:127] ; cc464078 1de29912
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[114:115], v[78:79], v[102:109] ; cc464066 1d9a9d72
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[10:11], v[4:5], v[184:191] ; cc4640b8 1ee2090a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[10:11], v[6:7], v[48:55] ; cc464030 1cc20d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[114:115], v[84:85], v[120:127] ; cc464078 1de2a972
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[96:97], v[8:9], 0   ; cc464020 1a021160
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[118:119], v[86:87], v[102:109] ; cc464066 1d9aad76
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[8:9], 0   ; cc464038 1a021118
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[118:119], v[92:93], v[120:127] ; cc464078 1de2b976
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[146:147], v[94:95], v[102:109] ; cc464066 1d9abd92
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[150:151], v[4:5], v[40:47] ; cc464028 1ca20996
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[148:149], v[4:5], v[32:39] ; cc464020 1c820994
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[182:183], v[4:5], v[64:71] ; cc464040 1d0209b6
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[180:181], v[4:5], v[56:63] ; cc464038 1ce209b4
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[146:147], v[100:101], v[120:127] ; cc464078 1de2c992
	v_wmma_f32_16x16x16_fp8_fp8 v[102:109], v[10:11], v[82:83], v[102:109] ; cc464066 1d9aa50a
	v_dual_mul_f32 v88, v67, v67 :: v_dual_mul_f32 v29, v41, v41 ; c8c68743 581c5329
	v_dual_mul_f32 v31, v43, v43 :: v_dual_mul_f32 v30, v65, v65 ; c8c6572b 1f1e8341
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[132:133], 0 ; cc464048 1a030908
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[134:135], 0 ; cc464050 1a030d08
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[90:91], v[120:127] ; cc464078 1de2b50a
	v_dual_fmac_f32 v88, v59, v59 :: v_dual_fmac_f32 v29, v33, v33 ; c800773b 581c4321
	v_dual_fmac_f32 v31, v35, v35 :: v_dual_fmac_f32 v30, v57, v57 ; c8004723 1f1e7339
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[4:5], v[176:177], v[72:79] ; cc464048 1d236104
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[4:5], v[178:179], v[80:87] ; cc464050 1d436504
	v_dual_fmac_f32 v88, v63, v63 :: v_dual_fmac_f32 v29, v37, v37 ; c8007f3f 581c4b25
	v_dual_fmac_f32 v31, v39, v39 :: v_dual_fmac_f32 v30, v61, v61 ; c8004f27 1f1e7b3d
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s28, 0x76543210                                   ; be9c00ff 76543210
	s_mov_b32 s30, 0xfedcba98                                   ; be9e00ff fedcba98
	v_dual_fmac_f32 v88, v71, v71 :: v_dual_fmac_f32 v29, v45, v45 ; c8008f47 581c5b2d
	s_movk_i32 s31, 0x410                                       ; b01f0410
	v_dual_fmac_f32 v31, v47, v47 :: v_dual_fmac_f32 v30, v69, v69 ; c8005f2f 1f1e8b45
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v88, v58, v58 :: v_dual_fmac_f32 v29, v32, v32 ; c800753a 581c4120
	v_dual_fmac_f32 v30, v56, v56 :: v_dual_fmac_f32 v31, v34, v34 ; c8007138 1e1e4522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v88, v66, v66 :: v_dual_fmac_f32 v29, v40, v40 ; c8008542 581c5128
	v_dual_fmac_f32 v30, v64, v64 :: v_dual_fmac_f32 v31, v42, v42 ; c8008140 1e1e552a
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v88, v62, v62 :: v_dual_fmac_f32 v29, v36, v36 ; c8007d3e 581c4924
	v_dual_fmac_f32 v30, v60, v60 :: v_dual_fmac_f32 v31, v38, v38 ; c800793c 1e1e4d26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v88, v70, v70 :: v_dual_fmac_f32 v29, v44, v44 ; c8008d46 581c592c
	v_dual_fmac_f32 v30, v68, v68 :: v_dual_fmac_f32 v31, v46, v46 ; c8008944 1e1e5d2e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v89, 1.0, v29, v31                          ; cc210059 047e3af2
	v_fma_mixhi_f16 v89, 1.0, v30, v88                          ; cc220059 05623cf2
	v_permlanex16_b32 v90, v89, s28, s30 op_sel:[1,1]           ; d65c185a 00783959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0059
	v_min_num_f64_e32 v[1:2], v[89:90], v[90:91]                ; 1a02b559
(invalid instruction)                                        ; cc1c0059
	v_subrev_f32_e32 v0, v89, v31                               ; 0a003f59
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v91, v89                                  ; 7eb61759
	v_cvt_f32_f16_e32 v89, v217/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eb217d9
	v_rsq_f32_e32 v91, v91                                      ; 7eb65d5b
	v_rsq_f32_e32 v89, v89                                      ; 7eb25d59
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_mul_f32_e32 v91, s10, v91                                 ; 10b6b60a
	v_dual_mul_f32 v59, v59, v89 :: v_dual_mul_f32 v58, v58, v89 ; c8c6b33b 3b3ab33a
	v_dual_mul_f32 v61, v61, v89 :: v_dual_mul_f32 v60, v60, v89 ; c8c6b33d 3d3cb33c
	v_dual_mul_f32 v63, v63, v89 :: v_dual_mul_f32 v62, v62, v89 ; c8c6b33f 3f3eb33e
	v_dual_mul_f32 v57, v57, v89 :: v_dual_mul_f32 v56, v56, v89 ; c8c6b339 3938b338
	v_dual_mul_f32 v37, v37, v91 :: v_dual_mul_f32 v36, v36, v91 ; c8c6b725 2524b724
	v_dual_mul_f32 v45, v45, v91 :: v_dual_mul_f32 v44, v44, v91 ; c8c6b72d 2d2cb72c
	v_dual_mul_f32 v41, v41, v91 :: v_dual_mul_f32 v40, v40, v91 ; c8c6b729 2928b728
	v_dual_mul_f32 v32, v32, v91 :: v_dual_mul_f32 v33, v33, v91 ; c8c6b720 2020b721
	v_dual_mul_f32 v65, v65, v89 :: v_dual_mul_f32 v64, v64, v89 ; c8c6b341 4140b340
	v_dual_mul_f32 v43, v43, v91 :: v_dual_mul_f32 v42, v42, v91 ; c8c6b72b 2b2ab72a
	v_dual_mul_f32 v47, v47, v91 :: v_dual_mul_f32 v46, v46, v91 ; c8c6b72f 2f2eb72e
	v_dual_mul_f32 v39, v39, v91 :: v_dual_mul_f32 v38, v38, v91 ; c8c6b727 2726b726
	v_dual_mul_f32 v34, v34, v91 :: v_dual_mul_f32 v35, v35, v91 ; c8c6b722 2222b723
	v_dual_mul_f32 v67, v67, v89 :: v_dual_mul_f32 v66, v66, v89 ; c8c6b343 4342b342
	v_dual_mul_f32 v69, v69, v89 :: v_dual_mul_f32 v68, v68, v89 ; c8c6b345 4544b344
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	v_lshl_add_u32 v92, v2, 5, v1                               ; d646005c 04050b02
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	v_dual_mul_f32 v71, v71, v89 :: v_dual_mul_f32 v70, v70, v89 ; c8c6b347 4746b346
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v92, v[8:9], v[30:31] offset1:2          ; d9380200 001e085c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[98:99], v[12:13], 0 ; cc464028 1a021962
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[26:27], v[12:13], 0 ; cc464040 1a02191a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[96:97], v[12:13], 0 ; cc464020 1a021960
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[12:13], 0 ; cc464038 1a021918
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[12:13], v[132:133], 0 ; cc464048 1a03090c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[150:151], v[6:7], v[40:47] ; cc464028 1ca20d96
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[134:135], 0 ; cc464050 1a030d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[182:183], v[6:7], v[64:71] ; cc464040 1d020db6
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[148:149], v[6:7], v[32:39] ; cc464020 1c820d94
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[180:181], v[6:7], v[56:63] ; cc464038 1ce20db4
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[6:7], v[176:177], v[72:79] ; cc464048 1d236106
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[6:7], v[178:179], v[80:87] ; cc464050 1d436506
	v_dual_mul_f32 v100, v67, v67 :: v_dual_mul_f32 v93, v41, v41 ; c8c68743 645c5329
	v_dual_mul_f32 v95, v43, v43 :: v_dual_mul_f32 v94, v65, v65 ; c8c6572b 5f5e8341
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v100, v59, v59 :: v_dual_fmac_f32 v93, v33, v33 ; c800773b 645c4321
	v_dual_fmac_f32 v95, v35, v35 :: v_dual_fmac_f32 v94, v57, v57 ; c8004723 5f5e7339
	v_dual_fmac_f32 v100, v63, v63 :: v_dual_fmac_f32 v93, v37, v37 ; c8007f3f 645c4b25
	v_dual_fmac_f32 v95, v39, v39 :: v_dual_fmac_f32 v94, v61, v61 ; c8004f27 5f5e7b3d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v100, v71, v71 :: v_dual_fmac_f32 v93, v45, v45 ; c8008f47 645c5b2d
	v_dual_fmac_f32 v95, v47, v47 :: v_dual_fmac_f32 v94, v69, v69 ; c8005f2f 5f5e8b45
	v_dual_fmac_f32 v100, v58, v58 :: v_dual_fmac_f32 v93, v32, v32 ; c800753a 645c4120
	v_dual_fmac_f32 v94, v56, v56 :: v_dual_fmac_f32 v95, v34, v34 ; c8007138 5e5e4522
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v100, v66, v66 :: v_dual_fmac_f32 v93, v40, v40 ; c8008542 645c5128
	v_dual_fmac_f32 v94, v64, v64 :: v_dual_fmac_f32 v95, v42, v42 ; c8008140 5e5e552a
	v_dual_fmac_f32 v100, v62, v62 :: v_dual_fmac_f32 v93, v36, v36 ; c8007d3e 645c4924
	v_dual_fmac_f32 v94, v60, v60 :: v_dual_fmac_f32 v95, v38, v38 ; c800793c 5e5e4d26
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v100, v70, v70 :: v_dual_fmac_f32 v93, v44, v44 ; c8008d46 645c592c
	v_dual_fmac_f32 v94, v68, v68 :: v_dual_fmac_f32 v95, v46, v46 ; c8008944 5e5e5d2e
	v_fma_mixlo_f16 v101, 1.0, v93, v95                         ; cc210065 057ebaf2
	v_fma_mixhi_f16 v101, 1.0, v94, v100                        ; cc220065 0592bcf2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v110, v101, s28, s30 op_sel:[1,1]         ; d65c186e 00783965
(invalid instruction)                                        ; cc0f0065
	v_min_num_f64_e32 v[1:2], v[101:102], v[110:111]            ; 1a02dd65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v31                              ; 0a003f65
	v_cvt_f32_f16_e32 v111, v101                                ; 7ede1765
	v_cvt_f32_f16_e32 v101, v229/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eca17e5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v111, v111                                    ; 7ede5d6f
	v_rsq_f32_e32 v101, v101                                    ; 7eca5d65
	v_mul_f32_e32 v111, s10, v111                               ; 10dede0a
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v63, v63, v101 :: v_dual_mul_f32 v62, v62, v101 ; c8c6cb3f 3f3ecb3e
	v_dual_mul_f32 v59, v59, v101 :: v_dual_mul_f32 v58, v58, v101 ; c8c6cb3b 3b3acb3a
	v_dual_mul_f32 v61, v61, v101 :: v_dual_mul_f32 v60, v60, v101 ; c8c6cb3d 3d3ccb3c
	v_dual_mul_f32 v57, v57, v101 :: v_dual_mul_f32 v56, v56, v101 ; c8c6cb39 3938cb38
	v_dual_mul_f32 v32, v32, v111 :: v_dual_mul_f32 v33, v33, v111 ; c8c6df20 2020df21
	v_dual_mul_f32 v41, v41, v111 :: v_dual_mul_f32 v40, v40, v111 ; c8c6df29 2928df28
	v_dual_mul_f32 v36, v36, v111 :: v_dual_mul_f32 v37, v37, v111 ; c8c6df24 2424df25
	v_dual_mul_f32 v65, v65, v101 :: v_dual_mul_f32 v64, v64, v101 ; c8c6cb41 4140cb40
	v_dual_mul_f32 v43, v43, v111 :: v_dual_mul_f32 v42, v42, v111 ; c8c6df2b 2b2adf2a
	v_dual_mul_f32 v34, v34, v111 :: v_dual_mul_f32 v35, v35, v111 ; c8c6df22 2222df23
	v_dual_mul_f32 v45, v45, v111 :: v_dual_mul_f32 v44, v44, v111 ; c8c6df2d 2d2cdf2c
	v_dual_mul_f32 v47, v47, v111 :: v_dual_mul_f32 v46, v46, v111 ; c8c6df2f 2f2edf2e
	v_dual_mul_f32 v39, v39, v111 :: v_dual_mul_f32 v38, v38, v111 ; c8c6df27 2726df26
	v_dual_mul_f32 v67, v67, v101 :: v_dual_mul_f32 v66, v66, v101 ; c8c6cb43 4342cb42
	v_dual_mul_f32 v69, v69, v101 :: v_dual_mul_f32 v68, v68, v101 ; c8c6cb45 4544cb44
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
	v_dual_mul_f32 v71, v71, v101 :: v_dual_mul_f32 v70, v70, v101 ; c8c6cb47 4746cb46
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v92, v[12:13], v[34:35] offset0:64 offset1:66 ; d9384240 00220c5c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[98:99], v[16:17], 0 ; cc464038 1a022162
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[16:17], 0 ; cc464048 1a02211a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[96:97], v[16:17], 0 ; cc464028 1a022160
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[16:17], 0 ; cc464040 1a022118
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[132:133], 0 ; cc464050 1a030910
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[150:151], v[10:11], v[56:63] ; cc464038 1ce21596
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[134:135], 0 ; cc464070 1a030d10
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[182:183], v[10:11], v[72:79] ; cc464048 1d2215b6
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[148:149], v[10:11], v[40:47] ; cc464028 1ca21594
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[180:181], v[10:11], v[64:71] ; cc464040 1d0215b4
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[10:11], v[176:177], v[80:87] ; cc464050 1d43610a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[178:179], v[112:119] ; cc464070 1dc3650a
	v_dual_mul_f32 v131, v75, v75 :: v_dual_mul_f32 v128, v57, v57 ; c8c6974b 83807339
	v_dual_mul_f32 v130, v59, v59 :: v_dual_mul_f32 v129, v73, v73 ; c8c6773b 82809349
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v131, v67, v67 :: v_dual_fmac_f32 v128, v41, v41 ; c8008743 83805329
	v_dual_fmac_f32 v130, v43, v43 :: v_dual_fmac_f32 v129, v65, v65 ; c800572b 82808341
	v_dual_fmac_f32 v131, v71, v71 :: v_dual_fmac_f32 v128, v45, v45 ; c8008f47 83805b2d
	v_dual_fmac_f32 v130, v47, v47 :: v_dual_fmac_f32 v129, v69, v69 ; c8005f2f 82808b45
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v131, v79, v79 :: v_dual_fmac_f32 v128, v61, v61 ; c8009f4f 83807b3d
	v_dual_fmac_f32 v130, v63, v63 :: v_dual_fmac_f32 v129, v77, v77 ; c8007f3f 82809b4d
	v_dual_fmac_f32 v131, v66, v66 :: v_dual_fmac_f32 v128, v40, v40 ; c8008542 83805128
	v_dual_fmac_f32 v129, v64, v64 :: v_dual_fmac_f32 v130, v42, v42 ; c8008140 8182552a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v131, v74, v74 :: v_dual_fmac_f32 v128, v56, v56 ; c800954a 83807138
	v_dual_fmac_f32 v129, v72, v72 :: v_dual_fmac_f32 v130, v58, v58 ; c8009148 8182753a
	v_dual_fmac_f32 v131, v70, v70 :: v_dual_fmac_f32 v128, v44, v44 ; c8008d46 8380592c
	v_dual_fmac_f32 v129, v68, v68 :: v_dual_fmac_f32 v130, v46, v46 ; c8008944 81825d2e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v131, v78, v78 :: v_dual_fmac_f32 v128, v60, v60 ; c8009d4e 8380793c
	v_dual_fmac_f32 v129, v76, v76 :: v_dual_fmac_f32 v130, v62, v62 ; c800994c 81827d3e
	v_fma_mixlo_f16 v144, 1.0, v128, v130                       ; cc210090 060b00f2
	v_fma_mixhi_f16 v144, 1.0, v129, v131                       ; cc220090 060f02f2
	v_lshl_add_u32 v2, v2, 6, s7                                ; d6460002 001d0d02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v145, v144, s28, s30 op_sel:[1,1]         ; d65c1891 00783990
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
(invalid instruction)                                        ; cc0f0090
	v_min_num_f64_e32 v[1:2], v[144:145], v[145:146]            ; 1a032390
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0090
	v_subrev_f32_e32 v0, v144, v31                              ; 0a003f90
(invalid instruction)                                        ; d58b0092
	v_cndmask_b32_e32 v0, v144, v128, vcc_lo                    ; 02010190
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v146, v146                                    ; 7f245d92
	v_mul_f32_e32 v146, s10, v146                               ; 1125240a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v41, v41, v146 :: v_dual_mul_f32 v40, v40, v146 ; c8c72529 29292528
	v_dual_mul_f32 v43, v43, v146 :: v_dual_mul_f32 v42, v42, v146 ; c8c7252b 2b2b252a
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[36:39], v2, s[40:43], null offen         ; c405c07c 40805024 00000002
	buffer_load_b128 v[40:43], v2, s[40:43], null offen offset:16 ; c405c07c 40805028 00001002
(invalid instruction)                                        ; d58b0890
	v_cndmask_b32_e32 v0, v144, v128, vcc_lo                    ; 02010190
	v_dual_mul_f32 v45, v45, v146 :: v_dual_mul_f32 v44, v44, v146 ; c8c7252d 2d2d252c
	v_dual_mul_f32 v47, v47, v146 :: v_dual_mul_f32 v46, v46, v146 ; c8c7252f 2f2f252e
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_rsq_f32_e32 v144, v144                                    ; 7f205d90
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a5
	v_dual_mul_f32 v67, v67, v144 :: v_dual_mul_f32 v66, v66, v144 ; c8c72143 43432142
	v_dual_mul_f32 v65, v65, v144 :: v_dual_mul_f32 v64, v64, v144 ; c8c72141 41412140
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v2, s[40:43], null offen offset:4096 ; c405c07c 4080502c 00100002
	buffer_load_b128 v[64:67], v2, s[40:43], null offen offset:4112 ; c405c07c 40805040 00101002
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mul_f32_e32 v56, v56, v146                                ; 10712538
	v_mul_f32_e32 v57, v57, v146                                ; 10732539
	v_dual_mul_f32 v61, v61, v146 :: v_dual_mul_f32 v60, v60, v146 ; c8c7253d 3d3d253c
	v_dual_mul_f32 v59, v59, v146 :: v_dual_mul_f32 v58, v58, v146 ; c8c7253b 3b3b253a
	v_dual_mul_f32 v69, v69, v144 :: v_dual_mul_f32 v68, v68, v144 ; c8c72145 45452144
	v_dual_mul_f32 v71, v71, v144 :: v_dual_mul_f32 v70, v70, v144 ; c8c72147 47472146
	v_dual_mul_f32 v63, v63, v146 :: v_dual_mul_f32 v62, v62, v146 ; c8c7253f 3f3f253e
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v2, s[40:43], null offen offset:8192 ; c405c07c 4080503c 00200002
	buffer_load_b128 v[68:71], v2, s[40:43], null offen offset:8208 ; c405c07c 40805044 00201002
	v_dual_mul_f32 v73, v73, v144 :: v_dual_mul_f32 v72, v72, v144 ; c8c72149 49492148
	v_dual_mul_f32 v75, v75, v144 :: v_dual_mul_f32 v74, v74, v144 ; c8c7214b 4b4b214a
	v_dual_mul_f32 v77, v77, v144 :: v_dual_mul_f32 v76, v76, v144 ; c8c7214d 4d4d214c
	v_dual_mul_f32 v79, v79, v144 :: v_dual_mul_f32 v78, v78, v144 ; c8c7214f 4f4f214e
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v92, v[16:17], v[58:59] offset0:128 offset1:130 ; d9388280 003a105c
	v_dual_mov_b32 v88, v126 :: v_dual_mov_b32 v147, v20        ; ca10017e 58920114
	v_dual_mov_b32 v59, v23 :: v_dual_mov_b32 v58, v22          ; ca100117 3b3a0116
	v_mov_b32_e32 v91, v108                                     ; 7eb6036c
	v_mov_b32_e32 v93, v109                                     ; 7eba036d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mov_b32 v90, v147 :: v_dual_mov_b32 v89, v127        ; ca100193 5a58017f
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[144:147], v2, s[40:43], null offen offset:12288 ; c405c07c 40805090 00300002
	buffer_load_b128 v[108:111], v2, s[40:43], null offen offset:12304 ; c405c07c 4080506c 00301002
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[96:97], v[22:23], 0 ; cc464048 1a022d60
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[98:99], v[22:23], 0 ; cc464050 1a022d62
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[22:23], 0 ; cc464070 1a022d18
	v_wmma_f32_16x16x16_fp8_fp8 v[94:101], v[26:27], v[22:23], 0 ; cc46405e 1a022d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[20:27], v[58:59], v[132:133], 0 ; cc464014 1a03093a
	v_wmma_f32_16x16x16_fp8_fp8 v[126:133], v[58:59], v[134:135], 0 ; cc46407e 1a030d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[148:149], v[14:15], v[72:79] ; cc464048 1d221d94
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[150:151], v[14:15], v[80:87] ; cc464050 1d421d96
	v_wmma_f32_16x16x16_fp8_fp8 v[20:27], v[14:15], v[176:177], v[20:27] ; cc464014 1c53610e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[180:181], v[14:15], v[112:119] ; cc464070 1dc21db4
	v_wmma_f32_16x16x16_fp8_fp8 v[94:101], v[182:183], v[14:15], v[94:101] ; cc46405e 1d7a1db6
	v_wmma_f32_16x16x16_fp8_fp8 v[126:133], v[14:15], v[178:179], v[126:133] ; cc46407e 1dfb650e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[176:179], v2, s[40:43], null offen offset:64 ; c405c07c 408050b0 00004002
	buffer_load_b128 v[180:183], v2, s[40:43], null offen offset:80 ; c405c07c 408050b4 00005002
	v_dual_mul_f32 v149, v97, v97 :: v_dual_mul_f32 v148, v83, v83 ; c8c6c361 9594a753
	v_dual_mul_f32 v135, v95, v95 :: v_dual_mul_f32 v134, v81, v81 ; c8c6bf5f 8786a351
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_fmac_f32 v149, v115, v115 :: v_dual_fmac_f32 v134, v73, v73 ; c800e773 95869349
	v_fmac_f32_e32 v135, v113, v113                             ; 570ee371
	v_dual_fmac_f32 v135, v117, v117 :: v_dual_fmac_f32 v148, v75, v75 ; c800eb75 8794974b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_fmac_f32_e32 v148, v79, v79                               ; 57289f4f
	v_dual_fmac_f32 v135, v99, v99 :: v_dual_fmac_f32 v134, v77, v77 ; c800c763 87869b4d
	v_fmac_f32_e32 v148, v87, v87                               ; 5728af57
	v_dual_fmac_f32 v149, v119, v119 :: v_dual_fmac_f32 v134, v85, v85 ; c800ef77 9586ab55
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v135, v112, v112 :: v_dual_fmac_f32 v148, v74, v74 ; c800e170 8794954a
	v_dual_fmac_f32 v134, v72, v72 :: v_dual_fmac_f32 v149, v101, v101 ; c8009148 8694cb65
	v_fmac_f32_e32 v135, v94, v94                               ; 570ebd5e
	v_fmac_f32_e32 v134, v80, v80                               ; 570ca150
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v135, v116, v116 :: v_dual_fmac_f32 v148, v82, v82 ; c800e974 8794a552
	v_dual_fmac_f32 v149, v114, v114 :: v_dual_fmac_f32 v134, v76, v76 ; c800e572 9586994c
	v_fmac_f32_e32 v135, v98, v98                               ; 570ec562
	v_dual_fmac_f32 v149, v96, v96 :: v_dual_fmac_f32 v148, v78, v78 ; c800c160 95949d4e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v149, v118, v118 :: v_dual_fmac_f32 v134, v84, v84 ; c800ed76 9586a954
	v_dual_fmac_f32 v149, v100, v100 :: v_dual_fmac_f32 v148, v86, v86 ; c800c964 9594ad56
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v150, 1.0, v134, v148                       ; cc210096 06530cf2
	v_fma_mixhi_f16 v150, 1.0, v135, v149                       ; cc220096 06570ef2
	v_permlanex16_b32 v151, v150, s28, s30 op_sel:[1,1]         ; d65c1897 00783996
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; cc0f0096
	v_min_num_f64_e32 v[1:2], v[150:151], v[151:152]            ; 1a032f96
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; cc1c0096
	v_subrev_f32_e32 v0, v150, v31                              ; 0a003f96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; d58b000e
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                    ; 02010196
(invalid instruction)                                        ; d58b0896
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                    ; 02010196
	v_rsq_f32_e32 v14, v14                                      ; 7e1c5d0e
	v_rsq_f32_e32 v150, v150                                    ; 7f2c5d96
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_mul_f32_e32 v14, s10, v14                                 ; 101c1c0a
	v_dual_mul_f32 v114, v114, v150 :: v_dual_mul_f32 v115, v115, v150 ; c8c72d72 72732d73
	v_dual_mul_f32 v119, v119, v150 :: v_dual_mul_f32 v118, v118, v150 ; c8c72d77 77772d76
	v_dual_mul_f32 v117, v117, v150 :: v_dual_mul_f32 v116, v116, v150 ; c8c72d75 75752d74
	v_dual_mul_f32 v112, v112, v150 :: v_dual_mul_f32 v113, v113, v150 ; c8c72d70 70712d71
	v_dual_mul_f32 v77, v77, v14 :: v_dual_mul_f32 v76, v76, v14 ; c8c61d4d 4d4c1d4c
	v_dual_mul_f32 v75, v75, v14 :: v_dual_mul_f32 v74, v74, v14 ; c8c61d4b 4b4a1d4a
	v_dual_mul_f32 v83, v83, v14 :: v_dual_mul_f32 v82, v82, v14 ; c8c61d53 53521d52
	v_dual_mul_f32 v87, v87, v14 :: v_dual_mul_f32 v86, v86, v14 ; c8c61d57 57561d56
	v_dual_mul_f32 v95, v95, v150 :: v_dual_mul_f32 v94, v94, v150 ; c8c72d5f 5f5f2d5e
	v_dual_mul_f32 v81, v81, v14 :: v_dual_mul_f32 v80, v80, v14 ; c8c61d51 51501d50
	v_dual_mul_f32 v73, v73, v14 :: v_dual_mul_f32 v72, v72, v14 ; c8c61d49 49481d48
	v_dual_mul_f32 v79, v79, v14 :: v_dual_mul_f32 v78, v78, v14 ; c8c61d4f 4f4e1d4e
	v_dual_mul_f32 v85, v85, v14 :: v_dual_mul_f32 v84, v84, v14 ; c8c61d55 55541d54
	v_dual_mul_f32 v97, v97, v150 :: v_dual_mul_f32 v96, v96, v150 ; c8c72d61 61612d60
	v_dual_mul_f32 v99, v99, v150 :: v_dual_mul_f32 v98, v98, v150 ; c8c72d63 63632d62
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v101, v101, v150 :: v_dual_mul_f32 v100, v100, v150 ; c8c72d65 65652d64
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v92, v[72:73], v[14:15] offset0:192 offset1:194 ; d938c2c0 000e485c
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_load_b64 v[24:25], v92                                   ; d9d80000 1800005c
	ds_load_b64 v[26:27], v92 offset:16                         ; d9d80010 1a00005c
	s_mov_b32 s32, 0x3d380000                                   ; bea000ff 3d380000
	s_movk_i32 s33, 0x3c20                                      ; b0213c20
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[24:25], v[58:59], 0 ; cc464080 1a027518
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[6:7], 0   ; cc464050 1a020d18
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[4:5], 0   ; cc464048 1a020918
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[10:11], 0 ; cc464070 1a021518
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[22:23], v[128:135] ; cc464080 1e022d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[28:29], v[72:79] ; cc464048 1d22391a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[26:27], v[32:33], v[80:87] ; cc464050 1d42411a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[56:57], v[112:119] ; cc464070 1dc2711a
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v25, s32, v74, v38                          ; cc210019 049a9420
	v_fma_mixhi_f16 v25, s32, v75, v39                          ; cc220019 049e9620
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v26, s32, v76, v40                          ; cc21001a 04a29820
	v_dual_mov_b32 v76, v43 :: v_dual_mov_b32 v27, v42          ; ca10012b 4c1a012a
	v_fma_mixhi_f16 v26, s32, v77, v41                          ; cc22001a 04a69a20
	v_dual_mov_b32 v100, v93 :: v_dual_mov_b32 v77, v92         ; ca10015d 644c015c
	v_fma_mixlo_f16 v24, s32, v72, v36                          ; cc210018 04929020
	v_fma_mixhi_f16 v24, s32, v73, v37                          ; cc220018 04969220
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[36:39], v2, s[40:43], null offen offset:4160 ; c405c07c 40805024 00104002
	buffer_load_b128 v[72:75], v2, s[40:43], null offen offset:4176 ; c405c07c 40805048 00105002
	buffer_load_b128 v[96:99], v2, s[40:43], null offen offset:8256 ; c405c07c 40805060 00204002
	buffer_load_b128 v[148:151], v2, s[40:43], null offen offset:8272 ; c405c07c 40805094 00205002
	buffer_load_b128 v[40:43], v2, s[40:43], null offen offset:12352 ; c405c07c 40805028 00304002
	buffer_load_b128 v[92:95], v2, s[40:43], null offen offset:12368 ; c405c07c 4080505c 00305002
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_fma_mixlo_f16 v126, s32, v80, v44                         ; cc21007e 04b2a020
	v_fma_mixhi_f16 v126, s32, v81, v45                         ; cc22007e 04b6a220
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v33                               ; 0a004319
	v_fma_mixlo_f16 v127, s32, v82, v46                         ; cc21007f 04baa420
	v_fma_mixhi_f16 v127, s32, v83, v47                         ; cc22007f 04bea620
	v_fma_mixlo_f16 v101, s32, v78, v27                         ; cc210065 046e9c20
	ds_load_b64 v[46:47], v77 offset:512                        ; d9d80200 2e00004d
	v_fma_mixhi_f16 v101, s32, v79, v76                         ; cc220065 05329e20
(invalid instruction)                                        ; cc1c001a
	v_subrev_f32_e32 v0, v26, v33                               ; 0a00431a
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v27, s32, v84, v64                          ; cc21001b 0502a820
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v45, s32, v112, v60                         ; cc21002d 04f2e020
	v_fma_mixlo_f16 v60, s32, v114, v62                         ; cc21003c 04fae420
	v_fma_mixhi_f16 v60, s32, v115, v63                         ; cc22003c 04fee620
	ds_load_b64 v[62:63], v77 offset:528                        ; d9d80210 3e00004d
	v_fma_mixhi_f16 v27, s32, v85, v65                          ; cc22001b 0506aa20
(invalid instruction)                                        ; cc1c0018
	v_subrev_f32_e32 v0, v24, v33                               ; 0a004318
	v_fma_mixlo_f16 v44, s32, v86, v66                          ; cc21002c 050aac20
	v_fma_mixhi_f16 v44, s32, v87, v67                          ; cc22002c 050eae20
	v_fma_mixhi_f16 v45, s32, v113, v61                         ; cc22002d 04f6e220
(invalid instruction)                                        ; cc1c007e
	v_subrev_f32_e32 v0, v126, v33                              ; 0a00437e
(invalid instruction)                                        ; cc1c007f
	v_subrev_f32_e32 v0, v127, v33                              ; 0a00437f
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v61, s32, v116, v68                         ; cc21003d 0512e820
	v_fma_mixhi_f16 v61, s32, v117, v69                         ; cc22003d 0516ea20
	v_fma_mixlo_f16 v64, s32, v118, v70                         ; cc210040 051aec20
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v33                              ; 0a004365
	v_dual_mov_b32 v70, v105 :: v_dual_mov_b32 v69, v104        ; ca100169 46440168
	v_fma_mixhi_f16 v64, s32, v119, v71                         ; cc220040 051eee20
	v_dual_mov_b32 v76, v107 :: v_dual_mov_b32 v71, v106        ; ca10016b 4c46016a
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v33                               ; 0a00433c
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v65, s32, v128, v144                        ; cc210041 06430020
(invalid instruction)                                        ; cc1c001b
	v_subrev_f32_e32 v0, v27, v33                               ; 0a00431b
	v_fma_mixhi_f16 v65, s32, v129, v145                        ; cc220041 06470220
	v_fma_mixlo_f16 v66, s32, v130, v146                        ; cc210042 064b0420
(invalid instruction)                                        ; cc1c002c
	v_subrev_f32_e32 v0, v44, v33                               ; 0a00432c
	v_fma_mixhi_f16 v66, s32, v131, v147                        ; cc220042 064f0620
(invalid instruction)                                        ; cc1c002d
	v_subrev_f32_e32 v0, v45, v33                               ; 0a00432d
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v67, s32, v132, v108                        ; cc210043 05b30820
	v_fma_mixhi_f16 v67, s32, v133, v109                        ; cc220043 05b70a20
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v33                               ; 0a00433d
	v_fma_mixlo_f16 v68, s32, v134, v110                        ; cc210044 05bb0c20
	v_fma_mixhi_f16 v68, s32, v135, v111                        ; cc220044 05bf0e20
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[4:5], 0   ; cc464050 1a02092e
(invalid instruction)                                        ; cc1c0040
	v_subrev_f32_e32 v0, v64, v33                               ; 0a004340
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[6:7], 0 ; cc464070 1a020d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[10:11], 0 ; cc464080 1a02152e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[58:59], 0 ; cc464068 1a02752e
(invalid instruction)                                        ; cc1c0041
	v_subrev_f32_e32 v0, v65, v33                               ; 0a004341
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v33                               ; 0a004342
	ds_load_b64 v[46:47], v77 offset:1024                       ; d9d80400 2e00004d
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v33                               ; 0a004343
(invalid instruction)                                        ; cc1c0044
	v_subrev_f32_e32 v0, v68, v33                               ; 0a004344
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[62:63], v[28:29], v[80:87] ; cc464050 1d42393e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[32:33], v[112:119] ; cc464070 1dc2413e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[56:57], v[128:135] ; cc464080 1e02713e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[62:63], v[22:23], v[104:111] ; cc464068 1da22d3e
	ds_load_b64 v[62:63], v77 offset:1040                       ; d9d80410 3e00004d
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v79, s32, v82, v178                         ; cc21004f 06caa420
	v_fma_mixlo_f16 v78, s32, v80, v176                         ; cc21004e 06c2a020
	v_fma_mixhi_f16 v79, s32, v83, v179                         ; cc22004f 06cea620
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v80, s32, v84, v180                         ; cc210050 06d2a820
	v_fma_mixhi_f16 v80, s32, v85, v181                         ; cc220050 06d6aa20
	v_fma_mixhi_f16 v78, s32, v81, v177                         ; cc22004e 06c6a220
	v_fma_mixlo_f16 v81, s32, v86, v182                         ; cc210051 06daac20
	v_fma_mixhi_f16 v81, s32, v87, v183                         ; cc220051 06deae20
(invalid instruction)                                        ; cc1c004f
	v_subrev_f32_e32 v0, v79, v33                               ; 0a00434f
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v33                               ; 0a004350
(invalid instruction)                                        ; cc1c004e
	v_subrev_f32_e32 v0, v78, v33                               ; 0a00434e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v33                               ; 0a004351
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v82, s32, v112, v36                         ; cc210052 0492e020
	v_fma_mixhi_f16 v82, s32, v113, v37                         ; cc220052 0496e220
	v_dual_mov_b32 v37, v69 :: v_dual_mov_b32 v36, v68          ; ca100145 25240144
	v_fma_mixlo_f16 v83, s32, v114, v38                         ; cc210053 049ae420
	v_fma_mixhi_f16 v83, s32, v115, v39                         ; cc220053 049ee620
	v_dual_mov_b32 v39, v71 :: v_dual_mov_b32 v38, v70          ; ca100147 27260146
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v84, s32, v116, v72                         ; cc210054 0522e820
	v_fma_mixhi_f16 v84, s32, v117, v73                         ; cc220054 0526ea20
	v_fma_mixlo_f16 v85, s32, v118, v74                         ; cc210055 052aec20
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v86, s32, v128, v96                         ; cc210056 05830020
	v_fma_mixhi_f16 v86, s32, v129, v97                         ; cc220056 05870220
	v_dual_mov_b32 v129, v101 :: v_dual_mov_b32 v128, v100      ; ca100165 81800164
	v_fma_mixlo_f16 v87, s32, v130, v98                         ; cc210057 058b0420
	v_fma_mixhi_f16 v87, s32, v131, v99                         ; cc220057 058f0620
	v_dual_mov_b32 v131, v103 :: v_dual_mov_b32 v130, v102      ; ca100167 83820166
	v_fma_mixhi_f16 v85, s32, v119, v75                         ; cc220055 052eee20
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[4:5], 0 ; cc464070 1a02092e
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v33                               ; 0a004352
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[6:7], 0 ; cc4640b0 1a020d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[68:75], v[46:47], v[10:11], 0 ; cc464044 1a02152e
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v33                               ; 0a004353
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[58:59], 0 ; cc464060 1a02752e
(invalid instruction)                                        ; cc1c0054
	v_subrev_f32_e32 v0, v84, v33                               ; 0a004354
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v132, s32, v132, v148                       ; cc210084 06530820
	v_fma_mixhi_f16 v132, s32, v133, v149                       ; cc220084 06570a20
(invalid instruction)                                        ; cc1c0056
	v_subrev_f32_e32 v0, v86, v33                               ; 0a004356
(invalid instruction)                                        ; cc1c0057
	v_subrev_f32_e32 v0, v87, v33                               ; 0a004357
(invalid instruction)                                        ; cc1c0055
	v_subrev_f32_e32 v0, v85, v33                               ; 0a004355
	v_fma_mixlo_f16 v133, s32, v134, v150                       ; cc210085 065b0c20
	v_fma_mixhi_f16 v133, s32, v135, v151                       ; cc220085 065f0e20
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[28:29], v[112:119] ; cc464070 1dc2393e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v134, s32, v104, v40                        ; cc210086 04a2d020
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[32:33], v[176:183] ; cc4640b0 1ec2413e
	v_fma_mixhi_f16 v134, s32, v105, v41                        ; cc220086 04a6d220
	v_fma_mixlo_f16 v135, s32, v106, v42                        ; cc210087 04aad420
	v_fma_mixhi_f16 v135, s32, v107, v43                        ; cc220087 04aed620
	v_wmma_f32_16x16x16_fp8_fp8 v[68:75], v[62:63], v[56:57], v[68:75] ; cc464044 1d12713e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v144, s32, v108, v92                        ; cc210090 0572d820
	v_fma_mixhi_f16 v144, s32, v109, v93                        ; cc220090 0576da20
	v_fma_mixlo_f16 v145, s32, v110, v94                        ; cc210091 057adc20
	v_fma_mixhi_f16 v145, s32, v111, v95                        ; cc220091 057ede20
	v_dual_mov_b32 v147, v45 :: v_dual_mov_b32 v146, v44        ; ca10012d 9392012c
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[40:43], v2, s[40:43], null offen offset:128 ; c405c07c 40805028 00008002
	buffer_load_b128 v[92:95], v2, s[40:43], null offen offset:144 ; c405c07c 4080505c 00009002
	buffer_load_b128 v[104:107], v2, s[40:43], null offen offset:4224 ; c405c07c 40805068 00108002
	buffer_load_b128 v[108:111], v2, s[40:43], null offen offset:4240 ; c405c07c 4080506c 00109002
	buffer_load_b128 v[148:151], v2, s[40:43], null offen offset:8320 ; c405c07c 40805094 00208002
	buffer_load_b128 v[44:47], v2, s[40:43], null offen offset:8336 ; c405c07c 4080502c 00209002
(invalid instruction)                                        ; cc1c0084
	v_subrev_f32_e32 v0, v132, v33                              ; 0a004384
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v40, s32, v112, v40                         ; cc210028 04a2e020
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[62:63], v[22:23], v[96:103] ; cc464060 1d822d3e
	v_fma_mixhi_f16 v40, s32, v113, v41                         ; cc220028 04a6e220
	v_fma_mixlo_f16 v41, s32, v114, v42                         ; cc210029 04aae420
	v_fma_mixhi_f16 v41, s32, v115, v43                         ; cc220029 04aee620
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v42, s32, v116, v92                         ; cc21002a 0572e820
	v_dual_mov_b32 v92, v61 :: v_dual_mov_b32 v43, v60          ; ca10013d 5c2a013c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[112:115], v2, s[40:43], null offen offset:12416 ; c405c07c 40805070 00308002
	buffer_load_b128 v[60:63], v2, s[40:43], null offen offset:12432 ; c405c07c 4080503c 00309002
	v_fma_mixhi_f16 v42, s32, v117, v93                         ; cc22002a 0576ea20
	ds_load_b64 v[116:117], v77 offset:1536                     ; d9d80600 7400004d
(invalid instruction)                                        ; cc1c0085
	v_subrev_f32_e32 v0, v133, v33                              ; 0a004385
(invalid instruction)                                        ; cc1c0086
	v_subrev_f32_e32 v0, v134, v33                              ; 0a004386
(invalid instruction)                                        ; cc1c0087
	v_subrev_f32_e32 v0, v135, v33                              ; 0a004387
(invalid instruction)                                        ; cc1c0090
	v_subrev_f32_e32 v0, v144, v33                              ; 0a004390
(invalid instruction)                                        ; cc1c0091
	v_subrev_f32_e32 v0, v145, v33                              ; 0a004391
	v_fma_mixlo_f16 v93, s32, v118, v94                         ; cc21005d 057aec20
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v94, s32, v176, v104                        ; cc21005e 05a36020
	v_fma_mixhi_f16 v94, s32, v177, v105                        ; cc22005e 05a76220
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v105, s32, v182, v110                       ; cc210069 05bb6c20
	v_fma_mixhi_f16 v105, s32, v183, v111                       ; cc220069 05bf6e20
(invalid instruction)                                        ; cc1c0028
	v_subrev_f32_e32 v0, v40, v33                               ; 0a004328
	v_dual_mov_b32 v111, v1 :: v_dual_mov_b32 v110, v0          ; ca100101 6f6e0100
(invalid instruction)                                        ; cc1c0029
	v_subrev_f32_e32 v0, v41, v33                               ; 0a004329
	v_fma_mixhi_f16 v93, s32, v119, v95                         ; cc22005d 057eee20
	v_dual_mov_b32 v119, v3 :: v_dual_mov_b32 v118, v2          ; ca100103 77760102
	v_fma_mixlo_f16 v95, s32, v178, v106                        ; cc21005f 05ab6420
(invalid instruction)                                        ; cc1c002a
	v_subrev_f32_e32 v0, v42, v33                               ; 0a00432a
	v_fma_mixhi_f16 v95, s32, v179, v107                        ; cc22005f 05af6620
	v_fma_mixlo_f16 v104, s32, v180, v108                       ; cc210068 05b36820
	v_fma_mixhi_f16 v104, s32, v181, v109                       ; cc220068 05b76a20
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v106, s32, v68, v148                        ; cc21006a 06528820
	v_fma_mixhi_f16 v106, s32, v69, v149                        ; cc22006a 06568a20
	v_fma_mixlo_f16 v107, s32, v70, v150                        ; cc21006b 065a8c20
	v_fma_mixhi_f16 v107, s32, v71, v151                        ; cc22006b 065e8e20
(invalid instruction)                                        ; cc1c005e
	v_subrev_f32_e32 v0, v94, v33                               ; 0a00435e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v108, s32, v72, v44                         ; cc21006c 04b29020
(invalid instruction)                                        ; cc1c0069
	v_subrev_f32_e32 v0, v105, v33                              ; 0a004369
	v_fma_mixhi_f16 v108, s32, v73, v45                         ; cc22006c 04b69220
	v_fma_mixlo_f16 v109, s32, v74, v46                         ; cc21006d 04ba9420
	v_fma_mixhi_f16 v109, s32, v75, v47                         ; cc22006d 04be9620
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[68:75], v[116:117], v[6:7], 0 ; cc464044 1a020d74
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[116:117], v[4:5], 0 ; cc4640b0 1a020974
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[116:117], v[10:11], 0 ; cc464000 1a021574
	v_dual_mov_b32 v11, v41 :: v_dual_mov_b32 v10, v40          ; ca100129 0b0a0128
	v_dual_mov_b32 v149, v43 :: v_dual_mov_b32 v148, v42        ; ca10012b 9594012a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[116:117], v[58:59], 0 ; cc464028 1a027574
	ds_load_b64 v[58:59], v77 offset:1552                       ; d9d80610 3a00004d
(invalid instruction)                                        ; cc1c005d
	v_subrev_f32_e32 v0, v93, v33                               ; 0a00435d
(invalid instruction)                                        ; cc1c005f
	v_subrev_f32_e32 v0, v95, v33                               ; 0a00435f
(invalid instruction)                                        ; cc1c0068
	v_subrev_f32_e32 v0, v104, v33                              ; 0a004368
(invalid instruction)                                        ; cc1c006a
	v_subrev_f32_e32 v0, v106, v33                              ; 0a00436a
(invalid instruction)                                        ; cc1c006b
	v_subrev_f32_e32 v0, v107, v33                              ; 0a00436b
(invalid instruction)                                        ; cc1c006c
	v_subrev_f32_e32 v0, v108, v33                              ; 0a00436c
(invalid instruction)                                        ; cc1c006d
	v_subrev_f32_e32 v0, v109, v33                              ; 0a00436d
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[68:75], v[58:59], v[32:33], v[68:75] ; cc464044 1d12413a
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[58:59], v[56:57], v[0:7] ; cc464000 1c02713a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[58:59], v[22:23], v[40:47] ; cc464028 1ca22d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[58:59], v[28:29], v[176:183] ; cc4640b0 1ec2393a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v151, s32, v98, v114                        ; cc210097 05cac420
	v_fma_mixhi_f16 v151, s32, v99, v115                        ; cc220097 05cec620
	v_fma_mixlo_f16 v150, s32, v96, v112                        ; cc210096 05c2c020
	v_fma_mixhi_f16 v150, s32, v97, v113                        ; cc220096 05c6c220
	v_dual_mov_b32 v29, v119 :: v_dual_mov_b32 v28, v118        ; ca100177 1d1c0176
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v23, s32, v102, v62                         ; cc210017 04facc20
	v_fma_mixhi_f16 v23, s32, v103, v63                         ; cc220017 04fece20
	v_fma_mixlo_f16 v22, s32, v100, v60                         ; cc210016 04f2c820
	v_fma_mixhi_f16 v22, s32, v101, v61                         ; cc220016 04f6ca20
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[56:59], v118, s[40:43], null offen offset:192 ; c405c07c 40805038 0000c076
	buffer_load_b128 v[60:63], v118, s[40:43], null offen offset:208 ; c405c07c 4080503c 0000d076
	buffer_load_b128 v[96:99], v118, s[40:43], null offen offset:4288 ; c405c07c 40805060 0010c076
	buffer_load_b128 v[100:103], v118, s[40:43], null offen offset:4304 ; c405c07c 40805064 0010d076
	buffer_load_b128 v[112:115], v118, s[40:43], null offen offset:8384 ; c405c07c 40805070 0020c076
	buffer_load_b128 v[116:119], v118, s[40:43], null offen offset:8400 ; c405c07c 40805074 0020d076
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v32, s32, v176, v56                         ; cc210020 04e36020
	v_fma_mixhi_f16 v32, s32, v177, v57                         ; cc220020 04e76220
	v_fma_mixlo_f16 v33, s32, v178, v58                         ; cc210021 04eb6420
	v_fma_mixhi_f16 v33, s32, v179, v59                         ; cc220021 04ef6620
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v28, s[40:43], null offen offset:12480 ; c405c07c 40805038 0030c01c
	buffer_load_b128 v[176:179], v28, s[40:43], null offen offset:12496 ; c405c07c 408050b0 0030d01c
(invalid instruction)                                        ; cc1c0097
	v_subrev_f32_e32 v0, v151, v33                              ; 0a004397
(invalid instruction)                                        ; cc1c0096
	v_subrev_f32_e32 v0, v150, v33                              ; 0a004396
	s_mov_b32 s34, 0x7ff88000                                   ; bea200ff 7ff88000
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v33                               ; 0a004317
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v33                               ; 0a004316
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v60, s32, v180, v60                         ; cc21003c 04f36820
	v_fma_mixhi_f16 v60, s32, v181, v61                         ; cc22003c 04f76a20
	v_fma_mixlo_f16 v61, s32, v182, v62                         ; cc21003d 04fb6c20
	v_fma_mixhi_f16 v61, s32, v183, v63                         ; cc22003d 04ff6e20
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v33                               ; 0a004320
(invalid instruction)                                        ; cc1c0021
	v_subrev_f32_e32 v0, v33, v33                               ; 0a004321
	v_lshl_add_u32 v10, v10, 5, s34                             ; d646000a 00890b0a
	v_lshl_add_u32 v24, v24, 5, s34                             ; d6460018 00890b18
	v_lshl_add_u32 v25, v25, 5, s34                             ; d6460019 00890b19
	v_lshl_add_u32 v78, v78, 5, s34                             ; d646004e 00890b4e
	v_lshl_add_u32 v79, v79, 5, s34                             ; d646004f 00890b4f
	v_lshl_add_u32 v11, v11, 5, s34                             ; d646000b 00890b0b
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v33                               ; 0a00433c
	v_lshl_add_u32 v26, v26, 5, s34                             ; d646001a 00890b1a
	v_lshl_add_u32 v80, v80, 5, s34                             ; d6460050 00890b50
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v33                               ; 0a00433d
	v_lshl_add_u32 v32, v32, 5, s34                             ; d6460020 00890b20
	v_lshl_add_u32 v148, v148, 5, s34                           ; d6460094 00890b94
	v_lshl_add_u32 v33, v33, 5, s34                             ; d6460021 00890b21
	v_lshl_add_u32 v129, v129, 5, s34                           ; d6460081 00890b81
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[24:25], v[78:79]                ; 1a029d18
	v_lshl_add_u32 v81, v81, 5, s34                             ; d6460051 00890b51
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[25:26], v[79:80]                ; 1a029f19
	v_lshl_add_u32 v93, v93, 5, s34                             ; d646005d 00890b5d
	v_lshl_add_u32 v60, v60, 5, s34                             ; d646003c 00890b3c
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[26:27], v[80:81]                ; 1a02a11a
	v_lshl_add_u32 v61, v61, 5, s34                             ; d646003d 00890b3d
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[10:11]                ; 1a02153e
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[129:130], v[81:82]              ; 1a02a381
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[11:12]                ; 1a02173f
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[148:149]              ; 1a03294d
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[32:33]                ; 1a02413e
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[93:94]              ; 1a02bbb4
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[33:34]                ; 1a02433f
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[60:61]                ; 1a02794d
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[61:62]              ; 1a027bb4
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[63:64]                ; 1a027f3e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[77:78]                ; 1a029b3e
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[180:181]              ; 1a03693e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v181, v62, s28, s30 op_sel:[1,1]          ; d65c18b5 0078393e
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[181:182]              ; 1a036b3e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53210b6
	v_cndmask_b32_e32 v1, v62, v62, vcc_lo                      ; 02027d3e
(invalid instruction)                                        ; d53100b6
	v_cndmask_b32_e32 v1, s27, v182, vcc_lo                     ; 02036c1b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00b7
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                    ; 020101b6
	v_rcp_f32_e32 v183, v183                                    ; 7f6e55b7
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v77, v26, v183, neg(0) op_sel_hi:[1,0,0]      ; cc20004d 8a036f1a
	v_fma_mix_f32 v182, v79, v183, neg(0) op_sel_hi:[1,0,0]     ; cc2000b6 8a036f4f
	v_fma_mix_f32 v180, v129, v183, neg(0) op_sel_hi:[1,0,0]    ; cc2000b4 8a036f81
	v_fma_mix_f32 v129, v129, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a036f81
	v_fma_mix_f32 v26, v26, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081a 8a036f1a
	v_fma_mix_f32 v28, v24, v183, neg(0) op_sel_hi:[1,0,0]      ; cc20001c 8a036f18
	v_fma_mix_f32 v24, v24, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200818 8a036f18
	v_fma_mix_f32 v181, v78, v183, neg(0) op_sel_hi:[1,0,0]     ; cc2000b5 8a036f4e
	v_fma_mix_f32 v78, v78, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084e 8a036f4e
	v_fma_mix_f32 v63, v25, v183, neg(0) op_sel_hi:[1,0,0]      ; cc20003f 8a036f19
	v_fma_mix_f32 v25, v25, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a036f19
	v_fma_mix_f32 v79, v79, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084f 8a036f4f
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                      ; 0202311c
	v_fma_mix_f32 v28, v10, v183, neg(0) op_sel_hi:[1,0,0]      ; cc20001c 8a036f0a
	v_fma_mix_f32 v10, v10, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080a 8a036f0a
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v181, v78, vcc_lo                     ; 02029db5
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v63, v25, vcc_lo                      ; 0202333f
	v_fma_mix_f32 v25, v80, v183, neg(0) op_sel_hi:[1,0,0]      ; cc200019 8a036f50
	v_fma_mix_f32 v80, v80, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200850 8a036f50
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v77, v26, vcc_lo                      ; 0202354d
	v_fma_mix_f32 v26, v81, v183, neg(0) op_sel_hi:[1,0,0]      ; cc20001a 8a036f51
	v_fma_mix_f32 v81, v81, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200851 8a036f51
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v180, v129, vcc_lo                    ; 020303b4
	v_fma_mix_f32 v77, v11, v183, neg(0) op_sel_hi:[1,0,0]      ; cc20004d 8a036f0b
	v_fma_mix_f32 v11, v11, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080b 8a036f0b
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v182, v79, vcc_lo                     ; 02029fb6
	v_fma_mix_f32 v79, v148, v183, neg(0) op_sel_hi:[1,0,0]     ; cc20004f 8a036f94
	v_fma_mix_f32 v148, v148, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200894 8a036f94
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v28, v10, vcc_lo                      ; 0202151c
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v25, v80, vcc_lo                      ; 0202a119
	v_fma_mix_f32 v80, v93, v183, neg(0) op_sel_hi:[1,0,0]      ; cc200050 8a036f5d
	v_fma_mix_f32 v93, v93, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085d 8a036f5d
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v26, v81, vcc_lo                      ; 0202a31a
	v_fma_mix_f32 v81, v32, v183, neg(0) op_sel_hi:[1,0,0]      ; cc200051 8a036f20
	v_fma_mix_f32 v32, v32, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a036f20
	v_fma_mix_f32 v129, v60, v183, neg(0) op_sel_hi:[1,0,0]     ; cc200081 8a036f3c
	v_fma_mix_f32 v60, v60, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083c 8a036f3c
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v77, v11, vcc_lo                      ; 0202174d
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v79, v148, vcc_lo                     ; 0203294f
	v_fma_mix_f32 v148, v61, v183, neg(0) op_sel_hi:[1,0,0]     ; cc200094 8a036f3d
	v_fma_mix_f32 v61, v61, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083d 8a036f3d
	v_lshl_add_u32 v126, v126, 5, s34                           ; d646007e 00890b7e
	v_lshl_add_u32 v82, v82, 5, s34                             ; d6460052 00890b52
	v_lshl_add_u32 v94, v94, 5, s34                             ; d646005e 00890b5e
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v80, v93, vcc_lo                      ; 0202bb50
	v_fma_mix_f32 v93, v33, v183, neg(0) op_sel_hi:[1,0,0]      ; cc20005d 8a036f21
	v_fma_mix_f32 v33, v33, v183, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200821 8a036f21
	v_lshl_add_u32 v127, v127, 5, s34                           ; d646007f 00890b7f
	v_lshl_add_u32 v83, v83, 5, s34                             ; d6460053 00890b53
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v81, v32, vcc_lo                      ; 02024151
	v_lshl_add_u32 v95, v95, 5, s34                             ; d646005f 00890b5f
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v129, v60, vcc_lo                     ; 02027981
	v_lshl_add_u32 v27, v27, 5, s34                             ; d646001b 00890b1b
	v_lshl_add_u32 v84, v84, 5, s34                             ; d6460054 00890b54
	v_lshl_add_u32 v104, v104, 5, s34                           ; d6460068 00890b68
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v148, v61, vcc_lo                     ; 02027b94
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[126:127], v[82:83]              ; 1a02a57e
	v_lshl_add_u32 v146, v146, 5, s34                           ; d6460092 00890b92
	v_lshl_add_u32 v85, v85, 5, s34                             ; d6460055 00890b55
	v_lshl_add_u32 v105, v105, 5, s34                           ; d6460069 00890b69
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v93, v33, vcc_lo                      ; 0202435d
	v_lshl_add_u32 v147, v147, 5, s34                           ; d6460093 00890b93
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[127:128], v[83:84]              ; 1a02a77f
	v_lshl_add_u32 v86, v86, 5, s34                             ; d6460056 00890b56
	v_lshl_add_u32 v106, v106, 5, s34                           ; d646006a 00890b6a
	v_lshl_add_u32 v149, v149, 5, s34                           ; d6460095 00890b95
	v_lshl_add_u32 v87, v87, 5, s34                             ; d6460057 00890b57
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[27:28], v[84:85]                ; 1a02a91b
	v_lshl_add_u32 v107, v107, 5, s34                           ; d646006b 00890b6b
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[94:95]              ; 1a02bdb4
	v_lshl_add_u32 v92, v92, 5, s34                             ; d646005c 00890b5c
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[146:147], v[85:86]              ; 1a02ab92
	v_lshl_add_u32 v132, v132, 5, s34                           ; d6460084 00890b84
	v_lshl_add_u32 v108, v108, 5, s34                           ; d646006c 00890b6c
	v_lshl_add_u32 v64, v64, 5, s34                             ; d6460040 00890b40
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[181:182], v[95:96]              ; 1a02bfb5
(invalid instruction)                                        ; cc0f001a
	v_min_num_f64_e32 v[1:2], v[147:148], v[86:87]              ; 1a02ad93
	v_lshl_add_u32 v133, v133, 5, s34                           ; d6460085 00890b85
	v_lshl_add_u32 v109, v109, 5, s34                           ; d646006d 00890b6d
(invalid instruction)                                        ; cc0f001c
	v_min_num_f64_e32 v[1:2], v[149:150], v[87:88]              ; 1a02af95
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[104:105]            ; 1a02d1b6
	v_lshl_add_u32 v65, v65, 5, s34                             ; d6460041 00890b41
	v_lshl_add_u32 v134, v134, 5, s34                           ; d6460086 00890b86
	v_lshl_add_u32 v150, v150, 5, s34                           ; d6460096 00890b96
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[105:106]            ; 1a02d3b7
	v_lshl_add_u32 v66, v66, 5, s34                             ; d6460042 00890b42
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[92:93], v[132:133]              ; 1a03095c
	v_lshl_add_u32 v135, v135, 5, s34                           ; d6460087 00890b87
	v_lshl_add_u32 v151, v151, 5, s34                           ; d6460097 00890b97
(invalid instruction)                                        ; cc0f001a
	v_min_num_f64_e32 v[1:2], v[26:27], v[106:107]              ; 1a02d51a
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[64:65], v[133:134]              ; 1a030b40
	v_lshl_add_u32 v67, v67, 5, s34                             ; d6460043 00890b43
	v_lshl_add_u32 v144, v144, 5, s34                           ; d6460090 00890b90
(invalid instruction)                                        ; cc0f001c
	v_min_num_f64_e32 v[1:2], v[28:29], v[107:108]              ; 1a02d71c
	v_lshl_add_u32 v22, v22, 5, s34                             ; d6460016 00890b16
	v_lshl_add_u32 v36, v36, 5, s34                             ; d6460024 00890b24
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[65:66], v[134:135]              ; 1a030d41
	v_lshl_add_u32 v145, v145, 5, s34                           ; d6460091 00890b91
	v_lshl_add_u32 v23, v23, 5, s34                             ; d6460017 00890b17
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[32:33], v[108:109]              ; 1a02d920
(invalid instruction)                                        ; cc0f003d
	v_min_num_f64_e32 v[1:2], v[66:67], v[135:136]              ; 1a030f42
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v81, s32, v68, v96                          ; cc210051 05828820
	v_fma_mixhi_f16 v81, s32, v69, v97                          ; cc220051 05868a20
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[109:110]              ; 1a02db21
	v_fma_mixlo_f16 v93, s32, v70, v98                          ; cc21005d 058a8c20
	v_fma_mixhi_f16 v93, s32, v71, v99                          ; cc22005d 058e8e20
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[67:68], v[144:145]              ; 1a032143
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v96, s32, v72, v100                         ; cc210060 05929020
	v_fma_mixhi_f16 v96, s32, v73, v101                         ; cc220060 05969220
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[60:61], v[150:151]              ; 1a032d3c
	v_fma_mixlo_f16 v97, s32, v74, v102                         ; cc210061 059a9420
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[36:37], v[145:146]              ; 1a032324
	v_fma_mixhi_f16 v97, s32, v75, v103                         ; cc220061 059e9620
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v98, s32, v0, v112                          ; cc210062 05c20020
	v_fma_mixhi_f16 v98, s32, v1, v113                          ; cc220062 05c60220
(invalid instruction)                                        ; cc0f003d
	v_min_num_f64_e32 v[1:2], v[61:62], v[151:152]              ; 1a032f3d
	v_fma_mixlo_f16 v99, s32, v2, v114                          ; cc210063 05ca0420
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v33                               ; 0a004351
	v_fma_mixhi_f16 v99, s32, v3, v115                          ; cc220063 05ce0620
(invalid instruction)                                        ; cc1c005d
	v_subrev_f32_e32 v0, v93, v33                               ; 0a00435d
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v100, s32, v4, v116                         ; cc210064 05d20820
	v_fma_mixhi_f16 v100, s32, v5, v117                         ; cc220064 05d60a20
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[22:23]                ; 1a022d4d
(invalid instruction)                                        ; cc1c0060
	v_subrev_f32_e32 v0, v96, v33                               ; 0a004360
	v_fma_mixlo_f16 v101, s32, v6, v118                         ; cc210065 05da0c20
	v_fma_mixhi_f16 v101, s32, v7, v119                         ; cc220065 05de0e20
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[23:24]                ; 1a022f50
(invalid instruction)                                        ; cc1c0061
	v_subrev_f32_e32 v0, v97, v33                               ; 0a004361
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v33                               ; 0a004362
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v33                               ; 0a004363
(invalid instruction)                                        ; cc1c0064
	v_subrev_f32_e32 v0, v100, v33                              ; 0a004364
	v_lshl_add_u32 v81, v81, 5, s34                             ; d6460051 00890b51
	v_lshl_add_u32 v93, v93, 5, s34                             ; d646005d 00890b5d
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v33                              ; 0a004365
	v_lshl_add_u32 v96, v96, 5, s34                             ; d6460060 00890b60
	v_lshl_add_u32 v97, v97, 5, s34                             ; d6460061 00890b61
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[81:82]              ; 1a02a3b4
(invalid instruction)                                        ; cc0f00b5
	v_min_num_f64_e32 v[1:2], v[181:182], v[93:94]              ; 1a02bbb5
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[96:97]              ; 1a02c1b6
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[97:98]              ; 1a02c3b7
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[181:182]            ; 1a036bb4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[182:183]            ; 1a036db4
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[183:184]            ; 1a036fb4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v114, v180, s28, s30 op_sel:[1,1]         ; d65c1872 007839b4
(invalid instruction)                                        ; cc0f00b4
	v_min_num_f64_e32 v[1:2], v[180:181], v[114:115]            ; 1a02e5b4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5321073
	v_cndmask_b32_e32 v1, v180, v180, vcc_lo                    ; 020369b4
	v_max_num_f16_e32 v115, s27, v115                           ; 62e6e61b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v116, v115                                ; 7ee81773
	v_rcp_f32_e32 v116, v116                                    ; 7ee85574
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v118, v127, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200076 8a02e97f
	v_fma_mix_f32 v117, v126, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200075 8a02e97e
	v_fma_mix_f32 v126, v126, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087e 8a02e97e
	v_fma_mix_f32 v127, v127, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087f 8a02e97f
	v_fma_mix_f32 v119, v27, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200077 8a02e91b
	v_fma_mix_f32 v27, v27, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081b 8a02e91b
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v102, s32, v40, v56                         ; cc210066 04e25020
	v_fma_mixhi_f16 v102, s32, v41, v57                         ; cc220066 04e65220
	v_fma_mixlo_f16 v103, s32, v42, v58                         ; cc210067 04ea5420
	v_fma_mixhi_f16 v103, s32, v43, v59                         ; cc220067 04ee5620
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v112, s32, v44, v176                        ; cc210070 06c25820
	v_fma_mixhi_f16 v112, s32, v45, v177                        ; cc220070 06c65a20
	v_fma_mixlo_f16 v113, s32, v46, v178                        ; cc210071 06ca5c20
	v_fma_mixhi_f16 v113, s32, v47, v179                        ; cc220071 06ce5e20
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v117, v126, vcc_lo                    ; 0202fd75
	v_fma_mix_f32 v126, v146, v116, neg(0) op_sel_hi:[1,0,0]    ; cc20007e 8a02e992
	v_fma_mix_f32 v146, v146, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200892 8a02e992
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v118, v127, vcc_lo                    ; 0202ff76
	v_fma_mix_f32 v127, v82, v116, neg(0) op_sel_hi:[1,0,0]     ; cc20007f 8a02e952
	v_fma_mix_f32 v82, v82, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200852 8a02e952
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v119, v27, vcc_lo                     ; 02023777
	v_fma_mix_f32 v129, v83, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200081 8a02e953
(invalid instruction)                                        ; cc1c0066
	v_subrev_f32_e32 v0, v102, v33                              ; 0a004366
	v_fma_mix_f32 v83, v83, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200853 8a02e953
(invalid instruction)                                        ; cc1c0067
	v_subrev_f32_e32 v0, v103, v33                              ; 0a004367
(invalid instruction)                                        ; cc1c0070
	v_subrev_f32_e32 v0, v112, v33                              ; 0a004370
	v_fma_mix_f32 v148, v85, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200094 8a02e955
(invalid instruction)                                        ; cc1c0071
	v_subrev_f32_e32 v0, v113, v33                              ; 0a004371
	v_fma_mix_f32 v85, v85, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200855 8a02e955
	v_fma_mix_f32 v176, v94, v116, neg(0) op_sel_hi:[1,0,0]     ; cc2000b0 8a02e95e
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v126, v146, vcc_lo                    ; 0203257e
	v_fma_mix_f32 v146, v84, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200092 8a02e954
	v_fma_mix_f32 v84, v84, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200854 8a02e954
	v_fma_mix_f32 v94, v94, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085e 8a02e95e
	v_fma_mix_f32 v177, v95, v116, neg(0) op_sel_hi:[1,0,0]     ; cc2000b1 8a02e95f
	v_fma_mix_f32 v95, v95, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085f 8a02e95f
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v127, v82, vcc_lo                     ; 0202a57f
	v_fma_mix_f32 v178, v104, v116, neg(0) op_sel_hi:[1,0,0]    ; cc2000b2 8a02e968
	v_fma_mix_f32 v104, v104, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200868 8a02e968
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v129, v83, vcc_lo                     ; 0202a781
	v_fma_mix_f32 v179, v105, v116, neg(0) op_sel_hi:[1,0,0]    ; cc2000b3 8a02e969
	v_fma_mix_f32 v105, v105, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200869 8a02e969
	v_fma_mix_f32 v180, v81, v116, neg(0) op_sel_hi:[1,0,0]     ; cc2000b4 8a02e951
	v_fma_mix_f32 v81, v81, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200851 8a02e951
	v_fma_mix_f32 v181, v93, v116, neg(0) op_sel_hi:[1,0,0]     ; cc2000b5 8a02e95d
	v_fma_mix_f32 v93, v93, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085d 8a02e95d
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v146, v84, vcc_lo                     ; 0202a992
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v148, v85, vcc_lo                     ; 0202ab94
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v176, v94, vcc_lo                     ; 0202bdb0
	v_fma_mix_f32 v182, v96, v116, neg(0) op_sel_hi:[1,0,0]     ; cc2000b6 8a02e960
	v_fma_mix_f32 v96, v96, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200860 8a02e960
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v177, v95, vcc_lo                     ; 0202bfb1
	v_fma_mix_f32 v183, v97, v116, neg(0) op_sel_hi:[1,0,0]     ; cc2000b7 8a02e961
	v_fma_mix_f32 v97, v97, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200861 8a02e961
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v178, v104, vcc_lo                    ; 0202d1b2
	v_lshl_add_u32 v98, v98, 5, s34                             ; d6460062 00890b62
	v_lshl_add_u32 v99, v99, 5, s34                             ; d6460063 00890b63
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v179, v105, vcc_lo                    ; 0202d3b3
	v_lshl_add_u32 v100, v100, 5, s34                           ; d6460064 00890b64
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v180, v81, vcc_lo                     ; 0202a3b4
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v181, v93, vcc_lo                     ; 0202bbb5
	v_lshl_add_u32 v101, v101, 5, s34                           ; d6460065 00890b65
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v182, v96, vcc_lo                     ; 0202c1b6
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v183, v97, vcc_lo                     ; 0202c3b7
(invalid instruction)                                        ; cc0f001a
	v_min_num_f64_e32 v[1:2], v[26:27], v[98:99]                ; 1a02c51a
(invalid instruction)                                        ; cc0f001c
	v_min_num_f64_e32 v[1:2], v[28:29], v[99:100]               ; 1a02c71c
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[32:33], v[100:101]              ; 1a02c920
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[101:102]              ; 1a02cb21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f001a
	v_min_num_f64_e32 v[1:2], v[26:27], v[28:29]                ; 1a02391a
(invalid instruction)                                        ; cc0f001a
	v_min_num_f64_e32 v[1:2], v[26:27], v[32:33]                ; 1a02411a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; cc0f001a
	v_min_num_f64_e32 v[1:2], v[26:27], v[33:34]                ; 1a02431a
	v_add_lshl_u32 v110, s9, v110, 2                            ; d647006e 020adc09
	v_permlanex16_b32 v27, v26, s28, s30 op_sel:[1,1]           ; d65c181b 0078391a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f001a
	v_min_num_f64_e32 v[1:2], v[26:27], v[27:28]                ; 1a02371a
	v_add_f16_e32 v28, v26, v154/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 6439351a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v28, s27, v28                             ; 6238381b
	v_cvt_f32_f16_e32 v32, v28                                  ; 7e40171c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v32, v32                                      ; 7e405520
	v_fma_mix_f32 v33, v147, v32, neg(0) op_sel_hi:[1,0,0]      ; cc200021 8a024193
	v_fma_mix_f32 v40, v149, v32, neg(0) op_sel_hi:[1,0,0]      ; cc200028 8a024195
	v_fma_mix_f32 v41, v92, v32, neg(0) op_sel_hi:[1,0,0]       ; cc200029 8a02415c
	v_fma_mix_f32 v92, v92, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085c 8a02415c
	v_fma_mix_f32 v149, v149, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a024195
	v_fma_mix_f32 v147, v147, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200893 8a024193
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v41, v92, vcc_lo                      ; 0202b929
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v33, v147, vcc_lo                     ; 02032721
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v40, v149, vcc_lo                     ; 02032b28
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v110, s[40:43], null offen       ; c405c07c 40805028 0000006e
	buffer_load_b128 v[56:59], v110, s[40:43], null offen offset:16 ; c405c07c 40805038 0000106e
	v_fma_mix_f32 v45, v86, v32, neg(0) op_sel_hi:[1,0,0]       ; cc20002d 8a024156
	v_fma_mix_f32 v44, v64, v32, neg(0) op_sel_hi:[1,0,0]       ; cc20002c 8a024140
	v_fma_mix_f32 v64, v64, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200840 8a024140
	v_fma_mix_f32 v86, v86, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200856 8a024156
	v_fma_mix_f32 v46, v87, v32, neg(0) op_sel_hi:[1,0,0]       ; cc20002e 8a024157
	v_fma_mix_f32 v87, v87, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200857 8a024157
	v_fma_mix_f32 v47, v132, v32, neg(0) op_sel_hi:[1,0,0]      ; cc20002f 8a024184
	v_fma_mix_f32 v132, v132, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200884 8a024184
	v_fma_mix_f32 v68, v106, v32, neg(0) op_sel_hi:[1,0,0]      ; cc200044 8a02416a
	v_fma_mix_f32 v106, v106, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086a 8a02416a
	v_fma_mix_f32 v69, v107, v32, neg(0) op_sel_hi:[1,0,0]      ; cc200045 8a02416b
	v_fma_mix_f32 v107, v107, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086b 8a02416b
	v_fma_mix_f32 v70, v108, v32, neg(0) op_sel_hi:[1,0,0]      ; cc200046 8a02416c
	v_fma_mix_f32 v108, v108, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086c 8a02416c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v44, v64, vcc_lo                      ; 0202812c
	v_fma_mix_f32 v64, v133, v32, neg(0) op_sel_hi:[1,0,0]      ; cc200040 8a024185
	v_fma_mix_f32 v133, v133, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200885 8a024185
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v45, v86, vcc_lo                      ; 0202ad2d
	v_fma_mix_f32 v71, v109, v32, neg(0) op_sel_hi:[1,0,0]      ; cc200047 8a02416d
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v46, v87, vcc_lo                      ; 0202af2e
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v90, s6, v90, 2                              ; d647005a 020ab406
	buffer_load_b128 v[84:87], v90, s[36:39], null offen        ; c405c07c 40804854 0000005a
	v_fma_mix_f32 v109, v109, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086d 8a02416d
	v_fma_mix_f32 v72, v98, v32, neg(0) op_sel_hi:[1,0,0]       ; cc200048 8a024162
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v47, v132, vcc_lo                     ; 0203092f
	v_fma_mix_f32 v98, v98, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200862 8a024162
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v68, v106, vcc_lo                     ; 0202d544
	v_fma_mix_f32 v73, v99, v32, neg(0) op_sel_hi:[1,0,0]       ; cc200049 8a024163
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v69, v107, vcc_lo                     ; 0202d745
	v_fma_mix_f32 v99, v99, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200863 8a024163
	v_fma_mix_f32 v74, v100, v32, neg(0) op_sel_hi:[1,0,0]      ; cc20004a 8a024164
	v_fma_mix_f32 v100, v100, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200864 8a024164
	v_fma_mix_f32 v75, v101, v32, neg(0) op_sel_hi:[1,0,0]      ; cc20004b 8a024165
	v_fma_mix_f32 v101, v101, v32, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200865 8a024165
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v72, v98, vcc_lo                      ; 0202c548
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v73, v99, vcc_lo                      ; 0202c749
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v74, v100, vcc_lo                     ; 0202c94a
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v75, v101, vcc_lo                     ; 0202cb4b
	buffer_load_b128 v[72:75], v90, s[36:39], null offen offset:512 ; c405c07c 40804848 0002005a
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v70, v108, vcc_lo                     ; 0202d946
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v64, v133, vcc_lo                     ; 02030b40
	v_lshl_add_u32 v102, v102, 5, s34                           ; d6460066 00890b66
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v71, v109, vcc_lo                     ; 0202db47
	v_lshl_add_u32 v103, v103, 5, s34                           ; d6460067 00890b67
	v_lshl_add_u32 v112, v112, 5, s34                           ; d6460070 00890b70
	v_lshl_add_u32 v113, v113, 5, s34                           ; d6460071 00890b71
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[60:61], v[102:103]              ; 1a02cd3c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
(invalid instruction)                                        ; cc0f003d
	v_min_num_f64_e32 v[1:2], v[61:62], v[103:104]              ; 1a02cf3d
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[112:113]              ; 1a02e14d
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[113:114]              ; 1a02e350
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[60:61], v[61:62]                ; 1a027b3c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[60:61], v[77:78]                ; 1a029b3c
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[60:61], v[80:81]                ; 1a02a13c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v77, v60, s28, s30 op_sel:[1,1]           ; d65c184d 0078393c
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[60:61], v[77:78]                ; 1a029b3c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v80, v60, v188/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64a1793c
	v_max_num_f16_e32 v80, s27, v80                             ; 62a0a01b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v81, v80                                  ; 7ea21750
	v_rcp_f32_e32 v81, v81                                      ; 7ea25551
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v94, v135, v81, neg(0) op_sel_hi:[1,0,0]      ; cc20005e 8a02a387
	v_fma_mix_f32 v90, v67, v81, neg(0) op_sel_hi:[1,0,0]       ; cc20005a 8a02a343
	v_fma_mix_f32 v92, v36, v81, neg(0) op_sel_hi:[1,0,0]       ; cc20005c 8a02a324
	v_fma_mix_f32 v36, v36, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200824 8a02a324
	v_fma_mix_f32 v82, v65, v81, neg(0) op_sel_hi:[1,0,0]       ; cc200052 8a02a341
	v_fma_mix_f32 v65, v65, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200841 8a02a341
	v_fma_mix_f32 v83, v66, v81, neg(0) op_sel_hi:[1,0,0]       ; cc200053 8a02a342
	v_fma_mix_f32 v66, v66, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200842 8a02a342
	v_fma_mix_f32 v67, v67, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200843 8a02a343
	v_fma_mix_f32 v93, v134, v81, neg(0) op_sel_hi:[1,0,0]      ; cc20005d 8a02a386
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v82, v65, vcc_lo                      ; 02028352
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v83, v66, vcc_lo                      ; 02028553
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v90, v67, vcc_lo                      ; 0202875a
	buffer_load_b128 v[64:67], v110, s[40:43], null offen offset:64 ; c405c07c 40805040 0000406e
	v_fma_mix_f32 v134, v134, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200886 8a02a386
	v_fma_mix_f32 v135, v135, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200887 8a02a387
	v_fma_mix_f32 v95, v144, v81, neg(0) op_sel_hi:[1,0,0]      ; cc20005f 8a02a390
	v_fma_mix_f32 v144, v144, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200890 8a02a390
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v92, v36, vcc_lo                      ; 0202495c
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v93, v134, vcc_lo                     ; 02030d5d
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v94, v135, vcc_lo                     ; 02030f5e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v95, v144, vcc_lo                     ; 0203215f
	buffer_load_b128 v[92:95], v110, s[40:43], null offen offset:80 ; c405c07c 4080505c 0000506e
	v_fma_mix_f32 v96, v145, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200060 8a02a391
	v_fma_mix_f32 v145, v145, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a02a391
	v_fma_mix_f32 v97, v150, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200061 8a02a396
	v_fma_mix_f32 v150, v150, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200896 8a02a396
	v_fma_mix_f32 v98, v151, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200062 8a02a397
	v_fma_mix_f32 v151, v151, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a02a397
	v_fma_mix_f32 v99, v22, v81, neg(0) op_sel_hi:[1,0,0]       ; cc200063 8a02a316
	v_fma_mix_f32 v22, v22, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a02a316
	v_fma_mix_f32 v100, v23, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200064 8a02a317
	v_fma_mix_f32 v23, v23, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a02a317
	v_fma_mix_f32 v101, v102, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200065 8a02a366
	v_fma_mix_f32 v102, v102, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200866 8a02a366
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v96, v145, vcc_lo                     ; 02032360
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v97, v150, vcc_lo                     ; 02032d61
	v_fma_mix_f32 v104, v113, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200068 8a02a371
	v_fma_mix_f32 v113, v113, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200871 8a02a371
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v98, v151, vcc_lo                     ; 02032f62
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v99, v22, vcc_lo                      ; 02022d63
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[18:19], v[26:27], 0 ; cc464090 1a023512
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v100, v23, vcc_lo                     ; 02022f64
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[18:19], v[32:33], 0 ; cc4640b0 1a024112
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v101, v102, vcc_lo                    ; 0202cd65
	v_fma_mix_f32 v102, v103, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200066 8a02a367
	v_fma_mix_f32 v103, v103, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200867 8a02a367
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[30:31], v[44:45], v[144:151] ; cc464090 1e42591e
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v103, v112, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200067 8a02a370
	v_fma_mix_f32 v112, v112, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200870 8a02a370
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[60:61], v[176:183] ; cc4640b0 1ec2791e
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v103, v112, vcc_lo                    ; 0202e167
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[18:19], v[62:63], 0 ; cc464060 1a027d12
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v104, v113, vcc_lo                    ; 0202e368
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[0:1], 0 ; cc464070 1a020112
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[34:35], v[46:47], v[144:151] ; cc464090 1e425d22
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[34:35], v[70:71], v[176:183] ; cc4640b0 1ec28d22
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[30:31], v[24:25], v[96:103] ; cc464060 1d82311e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[2:3], v[112:119] ; cc464070 1dc2051e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[20:21], v[68:69], v[144:151] ; cc464090 1e428914
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[78:79], v[96:103] ; cc464060 1d829d22
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[4:5], v[112:119] ; cc464070 1dc20922
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[20:21], v[22:23], v[176:183] ; cc4640b0 1ec22d14
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[10:11], v[96:103] ; cc464060 1d821514
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[6:7], v[112:119] ; cc464070 1dc20d14
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[8:9], v[26:27], 0 ; cc464090 1a023508
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[8:9], v[32:33], 0 ; cc4640b0 1a024108
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[62:63], 0  ; cc464060 1a027d08
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[8:9], v[0:1], 0   ; cc464070 1a020108
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_mul_f32 v9, v137, v41 :: v_dual_mul_f32 v8, v136, v40 ; c8c65389 09085188
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[12:13], v[44:45], v[144:151] ; cc464090 1e42590c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[60:61], v[176:183] ; cc4640b0 1ec2790c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[24:25], v[96:103] ; cc464060 1d82310c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[2:3], v[112:119] ; cc464070 1dc2050c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mul_f32 v13, v141, v57 :: v_dual_mul_f32 v12, v140, v56 ; c8c6738d 0d0c718c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[16:17], v[46:47], v[144:151] ; cc464090 1e425d10
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[70:71], v[176:183] ; cc4640b0 1ec28d10
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[78:79], v[96:103] ; cc464060 1d829d10
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[4:5], v[112:119] ; cc464070 1dc20910
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[14:15], v[68:69], v[144:151] ; cc464090 1e42890e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[14:15], v[22:23], v[176:183] ; cc4640b0 1ec22d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[14:15], v[10:11], v[96:103] ; cc464060 1d82150e
	v_dual_mul_f32 v11, v139, v43 :: v_dual_mul_f32 v10, v138, v42 ; c8c6578b 0b0a558a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[6:7], v[112:119] ; cc464070 1dc20d0e
	v_dual_mul_f32 v15, v143, v59 :: v_dual_mul_f32 v14, v142, v58 ; c8c6778f 0f0e758e
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_dual_mul_f32 v97, v153, v41 :: v_dual_mul_f32 v96, v152, v40 ; c8c65399 61605198
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_mul_f32 v101, v157, v57 :: v_dual_mul_f32 v100, v156, v56 ; c8c6739d 6564719c
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_dual_mul_f32 v99, v155, v43 :: v_dual_mul_f32 v98, v154, v42 ; c8c6579b 6362559a
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_dual_mul_f32 v103, v159, v59 :: v_dual_mul_f32 v102, v158, v58 ; c8c6779f 6766759e
	v_dual_mul_f32 v137, v169, v41 :: v_dual_mul_f32 v136, v168, v40 ; c8c653a9 898851a8
	v_dual_mul_f32 v139, v171, v43 :: v_dual_mul_f32 v138, v170, v42 ; c8c657ab 8b8a55aa
	v_dual_mul_f32 v141, v173, v57 :: v_dual_mul_f32 v140, v172, v56 ; c8c673ad 8d8c71ac
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v117, v165, v57 :: v_dual_mul_f32 v116, v164, v56 ; c8c673a5 757471a4
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_dual_mul_f32 v113, v161, v41 :: v_dual_mul_f32 v112, v160, v40 ; c8c653a1 717051a0
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_mul_f32 v115, v163, v43 :: v_dual_mul_f32 v114, v162, v42 ; c8c657a3 737255a2
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_mul_f32 v119, v167, v59 :: v_dual_mul_f32 v118, v166, v58 ; c8c677a7 777675a6
	v_dual_mul_f32 v143, v175, v59 :: v_dual_mul_f32 v142, v174, v58 ; c8c677af 8f8e75ae
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[84:85], v[18:19], v[8:15] ; cc464008 1c222554
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[84:85], v[34:35], v[136:143] ; cc464088 1e224554
	s_add_co_u32 s22, s2, s22                                   ; 80161602
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[84:85], v[30:31], v[112:119] ; cc464070 1dc23d54
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[84:85], v[20:21], v[96:103] ; cc464060 1d822954
	s_add_co_u32 s14, s2, s14                                   ; 800e0e02
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v105, v111, s22, v29                             ; d6550069 04742d6f
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[72:73], v[0:1], v[8:15] ; cc464008 1c220148
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[72:73], v[6:7], v[136:143] ; cc464088 1e220d48
	v_add3_u32 v106, v111, s14, v29                             ; d655006a 04741d6f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[72:73], v[4:5], v[112:119] ; cc464070 1dc20948
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[2:3], v[96:103] ; cc464060 1d820548
	s_add_co_u32 s13, s2, s13                                   ; 800d0d02
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_add3_u32 v107, v111, s13, v29                             ; d655006b 04741b6f
	s_add_co_u32 s2, s2, s29                                    ; 80021d02
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v108, v111, s2, v29                              ; d655006c 0474056f
	s_clause 0x3                                                ; bf850003
	buffer_store_b64 v[8:9], v105, s[16:19], null offen         ; c406c07c 40802008 00000069
	buffer_store_b64 v[10:11], v106, s[16:19], null offen       ; c406c07c 4080200a 0000006a
	buffer_store_b64 v[12:13], v107, s[16:19], null offen       ; c406c07c 4080200c 0000006b
	buffer_store_b64 v[14:15], v108, s[16:19], null offen       ; c406c07c 4080200e 0000006c
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_dual_mul_f32 v9, v185, v65 :: v_dual_mul_f32 v8, v184, v64 ; c8c683b9 090881b8
	v_dual_mul_f32 v11, v187, v67 :: v_dual_mul_f32 v10, v186, v66 ; c8c687bb 0b0a85ba
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mul_f32 v13, v189, v93 :: v_dual_mul_f32 v12, v188, v92 ; c8c6bbbd 0d0cb9bc
	v_dual_mul_f32 v15, v191, v95 :: v_dual_mul_f32 v14, v190, v94 ; c8c6bfbf 0f0ebdbe
	v_dual_mul_f32 v41, v49, v65 :: v_dual_mul_f32 v40, v48, v64 ; c8c68331 29288130
	v_dual_mul_f32 v43, v51, v67 :: v_dual_mul_f32 v42, v50, v66 ; c8c68733 2b2a8532
	v_dual_mul_f32 v45, v53, v93 :: v_dual_mul_f32 v44, v52, v92 ; c8c6bb35 2d2cb934
	v_dual_mul_f32 v47, v55, v95 :: v_dual_mul_f32 v46, v54, v94 ; c8c6bf37 2f2ebd36
	v_dual_mul_f32 v49, v131, v65 :: v_dual_mul_f32 v48, v130, v64 ; c8c68383 31308182
	v_dual_mul_f32 v51, v38, v67 :: v_dual_mul_f32 v50, v37, v66 ; c8c68726 33328525
	v_dual_mul_f32 v53, v76, v93 :: v_dual_mul_f32 v52, v39, v92 ; c8c6bb4c 3534b927
	v_dual_mul_f32 v55, v128, v95 :: v_dual_mul_f32 v54, v91, v94 ; c8c6bf80 3736bd5b
	v_dual_mul_f32 v57, v121, v65 :: v_dual_mul_f32 v56, v120, v64 ; c8c68379 39388178
	v_dual_mul_f32 v59, v123, v67 :: v_dual_mul_f32 v58, v122, v66 ; c8c6877b 3b3a857a
	v_add3_u32 v110, v29, s14, s24                              ; d655006e 00601d1d
	v_add3_u32 v112, v29, s13, s24                              ; d6550070 00601b1d
	v_add3_u32 v109, v29, s22, s24                              ; d655006d 00602d1d
	v_add3_u32 v29, v29, s2, s24                                ; d655001d 0060051d
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[86:87], v[18:19], v[8:15] ; cc464008 1c222556
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[86:87], v[20:21], v[40:47] ; cc464028 1ca22956
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[86:87], v[30:31], v[48:55] ; cc464030 1cc23d56
	v_dual_mul_f32 v61, v125, v93 :: v_dual_add_nc_u32 v110, v110, v111 ; c8e0bb7d 3d6edf6e
	v_dual_mul_f32 v63, v89, v95 :: v_dual_add_nc_u32 v112, v111, v112 ; c8e0bf59 3f70e16f
	v_dual_mul_f32 v60, v124, v92 :: v_dual_add_nc_u32 v109, v109, v111 ; c8e0b97c 3c6cdf6d
	v_dual_mul_f32 v62, v88, v94 :: v_dual_add_nc_u32 v29, v29, v111 ; c8e0bd58 3e1cdf1d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[86:87], v[34:35], v[56:63] ; cc464038 1ce24556
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[74:75], v[0:1], v[8:15] ; cc464008 1c22014a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[74:75], v[2:3], v[40:47] ; cc464028 1ca2054a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[74:75], v[4:5], v[48:55] ; cc464030 1cc2094a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[74:75], v[6:7], v[56:63] ; cc464038 1ce20d4a
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_clause 0x3                                                ; bf850003
	buffer_store_b64 v[0:1], v109, s[16:19], null offen         ; c406c07c 40802000 0000006d
	buffer_store_b64 v[2:3], v110, s[16:19], null offen         ; c406c07c 40802002 0000006e
	buffer_store_b64 v[4:5], v112, s[16:19], null offen         ; c406c07c 40802004 00000070
	buffer_store_b64 v[6:7], v29, s[16:19], null offen          ; c406c07c 40802006 0000001d
	s_branch BB78                                               ; bfa02cc7
BB20:
	s_cmp_eq_i32 s17, 12                                        ; bf008c11
	s_cbranch_scc0 BB34                                         ; bfa10b28
BB21:
	s_mov_b32 s14, s1                                           ; be8e0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[0:1], 0x0                           ; f4004400 f8000000
	s_load_b256 s[48:55], s[0:1], 0x30                          ; f4006c00 f8000030
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_max_i32 s13, s13, 0                                       ; 8a0d800d
	s_add_co_u32 s15, s11, -1                                   ; 800fc10b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s13, s13, s15                                     ; 890d0f0d
	s_max_i32 s29, s29, 0                                       ; 8a1d801d
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	s_min_i32 s29, s29, s12                                     ; 891d0c1d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s29, s29, s11                                     ; 961d0b1d
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_add_co_u32 s13, s29, s13                                  ; 800d0d1d
	s_lshl_b32 s13, s13, 9                                      ; 840d890d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s21, s14, s13                                  ; 80150d0e
	s_max_i32 s20, s20, 0                                       ; 8a148014
	v_add3_u32 v5, v3, s21, 0x100                               ; d6550005 03fc2b03 00000100
	v_add3_u32 v4, v1, s21, v3                                  ; d6550004 040c2b01
	s_min_i32 s20, s20, s15                                     ; 89140f14
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s29, s29, s20                                  ; 801d141d
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_lshl_b32 s29, s29, 9                                      ; 841d891d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s14, s14, s29                                  ; 800e1d0e
	v_add3_u32 v7, v3, s14, 0x100                               ; d6550007 03fc1d03 00000100
	v_add3_u32 v6, v1, s14, v3                                  ; d6550006 040c1d01
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[8:9], v4, s[16:19], null offen            ; c405407c 40802008 00000004
	buffer_load_b64 v[4:5], v5, s[16:19], null offen            ; c405407c 40802004 00000005
	buffer_load_b64 v[10:11], v6, s[16:19], null offen          ; c405407c 4080200a 00000006
	buffer_load_b64 v[6:7], v7, s[16:19], null offen            ; c405407c 40802006 00000007
	v_lshlrev_b32_e32 v12, 2, v0                                ; 30180082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v13, s3, v12, 2                              ; d647000d 020a1803
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[16:19], v13, s[52:55], null offen        ; c405c07c 40806810 0000000d
	buffer_load_b128 v[20:23], v13, s[52:55], null offen offset:512 ; c405c07c 40806814 0002000d
	buffer_load_b128 v[24:27], v13, s[52:55], null offen offset:1024 ; c405c07c 40806818 0004000d
	buffer_load_b128 v[28:31], v13, s[52:55], null offen offset:1536 ; c405c07c 4080681c 0006000d
	buffer_load_b128 v[32:35], v13, s[52:55], null offen offset:2048 ; c405c07c 40806820 0008000d
	buffer_load_b128 v[36:39], v13, s[52:55], null offen offset:2560 ; c405c07c 40806824 000a000d
	buffer_load_b128 v[40:43], v13, s[52:55], null offen offset:3072 ; c405c07c 40806828 000c000d
	buffer_load_b128 v[44:47], v13, s[52:55], null offen offset:3584 ; c405c07c 4080682c 000e000d
	v_lshrrev_b32_e32 v0, 4, v0                                 ; 32000084
	s_mov_b64 s[20:21], s[48:49]                                ; be940130
	s_mov_b64 s[22:23], s[50:51]                                ; be960132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshlrev_b32_e32 v0, 3, v0                                 ; 30000083
	v_add_lshl_u32 v14, s8, v0, 2                               ; d647000e 020a0008
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v14, s[20:23], null offen        ; c405c07c 40802830 0000000e
	buffer_load_b128 v[52:55], v14, s[20:23], null offen offset:16 ; c405c07c 40802834 0000100e
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add_lshl_u32 v15, s4, v12, 2                              ; d647000f 020a1804
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[56:59], v15, s[52:55], null offen        ; c405c07c 40806838 0000000f
	buffer_load_b128 v[60:63], v15, s[52:55], null offen offset:512 ; c405c07c 4080683c 0002000f
	buffer_load_b128 v[64:67], v15, s[52:55], null offen offset:1024 ; c405c07c 40806840 0004000f
	buffer_load_b128 v[68:71], v15, s[52:55], null offen offset:1536 ; c405c07c 40806844 0006000f
	buffer_load_b128 v[72:75], v15, s[52:55], null offen offset:2048 ; c405c07c 40806848 0008000f
	buffer_load_b128 v[76:79], v15, s[52:55], null offen offset:2560 ; c405c07c 4080684c 000a000f
	buffer_load_b128 v[80:83], v15, s[52:55], null offen offset:3072 ; c405c07c 40806850 000c000f
	buffer_load_b128 v[84:87], v15, s[52:55], null offen offset:3584 ; c405c07c 40806854 000e000f
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_cndmask_b32_e64 v8, v8, 0, s31                            ; d5010008 007d0108
	v_cndmask_b32_e64 v9, v9, 0, s31                            ; d5010009 007d0109
	s_wait_loadcnt 0x14                                         ; bfc00014
	v_cndmask_b32_e64 v5, v5, 0, s31                            ; d5010005 007d0105
	v_cndmask_b32_e64 v4, v4, 0, s31                            ; d5010004 007d0104
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_cndmask_b32_e64 v10, v10, 0, s37                          ; d501000a 0095010a
	v_cndmask_b32_e64 v11, v11, 0, s37                          ; d501000b 0095010b
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v7, v7, 0, s37                            ; d5010007 00950107
	v_cndmask_b32_e64 v6, v6, 0, s37                            ; d5010006 00950106
	v_cvt_pk_f32_fp8_e32 v[92:93], v136                         ; 7eb8dd88
	v_cvt_pk_f32_fp8_e32 v[90:91], v8                           ; 7eb4dd08
	v_dual_mov_b32 v89, v9 :: v_dual_mov_b32 v88, v8            ; ca100109 59580108
	v_cvt_pk_f32_fp8_e32 v[94:95], v9                           ; 7ebcdd09
	v_cvt_pk_f32_fp8_e32 v[8:9], v137                           ; 7e10dd89
	v_dual_mov_b32 v97, v5 :: v_dual_mov_b32 v96, v4            ; ca100105 61600104
	v_cvt_pk_f32_fp8_e32 v[100:101], v10                        ; 7ec8dd0a
	v_dual_mov_b32 v99, v11 :: v_dual_mov_b32 v98, v10          ; ca10010b 6362010a
	v_cvt_pk_f32_fp8_e32 v[102:103], v138                       ; 7eccdd8a
	v_cvt_pk_f32_fp8_e32 v[104:105], v11                        ; 7ed0dd0b
	v_dual_mov_b32 v107, v7 :: v_dual_mov_b32 v106, v6          ; ca100107 6b6a0106
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[88:89], 0 ; cc464070 1a02b110
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[88:89], 0 ; cc464080 1a02b112
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[98:99], 0 ; cc464078 1a02c510
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[98:99], 0 ; cc464088 1a02c512
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[96:97], v[112:119] ; cc464070 1dc2c114
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[20:21], v[106:107], v[120:127] ; cc464078 1de2d514
	v_maxmin_num_f32 v110, -4.0, v116, 4.0                      ; d669006e 03dae8f7
	v_maxmin_num_f32 v20, -4.0, v114, 4.0                       ; d6690014 03dae4f7
	v_maxmin_num_f32 v108, -4.0, v115, 4.0                      ; d669006c 03dae6f7
	v_maxmin_num_f32 v18, -4.0, v113, 4.0                       ; d6690012 03dae2f7
	v_maxmin_num_f32 v16, -4.0, v112, 4.0                       ; d6690010 03dae0f7
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v21, 0xab28, |v20|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfe28ff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v19, 0xab28, |v18|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206213 0bfe24ff 3728ab28
	v_fma_mix_f32 v17, 0xab28, |v16|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206211 0bfe20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fmaak_f32 v109, v109, v108, 0x3f650000                    ; 5adad96d 3f650000
	v_dual_fmaak_f32 v19, v19, v18, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v17, 0x3f650000 ; c8422513 13102310 3f650000
	v_maxmin_num_f32 v144, -4.0, v121, 4.0                      ; d6690090 03daf2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_mul_f32 v115, v109, v115 :: v_dual_fmaak_f32 v20, v20, v21, 0x3f650000 ; c8c2e76d 73142b14 3f650000
	v_dual_mul_f32 v113, v113, v19 :: v_dual_mul_f32 v112, v112, v16 ; c8c62771 71702170
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v117, 4.0                      ; d6690070 03daeaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v123, 4.0                      ; d6690094 03daf6f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v122, 4.0                      ; d6690092 03daf4f7
	v_dual_mul_f32 v117, v117, v113 :: v_dual_mul_f32 v116, v116, v110 ; c8c6e375 7574dd74
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v125, 4.0                      ; d6690098 03dafaf7
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v116, -4.0, v119, 4.0                      ; d6690074 03daeef7
	v_maxmin_num_f32 v150, -4.0, v124, 4.0                      ; d6690096 03daf8f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v127, 4.0                      ; d669009c 03dafef7
	v_dual_fmaak_f32 v117, v116, v117, 0x3f650000 :: v_dual_mul_f32 v114, v114, v20 ; c846eb74 75722972 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v126, 4.0                      ; d669009a 03dafcf7
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v118, 4.0                      ; d6690072 03daecf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[96:97], v[128:135] ; cc464080 1e02c116
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_dual_mul_f32 v119, v119, v117 :: v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 ; c8c2eb77 7772e772 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v118, v118, v114 ; c8472191 9176e576 3f650000
	v_maxmin_num_f32 v160, -4.0, v129, 4.0                      ; d66900a0 03db02f7
	v_maxmin_num_f32 v158, -4.0, v128, 4.0                      ; d669009e 03db00f7
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v120, 4.0                      ; d6690076 03daf0f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v131, 4.0                      ; d66900a4 03db06f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v130, 4.0                      ; d66900a2 03db04f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_mul_f32 v121, v121, v145 :: v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 ; c8c32379 7976ef76 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[106:107], v[136:143] ; cc464088 1e22d516
	v_maxmin_num_f32 v168, -4.0, v133, 4.0                      ; d66900a8 03db0af7
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v120, v120, v118 ; c8472995 9578ed78 3f650000
	v_maxmin_num_f32 v166, -4.0, v132, 4.0                      ; d66900a6 03db08f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d3
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v123, v123, v149 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8c32b7b 7b932792 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v135, 4.0                      ; d66900ac 03db0ef7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v122, v122, v146 ; c8473199 997b257a 3f650000
	v_maxmin_num_f32 v170, -4.0, v134, 4.0                      ; d66900aa 03db0cf7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v125, v125, v153 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8c3337d 7d972f96 3f650000
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v137, 4.0                      ; d66900b0 03db12f7
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v124, v124, v150 ; c847399d 9d7d2d7c 3f650000
	v_maxmin_num_f32 v174, -4.0, v136, 4.0                      ; d66900ae 03db10f7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_mul_f32 v127, v127, v157 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8c33b7f 7f9b379a 3f650000
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v139, 4.0                      ; d66900b4 03db16f7
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_mul_f32 v126, v126, v154 ; c84741a1 a17f357e 3f650000
	v_maxmin_num_f32 v178, -4.0, v138, 4.0                      ; d66900b2 03db14f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v129, v129, v161 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c8c34381 819f3f9e 3f650000
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v141, 4.0                      ; d66900b8 03db1af7
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_mul_f32 v128, v128, v158 ; c84749a5 a5813d80 3f650000
	v_maxmin_num_f32 v182, -4.0, v140, 4.0                      ; d66900b6 03db18f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v131, v131, v165 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8c34b83 83a347a2 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v143, 4.0                      ; d66900bc 03db1ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_mul_f32 v130, v130, v162 ; c84751a9 a9834582 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[88:89], 0 ; cc464070 1a02b118
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v133, v133, v169 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c8c35385 85a74fa6 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v132, v132, v166 ; c84759ad ad854d84 3f650000
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[96:97], v[112:119] ; cc464070 1dc2c11c
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v135, v135, v173 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8c35b87 87ab57aa 3f650000
	v_maxmin_num_f32 v186, -4.0, v142, 4.0                      ; d66900ba 03db1cf7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_mul_f32 v134, v134, v170 ; c84761b1 b1875586 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v112, 4.0                      ; d66900be 03dae0f7
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v137, v137, v177 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c8c36389 89af5fae 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[98:99], 0 ; cc464078 1a02c518
	v_maxmin_num_f32 v15, -4.0, v114, 4.0                       ; d669000f 03dae4f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v136, v136, v174 ; c84769b5 b5895d88 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v25, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe1eff 3728ab28
	v_dual_mul_f32 v139, v139, v181 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c8c36b8b 8bb367b2 3f650000
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fmaak_f32 v15, v15, v25, 0x3f650000                       ; 5a1e330f 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[106:107], v[120:127] ; cc464078 1de2d51c
	v_maxmin_num_f32 v28, -4.0, v115, 4.0                       ; d669001c 03dae6f7
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_mul_f32 v138, v138, v178 ; c84771b9 b98b658a 3f650000
	v_maxmin_num_f32 v108, -4.0, v116, 4.0                      ; d669006c 03dae8f7
	v_maxmin_num_f32 v110, -4.0, v117, 4.0                      ; d669006e 03daeaf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v141, v141, v185 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c8c3738d 8db76fb6 3f650000
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v140, v140, v182 ; c84779bd bd8d6d8c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b8f 8fbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v113, 4.0                      ; d66900bf 03dae2f7
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v108 ; c8c6df75 7574d974
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 :: v_dual_mul_f32 v112, v112, v190 ; c846391d 1d717d70 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v115, v115, v29 :: v_dual_mul_f32 v114, v114, v15 ; c8c63b73 73721f72
	v_dual_fmaak_f32 v13, v191, v13, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8421bbf 0dbb77ba 3f650000
	v_maxmin_num_f32 v116, -4.0, v120, 4.0                      ; d6690074 03daf0f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v113, v113, v13 :: v_dual_mul_f32 v142, v142, v186 ; c8c61b71 718f758e
	v_maxmin_num_f32 v128, -4.0, v123, 4.0                      ; d6690080 03daf6f7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v118, 4.0                      ; d6690070 03daecf7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v119, 4.0                      ; d6690072 03daeef7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v125, 4.0                      ; d6690084 03dafaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v124, 4.0                      ; d6690082 03daf8f7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c8430181 8174eb74 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v127, 4.0                      ; d6690088 03dafef7
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_mul_f32 v123, v123, v129 :: v_dual_mul_f32 v120, v120, v116 ; c8c7037b 7b78e978
	v_maxmin_num_f32 v134, -4.0, v126, 4.0                      ; d6690086 03dafcf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v119, v119, v115 :: v_dual_mul_f32 v118, v118, v112 ; c8c6e777 7776e176
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8431189 89830782 3f650000
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v121, 4.0                      ; d6690076 03daf2f7
	v_dual_mul_f32 v127, v127, v137 :: v_dual_mul_f32 v124, v124, v130 ; c8c7137f 7f7d057c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fmaak_f32 v119, v119, v118, 0x3f650000                    ; 5aeeed77 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_mul_f32_e32 v121, v121, v119                              ; 10f2ef79
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[88:89], 0 ; cc464070 1a02b11a
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v122, 4.0                      ; d6690078 03daf4f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[96:97], v[112:119] ; cc464070 1dc2c11e
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8430985 8578f378 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v125, v125, v133 :: v_dual_mul_f32 v122, v122, v120 ; c8c70b7d 7d7af17a
	v_maxmin_num_f32 v140, -4.0, v113, 4.0                      ; d669008c 03dae2f7
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v144, -4.0, v115, 4.0                      ; d6690090 03dae6f7
	v_maxmin_num_f32 v138, -4.0, v112, 4.0                      ; d669008a 03dae0f7
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v142, -4.0, v114, 4.0                      ; d669008e 03dae4f7
	v_maxmin_num_f32 v148, -4.0, v117, 4.0                      ; d6690094 03daeaf7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v116, 4.0                      ; d6690092 03dae8f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v119, 4.0                      ; d6690098 03daeef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c843198d 8d870f86 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v118, 4.0                      ; d6690096 03daecf7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c8432191 918b178a 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432995 958f1f8e 3f650000
	v_dual_mul_f32 v113, v113, v141 :: v_dual_mul_f32 v126, v126, v134 ; c8c71b71 717f0d7e
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8433199 99932792 3f650000
	v_dual_mul_f32 v115, v115, v145 :: v_dual_mul_f32 v112, v112, v138 ; c8c72373 73711570
	v_dual_mul_f32 v117, v117, v149 :: v_dual_mul_f32 v114, v114, v142 ; c8c72b75 75731d72
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[98:99], 0 ; cc464078 1a02c51a
	v_dual_mul_f32 v119, v119, v153 :: v_dual_mul_f32 v116, v116, v146 ; c8c73377 77752574
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[106:107], v[120:127] ; cc464078 1de2d51e
	v_maxmin_num_f32 v164, -4.0, v125, 4.0                      ; d66900a4 03dafaf7
	v_maxmin_num_f32 v160, -4.0, v123, 4.0                      ; d66900a0 03daf6f7
	v_maxmin_num_f32 v154, -4.0, v120, 4.0                      ; d669009a 03daf0f7
	v_maxmin_num_f32 v156, -4.0, v121, 4.0                      ; d669009c 03daf2f7
	v_maxmin_num_f32 v158, -4.0, v122, 4.0                      ; d669009e 03daf4f7
	v_maxmin_num_f32 v162, -4.0, v124, 4.0                      ; d66900a2 03daf8f7
	v_maxmin_num_f32 v168, -4.0, v127, 4.0                      ; d66900a8 03dafef7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v126, 4.0                      ; d66900a6 03dafcf7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c84341a1 a19b379a 3f650000
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c843399d 9d972f96 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84349a5 a59f3f9e 3f650000
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84351a9 a9a347a2 3f650000
	v_dual_mul_f32 v123, v123, v161 :: v_dual_mul_f32 v120, v120, v154 ; c8c7437b 7b793578
	v_dual_mul_f32 v121, v121, v157 :: v_dual_mul_f32 v118, v118, v150 ; c8c73b79 79772d76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_mul_f32 v125, v125, v165 :: v_dual_mul_f32 v122, v122, v158 ; c8c74b7d 7d7b3d7a
	v_dual_mul_f32 v127, v127, v169 :: v_dual_mul_f32 v124, v124, v162 ; c8c7537f 7f7d457c
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[88:89], 0 ; cc464070 1a02b120
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[96:97], v[112:119] ; cc464070 1dc2c124
	v_maxmin_num_f32 v176, -4.0, v115, 4.0                      ; d66900b0 03dae6f7
	v_maxmin_num_f32 v174, -4.0, v114, 4.0                      ; d66900ae 03dae4f7
	v_maxmin_num_f32 v172, -4.0, v113, 4.0                      ; d66900ac 03dae2f7
	v_maxmin_num_f32 v170, -4.0, v112, 4.0                      ; d66900aa 03dae0f7
	v_maxmin_num_f32 v180, -4.0, v117, 4.0                      ; d66900b4 03daeaf7
	v_maxmin_num_f32 v178, -4.0, v116, 4.0                      ; d66900b2 03dae8f7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v119, 4.0                      ; d66900b8 03daeef7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v118, 4.0                      ; d66900b6 03daecf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84359ad ada74fa6 3f650000
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84361b1 b1ab57aa 3f650000
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84369b5 b5af5fae 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84371b9 b9b367b2 3f650000
	v_dual_mul_f32 v113, v113, v173 :: v_dual_mul_f32 v126, v126, v166 ; c8c75b71 717f4d7e
	v_dual_mul_f32 v115, v115, v177 :: v_dual_mul_f32 v112, v112, v170 ; c8c76373 73715570
	v_dual_mul_f32 v117, v117, v181 :: v_dual_mul_f32 v114, v114, v174 ; c8c76b75 75735d72
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v119, v119, v185 :: v_dual_mul_f32 v116, v116, v178 ; c8c77377 77756574
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[98:99], 0 ; cc464078 1a02c520
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[106:107], v[120:127] ; cc464078 1de2d524
	v_maxmin_num_f32 v190, -4.0, v122, 4.0                      ; d66900be 03daf4f7
	v_maxmin_num_f32 v186, -4.0, v120, 4.0                      ; d66900ba 03daf0f7
	v_maxmin_num_f32 v188, -4.0, v121, 4.0                      ; d66900bc 03daf2f7
	v_maxmin_num_f32 v15, -4.0, v124, 4.0                       ; d669000f 03daf8f7
	v_maxmin_num_f32 v108, -4.0, v125, 4.0                      ; d669006c 03dafaf7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v126, 4.0                      ; d669006e 03dafcf7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v127, 4.0                      ; d6690070 03dafef7
	v_fma_mix_f32 v37, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfe1eff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84379bd bdb76fb6 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v121, v121, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b79 79bf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v123, 4.0                      ; d66900bf 03daf6f7
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_mul_f32 v122, v122, v190 ; c846d96d 6d7b7d7a 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_dual_mul_f32 v127, v127, v113 :: v_dual_mul_f32 v126, v126, v110 ; c8c6e37f 7f7edd7e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v13, v13, v191, 0x3f650000 :: v_dual_mul_f32 v118, v118, v182 ; c8477f0d 0d776d76 3f650000
	v_dual_mul_f32 v123, v123, v13 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8c21b7b 7bbb77ba 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[88:89], 0 ; cc464070 1a02b122
	v_dual_fmaak_f32 v15, v15, v37, 0x3f650000 :: v_dual_mul_f32 v120, v120, v186 ; c8464b0f 0f797578 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_mul_f32 v125, v125, v109 :: v_dual_mul_f32 v124, v124, v15 ; c8c6db7d 7d7c1f7c
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[98:99], 0 ; cc464078 1a02c522
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[96:97], v[112:119] ; cc464070 1dc2c126
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[106:107], v[120:127] ; cc464078 1de2d526
	v_maxmin_num_f32 v138, -4.0, v117, 4.0                      ; d669008a 03daeaf7
	v_maxmin_num_f32 v130, -4.0, v113, 4.0                      ; d6690082 03dae2f7
	v_maxmin_num_f32 v136, -4.0, v116, 4.0                      ; d6690088 03dae8f7
	v_maxmin_num_f32 v132, -4.0, v114, 4.0                      ; d6690084 03dae4f7
	v_maxmin_num_f32 v134, -4.0, v115, 4.0                      ; d6690086 03dae6f7
	v_maxmin_num_f32 v128, -4.0, v112, 4.0                      ; d6690080 03dae0f7
	v_maxmin_num_f32 v140, -4.0, v118, 4.0                      ; d669008c 03daecf7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v119, 4.0                      ; d669008e 03daeef7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v120, 4.0                      ; d6690090 03daf0f7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v121, 4.0                      ; d6690092 03daf2f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c843158b 8b891388 3f650000
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430d87 87850b84 3f650000
	v_maxmin_num_f32 v148, -4.0, v122, 4.0                      ; d6690094 03daf4f7
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
	v_maxmin_num_f32 v150, -4.0, v123, 4.0                      ; d6690096 03daf6f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 ; c8431d8f 8f8d1b8c 3f650000
	v_dual_mul_f32 v117, v117, v139 :: v_dual_mul_f32 v116, v116, v136 ; c8c71775 75751174
	v_dual_mul_f32 v115, v115, v135 :: v_dual_mul_f32 v114, v114, v132 ; c8c70f73 73730972
	v_maxmin_num_f32 v152, -4.0, v124, 4.0                      ; d6690098 03daf8f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_mul_f32 v113, v113, v131 :: v_dual_mul_f32 v112, v112, v128 ; c8c70771 71710170
	v_maxmin_num_f32 v154, -4.0, v125, 4.0                      ; d669009a 03dafaf7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_dual_mul_f32 v119, v119, v143 :: v_dual_mul_f32 v118, v118, v140 ; c8c71f77 77771976
	v_maxmin_num_f32 v156, -4.0, v126, 4.0                      ; d669009c 03dafcf7
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v158, -4.0, v127, 4.0                      ; d669009e 03dafef7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_mul_f32 v121, v121, v147 :: v_dual_mul_f32 v120, v120, v144 ; c8c72779 79792178
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[88:89], 0 ; cc464070 1a02b128
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_dual_mul_f32 v123, v123, v151 :: v_dual_mul_f32 v122, v122, v148 ; c8c72f7b 7b7b297a
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_dual_mul_f32 v125, v125, v155 :: v_dual_mul_f32 v124, v124, v152 ; c8c7377d 7d7d317c
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[96:97], v[112:119] ; cc464070 1dc2c12c
	v_dual_mul_f32 v127, v127, v159 :: v_dual_mul_f32 v126, v126, v156 ; c8c73f7f 7f7f397e
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[98:99], 0 ; cc464078 1a02c528
	v_maxmin_num_f32 v162, -4.0, v113, 4.0                      ; d66900a2 03dae2f7
	v_maxmin_num_f32 v160, -4.0, v112, 4.0                      ; d66900a0 03dae0f7
	v_maxmin_num_f32 v164, -4.0, v114, 4.0                      ; d66900a4 03dae4f7
	v_maxmin_num_f32 v166, -4.0, v115, 4.0                      ; d66900a6 03dae6f7
	v_maxmin_num_f32 v168, -4.0, v116, 4.0                      ; d66900a8 03dae8f7
	v_maxmin_num_f32 v170, -4.0, v117, 4.0                      ; d66900aa 03daeaf7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v118, 4.0                      ; d66900ac 03daecf7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	buffer_load_b128 v[108:111], v14, s[20:23], null offen offset:64 ; c405c07c 4080286c 0000400e
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	v_dual_mul_f32 v113, v113, v163 :: v_dual_mul_f32 v112, v112, v160 ; c8c74771 71714170
	v_dual_mul_f32 v115, v115, v167 :: v_dual_mul_f32 v114, v114, v164 ; c8c74f73 73734972
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	buffer_load_b128 v[112:115], v14, s[20:23], null offen offset:80 ; c405c07c 40802870 0000500e
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v119, 4.0                      ; d66900ae 03daeef7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[106:107], v[120:127] ; cc464078 1de2d52c
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c84355ab aba953a8 3f650000
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v117, v117, v171 :: v_dual_mul_f32 v116, v116, v168 ; c8c75775 75755174
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 ; c8435daf afad5bac 3f650000
	v_maxmin_num_f32 v180, -4.0, v122, 4.0                      ; d66900b4 03daf4f7
	v_maxmin_num_f32 v178, -4.0, v121, 4.0                      ; d66900b2 03daf2f7
	v_maxmin_num_f32 v184, -4.0, v124, 4.0                      ; d66900b8 03daf8f7
	v_maxmin_num_f32 v176, -4.0, v120, 4.0                      ; d66900b0 03daf0f7
	v_maxmin_num_f32 v182, -4.0, v123, 4.0                      ; d66900b6 03daf6f7
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v119, v119, v175 :: v_dual_mul_f32 v118, v118, v172 ; c8c75f77 77775976
	v_maxmin_num_f32 v186, -4.0, v125, 4.0                      ; d66900ba 03dafaf7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v126, 4.0                      ; d66900bc 03dafcf7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v127, 4.0                      ; d66900be 03dafef7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84365b3 b3b163b0 3f650000
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c8436db7 b7b56bb4 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[98:99], 0 ; cc464080 1a02c52a
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84375bb bbb973b8 3f650000
	v_dual_mul_f32 v121, v121, v179 :: v_dual_mul_f32 v120, v120, v176 ; c8c76779 79796178
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8437dbf bfbd7bbc 3f650000
	v_dual_mul_f32 v123, v123, v183 :: v_dual_mul_f32 v122, v122, v180 ; c8c76f7b 7b7b697a
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v125, v125, v187 :: v_dual_mul_f32 v124, v124, v184 ; c8c7777d 7d7d717c
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v127, v127, v191 :: v_dual_mul_f32 v126, v126, v188 ; c8c77f7f 7f7f797e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[106:107], v[128:135] ; cc464080 1e02d52e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[88:89], 0 ; cc464078 1a02b12a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[96:97], v[120:127] ; cc464078 1de2c12e
	v_maxmin_num_f32 v42, -4.0, v121, 4.0                       ; d669002a 03daf2f7
	v_maxmin_num_f32 v191, -4.0, v120, 4.0                      ; d66900bf 03daf0f7
	v_maxmin_num_f32 v96, -4.0, v125, 4.0                       ; d6690060 03dafaf7
	v_maxmin_num_f32 v46, -4.0, v123, 4.0                       ; d669002e 03daf6f7
	v_maxmin_num_f32 v88, -4.0, v124, 4.0                       ; d6690058 03daf8f7
	v_maxmin_num_f32 v44, -4.0, v122, 4.0                       ; d669002c 03daf4f7
	v_fma_mix_f32 v43, 0xab28, |v42|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622b 0bfe54ff 3728ab28
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_fma_mix_f32 v47, 0xab28, |v46|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622f 0bfe5cff 3728ab28
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v98, s5, v12, 2                              ; d6470062 020a1805
	v_fma_mix_f32 v45, 0xab28, |v44|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe58ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v47, v47, v46, 0x3f650000 :: v_dual_fmaak_f32 v44, v44, v45, 0x3f650000 ; c8425d2f 2f2c5b2c 3f650000
	v_dual_mul_f32 v123, v123, v47 :: v_dual_mul_f32 v122, v122, v44 ; c8c65f7b 7b7a597a
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v98, s[52:55], null offen        ; c405c07c 4080682c 00000062
	buffer_load_b128 v[116:119], v98, s[52:55], null offen offset:1024 ; c405c07c 40806874 00040062
	v_maxmin_num_f32 v99, -4.0, v126, 4.0                       ; d6690063 03dafcf7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fmaak_f32 v43, v43, v42, 0x3f650000                       ; 5a56552b 3f650000
	v_fmaak_f32 v191, v191, v13, 0x3f650000                     ; 5b7e1bbf 3f650000
	v_maxmin_num_f32 v107, -4.0, v127, 4.0                      ; d669006b 03dafef7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_mul_f32 v121, v43, v121 :: v_dual_mul_f32 v120, v120, v191 ; c8c6f32b 79797f78
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v106, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfec6ff 3728ab28
	v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842c161 6158b358 3f650000
	v_fma_mix_f32 v120, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfed6ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fmaak_f32 v99, v99, v106, 0x3f650000                      ; 5ac6d563 3f650000
	v_dual_mul_f32 v125, v125, v97 :: v_dual_mul_f32 v124, v124, v88 ; c8c6c37d 7d7cb17c
	v_fmaak_f32 v120, v120, v107, 0x3f650000                    ; 5af0d778 3f650000
	v_mul_f32_e32 v126, v126, v99                               ; 10fcc77e
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v128, 4.0                      ; d669007c 03db00f7
	v_mul_f32_e32 v127, v127, v120                              ; 10fef17f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fmaak_f32 v124, v124, v125, 0x3f650000                    ; 5af8fb7c 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v128, v128, v124                              ; 1100f980
	v_maxmin_num_f32 v136, -4.0, v129, 4.0                      ; d6690088 03db02f7
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[120:123], v98, s[52:55], null offen offset:2048 ; c405c07c 40806878 00080062
	buffer_load_b128 v[124:127], v98, s[52:55], null offen offset:512 ; c405c07c 4080687c 00020062
	buffer_load_b128 v[140:143], v98, s[52:55], null offen offset:1536 ; c405c07c 4080688c 00060062
	buffer_load_b128 v[96:99], v98, s[52:55], null offen offset:2560 ; c405c07c 40806860 000a0062
	v_maxmin_num_f32 v138, -4.0, v130, 4.0                      ; d669008a 03db04f7
	v_maxmin_num_f32 v144, -4.0, v131, 4.0                      ; d6690090 03db06f7
	v_maxmin_num_f32 v146, -4.0, v132, 4.0                      ; d6690092 03db08f7
	v_maxmin_num_f32 v148, -4.0, v133, 4.0                      ; d6690094 03db0af7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v134, 4.0                      ; d6690096 03db0cf7
	v_maxmin_num_f32 v152, -4.0, v135, 4.0                      ; d6690098 03db0ef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fmaak_f32 v137, v137, v136, 0x3f650000                    ; 5b131189 3f650000
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c8432191 918b178a 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8432995 95932792 3f650000
	v_mul_f32_e32 v129, v129, v137                              ; 11031381
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8433199 99972f96 3f650000
	v_dual_mul_f32 v131, v131, v145 :: v_dual_mul_f32 v130, v130, v138 ; c8c72383 83831582
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_dual_mul_f32 v145, v101, v49 :: v_dual_mul_f32 v144, v100, v48 ; c8c66365 91906164
	v_dual_mul_f32 v133, v133, v149 :: v_dual_mul_f32 v132, v132, v146 ; c8c72b85 85852584
	v_dual_mul_f32 v147, v103, v51 :: v_dual_mul_f32 v146, v102, v50 ; c8c66767 93926566
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_mul_f32 v149, v105, v53 :: v_dual_mul_f32 v148, v104, v52 ; c8c66b69 95946968
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v129, v91, v49 :: v_dual_mul_f32 v128, v90, v48 ; c8c6635b 8180615a
	v_dual_mul_f32 v135, v135, v153 :: v_dual_mul_f32 v134, v134, v150 ; c8c73387 87872d86
	v_dual_mul_f32 v151, v11, v55 :: v_dual_mul_f32 v150, v10, v54 ; c8c66f0b 97966d0a
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v131, v93, v51 :: v_dual_mul_f32 v130, v92, v50 ; c8c6675d 8382655c
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[18:19], v[144:151] ; cc464090 1e422538
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	s_bitset0_b32 s49, 14                                       ; beb1108e
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_buffer_load_b32 s10, s[48:51], s10 offset:0x0             ; f4020298 14000000
	v_dual_mul_f32 v133, v95, v53 :: v_dual_mul_f32 v132, v94, v52 ; c8c66b5f 8584695e
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v135, v9, v55 :: v_dual_mul_f32 v134, v8, v54 ; c8c66f09 87866d08
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[16:17], v[128:135] ; cc464080 1e022138
	v_cvt_pk_f32_fp8_e32 v[48:49], v4                           ; 7e60dd04
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[22:23], v[144:151] ; cc464090 1e422d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[20:21], v[128:135] ; cc464080 1e02293c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[64:65], v[28:29], v[144:151] ; cc464090 1e423940
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[64:65], v[24:25], v[128:135] ; cc464080 1e023140
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[30:31], v[144:151] ; cc464090 1e423d44
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mul_f32 v153, v49, v109 :: v_dual_mul_f32 v152, v48, v108 ; c8c6db31 9998d930
	v_cvt_pk_f32_fp8_e32 v[48:49], v132                         ; 7e60dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[26:27], v[128:135] ; cc464080 1e023544
	v_dual_mul_f32 v155, v49, v111 :: v_dual_mul_f32 v154, v48, v110 ; c8c6df31 9b9add30
	v_cvt_pk_f32_fp8_e32 v[48:49], v5                           ; 7e60dd05
	v_cvt_pk_f32_fp8_e32 v[4:5], v133                           ; 7e08dd85
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[36:37], v[144:151] ; cc464090 1e424948
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v159, v5, v115 :: v_dual_mul_f32 v158, v4, v114 ; c8c6e705 9f9ee504
	v_cvt_pk_f32_fp8_e32 v[4:5], v6                             ; 7e08dd06
	v_dual_mul_f32 v157, v49, v113 :: v_dual_mul_f32 v156, v48, v112 ; c8c6e331 9d9ce130
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[32:33], v[128:135] ; cc464080 1e024148
	v_dual_mul_f32 v49, v5, v109 :: v_dual_mul_f32 v48, v4, v108 ; c8c6db05 3130d904
	v_cvt_pk_f32_fp8_e32 v[4:5], v134                           ; 7e08dd86
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[76:77], v[38:39], v[144:151] ; cc464090 1e424d4c
	v_dual_mul_f32 v51, v5, v111 :: v_dual_mul_f32 v50, v4, v110 ; c8c6df05 3332dd04
	v_cvt_pk_f32_fp8_e32 v[4:5], v7                             ; 7e08dd07
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[34:35], v[128:135] ; cc464080 1e02454c
	v_dual_mul_f32 v53, v5, v113 :: v_dual_mul_f32 v52, v4, v112 ; c8c6e305 3534e104
	v_cvt_pk_f32_fp8_e32 v[4:5], v135                           ; 7e08dd87
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[80:81], v[14:15], v[144:151] ; cc464090 1e421d50
	v_dual_mul_f32 v55, v5, v115 :: v_dual_mul_f32 v54, v4, v114 ; c8c6e705 3736e504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[58:59], v[18:19], v[48:55] ; cc464030 1cc2253a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[40:41], v[128:135] ; cc464080 1e025150
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[88:89], v[144:151] ; cc464090 1e42b154
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[62:63], v[22:23], v[48:55] ; cc464030 1cc22d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[42:43], v[128:135] ; cc464080 1e025554
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[16:17], v[152:159] ; cc464098 1e62213a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[66:67], v[28:29], v[48:55] ; cc464030 1cc23942
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[20:21], v[152:159] ; cc464098 1e62293e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[70:71], v[30:31], v[48:55] ; cc464030 1cc23d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[24:25], v[152:159] ; cc464098 1e623142
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[74:75], v[36:37], v[48:55] ; cc464030 1cc2494a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[70:71], v[26:27], v[152:159] ; cc464098 1e623546
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[78:79], v[38:39], v[48:55] ; cc464030 1cc24d4e
	v_lshl_add_u32 v160, v2, 5, v1                              ; d64600a0 04050b02
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[32:33], v[152:159] ; cc464098 1e62414a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[82:83], v[14:15], v[48:55] ; cc464030 1cc21d52
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, 0              ; ca100080 0f0e0080
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[78:79], v[34:35], v[152:159] ; cc464098 1e62454e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[86:87], v[88:89], v[48:55] ; cc464030 1cc2b156
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[82:83], v[40:41], v[152:159] ; cc464098 1e625152
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[42:43], v[152:159] ; cc464098 1e625556
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v160, v[14:15], v[14:15] offset1:2       ; d9380200 000e0ea0
	ds_store_2addr_b64 v160, v[14:15], v[14:15] offset0:64 offset1:66 ; d9384240 000e0ea0
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[46:47], v[8:9], 0   ; cc464018 1a02112e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[118:119], v[8:9], 0 ; cc464038 1a021176
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[8:9], 0   ; cc464010 1a02112c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[116:117], v[8:9], 0 ; cc464020 1a021174
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[120:121], 0 ; cc464040 1a02f108
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[122:123], 0 ; cc464048 1a02f508
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[126:127], v[4:5], v[24:31] ; cc464018 1c62097e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[142:143], v[4:5], v[56:63] ; cc464038 1ce2098e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[124:125], v[4:5], v[16:23] ; cc464010 1c42097c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[140:141], v[4:5], v[32:39] ; cc464020 1c82098c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[4:5], v[96:97], v[64:71] ; cc464040 1d02c104
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[4:5], v[98:99], v[72:79] ; cc464048 1d22c504
	v_dual_mul_f32 v164, v59, v59 :: v_dual_mul_f32 v161, v25, v25 ; c8c6773b a4a03319
	v_dual_mul_f32 v163, v27, v27 :: v_dual_mul_f32 v162, v57, v57 ; c8c6371b a3a27339
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_dual_fmac_f32 v164, v35, v35 :: v_dual_fmac_f32 v161, v17, v17 ; c8004723 a4a02311
	s_mov_b32 s24, 0x76543210                                   ; be9800ff 76543210
	v_dual_fmac_f32 v163, v19, v19 :: v_dual_fmac_f32 v162, v33, v33 ; c8002713 a3a24321
	s_mov_b32 s25, 0xfedcba98                                   ; be9900ff fedcba98
	v_dual_fmac_f32 v164, v39, v39 :: v_dual_fmac_f32 v161, v21, v21 ; c8004f27 a4a02b15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v163, v23, v23 :: v_dual_fmac_f32 v162, v37, v37 ; c8002f17 a3a24b25
	v_dual_fmac_f32 v164, v63, v63 :: v_dual_fmac_f32 v161, v29, v29 ; c8007f3f a4a03b1d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v163, v31, v31 :: v_dual_fmac_f32 v162, v61, v61 ; c8003f1f a3a27b3d
	v_dual_fmac_f32 v164, v34, v34 :: v_dual_fmac_f32 v161, v16, v16 ; c8004522 a4a02110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v32, v32 :: v_dual_fmac_f32 v163, v18, v18 ; c8004120 a2a22512
	v_dual_fmac_f32 v164, v58, v58 :: v_dual_fmac_f32 v161, v24, v24 ; c800753a a4a03118
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v56, v56 :: v_dual_fmac_f32 v163, v26, v26 ; c8007138 a2a2351a
	v_dual_fmac_f32 v164, v38, v38 :: v_dual_fmac_f32 v161, v20, v20 ; c8004d26 a4a02914
	v_lshl_add_u32 v2, v2, 6, s7                                ; d6460002 001d0d02
	v_dual_fmac_f32 v162, v36, v36 :: v_dual_fmac_f32 v163, v22, v22 ; c8004924 a2a22d16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
	v_dual_fmac_f32 v164, v62, v62 :: v_dual_fmac_f32 v161, v28, v28 ; c8007d3e a4a0391c
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
	v_dual_fmac_f32 v162, v60, v60 :: v_dual_fmac_f32 v163, v30, v30 ; c800793c a2a23d1e
	v_fma_mixlo_f16 v165, 1.0, v161, v163                       ; cc2100a5 068f42f2
	v_fma_mixhi_f16 v165, 1.0, v162, v164                       ; cc2200a5 069344f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v166, v165, s24, s25 op_sel:[1,1]         ; d65c18a6 006431a5
(invalid instruction)                                        ; cc0f00a5
	v_min_num_f64_e32 v[1:2], v[165:166], v[166:167]            ; 1a034da5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v255                             ; 0a01ffa5
(invalid instruction)                                        ; 00000410
(invalid instruction)                                        ; d58b00a7
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a1
	v_rsq_f32_e32 v167, v167                                    ; 7f4e5da7
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_mul_f32_e32 v167, s10, v167                               ; 114f4e0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v18, v18, v167 :: v_dual_mul_f32 v19, v19, v167 ; c8c74f12 12134f13
	v_dual_mul_f32 v16, v16, v167 :: v_dual_mul_f32 v17, v17, v167 ; c8c74f10 10114f11
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v2, s[20:23], null offen offset:8192 ; c405c07c 40802810 00200002
	buffer_load_b128 v[40:43], v2, s[20:23], null offen offset:8208 ; c405c07c 40802828 00201002
	v_dual_mul_f32 v23, v23, v167 :: v_dual_mul_f32 v22, v22, v167 ; c8c74f17 17174f16
(invalid instruction)                                        ; d58b08a5
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
	v_mul_f32_e32 v21, v21, v167                                ; 102b4f15
	v_mul_f32_e32 v20, v20, v167                                ; 10294f14
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(TRANS32_DEP_1) ; bf8702b3
	v_rsq_f32_e32 v165, v165                                    ; 7f4a5da5
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	v_dual_mul_f32 v33, v33, v165 :: v_dual_mul_f32 v32, v32, v165 ; c8c74b21 21214b20
	v_dual_mul_f32 v35, v35, v165 :: v_dual_mul_f32 v34, v34, v165 ; c8c74b23 23234b22
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v2, s[20:23], null offen offset:12288 ; c405c07c 40802814 00300002
	buffer_load_b128 v[32:35], v2, s[20:23], null offen offset:12304 ; c405c07c 40802820 00301002
	v_mul_f32_e32 v24, v24, v167                                ; 10314f18
	v_dual_mul_f32 v26, v26, v167 :: v_dual_mul_f32 v25, v25, v167 ; c8c74f1a 1a194f19
	v_dual_mul_f32 v28, v28, v167 :: v_dual_mul_f32 v27, v27, v167 ; c8c74f1c 1c1b4f1b
	v_dual_mul_f32 v30, v30, v167 :: v_dual_mul_f32 v29, v29, v167 ; c8c74f1e 1e1d4f1d
	v_dual_mul_f32 v56, v56, v165 :: v_dual_mul_f32 v31, v31, v167 ; c8c74b38 381f4f1f
	v_dual_mul_f32 v39, v39, v165 :: v_dual_mul_f32 v38, v38, v165 ; c8c74b27 27274b26
	v_dual_mul_f32 v37, v37, v165 :: v_dual_mul_f32 v36, v36, v165 ; c8c74b25 25254b24
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
	v_dual_mul_f32 v58, v58, v165 :: v_dual_mul_f32 v57, v57, v165 ; c8c74b3a 3a394b39
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v2, s[20:23], null offen offset:8256 ; c405c07c 4080281c 00204002
	buffer_load_b128 v[36:39], v2, s[20:23], null offen offset:8272 ; c405c07c 40802824 00205002
	v_dual_mul_f32 v60, v60, v165 :: v_dual_mul_f32 v59, v59, v165 ; c8c74b3c 3c3b4b3b
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mul_f32_e32 v61, v61, v165                                ; 107b4b3d
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
	v_dual_mul_f32 v63, v63, v165 :: v_dual_mul_f32 v62, v62, v165 ; c8c74b3f 3f3f4b3e
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v160, v[8:9], v[26:27] offset0:128 offset1:130 ; d9388280 001a08a0
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[10:11], 0 ; cc464038 1a02152c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[10:11], 0 ; cc464040 1a02152e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v2, s[20:23], null offen offset:12352 ; c405c07c 4080282c 00304002
	buffer_load_b128 v[100:103], v2, s[20:23], null offen offset:12368 ; c405c07c 40802864 00305002
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[116:117], v[10:11], 0 ; cc464048 1a021574
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[118:119], v[10:11], 0 ; cc464050 1a021576
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[10:11], v[120:121], 0 ; cc464058 1a02f10a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[122:123], 0 ; cc464068 1a02f50a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[6:7], v[96:97], v[88:95] ; cc464058 1d62c106
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[124:125], v[6:7], v[56:63] ; cc464038 1ce20d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[6:7], v[98:99], v[104:111] ; cc464068 1da2c506
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[96:99], v2, s[20:23], null offen offset:8320 ; c405c07c 40802860 00208002
	buffer_load_b128 v[112:115], v2, s[20:23], null offen offset:8336 ; c405c07c 40802870 00209002
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[126:127], v[6:7], v[64:71] ; cc464040 1d020d7e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[140:141], v[6:7], v[72:79] ; cc464048 1d220d8c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[142:143], v[6:7], v[80:87] ; cc464050 1d420d8e
	v_mul_f32_e32 v168, v65, v65                                ; 11508341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v168, v57, v57                               ; 57507339
	v_dual_fmac_f32 v168, v61, v61 :: v_dual_mul_f32 v171, v83, v83 ; c8067b3d a8aaa753
	v_mul_f32_e32 v169, v81, v81                                ; 1152a351
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmac_f32 v168, v69, v69 :: v_dual_fmac_f32 v171, v75, v75 ; c8008b45 a8aa974b
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[116:119], v2, s[20:23], null offen offset:12416 ; c405c07c 40802874 00308002
	buffer_load_b128 v[120:123], v2, s[20:23], null offen offset:12432 ; c405c07c 40802878 00309002
	v_dual_mul_f32 v170, v67, v67 :: v_dual_fmac_f32 v169, v73, v73 ; c8c08743 aaa89349
	v_fmac_f32_e32 v168, v56, v56                               ; 57507138
	v_fmac_f32_e32 v171, v79, v79                               ; 57569f4f
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmac_f32 v170, v59, v59 :: v_dual_fmac_f32 v169, v77, v77 ; c800773b aaa89b4d
	v_dual_fmac_f32 v168, v64, v64 :: v_dual_fmac_f32 v171, v87, v87 ; c8008140 a8aaaf57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v170, v63, v63 :: v_dual_fmac_f32 v169, v85, v85 ; c8007f3f aaa8ab55
	v_dual_fmac_f32 v168, v60, v60 :: v_dual_fmac_f32 v171, v74, v74 ; c800793c a8aa954a
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fmac_f32_e32 v170, v71, v71                               ; 57548f47
	v_dual_fmac_f32 v168, v68, v68 :: v_dual_fmac_f32 v171, v82, v82 ; c8008944 a8aaa552
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v170, v58, v58 :: v_dual_fmac_f32 v169, v72, v72 ; c800753a aaa89148
	v_fmac_f32_e32 v171, v78, v78                               ; 57569d4e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v170, v66, v66 :: v_dual_fmac_f32 v169, v80, v80 ; c8008542 aaa8a150
	v_fmac_f32_e32 v171, v86, v86                               ; 5756ad56
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmac_f32 v170, v62, v62 :: v_dual_fmac_f32 v169, v76, v76 ; c8007d3e aaa8994c
	v_dual_fmac_f32 v170, v70, v70 :: v_dual_fmac_f32 v169, v84, v84 ; c8008d46 aaa8a954
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v172, 1.0, v168, v170                       ; cc2100ac 06ab50f2
	v_fma_mixhi_f16 v172, 1.0, v169, v171                       ; cc2200ac 06af52f2
	v_permlanex16_b32 v173, v172, s24, s25 op_sel:[1,1]         ; d65c18ad 006431ac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[173:174]            ; 1a035bac
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v255                             ; 0a01ffac
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
(invalid instruction)                                        ; d58b08ac
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	v_rsq_f32_e32 v174, v174                                    ; 7f5c5dae
	v_rsq_f32_e32 v172, v172                                    ; 7f585dac
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870096
	v_mul_f32_e32 v174, s10, v174                               ; 115d5c0a
	v_dual_mul_f32 v62, v62, v174 :: v_dual_mul_f32 v61, v61, v174 ; c8c75d3e 3e3d5d3d
	v_dual_mul_f32 v58, v58, v174 :: v_dual_mul_f32 v57, v57, v174 ; c8c75d3a 3a395d39
	v_dual_mul_f32 v72, v72, v172 :: v_dual_mul_f32 v63, v63, v174 ; c8c75948 483f5d3f
	v_mul_f32_e32 v56, v56, v174                                ; 10715d38
	v_dual_mul_f32 v60, v60, v174 :: v_dual_mul_f32 v59, v59, v174 ; c8c75d3c 3c3b5d3b
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	v_mul_f32_e32 v73, v73, v172                                ; 10935949
	v_dual_mul_f32 v75, v75, v172 :: v_dual_mul_f32 v74, v74, v172 ; c8c7594b 4b4b594a
	v_dual_mul_f32 v79, v79, v172 :: v_dual_mul_f32 v78, v78, v172 ; c8c7594f 4f4f594e
	v_dual_mul_f32 v77, v77, v172 :: v_dual_mul_f32 v76, v76, v172 ; c8c7594d 4d4d594c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[56:59], v2, s[20:23], null offen offset:8384 ; c405c07c 40802838 0020c002
	buffer_load_b128 v[60:63], v2, s[20:23], null offen offset:8400 ; c405c07c 4080283c 0020d002
	buffer_load_b128 v[72:75], v2, s[20:23], null offen offset:12480 ; c405c07c 40802848 0030c002
	buffer_load_b128 v[76:79], v2, s[20:23], null offen offset:12496 ; c405c07c 4080284c 0030d002
	v_dual_mul_f32 v65, v65, v174 :: v_dual_mul_f32 v64, v64, v174 ; c8c75d41 41415d40
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v67, v67, v174 :: v_dual_mul_f32 v66, v66, v174 ; c8c75d43 43435d42
	v_dual_mul_f32 v69, v69, v174 :: v_dual_mul_f32 v68, v68, v174 ; c8c75d45 45455d44
	v_dual_mul_f32 v71, v71, v174 :: v_dual_mul_f32 v70, v70, v174 ; c8c75d47 47475d46
	v_dual_mul_f32 v81, v81, v172 :: v_dual_mul_f32 v80, v80, v172 ; c8c75951 51515950
	v_dual_mul_f32 v83, v83, v172 :: v_dual_mul_f32 v82, v82, v172 ; c8c75953 53535952
	v_dual_mul_f32 v85, v85, v172 :: v_dual_mul_f32 v84, v84, v172 ; c8c75955 55555954
	v_dual_mul_f32 v87, v87, v172 :: v_dual_mul_f32 v86, v86, v172 ; c8c75957 57575956
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v160, v[10:11], v[66:67] offset0:192 offset1:194 ; d938c2c0 00420aa0
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_load_b64 v[66:67], v160                                  ; d9d80000 420000a0
	ds_load_b64 v[68:69], v160 offset:16                        ; d9d80010 440000a0
	s_mov_b32 s26, 0x3d380000                                   ; be9a00ff 3d380000
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[66:67], v[4:5], 0   ; cc464050 1a020942
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[66:67], v[6:7], 0   ; cc464058 1a020d42
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[24:25], v[80:87] ; cc464050 1d423144
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_fma_mixlo_f16 v175, s26, v80, v16                         ; cc2100af 0442a01a
	v_fma_mixhi_f16 v175, s26, v81, v17                         ; cc2200af 0446a21a
	ds_load_b64 v[16:17], v160 offset:512                       ; d9d80200 100000a0
	ds_load_b64 v[66:67], v160 offset:528                       ; d9d80210 420000a0
	s_movk_i32 s27, 0x3c20                                      ; b01b3c20
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[64:65], v[88:95] ; cc464058 1d628144
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v178, s26, v86, v42                         ; cc2100b2 04aaac1a
	v_fma_mixlo_f16 v176, s26, v82, v18                         ; cc2100b0 044aa41a
	v_fma_mixhi_f16 v176, s26, v83, v19                         ; cc2200b0 044ea61a
	v_fma_mixhi_f16 v178, s26, v87, v43                         ; cc2200b2 04aeae1a
	v_fma_mixlo_f16 v177, s26, v84, v40                         ; cc2100b1 04a2a81a
	v_fma_mixhi_f16 v177, s26, v85, v41                         ; cc2200b1 04a6aa1a
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v27                              ; 0a0037af
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v27                              ; 0a0037b0
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v27                              ; 0a0037b2
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[4:5], 0   ; cc464050 1a020910
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v27                              ; 0a0037b1
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v181, s26, v92, v32                         ; cc2100b5 0482b81a
	v_fma_mixhi_f16 v181, s26, v93, v33                         ; cc2200b5 0486ba1a
	v_fma_mixlo_f16 v180, s26, v90, v22                         ; cc2100b4 045ab41a
	v_fma_mixlo_f16 v182, s26, v94, v34                         ; cc2100b6 048abc1a
	v_fma_mixhi_f16 v182, s26, v95, v35                         ; cc2200b6 048ebe1a
	v_fma_mixhi_f16 v180, s26, v91, v23                         ; cc2200b4 045eb61a
	v_fma_mixlo_f16 v179, s26, v88, v20                         ; cc2100b3 0452b01a
	v_fma_mixhi_f16 v179, s26, v89, v21                         ; cc2200b3 0456b21a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[6:7], 0   ; cc464058 1a020d10
	ds_load_b64 v[16:17], v160 offset:1024                      ; d9d80400 100000a0
	ds_load_b64 v[18:19], v160 offset:1040                      ; d9d80410 120000a0
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v27                              ; 0a0037b5
(invalid instruction)                                        ; cc1c00b6
	v_subrev_f32_e32 v0, v182, v27                              ; 0a0037b6
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[66:67], v[24:25], v[80:87] ; cc464050 1d423142
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v27                              ; 0a0037b4
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v27                              ; 0a0037b3
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[66:67], v[64:65], v[88:95] ; cc464058 1d628142
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v183, s26, v80, v28                         ; cc2100b7 0472a01a
	v_fma_mixhi_f16 v183, s26, v81, v29                         ; cc2200b7 0476a21a
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v186, s26, v86, v38                         ; cc2100ba 049aac1a
	v_fma_mixhi_f16 v186, s26, v87, v39                         ; cc2200ba 049eae1a
	v_fma_mixlo_f16 v184, s26, v82, v30                         ; cc2100b8 047aa41a
	v_fma_mixhi_f16 v184, s26, v83, v31                         ; cc2200b8 047ea61a
	v_fma_mixlo_f16 v185, s26, v84, v36                         ; cc2100b9 0492a81a
	v_fma_mixhi_f16 v185, s26, v85, v37                         ; cc2200b9 0496aa1a
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v27                              ; 0a0037b7
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[4:5], 0   ; cc464020 1a020910
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v27                              ; 0a0037ba
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v187, s26, v88, v44                         ; cc2100bb 04b2b01a
	v_fma_mixlo_f16 v188, s26, v90, v46                         ; cc2100bc 04bab41a
	v_fma_mixhi_f16 v188, s26, v91, v47                         ; cc2200bc 04beb61a
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v189, s26, v92, v100                        ; cc2100bd 0592b81a
	v_fma_mixhi_f16 v189, s26, v93, v101                        ; cc2200bd 0596ba1a
	v_fma_mixhi_f16 v187, s26, v89, v45                         ; cc2200bb 04b6b21a
	v_fma_mixlo_f16 v190, s26, v94, v102                        ; cc2100be 059abc1a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[6:7], 0   ; cc464028 1a020d10
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[24:25], v[32:39] ; cc464020 1c823112
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[64:65], v[40:47] ; cc464028 1ca28112
	ds_load_b64 v[16:17], v160 offset:1536                      ; d9d80600 100000a0
	ds_load_b64 v[18:19], v160 offset:1552                      ; d9d80610 120000a0
	v_fma_mixhi_f16 v190, s26, v95, v103                        ; cc2200be 059ebe1a
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v27                              ; 0a0037b8
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v27                              ; 0a0037b9
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v27                              ; 0a0037bc
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v27                              ; 0a0037bd
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v27                              ; 0a0037bb
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v13, s26, v36, v112                         ; cc21000d 05c2481a
	v_fma_mixlo_f16 v191, s26, v32, v96                         ; cc2100bf 0582401a
	v_fma_mixhi_f16 v191, s26, v33, v97                         ; cc2200bf 0586421a
	v_fma_mixlo_f16 v2, s26, v34, v98                           ; cc210002 058a441a
	v_fma_mixhi_f16 v2, s26, v35, v99                           ; cc220002 058e461a
	v_fma_mixhi_f16 v13, s26, v37, v113                         ; cc22000d 05c64a1a
	v_fma_mixlo_f16 v20, s26, v38, v114                         ; cc210014 05ca4c1a
	v_fma_mixhi_f16 v20, s26, v39, v115                         ; cc220014 05ce4e1a
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v27                              ; 0a0037be
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v21, s26, v40, v116                         ; cc210015 05d2501a
	v_fma_mixlo_f16 v22, s26, v42, v118                         ; cc210016 05da541a
	v_fma_mixhi_f16 v22, s26, v43, v119                         ; cc220016 05de561a
	v_fma_mixhi_f16 v21, s26, v41, v117                         ; cc220015 05d6521a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v23, s26, v44, v120                         ; cc210017 05e2581a
	v_fma_mixhi_f16 v23, s26, v45, v121                         ; cc220017 05e65a1a
	v_fma_mixlo_f16 v28, s26, v46, v122                         ; cc21001c 05ea5c1a
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v27                              ; 0a0037bf
	v_fma_mixhi_f16 v28, s26, v47, v123                         ; cc22001c 05ee5e1a
(invalid instruction)                                        ; cc1c0002
	v_subrev_f32_e32 v0, v2, v27                                ; 0a003702
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v27                               ; 0a00370d
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[4:5], 0   ; cc464020 1a020910
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v27                               ; 0a003714
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[6:7], 0   ; cc464028 1a020d10
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v27                               ; 0a003716
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v27                               ; 0a003715
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v27                               ; 0a003717
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v27                               ; 0a00371c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[24:25], v[32:39] ; cc464020 1c823112
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[64:65], v[40:47] ; cc464028 1ca28112
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v30, s26, v34, v58                          ; cc21001e 04ea441a
	v_fma_mixlo_f16 v29, s26, v32, v56                          ; cc21001d 04e2401a
	v_fma_mixhi_f16 v29, s26, v33, v57                          ; cc22001d 04e6421a
	v_fma_mixhi_f16 v30, s26, v35, v59                          ; cc22001e 04ee461a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v32, s26, v38, v62                          ; cc210020 04fa4c1a
	v_fma_mixhi_f16 v32, s26, v39, v63                          ; cc220020 04fe4e1a
	v_fma_mixlo_f16 v31, s26, v36, v60                          ; cc21001f 04f2481a
	v_fma_mixhi_f16 v31, s26, v37, v61                          ; cc22001f 04f64a1a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v33, s26, v40, v72                          ; cc210021 0522501a
	v_fma_mixhi_f16 v33, s26, v41, v73                          ; cc220021 0526521a
	v_fma_mixlo_f16 v34, s26, v42, v74                          ; cc210022 052a541a
	v_fma_mixhi_f16 v34, s26, v43, v75                          ; cc220022 052e561a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v35, s26, v44, v76                          ; cc210023 0532581a
	v_fma_mixhi_f16 v35, s26, v45, v77                          ; cc220023 05365a1a
	v_fma_mixlo_f16 v36, s26, v46, v78                          ; cc210024 053a5c1a
	v_fma_mixhi_f16 v36, s26, v47, v79                          ; cc220024 053e5e1a
(invalid instruction)                                        ; cc1c001d
	v_subrev_f32_e32 v0, v29, v27                               ; 0a00371d
	s_mov_b32 s28, 0x7ff88000                                   ; be9c00ff 7ff88000
(invalid instruction)                                        ; cc1c001e
	v_subrev_f32_e32 v0, v30, v27                               ; 0a00371e
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v27                               ; 0a003720
(invalid instruction)                                        ; cc1c001f
	v_subrev_f32_e32 v0, v31, v27                               ; 0a00371f
(invalid instruction)                                        ; cc1c0021
	v_subrev_f32_e32 v0, v33, v27                               ; 0a003721
(invalid instruction)                                        ; cc1c0022
	v_subrev_f32_e32 v0, v34, v27                               ; 0a003722
(invalid instruction)                                        ; cc1c0023
	v_subrev_f32_e32 v0, v35, v27                               ; 0a003723
	v_lshl_add_u32 v2, v2, 5, s28                               ; d6460002 00710b02
	v_lshl_add_u32 v175, v175, 5, s28                           ; d64600af 00710baf
	v_lshl_add_u32 v191, v191, 5, s28                           ; d64600bf 00710bbf
	v_lshl_add_u32 v184, v184, 5, s28                           ; d64600b8 00710bb8
	v_lshl_add_u32 v183, v183, 5, s28                           ; d64600b7 00710bb7
	v_lshl_add_u32 v176, v176, 5, s28                           ; d64600b0 00710bb0
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v27                               ; 0a003724
	v_lshl_add_u32 v29, v29, 5, s28                             ; d646001d 00710b1d
	v_lshl_add_u32 v177, v177, 5, s28                           ; d64600b1 00710bb1
	v_lshl_add_u32 v30, v30, 5, s28                             ; d646001e 00710b1e
	v_lshl_add_u32 v185, v185, 5, s28                           ; d64600b9 00710bb9
	v_add_lshl_u32 v0, s9, v0, 2                                ; d6470000 020a0009
	v_lshl_add_u32 v13, v13, 5, s28                             ; d646000d 00710b0d
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[4:7], v0, s[20:23], null offen           ; c405c07c 40802804 00000000
	buffer_load_b128 v[16:19], v0, s[20:23], null offen offset:16 ; c405c07c 40802810 00001000
	v_lshl_add_u32 v31, v31, 5, s28                             ; d646001f 00710b1f
	v_lshl_add_u32 v178, v178, 5, s28                           ; d64600b2 00710bb2
	v_lshl_add_u32 v186, v186, 5, s28                           ; d64600ba 00710bba
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[175:176], v[183:184]            ; 1a036faf
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[176:177], v[184:185]            ; 1a0371b0
	v_lshl_add_u32 v20, v20, 5, s28                             ; d6460014 00710b14
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[177:178], v[185:186]            ; 1a0373b1
	v_lshl_add_u32 v32, v32, 5, s28                             ; d6460020 00710b20
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[178:179], v[186:187]            ; 1a0375b2
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[191:192]              ; 1a037f25
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[2:3]                  ; 1a020526
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[13:14]                ; 1a021b27
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[40:41], v[20:21]                ; 1a022928
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[29:30]                ; 1a023b25
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[30:31]                ; 1a023d26
	s_lshr_b32 s6, s6, 2                                        ; 85068206
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[31:32]                ; 1a023f27
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[40:41], v[32:33]                ; 1a024128
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v12, s6, v12, 2                              ; d647000c 020a1806
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[38:39]                ; 1a024d25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[39:40]                ; 1a024f25
	buffer_load_b64 v[38:39], v12, s[52:55], null offen         ; c405407c 40806826 0000000c
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[40:41]                ; 1a025125
	v_permlanex16_b32 v41, v37, s24, s25 op_sel:[1,1]           ; d65c1829 00643125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[41:42]                ; 1a025325
	buffer_load_b64 v[40:41], v12, s[52:55], null offen offset:512 ; c405407c 40806828 0002000c
	v_add_f16_e32 v42, v37, v165/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64554b25
	v_max_num_f16_e32 v42, 0x400, v42                           ; 625454ff 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v43, v42                                  ; 7e56172a
	v_rcp_f32_e32 v43, v43                                      ; 7e56552b
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v46, v177, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002e 8a0257b1
	v_fma_mix_f32 v44, v175, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002c 8a0257af
	v_fma_mix_f32 v56, v183, v43, neg(0) op_sel_hi:[1,0,0]      ; cc200038 8a0257b7
	v_fma_mix_f32 v183, v183, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a0257b7
	v_fma_mix_f32 v177, v177, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a0257b1
	v_fma_mix_f32 v175, v175, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a0257af
	v_fma_mix_f32 v47, v178, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002f 8a0257b2
	v_fma_mix_f32 v178, v178, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a0257b2
	v_fma_mix_f32 v45, v176, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002d 8a0257b0
	v_fma_mix_f32 v176, v176, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a0257b0
	v_fma_mix_f32 v57, v184, v43, neg(0) op_sel_hi:[1,0,0]      ; cc200039 8a0257b8
	v_fma_mix_f32 v184, v184, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a0257b8
	v_fma_mix_f32 v58, v185, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003a 8a0257b9
	v_fma_mix_f32 v185, v185, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a0257b9
	v_fma_mix_f32 v59, v186, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003b 8a0257ba
	v_fma_mix_f32 v186, v186, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a0257ba
	v_fma_mix_f32 v60, v191, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a0257bf
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v46, v177, vcc_lo                     ; 0203632e
	v_fma_mix_f32 v191, v191, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a0257bf
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v44, v175, vcc_lo                     ; 02035f2c
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v56, v183, vcc_lo                     ; 02036f38
	v_fma_mix_f32 v61, v2, v43, neg(0) op_sel_hi:[1,0,0]        ; cc20003d 8a025702
	v_fma_mix_f32 v2, v2, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200802 8a025702
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v47, v178, vcc_lo                     ; 0203652f
	v_fma_mix_f32 v62, v13, v43, neg(0) op_sel_hi:[1,0,0]       ; cc20003e 8a02570d
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v45, v176, vcc_lo                     ; 0203612d
	v_fma_mix_f32 v13, v13, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080d 8a02570d
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v57, v184, vcc_lo                     ; 02037139
	v_fma_mix_f32 v63, v20, v43, neg(0) op_sel_hi:[1,0,0]       ; cc20003f 8a025714
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v58, v185, vcc_lo                     ; 0203733a
	v_fma_mix_f32 v20, v20, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a025714
	v_fma_mix_f32 v64, v29, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200040 8a02571d
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v59, v186, vcc_lo                     ; 0203753b
	v_fma_mix_f32 v29, v29, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081d 8a02571d
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v60, v191, vcc_lo                     ; 02037f3c
	v_fma_mix_f32 v65, v30, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200041 8a02571e
	v_fma_mix_f32 v30, v30, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081e 8a02571e
	v_fma_mix_f32 v66, v31, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200042 8a02571f
	v_fma_mix_f32 v31, v31, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081f 8a02571f
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v61, v2, vcc_lo                       ; 0202053d
	v_fma_mix_f32 v67, v32, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200043 8a025720
	v_fma_mix_f32 v32, v32, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a025720
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v62, v13, vcc_lo                      ; 02021b3e
	v_lshl_add_u32 v179, v179, 5, s28                           ; d64600b3 00710bb3
	v_lshl_add_u32 v187, v187, 5, s28                           ; d64600bb 00710bbb
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v63, v20, vcc_lo                      ; 0202293f
	v_lshl_add_u32 v21, v21, 5, s28                             ; d6460015 00710b15
	v_lshl_add_u32 v33, v33, 5, s28                             ; d6460021 00710b21
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v64, v29, vcc_lo                      ; 02023b40
	v_lshl_add_u32 v180, v180, 5, s28                           ; d64600b4 00710bb4
	v_lshl_add_u32 v188, v188, 5, s28                           ; d64600bc 00710bbc
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v65, v30, vcc_lo                      ; 02023d41
	v_lshl_add_u32 v22, v22, 5, s28                             ; d6460016 00710b16
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v66, v31, vcc_lo                      ; 02023f42
	v_lshl_add_u32 v34, v34, 5, s28                             ; d6460022 00710b22
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v67, v32, vcc_lo                      ; 02024143
	v_lshl_add_u32 v181, v181, 5, s28                           ; d64600b5 00710bb5
	v_lshl_add_u32 v189, v189, 5, s28                           ; d64600bd 00710bbd
	v_lshl_add_u32 v23, v23, 5, s28                             ; d6460017 00710b17
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[179:180], v[187:188]            ; 1a0377b3
	v_lshl_add_u32 v35, v35, 5, s28                             ; d6460023 00710b23
	v_lshl_add_u32 v182, v182, 5, s28                           ; d64600b6 00710bb6
	v_lshl_add_u32 v190, v190, 5, s28                           ; d64600be 00710bbe
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[180:181], v[188:189]            ; 1a0379b4
	v_lshl_add_u32 v28, v28, 5, s28                             ; d646001c 00710b1c
	v_lshl_add_u32 v36, v36, 5, s28                             ; d6460024 00710b24
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[181:182], v[189:190]            ; 1a037bb5
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[21:22]                ; 1a022b44
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[182:183], v[190:191]            ; 1a037db6
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[22:23]                ; 1a022d45
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[23:24]                ; 1a022f46
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[33:34]                ; 1a024344
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[28:29]                ; 1a023947
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[34:35]                ; 1a024545
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[35:36]                ; 1a024746
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[36:37]                ; 1a024947
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[69:70]                ; 1a028b44
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[70:71]                ; 1a028d44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[71:72]                ; 1a028f44
	v_permlanex16_b32 v72, v68, s24, s25 op_sel:[1,1]           ; d65c1848 00643144
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[72:73]                ; 1a029144
	v_add_f16_e32 v73, v68, v196/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64938944
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v73, 0x400, v73                           ; 629292ff 00000400
	v_cvt_f32_f16_e32 v74, v73                                  ; 7e941749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v74, v74                                      ; 7e94554a
	v_fma_mix_f32 v76, v180, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004c 8a0295b4
	v_fma_mix_f32 v83, v21, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200053 8a029515
	v_fma_mix_f32 v21, v21, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a029515
	v_fma_mix_f32 v180, v180, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a0295b4
	v_fma_mix_f32 v75, v179, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004b 8a0295b3
	v_fma_mix_f32 v85, v23, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200055 8a029517
	v_fma_mix_f32 v23, v23, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a029517
	v_fma_mix_f32 v86, v28, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200056 8a02951c
	v_fma_mix_f32 v28, v28, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a02951c
	v_fma_mix_f32 v179, v179, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a0295b3
	v_fma_mix_f32 v77, v181, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004d 8a0295b5
	v_fma_mix_f32 v181, v181, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a0295b5
	v_fma_mix_f32 v78, v182, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004e 8a0295b6
	v_fma_mix_f32 v182, v182, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a0295b6
	v_fma_mix_f32 v79, v187, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004f 8a0295bb
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v83, v21, vcc_lo                      ; 02022b53
	v_fma_mix_f32 v187, v187, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a0295bb
	v_fma_mix_f32 v80, v188, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200050 8a0295bc
	v_fma_mix_f32 v188, v188, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a0295bc
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v85, v23, vcc_lo                      ; 02022f55
	v_fma_mix_f32 v81, v189, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200051 8a0295bd
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v86, v28, vcc_lo                      ; 02023956
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	v_fma_mix_f32 v189, v189, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a0295bd
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v75, v179, vcc_lo                     ; 0203674b
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v76, v180, vcc_lo                     ; 0203694c
	v_fma_mix_f32 v82, v190, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200052 8a0295be
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v77, v181, vcc_lo                     ; 02036b4d
	v_fma_mix_f32 v190, v190, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a0295be
	v_fma_mix_f32 v84, v22, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200054 8a029516
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v78, v182, vcc_lo                     ; 02036d4e
	v_fma_mix_f32 v22, v22, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a029516
	v_fma_mix_f32 v87, v33, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200057 8a029521
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v79, v187, vcc_lo                     ; 0203774f
	v_fma_mix_f32 v33, v33, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200821 8a029521
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v80, v188, vcc_lo                     ; 02037950
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[28:29], v[24:25], 0 ; cc464040 1a02311c
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v81, v189, vcc_lo                     ; 02037b51
	v_fma_mix_f32 v88, v34, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200058 8a029522
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v82, v190, vcc_lo                     ; 02037d52
	v_fma_mix_f32 v34, v34, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200822 8a029522
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v84, v22, vcc_lo                      ; 02022d54
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v87, v33, vcc_lo                      ; 02024357
	v_fma_mix_f32 v89, v35, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200059 8a029523
	v_fma_mix_f32 v35, v35, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200823 8a029523
	v_fma_mix_f32 v90, v36, v74, neg(0) op_sel_hi:[1,0,0]       ; cc20005a 8a029524
	v_fma_mix_f32 v36, v36, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200824 8a029524
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[30:31], 0 ; cc464048 1a023d1c
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v88, v34, vcc_lo                      ; 02024558
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[28:29], v[44:45], v[64:71] ; cc464040 1d02591c
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v89, v35, vcc_lo                      ; 02024759
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v90, v36, vcc_lo                      ; 0202495a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[42:43], v[72:79] ; cc464048 1d22551c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[14:15], v[46:47], v[64:71] ; cc464050 1d025d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[46:47], v[64:71] ; cc464040 1d025d08
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v59, v131, v7 :: v_dual_mul_f32 v58, v130, v6 ; c8c60f83 3b3a0d82
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v61, v133, v17 :: v_dual_mul_f32 v60, v132, v16 ; c8c62385 3d3c2184
	v_dual_mul_f32 v63, v135, v19 :: v_dual_mul_f32 v62, v134, v18 ; c8c62787 3f3e2586
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[14:15], v[20:21], v[72:79] ; cc464058 1d22290e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[20:21], v[72:79] ; cc464048 1d222908
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[26:27], v[56:57], v[80:87] ; cc464050 1d42711a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[10:11], v[56:57], v[64:71] ; cc464040 1d02710a
	v_dual_mul_f32 v57, v129, v5 :: v_dual_mul_f32 v56, v128, v4 ; c8c60b81 39380980
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[26:27], v[22:23], v[88:95] ; cc464058 1d622d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[10:11], v[22:23], v[72:79] ; cc464048 1d222d0a
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_dual_mul_f32 v65, v145, v5 :: v_dual_mul_f32 v64, v144, v4 ; c8c60b91 41400990
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_dual_mul_f32 v69, v149, v17 :: v_dual_mul_f32 v68, v148, v16 ; c8c62395 45442194
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v67, v147, v7 :: v_dual_mul_f32 v66, v146, v6 ; c8c60f93 43420d92
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[38:39], v[14:15], v[56:63] ; cc464038 1ce21d26
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_dual_mul_f32 v71, v151, v19 :: v_dual_mul_f32 v70, v150, v18 ; c8c62797 47462596
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_cmp_lg_i32 s35, 0                                         ; bf018023
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[38:39], v[24:25], v[64:71] ; cc464040 1d023126
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[40:41], v[8:9], v[56:63] ; cc464038 1ce21128
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[40:41], v[10:11], v[64:71] ; cc464040 1d021528
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_cbranch_scc1 BB24                                         ; bfa20007
BB22:
	v_add3_u32 v2, v3, s2, s13                                  ; d6550002 00340503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[4:5], v2, s[16:19], null offen           ; c406c07c 40802004 00000002
BB24:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_lg_i32 s40, 0                                         ; bf018028
	s_cbranch_scc1 BB27                                         ; bfa20007
BB25:
	v_add3_u32 v2, v3, s2, s29                                  ; d6550002 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[4:5], v2, s[16:19], null offen           ; c406c07c 40802004 00000002
BB27:
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[4:7], v0, s[20:23], null offen offset:64 ; c405c07c 40802804 00004000
	buffer_load_b128 v[16:19], v0, s[20:23], null offen offset:80 ; c405c07c 40802810 00005000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[20:21], v12, s[52:55], null offen offset:8 ; c405407c 40806814 0000080c
	buffer_load_b64 v[12:13], v12, s[52:55], null offen offset:520 ; c405407c 4080680c 0002080c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v33, v153, v5 :: v_dual_mul_f32 v32, v152, v4 ; c8c60b99 21200998
	v_dual_mul_f32 v35, v155, v7 :: v_dual_mul_f32 v34, v154, v6 ; c8c60f9b 23220d9a
	v_dual_mul_f32 v41, v49, v5 :: v_dual_mul_f32 v40, v48, v4  ; c8c60b31 29280930
	v_dual_mul_f32 v43, v51, v7 :: v_dual_mul_f32 v42, v50, v6  ; c8c60f33 2b2a0d32
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v37, v157, v17 :: v_dual_mul_f32 v36, v156, v16 ; c8c6239d 2524219c
	v_dual_mul_f32 v39, v159, v19 :: v_dual_mul_f32 v38, v158, v18 ; c8c6279f 2726259e
	v_dual_mul_f32 v45, v53, v17 :: v_dual_mul_f32 v44, v52, v16 ; c8c62335 2d2c2134
	v_dual_mul_f32 v47, v55, v19 :: v_dual_mul_f32 v46, v54, v18 ; c8c62737 2f2e2536
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[20:21], v[14:15], v[32:39] ; cc464020 1c821d14
	s_mov_b32 s0, vcc_lo                                        ; be80006a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[20:21], v[24:25], v[40:47] ; cc464028 1ca23114
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[12:13], v[8:9], v[32:39] ; cc464020 1c82110c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[10:11], v[40:47] ; cc464028 1ca2150c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_cbranch_scc1 BB30                                         ; bfa20009
BB28:
	s_add_co_u32 s1, s2, 0x100                                  ; 8001ff02 00000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	v_add3_u32 v0, v3, s1, s13                                  ; d6550000 00340303
	v_add_nc_u32_e32 v0, v0, v1                                 ; 4a000300
	buffer_store_b64 v[4:5], v0, s[16:19], null offen           ; c406c07c 40802004 00000000
BB30:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB78                                         ; bfa221a7
BB31:
	s_addk_co_i32 s2, 0x100                                     ; b7820100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v3, v3, s2, s29                                  ; d6550003 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	buffer_store_b64 v[4:5], v3, s[16:19], null offen           ; c406c07c 40802004 00000003
	s_branch BB78                                               ; bfa0219d
BB34:
	s_cmp_eq_i32 s17, 3                                         ; bf008311
	s_cbranch_scc0 BB48                                         ; bfa10b33
BB35:
	s_mov_b32 s15, s1                                           ; be8f0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[32:35], s[0:1], 0x0                           ; f4004800 f8000000
	s_load_b256 s[40:47], s[0:1], 0x30                          ; f4006a00 f8000030
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_max_i32 s13, s13, 0                                       ; 8a0d800d
	s_add_co_u32 s17, s11, -1                                   ; 8011c10b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s13, s13, s17                                     ; 890d110d
	s_max_i32 s14, s14, 0                                       ; 8a0e800e
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	s_min_i32 s14, s14, s12                                     ; 890e0c0e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s14, s14, s11                                     ; 960e0b0e
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_add_co_u32 s13, s14, s13                                  ; 800d0d0e
	s_lshl_b32 s13, s13, 9                                      ; 840d890d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s18, s15, s13                                  ; 80120d0f
	s_max_i32 s20, s20, 0                                       ; 8a148014
	v_add3_u32 v5, v3, s18, 0x100                               ; d6550005 03fc2503 00000100
	v_add3_u32 v4, v1, s18, v3                                  ; d6550004 040c2501
	s_min_i32 s20, s20, s17                                     ; 89141114
	s_add_co_u32 s14, s14, s20                                  ; 800e140e
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_lshl_b32 s14, s14, 9                                      ; 840e890e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s15, s15, s14                                  ; 800f0e0f
	v_add3_u32 v7, v3, s15, 0x100                               ; d6550007 03fc1f03 00000100
	v_add3_u32 v6, v1, s15, v3                                  ; d6550006 040c1f01
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[8:9], v4, s[32:35], null offen            ; c405407c 40804008 00000004
	buffer_load_b64 v[4:5], v5, s[32:35], null offen            ; c405407c 40804004 00000005
	buffer_load_b64 v[10:11], v6, s[32:35], null offen          ; c405407c 4080400a 00000006
	buffer_load_b64 v[6:7], v7, s[32:35], null offen            ; c405407c 40804006 00000007
	v_lshlrev_b32_e32 v12, 2, v0                                ; 30180082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v13, s3, v12, 2                              ; d647000d 020a1803
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[16:19], v13, s[44:47], null offen        ; c405c07c 40805810 0000000d
	buffer_load_b128 v[20:23], v13, s[44:47], null offen offset:512 ; c405c07c 40805814 0002000d
	buffer_load_b128 v[24:27], v13, s[44:47], null offen offset:1024 ; c405c07c 40805818 0004000d
	buffer_load_b128 v[28:31], v13, s[44:47], null offen offset:1536 ; c405c07c 4080581c 0006000d
	buffer_load_b128 v[32:35], v13, s[44:47], null offen offset:2048 ; c405c07c 40805820 0008000d
	buffer_load_b128 v[36:39], v13, s[44:47], null offen offset:2560 ; c405c07c 40805824 000a000d
	buffer_load_b128 v[40:43], v13, s[44:47], null offen offset:3072 ; c405c07c 40805828 000c000d
	buffer_load_b128 v[44:47], v13, s[44:47], null offen offset:3584 ; c405c07c 4080582c 000e000d
	v_lshrrev_b32_e32 v0, 4, v0                                 ; 32000084
	s_mov_b64 s[36:37], s[40:41]                                ; bea40128
	s_mov_b64 s[38:39], s[42:43]                                ; bea6012a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshlrev_b32_e32 v0, 3, v0                                 ; 30000083
	v_add_lshl_u32 v14, s8, v0, 2                               ; d647000e 020a0008
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v14, s[36:39], null offen        ; c405c07c 40804830 0000000e
	buffer_load_b128 v[52:55], v14, s[36:39], null offen offset:16 ; c405c07c 40804834 0000100e
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add_lshl_u32 v15, s4, v12, 2                              ; d647000f 020a1804
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[56:59], v15, s[44:47], null offen        ; c405c07c 40805838 0000000f
	buffer_load_b128 v[60:63], v15, s[44:47], null offen offset:512 ; c405c07c 4080583c 0002000f
	buffer_load_b128 v[64:67], v15, s[44:47], null offen offset:1024 ; c405c07c 40805840 0004000f
	buffer_load_b128 v[68:71], v15, s[44:47], null offen offset:1536 ; c405c07c 40805844 0006000f
	buffer_load_b128 v[72:75], v15, s[44:47], null offen offset:2048 ; c405c07c 40805848 0008000f
	buffer_load_b128 v[76:79], v15, s[44:47], null offen offset:2560 ; c405c07c 4080584c 000a000f
	buffer_load_b128 v[80:83], v15, s[44:47], null offen offset:3072 ; c405c07c 40805850 000c000f
	buffer_load_b128 v[84:87], v15, s[44:47], null offen offset:3584 ; c405c07c 40805854 000e000f
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_cndmask_b32_e64 v8, v8, 0, s16                            ; d5010008 00410108
	v_cndmask_b32_e64 v9, v9, 0, s16                            ; d5010009 00410109
	s_wait_loadcnt 0x14                                         ; bfc00014
	v_cndmask_b32_e64 v5, v5, 0, s16                            ; d5010005 00410105
	v_cndmask_b32_e64 v4, v4, 0, s16                            ; d5010004 00410104
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_cndmask_b32_e64 v10, v10, 0, s22                          ; d501000a 0059010a
	v_cndmask_b32_e64 v11, v11, 0, s22                          ; d501000b 0059010b
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v7, v7, 0, s22                            ; d5010007 00590107
	v_cndmask_b32_e64 v6, v6, 0, s22                            ; d5010006 00590106
	v_cvt_pk_f32_fp8_e32 v[92:93], v136                         ; 7eb8dd88
	v_cvt_pk_f32_fp8_e32 v[90:91], v8                           ; 7eb4dd08
	v_dual_mov_b32 v89, v9 :: v_dual_mov_b32 v88, v8            ; ca100109 59580108
	v_cvt_pk_f32_fp8_e32 v[94:95], v9                           ; 7ebcdd09
	v_cvt_pk_f32_fp8_e32 v[8:9], v137                           ; 7e10dd89
	v_dual_mov_b32 v97, v5 :: v_dual_mov_b32 v96, v4            ; ca100105 61600104
	v_cvt_pk_f32_fp8_e32 v[100:101], v10                        ; 7ec8dd0a
	v_dual_mov_b32 v99, v11 :: v_dual_mov_b32 v98, v10          ; ca10010b 6362010a
	v_cvt_pk_f32_fp8_e32 v[102:103], v138                       ; 7eccdd8a
	v_cvt_pk_f32_fp8_e32 v[104:105], v11                        ; 7ed0dd0b
	v_dual_mov_b32 v107, v7 :: v_dual_mov_b32 v106, v6          ; ca100107 6b6a0106
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[88:89], 0 ; cc464070 1a02b110
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[88:89], 0 ; cc464080 1a02b112
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[98:99], 0 ; cc464078 1a02c510
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[98:99], 0 ; cc464088 1a02c512
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[96:97], v[112:119] ; cc464070 1dc2c114
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[20:21], v[106:107], v[120:127] ; cc464078 1de2d514
	v_maxmin_num_f32 v110, -4.0, v116, 4.0                      ; d669006e 03dae8f7
	v_maxmin_num_f32 v20, -4.0, v114, 4.0                       ; d6690014 03dae4f7
	v_maxmin_num_f32 v108, -4.0, v115, 4.0                      ; d669006c 03dae6f7
	v_maxmin_num_f32 v18, -4.0, v113, 4.0                       ; d6690012 03dae2f7
	v_maxmin_num_f32 v16, -4.0, v112, 4.0                       ; d6690010 03dae0f7
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v21, 0xab28, |v20|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfe28ff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v19, 0xab28, |v18|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206213 0bfe24ff 3728ab28
	v_fma_mix_f32 v17, 0xab28, |v16|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206211 0bfe20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fmaak_f32 v109, v109, v108, 0x3f650000                    ; 5adad96d 3f650000
	v_dual_fmaak_f32 v19, v19, v18, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v17, 0x3f650000 ; c8422513 13102310 3f650000
	v_maxmin_num_f32 v144, -4.0, v121, 4.0                      ; d6690090 03daf2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_mul_f32 v115, v109, v115 :: v_dual_fmaak_f32 v20, v20, v21, 0x3f650000 ; c8c2e76d 73142b14 3f650000
	v_dual_mul_f32 v113, v113, v19 :: v_dual_mul_f32 v112, v112, v16 ; c8c62771 71702170
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v117, 4.0                      ; d6690070 03daeaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v123, 4.0                      ; d6690094 03daf6f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v122, 4.0                      ; d6690092 03daf4f7
	v_dual_mul_f32 v117, v117, v113 :: v_dual_mul_f32 v116, v116, v110 ; c8c6e375 7574dd74
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v125, 4.0                      ; d6690098 03dafaf7
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v116, -4.0, v119, 4.0                      ; d6690074 03daeef7
	v_maxmin_num_f32 v150, -4.0, v124, 4.0                      ; d6690096 03daf8f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v127, 4.0                      ; d669009c 03dafef7
	v_dual_fmaak_f32 v117, v116, v117, 0x3f650000 :: v_dual_mul_f32 v114, v114, v20 ; c846eb74 75722972 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v126, 4.0                      ; d669009a 03dafcf7
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v118, 4.0                      ; d6690072 03daecf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[96:97], v[128:135] ; cc464080 1e02c116
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_dual_mul_f32 v119, v119, v117 :: v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 ; c8c2eb77 7772e772 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v118, v118, v114 ; c8472191 9176e576 3f650000
	v_maxmin_num_f32 v160, -4.0, v129, 4.0                      ; d66900a0 03db02f7
	v_maxmin_num_f32 v158, -4.0, v128, 4.0                      ; d669009e 03db00f7
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v120, 4.0                      ; d6690076 03daf0f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v131, 4.0                      ; d66900a4 03db06f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v130, 4.0                      ; d66900a2 03db04f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_mul_f32 v121, v121, v145 :: v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 ; c8c32379 7976ef76 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[106:107], v[136:143] ; cc464088 1e22d516
	v_maxmin_num_f32 v168, -4.0, v133, 4.0                      ; d66900a8 03db0af7
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v120, v120, v118 ; c8472995 9578ed78 3f650000
	v_maxmin_num_f32 v166, -4.0, v132, 4.0                      ; d66900a6 03db08f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d3
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v123, v123, v149 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8c32b7b 7b932792 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v135, 4.0                      ; d66900ac 03db0ef7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v122, v122, v146 ; c8473199 997b257a 3f650000
	v_maxmin_num_f32 v170, -4.0, v134, 4.0                      ; d66900aa 03db0cf7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v125, v125, v153 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8c3337d 7d972f96 3f650000
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v137, 4.0                      ; d66900b0 03db12f7
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v124, v124, v150 ; c847399d 9d7d2d7c 3f650000
	v_maxmin_num_f32 v174, -4.0, v136, 4.0                      ; d66900ae 03db10f7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_mul_f32 v127, v127, v157 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8c33b7f 7f9b379a 3f650000
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v139, 4.0                      ; d66900b4 03db16f7
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_mul_f32 v126, v126, v154 ; c84741a1 a17f357e 3f650000
	v_maxmin_num_f32 v178, -4.0, v138, 4.0                      ; d66900b2 03db14f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v129, v129, v161 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c8c34381 819f3f9e 3f650000
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v141, 4.0                      ; d66900b8 03db1af7
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_mul_f32 v128, v128, v158 ; c84749a5 a5813d80 3f650000
	v_maxmin_num_f32 v182, -4.0, v140, 4.0                      ; d66900b6 03db18f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v131, v131, v165 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8c34b83 83a347a2 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v143, 4.0                      ; d66900bc 03db1ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_mul_f32 v130, v130, v162 ; c84751a9 a9834582 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[88:89], 0 ; cc464070 1a02b118
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v133, v133, v169 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c8c35385 85a74fa6 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v132, v132, v166 ; c84759ad ad854d84 3f650000
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[96:97], v[112:119] ; cc464070 1dc2c11c
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v135, v135, v173 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8c35b87 87ab57aa 3f650000
	v_maxmin_num_f32 v186, -4.0, v142, 4.0                      ; d66900ba 03db1cf7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_mul_f32 v134, v134, v170 ; c84761b1 b1875586 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v112, 4.0                      ; d66900be 03dae0f7
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v137, v137, v177 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c8c36389 89af5fae 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[98:99], 0 ; cc464078 1a02c518
	v_maxmin_num_f32 v15, -4.0, v114, 4.0                       ; d669000f 03dae4f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v136, v136, v174 ; c84769b5 b5895d88 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v25, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe1eff 3728ab28
	v_dual_mul_f32 v139, v139, v181 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c8c36b8b 8bb367b2 3f650000
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fmaak_f32 v15, v15, v25, 0x3f650000                       ; 5a1e330f 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[106:107], v[120:127] ; cc464078 1de2d51c
	v_maxmin_num_f32 v28, -4.0, v115, 4.0                       ; d669001c 03dae6f7
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_mul_f32 v138, v138, v178 ; c84771b9 b98b658a 3f650000
	v_maxmin_num_f32 v108, -4.0, v116, 4.0                      ; d669006c 03dae8f7
	v_maxmin_num_f32 v110, -4.0, v117, 4.0                      ; d669006e 03daeaf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v141, v141, v185 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c8c3738d 8db76fb6 3f650000
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v140, v140, v182 ; c84779bd bd8d6d8c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b8f 8fbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v113, 4.0                      ; d66900bf 03dae2f7
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v108 ; c8c6df75 7574d974
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 :: v_dual_mul_f32 v112, v112, v190 ; c846391d 1d717d70 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v115, v115, v29 :: v_dual_mul_f32 v114, v114, v15 ; c8c63b73 73721f72
	v_dual_fmaak_f32 v13, v191, v13, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8421bbf 0dbb77ba 3f650000
	v_maxmin_num_f32 v116, -4.0, v120, 4.0                      ; d6690074 03daf0f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v113, v113, v13 :: v_dual_mul_f32 v142, v142, v186 ; c8c61b71 718f758e
	v_maxmin_num_f32 v128, -4.0, v123, 4.0                      ; d6690080 03daf6f7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v118, 4.0                      ; d6690070 03daecf7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v119, 4.0                      ; d6690072 03daeef7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v125, 4.0                      ; d6690084 03dafaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v124, 4.0                      ; d6690082 03daf8f7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c8430181 8174eb74 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v127, 4.0                      ; d6690088 03dafef7
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_mul_f32 v123, v123, v129 :: v_dual_mul_f32 v120, v120, v116 ; c8c7037b 7b78e978
	v_maxmin_num_f32 v134, -4.0, v126, 4.0                      ; d6690086 03dafcf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v119, v119, v115 :: v_dual_mul_f32 v118, v118, v112 ; c8c6e777 7776e176
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8431189 89830782 3f650000
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v121, 4.0                      ; d6690076 03daf2f7
	v_dual_mul_f32 v127, v127, v137 :: v_dual_mul_f32 v124, v124, v130 ; c8c7137f 7f7d057c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fmaak_f32 v119, v119, v118, 0x3f650000                    ; 5aeeed77 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_mul_f32_e32 v121, v121, v119                              ; 10f2ef79
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[88:89], 0 ; cc464070 1a02b11a
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v122, 4.0                      ; d6690078 03daf4f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[96:97], v[112:119] ; cc464070 1dc2c11e
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8430985 8578f378 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v125, v125, v133 :: v_dual_mul_f32 v122, v122, v120 ; c8c70b7d 7d7af17a
	v_maxmin_num_f32 v140, -4.0, v113, 4.0                      ; d669008c 03dae2f7
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v144, -4.0, v115, 4.0                      ; d6690090 03dae6f7
	v_maxmin_num_f32 v138, -4.0, v112, 4.0                      ; d669008a 03dae0f7
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v142, -4.0, v114, 4.0                      ; d669008e 03dae4f7
	v_maxmin_num_f32 v148, -4.0, v117, 4.0                      ; d6690094 03daeaf7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v116, 4.0                      ; d6690092 03dae8f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v119, 4.0                      ; d6690098 03daeef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c843198d 8d870f86 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v118, 4.0                      ; d6690096 03daecf7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c8432191 918b178a 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432995 958f1f8e 3f650000
	v_dual_mul_f32 v113, v113, v141 :: v_dual_mul_f32 v126, v126, v134 ; c8c71b71 717f0d7e
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8433199 99932792 3f650000
	v_dual_mul_f32 v115, v115, v145 :: v_dual_mul_f32 v112, v112, v138 ; c8c72373 73711570
	v_dual_mul_f32 v117, v117, v149 :: v_dual_mul_f32 v114, v114, v142 ; c8c72b75 75731d72
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[98:99], 0 ; cc464078 1a02c51a
	v_dual_mul_f32 v119, v119, v153 :: v_dual_mul_f32 v116, v116, v146 ; c8c73377 77752574
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[106:107], v[120:127] ; cc464078 1de2d51e
	v_maxmin_num_f32 v164, -4.0, v125, 4.0                      ; d66900a4 03dafaf7
	v_maxmin_num_f32 v160, -4.0, v123, 4.0                      ; d66900a0 03daf6f7
	v_maxmin_num_f32 v154, -4.0, v120, 4.0                      ; d669009a 03daf0f7
	v_maxmin_num_f32 v156, -4.0, v121, 4.0                      ; d669009c 03daf2f7
	v_maxmin_num_f32 v158, -4.0, v122, 4.0                      ; d669009e 03daf4f7
	v_maxmin_num_f32 v162, -4.0, v124, 4.0                      ; d66900a2 03daf8f7
	v_maxmin_num_f32 v168, -4.0, v127, 4.0                      ; d66900a8 03dafef7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v126, 4.0                      ; d66900a6 03dafcf7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c84341a1 a19b379a 3f650000
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c843399d 9d972f96 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84349a5 a59f3f9e 3f650000
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84351a9 a9a347a2 3f650000
	v_dual_mul_f32 v123, v123, v161 :: v_dual_mul_f32 v120, v120, v154 ; c8c7437b 7b793578
	v_dual_mul_f32 v121, v121, v157 :: v_dual_mul_f32 v118, v118, v150 ; c8c73b79 79772d76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_mul_f32 v125, v125, v165 :: v_dual_mul_f32 v122, v122, v158 ; c8c74b7d 7d7b3d7a
	v_dual_mul_f32 v127, v127, v169 :: v_dual_mul_f32 v124, v124, v162 ; c8c7537f 7f7d457c
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[88:89], 0 ; cc464070 1a02b120
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[96:97], v[112:119] ; cc464070 1dc2c124
	v_maxmin_num_f32 v176, -4.0, v115, 4.0                      ; d66900b0 03dae6f7
	v_maxmin_num_f32 v174, -4.0, v114, 4.0                      ; d66900ae 03dae4f7
	v_maxmin_num_f32 v172, -4.0, v113, 4.0                      ; d66900ac 03dae2f7
	v_maxmin_num_f32 v170, -4.0, v112, 4.0                      ; d66900aa 03dae0f7
	v_maxmin_num_f32 v180, -4.0, v117, 4.0                      ; d66900b4 03daeaf7
	v_maxmin_num_f32 v178, -4.0, v116, 4.0                      ; d66900b2 03dae8f7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v119, 4.0                      ; d66900b8 03daeef7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v118, 4.0                      ; d66900b6 03daecf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84359ad ada74fa6 3f650000
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84361b1 b1ab57aa 3f650000
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84369b5 b5af5fae 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84371b9 b9b367b2 3f650000
	v_dual_mul_f32 v113, v113, v173 :: v_dual_mul_f32 v126, v126, v166 ; c8c75b71 717f4d7e
	v_dual_mul_f32 v115, v115, v177 :: v_dual_mul_f32 v112, v112, v170 ; c8c76373 73715570
	v_dual_mul_f32 v117, v117, v181 :: v_dual_mul_f32 v114, v114, v174 ; c8c76b75 75735d72
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v119, v119, v185 :: v_dual_mul_f32 v116, v116, v178 ; c8c77377 77756574
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[98:99], 0 ; cc464078 1a02c520
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[106:107], v[120:127] ; cc464078 1de2d524
	v_maxmin_num_f32 v190, -4.0, v122, 4.0                      ; d66900be 03daf4f7
	v_maxmin_num_f32 v186, -4.0, v120, 4.0                      ; d66900ba 03daf0f7
	v_maxmin_num_f32 v188, -4.0, v121, 4.0                      ; d66900bc 03daf2f7
	v_maxmin_num_f32 v15, -4.0, v124, 4.0                       ; d669000f 03daf8f7
	v_maxmin_num_f32 v108, -4.0, v125, 4.0                      ; d669006c 03dafaf7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v126, 4.0                      ; d669006e 03dafcf7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v127, 4.0                      ; d6690070 03dafef7
	v_fma_mix_f32 v37, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfe1eff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84379bd bdb76fb6 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v121, v121, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b79 79bf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v123, 4.0                      ; d66900bf 03daf6f7
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_mul_f32 v122, v122, v190 ; c846d96d 6d7b7d7a 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_dual_mul_f32 v127, v127, v113 :: v_dual_mul_f32 v126, v126, v110 ; c8c6e37f 7f7edd7e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v13, v13, v191, 0x3f650000 :: v_dual_mul_f32 v118, v118, v182 ; c8477f0d 0d776d76 3f650000
	v_dual_mul_f32 v123, v123, v13 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8c21b7b 7bbb77ba 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[88:89], 0 ; cc464070 1a02b122
	v_dual_fmaak_f32 v15, v15, v37, 0x3f650000 :: v_dual_mul_f32 v120, v120, v186 ; c8464b0f 0f797578 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_mul_f32 v125, v125, v109 :: v_dual_mul_f32 v124, v124, v15 ; c8c6db7d 7d7c1f7c
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[98:99], 0 ; cc464078 1a02c522
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[96:97], v[112:119] ; cc464070 1dc2c126
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[106:107], v[120:127] ; cc464078 1de2d526
	v_maxmin_num_f32 v138, -4.0, v117, 4.0                      ; d669008a 03daeaf7
	v_maxmin_num_f32 v130, -4.0, v113, 4.0                      ; d6690082 03dae2f7
	v_maxmin_num_f32 v136, -4.0, v116, 4.0                      ; d6690088 03dae8f7
	v_maxmin_num_f32 v132, -4.0, v114, 4.0                      ; d6690084 03dae4f7
	v_maxmin_num_f32 v134, -4.0, v115, 4.0                      ; d6690086 03dae6f7
	v_maxmin_num_f32 v128, -4.0, v112, 4.0                      ; d6690080 03dae0f7
	v_maxmin_num_f32 v140, -4.0, v118, 4.0                      ; d669008c 03daecf7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v119, 4.0                      ; d669008e 03daeef7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v120, 4.0                      ; d6690090 03daf0f7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v121, 4.0                      ; d6690092 03daf2f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c843158b 8b891388 3f650000
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430d87 87850b84 3f650000
	v_maxmin_num_f32 v148, -4.0, v122, 4.0                      ; d6690094 03daf4f7
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
	v_maxmin_num_f32 v150, -4.0, v123, 4.0                      ; d6690096 03daf6f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 ; c8431d8f 8f8d1b8c 3f650000
	v_dual_mul_f32 v117, v117, v139 :: v_dual_mul_f32 v116, v116, v136 ; c8c71775 75751174
	v_dual_mul_f32 v115, v115, v135 :: v_dual_mul_f32 v114, v114, v132 ; c8c70f73 73730972
	v_maxmin_num_f32 v152, -4.0, v124, 4.0                      ; d6690098 03daf8f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_mul_f32 v113, v113, v131 :: v_dual_mul_f32 v112, v112, v128 ; c8c70771 71710170
	v_maxmin_num_f32 v154, -4.0, v125, 4.0                      ; d669009a 03dafaf7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_dual_mul_f32 v119, v119, v143 :: v_dual_mul_f32 v118, v118, v140 ; c8c71f77 77771976
	v_maxmin_num_f32 v156, -4.0, v126, 4.0                      ; d669009c 03dafcf7
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v158, -4.0, v127, 4.0                      ; d669009e 03dafef7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_mul_f32 v121, v121, v147 :: v_dual_mul_f32 v120, v120, v144 ; c8c72779 79792178
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[88:89], 0 ; cc464070 1a02b128
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_dual_mul_f32 v123, v123, v151 :: v_dual_mul_f32 v122, v122, v148 ; c8c72f7b 7b7b297a
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_dual_mul_f32 v125, v125, v155 :: v_dual_mul_f32 v124, v124, v152 ; c8c7377d 7d7d317c
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[96:97], v[112:119] ; cc464070 1dc2c12c
	v_dual_mul_f32 v127, v127, v159 :: v_dual_mul_f32 v126, v126, v156 ; c8c73f7f 7f7f397e
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[98:99], 0 ; cc464078 1a02c528
	v_maxmin_num_f32 v162, -4.0, v113, 4.0                      ; d66900a2 03dae2f7
	v_maxmin_num_f32 v160, -4.0, v112, 4.0                      ; d66900a0 03dae0f7
	v_maxmin_num_f32 v164, -4.0, v114, 4.0                      ; d66900a4 03dae4f7
	v_maxmin_num_f32 v166, -4.0, v115, 4.0                      ; d66900a6 03dae6f7
	v_maxmin_num_f32 v168, -4.0, v116, 4.0                      ; d66900a8 03dae8f7
	v_maxmin_num_f32 v170, -4.0, v117, 4.0                      ; d66900aa 03daeaf7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v118, 4.0                      ; d66900ac 03daecf7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	buffer_load_b128 v[108:111], v14, s[36:39], null offen offset:64 ; c405c07c 4080486c 0000400e
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v119, 4.0                      ; d66900ae 03daeef7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[106:107], v[120:127] ; cc464078 1de2d52c
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_mul_f32 v113, v113, v163 :: v_dual_mul_f32 v112, v112, v160 ; c8c74771 71714170
	v_dual_mul_f32 v115, v115, v167 :: v_dual_mul_f32 v114, v114, v164 ; c8c74f73 73734972
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	buffer_load_b128 v[112:115], v14, s[36:39], null offen offset:80 ; c405c07c 40804870 0000500e
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c84355ab aba953a8 3f650000
	v_maxmin_num_f32 v178, -4.0, v121, 4.0                      ; d66900b2 03daf2f7
	v_maxmin_num_f32 v176, -4.0, v120, 4.0                      ; d66900b0 03daf0f7
	v_maxmin_num_f32 v180, -4.0, v122, 4.0                      ; d66900b4 03daf4f7
	v_maxmin_num_f32 v182, -4.0, v123, 4.0                      ; d66900b6 03daf6f7
	v_maxmin_num_f32 v184, -4.0, v124, 4.0                      ; d66900b8 03daf8f7
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 ; c8435daf afad5bac 3f650000
	v_maxmin_num_f32 v186, -4.0, v125, 4.0                      ; d66900ba 03dafaf7
	v_dual_mul_f32 v117, v117, v171 :: v_dual_mul_f32 v116, v116, v168 ; c8c75775 75755174
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v126, 4.0                      ; d66900bc 03dafcf7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_mul_f32 v119, v119, v175 :: v_dual_mul_f32 v118, v118, v172 ; c8c75f77 77775976
	v_maxmin_num_f32 v190, -4.0, v127, 4.0                      ; d66900be 03dafef7
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84365b3 b3b163b0 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c8436db7 b7b56bb4 3f650000
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84375bb bbb973b8 3f650000
	v_dual_mul_f32 v121, v121, v179 :: v_dual_mul_f32 v120, v120, v176 ; c8c76779 79796178
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[98:99], 0 ; cc464080 1a02c52a
	v_dual_mul_f32 v123, v123, v183 :: v_dual_mul_f32 v122, v122, v180 ; c8c76f7b 7b7b697a
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8437dbf bfbd7bbc 3f650000
	v_dual_mul_f32 v125, v125, v187 :: v_dual_mul_f32 v124, v124, v184 ; c8c7777d 7d7d717c
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v127, v127, v191 :: v_dual_mul_f32 v126, v126, v188 ; c8c77f7f 7f7f797e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[106:107], v[128:135] ; cc464080 1e02d52e
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[88:89], 0 ; cc464078 1a02b12a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[96:97], v[120:127] ; cc464078 1de2c12e
	v_maxmin_num_f32 v46, -4.0, v123, 4.0                       ; d669002e 03daf6f7
	v_maxmin_num_f32 v44, -4.0, v122, 4.0                       ; d669002c 03daf4f7
	v_maxmin_num_f32 v42, -4.0, v121, 4.0                       ; d669002a 03daf2f7
	v_maxmin_num_f32 v191, -4.0, v120, 4.0                      ; d66900bf 03daf0f7
	v_maxmin_num_f32 v88, -4.0, v124, 4.0                       ; d6690058 03daf8f7
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_fma_mix_f32 v47, 0xab28, |v46|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622f 0bfe5cff 3728ab28
	v_fma_mix_f32 v45, 0xab28, |v44|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe58ff 3728ab28
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v96, s5, v12, 2                              ; d6470060 020a1805
	v_fma_mix_f32 v43, 0xab28, |v42|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622b 0bfe54ff 3728ab28
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v125, 4.0                       ; d6690061 03dafaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_fmaak_f32 v43, v43, v42, 0x3f650000 :: v_dual_fmaak_f32 v44, v44, v45, 0x3f650000 ; c842552b 2b2c5b2c 3f650000
	v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 :: v_dual_fmaak_f32 v47, v47, v46, 0x3f650000 ; c842b358 582e5d2f 3f650000
	v_dual_mul_f32 v122, v122, v44 :: v_dual_mul_f32 v121, v121, v43 ; c8c6597a 7a785779
	v_dual_mul_f32 v124, v124, v88 :: v_dual_mul_f32 v123, v123, v47 ; c8c6b17c 7c7a5f7b
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v96, s[44:47], null offen        ; c405c07c 4080582c 00000060
	buffer_load_b128 v[116:119], v96, s[44:47], null offen offset:1024 ; c405c07c 40805874 00040060
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v191, v191, v13, 0x3f650000                     ; 5b7e1bbf 3f650000
	v_mul_f32_e32 v120, v120, v191                              ; 10f17f78
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870251
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v99, -4.0, v126, 4.0                       ; d6690063 03dafcf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v127, 4.0                      ; d669006b 03dafef7
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v106, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfec6ff 3728ab28
	v_fmaak_f32 v98, v98, v97, 0x3f650000                       ; 5ac4c362 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_fmaak_f32 v99, v99, v106, 0x3f650000                      ; 5ac6d563 3f650000
	v_maxmin_num_f32 v136, -4.0, v128, 4.0                      ; d6690088 03db00f7
	v_mul_f32_e32 v125, v125, v98                               ; 10fac57d
	v_mul_f32_e32 v126, v126, v99                               ; 10fcc77e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v124, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfed6ff 3728ab28
	v_fmaak_f32 v124, v124, v107, 0x3f650000                    ; 5af8d77c 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_mul_f32_e32 v127, v127, v124                              ; 10fef97f
	v_maxmin_num_f32 v138, -4.0, v129, 4.0                      ; d669008a 03db02f7
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[120:123], v96, s[44:47], null offen offset:2048 ; c405c07c 40805878 00080060
	buffer_load_b128 v[124:127], v96, s[44:47], null offen offset:512 ; c405c07c 4080587c 00020060
	buffer_load_b128 v[140:143], v96, s[44:47], null offen offset:1536 ; c405c07c 4080588c 00060060
	buffer_load_b128 v[96:99], v96, s[44:47], null offen offset:2560 ; c405c07c 40805860 000a0060
	v_maxmin_num_f32 v144, -4.0, v130, 4.0                      ; d6690090 03db04f7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v131, 4.0                      ; d6690092 03db06f7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v132, 4.0                      ; d6690094 03db08f7
	v_maxmin_num_f32 v150, -4.0, v133, 4.0                      ; d6690096 03db0af7
	v_maxmin_num_f32 v152, -4.0, v134, 4.0                      ; d6690098 03db0cf7
	v_maxmin_num_f32 v154, -4.0, v135, 4.0                      ; d669009a 03db0ef7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fmaak_f32 v136, v136, v137, 0x3f650000                    ; 5b111388 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fmaak_f32 v144, v144, v145, 0x3f650000                    ; 5b212390 3f650000
	v_dual_mul_f32 v128, v128, v136 :: v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 ; c8c31180 808b158b 3f650000
	v_fmaak_f32 v147, v147, v146, 0x3f650000                    ; 5b272593 3f650000
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v130, v130, v144 :: v_dual_mul_f32 v129, v129, v139 ; c8c72182 82811781
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_dual_mul_f32 v145, v101, v49 :: v_dual_mul_f32 v144, v100, v48 ; c8c66365 91906164
	v_mul_f32_e32 v131, v131, v147                              ; 11072783
	v_dual_mul_f32 v147, v103, v51 :: v_dual_mul_f32 v146, v102, v50 ; c8c66767 93926566
	v_dual_mul_f32 v133, v133, v151 :: v_dual_mul_f32 v132, v132, v148 ; c8c72f85 85852984
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_mul_f32 v149, v105, v53 :: v_dual_mul_f32 v148, v104, v52 ; c8c66b69 95946968
	v_dual_mul_f32 v151, v11, v55 :: v_dual_mul_f32 v150, v10, v54 ; c8c66f0b 97966d0a
	v_dual_mul_f32 v135, v135, v155 :: v_dual_mul_f32 v134, v134, v152 ; c8c73787 87873186
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v129, v91, v49 :: v_dual_mul_f32 v128, v90, v48 ; c8c6635b 8180615a
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[18:19], v[144:151] ; cc464090 1e422538
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v131, v93, v51 :: v_dual_mul_f32 v130, v92, v50 ; c8c6675d 8382655c
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	s_bitset0_b32 s41, 14                                       ; bea9108e
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_buffer_load_b32 s10, s[40:43], s10 offset:0x0             ; f4020294 14000000
	v_dual_mul_f32 v133, v95, v53 :: v_dual_mul_f32 v132, v94, v52 ; c8c66b5f 8584695e
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v135, v9, v55 :: v_dual_mul_f32 v134, v8, v54 ; c8c66f09 87866d08
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[16:17], v[128:135] ; cc464080 1e022138
	v_cvt_pk_f32_fp8_e32 v[48:49], v4                           ; 7e60dd04
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[22:23], v[144:151] ; cc464090 1e422d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[20:21], v[128:135] ; cc464080 1e02293c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[64:65], v[28:29], v[144:151] ; cc464090 1e423940
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[64:65], v[24:25], v[128:135] ; cc464080 1e023140
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[30:31], v[144:151] ; cc464090 1e423d44
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mul_f32 v153, v49, v109 :: v_dual_mul_f32 v152, v48, v108 ; c8c6db31 9998d930
	v_cvt_pk_f32_fp8_e32 v[48:49], v132                         ; 7e60dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[26:27], v[128:135] ; cc464080 1e023544
	v_dual_mul_f32 v155, v49, v111 :: v_dual_mul_f32 v154, v48, v110 ; c8c6df31 9b9add30
	v_cvt_pk_f32_fp8_e32 v[48:49], v5                           ; 7e60dd05
	v_cvt_pk_f32_fp8_e32 v[4:5], v133                           ; 7e08dd85
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[36:37], v[144:151] ; cc464090 1e424948
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[32:33], v[128:135] ; cc464080 1e024148
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v157, v49, v113 :: v_dual_mul_f32 v156, v48, v112 ; c8c6e331 9d9ce130
	v_dual_mul_f32 v159, v5, v115 :: v_dual_mul_f32 v158, v4, v114 ; c8c6e705 9f9ee504
	v_cvt_pk_f32_fp8_e32 v[4:5], v6                             ; 7e08dd06
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[76:77], v[38:39], v[144:151] ; cc464090 1e424d4c
	v_dual_mul_f32 v49, v5, v109 :: v_dual_mul_f32 v48, v4, v108 ; c8c6db05 3130d904
	v_cvt_pk_f32_fp8_e32 v[4:5], v134                           ; 7e08dd86
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[34:35], v[128:135] ; cc464080 1e02454c
	v_dual_mul_f32 v51, v5, v111 :: v_dual_mul_f32 v50, v4, v110 ; c8c6df05 3332dd04
	v_cvt_pk_f32_fp8_e32 v[4:5], v7                             ; 7e08dd07
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[80:81], v[14:15], v[144:151] ; cc464090 1e421d50
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[16:17], v[152:159] ; cc464098 1e62213a
	v_dual_mul_f32 v53, v5, v113 :: v_dual_mul_f32 v52, v4, v112 ; c8c6e305 3534e104
	v_cvt_pk_f32_fp8_e32 v[4:5], v135                           ; 7e08dd87
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[40:41], v[128:135] ; cc464080 1e025150
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[88:89], v[144:151] ; cc464090 1e42b154
	v_dual_mul_f32 v55, v5, v115 :: v_dual_mul_f32 v54, v4, v114 ; c8c6e705 3736e504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[58:59], v[18:19], v[48:55] ; cc464030 1cc2253a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[20:21], v[152:159] ; cc464098 1e62293e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[42:43], v[128:135] ; cc464080 1e025554
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[62:63], v[22:23], v[48:55] ; cc464030 1cc22d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[24:25], v[152:159] ; cc464098 1e623142
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[66:67], v[28:29], v[48:55] ; cc464030 1cc23942
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[70:71], v[26:27], v[152:159] ; cc464098 1e623546
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[118:119], v[8:9], 0 ; cc464038 1a021176
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[70:71], v[30:31], v[48:55] ; cc464030 1cc23d46
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[46:47], v[8:9], 0   ; cc464018 1a02112e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[32:33], v[152:159] ; cc464098 1e62414a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[8:9], 0   ; cc464010 1a02112c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[74:75], v[36:37], v[48:55] ; cc464030 1cc2494a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[78:79], v[34:35], v[152:159] ; cc464098 1e62454e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[78:79], v[38:39], v[48:55] ; cc464030 1cc24d4e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[116:117], v[8:9], 0 ; cc464020 1a021174
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[82:83], v[40:41], v[152:159] ; cc464098 1e625152
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[82:83], v[14:15], v[48:55] ; cc464030 1cc21d52
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[42:43], v[152:159] ; cc464098 1e625556
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[86:87], v[88:89], v[48:55] ; cc464030 1cc2b156
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[120:121], 0 ; cc464040 1a02f108
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[122:123], 0 ; cc464048 1a02f508
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[140:141], v[4:5], v[32:39] ; cc464020 1c82098c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[126:127], v[4:5], v[24:31] ; cc464018 1c62097e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[124:125], v[4:5], v[16:23] ; cc464010 1c42097c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[142:143], v[4:5], v[56:63] ; cc464038 1ce2098e
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[4:5], v[96:97], v[64:71] ; cc464040 1d02c104
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[4:5], v[98:99], v[72:79] ; cc464048 1d22c504
	v_dual_mul_f32 v163, v59, v59 :: v_dual_mul_f32 v160, v25, v25 ; c8c6773b a3a03319
	v_dual_mul_f32 v162, v27, v27 :: v_dual_mul_f32 v161, v57, v57 ; c8c6371b a2a07339
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_dual_fmac_f32 v163, v35, v35 :: v_dual_fmac_f32 v160, v17, v17 ; c8004723 a3a02311
	s_mov_b32 s19, 0x76543210                                   ; be9300ff 76543210
	v_dual_fmac_f32 v162, v19, v19 :: v_dual_fmac_f32 v161, v33, v33 ; c8002713 a2a04321
	s_mov_b32 s20, 0xfedcba98                                   ; be9400ff fedcba98
	v_dual_fmac_f32 v163, v39, v39 :: v_dual_fmac_f32 v160, v21, v21 ; c8004f27 a3a02b15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v23, v23 :: v_dual_fmac_f32 v161, v37, v37 ; c8002f17 a2a04b25
	v_dual_fmac_f32 v163, v63, v63 :: v_dual_fmac_f32 v160, v29, v29 ; c8007f3f a3a03b1d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v31, v31 :: v_dual_fmac_f32 v161, v61, v61 ; c8003f1f a2a07b3d
	v_dual_fmac_f32 v163, v34, v34 :: v_dual_fmac_f32 v160, v16, v16 ; c8004522 a3a02110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v32, v32 :: v_dual_fmac_f32 v162, v18, v18 ; c8004120 a1a22512
	v_dual_fmac_f32 v163, v58, v58 :: v_dual_fmac_f32 v160, v24, v24 ; c800753a a3a03118
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v56, v56 :: v_dual_fmac_f32 v162, v26, v26 ; c8007138 a1a2351a
	v_dual_fmac_f32 v163, v38, v38 :: v_dual_fmac_f32 v160, v20, v20 ; c8004d26 a3a02914
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v36, v36 :: v_dual_fmac_f32 v162, v22, v22 ; c8004924 a1a22d16
	v_dual_fmac_f32 v163, v62, v62 :: v_dual_fmac_f32 v160, v28, v28 ; c8007d3e a3a0391c
	v_lshl_add_u32 v167, v2, 5, v1                              ; d64600a7 04050b02
	v_lshl_add_u32 v2, v2, 6, s7                                ; d6460002 001d0d02
	v_dual_fmac_f32 v161, v60, v60 :: v_dual_fmac_f32 v162, v30, v30 ; c800793c a1a23d1e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
	v_fma_mixlo_f16 v164, 1.0, v160, v162                       ; cc2100a4 068b40f2
	v_fma_mixhi_f16 v164, 1.0, v161, v163                       ; cc2200a4 068f42f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_permlanex16_b32 v165, v164, s19, s20 op_sel:[1,1]         ; d65c18a5 005027a4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[165:166]            ; 1a034ba4
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v255                             ; 0a01ffa4
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00a6
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
	v_rsq_f32_e32 v166, v166                                    ; 7f4c5da6
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v166, s10, v166                               ; 114d4c0a
	v_dual_mul_f32 v17, v17, v166 :: v_dual_mul_f32 v16, v16, v166 ; c8c74d11 11114d10
	v_dual_mul_f32 v19, v19, v166 :: v_dual_mul_f32 v18, v18, v166 ; c8c74d13 13134d12
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v2, s[36:39], null offen         ; c405c07c 40804810 00000002
	buffer_load_b128 v[40:43], v2, s[36:39], null offen offset:16 ; c405c07c 40804828 00001002
(invalid instruction)                                        ; d58b08a4
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
	v_mul_f32_e32 v22, v22, v166                                ; 102d4d16
	v_dual_mul_f32 v21, v21, v166 :: v_dual_mul_f32 v20, v20, v166 ; c8c74d15 15154d14
	v_mul_f32_e32 v23, v23, v166                                ; 102f4d17
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_rsq_f32_e32 v164, v164                                    ; 7f485da4
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870125
	v_dual_mul_f32 v33, v33, v164 :: v_dual_mul_f32 v32, v32, v164 ; c8c74921 21214920
	v_dual_mul_f32 v35, v35, v164 :: v_dual_mul_f32 v34, v34, v164 ; c8c74923 23234922
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v2, s[36:39], null offen offset:4096 ; c405c07c 40804814 00100002
	buffer_load_b128 v[32:35], v2, s[36:39], null offen offset:4112 ; c405c07c 40804820 00101002
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mul_f32_e32 v24, v24, v166                                ; 10314d18
	v_dual_mul_f32 v26, v26, v166 :: v_dual_mul_f32 v25, v25, v166 ; c8c74d1a 1a194d19
	v_dual_mul_f32 v28, v28, v166 :: v_dual_mul_f32 v27, v27, v166 ; c8c74d1c 1c1b4d1b
	v_dual_mul_f32 v30, v30, v166 :: v_dual_mul_f32 v29, v29, v166 ; c8c74d1e 1e1d4d1d
	v_dual_mul_f32 v37, v37, v164 :: v_dual_mul_f32 v36, v36, v164 ; c8c74925 25254924
	v_dual_mul_f32 v39, v39, v164 :: v_dual_mul_f32 v38, v38, v164 ; c8c74927 27274926
	v_dual_mul_f32 v56, v56, v164 :: v_dual_mul_f32 v31, v31, v166 ; c8c74938 381f4d1f
	v_dual_mul_f32 v58, v58, v164 :: v_dual_mul_f32 v57, v57, v164 ; c8c7493a 3a394939
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v2, s[36:39], null offen offset:64 ; c405c07c 4080481c 00004002
	buffer_load_b128 v[36:39], v2, s[36:39], null offen offset:80 ; c405c07c 40804824 00005002
	v_dual_mul_f32 v60, v60, v164 :: v_dual_mul_f32 v59, v59, v164 ; c8c7493c 3c3b493b
	v_dual_mul_f32 v62, v62, v164 :: v_dual_mul_f32 v61, v61, v164 ; c8c7493e 3e3d493d
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mul_f32_e32 v63, v63, v164                                ; 107f493f
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v167, v[8:9], v[26:27] offset1:2         ; d9380200 001a08a7
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[10:11], 0 ; cc464038 1a02152c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[10:11], 0 ; cc464040 1a02152e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v2, s[36:39], null offen offset:4160 ; c405c07c 4080482c 00104002
	buffer_load_b128 v[100:103], v2, s[36:39], null offen offset:4176 ; c405c07c 40804864 00105002
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[116:117], v[10:11], 0 ; cc464048 1a021574
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[118:119], v[10:11], 0 ; cc464050 1a021576
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[10:11], v[120:121], 0 ; cc464058 1a02f10a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[122:123], 0 ; cc464068 1a02f50a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[6:7], v[96:97], v[88:95] ; cc464058 1d62c106
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[124:125], v[6:7], v[56:63] ; cc464038 1ce20d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[6:7], v[98:99], v[104:111] ; cc464068 1da2c506
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[96:99], v2, s[36:39], null offen offset:128 ; c405c07c 40804860 00008002
	buffer_load_b128 v[112:115], v2, s[36:39], null offen offset:144 ; c405c07c 40804870 00009002
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[126:127], v[6:7], v[64:71] ; cc464040 1d020d7e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[140:141], v[6:7], v[72:79] ; cc464048 1d220d8c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[142:143], v[6:7], v[80:87] ; cc464050 1d420d8e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v171, v83, v83 :: v_dual_mul_f32 v168, v65, v65 ; c8c6a753 aba88341
	v_dual_mul_f32 v170, v67, v67 :: v_dual_mul_f32 v169, v81, v81 ; c8c68743 aaa8a351
	v_dual_fmac_f32 v171, v75, v75 :: v_dual_fmac_f32 v168, v57, v57 ; c800974b aba87339
	v_dual_fmac_f32 v170, v59, v59 :: v_dual_fmac_f32 v169, v73, v73 ; c800773b aaa89349
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmac_f32 v171, v79, v79 :: v_dual_fmac_f32 v168, v61, v61 ; c8009f4f aba87b3d
	v_dual_fmac_f32 v170, v63, v63 :: v_dual_fmac_f32 v169, v77, v77 ; c8007f3f aaa89b4d
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[116:119], v2, s[36:39], null offen offset:4224 ; c405c07c 40804874 00108002
	buffer_load_b128 v[120:123], v2, s[36:39], null offen offset:4240 ; c405c07c 40804878 00109002
	v_dual_fmac_f32 v171, v87, v87 :: v_dual_fmac_f32 v168, v69, v69 ; c800af57 aba88b45
	v_dual_fmac_f32 v170, v71, v71 :: v_dual_fmac_f32 v169, v85, v85 ; c8008f47 aaa8ab55
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_fmac_f32_e32 v171, v74, v74                               ; 5756954a
	v_fmac_f32_e32 v168, v56, v56                               ; 57507138
	v_dual_fmac_f32 v169, v72, v72 :: v_dual_fmac_f32 v170, v58, v58 ; c8009148 a9aa753a
	v_dual_fmac_f32 v171, v82, v82 :: v_dual_fmac_f32 v168, v64, v64 ; c800a552 aba88140
	v_dual_fmac_f32 v169, v80, v80 :: v_dual_fmac_f32 v170, v66, v66 ; c800a150 a9aa8542
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v171, v78, v78 :: v_dual_fmac_f32 v168, v60, v60 ; c8009d4e aba8793c
	v_dual_fmac_f32 v169, v76, v76 :: v_dual_fmac_f32 v170, v62, v62 ; c800994c a9aa7d3e
	v_dual_fmac_f32 v171, v86, v86 :: v_dual_fmac_f32 v168, v68, v68 ; c800ad56 aba88944
	v_dual_fmac_f32 v169, v84, v84 :: v_dual_fmac_f32 v170, v70, v70 ; c800a954 a9aa8d46
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v172, 1.0, v168, v170                       ; cc2100ac 06ab50f2
	v_fma_mixhi_f16 v172, 1.0, v169, v171                       ; cc2200ac 06af52f2
	v_permlanex16_b32 v173, v172, s19, s20 op_sel:[1,1]         ; d65c18ad 005027ac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[173:174]            ; 1a035bac
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v255                             ; 0a01ffac
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
(invalid instruction)                                        ; d58b08ac
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	v_rsq_f32_e32 v174, v174                                    ; 7f5c5dae
	v_rsq_f32_e32 v172, v172                                    ; 7f585dac
	s_delay_alu instid0(TRANS32_DEP_2)                          ; bf870006
	v_mul_f32_e32 v174, s10, v174                               ; 115d5c0a
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)    ; bf870085
	v_dual_mul_f32 v72, v72, v172 :: v_dual_mul_f32 v63, v63, v174 ; c8c75948 483f5d3f
	v_dual_mul_f32 v60, v60, v174 :: v_dual_mul_f32 v59, v59, v174 ; c8c75d3c 3c3b5d3b
	v_mul_f32_e32 v56, v56, v174                                ; 10715d38
	v_dual_mul_f32 v58, v58, v174 :: v_dual_mul_f32 v57, v57, v174 ; c8c75d3a 3a395d39
	v_dual_mul_f32 v62, v62, v174 :: v_dual_mul_f32 v61, v61, v174 ; c8c75d3e 3e3d5d3d
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v2, s[36:39], null offen offset:192 ; c405c07c 40804838 0000c002
	buffer_load_b128 v[60:63], v2, s[36:39], null offen offset:208 ; c405c07c 4080483c 0000d002
	v_dual_mul_f32 v79, v79, v172 :: v_dual_mul_f32 v78, v78, v172 ; c8c7594f 4f4f594e
	v_mul_f32_e32 v75, v75, v172                                ; 1097594b
	v_dual_mul_f32 v77, v77, v172 :: v_dual_mul_f32 v76, v76, v172 ; c8c7594d 4d4d594c
	v_dual_mul_f32 v74, v74, v172 :: v_dual_mul_f32 v73, v73, v172 ; c8c7594a 4a495949
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v2, s[36:39], null offen offset:4288 ; c405c07c 40804848 0010c002
	buffer_load_b128 v[76:79], v2, s[36:39], null offen offset:4304 ; c405c07c 4080484c 0010d002
	v_dual_mul_f32 v65, v65, v174 :: v_dual_mul_f32 v64, v64, v174 ; c8c75d41 41415d40
	v_dual_mul_f32 v67, v67, v174 :: v_dual_mul_f32 v66, v66, v174 ; c8c75d43 43435d42
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v69, v69, v174 :: v_dual_mul_f32 v68, v68, v174 ; c8c75d45 45455d44
	v_dual_mul_f32 v71, v71, v174 :: v_dual_mul_f32 v70, v70, v174 ; c8c75d47 47475d46
	v_dual_mul_f32 v81, v81, v172 :: v_dual_mul_f32 v80, v80, v172 ; c8c75951 51515950
	v_dual_mul_f32 v83, v83, v172 :: v_dual_mul_f32 v82, v82, v172 ; c8c75953 53535952
	v_dual_mul_f32 v85, v85, v172 :: v_dual_mul_f32 v84, v84, v172 ; c8c75955 55555954
	v_dual_mul_f32 v87, v87, v172 :: v_dual_mul_f32 v86, v86, v172 ; c8c75957 57575956
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v167, v[10:11], v[66:67] offset0:64 offset1:66 ; d9384240 00420aa7
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0              ; ca100080 43420080
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v167, v[66:67], v[66:67] offset0:128 offset1:130 ; d9388280 004242a7
	ds_store_2addr_b64 v167, v[66:67], v[66:67] offset0:192 offset1:194 ; d938c2c0 004242a7
	ds_load_b64 v[66:67], v167                                  ; d9d80000 420000a7
	ds_load_b64 v[68:69], v167 offset:16                        ; d9d80010 440000a7
	s_mov_b32 s21, 0x3d380000                                   ; be9500ff 3d380000
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[66:67], v[6:7], 0   ; cc464058 1a020d42
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[66:67], v[4:5], 0   ; cc464050 1a020942
	s_wait_dscnt 0x0                                            ; bfc60000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[24:25], v[80:87] ; cc464050 1d423144
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_mixlo_f16 v175, s21, v80, v16                         ; cc2100af 0442a015
	v_fma_mixhi_f16 v175, s21, v81, v17                         ; cc2200af 0446a215
	ds_load_b64 v[16:17], v167 offset:512                       ; d9d80200 100000a7
	ds_load_b64 v[66:67], v167 offset:528                       ; d9d80210 420000a7
	s_movk_i32 s22, 0x3c20                                      ; b0163c20
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[64:65], v[88:95] ; cc464058 1d628144
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v177, s21, v84, v40                         ; cc2100b1 04a2a815
	v_fma_mixlo_f16 v178, s21, v86, v42                         ; cc2100b2 04aaac15
	v_fma_mixhi_f16 v177, s21, v85, v41                         ; cc2200b1 04a6aa15
	v_fma_mixhi_f16 v178, s21, v87, v43                         ; cc2200b2 04aeae15
	v_fma_mixlo_f16 v176, s21, v82, v18                         ; cc2100b0 044aa415
	v_fma_mixhi_f16 v176, s21, v83, v19                         ; cc2200b0 044ea615
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v22                              ; 0a002daf
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v22                              ; 0a002db1
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v22                              ; 0a002db2
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[4:5], 0   ; cc464050 1a020910
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v22                              ; 0a002db0
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v181, s21, v92, v32                         ; cc2100b5 0482b815
	v_fma_mixhi_f16 v181, s21, v93, v33                         ; cc2200b5 0486ba15
	v_fma_mixlo_f16 v182, s21, v94, v34                         ; cc2100b6 048abc15
	v_fma_mixlo_f16 v180, s21, v90, v22                         ; cc2100b4 045ab415
	v_fma_mixhi_f16 v180, s21, v91, v23                         ; cc2200b4 045eb615
	v_fma_mixlo_f16 v179, s21, v88, v20                         ; cc2100b3 0452b015
	v_fma_mixhi_f16 v179, s21, v89, v21                         ; cc2200b3 0456b215
	v_fma_mixhi_f16 v182, s21, v95, v35                         ; cc2200b6 048ebe15
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[6:7], 0   ; cc464058 1a020d10
	ds_load_b64 v[16:17], v167 offset:1024                      ; d9d80400 100000a7
	ds_load_b64 v[18:19], v167 offset:1040                      ; d9d80410 120000a7
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v22                              ; 0a002db5
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v22                              ; 0a002db4
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[66:67], v[24:25], v[80:87] ; cc464050 1d423142
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v22                              ; 0a002db3
(invalid instruction)                                        ; cc1c00b6
	v_subrev_f32_e32 v0, v182, v22                              ; 0a002db6
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[66:67], v[64:65], v[88:95] ; cc464058 1d628142
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v184, s21, v82, v30                         ; cc2100b8 047aa415
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v186, s21, v86, v38                         ; cc2100ba 049aac15
	v_fma_mixhi_f16 v186, s21, v87, v39                         ; cc2200ba 049eae15
	v_fma_mixhi_f16 v184, s21, v83, v31                         ; cc2200b8 047ea615
	v_fma_mixlo_f16 v183, s21, v80, v28                         ; cc2100b7 0472a015
	v_fma_mixhi_f16 v183, s21, v81, v29                         ; cc2200b7 0476a215
	v_fma_mixlo_f16 v185, s21, v84, v36                         ; cc2100b9 0492a815
	v_fma_mixhi_f16 v185, s21, v85, v37                         ; cc2200b9 0496aa15
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v22                              ; 0a002dba
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v22                              ; 0a002db8
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[4:5], 0   ; cc464020 1a020910
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v190, s21, v94, v102                        ; cc2100be 059abc15
	v_fma_mixlo_f16 v189, s21, v92, v100                        ; cc2100bd 0592b815
	v_fma_mixlo_f16 v187, s21, v88, v44                         ; cc2100bb 04b2b015
	v_fma_mixhi_f16 v187, s21, v89, v45                         ; cc2200bb 04b6b215
	v_fma_mixlo_f16 v188, s21, v90, v46                         ; cc2100bc 04bab415
	v_fma_mixhi_f16 v188, s21, v91, v47                         ; cc2200bc 04beb615
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[6:7], 0   ; cc464028 1a020d10
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[24:25], v[32:39] ; cc464020 1c823112
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[64:65], v[40:47] ; cc464028 1ca28112
	ds_load_b64 v[16:17], v167 offset:1536                      ; d9d80600 100000a7
	ds_load_b64 v[18:19], v167 offset:1552                      ; d9d80610 120000a7
	v_fma_mixhi_f16 v189, s21, v93, v101                        ; cc2200bd 0596ba15
	v_fma_mixhi_f16 v190, s21, v95, v103                        ; cc2200be 059ebe15
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v22                              ; 0a002db7
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v22                              ; 0a002db9
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v22                              ; 0a002dbb
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v22                              ; 0a002dbc
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v191, s21, v32, v96                         ; cc2100bf 05824015
	v_fma_mixhi_f16 v191, s21, v33, v97                         ; cc2200bf 05864215
	v_fma_mixlo_f16 v2, s21, v34, v98                           ; cc210002 058a4415
	v_fma_mixhi_f16 v2, s21, v35, v99                           ; cc220002 058e4615
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v13, s21, v36, v112                         ; cc21000d 05c24815
	v_fma_mixhi_f16 v13, s21, v37, v113                         ; cc22000d 05c64a15
	v_fma_mixlo_f16 v20, s21, v38, v114                         ; cc210014 05ca4c15
	v_fma_mixhi_f16 v20, s21, v39, v115                         ; cc220014 05ce4e15
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v22                              ; 0a002dbd
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v22                              ; 0a002dbe
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v22, s21, v42, v118                         ; cc210016 05da5415
	v_fma_mixhi_f16 v22, s21, v43, v119                         ; cc220016 05de5615
	v_fma_mixlo_f16 v21, s21, v40, v116                         ; cc210015 05d25015
	v_fma_mixhi_f16 v21, s21, v41, v117                         ; cc220015 05d65215
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v23, s21, v44, v120                         ; cc210017 05e25815
	v_fma_mixhi_f16 v23, s21, v45, v121                         ; cc220017 05e65a15
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v22                              ; 0a002dbf
	v_fma_mixlo_f16 v28, s21, v46, v122                         ; cc21001c 05ea5c15
(invalid instruction)                                        ; cc1c0002
	v_subrev_f32_e32 v0, v2, v22                                ; 0a002d02
	v_fma_mixhi_f16 v28, s21, v47, v123                         ; cc22001c 05ee5e15
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v22                               ; 0a002d0d
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v22                               ; 0a002d14
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[4:5], 0   ; cc464020 1a020910
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[6:7], 0   ; cc464028 1a020d10
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v22                               ; 0a002d16
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v22                               ; 0a002d15
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v22                               ; 0a002d17
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v22                               ; 0a002d1c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[24:25], v[32:39] ; cc464020 1c823112
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[64:65], v[40:47] ; cc464028 1ca28112
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v29, s21, v32, v56                          ; cc21001d 04e24015
	v_fma_mixlo_f16 v30, s21, v34, v58                          ; cc21001e 04ea4415
	v_fma_mixhi_f16 v30, s21, v35, v59                          ; cc22001e 04ee4615
	v_fma_mixhi_f16 v29, s21, v33, v57                          ; cc22001d 04e64215
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v32, s21, v38, v62                          ; cc210020 04fa4c15
	v_fma_mixlo_f16 v31, s21, v36, v60                          ; cc21001f 04f24815
	v_fma_mixhi_f16 v31, s21, v37, v61                          ; cc22001f 04f64a15
	v_fma_mixhi_f16 v32, s21, v39, v63                          ; cc220020 04fe4e15
(invalid instruction)                                        ; cc1c001e
	v_subrev_f32_e32 v0, v30, v22                               ; 0a002d1e
(invalid instruction)                                        ; cc1c001d
	v_subrev_f32_e32 v0, v29, v22                               ; 0a002d1d
	s_mov_b32 s23, 0x7ff88000                                   ; be9700ff 7ff88000
(invalid instruction)                                        ; cc1c001f
	v_subrev_f32_e32 v0, v31, v22                               ; 0a002d1f
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v22                               ; 0a002d20
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v175, v175, 5, s23                           ; d64600af 005d0baf
	v_lshl_add_u32 v183, v183, 5, s23                           ; d64600b7 005d0bb7
	v_lshl_add_u32 v191, v191, 5, s23                           ; d64600bf 005d0bbf
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v34, s21, v42, v74                          ; cc210022 052a5415
	v_fma_mixhi_f16 v34, s21, v43, v75                          ; cc220022 052e5615
	v_fma_mixlo_f16 v33, s21, v40, v72                          ; cc210021 05225015
	v_fma_mixhi_f16 v33, s21, v41, v73                          ; cc220021 05265215
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v35, s21, v44, v76                          ; cc210023 05325815
	v_fma_mixhi_f16 v35, s21, v45, v77                          ; cc220023 05365a15
	v_fma_mixlo_f16 v36, s21, v46, v78                          ; cc210024 053a5c15
	v_fma_mixhi_f16 v36, s21, v47, v79                          ; cc220024 053e5e15
	v_lshl_add_u32 v29, v29, 5, s23                             ; d646001d 005d0b1d
	v_lshl_add_u32 v176, v176, 5, s23                           ; d64600b0 005d0bb0
	v_lshl_add_u32 v184, v184, 5, s23                           ; d64600b8 005d0bb8
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[175:176], v[183:184]            ; 1a036faf
	v_lshl_add_u32 v2, v2, 5, s23                               ; d6460002 005d0b02
	v_lshl_add_u32 v30, v30, 5, s23                             ; d646001e 005d0b1e
(invalid instruction)                                        ; cc1c0022
	v_subrev_f32_e32 v0, v34, v22                               ; 0a002d22
	v_lshl_add_u32 v177, v177, 5, s23                           ; d64600b1 005d0bb1
(invalid instruction)                                        ; cc1c0021
	v_subrev_f32_e32 v0, v33, v22                               ; 0a002d21
	v_lshl_add_u32 v185, v185, 5, s23                           ; d64600b9 005d0bb9
	v_lshl_add_u32 v13, v13, 5, s23                             ; d646000d 005d0b0d
(invalid instruction)                                        ; cc1c0023
	v_subrev_f32_e32 v0, v35, v22                               ; 0a002d23
	v_lshl_add_u32 v31, v31, 5, s23                             ; d646001f 005d0b1f
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v22                               ; 0a002d24
	v_lshl_add_u32 v178, v178, 5, s23                           ; d64600b2 005d0bb2
	v_add_lshl_u32 v0, s9, v0, 2                                ; d6470000 020a0009
	buffer_load_b128 v[4:7], v0, s[36:39], null offen           ; c405c07c 40804804 00000000
	v_lshl_add_u32 v186, v186, 5, s23                           ; d64600ba 005d0bba
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[176:177], v[184:185]            ; 1a0371b0
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[191:192]              ; 1a037f25
	v_lshl_add_u32 v20, v20, 5, s23                             ; d6460014 005d0b14
	buffer_load_b128 v[16:19], v0, s[36:39], null offen offset:16 ; c405c07c 40804810 00001000
	v_lshl_add_u32 v32, v32, 5, s23                             ; d6460020 005d0b20
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[177:178], v[185:186]            ; 1a0373b1
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[178:179], v[186:187]            ; 1a0375b2
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[2:3]                  ; 1a020526
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[29:30]                ; 1a023b25
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[13:14]                ; 1a021b27
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[40:41], v[20:21]                ; 1a022928
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[30:31]                ; 1a023d26
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[31:32]                ; 1a023f27
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[40:41], v[32:33]                ; 1a024128
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[38:39]                ; 1a024d25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[39:40]                ; 1a024f25
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v12, s6, v12, 2                              ; d647000c 020a1806
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[40:41]                ; 1a025125
	buffer_load_b64 v[38:39], v12, s[44:47], null offen         ; c405407c 40805826 0000000c
	v_permlanex16_b32 v41, v37, s19, s20 op_sel:[1,1]           ; d65c1829 00502725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[41:42]                ; 1a025325
	v_add_f16_e32 v42, v37, v165/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64554b25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_max_num_f16_e32 v42, 0x400, v42                           ; 625454ff 00000400
	buffer_load_b64 v[40:41], v12, s[44:47], null offen offset:512 ; c405407c 40805828 0002000c
	v_cvt_f32_f16_e32 v43, v42                                  ; 7e56172a
	v_rcp_f32_e32 v43, v43                                      ; 7e56552b
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v44, v175, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002c 8a0257af
	v_fma_mix_f32 v45, v176, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002d 8a0257b0
	v_fma_mix_f32 v175, v175, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a0257af
	v_fma_mix_f32 v56, v183, v43, neg(0) op_sel_hi:[1,0,0]      ; cc200038 8a0257b7
	v_fma_mix_f32 v46, v177, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002e 8a0257b1
	v_fma_mix_f32 v57, v184, v43, neg(0) op_sel_hi:[1,0,0]      ; cc200039 8a0257b8
	v_fma_mix_f32 v177, v177, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a0257b1
	v_fma_mix_f32 v183, v183, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a0257b7
	v_fma_mix_f32 v176, v176, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a0257b0
	v_fma_mix_f32 v47, v178, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20002f 8a0257b2
	v_fma_mix_f32 v178, v178, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a0257b2
	v_fma_mix_f32 v184, v184, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a0257b8
	v_fma_mix_f32 v58, v185, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003a 8a0257b9
	v_fma_mix_f32 v185, v185, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a0257b9
	v_fma_mix_f32 v59, v186, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003b 8a0257ba
	v_fma_mix_f32 v186, v186, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a0257ba
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v44, v175, vcc_lo                     ; 02035f2c
	v_fma_mix_f32 v60, v191, v43, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a0257bf
	v_fma_mix_f32 v191, v191, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a0257bf
	v_fma_mix_f32 v61, v2, v43, neg(0) op_sel_hi:[1,0,0]        ; cc20003d 8a025702
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v46, v177, vcc_lo                     ; 0203632e
	v_fma_mix_f32 v2, v2, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200802 8a025702
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v56, v183, vcc_lo                     ; 02036f38
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v45, v176, vcc_lo                     ; 0203612d
	v_fma_mix_f32 v62, v13, v43, neg(0) op_sel_hi:[1,0,0]       ; cc20003e 8a02570d
	v_fma_mix_f32 v13, v13, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080d 8a02570d
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v47, v178, vcc_lo                     ; 0203652f
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v57, v184, vcc_lo                     ; 02037139
	v_fma_mix_f32 v63, v20, v43, neg(0) op_sel_hi:[1,0,0]       ; cc20003f 8a025714
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v58, v185, vcc_lo                     ; 0203733a
	v_fma_mix_f32 v20, v20, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a025714
	v_fma_mix_f32 v64, v29, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200040 8a02571d
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v59, v186, vcc_lo                     ; 0203753b
	v_fma_mix_f32 v29, v29, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081d 8a02571d
	v_fma_mix_f32 v65, v30, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200041 8a02571e
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v60, v191, vcc_lo                     ; 02037f3c
	v_fma_mix_f32 v30, v30, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081e 8a02571e
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v61, v2, vcc_lo                       ; 0202053d
	v_fma_mix_f32 v66, v31, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200042 8a02571f
	v_fma_mix_f32 v31, v31, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081f 8a02571f
	v_fma_mix_f32 v67, v32, v43, neg(0) op_sel_hi:[1,0,0]       ; cc200043 8a025720
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v62, v13, vcc_lo                      ; 02021b3e
	v_fma_mix_f32 v32, v32, v43, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a025720
	v_lshl_add_u32 v179, v179, 5, s23                           ; d64600b3 005d0bb3
	v_lshl_add_u32 v187, v187, 5, s23                           ; d64600bb 005d0bbb
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v63, v20, vcc_lo                      ; 0202293f
	v_lshl_add_u32 v21, v21, 5, s23                             ; d6460015 005d0b15
	v_lshl_add_u32 v33, v33, 5, s23                             ; d6460021 005d0b21
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v64, v29, vcc_lo                      ; 02023b40
	v_lshl_add_u32 v180, v180, 5, s23                           ; d64600b4 005d0bb4
	v_lshl_add_u32 v188, v188, 5, s23                           ; d64600bc 005d0bbc
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v65, v30, vcc_lo                      ; 02023d41
	v_lshl_add_u32 v22, v22, 5, s23                             ; d6460016 005d0b16
	v_lshl_add_u32 v34, v34, 5, s23                             ; d6460022 005d0b22
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v66, v31, vcc_lo                      ; 02023f42
	v_lshl_add_u32 v181, v181, 5, s23                           ; d64600b5 005d0bb5
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v67, v32, vcc_lo                      ; 02024143
	v_lshl_add_u32 v189, v189, 5, s23                           ; d64600bd 005d0bbd
	v_lshl_add_u32 v23, v23, 5, s23                             ; d6460017 005d0b17
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[179:180], v[187:188]            ; 1a0377b3
	v_lshl_add_u32 v35, v35, 5, s23                             ; d6460023 005d0b23
	v_lshl_add_u32 v182, v182, 5, s23                           ; d64600b6 005d0bb6
	v_lshl_add_u32 v190, v190, 5, s23                           ; d64600be 005d0bbe
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[180:181], v[188:189]            ; 1a0379b4
	v_lshl_add_u32 v28, v28, 5, s23                             ; d646001c 005d0b1c
	v_lshl_add_u32 v36, v36, 5, s23                             ; d6460024 005d0b24
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[181:182], v[189:190]            ; 1a037bb5
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[21:22]                ; 1a022b44
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[182:183], v[190:191]            ; 1a037db6
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[22:23]                ; 1a022d45
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[23:24]                ; 1a022f46
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[33:34]                ; 1a024344
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[28:29]                ; 1a023947
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[34:35]                ; 1a024545
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[35:36]                ; 1a024746
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[36:37]                ; 1a024947
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[69:70]                ; 1a028b44
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[70:71]                ; 1a028d44
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[71:72]                ; 1a028f44
	v_permlanex16_b32 v72, v68, s19, s20 op_sel:[1,1]           ; d65c1848 00502744
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[68:69], v[72:73]                ; 1a029144
	v_add_f16_e32 v73, v68, v196/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64938944
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v73, 0x400, v73                           ; 629292ff 00000400
	v_cvt_f32_f16_e32 v74, v73                                  ; 7e941749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v74, v74                                      ; 7e94554a
	v_fma_mix_f32 v79, v187, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004f 8a0295bb
	v_fma_mix_f32 v76, v180, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004c 8a0295b4
	v_fma_mix_f32 v180, v180, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a0295b4
	v_fma_mix_f32 v77, v181, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004d 8a0295b5
	v_fma_mix_f32 v181, v181, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a0295b5
	v_fma_mix_f32 v75, v179, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004b 8a0295b3
	v_fma_mix_f32 v179, v179, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a0295b3
	v_fma_mix_f32 v187, v187, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a0295bb
	v_fma_mix_f32 v78, v182, v74, neg(0) op_sel_hi:[1,0,0]      ; cc20004e 8a0295b6
	v_fma_mix_f32 v182, v182, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a0295b6
	v_fma_mix_f32 v80, v188, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200050 8a0295bc
	v_fma_mix_f32 v188, v188, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a0295bc
	v_fma_mix_f32 v81, v189, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200051 8a0295bd
	v_fma_mix_f32 v189, v189, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a0295bd
	v_fma_mix_f32 v82, v190, v74, neg(0) op_sel_hi:[1,0,0]      ; cc200052 8a0295be
	v_fma_mix_f32 v190, v190, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a0295be
	v_fma_mix_f32 v83, v21, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200053 8a029515
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v77, v181, vcc_lo                     ; 02036b4d
	v_fma_mix_f32 v21, v21, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a029515
	v_fma_mix_f32 v84, v22, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200054 8a029516
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v75, v179, vcc_lo                     ; 0203674b
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v76, v180, vcc_lo                     ; 0203694c
	v_fma_mix_f32 v22, v22, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a029516
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v79, v187, vcc_lo                     ; 0203774f
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v78, v182, vcc_lo                     ; 02036d4e
	v_fma_mix_f32 v85, v23, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200055 8a029517
	v_fma_mix_f32 v23, v23, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a029517
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v80, v188, vcc_lo                     ; 02037950
	v_fma_mix_f32 v86, v28, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200056 8a02951c
	v_fma_mix_f32 v28, v28, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a02951c
	v_fma_mix_f32 v87, v33, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200057 8a029521
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v81, v189, vcc_lo                     ; 02037b51
	v_fma_mix_f32 v33, v33, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200821 8a029521
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v82, v190, vcc_lo                     ; 02037d52
	v_fma_mix_f32 v88, v34, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200058 8a029522
	v_fma_mix_f32 v34, v34, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200822 8a029522
	v_fma_mix_f32 v89, v35, v74, neg(0) op_sel_hi:[1,0,0]       ; cc200059 8a029523
	v_fma_mix_f32 v35, v35, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200823 8a029523
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v83, v21, vcc_lo                      ; 02022b53
	v_fma_mix_f32 v90, v36, v74, neg(0) op_sel_hi:[1,0,0]       ; cc20005a 8a029524
	v_fma_mix_f32 v36, v36, v74, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200824 8a029524
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[24:25], 0 ; cc464040 1a02310e
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v84, v22, vcc_lo                      ; 02022d54
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[30:31], 0 ; cc464048 1a023d0e
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, 0              ; ca100080 0f0e0080
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v85, v23, vcc_lo                      ; 02022f55
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v86, v28, vcc_lo                      ; 02023956
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v87, v33, vcc_lo                      ; 02024357
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v88, v34, vcc_lo                      ; 02024558
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v89, v35, vcc_lo                      ; 02024759
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v90, v36, vcc_lo                      ; 0202495a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[26:27], v[44:45], v[64:71] ; cc464040 1d02591a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[42:43], v[72:79] ; cc464048 1d22551a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[46:47], v[64:71] ; cc464040 1d025d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[20:21], v[72:79] ; cc464048 1d22290e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v59, v131, v7 :: v_dual_mul_f32 v58, v130, v6 ; c8c60f83 3b3a0d82
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v63, v135, v19 :: v_dual_mul_f32 v62, v134, v18 ; c8c62787 3f3e2586
	v_dual_mul_f32 v61, v133, v17 :: v_dual_mul_f32 v60, v132, v16 ; c8c62385 3d3c2184
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[56:57], v[64:71] ; cc464040 1d02710e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[22:23], v[72:79] ; cc464048 1d222d0e
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[24:25], 0   ; cc464040 1a023108
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[30:31], 0   ; cc464048 1a023d08
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[10:11], v[44:45], v[64:71] ; cc464040 1d02590a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[10:11], v[42:43], v[72:79] ; cc464048 1d22550a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[46:47], v[64:71] ; cc464040 1d025d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[20:21], v[72:79] ; cc464048 1d22290e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[56:57], v[64:71] ; cc464040 1d02710e
	v_dual_mul_f32 v57, v129, v5 :: v_dual_mul_f32 v56, v128, v4 ; c8c60b81 39380980
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[22:23], v[72:79] ; cc464048 1d222d0e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[38:39], v[26:27], v[56:63] ; cc464038 1ce23526
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_dual_mul_f32 v69, v149, v17 :: v_dual_mul_f32 v68, v148, v16 ; c8c62395 45442194
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_dual_mul_f32 v71, v151, v19 :: v_dual_mul_f32 v70, v150, v18 ; c8c62797 47462596
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_dual_mul_f32 v65, v145, v5 :: v_dual_mul_f32 v64, v144, v4 ; c8c60b91 41400990
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v67, v147, v7 :: v_dual_mul_f32 v66, v146, v6 ; c8c60f93 43420d92
	s_cmp_lg_i32 s27, 0                                         ; bf01801b
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[38:39], v[28:29], v[64:71] ; cc464040 1d023926
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[40:41], v[8:9], v[56:63] ; cc464038 1ce21128
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[40:41], v[10:11], v[64:71] ; cc464040 1d021528
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_cbranch_scc1 BB38                                         ; bfa20007
BB36:
	v_add3_u32 v2, v3, s2, s13                                  ; d6550002 00340503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[4:5], v2, s[32:35], null offen           ; c406c07c 40804004 00000002
BB38:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_lg_i32 s28, 0                                         ; bf01801c
	s_cbranch_scc1 BB41                                         ; bfa20007
BB39:
	v_add3_u32 v2, v3, s2, s14                                  ; d6550002 00380503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[4:5], v2, s[32:35], null offen           ; c406c07c 40804004 00000002
BB41:
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[4:7], v0, s[36:39], null offen offset:64 ; c405c07c 40804804 00004000
	buffer_load_b128 v[16:19], v0, s[36:39], null offen offset:80 ; c405c07c 40804810 00005000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[14:15], v12, s[44:47], null offen offset:8 ; c405407c 4080580e 0000080c
	buffer_load_b64 v[12:13], v12, s[44:47], null offen offset:520 ; c405407c 4080580c 0002080c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v33, v153, v5 :: v_dual_mul_f32 v32, v152, v4 ; c8c60b99 21200998
	v_dual_mul_f32 v35, v155, v7 :: v_dual_mul_f32 v34, v154, v6 ; c8c60f9b 23220d9a
	v_dual_mul_f32 v41, v49, v5 :: v_dual_mul_f32 v40, v48, v4  ; c8c60b31 29280930
	v_dual_mul_f32 v43, v51, v7 :: v_dual_mul_f32 v42, v50, v6  ; c8c60f33 2b2a0d32
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v37, v157, v17 :: v_dual_mul_f32 v36, v156, v16 ; c8c6239d 2524219c
	v_dual_mul_f32 v39, v159, v19 :: v_dual_mul_f32 v38, v158, v18 ; c8c6279f 2726259e
	v_dual_mul_f32 v45, v53, v17 :: v_dual_mul_f32 v44, v52, v16 ; c8c62335 2d2c2134
	v_dual_mul_f32 v47, v55, v19 :: v_dual_mul_f32 v46, v54, v18 ; c8c62737 2f2e2536
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[14:15], v[26:27], v[32:39] ; cc464020 1c82350e
	s_mov_b32 s0, vcc_lo                                        ; be80006a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[14:15], v[28:29], v[40:47] ; cc464028 1ca2390e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[12:13], v[8:9], v[32:39] ; cc464020 1c82110c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[10:11], v[40:47] ; cc464028 1ca2150c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_cbranch_scc1 BB44                                         ; bfa20009
BB42:
	s_add_co_u32 s1, s2, 0x100                                  ; 8001ff02 00000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	v_add3_u32 v0, v3, s1, s13                                  ; d6550000 00340303
	v_add_nc_u32_e32 v0, v0, v1                                 ; 4a000300
	buffer_store_b64 v[4:5], v0, s[32:35], null offen           ; c406c07c 40804004 00000000
BB44:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB78                                         ; bfa21672
BB45:
	s_addk_co_i32 s2, 0x100                                     ; b7820100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v3, v3, s2, s14                                  ; d6550003 00380503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	buffer_store_b64 v[4:5], v3, s[32:35], null offen           ; c406c07c 40804004 00000003
	s_branch BB78                                               ; bfa01668
BB48:
	s_cmp_eq_i32 s17, 10                                        ; bf008a11
	s_cbranch_scc0 BB62                                         ; bfa10b2e
BB49:
	s_mov_b32 s13, s1                                           ; be8d0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[0:1], 0x0                           ; f4004400 f8000000
	s_load_b256 s[48:55], s[0:1], 0x30                          ; f4006c00 f8000030
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_max_i32 s14, s14, 0                                       ; 8a0e800e
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s14, s14, s12                                     ; 890e0c0e
	s_max_i32 s20, s20, 0                                       ; 8a148014
	s_add_co_u32 s15, s11, -1                                   ; 800fc10b
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	s_mul_i32 s14, s14, s11                                     ; 960e0b0e
	s_min_i32 s20, s20, s15                                     ; 89140f14
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_add_co_u32 s14, s14, s20                                  ; 800e140e
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_lshl_b32 s14, s14, 9                                      ; 840e890e
	s_add_co_u32 s21, s13, s14                                  ; 80150e0d
	s_max_i32 s29, s29, 0                                       ; 8a1d801d
	v_add3_u32 v5, v3, s21, 0x100                               ; d6550005 03fc2b03 00000100
	v_add3_u32 v4, v1, s21, v3                                  ; d6550004 040c2b01
	s_min_i32 s29, s29, s12                                     ; 891d0c1d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mul_i32 s29, s29, s11                                     ; 961d0b1d
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_add_co_u32 s29, s29, s20                                  ; 801d141d
	s_lshl_b32 s29, s29, 9                                      ; 841d891d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s13, s13, s29                                  ; 800d1d0d
	v_add3_u32 v9, v3, s13, 0x100                               ; d6550009 03fc1b03 00000100
	v_add3_u32 v8, v1, s13, v3                                  ; d6550008 040c1b01
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v9, v9, v1                                 ; 4a120309
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[6:7], v4, s[16:19], null offen            ; c405407c 40802006 00000004
	buffer_load_b64 v[4:5], v5, s[16:19], null offen            ; c405407c 40802004 00000005
	buffer_load_b64 v[10:11], v8, s[16:19], null offen          ; c405407c 4080200a 00000008
	buffer_load_b64 v[8:9], v9, s[16:19], null offen            ; c405407c 40802008 00000009
	v_lshlrev_b32_e32 v12, 2, v0                                ; 30180082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v13, s3, v12, 2                              ; d647000d 020a1803
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[16:19], v13, s[52:55], null offen        ; c405c07c 40806810 0000000d
	buffer_load_b128 v[20:23], v13, s[52:55], null offen offset:512 ; c405c07c 40806814 0002000d
	buffer_load_b128 v[24:27], v13, s[52:55], null offen offset:1024 ; c405c07c 40806818 0004000d
	buffer_load_b128 v[28:31], v13, s[52:55], null offen offset:1536 ; c405c07c 4080681c 0006000d
	buffer_load_b128 v[32:35], v13, s[52:55], null offen offset:2048 ; c405c07c 40806820 0008000d
	buffer_load_b128 v[36:39], v13, s[52:55], null offen offset:2560 ; c405c07c 40806824 000a000d
	buffer_load_b128 v[40:43], v13, s[52:55], null offen offset:3072 ; c405c07c 40806828 000c000d
	buffer_load_b128 v[44:47], v13, s[52:55], null offen offset:3584 ; c405c07c 4080682c 000e000d
	v_lshrrev_b32_e32 v0, 4, v0                                 ; 32000084
	s_mov_b64 s[24:25], s[48:49]                                ; be980130
	s_mov_b64 s[26:27], s[50:51]                                ; be9a0132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshlrev_b32_e32 v0, 3, v0                                 ; 30000083
	v_add_lshl_u32 v14, s8, v0, 2                               ; d647000e 020a0008
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v14, s[24:27], null offen        ; c405c07c 40803030 0000000e
	buffer_load_b128 v[52:55], v14, s[24:27], null offen offset:16 ; c405c07c 40803034 0000100e
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add_lshl_u32 v15, s4, v12, 2                              ; d647000f 020a1804
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[56:59], v15, s[52:55], null offen        ; c405c07c 40806838 0000000f
	buffer_load_b128 v[60:63], v15, s[52:55], null offen offset:512 ; c405c07c 4080683c 0002000f
	buffer_load_b128 v[64:67], v15, s[52:55], null offen offset:1024 ; c405c07c 40806840 0004000f
	buffer_load_b128 v[68:71], v15, s[52:55], null offen offset:1536 ; c405c07c 40806844 0006000f
	buffer_load_b128 v[72:75], v15, s[52:55], null offen offset:2048 ; c405c07c 40806848 0008000f
	buffer_load_b128 v[76:79], v15, s[52:55], null offen offset:2560 ; c405c07c 4080684c 000a000f
	buffer_load_b128 v[80:83], v15, s[52:55], null offen offset:3072 ; c405c07c 40806850 000c000f
	buffer_load_b128 v[84:87], v15, s[52:55], null offen offset:3584 ; c405c07c 40806854 000e000f
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_cndmask_b32_e64 v6, v6, 0, s22                            ; d5010006 00590106
	v_cndmask_b32_e64 v7, v7, 0, s22                            ; d5010007 00590107
	s_wait_loadcnt 0x14                                         ; bfc00014
	v_cndmask_b32_e64 v4, v4, 0, s22                            ; d5010004 00590104
	v_cndmask_b32_e64 v5, v5, 0, s22                            ; d5010005 00590105
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_cndmask_b32_e64 v10, v10, 0, s37                          ; d501000a 0095010a
	v_cndmask_b32_e64 v11, v11, 0, s37                          ; d501000b 0095010b
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v8, v8, 0, s37                            ; d5010008 00950108
	v_cndmask_b32_e64 v9, v9, 0, s37                            ; d5010009 00950109
	v_cvt_pk_f32_fp8_e32 v[92:93], v134                         ; 7eb8dd86
	v_cvt_pk_f32_fp8_e32 v[90:91], v6                           ; 7eb4dd06
	v_cvt_pk_f32_fp8_e32 v[94:95], v7                           ; 7ebcdd07
	v_dual_mov_b32 v89, v7 :: v_dual_mov_b32 v88, v6            ; ca100107 59580106
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	v_dual_mov_b32 v97, v5 :: v_dual_mov_b32 v96, v4            ; ca100105 61600104
	v_dual_mov_b32 v99, v11 :: v_dual_mov_b32 v98, v10          ; ca10010b 6362010a
	v_cvt_pk_f32_fp8_e32 v[100:101], v10                        ; 7ec8dd0a
	v_cvt_pk_f32_fp8_e32 v[102:103], v138                       ; 7eccdd8a
	v_cvt_pk_f32_fp8_e32 v[104:105], v11                        ; 7ed0dd0b
	v_dual_mov_b32 v107, v9 :: v_dual_mov_b32 v106, v8          ; ca100109 6b6a0108
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[88:89], 0 ; cc464070 1a02b110
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[88:89], 0 ; cc464080 1a02b112
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[98:99], 0 ; cc464078 1a02c510
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[98:99], 0 ; cc464088 1a02c512
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[96:97], v[112:119] ; cc464070 1dc2c114
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[20:21], v[106:107], v[120:127] ; cc464078 1de2d514
	v_maxmin_num_f32 v20, -4.0, v114, 4.0                       ; d6690014 03dae4f7
	v_maxmin_num_f32 v18, -4.0, v113, 4.0                       ; d6690012 03dae2f7
	v_maxmin_num_f32 v108, -4.0, v115, 4.0                      ; d669006c 03dae6f7
	v_maxmin_num_f32 v110, -4.0, v116, 4.0                      ; d669006e 03dae8f7
	v_maxmin_num_f32 v16, -4.0, v112, 4.0                       ; d6690010 03dae0f7
	v_fma_mix_f32 v21, 0xab28, |v20|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfe28ff 3728ab28
	v_fma_mix_f32 v19, 0xab28, |v18|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206213 0bfe24ff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v17, 0xab28, |v16|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206211 0bfe20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fmaak_f32 v109, v109, v108, 0x3f650000                    ; 5adad96d 3f650000
	v_dual_fmaak_f32 v19, v19, v18, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v17, 0x3f650000 ; c8422513 13102310 3f650000
	v_maxmin_num_f32 v144, -4.0, v121, 4.0                      ; d6690090 03daf2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_mul_f32 v115, v109, v115 :: v_dual_fmaak_f32 v20, v20, v21, 0x3f650000 ; c8c2e76d 73142b14 3f650000
	v_dual_mul_f32 v113, v113, v19 :: v_dual_mul_f32 v112, v112, v16 ; c8c62771 71702170
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v117, 4.0                      ; d6690070 03daeaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v123, 4.0                      ; d6690094 03daf6f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v122, 4.0                      ; d6690092 03daf4f7
	v_dual_mul_f32 v117, v117, v113 :: v_dual_mul_f32 v116, v116, v110 ; c8c6e375 7574dd74
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v125, 4.0                      ; d6690098 03dafaf7
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v116, -4.0, v119, 4.0                      ; d6690074 03daeef7
	v_maxmin_num_f32 v150, -4.0, v124, 4.0                      ; d6690096 03daf8f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v127, 4.0                      ; d669009c 03dafef7
	v_dual_fmaak_f32 v117, v116, v117, 0x3f650000 :: v_dual_mul_f32 v114, v114, v20 ; c846eb74 75722972 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v126, 4.0                      ; d669009a 03dafcf7
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v118, 4.0                      ; d6690072 03daecf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[96:97], v[128:135] ; cc464080 1e02c116
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_dual_mul_f32 v119, v119, v117 :: v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 ; c8c2eb77 7772e772 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v118, v118, v114 ; c8472191 9176e576 3f650000
	v_maxmin_num_f32 v160, -4.0, v129, 4.0                      ; d66900a0 03db02f7
	v_maxmin_num_f32 v158, -4.0, v128, 4.0                      ; d669009e 03db00f7
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v120, 4.0                      ; d6690076 03daf0f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v131, 4.0                      ; d66900a4 03db06f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v130, 4.0                      ; d66900a2 03db04f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_mul_f32 v121, v121, v145 :: v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 ; c8c32379 7976ef76 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[106:107], v[136:143] ; cc464088 1e22d516
	v_maxmin_num_f32 v168, -4.0, v133, 4.0                      ; d66900a8 03db0af7
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v120, v120, v118 ; c8472995 9578ed78 3f650000
	v_maxmin_num_f32 v166, -4.0, v132, 4.0                      ; d66900a6 03db08f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d3
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v123, v123, v149 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8c32b7b 7b932792 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v135, 4.0                      ; d66900ac 03db0ef7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v122, v122, v146 ; c8473199 997b257a 3f650000
	v_maxmin_num_f32 v170, -4.0, v134, 4.0                      ; d66900aa 03db0cf7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v125, v125, v153 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8c3337d 7d972f96 3f650000
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v137, 4.0                      ; d66900b0 03db12f7
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v124, v124, v150 ; c847399d 9d7d2d7c 3f650000
	v_maxmin_num_f32 v174, -4.0, v136, 4.0                      ; d66900ae 03db10f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_dual_mul_f32 v127, v127, v157 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8c33b7f 7f9b379a 3f650000
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v139, 4.0                      ; d66900b4 03db16f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_mul_f32 v126, v126, v154 ; c84741a1 a17f357e 3f650000
	v_maxmin_num_f32 v178, -4.0, v138, 4.0                      ; d66900b2 03db14f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v129, v129, v161 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c8c34381 819f3f9e 3f650000
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v141, 4.0                      ; d66900b8 03db1af7
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_mul_f32 v128, v128, v158 ; c84749a5 a5813d80 3f650000
	v_maxmin_num_f32 v182, -4.0, v140, 4.0                      ; d66900b6 03db18f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v131, v131, v165 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8c34b83 83a347a2 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v143, 4.0                      ; d66900bc 03db1ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_mul_f32 v130, v130, v162 ; c84751a9 a9834582 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[88:89], 0 ; cc464070 1a02b118
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v133, v133, v169 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c8c35385 85a74fa6 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v132, v132, v166 ; c84759ad ad854d84 3f650000
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[96:97], v[112:119] ; cc464070 1dc2c11c
	v_dual_mul_f32 v135, v135, v173 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8c35b87 87ab57aa 3f650000
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v186, -4.0, v142, 4.0                      ; d66900ba 03db1cf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_mul_f32 v134, v134, v170 ; c84761b1 b1875586 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v112, 4.0                      ; d66900be 03dae0f7
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v137, v137, v177 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c8c36389 89af5fae 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[98:99], 0 ; cc464078 1a02c518
	v_maxmin_num_f32 v15, -4.0, v114, 4.0                       ; d669000f 03dae4f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v136, v136, v174 ; c84769b5 b5895d88 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v25, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe1eff 3728ab28
	v_dual_mul_f32 v139, v139, v181 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c8c36b8b 8bb367b2 3f650000
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[106:107], v[120:127] ; cc464078 1de2d51c
	v_maxmin_num_f32 v28, -4.0, v115, 4.0                       ; d669001c 03dae6f7
	v_fmaak_f32 v15, v15, v25, 0x3f650000                       ; 5a1e330f 3f650000
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_mul_f32 v138, v138, v178 ; c84771b9 b98b658a 3f650000
	v_maxmin_num_f32 v108, -4.0, v116, 4.0                      ; d669006c 03dae8f7
	v_maxmin_num_f32 v110, -4.0, v117, 4.0                      ; d669006e 03daeaf7
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v141, v141, v185 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c8c3738d 8db76fb6 3f650000
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v140, v140, v182 ; c84779bd bd8d6d8c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b8f 8fbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v113, 4.0                      ; d66900bf 03dae2f7
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v108 ; c8c6df75 7574d974
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 :: v_dual_mul_f32 v112, v112, v190 ; c846391d 1d717d70 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v115, v115, v29 :: v_dual_mul_f32 v114, v114, v15 ; c8c63b73 73721f72
	v_dual_fmaak_f32 v13, v191, v13, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8421bbf 0dbb77ba 3f650000
	v_maxmin_num_f32 v116, -4.0, v120, 4.0                      ; d6690074 03daf0f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v113, v113, v13 :: v_dual_mul_f32 v142, v142, v186 ; c8c61b71 718f758e
	v_maxmin_num_f32 v128, -4.0, v123, 4.0                      ; d6690080 03daf6f7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v118, 4.0                      ; d6690070 03daecf7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v119, 4.0                      ; d6690072 03daeef7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v125, 4.0                      ; d6690084 03dafaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v124, 4.0                      ; d6690082 03daf8f7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c8430181 8174eb74 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v127, 4.0                      ; d6690088 03dafef7
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_mul_f32 v123, v123, v129 :: v_dual_mul_f32 v120, v120, v116 ; c8c7037b 7b78e978
	v_maxmin_num_f32 v134, -4.0, v126, 4.0                      ; d6690086 03dafcf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v119, v119, v115 :: v_dual_mul_f32 v118, v118, v112 ; c8c6e777 7776e176
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8431189 89830782 3f650000
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v121, 4.0                      ; d6690076 03daf2f7
	v_dual_mul_f32 v127, v127, v137 :: v_dual_mul_f32 v124, v124, v130 ; c8c7137f 7f7d057c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fmaak_f32 v119, v119, v118, 0x3f650000                    ; 5aeeed77 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_mul_f32_e32 v121, v121, v119                              ; 10f2ef79
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[88:89], 0 ; cc464070 1a02b11a
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v122, 4.0                      ; d6690078 03daf4f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[96:97], v[112:119] ; cc464070 1dc2c11e
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8430985 8578f378 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_mul_f32 v125, v125, v133 :: v_dual_mul_f32 v122, v122, v120 ; c8c70b7d 7d7af17a
	v_maxmin_num_f32 v140, -4.0, v113, 4.0                      ; d669008c 03dae2f7
	v_maxmin_num_f32 v142, -4.0, v114, 4.0                      ; d669008e 03dae4f7
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v144, -4.0, v115, 4.0                      ; d6690090 03dae6f7
	v_maxmin_num_f32 v138, -4.0, v112, 4.0                      ; d669008a 03dae0f7
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v148, -4.0, v117, 4.0                      ; d6690094 03daeaf7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v116, 4.0                      ; d6690092 03dae8f7
	v_maxmin_num_f32 v152, -4.0, v119, 4.0                      ; d6690098 03daeef7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c843198d 8d870f86 3f650000
	v_maxmin_num_f32 v150, -4.0, v118, 4.0                      ; d6690096 03daecf7
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c8432191 918b178a 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432995 958f1f8e 3f650000
	v_dual_mul_f32 v113, v113, v141 :: v_dual_mul_f32 v126, v126, v134 ; c8c71b71 717f0d7e
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8433199 99932792 3f650000
	v_dual_mul_f32 v115, v115, v145 :: v_dual_mul_f32 v112, v112, v138 ; c8c72373 73711570
	v_dual_mul_f32 v117, v117, v149 :: v_dual_mul_f32 v114, v114, v142 ; c8c72b75 75731d72
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[98:99], 0 ; cc464078 1a02c51a
	v_dual_mul_f32 v119, v119, v153 :: v_dual_mul_f32 v116, v116, v146 ; c8c73377 77752574
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[106:107], v[120:127] ; cc464078 1de2d51e
	v_maxmin_num_f32 v160, -4.0, v123, 4.0                      ; d66900a0 03daf6f7
	v_maxmin_num_f32 v154, -4.0, v120, 4.0                      ; d669009a 03daf0f7
	v_maxmin_num_f32 v158, -4.0, v122, 4.0                      ; d669009e 03daf4f7
	v_maxmin_num_f32 v156, -4.0, v121, 4.0                      ; d669009c 03daf2f7
	v_maxmin_num_f32 v164, -4.0, v125, 4.0                      ; d66900a4 03dafaf7
	v_maxmin_num_f32 v162, -4.0, v124, 4.0                      ; d66900a2 03daf8f7
	v_maxmin_num_f32 v168, -4.0, v127, 4.0                      ; d66900a8 03dafef7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v126, 4.0                      ; d66900a6 03dafcf7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c84341a1 a19b379a 3f650000
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c843399d 9d972f96 3f650000
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84349a5 a59f3f9e 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84351a9 a9a347a2 3f650000
	v_dual_mul_f32 v123, v123, v161 :: v_dual_mul_f32 v120, v120, v154 ; c8c7437b 7b793578
	v_dual_mul_f32 v121, v121, v157 :: v_dual_mul_f32 v118, v118, v150 ; c8c73b79 79772d76
	v_dual_mul_f32 v125, v125, v165 :: v_dual_mul_f32 v122, v122, v158 ; c8c74b7d 7d7b3d7a
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v127, v127, v169 :: v_dual_mul_f32 v124, v124, v162 ; c8c7537f 7f7d457c
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[88:89], 0 ; cc464070 1a02b120
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[96:97], v[112:119] ; cc464070 1dc2c124
	v_maxmin_num_f32 v174, -4.0, v114, 4.0                      ; d66900ae 03dae4f7
	v_maxmin_num_f32 v176, -4.0, v115, 4.0                      ; d66900b0 03dae6f7
	v_maxmin_num_f32 v172, -4.0, v113, 4.0                      ; d66900ac 03dae2f7
	v_maxmin_num_f32 v170, -4.0, v112, 4.0                      ; d66900aa 03dae0f7
	v_maxmin_num_f32 v180, -4.0, v117, 4.0                      ; d66900b4 03daeaf7
	v_maxmin_num_f32 v178, -4.0, v116, 4.0                      ; d66900b2 03dae8f7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v119, 4.0                      ; d66900b8 03daeef7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v118, 4.0                      ; d66900b6 03daecf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84359ad ada74fa6 3f650000
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84361b1 b1ab57aa 3f650000
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84369b5 b5af5fae 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84371b9 b9b367b2 3f650000
	v_dual_mul_f32 v113, v113, v173 :: v_dual_mul_f32 v126, v126, v166 ; c8c75b71 717f4d7e
	v_dual_mul_f32 v115, v115, v177 :: v_dual_mul_f32 v112, v112, v170 ; c8c76373 73715570
	v_dual_mul_f32 v117, v117, v181 :: v_dual_mul_f32 v114, v114, v174 ; c8c76b75 75735d72
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v119, v119, v185 :: v_dual_mul_f32 v116, v116, v178 ; c8c77377 77756574
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[98:99], 0 ; cc464078 1a02c520
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[106:107], v[120:127] ; cc464078 1de2d524
	v_maxmin_num_f32 v190, -4.0, v122, 4.0                      ; d66900be 03daf4f7
	v_maxmin_num_f32 v188, -4.0, v121, 4.0                      ; d66900bc 03daf2f7
	v_maxmin_num_f32 v186, -4.0, v120, 4.0                      ; d66900ba 03daf0f7
	v_maxmin_num_f32 v15, -4.0, v124, 4.0                       ; d669000f 03daf8f7
	v_maxmin_num_f32 v108, -4.0, v125, 4.0                      ; d669006c 03dafaf7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v126, 4.0                      ; d669006e 03dafcf7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v127, 4.0                      ; d6690070 03dafef7
	v_fma_mix_f32 v37, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfe1eff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84379bd bdb76fb6 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v121, v121, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b79 79bf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v123, 4.0                      ; d66900bf 03daf6f7
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_mul_f32 v122, v122, v190 ; c846d96d 6d7b7d7a 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_dual_mul_f32 v127, v127, v113 :: v_dual_mul_f32 v126, v126, v110 ; c8c6e37f 7f7edd7e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v13, v13, v191, 0x3f650000 :: v_dual_mul_f32 v118, v118, v182 ; c8477f0d 0d776d76 3f650000
	v_dual_mul_f32 v123, v123, v13 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8c21b7b 7bbb77ba 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[88:89], 0 ; cc464070 1a02b122
	v_dual_fmaak_f32 v15, v15, v37, 0x3f650000 :: v_dual_mul_f32 v120, v120, v186 ; c8464b0f 0f797578 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v125, v125, v109 :: v_dual_mul_f32 v124, v124, v15 ; c8c6db7d 7d7c1f7c
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[96:97], v[112:119] ; cc464070 1dc2c126
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[98:99], 0 ; cc464078 1a02c522
	v_maxmin_num_f32 v136, -4.0, v116, 4.0                      ; d6690088 03dae8f7
	v_maxmin_num_f32 v132, -4.0, v114, 4.0                      ; d6690084 03dae4f7
	v_maxmin_num_f32 v138, -4.0, v117, 4.0                      ; d669008a 03daeaf7
	v_maxmin_num_f32 v130, -4.0, v113, 4.0                      ; d6690082 03dae2f7
	v_maxmin_num_f32 v134, -4.0, v115, 4.0                      ; d6690086 03dae6f7
	v_maxmin_num_f32 v128, -4.0, v112, 4.0                      ; d6690080 03dae0f7
	v_maxmin_num_f32 v140, -4.0, v118, 4.0                      ; d669008c 03daecf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v119, 4.0                      ; d669008e 03daeef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[106:107], v[120:127] ; cc464078 1de2d526
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c843158b 8b891388 3f650000
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430d87 87850b84 3f650000
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 ; c8431d8f 8f8d1b8c 3f650000
	v_dual_mul_f32 v117, v117, v139 :: v_dual_mul_f32 v116, v116, v136 ; c8c71775 75751174
	v_dual_mul_f32 v115, v115, v135 :: v_dual_mul_f32 v114, v114, v132 ; c8c70f73 73730972
	v_maxmin_num_f32 v148, -4.0, v122, 4.0                      ; d6690094 03daf4f7
	v_dual_mul_f32 v113, v113, v131 :: v_dual_mul_f32 v112, v112, v128 ; c8c70771 71710170
	v_maxmin_num_f32 v144, -4.0, v120, 4.0                      ; d6690090 03daf0f7
	v_maxmin_num_f32 v150, -4.0, v123, 4.0                      ; d6690096 03daf6f7
	v_maxmin_num_f32 v146, -4.0, v121, 4.0                      ; d6690092 03daf2f7
	v_dual_mul_f32 v119, v119, v143 :: v_dual_mul_f32 v118, v118, v140 ; c8c71f77 77771976
	v_maxmin_num_f32 v152, -4.0, v124, 4.0                      ; d6690098 03daf8f7
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v154, -4.0, v125, 4.0                      ; d669009a 03dafaf7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v126, 4.0                      ; d669009c 03dafcf7
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v127, 4.0                      ; d669009e 03dafef7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[88:89], 0 ; cc464070 1a02b128
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_dual_mul_f32 v123, v123, v151 :: v_dual_mul_f32 v122, v122, v148 ; c8c72f7b 7b7b297a
	v_dual_mul_f32 v121, v121, v147 :: v_dual_mul_f32 v120, v120, v144 ; c8c72779 79792178
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_dual_mul_f32 v125, v125, v155 :: v_dual_mul_f32 v124, v124, v152 ; c8c7377d 7d7d317c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[96:97], v[112:119] ; cc464070 1dc2c12c
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v127, v127, v159 :: v_dual_mul_f32 v126, v126, v156 ; c8c73f7f 7f7f397e
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[98:99], 0 ; cc464078 1a02c528
	v_maxmin_num_f32 v168, -4.0, v116, 4.0                      ; d66900a8 03dae8f7
	v_maxmin_num_f32 v162, -4.0, v113, 4.0                      ; d66900a2 03dae2f7
	v_maxmin_num_f32 v164, -4.0, v114, 4.0                      ; d66900a4 03dae4f7
	v_maxmin_num_f32 v160, -4.0, v112, 4.0                      ; d66900a0 03dae0f7
	v_maxmin_num_f32 v166, -4.0, v115, 4.0                      ; d66900a6 03dae6f7
	v_maxmin_num_f32 v170, -4.0, v117, 4.0                      ; d66900aa 03daeaf7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v118, 4.0                      ; d66900ac 03daecf7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	buffer_load_b128 v[108:111], v14, s[24:27], null offen offset:64 ; c405c07c 4080306c 0000400e
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	v_dual_mul_f32 v113, v113, v163 :: v_dual_mul_f32 v112, v112, v160 ; c8c74771 71714170
	v_dual_mul_f32 v115, v115, v167 :: v_dual_mul_f32 v114, v114, v164 ; c8c74f73 73734972
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	buffer_load_b128 v[112:115], v14, s[24:27], null offen offset:80 ; c405c07c 40803070 0000500e
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v119, 4.0                      ; d66900ae 03daeef7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[106:107], v[120:127] ; cc464078 1de2d52c
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c84355ab aba953a8 3f650000
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v117, v117, v171 :: v_dual_mul_f32 v116, v116, v168 ; c8c75775 75755174
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 ; c8435daf afad5bac 3f650000
	v_maxmin_num_f32 v180, -4.0, v122, 4.0                      ; d66900b4 03daf4f7
	v_maxmin_num_f32 v182, -4.0, v123, 4.0                      ; d66900b6 03daf6f7
	v_maxmin_num_f32 v178, -4.0, v121, 4.0                      ; d66900b2 03daf2f7
	v_maxmin_num_f32 v184, -4.0, v124, 4.0                      ; d66900b8 03daf8f7
	v_maxmin_num_f32 v176, -4.0, v120, 4.0                      ; d66900b0 03daf0f7
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v186, -4.0, v125, 4.0                      ; d66900ba 03dafaf7
	v_dual_mul_f32 v119, v119, v175 :: v_dual_mul_f32 v118, v118, v172 ; c8c75f77 77775976
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v126, 4.0                      ; d66900bc 03dafcf7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v127, 4.0                      ; d66900be 03dafef7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c8436db7 b7b56bb4 3f650000
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84365b3 b3b163b0 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[98:99], 0 ; cc464080 1a02c52a
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84375bb bbb973b8 3f650000
	v_dual_mul_f32 v123, v123, v183 :: v_dual_mul_f32 v122, v122, v180 ; c8c76f7b 7b7b697a
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8437dbf bfbd7bbc 3f650000
	v_dual_mul_f32 v121, v121, v179 :: v_dual_mul_f32 v120, v120, v176 ; c8c76779 79796178
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v125, v125, v187 :: v_dual_mul_f32 v124, v124, v184 ; c8c7777d 7d7d717c
	v_dual_mul_f32 v127, v127, v191 :: v_dual_mul_f32 v126, v126, v188 ; c8c77f7f 7f7f797e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[106:107], v[128:135] ; cc464080 1e02d52e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[88:89], 0 ; cc464078 1a02b12a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[96:97], v[120:127] ; cc464078 1de2c12e
	v_maxmin_num_f32 v88, -4.0, v124, 4.0                       ; d6690058 03daf8f7
	v_maxmin_num_f32 v96, -4.0, v125, 4.0                       ; d6690060 03dafaf7
	v_maxmin_num_f32 v191, -4.0, v120, 4.0                      ; d66900bf 03daf0f7
	v_maxmin_num_f32 v42, -4.0, v121, 4.0                       ; d669002a 03daf2f7
	v_maxmin_num_f32 v46, -4.0, v123, 4.0                       ; d669002e 03daf6f7
	v_maxmin_num_f32 v44, -4.0, v122, 4.0                       ; d669002c 03daf4f7
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_fma_mix_f32 v43, 0xab28, |v42|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622b 0bfe54ff 3728ab28
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v98, s5, v12, 2                              ; d6470062 020a1805
	v_fma_mix_f32 v47, 0xab28, |v46|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622f 0bfe5cff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v126, 4.0                       ; d6690063 03dafcf7
	v_fma_mix_f32 v45, 0xab28, |v44|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe58ff 3728ab28
	v_fmaak_f32 v191, v191, v13, 0x3f650000                     ; 5b7e1bbf 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_dual_fmaak_f32 v47, v47, v46, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c8425d2f 2f58b358 3f650000
	v_dual_fmaak_f32 v43, v43, v42, 0x3f650000 :: v_dual_mul_f32 v120, v120, v191 ; c846552b 2b797f78 3f650000
	v_maxmin_num_f32 v107, -4.0, v127, 4.0                      ; d669006b 03dafef7
	v_fma_mix_f32 v106, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfec6ff 3728ab28
	v_dual_mul_f32 v124, v124, v88 :: v_dual_mul_f32 v123, v123, v47 ; c8c6b17c 7c7a5f7b
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v121, v121, v43 :: v_dual_fmaak_f32 v44, v44, v45, 0x3f650000 ; c8c25779 792c5b2c 3f650000
	v_fmaak_f32 v99, v99, v106, 0x3f650000                      ; 5ac6d563 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v97, v96, v97, 0x3f650000 :: v_dual_mul_f32 v122, v122, v44 ; c846c360 617a597a 3f650000
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_fma_mix_f32 v120, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfed6ff 3728ab28
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fmaak_f32 v120, v120, v107, 0x3f650000                    ; 5af0d778 3f650000
	v_dual_mul_f32 v126, v126, v99 :: v_dual_mul_f32 v127, v127, v120 ; c8c6c77e 7e7ef17f
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[44:47], v98, s[52:55], null offen        ; c405c07c 4080682c 00000062
	buffer_load_b128 v[116:119], v98, s[52:55], null offen offset:1024 ; c405c07c 40806874 00040062
	buffer_load_b128 v[120:123], v98, s[52:55], null offen offset:2048 ; c405c07c 40806878 00080062
	buffer_load_b128 v[136:139], v98, s[52:55], null offen offset:512 ; c405c07c 40806888 00020062
	v_mul_f32_e32 v125, v125, v97                               ; 10fac37d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870251
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v128, 4.0                      ; d669007c 03db00f7
	v_maxmin_num_f32 v140, -4.0, v131, 4.0                      ; d669008c 03db06f7
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v129, 4.0                      ; d669007e 03db02f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_fmaak_f32 v124, v124, v125, 0x3f650000                    ; 5af8fb7c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fmaak_f32 v127, v127, v126, 0x3f650000                    ; 5afefd7f 3f650000
	v_dual_mul_f32 v129, v129, v127 :: v_dual_mul_f32 v128, v128, v124 ; c8c6ff81 8180f980
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[124:127], v98, s[52:55], null offen offset:1536 ; c405c07c 4080687c 00060062
	buffer_load_b128 v[96:99], v98, s[52:55], null offen offset:2560 ; c405c07c 40806860 000a0062
	v_maxmin_num_f32 v142, -4.0, v132, 4.0                      ; d669008e 03db08f7
	v_maxmin_num_f32 v144, -4.0, v133, 4.0                      ; d6690090 03db0af7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v134, 4.0                      ; d6690092 03db0cf7
	v_maxmin_num_f32 v148, -4.0, v135, 4.0                      ; d6690094 03db0ef7
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v128, -4.0, v130, 4.0                      ; d6690080 03db04f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432191 918f1f8e 3f650000
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_mul_f32 v151, v11, v55 :: v_dual_mul_f32 v150, v10, v54 ; c8c66f0b 97966d0a
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8432995 95932792 3f650000
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c843198d 8d810380 3f650000
	v_dual_mul_f32 v133, v133, v145 :: v_dual_mul_f32 v132, v132, v142 ; c8c72385 85851d84
	v_dual_mul_f32 v145, v101, v49 :: v_dual_mul_f32 v144, v100, v48 ; c8c66365 91906164
	v_dual_mul_f32 v135, v135, v149 :: v_dual_mul_f32 v134, v134, v146 ; c8c72b87 87872586
	v_dual_mul_f32 v147, v103, v51 :: v_dual_mul_f32 v146, v102, v50 ; c8c66767 93926566
	v_dual_mul_f32 v149, v105, v53 :: v_dual_mul_f32 v148, v104, v52 ; c8c66b69 95946968
	v_dual_mul_f32 v131, v131, v141 :: v_dual_mul_f32 v130, v130, v128 ; c8c71b83 83830182
	v_dual_mul_f32 v129, v91, v49 :: v_dual_mul_f32 v128, v90, v48 ; c8c6635b 8180615a
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v133, v95, v53 :: v_dual_mul_f32 v132, v94, v52 ; c8c66b5f 8584695e
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[18:19], v[144:151] ; cc464090 1e422538
	s_bitset0_b32 s49, 14                                       ; beb1108e
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_buffer_load_b32 s10, s[48:51], s10 offset:0x0             ; f4020298 14000000
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v135, v7, v55 :: v_dual_mul_f32 v134, v6, v54 ; c8c66f07 87866d06
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v131, v93, v51 :: v_dual_mul_f32 v130, v92, v50 ; c8c6675d 8382655c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[16:17], v[128:135] ; cc464080 1e022138
	v_cvt_pk_f32_fp8_e32 v[48:49], v4                           ; 7e60dd04
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[22:23], v[144:151] ; cc464090 1e422d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[20:21], v[128:135] ; cc464080 1e02293c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[64:65], v[28:29], v[144:151] ; cc464090 1e423940
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[64:65], v[24:25], v[128:135] ; cc464080 1e023140
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[30:31], v[144:151] ; cc464090 1e423d44
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mul_f32 v153, v49, v109 :: v_dual_mul_f32 v152, v48, v108 ; c8c6db31 9998d930
	v_cvt_pk_f32_fp8_e32 v[48:49], v132                         ; 7e60dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[26:27], v[128:135] ; cc464080 1e023544
	v_dual_mul_f32 v155, v49, v111 :: v_dual_mul_f32 v154, v48, v110 ; c8c6df31 9b9add30
	v_cvt_pk_f32_fp8_e32 v[48:49], v5                           ; 7e60dd05
	v_cvt_pk_f32_fp8_e32 v[4:5], v133                           ; 7e08dd85
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[36:37], v[144:151] ; cc464090 1e424948
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v157, v49, v113 :: v_dual_mul_f32 v156, v48, v112 ; c8c6e331 9d9ce130
	v_dual_mul_f32 v159, v5, v115 :: v_dual_mul_f32 v158, v4, v114 ; c8c6e705 9f9ee504
	v_cvt_pk_f32_fp8_e32 v[4:5], v8                             ; 7e08dd08
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[32:33], v[128:135] ; cc464080 1e024148
	v_dual_mul_f32 v49, v5, v109 :: v_dual_mul_f32 v48, v4, v108 ; c8c6db05 3130d904
	v_cvt_pk_f32_fp8_e32 v[4:5], v136                           ; 7e08dd88
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[76:77], v[38:39], v[144:151] ; cc464090 1e424d4c
	v_dual_mul_f32 v51, v5, v111 :: v_dual_mul_f32 v50, v4, v110 ; c8c6df05 3332dd04
	v_cvt_pk_f32_fp8_e32 v[4:5], v9                             ; 7e08dd09
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[34:35], v[128:135] ; cc464080 1e02454c
	v_dual_mul_f32 v53, v5, v113 :: v_dual_mul_f32 v52, v4, v112 ; c8c6e305 3534e104
	v_cvt_pk_f32_fp8_e32 v[4:5], v137                           ; 7e08dd89
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[80:81], v[14:15], v[144:151] ; cc464090 1e421d50
	v_dual_mul_f32 v55, v5, v115 :: v_dual_mul_f32 v54, v4, v114 ; c8c6e705 3736e504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[58:59], v[18:19], v[48:55] ; cc464030 1cc2253a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[40:41], v[128:135] ; cc464080 1e025150
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[88:89], v[144:151] ; cc464090 1e42b154
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[62:63], v[22:23], v[48:55] ; cc464030 1cc22d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[42:43], v[128:135] ; cc464080 1e025554
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[16:17], v[152:159] ; cc464098 1e62213a
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[66:67], v[28:29], v[48:55] ; cc464030 1cc23942
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[20:21], v[152:159] ; cc464098 1e62293e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[70:71], v[30:31], v[48:55] ; cc464030 1cc23d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[24:25], v[152:159] ; cc464098 1e623142
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[74:75], v[36:37], v[48:55] ; cc464030 1cc2494a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[70:71], v[26:27], v[152:159] ; cc464098 1e623546
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[78:79], v[38:39], v[48:55] ; cc464030 1cc24d4e
	v_lshl_add_u32 v160, v2, 5, v1                              ; d64600a0 04050b02
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[32:33], v[152:159] ; cc464098 1e62414a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[82:83], v[14:15], v[48:55] ; cc464030 1cc21d52
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, 0              ; ca100080 0f0e0080
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[78:79], v[34:35], v[152:159] ; cc464098 1e62454e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[86:87], v[88:89], v[48:55] ; cc464030 1cc2b156
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[82:83], v[40:41], v[152:159] ; cc464098 1e625152
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[42:43], v[152:159] ; cc464098 1e625556
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v160, v[14:15], v[14:15] offset1:2       ; d9380200 000e0ea0
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[46:47], v[6:7], 0   ; cc464018 1a020d2e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[118:119], v[6:7], 0 ; cc464038 1a020d76
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[6:7], 0   ; cc464010 1a020d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[116:117], v[6:7], 0 ; cc464020 1a020d74
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[6:7], v[120:121], 0 ; cc464040 1a02f106
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[6:7], v[122:123], 0 ; cc464048 1a02f506
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[138:139], v[4:5], v[24:31] ; cc464018 1c62098a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[126:127], v[4:5], v[56:63] ; cc464038 1ce2097e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[136:137], v[4:5], v[16:23] ; cc464010 1c420988
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[124:125], v[4:5], v[32:39] ; cc464020 1c82097c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[4:5], v[96:97], v[64:71] ; cc464040 1d02c104
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[4:5], v[98:99], v[72:79] ; cc464048 1d22c504
	v_dual_mul_f32 v163, v27, v27 :: v_dual_mul_f32 v162, v57, v57 ; c8c6371b a3a27339
	v_dual_mul_f32 v164, v59, v59 :: v_dual_mul_f32 v161, v25, v25 ; c8c6773b a4a03319
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_dual_fmac_f32 v163, v19, v19 :: v_dual_fmac_f32 v162, v33, v33 ; c8002713 a3a24321
	v_dual_fmac_f32 v164, v35, v35 :: v_dual_fmac_f32 v161, v17, v17 ; c8004723 a4a02311
	s_mov_b32 s22, 0x76543210                                   ; be9600ff 76543210
	s_mov_b32 s23, 0xfedcba98                                   ; be9700ff fedcba98
	v_dual_fmac_f32 v163, v23, v23 :: v_dual_fmac_f32 v162, v37, v37 ; c8002f17 a3a24b25
	v_dual_fmac_f32 v164, v39, v39 :: v_dual_fmac_f32 v161, v21, v21 ; c8004f27 a4a02b15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v163, v31, v31 :: v_dual_fmac_f32 v162, v61, v61 ; c8003f1f a3a27b3d
	v_dual_fmac_f32 v164, v63, v63 :: v_dual_fmac_f32 v161, v29, v29 ; c8007f3f a4a03b1d
	v_dual_fmac_f32 v162, v32, v32 :: v_dual_fmac_f32 v163, v18, v18 ; c8004120 a2a22512
	v_dual_fmac_f32 v164, v34, v34 :: v_dual_fmac_f32 v161, v16, v16 ; c8004522 a4a02110
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v162, v56, v56 :: v_dual_fmac_f32 v163, v26, v26 ; c8007138 a2a2351a
	v_dual_fmac_f32 v164, v58, v58 :: v_dual_fmac_f32 v161, v24, v24 ; c800753a a4a03118
	v_dual_fmac_f32 v162, v36, v36 :: v_dual_fmac_f32 v163, v22, v22 ; c8004924 a2a22d16
	v_dual_fmac_f32 v164, v38, v38 :: v_dual_fmac_f32 v161, v20, v20 ; c8004d26 a4a02914
	v_lshl_add_u32 v2, v2, 6, s7                                ; d6460002 001d0d02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
	v_dual_fmac_f32 v162, v60, v60 :: v_dual_fmac_f32 v163, v30, v30 ; c800793c a2a23d1e
	v_dual_fmac_f32 v164, v62, v62 :: v_dual_fmac_f32 v161, v28, v28 ; c8007d3e a4a0391c
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
	v_fma_mixlo_f16 v165, 1.0, v161, v163                       ; cc2100a5 068f42f2
	v_fma_mixhi_f16 v165, 1.0, v162, v164                       ; cc2200a5 069344f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v166, v165, s22, s23 op_sel:[1,1]         ; d65c18a6 005c2da5
(invalid instruction)                                        ; cc0f00a5
	v_min_num_f64_e32 v[1:2], v[165:166], v[166:167]            ; 1a034da5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v255                             ; 0a01ffa5
(invalid instruction)                                        ; 00000410
(invalid instruction)                                        ; d58b00a7
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a1
	v_rsq_f32_e32 v167, v167                                    ; 7f4e5da7
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_mul_f32_e32 v167, s10, v167                               ; 114f4e0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v20, v20, v167 :: v_dual_mul_f32 v19, v19, v167 ; c8c74f14 14134f13
	v_dual_mul_f32 v18, v18, v167 :: v_dual_mul_f32 v17, v17, v167 ; c8c74f12 12114f11
	v_mul_f32_e32 v16, v16, v167                                ; 10214f10
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v2, s[24:27], null offen offset:4096 ; c405c07c 40803010 00100002
	buffer_load_b128 v[40:43], v2, s[24:27], null offen offset:4112 ; c405c07c 40803028 00101002
	v_dual_mul_f32 v23, v23, v167 :: v_dual_mul_f32 v22, v22, v167 ; c8c74f17 17174f16
(invalid instruction)                                        ; d58b08a5
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
	v_mul_f32_e32 v21, v21, v167                                ; 102b4f15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(TRANS32_DEP_1) ; bf8702b2
	v_rsq_f32_e32 v165, v165                                    ; 7f4a5da5
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	v_dual_mul_f32 v37, v37, v165 :: v_dual_mul_f32 v36, v36, v165 ; c8c74b25 25254b24
	v_dual_mul_f32 v39, v39, v165 :: v_dual_mul_f32 v38, v38, v165 ; c8c74b27 27274b26
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v2, s[24:27], null offen offset:12288 ; c405c07c 40803014 00300002
	buffer_load_b128 v[36:39], v2, s[24:27], null offen offset:12304 ; c405c07c 40803024 00301002
	v_dual_mul_f32 v25, v25, v167 :: v_dual_mul_f32 v24, v24, v167 ; c8c74f19 19194f18
	v_dual_mul_f32 v27, v27, v167 :: v_dual_mul_f32 v26, v26, v167 ; c8c74f1b 1b1b4f1a
	v_dual_mul_f32 v29, v29, v167 :: v_dual_mul_f32 v28, v28, v167 ; c8c74f1d 1d1d4f1c
	v_dual_mul_f32 v31, v31, v167 :: v_dual_mul_f32 v30, v30, v167 ; c8c74f1f 1f1f4f1e
	v_dual_mul_f32 v33, v33, v165 :: v_dual_mul_f32 v32, v32, v165 ; c8c74b21 21214b20
	v_dual_mul_f32 v35, v35, v165 :: v_dual_mul_f32 v34, v34, v165 ; c8c74b23 23234b22
	v_dual_mul_f32 v57, v57, v165 :: v_dual_mul_f32 v56, v56, v165 ; c8c74b39 39394b38
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
	v_dual_mul_f32 v59, v59, v165 :: v_dual_mul_f32 v58, v58, v165 ; c8c74b3b 3b3b4b3a
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v2, s[24:27], null offen offset:4160 ; c405c07c 4080301c 00104002
	buffer_load_b128 v[56:59], v2, s[24:27], null offen offset:4176 ; c405c07c 40803038 00105002
	v_dual_mul_f32 v61, v61, v165 :: v_dual_mul_f32 v60, v60, v165 ; c8c74b3d 3d3d4b3c
	v_dual_mul_f32 v63, v63, v165 :: v_dual_mul_f32 v62, v62, v165 ; c8c74b3f 3f3f4b3e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v160, v[6:7], v[26:27] offset0:64 offset1:66 ; d9384240 001a06a0
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v160, v[14:15], v[14:15] offset0:128 offset1:130 ; d9388280 000e0ea0
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[44:45], v[10:11], 0 ; cc464040 1a02152c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[46:47], v[10:11], 0 ; cc464048 1a02152e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v2, s[24:27], null offen offset:12352 ; c405c07c 4080302c 00304002
	buffer_load_b128 v[60:63], v2, s[24:27], null offen offset:12368 ; c405c07c 4080303c 00305002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[116:117], v[10:11], 0 ; cc464050 1a021574
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[118:119], v[10:11], 0 ; cc464058 1a021576
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[120:121], 0 ; cc464068 1a02f10a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[122:123], 0 ; cc464070 1a02f50a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[136:137], v[8:9], v[64:71] ; cc464040 1d021188
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[138:139], v[8:9], v[72:79] ; cc464048 1d22118a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[124:125], v[8:9], v[80:87] ; cc464050 1d42117c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[126:127], v[8:9], v[88:95] ; cc464058 1d62117e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[96:97], v[104:111] ; cc464068 1da2c108
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[8:9], v[98:99], v[112:119] ; cc464070 1dc2c508
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v2, s[24:27], null offen offset:4224 ; c405c07c 40803008 00108002
	buffer_load_b128 v[96:99], v2, s[24:27], null offen offset:4240 ; c405c07c 40803060 00109002
	v_mul_f32_e32 v168, v73, v73                                ; 11509349
	v_mul_f32_e32 v169, v89, v89                                ; 1152b359
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmac_f32_e32 v168, v65, v65                               ; 57508341
	v_dual_mul_f32 v170, v75, v75 :: v_dual_fmac_f32 v169, v81, v81 ; c8c0974b aaa8a351
	v_dual_fmac_f32 v168, v69, v69 :: v_dual_mul_f32 v171, v91, v91 ; c8068b45 a8aab75b
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[100:103], v2, s[24:27], null offen offset:12416 ; c405c07c 40803064 00308002
	buffer_load_b128 v[120:123], v2, s[24:27], null offen offset:12432 ; c405c07c 40803078 00309002
	v_dual_fmac_f32 v170, v67, v67 :: v_dual_fmac_f32 v169, v85, v85 ; c8008743 aaa8ab55
	v_dual_fmac_f32 v168, v77, v77 :: v_dual_fmac_f32 v171, v83, v83 ; c8009b4d a8aaa753
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmac_f32 v170, v71, v71 :: v_dual_fmac_f32 v169, v93, v93 ; c8008f47 aaa8bb5d
	v_fmac_f32_e32 v168, v64, v64                               ; 57508140
	v_fmac_f32_e32 v171, v87, v87                               ; 5756af57
	v_fmac_f32_e32 v170, v79, v79                               ; 57549f4f
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v168, v72, v72 :: v_dual_fmac_f32 v171, v95, v95 ; c8009148 a8aabf5f
	v_dual_fmac_f32 v170, v66, v66 :: v_dual_fmac_f32 v169, v80, v80 ; c8008542 aaa8a150
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v168, v68, v68 :: v_dual_fmac_f32 v171, v82, v82 ; c8008944 a8aaa552
	v_dual_fmac_f32 v170, v74, v74 :: v_dual_fmac_f32 v169, v88, v88 ; c800954a aaa8b158
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v168, v76, v76 :: v_dual_fmac_f32 v171, v90, v90 ; c800994c a8aab55a
	v_dual_fmac_f32 v170, v70, v70 :: v_dual_fmac_f32 v169, v84, v84 ; c8008d46 aaa8a954
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fmac_f32_e32 v171, v86, v86                               ; 5756ad56
	v_dual_fmac_f32 v170, v78, v78 :: v_dual_fmac_f32 v169, v92, v92 ; c8009d4e aaa8b95c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fmac_f32_e32 v171, v94, v94                               ; 5756bd5e
	v_fma_mixlo_f16 v172, 1.0, v168, v170                       ; cc2100ac 06ab50f2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mixhi_f16 v172, 1.0, v169, v171                       ; cc2200ac 06af52f2
	v_permlanex16_b32 v173, v172, s22, s23 op_sel:[1,1]         ; d65c18ad 005c2dac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[173:174]            ; 1a035bac
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v255                             ; 0a01ffac
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
(invalid instruction)                                        ; d58b08ac
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	v_rsq_f32_e32 v174, v174                                    ; 7f5c5dae
	v_rsq_f32_e32 v172, v172                                    ; 7f585dac
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870096
	v_mul_f32_e32 v174, s10, v174                               ; 115d5c0a
	v_dual_mul_f32 v68, v68, v174 :: v_dual_mul_f32 v67, v67, v174 ; c8c75d44 44435d43
	v_dual_mul_f32 v80, v80, v172 :: v_dual_mul_f32 v71, v71, v174 ; c8c75950 50475d47
	v_dual_mul_f32 v70, v70, v174 :: v_dual_mul_f32 v69, v69, v174 ; c8c75d46 46455d45
	v_dual_mul_f32 v66, v66, v174 :: v_dual_mul_f32 v65, v65, v174 ; c8c75d42 42415d41
	v_mul_f32_e32 v64, v64, v174                                ; 10815d40
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v83, v83, v172 :: v_dual_mul_f32 v82, v82, v172 ; c8c75953 53535952
	v_mul_f32_e32 v81, v81, v172                                ; 10a35951
	v_dual_mul_f32 v87, v87, v172 :: v_dual_mul_f32 v86, v86, v172 ; c8c75957 57575956
	v_dual_mul_f32 v85, v85, v172 :: v_dual_mul_f32 v84, v84, v172 ; c8c75955 55555954
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[64:67], v2, s[24:27], null offen offset:4288 ; c405c07c 40803040 0010c002
	buffer_load_b128 v[68:71], v2, s[24:27], null offen offset:4304 ; c405c07c 40803044 0010d002
	buffer_load_b128 v[80:83], v2, s[24:27], null offen offset:12480 ; c405c07c 40803050 0030c002
	buffer_load_b128 v[84:87], v2, s[24:27], null offen offset:12496 ; c405c07c 40803054 0030d002
	v_dual_mul_f32 v73, v73, v174 :: v_dual_mul_f32 v72, v72, v174 ; c8c75d49 49495d48
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v75, v75, v174 :: v_dual_mul_f32 v74, v74, v174 ; c8c75d4b 4b4b5d4a
	v_dual_mul_f32 v77, v77, v174 :: v_dual_mul_f32 v76, v76, v174 ; c8c75d4d 4d4d5d4c
	v_dual_mul_f32 v79, v79, v174 :: v_dual_mul_f32 v78, v78, v174 ; c8c75d4f 4f4f5d4e
	v_dual_mul_f32 v89, v89, v172 :: v_dual_mul_f32 v88, v88, v172 ; c8c75959 59595958
	v_dual_mul_f32 v91, v91, v172 :: v_dual_mul_f32 v90, v90, v172 ; c8c7595b 5b5b595a
	v_dual_mul_f32 v93, v93, v172 :: v_dual_mul_f32 v92, v92, v172 ; c8c7595d 5d5d595c
	v_dual_mul_f32 v95, v95, v172 :: v_dual_mul_f32 v94, v94, v172 ; c8c7595f 5f5f595e
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v160, v[26:27], v[74:75] offset0:192 offset1:194 ; d938c2c0 004a1aa0
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_load_b64 v[74:75], v160                                  ; d9d80000 4a0000a0
	ds_load_b64 v[76:77], v160 offset:16                        ; d9d80010 4c0000a0
	s_mov_b32 s30, 0x3d380000                                   ; be9e00ff 3d380000
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[74:75], v[4:5], 0   ; cc464058 1a02094a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[74:75], v[14:15], 0 ; cc464068 1a021d4a
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[76:77], v[24:25], v[88:95] ; cc464058 1d62314c
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_fma_mixlo_f16 v175, s30, v88, v16                         ; cc2100af 0442b01e
	v_fma_mixhi_f16 v175, s30, v89, v17                         ; cc2200af 0446b21e
	ds_load_b64 v[16:17], v160 offset:512                       ; d9d80200 100000a0
	ds_load_b64 v[74:75], v160 offset:528                       ; d9d80210 4a0000a0
	s_movk_i32 s31, 0x3c20                                      ; b01f3c20
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[76:77], v[72:73], v[104:111] ; cc464068 1da2914c
	v_fma_mixlo_f16 v176, s30, v90, v18                         ; cc2100b0 044ab41e
	v_fma_mixhi_f16 v176, s30, v91, v19                         ; cc2200b0 044eb61e
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v178, s30, v94, v42                         ; cc2100b2 04aabc1e
	v_fma_mixhi_f16 v178, s30, v95, v43                         ; cc2200b2 04aebe1e
	v_fma_mixlo_f16 v177, s30, v92, v40                         ; cc2100b1 04a2b81e
	v_fma_mixhi_f16 v177, s30, v93, v41                         ; cc2200b1 04a6ba1e
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v31                              ; 0a003faf
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v31                              ; 0a003fb0
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v31                              ; 0a003fb2
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[4:5], 0   ; cc464058 1a020910
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v31                              ; 0a003fb1
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v181, s30, v108, v36                        ; cc2100b5 0492d81e
	v_fma_mixhi_f16 v181, s30, v109, v37                        ; cc2200b5 0496da1e
	v_fma_mixlo_f16 v182, s30, v110, v38                        ; cc2100b6 049adc1e
	v_fma_mixlo_f16 v180, s30, v106, v22                        ; cc2100b4 045ad41e
	v_fma_mixhi_f16 v180, s30, v107, v23                        ; cc2200b4 045ed61e
	v_fma_mixhi_f16 v182, s30, v111, v39                        ; cc2200b6 049ede1e
	v_fma_mixlo_f16 v179, s30, v104, v20                        ; cc2100b3 0452d01e
	v_fma_mixhi_f16 v179, s30, v105, v21                        ; cc2200b3 0456d21e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[14:15], 0 ; cc464068 1a021d10
	ds_load_b64 v[16:17], v160 offset:1024                      ; d9d80400 100000a0
	ds_load_b64 v[18:19], v160 offset:1040                      ; d9d80410 120000a0
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v31                              ; 0a003fb5
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v31                              ; 0a003fb4
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[74:75], v[24:25], v[88:95] ; cc464058 1d62314a
(invalid instruction)                                        ; cc1c00b6
	v_subrev_f32_e32 v0, v182, v31                              ; 0a003fb6
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v31                              ; 0a003fb3
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[74:75], v[72:73], v[104:111] ; cc464068 1da2914a
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v184, s30, v90, v30                         ; cc2100b8 047ab41e
	v_fma_mixlo_f16 v183, s30, v88, v28                         ; cc2100b7 0472b01e
	v_fma_mixhi_f16 v183, s30, v89, v29                         ; cc2200b7 0476b21e
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v185, s30, v92, v56                         ; cc2100b9 04e2b81e
	v_fma_mixlo_f16 v186, s30, v94, v58                         ; cc2100ba 04eabc1e
	v_fma_mixhi_f16 v186, s30, v95, v59                         ; cc2200ba 04eebe1e
	v_fma_mixhi_f16 v185, s30, v93, v57                         ; cc2200b9 04e6ba1e
	v_fma_mixhi_f16 v184, s30, v91, v31                         ; cc2200b8 047eb61e
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v31                              ; 0a003fb7
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v187, s30, v104, v44                        ; cc2100bb 04b2d01e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v189, s30, v108, v60                        ; cc2100bd 04f2d81e
	v_fma_mixlo_f16 v190, s30, v110, v62                        ; cc2100be 04fadc1e
	v_fma_mixlo_f16 v188, s30, v106, v46                        ; cc2100bc 04bad41e
	v_fma_mixhi_f16 v188, s30, v107, v47                        ; cc2200bc 04bed61e
	v_fma_mixhi_f16 v189, s30, v109, v61                        ; cc2200bd 04f6da1e
	v_fma_mixhi_f16 v190, s30, v111, v63                        ; cc2200be 04fede1e
	v_fma_mixhi_f16 v187, s30, v105, v45                        ; cc2200bb 04b6d21e
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[4:5], 0   ; cc464028 1a020910
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[16:17], v[14:15], 0 ; cc464038 1a021d10
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[24:25], v[40:47] ; cc464028 1ca23112
	s_wait_loadcnt 0x7                                          ; bfc00007
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_fma_mixlo_f16 v191, s30, v40, v8                          ; cc2100bf 0422501e
	v_fma_mixhi_f16 v191, s30, v41, v9                          ; cc2200bf 0426521e
	ds_load_b64 v[8:9], v160 offset:1536                        ; d9d80600 080000a0
	ds_load_b64 v[16:17], v160 offset:1552                      ; d9d80610 100000a0
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v31                              ; 0a003fba
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v31                              ; 0a003fb9
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v31                              ; 0a003fb8
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v31                              ; 0a003fbc
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v31                              ; 0a003fbd
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v31                              ; 0a003fbe
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v31                              ; 0a003fbb
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[18:19], v[72:73], v[56:63] ; cc464038 1ce29112
	v_fma_mixlo_f16 v2, s30, v42, v10                           ; cc210002 042a541e
	v_fma_mixhi_f16 v2, s30, v43, v11                           ; cc220002 042e561e
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v10, s30, v44, v96                          ; cc21000a 0582581e
	v_fma_mixhi_f16 v10, s30, v45, v97                          ; cc22000a 05865a1e
	v_fma_mixlo_f16 v11, s30, v46, v98                          ; cc21000b 058a5c1e
	v_fma_mixhi_f16 v11, s30, v47, v99                          ; cc22000b 058e5e1e
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v31                              ; 0a003fbf
(invalid instruction)                                        ; cc1c0002
	v_subrev_f32_e32 v0, v2, v31                                ; 0a003f02
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[8:9], v[4:5], 0     ; cc464028 1a020908
(invalid instruction)                                        ; cc1c000a
	v_subrev_f32_e32 v0, v10, v31                               ; 0a003f0a
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v31                               ; 0a003f0b
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v20, s30, v62, v122                         ; cc210014 05ea7c1e
	v_fma_mixlo_f16 v19, s30, v60, v120                         ; cc210013 05e2781e
	v_fma_mixhi_f16 v19, s30, v61, v121                         ; cc220013 05e67a1e
	v_fma_mixlo_f16 v18, s30, v58, v102                         ; cc210012 059a741e
	v_fma_mixhi_f16 v18, s30, v59, v103                         ; cc220012 059e761e
	v_fma_mixhi_f16 v20, s30, v63, v123                         ; cc220014 05ee7e1e
	v_fma_mixlo_f16 v13, s30, v56, v100                         ; cc21000d 0592701e
	v_fma_mixhi_f16 v13, s30, v57, v101                         ; cc22000d 0596721e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[8:9], v[14:15], 0   ; cc464038 1a021d08
(invalid instruction)                                        ; cc1c0013
	v_subrev_f32_e32 v0, v19, v31                               ; 0a003f13
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v31                               ; 0a003f12
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[24:25], v[40:47] ; cc464028 1ca23110
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v31                               ; 0a003f14
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v31                               ; 0a003f0d
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[16:17], v[72:73], v[56:63] ; cc464038 1ce29110
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v22, s30, v42, v66                          ; cc210016 050a541e
	v_fma_mixlo_f16 v21, s30, v40, v64                          ; cc210015 0502501e
	v_fma_mixhi_f16 v21, s30, v41, v65                          ; cc220015 0506521e
	v_fma_mixhi_f16 v22, s30, v43, v67                          ; cc220016 050e561e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v24, s30, v46, v70                          ; cc210018 051a5c1e
	v_fma_mixhi_f16 v24, s30, v47, v71                          ; cc220018 051e5e1e
	v_fma_mixlo_f16 v23, s30, v44, v68                          ; cc210017 0512581e
	v_fma_mixhi_f16 v23, s30, v45, v69                          ; cc220017 05165a1e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v28, s30, v58, v82                          ; cc21001c 054a741e
	v_fma_mixhi_f16 v28, s30, v59, v83                          ; cc22001c 054e761e
	v_fma_mixlo_f16 v25, s30, v56, v80                          ; cc210019 0542701e
	v_fma_mixhi_f16 v25, s30, v57, v81                          ; cc220019 0546721e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v29, s30, v60, v84                          ; cc21001d 0552781e
	v_fma_mixhi_f16 v29, s30, v61, v85                          ; cc22001d 05567a1e
	v_fma_mixlo_f16 v30, s30, v62, v86                          ; cc21001e 055a7c1e
	v_fma_mixhi_f16 v30, s30, v63, v87                          ; cc22001e 055e7e1e
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v31                               ; 0a003f15
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v31                               ; 0a003f16
	s_mov_b32 s32, 0x7ff88000                                   ; bea000ff 7ff88000
(invalid instruction)                                        ; cc1c0018
	v_subrev_f32_e32 v0, v24, v31                               ; 0a003f18
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v31                               ; 0a003f17
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v31                               ; 0a003f1c
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v31                               ; 0a003f19
(invalid instruction)                                        ; cc1c001d
	v_subrev_f32_e32 v0, v29, v31                               ; 0a003f1d
	v_lshl_add_u32 v191, v191, 5, s32                           ; d64600bf 00810bbf
	v_lshl_add_u32 v175, v175, 5, s32                           ; d64600af 00810baf
	v_lshl_add_u32 v184, v184, 5, s32                           ; d64600b8 00810bb8
	v_lshl_add_u32 v2, v2, 5, s32                               ; d6460002 00810b02
	v_lshl_add_u32 v176, v176, 5, s32                           ; d64600b0 00810bb0
	v_lshl_add_u32 v183, v183, 5, s32                           ; d64600b7 00810bb7
(invalid instruction)                                        ; cc1c001e
	v_subrev_f32_e32 v0, v30, v31                               ; 0a003f1e
	v_lshl_add_u32 v21, v21, 5, s32                             ; d6460015 00810b15
	v_lshl_add_u32 v22, v22, 5, s32                             ; d6460016 00810b16
	v_lshl_add_u32 v177, v177, 5, s32                           ; d64600b1 00810bb1
	v_lshl_add_u32 v185, v185, 5, s32                           ; d64600b9 00810bb9
	v_lshl_add_u32 v10, v10, 5, s32                             ; d646000a 00810b0a
	v_lshl_add_u32 v23, v23, 5, s32                             ; d6460017 00810b17
	v_add_lshl_u32 v0, s9, v0, 2                                ; d6470000 020a0009
	v_lshl_add_u32 v178, v178, 5, s32                           ; d64600b2 00810bb2
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v0, s[24:27], null offen         ; c405c07c 40803028 00000000
	buffer_load_b128 v[44:47], v0, s[24:27], null offen offset:16 ; c405c07c 4080302c 00001000
	v_lshl_add_u32 v186, v186, 5, s32                           ; d64600ba 00810bba
	v_lshl_add_u32 v11, v11, 5, s32                             ; d646000b 00810b0b
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[176:177], v[184:185]            ; 1a0371b0
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[175:176], v[183:184]            ; 1a036faf
	v_lshl_add_u32 v24, v24, 5, s32                             ; d6460018 00810b18
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[177:178], v[185:186]            ; 1a0373b1
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[178:179], v[186:187]            ; 1a0375b2
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[36:37], v[2:3]                  ; 1a020524
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[191:192]              ; 1a037f1f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[10:11]                ; 1a021525
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[11:12]                ; 1a021726
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[36:37], v[22:23]                ; 1a022d24
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[21:22]                ; 1a022b1f
(invalid instruction)                                        ; cc0f0025
	v_min_num_f64_e32 v[1:2], v[37:38], v[23:24]                ; 1a022f25
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[24:25]                ; 1a023126
	s_lshr_b32 s6, s6, 2                                        ; 85068206
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[36:37]                ; 1a02491f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v12, s6, v12, 2                              ; d647000c 020a1806
	buffer_load_b64 v[8:9], v12, s[52:55], null offen           ; c405407c 40806808 0000000c
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[37:38]                ; 1a024b1f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[38:39]                ; 1a024d1f
	v_permlanex16_b32 v39, v31, s22, s23 op_sel:[1,1]           ; d65c1827 005c2d1f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[39:40]                ; 1a024f1f
	buffer_load_b64 v[14:15], v12, s[52:55], null offen offset:512 ; c405407c 4080680e 0002000c
	v_add_f16_e32 v56, v31, v159/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64713f1f
	v_max_num_f16_e32 v56, 0x400, v56                           ; 627070ff 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v57, v56                                  ; 7e721738
	v_rcp_f32_e32 v57, v57                                      ; 7e725539
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v61, v178, v57, neg(0) op_sel_hi:[1,0,0]      ; cc20003d 8a0273b2
	v_fma_mix_f32 v60, v177, v57, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a0273b1
	v_fma_mix_f32 v177, v177, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a0273b1
	v_fma_mix_f32 v63, v184, v57, neg(0) op_sel_hi:[1,0,0]      ; cc20003f 8a0273b8
	v_fma_mix_f32 v178, v178, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a0273b2
	v_fma_mix_f32 v59, v176, v57, neg(0) op_sel_hi:[1,0,0]      ; cc20003b 8a0273b0
	v_fma_mix_f32 v58, v175, v57, neg(0) op_sel_hi:[1,0,0]      ; cc20003a 8a0273af
	v_fma_mix_f32 v175, v175, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a0273af
	v_fma_mix_f32 v176, v176, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a0273b0
	v_fma_mix_f32 v62, v183, v57, neg(0) op_sel_hi:[1,0,0]      ; cc20003e 8a0273b7
	v_fma_mix_f32 v183, v183, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a0273b7
	v_fma_mix_f32 v184, v184, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a0273b8
	v_fma_mix_f32 v64, v185, v57, neg(0) op_sel_hi:[1,0,0]      ; cc200040 8a0273b9
	v_fma_mix_f32 v185, v185, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a0273b9
	v_fma_mix_f32 v65, v186, v57, neg(0) op_sel_hi:[1,0,0]      ; cc200041 8a0273ba
	v_fma_mix_f32 v186, v186, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a0273ba
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v60, v177, vcc_lo                     ; 0203633c
	v_fma_mix_f32 v66, v191, v57, neg(0) op_sel_hi:[1,0,0]      ; cc200042 8a0273bf
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v61, v178, vcc_lo                     ; 0203653d
	v_fma_mix_f32 v191, v191, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a0273bf
	v_fma_mix_f32 v67, v2, v57, neg(0) op_sel_hi:[1,0,0]        ; cc200043 8a027302
	v_fma_mix_f32 v2, v2, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200802 8a027302
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v58, v175, vcc_lo                     ; 02035f3a
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v59, v176, vcc_lo                     ; 0203613b
	v_fma_mix_f32 v68, v10, v57, neg(0) op_sel_hi:[1,0,0]       ; cc200044 8a02730a
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v62, v183, vcc_lo                     ; 02036f3e
	v_fma_mix_f32 v10, v10, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080a 8a02730a
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v63, v184, vcc_lo                     ; 0203713f
	v_fma_mix_f32 v69, v11, v57, neg(0) op_sel_hi:[1,0,0]       ; cc200045 8a02730b
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v64, v185, vcc_lo                     ; 02037340
	v_fma_mix_f32 v11, v11, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080b 8a02730b
	v_fma_mix_f32 v70, v21, v57, neg(0) op_sel_hi:[1,0,0]       ; cc200046 8a027315
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v65, v186, vcc_lo                     ; 02037541
	v_fma_mix_f32 v21, v21, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a027315
	v_fma_mix_f32 v71, v22, v57, neg(0) op_sel_hi:[1,0,0]       ; cc200047 8a027316
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v66, v191, vcc_lo                     ; 02037f42
	v_fma_mix_f32 v22, v22, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a027316
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v67, v2, vcc_lo                       ; 02020543
	v_fma_mix_f32 v72, v23, v57, neg(0) op_sel_hi:[1,0,0]       ; cc200048 8a027317
	v_fma_mix_f32 v23, v23, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a027317
	v_fma_mix_f32 v73, v24, v57, neg(0) op_sel_hi:[1,0,0]       ; cc200049 8a027318
	v_fma_mix_f32 v24, v24, v57, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200818 8a027318
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v68, v10, vcc_lo                      ; 02021544
	v_lshl_add_u32 v179, v179, 5, s32                           ; d64600b3 00810bb3
	v_lshl_add_u32 v187, v187, 5, s32                           ; d64600bb 00810bbb
	v_lshl_add_u32 v13, v13, 5, s32                             ; d646000d 00810b0d
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v69, v11, vcc_lo                      ; 02021745
	v_lshl_add_u32 v25, v25, 5, s32                             ; d6460019 00810b19
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v70, v21, vcc_lo                      ; 02022b46
	v_lshl_add_u32 v180, v180, 5, s32                           ; d64600b4 00810bb4
	v_lshl_add_u32 v188, v188, 5, s32                           ; d64600bc 00810bbc
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v71, v22, vcc_lo                      ; 02022d47
	v_lshl_add_u32 v18, v18, 5, s32                             ; d6460012 00810b12
	v_lshl_add_u32 v28, v28, 5, s32                             ; d646001c 00810b1c
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v72, v23, vcc_lo                      ; 02022f48
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v73, v24, vcc_lo                      ; 02023149
	v_lshl_add_u32 v181, v181, 5, s32                           ; d64600b5 00810bb5
	v_lshl_add_u32 v189, v189, 5, s32                           ; d64600bd 00810bbd
	v_lshl_add_u32 v19, v19, 5, s32                             ; d6460013 00810b13
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[179:180], v[187:188]            ; 1a0377b3
	v_lshl_add_u32 v29, v29, 5, s32                             ; d646001d 00810b1d
	v_lshl_add_u32 v182, v182, 5, s32                           ; d64600b6 00810bb6
	v_lshl_add_u32 v190, v190, 5, s32                           ; d64600be 00810bbe
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[180:181], v[188:189]            ; 1a0379b4
	v_lshl_add_u32 v20, v20, 5, s32                             ; d6460014 00810b14
	v_lshl_add_u32 v30, v30, 5, s32                             ; d646001e 00810b1e
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[181:182], v[189:190]            ; 1a037bb5
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[13:14]                ; 1a021b4a
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[182:183], v[190:191]            ; 1a037db6
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[18:19]                ; 1a02254b
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[19:20]                ; 1a02274c
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[25:26]                ; 1a02334a
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[20:21]                ; 1a02294d
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[28:29]                ; 1a02394b
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[29:30]                ; 1a023b4c
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[30:31]                ; 1a023d4d
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[75:76]                ; 1a02974a
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[76:77]                ; 1a02994a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[77:78]                ; 1a029b4a
	v_permlanex16_b32 v78, v74, s22, s23 op_sel:[1,1]           ; d65c184e 005c2d4a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[78:79]                ; 1a029d4a
	v_add_f16_e32 v79, v74, v202/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 649f954a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v79, 0x400, v79                           ; 629e9eff 00000400
	v_cvt_f32_f16_e32 v80, v79                                  ; 7ea0174f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v80, v80                                      ; 7ea05550
	v_fma_mix_f32 v81, v179, v80, neg(0) op_sel_hi:[1,0,0]      ; cc200051 8a02a1b3
	v_fma_mix_f32 v179, v179, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a02a1b3
	v_fma_mix_f32 v92, v20, v80, neg(0) op_sel_hi:[1,0,0]       ; cc20005c 8a02a114
	v_fma_mix_f32 v20, v20, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a02a114
	v_fma_mix_f32 v91, v19, v80, neg(0) op_sel_hi:[1,0,0]       ; cc20005b 8a02a113
	v_fma_mix_f32 v19, v19, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200813 8a02a113
	v_fma_mix_f32 v82, v180, v80, neg(0) op_sel_hi:[1,0,0]      ; cc200052 8a02a1b4
	v_fma_mix_f32 v83, v181, v80, neg(0) op_sel_hi:[1,0,0]      ; cc200053 8a02a1b5
	v_fma_mix_f32 v181, v181, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a02a1b5
	v_fma_mix_f32 v180, v180, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a02a1b4
	v_fma_mix_f32 v84, v182, v80, neg(0) op_sel_hi:[1,0,0]      ; cc200054 8a02a1b6
	v_fma_mix_f32 v182, v182, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a02a1b6
	v_fma_mix_f32 v85, v187, v80, neg(0) op_sel_hi:[1,0,0]      ; cc200055 8a02a1bb
	v_fma_mix_f32 v187, v187, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a02a1bb
	v_fma_mix_f32 v86, v188, v80, neg(0) op_sel_hi:[1,0,0]      ; cc200056 8a02a1bc
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v81, v179, vcc_lo                     ; 02036751
	v_fma_mix_f32 v188, v188, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a02a1bc
	v_fma_mix_f32 v87, v189, v80, neg(0) op_sel_hi:[1,0,0]      ; cc200057 8a02a1bd
	v_fma_mix_f32 v189, v189, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a02a1bd
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v91, v19, vcc_lo                      ; 0202275b
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v92, v20, vcc_lo                      ; 0202295c
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
	v_fma_mix_f32 v88, v190, v80, neg(0) op_sel_hi:[1,0,0]      ; cc200058 8a02a1be
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v83, v181, vcc_lo                     ; 02036b53
	v_fma_mix_f32 v190, v190, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a02a1be
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v82, v180, vcc_lo                     ; 02036952
	v_fma_mix_f32 v89, v13, v80, neg(0) op_sel_hi:[1,0,0]       ; cc200059 8a02a10d
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v84, v182, vcc_lo                     ; 02036d54
	v_fma_mix_f32 v13, v13, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080d 8a02a10d
	v_fma_mix_f32 v90, v18, v80, neg(0) op_sel_hi:[1,0,0]       ; cc20005a 8a02a112
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v85, v187, vcc_lo                     ; 02037755
	v_fma_mix_f32 v18, v18, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200812 8a02a112
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v86, v188, vcc_lo                     ; 02037956
	v_fma_mix_f32 v93, v25, v80, neg(0) op_sel_hi:[1,0,0]       ; cc20005d 8a02a119
	v_fma_mix_f32 v25, v25, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a02a119
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v87, v189, vcc_lo                     ; 02037b57
	v_fma_mix_f32 v94, v28, v80, neg(0) op_sel_hi:[1,0,0]       ; cc20005e 8a02a11c
	v_fma_mix_f32 v28, v28, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a02a11c
	v_fma_mix_f32 v95, v29, v80, neg(0) op_sel_hi:[1,0,0]       ; cc20005f 8a02a11d
	v_fma_mix_f32 v29, v29, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081d 8a02a11d
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v88, v190, vcc_lo                     ; 02037d58
	v_fma_mix_f32 v96, v30, v80, neg(0) op_sel_hi:[1,0,0]       ; cc200060 8a02a11e
	v_fma_mix_f32 v30, v30, v80, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081e 8a02a11e
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v89, v13, vcc_lo                      ; 02021b59
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[4:5], 0   ; cc464040 1a020914
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[20:21], v[22:23], 0 ; cc464048 1a022d14
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v90, v18, vcc_lo                      ; 0202255a
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v93, v25, vcc_lo                      ; 0202335d
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v94, v28, vcc_lo                      ; 0202395e
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v95, v29, vcc_lo                      ; 02023b5f
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v96, v30, vcc_lo                      ; 02023d60
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[16:17], v[64:71] ; cc464050 1d022120
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[6:7], v[16:17], v[64:71] ; cc464040 1d022106
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[38:39], v[72:79] ; cc464058 1d224d20
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[6:7], v[38:39], v[72:79] ; cc464048 1d224d06
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[36:37], v[80:87] ; cc464050 1d424914
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v25, v129, v41 :: v_dual_mul_f32 v24, v128, v40 ; c8c65381 19185180
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v29, v133, v45 :: v_dual_mul_f32 v28, v132, v44 ; c8c65b85 1d1c5984
	v_dual_mul_f32 v31, v135, v47 :: v_dual_mul_f32 v30, v134, v46 ; c8c65f87 1f1e5d86
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[36:37], v[64:71] ; cc464040 1d024914
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[56:57], v[88:95] ; cc464058 1d627114
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[20:21], v[56:57], v[72:79] ; cc464048 1d227114
	v_dual_mul_f32 v33, v145, v41 :: v_dual_mul_f32 v32, v144, v40 ; c8c65391 21205190
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[34:35], v[10:11], v[80:87] ; cc464050 1d421522
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[26:27], v[10:11], v[64:71] ; cc464040 1d02151a
	v_dual_mul_f32 v37, v149, v45 :: v_dual_mul_f32 v36, v148, v44 ; c8c65b95 25245994
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[34:35], v[18:19], v[88:95] ; cc464058 1d622522
	v_dual_mul_f32 v35, v147, v43 :: v_dual_mul_f32 v34, v146, v42 ; c8c65793 23225592
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[18:19], v[72:79] ; cc464048 1d22251a
	v_dual_mul_f32 v27, v131, v43 :: v_dual_mul_f32 v26, v130, v42 ; c8c65783 1b1a5582
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_dual_mul_f32 v39, v151, v47 :: v_dual_mul_f32 v38, v150, v46 ; c8c65f97 27265d96
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[8:9], v[4:5], v[24:31] ; cc464018 1c620908
	s_cmp_lg_i32 s28, 0                                         ; bf01801c
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[8:9], v[22:23], v[32:39] ; cc464020 1c822d08
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[14:15], v[6:7], v[24:31] ; cc464018 1c620d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[14:15], v[10:11], v[32:39] ; cc464020 1c82150e
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
	s_cbranch_scc1 BB52                                         ; bfa20007
BB50:
	v_add3_u32 v2, v3, s2, s14                                  ; d6550002 00380503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[8:9], v2, s[16:19], null offen           ; c406c07c 40802008 00000002
BB52:
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_lg_i32 s40, 0                                         ; bf018028
	s_cbranch_scc1 BB55                                         ; bfa20007
BB53:
	v_add3_u32 v2, v3, s2, s29                                  ; d6550002 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[8:9], v2, s[16:19], null offen           ; c406c07c 40802008 00000002
BB55:
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v0, s[24:27], null offen offset:64 ; c405c07c 40803010 00004000
	buffer_load_b128 v[24:27], v0, s[24:27], null offen offset:80 ; c405c07c 40803018 00005000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[8:9], v12, s[52:55], null offen offset:8  ; c405407c 40806808 0000080c
	buffer_load_b64 v[12:13], v12, s[52:55], null offen offset:520 ; c405407c 4080680c 0002080c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v33, v153, v17 :: v_dual_mul_f32 v32, v152, v16 ; c8c62399 21202198
	v_dual_mul_f32 v35, v155, v19 :: v_dual_mul_f32 v34, v154, v18 ; c8c6279b 2322259a
	v_dual_mul_f32 v41, v49, v17 :: v_dual_mul_f32 v40, v48, v16 ; c8c62331 29282130
	v_dual_mul_f32 v43, v51, v19 :: v_dual_mul_f32 v42, v50, v18 ; c8c62733 2b2a2532
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v37, v157, v25 :: v_dual_mul_f32 v36, v156, v24 ; c8c6339d 2524319c
	v_dual_mul_f32 v39, v159, v27 :: v_dual_mul_f32 v38, v158, v26 ; c8c6379f 2726359e
	v_dual_mul_f32 v45, v53, v25 :: v_dual_mul_f32 v44, v52, v24 ; c8c63335 2d2c3134
	v_dual_mul_f32 v47, v55, v27 :: v_dual_mul_f32 v46, v54, v26 ; c8c63737 2f2e3536
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[8:9], v[4:5], v[32:39] ; cc464020 1c820908
	s_mov_b32 s0, vcc_lo                                        ; be80006a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[8:9], v[22:23], v[40:47] ; cc464028 1ca22d08
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[12:13], v[6:7], v[32:39] ; cc464020 1c820d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[10:11], v[40:47] ; cc464028 1ca2150c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_cbranch_scc1 BB58                                         ; bfa20009
BB56:
	s_add_co_u32 s1, s2, 0x100                                  ; 8001ff02 00000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	v_add3_u32 v0, v3, s1, s14                                  ; d6550000 00380303
	v_add_nc_u32_e32 v0, v0, v1                                 ; 4a000300
	buffer_store_b64 v[4:5], v0, s[16:19], null offen           ; c406c07c 40802004 00000000
BB58:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB78                                         ; bfa20b42
BB59:
	s_addk_co_i32 s2, 0x100                                     ; b7820100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v3, v3, s2, s29                                  ; d6550003 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	buffer_store_b64 v[4:5], v3, s[16:19], null offen           ; c406c07c 40802004 00000003
	s_branch BB78                                               ; bfa00b38
BB62:
	s_mov_b32 s15, s1                                           ; be8f0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	s_load_b256 s[40:47], s[0:1], 0x30                          ; f4006a00 f8000030
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_max_i32 s13, s13, 0                                       ; 8a0d800d
	s_add_co_u32 s17, s11, -1                                   ; 8011c10b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s13, s13, s17                                     ; 890d110d
	s_max_i32 s14, s14, 0                                       ; 8a0e800e
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	s_min_i32 s14, s14, s12                                     ; 890e0c0e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s14, s14, s11                                     ; 960e0b0e
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_add_co_u32 s14, s14, s13                                  ; 800e0d0e
	s_lshl_b32 s14, s14, 9                                      ; 840e890e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s18, s15, s14                                  ; 80120e0f
	s_max_i32 s29, s29, 0                                       ; 8a1d801d
	v_add3_u32 v5, v3, s18, 0x100                               ; d6550005 03fc2503 00000100
	v_add3_u32 v4, v1, s18, v3                                  ; d6550004 040c2501
	s_min_i32 s29, s29, s12                                     ; 891d0c1d
	s_mul_i32 s29, s29, s11                                     ; 961d0b1d
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_add_co_u32 s29, s29, s13                                  ; 801d0d1d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s29, s29, 9                                      ; 841d891d
	s_add_co_u32 s15, s15, s29                                  ; 800f1d0f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a9
	v_add3_u32 v8, v1, s15, v3                                  ; d6550008 040c1f01
	v_add3_u32 v9, v3, s15, 0x100                               ; d6550009 03fc1f03 00000100
	v_add_nc_u32_e32 v9, v9, v1                                 ; 4a120309
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[6:7], v4, s[20:23], null offen            ; c405407c 40802806 00000004
	buffer_load_b64 v[4:5], v5, s[20:23], null offen            ; c405407c 40802804 00000005
	buffer_load_b64 v[10:11], v8, s[20:23], null offen          ; c405407c 4080280a 00000008
	buffer_load_b64 v[8:9], v9, s[20:23], null offen            ; c405407c 40802808 00000009
	v_lshlrev_b32_e32 v12, 2, v0                                ; 30180082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v13, s3, v12, 2                              ; d647000d 020a1803
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[16:19], v13, s[44:47], null offen        ; c405c07c 40805810 0000000d
	buffer_load_b128 v[20:23], v13, s[44:47], null offen offset:512 ; c405c07c 40805814 0002000d
	buffer_load_b128 v[24:27], v13, s[44:47], null offen offset:1024 ; c405c07c 40805818 0004000d
	buffer_load_b128 v[28:31], v13, s[44:47], null offen offset:1536 ; c405c07c 4080581c 0006000d
	buffer_load_b128 v[32:35], v13, s[44:47], null offen offset:2048 ; c405c07c 40805820 0008000d
	buffer_load_b128 v[36:39], v13, s[44:47], null offen offset:2560 ; c405c07c 40805824 000a000d
	buffer_load_b128 v[40:43], v13, s[44:47], null offen offset:3072 ; c405c07c 40805828 000c000d
	buffer_load_b128 v[44:47], v13, s[44:47], null offen offset:3584 ; c405c07c 4080582c 000e000d
	v_lshrrev_b32_e32 v0, 4, v0                                 ; 32000084
	s_mov_b64 s[36:37], s[40:41]                                ; bea40128
	s_mov_b64 s[38:39], s[42:43]                                ; bea6012a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshlrev_b32_e32 v0, 3, v0                                 ; 30000083
	v_add_lshl_u32 v14, s8, v0, 2                               ; d647000e 020a0008
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[48:51], v14, s[36:39], null offen        ; c405c07c 40804830 0000000e
	buffer_load_b128 v[52:55], v14, s[36:39], null offen offset:16 ; c405c07c 40804834 0000100e
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add_lshl_u32 v15, s4, v12, 2                              ; d647000f 020a1804
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[56:59], v15, s[44:47], null offen        ; c405c07c 40805838 0000000f
	buffer_load_b128 v[60:63], v15, s[44:47], null offen offset:512 ; c405c07c 4080583c 0002000f
	buffer_load_b128 v[64:67], v15, s[44:47], null offen offset:1024 ; c405c07c 40805840 0004000f
	buffer_load_b128 v[68:71], v15, s[44:47], null offen offset:1536 ; c405c07c 40805844 0006000f
	buffer_load_b128 v[72:75], v15, s[44:47], null offen offset:2048 ; c405c07c 40805848 0008000f
	buffer_load_b128 v[76:79], v15, s[44:47], null offen offset:2560 ; c405c07c 4080584c 000a000f
	buffer_load_b128 v[80:83], v15, s[44:47], null offen offset:3072 ; c405c07c 40805850 000c000f
	buffer_load_b128 v[84:87], v15, s[44:47], null offen offset:3584 ; c405c07c 40805854 000e000f
	s_wait_loadcnt 0x15                                         ; bfc00015
	v_cndmask_b32_e64 v6, v6, 0, s16                            ; d5010006 00410106
	v_cndmask_b32_e64 v7, v7, 0, s16                            ; d5010007 00410107
	s_wait_loadcnt 0x14                                         ; bfc00014
	v_cndmask_b32_e64 v4, v4, 0, s16                            ; d5010004 00410104
	v_cndmask_b32_e64 v5, v5, 0, s16                            ; d5010005 00410105
	s_wait_loadcnt 0x13                                         ; bfc00013
	v_cndmask_b32_e64 v10, v10, 0, s31                          ; d501000a 007d010a
	v_cndmask_b32_e64 v11, v11, 0, s31                          ; d501000b 007d010b
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v8, v8, 0, s31                            ; d5010008 007d0108
	v_cndmask_b32_e64 v9, v9, 0, s31                            ; d5010009 007d0109
	v_cvt_pk_f32_fp8_e32 v[92:93], v134                         ; 7eb8dd86
	v_cvt_pk_f32_fp8_e32 v[90:91], v6                           ; 7eb4dd06
	v_cvt_pk_f32_fp8_e32 v[94:95], v7                           ; 7ebcdd07
	v_dual_mov_b32 v89, v7 :: v_dual_mov_b32 v88, v6            ; ca100107 59580106
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	v_dual_mov_b32 v97, v5 :: v_dual_mov_b32 v96, v4            ; ca100105 61600104
	v_dual_mov_b32 v99, v11 :: v_dual_mov_b32 v98, v10          ; ca10010b 6362010a
	v_cvt_pk_f32_fp8_e32 v[100:101], v10                        ; 7ec8dd0a
	v_cvt_pk_f32_fp8_e32 v[102:103], v138                       ; 7eccdd8a
	v_cvt_pk_f32_fp8_e32 v[104:105], v11                        ; 7ed0dd0b
	v_dual_mov_b32 v107, v9 :: v_dual_mov_b32 v106, v8          ; ca100109 6b6a0108
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[88:89], 0 ; cc464070 1a02b110
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[88:89], 0 ; cc464080 1a02b112
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[98:99], 0 ; cc464078 1a02c510
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[98:99], 0 ; cc464088 1a02c512
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[96:97], v[112:119] ; cc464070 1dc2c114
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[20:21], v[106:107], v[120:127] ; cc464078 1de2d514
	v_maxmin_num_f32 v20, -4.0, v114, 4.0                       ; d6690014 03dae4f7
	v_maxmin_num_f32 v108, -4.0, v115, 4.0                      ; d669006c 03dae6f7
	v_maxmin_num_f32 v18, -4.0, v113, 4.0                       ; d6690012 03dae2f7
	v_maxmin_num_f32 v110, -4.0, v116, 4.0                      ; d669006e 03dae8f7
	v_maxmin_num_f32 v16, -4.0, v112, 4.0                       ; d6690010 03dae0f7
	v_fma_mix_f32 v21, 0xab28, |v20|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfe28ff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v19, 0xab28, |v18|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206213 0bfe24ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v17, 0xab28, |v16|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206211 0bfe20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_fmaak_f32 v109, v109, v108, 0x3f650000                    ; 5adad96d 3f650000
	v_dual_fmaak_f32 v19, v19, v18, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v17, 0x3f650000 ; c8422513 13102310 3f650000
	v_maxmin_num_f32 v144, -4.0, v121, 4.0                      ; d6690090 03daf2f7
	v_dual_mul_f32 v115, v109, v115 :: v_dual_fmaak_f32 v20, v20, v21, 0x3f650000 ; c8c2e76d 73142b14 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_mul_f32 v113, v113, v19 :: v_dual_mul_f32 v112, v112, v16 ; c8c62771 71702170
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v117, 4.0                      ; d6690070 03daeaf7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v123, 4.0                      ; d6690094 03daf6f7
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v122, 4.0                      ; d6690092 03daf4f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_mul_f32 v117, v117, v113 :: v_dual_mul_f32 v116, v116, v110 ; c8c6e375 7574dd74
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v125, 4.0                      ; d6690098 03dafaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v116, -4.0, v119, 4.0                      ; d6690074 03daeef7
	v_maxmin_num_f32 v150, -4.0, v124, 4.0                      ; d6690096 03daf8f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v127, 4.0                      ; d669009c 03dafef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v117, v116, v117, 0x3f650000 :: v_dual_mul_f32 v114, v114, v20 ; c846eb74 75722972 3f650000
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v126, 4.0                      ; d669009a 03dafcf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v118, 4.0                      ; d6690072 03daecf7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[96:97], v[128:135] ; cc464080 1e02c116
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v119, v119, v117 :: v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 ; c8c2eb77 7772e772 3f650000
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v118, v118, v114 ; c8472191 9176e576 3f650000
	v_maxmin_num_f32 v160, -4.0, v129, 4.0                      ; d66900a0 03db02f7
	v_maxmin_num_f32 v158, -4.0, v128, 4.0                      ; d669009e 03db00f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870253
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v120, 4.0                      ; d6690076 03daf0f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v131, 4.0                      ; d66900a4 03db06f7
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v130, 4.0                      ; d66900a2 03db04f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_mul_f32 v121, v121, v145 :: v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 ; c8c32379 7976ef76 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[106:107], v[136:143] ; cc464088 1e22d516
	v_maxmin_num_f32 v168, -4.0, v133, 4.0                      ; d66900a8 03db0af7
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v120, v120, v118 ; c8472995 9578ed78 3f650000
	v_maxmin_num_f32 v166, -4.0, v132, 4.0                      ; d66900a6 03db08f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d3
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v123, v123, v149 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8c32b7b 7b932792 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v135, 4.0                      ; d66900ac 03db0ef7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v122, v122, v146 ; c8473199 997b257a 3f650000
	v_maxmin_num_f32 v170, -4.0, v134, 4.0                      ; d66900aa 03db0cf7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v125, v125, v153 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8c3337d 7d972f96 3f650000
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v137, 4.0                      ; d66900b0 03db12f7
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v124, v124, v150 ; c847399d 9d7d2d7c 3f650000
	v_maxmin_num_f32 v174, -4.0, v136, 4.0                      ; d66900ae 03db10f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_dual_mul_f32 v127, v127, v157 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8c33b7f 7f9b379a 3f650000
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v139, 4.0                      ; d66900b4 03db16f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_mul_f32 v126, v126, v154 ; c84741a1 a17f357e 3f650000
	v_maxmin_num_f32 v178, -4.0, v138, 4.0                      ; d66900b2 03db14f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v129, v129, v161 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c8c34381 819f3f9e 3f650000
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v141, 4.0                      ; d66900b8 03db1af7
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_mul_f32 v128, v128, v158 ; c84749a5 a5813d80 3f650000
	v_maxmin_num_f32 v182, -4.0, v140, 4.0                      ; d66900b6 03db18f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v131, v131, v165 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8c34b83 83a347a2 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v143, 4.0                      ; d66900bc 03db1ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_mul_f32 v130, v130, v162 ; c84751a9 a9834582 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[88:89], 0 ; cc464070 1a02b118
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v133, v133, v169 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c8c35385 85a74fa6 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v132, v132, v166 ; c84759ad ad854d84 3f650000
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[96:97], v[112:119] ; cc464070 1dc2c11c
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v135, v135, v173 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8c35b87 87ab57aa 3f650000
	v_maxmin_num_f32 v186, -4.0, v142, 4.0                      ; d66900ba 03db1cf7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_mul_f32 v134, v134, v170 ; c84761b1 b1875586 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v112, 4.0                      ; d66900be 03dae0f7
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v137, v137, v177 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c8c36389 89af5fae 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[98:99], 0 ; cc464078 1a02c518
	v_maxmin_num_f32 v15, -4.0, v114, 4.0                       ; d669000f 03dae4f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v136, v136, v174 ; c84769b5 b5895d88 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v25, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe1eff 3728ab28
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_dual_mul_f32 v139, v139, v181 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c8c36b8b 8bb367b2 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[106:107], v[120:127] ; cc464078 1de2d51c
	v_maxmin_num_f32 v28, -4.0, v115, 4.0                       ; d669001c 03dae6f7
	v_fmaak_f32 v15, v15, v25, 0x3f650000                       ; 5a1e330f 3f650000
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_mul_f32 v138, v138, v178 ; c84771b9 b98b658a 3f650000
	v_maxmin_num_f32 v108, -4.0, v116, 4.0                      ; d669006c 03dae8f7
	v_maxmin_num_f32 v110, -4.0, v117, 4.0                      ; d669006e 03daeaf7
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v141, v141, v185 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c8c3738d 8db76fb6 3f650000
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v140, v140, v182 ; c84779bd bd8d6d8c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b8f 8fbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v113, 4.0                      ; d66900bf 03dae2f7
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v108 ; c8c6df75 7574d974
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 :: v_dual_mul_f32 v112, v112, v190 ; c846391d 1d717d70 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v115, v115, v29 :: v_dual_mul_f32 v114, v114, v15 ; c8c63b73 73721f72
	v_dual_fmaak_f32 v13, v191, v13, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8421bbf 0dbb77ba 3f650000
	v_maxmin_num_f32 v116, -4.0, v120, 4.0                      ; d6690074 03daf0f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v113, v113, v13 :: v_dual_mul_f32 v142, v142, v186 ; c8c61b71 718f758e
	v_maxmin_num_f32 v128, -4.0, v123, 4.0                      ; d6690080 03daf6f7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v118, 4.0                      ; d6690070 03daecf7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v119, 4.0                      ; d6690072 03daeef7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v125, 4.0                      ; d6690084 03dafaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v130, -4.0, v124, 4.0                      ; d6690082 03daf8f7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c8430181 8174eb74 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v127, 4.0                      ; d6690088 03dafef7
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_mul_f32 v123, v123, v129 :: v_dual_mul_f32 v120, v120, v116 ; c8c7037b 7b78e978
	v_maxmin_num_f32 v134, -4.0, v126, 4.0                      ; d6690086 03dafcf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v119, v119, v115 :: v_dual_mul_f32 v118, v118, v112 ; c8c6e777 7776e176
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8431189 89830782 3f650000
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v121, 4.0                      ; d6690076 03daf2f7
	v_dual_mul_f32 v127, v127, v137 :: v_dual_mul_f32 v124, v124, v130 ; c8c7137f 7f7d057c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fmaak_f32 v119, v119, v118, 0x3f650000                    ; 5aeeed77 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_mul_f32_e32 v121, v121, v119                              ; 10f2ef79
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[88:89], 0 ; cc464070 1a02b11a
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v122, 4.0                      ; d6690078 03daf4f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[96:97], v[112:119] ; cc464070 1dc2c11e
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8430985 8578f378 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v125, v125, v133 :: v_dual_mul_f32 v122, v122, v120 ; c8c70b7d 7d7af17a
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v140, -4.0, v113, 4.0                      ; d669008c 03dae2f7
	v_maxmin_num_f32 v142, -4.0, v114, 4.0                      ; d669008e 03dae4f7
	v_maxmin_num_f32 v144, -4.0, v115, 4.0                      ; d6690090 03dae6f7
	v_maxmin_num_f32 v138, -4.0, v112, 4.0                      ; d669008a 03dae0f7
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v148, -4.0, v117, 4.0                      ; d6690094 03daeaf7
	v_maxmin_num_f32 v146, -4.0, v116, 4.0                      ; d6690092 03dae8f7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v119, 4.0                      ; d6690098 03daeef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c843198d 8d870f86 3f650000
	v_maxmin_num_f32 v150, -4.0, v118, 4.0                      ; d6690096 03daecf7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c8432191 918b178a 3f650000
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432995 958f1f8e 3f650000
	v_dual_mul_f32 v113, v113, v141 :: v_dual_mul_f32 v126, v126, v134 ; c8c71b71 717f0d7e
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8433199 99932792 3f650000
	v_dual_mul_f32 v115, v115, v145 :: v_dual_mul_f32 v112, v112, v138 ; c8c72373 73711570
	v_dual_mul_f32 v117, v117, v149 :: v_dual_mul_f32 v114, v114, v142 ; c8c72b75 75731d72
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[98:99], 0 ; cc464078 1a02c51a
	v_dual_mul_f32 v119, v119, v153 :: v_dual_mul_f32 v116, v116, v146 ; c8c73377 77752574
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[106:107], v[120:127] ; cc464078 1de2d51e
	v_maxmin_num_f32 v156, -4.0, v121, 4.0                      ; d669009c 03daf2f7
	v_maxmin_num_f32 v160, -4.0, v123, 4.0                      ; d66900a0 03daf6f7
	v_maxmin_num_f32 v164, -4.0, v125, 4.0                      ; d66900a4 03dafaf7
	v_maxmin_num_f32 v158, -4.0, v122, 4.0                      ; d669009e 03daf4f7
	v_maxmin_num_f32 v154, -4.0, v120, 4.0                      ; d669009a 03daf0f7
	v_maxmin_num_f32 v162, -4.0, v124, 4.0                      ; d66900a2 03daf8f7
	v_maxmin_num_f32 v168, -4.0, v127, 4.0                      ; d66900a8 03dafef7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v126, 4.0                      ; d66900a6 03dafcf7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c843399d 9d972f96 3f650000
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84349a5 a59f3f9e 3f650000
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c84341a1 a19b379a 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84351a9 a9a347a2 3f650000
	v_dual_mul_f32 v121, v121, v157 :: v_dual_mul_f32 v118, v118, v150 ; c8c73b79 79772d76
	v_dual_mul_f32 v125, v125, v165 :: v_dual_mul_f32 v122, v122, v158 ; c8c74b7d 7d7b3d7a
	v_dual_mul_f32 v123, v123, v161 :: v_dual_mul_f32 v120, v120, v154 ; c8c7437b 7b793578
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v127, v127, v169 :: v_dual_mul_f32 v124, v124, v162 ; c8c7537f 7f7d457c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[88:89], 0 ; cc464070 1a02b120
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[96:97], v[112:119] ; cc464070 1dc2c124
	v_maxmin_num_f32 v174, -4.0, v114, 4.0                      ; d66900ae 03dae4f7
	v_maxmin_num_f32 v172, -4.0, v113, 4.0                      ; d66900ac 03dae2f7
	v_maxmin_num_f32 v180, -4.0, v117, 4.0                      ; d66900b4 03daeaf7
	v_maxmin_num_f32 v176, -4.0, v115, 4.0                      ; d66900b0 03dae6f7
	v_maxmin_num_f32 v170, -4.0, v112, 4.0                      ; d66900aa 03dae0f7
	v_maxmin_num_f32 v178, -4.0, v116, 4.0                      ; d66900b2 03dae8f7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v119, 4.0                      ; d66900b8 03daeef7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v118, 4.0                      ; d66900b6 03daecf7
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84359ad ada74fa6 3f650000
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84369b5 b5af5fae 3f650000
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84361b1 b1ab57aa 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_mul_f32 v113, v113, v173 :: v_dual_mul_f32 v126, v126, v166 ; c8c75b71 717f4d7e
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84371b9 b9b367b2 3f650000
	v_dual_mul_f32 v117, v117, v181 :: v_dual_mul_f32 v114, v114, v174 ; c8c76b75 75735d72
	v_dual_mul_f32 v115, v115, v177 :: v_dual_mul_f32 v112, v112, v170 ; c8c76373 73715570
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[98:99], 0 ; cc464078 1a02c520
	v_dual_mul_f32 v119, v119, v185 :: v_dual_mul_f32 v116, v116, v178 ; c8c77377 77756574
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[106:107], v[120:127] ; cc464078 1de2d524
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_maxmin_num_f32 v15, -4.0, v124, 4.0                       ; d669000f 03daf8f7
	v_maxmin_num_f32 v186, -4.0, v120, 4.0                      ; d66900ba 03daf0f7
	v_maxmin_num_f32 v190, -4.0, v122, 4.0                      ; d66900be 03daf4f7
	v_maxmin_num_f32 v188, -4.0, v121, 4.0                      ; d66900bc 03daf2f7
	v_maxmin_num_f32 v108, -4.0, v125, 4.0                      ; d669006c 03dafaf7
	v_fma_mix_f32 v37, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfe1eff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v126, 4.0                      ; d669006e 03dafcf7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v127, 4.0                      ; d6690070 03dafef7
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84379bd bdb76fb6 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_dual_mul_f32 v121, v121, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b79 79bf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v123, 4.0                      ; d66900bf 03daf6f7
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_mul_f32 v122, v122, v190 ; c846d96d 6d7b7d7a 3f650000
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	v_dual_mul_f32 v127, v127, v113 :: v_dual_mul_f32 v126, v126, v110 ; c8c6e37f 7f7edd7e
	v_dual_fmaak_f32 v13, v13, v191, 0x3f650000 :: v_dual_mul_f32 v118, v118, v182 ; c8477f0d 0d776d76 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_dual_mul_f32 v123, v123, v13 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8c21b7b 7bbb77ba 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[88:89], 0 ; cc464070 1a02b122
	v_dual_fmaak_f32 v15, v15, v37, 0x3f650000 :: v_dual_mul_f32 v120, v120, v186 ; c8464b0f 0f797578 3f650000
	v_dual_mul_f32 v125, v125, v109 :: v_dual_mul_f32 v124, v124, v15 ; c8c6db7d 7d7c1f7c
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[98:99], 0 ; cc464078 1a02c522
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[96:97], v[112:119] ; cc464070 1dc2c126
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[106:107], v[120:127] ; cc464078 1de2d526
	v_maxmin_num_f32 v130, -4.0, v113, 4.0                      ; d6690082 03dae2f7
	v_maxmin_num_f32 v138, -4.0, v117, 4.0                      ; d669008a 03daeaf7
	v_maxmin_num_f32 v136, -4.0, v116, 4.0                      ; d6690088 03dae8f7
	v_maxmin_num_f32 v134, -4.0, v115, 4.0                      ; d6690086 03dae6f7
	v_maxmin_num_f32 v132, -4.0, v114, 4.0                      ; d6690084 03dae4f7
	v_maxmin_num_f32 v128, -4.0, v112, 4.0                      ; d6690080 03dae0f7
	v_maxmin_num_f32 v140, -4.0, v118, 4.0                      ; d669008c 03daecf7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v119, 4.0                      ; d669008e 03daeef7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v120, 4.0                      ; d6690090 03daf0f7
	v_maxmin_num_f32 v146, -4.0, v121, 4.0                      ; d6690092 03daf2f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c843158b 8b891388 3f650000
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430d87 87850b84 3f650000
	v_maxmin_num_f32 v148, -4.0, v122, 4.0                      ; d6690094 03daf4f7
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430583 83810380 3f650000
	v_maxmin_num_f32 v150, -4.0, v123, 4.0                      ; d6690096 03daf6f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 ; c8431d8f 8f8d1b8c 3f650000
	v_dual_mul_f32 v117, v117, v139 :: v_dual_mul_f32 v116, v116, v136 ; c8c71775 75751174
	v_dual_mul_f32 v115, v115, v135 :: v_dual_mul_f32 v114, v114, v132 ; c8c70f73 73730972
	v_maxmin_num_f32 v152, -4.0, v124, 4.0                      ; d6690098 03daf8f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v125, 4.0                      ; d669009a 03dafaf7
	v_dual_mul_f32 v113, v113, v131 :: v_dual_mul_f32 v112, v112, v128 ; c8c70771 71710170
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_dual_mul_f32 v119, v119, v143 :: v_dual_mul_f32 v118, v118, v140 ; c8c71f77 77771976
	v_maxmin_num_f32 v156, -4.0, v126, 4.0                      ; d669009c 03dafcf7
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v158, -4.0, v127, 4.0                      ; d669009e 03dafef7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_mul_f32 v121, v121, v147 :: v_dual_mul_f32 v120, v120, v144 ; c8c72779 79792178
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[88:89], 0 ; cc464070 1a02b128
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_dual_mul_f32 v123, v123, v151 :: v_dual_mul_f32 v122, v122, v148 ; c8c72f7b 7b7b297a
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_dual_mul_f32 v125, v125, v155 :: v_dual_mul_f32 v124, v124, v152 ; c8c7377d 7d7d317c
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[96:97], v[112:119] ; cc464070 1dc2c12c
	v_dual_mul_f32 v127, v127, v159 :: v_dual_mul_f32 v126, v126, v156 ; c8c73f7f 7f7f397e
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[98:99], 0 ; cc464078 1a02c528
	v_maxmin_num_f32 v166, -4.0, v115, 4.0                      ; d66900a6 03dae6f7
	v_maxmin_num_f32 v168, -4.0, v116, 4.0                      ; d66900a8 03dae8f7
	v_maxmin_num_f32 v162, -4.0, v113, 4.0                      ; d66900a2 03dae2f7
	v_maxmin_num_f32 v164, -4.0, v114, 4.0                      ; d66900a4 03dae4f7
	v_maxmin_num_f32 v160, -4.0, v112, 4.0                      ; d66900a0 03dae0f7
	v_maxmin_num_f32 v170, -4.0, v117, 4.0                      ; d66900aa 03daeaf7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v118, 4.0                      ; d66900ac 03daecf7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	buffer_load_b128 v[108:111], v14, s[36:39], null offen offset:64 ; c405c07c 4080486c 0000400e
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v119, 4.0                      ; d66900ae 03daeef7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[106:107], v[120:127] ; cc464078 1de2d52c
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_mul_f32 v115, v115, v167 :: v_dual_mul_f32 v114, v114, v164 ; c8c74f73 73734972
	v_dual_mul_f32 v113, v113, v163 :: v_dual_mul_f32 v112, v112, v160 ; c8c74771 71714170
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	buffer_load_b128 v[112:115], v14, s[36:39], null offen offset:80 ; c405c07c 40804870 0000500e
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c84355ab aba953a8 3f650000
	v_maxmin_num_f32 v178, -4.0, v121, 4.0                      ; d66900b2 03daf2f7
	v_maxmin_num_f32 v176, -4.0, v120, 4.0                      ; d66900b0 03daf0f7
	v_maxmin_num_f32 v180, -4.0, v122, 4.0                      ; d66900b4 03daf4f7
	v_maxmin_num_f32 v182, -4.0, v123, 4.0                      ; d66900b6 03daf6f7
	v_maxmin_num_f32 v184, -4.0, v124, 4.0                      ; d66900b8 03daf8f7
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 ; c8435daf afad5bac 3f650000
	v_maxmin_num_f32 v186, -4.0, v125, 4.0                      ; d66900ba 03dafaf7
	v_dual_mul_f32 v117, v117, v171 :: v_dual_mul_f32 v116, v116, v168 ; c8c75775 75755174
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v126, 4.0                      ; d66900bc 03dafcf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v127, 4.0                      ; d66900be 03dafef7
	v_dual_mul_f32 v119, v119, v175 :: v_dual_mul_f32 v118, v118, v172 ; c8c75f77 77775976
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84365b3 b3b163b0 3f650000
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c8436db7 b7b56bb4 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84375bb bbb973b8 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[98:99], 0 ; cc464080 1a02c52a
	v_dual_mul_f32 v121, v121, v179 :: v_dual_mul_f32 v120, v120, v176 ; c8c76779 79796178
	v_dual_mul_f32 v123, v123, v183 :: v_dual_mul_f32 v122, v122, v180 ; c8c76f7b 7b7b697a
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8437dbf bfbd7bbc 3f650000
	v_dual_mul_f32 v125, v125, v187 :: v_dual_mul_f32 v124, v124, v184 ; c8c7777d 7d7d717c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_mul_f32 v127, v127, v191 :: v_dual_mul_f32 v126, v126, v188 ; c8c77f7f 7f7f797e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[106:107], v[128:135] ; cc464080 1e02d52e
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[88:89], 0 ; cc464078 1a02b12a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[96:97], v[120:127] ; cc464078 1de2c12e
	v_maxmin_num_f32 v46, -4.0, v123, 4.0                       ; d669002e 03daf6f7
	v_maxmin_num_f32 v44, -4.0, v122, 4.0                       ; d669002c 03daf4f7
	v_maxmin_num_f32 v42, -4.0, v121, 4.0                       ; d669002a 03daf2f7
	v_maxmin_num_f32 v191, -4.0, v120, 4.0                      ; d66900bf 03daf0f7
	v_maxmin_num_f32 v88, -4.0, v124, 4.0                       ; d6690058 03daf8f7
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_fma_mix_f32 v47, 0xab28, |v46|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622f 0bfe5cff 3728ab28
	v_fma_mix_f32 v45, 0xab28, |v44|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe58ff 3728ab28
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v96, s5, v12, 2                              ; d6470060 020a1805
	v_fma_mix_f32 v43, 0xab28, |v42|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622b 0bfe54ff 3728ab28
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v125, 4.0                       ; d6690061 03dafaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_fmaak_f32 v43, v43, v42, 0x3f650000 :: v_dual_fmaak_f32 v44, v44, v45, 0x3f650000 ; c842552b 2b2c5b2c 3f650000
	v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 :: v_dual_fmaak_f32 v47, v47, v46, 0x3f650000 ; c842b358 582e5d2f 3f650000
	v_dual_mul_f32 v122, v122, v44 :: v_dual_mul_f32 v121, v121, v43 ; c8c6597a 7a785779
	v_dual_mul_f32 v124, v124, v88 :: v_dual_mul_f32 v123, v123, v47 ; c8c6b17c 7c7a5f7b
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v96, s[44:47], null offen        ; c405c07c 4080582c 00000060
	buffer_load_b128 v[116:119], v96, s[44:47], null offen offset:1024 ; c405c07c 40805874 00040060
	v_fma_mix_f32 v13, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v191, v191, v13, 0x3f650000                     ; 5b7e1bbf 3f650000
	v_mul_f32_e32 v120, v120, v191                              ; 10f17f78
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870251
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v99, -4.0, v126, 4.0                       ; d6690063 03dafcf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v127, 4.0                      ; d669006b 03dafef7
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v106, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfec6ff 3728ab28
	v_fmaak_f32 v98, v98, v97, 0x3f650000                       ; 5ac4c362 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_fmaak_f32 v99, v99, v106, 0x3f650000                      ; 5ac6d563 3f650000
	v_maxmin_num_f32 v136, -4.0, v128, 4.0                      ; d6690088 03db00f7
	v_mul_f32_e32 v125, v125, v98                               ; 10fac57d
	v_mul_f32_e32 v126, v126, v99                               ; 10fcc77e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v124, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfed6ff 3728ab28
	v_fmaak_f32 v124, v124, v107, 0x3f650000                    ; 5af8d77c 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_mul_f32_e32 v127, v127, v124                              ; 10fef97f
	v_maxmin_num_f32 v138, -4.0, v129, 4.0                      ; d669008a 03db02f7
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[120:123], v96, s[44:47], null offen offset:2048 ; c405c07c 40805878 00080060
	buffer_load_b128 v[124:127], v96, s[44:47], null offen offset:512 ; c405c07c 4080587c 00020060
	buffer_load_b128 v[140:143], v96, s[44:47], null offen offset:1536 ; c405c07c 4080588c 00060060
	buffer_load_b128 v[96:99], v96, s[44:47], null offen offset:2560 ; c405c07c 40805860 000a0060
	v_maxmin_num_f32 v144, -4.0, v130, 4.0                      ; d6690090 03db04f7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v131, 4.0                      ; d6690092 03db06f7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v132, 4.0                      ; d6690094 03db08f7
	v_maxmin_num_f32 v150, -4.0, v133, 4.0                      ; d6690096 03db0af7
	v_maxmin_num_f32 v152, -4.0, v134, 4.0                      ; d6690098 03db0cf7
	v_maxmin_num_f32 v154, -4.0, v135, 4.0                      ; d669009a 03db0ef7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fmaak_f32 v136, v136, v137, 0x3f650000                    ; 5b111388 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fmaak_f32 v144, v144, v145, 0x3f650000                    ; 5b212390 3f650000
	v_dual_mul_f32 v128, v128, v136 :: v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 ; c8c31180 808b158b 3f650000
	v_fmaak_f32 v147, v147, v146, 0x3f650000                    ; 5b272593 3f650000
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v130, v130, v144 :: v_dual_mul_f32 v129, v129, v139 ; c8c72182 82811781
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_dual_mul_f32 v145, v101, v49 :: v_dual_mul_f32 v144, v100, v48 ; c8c66365 91906164
	v_mul_f32_e32 v131, v131, v147                              ; 11072783
	v_dual_mul_f32 v147, v103, v51 :: v_dual_mul_f32 v146, v102, v50 ; c8c66767 93926566
	v_dual_mul_f32 v133, v133, v151 :: v_dual_mul_f32 v132, v132, v148 ; c8c72f85 85852984
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_mul_f32 v149, v105, v53 :: v_dual_mul_f32 v148, v104, v52 ; c8c66b69 95946968
	v_dual_mul_f32 v151, v11, v55 :: v_dual_mul_f32 v150, v10, v54 ; c8c66f0b 97966d0a
	v_dual_mul_f32 v135, v135, v155 :: v_dual_mul_f32 v134, v134, v152 ; c8c73787 87873186
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_dual_mul_f32 v129, v91, v49 :: v_dual_mul_f32 v128, v90, v48 ; c8c6635b 8180615a
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[18:19], v[144:151] ; cc464090 1e422538
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v131, v93, v51 :: v_dual_mul_f32 v130, v92, v50 ; c8c6675d 8382655c
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	s_bitset0_b32 s41, 14                                       ; bea9108e
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_buffer_load_b32 s10, s[40:43], s10 offset:0x0             ; f4020294 14000000
	v_dual_mul_f32 v133, v95, v53 :: v_dual_mul_f32 v132, v94, v52 ; c8c66b5f 8584695e
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v135, v7, v55 :: v_dual_mul_f32 v134, v6, v54 ; c8c66f07 87866d06
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[16:17], v[128:135] ; cc464080 1e022138
	v_cvt_pk_f32_fp8_e32 v[48:49], v4                           ; 7e60dd04
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[22:23], v[144:151] ; cc464090 1e422d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[20:21], v[128:135] ; cc464080 1e02293c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[64:65], v[28:29], v[144:151] ; cc464090 1e423940
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[64:65], v[24:25], v[128:135] ; cc464080 1e023140
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[30:31], v[144:151] ; cc464090 1e423d44
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mul_f32 v153, v49, v109 :: v_dual_mul_f32 v152, v48, v108 ; c8c6db31 9998d930
	v_cvt_pk_f32_fp8_e32 v[48:49], v132                         ; 7e60dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[26:27], v[128:135] ; cc464080 1e023544
	v_dual_mul_f32 v155, v49, v111 :: v_dual_mul_f32 v154, v48, v110 ; c8c6df31 9b9add30
	v_cvt_pk_f32_fp8_e32 v[48:49], v5                           ; 7e60dd05
	v_cvt_pk_f32_fp8_e32 v[4:5], v133                           ; 7e08dd85
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[36:37], v[144:151] ; cc464090 1e424948
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[32:33], v[128:135] ; cc464080 1e024148
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v159, v5, v115 :: v_dual_mul_f32 v158, v4, v114 ; c8c6e705 9f9ee504
	v_cvt_pk_f32_fp8_e32 v[4:5], v8                             ; 7e08dd08
	v_dual_mul_f32 v157, v49, v113 :: v_dual_mul_f32 v156, v48, v112 ; c8c6e331 9d9ce130
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[76:77], v[38:39], v[144:151] ; cc464090 1e424d4c
	v_dual_mul_f32 v49, v5, v109 :: v_dual_mul_f32 v48, v4, v108 ; c8c6db05 3130d904
	v_cvt_pk_f32_fp8_e32 v[4:5], v136                           ; 7e08dd88
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[34:35], v[128:135] ; cc464080 1e02454c
	v_dual_mul_f32 v51, v5, v111 :: v_dual_mul_f32 v50, v4, v110 ; c8c6df05 3332dd04
	v_cvt_pk_f32_fp8_e32 v[4:5], v9                             ; 7e08dd09
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[80:81], v[14:15], v[144:151] ; cc464090 1e421d50
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[16:17], v[152:159] ; cc464098 1e62213a
	v_dual_mul_f32 v53, v5, v113 :: v_dual_mul_f32 v52, v4, v112 ; c8c6e305 3534e104
	v_cvt_pk_f32_fp8_e32 v[4:5], v137                           ; 7e08dd89
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[40:41], v[128:135] ; cc464080 1e025150
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[88:89], v[144:151] ; cc464090 1e42b154
	v_dual_mul_f32 v55, v5, v115 :: v_dual_mul_f32 v54, v4, v114 ; c8c6e705 3736e504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[58:59], v[18:19], v[48:55] ; cc464030 1cc2253a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[62:63], v[20:21], v[152:159] ; cc464098 1e62293e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[42:43], v[128:135] ; cc464080 1e025554
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[62:63], v[22:23], v[48:55] ; cc464030 1cc22d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[24:25], v[152:159] ; cc464098 1e623142
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[66:67], v[28:29], v[48:55] ; cc464030 1cc23942
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[70:71], v[26:27], v[152:159] ; cc464098 1e623546
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[118:119], v[6:7], 0 ; cc464038 1a020d76
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[70:71], v[30:31], v[48:55] ; cc464030 1cc23d46
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[46:47], v[6:7], 0   ; cc464018 1a020d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[74:75], v[32:33], v[152:159] ; cc464098 1e62414a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[6:7], 0   ; cc464010 1a020d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[74:75], v[36:37], v[48:55] ; cc464030 1cc2494a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[78:79], v[34:35], v[152:159] ; cc464098 1e62454e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[78:79], v[38:39], v[48:55] ; cc464030 1cc24d4e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[116:117], v[6:7], 0 ; cc464020 1a020d74
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[82:83], v[40:41], v[152:159] ; cc464098 1e625152
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[82:83], v[14:15], v[48:55] ; cc464030 1cc21d52
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[42:43], v[152:159] ; cc464098 1e625556
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[86:87], v[88:89], v[48:55] ; cc464030 1cc2b156
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[6:7], v[120:121], 0 ; cc464040 1a02f106
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[6:7], v[122:123], 0 ; cc464048 1a02f506
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[126:127], v[4:5], v[24:31] ; cc464018 1c62097e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[140:141], v[4:5], v[32:39] ; cc464020 1c82098c
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[142:143], v[4:5], v[56:63] ; cc464038 1ce2098e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[124:125], v[4:5], v[16:23] ; cc464010 1c42097c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[4:5], v[96:97], v[64:71] ; cc464040 1d02c104
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[4:5], v[98:99], v[72:79] ; cc464048 1d22c504
	v_dual_mul_f32 v163, v59, v59 :: v_dual_mul_f32 v160, v25, v25 ; c8c6773b a3a03319
	v_dual_mul_f32 v162, v27, v27 :: v_dual_mul_f32 v161, v57, v57 ; c8c6371b a2a07339
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_dual_fmac_f32 v163, v35, v35 :: v_dual_fmac_f32 v160, v17, v17 ; c8004723 a3a02311
	s_mov_b32 s19, 0x76543210                                   ; be9300ff 76543210
	v_dual_fmac_f32 v162, v19, v19 :: v_dual_fmac_f32 v161, v33, v33 ; c8002713 a2a04321
	s_mov_b32 s24, 0xfedcba98                                   ; be9800ff fedcba98
	v_dual_fmac_f32 v163, v39, v39 :: v_dual_fmac_f32 v160, v21, v21 ; c8004f27 a3a02b15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v23, v23 :: v_dual_fmac_f32 v161, v37, v37 ; c8002f17 a2a04b25
	v_dual_fmac_f32 v163, v63, v63 :: v_dual_fmac_f32 v160, v29, v29 ; c8007f3f a3a03b1d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v162, v31, v31 :: v_dual_fmac_f32 v161, v61, v61 ; c8003f1f a2a07b3d
	v_dual_fmac_f32 v163, v34, v34 :: v_dual_fmac_f32 v160, v16, v16 ; c8004522 a3a02110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v32, v32 :: v_dual_fmac_f32 v162, v18, v18 ; c8004120 a1a22512
	v_dual_fmac_f32 v163, v58, v58 :: v_dual_fmac_f32 v160, v24, v24 ; c800753a a3a03118
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v56, v56 :: v_dual_fmac_f32 v162, v26, v26 ; c8007138 a1a2351a
	v_dual_fmac_f32 v163, v38, v38 :: v_dual_fmac_f32 v160, v20, v20 ; c8004d26 a3a02914
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v161, v36, v36 :: v_dual_fmac_f32 v162, v22, v22 ; c8004924 a1a22d16
	v_dual_fmac_f32 v163, v62, v62 :: v_dual_fmac_f32 v160, v28, v28 ; c8007d3e a3a0391c
	v_lshl_add_u32 v167, v2, 5, v1                              ; d64600a7 04050b02
	v_lshl_add_u32 v2, v2, 6, s7                                ; d6460002 001d0d02
	v_dual_fmac_f32 v161, v60, v60 :: v_dual_fmac_f32 v162, v30, v30 ; c800793c a1a23d1e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
	v_fma_mixlo_f16 v164, 1.0, v160, v162                       ; cc2100a4 068b40f2
	v_fma_mixhi_f16 v164, 1.0, v161, v163                       ; cc2200a4 068f42f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_permlanex16_b32 v165, v164, s19, s24 op_sel:[1,1]         ; d65c18a5 006027a4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00a4
	v_min_num_f64_e32 v[1:2], v[164:165], v[165:166]            ; 1a034ba4
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v255                             ; 0a01ffa4
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00a6
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
	v_rsq_f32_e32 v166, v166                                    ; 7f4c5da6
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v166, s10, v166                               ; 114d4c0a
	v_dual_mul_f32 v19, v19, v166 :: v_dual_mul_f32 v18, v18, v166 ; c8c74d13 13134d12
	v_dual_mul_f32 v17, v17, v166 :: v_dual_mul_f32 v16, v16, v166 ; c8c74d11 11114d10
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v2, s[36:39], null offen         ; c405c07c 40804810 00000002
	buffer_load_b128 v[40:43], v2, s[36:39], null offen offset:16 ; c405c07c 40804828 00001002
(invalid instruction)                                        ; d58b08a4
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
	v_mul_f32_e32 v22, v22, v166                                ; 102d4d16
	v_mul_f32_e32 v23, v23, v166                                ; 102f4d17
	v_dual_mul_f32 v21, v21, v166 :: v_dual_mul_f32 v20, v20, v166 ; c8c74d15 15154d14
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_rsq_f32_e32 v164, v164                                    ; 7f485da4
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a5
	v_dual_mul_f32 v35, v35, v164 :: v_dual_mul_f32 v34, v34, v164 ; c8c74923 23234922
	v_dual_mul_f32 v33, v33, v164 :: v_dual_mul_f32 v32, v32, v164 ; c8c74921 21214920
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v2, s[36:39], null offen offset:8192 ; c405c07c 40804814 00200002
	buffer_load_b128 v[32:35], v2, s[36:39], null offen offset:8208 ; c405c07c 40804820 00201002
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mul_f32_e32 v24, v24, v166                                ; 10314d18
	v_dual_mul_f32 v26, v26, v166 :: v_dual_mul_f32 v25, v25, v166 ; c8c74d1a 1a194d19
	v_dual_mul_f32 v28, v28, v166 :: v_dual_mul_f32 v27, v27, v166 ; c8c74d1c 1c1b4d1b
	v_dual_mul_f32 v30, v30, v166 :: v_dual_mul_f32 v29, v29, v166 ; c8c74d1e 1e1d4d1d
	v_dual_mul_f32 v37, v37, v164 :: v_dual_mul_f32 v36, v36, v164 ; c8c74925 25254924
	v_dual_mul_f32 v39, v39, v164 :: v_dual_mul_f32 v38, v38, v164 ; c8c74927 27274926
	v_dual_mul_f32 v56, v56, v164 :: v_dual_mul_f32 v31, v31, v166 ; c8c74938 381f4d1f
	v_dual_mul_f32 v58, v58, v164 :: v_dual_mul_f32 v57, v57, v164 ; c8c7493a 3a394939
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v2, s[36:39], null offen offset:64 ; c405c07c 4080481c 00004002
	buffer_load_b128 v[36:39], v2, s[36:39], null offen offset:80 ; c405c07c 40804824 00005002
	v_dual_mul_f32 v60, v60, v164 :: v_dual_mul_f32 v59, v59, v164 ; c8c7493c 3c3b493b
	v_dual_mul_f32 v62, v62, v164 :: v_dual_mul_f32 v61, v61, v164 ; c8c7493e 3e3d493d
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mul_f32_e32 v63, v63, v164                                ; 107f493f
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v167, v[6:7], v[26:27] offset1:2         ; d9380200 001a06a7
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v167, v[26:27], v[26:27] offset0:64 offset1:66 ; d9384240 001a1aa7
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[10:11], 0 ; cc464038 1a02152c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[10:11], 0 ; cc464040 1a02152e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[44:47], v2, s[36:39], null offen offset:8256 ; c405c07c 4080482c 00204002
	buffer_load_b128 v[100:103], v2, s[36:39], null offen offset:8272 ; c405c07c 40804864 00205002
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[116:117], v[10:11], 0 ; cc464048 1a021574
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[118:119], v[10:11], 0 ; cc464050 1a021576
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[10:11], v[120:121], 0 ; cc464058 1a02f10a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[122:123], 0 ; cc464068 1a02f50a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[124:125], v[8:9], v[56:63] ; cc464038 1ce2117c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[126:127], v[8:9], v[64:71] ; cc464040 1d02117e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[140:141], v[8:9], v[72:79] ; cc464048 1d22118c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[142:143], v[8:9], v[80:87] ; cc464050 1d42118e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[96:97], v[88:95] ; cc464058 1d62c108
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[98:99], v[104:111] ; cc464068 1da2c508
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v2, s[36:39], null offen offset:128 ; c405c07c 40804808 00008002
	buffer_load_b128 v[96:99], v2, s[36:39], null offen offset:144 ; c405c07c 40804860 00009002
	v_mul_f32_e32 v168, v65, v65                                ; 11508341
	v_mul_f32_e32 v169, v81, v81                                ; 1152a351
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v171, v83, v83 :: v_dual_fmac_f32 v168, v57, v57 ; c8c0a753 aba87339
	v_dual_mul_f32 v170, v67, v67 :: v_dual_fmac_f32 v169, v73, v73 ; c8c08743 aaa89349
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[112:115], v2, s[36:39], null offen offset:8320 ; c405c07c 40804870 00208002
	buffer_load_b128 v[116:119], v2, s[36:39], null offen offset:8336 ; c405c07c 40804874 00209002
	v_dual_fmac_f32 v168, v61, v61 :: v_dual_fmac_f32 v171, v75, v75 ; c8007b3d a8aa974b
	v_dual_fmac_f32 v169, v77, v77 :: v_dual_fmac_f32 v170, v59, v59 ; c8009b4d a9aa773b
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v171, v79, v79 :: v_dual_fmac_f32 v168, v69, v69 ; c8009f4f aba88b45
	v_dual_fmac_f32 v170, v63, v63 :: v_dual_fmac_f32 v169, v85, v85 ; c8007f3f aaa8ab55
	v_dual_fmac_f32 v168, v56, v56 :: v_dual_fmac_f32 v171, v87, v87 ; c8007138 a8aaaf57
	v_fmac_f32_e32 v170, v71, v71                               ; 57548f47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v171, v74, v74 :: v_dual_fmac_f32 v168, v64, v64 ; c800954a aba88140
	v_dual_fmac_f32 v169, v72, v72 :: v_dual_fmac_f32 v170, v58, v58 ; c8009148 a9aa753a
	v_dual_fmac_f32 v171, v82, v82 :: v_dual_fmac_f32 v168, v60, v60 ; c800a552 aba8793c
	v_dual_fmac_f32 v169, v80, v80 :: v_dual_fmac_f32 v170, v66, v66 ; c800a150 a9aa8542
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v171, v78, v78 :: v_dual_fmac_f32 v168, v68, v68 ; c8009d4e aba88944
	v_dual_fmac_f32 v169, v76, v76 :: v_dual_fmac_f32 v170, v62, v62 ; c800994c a9aa7d3e
	v_fmac_f32_e32 v171, v86, v86                               ; 5756ad56
	v_dual_fmac_f32 v169, v84, v84 :: v_dual_fmac_f32 v170, v70, v70 ; c800a954 a9aa8d46
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v172, 1.0, v168, v170                       ; cc2100ac 06ab50f2
	v_fma_mixhi_f16 v172, 1.0, v169, v171                       ; cc2200ac 06af52f2
	v_permlanex16_b32 v173, v172, s19, s24 op_sel:[1,1]         ; d65c18ad 006027ac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[173:174]            ; 1a035bac
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v255                             ; 0a01ffac
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
(invalid instruction)                                        ; d58b08ac
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	v_rsq_f32_e32 v174, v174                                    ; 7f5c5dae
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v174, s10, v174                               ; 115d5c0a
	v_dual_mul_f32 v60, v60, v174 :: v_dual_mul_f32 v61, v61, v174 ; c8c75d3c 3c3d5d3d
	v_dual_mul_f32 v56, v56, v174 :: v_dual_mul_f32 v57, v57, v174 ; c8c75d38 38395d39
	v_dual_mul_f32 v62, v62, v174 :: v_dual_mul_f32 v63, v63, v174 ; c8c75d3e 3e3f5d3f
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v2, s[36:39], null offen offset:192 ; c405c07c 4080483c 0000c002
	buffer_load_b128 v[120:123], v2, s[36:39], null offen offset:208 ; c405c07c 40804878 0000d002
	v_rsq_f32_e32 v172, v172                                    ; 7f585dac
	v_dual_mul_f32 v58, v58, v174 :: v_dual_mul_f32 v59, v59, v174 ; c8c75d3a 3a3b5d3b
	v_dual_mul_f32 v65, v65, v174 :: v_dual_mul_f32 v64, v64, v174 ; c8c75d41 41415d40
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d2
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	v_mul_f32_e32 v66, v66, v174                                ; 10855d42
	v_dual_mul_f32 v72, v72, v172 :: v_dual_mul_f32 v73, v73, v172 ; c8c75948 48495949
	v_dual_mul_f32 v79, v79, v172 :: v_dual_mul_f32 v78, v78, v172 ; c8c7594f 4f4f594e
	v_dual_mul_f32 v77, v77, v172 :: v_dual_mul_f32 v76, v76, v172 ; c8c7594d 4d4d594c
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[76:79], v2, s[36:39], null offen offset:8384 ; c405c07c 4080484c 0020c002
	buffer_load_b128 v[88:91], v2, s[36:39], null offen offset:8400 ; c405c07c 40804858 0020d002
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_mul_f32_e32 v67, v67, v174                                ; 10875d43
	v_dual_mul_f32 v75, v75, v172 :: v_dual_mul_f32 v74, v74, v172 ; c8c7594b 4b4b594a
	v_dual_mul_f32 v69, v69, v174 :: v_dual_mul_f32 v68, v68, v174 ; c8c75d45 45455d44
	v_dual_mul_f32 v71, v71, v174 :: v_dual_mul_f32 v70, v70, v174 ; c8c75d47 47475d46
	v_dual_mul_f32 v81, v81, v172 :: v_dual_mul_f32 v80, v80, v172 ; c8c75951 51515950
	v_dual_mul_f32 v83, v83, v172 :: v_dual_mul_f32 v82, v82, v172 ; c8c75953 53535952
	v_dual_mul_f32 v85, v85, v172 :: v_dual_mul_f32 v84, v84, v172 ; c8c75955 55555954
	v_dual_mul_f32 v87, v87, v172 :: v_dual_mul_f32 v86, v86, v172 ; c8c75957 57575956
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v167, v[58:59], v[66:67] offset0:128 offset1:130 ; d9388280 00423aa7
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v167, v[26:27], v[26:27] offset0:192 offset1:194 ; d938c2c0 001a1aa7
	ds_load_b64 v[26:27], v167                                  ; d9d80000 1a0000a7
	ds_load_b64 v[66:67], v167 offset:16                        ; d9d80010 420000a7
	s_mov_b32 s25, 0x3d380000                                   ; be9900ff 3d380000
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[56:57], 0 ; cc464068 1a02711a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[26:27], v[4:5], 0   ; cc464050 1a02091a
	s_wait_dscnt 0x0                                            ; bfc60000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[66:67], v[24:25], v[80:87] ; cc464050 1d423142
	s_wait_loadcnt 0xf                                          ; bfc0000f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_mixlo_f16 v175, s25, v80, v16                         ; cc2100af 0442a019
	v_fma_mixhi_f16 v175, s25, v81, v17                         ; cc2200af 0446a219
	ds_load_b64 v[16:17], v167 offset:512                       ; d9d80200 100000a7
	ds_load_b64 v[26:27], v167 offset:528                       ; d9d80210 1a0000a7
	s_movk_i32 s26, 0x3c20                                      ; b01a3c20
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[66:67], v[64:65], v[104:111] ; cc464068 1da28142
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_fma_mixlo_f16 v178, s25, v86, v42                         ; cc2100b2 04aaac19
	v_fma_mixlo_f16 v177, s25, v84, v40                         ; cc2100b1 04a2a819
	v_fma_mixhi_f16 v178, s25, v87, v43                         ; cc2200b2 04aeae19
	v_fma_mixhi_f16 v177, s25, v85, v41                         ; cc2200b1 04a6aa19
	v_fma_mixlo_f16 v176, s25, v82, v18                         ; cc2100b0 044aa419
	v_fma_mixhi_f16 v176, s25, v83, v19                         ; cc2200b0 044ea619
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v26                              ; 0a0035af
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v26                              ; 0a0035b2
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v26                              ; 0a0035b1
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[4:5], 0   ; cc464050 1a020910
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v26                              ; 0a0035b0
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v181, s25, v108, v32                        ; cc2100b5 0482d819
	v_fma_mixlo_f16 v179, s25, v104, v20                        ; cc2100b3 0452d019
	v_fma_mixhi_f16 v179, s25, v105, v21                        ; cc2200b3 0456d219
	v_fma_mixlo_f16 v180, s25, v106, v22                        ; cc2100b4 045ad419
	v_fma_mixhi_f16 v181, s25, v109, v33                        ; cc2200b5 0486da19
	v_fma_mixlo_f16 v182, s25, v110, v34                        ; cc2100b6 048adc19
	v_fma_mixhi_f16 v180, s25, v107, v23                        ; cc2200b4 045ed619
	v_fma_mixhi_f16 v182, s25, v111, v35                        ; cc2200b6 048ede19
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[56:57], 0 ; cc464068 1a027110
	ds_load_b64 v[16:17], v167 offset:1024                      ; d9d80400 100000a7
	ds_load_b64 v[18:19], v167 offset:1040                      ; d9d80410 120000a7
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v26                              ; 0a0035b3
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v26                              ; 0a0035b5
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[26:27], v[24:25], v[80:87] ; cc464050 1d42311a
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v26                              ; 0a0035b4
(invalid instruction)                                        ; cc1c00b6
	v_subrev_f32_e32 v0, v182, v26                              ; 0a0035b6
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[64:65], v[104:111] ; cc464068 1da2811a
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v183, s25, v80, v28                         ; cc2100b7 0472a019
	v_fma_mixhi_f16 v183, s25, v81, v29                         ; cc2200b7 0476a219
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v186, s25, v86, v38                         ; cc2100ba 049aac19
	v_fma_mixhi_f16 v186, s25, v87, v39                         ; cc2200ba 049eae19
	v_fma_mixlo_f16 v184, s25, v82, v30                         ; cc2100b8 047aa419
	v_fma_mixhi_f16 v184, s25, v83, v31                         ; cc2200b8 047ea619
	v_fma_mixlo_f16 v185, s25, v84, v36                         ; cc2100b9 0492a819
	v_fma_mixhi_f16 v185, s25, v85, v37                         ; cc2200b9 0496aa19
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v26                              ; 0a0035b7
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[4:5], 0   ; cc464020 1a020910
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v26                              ; 0a0035ba
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v188, s25, v106, v46                        ; cc2100bc 04bad419
	v_fma_mixhi_f16 v188, s25, v107, v47                        ; cc2200bc 04bed619
	v_fma_mixlo_f16 v187, s25, v104, v44                        ; cc2100bb 04b2d019
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v189, s25, v108, v100                       ; cc2100bd 0592d819
	v_fma_mixhi_f16 v189, s25, v109, v101                       ; cc2200bd 0596da19
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[18:19], v[24:25], v[32:39] ; cc464020 1c823112
	v_fma_mixhi_f16 v187, s25, v105, v45                        ; cc2200bb 04b6d219
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[56:57], 0 ; cc464028 1a027110
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v191, s25, v32, v8                          ; cc2100bf 04224019
	v_fma_mixhi_f16 v191, s25, v33, v9                          ; cc2200bf 04264219
	ds_load_b64 v[8:9], v167 offset:1536                        ; d9d80600 080000a7
	ds_load_b64 v[16:17], v167 offset:1552                      ; d9d80610 100000a7
	v_fma_mixlo_f16 v190, s25, v110, v102                       ; cc2100be 059adc19
	v_fma_mixhi_f16 v190, s25, v111, v103                       ; cc2200be 059ede19
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v26                              ; 0a0035b8
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v26                              ; 0a0035b9
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v26                              ; 0a0035bc
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v26                              ; 0a0035bd
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v26                              ; 0a0035bb
	v_fma_mixlo_f16 v2, s25, v34, v10                           ; cc210002 042a4419
	v_fma_mixhi_f16 v2, s25, v35, v11                           ; cc220002 042e4619
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v10, s25, v36, v96                          ; cc21000a 05824819
	v_fma_mixhi_f16 v10, s25, v37, v97                          ; cc22000a 05864a19
	v_fma_mixlo_f16 v11, s25, v38, v98                          ; cc21000b 058a4c19
	v_fma_mixhi_f16 v11, s25, v39, v99                          ; cc22000b 058e4e19
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v26                              ; 0a0035bf
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[64:65], v[40:47] ; cc464028 1ca28112
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v26                              ; 0a0035be
(invalid instruction)                                        ; cc1c0002
	v_subrev_f32_e32 v0, v2, v26                                ; 0a003502
(invalid instruction)                                        ; cc1c000a
	v_subrev_f32_e32 v0, v10, v26                               ; 0a00350a
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v26                               ; 0a00350b
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[8:9], v[4:5], 0     ; cc464020 1a020908
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v19, s25, v44, v116                         ; cc210013 05d25819
	v_fma_mixlo_f16 v13, s25, v40, v112                         ; cc21000d 05c25019
	v_fma_mixhi_f16 v13, s25, v41, v113                         ; cc22000d 05c65219
	v_fma_mixhi_f16 v19, s25, v45, v117                         ; cc220013 05d65a19
	v_fma_mixlo_f16 v18, s25, v42, v114                         ; cc210012 05ca5419
	v_fma_mixhi_f16 v18, s25, v43, v115                         ; cc220012 05ce5619
	v_fma_mixlo_f16 v20, s25, v46, v118                         ; cc210014 05da5c19
	v_fma_mixhi_f16 v20, s25, v47, v119                         ; cc220014 05de5e19
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[8:9], v[56:57], 0   ; cc464028 1a027108
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v26                               ; 0a00350d
(invalid instruction)                                        ; cc1c0013
	v_subrev_f32_e32 v0, v19, v26                               ; 0a003513
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v26                               ; 0a003512
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[24:25], v[32:39] ; cc464020 1c823110
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v26                               ; 0a003514
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[64:65], v[40:47] ; cc464028 1ca28110
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v24, s25, v38, v122                         ; cc210018 05ea4c19
	v_fma_mixlo_f16 v22, s25, v34, v62                          ; cc210016 04fa4419
	v_fma_mixhi_f16 v22, s25, v35, v63                          ; cc220016 04fe4619
	v_fma_mixlo_f16 v23, s25, v36, v120                         ; cc210017 05e24819
	v_fma_mixlo_f16 v21, s25, v32, v60                          ; cc210015 04f24019
	v_fma_mixhi_f16 v21, s25, v33, v61                          ; cc220015 04f64219
	v_fma_mixhi_f16 v24, s25, v39, v123                         ; cc220018 05ee4e19
	v_fma_mixhi_f16 v23, s25, v37, v121                         ; cc220017 05e64a19
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v26                               ; 0a003516
	s_mov_b32 s28, 0x7ff88000                                   ; be9c00ff 7ff88000
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v26                               ; 0a003515
	v_lshl_add_u32 v183, v183, 5, s28                           ; d64600b7 00710bb7
(invalid instruction)                                        ; cc1c0018
	v_subrev_f32_e32 v0, v24, v26                               ; 0a003518
	v_lshl_add_u32 v175, v175, 5, s28                           ; d64600af 00710baf
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v26                               ; 0a003517
	v_lshl_add_u32 v191, v191, 5, s28                           ; d64600bf 00710bbf
	v_lshl_add_u32 v21, v21, 5, s28                             ; d6460015 00710b15
	v_lshl_add_u32 v176, v176, 5, s28                           ; d64600b0 00710bb0
	v_lshl_add_u32 v184, v184, 5, s28                           ; d64600b8 00710bb8
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[175:176], v[183:184]            ; 1a036faf
	v_lshl_add_u32 v2, v2, 5, s28                               ; d6460002 00710b02
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v25, s25, v40, v76                          ; cc210019 05325019
	v_fma_mixhi_f16 v25, s25, v41, v77                          ; cc220019 05365219
	v_fma_mixlo_f16 v26, s25, v42, v78                          ; cc21001a 053a5419
	v_fma_mixhi_f16 v26, s25, v43, v79                          ; cc22001a 053e5619
	v_lshl_add_u32 v22, v22, 5, s28                             ; d6460016 00710b16
(invalid instruction)                                        ; cc0f001e
	v_min_num_f64_e32 v[1:2], v[176:177], v[184:185]            ; 1a0371b0
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v28, s25, v46, v90                          ; cc21001c 056a5c19
	v_fma_mixlo_f16 v27, s25, v44, v88                          ; cc21001b 05625819
	v_fma_mixhi_f16 v27, s25, v45, v89                          ; cc22001b 05665a19
	v_fma_mixhi_f16 v28, s25, v47, v91                          ; cc22001c 056e5e19
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[191:192]              ; 1a037f1d
	v_lshl_add_u32 v177, v177, 5, s28                           ; d64600b1 00710bb1
	v_lshl_add_u32 v185, v185, 5, s28                           ; d64600b9 00710bb9
	v_lshl_add_u32 v10, v10, 5, s28                             ; d646000a 00710b0a
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v26                               ; 0a003519
	v_lshl_add_u32 v23, v23, 5, s28                             ; d6460017 00710b17
(invalid instruction)                                        ; cc1c001a
	v_subrev_f32_e32 v0, v26, v26                               ; 0a00351a
	v_lshl_add_u32 v178, v178, 5, s28                           ; d64600b2 00710bb2
	v_add_lshl_u32 v0, s9, v0, 2                                ; d6470000 020a0009
	buffer_load_b128 v[36:39], v0, s[36:39], null offen         ; c405c07c 40804824 00000000
(invalid instruction)                                        ; cc0f001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[2:3]                  ; 1a02051e
	v_lshl_add_u32 v186, v186, 5, s28                           ; d64600ba 00710bba
	v_lshl_add_u32 v11, v11, 5, s28                             ; d646000b 00710b0b
(invalid instruction)                                        ; cc1c001b
	v_subrev_f32_e32 v0, v27, v26                               ; 0a00351b
	buffer_load_b128 v[40:43], v0, s[36:39], null offen offset:16 ; c405c07c 40804828 00001000
	v_lshl_add_u32 v24, v24, 5, s28                             ; d6460018 00710b18
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v26                               ; 0a00351c
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[21:22]                ; 1a022b1d
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[177:178], v[185:186]            ; 1a0373b1
(invalid instruction)                                        ; cc0f001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[22:23]                ; 1a022d1e
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[178:179], v[186:187]            ; 1a0375b2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[10:11]                ; 1a02151f
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[30:31]                ; 1a023d1d
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[32:33], v[11:12]                ; 1a021720
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[23:24]                ; 1a022f1f
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[32:33], v[24:25]                ; 1a023120
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[31:32]                ; 1a023f1d
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v12, s6, v12, 2                              ; d647000c 020a1806
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[32:33]                ; 1a02411d
	buffer_load_b64 v[8:9], v12, s[44:47], null offen           ; c405407c 40805808 0000000c
	v_permlanex16_b32 v33, v29, s19, s24 op_sel:[1,1]           ; d65c1821 0060271d
(invalid instruction)                                        ; cc0f001d
	v_min_num_f64_e32 v[1:2], v[29:30], v[33:34]                ; 1a02431d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v34, v29, v157/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64453b1d
	v_max_num_f16_e32 v34, 0x400, v34                           ; 624444ff 00000400
	buffer_load_b64 v[16:17], v12, s[44:47], null offen offset:512 ; c405407c 40805810 0002000c
	v_cvt_f32_f16_e32 v35, v34                                  ; 7e461722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v35, v35                                      ; 7e465523
	v_fma_mix_f32 v44, v175, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20002c 8a0247af
	v_fma_mix_f32 v56, v183, v35, neg(0) op_sel_hi:[1,0,0]      ; cc200038 8a0247b7
	v_fma_mix_f32 v183, v183, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a0247b7
	v_fma_mix_f32 v47, v178, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20002f 8a0247b2
	v_fma_mix_f32 v45, v176, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20002d 8a0247b0
	v_fma_mix_f32 v176, v176, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a0247b0
	v_fma_mix_f32 v46, v177, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20002e 8a0247b1
	v_fma_mix_f32 v177, v177, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a0247b1
	v_fma_mix_f32 v175, v175, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a0247af
	v_fma_mix_f32 v57, v184, v35, neg(0) op_sel_hi:[1,0,0]      ; cc200039 8a0247b8
	v_fma_mix_f32 v178, v178, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a0247b2
	v_fma_mix_f32 v184, v184, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a0247b8
	v_fma_mix_f32 v60, v185, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a0247b9
	v_fma_mix_f32 v185, v185, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a0247b9
	v_fma_mix_f32 v61, v186, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20003d 8a0247ba
	v_fma_mix_f32 v186, v186, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a0247ba
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v56, v183, vcc_lo                     ; 02036f38
	v_fma_mix_f32 v62, v191, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20003e 8a0247bf
	v_fma_mix_f32 v191, v191, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a0247bf
	v_fma_mix_f32 v63, v2, v35, neg(0) op_sel_hi:[1,0,0]        ; cc20003f 8a024702
	v_fma_mix_f32 v2, v2, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200802 8a024702
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v46, v177, vcc_lo                     ; 0203632e
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v44, v175, vcc_lo                     ; 02035f2c
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v45, v176, vcc_lo                     ; 0203612d
	v_fma_mix_f32 v64, v10, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200040 8a02470a
	v_fma_mix_f32 v10, v10, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080a 8a02470a
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v47, v178, vcc_lo                     ; 0203652f
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v57, v184, vcc_lo                     ; 02037139
	v_fma_mix_f32 v65, v11, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200041 8a02470b
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v60, v185, vcc_lo                     ; 0203733c
	v_fma_mix_f32 v11, v11, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080b 8a02470b
	v_fma_mix_f32 v66, v21, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200042 8a024715
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v61, v186, vcc_lo                     ; 0203753d
	v_fma_mix_f32 v21, v21, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a024715
	v_fma_mix_f32 v67, v22, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200043 8a024716
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v62, v191, vcc_lo                     ; 02037f3e
	v_fma_mix_f32 v22, v22, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a024716
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v63, v2, vcc_lo                       ; 0202053f
	v_fma_mix_f32 v68, v23, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200044 8a024717
	v_fma_mix_f32 v23, v23, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a024717
	v_fma_mix_f32 v69, v24, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200045 8a024718
	v_fma_mix_f32 v24, v24, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200818 8a024718
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v64, v10, vcc_lo                      ; 02021540
	v_lshl_add_u32 v179, v179, 5, s28                           ; d64600b3 00710bb3
	v_lshl_add_u32 v187, v187, 5, s28                           ; d64600bb 00710bbb
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v65, v11, vcc_lo                      ; 02021741
	v_lshl_add_u32 v13, v13, 5, s28                             ; d646000d 00710b0d
	v_lshl_add_u32 v25, v25, 5, s28                             ; d6460019 00710b19
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v66, v21, vcc_lo                      ; 02022b42
	v_lshl_add_u32 v180, v180, 5, s28                           ; d64600b4 00710bb4
	v_lshl_add_u32 v188, v188, 5, s28                           ; d64600bc 00710bbc
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v67, v22, vcc_lo                      ; 02022d43
	v_lshl_add_u32 v18, v18, 5, s28                             ; d6460012 00710b12
	v_lshl_add_u32 v26, v26, 5, s28                             ; d646001a 00710b1a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v68, v23, vcc_lo                      ; 02022f44
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v69, v24, vcc_lo                      ; 02023145
	v_lshl_add_u32 v181, v181, 5, s28                           ; d64600b5 00710bb5
	v_lshl_add_u32 v189, v189, 5, s28                           ; d64600bd 00710bbd
	v_lshl_add_u32 v19, v19, 5, s28                             ; d6460013 00710b13
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[179:180], v[187:188]            ; 1a0377b3
	v_lshl_add_u32 v27, v27, 5, s28                             ; d646001b 00710b1b
	v_lshl_add_u32 v182, v182, 5, s28                           ; d64600b6 00710bb6
	v_lshl_add_u32 v190, v190, 5, s28                           ; d64600be 00710bbe
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[180:181], v[188:189]            ; 1a0379b4
	v_lshl_add_u32 v20, v20, 5, s28                             ; d6460014 00710b14
	v_lshl_add_u32 v28, v28, 5, s28                             ; d646001c 00710b1c
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[181:182], v[189:190]            ; 1a037bb5
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[13:14]                ; 1a021b46
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[182:183], v[190:191]            ; 1a037db6
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[18:19]                ; 1a022547
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[19:20]                ; 1a02274a
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[25:26]                ; 1a023346
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[20:21]                ; 1a02294b
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[26:27]                ; 1a023547
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[27:28]                ; 1a02374a
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[28:29]                ; 1a02394b
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[71:72]                ; 1a028f46
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[74:75]                ; 1a029546
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[75:76]                ; 1a029746
	v_permlanex16_b32 v76, v70, s19, s24 op_sel:[1,1]           ; d65c184c 00602746
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[76:77]                ; 1a029946
	v_add_f16_e32 v77, v70, v198/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 649b8d46
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v77, 0x400, v77                           ; 629a9aff 00000400
	v_cvt_f32_f16_e32 v78, v77                                  ; 7e9c174d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v78, v78                                      ; 7e9c554e
	v_fma_mix_f32 v83, v187, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200053 8a029dbb
	v_fma_mix_f32 v81, v181, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200051 8a029db5
	v_fma_mix_f32 v84, v188, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200054 8a029dbc
	v_fma_mix_f32 v80, v180, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200050 8a029db4
	v_fma_mix_f32 v180, v180, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a029db4
	v_fma_mix_f32 v181, v181, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a029db5
	v_fma_mix_f32 v79, v179, v78, neg(0) op_sel_hi:[1,0,0]      ; cc20004f 8a029db3
	v_fma_mix_f32 v179, v179, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a029db3
	v_fma_mix_f32 v82, v182, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200052 8a029db6
	v_fma_mix_f32 v182, v182, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a029db6
	v_fma_mix_f32 v187, v187, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a029dbb
	v_fma_mix_f32 v188, v188, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a029dbc
	v_fma_mix_f32 v85, v189, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200055 8a029dbd
	v_fma_mix_f32 v189, v189, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a029dbd
	v_fma_mix_f32 v86, v190, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200056 8a029dbe
	v_fma_mix_f32 v190, v190, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a029dbe
	v_fma_mix_f32 v87, v13, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200057 8a029d0d
	v_fma_mix_f32 v13, v13, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080d 8a029d0d
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v81, v181, vcc_lo                     ; 02036b51
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[4:5], 0   ; cc464040 1a02090e
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v79, v179, vcc_lo                     ; 0203674f
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v80, v180, vcc_lo                     ; 02036950
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v82, v182, vcc_lo                     ; 02036d52
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v83, v187, vcc_lo                     ; 02037753
	v_fma_mix_f32 v88, v18, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200058 8a029d12
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v84, v188, vcc_lo                     ; 02037954
	v_fma_mix_f32 v18, v18, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200812 8a029d12
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v85, v189, vcc_lo                     ; 02037b55
	v_fma_mix_f32 v89, v19, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200059 8a029d13
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v86, v190, vcc_lo                     ; 02037d56
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v87, v13, vcc_lo                      ; 02021b57
	v_fma_mix_f32 v19, v19, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200813 8a029d13
	v_fma_mix_f32 v90, v20, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005a 8a029d14
	v_fma_mix_f32 v20, v20, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a029d14
	v_fma_mix_f32 v91, v25, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005b 8a029d19
	v_fma_mix_f32 v25, v25, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a029d19
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[14:15], v[22:23], 0 ; cc464050 1a022d0e
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, 0              ; ca100080 0f0e0080
	v_fma_mix_f32 v92, v26, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005c 8a029d1a
	v_fma_mix_f32 v26, v26, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081a 8a029d1a
	v_fma_mix_f32 v93, v27, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005d 8a029d1b
	v_fma_mix_f32 v27, v27, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081b 8a029d1b
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v88, v18, vcc_lo                      ; 02022558
	v_fma_mix_f32 v94, v28, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005e 8a029d1c
	v_fma_mix_f32 v28, v28, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081c 8a029d1c
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v89, v19, vcc_lo                      ; 02022759
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v90, v20, vcc_lo                      ; 0202295a
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v91, v25, vcc_lo                      ; 0202335b
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[30:31], v[64:71] ; cc464040 1d023d0e
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v92, v26, vcc_lo                      ; 0202355c
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v93, v27, vcc_lo                      ; 0202375d
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[14:15], v[34:35], v[80:87] ; cc464050 1d42450e
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v94, v28, vcc_lo                      ; 0202395e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[72:73], v[32:33], v[64:71] ; cc464040 1d024148
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[44:45], v[80:87] ; cc464050 1d425948
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[6:7], v[22:23], 0   ; cc464048 1a022d06
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v57, v129, v37 :: v_dual_mul_f32 v56, v128, v36 ; c8c64b81 39384980
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v61, v133, v41 :: v_dual_mul_f32 v60, v132, v40 ; c8c65385 3d3c5184
	v_dual_mul_f32 v63, v135, v43 :: v_dual_mul_f32 v62, v134, v42 ; c8c65787 3f3e5586
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[10:11], v[64:71] ; cc464040 1d02150e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[14:15], v[18:19], v[80:87] ; cc464050 1d42250e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[34:35], v[72:79] ; cc464048 1d22450e
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[6:7], v[4:5], 0     ; cc464040 1a020906
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[58:59], v[44:45], v[72:79] ; cc464048 1d22593a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[30:31], v[64:71] ; cc464040 1d023d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[18:19], v[72:79] ; cc464048 1d22250e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[58:59], v[32:33], v[64:71] ; cc464040 1d02413a
	v_dual_mul_f32 v59, v131, v39 :: v_dual_mul_f32 v58, v130, v38 ; c8c64f83 3b3a4d82
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[8:9], v[20:21], v[56:63] ; cc464038 1ce22908
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[10:11], v[64:71] ; cc464040 1d02150e
	s_cmp_lg_i32 s27, 0                                         ; bf01801b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_dual_mul_f32 v65, v145, v37 :: v_dual_mul_f32 v64, v144, v36 ; c8c64b91 41404990
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v67, v147, v39 :: v_dual_mul_f32 v66, v146, v38 ; c8c64f93 43424d92
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_dual_mul_f32 v69, v149, v41 :: v_dual_mul_f32 v68, v148, v40 ; c8c65395 45445194
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_dual_mul_f32 v71, v151, v43 :: v_dual_mul_f32 v70, v150, v42 ; c8c65797 47465596
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[24:25], v[64:71] ; cc464040 1d023108
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[16:17], v[4:5], v[56:63] ; cc464038 1ce20910
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[16:17], v[6:7], v[64:71] ; cc464040 1d020d10
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_cbranch_scc1 BB65                                         ; bfa20007
BB63:
	v_add3_u32 v2, v3, s2, s14                                  ; d6550002 00380503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[8:9], v2, s[20:23], null offen           ; c406c07c 40802808 00000002
BB65:
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_lg_i32 s35, 0                                         ; bf018023
	s_cbranch_scc1 BB68                                         ; bfa20007
BB66:
	v_add3_u32 v2, v3, s2, s29                                  ; d6550002 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[8:9], v2, s[20:23], null offen           ; c406c07c 40802808 00000002
BB68:
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v0, s[36:39], null offen offset:64 ; c405c07c 40804808 00004000
	buffer_load_b128 v[16:19], v0, s[36:39], null offen offset:80 ; c405c07c 40804810 00005000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[14:15], v12, s[44:47], null offen offset:8 ; c405407c 4080580e 0000080c
	buffer_load_b64 v[12:13], v12, s[44:47], null offen offset:520 ; c405407c 4080580c 0002080c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v33, v153, v9 :: v_dual_mul_f32 v32, v152, v8 ; c8c61399 21201198
	v_dual_mul_f32 v35, v155, v11 :: v_dual_mul_f32 v34, v154, v10 ; c8c6179b 2322159a
	v_dual_mul_f32 v41, v49, v9 :: v_dual_mul_f32 v40, v48, v8  ; c8c61331 29281130
	v_dual_mul_f32 v43, v51, v11 :: v_dual_mul_f32 v42, v50, v10 ; c8c61733 2b2a1532
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v37, v157, v17 :: v_dual_mul_f32 v36, v156, v16 ; c8c6239d 2524219c
	v_dual_mul_f32 v39, v159, v19 :: v_dual_mul_f32 v38, v158, v18 ; c8c6279f 2726259e
	v_dual_mul_f32 v45, v53, v17 :: v_dual_mul_f32 v44, v52, v16 ; c8c62335 2d2c2134
	v_dual_mul_f32 v47, v55, v19 :: v_dual_mul_f32 v46, v54, v18 ; c8c62737 2f2e2536
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[14:15], v[20:21], v[32:39] ; cc464020 1c82290e
	s_mov_b32 s0, vcc_lo                                        ; be80006a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[14:15], v[24:25], v[40:47] ; cc464028 1ca2310e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[12:13], v[4:5], v[32:39] ; cc464020 1c82090c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[6:7], v[40:47] ; cc464028 1ca20d0c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_cbranch_scc1 BB71                                         ; bfa20009
BB69:
	s_add_co_u32 s1, s2, 0x100                                  ; 8001ff02 00000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	v_add3_u32 v0, v3, s1, s14                                  ; d6550000 00380303
	v_add_nc_u32_e32 v0, v0, v1                                 ; 4a000300
	buffer_store_b64 v[4:5], v0, s[20:23], null offen           ; c406c07c 40802804 00000000
BB71:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB78                                         ; bfa20009
BB72:
	s_addk_co_i32 s2, 0x100                                     ; b7820100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v3, v3, s2, s29                                  ; d6550003 00740503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	buffer_store_b64 v[4:5], v3, s[20:23], null offen           ; c406c07c 40802804 00000003
BB78:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
