BB0:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s10, s1                                           ; be8a0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_pack_ll_b32_b16 s21, ttmp7, 0                             ; 99158073
	s_clause 0x4                                                ; bf850004
	s_load_b128 s[12:15], s[0:1], 0x0                           ; f4004300 f8000000
	s_load_b128 s[16:19], s[10:11], 0x30                        ; f4004405 f8000030
	s_load_b32 s20, s[10:11], 0x40                              ; f4000505 f8000040
	s_load_b64 s[22:23], s[10:11], 0x20                         ; f4002585 f8000020
	s_load_b256 s[32:39], s[0:1], 0x30                          ; f4006800 f8000030
(invalid instruction)                                        ; d71f0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_lshrrev_b32_e32 v1, 5, v0                                 ; 32020085
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_and_b32_e32 v4, 15, v3                                    ; 3608068f
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_lshlrev_b32_e32 v2, 9, v1                                 ; 30040289
	v_lshlrev_b32_e32 v5, 4, v4                                 ; 300a0884
	v_lshlrev_b32_e32 v6, 3, v3                                 ; 300c0683
	v_add_nc_u32_e32 v8, 0x100, v2                              ; 4a1004ff 00000100
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl1_add_u32 s24, ttmp9, s19                             ; 87181375
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_max_i32 s25, s24, 0                                       ; 8a198018
	s_add_co_u32 s26, s17, -1                                   ; 801ac111
	s_min_i32 s25, s25, s26                                     ; 89191a19
	s_add_co_u32 s27, s18, -1                                   ; 801bc112
	s_lshl1_add_u32 s21, s21, s20                               ; 87151415
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_max_i32 s28, s21, 0                                       ; 8a1c8015
	s_min_i32 s28, s28, s27                                     ; 891c1b1c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s28, s28, s17                                     ; 961c111c
	s_add_co_u32 s29, s28, s25                                  ; 801d191c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s29, s29, 11                                     ; 841d8b1d
	s_add_co_u32 s30, s2, s29                                   ; 801e1d02
	s_add_co_u32 s31, s24, 1                                    ; 801f8118
	v_add3_u32 v7, v5, s30, v2                                  ; d6550007 04083d05
	v_add3_u32 v9, v5, s30, v8                                  ; d6550009 04203d05
	s_max_i32 s40, s31, 0                                       ; 8a28801f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_min_i32 s40, s40, s26                                     ; 89281a28
	v_add_nc_u32_e32 v7, v7, v6                                 ; 4a0e0d07
	v_add_nc_u32_e32 v9, v9, v6                                 ; 4a120d09
	s_add_co_u32 s28, s28, s40                                  ; 801c281c
	s_lshl_b32 s28, s28, 11                                     ; 841c8b1c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s41, s2, s28                                   ; 80291c02
	s_add_co_u32 s42, s21, 1                                    ; 802a8115
	v_add3_u32 v11, v5, s41, v8                                 ; d655000b 04205305
	v_add3_u32 v10, v5, s41, v2                                 ; d655000a 04085305
	s_max_i32 s43, s42, 0                                       ; 8a2b802a
	s_min_i32 s43, s43, s27                                     ; 892b1b2b
	v_add_nc_u32_e32 v11, v11, v6                               ; 4a160d0b
	v_add_nc_u32_e32 v10, v10, v6                               ; 4a140d0a
	s_mul_i32 s43, s43, s17                                     ; 962b112b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s25, s43, s25                                  ; 8019192b
	s_lshl_b32 s25, s25, 11                                     ; 84198b19
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s44, s2, s25                                   ; 802c1902
	s_add_co_u32 s43, s43, s40                                  ; 802b282b
	v_add3_u32 v13, v5, s44, v8                                 ; d655000d 04205905
	v_add3_u32 v12, v5, s44, v2                                 ; d655000c 04085905
	s_lshl_b32 s43, s43, 11                                     ; 842b8b2b
	s_add_co_u32 s2, s2, s43                                    ; 80022b02
	v_add_nc_u32_e32 v13, v13, v6                               ; 4a1a0d0d
	v_add_nc_u32_e32 v12, v12, v6                               ; 4a180d0c
	v_add3_u32 v14, v5, s2, v2                                  ; d655000e 04080505
	v_add3_u32 v15, v5, s2, v8                                  ; d655000f 04200505
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v6                               ; 4a1c0d0e
	v_add_nc_u32_e32 v15, v15, v6                               ; 4a1e0d0f
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[16:17], v7, s[12:15], null offen          ; c405407c 40801810 00000007
	buffer_load_b64 v[18:19], v9, s[12:15], null offen          ; c405407c 40801812 00000009
	buffer_load_b64 v[20:21], v10, s[12:15], null offen         ; c405407c 40801814 0000000a
	buffer_load_b64 v[10:11], v11, s[12:15], null offen         ; c405407c 4080180a 0000000b
	buffer_load_b64 v[22:23], v12, s[12:15], null offen         ; c405407c 40801816 0000000c
	buffer_load_b64 v[12:13], v13, s[12:15], null offen         ; c405407c 4080180c 0000000d
	buffer_load_b64 v[24:25], v14, s[12:15], null offen         ; c405407c 40801818 0000000e
	buffer_load_b64 v[14:15], v15, s[12:15], null offen         ; c405407c 4080180e 0000000f
	v_lshlrev_b32_e32 v26, 3, v1                                ; 30340283
	v_and_b32_e32 v29, 31, v0                                   ; 363a009f
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_sub_nc_u32_e32 v27, 0, v26                                ; 4c363480
	v_med3_i32 v28, -1, v26, 1                                  ; d620001c 020634c1
	v_add_nc_u32_e32 v31, 2, v26                                ; 4a3e3482
	v_lshlrev_b32_e32 v30, 2, v29                               ; 303c3a82
	v_max_i32_e32 v27, v26, v27                                 ; 2436371a
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_sub_nc_u32_e32 v32, 0, v31                                ; 4c403e80
	v_lshrrev_b32_e32 v27, 1, v27                               ; 32363681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_max_i32_e32 v32, v31, v32                                 ; 2440411f
	v_med3_i32 v31, -1, v31, 1                                  ; d620001f 02063ec1
(invalid instruction)                                        ; d72c001c
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                      ; 0202371c
	v_lshrrev_b32_e32 v32, 1, v32                               ; 32404081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d72c001f
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                      ; 0202411f
	v_lshl_add_u32 v28, v28, 10, s4                             ; d646001c 0011151c
	v_add_lshl_u32 v28, v28, v30, 2                             ; d647001c 020a3d1c
	v_lshl_add_u32 v31, v31, 10, s4                             ; d646001f 0011151f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v31, v31, v30, 2                             ; d647001f 020a3d1f
	s_clause 0x9                                                ; bf850009
	buffer_load_b128 v[32:35], v28, s[36:39], null offen        ; c405c07c 40804820 0000001c
	buffer_load_b128 v[36:39], v31, s[36:39], null offen        ; c405c07c 40804824 0000001f
	buffer_load_b128 v[40:43], v28, s[36:39], null offen offset:512 ; c405c07c 40804828 0002001c
	buffer_load_b128 v[44:47], v31, s[36:39], null offen offset:512 ; c405c07c 4080482c 0002001f
	buffer_load_b128 v[48:51], v28, s[36:39], null offen offset:1024 ; c405c07c 40804830 0004001c
	buffer_load_b128 v[52:55], v31, s[36:39], null offen offset:1024 ; c405c07c 40804834 0004001f
	buffer_load_b128 v[56:59], v28, s[36:39], null offen offset:1536 ; c405c07c 40804838 0006001c
	buffer_load_b128 v[60:63], v31, s[36:39], null offen offset:1536 ; c405c07c 4080483c 0006001f
	buffer_load_b128 v[64:67], v28, s[36:39], null offen offset:2048 ; c405c07c 40804840 0008001c
	buffer_load_b128 v[68:71], v31, s[36:39], null offen offset:2048 ; c405c07c 40804844 0008001f
	v_add_nc_u32_e32 v72, v5, v6                                ; 4a900d05
	s_min_i32 s45, s24, s21                                     ; 892d1518
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s45, 0                                         ; bf04802d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b1
	v_add_nc_u32_e32 v73, v2, v72                               ; 4a929102
	s_cselect_b32 s46, -1, 0                                    ; 982e80c1
	s_cmp_ge_i32 s24, s17                                       ; bf031118
	s_cselect_b32 s47, -1, 0                                    ; 982f80c1
	v_add_nc_u32_e32 v75, 0x1000, v73                           ; 4a9692ff 00001000
	v_add_nc_u32_e32 v76, 0x1800, v73                           ; 4a9892ff 00001800
	v_add_nc_u32_e32 v74, 0x800, v73                            ; 4a9492ff 00000800
	s_or_b32 s46, s46, s47                                      ; 8c2e2f2e
	s_cmp_ge_i32 s21, s18                                       ; bf031215
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_mov_b32 s49, src_scc                                      ; beb100fd
	s_cselect_b32 s48, -1, 0                                    ; 983080c1
	s_nor_b32 vcc_lo, s46, s48                                  ; 8f6a302e
	s_min_i32 s50, s31, s21                                     ; 8932151f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s50, 0                                         ; bf048032
	s_cselect_b32 s51, -1, 0                                    ; 983380c1
	s_cmp_ge_i32 s31, s17                                       ; bf03111f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s52, -1, 0                                    ; 983480c1
	s_or_b32 s51, s51, s52                                      ; 8c333433
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_nor_b32 s51, s51, s48                                     ; 8f333033
	s_min_i32 s53, s24, s42                                     ; 89352a18
	s_pack_hh_b32_b16 s59, ttmp7, 0                             ; 9a3b8073
	s_movk_i32 s60, 0x400                                       ; b03c0400
	s_cmp_lt_i32 s53, 0                                         ; bf048035
	v_lshl_add_u32 v77, s59, 4, v72                             ; d646004d 0521083b
	s_cselect_b32 s54, -1, 0                                    ; 983680c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_or_b32 s54, s54, s47                                      ; 8c362f36
	s_cmp_ge_i32 s42, s18                                       ; bf03122a
	s_cselect_b32 s55, -1, 0                                    ; 983780c1
	s_mov_b32 s56, src_scc                                      ; beb800fd
	s_nor_b32 s54, s54, s55                                     ; 8f363736
	s_min_i32 s57, s31, s42                                     ; 89392a1f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s57, 0                                         ; bf048039
	s_cselect_b32 s58, -1, 0                                    ; 983a80c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s58, s58, s52                                      ; 8c3a343a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_nor_b32 s58, s58, s55                                     ; 8f3a373a
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_dual_cndmask_b32 v78, 0, v16 :: v_dual_cndmask_b32 v79, 0, v17 ; ca522080 4e4e2280
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_dual_cndmask_b32 v16, 0, v18 :: v_dual_cndmask_b32 v17, 0, v19 ; ca522480 10102680
	ds_store_2addr_b64 v73, v[78:79], v[16:17] offset1:32       ; d9382000 00104e49
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_cndmask_b32_e64 v17, 0, v21, s51                          ; d5010011 00ce2a80
	v_cndmask_b32_e64 v16, 0, v20, s51                          ; d5010010 00ce2880
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_cndmask_b32_e64 v19, 0, v11, s51                          ; d5010013 00ce1680
	v_cndmask_b32_e64 v18, 0, v10, s51                          ; d5010012 00ce1480
	ds_store_2addr_b64 v74, v[16:17], v[18:19] offset1:32       ; d9382000 0012104a
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_cndmask_b32_e64 v10, 0, v22, s54                          ; d501000a 00da2c80
	v_cndmask_b32_e64 v11, 0, v23, s54                          ; d501000b 00da2e80
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_cndmask_b32_e64 v17, 0, v13, s54                          ; d5010011 00da1a80
	v_cndmask_b32_e64 v16, 0, v12, s54                          ; d5010010 00da1880
	ds_store_2addr_b64 v75, v[10:11], v[16:17] offset1:32       ; d9382000 00100a4b
	s_wait_loadcnt 0xb                                          ; bfc0000b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v10, 0, v24, s58                          ; d501000a 00ea3080
	v_cndmask_b32_e64 v11, 0, v25, s58                          ; d501000b 00ea3280
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cndmask_b32_e64 v12, 0, v14, s58                          ; d501000c 00ea1c80
	v_cndmask_b32_e64 v13, 0, v15, s58                          ; d501000d 00ea1e80
	ds_store_2addr_b64 v76, v[10:11], v[12:13] offset1:32       ; d9382000 000c0a4c
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[10:11], v77                                   ; d9d80000 0a00004d
	ds_load_b64 v[12:13], v77 offset:2048                       ; d9d80800 0c00004d
	ds_load_b64 v[14:15], v77 offset:4096                       ; d9d81000 0e00004d
	ds_load_b64 v[16:17], v77 offset:6144                       ; d9d81800 1000004d
	ds_load_b64 v[18:19], v77 offset:256                        ; d9d80100 1200004d
	ds_load_b64 v[20:21], v77 offset:2304                       ; d9d80900 1400004d
	ds_load_b64 v[22:23], v77 offset:4352                       ; d9d81100 1600004d
	ds_load_b64 v[24:25], v77 offset:6400                       ; d9d81900 1800004d
	ds_load_b64 v[78:79], v77 offset:512                        ; d9d80200 4e00004d
	ds_load_b64 v[80:81], v77 offset:2560                       ; d9d80a00 5000004d
	v_mov_b32_e32 v82, v8                                       ; 7ea40308
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[34:35], v[14:15], 0 ; cc4640a0 1a021d22
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[12:13], 0 ; cc464078 1a021920
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[10:11], 0 ; cc464060 1a021522
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[14:15], 0 ; cc464098 1a021d20
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[12:13], 0 ; cc464080 1a021922
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[32:33], v[16:17], 0 ; cc4640b8 1a022120
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[10:11], 0 ; cc464058 1a021520
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[12:13], 0 ; cc464090 1a021926
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[36:37], v[14:15], 0 ; cc4640a8 1a021d24
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[36:37], v[12:13], 0 ; cc464088 1a021924
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[10:11], 0 ; cc464070 1a021526
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[10:11], 0 ; cc464068 1a021524
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[14:15], 0 ; cc4640b0 1a021d26
	v_mov_b32_e32 v15, v82                                      ; 7e1e0352
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[34:35], v[16:17], 0  ; cc464007 1a022122
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v33, v81 :: v_dual_mov_b32 v32, v80          ; ca100151 21200150
	v_dual_mov_b32 v35, v17 :: v_dual_mov_b32 v34, v16          ; ca100111 23220110
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[16:17], 0 ; cc464050 1a022124
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[18:19], v[96:103] ; cc464060 1d82252a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[20:21], v[120:127] ; cc464078 1de22928
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[20:21], v[128:135] ; cc464080 1e02292a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[18:19], v[88:95] ; cc464058 1d622528
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[20:21], v[144:151] ; cc464090 1e42292e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[22:23], v[152:159] ; cc464098 1e622d28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[44:45], v[20:21], v[136:143] ; cc464088 1e22292c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[42:43], v[22:23], v[160:167] ; cc4640a0 1e822d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[18:19], v[112:119] ; cc464070 1dc2252e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[22:23], v[168:175] ; cc4640a8 1ea22d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[18:19], v[104:111] ; cc464068 1da2252c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[22:23], v[176:183] ; cc4640b0 1ec22d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[38:39], v[34:35], 0 ; cc464010 1a024526
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[78:79], v[96:103] ; cc464060 1d829d32
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[32:33], v[120:127] ; cc464078 1de24130
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[32:33], v[128:135] ; cc464080 1e024132
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[32:33], v[144:151] ; cc464090 1e424136
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[78:79], v[88:95] ; cc464058 1d629d30
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[32:33], v[136:143] ; cc464088 1e224134
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[40:41], v[24:25], v[184:191] ; cc4640b8 1ee23128
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[42:43], v[24:25], v[7:14] ; cc464007 1c1e312a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[24:25], v[80:87] ; cc464050 1d42312c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[24:25], v[16:23] ; cc464010 1c42312e
	ds_load_b64 v[34:35], v77 offset:4608                       ; d9d81200 2200004d
	ds_load_b64 v[36:37], v77 offset:6656                       ; d9d81a00 2400004d
	ds_load_b64 v[38:39], v77 offset:768                        ; d9d80300 2600004d
	ds_load_b64 v[32:33], v77 offset:2816                       ; d9d80b00 2000004d
	ds_load_b64 v[40:41], v77 offset:4864                       ; d9d81300 2800004d
	ds_load_b64 v[42:43], v77 offset:6912                       ; d9d81b00 2a00004d
	ds_load_b64 v[44:45], v77 offset:1024                       ; d9d80400 2c00004d
	ds_load_b64 v[24:25], v77 offset:3072                       ; d9d80c00 1800004d
	ds_load_b64 v[46:47], v77 offset:5120                       ; d9d81400 2e00004d
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[78:79], v[104:111] ; cc464068 1da29d34
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[34:35], v[168:175] ; cc4640a8 1ea24534
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[34:35], v[176:183] ; cc4640b0 1ec24536
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[34:35], v[152:159] ; cc464098 1e624530
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[34:35], v[160:167] ; cc4640a0 1e824532
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[50:51], v[36:37], v[7:14] ; cc464007 1c1e4932
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[52:53], v[36:37], v[80:87] ; cc464050 1d424934
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[48:49], v[36:37], v[184:191] ; cc4640b8 1ee24930
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[36:37], v[16:23] ; cc464010 1c424936
	ds_load_b64 v[34:35], v77 offset:7168                       ; d9d81c00 2200004d
	ds_load_b64 v[48:49], v77 offset:1280                       ; d9d80500 3000004d
	ds_load_b64 v[50:51], v77 offset:3328                       ; d9d80d00 3200004d
	ds_load_b64 v[52:53], v77 offset:5376                       ; d9d81500 3400004d
	ds_load_b64 v[36:37], v77 offset:7424                       ; d9d81d00 2400004d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[78:79], v[112:119] ; cc464070 1dc29d36
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[38:39], v[88:95] ; cc464058 1d624d38
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[38:39], v[96:103] ; cc464060 1d824d3a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[32:33], v[120:127] ; cc464078 1de24138
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[32:33], v[128:135] ; cc464080 1e02413a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[40:41], v[152:159] ; cc464098 1e625138
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[40:41], v[160:167] ; cc4640a0 1e82513a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[58:59], v[42:43], v[7:14] ; cc464007 1c1e553a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[38:39], v[104:111] ; cc464068 1da24d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[32:33], v[136:143] ; cc464088 1e22413c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[40:41], v[168:175] ; cc4640a8 1ea2513c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[42:43], v[80:87] ; cc464050 1d42553c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[42:43], v[184:191] ; cc4640b8 1ee25538
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[32:33], v[144:151] ; cc464090 1e42413e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[40:41], v[176:183] ; cc4640b0 1ec2513e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[38:39], v[112:119] ; cc464070 1dc24d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[62:63], v[42:43], v[16:23] ; cc464010 1c42553e
	ds_load_b64 v[38:39], v77 offset:1536                       ; d9d80600 2600004d
	ds_load_b64 v[32:33], v77 offset:3584                       ; d9d80e00 2000004d
	ds_load_b64 v[40:41], v77 offset:5632                       ; d9d81600 2800004d
	ds_load_b64 v[42:43], v77 offset:7680                       ; d9d81e00 2a00004d
	s_wait_loadcnt_dscnt 0x10b                                  ; bfc8010b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[44:45], v[88:95] ; cc464058 1d625940
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[24:25], v[120:127] ; cc464078 1de23140
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[46:47], v[152:159] ; cc464098 1e625d40
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[44:45], v[96:103] ; cc464060 1d825942
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[24:25], v[128:135] ; cc464080 1e023142
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[46:47], v[160:167] ; cc4640a0 1e825d42
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[66:67], v[34:35], v[7:14] ; cc464007 1c1e4542
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[44:45], v[104:111] ; cc464068 1da25944
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[34:35], v[184:191] ; cc4640b8 1ee24540
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[24:25], v[136:143] ; cc464088 1e223144
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[46:47], v[168:175] ; cc4640a8 1ea25d44
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[34:35], v[80:87] ; cc464050 1d424544
	v_dual_mov_b32 v54, v71 :: v_dual_mov_b32 v27, v70          ; ca100147 361a0146
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[56:59], v28, s[36:39], null offen offset:2560 ; c405c07c 40804838 000a001c
	buffer_load_b128 v[60:63], v31, s[36:39], null offen offset:2560 ; c405c07c 4080483c 000a001f
	buffer_load_b128 v[64:67], v28, s[36:39], null offen offset:3072 ; c405c07c 40804840 000c001c
	buffer_load_b128 v[68:71], v31, s[36:39], null offen offset:3072 ; c405c07c 40804844 000c001f
	v_swap_b32 v28, v54                                         ; 7e38cb36
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[27:28], v[24:25], v[144:151] ; cc464090 1e42311b
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[27:28], v[46:47], v[176:183] ; cc4640b0 1ec25d1b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[27:28], v[44:45], v[112:119] ; cc464070 1dc2591b
	ds_load_b64 v[44:45], v77 offset:1792                       ; d9d80700 2c00004d
	ds_load_b64 v[24:25], v77 offset:3840                       ; d9d80f00 1800004d
	ds_load_b64 v[46:47], v77 offset:5888                       ; d9d81700 2e00004d
	ds_load_b64 v[78:79], v77 offset:7936                       ; d9d81f00 4e00004d
	v_mov_b32_e32 v77, v30                                      ; 7e9a031e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[27:28], v[34:35], v[16:23] ; cc464010 1c42451b
	v_mov_b32_e32 v27, v29                                      ; 7e36031d
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[50:51], v[120:127] ; cc464078 1de26538
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[52:53], v[152:159] ; cc464098 1e626938
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[36:37], v[184:191] ; cc4640b8 1ee24938
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[48:49], v[88:95] ; cc464058 1d626138
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[54:57], v54, s[36:39], null offen offset:3584 ; c405c07c 40804836 000e0036
	buffer_load_b128 v[28:31], v31, s[36:39], null offen offset:3584 ; c405c07c 4080481c 000e001f
	v_mad_u32_u24 v34, s59, 0x50, v72                           ; d60b0022 0521fe3b 00000050
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[48:49], v[96:103] ; cc464060 1d82613a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[50:51], v[128:135] ; cc464080 1e02653a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[52:53], v[160:167] ; cc4640a0 1e82693a
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[58:59], v[36:37], v[7:14] ; cc464007 1c1e493a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[52:53], v[168:175] ; cc4640a8 1ea2693c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[50:51], v[136:143] ; cc464088 1e22653c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[48:49], v[104:111] ; cc464068 1da2613c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[48:49], v[112:119] ; cc464070 1dc2613e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[50:51], v[144:151] ; cc464090 1e42653e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[52:53], v[176:183] ; cc4640b0 1ec2693e
	ds_load_b64 v[58:59], v34                                   ; d9d80000 3a000022
	ds_load_b64 v[48:49], v34 offset:2048                       ; d9d80800 30000022
	ds_load_b64 v[50:51], v34 offset:4096                       ; d9d81000 32000022
	ds_load_b64 v[52:53], v34 offset:6144                       ; d9d81800 34000022
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[36:37], v[80:87] ; cc464050 1d42493c
	v_add_nc_u32_e32 v35, 4, v26                                ; 4a463484
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[62:63], v[36:37], v[16:23] ; cc464010 1c42493e
	v_sub_nc_u32_e32 v36, 0, v35                                ; 4c484680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v36, v35, v36                                 ; 24484923
	v_med3_i32 v35, -1, v35, 1                                  ; d6200023 020646c1
	v_lshrrev_b32_e32 v36, 1, v36                               ; 32484881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0023
	v_cndmask_b32_e32 v1, v35, v36, vcc_lo                      ; 02024923
	v_lshl_add_u32 v35, v35, 10, s4                             ; d6460023 00111523
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v35, v35, v77, 2                             ; d6470023 020a9b23
	buffer_load_b128 v[60:63], v35, s[36:39], null offen        ; c405c07c 4080483c 00000023
	v_add_nc_u32_e32 v26, 6, v26                                ; 4a343486
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[38:39], v[88:95] ; cc464058 1d624d40
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[32:33], v[120:127] ; cc464078 1de24140
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[40:41], v[152:159] ; cc464098 1e625140
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[42:43], v[184:191] ; cc4640b8 1ee25540
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[38:39], v[96:103] ; cc464060 1d824d42
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[32:33], v[128:135] ; cc464080 1e024142
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[40:41], v[160:167] ; cc4640a0 1e825142
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[66:67], v[42:43], v[7:14] ; cc464007 1c1e5542
	v_sub_nc_u32_e32 v37, 0, v26                                ; 4c4a3480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v37, v26, v37                                 ; 244a4b1a
	v_med3_i32 v26, -1, v26, 1                                  ; d620001a 020634c1
	v_lshrrev_b32_e32 v37, 1, v37                               ; 324a4a81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c001a
	v_cndmask_b32_e32 v1, v26, v37, vcc_lo                      ; 02024b1a
	v_lshl_add_u32 v26, v26, 10, s4                             ; d646001a 0011151a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v26, v26, v77, 2                             ; d647001a 020a9b1a
	buffer_load_b128 v[64:67], v26, s[36:39], null offen        ; c405c07c 40804840 0000001a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[38:39], v[104:111] ; cc464068 1da24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[32:33], v[136:143] ; cc464088 1e224144
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[40:41], v[168:175] ; cc4640a8 1ea25144
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[38:39], v[112:119] ; cc464070 1dc24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[32:33], v[144:151] ; cc464090 1e424146
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[40:41], v[176:183] ; cc4640b0 1ec25146
	ds_load_b64 v[36:37], v34 offset:256                        ; d9d80100 24000022
	ds_load_b64 v[38:39], v34 offset:2304                       ; d9d80900 26000022
	ds_load_b64 v[32:33], v34 offset:4352                       ; d9d81100 20000022
	ds_load_b64 v[40:41], v34 offset:6400                       ; d9d81900 28000022
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[42:43], v[80:87] ; cc464050 1d425544
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[70:71], v[42:43], v[16:23] ; cc464010 1c425546
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[24:25], v[120:127] ; cc464078 1de23136
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[24:25], v[128:135] ; cc464080 1e023138
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[56:57], v[44:45], v[96:103] ; cc464060 1d825938
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[54:55], v[46:47], v[152:159] ; cc464098 1e625d36
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[56:57], v[46:47], v[160:167] ; cc4640a0 1e825d38
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[78:79], v[184:191] ; cc4640b8 1ee29d36
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[56:57], v[78:79], v[7:14] ; cc464007 1c1e9d38
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[54:55], v[44:45], v[88:95] ; cc464058 1d625936
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_maxmin_num_f32 v68, -4.0, v91, 4.0                        ; d6690044 03dab6f7
	v_maxmin_num_f32 v42, -4.0, v88, 4.0                        ; d669002a 03dab0f7
	v_maxmin_num_f32 v54, -4.0, v89, 4.0                        ; d6690036 03dab2f7
	v_maxmin_num_f32 v70, -4.0, v92, 4.0                        ; d6690046 03dab8f7
	v_maxmin_num_f32 v56, -4.0, v90, 4.0                        ; d6690038 03dab4f7
	v_fma_mix_f32 v69, 0xab28, |v68|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe88ff 3728ab28
	v_fma_mix_f32 v43, 0xab28, |v42|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622b 0bfe54ff 3728ab28
	v_fma_mix_f32 v55, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe6cff 3728ab28
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_fma_mix_f32 v57, 0xab28, |v56|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206239 0bfe70ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v55, v55, v54, 0x3f650000 :: v_dual_fmaak_f32 v42, v42, v43, 0x3f650000 ; c8426d37 372a572a 3f650000
	v_dual_fmaak_f32 v69, v69, v68, 0x3f650000 :: v_dual_fmaak_f32 v56, v56, v57, 0x3f650000 ; c8428945 45387338 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v89, v89, v55 :: v_dual_mul_f32 v88, v88, v42 ; c8c66f59 59585558
	v_dual_mul_f32 v91, v91, v69 :: v_dual_mul_f32 v90, v90, v56 ; c8c68b5b 5b5a715a
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v93, 4.0                        ; d6690058 03dabaf7
	v_maxmin_num_f32 v54, -4.0, v121, 4.0                       ; d6690036 03daf2f7
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v90, -4.0, v94, 4.0                        ; d669005a 03dabcf7
	v_maxmin_num_f32 v56, -4.0, v122, 4.0                       ; d6690038 03daf4f7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v68, -4.0, v123, 4.0                       ; d6690044 03daf6f7
	v_fma_mix_f32 v55, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe6cff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v57, 0xab28, |v56|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206239 0bfe70ff 3728ab28
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_fmaak_f32 v70, v70, v71, 0x3f650000 ; c842b159 59468f46 3f650000
	v_fma_mix_f32 v69, 0xab28, |v68|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe88ff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v125, 4.0                       ; d6690058 03dafaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v93, v93, v89 :: v_dual_mul_f32 v92, v92, v70 ; c8c6b35d 5d5c8d5c
	v_maxmin_num_f32 v70, -4.0, v124, 4.0                       ; d6690046 03daf8f7
	v_dual_fmaak_f32 v69, v69, v68, 0x3f650000 :: v_dual_fmaak_f32 v56, v56, v57, 0x3f650000 ; c8428945 45387338 3f650000
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v92, -4.0, v95, 4.0                        ; d669005c 03dabef7
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_dual_mul_f32 v123, v123, v69 :: v_dual_mul_f32 v122, v122, v56 ; c8c68b7b 7b7a717a
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_fmaak_f32 v70, v70, v71, 0x3f650000 ; c842b159 59468f46 3f650000
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 ; c842b95d 5d5ab75a 3f650000
	v_maxmin_num_f32 v92, -4.0, v127, 4.0                       ; d669005c 03dafef7
	v_dual_mul_f32 v125, v125, v89 :: v_dual_mul_f32 v124, v124, v70 ; c8c6b37d 7d7c8d7c
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_mul_f32 v95, v95, v93 :: v_dual_mul_f32 v94, v94, v90 ; c8c6bb5f 5f5eb55e
	v_maxmin_num_f32 v90, -4.0, v126, 4.0                       ; d669005a 03dafcf7
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v94, -4.0, v120, 4.0                       ; d669005e 03daf0f7
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 ; c842b95d 5d5ab75a 3f650000
	v_dual_fmaak_f32 v55, v55, v54, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c8426d37 375ebf5e 3f650000
	v_dual_mul_f32 v127, v127, v93 :: v_dual_mul_f32 v126, v126, v90 ; c8c6bb7f 7f7eb57e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v121, v121, v55 :: v_dual_mul_f32 v120, v120, v94 ; c8c66f79 7978bd78
	v_maxmin_num_f32 v94, -4.0, v152, 4.0                       ; d669005e 03db30f7
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v155, 4.0                      ; d669007c 03db36f7
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v156, 4.0                      ; d669007e 03db38f7
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v120, -4.0, v153, 4.0                      ; d6690078 03db32f7
	v_maxmin_num_f32 v122, -4.0, v154, 4.0                      ; d669007a 03db34f7
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c842f179 795ebf5e 3f650000
	v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 ; c842f97d 7d7af77a 3f650000
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[28:29], v[24:25], v[136:143] ; cc464088 1e22311c
	v_dual_mul_f32 v153, v153, v121 :: v_dual_mul_f32 v152, v152, v94 ; c8c6f399 9998bd98
	v_dual_mul_f32 v155, v155, v125 :: v_dual_mul_f32 v154, v154, v122 ; c8c6fb9b 9b9af59a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[30:31], v[24:25], v[144:151] ; cc464090 1e42311e
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v152, -4.0, v157, 4.0                      ; d6690098 03db3af7
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v154, -4.0, v158, 4.0                      ; d669009a 03db3cf7
	v_maxmin_num_f32 v24, -4.0, v185, 4.0                       ; d6690018 03db72f7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[44:45], v[104:111] ; cc464068 1da2591c
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v25, 0xab28, |v24|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe30ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[28:29], v[46:47], v[168:175] ; cc4640a8 1ea25d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[78:79], v[80:87] ; cc464050 1d429d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[44:45], v[112:119] ; cc464070 1dc2591e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[46:47], v[176:183] ; cc4640b0 1ec25d1e
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v127, 0x3f650000 ; c8433199 997eff7e 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[30:31], v[78:79], v[16:23] ; cc464010 1c429d1e
	v_maxmin_num_f32 v28, -4.0, v186, 4.0                       ; d669001c 03db74f7
	v_maxmin_num_f32 v30, -4.0, v187, 4.0                       ; d669001e 03db76f7
	v_dual_mul_f32 v157, v157, v153 :: v_dual_mul_f32 v156, v156, v126 ; c8c7339d 9d9cfd9c
	v_maxmin_num_f32 v44, -4.0, v188, 4.0                       ; d669002c 03db78f7
	v_maxmin_num_f32 v46, -4.0, v189, 4.0                       ; d669002e 03db7af7
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
	v_fma_mix_f32 v31, 0xab28, |v30|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621f 0bfe3cff 3728ab28
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_maxmin_num_f32 v156, -4.0, v159, 4.0                      ; d669009c 03db3ef7
	v_fma_mix_f32 v45, 0xab28, |v44|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe58ff 3728ab28
	v_maxmin_num_f32 v68, -4.0, v190, 4.0                       ; d6690044 03db7cf7
	v_fma_mix_f32 v47, 0xab28, |v46|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622f 0bfe5cff 3728ab28
	v_maxmin_num_f32 v70, -4.0, v191, 4.0                       ; d6690046 03db7ef7
	v_dual_fmaak_f32 v31, v31, v30, 0x3f650000 :: v_dual_fmaak_f32 v28, v28, v29, 0x3f650000 ; c8423d1f 1f1c3b1c 3f650000
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v69, 0xab28, |v68|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe88ff 3728ab28
	v_dual_fmaak_f32 v47, v47, v46, 0x3f650000 :: v_dual_fmaak_f32 v44, v44, v45, 0x3f650000 ; c8425d2f 2f2c5b2c 3f650000
	v_maxmin_num_f32 v78, -4.0, v96, 4.0                        ; d669004e 03dac0f7
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_dual_mul_f32 v187, v187, v31 :: v_dual_mul_f32 v186, v186, v28 ; c8c63fbb bbba39ba
	v_maxmin_num_f32 v88, -4.0, v97, 4.0                        ; d6690058 03dac2f7
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c843399d 9d9b379a 3f650000
	v_dual_mul_f32 v189, v189, v47 :: v_dual_mul_f32 v188, v188, v44 ; c8c65fbd bdbc59bc
	v_fma_mix_f32 v79, 0xab28, |v78|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624f 0bfe9cff 3728ab28
	v_maxmin_num_f32 v90, -4.0, v98, 4.0                        ; d669005a 03dac4f7
	v_dual_fmaak_f32 v71, v71, v70, 0x3f650000 :: v_dual_fmaak_f32 v68, v68, v69, 0x3f650000 ; c8428d47 47448b44 3f650000
	v_maxmin_num_f32 v92, -4.0, v99, 4.0                        ; d669005c 03dac6f7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_dual_mul_f32 v159, v159, v157 :: v_dual_mul_f32 v158, v158, v154 ; c8c73b9f 9f9f359e
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_dual_mul_f32 v191, v191, v71 :: v_dual_mul_f32 v190, v190, v68 ; c8c68fbf bfbe89be
	v_maxmin_num_f32 v94, -4.0, v100, 4.0                       ; d669005e 03dac8f7
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_fmaak_f32 v78, v78, v79, 0x3f650000 ; c842b159 594e9f4e 3f650000
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_maxmin_num_f32 v158, -4.0, v184, 4.0                      ; d669009e 03db70f7
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 ; c842b95d 5d5ab75a 3f650000
	v_dual_mul_f32 v97, v97, v89 :: v_dual_mul_f32 v96, v96, v78 ; c8c6b361 61609d60
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_mul_f32 v99, v99, v93 :: v_dual_mul_f32 v98, v98, v90 ; c8c6bb63 6362b562
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v96, -4.0, v101, 4.0                       ; d6690060 03dacaf7
	v_dual_fmaak_f32 v25, v25, v24, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c8423119 199f3f9e 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v98, -4.0, v102, 4.0                       ; d6690062 03daccf7
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_dual_mul_f32 v185, v185, v25 :: v_dual_mul_f32 v184, v184, v158 ; c8c633b9 b9b93db8
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v120, -4.0, v129, 4.0                      ; d6690078 03db02f7
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c842c161 615ebf5e 3f650000
	v_maxmin_num_f32 v122, -4.0, v130, 4.0                      ; d669007a 03db04f7
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v124, -4.0, v131, 4.0                      ; d669007c 03db06f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_dual_mul_f32 v101, v101, v97 :: v_dual_mul_f32 v100, v100, v94 ; c8c6c365 6564bd64
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_maxmin_num_f32 v126, -4.0, v132, 4.0                      ; d669007e 03db08f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v100, -4.0, v103, 4.0                      ; d6690064 03dacef7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 ; c842f97d 7d7af77a 3f650000
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v131, v131, v125 :: v_dual_mul_f32 v130, v130, v122 ; c8c6fb83 8382f582
	v_dual_fmaak_f32 v101, v101, v100, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v99, 0x3f650000 ; c842c965 6562c762 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v103, v103, v101 :: v_dual_mul_f32 v102, v102, v98 ; c8c6cb67 6766c566
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v102, -4.0, v128, 4.0                      ; d6690066 03db00f7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 ; c842f179 7966cf66 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v129, v129, v121 :: v_dual_mul_f32 v128, v128, v102 ; c8c6f381 8180cd80
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v128, -4.0, v133, 4.0                      ; d6690080 03db0af7
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v130, -4.0, v134, 4.0                      ; d6690082 03db0cf7
	v_maxmin_num_f32 v152, -4.0, v161, 4.0                      ; d6690098 03db42f7
	v_maxmin_num_f32 v154, -4.0, v162, 4.0                      ; d669009a 03db44f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v163, 4.0                      ; d669009c 03db46f7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v127, 0x3f650000 ; c8430181 817eff7e 3f650000
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v164, 4.0                      ; d669009e 03db48f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_mul_f32 v133, v133, v129 :: v_dual_mul_f32 v132, v132, v126 ; c8c70385 8584fd84
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c843399d 9d9b379a 3f650000
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v132, -4.0, v135, 4.0                      ; d6690084 03db0ef7
	v_dual_mul_f32 v163, v163, v157 :: v_dual_mul_f32 v162, v162, v154 ; c8c73ba3 a3a335a2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8430985 85830782 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v135, v135, v133 :: v_dual_mul_f32 v134, v134, v130 ; c8c70b87 87870586
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v134, -4.0, v160, 4.0                      ; d6690086 03db40f7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c8433199 99870f86 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v161, v161, v153 :: v_dual_mul_f32 v160, v160, v134 ; c8c733a1 a1a10da0
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_maxmin_num_f32 v160, -4.0, v165, 4.0                      ; d66900a0 03db4af7
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_maxmin_num_f32 v162, -4.0, v166, 4.0                      ; d66900a2 03db4cf7
	v_maxmin_num_f32 v184, -4.0, v8, 4.0                        ; d66900b8 03da10f7
	v_maxmin_num_f32 v186, -4.0, v9, 4.0                        ; d66900ba 03da12f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v10, 4.0                       ; d66900bc 03da14f7
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84341a1 a19f3f9e 3f650000
	v_maxmin_num_f32 v190, -4.0, v11, 4.0                       ; d66900be 03da16f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84371b9 b9bb77ba 3f650000
	v_dual_mul_f32 v165, v165, v161 :: v_dual_mul_f32 v164, v164, v158 ; c8c743a5 a5a53da4
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_mul_f32 v9, v9, v186 :: v_dual_mul_f32 v8, v8, v185  ; c8c77509 09097308
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_maxmin_num_f32 v164, -4.0, v167, 4.0                      ; d66900a4 03db4ef7
	v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 :: v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 ; c8437fbe bebd79bd 3f650000
	v_maxmin_num_f32 v191, -4.0, v12, 4.0                       ; d66900bf 03da18f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84349a5 a5a347a2 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v167, v167, v165 :: v_dual_mul_f32 v166, v166, v162 ; c8c74ba7 a7a745a6
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_maxmin_num_f32 v166, -4.0, v7, 4.0                        ; d66900a6 03da0ef7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_fmaak_f32 v166, v166, v167, 0x3f650000                    ; 5b4d4fa6 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_f32_e32 v7, v7, v166                                  ; 100f4d07
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                        ; 02021107
	v_maxmin_num_f32 v8, -4.0, v13, 4.0                         ; d6690008 03da1af7
	v_fma_mix_f32 v7, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v10, v10, v189 :: v_dual_fmaak_f32 v7, v7, v191, 0x3f650000 ; c8c37b0a 0a077f07 3f650000
	v_maxmin_num_f32 v69, -4.0, v106, 4.0                       ; d6690045 03dad4f7
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                       ; 02021509
	v_maxmin_num_f32 v10, -4.0, v14, 4.0                        ; d669000a 03da1cf7
	v_fma_mix_f32 v9, 0xab28, |v8|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206209 0bfe10ff 3728ab28
	v_dual_mul_f32 v12, v12, v7 :: v_dual_mul_f32 v11, v11, v190 ; c8c60f0c 0c0b7d0b
	v_maxmin_num_f32 v71, -4.0, v107, 4.0                       ; d6690047 03dad6f7
	v_fma_mix_f32 v70, 0xab28, |v69|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe8aff 3728ab28
	v_maxmin_num_f32 v79, -4.0, v108, 4.0                       ; d669004f 03dad8f7
	v_maxmin_num_f32 v89, -4.0, v109, 4.0                       ; d6690059 03dadaf7
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v11, v12, vcc_lo                      ; 0202190b
	v_maxmin_num_f32 v12, -4.0, v104, 4.0                       ; d669000c 03dad0f7
	v_fma_mix_f32 v11, 0xab28, |v10|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620b 0bfe14ff 3728ab28
	v_fma_mix_f32 v78, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe8eff 3728ab28
	v_fma_mix_f32 v88, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfe9eff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v110, 4.0                       ; d669005b 03dadcf7
	v_maxmin_num_f32 v93, -4.0, v111, 4.0                       ; d669005d 03dadef7
	v_dual_fmaak_f32 v11, v11, v10, 0x3f650000 :: v_dual_fmaak_f32 v8, v8, v9, 0x3f650000 ; c842150b 0b081308 3f650000
	v_dual_fmaak_f32 v78, v78, v71, 0x3f650000 :: v_dual_fmaak_f32 v69, v69, v70, 0x3f650000 ; c8428f4e 4e448d45 3f650000
	v_dual_fmaak_f32 v79, v79, v88, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b14f 4f5ab35a 3f650000
	v_maxmin_num_f32 v95, -4.0, v136, 4.0                       ; d669005f 03db10f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_mul_f32 v14, v14, v11 :: v_dual_mul_f32 v13, v13, v8 ; c8c6170e 0e0c110d
	v_maxmin_num_f32 v97, -4.0, v137, 4.0                       ; d6690061 03db12f7
	v_dual_mul_f32 v109, v109, v90 :: v_dual_mul_f32 v106, v106, v69 ; c8c6b56d 6d6a8b6a
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v138, 4.0                       ; d6690063 03db14f7
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842b95b 5b5ebb5e 3f650000
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                      ; 02021d0d
	v_maxmin_num_f32 v14, -4.0, v105, 4.0                       ; d669000e 03dad2f7
	v_fma_mix_f32 v13, 0xab28, |v12|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bfe18ff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v139, 4.0                      ; d6690065 03db16f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_dual_mul_f32 v111, v111, v94 :: v_dual_mul_f32 v108, v108, v79 ; c8c6bd6f 6f6c9f6c
	v_maxmin_num_f32 v103, -4.0, v140, 4.0                      ; d6690067 03db18f7
	v_fma_mix_f32 v68, 0xab28, |v14|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206244 0bfe1cff 3728ab28
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 ; c842c15f 5f62c362 3f650000
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fmaak_f32 v68, v68, v14, 0x3f650000                       ; 5a881d44 3f650000
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c842c963 6366cb66 3f650000
	v_maxmin_num_f32 v109, -4.0, v143, 4.0                      ; d669006d 03db1ef7
	v_dual_mul_f32 v137, v137, v98 :: v_dual_mul_f32 v110, v110, v91 ; c8c6c589 896eb76e
	v_dual_fmaak_f32 v12, v12, v13, 0x3f650000 :: v_dual_mul_f32 v105, v105, v68 ; c8461b0c 0c688969 3f650000
	v_dual_mul_f32 v139, v139, v102 :: v_dual_mul_f32 v136, v136, v95 ; c8c6cd8b 8b88bf88
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_maxmin_num_f32 v111, -4.0, v168, 4.0                      ; d669006f 03db50f7
	v_maxmin_num_f32 v121, -4.0, v169, 4.0                      ; d6690079 03db52f7
	v_dual_mul_f32 v104, v104, v12 :: v_dual_mul_f32 v107, v107, v78 ; c8c61968 686a9d6b
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v120, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfedeff 3728ab28
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v105, -4.0, v141, 4.0                      ; d6690069 03db1af7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v107, -4.0, v142, 4.0                      ; d669006b 03db1cf7
	v_maxmin_num_f32 v123, -4.0, v170, 4.0                      ; d669007b 03db54f7
	v_maxmin_num_f32 v125, -4.0, v171, 4.0                      ; d669007d 03db56f7
	v_dual_fmaak_f32 v111, v111, v120, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f16f 6f7af37a 3f650000
	v_maxmin_num_f32 v127, -4.0, v172, 4.0                      ; d669007f 03db58f7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v173, 4.0                      ; d6690081 03db5af7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v174, 4.0                      ; d6690083 03db5cf7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 ; c842d167 676ad36a 3f650000
	v_maxmin_num_f32 v133, -4.0, v175, 4.0                      ; d6690085 03db5ef7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 ; c842d96b 6b6edb6e 3f650000
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c842f97b 7b7efb7e 3f650000
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v80, 4.0                       ; d6690087 03daa0f7
	v_dual_mul_f32 v141, v141, v106 :: v_dual_mul_f32 v138, v138, v99 ; c8c6d58d 8d8ac78a
	v_maxmin_num_f32 v137, -4.0, v81, 4.0                       ; d6690089 03daa2f7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 ; c843017f 7f830382 3f650000
	v_dual_mul_f32 v169, v169, v122 :: v_dual_mul_f32 v142, v142, v107 ; c8c6f5a9 a98ed78e
	v_dual_mul_f32 v143, v143, v110 :: v_dual_mul_f32 v140, v140, v103 ; c8c6dd8f 8f8ccf8c
	v_dual_mul_f32 v171, v171, v126 :: v_dual_mul_f32 v168, v168, v111 ; c8c6fdab aba8dfa8
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_maxmin_num_f32 v139, -4.0, v82, 4.0                       ; d669008b 03daa4f7
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 ; c8430983 83870b86 3f650000
	v_dual_mul_f32 v173, v173, v130 :: v_dual_mul_f32 v170, v170, v123 ; c8c705ad adaaf7aa
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_maxmin_num_f32 v141, -4.0, v83, 4.0                       ; d669008d 03daa6f7
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_maxmin_num_f32 v143, -4.0, v84, 4.0                       ; d669008f 03daa8f7
	v_maxmin_num_f32 v153, -4.0, v85, 4.0                       ; d6690099 03daaaf7
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 ; c8431187 878b138a 3f650000
	v_dual_mul_f32 v175, v175, v134 :: v_dual_mul_f32 v172, v172, v127 ; c8c70daf afacffac
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_maxmin_num_f32 v155, -4.0, v86, 4.0                       ; d669009b 03daacf7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v87, 4.0                       ; d669009d 03daaef7
	v_fma_mix_f32 v152, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff1eff 3728ab28
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v159, -4.0, v112, 4.0                      ; d669009f 03dae0f7
	v_dual_mul_f32 v81, v81, v138 :: v_dual_mul_f32 v174, v174, v131 ; c8c71551 51af07ae
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_maxmin_num_f32 v161, -4.0, v113, 4.0                      ; d66900a1 03dae2f7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 ; c843198b 8b8f1b8e 3f650000
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v114, 4.0                      ; d66900a3 03dae4f7
	v_dual_fmaak_f32 v143, v143, v152, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843318f 8f9b339a 3f650000
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_maxmin_num_f32 v165, -4.0, v115, 4.0                      ; d66900a5 03dae6f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_mul_f32 v83, v83, v142 :: v_dual_mul_f32 v80, v80, v135 ; c8c71d53 53510f50
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 ; c843399b 9b9f3b9e 3f650000
	v_maxmin_num_f32 v167, -4.0, v116, 4.0                      ; d66900a7 03dae8f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v169, -4.0, v117, 4.0                      ; d66900a9 03daeaf7
	v_dual_mul_f32 v85, v85, v154 :: v_dual_mul_f32 v82, v82, v139 ; c8c73555 55531752
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c843419f 9fa343a2 3f650000
	v_maxmin_num_f32 v171, -4.0, v118, 4.0                      ; d66900ab 03daecf7
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_dual_mul_f32 v87, v87, v158 :: v_dual_mul_f32 v84, v84, v143 ; c8c73d57 57551f54
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_maxmin_num_f32 v173, -4.0, v119, 4.0                      ; d66900ad 03daeef7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84349a3 a3a74ba6 3f650000
	v_dual_mul_f32 v113, v113, v162 :: v_dual_mul_f32 v86, v86, v155 ; c8c74571 71573756
	v_maxmin_num_f32 v175, -4.0, v144, 4.0                      ; d66900af 03db20f7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v145, 4.0                      ; d66900b9 03db22f7
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 ; c84351a7 a7ab53aa 3f650000
	v_maxmin_num_f32 v187, -4.0, v146, 4.0                      ; d66900bb 03db24f7
	v_dual_mul_f32 v115, v115, v166 :: v_dual_mul_f32 v112, v112, v159 ; c8c74d73 73713f70
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v189, -4.0, v147, 4.0                      ; d66900bd 03db26f7
	v_fma_mix_f32 v184, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff5eff 3728ab28
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v148, 4.0                      ; d66900bf 03db28f7
	v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v173, 0x3f650000 ; c84359ab abaf5bae 3f650000
	v_dual_mul_f32 v117, v117, v170 :: v_dual_mul_f32 v114, v114, v163 ; c8c75575 75734772
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v14, -4.0, v149, 4.0                       ; d669000e 03db2af7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_fmaak_f32 v175, v175, v184, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84371af afbb73ba 3f650000
	v_maxmin_num_f32 v80, -4.0, v150, 4.0                       ; d6690050 03db2cf7
	v_fma_mix_f32 v7, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bff7eff 3728ab28
	v_dual_mul_f32 v119, v119, v174 :: v_dual_mul_f32 v116, v116, v167 ; c8c75d77 77754f74
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v82, -4.0, v151, 4.0                       ; d6690052 03db2ef7
	v_fma_mix_f32 v79, 0xab28, |v14|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624f 0bfe1cff 3728ab28
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c84379bb bbbf7bbe 3f650000
	v_maxmin_num_f32 v84, -4.0, v176, 4.0                       ; d6690054 03db60f7
	v_dual_mul_f32 v145, v145, v186 :: v_dual_mul_f32 v118, v118, v171 ; c8c77591 91775776
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_maxmin_num_f32 v86, -4.0, v177, 4.0                       ; d6690056 03db62f7
	v_fmaak_f32 v191, v191, v7, 0x3f650000                      ; 5b7e0fbf 3f650000
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v178, 4.0                       ; d6690058 03db64f7
	v_dual_mul_f32 v147, v147, v190 :: v_dual_mul_f32 v144, v144, v175 ; c8c77d93 93915f90
	v_dual_fmaak_f32 v79, v79, v14, 0x3f650000 :: v_dual_mul_f32 v146, v146, v187 ; c8461d4f 4f937792 3f650000
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v90, -4.0, v179, 4.0                       ; d669005a 03db66f7
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v180, 4.0                       ; d669005c 03db68f7
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c842a553 5350a350 3f650000
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v94, -4.0, v181, 4.0                       ; d669005e 03db6af7
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_dual_mul_f32 v149, v79, v149 :: v_dual_mul_f32 v148, v148, v191 ; c8c72b4f 95957f94
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_maxmin_num_f32 v96, -4.0, v182, 4.0                       ; d6690060 03db6cf7
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c842ad57 5754ab54 3f650000
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_mul_f32 v151, v151, v83 :: v_dual_mul_f32 v150, v150, v80 ; c8c6a797 9796a196
	v_maxmin_num_f32 v98, -4.0, v183, 4.0                       ; d6690062 03db6ef7
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v100, -4.0, v16, 4.0                       ; d6690064 03da20f7
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_maxmin_num_f32 v102, -4.0, v17, 4.0                       ; d6690066 03da22f7
	v_dual_mul_f32 v177, v177, v87 :: v_dual_mul_f32 v176, v176, v84 ; c8c6afb1 b1b0a9b0
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_maxmin_num_f32 v104, -4.0, v18, 4.0                       ; d6690068 03da24f7
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 ; c842bd5f 5f5cbb5c 3f650000
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_maxmin_num_f32 v106, -4.0, v19, 4.0                       ; d669006a 03da26f7
	v_dual_mul_f32 v179, v179, v91 :: v_dual_mul_f32 v178, v178, v88 ; c8c6b7b3 b3b2b1b2
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_maxmin_num_f32 v108, -4.0, v20, 4.0                       ; d669006c 03da28f7
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v97, 0x3f650000 ; c842c563 6360c360 3f650000
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_maxmin_num_f32 v110, -4.0, v21, 4.0                       ; d669006e 03da2af7
	v_dual_mul_f32 v181, v181, v95 :: v_dual_mul_f32 v180, v180, v92 ; c8c6bfb5 b5b4b9b4
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c842cd67 6764cb64 3f650000
	v_maxmin_num_f32 v112, -4.0, v22, 4.0                       ; d6690070 03da2cf7
	v_maxmin_num_f32 v114, -4.0, v23, 4.0                       ; d6690072 03da2ef7
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_dual_mul_f32 v183, v183, v99 :: v_dual_mul_f32 v182, v182, v96 ; c8c6c7b7 b7b6c1b6
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 ; c842d56b 6b68d368 3f650000
	v_dual_mul_f32 v17, v17, v103 :: v_dual_mul_f32 v16, v16, v100 ; c8c6cf11 1110c910
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[60:61], v[58:59], 0 ; cc464058 1a02753c
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[60:61], v[48:49], 0 ; cc464060 1a02613c
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
	v_dual_mul_f32 v19, v19, v107 :: v_dual_mul_f32 v18, v18, v104 ; c8c6d713 1312d112
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[62:63], v[58:59], 0 ; cc464078 1a02753e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[48:49], 0 ; cc464080 1a02613e
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[62:63], v[50:51], 0 ; cc464088 1a02653e
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[52:53], 0 ; cc464090 1a02693e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[58:59], 0 ; cc464098 1a027540
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[64:65], v[48:49], 0 ; cc4640a0 1a026140
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[64:65], v[50:51], 0 ; cc4640a8 1a026540
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[64:65], v[52:53], 0 ; cc4640b0 1a026940
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 ; c842e573 7370e370 3f650000
	v_dual_mul_f32 v21, v21, v111 :: v_dual_mul_f32 v20, v20, v108 ; c8c6df15 1514d914
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[50:51], 0 ; cc464068 1a02653c
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[66:67], v[58:59], 0 ; cc4640b8 1a027542
	v_dual_mul_f32 v23, v23, v115 :: v_dual_mul_f32 v22, v22, v112 ; c8c6e717 1716e116
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[60:61], v[52:53], 0 ; cc464070 1a02693c
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[66:67], v[48:49], 0 ; cc46403a 1a026142
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mov_b32 v49, v17 :: v_dual_mov_b32 v48, v16          ; ca100111 31300110
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[66:67], v[50:51], 0 ; cc464010 1a026542
	v_dual_mov_b32 v51, v81 :: v_dual_mov_b32 v50, v80          ; ca100151 33320150
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[66:67], v[52:53], 0 ; cc464050 1a026942
	v_dual_mov_b32 v67, v55 :: v_dual_mov_b32 v66, v54          ; ca100137 43420136
	buffer_load_b128 v[52:55], v35, s[36:39], null offen offset:512 ; c405c07c 40804834 00020023
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[54:55], v[32:33], v[136:143] ; cc464088 1e224136
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[36:37], v[88:95] ; cc464058 1d624934
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[36:37], v[120:127] ; cc464078 1de24936
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[38:39], v[96:103] ; cc464060 1d824d34
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[32:33], v[104:111] ; cc464068 1da24134
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[38:39], v[128:135] ; cc464080 1e024d36
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[40:41], v[144:151] ; cc464090 1e425136
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[52:53], v[40:41], v[112:119] ; cc464070 1dc25134
	buffer_load_b128 v[52:55], v26, s[36:39], null offen offset:512 ; c405c07c 40804834 0002001a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[54:55], v[38:39], v[58:65] ; cc46403a 1cea4d36
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[32:33], v[16:23] ; cc464010 1c424136
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[36:37], v[152:159] ; cc464098 1e624934
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[36:37], v[184:191] ; cc4640b8 1ee24936
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[52:53], v[40:41], v[176:183] ; cc4640b0 1ec25134
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[38:39], v[160:167] ; cc4640a0 1e824d34
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[32:33], v[168:175] ; cc4640a8 1ea24134
	ds_load_b64 v[52:53], v34 offset:512                        ; d9d80200 34000022
	ds_load_b64 v[36:37], v34 offset:2560                       ; d9d80a00 24000022
	ds_load_b64 v[38:39], v34 offset:4608                       ; d9d81200 26000022
	ds_load_b64 v[32:33], v34 offset:6656                       ; d9d81a00 20000022
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[54:55], v[40:41], v[80:87] ; cc464050 1d425136
	v_dual_mov_b32 v55, v43 :: v_dual_mov_b32 v54, v42          ; ca10012b 3736012a
	buffer_load_b128 v[40:43], v35, s[36:39], null offen offset:1024 ; c405c07c 40804828 00040023
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[38:39], v[104:111] ; cc464068 1da24d28
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[32:33], v[112:119] ; cc464070 1dc24128
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[52:53], v[120:127] ; cc464078 1de2692a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[36:37], v[128:135] ; cc464080 1e02492a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[38:39], v[136:143] ; cc464088 1e224d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[32:33], v[144:151] ; cc464090 1e42412a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[36:37], v[96:103] ; cc464060 1d824928
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[52:53], v[88:95] ; cc464058 1d626928
	buffer_load_b128 v[40:43], v26, s[36:39], null offen offset:1024 ; c405c07c 40804828 0004001a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[42:43], v[36:37], v[58:65] ; cc46403a 1cea492a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[38:39], v[168:175] ; cc4640a8 1ea24d28
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[40:41], v[32:33], v[176:183] ; cc4640b0 1ec24128
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[42:43], v[38:39], v[16:23] ; cc464010 1c424d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[42:43], v[52:53], v[184:191] ; cc4640b8 1ee2692a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[40:41], v[36:37], v[160:167] ; cc4640a0 1e824928
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[52:53], v[152:159] ; cc464098 1e626928
	ds_load_b64 v[40:41], v34 offset:768                        ; d9d80300 28000022
	ds_load_b64 v[52:53], v34 offset:2816                       ; d9d80b00 34000022
	ds_load_b64 v[36:37], v34 offset:4864                       ; d9d81300 24000022
	ds_load_b64 v[38:39], v34 offset:6912                       ; d9d81b00 26000022
	v_dual_mov_b32 v14, v35 :: v_dual_mov_b32 v7, v34           ; ca100123 0e060122
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[42:43], v[32:33], v[80:87] ; cc464050 1d42412a
	buffer_load_b128 v[32:35], v35, s[36:39], null offen offset:1536 ; c405c07c 40804820 00060023
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[32:33], v[36:37], v[104:111] ; cc464068 1da24920
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[38:39], v[112:119] ; cc464070 1dc24d20
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[40:41], v[120:127] ; cc464078 1de25122
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[52:53], v[128:135] ; cc464080 1e026922
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[34:35], v[36:37], v[136:143] ; cc464088 1e224922
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[34:35], v[38:39], v[144:151] ; cc464090 1e424d22
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[52:53], v[96:103] ; cc464060 1d826920
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[40:41], v[88:95] ; cc464058 1d625120
	buffer_load_b128 v[32:35], v26, s[36:39], null offen offset:1536 ; c405c07c 40804820 0006001a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[32:33], v[36:37], v[168:175] ; cc4640a8 1ea24920
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[34:35], v[36:37], v[16:23] ; cc464010 1c424922
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[40:41], v[152:159] ; cc464098 1e625120
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[32:33], v[38:39], v[176:183] ; cc4640b0 1ec24d20
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[32:33], v[52:53], v[160:167] ; cc4640a0 1e826920
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[34:35], v[40:41], v[184:191] ; cc4640b8 1ee25122
	ds_load_b64 v[32:33], v7 offset:1024                        ; d9d80400 20000007
	ds_load_b64 v[40:41], v7 offset:3072                        ; d9d80c00 28000007
	ds_load_b64 v[42:43], v7 offset:5120                        ; d9d81400 2a000007
	ds_load_b64 v[36:37], v7 offset:7168                        ; d9d81c00 24000007
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[34:35], v[52:53], v[58:65] ; cc46403a 1cea6922
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[34:35], v[38:39], v[80:87] ; cc464050 1d424d22
	s_wait_dscnt 0x3                                            ; bfc60003
	v_dual_mov_b32 v39, v33 :: v_dual_mov_b32 v38, v32          ; ca100121 27260120
	buffer_load_b128 v[32:35], v14, s[36:39], null offen offset:2048 ; c405c07c 40804820 0008000e
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[32:33], v[42:43], v[104:111] ; cc464068 1da25520
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[36:37], v[112:119] ; cc464070 1dc24920
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[38:39], v[120:127] ; cc464078 1de24d22
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[40:41], v[128:135] ; cc464080 1e025122
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[34:35], v[42:43], v[136:143] ; cc464088 1e225522
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[34:35], v[36:37], v[144:151] ; cc464090 1e424922
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[38:39], v[88:95] ; cc464058 1d624d20
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[40:41], v[96:103] ; cc464060 1d825120
	buffer_load_b128 v[32:35], v26, s[36:39], null offen offset:2048 ; c405c07c 40804820 0008001a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[32:33], v[36:37], v[176:183] ; cc4640b0 1ec24920
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[32:33], v[40:41], v[160:167] ; cc4640a0 1e825120
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[34:35], v[40:41], v[58:65] ; cc46403a 1cea5122
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[34:35], v[42:43], v[16:23] ; cc464010 1c425522
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[32:33], v[42:43], v[168:175] ; cc4640a8 1ea25520
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[34:35], v[38:39], v[184:191] ; cc4640b8 1ee24d22
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[38:39], v[152:159] ; cc464098 1e624d20
	ds_load_b64 v[32:33], v7 offset:1280                        ; d9d80500 20000007
	ds_load_b64 v[38:39], v7 offset:3328                        ; d9d80d00 26000007
	ds_load_b64 v[40:41], v7 offset:5376                        ; d9d81500 28000007
	ds_load_b64 v[42:43], v7 offset:7424                        ; d9d81d00 2a000007
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[34:35], v[36:37], v[80:87] ; cc464050 1d424922
	buffer_load_b128 v[34:37], v14, s[36:39], null offen offset:2560 ; c405c07c 40804822 000a000e
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[42:43], v[112:119] ; cc464070 1dc25522
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[32:33], v[120:127] ; cc464078 1de24124
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[36:37], v[38:39], v[128:135] ; cc464080 1e024d24
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[36:37], v[40:41], v[136:143] ; cc464088 1e225124
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[42:43], v[144:151] ; cc464090 1e425524
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[34:35], v[40:41], v[104:111] ; cc464068 1da25122
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[34:35], v[32:33], v[88:95] ; cc464058 1d624122
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[38:39], v[96:103] ; cc464060 1d824d22
	buffer_load_b128 v[34:37], v26, s[36:39], null offen offset:2560 ; c405c07c 40804822 000a001a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[36:37], v[38:39], v[58:65] ; cc46403a 1cea4d24
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[36:37], v[40:41], v[16:23] ; cc464010 1c425124
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[34:35], v[42:43], v[176:183] ; cc4640b0 1ec25522
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[34:35], v[38:39], v[160:167] ; cc4640a0 1e824d22
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[36:37], v[32:33], v[184:191] ; cc4640b8 1ee24124
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[34:35], v[40:41], v[168:175] ; cc4640a8 1ea25122
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[34:35], v[32:33], v[152:159] ; cc464098 1e624122
	ds_load_b64 v[34:35], v7 offset:1536                        ; d9d80600 22000007
	ds_load_b64 v[32:33], v7 offset:3584                        ; d9d80e00 20000007
	ds_load_b64 v[38:39], v7 offset:5632                        ; d9d81600 26000007
	ds_load_b64 v[40:41], v7 offset:7680                        ; d9d81e00 28000007
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[42:43], v[80:87] ; cc464050 1d425524
	s_wait_dscnt 0x1                                            ; bfc60001
	v_dual_mov_b32 v43, v39 :: v_dual_mov_b32 v42, v38          ; ca100127 2b2a0126
	buffer_load_b128 v[36:39], v14, s[36:39], null offen offset:3072 ; c405c07c 40804824 000c000e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[42:43], v[104:111] ; cc464068 1da25524
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[40:41], v[112:119] ; cc464070 1dc25124
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[34:35], v[120:127] ; cc464078 1de24526
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[38:39], v[32:33], v[128:135] ; cc464080 1e024126
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[38:39], v[42:43], v[136:143] ; cc464088 1e225526
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[32:33], v[96:103] ; cc464060 1d824124
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[40:41], v[144:151] ; cc464090 1e425126
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[34:35], v[88:95] ; cc464058 1d624524
	buffer_load_b128 v[36:39], v26, s[36:39], null offen offset:3072 ; c405c07c 40804824 000c001a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[38:39], v[32:33], v[58:65] ; cc46403a 1cea4126
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[36:37], v[42:43], v[168:175] ; cc4640a8 1ea25524
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[38:39], v[42:43], v[16:23] ; cc464010 1c425526
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[36:37], v[40:41], v[176:183] ; cc4640b0 1ec25124
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[36:37], v[34:35], v[152:159] ; cc464098 1e624524
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[38:39], v[34:35], v[184:191] ; cc4640b8 1ee24526
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[36:37], v[32:33], v[160:167] ; cc4640a0 1e824124
	ds_load_b64 v[36:37], v7 offset:1792                        ; d9d80700 24000007
	ds_load_b64 v[34:35], v7 offset:3840                        ; d9d80f00 22000007
	ds_load_b64 v[32:33], v7 offset:5888                        ; d9d81700 20000007
	ds_load_b64 v[42:43], v7 offset:7936                        ; d9d81f00 2a000007
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[38:39], v[40:41], v[80:87] ; cc464050 1d425126
	buffer_load_b128 v[38:41], v14, s[36:39], null offen offset:3584 ; c405c07c 40804826 000e000e
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[32:33], v[104:111] ; cc464068 1da24126
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[42:43], v[112:119] ; cc464070 1dc25526
	v_dual_mov_b32 v14, v41 :: v_dual_mov_b32 v7, v40           ; ca100129 0e060128
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[34:35], v[96:103] ; cc464060 1d824526
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[38:39], v[36:37], v[88:95] ; cc464058 1d624926
	buffer_load_b128 v[38:41], v26, s[36:39], null offen offset:3584 ; c405c07c 40804826 000e001a
	v_dual_mov_b32 v53, v14 :: v_dual_mov_b32 v52, v7           ; ca10010e 35340107
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[42:43], v[144:151] ; cc464090 1e425534
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[52:53], v[36:37], v[120:127] ; cc464078 1de24934
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[52:53], v[34:35], v[128:135] ; cc464080 1e024534
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[32:33], v[136:143] ; cc464088 1e224134
	v_maxmin_num_f32 v14, -4.0, v90, 4.0                        ; d669000e 03dab4f7
	v_maxmin_num_f32 v53, -4.0, v89, 4.0                        ; d6690035 03dab2f7
	v_maxmin_num_f32 v26, -4.0, v88, 4.0                        ; d669001a 03dab0f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mix_f32 v7, 0xab28, |v53|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bfe6aff 3728ab28
	v_fma_mix_f32 v52, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206234 0bfe34ff 3728ab28
	v_fmaak_f32 v26, v26, v52, 0x3f650000                       ; 5a34691a 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v88, v88, v26 :: v_dual_fmaak_f32 v7, v7, v53, 0x3f650000 ; c8c23558 58066b07 3f650000
	v_maxmin_num_f32 v53, -4.0, v91, 4.0                        ; d6690035 03dab6f7
	v_fma_mix_f32 v26, 0xab28, |v14|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe1cff 3728ab28
	v_dual_fmaak_f32 v14, v14, v26, 0x3f650000 :: v_dual_mul_f32 v89, v89, v7 ; c846350e 0e580f59 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v89, -4.0, v92, 4.0                        ; d6690059 03dab8f7
	v_fma_mix_f32 v88, 0xab28, |v53|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfe6aff 3728ab28
	v_fmaak_f32 v88, v88, v53, 0x3f650000                       ; 5ab06b58 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_mul_f32 v90, v90, v14 :: v_dual_mul_f32 v91, v91, v88 ; c8c61d5a 5a5ab15b
	v_maxmin_num_f32 v14, -4.0, v94, 4.0                        ; d669000e 03dabcf7
	v_maxmin_num_f32 v88, -4.0, v95, 4.0                        ; d6690058 03dabef7
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v93, 4.0                        ; d669005b 03dabaf7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_fma_mix_f32 v26, 0xab28, |v14|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe1cff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v7, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bfeb6ff 3728ab28
	v_fmaak_f32 v89, v89, v90, 0x3f650000                       ; 5ab2b559 3f650000
	v_maxmin_num_f32 v90, -4.0, v96, 4.0                        ; d669005a 03dac0f7
	v_fmaak_f32 v7, v7, v91, 0x3f650000                         ; 5a0eb707 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_dual_mul_f32 v93, v93, v7 :: v_dual_mul_f32 v92, v92, v89 ; c8c60f5d 5d5cb35c
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v92, -4.0, v97, 4.0                        ; d669005c 03dac2f7
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_fmaak_f32 v14, v14, v26, 0x3f650000 ; c842b159 590e350e 3f650000
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_mul_f32 v95, v95, v89 :: v_dual_mul_f32 v94, v94, v14 ; c8c6b35f 5f5e1d5e
	v_maxmin_num_f32 v7, -4.0, v101, 4.0                        ; d6690007 03dacaf7
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 ; c842b95d 5d5ab75a 3f650000
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v94, -4.0, v98, 4.0                        ; d669005e 03dac4f7
	v_maxmin_num_f32 v26, -4.0, v102, 4.0                       ; d669001a 03daccf7
	v_fma_mix_f32 v14, 0xab28, |v7|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620e 0bfe0eff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v103, 4.0                       ; d669005b 03dacef7
	v_dual_mul_f32 v97, v97, v93 :: v_dual_mul_f32 v96, v96, v90 ; c8c6bb61 6160b560
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfe34ff 3728ab28
	v_fmaak_f32 v14, v14, v7, 0x3f650000                        ; 5a1c0f0e 3f650000
	v_maxmin_num_f32 v93, -4.0, v104, 4.0                       ; d669005d 03dad0f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v96, -4.0, v99, 4.0                        ; d6690060 03dac6f7
	v_fmaak_f32 v26, v26, v90, 0x3f650000                       ; 5a34b51a 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_mul_f32 v101, v101, v14 ; c846b75c 5c641d65 3f650000
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v102, v102, v26 :: v_dual_mul_f32 v103, v103, v92 ; c8c63566 6666b967
	v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c842c161 615ebf5e 3f650000
	v_maxmin_num_f32 v95, -4.0, v105, 4.0                       ; d669005f 03dad2f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_dual_mul_f32 v99, v99, v97 :: v_dual_mul_f32 v98, v98, v94 ; c8c6c363 6362bd62
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v106, 4.0                       ; d6690061 03dad4f7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v98, -4.0, v100, 4.0                       ; d6690062 03dac8f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v104, v104, v93 :: v_dual_mul_f32 v105, v105, v96 ; c8c6bb68 6868c169
	v_fmaak_f32 v98, v98, v99, 0x3f650000                       ; 5ac4c762 3f650000
	v_maxmin_num_f32 v99, -4.0, v107, 4.0                       ; d6690063 03dad6f7
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v105, -4.0, v110, 4.0                      ; d6690069 03dadcf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_mul_f32_e32 v100, v100, v98                               ; 10c8c564
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v101, -4.0, v108, 4.0                      ; d6690065 03dad8f7
	v_maxmin_num_f32 v103, -4.0, v109, 4.0                      ; d6690067 03dadaf7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_maxmin_num_f32 v14, -4.0, v114, 4.0                       ; d669000e 03dae4f7
	v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 :: v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 ; c842c764 6460c561 3f650000
	v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 ; c842cd65 6568cf68 3f650000
	v_fma_mix_f32 v26, 0xab28, |v14|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe1cff 3728ab28
	v_dual_mul_f32 v107, v107, v100 :: v_dual_mul_f32 v106, v106, v97 ; c8c6c96b 6b6ac36a
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_mul_f32 v109, v109, v104 :: v_dual_mul_f32 v108, v108, v101 ; c8c6d16d 6d6ccb6c
	v_maxmin_num_f32 v93, -4.0, v115, 4.0                       ; d669005d 03dae6f7
	v_fmaak_f32 v14, v14, v26, 0x3f650000                       ; 5a1c350e 3f650000
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v107, -4.0, v111, 4.0                      ; d669006b 03dadef7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v116, 4.0                       ; d669005f 03dae8f7
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v109, -4.0, v112, 4.0                      ; d669006d 03dae0f7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v117, 4.0                       ; d6690061 03daeaf7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v118, 4.0                       ; d6690063 03daecf7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v119, 4.0                      ; d6690065 03daeef7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 :: v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 ; c842d76c 6c68d569 3f650000
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v120, 4.0                      ; d6690067 03daf0f7
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c842c362 625ec15f 3f650000
	v_dual_mul_f32 v111, v111, v108 :: v_dual_mul_f32 v110, v110, v105 ; c8c6d96f 6f6ed36e
	v_maxmin_num_f32 v105, -4.0, v121, 4.0                      ; d6690069 03daf2f7
	v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 :: v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 ; c842cb66 6662c963 3f650000
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_mul_f32 v116, v116, v95 :: v_dual_mul_f32 v117, v117, v98 ; c8c6bf74 7474c575
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v111, -4.0, v113, 4.0                      ; d669006f 03dae2f7
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v122, 4.0                      ; d669006b 03daf4f7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_mul_f32 v119, v119, v102 :: v_dual_mul_f32 v118, v118, v99 ; c8c6cd77 7776c776
	v_fma_mix_f32 v7, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bfedeff 3728ab28
	v_fmaak_f32 v109, v109, v110, 0x3f650000                    ; 5adadd6d 3f650000
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 :: v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 ; c842d36a 6a66d167 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_mul_f32 v114, v114, v14 :: v_dual_fmaak_f32 v7, v7, v111, 0x3f650000 ; c8c21d72 7206df07 3f650000
	v_maxmin_num_f32 v111, -4.0, v124, 4.0                      ; d669006f 03daf8f7
	v_dual_mul_f32 v121, v121, v106 :: v_dual_mul_f32 v120, v120, v103 ; c8c6d579 7978cf78
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v113, v113, v7 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c8c20f71 715ebb5e 3f650000
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v117, -4.0, v127, 4.0                      ; d6690075 03dafef7
	v_dual_mul_f32 v115, v115, v94 :: v_dual_mul_f32 v112, v112, v109 ; c8c6bd73 7370db70
	v_maxmin_num_f32 v109, -4.0, v123, 4.0                      ; d669006d 03daf6f7
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v128, 4.0                      ; d6690077 03db00f7
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v113, -4.0, v125, 4.0                      ; d6690071 03dafaf7
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v115, -4.0, v126, 4.0                      ; d6690073 03dafcf7
	v_maxmin_num_f32 v121, -4.0, v129, 4.0                      ; d6690079 03db02f7
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 :: v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 ; c842db6e 6e6ad96b 3f650000
	v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 :: v_dual_fmaak_f32 v111, v111, v112, 0x3f650000 ; c842e372 726ee16f 3f650000
	v_dual_fmaak_f32 v118, v118, v117, 0x3f650000 :: v_dual_fmaak_f32 v115, v115, v116, 0x3f650000 ; c842eb76 7672e973 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_mul_f32 v123, v123, v110 :: v_dual_mul_f32 v122, v122, v107 ; c8c6dd7b 7b7ad77a
	v_dual_mul_f32 v125, v125, v114 :: v_dual_mul_f32 v124, v124, v111 ; c8c6e57d 7d7cdf7c
	v_dual_mul_f32 v127, v127, v118 :: v_dual_mul_f32 v126, v126, v115 ; c8c6ed7f 7f7ee77e
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v130, 4.0                      ; d669007b 03db04f7
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v125, -4.0, v131, 4.0                      ; d669007d 03db06f7
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 :: v_dual_fmaak_f32 v119, v119, v120, 0x3f650000 ; c842f37a 7a76f177 3f650000
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v132, 4.0                      ; d669007f 03db08f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_dual_mul_f32 v129, v129, v122 :: v_dual_mul_f32 v128, v128, v119 ; c8c6f581 8180ef80
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c842f97b 7b7efb7e 3f650000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[38:39], v[36:37], v[152:159] ; cc464098 1e624926
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[42:43], v[176:183] ; cc4640b0 1ec25526
	v_dual_mul_f32 v131, v131, v126 :: v_dual_mul_f32 v130, v130, v123 ; c8c6fd83 8382f782
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[38:39], v[34:35], v[160:167] ; cc4640a0 1e824526
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[38:39], v[32:33], v[168:175] ; cc4640a8 1ea24126
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[40:41], v[32:33], v[16:23] ; cc464010 1c424128
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v129, -4.0, v133, 4.0                      ; d6690081 03db0af7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[40:41], v[36:37], v[184:191] ; cc4640b8 1ee24928
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[40:41], v[34:35], v[58:65] ; cc46403a 1cea4528
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[42:43], v[80:87] ; cc464050 1d425528
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v131, -4.0, v134, 4.0                      ; d6690083 03db0cf7
	v_maxmin_num_f32 v14, -4.0, v136, 4.0                       ; d669000e 03db10f7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v34, -4.0, v137, 4.0                       ; d6690022 03db12f7
	v_maxmin_num_f32 v36, -4.0, v138, 4.0                       ; d6690024 03db14f7
	v_maxmin_num_f32 v38, -4.0, v139, 4.0                       ; d6690026 03db16f7
	v_fma_mix_f32 v26, 0xab28, |v14|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe1cff 3728ab28
	v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 :: v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 ; c8430382 827f017f 3f650000
	v_maxmin_num_f32 v40, -4.0, v140, 4.0                       ; d6690028 03db18f7
	v_fma_mix_f32 v35, 0xab28, |v34|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206223 0bfe44ff 3728ab28
	v_fma_mix_f32 v37, 0xab28, |v36|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206225 0bfe48ff 3728ab28
	v_fma_mix_f32 v39, 0xab28, |v38|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206227 0bfe4cff 3728ab28
	v_maxmin_num_f32 v42, -4.0, v141, 4.0                       ; d669002a 03db1af7
	v_dual_mul_f32 v133, v133, v130 :: v_dual_mul_f32 v132, v132, v127 ; c8c70585 8584ff84
	v_fma_mix_f32 v41, 0xab28, |v40|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206229 0bfe50ff 3728ab28
	v_maxmin_num_f32 v96, -4.0, v142, 4.0                       ; d6690060 03db1cf7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v43, 0xab28, |v42|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622b 0bfe54ff 3728ab28
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v133, -4.0, v135, 4.0                      ; d6690085 03db0ef7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_maxmin_num_f32 v98, -4.0, v143, 4.0                       ; d6690062 03db1ef7
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_maxmin_num_f32 v100, -4.0, v144, 4.0                      ; d6690064 03db20f7
	v_fma_mix_f32 v7, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bff0aff 3728ab28
	v_fmaak_f32 v131, v131, v132, 0x3f650000                    ; 5b070983 3f650000
	v_maxmin_num_f32 v102, -4.0, v145, 4.0                      ; d6690066 03db22f7
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_dual_fmaak_f32 v7, v7, v133, 0x3f650000 :: v_dual_mul_f32 v134, v134, v131 ; c8470b07 07870786 3f650000
	v_maxmin_num_f32 v104, -4.0, v146, 4.0                      ; d6690068 03db24f7
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_dual_mul_f32 v135, v135, v7 :: v_dual_fmaak_f32 v14, v14, v26, 0x3f650000 ; c8c20f87 870e350e 3f650000
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_maxmin_num_f32 v106, -4.0, v147, 4.0                      ; d669006a 03db26f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v35, v34, v35, 0x3f650000 :: v_dual_mul_f32 v136, v136, v14 ; c8464722 23881d88 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_maxmin_num_f32 v108, -4.0, v148, 4.0                      ; d669006c 03db28f7
	v_dual_fmaak_f32 v36, v36, v37, 0x3f650000 :: v_dual_mul_f32 v137, v137, v35 ; c8464b24 24884789 3f650000
	v_maxmin_num_f32 v110, -4.0, v149, 4.0                      ; d669006e 03db2af7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_dual_fmaak_f32 v39, v39, v38, 0x3f650000 :: v_dual_mul_f32 v138, v138, v36 ; c8464d27 278a498a 3f650000
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v150, 4.0                      ; d6690070 03db2cf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v40, v40, v41, 0x3f650000 :: v_dual_mul_f32 v139, v139, v39 ; c8465328 288a4f8b 3f650000
	v_maxmin_num_f32 v114, -4.0, v151, 4.0                      ; d6690072 03db2ef7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_fmaak_f32 v43, v43, v42, 0x3f650000 :: v_dual_mul_f32 v140, v140, v40 ; c846552b 2b8c518c 3f650000
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v116, -4.0, v152, 4.0                      ; d6690074 03db30f7
	v_dual_fmaak_f32 v96, v96, v97, 0x3f650000 :: v_dual_mul_f32 v141, v141, v43 ; c846c360 608c578d 3f650000
	v_maxmin_num_f32 v118, -4.0, v153, 4.0                      ; d6690076 03db32f7
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_mul_f32 v142, v142, v96 ; c846c563 638ec18e 3f650000
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_maxmin_num_f32 v120, -4.0, v154, 4.0                      ; d6690078 03db34f7
	v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 :: v_dual_mul_f32 v143, v143, v99 ; c846cb64 648ec78f 3f650000
	v_maxmin_num_f32 v122, -4.0, v155, 4.0                      ; d669007a 03db36f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_mul_f32 v144, v144, v100 ; c846cd67 6790c990 3f650000
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_maxmin_num_f32 v124, -4.0, v156, 4.0                      ; d669007c 03db38f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 :: v_dual_mul_f32 v145, v145, v103 ; c846d368 6890cf91 3f650000
	v_maxmin_num_f32 v126, -4.0, v157, 4.0                      ; d669007e 03db3af7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 :: v_dual_mul_f32 v146, v146, v104 ; c846d56b 6b92d192 3f650000
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_maxmin_num_f32 v128, -4.0, v158, 4.0                      ; d6690080 03db3cf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 :: v_dual_mul_f32 v147, v147, v107 ; c846db6c 6c92d793 3f650000
	v_maxmin_num_f32 v130, -4.0, v159, 4.0                      ; d6690082 03db3ef7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_mul_f32 v148, v148, v108 ; c846dd6f 6f94d994 3f650000
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v160, 4.0                      ; d6690084 03db40f7
	v_dual_fmaak_f32 v112, v112, v113, 0x3f650000 :: v_dual_mul_f32 v149, v149, v111 ; c846e370 7094df95 3f650000
	v_maxmin_num_f32 v134, -4.0, v161, 4.0                      ; d6690086 03db42f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_mul_f32 v150, v150, v112 ; c846e573 7396e196 3f650000
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v162, 4.0                      ; d6690088 03db44f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 :: v_dual_mul_f32 v151, v151, v115 ; c846eb74 7496e797 3f650000
	v_maxmin_num_f32 v138, -4.0, v163, 4.0                      ; d669008a 03db46f7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_dual_fmaak_f32 v119, v119, v118, 0x3f650000 :: v_dual_mul_f32 v152, v152, v116 ; c846ed77 7798e998 3f650000
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v140, -4.0, v164, 4.0                      ; d669008c 03db48f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 :: v_dual_mul_f32 v153, v153, v119 ; c846f378 7898ef99 3f650000
	v_maxmin_num_f32 v142, -4.0, v165, 4.0                      ; d669008e 03db4af7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 :: v_dual_mul_f32 v154, v154, v120 ; c846f57b 7b9af19a 3f650000
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v166, 4.0                      ; d6690090 03db4cf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 :: v_dual_mul_f32 v155, v155, v123 ; c846fb7c 7c9af79b 3f650000
	v_maxmin_num_f32 v146, -4.0, v167, 4.0                      ; d6690092 03db4ef7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_mul_f32 v156, v156, v124 ; c846fd7f 7f9cf99c 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v168, 4.0                      ; d6690094 03db50f7
	v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 :: v_dual_mul_f32 v157, v157, v127 ; c8470380 809cff9d 3f650000
	v_maxmin_num_f32 v150, -4.0, v169, 4.0                      ; d6690096 03db52f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_mul_f32 v158, v158, v128 ; c8470583 839f019e 3f650000
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v170, 4.0                      ; d6690098 03db54f7
	v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 :: v_dual_mul_f32 v159, v159, v131 ; c8470b84 849f079f 3f650000
	v_maxmin_num_f32 v154, -4.0, v171, 4.0                      ; d669009a 03db56f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_mul_f32 v160, v160, v132 ; c8470d87 87a109a0 3f650000
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v172, 4.0                      ; d669009c 03db58f7
	v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 :: v_dual_mul_f32 v161, v161, v135 ; c8471388 88a10fa1 3f650000
	v_maxmin_num_f32 v158, -4.0, v173, 4.0                      ; d669009e 03db5af7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 :: v_dual_mul_f32 v162, v162, v136 ; c847158b 8ba311a2 3f650000
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v174, 4.0                      ; d66900a0 03db5cf7
	v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 :: v_dual_mul_f32 v163, v163, v139 ; c8471b8c 8ca317a3 3f650000
	s_lshr_b32 s16, s16, 2                                      ; 85108210
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 :: v_dual_mul_f32 v164, v164, v140 ; c8471d8f 8fa519a4 3f650000
	v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 :: v_dual_mul_f32 v165, v165, v143 ; c8472390 90a51fa5 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_mul_f32 v166, v166, v144 ; c8472593 93a721a6 3f650000
	v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 :: v_dual_mul_f32 v167, v167, v147 ; c8472b94 94a727a7 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_mul_f32 v168, v168, v148 ; c8472d97 97a929a8 3f650000
	v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 :: v_dual_mul_f32 v169, v169, v151 ; c8473398 98a92fa9 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_mul_f32 v170, v170, v152 ; c847359b 9bab31aa 3f650000
	v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 :: v_dual_mul_f32 v171, v171, v155 ; c8473b9c 9cab37ab 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_mul_f32 v172, v172, v156 ; c8473d9f 9fad39ac 3f650000
	v_dual_mul_f32 v173, v173, v159 :: v_dual_lshlrev_b32 v162, 10, v1 ; c8e33fad ada2028a
	v_maxmin_num_f32 v164, -4.0, v175, 4.0                      ; d66900a4 03db5ef7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_add3_u32 v163, v77, s16, v162                             ; d65500a3 0688214d
	v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 :: v_dual_lshlrev_b32 v163, 2, v163 ; c86343a0 a0a34682 3f650000
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[96:99], v163, s[36:39], null offen       ; c405c07c 40804860 000000a3
	buffer_load_b128 v[100:103], v163, s[36:39], null offen offset:512 ; c405c07c 40804864 000200a3
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_maxmin_num_f32 v166, -4.0, v176, 4.0                      ; d66900a6 03db60f7
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_maxmin_num_f32 v168, -4.0, v177, 4.0                      ; d66900a8 03db62f7
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	buffer_load_b128 v[108:111], v163, s[36:39], null offen offset:1024 ; c405c07c 4080486c 000400a3
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v170, -4.0, v178, 4.0                      ; d66900aa 03db64f7
	v_mul_f32_e32 v174, v174, v160                              ; 115d41ae
	v_maxmin_num_f32 v172, -4.0, v179, 4.0                      ; d66900ac 03db66f7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 ; c8434fa6 a6a549a5 3f650000
	buffer_load_b128 v[112:115], v163, s[36:39], null offen offset:1536 ; c405c07c 40804870 000600a3
	v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 ; c84357aa aaa951a9 3f650000
	v_fmaak_f32 v173, v173, v172, 0x3f650000                    ; 5b5b59ad 3f650000
	v_dual_mul_f32 v176, v176, v166 :: v_dual_mul_f32 v175, v175, v165 ; c8c74db0 b0af4baf
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v178, v178, v170 :: v_dual_mul_f32 v177, v177, v169 ; c8c755b2 b2b153b1
	v_mul_f32_e32 v179, v179, v173                              ; 11675bb3
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_maxmin_num_f32 v174, -4.0, v180, 4.0                      ; d66900ae 03db68f7
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	buffer_load_b128 v[116:119], v163, s[36:39], null offen offset:2048 ; c405c07c 40804874 000800a3
	v_maxmin_num_f32 v176, -4.0, v181, 4.0                      ; d66900b0 03db6af7
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_maxmin_num_f32 v178, -4.0, v182, 4.0                      ; d66900b2 03db6cf7
	v_maxmin_num_f32 v7, -4.0, v185, 4.0                        ; d6690007 03db72f7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v14, 0xab28, |v7|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620e 0bfe0eff 3728ab28
	v_maxmin_num_f32 v26, -4.0, v186, 4.0                       ; d669001a 03db74f7
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84361b1 b1af5fae 3f650000
	buffer_load_b128 v[120:123], v163, s[36:39], null offen offset:2560 ; c405c07c 40804878 000a00a3
	v_fmaak_f32 v14, v14, v7, 0x3f650000                        ; 5a1c0f0e 3f650000
	v_fma_mix_f32 v107, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfe34ff 3728ab28
	v_maxmin_num_f32 v124, -4.0, v187, 4.0                      ; d669007c 03db76f7
	v_maxmin_num_f32 v126, -4.0, v188, 4.0                      ; d669007e 03db78f7
	v_dual_mul_f32 v181, v181, v177 :: v_dual_mul_f32 v180, v180, v174 ; c8c763b5 b5b55db4
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
	v_fmaak_f32 v26, v26, v107, 0x3f650000                      ; 5a34d71a 3f650000
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_dual_fmaak_f32 v126, v126, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 ; c842ff7e 7e7cf97d 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v188, v188, v126 :: v_dual_mul_f32 v187, v187, v125 ; c8c6fdbc bcbafbbb
	buffer_load_b128 v[124:127], v163, s[36:39], null offen offset:3072 ; c405c07c 4080487c 000c00a3
	v_maxmin_num_f32 v180, -4.0, v183, 4.0                      ; d66900b4 03db6ef7
	v_maxmin_num_f32 v128, -4.0, v189, 4.0                      ; d6690080 03db7af7
	v_mul_f32_e32 v186, v186, v26                               ; 117435ba
	v_maxmin_num_f32 v130, -4.0, v190, 4.0                      ; d6690082 03db7cf7
	v_maxmin_num_f32 v132, -4.0, v191, 4.0                      ; d6690084 03db7ef7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 ; c8430782 82810181 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v190, v190, v130 :: v_dual_mul_f32 v189, v189, v129 ; c8c705be bebd03bd
	buffer_load_b128 v[128:131], v163, s[36:39], null offen offset:3584 ; c405c07c 40804880 000e00a3
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v134, -4.0, v58, 4.0                       ; d6690086 03da74f7
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84369b5 b5b367b2 3f650000
	v_maxmin_num_f32 v136, -4.0, v59, 4.0                       ; d6690088 03da76f7
	v_maxmin_num_f32 v138, -4.0, v60, 4.0                       ; d669008a 03da78f7
(invalid instruction)                                        ; d769006b
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_maxmin_num_f32 v140, -4.0, v61, 4.0                       ; d669008c 03da7af7
	v_fmaak_f32 v133, v133, v132, 0x3f650000                    ; 5b0b0985 3f650000
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_mul_f32 v183, v183, v181 :: v_dual_mul_f32 v182, v182, v178 ; c8c76bb7 b7b765b6
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v62, 4.0                       ; d669008e 03da7cf7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v63, 4.0                       ; d6690090 03da7ef7
	v_dual_mul_f32 v191, v191, v133 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c8c30bbf bf870f86 3f650000
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_maxmin_num_f32 v182, -4.0, v184, 4.0                      ; d66900b6 03db70f7
	v_maxmin_num_f32 v146, -4.0, v64, 4.0                       ; d6690092 03da80f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v65, 4.0                       ; d6690094 03da82f7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_mul_f32 v58, v58, v134 ; c8471189 893b0d3a 3f650000
(invalid instruction)                                        ; d769406b
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v16, 4.0                       ; d6690096 03da20f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v17, 4.0                       ; d6690098 03da22f7
	v_dual_mul_f32 v59, v59, v137 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c8c3133b 3b8b178a 3f650000
	v_fmaak_f32 v182, v182, v183, 0x3f650000                    ; 5b6d6fb6 3f650000
	v_maxmin_num_f32 v154, -4.0, v18, 4.0                       ; d669009a 03da24f7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v19, 4.0                       ; d669009c 03da26f7
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_mul_f32 v60, v60, v138 ; c847198d 8d3d153c 3f650000
	v_dual_mul_f32 v184, v182, v184 :: v_dual_mul_f32 v185, v185, v14 ; c8c771b6 b8b81db9
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v20, 4.0                       ; d669009e 03da28f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v21, 4.0                       ; d66900a0 03da2af7
	v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 :: v_dual_mul_f32 v61, v61, v141 ; c8471f8e 8e3d1b3d 3f650000
(invalid instruction)                                        ; d769006a
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d769406a
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v163, -4.0, v22, 4.0                       ; d66900a3 03da2cf7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_lshrrev_b32_e32 v167, 4, v27                              ; 334e3684
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v62, v62, v142 ; c8472191 913f1d3e 3f650000
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84341a1 a19f3f9e 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_mul_f32 v63, v63, v145 ; c8472792 923f233f 3f650000
	v_maxmin_num_f32 v165, -4.0, v23, 4.0                       ; d66900a5 03da2ef7
	v_dual_mul_f32 v20, v20, v158 :: v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 ; c8c33d14 14a349a3 3f650000
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_mul_f32 v64, v64, v146 ; c8472995 95412540 3f650000
	v_dual_mul_f32 v22, v163, v22 :: v_dual_lshlrev_b32 v167, 3, v167 ; c8e22da3 16a74e83
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_mul_f32 v65, v65, v149 ; c8472f96 96412b41 3f650000
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_mul_f32 v16, v16, v150 ; c8473199 99112d10 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_mul_f32 v17, v17, v153 ; c847379a 9a113311 3f650000
	v_maxmin_num_f32 v170, -4.0, v80, 4.0                       ; d66900aa 03daa0f7
	v_fma_mix_f32 v169, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff4aff 3728ab28
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v18, v18, v154 ; c847399d 9d133512 3f650000
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_mul_f32 v19, v19, v157 :: v_dual_and_b32 v166, 0xffffffe0, v0 ; c8e53b13 13a600ff ffffffe0
	v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v165, 0x3f650000 ; c84357aa aaa94ba9 3f650000
	v_add3_u32 v168, v167, s9, v166                             ; d65500a8 069813a7
	v_dual_mul_f32 v80, v80, v170 :: v_dual_mul_f32 v23, v23, v169 ; c8c75550 50175317
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_mul_f32 v21, v21, v161 :: v_dual_lshlrev_b32 v168, 2, v168 ; c8e34315 15a95082
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v168, s[32:35], null offen       ; c405c07c 4080403c 000000a8
	buffer_load_b128 v[20:23], v168, s[32:35], null offen offset:16 ; c405c07c 40804014 000010a8
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_maxmin_num_f32 v172, -4.0, v81, 4.0                       ; d66900ac 03daa2f7
	v_maxmin_num_f32 v174, -4.0, v82, 4.0                       ; d66900ae 03daa4f7
	v_maxmin_num_f32 v176, -4.0, v83, 4.0                       ; d66900b0 03daa6f7
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_maxmin_num_f32 v178, -4.0, v84, 4.0                       ; d66900b2 03daa8f7
	v_maxmin_num_f32 v180, -4.0, v85, 4.0                       ; d66900b4 03daaaf7
	v_maxmin_num_f32 v182, -4.0, v86, 4.0                       ; d66900b6 03daacf7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v87, 4.0                       ; d66900b8 03daaef7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 ; c8435fae aead59ad 3f650000
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 ; c84367b2 b2b161b1 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 ; c8436fb6 b6b569b5 3f650000
	v_dual_mov_b32 v14, v162 :: v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 ; ca0201a2 0eb971b9 3f650000
	v_dual_mul_f32 v82, v82, v174 :: v_dual_mul_f32 v81, v81, v173 ; c8c75d52 52515b51
	v_dual_mul_f32 v84, v84, v178 :: v_dual_mul_f32 v83, v83, v177 ; c8c76554 54536353
	v_dual_mul_f32 v86, v86, v182 :: v_dual_mul_f32 v85, v85, v181 ; c8c76d56 56556b55
	v_dual_mov_b32 v26, v166 :: v_dual_mul_f32 v87, v87, v185   ; ca0601a6 1a577357
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[96:97], v[54:55], 0 ; cc464050 1a026d60
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[96:97], v[66:67], 0 ; cc464088 1a028560
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[66:67], 0 ; cc4640b8 1a028562
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[24:25], 0 ; cc464098 1a023160
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[56:57], 0 ; cc464090 1a027160
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[98:99], v[54:55], 0 ; cc4640b0 1a026d62
	v_dual_mov_b32 v54, v167 :: v_dual_mov_b32 v7, v168         ; ca1001a7 360601a8
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[98:99], v[56:57], 0 ; cc4640a8 1a027162
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[98:99], v[24:25], 0 ; cc4640a0 1a023162
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[100:101], v[28:29], v[80:87] ; cc464050 1d423964
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[100:101], v[30:31], v[136:143] ; cc464088 1e223d64
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[102:103], v[30:31], v[184:191] ; cc4640b8 1ee23d66
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[102:103], v[28:29], v[176:183] ; cc4640b0 1ec23966
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[108:109], v[8:9], v[80:87] ; cc464050 1d42116c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[10:11], v[136:143] ; cc464088 1e22156c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[10:11], v[184:191] ; cc4640b8 1ee2156e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[100:101], v[46:47], v[152:159] ; cc464098 1e625d64
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[110:111], v[8:9], v[176:183] ; cc4640b0 1ec2116e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v7, s[32:35], null offen offset:64 ; c405c07c 40804008 00004007
	buffer_load_b128 v[28:31], v7, s[32:35], null offen offset:80 ; c405c07c 4080401c 00005007
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[44:45], v[144:151] ; cc464090 1e425964
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[102:103], v[44:45], v[168:175] ; cc4640a8 1ea25966
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[102:103], v[46:47], v[160:167] ; cc4640a0 1e825d66
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[112:113], v[70:71], v[80:87] ; cc464050 1d428d70
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[78:79], v[136:143] ; cc464088 1e229d70
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[78:79], v[184:191] ; cc4640b8 1ee29d72
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[68:69], v[152:159] ; cc464098 1e62896c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[70:71], v[176:183] ; cc4640b0 1ec28d72
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[12:13], v[144:151] ; cc464090 1e42196c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[110:111], v[12:13], v[168:175] ; cc4640a8 1ea2196e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[110:111], v[68:69], v[160:167] ; cc4640a0 1e82896e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v55, v77, s5, v14                                ; d6550037 04380b4d
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[116:117], v[52:53], v[80:87] ; cc464050 1d426974
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[116:117], v[88:89], v[136:143] ; cc464088 1e22b174
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[88:89], v[184:191] ; cc4640b8 1ee2b176
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[48:49], v[152:159] ; cc464098 1e626170
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[118:119], v[52:53], v[176:183] ; cc4640b0 1ec26976
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[112:113], v[50:51], v[144:151] ; cc464090 1e426570
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[114:115], v[50:51], v[168:175] ; cc4640a8 1ea26572
	v_lshlrev_b32_e32 v55, 2, v55                               ; 306e6e82
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[114:115], v[48:49], v[160:167] ; cc4640a0 1e826172
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[120:121], v[94:95], v[80:87] ; cc464050 1d42bd78
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[120:121], v[32:33], v[136:143] ; cc464088 1e224178
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[122:123], v[32:33], v[184:191] ; cc4640b8 1ee2417a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[92:93], v[152:159] ; cc464098 1e62b974
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[122:123], v[94:95], v[176:183] ; cc4640b0 1ec2bd7a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[116:117], v[90:91], v[144:151] ; cc464090 1e42b574
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[118:119], v[90:91], v[168:175] ; cc4640a8 1ea2b576
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[118:119], v[92:93], v[160:167] ; cc4640a0 1e82b976
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[124:125], v[38:39], v[80:87] ; cc464050 1d424d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[124:125], v[40:41], v[136:143] ; cc464088 1e22517c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[126:127], v[40:41], v[184:191] ; cc4640b8 1ee2517e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[120:121], v[36:37], v[152:159] ; cc464098 1e624978
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[126:127], v[38:39], v[176:183] ; cc4640b0 1ec24d7e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[120:121], v[34:35], v[144:151] ; cc464090 1e424578
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[122:123], v[34:35], v[168:175] ; cc4640a8 1ea2457a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[122:123], v[36:37], v[160:167] ; cc4640a0 1e82497a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[128:129], v[106:107], v[80:87] ; cc464050 1d42d580
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[128:129], v[58:59], v[136:143] ; cc464088 1e227580
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[130:131], v[58:59], v[184:191] ; cc4640b8 1ee27582
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[124:125], v[104:105], v[152:159] ; cc464098 1e62d17c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[130:131], v[106:107], v[176:183] ; cc4640b0 1ec2d582
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[124:125], v[42:43], v[144:151] ; cc464090 1e42557c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[126:127], v[42:43], v[168:175] ; cc4640a8 1ea2557e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[126:127], v[104:105], v[160:167] ; cc4640a0 1e82d17e
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	buffer_load_b128 v[32:35], v55, s[36:39], null offen        ; c405c07c 40804820 00000037
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[128:129], v[18:19], v[152:159] ; cc464098 1e622580
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[128:129], v[16:17], v[144:151] ; cc464090 1e422180
	v_add_nc_u32_e32 v56, 0x2000, v73                           ; 4a7092ff 00002000
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[130:131], v[16:17], v[168:175] ; cc4640a8 1ea22182
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[130:131], v[18:19], v[160:167] ; cc4640a0 1e822582
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	ds_store_2addr_b64 v56, v[12:13], v[36:37] offset1:32       ; d9382000 00240c38
	buffer_load_b128 v[44:47], v55, s[36:39], null offen offset:512 ; c405c07c 4080482c 00020037
	v_add_nc_u32_e32 v57, 0x2800, v73                           ; 4a7292ff 00002800
	v_add_nc_u32_e32 v58, 0x3000, v73                           ; 4a7492ff 00003000
	v_add_nc_u32_e32 v59, 0x3800, v73                           ; 4a7692ff 00003800
	ds_store_2addr_b64 v57, v[16:17], v[38:39] offset1:32       ; d9382000 00261039
	ds_store_2addr_b64 v58, v[18:19], v[40:41] offset1:32       ; d9382000 0028123a
	ds_store_2addr_b64 v59, v[24:25], v[42:43] offset1:32       ; d9382000 002a183b
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	buffer_load_b128 v[16:19], v55, s[36:39], null offen offset:1024 ; c405c07c 40804810 00040037
	v_mad_u32_u24 v64, s59, 0x500, v2                           ; d60b0040 0409fe3b 00000500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v64, v64, v72                              ; 4a809140
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[12:13], v64                                   ; d9d80000 0c000040
	ds_load_b64 v[24:25], v64 offset:2048                       ; d9d80800 18000040
	ds_load_b64 v[36:37], v64 offset:4096                       ; d9d81000 24000040
	buffer_load_b128 v[40:43], v55, s[36:39], null offen offset:1536 ; c405c07c 40804828 00060037
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[38:39], v12                          ; 7e4cdd0c
	s_wait_loadcnt 0x7                                          ; bfc00007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v81, v39, v61 :: v_dual_mul_f32 v80, v38, v60 ; c8c67b27 51507926
	v_cvt_pk_f32_fp8_e32 v[38:39], v140                         ; 7e4cdd8c
	v_dual_mul_f32 v83, v39, v63 :: v_dual_mul_f32 v82, v38, v62 ; c8c67f27 53527d26
	v_cvt_pk_f32_fp8_e32 v[38:39], v13                          ; 7e4cdd0d
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v85, v39, v21 :: v_dual_mul_f32 v84, v38, v20 ; c8c62b27 55542926
	ds_load_b64 v[38:39], v64 offset:6144                       ; d9d81800 26000040
	buffer_load_b128 v[48:51], v55, s[36:39], null offen offset:2048 ; c405c07c 40804830 00080037
	ds_load_b64 v[52:53], v64 offset:256                        ; d9d80100 34000040
	buffer_load_b128 v[68:71], v55, s[36:39], null offen offset:2560 ; c405c07c 40804844 000a0037
	v_cvt_pk_f32_fp8_e32 v[12:13], v141                         ; 7e18dd8d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v87, v13, v23 :: v_dual_mul_f32 v86, v12, v22 ; c8c62f0d 57562d0c
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[12:13], v24                          ; 7e18dd18
	v_dual_mul_f32 v89, v13, v61 :: v_dual_mul_f32 v88, v12, v60 ; c8c67b0d 5958790c
	buffer_load_b128 v[104:107], v55, s[36:39], null offen offset:3072 ; c405c07c 40804868 000c0037
	v_cvt_pk_f32_fp8_e32 v[12:13], v152                         ; 7e18dd98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v91, v13, v63 :: v_dual_mul_f32 v90, v12, v62 ; c8c67f0d 5b5a7d0c
	v_cvt_pk_f32_fp8_e32 v[12:13], v25                          ; 7e18dd19
	v_cvt_pk_f32_fp8_e32 v[24:25], v153                         ; 7e30dd99
	v_dual_mul_f32 v93, v13, v21 :: v_dual_mul_f32 v92, v12, v20 ; c8c62b0d 5d5c290c
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[12:13], v36                          ; 7e18dd24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v97, v13, v61 :: v_dual_mul_f32 v96, v12, v60 ; c8c67b0d 6160790c
	v_cvt_pk_f32_fp8_e32 v[12:13], v164                         ; 7e18dda4
	v_dual_mul_f32 v99, v13, v63 :: v_dual_mul_f32 v98, v12, v62 ; c8c67f0d 63627d0c
	v_cvt_pk_f32_fp8_e32 v[12:13], v37                          ; 7e18dd25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_dual_mul_f32 v101, v13, v21 :: v_dual_mul_f32 v94, v24, v22 ; c8c62b0d 655e2d18
	v_dual_mul_f32 v95, v25, v23 :: v_dual_mul_f32 v100, v12, v20 ; c8c62f19 5f64290c
	ds_load_b64 v[24:25], v64 offset:2304                       ; d9d80900 18000040
	v_cvt_pk_f32_fp8_e32 v[12:13], v165                         ; 7e18dda5
	v_dual_mul_f32 v103, v13, v23 :: v_dual_mul_f32 v102, v12, v22 ; c8c62f0d 67662d0c
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[12:13], v38                          ; 7e18dd26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v112, v12, v60                                ; 10e0790c
	v_mul_f32_e32 v113, v13, v61                                ; 10e27b0d
	v_cvt_pk_f32_fp8_e32 v[12:13], v166                         ; 7e18dda6
	v_dual_mul_f32 v115, v13, v63 :: v_dual_mul_f32 v114, v12, v62 ; c8c67f0d 73727d0c
	v_cvt_pk_f32_fp8_e32 v[12:13], v39                          ; 7e18dd27
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v117, v13, v21 :: v_dual_mul_f32 v116, v12, v20 ; c8c62b0d 7574290c
	v_cvt_pk_f32_fp8_e32 v[12:13], v167                         ; 7e18dda7
	buffer_load_b128 v[36:39], v55, s[36:39], null offen offset:3584 ; c405c07c 40804824 000e0037
	v_dual_mul_f32 v119, v13, v23 :: v_dual_mul_f32 v118, v12, v22 ; c8c62f0d 77762d0c
	ds_load_b64 v[20:21], v64 offset:4352                       ; d9d81100 14000040
	ds_load_b64 v[22:23], v64 offset:6400                       ; d9d81900 16000040
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[12:13], v52                          ; 7e18dd34
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v121, v13, v9 :: v_dual_mul_f32 v120, v12, v8 ; c8c6130d 7978110c
	v_cvt_pk_f32_fp8_e32 v[12:13], v180                         ; 7e18ddb4
	v_dual_mul_f32 v123, v13, v11 :: v_dual_mul_f32 v122, v12, v10 ; c8c6170d 7b7a150c
	v_cvt_pk_f32_fp8_e32 v[12:13], v53                          ; 7e18dd35
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v125, v13, v29 :: v_dual_mul_f32 v124, v12, v28 ; c8c63b0d 7d7c390c
	v_cvt_pk_f32_fp8_e32 v[12:13], v181                         ; 7e18ddb5
	v_dual_mul_f32 v127, v13, v31 :: v_dual_mul_f32 v126, v12, v30 ; c8c63f0d 7f7e3d0c
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[12:13], v24                          ; 7e18dd18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v129, v13, v9 :: v_dual_mul_f32 v128, v12, v8 ; c8c6130d 8180110c
	v_cvt_pk_f32_fp8_e32 v[12:13], v152                         ; 7e18dd98
	v_dual_mul_f32 v131, v13, v11 :: v_dual_mul_f32 v130, v12, v10 ; c8c6170d 8382150c
	v_cvt_pk_f32_fp8_e32 v[12:13], v25                          ; 7e18dd19
	v_add_lshl_u32 v65, s23, v1, 2                              ; d6470041 020a0217
	buffer_load_b32 v65, v65, s[32:35], null offen              ; c405007c 40804041 00000041
	v_dual_mul_f32 v133, v13, v29 :: v_dual_mul_f32 v132, v12, v28 ; c8c63b0d 8584390c
	v_cvt_pk_f32_fp8_e32 v[12:13], v153                         ; 7e18dd99
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870119
	v_mad_u32_u24 v66, 0xc00, v1, s6                            ; d60b0042 001a02ff 00000c00
	v_dual_mul_f32 v135, v13, v31 :: v_dual_mul_f32 v134, v12, v30 ; c8c63f0d 87863d0c
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[12:13], v20                          ; 7e18dd14
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_add_lshl_u32 v66, v66, v77, 2                             ; d6470042 020a9b42
	v_dual_mul_f32 v137, v13, v9 :: v_dual_mul_f32 v136, v12, v8 ; c8c6130d 8988110c
	v_cvt_pk_f32_fp8_e32 v[12:13], v148                         ; 7e18dd94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v139, v13, v11 :: v_dual_mul_f32 v138, v12, v10 ; c8c6170d 8b8a150c
	v_cvt_pk_f32_fp8_e32 v[12:13], v21                          ; 7e18dd15
	v_dual_mul_f32 v141, v13, v29 :: v_dual_mul_f32 v140, v12, v28 ; c8c63b0d 8d8c390c
	v_cvt_pk_f32_fp8_e32 v[12:13], v149                         ; 7e18dd95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v143, v13, v31 :: v_dual_mul_f32 v142, v12, v30 ; c8c63f0d 8f8e3d0c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[12:13], v22                          ; 7e18dd16
	v_dual_mul_f32 v145, v13, v9 :: v_dual_mul_f32 v144, v12, v8 ; c8c6130d 9190110c
	v_cvt_pk_f32_fp8_e32 v[8:9], v150                           ; 7e10dd96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v147, v9, v11 :: v_dual_mul_f32 v146, v8, v10 ; c8c61709 93921508
	v_cvt_pk_f32_fp8_e32 v[8:9], v23                            ; 7e10dd17
	v_dual_mul_f32 v149, v9, v29 :: v_dual_mul_f32 v148, v8, v28 ; c8c63b09 95943908
	buffer_load_b128 v[8:11], v66, s[36:39], null offen         ; c405c07c 40804808 00000042
	v_cvt_pk_f32_fp8_e32 v[12:13], v151                         ; 7e18dd97
	v_lshl_add_u32 v67, s59, 10, v72                            ; d6460043 0521143b
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v151, v13, v31 :: v_dual_mul_f32 v150, v12, v30 ; c8c63f0d 97963d0c
	ds_load_b64 v[12:13], v67 offset:8192                       ; d9d82000 0c000043
	ds_load_b64 v[20:21], v67 offset:10240                      ; d9d82800 14000043
	ds_load_b64 v[22:23], v67 offset:12288                      ; d9d83000 16000043
	ds_load_b64 v[24:25], v67 offset:14336                      ; d9d83800 18000043
	ds_load_b64 v[28:29], v67 offset:8448                       ; d9d82100 1c000043
	ds_load_b64 v[30:31], v67 offset:10496                      ; d9d82900 1e000043
	buffer_load_b128 v[60:63], v66, s[36:39], null offen offset:4096 ; c405c07c 4080483c 00100042
	ds_load_b64 v[52:53], v67 offset:12544                      ; d9d83100 34000043
	ds_load_b64 v[78:79], v67 offset:14592                      ; d9d83900 4e000043
	ds_load_b64 v[108:109], v67 offset:8704                     ; d9d82200 6c000043
	ds_load_b64 v[110:111], v67 offset:10752                    ; d9d82a00 6e000043
	ds_load_b64 v[152:153], v67 offset:12800                    ; d9d83200 98000043
	ds_load_b64 v[154:155], v67 offset:14848                    ; d9d83a00 9a000043
	buffer_load_b128 v[156:159], v66, s[36:39], null offen offset:512 ; c405c07c 4080489c 00020042
	ds_load_b64 v[160:161], v67 offset:8960                     ; d9d82300 a0000043
	ds_load_b64 v[162:163], v67 offset:11008                    ; d9d82b00 a2000043
	ds_load_b64 v[164:165], v67 offset:13056                    ; d9d83300 a4000043
	ds_load_b64 v[166:167], v67 offset:15104                    ; d9d83b00 a6000043
	buffer_load_b128 v[168:171], v66, s[36:39], null offen offset:4608 ; c405c07c 408048a8 00120042
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[12:13], v[80:87] ; cc464050 1d421920
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[12:13], v[120:127] ; cc464078 1de21922
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[20:21], v[128:135] ; cc464080 1e022922
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[20:21], v[88:95] ; cc464058 1d622920
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[22:23], v[96:103] ; cc464060 1d822d20
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[34:35], v[22:23], v[136:143] ; cc464088 1e222d22
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[24:25], v[112:119] ; cc464070 1dc23120
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[34:35], v[24:25], v[144:151] ; cc464090 1e423122
	ds_load_b64 v[12:13], v67 offset:9216                       ; d9d82400 0c000043
	ds_load_b64 v[20:21], v67 offset:11264                      ; d9d82c00 14000043
	ds_load_b64 v[22:23], v67 offset:13312                      ; d9d83400 16000043
	ds_load_b64 v[24:25], v67 offset:15360                      ; d9d83c00 18000043
	buffer_load_b128 v[32:35], v66, s[36:39], null offen offset:1024 ; c405c07c 40804820 00040042
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[28:29], v[80:87] ; cc464050 1d42392c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[28:29], v[120:127] ; cc464078 1de2392e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[30:31], v[128:135] ; cc464080 1e023d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[30:31], v[88:95] ; cc464058 1d623d2c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[52:53], v[96:103] ; cc464060 1d82692c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[52:53], v[136:143] ; cc464088 1e22692e
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[78:79], v[112:119] ; cc464070 1dc29d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[78:79], v[144:151] ; cc464090 1e429d2e
	ds_load_b64 v[28:29], v67 offset:9472                       ; d9d82500 1c000043
	ds_load_b64 v[30:31], v67 offset:11520                      ; d9d82d00 1e000043
	ds_load_b64 v[44:45], v67 offset:13568                      ; d9d83500 2c000043
	ds_load_b64 v[46:47], v67 offset:15616                      ; d9d83d00 2e000043
	buffer_load_b128 v[172:175], v66, s[36:39], null offen offset:5120 ; c405c07c 408048ac 00140042
	s_wait_loadcnt_dscnt 0xc0f                                  ; bfc80c0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[108:109], v[80:87] ; cc464050 1d42d910
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[108:109], v[120:127] ; cc464078 1de2d912
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[110:111], v[128:135] ; cc464080 1e02dd12
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[110:111], v[88:95] ; cc464058 1d62dd10
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[152:153], v[96:103] ; cc464060 1d833110
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[152:153], v[136:143] ; cc464088 1e233112
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[154:155], v[112:119] ; cc464070 1dc33510
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[18:19], v[154:155], v[144:151] ; cc464090 1e433512
	s_wait_loadcnt_dscnt 0xb0b                                  ; bfc80b0b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[160:161], v[80:87] ; cc464050 1d434128
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[160:161], v[120:127] ; cc464078 1de3412a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[162:163], v[128:135] ; cc464080 1e03452a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[162:163], v[88:95] ; cc464058 1d634528
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[164:165], v[96:103] ; cc464060 1d834928
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[164:165], v[136:143] ; cc464088 1e23492a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[166:167], v[112:119] ; cc464070 1dc34d28
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[166:167], v[144:151] ; cc464090 1e434d2a
	ds_load_b64 v[16:17], v67 offset:9728                       ; d9d82600 10000043
	ds_load_b64 v[18:19], v67 offset:11776                      ; d9d82e00 12000043
	ds_load_b64 v[52:53], v67 offset:13824                      ; d9d83600 34000043
	ds_load_b64 v[78:79], v67 offset:15872                      ; d9d83e00 4e000043
	ds_load_b64 v[40:41], v67 offset:9984                       ; d9d82700 28000043
	ds_load_b64 v[42:43], v67 offset:12032                      ; d9d82f00 2a000043
	ds_load_b64 v[108:109], v67 offset:14080                    ; d9d83700 6c000043
	ds_load_b64 v[110:111], v67 offset:16128                    ; d9d83f00 6e000043
	s_wait_loadcnt_dscnt 0xa0f                                  ; bfc80a0f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[12:13], v[80:87] ; cc464050 1d421930
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[12:13], v[120:127] ; cc464078 1de21932
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[20:21], v[88:95] ; cc464058 1d622930
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[20:21], v[128:135] ; cc464080 1e022932
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[48:49], v[22:23], v[96:103] ; cc464060 1d822d30
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[50:51], v[22:23], v[136:143] ; cc464088 1e222d32
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[24:25], v[112:119] ; cc464070 1dc23130
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[50:51], v[24:25], v[144:151] ; cc464090 1e423132
	s_wait_loadcnt_dscnt 0x90b                                  ; bfc8090b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[28:29], v[80:87] ; cc464050 1d423944
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[28:29], v[120:127] ; cc464078 1de23946
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[30:31], v[88:95] ; cc464058 1d623d44
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[30:31], v[128:135] ; cc464080 1e023d46
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[44:45], v[96:103] ; cc464060 1d825944
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[44:45], v[136:143] ; cc464088 1e225946
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[68:69], v[46:47], v[112:119] ; cc464070 1dc25d44
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[46:47], v[144:151] ; cc464090 1e425d46
	s_wait_loadcnt_dscnt 0x807                                  ; bfc80807
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[104:105], v[16:17], v[80:87] ; cc464050 1d422168
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[106:107], v[16:17], v[120:127] ; cc464078 1de2216a
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[104:105], v[18:19], v[88:95] ; cc464058 1d622568
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[106:107], v[18:19], v[128:135] ; cc464080 1e02256a
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[104:105], v[52:53], v[96:103] ; cc464060 1d826968
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[106:107], v[52:53], v[136:143] ; cc464088 1e22696a
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[104:105], v[78:79], v[112:119] ; cc464070 1dc29d68
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[106:107], v[78:79], v[144:151] ; cc464090 1e429d6a
	s_wait_loadcnt_dscnt 0x703                                  ; bfc80703
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[40:41], v[80:87] ; cc464050 1d425124
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[40:41], v[120:127] ; cc464078 1de25126
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[42:43], v[88:95] ; cc464058 1d625524
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[38:39], v[42:43], v[128:135] ; cc464080 1e025526
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[108:109], v[96:103] ; cc464060 1d82d924
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[38:39], v[108:109], v[136:143] ; cc464088 1e22d926
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[110:111], v[112:119] ; cc464070 1dc2dd24
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[110:111], v[144:151] ; cc464090 1e42dd26
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v73, v[12:13], v[22:23] offset1:32       ; d9382000 00160c49
	ds_store_2addr_b64 v74, v[16:17], v[24:25] offset1:32       ; d9382000 0018104a
	ds_store_2addr_b64 v75, v[18:19], v[28:29] offset1:32       ; d9382000 001c124b
	ds_store_2addr_b64 v76, v[20:21], v[30:31] offset1:32       ; d9382000 001e144c
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_lshl_add_u32 v68, s59, 11, v72                            ; d6460044 0521163b
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[12:13], v68                                   ; d9d80000 0c000044
	ds_load_b64 v[16:17], v68 offset:2048                       ; d9d80800 10000044
	ds_load_b64 v[18:19], v68 offset:4096                       ; d9d81000 12000044
	ds_load_b64 v[20:21], v68 offset:6144                       ; d9d81800 14000044
	ds_load_b64 v[22:23], v68 offset:256                        ; d9d80100 16000044
	ds_load_b64 v[24:25], v68 offset:2304                       ; d9d80900 18000044
	ds_load_b64 v[28:29], v68 offset:4352                       ; d9d81100 1c000044
	ds_load_b64 v[30:31], v68 offset:6400                       ; d9d81900 1e000044
	s_wait_loadcnt_dscnt 0x507                                  ; bfc80507
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[8:9], v[12:13], 0   ; cc464028 1a021908
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[12:13], 0 ; cc464068 1a02190a
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[16:17], 0   ; cc464050 1a022108
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[16:17], 0 ; cc464070 1a02210a
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[18:19], 0   ; cc464058 1a022508
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[18:19], 0 ; cc464078 1a02250a
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[20:21], 0  ; cc464060 1a022908
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[20:21], 0 ; cc464080 1a02290a
	ds_load_b64 v[8:9], v68 offset:512                          ; d9d80200 08000044
	ds_load_b64 v[10:11], v68 offset:2560                       ; d9d80a00 0a000044
	ds_load_b64 v[36:37], v68 offset:4608                       ; d9d81200 24000044
	ds_load_b64 v[38:39], v68 offset:6656                       ; d9d81a00 26000044
	v_mov_b32_e32 v7, v54                                       ; 7e0e0336
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[62:63], v[12:13], 0 ; cc4640b8 1a02193e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[12:13], 0 ; cc464088 1a02193c
	v_dual_mov_b32 v13, v73 :: v_dual_mov_b32 v12, v72          ; ca100149 0d0c0148
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[16:17], 0 ; cc464090 1a02213c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[60:61], v[18:19], 0 ; cc4640a0 1a02253c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[60:61], v[20:21], 0 ; cc4640b0 1a02293c
	v_dual_mov_b32 v79, v15 :: v_dual_mov_b32 v78, v14          ; ca10010f 4f4e010e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[62:63], v[16:17], 0 ; cc464030 1a02213e
	v_wmma_f32_16x16x16_fp8_fp8 v[69:76], v[62:63], v[18:19], 0 ; cc464045 1a02253e
	v_dual_mov_b32 v61, v13 :: v_dual_mov_b32 v60, v12          ; ca10010d 3d3c010c
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[62:63], v[20:21], 0 ; cc46400c 1a02293e
	ds_load_b64 v[20:21], v68 offset:768                        ; d9d80300 14000044
	ds_load_b64 v[62:63], v68 offset:2816                       ; d9d80b00 3e000044
	ds_load_b64 v[152:153], v68 offset:4864                     ; d9d81300 98000044
	ds_load_b64 v[154:155], v68 offset:6912                     ; d9d81b00 9a000044
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[156:157], v[22:23], v[40:47] ; cc464028 1ca22d9c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[156:157], v[24:25], v[80:87] ; cc464050 1d42319c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[156:157], v[28:29], v[88:95] ; cc464058 1d62399c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[156:157], v[30:31], v[96:103] ; cc464060 1d823d9c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[158:159], v[22:23], v[104:111] ; cc464068 1da22d9e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[158:159], v[24:25], v[112:119] ; cc464070 1dc2319e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[158:159], v[28:29], v[120:127] ; cc464078 1de2399e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[158:159], v[30:31], v[128:135] ; cc464080 1e023d9e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[168:169], v[22:23], v[136:143] ; cc464088 1e222da8
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[168:169], v[24:25], v[144:151] ; cc464090 1e4231a8
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[170:171], v[22:23], v[184:191] ; cc4640b8 1ee22daa
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[170:171], v[24:25], v[48:55] ; cc464030 1cc231aa
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[156:159], v66, s[36:39], null offen offset:1536 ; c405c07c 4080489c 00060042
	buffer_load_b128 v[22:25], v66, s[36:39], null offen offset:5632 ; c405c07c 40804816 00160042
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[168:169], v[28:29], v[160:167] ; cc4640a0 1e8239a8
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[168:169], v[30:31], v[176:183] ; cc4640b0 1ec23da8
	v_wmma_f32_16x16x16_fp8_fp8 v[69:76], v[170:171], v[28:29], v[69:76] ; cc464045 1d1639aa
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[170:171], v[30:31], v[12:19] ; cc46400c 1c323daa
	s_wait_loadcnt_dscnt 0x307                                  ; bfc80307
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[32:33], v[8:9], v[40:47] ; cc464028 1ca21120
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[10:11], v[80:87] ; cc464050 1d421520
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[36:37], v[88:95] ; cc464058 1d624920
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[38:39], v[96:103] ; cc464060 1d824d20
	ds_load_b64 v[28:29], v68 offset:1024                       ; d9d80400 1c000044
	ds_load_b64 v[30:31], v68 offset:3072                       ; d9d80c00 1e000044
	ds_load_b64 v[168:169], v68 offset:5120                     ; d9d81400 a8000044
	ds_load_b64 v[32:33], v68 offset:7168                       ; d9d81c00 20000044
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[34:35], v[8:9], v[104:111] ; cc464068 1da21122
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[10:11], v[112:119] ; cc464070 1dc21522
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[172:173], v[8:9], v[136:143] ; cc464088 1e2211ac
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[172:173], v[10:11], v[144:151] ; cc464090 1e4215ac
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[172:173], v[36:37], v[160:167] ; cc4640a0 1e8249ac
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[38:39], v[176:183] ; cc4640b0 1ec24dac
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[174:175], v[8:9], v[184:191] ; cc4640b8 1ee211ae
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[174:175], v[10:11], v[48:55] ; cc464030 1cc215ae
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v66, s[36:39], null offen offset:2048 ; c405c07c 40804808 00080042
	buffer_load_b128 v[170:173], v66, s[36:39], null offen offset:6144 ; c405c07c 408048aa 00180042
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[36:37], v[120:127] ; cc464078 1de24922
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[38:39], v[128:135] ; cc464080 1e024d22
	v_wmma_f32_16x16x16_fp8_fp8 v[69:76], v[174:175], v[36:37], v[69:76] ; cc464045 1d1649ae
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[174:175], v[38:39], v[12:19] ; cc46400c 1c324dae
	s_wait_loadcnt_dscnt 0x305                                  ; bfc80305
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[156:157], v[152:153], v[88:95] ; cc464058 1d63319c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[156:157], v[20:21], v[40:47] ; cc464028 1ca2299c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[156:157], v[62:63], v[80:87] ; cc464050 1d427d9c
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[156:157], v[154:155], v[96:103] ; cc464060 1d83359c
	ds_load_b64 v[34:35], v68 offset:1280                       ; d9d80500 22000044
	ds_load_b64 v[36:37], v68 offset:3328                       ; d9d80d00 24000044
	ds_load_b64 v[38:39], v68 offset:5376                       ; d9d81500 26000044
	ds_load_b64 v[156:157], v68 offset:7424                     ; d9d81d00 9c000044
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[158:159], v[20:21], v[104:111] ; cc464068 1da2299e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[158:159], v[152:153], v[120:127] ; cc464078 1de3319e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[158:159], v[62:63], v[112:119] ; cc464070 1dc27d9e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[158:159], v[154:155], v[128:135] ; cc464080 1e03359e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[22:23], v[152:153], v[160:167] ; cc4640a0 1e833116
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[20:21], v[136:143] ; cc464088 1e222916
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[22:23], v[154:155], v[176:183] ; cc4640b0 1ec33516
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[22:23], v[62:63], v[144:151] ; cc464090 1e427d16
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[24:25], v[20:21], v[184:191] ; cc4640b8 1ee22918
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[24:25], v[62:63], v[48:55] ; cc464030 1cc27d18
	v_dual_mov_b32 v159, v61 :: v_dual_mov_b32 v158, v60        ; ca10013d 9f9e013c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v66, s[36:39], null offen offset:2560 ; c405c07c 40804814 000a0042
	buffer_load_b128 v[60:63], v66, s[36:39], null offen offset:6656 ; c405c07c 4080483c 001a0042
	v_wmma_f32_16x16x16_fp8_fp8 v[69:76], v[24:25], v[152:153], v[69:76] ; cc464045 1d173118
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[24:25], v[154:155], v[12:19] ; cc46400c 1c333518
	s_wait_loadcnt_dscnt 0x305                                  ; bfc80305
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[168:169], v[88:95] ; cc464058 1d635108
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[32:33], v[96:103] ; cc464060 1d824108
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[8:9], v[28:29], v[40:47] ; cc464028 1ca23908
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[30:31], v[80:87] ; cc464050 1d423d08
	ds_load_b64 v[152:153], v68 offset:1536                     ; d9d80600 98000044
	ds_load_b64 v[24:25], v68 offset:3584                       ; d9d80e00 18000044
	ds_load_b64 v[154:155], v68 offset:5632                     ; d9d81600 9a000044
	ds_load_b64 v[8:9], v68 offset:7680                         ; d9d81e00 08000044
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[30:31], v[112:119] ; cc464070 1dc23d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[168:169], v[120:127] ; cc464078 1de3510a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[32:33], v[128:135] ; cc464080 1e02410a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[28:29], v[104:111] ; cc464068 1da2390a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[170:171], v[168:169], v[160:167] ; cc4640a0 1e8351aa
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[170:171], v[30:31], v[144:151] ; cc464090 1e423daa
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[170:171], v[28:29], v[136:143] ; cc464088 1e2239aa
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[170:171], v[32:33], v[176:183] ; cc4640b0 1ec241aa
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[172:173], v[28:29], v[184:191] ; cc4640b8 1ee239ac
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[172:173], v[30:31], v[48:55] ; cc464030 1cc23dac
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v171, v9 :: v_dual_mov_b32 v170, v8          ; ca100109 abaa0108
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v66, s[36:39], null offen offset:3072 ; c405c07c 4080481c 000c0042
	buffer_load_b128 v[8:11], v66, s[36:39], null offen offset:7168 ; c405c07c 40804808 001c0042
	v_wmma_f32_16x16x16_fp8_fp8 v[69:76], v[172:173], v[168:169], v[69:76] ; cc464045 1d1751ac
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[172:173], v[32:33], v[12:19] ; cc46400c 1c3241ac
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[38:39], v[88:95] ; cc464058 1d624d14
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[156:157], v[96:103] ; cc464060 1d833914
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[20:21], v[34:35], v[40:47] ; cc464028 1ca24514
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[36:37], v[80:87] ; cc464050 1d424914
	ds_load_b64 v[168:169], v68 offset:1792                     ; d9d80700 a8000044
	ds_load_b64 v[32:33], v68 offset:3840                       ; d9d80f00 20000044
	ds_load_b64 v[172:173], v68 offset:5888                     ; d9d81700 ac000044
	ds_load_b64 v[20:21], v68 offset:7936                       ; d9d81f00 14000044
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[36:37], v[112:119] ; cc464070 1dc24916
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[38:39], v[120:127] ; cc464078 1de24d16
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[34:35], v[104:111] ; cc464068 1da24516
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[156:157], v[128:135] ; cc464080 1e033916
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[60:61], v[38:39], v[160:167] ; cc4640a0 1e824d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[60:61], v[156:157], v[176:183] ; cc4640b0 1ec3393c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[36:37], v[144:151] ; cc464090 1e42493c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[34:35], v[136:143] ; cc464088 1e22453c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[62:63], v[34:35], v[184:191] ; cc4640b8 1ee2453e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[62:63], v[36:37], v[48:55] ; cc464030 1cc2493e
	v_dual_mov_b32 v23, v59 :: v_dual_mov_b32 v22, v58          ; ca10013b 1716013a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[34:37], v66, s[36:39], null offen offset:3584 ; c405c07c 40804822 000e0042
	buffer_load_b128 v[58:61], v66, s[36:39], null offen offset:7680 ; c405c07c 4080483a 001e0042
	v_wmma_f32_16x16x16_fp8_fp8 v[69:76], v[62:63], v[38:39], v[69:76] ; cc464045 1d164d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[62:63], v[156:157], v[12:19] ; cc46400c 1c33393e
	v_mad_u32_u24 v158, s59, 0x820, v158                        ; d60b009e 0679fe3b 00000820
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[154:155], v[88:95] ; cc464058 1d63351c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[170:171], v[96:103] ; cc464060 1d83551c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[28:29], v[152:153], v[40:47] ; cc464028 1ca3311c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[24:25], v[80:87] ; cc464050 1d42311c
	ds_load_b64 v[38:39], v158                                  ; d9d80000 2600009e
	ds_load_b64 v[62:63], v158 offset:2048                      ; d9d80800 3e00009e
	ds_load_b64 v[156:157], v158 offset:4096                    ; d9d81000 9c00009e
	ds_load_b64 v[28:29], v158 offset:6144                      ; d9d81800 1c00009e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[24:25], v[112:119] ; cc464070 1dc2311e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[154:155], v[120:127] ; cc464078 1de3351e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[170:171], v[128:135] ; cc464080 1e03551e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[152:153], v[104:111] ; cc464068 1da3311e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mov_b32 v31, v11 :: v_dual_mov_b32 v30, v10          ; ca10010b 1f1e010a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[8:9], v[152:153], v[136:143] ; cc464088 1e233108
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[8:9], v[24:25], v[144:151] ; cc464090 1e423108
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[8:9], v[154:155], v[160:167] ; cc4640a0 1e833508
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[8:9], v[170:171], v[176:183] ; cc4640b0 1ec35508
	buffer_load_b128 v[8:11], v66, s[36:39], null offen offset:8192 ; c405c07c 40804808 00200042
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[30:31], v[152:153], v[184:191] ; cc4640b8 1ee3311e
	v_wmma_f32_16x16x16_fp8_fp8 v[69:76], v[30:31], v[154:155], v[69:76] ; cc464045 1d17351e
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[30:31], v[170:171], v[12:19] ; cc46400c 1c33551e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[30:31], v[24:25], v[48:55] ; cc464030 1cc2311e
	ds_load_b64 v[152:153], v158 offset:256                     ; d9d80100 9800009e
	ds_load_b64 v[24:25], v158 offset:2304                      ; d9d80900 1800009e
	ds_load_b64 v[154:155], v158 offset:4352                    ; d9d81100 9a00009e
	ds_load_b64 v[30:31], v158 offset:6400                      ; d9d81900 1e00009e
	s_mov_b32 s61, 0x76543210                                   ; bebd00ff 76543210
	s_mov_b32 s62, 0xfedcba98                                   ; bebe00ff fedcba98
	s_movk_i32 s63, 0x410                                       ; b03f0410
	s_wait_loadcnt_dscnt 0x208                                  ; bfc80208
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[36:37], v[20:21], v[128:135] ; cc464080 1e022924
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[34:35], v[168:169], v[40:47] ; cc464028 1ca35122
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[34:35], v[32:33], v[80:87] ; cc464050 1d424122
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[34:35], v[172:173], v[88:95] ; cc464058 1d635922
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[20:21], v[96:103] ; cc464060 1d822922
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[172:173], v[120:127] ; cc464078 1de35924
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[32:33], v[112:119] ; cc464070 1dc24124
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[168:169], v[104:111] ; cc464068 1da35124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v35, v107, v107 :: v_dual_mul_f32 v34, v105, v105 ; c8c6d76b 2322d369
	v_dual_fmac_f32 v35, v43, v43 :: v_dual_fmac_f32 v34, v41, v41 ; c800572b 23225329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v35, v47, v47 :: v_dual_fmac_f32 v34, v45, v45 ; c8005f2f 23225b2d
	v_dual_fmac_f32 v35, v111, v111 :: v_dual_fmac_f32 v34, v109, v109 ; c800df6f 2322db6d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v35, v42, v42 :: v_dual_fmac_f32 v34, v40, v40 ; c800552a 23225128
	v_dual_fmac_f32 v35, v106, v106 :: v_dual_fmac_f32 v34, v104, v104 ; c800d56a 2322d168
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v35, v46, v46 :: v_dual_fmac_f32 v34, v44, v44 ; c8005d2e 2322592c
	v_dual_fmac_f32 v35, v110, v110 :: v_dual_fmac_f32 v34, v108, v108 ; c800dd6e 2322d96c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v36, 1.0, v34, v35                          ; cc210024 048e44f2
	v_cvt_u32_u16_e32 v37, v36                                  ; 7e4ad724
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v37, v37, s61, s62 op_sel:[1,1]           ; d65c1825 00f87b25
	v_add_f16_e32 v36, v36, v37                                 ; 64484b24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v36, s63, v36                             ; 6248483f
	v_cvt_f32_f16_e32 v68, v36                                  ; 7e881724
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v68, v68                                      ; 7e885d44
	v_mul_f32_e32 v68, v68, v65                                 ; 10888344
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v111, v111, v68 :: v_dual_mul_f32 v110, v110, v68 ; c8c6896f 6f6e896e
	v_dual_mul_f32 v41, v41, v68 :: v_dual_mul_f32 v40, v40, v68 ; c8c68929 29288928
	v_dual_mul_f32 v104, v104, v68 :: v_dual_mul_f32 v105, v105, v68 ; c8c68968 68688969
	v_dual_mul_f32 v106, v106, v68 :: v_dual_mul_f32 v107, v107, v68 ; c8c6896a 6a6a896b
	v_dual_mul_f32 v43, v43, v68 :: v_dual_mul_f32 v42, v42, v68 ; c8c6892b 2b2a892a
	v_dual_mul_f32 v108, v108, v68 :: v_dual_mul_f32 v109, v109, v68 ; c8c6896c 6c6c896d
	v_dual_mul_f32 v45, v45, v68 :: v_dual_mul_f32 v44, v44, v68 ; c8c6892d 2d2c892c
	v_dual_mul_f32 v47, v47, v68 :: v_dual_mul_f32 v46, v46, v68 ; c8c6892f 2f2e892e
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_mul_f32 v105, v115, v115 :: v_dual_mul_f32 v104, v113, v113 ; c8c6e773 6968e371
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	v_dual_fmac_f32 v105, v83, v83 :: v_dual_fmac_f32 v104, v81, v81 ; c800a753 6968a351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v105, v87, v87 :: v_dual_fmac_f32 v104, v85, v85 ; c800af57 6968ab55
	v_dual_fmac_f32 v105, v119, v119 :: v_dual_fmac_f32 v104, v117, v117 ; c800ef77 6968eb75
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v105, v82, v82 :: v_dual_fmac_f32 v104, v80, v80 ; c800a552 6968a150
	v_dual_fmac_f32 v105, v114, v114 :: v_dual_fmac_f32 v104, v112, v112 ; c800e572 6968e170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v105, v86, v86 :: v_dual_fmac_f32 v104, v84, v84 ; c800ad56 6968a954
	v_dual_fmac_f32 v105, v118, v118 :: v_dual_fmac_f32 v104, v116, v116 ; c800ed76 6968e974
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v106, 1.0, v104, v105                       ; cc21006a 05a6d0f2
	v_cvt_u32_u16_e32 v107, v106                                ; 7ed6d76a
	v_dual_mul_f32 v110, v123, v123 :: v_dual_mul_f32 v109, v121, v121 ; c8c6f77b 6e6cf379
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v107, v107, s61, s62 op_sel:[1,1]         ; d65c186b 00f87b6b
	v_dual_fmac_f32 v110, v91, v91 :: v_dual_fmac_f32 v109, v89, v89 ; c800b75b 6e6cb359
	v_add_f16_e32 v106, v106, v107                              ; 64d4d76a
	v_dual_fmac_f32 v110, v95, v95 :: v_dual_fmac_f32 v109, v93, v93 ; c800bf5f 6e6cbb5d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_max_num_f16_e32 v106, s63, v106                           ; 62d4d43f
	v_dual_fmac_f32 v110, v127, v127 :: v_dual_fmac_f32 v109, v125, v125 ; c800ff7f 6e6cfb7d
	v_cvt_f32_f16_e32 v108, v106                                ; 7ed8176a
	v_dual_fmac_f32 v110, v90, v90 :: v_dual_fmac_f32 v109, v88, v88 ; c800b55a 6e6cb158
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a2
	v_rsq_f32_e32 v108, v108                                    ; 7ed85d6c
	v_dual_fmac_f32 v110, v122, v122 :: v_dual_fmac_f32 v109, v120, v120 ; c800f57a 6e6cf178
	v_mul_f32_e32 v108, v108, v65                               ; 10d8836c
	v_dual_fmac_f32 v110, v94, v94 :: v_dual_fmac_f32 v109, v92, v92 ; c800bd5e 6e6cb95c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v87, v87, v108 :: v_dual_mul_f32 v86, v86, v108 ; c8c6d957 5756d956
	v_dual_mul_f32 v112, v112, v108 :: v_dual_mul_f32 v113, v113, v108 ; c8c6d970 7070d971
	v_dual_mul_f32 v114, v114, v108 :: v_dual_mul_f32 v115, v115, v108 ; c8c6d972 7272d973
	v_dual_mul_f32 v83, v83, v108 :: v_dual_mul_f32 v82, v82, v108 ; c8c6d953 5352d952
	v_dual_mul_f32 v116, v116, v108 :: v_dual_mul_f32 v117, v117, v108 ; c8c6d974 7474d975
	v_dual_mul_f32 v85, v85, v108 :: v_dual_mul_f32 v84, v84, v108 ; c8c6d955 5554d954
	v_dual_mul_f32 v119, v119, v108 :: v_dual_mul_f32 v118, v118, v108 ; c8c6d977 7776d976
	v_dual_mul_f32 v81, v81, v108 :: v_dual_mul_f32 v80, v80, v108 ; c8c6d951 5150d950
	v_dual_fmac_f32 v110, v126, v126 :: v_dual_fmac_f32 v109, v124, v124 ; c800fd7e 6e6cf97c
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_fma_mixlo_f16 v111, 1.0, v109, v110                       ; cc21006f 05badaf2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_u32_u16_e32 v112, v111                                ; 7ee0d76f
	v_dual_mul_f32 v115, v131, v131 :: v_dual_mul_f32 v114, v129, v129 ; c8c70783 73730381
	v_permlanex16_b32 v112, v112, s61, s62 op_sel:[1,1]         ; d65c1870 00f87b70
	v_dual_fmac_f32 v115, v99, v99 :: v_dual_fmac_f32 v114, v97, v97 ; c800c763 7372c361
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_add_f16_e32 v111, v111, v112                              ; 64dee16f
	v_dual_fmac_f32 v115, v103, v103 :: v_dual_fmac_f32 v114, v101, v101 ; c800cf67 7372cb65
	v_max_num_f16_e32 v111, s63, v111                           ; 62dede3f
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[58:59], v[168:169], v[136:143] ; cc464088 1e23513a
	v_cvt_f32_f16_e32 v113, v111                                ; 7ee2176f
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[58:59], v[32:33], v[144:151] ; cc464090 1e42413a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[172:173], v[160:167] ; cc4640a0 1e83593a
	v_rsq_f32_e32 v113, v113                                    ; 7ee25d71
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[58:59], v[20:21], v[176:183] ; cc4640b0 1ec2293a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[60:61], v[168:169], v[184:191] ; cc4640b8 1ee3513c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[60:61], v[32:33], v[48:55] ; cc464030 1cc2413c
	v_wmma_f32_16x16x16_fp8_fp8 v[69:76], v[60:61], v[172:173], v[69:76] ; cc464045 1d17593c
	v_mul_f32_e32 v113, v113, v65                               ; 10e28371
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[60:61], v[20:21], v[12:19] ; cc46400c 1c32293c
	v_dual_fmac_f32 v115, v135, v135 :: v_dual_fmac_f32 v114, v133, v133 ; c8010f87 73730b85
	v_dual_mul_f32 v125, v125, v113 :: v_dual_mul_f32 v124, v124, v113 ; c8c6e37d 7d7ce37c
	v_dual_mul_f32 v127, v127, v113 :: v_dual_mul_f32 v126, v126, v113 ; c8c6e37f 7f7ee37e
	v_dual_mul_f32 v121, v121, v113 :: v_dual_mul_f32 v120, v120, v113 ; c8c6e379 7978e378
	v_dual_mul_f32 v95, v95, v113 :: v_dual_mul_f32 v94, v94, v113 ; c8c6e35f 5f5ee35e
	v_dual_mul_f32 v90, v90, v113 :: v_dual_mul_f32 v91, v91, v113 ; c8c6e35a 5a5ae35b
	v_dual_mul_f32 v88, v88, v113 :: v_dual_mul_f32 v89, v89, v113 ; c8c6e358 5858e359
	v_dual_mul_f32 v123, v123, v113 :: v_dual_mul_f32 v122, v122, v113 ; c8c6e37b 7b7ae37a
	v_dual_mul_f32 v92, v92, v113 :: v_dual_mul_f32 v93, v93, v113 ; c8c6e35c 5c5ce35d
	v_dual_fmac_f32 v115, v98, v98 :: v_dual_fmac_f32 v114, v96, v96 ; c800c562 7372c160
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_dual_fmac_f32 v115, v130, v130 :: v_dual_fmac_f32 v114, v128, v128 ; c8010582 73730180
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v115, v102, v102 :: v_dual_fmac_f32 v114, v100, v100 ; c800cd66 7372c964
	v_dual_fmac_f32 v115, v134, v134 :: v_dual_fmac_f32 v114, v132, v132 ; c8010d86 73730984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v116, 1.0, v114, v115                       ; cc210074 05cee4f2
	v_cvt_u32_u16_e32 v117, v116                                ; 7eead774
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v117, v117, s61, s62 op_sel:[1,1]         ; d65c1875 00f87b75
	v_add_f16_e32 v116, v116, v117                              ; 64e8eb74
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v116, s63, v116                           ; 62e8e83f
	v_cvt_f32_f16_e32 v118, v116                                ; 7eec1774
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v118, v118                                    ; 7eec5d76
	v_mul_f32_e32 v118, v118, v65                               ; 10ec8376
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v133, v133, v118 :: v_dual_mul_f32 v130, v130, v118 ; c8c6ed85 8582ed82
	v_mul_f32_e32 v97, v97, v118                                ; 10c2ed61
	v_dual_mul_f32 v99, v99, v118 :: v_dual_mul_f32 v96, v96, v118 ; c8c6ed63 6360ed60
	v_dual_mul_f32 v135, v135, v118 :: v_dual_mul_f32 v132, v132, v118 ; c8c6ed87 8784ed84
	v_dual_mul_f32 v119, v185, v185 :: v_dual_mul_f32 v134, v134, v118 ; c8c773b9 7786ed86
	v_dual_mul_f32 v103, v103, v118 :: v_dual_mul_f32 v100, v100, v118 ; c8c6ed67 6764ed64
	v_dual_mul_f32 v129, v129, v118 :: v_dual_mul_f32 v102, v102, v118 ; c8c6ed81 8166ed66
	v_dual_mul_f32 v101, v101, v118 :: v_dual_mul_f32 v98, v98, v118 ; c8c6ed65 6562ed62
	v_dual_mul_f32 v131, v131, v118 :: v_dual_mul_f32 v128, v128, v118 ; c8c6ed83 8380ed80
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	buffer_load_b128 v[80:83], v66, s[36:39], null offen offset:8704 ; c405c07c 40804850 00220042
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_fmac_f32 v119, v137, v137 :: v_dual_mul_f32 v120, v187, v187 ; c8071389 777977bb
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_fmac_f32 v119, v141, v141 :: v_dual_fmac_f32 v120, v139, v139 ; c8011b8d 7779178b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v119, v189, v189 :: v_dual_fmac_f32 v120, v143, v143 ; c8017bbd 77791f8f
	v_dual_fmac_f32 v119, v136, v136 :: v_dual_fmac_f32 v120, v191, v191 ; c8011188 77797fbf
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v119, v184, v184 :: v_dual_fmac_f32 v120, v138, v138 ; c80171b8 7779158a
	v_dual_fmac_f32 v119, v140, v140 :: v_dual_fmac_f32 v120, v186, v186 ; c801198c 777975ba
	buffer_load_b128 v[84:87], v66, s[36:39], null offen offset:9216 ; c405c07c 40804854 00240042
	v_dual_fmac_f32 v119, v188, v188 :: v_dual_fmac_f32 v120, v142, v142 ; c80179bc 77791d8e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v120, v190, v190                             ; 56f17dbe
	v_fma_mixlo_f16 v121, 1.0, v119, v120                       ; cc210079 05e2eef2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v122, v121                                ; 7ef4d779
	v_permlanex16_b32 v122, v122, s61, s62 op_sel:[1,1]         ; d65c187a 00f87b7a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v121, v121, v122                              ; 64f2f579
	v_max_num_f16_e32 v121, s63, v121                           ; 62f2f23f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v123, v121                                ; 7ef61779
	v_rsq_f32_e32 v123, v123                                    ; 7ef65d7b
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v140, v140, v123 :: v_dual_mul_f32 v139, v139, v123 ; c8c6f78c 8c8af78b
	buffer_load_b128 v[88:91], v66, s[36:39], null offen offset:9728 ; c405c07c 40804858 00260042
	v_mul_f32_e32 v136, v136, v123                              ; 1110f788
	v_dual_mul_f32 v143, v143, v123 :: v_dual_mul_f32 v142, v142, v123 ; c8c6f78f 8f8ef78e
	v_dual_mul_f32 v138, v138, v123 :: v_dual_mul_f32 v137, v137, v123 ; c8c6f78a 8a88f789
	v_mul_f32_e32 v141, v141, v123                              ; 111af78d
	v_dual_mul_f32 v187, v187, v123 :: v_dual_mul_f32 v186, v186, v123 ; c8c6f7bb bbbaf7ba
	v_dual_mul_f32 v185, v185, v123 :: v_dual_mul_f32 v184, v184, v123 ; c8c6f7b9 b9b8f7b8
	v_dual_mul_f32 v189, v189, v123 :: v_dual_mul_f32 v188, v188, v123 ; c8c6f7bd bdbcf7bc
	v_mul_f32_e32 v190, v190, v123                              ; 117cf7be
	v_mul_f32_e32 v124, v49, v49                                ; 10f86331
	buffer_load_b128 v[92:95], v66, s[36:39], null offen offset:10240 ; c405c07c 4080485c 00280042
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_fmac_f32_e32 v124, v145, v145                             ; 56f92391
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v124, v149, v149 :: v_dual_mul_f32 v191, v191, v123 ; c8072b95 7cbef7bf
	v_dual_fmac_f32 v124, v53, v53 :: v_dual_mul_f32 v125, v51, v51 ; c8066b35 7c7c6733
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmac_f32 v124, v144, v144 :: v_dual_fmac_f32 v125, v147, v147 ; c8012190 7c7d2793
	v_dual_fmac_f32 v124, v48, v48 :: v_dual_fmac_f32 v125, v151, v151 ; c8006130 7c7d2f97
	buffer_load_b128 v[100:103], v66, s[36:39], null offen offset:10752 ; c405c07c 40804864 002a0042
	v_dual_fmac_f32 v124, v148, v148 :: v_dual_fmac_f32 v125, v55, v55 ; c8012994 7c7c6f37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v125, v146, v146                             ; 56fb2592
	v_fmac_f32_e32 v125, v50, v50                               ; 56fa6532
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v125, v150, v150                             ; 56fb2d96
	v_dual_fmac_f32 v125, v54, v54 :: v_dual_fmac_f32 v124, v52, v52 ; c8006d36 7d7c6934
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v126, 1.0, v124, v125                       ; cc21007e 05f6f8f2
	v_cvt_u32_u16_e32 v127, v126                                ; 7efed77e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v127, v127, s61, s62 op_sel:[1,1]         ; d65c187f 00f87b7f
	v_add_f16_e32 v126, v126, v127                              ; 64fcff7e
	buffer_load_b128 v[104:107], v66, s[36:39], null offen offset:11264 ; c405c07c 40804868 002c0042
	v_max_num_f16_e32 v126, s63, v126                           ; 62fcfc3f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v128, v126                                ; 7f00177e
	v_rsq_f32_e32 v128, v128                                    ; 7f005d80
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_mul_f32_e32 v53, v53, v128                                ; 106b0135
	v_dual_mul_f32 v51, v51, v128 :: v_dual_mul_f32 v50, v50, v128 ; c8c70133 33330132
	v_dual_mul_f32 v145, v145, v128 :: v_dual_mul_f32 v144, v144, v128 ; c8c70191 91910190
	v_dual_mul_f32 v149, v149, v128 :: v_dual_mul_f32 v148, v148, v128 ; c8c70195 95950194
	v_dual_mul_f32 v147, v147, v128 :: v_dual_mul_f32 v146, v146, v128 ; c8c70193 93930192
	v_dual_mul_f32 v151, v151, v128 :: v_dual_mul_f32 v150, v150, v128 ; c8c70197 97970196
	v_dual_mul_f32 v49, v49, v128 :: v_dual_mul_f32 v48, v48, v128 ; c8c70131 31310130
	v_dual_mul_f32 v129, v70, v70 :: v_dual_mul_f32 v52, v52, v128 ; c8c68d46 81350134
	v_dual_mul_f32 v55, v55, v128 :: v_dual_mul_f32 v54, v54, v128 ; c8c70137 37370136
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	buffer_load_b128 v[52:55], v66, s[36:39], null offen offset:11776 ; c405c07c 40804834 002e0042
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7690060
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7690061
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694060
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7694061
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_dual_fmac_f32 v129, v161, v161 :: v_dual_mul_f32 v130, v72, v72 ; c80743a1 81829148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v129, v165, v165 :: v_dual_fmac_f32 v130, v163, v163 ; c8014ba5 818347a3
	v_dual_fmac_f32 v129, v74, v74 :: v_dual_fmac_f32 v130, v167, v167 ; c800954a 81834fa7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v130, v76, v76                               ; 5704994c
	v_dual_fmac_f32 v130, v162, v162 :: v_dual_fmac_f32 v129, v160, v160 ; c80145a2 828141a0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v130, v71, v71 :: v_dual_fmac_f32 v129, v69, v69 ; c8008f47 82808b45
	v_dual_fmac_f32 v130, v166, v166 :: v_dual_fmac_f32 v129, v164, v164 ; c8014da6 828149a4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v130, v75, v75 :: v_dual_fmac_f32 v129, v73, v73 ; c800974b 82809349
	v_fma_mixlo_f16 v131, 1.0, v129, v130                       ; cc210083 060b02f2
	v_dual_mul_f32 v135, v15, v15 :: v_dual_mul_f32 v134, v13, v13 ; c8c61f0f 87861b0d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d5eb0084
	v_cndmask_b32_e32 v0, v131, v128, vcc_lo                    ; 02010183
	v_dual_fmac_f32 v135, v179, v179 :: v_dual_fmac_f32 v134, v177, v177 ; c80167b3 878763b1
	v_permlanex16_b32 v132, v132, s61, s62 op_sel:[1,1]         ; d65c1884 00f87b84
	v_dual_fmac_f32 v135, v183, v183 :: v_dual_fmac_f32 v134, v181, v181 ; c8016fb7 87876bb5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d5320083
	v_cndmask_b32_e32 v1, v131, v132, vcc_lo                    ; 02030983
	v_dual_fmac_f32 v135, v19, v19 :: v_dual_fmac_f32 v134, v17, v17 ; c8002713 87862311
(invalid instruction)                                        ; d5310083
	v_cndmask_b32_e32 v1, s63, v131, vcc_lo                     ; 0203063f
	v_dual_fmac_f32 v135, v178, v178 :: v_dual_fmac_f32 v134, v176, v176 ; c80165b2 878761b0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d58b0085
	v_cndmask_b32_e32 v0, v131, v128, vcc_lo                    ; 02010183
	v_dual_fmac_f32 v135, v14, v14 :: v_dual_fmac_f32 v134, v12, v12 ; c8001d0e 8786190c
	v_rsq_f32_e32 v133, v133                                    ; 7f0a5d85
	v_dual_fmac_f32 v135, v182, v182 :: v_dual_fmac_f32 v134, v180, v180 ; c8016db6 878769b4
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v166, v166, v133 :: v_dual_mul_f32 v167, v167, v133 ; c8c70ba6 a6a70ba7
	v_dual_mul_f32 v162, v162, v133 :: v_dual_mul_f32 v163, v163, v133 ; c8c70ba2 a2a30ba3
	v_dual_mul_f32 v164, v164, v133 :: v_dual_mul_f32 v165, v165, v133 ; c8c70ba4 a4a50ba5
	v_dual_mul_f32 v160, v160, v133 :: v_dual_mul_f32 v161, v161, v133 ; c8c70ba0 a0a10ba1
	v_dual_mul_f32 v70, v70, v133 :: v_dual_mul_f32 v69, v69, v133 ; c8c70b46 46450b45
	v_dual_mul_f32 v72, v72, v133 :: v_dual_mul_f32 v71, v71, v133 ; c8c70b48 48470b47
	v_dual_mul_f32 v74, v74, v133 :: v_dual_mul_f32 v73, v73, v133 ; c8c70b4a 4a490b49
	v_dual_mul_f32 v76, v76, v133 :: v_dual_mul_f32 v75, v75, v133 ; c8c70b4c 4c4b0b4b
	v_dual_fmac_f32 v135, v18, v18 :: v_dual_fmac_f32 v134, v16, v16 ; c8002512 87862110
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v69, v70, vcc_lo                      ; 02028d45
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v71, v72, vcc_lo                      ; 02029147
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                      ; 02029549
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v75, v76, vcc_lo                      ; 0202994b
	v_fma_mixlo_f16 v136, 1.0, v134, v135                       ; cc210088 061f0cf2
	v_lshl_add_u32 v139, v1, 12, s8                             ; d646008b 00211901
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d5eb0089
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                    ; 02010188
	v_lshl_add_u32 v139, v4, 6, v139                            ; d646008b 062d0d04
	v_permlanex16_b32 v137, v137, s61, s62 op_sel:[1,1]         ; d65c1889 00f87b89
	v_add_lshl_u32 v139, v139, v6, 2                            ; d647008b 020a0d8b
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v139, s[32:35], null offen       ; c405c07c 40804048 0000008b
	buffer_load_b128 v[108:111], v139, s[32:35], null offen offset:16 ; c405c07c 4080406c 0000108b
(invalid instruction)                                        ; d5320088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5310088
	v_cndmask_b32_e32 v1, s63, v136, vcc_lo                     ; 0203103f
(invalid instruction)                                        ; d58b008a
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                    ; 02010188
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_rsq_f32_e32 v138, v138                                    ; 7f145d8a
	ds_load_b64 v[98:99], v158 offset:512                       ; d9d80200 6200009e
	ds_load_b64 v[112:113], v158 offset:2560                    ; d9d80a00 7000009e
	ds_load_b64 v[114:115], v158 offset:4608                    ; d9d81200 7200009e
	ds_load_b64 v[116:117], v158 offset:6656                    ; d9d81a00 7400009e
	v_mul_f32_e32 v176, v176, v138                              ; 116115b0
	v_dual_mul_f32 v17, v17, v138 :: v_dual_mul_f32 v16, v16, v138 ; c8c71511 11111510
	v_mul_f32_e32 v183, v183, v138                              ; 116f15b7
	v_dual_mul_f32 v177, v177, v138 :: v_dual_mul_f32 v178, v178, v138 ; c8c715b1 b1b315b2
	v_dual_mul_f32 v179, v179, v138 :: v_dual_mul_f32 v180, v180, v138 ; c8c715b3 b3b515b4
	v_dual_mul_f32 v13, v13, v138 :: v_dual_mul_f32 v12, v12, v138 ; c8c7150d 0d0d150c
	v_dual_mul_f32 v19, v19, v138 :: v_dual_mul_f32 v18, v18, v138 ; c8c71513 13131512
	v_dual_mul_f32 v15, v15, v138 :: v_dual_mul_f32 v14, v14, v138 ; c8c7150f 0f0f150e
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
	ds_load_b64 v[14:15], v158 offset:768                       ; d9d80300 0e00009e
	ds_load_b64 v[16:17], v158 offset:2816                      ; d9d80b00 1000009e
	ds_load_b64 v[18:19], v158 offset:4864                      ; d9d81300 1200009e
	ds_load_b64 v[118:119], v158 offset:6912                    ; d9d81b00 7600009e
	v_dual_mul_f32 v181, v181, v138 :: v_dual_mul_f32 v182, v182, v138 ; c8c715b5 b5b715b6
	s_wait_loadcnt_dscnt 0x90f                                  ; bfc8090f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[8:9], v[38:39], 0 ; cc464078 1a024d08
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[8:9], v[62:63], 0 ; cc464080 1a027d08
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[8:9], v[156:157], 0 ; cc464090 1a033908
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[8:9], v[28:29], 0 ; cc4640a0 1a023908
	v_mov_b32_e32 v8, v139                                      ; 7e10038b
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[10:11], v[38:39], 0 ; cc4640a8 1a024d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[10:11], v[156:157], 0 ; cc4640b8 1a03390a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[28:29], 0 ; cc464088 1a02390a
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[10:11], v[62:63], 0 ; cc4640b0 1a027d0a
	s_wait_loadcnt_dscnt 0x80b                                  ; bfc8080b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[152:153], v[120:127] ; cc464078 1de33150
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[24:25], v[128:135] ; cc464080 1e023150
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[80:81], v[154:155], v[144:151] ; cc464090 1e433550
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[80:81], v[30:31], v[160:167] ; cc4640a0 1e823d50
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[82:83], v[152:153], v[168:175] ; cc4640a8 1ea33152
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[82:83], v[154:155], v[184:191] ; cc4640b8 1ee33552
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[82:83], v[30:31], v[136:143] ; cc464088 1e223d52
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[82:83], v[24:25], v[176:183] ; cc4640b0 1ec23152
	ds_load_b64 v[10:11], v158 offset:1024                      ; d9d80400 0a00009e
	ds_load_b64 v[28:29], v158 offset:3072                      ; d9d80c00 1c00009e
	ds_load_b64 v[38:39], v158 offset:5120                      ; d9d81400 2600009e
	ds_load_b64 v[62:63], v158 offset:7168                      ; d9d81c00 3e00009e
	ds_load_b64 v[24:25], v158 offset:1280                      ; d9d80500 1800009e
	ds_load_b64 v[30:31], v158 offset:3328                      ; d9d80d00 1e00009e
	ds_load_b64 v[80:81], v158 offset:5376                      ; d9d81500 5000009e
	ds_load_b64 v[82:83], v158 offset:7424                      ; d9d81d00 5200009e
	s_wait_loadcnt_dscnt 0x70f                                  ; bfc8070f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[84:85], v[98:99], v[120:127] ; cc464078 1de2c554
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[112:113], v[128:135] ; cc464080 1e02e154
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[114:115], v[144:151] ; cc464090 1e42e554
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[84:85], v[116:117], v[160:167] ; cc4640a0 1e82e954
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[86:87], v[98:99], v[168:175] ; cc4640a8 1ea2c556
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[86:87], v[114:115], v[184:191] ; cc4640b8 1ee2e556
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[86:87], v[116:117], v[136:143] ; cc464088 1e22e956
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[86:87], v[112:113], v[176:183] ; cc4640b0 1ec2e156
	s_wait_loadcnt_dscnt 0x60b                                  ; bfc8060b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[88:89], v[14:15], v[120:127] ; cc464078 1de21d58
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[88:89], v[16:17], v[128:135] ; cc464080 1e022158
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[88:89], v[18:19], v[144:151] ; cc464090 1e422558
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[88:89], v[118:119], v[160:167] ; cc4640a0 1e82ed58
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[90:91], v[14:15], v[168:175] ; cc4640a8 1ea21d5a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[90:91], v[18:19], v[184:191] ; cc4640b8 1ee2255a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[90:91], v[16:17], v[176:183] ; cc4640b0 1ec2215a
	ds_load_b64 v[84:85], v158 offset:1536                      ; d9d80600 5400009e
	ds_load_b64 v[86:87], v158 offset:3584                      ; d9d80e00 5600009e
	ds_load_b64 v[98:99], v158 offset:5632                      ; d9d81600 6200009e
	ds_load_b64 v[112:113], v158 offset:7680                    ; d9d81e00 7000009e
	ds_load_b64 v[14:15], v158 offset:1792                      ; d9d80700 0e00009e
	ds_load_b64 v[16:17], v158 offset:3840                      ; d9d80f00 1000009e
	ds_load_b64 v[18:19], v158 offset:5888                      ; d9d81700 1200009e
	ds_load_b64 v[88:89], v158 offset:7936                      ; d9d81f00 5800009e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[90:91], v[118:119], v[136:143] ; cc464088 1e22ed5a
	s_wait_loadcnt_dscnt 0x50f                                  ; bfc8050f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[92:93], v[10:11], v[120:127] ; cc464078 1de2155c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[28:29], v[128:135] ; cc464080 1e02395c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[92:93], v[38:39], v[144:151] ; cc464090 1e424d5c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[92:93], v[62:63], v[160:167] ; cc4640a0 1e827d5c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[94:95], v[10:11], v[168:175] ; cc4640a8 1ea2155e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[94:95], v[38:39], v[184:191] ; cc4640b8 1ee24d5e
	v_dual_mov_b32 v39, v67 :: v_dual_mov_b32 v38, v64          ; ca100143 27260140
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[94:95], v[28:29], v[176:183] ; cc4640b0 1ec2395e
	v_mov_b32_e32 v28, v8                                       ; 7e380308
	v_mov_b32_e32 v29, v159                                     ; 7e3a039f
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[116:119], v8, s[32:35], null offen offset:64 ; c405c07c 40804074 00004008
	buffer_load_b128 v[152:155], v8, s[32:35], null offen offset:80 ; c405c07c 40804098 00005008
	buffer_load_b128 v[90:93], v8, s[32:35], null offen offset:128 ; c405c07c 4080405a 00008008
	buffer_load_b128 v[8:11], v8, s[32:35], null offen offset:144 ; c405c07c 40804008 00009008
	buffer_load_b128 v[156:159], v28, s[32:35], null offen offset:192 ; c405c07c 4080409c 0000c01c
	buffer_load_b128 v[64:67], v28, s[32:35], null offen offset:208 ; c405c07c 40804040 0000d01c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[94:95], v[62:63], v[136:143] ; cc464088 1e227d5e
	s_wait_loadcnt_dscnt 0xa0b                                  ; bfc80a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[100:101], v[24:25], v[120:127] ; cc464078 1de23164
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[100:101], v[30:31], v[128:135] ; cc464080 1e023d64
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[80:81], v[144:151] ; cc464090 1e42a164
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[100:101], v[82:83], v[160:167] ; cc4640a0 1e82a564
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[102:103], v[24:25], v[168:175] ; cc4640a8 1ea23166
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[102:103], v[80:81], v[184:191] ; cc4640b8 1ee2a166
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[102:103], v[30:31], v[176:183] ; cc4640b0 1ec23d66
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[102:103], v[82:83], v[136:143] ; cc464088 1e22a566
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[104:105], v[84:85], v[120:127] ; cc464078 1de2a968
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[104:105], v[86:87], v[128:135] ; cc464080 1e02ad68
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[104:105], v[98:99], v[144:151] ; cc464090 1e42c568
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[104:105], v[112:113], v[160:167] ; cc4640a0 1e82e168
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[106:107], v[84:85], v[168:175] ; cc4640a8 1ea2a96a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[106:107], v[98:99], v[184:191] ; cc4640b8 1ee2c56a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[106:107], v[86:87], v[176:183] ; cc4640b0 1ec2ad6a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[106:107], v[112:113], v[136:143] ; cc464088 1e22e16a
	s_wait_loadcnt_dscnt 0x803                                  ; bfc80803
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[52:53], v[14:15], v[120:127] ; cc464078 1de21d34
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[52:53], v[16:17], v[128:135] ; cc464080 1e022134
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[52:53], v[18:19], v[144:151] ; cc464090 1e422534
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[52:53], v[88:89], v[160:167] ; cc4640a0 1e82b134
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[54:55], v[14:15], v[168:175] ; cc4640a8 1ea21d36
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[18:19], v[184:191] ; cc4640b8 1ee22536
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[16:17], v[176:183] ; cc4640b0 1ec22136
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[54:55], v[88:89], v[136:143] ; cc464088 1e22b136
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	ds_store_2addr_b64 v56, v[14:15], v[16:17] offset1:32       ; d9382000 00100e38
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	ds_store_2addr_b64 v57, v[14:15], v[16:17] offset1:32       ; d9382000 00100e39
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	ds_store_2addr_b64 v22, v[14:15], v[16:17] offset1:32       ; d9382000 00100e16
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v23, v[14:15], v[16:17] offset1:32       ; d9382000 00100e17
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v28, s[32:35], null offen offset:4096 ; c405c07c 40804010 0010001c
	buffer_load_b128 v[52:55], v28, s[32:35], null offen offset:4112 ; c405c07c 40804034 0010101c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[58:59], v[34:35], 0 ; cc464050 1a02453a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[96:97], v[34:35], 0 ; cc464078 1a024560
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[34:35], 0 ; cc464080 1a024532
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[34:35], 0 ; cc464088 1a024546
	s_mov_b32 s64, 0x3d380000                                   ; bec000ff 3d380000
	s_movk_i32 s65, 0x3e47                                      ; b0413e47
	s_movk_i32 s66, 0x3c20                                      ; b0423c20
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[36:37], v[80:87] ; cc464050 1d42493c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[36:37], v[120:127] ; cc464078 1de24930
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[36:37], v[128:135] ; cc464080 1e024944
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[12:13], v[36:37], v[136:143] ; cc464088 1e22490c
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v57, s64, v82, v74                          ; cc210039 052aa440
	v_fma_mixhi_f16 v57, s64, v83, v75                          ; cc220039 052ea640
	v_fma_mixlo_f16 v56, s64, v80, v72                          ; cc210038 0522a040
	v_fma_mixhi_f16 v56, s64, v81, v73                          ; cc220038 0526a240
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v28, s[32:35], null offen offset:4160 ; c405c07c 40804048 0010401c
	buffer_load_b128 v[80:83], v28, s[32:35], null offen offset:4176 ; c405c07c 40804050 0010501c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v62, s64, v84, v108                         ; cc21003e 05b2a840
	v_fma_mixhi_f16 v62, s64, v85, v109                         ; cc22003e 05b6aa40
	v_fma_mixlo_f16 v63, s64, v86, v110                         ; cc21003f 05baac40
	v_fma_mixhi_f16 v63, s64, v87, v111                         ; cc22003f 05beae40
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v76, s64, v120, v116                        ; cc21004c 05d2f040
	v_fma_mixhi_f16 v76, s64, v121, v117                        ; cc22004c 05d6f240
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v66                               ; 0a008539
	v_fma_mixlo_f16 v84, s64, v122, v118                        ; cc210054 05daf440
	v_fma_mixhi_f16 v84, s64, v123, v119                        ; cc220054 05def640
(invalid instruction)                                        ; cc1c0038
	v_subrev_f32_e32 v0, v56, v66                               ; 0a008538
	s_mov_b32 s67, 0x7ff88000                                   ; bec300ff 7ff88000
(invalid instruction)                                        ; cc1c003e
	v_subrev_f32_e32 v0, v62, v66                               ; 0a00853e
(invalid instruction)                                        ; cc1c003f
	v_subrev_f32_e32 v0, v63, v66                               ; 0a00853f
(invalid instruction)                                        ; cc1c004c
	v_subrev_f32_e32 v0, v76, v66                               ; 0a00854c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[100:103], v28, s[32:35], null offen offset:4224 ; c405c07c 40804064 0010801c
	buffer_load_b128 v[104:107], v28, s[32:35], null offen offset:4240 ; c405c07c 40804068 0010901c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v87, s64, v124, v152                        ; cc210057 0662f840
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v65                               ; 0a008339
	v_fma_mixhi_f16 v87, s64, v125, v153                        ; cc220057 0666fa40
(invalid instruction)                                        ; cc1c0054
	v_subrev_f32_e32 v0, v84, v66                               ; 0a008554
(invalid instruction)                                        ; cc1b0038
	v_subrev_f32_e32 v0, v56, v65                               ; 0a008338
(invalid instruction)                                        ; cc1b003e
	v_subrev_f32_e32 v0, v62, v65                               ; 0a00833e
(invalid instruction)                                        ; cc1b003f
	v_subrev_f32_e32 v0, v63, v65                               ; 0a00833f
	v_fma_mixlo_f16 v88, s64, v126, v154                        ; cc210058 066afc40
(invalid instruction)                                        ; cc1b004c
	v_subrev_f32_e32 v0, v76, v65                               ; 0a00834c
	v_fma_mixhi_f16 v88, s64, v127, v155                        ; cc220058 066efe40
	v_lshl_add_u32 v57, v57, 5, s67                             ; d6460039 010d0b39
(invalid instruction)                                        ; cc1c0057
	v_subrev_f32_e32 v0, v87, v66                               ; 0a008557
(invalid instruction)                                        ; cc1b0054
	v_subrev_f32_e32 v0, v84, v65                               ; 0a008354
	v_lshl_add_u32 v56, v56, 5, s67                             ; d6460038 010d0b38
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v90, s64, v128, v90                         ; cc21005a 056b0040
	v_lshl_add_u32 v62, v62, 5, s67                             ; d646003e 010d0b3e
	v_lshl_add_u32 v63, v63, 5, s67                             ; d646003f 010d0b3f
	v_fma_mixhi_f16 v90, s64, v129, v91                         ; cc22005a 056f0240
	v_lshl_add_u32 v76, v76, 5, s67                             ; d646004c 010d0b4c
	v_fma_mixlo_f16 v91, s64, v130, v92                         ; cc21005b 05730440
	v_fma_mixhi_f16 v91, s64, v131, v93                         ; cc22005b 05770640
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[92:95], v28, s[32:35], null offen offset:4288 ; c405c07c 4080405c 0010c01c
	buffer_load_b128 v[108:111], v28, s[32:35], null offen offset:4304 ; c405c07c 4080406c 0010d01c
(invalid instruction)                                        ; cc1c0058
	v_subrev_f32_e32 v0, v88, v66                               ; 0a008558
(invalid instruction)                                        ; cc1b0057
	v_subrev_f32_e32 v0, v87, v65                               ; 0a008357
	v_lshl_add_u32 v84, v84, 5, s67                             ; d6460054 010d0b54
(invalid instruction)                                        ; cc1c005a
	v_subrev_f32_e32 v0, v90, v66                               ; 0a00855a
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[56:57], v[76:77]                ; 1a029938
(invalid instruction)                                        ; cc1c005b
	v_subrev_f32_e32 v0, v91, v66                               ; 0a00855b
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v99, s64, v132, v8                          ; cc210063 04230840
	v_fma_mixhi_f16 v99, s64, v133, v9                          ; cc220063 04270a40
(invalid instruction)                                        ; cc1b0058
	v_subrev_f32_e32 v0, v88, v65                               ; 0a008358
	v_lshl_add_u32 v87, v87, 5, s67                             ; d6460057 010d0b57
	v_fma_mixlo_f16 v112, s64, v134, v10                        ; cc210070 042b0c40
	v_fma_mixhi_f16 v112, s64, v135, v11                        ; cc220070 042f0e40
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[57:58], v[84:85]                ; 1a02a939
(invalid instruction)                                        ; cc1b005a
	v_subrev_f32_e32 v0, v90, v65                               ; 0a00835a
(invalid instruction)                                        ; cc1b005b
	v_subrev_f32_e32 v0, v91, v65                               ; 0a00835b
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v66                               ; 0a008563
	v_lshl_add_u32 v88, v88, 5, s67                             ; d6460058 010d0b58
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[58:59], v[40:41], 0 ; cc464078 1a02513a
(invalid instruction)                                        ; cc0f0059
	v_min_num_f64_e32 v[1:2], v[62:63], v[87:88]                ; 1a02af3e
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v113, s64, v136, v156                       ; cc210071 06731040
	v_fma_mixhi_f16 v113, s64, v137, v157                       ; cc220071 06771240
(invalid instruction)                                        ; cc1c0070
	v_subrev_f32_e32 v0, v112, v66                              ; 0a008570
	v_lshl_add_u32 v90, v90, 5, s67                             ; d646005a 010d0b5a
	v_lshl_add_u32 v91, v91, 5, s67                             ; d646005b 010d0b5b
(invalid instruction)                                        ; cc1b0063
	v_subrev_f32_e32 v0, v99, v65                               ; 0a008363
(invalid instruction)                                        ; cc0f0062
	v_min_num_f64_e32 v[1:2], v[63:64], v[88:89]                ; 1a02b13f
	v_fma_mixlo_f16 v114, s64, v138, v158                       ; cc210072 067b1440
	v_fma_mixhi_f16 v114, s64, v139, v159                       ; cc220072 067f1640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v115, s64, v140, v64                        ; cc210073 05031840
	v_fma_mixhi_f16 v115, s64, v141, v65                        ; cc220073 05071a40
(invalid instruction)                                        ; cc1c0071
	v_subrev_f32_e32 v0, v113, v66                              ; 0a008571
(invalid instruction)                                        ; cc1b0070
	v_subrev_f32_e32 v0, v112, v65                              ; 0a008370
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[90:91]                ; 1a02b555
	v_fma_mixlo_f16 v116, s64, v142, v66                        ; cc210074 050b1c40
	v_fma_mixhi_f16 v116, s64, v143, v67                        ; cc220074 050f1e40
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[86:87], v[91:92]                ; 1a02b756
	v_lshl_add_u32 v99, v99, 5, s67                             ; d6460063 010d0b63
(invalid instruction)                                        ; cc1c0072
	v_subrev_f32_e32 v0, v114, v66                              ; 0a008572
(invalid instruction)                                        ; cc1c0073
	v_subrev_f32_e32 v0, v115, v66                              ; 0a008573
(invalid instruction)                                        ; cc1b0071
	v_subrev_f32_e32 v0, v113, v65                              ; 0a008371
	v_lshl_add_u32 v112, v112, 5, s67                           ; d6460070 010d0b70
(invalid instruction)                                        ; cc1c0074
	v_subrev_f32_e32 v0, v116, v66                              ; 0a008574
(invalid instruction)                                        ; cc0f0059
	v_min_num_f64_e32 v[1:2], v[89:90], v[99:100]               ; 1a02c759
(invalid instruction)                                        ; cc1b0072
	v_subrev_f32_e32 v0, v114, v65                              ; 0a008372
(invalid instruction)                                        ; cc1b0073
	v_subrev_f32_e32 v0, v115, v65                              ; 0a008373
	v_lshl_add_u32 v113, v113, 5, s67                           ; d6460071 010d0b71
(invalid instruction)                                        ; cc0f0062
	v_min_num_f64_e32 v[1:2], v[98:99], v[112:113]              ; 1a02e162
(invalid instruction)                                        ; cc1b0074
	v_subrev_f32_e32 v0, v116, v65                              ; 0a008374
	v_lshl_add_u32 v114, v114, 5, s67                           ; d6460072 010d0b72
	v_lshl_add_u32 v115, v115, 5, s67                           ; d6460073 010d0b73
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[113:114]              ; 1a02e355
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_lshl_add_u32 v116, v116, 5, s67                           ; d6460074 010d0b74
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[86:87], v[114:115]              ; 1a02e556
(invalid instruction)                                        ; cc0f0059
	v_min_num_f64_e32 v[1:2], v[89:90], v[115:116]              ; 1a02e759
(invalid instruction)                                        ; cc0f0062
	v_min_num_f64_e32 v[1:2], v[98:99], v[116:117]              ; 1a02e962
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[86:87]                ; 1a02ad55
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[89:90]                ; 1a02b355
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[98:99]                ; 1a02c555
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v117, v85, s61, s62 op_sel:[1,1]          ; d65c1875 00f87b55
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[117:118]              ; 1a02eb55
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v118, v85, v213/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64edab55
	v_max_num_f16_e32 v118, s60, v118                           ; 62ecec3c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v119, v118                                ; 7eee1776
	v_rcp_f32_e32 v119, v119                                    ; 7eee5577
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v131, v63, v119, neg(0) op_sel_hi:[1,0,0]     ; cc200083 8a02ef3f
	v_fma_mix_f32 v63, v63, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083f 8a02ef3f
	v_fma_mix_f32 v132, v76, v119, neg(0) op_sel_hi:[1,0,0]     ; cc200084 8a02ef4c
	v_fma_mix_f32 v76, v76, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084c 8a02ef4c
	v_fma_mix_f32 v133, v84, v119, neg(0) op_sel_hi:[1,0,0]     ; cc200085 8a02ef54
	v_fma_mix_f32 v130, v62, v119, neg(0) op_sel_hi:[1,0,0]     ; cc200082 8a02ef3e
	v_fma_mix_f32 v128, v56, v119, neg(0) op_sel_hi:[1,0,0]     ; cc200080 8a02ef38
	v_fma_mix_f32 v62, v62, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083e 8a02ef3e
	v_fma_mix_f32 v129, v57, v119, neg(0) op_sel_hi:[1,0,0]     ; cc200081 8a02ef39
	v_fma_mix_f32 v57, v57, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200839 8a02ef39
	v_fma_mix_f32 v56, v56, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200838 8a02ef38
	v_fma_mix_f32 v84, v84, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200854 8a02ef54
	v_fma_mix_f32 v134, v87, v119, neg(0) op_sel_hi:[1,0,0]     ; cc200086 8a02ef57
	v_fma_mix_f32 v87, v87, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200857 8a02ef57
	v_fma_mix_f32 v135, v88, v119, neg(0) op_sel_hi:[1,0,0]     ; cc200087 8a02ef58
	v_fma_mix_f32 v88, v88, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200858 8a02ef58
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v132, v76, vcc_lo                     ; 02029984
	v_fma_mix_f32 v136, v90, v119, neg(0) op_sel_hi:[1,0,0]     ; cc200088 8a02ef5a
	v_fma_mix_f32 v90, v90, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085a 8a02ef5a
	v_fma_mix_f32 v137, v91, v119, neg(0) op_sel_hi:[1,0,0]     ; cc200089 8a02ef5b
	v_fma_mix_f32 v91, v91, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085b 8a02ef5b
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v130, v62, vcc_lo                     ; 02027d82
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v131, v63, vcc_lo                     ; 02027f83
	v_fma_mix_f32 v138, v99, v119, neg(0) op_sel_hi:[1,0,0]     ; cc20008a 8a02ef63
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v128, v56, vcc_lo                     ; 02027180
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v129, v57, vcc_lo                     ; 02027381
	v_fma_mix_f32 v99, v99, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200863 8a02ef63
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v133, v84, vcc_lo                     ; 0202a985
	v_fma_mix_f32 v139, v112, v119, neg(0) op_sel_hi:[1,0,0]    ; cc20008b 8a02ef70
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v134, v87, vcc_lo                     ; 0202af86
	v_fma_mix_f32 v112, v112, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200870 8a02ef70
	v_fma_mix_f32 v140, v113, v119, neg(0) op_sel_hi:[1,0,0]    ; cc20008c 8a02ef71
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v135, v88, vcc_lo                     ; 0202b187
	v_fma_mix_f32 v113, v113, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200871 8a02ef71
	v_fma_mix_f32 v141, v114, v119, neg(0) op_sel_hi:[1,0,0]    ; cc20008d 8a02ef72
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v136, v90, vcc_lo                     ; 0202b588
	v_fma_mix_f32 v114, v114, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200872 8a02ef72
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v137, v91, vcc_lo                     ; 0202b789
	v_fma_mix_f32 v142, v115, v119, neg(0) op_sel_hi:[1,0,0]    ; cc20008e 8a02ef73
	v_fma_mix_f32 v115, v115, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200873 8a02ef73
	v_fma_mix_f32 v143, v116, v119, neg(0) op_sel_hi:[1,0,0]    ; cc20008f 8a02ef74
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[64:67], v28, s[32:35], null offen offset:8192 ; c405c07c 40804040 0020001c
	buffer_load_b128 v[84:87], v28, s[32:35], null offen offset:8208 ; c405c07c 40804054 0020101c
	v_fma_mix_f32 v116, v116, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200874 8a02ef74
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v138, v99, vcc_lo                     ; 0202c78a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[40:41], 0 ; cc464080 1a025132
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v139, v112, vcc_lo                    ; 0202e18b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[60:61], v[42:43], v[120:127] ; cc464078 1de2553c
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v140, v113, vcc_lo                    ; 0202e38c
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v141, v114, vcc_lo                    ; 0202e58d
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v142, v115, vcc_lo                    ; 0202e78e
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v143, v116, vcc_lo                    ; 0202e98f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[96:97], v[40:41], 0 ; cc464070 1a025160
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[40:41], 0 ; cc464088 1a025146
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[42:43], v[128:135] ; cc464080 1e025544
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v145, s64, v122, v18                        ; cc210091 044af440
	v_fma_mixhi_f16 v145, s64, v123, v19                        ; cc220091 044ef640
	v_fma_mixlo_f16 v144, s64, v120, v16                        ; cc210090 0442f040
	v_fma_mixhi_f16 v144, s64, v121, v17                        ; cc220090 0446f240
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[42:43], v[112:119] ; cc464070 1dc25530
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[12:13], v[42:43], v[136:143] ; cc464088 1e22550c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v28, s[32:35], null offen offset:8256 ; c405c07c 40804010 0020401c
	buffer_load_b128 v[40:43], v28, s[32:35], null offen offset:8272 ; c405c07c 40804028 0020501c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v146, s64, v124, v52                        ; cc210092 04d2f840
	v_fma_mixhi_f16 v146, s64, v125, v53                        ; cc220092 04d6fa40
	v_fma_mixlo_f16 v147, s64, v126, v54                        ; cc210093 04dafc40
	v_fma_mixhi_f16 v147, s64, v127, v55                        ; cc220093 04defe40
(invalid instruction)                                        ; cc1c0091
	v_subrev_f32_e32 v0, v145, v66                              ; 0a008591
(invalid instruction)                                        ; cc1c0090
	v_subrev_f32_e32 v0, v144, v66                              ; 0a008590
(invalid instruction)                                        ; cc1c0092
	v_subrev_f32_e32 v0, v146, v66                              ; 0a008592
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c0093
	v_subrev_f32_e32 v0, v147, v66                              ; 0a008593
(invalid instruction)                                        ; cc1b0091
	v_subrev_f32_e32 v0, v145, v65                              ; 0a008391
(invalid instruction)                                        ; cc1b0090
	v_subrev_f32_e32 v0, v144, v65                              ; 0a008390
(invalid instruction)                                        ; cc1b0092
	v_subrev_f32_e32 v0, v146, v65                              ; 0a008392
(invalid instruction)                                        ; cc1b0093
	v_subrev_f32_e32 v0, v147, v65                              ; 0a008393
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v148, s64, v112, v72                        ; cc210094 0522e040
	v_fma_mixhi_f16 v148, s64, v113, v73                        ; cc220094 0526e240
	v_fma_mixlo_f16 v149, s64, v114, v74                        ; cc210095 052ae440
	v_fma_mixhi_f16 v149, s64, v115, v75                        ; cc220095 052ee640
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[52:55], v28, s[32:35], null offen offset:8320 ; c405c07c 40804034 0020801c
	buffer_load_b128 v[72:75], v28, s[32:35], null offen offset:8336 ; c405c07c 40804048 0020901c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v151, s64, v118, v82                        ; cc210097 054aec40
	v_fma_mixhi_f16 v151, s64, v119, v83                        ; cc220097 054eee40
	v_fma_mixlo_f16 v150, s64, v116, v80                        ; cc210096 0542e840
	v_fma_mixhi_f16 v150, s64, v117, v81                        ; cc220096 0546ea40
(invalid instruction)                                        ; cc1c0094
	v_subrev_f32_e32 v0, v148, v66                              ; 0a008594
(invalid instruction)                                        ; cc1c0095
	v_subrev_f32_e32 v0, v149, v66                              ; 0a008595
(invalid instruction)                                        ; cc1c0097
	v_subrev_f32_e32 v0, v151, v66                              ; 0a008597
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c0096
	v_subrev_f32_e32 v0, v150, v66                              ; 0a008596
(invalid instruction)                                        ; cc1b0094
	v_subrev_f32_e32 v0, v148, v65                              ; 0a008394
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v153, s64, v130, v102                       ; cc210099 059b0440
	v_fma_mixhi_f16 v153, s64, v131, v103                       ; cc220099 059f0640
	v_fma_mixlo_f16 v152, s64, v128, v100                       ; cc210098 05930040
	v_fma_mixhi_f16 v152, s64, v129, v101                       ; cc220098 05970240
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[80:83], v28, s[32:35], null offen offset:8384 ; c405c07c 40804050 0020c01c
	buffer_load_b128 v[88:91], v28, s[32:35], null offen offset:8400 ; c405c07c 40804058 0020d01c
(invalid instruction)                                        ; cc1b0095
	v_subrev_f32_e32 v0, v149, v65                              ; 0a008395
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v155, s64, v134, v106                       ; cc21009b 05ab0c40
	v_fma_mixlo_f16 v154, s64, v132, v104                       ; cc21009a 05a30840
	v_fma_mixhi_f16 v154, s64, v133, v105                       ; cc22009a 05a70a40
	v_fma_mixhi_f16 v155, s64, v135, v107                       ; cc22009b 05af0e40
(invalid instruction)                                        ; cc1b0097
	v_subrev_f32_e32 v0, v151, v65                              ; 0a008397
(invalid instruction)                                        ; cc1b0096
	v_subrev_f32_e32 v0, v150, v65                              ; 0a008396
(invalid instruction)                                        ; cc1c0099
	v_subrev_f32_e32 v0, v153, v66                              ; 0a008599
(invalid instruction)                                        ; cc1c0098
	v_subrev_f32_e32 v0, v152, v66                              ; 0a008598
(invalid instruction)                                        ; cc1c009a
	v_subrev_f32_e32 v0, v154, v66                              ; 0a00859a
(invalid instruction)                                        ; cc1c009b
	v_subrev_f32_e32 v0, v155, v66                              ; 0a00859b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b0099
	v_subrev_f32_e32 v0, v153, v65                              ; 0a008399
(invalid instruction)                                        ; cc1b0098
	v_subrev_f32_e32 v0, v152, v65                              ; 0a008398
(invalid instruction)                                        ; cc1b009a
	v_subrev_f32_e32 v0, v154, v65                              ; 0a00839a
(invalid instruction)                                        ; cc1b009b
	v_subrev_f32_e32 v0, v155, v65                              ; 0a00839b
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v157, s64, v138, v94                        ; cc21009d 057b1440
	v_fma_mixhi_f16 v157, s64, v139, v95                        ; cc22009d 057f1640
	v_fma_mixlo_f16 v156, s64, v136, v92                        ; cc21009c 05731040
	v_fma_mixhi_f16 v156, s64, v137, v93                        ; cc22009c 05771240
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v159, s64, v142, v110                       ; cc21009f 05bb1c40
	v_fma_mixhi_f16 v159, s64, v143, v111                       ; cc22009f 05bf1e40
	v_fma_mixlo_f16 v158, s64, v140, v108                       ; cc21009e 05b31840
	v_fma_mixhi_f16 v158, s64, v141, v109                       ; cc22009e 05b71a40
	v_lshl_add_u32 v144, v144, 5, s67                           ; d6460090 010d0b90
	v_lshl_add_u32 v148, v148, 5, s67                           ; d6460094 010d0b94
	v_lshl_add_u32 v152, v152, 5, s67                           ; d6460098 010d0b98
(invalid instruction)                                        ; cc1c009d
	v_subrev_f32_e32 v0, v157, v66                              ; 0a00859d
	v_lshl_add_u32 v145, v145, 5, s67                           ; d6460091 010d0b91
(invalid instruction)                                        ; cc1c009c
	v_subrev_f32_e32 v0, v156, v66                              ; 0a00859c
	v_lshl_add_u32 v149, v149, 5, s67                           ; d6460095 010d0b95
	v_lshl_add_u32 v153, v153, 5, s67                           ; d6460099 010d0b99
(invalid instruction)                                        ; cc1c009f
	v_subrev_f32_e32 v0, v159, v66                              ; 0a00859f
(invalid instruction)                                        ; cc1c009e
	v_subrev_f32_e32 v0, v158, v66                              ; 0a00859e
	v_lshl_add_u32 v146, v146, 5, s67                           ; d6460092 010d0b92
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[144:145], v[148:149]            ; 1a032990
	v_lshl_add_u32 v150, v150, 5, s67                           ; d6460096 010d0b96
(invalid instruction)                                        ; cc1b009d
	v_subrev_f32_e32 v0, v157, v65                              ; 0a00839d
	v_lshl_add_u32 v154, v154, 5, s67                           ; d646009a 010d0b9a
(invalid instruction)                                        ; cc1b009c
	v_subrev_f32_e32 v0, v156, v65                              ; 0a00839c
(invalid instruction)                                        ; cc0f00a1
	v_min_num_f64_e32 v[1:2], v[145:146], v[149:150]            ; 1a032b91
(invalid instruction)                                        ; cc1b009f
	v_subrev_f32_e32 v0, v159, v65                              ; 0a00839f
	v_lshl_add_u32 v147, v147, 5, s67                           ; d6460093 010d0b93
	v_lshl_add_u32 v151, v151, 5, s67                           ; d6460097 010d0b97
(invalid instruction)                                        ; cc1b009e
	v_subrev_f32_e32 v0, v158, v65                              ; 0a00839e
	v_lshl_add_u32 v155, v155, 5, s67                           ; d646009b 010d0b9b
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[152:153]            ; 1a0331a0
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[146:147], v[150:151]            ; 1a032d92
	v_lshl_add_u32 v157, v157, 5, s67                           ; d646009d 010d0b9d
	v_lshl_add_u32 v156, v156, 5, s67                           ; d646009c 010d0b9c
(invalid instruction)                                        ; cc0f00a1
	v_min_num_f64_e32 v[1:2], v[161:162], v[153:154]            ; 1a0333a1
	v_lshl_add_u32 v159, v159, 5, s67                           ; d646009f 010d0b9f
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[147:148], v[151:152]            ; 1a032f93
	v_lshl_add_u32 v158, v158, 5, s67                           ; d646009e 010d0b9e
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[162:163], v[154:155]            ; 1a0335a2
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[156:157]            ; 1a0339a0
(invalid instruction)                                        ; cc0f00a1
	v_min_num_f64_e32 v[1:2], v[161:162], v[157:158]            ; 1a033ba1
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[155:156]            ; 1a0337a3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[162:163], v[158:159]            ; 1a033da2
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[161:162]            ; 1a0343a0
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[159:160]            ; 1a033fa3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[162:163]            ; 1a0345a0
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[163:164]            ; 1a0347a0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v164, v160, s61, s62 op_sel:[1,1]         ; d65c18a4 00f87ba0
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[164:165]            ; 1a0349a0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53210a5
	v_cndmask_b32_e32 v1, v160, v160, vcc_lo                    ; 020341a0
(invalid instruction)                                        ; d53100a5
	v_cndmask_b32_e32 v1, s60, v165, vcc_lo                     ; 02034a3c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00a6
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
	v_rcp_f32_e32 v166, v166                                    ; 7f4c55a6
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v168, v145, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000a8 8a034d91
	v_fma_mix_f32 v171, v148, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000ab 8a034d94
	v_fma_mix_f32 v145, v145, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a034d91
	v_fma_mix_f32 v148, v148, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200894 8a034d94
	v_fma_mix_f32 v172, v149, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000ac 8a034d95
	v_fma_mix_f32 v170, v147, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000aa 8a034d93
	v_fma_mix_f32 v147, v147, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200893 8a034d93
	v_fma_mix_f32 v167, v144, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000a7 8a034d90
	v_fma_mix_f32 v144, v144, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200890 8a034d90
	v_fma_mix_f32 v169, v146, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000a9 8a034d92
	v_fma_mix_f32 v146, v146, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200892 8a034d92
	v_fma_mix_f32 v149, v149, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a034d95
	v_fma_mix_f32 v173, v150, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000ad 8a034d96
	v_fma_mix_f32 v150, v150, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200896 8a034d96
	v_fma_mix_f32 v174, v151, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000ae 8a034d97
	v_fma_mix_f32 v151, v151, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a034d97
	v_fma_mix_f32 v175, v152, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000af 8a034d98
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v171, v148, vcc_lo                    ; 020329ab
	v_fma_mix_f32 v152, v152, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200898 8a034d98
	v_fma_mix_f32 v176, v153, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000b0 8a034d99
	v_fma_mix_f32 v153, v153, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a034d99
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v167, v144, vcc_lo                    ; 020321a7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v168, v145, vcc_lo                    ; 020323a8
	v_fma_mix_f32 v177, v154, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000b1 8a034d9a
	v_fma_mix_f32 v154, v154, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089a 8a034d9a
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v169, v146, vcc_lo                    ; 020325a9
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v170, v147, vcc_lo                    ; 020327aa
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v172, v149, vcc_lo                    ; 02032bac
	v_fma_mix_f32 v178, v155, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000b2 8a034d9b
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v173, v150, vcc_lo                    ; 02032dad
	v_fma_mix_f32 v155, v155, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089b 8a034d9b
	v_fma_mix_f32 v179, v156, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000b3 8a034d9c
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v174, v151, vcc_lo                    ; 02032fae
	v_fma_mix_f32 v156, v156, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089c 8a034d9c
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v175, v152, vcc_lo                    ; 020331af
	v_fma_mix_f32 v180, v157, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000b4 8a034d9d
	v_fma_mix_f32 v157, v157, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a034d9d
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v176, v153, vcc_lo                    ; 020333b0
	v_fma_mix_f32 v181, v158, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000b5 8a034d9e
	v_fma_mix_f32 v158, v158, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089e 8a034d9e
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v177, v154, vcc_lo                    ; 020335b1
	v_fma_mix_f32 v182, v159, v166, neg(0) op_sel_hi:[1,0,0]    ; cc2000b6 8a034d9f
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[92:95], v28, s[32:35], null offen offset:12288 ; c405c07c 4080405c 0030001c
	buffer_load_b128 v[100:103], v28, s[32:35], null offen offset:12304 ; c405c07c 40804064 0030101c
	v_fma_mix_f32 v159, v159, v166, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089f 8a034d9f
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[58:59], v[44:45], 0 ; cc464068 1a02593a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[96:97], v[44:45], 0 ; cc464070 1a025960
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[44:45], 0 ; cc464078 1a025932
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v178, v155, vcc_lo                    ; 020337b2
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[44:45], 0 ; cc464080 1a025946
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v179, v156, vcc_lo                    ; 020339b3
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v180, v157, vcc_lo                    ; 02033bb4
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v181, v158, vcc_lo                    ; 02033db5
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v182, v159, vcc_lo                    ; 02033fb6
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[20:21], v[104:111] ; cc464068 1da2293c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[20:21], v[112:119] ; cc464070 1dc22930
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[20:21], v[120:127] ; cc464078 1de22944
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[12:13], v[20:21], v[128:135] ; cc464080 1e02290c
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v185, s64, v108, v84                        ; cc2100b9 0552d840
	v_fma_mixlo_f16 v183, s64, v104, v64                        ; cc2100b7 0502d040
	v_fma_mixlo_f16 v186, s64, v110, v86                        ; cc2100ba 055adc40
	v_fma_mixhi_f16 v186, s64, v111, v87                        ; cc2200ba 055ede40
	v_fma_mixhi_f16 v183, s64, v105, v65                        ; cc2200b7 0506d240
	v_fma_mixhi_f16 v185, s64, v109, v85                        ; cc2200b9 0556da40
	v_fma_mixlo_f16 v184, s64, v106, v66                        ; cc2100b8 050ad440
	v_fma_mixhi_f16 v184, s64, v107, v67                        ; cc2200b8 050ed640
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[64:67], v28, s[32:35], null offen offset:12352 ; c405c07c 40804040 0030401c
	buffer_load_b128 v[84:87], v28, s[32:35], null offen offset:12368 ; c405c07c 40804054 0030501c
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v66                              ; 0a0085ba
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v66                              ; 0a0085b7
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v66                              ; 0a0085b9
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v66                              ; 0a0085b8
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b00ba
	v_subrev_f32_e32 v0, v186, v65                              ; 0a0083ba
(invalid instruction)                                        ; cc1b00b7
	v_subrev_f32_e32 v0, v183, v65                              ; 0a0083b7
(invalid instruction)                                        ; cc1b00b9
	v_subrev_f32_e32 v0, v185, v65                              ; 0a0083b9
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v187, s64, v112, v16                        ; cc2100bb 0442e040
	v_fma_mixhi_f16 v187, s64, v113, v17                        ; cc2200bb 0446e240
	v_fma_mixlo_f16 v188, s64, v114, v18                        ; cc2100bc 044ae440
	v_fma_mixhi_f16 v188, s64, v115, v19                        ; cc2200bc 044ee640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v189, s64, v116, v40                        ; cc2100bd 04a2e840
	v_fma_mixlo_f16 v190, s64, v118, v42                        ; cc2100be 04aaec40
	v_fma_mixhi_f16 v190, s64, v119, v43                        ; cc2200be 04aeee40
	v_fma_mixhi_f16 v189, s64, v117, v41                        ; cc2200bd 04a6ea40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v28, s[32:35], null offen offset:12416 ; c405c07c 40804010 0030801c
	buffer_load_b128 v[40:43], v28, s[32:35], null offen offset:12432 ; c405c07c 40804028 0030901c
(invalid instruction)                                        ; cc1b00b8
	v_subrev_f32_e32 v0, v184, v65                              ; 0a0083b8
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v66                              ; 0a0085bb
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v66                              ; 0a0085bc
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v66                              ; 0a0085be
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v66                              ; 0a0085bd
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b00bb
	v_subrev_f32_e32 v0, v187, v65                              ; 0a0083bb
(invalid instruction)                                        ; cc1b00bc
	v_subrev_f32_e32 v0, v188, v65                              ; 0a0083bc
(invalid instruction)                                        ; cc1b00be
	v_subrev_f32_e32 v0, v190, v65                              ; 0a0083be
(invalid instruction)                                        ; cc1b00bd
	v_subrev_f32_e32 v0, v189, v65                              ; 0a0083bd
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v191, s64, v120, v52                        ; cc2100bf 04d2f040
	v_fma_mixhi_f16 v191, s64, v121, v53                        ; cc2200bf 04d6f240
	v_fma_mixlo_f16 v20, s64, v122, v54                         ; cc210014 04daf440
	v_fma_mixhi_f16 v20, s64, v123, v55                         ; cc220014 04def640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v21, s64, v124, v72                         ; cc210015 0522f840
	v_fma_mixlo_f16 v44, s64, v126, v74                         ; cc21002c 052afc40
	v_fma_mixhi_f16 v44, s64, v127, v75                         ; cc22002c 052efe40
	v_fma_mixhi_f16 v21, s64, v125, v73                         ; cc220015 0526fa40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[52:55], v28, s[32:35], null offen offset:12480 ; c405c07c 40804034 0030c01c
	buffer_load_b128 v[72:75], v28, s[32:35], null offen offset:12496 ; c405c07c 40804048 0030d01c
	v_add3_u32 v26, v7, s22, v26                                ; d655001a 04682d07
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v66                              ; 0a0085bf
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v66                               ; 0a008514
(invalid instruction)                                        ; cc1c002c
	v_subrev_f32_e32 v0, v44, v66                               ; 0a00852c
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v66                               ; 0a008515
	v_lshlrev_b32_e32 v26, 2, v26                               ; 30343482
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v45, s64, v128, v80                         ; cc21002d 05430040
	v_fma_mixhi_f16 v45, s64, v129, v81                         ; cc22002d 05470240
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v65                              ; 0a0083bf
	v_fma_mixlo_f16 v56, s64, v130, v82                         ; cc210038 054b0440
	v_fma_mixhi_f16 v56, s64, v131, v83                         ; cc220038 054f0640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v57, s64, v132, v88                         ; cc210039 05630840
	v_fma_mixlo_f16 v62, s64, v134, v90                         ; cc21003e 056b0c40
(invalid instruction)                                        ; cc1b0014
	v_subrev_f32_e32 v0, v20, v65                               ; 0a008314
	v_fma_mixhi_f16 v57, s64, v133, v89                         ; cc220039 05670a40
(invalid instruction)                                        ; cc1b002c
	v_subrev_f32_e32 v0, v44, v65                               ; 0a00832c
	v_fma_mixhi_f16 v62, s64, v135, v91                         ; cc22003e 056f0e40
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v65                               ; 0a008315
	v_lshl_add_u32 v183, v183, 5, s67                           ; d64600b7 010d0bb7
	v_lshl_add_u32 v187, v187, 5, s67                           ; d64600bb 010d0bbb
(invalid instruction)                                        ; cc1c002d
	v_subrev_f32_e32 v0, v45, v66                               ; 0a00852d
	v_lshl_add_u32 v191, v191, 5, s67                           ; d64600bf 010d0bbf
(invalid instruction)                                        ; cc1c0038
	v_subrev_f32_e32 v0, v56, v66                               ; 0a008538
	v_lshl_add_u32 v184, v184, 5, s67                           ; d64600b8 010d0bb8
	v_lshl_add_u32 v188, v188, 5, s67                           ; d64600bc 010d0bbc
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v66                               ; 0a008539
	v_lshl_add_u32 v20, v20, 5, s67                             ; d6460014 010d0b14
(invalid instruction)                                        ; cc1c003e
	v_subrev_f32_e32 v0, v62, v66                               ; 0a00853e
	v_lshl_add_u32 v185, v185, 5, s67                           ; d64600b9 010d0bb9
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[183:184], v[187:188]            ; 1a0377b7
	v_lshl_add_u32 v189, v189, 5, s67                           ; d64600bd 010d0bbd
(invalid instruction)                                        ; cc1b002d
	v_subrev_f32_e32 v0, v45, v65                               ; 0a00832d
(invalid instruction)                                        ; cc1b0038
	v_subrev_f32_e32 v0, v56, v65                               ; 0a008338
	v_lshl_add_u32 v21, v21, 5, s67                             ; d6460015 010d0b15
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[184:185], v[188:189]            ; 1a0379b8
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v65                               ; 0a008339
	v_lshl_add_u32 v186, v186, 5, s67                           ; d64600ba 010d0bba
	v_lshl_add_u32 v190, v190, 5, s67                           ; d64600be 010d0bbe
(invalid instruction)                                        ; cc1b003e
	v_subrev_f32_e32 v0, v62, v65                               ; 0a00833e
	v_lshl_add_u32 v44, v44, 5, s67                             ; d646002c 010d0b2c
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[191:192]              ; 1a037f3f
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[185:186], v[189:190]            ; 1a037bb9
	v_lshl_add_u32 v45, v45, 5, s67                             ; d646002d 010d0b2d
	v_lshl_add_u32 v56, v56, 5, s67                             ; d6460038 010d0b38
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[20:21]                ; 1a02294c
	v_lshl_add_u32 v57, v57, 5, s67                             ; d6460039 010d0b39
(invalid instruction)                                        ; cc0f0051
	v_min_num_f64_e32 v[1:2], v[186:187], v[190:191]            ; 1a037dba
	v_lshl_add_u32 v62, v62, 5, s67                             ; d646003e 010d0b3e
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[21:22]                ; 1a022b50
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[45:46]                ; 1a025b3f
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[56:57]                ; 1a02714c
(invalid instruction)                                        ; cc0f0051
	v_min_num_f64_e32 v[1:2], v[81:82], v[44:45]                ; 1a025951
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[57:58]                ; 1a027350
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[76:77]                ; 1a02993f
(invalid instruction)                                        ; cc0f0051
	v_min_num_f64_e32 v[1:2], v[81:82], v[62:63]                ; 1a027d51
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[80:81]                ; 1a02a13f
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[81:82]                ; 1a02a33f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v82, v63, s61, s62 op_sel:[1,1]           ; d65c1852 00f87b3f
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[82:83]                ; 1a02a53f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v83, v63, v191/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64a77f3f
	v_max_num_f16_e32 v83, s60, v83                             ; 62a6a63c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v88, v83                                  ; 7eb01753
	v_rcp_f32_e32 v88, v88                                      ; 7eb05558
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v99, v187, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200063 8a02b1bb
	v_fma_mix_f32 v187, v187, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a02b1bb
	v_fma_mix_f32 v104, v188, v88, neg(0) op_sel_hi:[1,0,0]     ; cc200068 8a02b1bc
	v_fma_mix_f32 v90, v184, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005a 8a02b1b8
	v_fma_mix_f32 v184, v184, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a02b1b8
	v_fma_mix_f32 v89, v183, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200059 8a02b1b7
	v_fma_mix_f32 v183, v183, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a02b1b7
	v_fma_mix_f32 v98, v186, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200062 8a02b1ba
	v_fma_mix_f32 v186, v186, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a02b1ba
	v_fma_mix_f32 v91, v185, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005b 8a02b1b9
	v_fma_mix_f32 v185, v185, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a02b1b9
	v_fma_mix_f32 v188, v188, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a02b1bc
	v_fma_mix_f32 v105, v189, v88, neg(0) op_sel_hi:[1,0,0]     ; cc200069 8a02b1bd
	v_fma_mix_f32 v189, v189, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a02b1bd
	v_fma_mix_f32 v106, v190, v88, neg(0) op_sel_hi:[1,0,0]     ; cc20006a 8a02b1be
	v_fma_mix_f32 v190, v190, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a02b1be
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v99, v187, vcc_lo                     ; 02037763
	v_fma_mix_f32 v107, v191, v88, neg(0) op_sel_hi:[1,0,0]     ; cc20006b 8a02b1bf
	v_fma_mix_f32 v191, v191, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a02b1bf
	v_fma_mix_f32 v108, v20, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20006c 8a02b114
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v89, v183, vcc_lo                     ; 02036f59
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v90, v184, vcc_lo                     ; 0203715a
	v_fma_mix_f32 v20, v20, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a02b114
	v_fma_mix_f32 v109, v21, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20006d 8a02b115
	v_fma_mix_f32 v21, v21, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200815 8a02b115
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v91, v185, vcc_lo                     ; 0203735b
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v98, v186, vcc_lo                     ; 02037562
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v104, v188, vcc_lo                    ; 02037968
	v_fma_mix_f32 v110, v44, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20006e 8a02b12c
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v105, v189, vcc_lo                    ; 02037b69
	v_fma_mix_f32 v44, v44, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082c 8a02b12c
	v_fma_mix_f32 v111, v45, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20006f 8a02b12d
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v106, v190, vcc_lo                    ; 02037d6a
	v_fma_mix_f32 v45, v45, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082d 8a02b12d
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v107, v191, vcc_lo                    ; 02037f6b
	v_fma_mix_f32 v112, v56, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200070 8a02b138
	v_fma_mix_f32 v56, v56, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200838 8a02b138
	v_fma_mix_f32 v113, v57, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200071 8a02b139
	v_fma_mix_f32 v57, v57, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200839 8a02b139
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v108, v20, vcc_lo                     ; 0202296c
	v_fma_mix_f32 v114, v62, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200072 8a02b13e
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v109, v21, vcc_lo                     ; 02022b6d
	v_fma_mix_f32 v62, v62, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083e 8a02b13e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[32:33], 0 ; cc464078 1a024132
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v110, v44, vcc_lo                     ; 0202596e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[32:33], 0 ; cc464080 1a024146
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v111, v45, vcc_lo                     ; 02025b6f
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[58:59], v[32:33], 0 ; cc464068 1a02413a
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v112, v56, vcc_lo                     ; 02027170
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v113, v57, vcc_lo                     ; 02027371
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v114, v62, vcc_lo                     ; 02027d72
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[96:97], v[32:33], 0 ; cc464070 1a024160
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[46:47], v[120:127] ; cc464078 1de25d44
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[12:13], v[46:47], v[128:135] ; cc464080 1e025d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[46:47], v[104:111] ; cc464068 1da25d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[46:47], v[112:119] ; cc464070 1dc25d30
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v137, s64, v106, v94                        ; cc210089 057ad440
	v_fma_mixlo_f16 v136, s64, v104, v92                        ; cc210088 0572d040
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v138, s64, v108, v100                       ; cc21008a 0592d840
	v_fma_mixhi_f16 v136, s64, v105, v93                        ; cc220088 0576d240
	v_fma_mixhi_f16 v138, s64, v109, v101                       ; cc22008a 0596da40
	v_fma_mixlo_f16 v139, s64, v110, v102                       ; cc21008b 059adc40
	v_fma_mixhi_f16 v139, s64, v111, v103                       ; cc22008b 059ede40
	v_fma_mixhi_f16 v137, s64, v107, v95                        ; cc220089 057ed640
(invalid instruction)                                        ; cc1c0088
	v_subrev_f32_e32 v0, v136, v66                              ; 0a008588
(invalid instruction)                                        ; cc1c008a
	v_subrev_f32_e32 v0, v138, v66                              ; 0a00858a
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c008b
	v_subrev_f32_e32 v0, v139, v66                              ; 0a00858b
(invalid instruction)                                        ; cc1c0089
	v_subrev_f32_e32 v0, v137, v66                              ; 0a008589
(invalid instruction)                                        ; cc1b0088
	v_subrev_f32_e32 v0, v136, v65                              ; 0a008388
(invalid instruction)                                        ; cc1b008a
	v_subrev_f32_e32 v0, v138, v65                              ; 0a00838a
(invalid instruction)                                        ; cc1b008b
	v_subrev_f32_e32 v0, v139, v65                              ; 0a00838b
(invalid instruction)                                        ; cc1b0089
	v_subrev_f32_e32 v0, v137, v65                              ; 0a008389
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v140, s64, v112, v64                        ; cc21008c 0502e040
	v_fma_mixhi_f16 v140, s64, v113, v65                        ; cc22008c 0506e240
	v_fma_mixlo_f16 v141, s64, v114, v66                        ; cc21008d 050ae440
	v_fma_mixhi_f16 v141, s64, v115, v67                        ; cc22008d 050ee640
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v143, s64, v118, v86                        ; cc21008f 055aec40
	v_fma_mixhi_f16 v143, s64, v119, v87                        ; cc22008f 055eee40
	v_fma_mixlo_f16 v142, s64, v116, v84                        ; cc21008e 0552e840
	v_fma_mixhi_f16 v142, s64, v117, v85                        ; cc22008e 0556ea40
(invalid instruction)                                        ; cc1c008c
	v_subrev_f32_e32 v0, v140, v66                              ; 0a00858c
(invalid instruction)                                        ; cc1c008d
	v_subrev_f32_e32 v0, v141, v66                              ; 0a00858d
(invalid instruction)                                        ; cc1c008f
	v_subrev_f32_e32 v0, v143, v66                              ; 0a00858f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c008e
	v_subrev_f32_e32 v0, v142, v66                              ; 0a00858e
(invalid instruction)                                        ; cc1b008c
	v_subrev_f32_e32 v0, v140, v65                              ; 0a00838c
(invalid instruction)                                        ; cc1b008d
	v_subrev_f32_e32 v0, v141, v65                              ; 0a00838d
(invalid instruction)                                        ; cc1b008f
	v_subrev_f32_e32 v0, v143, v65                              ; 0a00838f
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v144, s64, v120, v16                        ; cc210090 0442f040
	v_fma_mixhi_f16 v144, s64, v121, v17                        ; cc220090 0446f240
	v_fma_mixlo_f16 v145, s64, v122, v18                        ; cc210091 044af440
	v_fma_mixhi_f16 v145, s64, v123, v19                        ; cc220091 044ef640
(invalid instruction)                                        ; cc1b008e
	v_subrev_f32_e32 v0, v142, v65                              ; 0a00838e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v146, s64, v124, v40                        ; cc210092 04a2f840
	v_fma_mixlo_f16 v147, s64, v126, v42                        ; cc210093 04aafc40
	v_fma_mixhi_f16 v146, s64, v125, v41                        ; cc220092 04a6fa40
	v_fma_mixhi_f16 v147, s64, v127, v43                        ; cc220093 04aefe40
(invalid instruction)                                        ; cc1c0090
	v_subrev_f32_e32 v0, v144, v66                              ; 0a008590
(invalid instruction)                                        ; cc1c0091
	v_subrev_f32_e32 v0, v145, v66                              ; 0a008591
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c0092
	v_subrev_f32_e32 v0, v146, v66                              ; 0a008592
(invalid instruction)                                        ; cc1c0093
	v_subrev_f32_e32 v0, v147, v66                              ; 0a008593
(invalid instruction)                                        ; cc1b0090
	v_subrev_f32_e32 v0, v144, v65                              ; 0a008390
(invalid instruction)                                        ; cc1b0091
	v_subrev_f32_e32 v0, v145, v65                              ; 0a008391
(invalid instruction)                                        ; cc1b0092
	v_subrev_f32_e32 v0, v146, v65                              ; 0a008392
(invalid instruction)                                        ; cc1b0093
	v_subrev_f32_e32 v0, v147, v65                              ; 0a008393
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v148, s64, v128, v52                        ; cc210094 04d30040
	v_fma_mixhi_f16 v148, s64, v129, v53                        ; cc220094 04d70240
	v_fma_mixlo_f16 v149, s64, v130, v54                        ; cc210095 04db0440
	v_fma_mixhi_f16 v149, s64, v131, v55                        ; cc220095 04df0640
	v_lshl_add_u32 v136, v136, 5, s67                           ; d6460088 010d0b88
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v150, s64, v132, v72                        ; cc210096 05230840
	v_fma_mixlo_f16 v151, s64, v134, v74                        ; cc210097 052b0c40
	v_fma_mixhi_f16 v151, s64, v135, v75                        ; cc220097 052f0e40
	v_fma_mixhi_f16 v150, s64, v133, v73                        ; cc220096 05270a40
	v_lshl_add_u32 v140, v140, 5, s67                           ; d646008c 010d0b8c
	v_lshl_add_u32 v144, v144, 5, s67                           ; d6460090 010d0b90
(invalid instruction)                                        ; cc1c0094
	v_subrev_f32_e32 v0, v148, v66                              ; 0a008594
	v_lshl_add_u32 v137, v137, 5, s67                           ; d6460089 010d0b89
(invalid instruction)                                        ; cc1c0095
	v_subrev_f32_e32 v0, v149, v66                              ; 0a008595
	v_lshl_add_u32 v141, v141, 5, s67                           ; d646008d 010d0b8d
	v_lshl_add_u32 v145, v145, 5, s67                           ; d6460091 010d0b91
(invalid instruction)                                        ; cc1c0097
	v_subrev_f32_e32 v0, v151, v66                              ; 0a008597
(invalid instruction)                                        ; cc1c0096
	v_subrev_f32_e32 v0, v150, v66                              ; 0a008596
(invalid instruction)                                        ; cc0f0098
	v_min_num_f64_e32 v[1:2], v[136:137], v[140:141]            ; 1a031988
	v_lshl_add_u32 v138, v138, 5, s67                           ; d646008a 010d0b8a
	v_lshl_add_u32 v142, v142, 5, s67                           ; d646008e 010d0b8e
(invalid instruction)                                        ; cc1b0094
	v_subrev_f32_e32 v0, v148, v65                              ; 0a008394
	v_lshl_add_u32 v146, v146, 5, s67                           ; d6460092 010d0b92
(invalid instruction)                                        ; cc1b0095
	v_subrev_f32_e32 v0, v149, v65                              ; 0a008395
(invalid instruction)                                        ; cc0f0099
	v_min_num_f64_e32 v[1:2], v[137:138], v[141:142]            ; 1a031b89
(invalid instruction)                                        ; cc1b0097
	v_subrev_f32_e32 v0, v151, v65                              ; 0a008397
	v_lshl_add_u32 v139, v139, 5, s67                           ; d646008b 010d0b8b
	v_lshl_add_u32 v143, v143, 5, s67                           ; d646008f 010d0b8f
(invalid instruction)                                        ; cc1b0096
	v_subrev_f32_e32 v0, v150, v65                              ; 0a008396
(invalid instruction)                                        ; cc0f0098
	v_min_num_f64_e32 v[1:2], v[152:153], v[144:145]            ; 1a032198
	v_lshl_add_u32 v147, v147, 5, s67                           ; d6460093 010d0b93
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[138:139], v[142:143]            ; 1a031d8a
	v_lshl_add_u32 v148, v148, 5, s67                           ; d6460094 010d0b94
	v_lshl_add_u32 v149, v149, 5, s67                           ; d6460095 010d0b95
(invalid instruction)                                        ; cc0f0099
	v_min_num_f64_e32 v[1:2], v[153:154], v[145:146]            ; 1a032399
	v_lshl_add_u32 v151, v151, 5, s67                           ; d6460097 010d0b97
(invalid instruction)                                        ; cc0f009b
	v_min_num_f64_e32 v[1:2], v[139:140], v[143:144]            ; 1a031f8b
	v_lshl_add_u32 v150, v150, 5, s67                           ; d6460096 010d0b96
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[146:147]            ; 1a03259a
(invalid instruction)                                        ; cc0f0098
	v_min_num_f64_e32 v[1:2], v[152:153], v[148:149]            ; 1a032998
(invalid instruction)                                        ; cc0f0099
	v_min_num_f64_e32 v[1:2], v[153:154], v[149:150]            ; 1a032b99
(invalid instruction)                                        ; cc0f009b
	v_min_num_f64_e32 v[1:2], v[155:156], v[147:148]            ; 1a03279b
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[150:151]            ; 1a032d9a
(invalid instruction)                                        ; cc0f0098
	v_min_num_f64_e32 v[1:2], v[152:153], v[153:154]            ; 1a033398
(invalid instruction)                                        ; cc0f009b
	v_min_num_f64_e32 v[1:2], v[155:156], v[151:152]            ; 1a032f9b
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f0098
	v_min_num_f64_e32 v[1:2], v[152:153], v[154:155]            ; 1a033598
(invalid instruction)                                        ; cc0f0098
	v_min_num_f64_e32 v[1:2], v[152:153], v[155:156]            ; 1a033798
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v156, v152, s61, s62 op_sel:[1,1]         ; d65c189c 00f87b98
(invalid instruction)                                        ; cc0f0098
	v_min_num_f64_e32 v[1:2], v[152:153], v[156:157]            ; 1a033998
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d532109d
	v_cndmask_b32_e32 v1, v152, v152, vcc_lo                    ; 02033198
(invalid instruction)                                        ; d531009d
	v_cndmask_b32_e32 v1, s60, v157, vcc_lo                     ; 02033a3c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b009e
	v_cndmask_b32_e32 v0, v157, v128, vcc_lo                    ; 0201019d
	v_rcp_f32_e32 v158, v158                                    ; 7f3c559e
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v162, v139, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000a2 8a033d8b
	v_fma_mix_f32 v139, v139, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088b 8a033d8b
	v_fma_mix_f32 v163, v140, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000a3 8a033d8c
	v_fma_mix_f32 v140, v140, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088c 8a033d8c
	v_fma_mix_f32 v160, v137, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000a0 8a033d89
	v_fma_mix_f32 v137, v137, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200889 8a033d89
	v_fma_mix_f32 v164, v141, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000a4 8a033d8d
	v_fma_mix_f32 v161, v138, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000a1 8a033d8a
	v_fma_mix_f32 v138, v138, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088a 8a033d8a
	buffer_load_b128 v[40:43], v26, s[32:35], null offen        ; c405c07c 40804028 0000001a
	v_fma_mix_f32 v159, v136, v158, neg(0) op_sel_hi:[1,0,0]    ; cc20009f 8a033d88
	v_fma_mix_f32 v136, v136, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200888 8a033d88
	v_fma_mix_f32 v141, v141, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088d 8a033d8d
	v_fma_mix_f32 v165, v142, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000a5 8a033d8e
	v_fma_mix_f32 v142, v142, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088e 8a033d8e
	v_fma_mix_f32 v166, v143, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000a6 8a033d8f
	v_fma_mix_f32 v143, v143, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088f 8a033d8f
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v163, v140, vcc_lo                    ; 020319a3
	buffer_load_b128 v[44:47], v26, s[32:35], null offen offset:16 ; c405c07c 4080402c 0000101a
	v_fma_mix_f32 v167, v144, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000a7 8a033d90
	v_fma_mix_f32 v144, v144, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200890 8a033d90
	v_fma_mix_f32 v168, v145, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000a8 8a033d91
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v161, v138, vcc_lo                    ; 020315a1
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v162, v139, vcc_lo                    ; 020317a2
	v_fma_mix_f32 v145, v145, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a033d91
	v_fma_mix_f32 v169, v146, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000a9 8a033d92
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v159, v136, vcc_lo                    ; 0203119f
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v160, v137, vcc_lo                    ; 020313a0
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v164, v141, vcc_lo                    ; 02031ba4
	v_mad_u32_u24 v175, s59, 0xc00, v2                          ; d60b00af 0409fe3b 00000c00
	v_lshl_add_u32 v3, v3, 7, v4                                ; d6460003 04110f03
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v165, v142, vcc_lo                    ; 02031da5
	v_fma_mix_f32 v146, v146, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200892 8a033d92
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v166, v143, vcc_lo                    ; 02031fa6
	v_fma_mix_f32 v170, v147, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000aa 8a033d93
	v_fma_mix_f32 v147, v147, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200893 8a033d93
	v_fma_mix_f32 v171, v148, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000ab 8a033d94
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v167, v144, vcc_lo                    ; 020321a7
	v_fma_mix_f32 v148, v148, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200894 8a033d94
	v_fma_mix_f32 v172, v149, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000ac 8a033d95
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v168, v145, vcc_lo                    ; 020323a8
	v_fma_mix_f32 v149, v149, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a033d95
	v_fma_mix_f32 v173, v150, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000ad 8a033d96
	v_fma_mix_f32 v150, v150, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200896 8a033d96
	v_fma_mix_f32 v174, v151, v158, neg(0) op_sel_hi:[1,0,0]    ; cc2000ae 8a033d97
	v_fma_mix_f32 v151, v151, v158, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a033d97
	v_add_nc_u32_e32 v175, v175, v3                             ; 4b5e07af
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v169, v146, vcc_lo                    ; 020325a9
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v170, v147, vcc_lo                    ; 020327aa
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v171, v148, vcc_lo                    ; 020329ab
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v172, v149, vcc_lo                    ; 02032bac
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v173, v150, vcc_lo                    ; 02032dad
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v174, v151, vcc_lo                    ; 02032fae
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_load_u8_d16 v48, v175 offset:8192                        ; da882000 300000af
	ds_load_u8_d16 v176, v175 offset:8208                       ; da882010 b00000af
	ds_load_u8_d16_hi v50, v175 offset:8224                     ; da8c2020 320000af
	ds_load_u8_d16 v177, v175 offset:8240                       ; da882030 b10000af
	ds_load_u8_d16 v49, v175 offset:8256                        ; da882040 310000af
	ds_load_u8_d16 v178, v175 offset:8272                       ; da882050 b20000af
	ds_load_u8_d16_hi v51, v175 offset:8288                     ; da8c2060 330000af
	ds_load_u8_d16 v179, v175 offset:8304                       ; da882070 b30000af
	ds_load_u8_d16 v52, v175 offset:10240                       ; da882800 340000af
	ds_load_u8_d16 v180, v175 offset:10256                      ; da882810 b40000af
	ds_load_u8_d16_hi v54, v175 offset:10272                    ; da8c2820 360000af
	ds_load_u8_d16 v181, v175 offset:10288                      ; da882830 b50000af
	ds_load_u8_d16 v53, v175 offset:10304                       ; da882840 350000af
	ds_load_u8_d16 v182, v175 offset:10320                      ; da882850 b60000af
	ds_load_u8_d16_hi v55, v175 offset:10336                    ; da8c2860 370000af
	ds_load_u8_d16 v183, v175 offset:10352                      ; da882870 b70000af
	ds_load_u8_d16 v56, v175 offset:12288                       ; da883000 380000af
	ds_load_u8_d16 v184, v175 offset:12304                      ; da883010 b80000af
	ds_load_u8_d16_hi v58, v175 offset:12320                    ; da8c3020 3a0000af
	ds_load_u8_d16 v185, v175 offset:12336                      ; da883030 b90000af
	ds_load_u8_d16 v57, v175 offset:12352                       ; da883040 390000af
	ds_load_u8_d16 v186, v175 offset:12368                      ; da883050 ba0000af
	ds_load_u8_d16_hi v59, v175 offset:12384                    ; da8c3060 3b0000af
	ds_load_u8_d16 v187, v175 offset:12400                      ; da883070 bb0000af
	ds_load_u8_d16 v60, v175 offset:14336                       ; da883800 3c0000af
	ds_load_u8_d16 v188, v175 offset:14352                      ; da883810 bc0000af
	ds_load_u8_d16_hi v62, v175 offset:14368                    ; da8c3820 3e0000af
	ds_load_u8_d16 v189, v175 offset:14384                      ; da883830 bd0000af
	ds_load_u8_d16 v61, v175 offset:14400                       ; da883840 3d0000af
	ds_load_u8_d16 v190, v175 offset:14416                      ; da883850 be0000af
	ds_load_u8_d16_hi v63, v175 offset:14432                    ; da8c3860 3f0000af
	ds_load_u8_d16 v191, v175 offset:14448                      ; da883870 bf0000af
	s_wait_dscnt 0x1e                                           ; bfc6001e
	v_perm_b32 v48, v48, v176, 0x7060004                        ; d6440030 03ff6130 07060004
	s_wait_dscnt 0x1a                                           ; bfc6001a
	v_perm_b32 v49, v49, v178, 0x7060004                        ; d6440031 03ff6531 07060004
	s_wait_dscnt 0x16                                           ; bfc60016
	v_perm_b32 v52, v52, v180, 0x7060004                        ; d6440034 03ff6934 07060004
	s_wait_dscnt 0x12                                           ; bfc60012
	v_perm_b32 v53, v53, v182, 0x7060004                        ; d6440035 03ff6d35 07060004
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_perm_b32 v48, v48, v50, 0x7020504                         ; d6440030 03fe6530 07020504
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_perm_b32 v56, v56, v184, 0x7060004                        ; d6440038 03ff7138 07060004
	v_perm_b32 v49, v49, v51, 0x7020504                         ; d6440031 03fe6731 07020504
	v_perm_b32 v52, v52, v54, 0x7020504                         ; d6440034 03fe6d34 07020504
	v_perm_b32 v53, v53, v55, 0x7020504                         ; d6440035 03fe6f35 07020504
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_perm_b32 v57, v57, v186, 0x7060004                        ; d6440039 03ff7539 07060004
	v_perm_b32 v48, v48, v177, 0x60504                          ; d6440030 03ff6330 00060504
	v_perm_b32 v56, v56, v58, 0x7020504                         ; d6440038 03fe7538 07020504
	v_perm_b32 v49, v49, v179, 0x60504                          ; d6440031 03ff6731 00060504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[48:49], v[24:25], 0 ; cc464060 1a023130
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[80:81], 0 ; cc464068 1a02a130
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[12:13], 0 ; cc464070 1a021930
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[48:49], v[8:9], 0   ; cc464040 1a021130
	buffer_load_b128 v[48:51], v26, s[32:35], null offen offset:64 ; c405c07c 40804030 0000401a
	v_perm_b32 v52, v52, v181, 0x60504                          ; d6440034 03ff6b34 00060504
	v_perm_b32 v53, v53, v183, 0x60504                          ; d6440035 03ff6f35 00060504
	s_wait_dscnt 0x9                                            ; bfc60009
	v_perm_b32 v57, v57, v59, 0x7020504                         ; d6440039 03fe7739 07020504
	v_perm_b32 v56, v56, v185, 0x60504                          ; d6440038 03ff7338 00060504
	s_wait_dscnt 0x6                                            ; bfc60006
	v_perm_b32 v60, v60, v188, 0x7060004                        ; d644003c 03ff793c 07060004
	s_wait_dscnt 0x2                                            ; bfc60002
	v_perm_b32 v61, v61, v190, 0x7060004                        ; d644003d 03ff7d3d 07060004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[82:83], v[104:111] ; cc464068 1da2a534
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[30:31], v[96:103] ; cc464060 1d823d34
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[52:53], v[16:17], v[112:119] ; cc464070 1dc22134
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[52:53], v[10:11], v[64:71] ; cc464040 1d021534
	buffer_load_b128 v[52:55], v26, s[32:35], null offen offset:80 ; c405c07c 40804034 0000501a
	v_perm_b32 v57, v57, v187, 0x60504                          ; d6440039 03ff7739 00060504
	v_perm_b32 v60, v60, v62, 0x7020504                         ; d644003c 03fe7d3c 07020504
	s_wait_dscnt 0x1                                            ; bfc60001
	v_perm_b32 v61, v61, v63, 0x7020504                         ; d644003d 03fe7f3d 07020504
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[56:57], v[90:91], v[104:111] ; cc464068 1da2b538
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[56:57], v[34:35], v[96:103] ; cc464060 1d824538
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[56:57], v[18:19], v[112:119] ; cc464070 1dc22538
	v_perm_b32 v60, v60, v189, 0x60504                          ; d644003c 03ff7b3c 00060504
	s_wait_dscnt 0x0                                            ; bfc60000
	v_perm_b32 v61, v61, v191, 0x60504                          ; d644003d 03ff7f3d 00060504
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[56:57], v[14:15], v[64:71] ; cc464040 1d021d38
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[20:21], v[104:111] ; cc464068 1da2293c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[60:61], v[36:37], v[96:103] ; cc464060 1d82493c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[60:61], v[32:33], v[112:119] ; cc464070 1dc2413c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[60:61], v[22:23], v[64:71] ; cc464040 1d022d3c
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	ds_store_2addr_stride64_b64 v29, v[56:57], v[58:59] offset0:16 offset1:20 ; d93c1410 003a381d
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	ds_store_2addr_stride64_b64 v29, v[56:57], v[58:59] offset0:24 offset1:28 ; d93c1c18 003a381d
	ds_load_u8_d16 v56, v175 offset:8448                        ; da882100 380000af
	ds_load_u8_d16 v191, v175 offset:8464                       ; da882110 bf0000af
	ds_load_u8_d16_hi v58, v175 offset:8480                     ; da8c2120 3a0000af
	ds_load_u8_d16 v3, v175 offset:8496                         ; da882130 030000af
	ds_load_u8_d16 v57, v175 offset:8512                        ; da882140 390000af
	ds_load_u8_d16 v4, v175 offset:8528                         ; da882150 040000af
	ds_load_u8_d16_hi v59, v175 offset:8544                     ; da8c2160 3b0000af
	ds_load_u8_d16 v26, v175 offset:8560                        ; da882170 1a0000af
	ds_load_u8_d16 v60, v175 offset:10496                       ; da882900 3c0000af
	ds_load_u8_d16 v28, v175 offset:10512                       ; da882910 1c0000af
	ds_load_u8_d16_hi v62, v175 offset:10528                    ; da8c2920 3e0000af
	ds_load_u8_d16 v61, v175 offset:10544                       ; da882930 3d0000af
	ds_load_u8_d16 v63, v175 offset:10560                       ; da882940 3f0000af
	ds_load_u8_d16 v64, v175 offset:10576                       ; da882950 400000af
	ds_load_u8_d16_hi v67, v175 offset:10592                    ; da8c2960 430000af
	ds_load_u8_d16 v62, v175 offset:10608                       ; da882970 3e0000af
	ds_load_u8_d16 v68, v175 offset:12544                       ; da883100 440000af
	ds_load_u8_d16 v65, v175 offset:12560                       ; da883110 410000af
	ds_load_u8_d16_hi v70, v175 offset:12576                    ; da8c3120 460000af
	ds_load_u8_d16 v66, v175 offset:12592                       ; da883130 420000af
	ds_load_u8_d16 v69, v175 offset:12608                       ; da883140 450000af
	ds_load_u8_d16 v71, v175 offset:12624                       ; da883150 470000af
	ds_load_u8_d16_hi v73, v175 offset:12640                    ; da8c3160 490000af
	ds_load_u8_d16 v67, v175 offset:12656                       ; da883170 430000af
	ds_load_u8_d16 v74, v175 offset:14592                       ; da883900 4a0000af
	ds_load_u8_d16 v72, v175 offset:14608                       ; da883910 480000af
	ds_load_u8_d16_hi v84, v175 offset:14624                    ; da8c3920 540000af
	ds_load_u8_d16 v75, v175 offset:14640                       ; da883930 4b0000af
	ds_load_u8_d16 v85, v175 offset:14656                       ; da883940 550000af
	ds_load_u8_d16 v73, v175 offset:14672                       ; da883950 490000af
	ds_load_u8_d16_hi v87, v175 offset:14688                    ; da8c3960 570000af
	ds_load_u8_d16 v76, v175 offset:14704                       ; da883970 4c0000af
	v_add_nc_u32_e32 v29, 0x100, v29                            ; 4a3a3aff 00000100
	s_lshr_b32 s7, s7, 2                                        ; 85078207
	s_wait_dscnt 0x1e                                           ; bfc6001e
	v_perm_b32 v56, v56, v191, 0x7060004                        ; d6440038 03ff7f38 07060004
	s_wait_dscnt 0x1a                                           ; bfc6001a
	v_perm_b32 v57, v57, v4, 0x7060004                          ; d6440039 03fe0939 07060004
	s_wait_dscnt 0x10                                           ; bfc60010
	v_perm_b32 v63, v63, v62, 0x60504                           ; d644003f 03fe7d3f 00060504
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v77, v77, s7, v78                                ; d655004d 05380f4d
	v_perm_b32 v62, v62, v60, 0x7060500                         ; d644003e 03fe793e 07060500
	v_perm_b32 v56, v56, v58, 0x7020504                         ; d6440038 03fe7538 07020504
	v_perm_b32 v57, v57, v59, 0x7020504                         ; d6440039 03fe7739 07020504
	v_perm_b32 v63, v63, v64, 0x7060004                         ; d644003f 03fe813f 07060004
	v_lshlrev_b32_e32 v77, 2, v77                               ; 309a9a82
	v_perm_b32 v62, v62, v28, 0x7060004                         ; d644003e 03fe393e 07060004
	v_perm_b32 v56, v56, v3, 0x60504                            ; d6440038 03fe0738 00060504
	v_perm_b32 v57, v57, v26, 0x60504                           ; d6440039 03fe3539 00060504
	s_wait_dscnt 0x8                                            ; bfc60008
	v_perm_b32 v63, v63, v67, 0x7020504                         ; d644003f 03fe873f 07020504
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_perm_b32 v62, v62, v61, 0x60504                           ; d644003e 03fe7b3e 00060504
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[56:57], v[8:9], 0  ; cc464060 1a021138
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[62:63], v[10:11], v[96:103] ; cc464060 1d82153e
	buffer_load_b128 v[8:11], v77, s[36:39], null offen         ; c405c07c 40804808 0000004d
	v_perm_b32 v68, v68, v65, 0x7060004                         ; d6440044 03fe8344 07060004
	v_perm_b32 v69, v69, v71, 0x7060004                         ; d6440045 03fe8f45 07060004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[56:57], v[80:81], 0 ; cc464070 1a02a138
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[56:57], v[24:25], 0 ; cc464068 1a023138
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[12:13], 0 ; cc464078 1a021938
	s_wait_dscnt 0x5                                            ; bfc60005
	v_perm_b32 v84, v84, v74, 0x7060500                         ; d6440054 03fe9554 07060500
	v_perm_b32 v68, v68, v70, 0x7020504                         ; d6440044 03fe8d44 07020504
	s_wait_dscnt 0x2                                            ; bfc60002
	v_perm_b32 v69, v69, v73, 0x7020504                         ; d6440045 03fe9345 07020504
	v_perm_b32 v85, v85, v73, 0x7060004                         ; d6440055 03fe9355 07060004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[82:83], v[112:119] ; cc464070 1dc2a53e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[62:63], v[30:31], v[104:111] ; cc464068 1da23d3e
	v_perm_b32 v84, v84, v72, 0x7060004                         ; d6440054 03fe9154 07060004
	v_perm_b32 v68, v68, v66, 0x60504                           ; d6440044 03fe8544 00060504
	v_perm_b32 v69, v69, v67, 0x60504                           ; d6440045 03fe8745 00060504
	s_wait_dscnt 0x1                                            ; bfc60001
	v_perm_b32 v85, v85, v87, 0x7020504                         ; d6440055 03feaf55 07020504
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[62:63], v[16:17], v[120:127] ; cc464078 1de2213e
	v_perm_b32 v84, v84, v75, 0x60504                           ; d6440054 03fe9754 00060504
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[14:15], v[96:103] ; cc464060 1d821d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[68:69], v[90:91], v[112:119] ; cc464070 1dc2b544
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[18:19], v[120:127] ; cc464078 1de22544
	buffer_load_b128 v[16:19], v77, s[36:39], null offen offset:512 ; c405c07c 40804810 0002004d
	s_wait_dscnt 0x0                                            ; bfc60000
	v_perm_b32 v85, v85, v76, 0x60504                           ; d6440055 03fe9955 00060504
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[34:35], v[104:111] ; cc464068 1da24544
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[84:85], v[22:23], v[96:103] ; cc464060 1d822d54
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[84:85], v[20:21], v[112:119] ; cc464070 1dc22954
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[84:85], v[32:33], v[120:127] ; cc464078 1de24154
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[84:85], v[36:37], v[104:111] ; cc464068 1da24954
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	ds_store_2addr_stride64_b64 v29, v[12:13], v[14:15] offset0:16 offset1:20 ; d93c1410 000e0c1d
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	ds_store_2addr_stride64_b64 v29, v[12:13], v[14:15] offset0:24 offset1:28 ; d93c1c18 000e0c1d
	buffer_load_b128 v[12:15], v77, s[36:39], null offen offset:1024 ; c405c07c 4080480c 0004004d
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[20:21], v38                                   ; d9d80000 14000026
	ds_load_b64 v[22:23], v38 offset:2048                       ; d9d80800 16000026
	ds_load_b64 v[24:25], v38 offset:4096                       ; d9d81000 18000026
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[28:29], v20                          ; 7e38dd14
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v57, v29, v41 :: v_dual_mul_f32 v56, v28, v40 ; c8c6531d 3938511c
	v_cvt_pk_f32_fp8_e32 v[28:29], v148                         ; 7e38dd94
	v_dual_mul_f32 v59, v29, v43 :: v_dual_mul_f32 v58, v28, v42 ; c8c6571d 3b3a551c
	buffer_load_b128 v[28:31], v77, s[36:39], null offen offset:1536 ; c405c07c 4080481c 0006004d
	v_cvt_pk_f32_fp8_e32 v[32:33], v21                          ; 7e40dd15
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v61, v33, v45 :: v_dual_mul_f32 v60, v32, v44 ; c8c65b21 3d3c5920
	ds_load_b64 v[32:33], v38 offset:6144                       ; d9d81800 20000026
	buffer_load_b128 v[68:71], v77, s[36:39], null offen offset:2048 ; c405c07c 40804844 0008004d
	ds_load_b64 v[34:35], v38 offset:256                        ; d9d80100 22000026
	buffer_load_b128 v[72:75], v77, s[36:39], null offen offset:2560 ; c405c07c 40804848 000a004d
	v_cvt_pk_f32_fp8_e32 v[20:21], v149                         ; 7e28dd95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v63, v21, v47 :: v_dual_mul_f32 v62, v20, v46 ; c8c65f15 3f3e5d14
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[20:21], v22                          ; 7e28dd16
	v_dual_mul_f32 v65, v21, v41 :: v_dual_mul_f32 v64, v20, v40 ; c8c65315 41405114
	v_cvt_pk_f32_fp8_e32 v[20:21], v150                         ; 7e28dd96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v67, v21, v43 :: v_dual_mul_f32 v66, v20, v42 ; c8c65715 43425514
	v_cvt_pk_f32_fp8_e32 v[20:21], v23                          ; 7e28dd17
	v_cvt_pk_f32_fp8_e32 v[22:23], v151                         ; 7e2cdd97
	v_dual_mul_f32 v85, v21, v45 :: v_dual_mul_f32 v84, v20, v44 ; c8c65b15 55545914
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[20:21], v24                          ; 7e28dd18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v89, v21, v41 :: v_dual_mul_f32 v88, v20, v40 ; c8c65315 59585114
	v_cvt_pk_f32_fp8_e32 v[20:21], v152                         ; 7e28dd98
	v_dual_mul_f32 v91, v21, v43 :: v_dual_mul_f32 v90, v20, v42 ; c8c65715 5b5a5514
	v_cvt_pk_f32_fp8_e32 v[20:21], v25                          ; 7e28dd19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v87, v23, v47 :: v_dual_mul_f32 v92, v20, v44 ; c8c65f17 575c5914
	v_dual_mul_f32 v93, v21, v45 :: v_dual_mul_f32 v86, v22, v46 ; c8c65b15 5d565d16
	v_cvt_pk_f32_fp8_e32 v[20:21], v153                         ; 7e28dd99
	v_dual_mul_f32 v95, v21, v47 :: v_dual_mul_f32 v94, v20, v46 ; c8c65f15 5f5e5d14
	buffer_load_b128 v[20:23], v77, s[36:39], null offen offset:3072 ; c405c07c 40804814 000c004d
	ds_load_b64 v[36:37], v38 offset:2304                       ; d9d80900 24000026
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[24:25], v32                          ; 7e30dd20
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v97, v25, v41                                 ; 10c25319
	v_mul_f32_e32 v96, v24, v40                                 ; 10c05118
	v_cvt_pk_f32_fp8_e32 v[24:25], v160                         ; 7e30dda0
	v_dual_mul_f32 v99, v25, v43 :: v_dual_mul_f32 v98, v24, v42 ; c8c65719 63625518
	buffer_load_b128 v[40:43], v77, s[36:39], null offen offset:3584 ; c405c07c 40804828 000e004d
	v_cvt_pk_f32_fp8_e32 v[24:25], v33                          ; 7e30dd21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v101, v25, v45 :: v_dual_mul_f32 v100, v24, v44 ; c8c65b19 65645918
	v_cvt_pk_f32_fp8_e32 v[24:25], v161                         ; 7e30dda1
	v_dual_mul_f32 v103, v25, v47 :: v_dual_mul_f32 v102, v24, v46 ; c8c65f19 67665d18
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[24:25], v34                          ; 7e30dd22
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v105, v25, v49 :: v_dual_mul_f32 v104, v24, v48 ; c8c66319 69686118
	v_cvt_pk_f32_fp8_e32 v[24:25], v162                         ; 7e30dda2
	v_dual_mul_f32 v107, v25, v51 :: v_dual_mul_f32 v106, v24, v50 ; c8c66719 6b6a6518
	v_cvt_pk_f32_fp8_e32 v[24:25], v35                          ; 7e30dd23
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v109, v25, v53 :: v_dual_mul_f32 v108, v24, v52 ; c8c66b19 6d6c6918
	v_cvt_pk_f32_fp8_e32 v[24:25], v163                         ; 7e30dda3
	v_dual_mul_f32 v111, v25, v55 :: v_dual_mul_f32 v110, v24, v54 ; c8c66f19 6f6e6d18
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[24:25], v36                          ; 7e30dd24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v25, v49 :: v_dual_mul_f32 v112, v24, v48 ; c8c66319 71706118
	v_cvt_pk_f32_fp8_e32 v[24:25], v164                         ; 7e30dda4
	v_dual_mul_f32 v115, v25, v51 :: v_dual_mul_f32 v114, v24, v50 ; c8c66719 73726518
	v_cvt_pk_f32_fp8_e32 v[24:25], v37                          ; 7e30dd25
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v117, v25, v53 :: v_dual_mul_f32 v116, v24, v52 ; c8c66b19 75746918
	v_cvt_pk_f32_fp8_e32 v[24:25], v165                         ; 7e30dda5
	ds_load_b64 v[32:33], v38 offset:4352                       ; d9d81100 20000026
	ds_load_b64 v[34:35], v38 offset:6400                       ; d9d81900 22000026
	ds_load_b64 v[36:37], v39 offset:8192                       ; d9d82000 24000027
	ds_load_b64 v[44:45], v39 offset:10240                      ; d9d82800 2c000027
	ds_load_b64 v[46:47], v39 offset:12288                      ; d9d83000 2e000027
	ds_load_b64 v[76:77], v39 offset:14336                      ; d9d83800 4c000027
	v_dual_mul_f32 v119, v25, v55 :: v_dual_mul_f32 v118, v24, v54 ; c8c66f19 77766d18
	s_wait_dscnt 0x5                                            ; bfc60005
	v_cvt_pk_f32_fp8_e32 v[24:25], v32                          ; 7e30dd20
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v121, v25, v49 :: v_dual_mul_f32 v120, v24, v48 ; c8c66319 79786118
	v_cvt_pk_f32_fp8_e32 v[24:25], v160                         ; 7e30dda0
	v_dual_mul_f32 v123, v25, v51 :: v_dual_mul_f32 v122, v24, v50 ; c8c66719 7b7a6518
	v_cvt_pk_f32_fp8_e32 v[24:25], v33                          ; 7e30dd21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v125, v25, v53 :: v_dual_mul_f32 v124, v24, v52 ; c8c66b19 7d7c6918
	v_cvt_pk_f32_fp8_e32 v[24:25], v161                         ; 7e30dda1
	v_dual_mul_f32 v127, v25, v55 :: v_dual_mul_f32 v126, v24, v54 ; c8c66f19 7f7e6d18
	s_wait_dscnt 0x4                                            ; bfc60004
	v_cvt_pk_f32_fp8_e32 v[24:25], v34                          ; 7e30dd22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v129, v25, v49                                ; 11026319
	v_mul_f32_e32 v128, v24, v48                                ; 11006118
	v_cvt_pk_f32_fp8_e32 v[24:25], v162                         ; 7e30dda2
	v_dual_mul_f32 v139, v25, v51 :: v_dual_mul_f32 v138, v24, v50 ; c8c66719 8b8a6518
	v_cvt_pk_f32_fp8_e32 v[24:25], v35                          ; 7e30dd23
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v133, v25, v53 :: v_dual_mul_f32 v132, v24, v52 ; c8c66b19 85846918
	v_cvt_pk_f32_fp8_e32 v[24:25], v163                         ; 7e30dda3
	ds_load_b64 v[32:33], v39 offset:8448                       ; d9d82100 20000027
	ds_load_b64 v[80:81], v39 offset:10496                      ; d9d82900 50000027
	ds_load_b64 v[82:83], v39 offset:12544                      ; d9d83100 52000027
	ds_load_b64 v[130:131], v39 offset:14592                    ; d9d83900 82000027
	ds_load_b64 v[34:35], v39 offset:8704                       ; d9d82200 22000027
	ds_load_b64 v[48:49], v39 offset:10752                      ; d9d82a00 30000027
	ds_load_b64 v[50:51], v39 offset:12800                      ; d9d83200 32000027
	ds_load_b64 v[52:53], v39 offset:14848                      ; d9d83a00 34000027
	v_dual_mul_f32 v135, v25, v55 :: v_dual_mul_f32 v134, v24, v54 ; c8c66f19 87866d18
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mov_b32 v141, v69 :: v_dual_mov_b32 v140, v68        ; ca100145 8d8c0144
	v_dual_mov_b32 v69, v85 :: v_dual_mov_b32 v68, v84          ; ca100155 45440154
	v_dual_mov_b32 v143, v71 :: v_dual_mov_b32 v142, v70        ; ca100147 8f8e0146
	v_dual_mov_b32 v71, v87 :: v_dual_mov_b32 v70, v86          ; ca100157 47460156
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[8:9], v[36:37], v[56:63] ; cc464038 1ce24908
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[46:47], v[88:95] ; cc464058 1d625d08
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[76:77], v[96:103] ; cc464060 1d829908
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[36:37], v[104:111] ; cc464068 1da2490a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[44:45], v[112:119] ; cc464070 1dc2590a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[44:45], v[64:71] ; cc464040 1d025908
	s_wait_dscnt 0x4                                            ; bfc60004
	v_dual_mov_b32 v9, v131 :: v_dual_mov_b32 v8, v130          ; ca100183 09080182
	v_dual_mov_b32 v131, v139 :: v_dual_mov_b32 v130, v138      ; ca10018b 8382018a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[46:47], v[120:127] ; cc464078 1de25d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[76:77], v[128:135] ; cc464080 1e02990a
	ds_load_b64 v[24:25], v39 offset:8960                       ; d9d82300 18000027
	ds_load_b64 v[54:55], v39 offset:11008                      ; d9d82b00 36000027
	ds_load_b64 v[84:85], v39 offset:13056                      ; d9d83300 54000027
	ds_load_b64 v[86:87], v39 offset:15104                      ; d9d83b00 56000027
	ds_load_b64 v[10:11], v39 offset:9216                       ; d9d82400 0a000027
	ds_load_b64 v[36:37], v39 offset:11264                      ; d9d82c00 24000027
	ds_load_b64 v[44:45], v39 offset:13312                      ; d9d83400 2c000027
	ds_load_b64 v[46:47], v39 offset:15360                      ; d9d83c00 2e000027
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[16:17], v[32:33], v[56:63] ; cc464038 1ce24110
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[82:83], v[88:95] ; cc464058 1d62a510
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[32:33], v[104:111] ; cc464068 1da24112
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[80:81], v[112:119] ; cc464070 1dc2a112
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[8:9], v[96:103] ; cc464060 1d821110
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[16:17], v[80:81], v[64:71] ; cc464040 1d02a110
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[82:83], v[120:127] ; cc464078 1de2a512
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[8:9], v[128:135] ; cc464080 1e021112
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[12:13], v[34:35], v[56:63] ; cc464038 1ce2450c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[50:51], v[88:95] ; cc464058 1d62650c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[34:35], v[104:111] ; cc464068 1da2450e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[48:49], v[112:119] ; cc464070 1dc2610e
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[52:53], v[96:103] ; cc464060 1d82690c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[12:13], v[48:49], v[64:71] ; cc464040 1d02610c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[50:51], v[120:127] ; cc464078 1de2650e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[52:53], v[128:135] ; cc464080 1e02690e
	ds_load_b64 v[8:9], v39 offset:9472                         ; d9d82500 08000027
	ds_load_b64 v[16:17], v39 offset:11520                      ; d9d82d00 10000027
	ds_load_b64 v[18:19], v39 offset:13568                      ; d9d83500 12000027
	ds_load_b64 v[32:33], v39 offset:15616                      ; d9d83d00 20000027
	ds_load_b64 v[12:13], v39 offset:9728                       ; d9d82600 0c000027
	ds_load_b64 v[14:15], v39 offset:11776                      ; d9d82e00 0e000027
	ds_load_b64 v[34:35], v39 offset:13824                      ; d9d83600 22000027
	ds_load_b64 v[48:49], v39 offset:15872                      ; d9d83e00 30000027
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[28:29], v[24:25], v[56:63] ; cc464038 1ce2311c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[84:85], v[88:95] ; cc464058 1d62a91c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[24:25], v[104:111] ; cc464068 1da2311e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[54:55], v[112:119] ; cc464070 1dc26d1e
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[86:87], v[96:103] ; cc464060 1d82ad1c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[28:29], v[54:55], v[64:71] ; cc464040 1d026d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[84:85], v[120:127] ; cc464078 1de2a91e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[86:87], v[128:135] ; cc464080 1e02ad1e
	ds_load_b64 v[24:25], v39 offset:9984                       ; d9d82700 18000027
	ds_load_b64 v[28:29], v39 offset:12032                      ; d9d82f00 1c000027
	ds_load_b64 v[30:31], v39 offset:14080                      ; d9d83700 1e000027
	ds_load_b64 v[38:39], v39 offset:16128                      ; d9d83f00 26000027
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[140:141], v[10:11], v[56:63] ; cc464038 1ce2158c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[140:141], v[44:45], v[88:95] ; cc464058 1d62598c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[142:143], v[10:11], v[104:111] ; cc464068 1da2158e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[142:143], v[36:37], v[112:119] ; cc464070 1dc2498e
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[140:141], v[46:47], v[96:103] ; cc464060 1d825d8c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[140:141], v[36:37], v[64:71] ; cc464040 1d02498c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[142:143], v[44:45], v[120:127] ; cc464078 1de2598e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[142:143], v[46:47], v[128:135] ; cc464080 1e025d8e
	s_wait_loadcnt_dscnt 0x20b                                  ; bfc8020b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[72:73], v[8:9], v[56:63] ; cc464038 1ce21148
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[18:19], v[88:95] ; cc464058 1d622548
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[74:75], v[8:9], v[104:111] ; cc464068 1da2114a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[16:17], v[112:119] ; cc464070 1dc2214a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[32:33], v[96:103] ; cc464060 1d824148
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[72:73], v[16:17], v[64:71] ; cc464040 1d022148
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[18:19], v[120:127] ; cc464078 1de2254a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[32:33], v[128:135] ; cc464080 1e02414a
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[20:21], v[12:13], v[56:63] ; cc464038 1ce21914
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[34:35], v[88:95] ; cc464058 1d624514
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[12:13], v[104:111] ; cc464068 1da21916
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[14:15], v[112:119] ; cc464070 1dc21d16
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[48:49], v[96:103] ; cc464060 1d826114
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[14:15], v[64:71] ; cc464040 1d021d14
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[34:35], v[120:127] ; cc464078 1de24516
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[48:49], v[128:135] ; cc464080 1e026116
	s_wait_loadcnt_dscnt 0x3                                    ; bfc80003
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[40:41], v[24:25], v[56:63] ; cc464038 1ce23128
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[30:31], v[88:95] ; cc464058 1d623d28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[24:25], v[104:111] ; cc464068 1da2312a
	s_cmp_ge_i32 s45, 0                                         ; bf03802d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[28:29], v[112:119] ; cc464070 1dc2392a
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[38:39], v[96:103] ; cc464060 1d824d28
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[40:41], v[28:29], v[64:71] ; cc464040 1d023928
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[30:31], v[120:127] ; cc464078 1de23d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[38:39], v[128:135] ; cc464080 1e024d2a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cselect_b32 s68, -1, 0                                    ; 984480c1
	s_cbranch_scc0 BB2                                          ; bfa10009
BB1:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s24, s0                                        ; bf040018
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00002
BB2:
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB5                                          ; bfa10008
BB4:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s21, s0                                        ; bf040015
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB6                                                ; bfa00001
BB5:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB6:
	v_lshlrev_b32_e32 v1, 1, v1                                 ; 30020281
	v_and_b32_e32 v0, 1, v0                                     ; 36000081
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_cndmask_b32_e64 v3, v56, v60, s0                          ; d5010003 00027938
	v_cndmask_b32_e64 v60, v60, v56, s0                         ; d501003c 0002713c
	v_cndmask_b32_e64 v4, v57, v61, s0                          ; d5010004 00027b39
	v_cndmask_b32_e64 v61, v61, v57, s0                         ; d501003d 0002733d
	v_cndmask_b32_e64 v10, v58, v62, s0                         ; d501000a 00027d3a
	v_cndmask_b32_e64 v62, v62, v58, s0                         ; d501003e 0002753e
	v_cndmask_b32_e64 v11, v59, v63, s0                         ; d501000b 00027f3b
	v_cndmask_b32_e64 v63, v63, v59, s0                         ; d501003f 0002773f
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v60, v60, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067806fa ff0cb13c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	v_add_f32_dpp v61, v61, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067a08fa ff0cb13d
	v_add_f32_dpp v62, v62, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067c14fa ff0cb13e
	v_add_f32_dpp v63, v63, v11 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067e16fa ff0cb13f
	v_cvt_f16_f32_e32 v14, v60                                  ; 7e1c153c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_cvt_f16_f32_e32 v15, v61                                  ; 7e1e153d
	v_cvt_f16_f32_e32 v12, v62                                  ; 7e18153e
	v_cndmask_b32_e64 v62, v62, v60, s2                         ; d501003e 000a793e
	v_cvt_f16_f32_e32 v13, v63                                  ; 7e1a153f
	v_cndmask_b32_e64 v63, v63, v61, s2                         ; d501003f 000a7b3f
	v_cndmask_b32_e64 v16, v14, v12, s2                         ; d5010010 000a190e
	v_cvt_f16_f32_dpp v17, v62 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2214fa ff0d643e
	v_cndmask_b16 v16, v15, v13, s2                             ; d65d4010 000a1b0f
(invalid instruction)                                        ; 7f2214fa
(invalid instruction)                                        ; ff0d643f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc0f0010
	v_min_num_f64_e32 v[1:2], v[16:17], v[17:18]                ; 1a022310
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB9                                          ; bfa1003a
BB7:
	s_load_b64 s[4:5], s[10:11], 0x44                           ; f4002105 f8000044
	s_ashr_i32 s0, s21, 1                                       ; 86008115
	s_ashr_i32 s2, s24, 1                                       ; 86028118
	v_bfe_u32 v3, v27, 1, 1                                     ; d6100003 0205031b
	v_bfe_u32 v4, v27, 3, 1                                     ; d6100004 0205071b
	s_and_b32 s6, s19, 1                                        ; 8b068113
	v_fma_mix_f32 v10, 0, v16, neg(0) op_sel_hi:[0,1,0]         ; cc20000a 920220ff 3e800000
	v_fma_mix_f32 v16, 0, v16, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 920220ff 3e800000
	v_bfe_u32 v12, v27, 2, 1                                    ; d610000c 0205051b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s6, s6, 5                                        ; 84068506
	s_and_b32 s7, s20, 1                                        ; 8b078114
	v_lshl_add_u32 v4, v4, 2, v3                                ; d6460004 040d0504
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v10, v16, vcc_lo                      ; 0202210a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s7, s7, 7                                        ; 84078707
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v4, v4, 4, v7                                ; d6460004 041d0904
	v_perm_b32 v14, v14, v11, 0x7060501                         ; d644000e 03fe170e 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s5                                        ; 96000500
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s2                                     ; 80000200
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v13, s0, 3, v1                               ; d646000d 04050600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v13, v13, 8, s4                              ; d646000d 0011110d
	v_add3_u32 v13, v13, s7, s6                                 ; d655000d 00180f0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v13, v13, v4                               ; 4a1a090d
	v_lshl_add_u32 v13, v0, 2, v13                              ; d646000d 04350500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v12, v12, 1, v13                             ; d646000c 0435030c
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v11, v12, s[12:15], null offen              ; c406007c 4080180b 0000000c
	buffer_store_b8 v14, v12, s[12:15], null offen offset:1     ; c406007c 4080180e 0000010c
BB9:
	s_or_not1_b32 s68, s47, s68                                 ; 9244442f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s0, src_scc, s49                                   ; 8c0031fd
	s_cbranch_scc1 BB12                                         ; bfa20008
BB10:
	v_add3_u32 v3, v2, s3, s29                                  ; d6550003 00740702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v3, v6, v3, v5                                   ; d6550003 04160706
	buffer_store_b64 v[8:9], v3, s[12:15], null offen           ; c406c07c 40801808 00000003
BB12:
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_ge_i32 s50, 0                                         ; bf038032
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s2, -1, 0                                     ; 980280c1
	s_cbranch_scc0 BB14                                         ; bfa1000a
BB13:
	s_load_b32 s4, s[10:11], 0x48                               ; f4000105 f8000048
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s4, s4, 1                                        ; 84048104
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s4                                        ; bf04041f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB15                                               ; bfa00002
BB14:
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB15:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	s_cbranch_scc0 BB17                                         ; bfa10009
BB16:
	s_load_b32 s4, s[10:11], 0x4c                               ; f4000105 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s4, s4, 1                                        ; 84048104
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s21, s4                                        ; bf040415
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB18                                               ; bfa00001
BB17:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB18:
	s_mov_b32 s4, 0xaaaaaaaa                                    ; be8400ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v3, v64, v68, s4                          ; d5010003 00128940
	v_cndmask_b32_e64 v68, v68, v64, s4                         ; d5010044 00128144
	v_cndmask_b32_e64 v4, v65, v69, s4                          ; d5010004 00128b41
	v_cndmask_b32_e64 v69, v69, v65, s4                         ; d5010045 00128345
	v_cndmask_b32_e64 v10, v66, v70, s4                         ; d501000a 00128d42
	v_cndmask_b32_e64 v70, v70, v66, s4                         ; d5010046 00128546
	v_cndmask_b32_e64 v11, v67, v71, s4                         ; d501000b 00128f43
	v_cndmask_b32_e64 v71, v71, v67, s4                         ; d5010047 00128747
	s_mov_b32 s6, 0xf0f0f0f0                                    ; be8600ff f0f0f0f0
	v_add_f32_dpp v68, v68, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068806fa ff0cb144
	s_and_b32 s7, vcc_lo, exec_lo                               ; 8b077e6a
	v_add_f32_dpp v69, v69, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068a08fa ff0cb145
	v_add_f32_dpp v70, v70, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068c14fa ff0cb146
	v_add_f32_dpp v71, v71, v11 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068e16fa ff0cb147
	v_cvt_f16_f32_e32 v14, v68                                  ; 7e1c1544
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v15, v69                                  ; 7e1e1545
	v_cvt_f16_f32_e32 v12, v70                                  ; 7e181546
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v70, v70, v68, s6                         ; d5010046 001a8946
	v_cvt_f16_f32_e32 v13, v71                                  ; 7e1a1547
	v_cndmask_b32_e64 v71, v71, v69, s6                         ; d5010047 001a8b47
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v16, v14, v12, s6                         ; d5010010 001a190e
	v_cvt_f16_f32_dpp v17, v70 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2214fa ff0d6446
	v_cndmask_b16 v16, v15, v13, s6                             ; d65d4010 001a1b0f
(invalid instruction)                                        ; 7f2214fa
(invalid instruction)                                        ; ff0d6447
(invalid instruction)                                        ; cc0f0010
	v_min_num_f64_e32 v[1:2], v[16:17], v[17:18]                ; 1a022310
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB21                                         ; bfa1003a
BB19:
	s_load_b64 s[6:7], s[10:11], 0x44                           ; f4002185 f8000044
	s_ashr_i32 s4, s21, 1                                       ; 86048115
	s_ashr_i32 s8, s31, 1                                       ; 8608811f
	v_bfe_u32 v3, v27, 1, 1                                     ; d6100003 0205031b
	v_bfe_u32 v4, v27, 3, 1                                     ; d6100004 0205071b
	s_and_b32 s9, s31, 1                                        ; 8b09811f
	v_fma_mix_f32 v10, 0, v16, neg(0) op_sel_hi:[0,1,0]         ; cc20000a 920220ff 3e800000
	v_fma_mix_f32 v16, 0, v16, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 920220ff 3e800000
	v_bfe_u32 v12, v27, 2, 1                                    ; d610000c 0205051b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s9, s9, 5                                        ; 84098509
	s_and_b32 s16, s20, 1                                       ; 8b108114
	v_lshl_add_u32 v4, v4, 2, v3                                ; d6460004 040d0504
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v10, v16, vcc_lo                      ; 0202210a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s16, s16, 7                                      ; 84108710
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v4, v4, 4, v7                                ; d6460004 041d0904
	v_perm_b32 v14, v14, v11, 0x7060501                         ; d644000e 03fe170e 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s4, s4, s7                                        ; 96040704
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s4, s8                                     ; 80040804
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v13, s4, 3, v1                               ; d646000d 04050604
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v13, v13, 8, s6                              ; d646000d 0019110d
	v_add3_u32 v13, v13, s16, s9                                ; d655000d 0024210d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v13, v13, v4                               ; 4a1a090d
	v_lshl_add_u32 v13, v0, 2, v13                              ; d646000d 04350500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v12, v12, 1, v13                             ; d646000c 0435030c
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v11, v12, s[12:15], null offen              ; c406007c 4080180b 0000000c
	buffer_store_b8 v14, v12, s[12:15], null offen offset:1     ; c406007c 4080180e 0000010c
BB21:
	s_or_not1_b32 s2, s52, s2                                   ; 92020234
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s49, src_scc, s49                                  ; 8c3131fd
	s_cbranch_scc1 BB24                                         ; bfa20008
BB22:
	v_add3_u32 v3, v2, s3, s28                                  ; d6550003 00700702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v3, v6, v3, v5                                   ; d6550003 04160706
	buffer_store_b64 v[8:9], v3, s[12:15], null offen           ; c406c07c 40801808 00000003
BB24:
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s2, src_scc                                       ; be8200fd
	s_cmp_ge_i32 s53, 0                                         ; bf038035
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s4, -1, 0                                     ; 980480c1
	s_cbranch_scc0 BB26                                         ; bfa1000a
BB25:
	s_load_b32 s6, s[10:11], 0x48                               ; f4000185 f8000048
	s_mov_b32 s7, src_scc                                       ; be8700fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s24, s6                                        ; bf040618
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB27                                               ; bfa00002
BB26:
	s_mov_b32 s7, src_scc                                       ; be8700fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB27:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	s_cbranch_scc0 BB29                                         ; bfa10009
BB28:
	s_load_b32 s6, s[10:11], 0x4c                               ; f4000185 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s6                                        ; bf04062a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB30                                               ; bfa00001
BB29:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB30:
	s_mov_b32 s6, 0xaaaaaaaa                                    ; be8600ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v3, v88, v92, s6                          ; d5010003 001ab958
	v_cndmask_b32_e64 v92, v92, v88, s6                         ; d501005c 001ab15c
	v_cndmask_b32_e64 v4, v89, v93, s6                          ; d5010004 001abb59
	v_cndmask_b32_e64 v93, v93, v89, s6                         ; d501005d 001ab35d
	v_cndmask_b32_e64 v10, v90, v94, s6                         ; d501000a 001abd5a
	v_cndmask_b32_e64 v94, v94, v90, s6                         ; d501005e 001ab55e
	v_cndmask_b32_e64 v11, v91, v95, s6                         ; d501000b 001abf5b
	v_cndmask_b32_e64 v95, v95, v91, s6                         ; d501005f 001ab75f
	s_mov_b32 s8, 0xf0f0f0f0                                    ; be8800ff f0f0f0f0
	v_add_f32_dpp v92, v92, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06b806fa ff0cb15c
	s_and_b32 s9, vcc_lo, exec_lo                               ; 8b097e6a
	v_add_f32_dpp v93, v93, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ba08fa ff0cb15d
	v_add_f32_dpp v94, v94, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06bc14fa ff0cb15e
	v_add_f32_dpp v95, v95, v11 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06be16fa ff0cb15f
	v_cvt_f16_f32_e32 v14, v92                                  ; 7e1c155c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v15, v93                                  ; 7e1e155d
	v_cvt_f16_f32_e32 v12, v94                                  ; 7e18155e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v94, v94, v92, s8                         ; d501005e 0022b95e
	v_cvt_f16_f32_e32 v13, v95                                  ; 7e1a155f
	v_cndmask_b32_e64 v95, v95, v93, s8                         ; d501005f 0022bb5f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v16, v14, v12, s8                         ; d5010010 0022190e
	v_cvt_f16_f32_dpp v17, v94 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2214fa ff0d645e
	v_cndmask_b16 v16, v15, v13, s8                             ; d65d4010 00221b0f
(invalid instruction)                                        ; 7f2214fa
(invalid instruction)                                        ; ff0d645f
(invalid instruction)                                        ; cc0f0010
	v_min_num_f64_e32 v[1:2], v[16:17], v[17:18]                ; 1a022310
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB33                                         ; bfa10039
BB31:
	s_load_b64 s[8:9], s[10:11], 0x44                           ; f4002205 f8000044
	s_ashr_i32 s6, s42, 1                                       ; 8606812a
	s_ashr_i32 s16, s24, 1                                      ; 86108118
	v_bfe_u32 v3, v27, 1, 1                                     ; d6100003 0205031b
	v_bfe_u32 v4, v27, 3, 1                                     ; d6100004 0205071b
	s_and_b32 s17, s19, 1                                       ; 8b118113
	v_fma_mix_f32 v10, 0, v16, neg(0) op_sel_hi:[0,1,0]         ; cc20000a 920220ff 3e800000
	v_fma_mix_f32 v16, 0, v16, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 920220ff 3e800000
	v_bfe_u32 v12, v27, 2, 1                                    ; d610000c 0205051b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s17, s17, 5                                      ; 84118511
	s_and_b32 s18, s42, 1                                       ; 8b12812a
	v_lshl_add_u32 v4, v4, 2, v3                                ; d6460004 040d0504
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v10, v16, vcc_lo                      ; 0202210a
	s_lshl_b32 s18, s18, 7                                      ; 84128712
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v4, v4, 4, v7                                ; d6460004 041d0904
	v_perm_b32 v14, v14, v11, 0x7060501                         ; d644000e 03fe170e 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s6, s6, s9                                        ; 96060906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s16                                    ; 80061006
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v13, s6, 3, v1                               ; d646000d 04050606
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v13, v13, 8, s8                              ; d646000d 0021110d
	v_add3_u32 v13, v13, s18, s17                               ; d655000d 0044250d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v13, v13, v4                               ; 4a1a090d
	v_lshl_add_u32 v13, v0, 2, v13                              ; d646000d 04350500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v12, v12, 1, v13                             ; d646000c 0435030c
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v11, v12, s[12:15], null offen              ; c406007c 4080180b 0000000c
	buffer_store_b8 v14, v12, s[12:15], null offen offset:1     ; c406007c 4080180e 0000010c
BB33:
	s_or_not1_b32 s47, s47, s4                                  ; 922f042f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s4, src_scc, s56                                   ; 8c0438fd
	s_cbranch_scc1 BB36                                         ; bfa20008
BB34:
	v_add3_u32 v3, v2, s3, s25                                  ; d6550003 00640702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v3, v6, v3, v5                                   ; d6550003 04160706
	buffer_store_b64 v[8:9], v3, s[12:15], null offen           ; c406c07c 40801808 00000003
BB36:
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s4, src_scc                                       ; be8400fd
	s_cmp_ge_i32 s57, 0                                         ; bf038039
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s6, -1, 0                                     ; 980680c1
	s_cbranch_scc0 BB38                                         ; bfa1000a
BB37:
	s_load_b32 s8, s[10:11], 0x48                               ; f4000205 f8000048
	s_mov_b32 s9, src_scc                                       ; be8900fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s8, s8, 1                                        ; 84088108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s8                                        ; bf04081f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB39                                               ; bfa00002
BB38:
	s_mov_b32 s9, src_scc                                       ; be8900fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB39:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s8, vcc_lo, exec_lo                               ; 8b087e6a
	s_cbranch_scc0 BB41                                         ; bfa10009
BB40:
	s_load_b32 s8, s[10:11], 0x4c                               ; f4000205 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s8, s8, 1                                        ; 84088108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s8                                        ; bf04082a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB42                                               ; bfa00001
BB41:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB42:
	s_mov_b32 s8, 0xaaaaaaaa                                    ; be8800ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v3, v96, v100, s8                         ; d5010003 0022c960
	v_cndmask_b32_e64 v100, v100, v96, s8                       ; d5010064 0022c164
	v_cndmask_b32_e64 v4, v97, v101, s8                         ; d5010004 0022cb61
	v_cndmask_b32_e64 v101, v101, v97, s8                       ; d5010065 0022c365
	v_cndmask_b32_e64 v10, v98, v102, s8                        ; d501000a 0022cd62
	v_cndmask_b32_e64 v102, v102, v98, s8                       ; d5010066 0022c566
	v_cndmask_b32_e64 v11, v99, v103, s8                        ; d501000b 0022cf63
	v_cndmask_b32_e64 v103, v103, v99, s8                       ; d5010067 0022c767
	s_mov_b32 s16, 0xf0f0f0f0                                   ; be9000ff f0f0f0f0
	v_add_f32_dpp v100, v100, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06c806fa ff0cb164
	s_and_b32 s17, vcc_lo, exec_lo                              ; 8b117e6a
	v_add_f32_dpp v101, v101, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ca08fa ff0cb165
	v_add_f32_dpp v102, v102, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cc14fa ff0cb166
	v_add_f32_dpp v103, v103, v11 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ce16fa ff0cb167
	v_cvt_f16_f32_e32 v14, v100                                 ; 7e1c1564
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v15, v101                                 ; 7e1e1565
	v_cvt_f16_f32_e32 v12, v102                                 ; 7e181566
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v102, v102, v100, s16                     ; d5010066 0042c966
	v_cvt_f16_f32_e32 v13, v103                                 ; 7e1a1567
	v_cndmask_b32_e64 v103, v103, v101, s16                     ; d5010067 0042cb67
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v16, v14, v12, s16                        ; d5010010 0042190e
	v_cvt_f16_f32_dpp v17, v102 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2214fa ff0d6466
	v_cndmask_b16 v16, v15, v13, s16                            ; d65d4010 00421b0f
(invalid instruction)                                        ; 7f2214fa
(invalid instruction)                                        ; ff0d6467
(invalid instruction)                                        ; cc0f0010
	v_min_num_f64_e32 v[1:2], v[16:17], v[17:18]                ; 1a022310
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB45                                         ; bfa1003a
BB43:
	s_load_b64 s[16:17], s[10:11], 0x44                         ; f4002405 f8000044
	s_ashr_i32 s8, s42, 1                                       ; 8608812a
	s_ashr_i32 s18, s31, 1                                      ; 8612811f
	v_bfe_u32 v3, v27, 1, 1                                     ; d6100003 0205031b
	v_bfe_u32 v4, v27, 3, 1                                     ; d6100004 0205071b
	s_and_b32 s22, s31, 1                                       ; 8b16811f
	v_fma_mix_f32 v10, 0, v16, neg(0) op_sel_hi:[0,1,0]         ; cc20000a 920220ff 3e800000
	v_fma_mix_f32 v16, 0, v16, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 920220ff 3e800000
	v_bfe_u32 v12, v27, 2, 1                                    ; d610000c 0205051b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s22, s22, 5                                      ; 84168516
	s_and_b32 s23, s42, 1                                       ; 8b17812a
	v_lshl_add_u32 v4, v4, 2, v3                                ; d6460004 040d0504
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v10, v16, vcc_lo                      ; 0202210a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s23, s23, 7                                      ; 84178717
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v4, v4, 4, v7                                ; d6460004 041d0904
	v_perm_b32 v14, v14, v11, 0x7060501                         ; d644000e 03fe170e 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s8, s8, s17                                       ; 96081108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s8, s8, s18                                    ; 80081208
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v13, s8, 3, v1                               ; d646000d 04050608
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v13, v13, 8, s16                             ; d646000d 0041110d
	v_add3_u32 v13, v13, s23, s22                               ; d655000d 00582f0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v13, v13, v4                               ; 4a1a090d
	v_lshl_add_u32 v13, v0, 2, v13                              ; d646000d 04350500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v12, v12, 1, v13                             ; d646000c 0435030c
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v11, v12, s[12:15], null offen              ; c406007c 4080180b 0000000c
	buffer_store_b8 v14, v12, s[12:15], null offen offset:1     ; c406007c 4080180e 0000010c
BB45:
	s_or_not1_b32 s52, s52, s6                                  ; 92340634
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s56, src_scc, s56                                  ; 8c3838fd
	s_cbranch_scc1 BB48                                         ; bfa20008
BB46:
	v_add3_u32 v2, v2, s3, s43                                  ; d6550002 00ac0702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v6, v2, v5                                   ; d6550002 04160506
	buffer_store_b64 v[8:9], v2, s[12:15], null offen           ; c406c07c 40801808 00000002
BB48:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s1, vcc_lo                                        ; be81006a
	s_cbranch_scc0 BB50                                         ; bfa10009
BB49:
	s_load_b32 s6, s[10:11], 0x48                               ; f4000185 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s24, s6                                        ; bf040618
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB51                                               ; bfa00001
BB50:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB51:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	s_cbranch_scc0 BB53                                         ; bfa10009
BB52:
	s_load_b32 s6, s[10:11], 0x4c                               ; f4000185 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s21, s6                                        ; bf040615
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB54                                               ; bfa00001
BB53:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB54:
	s_mov_b32 s6, 0xaaaaaaaa                                    ; be8600ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v104, v108, s6                        ; d5010004 001ad968
	v_cndmask_b32_e64 v108, v108, v104, s6                      ; d501006c 001ad16c
	v_cndmask_b32_e64 v8, v105, v109, s6                        ; d5010008 001adb69
	v_cndmask_b32_e64 v109, v109, v105, s6                      ; d501006d 001ad36d
	v_cndmask_b32_e64 v9, v106, v110, s6                        ; d5010009 001add6a
	v_cndmask_b32_e64 v110, v110, v106, s6                      ; d501006e 001ad56e
	v_cndmask_b32_e64 v10, v107, v111, s6                       ; d501000a 001adf6b
	v_cndmask_b32_e64 v111, v111, v107, s6                      ; d501006f 001ad76f
	s_mov_b32 s8, 0xf0f0f0f0                                    ; be8800ff f0f0f0f0
	v_add_f32_dpp v108, v108, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06d808fa ff0cb16c
	s_and_b32 s16, vcc_lo, exec_lo                              ; 8b107e6a
	v_add_f32_dpp v109, v109, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06da10fa ff0cb16d
	v_add_f32_dpp v110, v110, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06dc12fa ff0cb16e
	v_add_f32_dpp v111, v111, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06de14fa ff0cb16f
	v_cvt_f16_f32_e32 v13, v108                                 ; 7e1a156c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v14, v109                                 ; 7e1c156d
	v_cvt_f16_f32_e32 v11, v110                                 ; 7e16156e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v110, v110, v108, s8                      ; d501006e 0022d96e
	v_cvt_f16_f32_e32 v12, v111                                 ; 7e18156f
	v_cndmask_b32_e64 v111, v111, v109, s8                      ; d501006f 0022db6f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v15, v13, v11, s8                         ; d501000f 0022170d
	v_cvt_f16_f32_dpp v16, v110 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d646e
	v_cndmask_b16 v15, v14, v12, s8                             ; d65d400f 0022190e
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d646f
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB57                                         ; bfa1003c
BB55:
	s_load_b64 s[16:17], s[10:11], 0x44                         ; f4002405 f8000044
	s_ashr_i32 s6, s21, 1                                       ; 86068115
	s_ashr_i32 s8, s24, 1                                       ; 86088118
	v_bfe_u32 v4, v27, 1, 1                                     ; d6100004 0205031b
	v_bfe_u32 v8, v27, 3, 1                                     ; d6100008 0205071b
	s_and_b32 s18, s19, 1                                       ; 8b128113
	v_fma_mix_f32 v9, 0, v15, neg(0) op_sel_hi:[0,1,0]          ; cc200009 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100f 92021eff 3e800000
	v_bfe_u32 v11, v27, 2, 1                                    ; d610000b 0205051b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s18, s18, 5                                      ; 84128512
	s_and_b32 s22, s20, 1                                       ; 8b168114
	v_lshl_add_u32 v8, v8, 2, v4                                ; d6460008 04110508
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v9, v15, vcc_lo                       ; 02021f09
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s22, s22, 7                                      ; 84168716
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s22, s22, s18                                  ; 80161216
	v_lshl_add_u32 v8, v8, 4, v7                                ; d6460008 041d0908
	v_perm_b32 v13, v13, v10, 0x7060501                         ; d644000d 03fe150d 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s6, s6, s17                                       ; 96061106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s8                                     ; 80060806
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v12, s6, 3, v1                               ; d646000c 04050606
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v12, v12, 8, 0x100                           ; d646000c 03fd110c 00000100
	v_add3_u32 v12, s22, s16, v12                               ; d655000c 04302016
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v12, v12, v8                               ; 4a18110c
	v_lshl_add_u32 v12, v0, 2, v12                              ; d646000c 04310500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v11, v11, 1, v12                             ; d646000b 0431030b
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v10, v11, s[12:15], null offen              ; c406007c 4080180a 0000000b
	buffer_store_b8 v13, v11, s[12:15], null offen offset:1     ; c406007c 4080180d 0000010b
BB57:
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB60                                         ; bfa20008
BB58:
	v_add3_u32 v4, v79, s3, s29                                 ; d6550004 0074074f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v6, v4, v5                                   ; d6550004 04160906
	buffer_store_b64 v[2:3], v4, s[12:15], null offen           ; c406c07c 40801802 00000004
BB60:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s5, 0                                          ; bf018005
	s_cbranch_scc0 BB62                                         ; bfa10009
BB61:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s0                                        ; bf04001f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB63                                               ; bfa00001
BB62:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB63:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB65                                         ; bfa10009
BB64:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s21, s0                                        ; bf040015
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB66                                               ; bfa00001
BB65:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB66:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v112, v116, s0                        ; d5010004 0002e970
	v_cndmask_b32_e64 v116, v116, v112, s0                      ; d5010074 0002e174
	v_cndmask_b32_e64 v8, v113, v117, s0                        ; d5010008 0002eb71
	v_cndmask_b32_e64 v117, v117, v113, s0                      ; d5010075 0002e375
	v_cndmask_b32_e64 v9, v114, v118, s0                        ; d5010009 0002ed72
	v_cndmask_b32_e64 v118, v118, v114, s0                      ; d5010076 0002e576
	v_cndmask_b32_e64 v10, v115, v119, s0                       ; d501000a 0002ef73
	v_cndmask_b32_e64 v119, v119, v115, s0                      ; d5010077 0002e777
	s_mov_b32 s5, 0xf0f0f0f0                                    ; be8500ff f0f0f0f0
	v_add_f32_dpp v116, v116, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06e808fa ff0cb174
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	v_add_f32_dpp v117, v117, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ea10fa ff0cb175
	v_add_f32_dpp v118, v118, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ec12fa ff0cb176
	v_add_f32_dpp v119, v119, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ee14fa ff0cb177
	v_cvt_f16_f32_e32 v13, v116                                 ; 7e1a1574
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v14, v117                                 ; 7e1c1575
	v_cvt_f16_f32_e32 v11, v118                                 ; 7e161576
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v118, v118, v116, s5                      ; d5010076 0016e976
	v_cvt_f16_f32_e32 v12, v119                                 ; 7e181577
	v_cndmask_b32_e64 v119, v119, v117, s5                      ; d5010077 0016eb77
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v15, v13, v11, s5                         ; d501000f 0016170d
	v_cvt_f16_f32_dpp v16, v118 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d6476
	v_cndmask_b16 v15, v14, v12, s5                             ; d65d400f 0016190e
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d6477
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB69                                         ; bfa1003a
BB67:
	s_load_b64 s[16:17], s[10:11], 0x44                         ; f4002405 f8000044
	s_ashr_i32 s21, s21, 1                                      ; 86158115
	s_ashr_i32 s0, s31, 1                                       ; 8600811f
	v_bfe_u32 v4, v27, 1, 1                                     ; d6100004 0205031b
	v_bfe_u32 v8, v27, 3, 1                                     ; d6100008 0205071b
	s_and_b32 s5, s31, 1                                        ; 8b05811f
	v_fma_mix_f32 v9, 0, v15, neg(0) op_sel_hi:[0,1,0]          ; cc200009 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100f 92021eff 3e800000
	v_bfe_u32 v11, v27, 2, 1                                    ; d610000b 0205051b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s5, s5, 5                                        ; 84058505
	s_and_b32 s20, s20, 1                                       ; 8b148114
	v_lshl_add_u32 v8, v8, 2, v4                                ; d6460008 04110508
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v9, v15, vcc_lo                       ; 02021f09
	s_lshl_b32 s20, s20, 7                                      ; 84148714
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s20, s20, s5                                   ; 80140514
	v_lshl_add_u32 v8, v8, 4, v7                                ; d6460008 041d0908
	v_perm_b32 v13, v13, v10, 0x7060501                         ; d644000d 03fe150d 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s21, s21, s17                                     ; 96151115
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s21, s21, s0                                   ; 80150015
	v_lshl_add_u32 v12, s21, 3, v1                              ; d646000c 04050615
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v12, v12, 8, 0x100                           ; d646000c 03fd110c 00000100
	v_add3_u32 v12, s20, s16, v12                               ; d655000c 04302014
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v12, v12, v8                               ; 4a18110c
	v_lshl_add_u32 v12, v0, 2, v12                              ; d646000c 04310500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v11, v11, 1, v12                             ; d646000b 0431030b
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v10, v11, s[12:15], null offen              ; c406007c 4080180a 0000000b
	buffer_store_b8 v13, v11, s[12:15], null offen offset:1     ; c406007c 4080180d 0000010b
BB69:
	s_cmp_lg_i32 s2, 0                                          ; bf018002
	s_cbranch_scc1 BB72                                         ; bfa20008
BB70:
	v_add3_u32 v4, v79, s3, s28                                 ; d6550004 0070074f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v6, v4, v5                                   ; d6550004 04160906
	buffer_store_b64 v[2:3], v4, s[12:15], null offen           ; c406c07c 40801802 00000004
BB72:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s7, 0                                          ; bf018007
	s_cbranch_scc0 BB74                                         ; bfa10009
BB73:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s24, s0                                        ; bf040018
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB75                                               ; bfa00001
BB74:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB75:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB77                                         ; bfa10009
BB76:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s0                                        ; bf04002a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB78                                               ; bfa00001
BB77:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB78:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v120, v124, s0                        ; d5010004 0002f978
	v_cndmask_b32_e64 v124, v124, v120, s0                      ; d501007c 0002f17c
	v_cndmask_b32_e64 v8, v121, v125, s0                        ; d5010008 0002fb79
	v_cndmask_b32_e64 v125, v125, v121, s0                      ; d501007d 0002f37d
	v_cndmask_b32_e64 v9, v122, v126, s0                        ; d5010009 0002fd7a
	v_cndmask_b32_e64 v126, v126, v122, s0                      ; d501007e 0002f57e
	v_cndmask_b32_e64 v10, v123, v127, s0                       ; d501000a 0002ff7b
	v_cndmask_b32_e64 v127, v127, v123, s0                      ; d501007f 0002f77f
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v124, v124, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06f808fa ff0cb17c
	s_and_b32 s5, vcc_lo, exec_lo                               ; 8b057e6a
	v_add_f32_dpp v125, v125, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06fa10fa ff0cb17d
	v_add_f32_dpp v126, v126, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06fc12fa ff0cb17e
	v_add_f32_dpp v127, v127, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06fe14fa ff0cb17f
	v_cvt_f16_f32_e32 v13, v124                                 ; 7e1a157c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v14, v125                                 ; 7e1c157d
	v_cvt_f16_f32_e32 v11, v126                                 ; 7e16157e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v126, v126, v124, s2                      ; d501007e 000af97e
	v_cvt_f16_f32_e32 v12, v127                                 ; 7e18157f
	v_cndmask_b32_e64 v127, v127, v125, s2                      ; d501007f 000afb7f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v15, v13, v11, s2                         ; d501000f 000a170d
	v_cvt_f16_f32_dpp v16, v126 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d647e
	v_cndmask_b16 v15, v14, v12, s2                             ; d65d400f 000a190e
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d647f
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB81                                         ; bfa1003c
BB79:
	s_load_b64 s[6:7], s[10:11], 0x44                           ; f4002185 f8000044
	s_ashr_i32 s0, s42, 1                                       ; 8600812a
	s_ashr_i32 s24, s24, 1                                      ; 86188118
	v_bfe_u32 v4, v27, 1, 1                                     ; d6100004 0205031b
	v_bfe_u32 v8, v27, 3, 1                                     ; d6100008 0205071b
	s_and_b32 s19, s19, 1                                       ; 8b138113
	v_fma_mix_f32 v9, 0, v15, neg(0) op_sel_hi:[0,1,0]          ; cc200009 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100f 92021eff 3e800000
	v_bfe_u32 v11, v27, 2, 1                                    ; d610000b 0205051b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s19, s19, 5                                      ; 84138513
	s_and_b32 s2, s42, 1                                        ; 8b02812a
	v_lshl_add_u32 v8, v8, 2, v4                                ; d6460008 04110508
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v9, v15, vcc_lo                       ; 02021f09
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s2, s2, 7                                        ; 84028702
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s2, s2, s19                                    ; 80021302
	v_lshl_add_u32 v8, v8, 4, v7                                ; d6460008 041d0908
	v_perm_b32 v13, v13, v10, 0x7060501                         ; d644000d 03fe150d 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s7                                        ; 96000700
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s24                                    ; 80001800
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v12, s0, 3, v1                               ; d646000c 04050600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v12, v12, 8, 0x100                           ; d646000c 03fd110c 00000100
	v_add3_u32 v12, s2, s6, v12                                 ; d655000c 04300c02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v12, v12, v8                               ; 4a18110c
	v_lshl_add_u32 v12, v0, 2, v12                              ; d646000c 04310500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v11, v11, 1, v12                             ; d646000b 0431030b
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v10, v11, s[12:15], null offen              ; c406007c 4080180a 0000000b
	buffer_store_b8 v13, v11, s[12:15], null offen offset:1     ; c406007c 4080180d 0000010b
BB81:
	s_cmp_lg_i32 s4, 0                                          ; bf018004
	s_cbranch_scc1 BB84                                         ; bfa20008
BB82:
	v_add3_u32 v4, v79, s3, s25                                 ; d6550004 0064074f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v6, v4, v5                                   ; d6550004 04160906
	buffer_store_b64 v[2:3], v4, s[12:15], null offen           ; c406c07c 40801802 00000004
BB84:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s9, 0                                          ; bf018009
	s_cbranch_scc0 BB86                                         ; bfa10009
BB85:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s0                                        ; bf04001f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB87                                               ; bfa00001
BB86:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB87:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB89                                         ; bfa10009
BB88:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s0                                        ; bf04002a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB90                                               ; bfa00001
BB89:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB90:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v128, v132, s0                        ; d5010004 00030980
	v_cndmask_b32_e64 v132, v132, v128, s0                      ; d5010084 00030184
	v_cndmask_b32_e64 v8, v129, v133, s0                        ; d5010008 00030b81
	v_cndmask_b32_e64 v133, v133, v129, s0                      ; d5010085 00030385
	v_cndmask_b32_e64 v9, v130, v134, s0                        ; d5010009 00030d82
	v_cndmask_b32_e64 v134, v134, v130, s0                      ; d5010086 00030586
	v_cndmask_b32_e64 v10, v131, v135, s0                       ; d501000a 00030f83
	v_cndmask_b32_e64 v135, v135, v131, s0                      ; d5010087 00030787
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v132, v132, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070808fa ff0cb184
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	v_add_f32_dpp v133, v133, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070a10fa ff0cb185
	v_add_f32_dpp v134, v134, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070c12fa ff0cb186
	v_add_f32_dpp v135, v135, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070e14fa ff0cb187
	v_cvt_f16_f32_e32 v13, v132                                 ; 7e1a1584
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v14, v133                                 ; 7e1c1585
	v_cvt_f16_f32_e32 v11, v134                                 ; 7e161586
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v134, v134, v132, s2                      ; d5010086 000b0986
	v_cvt_f16_f32_e32 v12, v135                                 ; 7e181587
	v_cndmask_b32_e64 v135, v135, v133, s2                      ; d5010087 000b0b87
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v15, v13, v11, s2                         ; d501000f 000a170d
	v_cvt_f16_f32_dpp v16, v134 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d6486
	v_cndmask_b16 v15, v14, v12, s2                             ; d65d400f 000a190e
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d6487
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB93                                         ; bfa1003c
BB91:
	s_load_b64 s[4:5], s[10:11], 0x44                           ; f4002105 f8000044
	s_ashr_i32 s0, s42, 1                                       ; 8600812a
	s_ashr_i32 s2, s31, 1                                       ; 8602811f
	v_bfe_u32 v4, v27, 1, 1                                     ; d6100004 0205031b
	v_bfe_u32 v8, v27, 3, 1                                     ; d6100008 0205071b
	s_and_b32 s31, s31, 1                                       ; 8b1f811f
	v_fma_mix_f32 v9, 0, v15, neg(0) op_sel_hi:[0,1,0]          ; cc200009 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100f 92021eff 3e800000
	v_bfe_u32 v27, v27, 2, 1                                    ; d610001b 0205051b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s31, s31, 5                                      ; 841f851f
	s_and_b32 s42, s42, 1                                       ; 8b2a812a
	v_lshl_add_u32 v8, v8, 2, v4                                ; d6460008 04110508
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v9, v15, vcc_lo                       ; 02021f09
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s42, s42, 7                                      ; 842a872a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s42, s42, s31                                  ; 802a1f2a
	v_lshl_add_u32 v8, v8, 4, v7                                ; d6460008 041d0908
	v_perm_b32 v11, v11, v10, 0x7060501                         ; d644000b 03fe150b 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s5                                        ; 96000500
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s2                                     ; 80000200
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v1, s0, 3, v1                                ; d6460001 04050600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v1, v1, 8, 0x100                             ; d6460001 03fd1101 00000100
	v_add3_u32 v1, s42, s4, v1                                  ; d6550001 0404082a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v1, v1, v8                                 ; 4a021101
	v_lshl_add_u32 v0, v0, 2, v1                                ; d6460000 04050500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v27, v27, 1, v0                              ; d646001b 0401031b
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v10, v27, s[12:15], null offen              ; c406007c 4080180a 0000001b
	buffer_store_b8 v11, v27, s[12:15], null offen offset:1     ; c406007c 4080180b 0000011b
BB93:
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc1 BB96                                         ; bfa20008
BB94:
	v_add3_u32 v79, v79, s3, s43                                ; d655004f 00ac074f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v6, v6, v79, v5                                  ; d6550006 04169f06
	buffer_store_b64 v[2:3], v6, s[12:15], null offen           ; c406c07c 40801802 00000006
BB96:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
