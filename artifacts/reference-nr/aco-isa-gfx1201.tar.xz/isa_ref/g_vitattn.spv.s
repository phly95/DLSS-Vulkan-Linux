BB0:
	s_cmp_lg_i32 s5, -1                                         ; bf01c105
	s_cbranch_scc0 BB2                                          ; bfa1000f
BB1:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[8:11], s[6:7], 0x10                           ; f4004203 f8000010
	s_lshl2_add_u32 s6, s5, 24                                  ; 87869805
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s9, 14                                        ; be89108e
	s_buffer_load_b32 s6, s[8:11], s6 offset:0x0                ; f4020184 0c000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s6, 0x54434852                                 ; bf01ff06 54434852
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	s_cselect_b32 s5, -1, s5                                    ; 980505c1
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s5, -1                                         ; bf01c105
	s_cbranch_scc0 BB5                                          ; bfa1000a
BB4:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[8:11], s[6:7], 0x10                           ; f4004203 f8000010
	s_lshl2_add_u32 s5, s5, 12                                  ; 87858c05
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s9, 14                                        ; be89108e
	s_buffer_load_b32 s5, s[8:11], s5 offset:0x0                ; f4020144 0a000000
	s_branch BB6                                                ; bfa00001
BB5:
	s_mov_b32 s5, -1                                            ; be8500c1
BB6:
	s_lshl_b32 s6, ttmp9, 5                                     ; 84068575
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lt_u32 s6, s3                                         ; bf0a0306
	s_cbranch_scc0 BB49                                         ; bfa1095b
BB7:
	s_mov_b32 s7, s1                                            ; be870001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[8:11], s[0:1], 0x0                            ; f4004200 f8000000
(invalid instruction)                                        ; d71f0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_add_co_u32 s12, s3, -1                                    ; 800cc103
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_and_b32 s12, s12, -16                                     ; 8b0cd00c
	v_and_b32_e32 v1, 15, v0                                    ; 3602008f
	v_lshrrev_b32_e32 v4, 4, v0                                 ; 32080084
	s_min_u32 s13, s6, s12                                      ; 898d0c06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_mulk_i32 s13, 0xc00                                       ; b80d0c00
	v_lshlrev_b32_e32 v2, 4, v1                                 ; 30040284
	v_lshlrev_b32_e32 v4, 3, v4                                 ; 30080883
	s_add_co_u32 s13, s7, s13                                   ; 800d0d07
	s_lshl_b32 s14, ttmp7, 9                                    ; 840e8973
	s_add_co_u32 s15, s14, 0x100                                ; 800fff0e 00000100
	s_add_co_u32 s16, s6, 16                                    ; 80109006
	v_add3_u32 v3, v2, s13, s14                                 ; d6550003 00381b02
	v_add3_u32 v5, v2, s13, s15                                 ; d6550005 003c1b02
	s_min_u32 s17, s16, s12                                     ; 89910c10
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mulk_i32 s17, 0xc00                                       ; b8110c00
	v_add_nc_u32_e32 v3, v3, v4                                 ; 4a060903
	v_add_nc_u32_e32 v5, v5, v4                                 ; 4a0a0905
	s_add_co_u32 s17, s7, s17                                   ; 80111107
	v_add3_u32 v6, v2, s17, s14                                 ; d6550006 00382302
	v_add3_u32 v7, v2, s17, s15                                 ; d6550007 003c2302
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v6, v6, v4                                 ; 4a0c0906
	v_add_nc_u32_e32 v7, v7, v4                                 ; 4a0e0907
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[8:9], v3, s[8:11], null offen             ; c405407c 40801008 00000003
	buffer_load_b64 v[10:11], v5, s[8:11], null offen           ; c405407c 4080100a 00000005
	buffer_load_b64 v[12:13], v6, s[8:11], null offen           ; c405407c 4080100c 00000006
	buffer_load_b64 v[6:7], v7, s[8:11], null offen             ; c405407c 40801006 00000007
	v_and_b32_e32 v15, 3, v0                                    ; 361e0083
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v14, 4, v0           ; ca240080 030e0084
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	s_mov_b64 s[20:21], s[8:9]                                  ; be940108
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_bfe_u32 v16, v0, 3, 1                                     ; d6100010 02050700
	s_mov_b32 s13, 0                                            ; be8d0080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	v_lshl_or_b32 v14, v14, 1, v15                              ; d656000e 043d030e
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_lshl_or_b32 v16, v16, 2, v14                              ; d6560010 04390510
	v_lshl_add_u32 v16, v16, 4, v4                              ; d6460010 04110910
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v16, 2, v16                               ; 32202082
	s_nop 0                                                     ; bf800000
	(then repeated 4 times)
BB8:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s13, s3                                        ; bf09030d
	s_cbranch_scc1 BB26                                         ; bfa2079d
BB10:
	s_add_co_u32 s15, s13, 64                                   ; 800fc00d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s3, s15                                        ; bf090f03
	s_cbranch_scc0 BB12                                         ; bfa10368
BB11:
	s_load_b128 s[24:27], s[0:1], 0x20                          ; f4004600 f8000020
	s_mulk_i32 s13, 0xc00                                       ; b80d0c00
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s13, s7, s13                                   ; 800d0d07
	s_add_co_u32 s17, s14, 0x4000                               ; 8011ff0e 00004000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s13, s17                                  ; 8011110d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s17, s17, 2                                      ; 85118211
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v5, s17, v16, 2                              ; d6470005 020a2011
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[18:19], v5, s[24:27], null offen          ; c405407c 40803012 00000005
	buffer_load_b64 v[20:21], v5, s[24:27], null offen offset:256 ; c405407c 40803014 00010005
	v_lshrrev_b32_e32 v14, 3, v0                                ; 321c0083
	s_add_co_u32 s18, s14, 0x8000                               ; 8012ff0e 00008000
	s_mov_b32 s19, 0xf0f0f0f0                                   ; be9300ff f0f0f0f0
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s13, s13, s18                                  ; 800d120d
	s_mov_b32 s18, s20                                          ; be920014
	v_cndmask_b32_e64 v17, 0, 8, s19                            ; d5010011 004d1080
	s_sext_i32_i16 s19, s21                                     ; be930f15
	v_lshl_add_u32 v14, v14, 2, v15                             ; d646000e 043d050e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshlrev_b32_e32 v14, 4, v14                               ; 301c1c84
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v23, v14, 0x100, s13                             ; d6550017 0035ff0e 00000100
	v_add3_u32 v22, v17, s13, v14                               ; d6550016 04381b11
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v23, v23, v17                              ; 4a2e2317
	s_clause 0x1                                                ; bf850001
	global_load_tr_b64 v[56:57], v22, s[18:19]                  ; ee160012 00000038 00000016
	global_load_tr_b64 v[22:23], v23, s[18:19]                  ; ee160012 00000016 00000017
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[58:59], v5, s[24:27], null offen offset:49152 ; c405407c 4080303a 00c00005
	buffer_load_b64 v[60:61], v5, s[24:27], null offen offset:49408 ; c405407c 4080303c 00c10005
	v_add3_u32 v62, v14, s13, 0xc000                            ; d655003e 03fc1b0e 0000c000
	v_add3_u32 v63, v14, 0xc100, s13                            ; d655003f 0035ff0e 0000c100
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v62, v62, v17                              ; 4a7c233e
	v_add_nc_u32_e32 v63, v63, v17                              ; 4a7e233f
	s_clause 0x1                                                ; bf850001
	global_load_tr_b64 v[64:65], v62, s[18:19]                  ; ee160012 00000040 0000003e
	global_load_tr_b64 v[62:63], v63, s[18:19]                  ; ee160012 0000003e 0000003f
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[66:67], v5, s[24:27], null offen offset:98304 ; c405407c 40803042 01800005
	buffer_load_b64 v[68:69], v5, s[24:27], null offen offset:98560 ; c405407c 40803044 01810005
	v_add3_u32 v70, v14, s13, 0x18000                           ; d6550046 03fc1b0e 00018000
	v_add3_u32 v71, v14, 0x18100, s13                           ; d6550047 0035ff0e 00018100
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v70, v70, v17                              ; 4a8c2346
	v_add_nc_u32_e32 v71, v71, v17                              ; 4a8e2347
	s_clause 0x1                                                ; bf850001
	global_load_tr_b64 v[72:73], v70, s[18:19]                  ; ee160012 00000048 00000046
	global_load_tr_b64 v[70:71], v71, s[18:19]                  ; ee160012 00000046 00000047
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[74:75], v5, s[24:27], null offen offset:147456 ; c405407c 4080304a 02400005
	buffer_load_b64 v[76:77], v5, s[24:27], null offen offset:147712 ; c405407c 4080304c 02410005
	v_add3_u32 v78, v14, s13, 0x24000                           ; d655004e 03fc1b0e 00024000
	v_add3_u32 v14, v14, 0x24100, s13                           ; d655000e 0035ff0e 00024100
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v78, v78, v17                              ; 4a9c234e
	v_add_nc_u32_e32 v14, v14, v17                              ; 4a1c230e
	s_clause 0x1                                                ; bf850001
	global_load_tr_b64 v[78:79], v78, s[18:19]                  ; ee160012 0000004e 0000004e
	global_load_tr_b64 v[80:81], v14, s[18:19]                  ; ee160012 00000050 0000000e
	s_movk_i32 s22, 0x3fe9                                      ; b0163fe9
	s_movk_i32 s23, 0x3dc2                                      ; b0173dc2
	s_mov_b32 s24, 0x3ffc4000                                   ; be9800ff 3ffc4000
	s_bfm_b32 vcc_lo, 16, 0                                     ; 956a8090
	s_mov_b32 s25, 0x76543210                                   ; be9900ff 76543210
	s_mov_b32 s26, 0xfedcba98                                   ; be9a00ff fedcba98
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[18:19], v[8:9], 0   ; cc464058 1a021112
	s_wait_loadcnt 0xe                                          ; bfc0000e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[10:11], v[88:95] ; cc464058 1d621514
	v_cvt_f16_f32_e32 v85, v94                                  ; 7eaa155e
	v_cvt_f16_f32_e32 v82, v88                                  ; 7ea41558
(invalid instruction)                                        ; 7fa41559
	v_cvt_f16_f32_e32 v84, v92                                  ; 7ea8155c
(invalid instruction)                                        ; 7fa8155d
	v_cvt_f16_f32_e32 v83, v90                                  ; 7ea6155a
(invalid instruction)                                        ; 7fa6155b
(invalid instruction)                                        ; 7faa155f
	v_pk_fma_f16 v82, v82, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6052 0bfdff52 3ed62dbb
	v_pk_fma_f16 v84, v84, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6054 0bfdff54 3ed62dbb
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_pk_fma_f16 v83, v83, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6053 0bfdff53 3ed62dbb
	v_pk_fma_f16 v85, v85, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6055 0bfdff55 3ed62dbb
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v23                               ; 0a002f52
(invalid instruction)                                        ; cc1c0054
	v_subrev_f32_e32 v0, v84, v23                               ; 0a002f54
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v23                               ; 0a002f53
(invalid instruction)                                        ; cc1c0055
	v_subrev_f32_e32 v0, v85, v23                               ; 0a002f55
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v22                               ; 0a002d52
(invalid instruction)                                        ; cc1b0054
	v_subrev_f32_e32 v0, v84, v22                               ; 0a002d54
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b0053
	v_subrev_f32_e32 v0, v83, v22                               ; 0a002d53
(invalid instruction)                                        ; cc1b0055
	v_subrev_f32_e32 v0, v85, v22                               ; 0a002d55
	v_lshl_add_u32 v82, v82, 4, s24                             ; d6460052 00610952
	v_lshl_add_u32 v84, v84, 4, s24                             ; d6460054 00610954
	v_lshl_add_u32 v83, v83, 4, s24                             ; d6460053 00610953
	v_lshl_add_u32 v85, v85, 4, s24                             ; d6460055 00610955
	v_cvt_f32_f16_e32 v88, v210/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eb017d2
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[82:83], v[84:85]                ; 1a02a952
	v_cvt_f32_f16_e32 v82, v82                                  ; 7ea41752
	v_cvt_f32_f16_e32 v91, v84                                  ; 7eb61754
	v_cvt_f32_f16_e32 v84, v212/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea817d4
	v_cvt_f32_f16_e32 v90, v83                                  ; 7eb41753
(invalid instruction)                                        ; cc0f0057
	v_min_num_f64_e32 v[1:2], v[83:84], v[85:86]                ; 1a02ab53
	v_cvt_f32_f16_e32 v83, v211/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea617d3
	v_cvt_f32_f16_e32 v93, v85                                  ; 7eba1755
	v_cvt_f32_f16_e32 v85, v213/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eaa17d5
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v82, v88, vcc_lo                      ; 0202b152
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v91, v84, vcc_lo                      ; 0202a95b
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v90, v83, vcc_lo                      ; 0202a75a
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v93, v85, vcc_lo                      ; 0202ab5d
	v_cndmask_b32_e32 v94, v89, v92, vcc_lo                     ; 02bcb959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v94, v94, s25, s26 op_sel:[1,1]           ; d65c185e 0068335e
	v_dual_cndmask_b32 v82, v94, v89 :: v_dual_cndmask_b32 v83, v92, v94 ; ca52b35e 5252bd5c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[18:19], v[12:13], 0 ; cc464058 1a021912
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[6:7], v[88:95] ; cc464058 1d620d14
	v_cvt_f16_f32_e32 v18, v94                                  ; 7e24155e
	v_cvt_f16_f32_e32 v14, v90                                  ; 7e1c155a
(invalid instruction)                                        ; 7f1c155b
	v_cvt_f16_f32_e32 v17, v92                                  ; 7e22155c
(invalid instruction)                                        ; 7f22155d
	v_cvt_f16_f32_e32 v5, v88                                   ; 7e0a1558
(invalid instruction)                                        ; 7f0a1559
(invalid instruction)                                        ; 7f24155f
	v_pk_fma_f16 v14, v14, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e600e 0bfdff0e 3ed62dbb
	v_pk_fma_f16 v17, v17, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6011 0bfdff11 3ed62dbb
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_pk_fma_f16 v5, v5, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6005 0bfdff05 3ed62dbb
	v_pk_fma_f16 v18, v18, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6012 0bfdff12 3ed62dbb
(invalid instruction)                                        ; cc1c000e
	v_subrev_f32_e32 v0, v14, v23                               ; 0a002f0e
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v23                               ; 0a002f11
(invalid instruction)                                        ; cc1c0005
	v_subrev_f32_e32 v0, v5, v23                                ; 0a002f05
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v23                               ; 0a002f12
(invalid instruction)                                        ; cc1b000e
	v_subrev_f32_e32 v0, v14, v22                               ; 0a002d0e
(invalid instruction)                                        ; cc1b0011
	v_subrev_f32_e32 v0, v17, v22                               ; 0a002d11
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b0005
	v_subrev_f32_e32 v0, v5, v22                                ; 0a002d05
(invalid instruction)                                        ; cc1b0012
	v_subrev_f32_e32 v0, v18, v22                               ; 0a002d12
	v_lshl_add_u32 v14, v14, 4, s24                             ; d646000e 0061090e
	v_lshl_add_u32 v17, v17, 4, s24                             ; d6460011 00610911
	v_lshl_add_u32 v5, v5, 4, s24                               ; d6460005 00610905
	v_lshl_add_u32 v18, v18, 4, s24                             ; d6460012 00610912
	v_cvt_f32_f16_e32 v85, v14                                  ; 7eaa170e
	v_cvt_f32_f16_e32 v88, v17                                  ; 7eb01711
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f32_f16_e32 v21, v133/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2a1785
(invalid instruction)                                        ; cc0f0013
	v_min_num_f64_e32 v[1:2], v[5:6], v[17:18]                  ; 1a022305
	v_cvt_f32_f16_e32 v17, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221791
	v_cvt_f32_f16_e32 v5, v5                                    ; 7e0a1705
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[56:57], v[82:83], v[24:31] ; cc464018 1c62a538
(invalid instruction)                                        ; cc0f0014
	v_min_num_f64_e32 v[1:2], v[14:15], v[18:19]                ; 1a02250e
	v_cvt_f32_f16_e32 v14, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1c178e
	v_cvt_f32_f16_e32 v90, v18                                  ; 7eb41712
	v_cvt_f32_f16_e32 v18, v146/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e241792
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[22:23], v[82:83], v[32:39] ; cc464020 1c82a516
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v88, v17, vcc_lo                      ; 02022358
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v5, v21, vcc_lo                       ; 02022b05
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v85, v14, vcc_lo                      ; 02021d55
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v90, v18, vcc_lo                      ; 0202255a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cndmask_b32_e32 v91, v84, v89, vcc_lo                     ; 02b6b354
	v_permlanex16_b32 v91, v91, s25, s26 op_sel:[1,1]           ; d65c185b 0068335b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mov_b32 v14, v19 :: v_dual_cndmask_b32 v85, v89, v91 ; ca120113 0e54b759
	v_cndmask_b32_e32 v84, v91, v84, vcc_lo                     ; 02a8a95b
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[58:59], v[8:9], 0   ; cc464058 1a02113a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[22:23], v[84:85], v[48:55] ; cc464030 1cc2a916
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[56:57], v[84:85], v[40:47] ; cc464028 1ca2a938
	v_dual_mov_b32 v56, v20 :: v_dual_mov_b32 v5, v16           ; ca100114 38040110
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[58:59], v[12:13], 0 ; cc464010 1a02193a
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[60:61], v[10:11], v[88:95] ; cc464058 1d62153c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v57, v88                                  ; 7e721558
	v_cvt_f16_f32_e32 v59, v92                                  ; 7e76155c
(invalid instruction)                                        ; 7f76155d
(invalid instruction)                                        ; 7f721559
	v_cvt_f16_f32_e32 v82, v94                                  ; 7ea4155e
	v_cvt_f16_f32_e32 v58, v90                                  ; 7e74155a
(invalid instruction)                                        ; 7f74155b
(invalid instruction)                                        ; 7fa4155f
	v_pk_fma_f16 v59, v59, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603b 0bfdff3b 3ed62dbb
	v_pk_fma_f16 v57, v57, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6039 0bfdff39 3ed62dbb
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_pk_fma_f16 v58, v58, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603a 0bfdff3a 3ed62dbb
	v_pk_fma_f16 v82, v82, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6052 0bfdff52 3ed62dbb
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v23                               ; 0a002f3b
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v23                               ; 0a002f39
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v23                               ; 0a002f3a
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v23                               ; 0a002f52
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v22                               ; 0a002d3b
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v22                               ; 0a002d39
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v22                               ; 0a002d3a
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v22                               ; 0a002d52
	v_lshl_add_u32 v59, v59, 4, s24                             ; d646003b 0061093b
	v_lshl_add_u32 v57, v57, 4, s24                             ; d6460039 00610939
	v_lshl_add_u32 v58, v58, 4, s24                             ; d646003a 0061093a
	v_lshl_add_u32 v82, v82, 4, s24                             ; d6460052 00610952
	v_cvt_f32_f16_e32 v90, v59                                  ; 7eb4173b
(invalid instruction)                                        ; cc0f0053
	v_min_num_f64_e32 v[1:2], v[57:58], v[59:60]                ; 1a027739
	v_cvt_f32_f16_e32 v59, v187/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7617bb
	v_cvt_f32_f16_e32 v85, v185/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eaa17b9
	v_cvt_f32_f16_e32 v57, v57                                  ; 7e721739
	v_cvt_f32_f16_e32 v89, v58                                  ; 7eb2173a
(invalid instruction)                                        ; cc0f0054
	v_min_num_f64_e32 v[1:2], v[58:59], v[82:83]                ; 1a02a53a
	v_cvt_f32_f16_e32 v58, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7417ba
	v_cvt_f32_f16_e32 v92, v82                                  ; 7eb81752
	v_cvt_f32_f16_e32 v82, v210/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea417d2
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[60:61], v[6:7], v[16:23] ; cc464010 1c420d3c
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[86:87], v[83:84]                ; 1a02a756
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v90, v59, vcc_lo                      ; 0202775a
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v57, v85, vcc_lo                      ; 0202ab39
(invalid instruction)                                        ; cc0f0057
	v_min_num_f64_e32 v[1:2], v[87:88], v[84:85]                ; 1a02a957
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v89, v58, vcc_lo                      ; 02027559
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v92, v82, vcc_lo                      ; 0202a55c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cndmask_b32_e32 v93, v88, v91, vcc_lo                     ; 02bab758
	v_cvt_f16_f32_e32 v94, v16                                  ; 7ebc1510
	v_cvt_f16_f32_e32 v95, v18                                  ; 7ebe1512
(invalid instruction)                                        ; 7fbc1511
	v_cvt_f16_f32_e32 v16, v20                                  ; 7e201514
(invalid instruction)                                        ; 7f201515
(invalid instruction)                                        ; 7fbe1513
	v_cvt_f16_f32_e32 v17, v22                                  ; 7e221516
	v_permlanex16_b32 v93, v93, s25, s26 op_sel:[1,1]           ; d65c185d 0068335d
(invalid instruction)                                        ; 7f221517
	v_pk_fma_f16 v94, v94, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e605e 0bfdff5e 3ed62dbb
	v_pk_fma_f16 v16, v16, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6010 0bfdff10 3ed62dbb
	v_pk_fma_f16 v95, v95, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e605f 0bfdff5f 3ed62dbb
	v_dual_cndmask_b32 v59, v91, v93 :: v_dual_cndmask_b32 v58, v93, v88 ; ca52bb5b 3b3ab15d
	v_pk_fma_f16 v17, v17, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6011 0bfdff11 3ed62dbb
(invalid instruction)                                        ; cc1c005e
	v_subrev_f32_e32 v0, v94, v23                               ; 0a002f5e
(invalid instruction)                                        ; cc1c0010
	v_subrev_f32_e32 v0, v16, v23                               ; 0a002f10
(invalid instruction)                                        ; cc1c005f
	v_subrev_f32_e32 v0, v95, v23                               ; 0a002f5f
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[62:63], v[58:59], v[32:39] ; cc464020 1c82753e
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[64:65], v[58:59], v[24:31] ; cc464018 1c627540
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v23                               ; 0a002f11
(invalid instruction)                                        ; cc1b005e
	v_subrev_f32_e32 v0, v94, v22                               ; 0a002d5e
(invalid instruction)                                        ; cc1b0010
	v_subrev_f32_e32 v0, v16, v22                               ; 0a002d10
(invalid instruction)                                        ; cc1b005f
	v_subrev_f32_e32 v0, v95, v22                               ; 0a002d5f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b0011
	v_subrev_f32_e32 v0, v17, v22                               ; 0a002d11
	v_lshl_add_u32 v94, v94, 4, s24                             ; d646005e 0061095e
	v_lshl_add_u32 v16, v16, 4, s24                             ; d6460010 00610910
	v_lshl_add_u32 v95, v95, 4, s24                             ; d646005f 0061095f
	v_lshl_add_u32 v17, v17, 4, s24                             ; d6460011 00610911
	v_cvt_f32_f16_e32 v20, v222/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2817de
(invalid instruction)                                        ; cc0f0012
	v_min_num_f64_e32 v[1:2], v[94:95], v[16:17]                ; 1a02215e
	v_cvt_f32_f16_e32 v94, v94                                  ; 7ebc175e
	v_cvt_f32_f16_e32 v23, v16                                  ; 7e2e1710
	v_cvt_f32_f16_e32 v16, v144/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e201790
	v_cvt_f32_f16_e32 v22, v95                                  ; 7e2c175f
	v_cvt_f32_f16_e32 v58, v17                                  ; 7e741711
(invalid instruction)                                        ; cc0f0013
	v_min_num_f64_e32 v[1:2], v[95:96], v[17:18]                ; 1a02235f
	v_cvt_f32_f16_e32 v95, v223/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ebe17df
	v_cvt_f32_f16_e32 v17, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221791
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[18:19]                ; 1a02250e
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v94, v20, vcc_lo                      ; 0202295e
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v23, v16, vcc_lo                      ; 02022117
(invalid instruction)                                        ; cc0f0038
	v_min_num_f64_e32 v[1:2], v[56:57], v[19:20]                ; 1a022738
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v22, v95, vcc_lo                      ; 0202bf16
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v58, v17, vcc_lo                      ; 0202233a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cndmask_b32_e32 v59, v21, v57, vcc_lo                     ; 02767315
	v_permlanex16_b32 v59, v59, s25, s26 op_sel:[1,1]           ; d65c183b 0068333b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_cndmask_b32 v17, v57, v59 :: v_dual_cndmask_b32 v16, v59, v21 ; ca527739 11102b3b
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[62:63], v[16:17], v[48:55] ; cc464030 1cc2213e
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[64:65], v[16:17], v[40:47] ; cc464028 1ca22140
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[66:67], v[8:9], 0   ; cc464010 1a021142
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[68:69], v[10:11], v[16:23] ; cc464010 1c421544
	v_cvt_f16_f32_e32 v61, v18                                  ; 7e7a1512
	v_cvt_f16_f32_e32 v62, v20                                  ; 7e7c1514
(invalid instruction)                                        ; 7f7c1515
	v_cvt_f16_f32_e32 v63, v22                                  ; 7e7e1516
(invalid instruction)                                        ; 7f7a1513
	v_cvt_f16_f32_e32 v60, v16                                  ; 7e781510
(invalid instruction)                                        ; 7f781511
(invalid instruction)                                        ; 7f7e1517
	v_pk_fma_f16 v62, v62, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603e 0bfdff3e 3ed62dbb
	v_pk_fma_f16 v61, v61, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603d 0bfdff3d 3ed62dbb
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_pk_fma_f16 v60, v60, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603c 0bfdff3c 3ed62dbb
	v_pk_fma_f16 v63, v63, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603f 0bfdff3f 3ed62dbb
(invalid instruction)                                        ; cc1c003e
	v_subrev_f32_e32 v0, v62, v23                               ; 0a002f3e
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v23                               ; 0a002f3d
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v23                               ; 0a002f3c
(invalid instruction)                                        ; cc1c003f
	v_subrev_f32_e32 v0, v63, v23                               ; 0a002f3f
(invalid instruction)                                        ; cc1b003e
	v_subrev_f32_e32 v0, v62, v22                               ; 0a002d3e
(invalid instruction)                                        ; cc1b003d
	v_subrev_f32_e32 v0, v61, v22                               ; 0a002d3d
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v22                               ; 0a002d3c
(invalid instruction)                                        ; cc1b003f
	v_subrev_f32_e32 v0, v63, v22                               ; 0a002d3f
	v_lshl_add_u32 v62, v62, 4, s24                             ; d646003e 0061093e
	v_lshl_add_u32 v61, v61, 4, s24                             ; d646003d 0061093d
	v_lshl_add_u32 v60, v60, 4, s24                             ; d646003c 0061093c
	v_lshl_add_u32 v63, v63, 4, s24                             ; d646003f 0061093f
	v_cvt_f32_f16_e32 v85, v62                                  ; 7eaa173e
	v_cvt_f32_f16_e32 v84, v61                                  ; 7ea8173d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f32_f16_e32 v82, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea417bc
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[60:61], v[62:63]                ; 1a027d3c
	v_cvt_f32_f16_e32 v62, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7c17be
	v_cvt_f32_f16_e32 v60, v60                                  ; 7e78173c
	v_cvt_f32_f16_e32 v89, v63                                  ; 7eb2173f
(invalid instruction)                                        ; cc0f0041
	v_min_num_f64_e32 v[1:2], v[61:62], v[63:64]                ; 1a027f3d
	v_cvt_f32_f16_e32 v61, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7a17bd
	v_cvt_f32_f16_e32 v63, v191/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7e17bf
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[86:87], v[64:65]                ; 1a028156
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v85, v62, vcc_lo                      ; 02027d55
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v60, v82, vcc_lo                      ; 0202a53c
(invalid instruction)                                        ; cc0f0057
	v_min_num_f64_e32 v[1:2], v[87:88], v[65:66]                ; 1a028357
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v84, v61, vcc_lo                      ; 02027b54
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v89, v63, vcc_lo                      ; 02027f59
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cndmask_b32_e32 v90, v83, v88, vcc_lo                     ; 02b4b153
	v_permlanex16_b32 v90, v90, s25, s26 op_sel:[1,1]           ; d65c185a 0068335a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_cndmask_b32 v16, v90, v83 :: v_dual_cndmask_b32 v17, v88, v90 ; ca52a75a 1010b558
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[70:71], v[16:17], v[32:39] ; cc464020 1c822146
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[72:73], v[16:17], v[24:31] ; cc464018 1c622148
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[66:67], v[12:13], 0 ; cc464010 1a021942
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[68:69], v[6:7], v[16:23] ; cc464010 1c420d44
	v_cvt_f16_f32_e32 v94, v22                                  ; 7ebc1516
	v_cvt_f16_f32_e32 v92, v18                                  ; 7eb81512
(invalid instruction)                                        ; 7fb81513
	v_cvt_f16_f32_e32 v93, v20                                  ; 7eba1514
(invalid instruction)                                        ; 7fba1515
	v_cvt_f16_f32_e32 v91, v16                                  ; 7eb61510
(invalid instruction)                                        ; 7fb61511
(invalid instruction)                                        ; 7fbc1517
	v_pk_fma_f16 v92, v92, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e605c 0bfdff5c 3ed62dbb
	v_pk_fma_f16 v93, v93, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e605d 0bfdff5d 3ed62dbb
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_pk_fma_f16 v91, v91, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e605b 0bfdff5b 3ed62dbb
	v_pk_fma_f16 v94, v94, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e605e 0bfdff5e 3ed62dbb
(invalid instruction)                                        ; cc1c005c
	v_subrev_f32_e32 v0, v92, v23                               ; 0a002f5c
(invalid instruction)                                        ; cc1c005d
	v_subrev_f32_e32 v0, v93, v23                               ; 0a002f5d
(invalid instruction)                                        ; cc1c005b
	v_subrev_f32_e32 v0, v91, v23                               ; 0a002f5b
(invalid instruction)                                        ; cc1c005e
	v_subrev_f32_e32 v0, v94, v23                               ; 0a002f5e
(invalid instruction)                                        ; cc1b005c
	v_subrev_f32_e32 v0, v92, v22                               ; 0a002d5c
(invalid instruction)                                        ; cc1b005d
	v_subrev_f32_e32 v0, v93, v22                               ; 0a002d5d
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b005b
	v_subrev_f32_e32 v0, v91, v22                               ; 0a002d5b
(invalid instruction)                                        ; cc1b005e
	v_subrev_f32_e32 v0, v94, v22                               ; 0a002d5e
	v_lshl_add_u32 v92, v92, 4, s24                             ; d646005c 0061095c
	v_lshl_add_u32 v93, v93, 4, s24                             ; d646005d 0061095d
	v_lshl_add_u32 v91, v91, 4, s24                             ; d646005b 0061095b
	v_lshl_add_u32 v94, v94, 4, s24                             ; d646005e 0061095e
	v_cvt_f32_f16_e32 v19, v92                                  ; 7e26175c
	v_cvt_f32_f16_e32 v20, v93                                  ; 7e28175d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc0f005f
	v_min_num_f64_e32 v[1:2], v[91:92], v[93:94]                ; 1a02bb5b
	v_cvt_f32_f16_e32 v93, v221/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eba17dd
	v_cvt_f32_f16_e32 v17, v219/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2217db
	v_cvt_f32_f16_e32 v91, v91                                  ; 7eb6175b
(invalid instruction)                                        ; cc0f0010
	v_min_num_f64_e32 v[1:2], v[92:93], v[94:95]                ; 1a02bd5c
	v_cvt_f32_f16_e32 v92, v220/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eb817dc
	v_cvt_f32_f16_e32 v22, v94                                  ; 7e2c175e
	v_cvt_f32_f16_e32 v94, v222/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ebc17de
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[95:96]                ; 1a02bf0e
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v20, v93, vcc_lo                      ; 0202bb14
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v91, v17, vcc_lo                      ; 0202235b
(invalid instruction)                                        ; cc0f0038
	v_min_num_f64_e32 v[1:2], v[56:57], v[16:17]                ; 1a022138
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v19, v92, vcc_lo                      ; 0202b913
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v22, v94, vcc_lo                      ; 0202bd16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cndmask_b32_e32 v23, v18, v21, vcc_lo                     ; 022e2b12
	v_permlanex16_b32 v23, v23, s25, s26 op_sel:[1,1]           ; d65c1817 00683317
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_cndmask_b32 v17, v21, v23 :: v_dual_cndmask_b32 v16, v23, v18 ; ca522f15 11102517
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[72:73], v[16:17], v[40:47] ; cc464028 1ca22148
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[70:71], v[16:17], v[48:55] ; cc464030 1cc22146
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[74:75], v[8:9], 0   ; cc464010 1a02114a
	s_wait_loadcnt 0x2                                          ; bfc00002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[76:77], v[10:11], v[16:23] ; cc464010 1c42154c
	v_cvt_f16_f32_e32 v58, v18                                  ; 7e741512
	v_cvt_f16_f32_e32 v60, v22                                  ; 7e781516
	v_cvt_f16_f32_e32 v57, v16                                  ; 7e721510
(invalid instruction)                                        ; 7f721511
(invalid instruction)                                        ; 7f741513
	v_cvt_f16_f32_e32 v59, v20                                  ; 7e761514
(invalid instruction)                                        ; 7f761515
(invalid instruction)                                        ; 7f781517
	v_pk_fma_f16 v57, v57, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6039 0bfdff39 3ed62dbb
	v_pk_fma_f16 v58, v58, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603a 0bfdff3a 3ed62dbb
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_pk_fma_f16 v59, v59, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603b 0bfdff3b 3ed62dbb
	v_pk_fma_f16 v60, v60, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603c 0bfdff3c 3ed62dbb
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v23                               ; 0a002f39
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v23                               ; 0a002f3a
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v23                               ; 0a002f3b
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v23                               ; 0a002f3c
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v22                               ; 0a002d39
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v22                               ; 0a002d3a
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v22                               ; 0a002d3b
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v22                               ; 0a002d3c
	v_lshl_add_u32 v57, v57, 4, s24                             ; d6460039 00610939
	v_lshl_add_u32 v58, v58, 4, s24                             ; d646003a 0061093a
	v_lshl_add_u32 v59, v59, 4, s24                             ; d646003b 0061093b
	v_lshl_add_u32 v60, v60, 4, s24                             ; d646003c 0061093c
	v_cvt_f32_f16_e32 v69, v185/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8a17b9
	v_cvt_f32_f16_e32 v71, v58                                  ; 7e8e173a
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc0f003d
	v_min_num_f64_e32 v[1:2], v[57:58], v[59:60]                ; 1a027739
	v_cvt_f32_f16_e32 v57, v57                                  ; 7e721739
	v_cvt_f32_f16_e32 v72, v59                                  ; 7e90173b
	v_cvt_f32_f16_e32 v59, v187/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7617bb
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[58:59], v[60:61]                ; 1a02793a
	v_cvt_f32_f16_e32 v58, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7417ba
	v_cvt_f32_f16_e32 v82, v60                                  ; 7ea4173c
	v_cvt_f32_f16_e32 v60, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7817bc
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[86:87], v[61:62]                ; 1a027b56
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v57, v69, vcc_lo                      ; 02028b39
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                      ; 02027748
(invalid instruction)                                        ; cc0f0057
	v_min_num_f64_e32 v[1:2], v[87:88], v[62:63]                ; 1a027d57
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v71, v58, vcc_lo                      ; 02027547
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v82, v60, vcc_lo                      ; 02027952
	v_permlanex16_b32 v63, v86, s25, s26 op_sel:[1,1]           ; d65c183f 00683356
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_permlanex16_b32 v64, v87, s25, s26 op_sel:[1,1]           ; d65c1840 00683357
	v_cndmask_b32_e32 v83, v70, v73, vcc_lo                     ; 02a69346
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_cndmask_b32 v66, v64, v87 :: v_dual_cndmask_b32 v65, v63, v86 ; ca52af40 4240ad3f
	v_dual_cndmask_b32 v87, v87, v64 :: v_dual_cndmask_b32 v86, v86, v63 ; ca528157 57567f56
	v_permlanex16_b32 v83, v83, s25, s26 op_sel:[1,1]           ; d65c1853 00683353
(invalid instruction)                                        ; cc0f0041
	v_min_num_f64_e32 v[1:2], v[65:66], v[66:67]                ; 1a028541
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_cndmask_b32 v17, v73, v83 :: v_dual_cndmask_b32 v16, v83, v70 ; ca52a749 11108d53
(invalid instruction)                                        ; cc0f0041
	v_min_num_f64_e32 v[1:2], v[65:66], v[86:87]                ; 1a02ad41
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d2
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[78:79], v[16:17], v[24:31] ; cc464018 1c62214e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[80:81], v[16:17], v[32:39] ; cc464020 1c822150
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[74:75], v[12:13], 0 ; cc464010 1a02194a
(invalid instruction)                                        ; cc0f0041
	v_min_num_f64_e32 v[1:2], v[65:66], v[87:88]                ; 1a02af41
	v_add_f16_e32 v67, v65, v193/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64878341
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; 65888783
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[76:77], v[6:7], v[16:23] ; cc464010 1c420d4c
	v_cvt_f16_f32_e32 v86, v20                                  ; 7eac1514
	v_cvt_f16_f32_e32 v84, v16                                  ; 7ea81510
(invalid instruction)                                        ; 7fac1515
(invalid instruction)                                        ; 7fa81511
	v_cvt_f16_f32_e32 v85, v18                                  ; 7eaa1512
(invalid instruction)                                        ; 7faa1513
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_pk_fma_f16 v86, v86, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6056 0bfdff56 3ed62dbb
	v_cvt_f16_f32_e32 v87, v22                                  ; 7eae1516
	v_pk_fma_f16 v84, v84, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6054 0bfdff54 3ed62dbb
(invalid instruction)                                        ; 7fae1517
	v_pk_fma_f16 v85, v85, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6055 0bfdff55 3ed62dbb
(invalid instruction)                                        ; cc1c0056
	v_subrev_f32_e32 v0, v86, v23                               ; 0a002f56
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c0054
	v_subrev_f32_e32 v0, v84, v23                               ; 0a002f54
	v_pk_fma_f16 v87, v87, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6057 0bfdff57 3ed62dbb
(invalid instruction)                                        ; cc1c0055
	v_subrev_f32_e32 v0, v85, v23                               ; 0a002f55
(invalid instruction)                                        ; cc1b0056
	v_subrev_f32_e32 v0, v86, v22                               ; 0a002d56
(invalid instruction)                                        ; cc1b0054
	v_subrev_f32_e32 v0, v84, v22                               ; 0a002d54
(invalid instruction)                                        ; cc1c0057
	v_subrev_f32_e32 v0, v87, v23                               ; 0a002f57
(invalid instruction)                                        ; cc1b0055
	v_subrev_f32_e32 v0, v85, v22                               ; 0a002d55
	v_lshl_add_u32 v86, v86, 4, s24                             ; d6460056 00610956
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_lshl_add_u32 v84, v84, 4, s24                             ; d6460054 00610954
(invalid instruction)                                        ; cc1b0057
	v_subrev_f32_e32 v0, v87, v22                               ; 0a002d57
	v_lshl_add_u32 v85, v85, 4, s24                             ; d6460055 00610955
	v_cvt_f32_f16_e32 v95, v212/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ebe17d4
(invalid instruction)                                        ; cc0f0058
	v_min_num_f64_e32 v[1:2], v[84:85], v[86:87]                ; 1a02ad54
	v_cvt_f32_f16_e32 v84, v84                                  ; 7ea81754
	v_lshl_add_u32 v87, v87, 4, s24                             ; d6460057 00610957
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[88:89]                ; 1a02b10e
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v84, v95, vcc_lo                      ; 0202bf54
(invalid instruction)                                        ; cc0f0059
	v_min_num_f64_e32 v[1:2], v[85:86], v[87:88]                ; 1a02af55
	v_permlanex16_b32 v90, v14, s25, s26 op_sel:[1,1]           ; d65c185a 0068330e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; cc0f0038
	v_min_num_f64_e32 v[1:2], v[56:57], v[89:90]                ; 1a02b338
	v_cvt_f32_f16_e32 v17, v87                                  ; 7e221757
	v_cvt_f32_f16_e32 v87, v215/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eae17d7
	v_cndmask_b32_e32 v92, v90, v14, vcc_lo                     ; 02b81d5a
	v_cndmask_b32_e32 v14, v14, v90, vcc_lo                     ; 021cb50e
	v_permlanex16_b32 v91, v56, s25, s26 op_sel:[1,1]           ; d65c185b 00683338
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_cndmask_b32 v93, v91, v56 :: v_dual_cndmask_b32 v56, v56, v91 ; ca52715b 5d38b738
(invalid instruction)                                        ; cc0f005c
	v_min_num_f64_e32 v[1:2], v[92:93], v[93:94]                ; 1a02bb5c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f005c
	v_min_num_f64_e32 v[1:2], v[92:93], v[14:15]                ; 1a021d5c
	v_cvt_f32_f16_e32 v14, v86                                  ; 7e1c1756
	v_cvt_f32_f16_e32 v86, v214/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eac17d6
(invalid instruction)                                        ; cc0f005c
	v_min_num_f64_e32 v[1:2], v[92:93], v[56:57]                ; 1a02715c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v14, v86, vcc_lo                      ; 0202ad0e
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v17, v87, vcc_lo                      ; 0202af11
	v_add_f16_e32 v94, v92, v220/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64bdb95c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_add_f16_e32 v68, v3, v94                                  ; 6488bd03
	v_cvt_f32_f16_e32 v3, v85                                   ; 7e061755
	v_cvt_f32_f16_e32 v85, v213/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eaa17d5
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v3, v85, vcc_lo                       ; 0202ab03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cndmask_b32_e32 v18, v95, v16, vcc_lo                     ; 0224215f
	v_permlanex16_b32 v18, v18, s25, s26 op_sel:[1,1]           ; d65c1812 00683312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_cndmask_b32_e32 v20, v18, v95, vcc_lo                     ; 0228bf12
	v_dual_cndmask_b32 v21, v16, v18 :: v_dual_mov_b32 v16, v5  ; ca502510 15100105
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[80:81], v[20:21], v[48:55] ; cc464030 1cc22950
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[78:79], v[20:21], v[40:47] ; cc464028 1ca2294e
	s_branch BB25                                               ; bfa0042e
BB12:
	s_cmp_lt_u32 s13, s3                                        ; bf0a030d
	s_cbranch_scc0 BB14                                         ; bfa10018
BB13:
	s_mul_i32 s17, s13, 0xc00                                   ; 9611ff0d 00000c00
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s7, s17                                   ; 80111107
	s_add_co_u32 s18, 0x4000, s14                               ; 80120eff 00004000
	s_add_co_u32 s19, 0x4100, s14                               ; 80130eff 00004100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v5, v2, s17, s18                                 ; d6550005 00482302
	v_add3_u32 v14, v2, s17, s19                                ; d655000e 004c2302
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v5, v5, v4                                 ; 4a0a0905
	v_add_nc_u32_e32 v14, v14, v4                               ; 4a1c090e
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[18:19], v5, s[8:11], null offen           ; c405407c 40801012 00000005
	buffer_load_b64 v[20:21], v14, s[8:11], null offen          ; c405407c 40801014 0000000e
	s_branch BB15                                               ; bfa00004
BB14:
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
BB15:
	v_lshrrev_b32_e32 v5, 3, v0                                 ; 320a0083
	s_min_u32 s17, s13, s12                                     ; 89910c0d
	s_mov_b32 s19, 0xf0f0f0f0                                   ; be9300ff f0f0f0f0
	s_sext_i32_i16 s23, s21                                     ; be970f15
	s_mov_b32 s22, s20                                          ; be960014
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mulk_i32 s17, 0xc00                                       ; b8110c00
	v_cndmask_b32_e64 v17, 0, 8, s19                            ; d5010011 004d1080
	v_lshl_add_u32 v5, v5, 2, v15                               ; d6460005 043d0505
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s7, s17                                   ; 80111107
	s_add_co_u32 s18, 0x8000, s14                               ; 80120eff 00008000
	s_add_co_u32 s24, 0x8100, s14                               ; 80180eff 00008100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshlrev_b32_e32 v5, 4, v5                                 ; 300a0a84
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v14, v5, s17, s18                                ; d655000e 00482305
	v_add3_u32 v22, v5, s17, s24                                ; d6550016 00602305
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v17                              ; 4a1c230e
	v_add_nc_u32_e32 v22, v22, v17                              ; 4a2c2316
	s_clause 0x1                                                ; bf850001
	global_load_tr_b64 v[56:57], v14, s[22:23]                  ; ee160016 00000038 0000000e
	global_load_tr_b64 v[22:23], v22, s[22:23]                  ; ee160016 00000016 00000016
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[18:19], v[8:9], 0   ; cc464040 1a021112
	s_movk_i32 s25, 0x3fe9                                      ; b0193fe9
	s_movk_i32 s26, 0x3dc2                                      ; b01a3dc2
	s_wait_loadcnt 0x2                                          ; bfc00002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[10:11], v[64:71] ; cc464040 1d021514
	v_cvt_f16_f32_e32 v60, v68                                  ; 7e781544
	v_cvt_f16_f32_e32 v59, v66                                  ; 7e761542
(invalid instruction)                                        ; 7f781545
(invalid instruction)                                        ; 7f761543
	v_cvt_f16_f32_e32 v61, v70                                  ; 7e7a1546
	v_cvt_f16_f32_e32 v58, v64                                  ; 7e741540
(invalid instruction)                                        ; 7f741541
(invalid instruction)                                        ; 7f7a1547
	s_mov_b32 s27, 0x3ffc4000                                   ; be9b00ff 3ffc4000
	s_mov_b32 s28, 0x76543210                                   ; be9c00ff 76543210
	s_mov_b32 s29, 0xfedcba98                                   ; be9d00ff fedcba98
	v_pk_fma_f16 v60, v60, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603c 0bfdff3c 3ed62dbb
	v_pk_fma_f16 v59, v59, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603b 0bfdff3b 3ed62dbb
	v_pk_fma_f16 v58, v58, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603a 0bfdff3a 3ed62dbb
	v_pk_fma_f16 v61, v61, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603d 0bfdff3d 3ed62dbb
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v26                               ; 0a00353c
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v26                               ; 0a00353b
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v26                               ; 0a00353a
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v26                               ; 0a00353d
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v25                               ; 0a00333c
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v25                               ; 0a00333b
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v25                               ; 0a00333a
(invalid instruction)                                        ; cc1b003d
	v_subrev_f32_e32 v0, v61, v25                               ; 0a00333d
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_lshl_add_u32 v60, v60, 4, s27                             ; d646003c 006d093c
	v_lshl_add_u32 v59, v59, 4, s27                             ; d646003b 006d093b
	v_lshl_add_u32 v58, v58, 4, s27                             ; d646003a 006d093a
	v_lshl_add_u32 v61, v61, 4, s27                             ; d646003d 006d093d
	v_permlanex16_b32 v64, v60, s28, s29 op_sel:[1,1]           ; d65c1840 0074393c
	v_cvt_f32_f16_e32 v68, v60                                  ; 7e88173c
	v_cvt_f32_f16_e32 v67, v59                                  ; 7e86173b
	v_permlanex16_b32 v63, v59, s28, s29 op_sel:[1,1]           ; d65c183f 0074393b
	v_cvt_f32_f16_e32 v66, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8417ba
	v_permlanex16_b32 v62, v58, s28, s29 op_sel:[1,1]           ; d65c183e 0074393a
	v_permlanex16_b32 v65, v61, s28, s29 op_sel:[1,1]           ; d65c1841 0074393d
	v_cvt_f32_f16_e32 v69, v61                                  ; 7e8a173d
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[18:19], v[12:13], 0 ; cc464048 1a021912
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[60:61], v[64:65]                ; 1a02813c
	v_cvt_f32_f16_e32 v60, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7817bc
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[59:60], v[63:64]                ; 1a027f3b
	v_cvt_f32_f16_e32 v59, v187/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7617bb
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[58:59], v[62:63]                ; 1a027d3a
	v_cvt_f32_f16_e32 v58, v58                                  ; 7e74173a
(invalid instruction)                                        ; cc0f0041
	v_min_num_f64_e32 v[1:2], v[61:62], v[65:66]                ; 1a02833d
	v_cvt_f32_f16_e32 v61, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7a17bd
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870153
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v58, v66, vcc_lo                      ; 0202853a
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v67, v59, vcc_lo                      ; 02027743
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v68, v60, vcc_lo                      ; 02027944
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[20:21], v[6:7], v[72:79] ; cc464048 1d220d14
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v69, v61, vcc_lo                      ; 02027b45
	v_cvt_f16_f32_e32 v70, v72                                  ; 7e8c1548
	v_cvt_f16_f32_e32 v72, v76                                  ; 7e90154c
(invalid instruction)                                        ; 7f90154d
	v_cvt_f16_f32_e32 v71, v74                                  ; 7e8e154a
(invalid instruction)                                        ; 7f8e154b
(invalid instruction)                                        ; 7f8c1549
	v_cvt_f16_f32_e32 v73, v78                                  ; 7e92154e
(invalid instruction)                                        ; 7f92154f
	v_pk_fma_f16 v72, v72, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6048 0bfdff48 3ed62dbb
	v_pk_fma_f16 v71, v71, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6047 0bfdff47 3ed62dbb
	v_pk_fma_f16 v70, v70, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6046 0bfdff46 3ed62dbb
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_pk_fma_f16 v73, v73, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6049 0bfdff49 3ed62dbb
(invalid instruction)                                        ; cc1c0048
	v_subrev_f32_e32 v0, v72, v26                               ; 0a003548
(invalid instruction)                                        ; cc1c0047
	v_subrev_f32_e32 v0, v71, v26                               ; 0a003547
(invalid instruction)                                        ; cc1c0046
	v_subrev_f32_e32 v0, v70, v26                               ; 0a003546
(invalid instruction)                                        ; cc1c0049
	v_subrev_f32_e32 v0, v73, v26                               ; 0a003549
(invalid instruction)                                        ; cc1b0048
	v_subrev_f32_e32 v0, v72, v25                               ; 0a003348
(invalid instruction)                                        ; cc1b0047
	v_subrev_f32_e32 v0, v71, v25                               ; 0a003347
(invalid instruction)                                        ; cc1b0046
	v_subrev_f32_e32 v0, v70, v25                               ; 0a003346
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b0049
	v_subrev_f32_e32 v0, v73, v25                               ; 0a003349
	v_lshl_add_u32 v72, v72, 4, s27                             ; d6460048 006d0948
	v_lshl_add_u32 v71, v71, 4, s27                             ; d6460047 006d0947
	v_lshl_add_u32 v70, v70, 4, s27                             ; d6460046 006d0946
	v_lshl_add_u32 v73, v73, 4, s27                             ; d6460049 006d0949
	v_cvt_f32_f16_e32 v80, v72                                  ; 7ea01748
	v_permlanex16_b32 v76, v72, s28, s29 op_sel:[1,1]           ; d65c184c 00743948
	v_permlanex16_b32 v75, v71, s28, s29 op_sel:[1,1]           ; d65c184b 00743947
	v_cvt_f32_f16_e32 v79, v71                                  ; 7e9e1747
	v_cvt_f32_f16_e32 v78, v198/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e9c17c6
	v_permlanex16_b32 v74, v70, s28, s29 op_sel:[1,1]           ; d65c184a 00743946
	v_cvt_f32_f16_e32 v81, v73                                  ; 7ea21749
	v_permlanex16_b32 v77, v73, s28, s29 op_sel:[1,1]           ; d65c184d 00743949
	s_add_co_u32 s30, s13, 16                                   ; 801e900d
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[72:73], v[76:77]                ; 1a029948
	v_cvt_f32_f16_e32 v72, v200/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e9017c8
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[71:72], v[75:76]                ; 1a029747
	v_cvt_f32_f16_e32 v71, v199/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8e17c7
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[70:71], v[74:75]                ; 1a029546
	v_cvt_f32_f16_e32 v70, v70                                  ; 7e8c1746
	s_cmp_lt_u32 s30, s3                                        ; bf0a031e
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[73:74], v[77:78]                ; 1a029b49
	v_cvt_f32_f16_e32 v73, v201/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e9217c9
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v80, v72, vcc_lo                      ; 02029150
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v70, v78, vcc_lo                      ; 02029d46
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v79, v71, vcc_lo                      ; 02028f4f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v81, v73, vcc_lo                      ; 02029351
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[56:57], v[66:67], v[24:31] ; cc464018 1c628538
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[56:57], v[18:19], v[40:47] ; cc464028 1ca22538
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[22:23], v[18:19], v[48:55] ; cc464030 1cc22516
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[22:23], v[66:67], v[32:39] ; cc464020 1c828516
	s_cbranch_scc0 BB17                                         ; bfa10018
BB16:
	s_mul_i32 s17, s30, 0xc00                                   ; 9611ff1e 00000c00
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s7, s17                                   ; 80111107
	s_add_co_u32 s19, 0x4000, s14                               ; 80130eff 00004000
	s_add_co_u32 s25, 0x4100, s14                               ; 80190eff 00004100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v14, v2, s17, s19                                ; d655000e 004c2302
	v_add3_u32 v18, v2, s17, s25                                ; d6550012 00642302
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v4                               ; 4a1c090e
	v_add_nc_u32_e32 v18, v18, v4                               ; 4a240912
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[20:21], v14, s[8:11], null offen          ; c405407c 40801014 0000000e
	buffer_load_b64 v[18:19], v18, s[8:11], null offen          ; c405407c 40801012 00000012
	s_branch BB18                                               ; bfa00004
BB17:
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
BB18:
	s_min_u32 s17, s30, s12                                     ; 89910c1e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mulk_i32 s17, 0xc00                                       ; b8110c00
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s7, s17                                   ; 80111107
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v14, v5, s17, s18                                ; d655000e 00482305
	v_add3_u32 v22, v5, s17, s24                                ; d6550016 00602305
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v17                              ; 4a1c230e
	v_add_nc_u32_e32 v22, v22, v17                              ; 4a2c2316
	s_clause 0x1                                                ; bf850001
	global_load_tr_b64 v[56:57], v14, s[22:23]                  ; ee160016 00000038 0000000e
	global_load_tr_b64 v[22:23], v22, s[22:23]                  ; ee160016 00000016 00000016
	s_movk_i32 s19, 0x3dc2                                      ; b0133dc2
	s_movk_i32 s25, 0x3fe9                                      ; b0193fe9
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[8:9], 0   ; cc464050 1a021114
	s_wait_loadcnt 0x2                                          ; bfc00002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[10:11], v[80:87] ; cc464050 1d421512
	v_cvt_f16_f32_e32 v59, v82                                  ; 7e761552
(invalid instruction)                                        ; 7f761553
	v_cvt_f16_f32_e32 v60, v84                                  ; 7e781554
(invalid instruction)                                        ; 7f781555
	v_cvt_f16_f32_e32 v61, v86                                  ; 7e7a1556
	v_cvt_f16_f32_e32 v58, v80                                  ; 7e741550
(invalid instruction)                                        ; 7f741551
(invalid instruction)                                        ; 7f7a1557
	s_mov_b32 s26, 0x3ffc4000                                   ; be9a00ff 3ffc4000
	v_pk_fma_f16 v59, v59, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603b 0bfdff3b 3ed62dbb
	s_mov_b32 s27, 0x76543210                                   ; be9b00ff 76543210
	s_mov_b32 s28, 0xfedcba98                                   ; be9c00ff fedcba98
	v_pk_fma_f16 v60, v60, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603c 0bfdff3c 3ed62dbb
	v_pk_fma_f16 v58, v58, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603a 0bfdff3a 3ed62dbb
	v_pk_fma_f16 v61, v61, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603d 0bfdff3d 3ed62dbb
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v19                               ; 0a00273b
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v19                               ; 0a00273c
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v19                               ; 0a00273a
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v19                               ; 0a00273d
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v25                               ; 0a00333b
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v25                               ; 0a00333c
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v25                               ; 0a00333a
(invalid instruction)                                        ; cc1b003d
	v_subrev_f32_e32 v0, v61, v25                               ; 0a00333d
	v_lshl_add_u32 v59, v59, 4, s26                             ; d646003b 0069093b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_lshl_add_u32 v60, v60, 4, s26                             ; d646003c 0069093c
	v_lshl_add_u32 v58, v58, 4, s26                             ; d646003a 0069093a
	v_lshl_add_u32 v61, v61, 4, s26                             ; d646003d 0069093d
	v_cvt_f32_f16_e32 v72, v59                                  ; 7e90173b
	v_permlanex16_b32 v67, v59, s27, s28 op_sel:[1,1]           ; d65c1843 0070373b
	v_permlanex16_b32 v68, v60, s27, s28 op_sel:[1,1]           ; d65c1844 0070373c
	v_cvt_f32_f16_e32 v73, v60                                  ; 7e92173c
	v_cvt_f32_f16_e32 v70, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8c17ba
	v_permlanex16_b32 v66, v58, s27, s28 op_sel:[1,1]           ; d65c1842 0070373a
	v_permlanex16_b32 v69, v61, s27, s28 op_sel:[1,1]           ; d65c1845 0070373d
	v_cvt_f32_f16_e32 v79, v61                                  ; 7e9e173d
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[59:60], v[67:68]                ; 1a02873b
	v_cvt_f32_f16_e32 v59, v187/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7617bb
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[60:61], v[68:69]                ; 1a02893c
	v_cvt_f32_f16_e32 v60, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7817bc
	s_cmp_ge_u32 s30, s3                                        ; bf09031e
(invalid instruction)                                        ; cc0f0042
	v_min_num_f64_e32 v[1:2], v[58:59], v[66:67]                ; 1a02853a
	v_cvt_f32_f16_e32 v58, v58                                  ; 7e74173a
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[61:62], v[69:70]                ; 1a028b3d
	v_cvt_f32_f16_e32 v61, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7a17bd
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[12:13], 0 ; cc464050 1a021914
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[67:68]                ; 1a02873f
	s_cselect_b32 s29, -1, 0                                    ; 981d80c1
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[64:65], v[68:69]                ; 1a028940
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v73, v60, vcc_lo                      ; 02027949
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[66:67]                ; 1a02853e
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v58, v70, vcc_lo                      ; 02028d3a
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                      ; 02027748
(invalid instruction)                                        ; cc0f0041
	v_min_num_f64_e32 v[1:2], v[65:66], v[69:70]                ; 1a028b41
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v79, v61, vcc_lo                      ; 02027b4f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[6:7], v[80:87] ; cc464050 1d420d12
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v58, v71, 0, s29                          ; d501003a 00750147
	v_cndmask_b32_e64 v59, v78, 0, s29                          ; d501003b 0075014e
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_cvt_f16_f32_e32 v80, v80                                  ; 7ea01550
(invalid instruction)                                        ; 7fa01551
	v_cvt_f16_f32_e32 v81, v82                                  ; 7ea21552
(invalid instruction)                                        ; 7fa21553
	v_cvt_f16_f32_e32 v83, v86                                  ; 7ea61556
	v_cvt_f16_f32_e32 v82, v84                                  ; 7ea41554
(invalid instruction)                                        ; 7fa41555
(invalid instruction)                                        ; 7fa61557
	v_pk_fma_f16 v80, v80, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6050 0bfdff50 3ed62dbb
	v_pk_fma_f16 v81, v81, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6051 0bfdff51 3ed62dbb
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_pk_fma_f16 v82, v82, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6052 0bfdff52 3ed62dbb
	v_pk_fma_f16 v83, v83, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6053 0bfdff53 3ed62dbb
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v19                               ; 0a002750
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v19                               ; 0a002751
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v19                               ; 0a002752
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v19                               ; 0a002753
(invalid instruction)                                        ; cc1b0050
	v_subrev_f32_e32 v0, v80, v25                               ; 0a003350
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v25                               ; 0a003351
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v25                               ; 0a003352
(invalid instruction)                                        ; cc1b0053
	v_subrev_f32_e32 v0, v83, v25                               ; 0a003353
	v_lshl_add_u32 v80, v80, 4, s26                             ; d6460050 00690950
	v_lshl_add_u32 v81, v81, 4, s26                             ; d6460051 00690951
	v_lshl_add_u32 v82, v82, 4, s26                             ; d6460052 00690952
	v_lshl_add_u32 v83, v83, 4, s26                             ; d6460053 00690953
	v_cvt_f32_f16_e32 v88, v208/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eb017d0
	v_permlanex16_b32 v84, v80, s27, s28 op_sel:[1,1]           ; d65c1854 00703750
	v_permlanex16_b32 v85, v81, s27, s28 op_sel:[1,1]           ; d65c1855 00703751
	v_cvt_f32_f16_e32 v90, v81                                  ; 7eb41751
	v_cvt_f32_f16_e32 v91, v82                                  ; 7eb61752
	v_permlanex16_b32 v86, v82, s27, s28 op_sel:[1,1]           ; d65c1856 00703752
	v_permlanex16_b32 v87, v83, s27, s28 op_sel:[1,1]           ; d65c1857 00703753
	v_cvt_f32_f16_e32 v93, v83                                  ; 7eba1753
(invalid instruction)                                        ; cc0f0054
	v_min_num_f64_e32 v[1:2], v[80:81], v[84:85]                ; 1a02a950
	v_cvt_f32_f16_e32 v80, v80                                  ; 7ea01750
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[81:82], v[85:86]                ; 1a02ab51
	v_cvt_f32_f16_e32 v81, v209/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea217d1
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[82:83], v[86:87]                ; 1a02ad52
	v_cvt_f32_f16_e32 v82, v210/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea417d2
	s_add_co_u32 s30, s13, 32                                   ; 801ea00d
(invalid instruction)                                        ; cc0f0057
	v_min_num_f64_e32 v[1:2], v[83:84], v[87:88]                ; 1a02af53
	v_cvt_f32_f16_e32 v83, v211/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea617d3
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[84:85]                ; 1a02a94a
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v80, v88, vcc_lo                      ; 0202b150
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[85:86]                ; 1a02ab4b
	s_cmp_lt_u32 s30, s3                                        ; bf0a031e
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v90, v81, vcc_lo                      ; 0202a35a
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[86:87]                ; 1a02ad4c
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v91, v82, vcc_lo                      ; 0202a55b
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[87:88]                ; 1a02af4d
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v93, v83, vcc_lo                      ; 0202a75d
	v_cndmask_b32_e64 v18, v89, 0, s29                          ; d5010012 00750159
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_cndmask_b32_e64 v19, v92, 0, s29                          ; d5010013 0075015c
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[56:57], v[18:19], v[40:47] ; cc464028 1ca22538
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[56:57], v[58:59], v[24:31] ; cc464018 1c627538
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[22:23], v[58:59], v[32:39] ; cc464020 1c827516
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[22:23], v[18:19], v[48:55] ; cc464030 1cc22516
	s_cbranch_scc0 BB20                                         ; bfa10018
BB19:
	s_mul_i32 s17, s30, 0xc00                                   ; 9611ff1e 00000c00
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s7, s17                                   ; 80111107
	s_add_co_u32 s19, 0x4000, s14                               ; 80130eff 00004000
	s_add_co_u32 s25, 0x4100, s14                               ; 80190eff 00004100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v14, v2, s17, s19                                ; d655000e 004c2302
	v_add3_u32 v18, v2, s17, s25                                ; d6550012 00642302
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v4                               ; 4a1c090e
	v_add_nc_u32_e32 v18, v18, v4                               ; 4a240912
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[20:21], v14, s[8:11], null offen          ; c405407c 40801014 0000000e
	buffer_load_b64 v[18:19], v18, s[8:11], null offen          ; c405407c 40801012 00000012
	s_branch BB21                                               ; bfa00004
BB20:
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
BB21:
	s_min_u32 s17, s30, s12                                     ; 89910c1e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mulk_i32 s17, 0xc00                                       ; b8110c00
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s7, s17                                   ; 80111107
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v14, v5, s17, s18                                ; d655000e 00482305
	v_add3_u32 v22, v5, s17, s24                                ; d6550016 00602305
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v17                              ; 4a1c230e
	v_add_nc_u32_e32 v22, v22, v17                              ; 4a2c2316
	s_clause 0x1                                                ; bf850001
	global_load_tr_b64 v[56:57], v14, s[22:23]                  ; ee160016 00000038 0000000e
	global_load_tr_b64 v[22:23], v22, s[22:23]                  ; ee160016 00000016 00000016
	s_movk_i32 s19, 0x3dc2                                      ; b0133dc2
	s_movk_i32 s25, 0x3fe9                                      ; b0193fe9
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[8:9], 0   ; cc464050 1a021114
	s_wait_loadcnt 0x2                                          ; bfc00002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[10:11], v[80:87] ; cc464050 1d421512
	v_cvt_f16_f32_e32 v59, v82                                  ; 7e761552
(invalid instruction)                                        ; 7f761553
	v_cvt_f16_f32_e32 v60, v84                                  ; 7e781554
(invalid instruction)                                        ; 7f781555
	v_cvt_f16_f32_e32 v61, v86                                  ; 7e7a1556
	v_cvt_f16_f32_e32 v58, v80                                  ; 7e741550
(invalid instruction)                                        ; 7f741551
(invalid instruction)                                        ; 7f7a1557
	s_mov_b32 s26, 0x3ffc4000                                   ; be9a00ff 3ffc4000
	v_pk_fma_f16 v59, v59, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603b 0bfdff3b 3ed62dbb
	s_mov_b32 s27, 0x76543210                                   ; be9b00ff 76543210
	s_mov_b32 s28, 0xfedcba98                                   ; be9c00ff fedcba98
	v_pk_fma_f16 v60, v60, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603c 0bfdff3c 3ed62dbb
	v_pk_fma_f16 v58, v58, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603a 0bfdff3a 3ed62dbb
	v_pk_fma_f16 v61, v61, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603d 0bfdff3d 3ed62dbb
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v19                               ; 0a00273b
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v19                               ; 0a00273c
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v19                               ; 0a00273a
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v19                               ; 0a00273d
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v25                               ; 0a00333b
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v25                               ; 0a00333c
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v25                               ; 0a00333a
(invalid instruction)                                        ; cc1b003d
	v_subrev_f32_e32 v0, v61, v25                               ; 0a00333d
	v_lshl_add_u32 v59, v59, 4, s26                             ; d646003b 0069093b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_lshl_add_u32 v60, v60, 4, s26                             ; d646003c 0069093c
	v_lshl_add_u32 v58, v58, 4, s26                             ; d646003a 0069093a
	v_lshl_add_u32 v61, v61, 4, s26                             ; d646003d 0069093d
	v_cvt_f32_f16_e32 v72, v59                                  ; 7e90173b
	v_permlanex16_b32 v67, v59, s27, s28 op_sel:[1,1]           ; d65c1843 0070373b
	v_permlanex16_b32 v68, v60, s27, s28 op_sel:[1,1]           ; d65c1844 0070373c
	v_cvt_f32_f16_e32 v73, v60                                  ; 7e92173c
	v_cvt_f32_f16_e32 v70, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8c17ba
	v_permlanex16_b32 v66, v58, s27, s28 op_sel:[1,1]           ; d65c1842 0070373a
	v_permlanex16_b32 v69, v61, s27, s28 op_sel:[1,1]           ; d65c1845 0070373d
	v_cvt_f32_f16_e32 v79, v61                                  ; 7e9e173d
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[59:60], v[67:68]                ; 1a02873b
	v_cvt_f32_f16_e32 v59, v187/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7617bb
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[60:61], v[68:69]                ; 1a02893c
	v_cvt_f32_f16_e32 v60, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7817bc
	s_cmp_ge_u32 s30, s3                                        ; bf09031e
(invalid instruction)                                        ; cc0f0042
	v_min_num_f64_e32 v[1:2], v[58:59], v[66:67]                ; 1a02853a
	v_cvt_f32_f16_e32 v58, v58                                  ; 7e74173a
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[61:62], v[69:70]                ; 1a028b3d
	v_cvt_f32_f16_e32 v61, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7a17bd
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[12:13], 0 ; cc464050 1a021914
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[67:68]                ; 1a02873f
	s_cselect_b32 s29, -1, 0                                    ; 981d80c1
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[64:65], v[68:69]                ; 1a028940
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v73, v60, vcc_lo                      ; 02027949
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[66:67]                ; 1a02853e
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v58, v70, vcc_lo                      ; 02028d3a
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                      ; 02027748
(invalid instruction)                                        ; cc0f0041
	v_min_num_f64_e32 v[1:2], v[65:66], v[69:70]                ; 1a028b41
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v79, v61, vcc_lo                      ; 02027b4f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[6:7], v[80:87] ; cc464050 1d420d12
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v58, v71, 0, s29                          ; d501003a 00750147
	v_cndmask_b32_e64 v59, v78, 0, s29                          ; d501003b 0075014e
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_cvt_f16_f32_e32 v80, v80                                  ; 7ea01550
(invalid instruction)                                        ; 7fa01551
	v_cvt_f16_f32_e32 v81, v82                                  ; 7ea21552
(invalid instruction)                                        ; 7fa21553
	v_cvt_f16_f32_e32 v83, v86                                  ; 7ea61556
	v_cvt_f16_f32_e32 v82, v84                                  ; 7ea41554
(invalid instruction)                                        ; 7fa41555
(invalid instruction)                                        ; 7fa61557
	v_pk_fma_f16 v80, v80, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6050 0bfdff50 3ed62dbb
	v_pk_fma_f16 v81, v81, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6051 0bfdff51 3ed62dbb
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_pk_fma_f16 v82, v82, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6052 0bfdff52 3ed62dbb
	v_pk_fma_f16 v83, v83, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6053 0bfdff53 3ed62dbb
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v19                               ; 0a002750
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v19                               ; 0a002751
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v19                               ; 0a002752
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v19                               ; 0a002753
(invalid instruction)                                        ; cc1b0050
	v_subrev_f32_e32 v0, v80, v25                               ; 0a003350
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v25                               ; 0a003351
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v25                               ; 0a003352
(invalid instruction)                                        ; cc1b0053
	v_subrev_f32_e32 v0, v83, v25                               ; 0a003353
	v_lshl_add_u32 v80, v80, 4, s26                             ; d6460050 00690950
	v_lshl_add_u32 v81, v81, 4, s26                             ; d6460051 00690951
	v_lshl_add_u32 v82, v82, 4, s26                             ; d6460052 00690952
	v_lshl_add_u32 v83, v83, 4, s26                             ; d6460053 00690953
	v_cvt_f32_f16_e32 v88, v208/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eb017d0
	v_permlanex16_b32 v84, v80, s27, s28 op_sel:[1,1]           ; d65c1854 00703750
	v_permlanex16_b32 v85, v81, s27, s28 op_sel:[1,1]           ; d65c1855 00703751
	v_cvt_f32_f16_e32 v90, v81                                  ; 7eb41751
	v_cvt_f32_f16_e32 v91, v82                                  ; 7eb61752
	v_permlanex16_b32 v86, v82, s27, s28 op_sel:[1,1]           ; d65c1856 00703752
	v_permlanex16_b32 v87, v83, s27, s28 op_sel:[1,1]           ; d65c1857 00703753
	v_cvt_f32_f16_e32 v93, v83                                  ; 7eba1753
(invalid instruction)                                        ; cc0f0054
	v_min_num_f64_e32 v[1:2], v[80:81], v[84:85]                ; 1a02a950
	v_cvt_f32_f16_e32 v80, v80                                  ; 7ea01750
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[81:82], v[85:86]                ; 1a02ab51
	v_cvt_f32_f16_e32 v81, v209/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea217d1
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[82:83], v[86:87]                ; 1a02ad52
	v_cvt_f32_f16_e32 v82, v210/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea417d2
	s_add_co_u32 s13, s13, 48                                   ; 800db00d
(invalid instruction)                                        ; cc0f0057
	v_min_num_f64_e32 v[1:2], v[83:84], v[87:88]                ; 1a02af53
	v_cvt_f32_f16_e32 v83, v211/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea617d3
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[84:85]                ; 1a02a94a
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v80, v88, vcc_lo                      ; 0202b150
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[85:86]                ; 1a02ab4b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_u32 s13, s3                                        ; bf0a030d
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v90, v81, vcc_lo                      ; 0202a35a
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[86:87]                ; 1a02ad4c
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v91, v82, vcc_lo                      ; 0202a55b
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[87:88]                ; 1a02af4d
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v93, v83, vcc_lo                      ; 0202a75d
	v_cndmask_b32_e64 v18, v89, 0, s29                          ; d5010012 00750159
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_cndmask_b32_e64 v19, v92, 0, s29                          ; d5010013 0075015c
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[56:57], v[18:19], v[40:47] ; cc464028 1ca22538
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[56:57], v[58:59], v[24:31] ; cc464018 1c627538
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[22:23], v[58:59], v[32:39] ; cc464020 1c827516
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[22:23], v[18:19], v[48:55] ; cc464030 1cc22516
	s_cbranch_scc0 BB23                                         ; bfa10018
BB22:
	s_mul_i32 s17, s13, 0xc00                                   ; 9611ff0d 00000c00
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s7, s17                                   ; 80111107
	s_add_co_u32 s19, 0x4000, s14                               ; 80130eff 00004000
	s_add_co_u32 s25, 0x4100, s14                               ; 80190eff 00004100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v14, v2, s17, s19                                ; d655000e 004c2302
	v_add3_u32 v18, v2, s17, s25                                ; d6550012 00642302
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v4                               ; 4a1c090e
	v_add_nc_u32_e32 v18, v18, v4                               ; 4a240912
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[20:21], v14, s[8:11], null offen          ; c405407c 40801014 0000000e
	buffer_load_b64 v[18:19], v18, s[8:11], null offen          ; c405407c 40801012 00000012
	s_branch BB24                                               ; bfa00004
BB23:
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
BB24:
	s_min_u32 s17, s13, s12                                     ; 89910c0d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mulk_i32 s17, 0xc00                                       ; b8110c00
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s7, s17                                   ; 80111107
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v14, v5, s17, s18                                ; d655000e 00482305
	v_add3_u32 v5, v5, s17, s24                                 ; d6550005 00602305
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v17                              ; 4a1c230e
	v_add_nc_u32_e32 v5, v5, v17                                ; 4a0a2305
	s_clause 0x1                                                ; bf850001
	global_load_tr_b64 v[22:23], v14, s[22:23]                  ; ee160016 00000016 0000000e
	global_load_tr_b64 v[56:57], v5, s[22:23]                   ; ee160016 00000038 00000005
	s_movk_i32 s18, 0x3dc2                                      ; b0123dc2
	s_movk_i32 s19, 0x3fe9                                      ; b0133fe9
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[8:9], 0   ; cc464050 1a021114
	s_wait_loadcnt 0x2                                          ; bfc00002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[10:11], v[80:87] ; cc464050 1d421512
	v_cvt_f16_f32_e32 v58, v82                                  ; 7e741552
(invalid instruction)                                        ; 7f741553
	v_cvt_f16_f32_e32 v59, v84                                  ; 7e761554
(invalid instruction)                                        ; 7f761555
	v_cvt_f16_f32_e32 v60, v86                                  ; 7e781556
	v_cvt_f16_f32_e32 v17, v80                                  ; 7e221550
(invalid instruction)                                        ; 7f221551
(invalid instruction)                                        ; 7f781557
	s_mov_b32 s22, 0x3ffc4000                                   ; be9600ff 3ffc4000
	v_pk_fma_f16 v58, v58, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603a 0bfdff3a 3ed62dbb
	s_mov_b32 s23, 0x76543210                                   ; be9700ff 76543210
	s_mov_b32 s24, 0xfedcba98                                   ; be9800ff fedcba98
	v_pk_fma_f16 v59, v59, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603b 0bfdff3b 3ed62dbb
	v_pk_fma_f16 v17, v17, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6011 0bfdff11 3ed62dbb
	v_pk_fma_f16 v60, v60, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603c 0bfdff3c 3ed62dbb
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v18                               ; 0a00253a
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v18                               ; 0a00253b
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v18                               ; 0a002511
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v18                               ; 0a00253c
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v19                               ; 0a00273a
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v19                               ; 0a00273b
(invalid instruction)                                        ; cc1b0011
	v_subrev_f32_e32 v0, v17, v19                               ; 0a002711
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v19                               ; 0a00273c
	v_lshl_add_u32 v58, v58, 4, s22                             ; d646003a 0059093a
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_lshl_add_u32 v59, v59, 4, s22                             ; d646003b 0059093b
	v_lshl_add_u32 v17, v17, 4, s22                             ; d6460011 00590911
	v_lshl_add_u32 v60, v60, 4, s22                             ; d646003c 0059093c
	v_permlanex16_b32 v66, v58, s23, s24 op_sel:[1,1]           ; d65c1842 00602f3a
	v_permlanex16_b32 v67, v59, s23, s24 op_sel:[1,1]           ; d65c1843 00602f3b
	v_cvt_f32_f16_e32 v70, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8c1791
	v_permlanex16_b32 v61, v17, s23, s24 op_sel:[1,1]           ; d65c183d 00602f11
	v_permlanex16_b32 v68, v60, s23, s24 op_sel:[1,1]           ; d65c1844 00602f3c
(invalid instruction)                                        ; cc0f0042
	v_min_num_f64_e32 v[1:2], v[58:59], v[66:67]                ; 1a02853a
	v_cvt_f32_f16_e32 v72, v58                                  ; 7e90173a
	v_cvt_f32_f16_e32 v58, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7417ba
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[59:60], v[67:68]                ; 1a02873b
	v_cvt_f32_f16_e32 v73, v59                                  ; 7e92173b
(invalid instruction)                                        ; cc0f003d
	v_min_num_f64_e32 v[1:2], v[17:18], v[61:62]                ; 1a027b11
	v_cvt_f32_f16_e32 v17, v17                                  ; 7e221711
	v_cvt_f32_f16_e32 v59, v187/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7617bb
(invalid instruction)                                        ; cc0f0044
	v_min_num_f64_e32 v[1:2], v[60:61], v[68:69]                ; 1a02893c
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[66:67]                ; 1a02853f
	v_cvt_f32_f16_e32 v79, v60                                  ; 7e9e173c
	v_cvt_f32_f16_e32 v60, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7817bc
	s_cmp_ge_u32 s13, s3                                        ; bf09030d
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[64:65], v[67:68]                ; 1a028740
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[61:62]                ; 1a027b3e
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v17, v70, vcc_lo                      ; 02028d11
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v72, v58, vcc_lo                      ; 02027548
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[12:13], 0 ; cc464050 1a021914
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v73, v59, vcc_lo                      ; 02027749
(invalid instruction)                                        ; cc0f0041
	v_min_num_f64_e32 v[1:2], v[65:66], v[68:69]                ; 1a028941
	s_cselect_b32 s25, -1, 0                                    ; 981980c1
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v79, v60, vcc_lo                      ; 0202794f
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[63:64]                ; 1a027f3e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v58, v71, 0, s25                          ; d501003a 00650147
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c3
	v_cndmask_b32_e64 v59, v78, 0, s25                          ; d501003b 0065014e
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[64:65]                ; 1a02813e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[6:7], v[80:87] ; cc464050 1d420d12
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[65:66]                ; 1a02833e
	v_add_f16_e32 v69, v62, v190/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 648b7d3e
	v_cvt_f16_f32_e32 v80, v80                                  ; 7ea01550
(invalid instruction)                                        ; 7fa01551
	v_cvt_f16_f32_e32 v81, v82                                  ; 7ea21552
	v_cvt_f16_f32_e32 v82, v84                                  ; 7ea41554
(invalid instruction)                                        ; 7fa21553
(invalid instruction)                                        ; 7fa41555
(invalid instruction)                                        ; 65888b83
	v_cvt_f16_f32_e32 v83, v86                                  ; 7ea61556
(invalid instruction)                                        ; 7fa61557
	v_pk_fma_f16 v80, v80, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6050 0bfdff50 3ed62dbb
	v_pk_fma_f16 v81, v81, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6051 0bfdff51 3ed62dbb
	v_pk_fma_f16 v82, v82, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6052 0bfdff52 3ed62dbb
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_pk_fma_f16 v83, v83, 0x3ed62dbb, 0x3ed62dbb op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6053 0bfdff53 3ed62dbb
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v18                               ; 0a002550
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v18                               ; 0a002551
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v18                               ; 0a002552
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v18                               ; 0a002553
(invalid instruction)                                        ; cc1b0050
	v_subrev_f32_e32 v0, v80, v19                               ; 0a002750
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v19                               ; 0a002751
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v19                               ; 0a002752
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b0053
	v_subrev_f32_e32 v0, v83, v19                               ; 0a002753
	v_lshl_add_u32 v80, v80, 4, s22                             ; d6460050 00590950
	v_lshl_add_u32 v81, v81, 4, s22                             ; d6460051 00590951
	v_lshl_add_u32 v82, v82, 4, s22                             ; d6460052 00590952
	v_lshl_add_u32 v83, v83, 4, s22                             ; d6460053 00590953
	v_permlanex16_b32 v84, v80, s23, s24 op_sel:[1,1]           ; d65c1854 00602f50
	v_permlanex16_b32 v85, v81, s23, s24 op_sel:[1,1]           ; d65c1855 00602f51
	v_permlanex16_b32 v86, v82, s23, s24 op_sel:[1,1]           ; d65c1856 00602f52
	v_cvt_f32_f16_e32 v89, v208/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eb217d0
	v_permlanex16_b32 v87, v83, s23, s24 op_sel:[1,1]           ; d65c1857 00602f53
	v_cvt_f32_f16_e32 v91, v81                                  ; 7eb61751
(invalid instruction)                                        ; cc0f0054
	v_min_num_f64_e32 v[1:2], v[80:81], v[84:85]                ; 1a02a950
	v_cvt_f32_f16_e32 v80, v80                                  ; 7ea01750
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[81:82], v[85:86]                ; 1a02ab51
	v_cvt_f32_f16_e32 v81, v209/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea217d1
(invalid instruction)                                        ; cc0f0056
	v_min_num_f64_e32 v[1:2], v[82:83], v[86:87]                ; 1a02ad52
	v_cvt_f32_f16_e32 v92, v82                                  ; 7eb81752
	v_cvt_f32_f16_e32 v82, v210/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea417d2
(invalid instruction)                                        ; cc0f0057
	v_min_num_f64_e32 v[1:2], v[83:84], v[87:88]                ; 1a02af53
	v_cvt_f32_f16_e32 v94, v83                                  ; 7ebc1753
	v_cvt_f32_f16_e32 v83, v211/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea617d3
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[84:85]                ; 1a02a94a
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v80, v89, vcc_lo                      ; 0202b350
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[85:86]                ; 1a02ab4b
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v91, v81, vcc_lo                      ; 0202a35b
(invalid instruction)                                        ; cc0f004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[86:87]                ; 1a02ad4c
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v92, v82, vcc_lo                      ; 0202a55c
(invalid instruction)                                        ; cc0f004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[87:88]                ; 1a02af4d
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v94, v83, vcc_lo                      ; 0202a75e
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[75:76]                ; 1a02974a
	v_cndmask_b32_e64 v18, v90, 0, s25                          ; d5010012 0065015a
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
	v_cndmask_b32_e64 v19, v93, 0, s25                          ; d5010013 0065015d
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[76:77]                ; 1a02994a
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[77:78]                ; 1a029b4a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v88, v74, v202/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64b1954a
	v_add_f16_e32 v68, v3, v88                                  ; 6488b103
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[22:23], v[58:59], v[24:31] ; cc464018 1c627516
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[22:23], v[18:19], v[40:47] ; cc464028 1ca22516
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[56:57], v[18:19], v[48:55] ; cc464030 1cc22538
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[56:57], v[58:59], v[32:39] ; cc464020 1c827538
BB25:
	v_mov_b32_e32 v3, v68                                       ; 7e060344
	s_mov_b32 s13, s15                                          ; be8d000f
	s_branch BB8                                                ; bfa0f860
BB26:
	v_add_nc_u32_e32 v5, s6, v1                                 ; 4a0a0206
	s_add_co_u32 s7, 63, s3                                     ; 800703bf
	s_mov_b32 s13, 0x38820000                                   ; be8d00ff 38820000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s7, s7, 0xffffffc0                                ; 8b07ff07 ffffffc0
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s7, s7, s3                                     ; 81870307
	s_lshl_b32 s12, ttmp7, 5                                    ; 840c8573
	s_and_b32 s4, s4, 12                                        ; 8b048c04
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_f32_u32 s7, s7                                        ; be876507
	s_cmp_eq_i32 s4, 12                                         ; bf008c04
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_f32 s7, s7, 0x3dac0000                                ; a207ff07 3dac0000
	s_cselect_b32 s13, 0x3c820000, s13                          ; 980d0dff 3c820000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_f16_f32 s7, s7                                        ; be876807
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc0f0a03
	v_sub_co_ci_u32_e32 v0, vcc_lo, v3, v7, vcc_lo              ; 42000f03
	v_cmpx_gt_u32_e32 s3, v5                                    ; 7d980a03
	s_cbranch_execz BB32                                        ; bfa5008d
BB27:
	s_load_b128 s[20:23], s[0:1], 0x20                          ; f4004500 f8000020
	v_cvt_f32_f16_e32 v5, v3                                    ; 7e0a1703
	s_lshr_b32 s14, s12, 4                                      ; 850e840c
	s_lshr_b32 s15, s6, 4                                       ; 850f8406
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v7, v24                                   ; 7e0e1518
(invalid instruction)                                        ; 7f0e1519
	s_movk_i32 s4, 0x5f00                                       ; b0045f00
	s_movk_i32 s7, 0xdf00                                       ; b007df00
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s15, s15, 6                                      ; 840f860f
	v_max_num_f32_e32 v5, s13, v5                               ; 2c0a0a0d
	v_cvt_f16_f32_e32 v9, v26                                   ; 7e12151a
(invalid instruction)                                        ; 7f12151b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s14, s15, s14                                  ; 800e0e0f
	s_and_b32 s17, s2, -4                                       ; 8b11c402
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s14, s14, 8                                      ; 840e880e
	v_rcp_f32_e32 v5, v5                                        ; 7e0a5505
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v15, v2, s17, s14                                ; d655000f 00382302
	v_cvt_f16_f32_e32 v11, v28                                  ; 7e16151c
(invalid instruction)                                        ; 7f16151d
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
	v_add_nc_u32_e32 v15, v15, v4                               ; 4a1e090f
	v_cvt_f16_f32_e32 v6, v5                                    ; 7e0c1505
(invalid instruction)                                        ; cc100009
	v_subrev_f32_e32 v1, v9, v6                                 ; 0a020d09
(invalid instruction)                                        ; cc10000b
	v_subrev_f32_e32 v1, v11, v6                                ; 0a020d0b
(invalid instruction)                                        ; cc100007
	v_subrev_f32_e32 v1, v7, v6                                 ; 0a020d07
	v_cvt_f16_f32_e32 v13, v30                                  ; 7e1a151e
(invalid instruction)                                        ; 7f1a151f
(invalid instruction)                                        ; cc1c0009
	v_subrev_f32_e32 v0, v9, v7                                 ; 0a000f09
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v7                                ; 0a000f0b
(invalid instruction)                                        ; cc1c0007
	v_subrev_f32_e32 v0, v7, v7                                 ; 0a000f07
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc10000d
	v_subrev_f32_e32 v1, v13, v6                                ; 0a020d0d
(invalid instruction)                                        ; cc1b0009
	v_subrev_f32_e32 v0, v9, v4                                 ; 0a000909
(invalid instruction)                                        ; cc1b000b
	v_subrev_f32_e32 v0, v11, v4                                ; 0a00090b
(invalid instruction)                                        ; cc1b0007
	v_subrev_f32_e32 v0, v7, v4                                 ; 0a000907
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v7                                ; 0a000f0d
	v_cvt_f32_f16_e32 v10, v137/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e141789
	v_cvt_f32_f16_e32 v9, v9                                    ; 7e121709
	v_cvt_f32_f16_e32 v12, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e18178b
	v_cvt_f32_f16_e32 v11, v11                                  ; 7e16170b
	v_cvt_f32_f16_e32 v8, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e101787
	v_cvt_f32_f16_e32 v7, v7                                    ; 7e0e1707
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v4                                ; 0a00090d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d2
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                        ; 02021107
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                       ; 02021509
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v11, v12, vcc_lo                      ; 0202190b
	v_cvt_f32_f16_e32 v14, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1c178d
	v_cvt_f32_f16_e32 v13, v13                                  ; 7e1a170d
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                      ; 02021d0d
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b64 v[8:9], v15, s[20:23], null offen          ; c406c07c 40802808 0000000f
	s_add_co_u32 s18, s12, 16                                   ; 8012900c
	v_cvt_f16_f32_e32 v16, v32                                  ; 7e201520
(invalid instruction)                                        ; 7f201521
	v_cvt_f16_f32_e32 v18, v34                                  ; 7e241522
(invalid instruction)                                        ; 7f241523
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s18, s18, 4                                      ; 85128412
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s15, s15, s18                                  ; 800f120f
(invalid instruction)                                        ; cc100010
	v_subrev_f32_e32 v1, v16, v6                                ; 0a020d10
	v_cvt_f16_f32_e32 v20, v36                                  ; 7e281524
(invalid instruction)                                        ; cc100012
	v_subrev_f32_e32 v1, v18, v6                                ; 0a020d12
(invalid instruction)                                        ; 7f281525
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s15, s15, 8                                      ; 840f880f
(invalid instruction)                                        ; cc1c0010
	v_subrev_f32_e32 v0, v16, v7                                ; 0a000f10
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v24, v2, s17, s15                                ; d6550018 003c2302
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v7                                ; 0a000f12
(invalid instruction)                                        ; cc100014
	v_subrev_f32_e32 v1, v20, v6                                ; 0a020d14
	v_cvt_f16_f32_e32 v22, v38                                  ; 7e2c1526
(invalid instruction)                                        ; 7f2c1527
(invalid instruction)                                        ; cc1b0010
	v_subrev_f32_e32 v0, v16, v4                                ; 0a000910
	v_add_nc_u32_e32 v24, v24, v4                               ; 4a300918
(invalid instruction)                                        ; cc1b0012
	v_subrev_f32_e32 v0, v18, v4                                ; 0a000912
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v7                                ; 0a000f14
(invalid instruction)                                        ; cc100016
	v_subrev_f32_e32 v1, v22, v6                                ; 0a020d16
	v_cvt_f32_f16_e32 v17, v144/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221790
	v_cvt_f32_f16_e32 v16, v16                                  ; 7e201710
	v_cvt_f32_f16_e32 v19, v146/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e261792
	v_cvt_f32_f16_e32 v18, v18                                  ; 7e241712
(invalid instruction)                                        ; cc1b0014
	v_subrev_f32_e32 v0, v20, v4                                ; 0a000914
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v7                                ; 0a000f16
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_cvt_f32_f16_e32 v21, v148/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2a1794
	v_cvt_f32_f16_e32 v20, v20                                  ; 7e281714
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v4                                ; 0a000916
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	v_cvt_f32_f16_e32 v23, v150/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2e1796
	v_cvt_f32_f16_e32 v22, v22                                  ; 7e2c1716
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	buffer_store_b64 v[8:9], v24, s[20:23], null offen          ; c406c07c 40802808 00000018
BB32:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_add_nc_u32_e32 v1, s16, v1                                ; 4a020210
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_gt_u32_e32 s3, v1                                    ; 7d980203
	s_cbranch_execz BB38                                        ; bfa5008e
BB33:
	s_load_b128 s[20:23], s[0:1], 0x20                          ; f4004500 f8000020
	v_cvt_f32_f16_e32 v3, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e061783
	s_lshr_b32 s4, s12, 4                                       ; 8504840c
	s_lshr_b32 s16, s16, 4                                      ; 85108410
	s_movk_i32 s0, 0x5f00                                       ; b0005f00
	s_movk_i32 s1, 0xdf00                                       ; b001df00
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s16, s16, 6                                      ; 84108610
	v_max_num_f32_e32 v3, s13, v3                               ; 2c06060d
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v7, v42                                   ; 7e0e152a
(invalid instruction)                                        ; 7f0e152b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s16, s4                                    ; 80040410
	s_and_b32 s2, s2, -4                                        ; 8b02c402
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s4, s4, 8                                        ; 84048804
	v_rcp_f32_e32 v3, v3                                        ; 7e065503
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v13, v2, s2, s4                                  ; d655000d 00100502
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v13, v13, v4                               ; 4a1a090d
	v_cvt_f16_f32_e32 v9, v44                                   ; 7e12152c
(invalid instruction)                                        ; 7f12152d
	v_cvt_f16_f32_e32 v1, v3                                    ; 7e021503
	v_cvt_f16_f32_e32 v3, v40                                   ; 7e061528
(invalid instruction)                                        ; 7f061529
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; cc100007
	v_subrev_f32_e32 v1, v7, v1                                 ; 0a020307
(invalid instruction)                                        ; cc100009
	v_subrev_f32_e32 v1, v9, v1                                 ; 0a020309
(invalid instruction)                                        ; cc100003
	v_subrev_f32_e32 v1, v3, v1                                 ; 0a020303
	v_cvt_f16_f32_e32 v11, v46                                  ; 7e16152e
(invalid instruction)                                        ; 7f16152f
(invalid instruction)                                        ; cc1c0007
	v_subrev_f32_e32 v0, v7, v1                                 ; 0a000307
(invalid instruction)                                        ; cc1c0009
	v_subrev_f32_e32 v0, v9, v1                                 ; 0a000309
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v1                                 ; 0a000303
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc10000b
	v_subrev_f32_e32 v1, v11, v1                                ; 0a02030b
(invalid instruction)                                        ; cc1b0007
	v_subrev_f32_e32 v0, v7, v0                                 ; 0a000107
(invalid instruction)                                        ; cc1b0009
	v_subrev_f32_e32 v0, v9, v0                                 ; 0a000109
(invalid instruction)                                        ; cc1b0003
	v_subrev_f32_e32 v0, v3, v0                                 ; 0a000103
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v1                                ; 0a00030b
	v_cvt_f32_f16_e32 v8, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e101787
	v_cvt_f32_f16_e32 v7, v7                                    ; 7e0e1707
	v_cvt_f32_f16_e32 v10, v137/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e141789
	v_cvt_f32_f16_e32 v9, v9                                    ; 7e121709
	v_cvt_f32_f16_e32 v5, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a1783
	v_cvt_f32_f16_e32 v3, v3                                    ; 7e061703
(invalid instruction)                                        ; cc1b000b
	v_subrev_f32_e32 v0, v11, v0                                ; 0a00010b
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d2
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                        ; 02020b03
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                        ; 02021107
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                       ; 02021509
	v_cvt_f32_f16_e32 v12, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e18178b
	v_cvt_f32_f16_e32 v11, v11                                  ; 7e16170b
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v11, v12, vcc_lo                      ; 0202190b
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b64 v[6:7], v13, s[20:23], null offen          ; c406c07c 40802806 0000000d
	s_add_co_u32 s12, s12, 16                                   ; 800c900c
	v_cvt_f16_f32_e32 v14, v48                                  ; 7e1c1530
(invalid instruction)                                        ; 7f1c1531
	v_cvt_f16_f32_e32 v16, v50                                  ; 7e201532
(invalid instruction)                                        ; 7f201533
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s12, s12, 4                                      ; 850c840c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s16, s12                                  ; 80100c10
(invalid instruction)                                        ; cc10000e
	v_subrev_f32_e32 v1, v14, v1                                ; 0a02030e
	v_cvt_f16_f32_e32 v18, v52                                  ; 7e241534
(invalid instruction)                                        ; cc100010
	v_subrev_f32_e32 v1, v16, v1                                ; 0a020310
(invalid instruction)                                        ; 7f241535
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s16, s16, 8                                      ; 84108810
(invalid instruction)                                        ; cc1c000e
	v_subrev_f32_e32 v0, v14, v1                                ; 0a00030e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v2, v2, s2, s16                                  ; d6550002 00400502
(invalid instruction)                                        ; cc1c0010
	v_subrev_f32_e32 v0, v16, v1                                ; 0a000310
	v_cvt_f16_f32_e32 v20, v54                                  ; 7e281536
(invalid instruction)                                        ; cc100012
	v_subrev_f32_e32 v1, v18, v1                                ; 0a020312
(invalid instruction)                                        ; 7f281537
(invalid instruction)                                        ; cc1b000e
	v_subrev_f32_e32 v0, v14, v0                                ; 0a00010e
	v_add_nc_u32_e32 v2, v2, v4                                 ; 4a040902
(invalid instruction)                                        ; cc1b0010
	v_subrev_f32_e32 v0, v16, v0                                ; 0a000110
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v1                                ; 0a000312
(invalid instruction)                                        ; cc100014
	v_subrev_f32_e32 v1, v20, v1                                ; 0a020314
	v_cvt_f32_f16_e32 v15, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e178e
	v_cvt_f32_f16_e32 v14, v14                                  ; 7e1c170e
	v_cvt_f32_f16_e32 v17, v144/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221790
	v_cvt_f32_f16_e32 v16, v16                                  ; 7e201710
(invalid instruction)                                        ; cc1b0012
	v_subrev_f32_e32 v0, v18, v0                                ; 0a000112
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v1                                ; 0a000314
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_cvt_f32_f16_e32 v19, v146/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e261792
	v_cvt_f32_f16_e32 v18, v18                                  ; 7e241712
(invalid instruction)                                        ; cc1b0014
	v_subrev_f32_e32 v0, v20, v0                                ; 0a000114
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_cvt_f32_f16_e32 v21, v148/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2a1794
	v_cvt_f32_f16_e32 v20, v20                                  ; 7e281714
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	buffer_store_b64 v[6:7], v2, s[20:23], null offen           ; c406c07c 40802806 00000002
BB38:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_cmp_lg_i32 s5, -1                                         ; bf01c105
	s_cbranch_scc0 BB49                                         ; bfa10015
BB39:
	s_lshr_b32 s6, s6, 4                                        ; 85068406
	s_add_co_u32 s3, s3, 15                                     ; 80038f03
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s3, s3, 4                                        ; 85038403
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s3, s3, s6                                     ; 81830603
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_u32 s3, 2, s3                                         ; 89830382
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmpx_gt_u32_e32 s3, v0                                    ; 7d980003
	s_cbranch_execz BB49                                        ; bfa5000a
BB40:
	v_add3_u32 v0, v0, s5, s6                                   ; d6550000 00180b00
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mov_b32 v1, 1 :: v_dual_lshlrev_b32 v0, 2, v0        ; ca220081 01000082
	s_wait_loadcnt 0x0                                          ; bfc00000
	s_wait_storecnt 0x0                                         ; bfc10000
	buffer_atomic_add_u32 v1, v0, s[8:11], null offen           ; c40d407c 40801001 00000000
BB49:
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
