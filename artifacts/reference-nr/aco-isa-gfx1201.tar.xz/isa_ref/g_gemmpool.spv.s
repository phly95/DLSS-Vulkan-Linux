BB0:
	v_and_b32_e32 v12, 15, v0                                   ; 3618008f
	v_lshrrev_b32_e32 v1, 7, v0                                 ; 32020087
	s_lshl_b32 s12, ttmp9, 6                                    ; 840c8675
	v_bfe_u32 v14, v0, 4, 1                                     ; d610000e 02050900
	s_lshr_b32 s13, s8, 4                                       ; 850d8408
	v_bfe_u32 v7, v0, 5, 2                                      ; d6100007 02090b00
	s_lshl_b32 s14, ttmp7, 7                                    ; 840e8773
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0              ; ca100080 10100080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0              ; ca100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0              ; ca100080 14140080
	v_lshlrev_b32_e32 v13, 4, v12                               ; 301a1884
	v_lshl_add_u32 v1, v1, 5, s12                               ; d6460001 00310b01
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	v_lshlrev_b32_e32 v15, 3, v14                               ; 301e1c83
	v_lshl_add_u32 v7, v7, 5, s14                               ; d6460007 00390b07
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	v_lshrrev_b32_e32 v2, 4, v1                                 ; 32040284
	v_add_nc_u32_e32 v4, 16, v1                                 ; 4a080290
	s_lshr_b32 s8, s8, 7                                        ; 85088708
	v_add_nc_u32_e32 v10, 16, v7                                ; 4a140e90
	v_lshrrev_b32_e32 v8, 4, v7                                 ; 32100e84
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
(invalid instruction)                                        ; d72c0003
	v_cndmask_b32_e32 v0, v2, v13, vcc_lo                       ; 02001b02
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_lshrrev_b32_e32 v5, 4, v4                                 ; 320a0884
	v_lshrrev_b32_e32 v10, 4, v10                               ; 32141484
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
(invalid instruction)                                        ; d72c0009
	v_cndmask_b32_e32 v0, v8, v13, vcc_lo                       ; 02001b08
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v5, v13, vcc_lo                       ; 02001b05
	v_lshl_add_u32 v3, v3, 8, s1                                ; d6460003 00051103
(invalid instruction)                                        ; d72c000b
	v_cndmask_b32_e32 v0, v10, v13, vcc_lo                      ; 02001b0a
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_lshl_add_u32 v9, v9, 8, s4                                ; d6460009 00111109
	v_add3_u32 v3, v15, v3, v13                                 ; d6550003 0436070f
	v_lshl_add_u32 v6, v6, 8, s1                                ; d6460006 00051106
	s_mov_b32 s1, 0                                             ; be810080
	v_lshl_add_u32 v11, v11, 8, s4                              ; d646000b 0011110b
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
	v_lshrrev_b32_e32 v3, 2, v3                                 ; 32060682
	v_add3_u32 v6, v15, v6, v13                                 ; d6550006 04360d0f
	v_lshrrev_b32_e32 v6, 2, v6                                 ; 320c0c82
	s_branch BB1                                                ; bfa0010e
BB3:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[12:13], 0x70                        ; f4004406 f8000070
	s_load_b128 s[12:15], s[12:13], 0x30                        ; f4004306 f8000030
	s_lshl_b32 s4, s1, 7                                        ; 84048701
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s4, s4, 4                                        ; 85048404
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s4, s4, 8                                        ; 84048804
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s20, s4, 2                                       ; 85148204
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v13, s20, v3, 2                              ; d647000d 020a0614
	v_add_lshl_u32 v48, s20, v6, 2                              ; d6470030 020a0c14
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[50:51], v13, s[16:19], null offen         ; c405407c 40802032 0000000d
	buffer_load_b64 v[52:53], v48, s[16:19], null offen         ; c405407c 40802034 00000030
(invalid instruction)                                        ; d71f0036
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_add_nc_u32_e32 v57, s4, v11                               ; 4a721604
	v_add_nc_u32_e32 v49, s4, v9                                ; 4a621204
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_and_b32_e32 v55, 15, v54                                  ; 366e6c8f
	v_lshrrev_b32_e32 v54, 4, v54                               ; 326c6c84
	v_lshlrev_b32_e32 v55, 4, v55                               ; 306e6e84
	v_lshlrev_b32_e32 v54, 3, v54                               ; 306c6c83
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add3_u32 v63, v55, 0x300, v49                             ; d655003f 04c5ff37 00000300
	v_add3_u32 v60, v55, 0x100, v57                             ; d655003c 04e5ff37 00000100
	v_add3_u32 v62, v55, 0x200, v57                             ; d655003e 04e5ff37 00000200
	v_add3_u32 v64, v55, 0x300, v57                             ; d6550040 04e5ff37 00000300
	v_add3_u32 v59, v55, 0x100, v49                             ; d655003b 04c5ff37 00000100
	v_add3_u32 v61, v55, 0x200, v49                             ; d655003d 04c5ff37 00000200
	v_add3_u32 v65, v55, 0x400, v49                             ; d6550041 04c5ff37 00000400
	v_add3_u32 v56, v54, v49, v55                               ; d6550038 04de6336
	v_add3_u32 v66, v55, 0x400, v57                             ; d6550042 04e5ff37 00000400
	v_add3_u32 v58, v54, v57, v55                               ; d655003a 04de7336
	v_add_nc_u32_e32 v63, v63, v54                              ; 4a7e6d3f
	v_add_nc_u32_e32 v60, v60, v54                              ; 4a786d3c
	v_add_nc_u32_e32 v62, v62, v54                              ; 4a7c6d3e
	s_clause 0xd                                                ; bf85000d
	buffer_load_b64 v[68:69], v13, s[16:19], null offen offset:256 ; c405407c 40802044 0001000d
	buffer_load_b64 v[70:71], v48, s[16:19], null offen offset:256 ; c405407c 40802046 00010030
	buffer_load_b64 v[72:73], v13, s[16:19], null offen offset:512 ; c405407c 40802048 0002000d
	buffer_load_b64 v[74:75], v48, s[16:19], null offen offset:512 ; c405407c 4080204a 00020030
	buffer_load_b64 v[76:77], v13, s[16:19], null offen offset:768 ; c405407c 4080204c 0003000d
	buffer_load_b64 v[78:79], v48, s[16:19], null offen offset:768 ; c405407c 4080204e 00030030
	buffer_load_b64 v[80:81], v13, s[16:19], null offen offset:1024 ; c405407c 40802050 0004000d
	buffer_load_b64 v[82:83], v48, s[16:19], null offen offset:1024 ; c405407c 40802052 00040030
	buffer_load_b64 v[84:85], v13, s[16:19], null offen offset:1280 ; c405407c 40802054 0005000d
	buffer_load_b64 v[86:87], v48, s[16:19], null offen offset:1280 ; c405407c 40802056 00050030
	buffer_load_b64 v[90:91], v13, s[16:19], null offen offset:1536 ; c405407c 4080205a 0006000d
	buffer_load_b64 v[92:93], v48, s[16:19], null offen offset:1536 ; c405407c 4080205c 00060030
	buffer_load_b64 v[96:97], v13, s[16:19], null offen offset:1792 ; c405407c 40802060 0007000d
	buffer_load_b64 v[98:99], v48, s[16:19], null offen offset:1792 ; c405407c 40802062 00070030
	v_add_nc_u32_e32 v64, v64, v54                              ; 4a806d40
	v_add_nc_u32_e32 v59, v59, v54                              ; 4a766d3b
	v_add_nc_u32_e32 v61, v61, v54                              ; 4a7a6d3d
	v_add_nc_u32_e32 v65, v65, v54                              ; 4a826d41
	v_add3_u32 v67, v55, 0x500, v49                             ; d6550043 04c5ff37 00000500
	v_add_nc_u32_e32 v66, v66, v54                              ; 4a846d42
	v_add3_u32 v88, v55, 0x500, v57                             ; d6550058 04e5ff37 00000500
	v_add3_u32 v89, v55, 0x600, v49                             ; d6550059 04c5ff37 00000600
	v_add3_u32 v94, v55, 0x600, v57                             ; d655005e 04e5ff37 00000600
	v_add3_u32 v49, v55, 0x700, v49                             ; d6550031 04c5ff37 00000700
	v_add3_u32 v55, v55, 0x700, v57                             ; d6550037 04e5ff37 00000700
	v_add_nc_u32_e32 v67, v67, v54                              ; 4a866d43
	v_add_nc_u32_e32 v88, v88, v54                              ; 4ab06d58
	v_add_nc_u32_e32 v89, v89, v54                              ; 4ab26d59
	v_add_nc_u32_e32 v94, v94, v54                              ; 4abc6d5e
	v_add_nc_u32_e32 v49, v49, v54                              ; 4a626d31
	v_add_nc_u32_e32 v55, v55, v54                              ; 4a6e6d37
	s_clause 0xf                                                ; bf85000f
	buffer_load_b64 v[56:57], v56, s[12:15], null offen         ; c405407c 40801838 00000038
	buffer_load_b64 v[100:101], v58, s[12:15], null offen       ; c405407c 40801864 0000003a
	buffer_load_b64 v[58:59], v59, s[12:15], null offen         ; c405407c 4080183a 0000003b
	buffer_load_b64 v[102:103], v60, s[12:15], null offen       ; c405407c 40801866 0000003c
	buffer_load_b64 v[60:61], v61, s[12:15], null offen         ; c405407c 4080183c 0000003d
	buffer_load_b64 v[104:105], v62, s[12:15], null offen       ; c405407c 40801868 0000003e
	buffer_load_b64 v[62:63], v63, s[12:15], null offen         ; c405407c 4080183e 0000003f
	buffer_load_b64 v[106:107], v64, s[12:15], null offen       ; c405407c 4080186a 00000040
	buffer_load_b64 v[64:65], v65, s[12:15], null offen         ; c405407c 40801840 00000041
	buffer_load_b64 v[108:109], v66, s[12:15], null offen       ; c405407c 4080186c 00000042
	buffer_load_b64 v[66:67], v67, s[12:15], null offen         ; c405407c 40801842 00000043
	buffer_load_b64 v[110:111], v88, s[12:15], null offen       ; c405407c 4080186e 00000058
	buffer_load_b64 v[88:89], v89, s[12:15], null offen         ; c405407c 40801858 00000059
	buffer_load_b64 v[94:95], v94, s[12:15], null offen         ; c405407c 4080185e 0000005e
	buffer_load_b64 v[48:49], v49, s[12:15], null offen         ; c405407c 40801830 00000031
	buffer_load_b64 v[54:55], v55, s[12:15], null offen         ; c405407c 40801836 00000037
	s_add_co_u32 s1, s1, 1                                      ; 80018101
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[50:51], v[56:57], v[16:23] ; cc464010 1c427132
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[52:53], v[56:57], v[32:39] ; cc464020 1c827134
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[52:53], v[100:101], v[40:47] ; cc464028 1ca2c934
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[50:51], v[100:101], v[24:31] ; cc464018 1c62c932
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[68:69], v[58:59], v[16:23] ; cc464010 1c427544
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[70:71], v[58:59], v[32:39] ; cc464020 1c827546
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[70:71], v[102:103], v[40:47] ; cc464028 1ca2cd46
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[68:69], v[102:103], v[24:31] ; cc464018 1c62cd44
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[72:73], v[60:61], v[16:23] ; cc464010 1c427948
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[74:75], v[60:61], v[32:39] ; cc464020 1c82794a
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[74:75], v[104:105], v[40:47] ; cc464028 1ca2d14a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[72:73], v[104:105], v[24:31] ; cc464018 1c62d148
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[76:77], v[62:63], v[16:23] ; cc464010 1c427d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[78:79], v[62:63], v[32:39] ; cc464020 1c827d4e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[78:79], v[106:107], v[40:47] ; cc464028 1ca2d54e
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[76:77], v[106:107], v[24:31] ; cc464018 1c62d54c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[80:81], v[64:65], v[16:23] ; cc464010 1c428150
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[82:83], v[64:65], v[32:39] ; cc464020 1c828152
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[82:83], v[108:109], v[40:47] ; cc464028 1ca2d952
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[80:81], v[108:109], v[24:31] ; cc464018 1c62d950
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[84:85], v[66:67], v[16:23] ; cc464010 1c428554
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[86:87], v[66:67], v[32:39] ; cc464020 1c828556
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[86:87], v[110:111], v[40:47] ; cc464028 1ca2dd56
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[84:85], v[110:111], v[24:31] ; cc464018 1c62dd54
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[90:91], v[88:89], v[16:23] ; cc464010 1c42b15a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[92:93], v[88:89], v[32:39] ; cc464020 1c82b15c
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[92:93], v[94:95], v[40:47] ; cc464028 1ca2bd5c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[90:91], v[94:95], v[24:31] ; cc464018 1c62bd5a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[96:97], v[48:49], v[16:23] ; cc464010 1c426160
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[98:99], v[48:49], v[32:39] ; cc464020 1c826162
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[98:99], v[54:55], v[40:47] ; cc464028 1ca26d62
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[96:97], v[54:55], v[24:31] ; cc464018 1c626d60
BB1:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s1, s8                                         ; bf090801
	s_cbranch_scc0 BB3                                          ; bfa1feef
BB4:
	v_cmpx_gt_u32_e32 s6, v1                                    ; 7d980206
	s_cbranch_execz BB28                                        ; bfa50231
BB5:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[12:13], 0x40                        ; f4004406 f8000040
	s_load_b128 s[12:15], s[12:13], 0x10                        ; f4004306 f8000010
	v_add3_u32 v1, v12, s5, v7                                  ; d6550001 041c0b0c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v1, 1, v1                                 ; 30020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v3, v1, s[16:19], null offen            ; c408007c 40802003 00000001
	v_and_b32_e32 v9, 16, v0                                    ; 36120090
	s_lshr_b32 s1, s7, 4                                        ; 85018407
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v2, v1, vcc_lo                        ; 02000302
	v_lshl_or_b32 v9, v9, 3, v12                                ; d6560009 04310709
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_add_lshl_u32 v11, v6, v8, 8                               ; d647000b 02221106
	v_add3_u32 v13, v9, s2, v11                                 ; d655000d 042c0509
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v48, v13, s[12:15], null offen           ; c407807c 40801830 0000000d
	buffer_load_d16_u8 v49, v13, s[12:15], null offen offset:16 ; c407807c 40801831 0000100d
	buffer_load_d16_u8 v50, v13, s[12:15], null offen offset:32 ; c407807c 40801832 0000200d
	buffer_load_d16_u8 v51, v13, s[12:15], null offen offset:48 ; c407807c 40801833 0000300d
	buffer_load_d16_u8 v52, v13, s[12:15], null offen offset:64 ; c407807c 40801834 0000400d
	buffer_load_d16_u8 v53, v13, s[12:15], null offen offset:80 ; c407807c 40801835 0000500d
	buffer_load_d16_u8 v54, v13, s[12:15], null offen offset:96 ; c407807c 40801836 0000600d
	buffer_load_d16_u8 v55, v13, s[12:15], null offen offset:112 ; c407807c 40801837 0000700d
	s_lshr_b32 s4, s10, 2                                       ; 8504820a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_f32_u32 s8, s4                                        ; be886504
(invalid instruction)                                        ; d6840008
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                      ; 02010008
	v_bfe_u32 v60, v15, 1, 1                                    ; d610003c 0205030f
	s_mul_f32 s8, s8, 0x4f7ffffe                                ; a208ff08 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s8, s8                                        ; be886708
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s20, s4, s8                                       ; 96140804
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s20, 0, s20                                    ; 81941480
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s20, s8, s20                                   ; 96941408
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s8, s8, s20                                    ; 80081408
	s_add_co_u32 s21, s11, 1                                    ; 8015810b
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d0038
	v_cndmask_b32_e32 v0, v2, v8, vcc_lo                        ; 02001102
	s_lshr_b32 s21, s21, 1                                      ; 85158115
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s21, s21, 3                                    ; 80158315
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s21, s21, -4                                      ; 8b15c415
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d72c0039
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                       ; 02000938
	s_cselect_b32 s22, -1, 0                                    ; 981680c1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v2, v2, v57                                ; 4c047302
(invalid instruction)                                        ; d7026a3a
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                        ; 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cndmask_b32_e32 v58, v58, v2, vcc_lo                      ; 0274053a
	v_subrev_co_ci_u32_e32 v56, vcc_lo, -1, v56, vcc_lo         ; 447070c1
(invalid instruction)                                        ; d702043b
	v_cndmask_b32_e32 v1, s4, v58, vcc_lo                       ; 02027404
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v59, v59, v58, s4                         ; d501003b 0012753b
	v_subrev_co_ci_u32_e64 v56, vcc_lo, -1, v56, s4             ; d5226a38 001270c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_lshl_add_u32 v60, v59, 1, v60                             ; d646003c 04f1033b
	v_lshl_add_u32 v56, v56, 1, v14                             ; d6460038 04390338
	v_cmp_le_u32_e32 vcc_lo, s21, v56                           ; 7c967015
	s_nand_b32 s22, s22, vcc_lo                                 ; 8e166a16
	s_add_co_u32 s23, s10, 1                                    ; 8017810a
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshr_b32 s23, s23, 1                                      ; 85178117
	s_add_co_u32 s23, s23, 3                                    ; 80178317
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v61, v48                                  ; 7e7ad930
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v65, v49                                  ; 7e82d931
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v69, v50                                  ; 7e8ad932
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v73, v51                                  ; 7e92d933
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v61, v3, v61, v16 op_sel_hi:[1,0,0]           ; cc20003d 0c427b03
	v_fma_mix_f32 v65, v3, v65, v17 op_sel_hi:[1,0,0]           ; cc200041 0c468303
	v_fma_mix_f32 v69, v3, v69, v18 op_sel_hi:[1,0,0]           ; cc200045 0c4a8b03
	v_fma_mix_f32 v73, v3, v73, v19 op_sel_hi:[1,0,0]           ; cc200049 0c4e9303
	v_cvt_f16_f32_e32 v62, v61                                  ; 7e7c153d
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v77, v52                                  ; 7e9ad934
	v_cvt_f16_f32_e32 v66, v65                                  ; 7e841541
	v_cvt_f16_f32_e32 v70, v69                                  ; 7e8c1545
	v_cvt_f16_f32_e32 v74, v73                                  ; 7e941549
	v_maxmin_num_f16 v62, 0xdf00, v62, neg(0xdf00)              ; d66b003e 83fe7cff 0000df00
	v_fma_mix_f32 v77, v3, v77, v20 op_sel_hi:[1,0,0]           ; cc20004d 0c529b03
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v81, v53                                  ; 7ea2d935
	v_maxmin_num_f16 v66, 0xdf00, v66, neg(0xdf00)              ; d66b0042 83fe84ff 0000df00
	v_maxmin_num_f16 v70, 0xdf00, v70, neg(0xdf00)              ; d66b0046 83fe8cff 0000df00
	v_maxmin_num_f16 v74, 0xdf00, v74, neg(0xdf00)              ; d66b004a 83fe94ff 0000df00
	v_cvt_f32_f16_e32 v63, v62                                  ; 7e7e173e
	v_cvt_f16_f32_e32 v78, v77                                  ; 7e9c154d
	v_fma_mix_f32 v81, v3, v81, v21 op_sel_hi:[1,0,0]           ; cc200051 0c56a303
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v85, v54                                  ; 7eaad936
	v_cvt_f32_f16_e32 v67, v66                                  ; 7e861742
	v_cvt_f32_f16_e32 v71, v70                                  ; 7e8e1746
	v_cvt_f32_f16_e32 v75, v74                                  ; 7e96174a
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v0, v63, v128, vcc_lo                     ; 0201013f
	v_maxmin_num_f16 v78, 0xdf00, v78, neg(0xdf00)              ; d66b004e 83fe9cff 0000df00
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v89, v55                                  ; 7eb2d937
	v_cvt_f16_f32_e32 v82, v81                                  ; 7ea41551
	v_fma_mix_f32 v85, v3, v85, v22 op_sel_hi:[1,0,0]           ; cc200055 0c5aab03
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v0, v67, v128, vcc_lo                     ; 02010143
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v0, v71, v128, vcc_lo                     ; 02010147
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v0, v75, v128, vcc_lo                     ; 0201014b
	v_cvt_f32_f16_e32 v79, v78                                  ; 7e9e174e
	v_fma_mix_f32 v89, v3, v89, v23 op_sel_hi:[1,0,0]           ; cc200059 0c5eb303
	v_maxmin_num_f16 v82, 0xdf00, v82, neg(0xdf00)              ; d66b0052 83fea4ff 0000df00
	v_cvt_f16_f32_e32 v86, v85                                  ; 7eac1555
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v0, v79, v128, vcc_lo                     ; 0201014f
	v_cvt_f16_f32_e32 v90, v89                                  ; 7eb41559
	v_cvt_f32_f16_e32 v83, v82                                  ; 7ea61752
	v_maxmin_num_f16 v86, 0xdf00, v86, neg(0xdf00)              ; d66b0056 83feacff 0000df00
	v_maxmin_num_f16 v90, 0xdf00, v90, neg(0xdf00)              ; d66b005a 83feb4ff 0000df00
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v0, v83, v128, vcc_lo                     ; 02010153
	v_cvt_f32_f16_e32 v87, v86                                  ; 7eae1756
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_cvt_f32_f16_e32 v91, v90                                  ; 7eb6175a
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v0, v87, v128, vcc_lo                     ; 02010157
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v0, v91, v128, vcc_lo                     ; 0201015b
	s_and_saveexec_b32 s24, s22                                 ; be982016
	s_cbranch_execz BB11                                        ; bfa5002d
BB6:
	v_and_b32_e32 v13, 3, v56                                   ; 361a7083
	v_and_b32_e32 v16, 3, v60                                   ; 36207883
	s_bfe_u32 s4, s23, 0x1e0002                                 ; 9304ff17 001e0002
	v_lshrrev_b32_e32 v2, 2, v56                                ; 32047082
	v_lshrrev_b32_e32 v3, 2, v60                                ; 32067882
	v_fma_mixlo_f16 v17, 1.0, v61, v65                          ; cc210011 05067af2
	v_fma_mixlo_f16 v18, 1.0, v77, v81                          ; cc210012 05469af2
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a4
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                        ; 02000902
	v_add_f16_e32 v17, v17, v18                                 ; 64222511
	v_mul_f16_e32 v17, 0x3400, v17                              ; 6a2222ff 00003400
	v_add_lshl_u32 v2, v2, v3, 4                                ; d6470002 02120702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_maxmin_num_f16 v17, 0xdf00, v17, neg(0xdf00)              ; d66b0011 83fe22ff 0000df00
	v_lshl_add_u32 v13, v13, 2, v2                              ; d646000d 0409050d
	v_cvt_f32_f16_e32 v20, v17                                  ; 7e281711
	v_add_nc_u32_e32 v13, v13, v16                              ; 4a1a210d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v0, v20, v128, vcc_lo                     ; 02010114
	v_lshrrev_b32_e32 v19, 4, v13                               ; 32261a84
	v_and_b32_e32 v13, 15, v13                                  ; 361a1a8f
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v0, v19, v1, vcc_lo                       ; 02000313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v19, v19, v8, 8                              ; d6470013 02221113
	v_add_nc_u32_e32 v19, s9, v19                               ; 4a262609
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v13, v13, 4, v19                             ; d646000d 044d090d
	v_add_nc_u32_e32 v13, v13, v12                              ; 4a1a190d
	buffer_store_b8 v21, v13, s[12:15], null offen              ; c406007c 40801815 0000000d
BB11:
	s_mov_b32 exec_lo, s24                                      ; befe0018
	v_add_nc_u32_e32 v2, 2, v15                                 ; 4a041e82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_bfe_u32 v2, v2, 1, 1                                      ; d6100002 02050302
	v_lshl_add_u32 v59, v59, 1, v2                              ; d646003b 0409033b
	s_and_b32 exec_lo, s22, exec_lo                             ; 8b7e7e16
	s_cbranch_execz BB17                                        ; bfa5002d
BB12:
	v_and_b32_e32 v13, 3, v56                                   ; 361a7083
	v_and_b32_e32 v16, 3, v59                                   ; 36207683
	s_bfe_u32 s4, s23, 0x1e0002                                 ; 9304ff17 001e0002
	v_lshrrev_b32_e32 v2, 2, v56                                ; 32047082
	v_lshrrev_b32_e32 v3, 2, v59                                ; 32067682
	v_fma_mixlo_f16 v17, 1.0, v69, v73                          ; cc210011 05268af2
	v_fma_mixlo_f16 v18, 1.0, v85, v89                          ; cc210012 0566aaf2
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a4
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                        ; 02000902
	v_add_f16_e32 v17, v17, v18                                 ; 64222511
	v_mul_f16_e32 v17, 0x3400, v17                              ; 6a2222ff 00003400
	v_add_lshl_u32 v2, v2, v3, 4                                ; d6470002 02120702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_maxmin_num_f16 v17, 0xdf00, v17, neg(0xdf00)              ; d66b0011 83fe22ff 0000df00
	v_lshl_add_u32 v13, v13, 2, v2                              ; d646000d 0409050d
	v_cvt_f32_f16_e32 v20, v17                                  ; 7e281711
	v_add_nc_u32_e32 v13, v13, v16                              ; 4a1a210d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v0, v20, v128, vcc_lo                     ; 02010114
	v_lshrrev_b32_e32 v19, 4, v13                               ; 32261a84
	v_and_b32_e32 v13, 15, v13                                  ; 361a1a8f
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v0, v19, v1, vcc_lo                       ; 02000313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v19, v19, v8, 8                              ; d6470013 02221113
	v_add_nc_u32_e32 v19, s9, v19                               ; 4a262609
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v13, v13, 4, v19                             ; d646000d 044d090d
	v_add_nc_u32_e32 v13, v13, v12                              ; 4a1a190d
	buffer_store_b8 v21, v13, s[12:15], null offen              ; c406007c 40801815 0000000d
BB17:
	s_mov_b32 exec_lo, s24                                      ; befe0018
	buffer_load_d16_b16 v1, v1, s[16:19], null offen offset:32  ; c408007c 40802001 00002001
	v_add3_u32 v11, v9, s3, v11                                 ; d655000b 042c0709
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v64, v11, s[12:15], null offen              ; c406007c 40801840 0000000b
	buffer_store_b8 v68, v11, s[12:15], null offen offset:16    ; c406007c 40801844 0000100b
	buffer_store_b8 v72, v11, s[12:15], null offen offset:32    ; c406007c 40801848 0000200b
	buffer_store_b8 v76, v11, s[12:15], null offen offset:48    ; c406007c 4080184c 0000300b
	buffer_store_b8 v80, v11, s[12:15], null offen offset:64    ; c406007c 40801850 0000400b
	buffer_store_b8 v84, v11, s[12:15], null offen offset:80    ; c406007c 40801854 0000500b
	buffer_store_b8 v88, v11, s[12:15], null offen offset:96    ; c406007c 40801858 0000600b
	buffer_store_b8 v92, v11, s[12:15], null offen offset:112   ; c406007c 4080185c 0000700b
	v_add_lshl_u32 v6, v6, v10, 8                               ; d6470006 02221506
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v9, s2, v6                                   ; d6550002 04180509
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v3, v2, s[12:15], null offen             ; c407807c 40801803 00000002
	buffer_load_d16_u8 v11, v2, s[12:15], null offen offset:16  ; c407807c 4080180b 00001002
	buffer_load_d16_u8 v13, v2, s[12:15], null offen offset:32  ; c407807c 4080180d 00002002
	buffer_load_d16_u8 v16, v2, s[12:15], null offen offset:48  ; c407807c 40801810 00003002
	buffer_load_d16_u8 v17, v2, s[12:15], null offen offset:64  ; c407807c 40801811 00004002
	buffer_load_d16_u8 v18, v2, s[12:15], null offen offset:80  ; c407807c 40801812 00005002
	buffer_load_d16_u8 v19, v2, s[12:15], null offen offset:96  ; c407807c 40801813 00006002
	buffer_load_d16_u8 v20, v2, s[12:15], null offen offset:112 ; c407807c 40801814 00007002
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v21, v3                                   ; 7e2ad903
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v48, v11                                  ; 7e60d90b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v52, v13                                  ; 7e68d90d
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v57, v16                                  ; 7e72d910
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v21, v1, v21, v24 op_sel_hi:[1,0,0]           ; cc200015 0c622b01
	v_fma_mix_f32 v48, v1, v48, v25 op_sel_hi:[1,0,0]           ; cc200030 0c666101
	v_fma_mix_f32 v52, v1, v52, v26 op_sel_hi:[1,0,0]           ; cc200034 0c6a6901
	v_fma_mix_f32 v57, v1, v57, v27 op_sel_hi:[1,0,0]           ; cc200039 0c6e7301
	v_cvt_f16_f32_e32 v22, v21                                  ; 7e2c1515
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v63, v17                                  ; 7e7ed911
	v_cvt_f16_f32_e32 v49, v48                                  ; 7e621530
	v_cvt_f16_f32_e32 v53, v52                                  ; 7e6a1534
	v_cvt_f16_f32_e32 v58, v57                                  ; 7e741539
	v_maxmin_num_f16 v22, 0xdf00, v22, neg(0xdf00)              ; d66b0016 83fe2cff 0000df00
	v_fma_mix_f32 v63, v1, v63, v28 op_sel_hi:[1,0,0]           ; cc20003f 0c727f01
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v67, v18                                  ; 7e86d912
	v_maxmin_num_f16 v49, 0xdf00, v49, neg(0xdf00)              ; d66b0031 83fe62ff 0000df00
	v_maxmin_num_f16 v53, 0xdf00, v53, neg(0xdf00)              ; d66b0035 83fe6aff 0000df00
	v_maxmin_num_f16 v58, 0xdf00, v58, neg(0xdf00)              ; d66b003a 83fe74ff 0000df00
	v_cvt_f32_f16_e32 v23, v22                                  ; 7e2e1716
	v_cvt_f16_f32_e32 v64, v63                                  ; 7e80153f
	v_fma_mix_f32 v67, v1, v67, v29 op_sel_hi:[1,0,0]           ; cc200043 0c768701
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v71, v19                                  ; 7e8ed913
	v_cvt_f32_f16_e32 v50, v49                                  ; 7e641731
	v_cvt_f32_f16_e32 v54, v53                                  ; 7e6c1735
	v_cvt_f32_f16_e32 v61, v58                                  ; 7e7a173a
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v0, v23, v128, vcc_lo                     ; 02010117
	v_maxmin_num_f16 v64, 0xdf00, v64, neg(0xdf00)              ; d66b0040 83fe80ff 0000df00
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v75, v20                                  ; 7e96d914
	v_cvt_f16_f32_e32 v68, v67                                  ; 7e881543
	v_fma_mix_f32 v71, v1, v71, v30 op_sel_hi:[1,0,0]           ; cc200047 0c7a8f01
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v0, v50, v128, vcc_lo                     ; 02010132
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v0, v54, v128, vcc_lo                     ; 02010136
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v0, v61, v128, vcc_lo                     ; 0201013d
	v_cvt_f32_f16_e32 v65, v64                                  ; 7e821740
	v_fma_mix_f32 v75, v1, v75, v31 op_sel_hi:[1,0,0]           ; cc20004b 0c7e9701
	v_maxmin_num_f16 v68, 0xdf00, v68, neg(0xdf00)              ; d66b0044 83fe88ff 0000df00
	v_cvt_f16_f32_e32 v72, v71                                  ; 7e901547
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v0, v65, v128, vcc_lo                     ; 02010141
	v_cvt_f16_f32_e32 v76, v75                                  ; 7e98154b
	v_cvt_f32_f16_e32 v69, v68                                  ; 7e8a1744
	v_maxmin_num_f16 v72, 0xdf00, v72, neg(0xdf00)              ; d66b0048 83fe90ff 0000df00
	v_maxmin_num_f16 v76, 0xdf00, v76, neg(0xdf00)              ; d66b004c 83fe98ff 0000df00
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v0, v69, v128, vcc_lo                     ; 02010145
	v_cvt_f32_f16_e32 v73, v72                                  ; 7e921748
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_cvt_f32_f16_e32 v77, v76                                  ; 7e9a174c
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v0, v73, v128, vcc_lo                     ; 02010149
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v0, v77, v128, vcc_lo                     ; 0201014d
	s_and_b32 exec_lo, s22, exec_lo                             ; 8b7e7e16
	s_cbranch_execz BB23                                        ; bfa5004c
BB18:
	v_lshrrev_b32_e32 v1, 2, v56                                ; 32027082
	v_and_b32_e32 v56, 3, v56                                   ; 36707083
	v_lshrrev_b32_e32 v2, 2, v60                                ; 32047882
	v_and_b32_e32 v60, 3, v60                                   ; 36787883
	s_bfe_u32 s23, s23, 0x1e0002                                ; 9317ff17 001e0002
	v_lshrrev_b32_e32 v18, 2, v59                               ; 32247682
	v_and_b32_e32 v59, 3, v59                                   ; 36767683
	v_fma_mixlo_f16 v3, 1.0, v21, v48                           ; cc210003 04c22af2
	v_lshlrev_b32_e32 v56, 2, v56                               ; 30707082
(invalid instruction)                                        ; d72c0001
	v_cndmask_b32_e32 v0, v1, v23, vcc_lo                       ; 02002f01
	v_fma_mixlo_f16 v11, 1.0, v63, v67                          ; cc21000b 050e7ef2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_add_f16_e32 v3, v3, v11                                   ; 64061703
	v_add_lshl_u32 v2, v1, v2, 4                                ; d6470002 02120501
	v_add_lshl_u32 v1, v1, v18, 4                               ; d6470001 02122501
	v_add3_u32 v60, v60, v2, v56                                ; d655003c 04e2053c
	v_add3_u32 v59, v59, v1, v56                                ; d655003b 04e2033b
	v_mul_f16_e32 v3, 0x3400, v3                                ; 6a0606ff 00003400
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_lshrrev_b32_e32 v13, 4, v60                               ; 321a7884
	v_and_b32_e32 v60, 15, v60                                  ; 3678788f
	v_lshrrev_b32_e32 v21, 4, v59                               ; 322a7684
	v_and_b32_e32 v59, 15, v59                                  ; 3676768f
	v_maxmin_num_f16 v3, 0xdf00, v3, neg(0xdf00)                ; d66b0003 83fe06ff 0000df00
	v_fma_mixlo_f16 v19, 1.0, v52, v57                          ; cc210013 04e668f2
	v_fma_mixlo_f16 v20, 1.0, v71, v75                          ; cc210014 052e8ef2
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v13, v1, vcc_lo                       ; 0200030d
(invalid instruction)                                        ; d72c0015
	v_cndmask_b32_e32 v0, v21, v1, vcc_lo                       ; 02000315
	v_cvt_f32_f16_e32 v16, v3                                   ; 7e201703
	v_add_f16_e32 v19, v19, v20                                 ; 64262913
	v_add_lshl_u32 v13, v13, v10, 8                             ; d647000d 0222150d
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
	v_mul_f16_e32 v19, 0x3400, v19                              ; 6a2626ff 00003400
	v_add_lshl_u32 v21, v21, v10, 8                             ; d6470015 02221515
	v_add_nc_u32_e32 v13, s9, v13                               ; 4a1a1a09
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
	v_add_nc_u32_e32 v21, s9, v21                               ; 4a2a2a09
	v_lshl_add_u32 v60, v60, 4, v13                             ; d646003c 0435093c
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_cvt_f32_f16_e32 v22, v19                                  ; 7e2c1713
	v_lshl_add_u32 v59, v59, 4, v21                             ; d646003b 0455093b
	v_add_nc_u32_e32 v60, v60, v12                              ; 4a78193c
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v0, v22, v128, vcc_lo                     ; 02010116
	v_add_nc_u32_e32 v59, v59, v12                              ; 4a76193b
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v17, v60, s[12:15], null offen              ; c406007c 40801811 0000003c
	buffer_store_b8 v23, v59, s[12:15], null offen              ; c406007c 40801817 0000003b
BB23:
	s_mov_b32 exec_lo, s24                                      ; befe0018
	v_add3_u32 v9, v9, s3, v6                                   ; d6550009 04180709
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v24, v9, s[12:15], null offen               ; c406007c 40801818 00000009
	buffer_store_b8 v51, v9, s[12:15], null offen offset:16     ; c406007c 40801833 00001009
	buffer_store_b8 v55, v9, s[12:15], null offen offset:32     ; c406007c 40801837 00002009
	buffer_store_b8 v62, v9, s[12:15], null offen offset:48     ; c406007c 4080183e 00003009
	buffer_store_b8 v66, v9, s[12:15], null offen offset:64     ; c406007c 40801842 00004009
	buffer_store_b8 v70, v9, s[12:15], null offen offset:80     ; c406007c 40801846 00005009
	buffer_store_b8 v74, v9, s[12:15], null offen offset:96     ; c406007c 4080184a 00006009
	buffer_store_b8 v78, v9, s[12:15], null offen offset:112    ; c406007c 4080184e 00007009
BB28:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cmpx_gt_u32_e32 s6, v4                                    ; 7d980806
	s_cbranch_execz BB52                                        ; bfa50234
BB29:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[12:15], s[0:1], 0x40                          ; f4004300 f8000040
	s_load_b128 s[16:19], s[0:1], 0x10                          ; f4004400 f8000010
	v_add3_u32 v7, v12, s5, v7                                  ; d6550007 041c0b0c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v7, 1, v7                                 ; 300e0e81
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v1, v7, s[12:15], null offen            ; c408007c 40801801 00000007
	v_and_b32_e32 v0, 16, v0                                    ; 36000090
	s_lshr_b32 s7, s7, 4                                        ; 85078407
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v5, v7, vcc_lo                        ; 02000f05
	v_lshl_or_b32 v0, v0, 3, v12                                ; d6560000 04310700
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_add_lshl_u32 v3, v2, v8, 8                                ; d6470003 02221102
	v_add3_u32 v4, v0, s2, v3                                   ; d6550004 040c0500
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v6, v4, s[16:19], null offen             ; c407807c 40802006 00000004
	buffer_load_d16_u8 v9, v4, s[16:19], null offen offset:16   ; c407807c 40802009 00001004
	buffer_load_d16_u8 v11, v4, s[16:19], null offen offset:32  ; c407807c 4080200b 00002004
	buffer_load_d16_u8 v13, v4, s[16:19], null offen offset:48  ; c407807c 4080200d 00003004
	buffer_load_d16_u8 v16, v4, s[16:19], null offen offset:64  ; c407807c 40802010 00004004
	buffer_load_d16_u8 v17, v4, s[16:19], null offen offset:80  ; c407807c 40802011 00005004
	buffer_load_d16_u8 v18, v4, s[16:19], null offen offset:96  ; c407807c 40802012 00006004
	buffer_load_d16_u8 v19, v4, s[16:19], null offen offset:112 ; c407807c 40802013 00007004
	s_lshr_b32 s0, s10, 2                                       ; 8500820a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_f32_u32 s1, s0                                        ; be816500
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840001
	v_cndmask_b32_e32 v0, s1, v128, vcc_lo                      ; 02010001
	v_bfe_u32 v24, v15, 1, 1                                    ; d6100018 0205030f
	s_mul_f32 s1, s1, 0x4f7ffffe                                ; a201ff01 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s1, s1                                        ; be816701
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s4, s0, s1                                        ; 96040100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s4, 0, s4                                      ; 81840480
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s4, s1, s4                                     ; 96840401
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s1, s1, s4                                     ; 80010401
	s_add_co_u32 s5, s11, 1                                     ; 8005810b
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d0014
	v_cndmask_b32_e32 v0, v5, v1, vcc_lo                        ; 02000305
	s_lshr_b32 s5, s5, 1                                        ; 85058105
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s5, s5, 3                                      ; 80058305
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s5, s5, -4                                        ; 8b05c405
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d72c0015
	v_cndmask_b32_e32 v0, v20, v0, vcc_lo                       ; 02000114
	s_cselect_b32 s6, -1, 0                                     ; 980680c1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v5, v5, v21                                ; 4c0a2b05
(invalid instruction)                                        ; d7026a16
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                        ; 02020a00
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v22, v22, v5, vcc_lo                      ; 022c0b16
	v_subrev_co_ci_u32_e32 v20, vcc_lo, -1, v20, vcc_lo         ; 442828c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d7020017
	v_cndmask_b32_e32 v1, s0, v22, vcc_lo                       ; 02022c00
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v23, v23, v22, s0                         ; d5010017 00022d17
	v_subrev_co_ci_u32_e64 v20, vcc_lo, -1, v20, s0             ; d5226a14 000228c1
	v_lshl_add_u32 v24, v23, 1, v24                             ; d6460018 04610317
	v_lshl_add_u32 v20, v20, 1, v14                             ; d6460014 04390314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b1
	v_cmp_le_u32_e32 vcc_lo, s5, v20                            ; 7c962805
	s_nand_b32 s6, s6, vcc_lo                                   ; 8e066a06
	s_add_co_u32 s10, s10, 1                                    ; 800a810a
	s_lshr_b32 s10, s10, 1                                      ; 850a810a
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870159
	s_add_co_u32 s10, s10, 3                                    ; 800a830a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v25, v6                                   ; 7e32d906
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v29, v9                                   ; 7e3ad909
	v_fma_mix_f32 v25, v1, v25, v32 op_sel_hi:[1,0,0]           ; cc200019 0c823301
	v_fma_mix_f32 v29, v1, v29, v33 op_sel_hi:[1,0,0]           ; cc20001d 0c863b01
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v33, v11                                  ; 7e42d90b
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v50, v13                                  ; 7e64d90d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v26, v25                                  ; 7e341519
	v_cvt_f16_f32_e32 v30, v29                                  ; 7e3c151d
	v_fma_mix_f32 v33, v1, v33, v34 op_sel_hi:[1,0,0]           ; cc200021 0c8a4301
	v_fma_mix_f32 v50, v1, v50, v35 op_sel_hi:[1,0,0]           ; cc200032 0c8e6501
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v54, v16                                  ; 7e6cd910
	v_maxmin_num_f16 v26, 0xdf00, v26, neg(0xdf00)              ; d66b001a 83fe34ff 0000df00
	v_maxmin_num_f16 v30, 0xdf00, v30, neg(0xdf00)              ; d66b001e 83fe3cff 0000df00
	v_cvt_f16_f32_e32 v34, v33                                  ; 7e441521
	v_cvt_f16_f32_e32 v51, v50                                  ; 7e661532
	v_fma_mix_f32 v54, v1, v54, v36 op_sel_hi:[1,0,0]           ; cc200036 0c926d01
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v58, v17                                  ; 7e74d911
	v_cvt_f32_f16_e32 v27, v26                                  ; 7e36171a
	v_cvt_f32_f16_e32 v31, v30                                  ; 7e3e171e
	v_maxmin_num_f16 v34, 0xdf00, v34, neg(0xdf00)              ; d66b0022 83fe44ff 0000df00
	v_maxmin_num_f16 v51, 0xdf00, v51, neg(0xdf00)              ; d66b0033 83fe66ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v62, v18                                  ; 7e7cd912
	v_cvt_f16_f32_e32 v55, v54                                  ; 7e6e1536
	v_fma_mix_f32 v58, v1, v58, v37 op_sel_hi:[1,0,0]           ; cc20003a 0c967501
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v0, v27, v128, vcc_lo                     ; 0201011b
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v0, v31, v128, vcc_lo                     ; 0201011f
	v_cvt_f32_f16_e32 v48, v34                                  ; 7e601722
	v_cvt_f32_f16_e32 v52, v51                                  ; 7e681733
	v_fma_mix_f32 v62, v1, v62, v38 op_sel_hi:[1,0,0]           ; cc20003e 0c9a7d01
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v66, v19                                  ; 7e84d913
	v_maxmin_num_f16 v55, 0xdf00, v55, neg(0xdf00)              ; d66b0037 83fe6eff 0000df00
	v_cvt_f16_f32_e32 v59, v58                                  ; 7e76153a
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v0, v52, v128, vcc_lo                     ; 02010134
	v_cvt_f16_f32_e32 v63, v62                                  ; 7e7e153e
	v_fma_mix_f32 v66, v1, v66, v39 op_sel_hi:[1,0,0]           ; cc200042 0c9e8501
	v_cvt_f32_f16_e32 v56, v55                                  ; 7e701737
	v_maxmin_num_f16 v59, 0xdf00, v59, neg(0xdf00)              ; d66b003b 83fe76ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_maxmin_num_f16 v63, 0xdf00, v63, neg(0xdf00)              ; d66b003f 83fe7eff 0000df00
	v_cvt_f16_f32_e32 v67, v66                                  ; 7e861542
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v0, v56, v128, vcc_lo                     ; 02010138
	v_cvt_f32_f16_e32 v60, v59                                  ; 7e78173b
	v_cvt_f32_f16_e32 v64, v63                                  ; 7e80173f
	v_maxmin_num_f16 v67, 0xdf00, v67, neg(0xdf00)              ; d66b0043 83fe86ff 0000df00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v0, v60, v128, vcc_lo                     ; 0201013c
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v0, v64, v128, vcc_lo                     ; 02010140
	v_cvt_f32_f16_e32 v68, v67                                  ; 7e881743
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v0, v68, v128, vcc_lo                     ; 02010144
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_saveexec_b32 s8, s6                                   ; be882006
	s_cbranch_execz BB35                                        ; bfa5002d
BB30:
	v_and_b32_e32 v5, 3, v20                                    ; 360a2883
	v_and_b32_e32 v6, 3, v24                                    ; 360c3083
	s_bfe_u32 s0, s10, 0x1e0002                                 ; 9300ff0a 001e0002
	v_lshrrev_b32_e32 v1, 2, v20                                ; 32022882
	v_lshrrev_b32_e32 v4, 2, v24                                ; 32083082
	v_fma_mixlo_f16 v9, 1.0, v25, v29                           ; cc210009 047632f2
	v_fma_mixlo_f16 v11, 1.0, v54, v58                          ; cc21000b 04ea6cf2
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a4
(invalid instruction)                                        ; d72c0001
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                        ; 02000101
	v_add_f16_e32 v9, v9, v11                                   ; 64121709
	v_mul_f16_e32 v9, 0x3400, v9                                ; 6a1212ff 00003400
	v_add_lshl_u32 v1, v1, v4, 4                                ; d6470001 02120901
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_maxmin_num_f16 v9, 0xdf00, v9, neg(0xdf00)                ; d66b0009 83fe12ff 0000df00
	v_lshl_add_u32 v5, v5, 2, v1                                ; d6460005 04050505
	v_cvt_f32_f16_e32 v14, v9                                   ; 7e1c1709
	v_add_nc_u32_e32 v5, v5, v6                                 ; 4a0a0d05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	v_lshrrev_b32_e32 v13, 4, v5                                ; 321a0a84
	v_and_b32_e32 v5, 15, v5                                    ; 360a0a8f
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v13, v7, vcc_lo                       ; 02000f0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v13, v13, v8, 8                              ; d647000d 0222110d
	v_add_nc_u32_e32 v13, s9, v13                               ; 4a1a1a09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v5, v5, 4, v13                               ; d6460005 04350905
	v_add_nc_u32_e32 v5, v5, v12                                ; 4a0a1905
	buffer_store_b8 v16, v5, s[16:19], null offen               ; c406007c 40802010 00000005
BB35:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, s8                                       ; befe0008
	v_add_nc_u32_e32 v15, 2, v15                                ; 4a1e1e82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_bfe_u32 v15, v15, 1, 1                                    ; d610000f 0205030f
	v_lshl_add_u32 v23, v23, 1, v15                             ; d6460017 043d0317
	s_and_b32 exec_lo, s6, exec_lo                              ; 8b7e7e06
	s_cbranch_execz BB41                                        ; bfa5002d
BB36:
	v_and_b32_e32 v5, 3, v20                                    ; 360a2883
	v_and_b32_e32 v6, 3, v23                                    ; 360c2e83
	s_bfe_u32 s0, s10, 0x1e0002                                 ; 9300ff0a 001e0002
	v_lshrrev_b32_e32 v1, 2, v20                                ; 32022882
	v_lshrrev_b32_e32 v4, 2, v23                                ; 32082e82
	v_fma_mixlo_f16 v9, 1.0, v33, v50                           ; cc210009 04ca42f2
	v_fma_mixlo_f16 v11, 1.0, v62, v66                          ; cc21000b 050a7cf2
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a4
(invalid instruction)                                        ; d72c0001
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                        ; 02000101
	v_add_f16_e32 v9, v9, v11                                   ; 64121709
	v_mul_f16_e32 v9, 0x3400, v9                                ; 6a1212ff 00003400
	v_add_lshl_u32 v1, v1, v4, 4                                ; d6470001 02120901
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_maxmin_num_f16 v9, 0xdf00, v9, neg(0xdf00)                ; d66b0009 83fe12ff 0000df00
	v_lshl_add_u32 v5, v5, 2, v1                                ; d6460005 04050505
	v_cvt_f32_f16_e32 v14, v9                                   ; 7e1c1709
	v_add_nc_u32_e32 v5, v5, v6                                 ; 4a0a0d05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	v_lshrrev_b32_e32 v13, 4, v5                                ; 321a0a84
	v_and_b32_e32 v5, 15, v5                                    ; 360a0a8f
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v13, v7, vcc_lo                       ; 02000f0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v13, v13, v8, 8                              ; d647000d 0222110d
	v_add_nc_u32_e32 v13, s9, v13                               ; 4a1a1a09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v5, v5, 4, v13                               ; d6460005 04350905
	v_add_nc_u32_e32 v5, v5, v12                                ; 4a0a1905
	buffer_store_b8 v15, v5, s[16:19], null offen               ; c406007c 4080200f 00000005
BB41:
	s_mov_b32 exec_lo, s8                                       ; befe0008
	buffer_load_d16_b16 v1, v7, s[12:15], null offen offset:32  ; c408007c 40801801 00002007
	v_add3_u32 v3, v0, s3, v3                                   ; d6550003 040c0700
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v28, v3, s[16:19], null offen               ; c406007c 4080201c 00000003
	buffer_store_b8 v32, v3, s[16:19], null offen offset:16     ; c406007c 40802020 00001003
	buffer_store_b8 v49, v3, s[16:19], null offen offset:32     ; c406007c 40802031 00002003
	buffer_store_b8 v53, v3, s[16:19], null offen offset:48     ; c406007c 40802035 00003003
	buffer_store_b8 v57, v3, s[16:19], null offen offset:64     ; c406007c 40802039 00004003
	buffer_store_b8 v61, v3, s[16:19], null offen offset:80     ; c406007c 4080203d 00005003
	buffer_store_b8 v65, v3, s[16:19], null offen offset:96     ; c406007c 40802041 00006003
	buffer_store_b8 v69, v3, s[16:19], null offen offset:112    ; c406007c 40802045 00007003
	v_add_lshl_u32 v2, v2, v10, 8                               ; d6470002 02221502
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v3, v0, s2, v2                                   ; d6550003 04080500
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v4, v3, s[16:19], null offen             ; c407807c 40802004 00000003
	buffer_load_d16_u8 v5, v3, s[16:19], null offen offset:16   ; c407807c 40802005 00001003
	buffer_load_d16_u8 v6, v3, s[16:19], null offen offset:32   ; c407807c 40802006 00002003
	buffer_load_d16_u8 v7, v3, s[16:19], null offen offset:48   ; c407807c 40802007 00003003
	buffer_load_d16_u8 v8, v3, s[16:19], null offen offset:64   ; c407807c 40802008 00004003
	buffer_load_d16_u8 v9, v3, s[16:19], null offen offset:80   ; c407807c 40802009 00005003
	buffer_load_d16_u8 v11, v3, s[16:19], null offen offset:96  ; c407807c 4080200b 00006003
	buffer_load_d16_u8 v13, v3, s[16:19], null offen offset:112 ; c407807c 4080200d 00007003
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v14, v4                                   ; 7e1cd904
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v18, v5                                   ; 7e24d905
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v25, v6                                   ; 7e32d906
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v29, v7                                   ; 7e3ad907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_fma_mix_f32 v14, v1, v14, v40 op_sel_hi:[1,0,0]           ; cc20000e 0ca21d01
	v_fma_mix_f32 v18, v1, v18, v41 op_sel_hi:[1,0,0]           ; cc200012 0ca62501
	v_fma_mix_f32 v25, v1, v25, v42 op_sel_hi:[1,0,0]           ; cc200019 0caa3301
	v_fma_mix_f32 v29, v1, v29, v43 op_sel_hi:[1,0,0]           ; cc20001d 0cae3b01
	v_cvt_f16_f32_e32 v15, v14                                  ; 7e1e150e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v33, v8                                   ; 7e42d908
	v_cvt_f16_f32_e32 v19, v18                                  ; 7e261512
	v_cvt_f16_f32_e32 v26, v25                                  ; 7e341519
	v_cvt_f16_f32_e32 v30, v29                                  ; 7e3c151d
	v_maxmin_num_f16 v15, 0xdf00, v15, neg(0xdf00)              ; d66b000f 83fe1eff 0000df00
	v_fma_mix_f32 v33, v1, v33, v44 op_sel_hi:[1,0,0]           ; cc200021 0cb24301
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v37, v9                                   ; 7e4ad909
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
	v_maxmin_num_f16 v26, 0xdf00, v26, neg(0xdf00)              ; d66b001a 83fe34ff 0000df00
	v_maxmin_num_f16 v30, 0xdf00, v30, neg(0xdf00)              ; d66b001e 83fe3cff 0000df00
	v_cvt_f32_f16_e32 v16, v15                                  ; 7e20170f
	v_cvt_f16_f32_e32 v34, v33                                  ; 7e441521
	v_fma_mix_f32 v37, v1, v37, v45 op_sel_hi:[1,0,0]           ; cc200025 0cb64b01
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v41, v11                                  ; 7e52d90b
	v_cvt_f32_f16_e32 v21, v19                                  ; 7e2a1713
	v_cvt_f32_f16_e32 v27, v26                                  ; 7e36171a
	v_cvt_f32_f16_e32 v31, v30                                  ; 7e3e171e
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
	v_maxmin_num_f16 v34, 0xdf00, v34, neg(0xdf00)              ; d66b0022 83fe44ff 0000df00
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v45, v13                                  ; 7e5ad90d
	v_cvt_f16_f32_e32 v38, v37                                  ; 7e4c1525
	v_fma_mix_f32 v41, v1, v41, v46 op_sel_hi:[1,0,0]           ; cc200029 0cba5301
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v0, v27, v128, vcc_lo                     ; 0201011b
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v0, v31, v128, vcc_lo                     ; 0201011f
	v_cvt_f32_f16_e32 v35, v34                                  ; 7e461722
	v_fma_mix_f32 v45, v1, v45, v47 op_sel_hi:[1,0,0]           ; cc20002d 0cbe5b01
	v_maxmin_num_f16 v38, 0xdf00, v38, neg(0xdf00)              ; d66b0026 83fe4cff 0000df00
	v_cvt_f16_f32_e32 v42, v41                                  ; 7e541529
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v0, v35, v128, vcc_lo                     ; 02010123
	v_cvt_f16_f32_e32 v46, v45                                  ; 7e5c152d
	v_cvt_f32_f16_e32 v39, v38                                  ; 7e4e1726
	v_maxmin_num_f16 v42, 0xdf00, v42, neg(0xdf00)              ; d66b002a 83fe54ff 0000df00
	v_maxmin_num_f16 v46, 0xdf00, v46, neg(0xdf00)              ; d66b002e 83fe5cff 0000df00
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v0, v39, v128, vcc_lo                     ; 02010127
	v_cvt_f32_f16_e32 v43, v42                                  ; 7e56172a
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_cvt_f32_f16_e32 v47, v46                                  ; 7e5e172e
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v0, v43, v128, vcc_lo                     ; 0201012b
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v0, v47, v128, vcc_lo                     ; 0201012f
	s_and_b32 exec_lo, s6, exec_lo                              ; 8b7e7e06
	s_cbranch_execz BB47                                        ; bfa5004c
BB42:
	v_lshrrev_b32_e32 v1, 2, v20                                ; 32022882
	v_and_b32_e32 v20, 3, v20                                   ; 36282883
	v_lshrrev_b32_e32 v9, 2, v23                                ; 32122e82
	v_and_b32_e32 v23, 3, v23                                   ; 362e2e83
	s_bfe_u32 s10, s10, 0x1e0002                                ; 930aff0a 001e0002
	v_lshrrev_b32_e32 v3, 2, v24                                ; 32063082
	v_fma_mixlo_f16 v4, 1.0, v14, v18                           ; cc210004 044a1cf2
	v_and_b32_e32 v24, 3, v24                                   ; 36303083
	v_lshlrev_b32_e32 v20, 2, v20                               ; 30282882
(invalid instruction)                                        ; d72c0001
	v_cndmask_b32_e32 v0, v1, v10, vcc_lo                       ; 02001501
	v_fma_mixlo_f16 v5, 1.0, v33, v37                           ; cc210005 049642f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_add_f16_e32 v4, v4, v5                                    ; 64080b04
	v_add_lshl_u32 v3, v1, v3, 4                                ; d6470003 02120701
	v_add_lshl_u32 v1, v1, v9, 4                                ; d6470001 02121301
	v_add3_u32 v24, v24, v3, v20                                ; d6550018 04520718
	v_add3_u32 v23, v23, v1, v20                                ; d6550017 04520317
	v_mul_f16_e32 v4, 0x3400, v4                                ; 6a0808ff 00003400
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_lshrrev_b32_e32 v6, 4, v24                                ; 320c3084
	v_and_b32_e32 v24, 15, v24                                  ; 3630308f
	v_lshrrev_b32_e32 v14, 4, v23                               ; 321c2e84
	v_and_b32_e32 v23, 15, v23                                  ; 362e2e8f
	v_fma_mixlo_f16 v11, 1.0, v25, v29                          ; cc21000b 047632f2
	v_maxmin_num_f16 v4, 0xdf00, v4, neg(0xdf00)                ; d66b0004 83fe08ff 0000df00
	v_fma_mixlo_f16 v13, 1.0, v41, v45                          ; cc21000d 04b652f2
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v6, v7, vcc_lo                        ; 02000f06
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v0, v14, v7, vcc_lo                       ; 02000f0e
	v_cvt_f32_f16_e32 v7, v4                                    ; 7e0e1704
	v_add_f16_e32 v11, v11, v13                                 ; 64161b0b
	v_add_lshl_u32 v6, v6, v10, 8                               ; d6470006 02221506
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v0, v7, v128, vcc_lo                      ; 02010107
	v_mul_f16_e32 v11, 0x3400, v11                              ; 6a1616ff 00003400
	v_add_lshl_u32 v14, v14, v10, 8                             ; d647000e 0222150e
	v_add_nc_u32_e32 v6, s9, v6                                 ; 4a0c0c09
	v_maxmin_num_f16 v11, 0xdf00, v11, neg(0xdf00)              ; d66b000b 83fe16ff 0000df00
	v_add_nc_u32_e32 v14, s9, v14                               ; 4a1c1c09
	v_lshl_add_u32 v24, v24, 4, v6                              ; d6460018 04190918
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_cvt_f32_f16_e32 v15, v11                                  ; 7e1e170b
	v_lshl_add_u32 v23, v23, 4, v14                             ; d6460017 04390917
	v_add_nc_u32_e32 v24, v24, v12                              ; 4a301918
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v0, v15, v128, vcc_lo                     ; 0201010f
	v_add_nc_u32_e32 v23, v23, v12                              ; 4a2e1917
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v8, v24, s[16:19], null offen               ; c406007c 40802008 00000018
	buffer_store_b8 v16, v23, s[16:19], null offen              ; c406007c 40802010 00000017
BB47:
	s_mov_b32 exec_lo, s8                                       ; befe0008
	v_add3_u32 v0, v0, s3, v2                                   ; d6550000 04080700
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v17, v0, s[16:19], null offen               ; c406007c 40802011 00000000
	buffer_store_b8 v22, v0, s[16:19], null offen offset:16     ; c406007c 40802016 00001000
	buffer_store_b8 v28, v0, s[16:19], null offen offset:32     ; c406007c 4080201c 00002000
	buffer_store_b8 v32, v0, s[16:19], null offen offset:48     ; c406007c 40802020 00003000
	buffer_store_b8 v36, v0, s[16:19], null offen offset:64     ; c406007c 40802024 00004000
	buffer_store_b8 v40, v0, s[16:19], null offen offset:80     ; c406007c 40802028 00005000
	buffer_store_b8 v44, v0, s[16:19], null offen offset:96     ; c406007c 4080202c 00006000
	buffer_store_b8 v48, v0, s[16:19], null offen offset:112    ; c406007c 40802030 00007000
BB52:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
