BB0:
	v_and_b32_e32 v3, 31, v0                                    ; 3606009f
	v_bfe_u32 v1, v0, 5, 2                                      ; d6100001 02090b00
	v_and_b32_e32 v0, 15, v0                                    ; 3600008f
	s_lshr_b32 s7, s6, 4                                        ; 85078406
	s_lshl_b32 s8, ttmp9, 5                                     ; 84088575
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_lshr_b32 s9, s8, 4                                        ; 85098408
	v_lshlrev_b32_e32 v0, 4, v0                                 ; 30000084
	s_mul_i32 s9, s9, s7                                        ; 96090709
	s_lshl_b32 s9, s9, 8                                        ; 84098809
	s_add_co_u32 s10, 16, s8                                    ; 800a0890
	v_add3_u32 v4, v0, s1, s9                                   ; d6550004 00240300
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0                ; ca100080 08080080
	s_lshr_b32 s11, s10, 4                                      ; 850b840a
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0              ; ca100080 0a0a0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0              ; ca100080 0c0c0080
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0              ; ca100080 0e0e0080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0              ; ca100080 10100080
	s_mul_i32 s11, s11, s7                                      ; 960b070b
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0              ; ca100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0              ; ca100080 14140080
	s_lshl_b32 s11, s11, 8                                      ; 840b880b
	s_lshl_b32 s12, ttmp7, 7                                    ; 840c8773
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_lshr_b32 s6, s6, 8                                        ; 85068806
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	v_add3_u32 v0, v0, s1, s11                                  ; d6550000 002c0300
	s_mov_b32 s1, 0                                             ; be810080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_lshl_add_u32 v1, v1, 5, s12                               ; d6460001 00310b01
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_lshrrev_b32_e32 v2, 5, v1                                 ; 32040285
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v2, v7, vcc_lo                        ; 02000f02
	v_lshl_add_u32 v2, v2, 7, s3                                ; d6460002 000d0f02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshl_add_u32 v2, v3, 2, v2                                ; d6460002 04090503
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_lshlrev_b32_e32 v3, 3, v3                                 ; 30060683
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_add_nc_u32_e32 v4, v4, v3                                 ; 4a080704
	v_add_nc_u32_e32 v0, v0, v3                                 ; 4a000700
	v_lshrrev_b32_e32 v4, 2, v4                                 ; 32080882
	v_lshrrev_b32_e32 v0, 2, v0                                 ; 32000082
	s_branch BB1                                                ; bfa00151
	s_nop 0                                                     ; bf800000
	(then repeated 5 times)
BB3:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[12:13], 0x70                        ; f4004406 f8000070
	s_load_b128 s[12:15], s[12:13], 0x30                        ; f4004306 f8000030
	s_lshl_b32 s3, s1, 8                                        ; 84038801
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s3, s3, 4                                        ; 85038403
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v6, s3, 7, v2                                ; d6460006 04090e03
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v6, 2, v6                                 ; 300c0c82
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[40:43], v6, s[12:15], null offen         ; c405c07c 40801828 00000006
	buffer_load_b128 v[44:47], v6, s[12:15], null offen offset:512 ; c405c07c 4080182c 00020006
	buffer_load_b128 v[48:51], v6, s[12:15], null offen offset:1024 ; c405c07c 40801830 00040006
	buffer_load_b128 v[52:55], v6, s[12:15], null offen offset:1536 ; c405c07c 40801834 00060006
	buffer_load_b128 v[56:59], v6, s[12:15], null offen offset:2048 ; c405c07c 40801838 00080006
	buffer_load_b128 v[60:63], v6, s[12:15], null offen offset:2560 ; c405c07c 4080183c 000a0006
	s_lshl_b32 s7, s3, 8                                        ; 84078803
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s7, s7, 2                                        ; 85078207
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v3, s7, v4, 2                                ; d6470003 020a0807
	v_add_lshl_u32 v5, s7, v0, 2                                ; d6470005 020a0007
	s_clause 0xd                                                ; bf85000d
	buffer_load_b64 v[64:65], v3, s[16:19], null offen          ; c405407c 40802040 00000003
	buffer_load_b64 v[66:67], v5, s[16:19], null offen          ; c405407c 40802042 00000005
	buffer_load_b64 v[68:69], v3, s[16:19], null offen offset:256 ; c405407c 40802044 00010003
	buffer_load_b64 v[70:71], v5, s[16:19], null offen offset:256 ; c405407c 40802046 00010005
	buffer_load_b64 v[72:73], v3, s[16:19], null offen offset:512 ; c405407c 40802048 00020003
	buffer_load_b64 v[74:75], v5, s[16:19], null offen offset:512 ; c405407c 4080204a 00020005
	buffer_load_b64 v[76:77], v3, s[16:19], null offen offset:768 ; c405407c 4080204c 00030003
	buffer_load_b64 v[78:79], v5, s[16:19], null offen offset:768 ; c405407c 4080204e 00030005
	buffer_load_b64 v[80:81], v3, s[16:19], null offen offset:1024 ; c405407c 40802050 00040003
	buffer_load_b64 v[82:83], v5, s[16:19], null offen offset:1024 ; c405407c 40802052 00040005
	buffer_load_b64 v[84:85], v3, s[16:19], null offen offset:1280 ; c405407c 40802054 00050003
	buffer_load_b64 v[86:87], v5, s[16:19], null offen offset:1280 ; c405407c 40802056 00050005
	buffer_load_b64 v[88:89], v3, s[16:19], null offen offset:1536 ; c405407c 40802058 00060003
	buffer_load_b64 v[90:91], v5, s[16:19], null offen offset:1536 ; c405407c 4080205a 00060005
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[64:65], v[40:41], v[8:15] ; cc464008 1c225140
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[64:65], v[42:43], v[16:23] ; cc464010 1c425540
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[66:67], v[40:41], v[24:31] ; cc464018 1c625142
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[66:67], v[42:43], v[32:39] ; cc464020 1c825542
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[68:69], v[44:45], v[8:15] ; cc464008 1c225944
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[68:69], v[46:47], v[16:23] ; cc464010 1c425d44
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[70:71], v[44:45], v[24:31] ; cc464018 1c625946
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[70:71], v[46:47], v[32:39] ; cc464020 1c825d46
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[72:73], v[48:49], v[8:15] ; cc464008 1c226148
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[72:73], v[50:51], v[16:23] ; cc464010 1c426548
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[74:75], v[48:49], v[24:31] ; cc464018 1c62614a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[74:75], v[50:51], v[32:39] ; cc464020 1c82654a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[76:77], v[52:53], v[8:15] ; cc464008 1c22694c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[76:77], v[54:55], v[16:23] ; cc464010 1c426d4c
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[78:79], v[52:53], v[24:31] ; cc464018 1c62694e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[78:79], v[54:55], v[32:39] ; cc464020 1c826d4e
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[80:81], v[56:57], v[8:15] ; cc464008 1c227150
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[80:81], v[58:59], v[16:23] ; cc464010 1c427550
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[82:83], v[56:57], v[24:31] ; cc464018 1c627152
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[82:83], v[58:59], v[32:39] ; cc464020 1c827552
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[84:85], v[60:61], v[8:15] ; cc464008 1c227954
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[84:85], v[62:63], v[16:23] ; cc464010 1c427d54
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[86:87], v[60:61], v[24:31] ; cc464018 1c627956
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[86:87], v[62:63], v[32:39] ; cc464020 1c827d56
	s_clause 0x6                                                ; bf850006
	buffer_load_b128 v[40:43], v6, s[12:15], null offen offset:3072 ; c405c07c 40801828 000c0006
	buffer_load_b128 v[44:47], v6, s[12:15], null offen offset:3584 ; c405c07c 4080182c 000e0006
	buffer_load_b128 v[48:51], v6, s[12:15], null offen offset:4096 ; c405c07c 40801830 00100006
	buffer_load_b128 v[64:67], v6, s[12:15], null offen offset:4608 ; c405c07c 40801840 00120006
	buffer_load_b128 v[52:55], v6, s[12:15], null offen offset:5120 ; c405c07c 40801834 00140006
	buffer_load_b128 v[56:59], v6, s[12:15], null offen offset:5632 ; c405c07c 40801838 00160006
	buffer_load_b128 v[60:63], v6, s[12:15], null offen offset:6144 ; c405c07c 4080183c 00180006
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[88:89], v[40:41], v[8:15] ; cc464008 1c225158
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[88:89], v[42:43], v[16:23] ; cc464010 1c425558
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[90:91], v[40:41], v[24:31] ; cc464018 1c62515a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[90:91], v[42:43], v[32:39] ; cc464020 1c82555a
	s_clause 0xd                                                ; bf85000d
	buffer_load_b64 v[40:41], v3, s[16:19], null offen offset:1792 ; c405407c 40802028 00070003
	buffer_load_b64 v[42:43], v5, s[16:19], null offen offset:1792 ; c405407c 4080202a 00070005
	buffer_load_b64 v[68:69], v3, s[16:19], null offen offset:2048 ; c405407c 40802044 00080003
	buffer_load_b64 v[70:71], v5, s[16:19], null offen offset:2048 ; c405407c 40802046 00080005
	buffer_load_b64 v[72:73], v3, s[16:19], null offen offset:2304 ; c405407c 40802048 00090003
	buffer_load_b64 v[74:75], v5, s[16:19], null offen offset:2304 ; c405407c 4080204a 00090005
	buffer_load_b64 v[76:77], v3, s[16:19], null offen offset:2560 ; c405407c 4080204c 000a0003
	buffer_load_b64 v[78:79], v5, s[16:19], null offen offset:2560 ; c405407c 4080204e 000a0005
	buffer_load_b64 v[80:81], v3, s[16:19], null offen offset:2816 ; c405407c 40802050 000b0003
	buffer_load_b64 v[82:83], v5, s[16:19], null offen offset:2816 ; c405407c 40802052 000b0005
	buffer_load_b64 v[84:85], v3, s[16:19], null offen offset:3072 ; c405407c 40802054 000c0003
	buffer_load_b64 v[86:87], v5, s[16:19], null offen offset:3072 ; c405407c 40802056 000c0005
	buffer_load_b64 v[88:89], v3, s[16:19], null offen offset:3328 ; c405407c 40802058 000d0003
	buffer_load_b64 v[90:91], v5, s[16:19], null offen offset:3328 ; c405407c 4080205a 000d0005
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[40:41], v[44:45], v[8:15] ; cc464008 1c225928
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[40:41], v[46:47], v[16:23] ; cc464010 1c425d28
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[42:43], v[44:45], v[24:31] ; cc464018 1c62592a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[42:43], v[46:47], v[32:39] ; cc464020 1c825d2a
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[40:41], v3, s[16:19], null offen offset:3584 ; c405407c 40802028 000e0003
	buffer_load_b64 v[42:43], v5, s[16:19], null offen offset:3584 ; c405407c 4080202a 000e0005
	buffer_load_b64 v[44:45], v3, s[16:19], null offen offset:3840 ; c405407c 4080202c 000f0003
	buffer_load_b64 v[46:47], v5, s[16:19], null offen offset:3840 ; c405407c 4080202e 000f0005
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[68:69], v[48:49], v[8:15] ; cc464008 1c226144
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[68:69], v[50:51], v[16:23] ; cc464010 1c426544
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[70:71], v[48:49], v[24:31] ; cc464018 1c626146
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[70:71], v[50:51], v[32:39] ; cc464020 1c826546
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[48:51], v6, s[12:15], null offen offset:6656 ; c405c07c 40801830 001a0006
	buffer_load_b128 v[68:71], v6, s[12:15], null offen offset:7168 ; c405c07c 40801844 001c0006
	buffer_load_b128 v[92:95], v6, s[12:15], null offen offset:7680 ; c405c07c 4080185c 001e0006
	s_add_co_u32 s1, s1, 1                                      ; 80018101
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[72:73], v[64:65], v[8:15] ; cc464008 1c228148
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[72:73], v[66:67], v[16:23] ; cc464010 1c428548
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[74:75], v[64:65], v[24:31] ; cc464018 1c62814a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[74:75], v[66:67], v[32:39] ; cc464020 1c82854a
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[76:77], v[52:53], v[8:15] ; cc464008 1c22694c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[76:77], v[54:55], v[16:23] ; cc464010 1c426d4c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[78:79], v[52:53], v[24:31] ; cc464018 1c62694e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[78:79], v[54:55], v[32:39] ; cc464020 1c826d4e
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[80:81], v[56:57], v[8:15] ; cc464008 1c227150
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[80:81], v[58:59], v[16:23] ; cc464010 1c427550
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[82:83], v[56:57], v[24:31] ; cc464018 1c627152
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[82:83], v[58:59], v[32:39] ; cc464020 1c827552
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[84:85], v[60:61], v[8:15] ; cc464008 1c227954
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[84:85], v[62:63], v[16:23] ; cc464010 1c427d54
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[86:87], v[60:61], v[24:31] ; cc464018 1c627956
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[86:87], v[62:63], v[32:39] ; cc464020 1c827d56
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[88:89], v[48:49], v[8:15] ; cc464008 1c226158
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[88:89], v[50:51], v[16:23] ; cc464010 1c426558
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[90:91], v[48:49], v[24:31] ; cc464018 1c62615a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[90:91], v[50:51], v[32:39] ; cc464020 1c82655a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[40:41], v[68:69], v[8:15] ; cc464008 1c228928
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[40:41], v[70:71], v[16:23] ; cc464010 1c428d28
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[42:43], v[68:69], v[24:31] ; cc464018 1c62892a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[42:43], v[70:71], v[32:39] ; cc464020 1c828d2a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[44:45], v[92:93], v[8:15] ; cc464008 1c22b92c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[94:95], v[16:23] ; cc464010 1c42bd2c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[46:47], v[92:93], v[24:31] ; cc464018 1c62b92e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[46:47], v[94:95], v[32:39] ; cc464020 1c82bd2e
BB1:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s1, s6                                         ; bf090601
	s_cbranch_scc0 BB3                                          ; bfa1feb2
BB4:
	s_cmp_lt_u32 s8, s4                                         ; bf0a0408
	s_cbranch_scc0 BB7                                          ; bfa10061
BB5:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[12:15], s[6:7], 0x0                           ; f4004303 f8000000
	v_cvt_f16_f32_e32 v3, v10                                   ; 7e06150a
	v_cvt_f16_f32_e32 v4, v11                                   ; 7e08150b
(invalid instruction)                                        ; d71f000a
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_cvt_f16_f32_e32 v2, v9                                    ; 7e041509
	v_cvt_f16_f32_e32 v5, v12                                   ; 7e0a150c
	s_mul_i32 s1, s8, s5                                        ; 96010508
	v_cvt_f16_f32_e32 v6, v13                                   ; 7e0c150d
	v_cvt_f16_f32_e32 v0, v8                                    ; 7e001508
	v_cvt_f16_f32_e32 v7, v14                                   ; 7e0e150e
	v_cvt_f16_f32_e32 v8, v15                                   ; 7e10150f
	v_lshrrev_b32_e32 v11, 4, v10                               ; 32161484
	v_and_b32_e32 v10, 15, v10                                  ; 3614148f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v9, v1, s2, s1                                   ; d6550009 00040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_lshlrev_b32_e32 v11, 3, v11                               ; 30161683
	v_add_nc_u32_e32 v13, 1, v11                                ; 4a1a1681
	v_add_nc_u32_e32 v40, 4, v11                                ; 4a501684
	v_add_nc_u32_e32 v14, 2, v11                                ; 4a1c1682
	v_add_nc_u32_e32 v15, 3, v11                                ; 4a1e1683
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v0, v11, v5, vcc_lo                       ; 02000b0b
	v_add_nc_u32_e32 v41, 5, v11                                ; 4a521685
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v13, v5, vcc_lo                       ; 02000b0d
(invalid instruction)                                        ; d72c0028
	v_cndmask_b32_e32 v0, v40, v5, vcc_lo                       ; 02000b28
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v0, v14, v5, vcc_lo                       ; 02000b0e
(invalid instruction)                                        ; d72c000f
	v_cndmask_b32_e32 v0, v15, v5, vcc_lo                       ; 02000b0f
(invalid instruction)                                        ; d72c0029
	v_cndmask_b32_e32 v0, v41, v5, vcc_lo                       ; 02000b29
	v_add3_u32 v12, v10, v9, v12                                ; d655000c 0432130a
	v_add_nc_u32_e32 v42, 6, v11                                ; 4a541686
	v_add3_u32 v13, v10, v9, v13                                ; d655000d 0436130a
	v_add3_u32 v40, v10, v9, v40                                ; d6550028 04a2130a
	v_add3_u32 v14, v10, v9, v14                                ; d655000e 043a130a
	v_add_nc_u32_e32 v11, 7, v11                                ; 4a161687
	v_add3_u32 v15, v10, v9, v15                                ; d655000f 043e130a
	v_lshlrev_b32_e32 v12, 1, v12                               ; 30181881
(invalid instruction)                                        ; d72c002a
	v_cndmask_b32_e32 v0, v42, v5, vcc_lo                       ; 02000b2a
	v_lshlrev_b32_e32 v13, 1, v13                               ; 301a1a81
	v_add3_u32 v41, v10, v9, v41                                ; d6550029 04a6130a
	v_lshlrev_b32_e32 v40, 1, v40                               ; 30505081
	v_lshlrev_b32_e32 v14, 1, v14                               ; 301c1c81
(invalid instruction)                                        ; d72c000b
	v_cndmask_b32_e32 v0, v11, v5, vcc_lo                       ; 02000b0b
	v_lshlrev_b32_e32 v15, 1, v15                               ; 301e1e81
	v_lshlrev_b32_e32 v41, 1, v41                               ; 30525281
	v_add3_u32 v42, v10, v9, v42                                ; d655002a 04aa130a
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_add3_u32 v10, v10, v9, v11                                ; d655000a 042e130a
	v_lshlrev_b32_e32 v42, 1, v42                               ; 30545481
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshlrev_b32_e32 v10, 1, v10                               ; 30141481
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b16 v0, v12, s[12:15], null offen              ; c406407c 40801800 0000000c
	buffer_store_b16 v2, v13, s[12:15], null offen              ; c406407c 40801802 0000000d
	buffer_store_b16 v3, v14, s[12:15], null offen              ; c406407c 40801803 0000000e
	buffer_store_b16 v4, v15, s[12:15], null offen              ; c406407c 40801804 0000000f
	buffer_store_b16 v5, v40, s[12:15], null offen              ; c406407c 40801805 00000028
	buffer_store_b16 v6, v41, s[12:15], null offen              ; c406407c 40801806 00000029
	buffer_store_b16 v7, v42, s[12:15], null offen              ; c406407c 40801807 0000002a
	buffer_store_b16 v8, v10, s[12:15], null offen              ; c406407c 40801808 0000000a
BB7:
	v_add_nc_u32_e32 v0, 16, v1                                 ; 4a000290
	s_cbranch_scc0 BB10                                         ; bfa10061
BB8:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[12:15], s[6:7], 0x0                           ; f4004303 f8000000
(invalid instruction)                                        ; d71f000b
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_mul_i32 s8, s8, s5                                        ; 96080508
	v_cvt_f16_f32_e32 v2, v16                                   ; 7e041510
	v_cvt_f16_f32_e32 v3, v17                                   ; 7e061511
	v_cvt_f16_f32_e32 v4, v18                                   ; 7e081512
	v_cvt_f16_f32_e32 v5, v19                                   ; 7e0a1513
	v_cvt_f16_f32_e32 v6, v20                                   ; 7e0c1514
	v_cvt_f16_f32_e32 v7, v21                                   ; 7e0e1515
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v10, v0, s2, s8                                  ; d655000a 00200500
	v_cvt_f16_f32_e32 v8, v22                                   ; 7e101516
	v_lshrrev_b32_e32 v12, 4, v11                               ; 32181684
	v_and_b32_e32 v11, 15, v11                                  ; 3616168f
	v_cvt_f16_f32_e32 v9, v23                                   ; 7e121517
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_lshlrev_b32_e32 v12, 3, v12                               ; 30181883
	v_add_nc_u32_e32 v15, 2, v12                                ; 4a1e1882
	v_add_nc_u32_e32 v16, 3, v12                                ; 4a201883
	v_add_nc_u32_e32 v17, 4, v12                                ; 4a221884
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v12, v5, vcc_lo                       ; 02000b0c
	v_add_nc_u32_e32 v14, 1, v12                                ; 4a1c1881
(invalid instruction)                                        ; d72c000f
	v_cndmask_b32_e32 v0, v15, v5, vcc_lo                       ; 02000b0f
(invalid instruction)                                        ; d72c0010
	v_cndmask_b32_e32 v0, v16, v5, vcc_lo                       ; 02000b10
	v_add_nc_u32_e32 v18, 5, v12                                ; 4a241885
(invalid instruction)                                        ; d72c0011
	v_cndmask_b32_e32 v0, v17, v5, vcc_lo                       ; 02000b11
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v0, v14, v5, vcc_lo                       ; 02000b0e
	v_add3_u32 v13, v11, v10, v13                               ; d655000d 0436150b
	v_add_nc_u32_e32 v19, 6, v12                                ; 4a261886
	v_add3_u32 v15, v11, v10, v15                               ; d655000f 043e150b
(invalid instruction)                                        ; d72c0012
	v_cndmask_b32_e32 v0, v18, v5, vcc_lo                       ; 02000b12
	v_add3_u32 v16, v11, v10, v16                               ; d6550010 0442150b
	v_add_nc_u32_e32 v12, 7, v12                                ; 4a181887
	v_add3_u32 v17, v11, v10, v17                               ; d6550011 0446150b
	v_lshlrev_b32_e32 v13, 1, v13                               ; 301a1a81
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v0, v19, v5, vcc_lo                       ; 02000b13
	v_lshlrev_b32_e32 v15, 1, v15                               ; 301e1e81
	v_add3_u32 v14, v11, v10, v14                               ; d655000e 043a150b
	v_lshlrev_b32_e32 v16, 1, v16                               ; 30202081
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v0, v12, v5, vcc_lo                       ; 02000b0c
	v_add3_u32 v18, v11, v10, v18                               ; d6550012 044a150b
	v_lshlrev_b32_e32 v17, 1, v17                               ; 30222281
	v_lshlrev_b32_e32 v14, 1, v14                               ; 301c1c81
	v_add3_u32 v19, v11, v10, v19                               ; d6550013 044e150b
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_lshlrev_b32_e32 v18, 1, v18                               ; 30242481
	v_add3_u32 v11, v11, v10, v12                               ; d655000b 0432150b
	v_lshlrev_b32_e32 v19, 1, v19                               ; 30262681
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshlrev_b32_e32 v11, 1, v11                               ; 30161681
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b16 v2, v13, s[12:15], null offen              ; c406407c 40801802 0000000d
	buffer_store_b16 v3, v14, s[12:15], null offen              ; c406407c 40801803 0000000e
	buffer_store_b16 v4, v15, s[12:15], null offen              ; c406407c 40801804 0000000f
	buffer_store_b16 v5, v16, s[12:15], null offen              ; c406407c 40801805 00000010
	buffer_store_b16 v6, v17, s[12:15], null offen              ; c406407c 40801806 00000011
	buffer_store_b16 v7, v18, s[12:15], null offen              ; c406407c 40801807 00000012
	buffer_store_b16 v8, v19, s[12:15], null offen              ; c406407c 40801808 00000013
	buffer_store_b16 v9, v11, s[12:15], null offen              ; c406407c 40801809 0000000b
BB10:
	s_cmp_lt_u32 s10, s4                                        ; bf0a040a
	s_cbranch_scc0 BB13                                         ; bfa10099
BB11:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[12:15], s[0:1], 0x0                           ; f4004300 f8000000
(invalid instruction)                                        ; d71f000a
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_mul_i32 s10, s10, s5                                      ; 960a050a
	v_cvt_f16_f32_e32 v2, v24                                   ; 7e041518
	v_cvt_f16_f32_e32 v3, v25                                   ; 7e061519
	v_cvt_f16_f32_e32 v4, v26                                   ; 7e08151a
	v_cvt_f16_f32_e32 v5, v27                                   ; 7e0a151b
	v_cvt_f16_f32_e32 v6, v28                                   ; 7e0c151c
	v_cvt_f16_f32_e32 v7, v29                                   ; 7e0e151d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v1, v1, s2, s10                                  ; d6550001 00280501
	v_cvt_f16_f32_e32 v8, v30                                   ; 7e10151e
	v_lshrrev_b32_e32 v11, 4, v10                               ; 32161484
	v_and_b32_e32 v10, 15, v10                                  ; 3614148f
	v_cvt_f16_f32_e32 v9, v31                                   ; 7e12151f
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_lshlrev_b32_e32 v11, 3, v11                               ; 30161683
	v_add_nc_u32_e32 v18, 3, v11                                ; 4a241683
	v_add_nc_u32_e32 v20, 4, v11                                ; 4a281684
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v0, v11, v5, vcc_lo                       ; 02000b0b
	v_add_nc_u32_e32 v14, 1, v11                                ; 4a1c1681
	v_add_nc_u32_e32 v16, 2, v11                                ; 4a201682
(invalid instruction)                                        ; d72c0012
	v_cndmask_b32_e32 v0, v18, v5, vcc_lo                       ; 02000b12
(invalid instruction)                                        ; d72c0014
	v_cndmask_b32_e32 v0, v20, v5, vcc_lo                       ; 02000b14
	v_add_nc_u32_e32 v22, 5, v11                                ; 4a2c1685
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v0, v14, v5, vcc_lo                       ; 02000b0e
(invalid instruction)                                        ; d72c0010
	v_cndmask_b32_e32 v0, v16, v5, vcc_lo                       ; 02000b10
	v_add3_u32 v13, v10, v1, v12                                ; d655000d 0432030a
	v_add_nc_u32_e32 v24, 6, v11                                ; 4a301686
	v_add3_u32 v19, v10, v1, v18                                ; d6550013 044a030a
(invalid instruction)                                        ; d72c0016
	v_cndmask_b32_e32 v0, v22, v5, vcc_lo                       ; 02000b16
	v_add3_u32 v21, v10, v1, v20                                ; d6550015 0452030a
	v_add_nc_u32_e32 v11, 7, v11                                ; 4a161687
	v_add3_u32 v0, v0, s2, s10                                  ; d6550000 00280500
	v_add3_u32 v15, v10, v1, v14                                ; d655000f 043a030a
	v_lshlrev_b32_e32 v13, 1, v13                               ; 301a1a81
(invalid instruction)                                        ; d72c0018
	v_cndmask_b32_e32 v0, v24, v5, vcc_lo                       ; 02000b18
	v_add3_u32 v17, v10, v1, v16                                ; d6550011 0442030a
	v_lshlrev_b32_e32 v19, 1, v19                               ; 30262681
	v_lshlrev_b32_e32 v21, 1, v21                               ; 302a2a81
(invalid instruction)                                        ; d72c000b
	v_cndmask_b32_e32 v0, v11, v5, vcc_lo                       ; 02000b0b
	v_add3_u32 v23, v10, v1, v22                                ; d6550017 045a030a
	v_add3_u32 v14, v10, v0, v14                                ; d655000e 043a010a
	v_add3_u32 v12, v10, v0, v12                                ; d655000c 0432010a
	v_lshlrev_b32_e32 v15, 1, v15                               ; 301e1e81
	v_add3_u32 v16, v10, v0, v16                                ; d6550010 0442010a
	v_add3_u32 v18, v10, v0, v18                                ; d6550012 044a010a
	v_lshlrev_b32_e32 v17, 1, v17                               ; 30222281
	v_add3_u32 v25, v10, v1, v24                                ; d6550019 0462030a
	v_add3_u32 v20, v10, v0, v20                                ; d6550014 0452010a
	v_add3_u32 v22, v10, v0, v22                                ; d6550016 045a010a
	v_add3_u32 v24, v10, v0, v24                                ; d6550018 0462010a
	v_lshlrev_b32_e32 v23, 1, v23                               ; 302e2e81
	v_lshlrev_b32_e32 v14, 1, v14                               ; 301c1c81
	v_cvt_f16_f32_e32 v26, v32                                  ; 7e341520
	v_cvt_f16_f32_e32 v27, v33                                  ; 7e361521
	v_lshlrev_b32_e32 v12, 1, v12                               ; 30181881
	v_add3_u32 v1, v10, v1, v11                                 ; d6550001 042e030a
	v_cvt_f16_f32_e32 v28, v34                                  ; 7e381522
	v_lshlrev_b32_e32 v16, 1, v16                               ; 30202081
	v_cvt_f16_f32_e32 v29, v35                                  ; 7e3a1523
	v_cvt_f16_f32_e32 v30, v36                                  ; 7e3c1524
	v_lshlrev_b32_e32 v18, 1, v18                               ; 30242481
	v_cvt_f16_f32_e32 v31, v37                                  ; 7e3e1525
	v_cvt_f16_f32_e32 v32, v38                                  ; 7e401526
	v_lshlrev_b32_e32 v25, 1, v25                               ; 30323281
	v_cvt_f16_f32_e32 v33, v39                                  ; 7e421527
	v_lshlrev_b32_e32 v20, 1, v20                               ; 30282881
	v_add3_u32 v10, v10, v0, v11                                ; d655000a 042e010a
	v_lshlrev_b32_e32 v22, 1, v22                               ; 302c2c81
	v_lshlrev_b32_e32 v24, 1, v24                               ; 30303081
	v_lshlrev_b32_e32 v1, 1, v1                                 ; 30020281
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_lshlrev_b32_e32 v10, 1, v10                               ; 30141481
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0xf                                                ; bf85000f
	buffer_store_b16 v2, v13, s[12:15], null offen              ; c406407c 40801802 0000000d
	buffer_store_b16 v3, v15, s[12:15], null offen              ; c406407c 40801803 0000000f
	buffer_store_b16 v4, v17, s[12:15], null offen              ; c406407c 40801804 00000011
	buffer_store_b16 v5, v19, s[12:15], null offen              ; c406407c 40801805 00000013
	buffer_store_b16 v6, v21, s[12:15], null offen              ; c406407c 40801806 00000015
	buffer_store_b16 v7, v23, s[12:15], null offen              ; c406407c 40801807 00000017
	buffer_store_b16 v8, v25, s[12:15], null offen              ; c406407c 40801808 00000019
	buffer_store_b16 v9, v1, s[12:15], null offen               ; c406407c 40801809 00000001
	buffer_store_b16 v26, v12, s[12:15], null offen             ; c406407c 4080181a 0000000c
	buffer_store_b16 v27, v14, s[12:15], null offen             ; c406407c 4080181b 0000000e
	buffer_store_b16 v28, v16, s[12:15], null offen             ; c406407c 4080181c 00000010
	buffer_store_b16 v29, v18, s[12:15], null offen             ; c406407c 4080181d 00000012
	buffer_store_b16 v30, v20, s[12:15], null offen             ; c406407c 4080181e 00000014
	buffer_store_b16 v31, v22, s[12:15], null offen             ; c406407c 4080181f 00000016
	buffer_store_b16 v32, v24, s[12:15], null offen             ; c406407c 40801820 00000018
	buffer_store_b16 v33, v10, s[12:15], null offen             ; c406407c 40801821 0000000a
BB13:
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
