BB0:
	s_cmp_lg_i32 s8, -1                                         ; bf01c108
	s_cbranch_scc0 BB2                                          ; bfa1000f
BB1:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[12:15], s[12:13], 0x30                        ; f4004306 f8000030
	s_lshl2_add_u32 s11, s8, 24                                 ; 878b9808
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s13, 14                                       ; be8d108e
	s_buffer_load_b32 s11, s[12:15], s11 offset:0x0             ; f40202c6 16000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s11, 0x54434852                                ; bf01ff0b 54434852
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s11, vcc_lo, exec_lo                              ; 8b0b7e6a
	s_cselect_b32 s8, -1, s8                                    ; 980808c1
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s8, -1                                         ; bf01c108
	s_cbranch_scc0 BB5                                          ; bfa1000b
BB4:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[12:15], s[12:13], 0x30                        ; f4004306 f8000030
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_lshl2_add_u32 s16, s8, 12                                 ; 87908c08
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s13, 14                                       ; be8d108e
	s_buffer_load_b32 s16, s[12:15], s16 offset:0x0             ; f4020406 20000000
	s_branch BB6                                                ; bfa00002
BB5:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_mov_b32 s16, -1                                           ; be9000c1
BB6:
	s_mov_b32 s12, ttmp9                                        ; be8c0075
	s_mov_b32 s13, ttmp7                                        ; be8d0073
	s_cmp_lg_i32 s7, 0                                          ; bf018007
	s_cbranch_scc0 BB9                                          ; bfa1004d
BB7:
	s_mul_i32 s12, s9, ttmp7                                    ; 960c7309
	s_mul_i32 s13, s7, s10                                      ; 960d0a07
	s_add_co_u32 s12, ttmp9, s12                                ; 800c0c75
	s_cvt_f32_u32 s14, s13                                      ; be8e650d
(invalid instruction)                                        ; d684000e
	v_cndmask_b32_e32 v0, s14, v128, vcc_lo                     ; 0201000e
	s_mul_f32 s14, s14, 0x4f7ffffe                              ; a20eff0e 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s14, s14                                      ; be8e670e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s15, s13, s14                                     ; 960f0e0d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s15, 0, s15                                    ; 818f0f80
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s15, s14, s15                                  ; 968f0f0e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s14, s14, s15                                  ; 800e0f0e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s14, s12, s14                                  ; 968e0e0c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s17, s14, s13                                     ; 96110d0e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s17, s12, s17                                  ; 8191110c
	s_sub_co_u32 s18, s17, s13                                  ; 80920d11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_absdiff_i32 s20, src_scc, 1                               ; 831481fd
	s_add_co_u32 s14, s14, s20                                  ; 800e140e
	s_sub_co_u32 s18, s17, s13                                  ; 80920d11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s17, s17, s18                                 ; 98111211
	s_cmp_ge_u32 s17, s13                                       ; bf090d11
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s14, s14, src_scc                              ; 800efd0e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s14, s14, s7                                      ; 960e070e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s9, s9, s14                                    ; 81890e09
	s_mul_i32 s10, s14, s10                                     ; 960a0a0e
	s_min_u32 s7, s7, s9                                        ; 89870907
	s_sub_co_i32 s12, s12, s10                                  ; 818c0a0c
	s_cvt_f32_u32 s21, s7                                       ; be956507
(invalid instruction)                                        ; d6840015
	v_cndmask_b32_e32 v0, s21, v128, vcc_lo                     ; 02010015
	s_mul_f32 s21, s21, 0x4f7ffffe                              ; a215ff15 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s21, s21                                      ; be956715
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s22, s7, s21                                      ; 96161507
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s22, 0, s22                                    ; 81961680
	s_mul_hi_u32 s22, s21, s22                                  ; 96961615
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s21, s21, s22                                  ; 80151615
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s21, s12, s21                                  ; 9695150c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s23, s21, s7                                      ; 96170715
	s_sub_co_i32 s12, s12, s23                                  ; 818c170c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s24, s12, s7                                   ; 8098070c
	s_absdiff_i32 s26, src_scc, 1                               ; 831a81fd
	s_sub_co_u32 s24, s12, s7                                   ; 8098070c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s12, s12, s24                                 ; 980c180c
	s_sub_co_u32 s7, s12, s7                                    ; 8087070c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mov_b32 s27, src_scc                                      ; be9b00fd
	s_absdiff_i32 s28, src_scc, 1                               ; 831c81fd
	s_cmp_lg_i32 s27, 0                                         ; bf01801b
	s_cselect_b32 s12, s12, s7                                  ; 980c070c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s12, s14, s12                                  ; 800c0c0e
	s_add_co_u32 s21, s21, s26                                  ; 80151a15
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s13, s21, s28                                  ; 800d1c15
BB9:
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
	s_cbranch_scc0 BB11                                         ; bfa1000e
BB10:
	s_mov_b32 s10, s0                                           ; be8a0000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_load_b128 s[20:23], s[10:11], 0x30                        ; f4004505 f8000030
	s_lshl2_add_u32 s7, s8, 8                                   ; 87878808
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_buffer_load_b32 s7, s[20:23], s7 offset:0x0               ; f40201ca 0e000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s7, -1                                         ; bf01c107
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB12                                               ; bfa00001
BB11:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB12:
	s_lshl_b32 s12, s12, 6                                      ; 840c860c
	s_and_b32 s7, vcc_lo, exec_lo                               ; 8b077e6a
	s_cbranch_scc0 BB47                                         ; bfa1005f
BB13:
	s_and_b32 s7, ttmp8, 0x3e000000                             ; 8b07ff74 3e000000
	s_cbranch_scc1 BB45                                         ; bfa2005a
BB14:
	s_mov_b32 s10, s0                                           ; be8a0000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_load_b128 s[20:23], s[10:11], 0x30                        ; f4004505 f8000030
	s_lshl_b32 s8, s8, 2                                        ; 84088208
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s9, s8, 8                                      ; 80098808
	s_add_co_u32 s14, s8, 16                                    ; 800e9008
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_clause 0x2                                                ; bf850002
	s_buffer_load_b32 s7, s[20:23], s8 offset:0x0               ; f40201ca 10000000
	s_buffer_load_b32 s9, s[20:23], s9 offset:0x0               ; f402024a 12000000
	s_buffer_load_b32 s14, s[20:23], s14 offset:0x0             ; f402038a 1c000000
	s_load_b128 s[24:27], s[10:11], 0x0                         ; f4004605 f8000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s14, s14, 2                                      ; 840e820e
	buffer_load_b32 v1, off, s[24:27], s14 scope:SCOPE_DEV      ; c405000e 00883001 00000000
	s_lshr_b32 s15, s12, 4                                      ; 850f840c
	s_bfm_b64 s[10:11], 1, 16                                   ; 958a9081
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s17, v1                                 ; 7e220501
BB15:
	s_add_co_u32 s14, s15, s11                                  ; 800e0b0f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s14, s9, s14                                   ; 800e0e09
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s14, s14, 2                                      ; 840e820e
	s_buffer_load_b32 s14, s[20:23], s14 offset:0x0             ; f402038a 1c000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s14, -1                                        ; bf01c10e
	s_cbranch_scc0 BB25                                         ; bfa10019
BB16:
	s_branch BB17                                               ; bfa00001
BB22:
	s_add_co_u32 s10, s10, -1                                   ; 800ac10a
BB17:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s10, 0                                         ; bf01800a
	s_cbranch_scc0 BB19                                         ; bfa10010
BB18:
	s_and_b32 s18, s14, 0xfffff                                 ; 8b12ff0e 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s18, s7, s18                                   ; 80121207
	s_lshl_b32 s18, s18, 2                                      ; 84128212
	buffer_load_b32 v1, off, s[24:27], s18 scope:SCOPE_DEV      ; c4050012 00883001 00000000
	s_lshr_b32 s19, s14, 20                                     ; 8513940e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s19, s19, s17                                     ; 96131113
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s28, v1                                 ; 7e380501
	s_cmp_lt_u32 s28, s19                                       ; bf0a131c
	s_cselect_b32 s29, -1, 0                                    ; 981d80c1
	s_branch BB20                                               ; bfa00001
BB19:
	s_mov_b32 s29, 0                                            ; be9d0080
BB20:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s29, exec_lo, s29                            ; 911d1d7e
	s_cbranch_scc0 BB22                                         ; bfa1ffe8
BB25:
	s_add_co_u32 s11, s11, 1                                    ; 800b810b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_ge_u32 s11, 4                                         ; bf09840b
	s_cbranch_scc0 BB15                                         ; bfa1ffd9
BB28:
	s_cmp_eq_i32 s10, 0                                         ; bf00800a
	s_cbranch_scc0 BB30                                         ; bfa10002
BB29:
	s_mov_b32 s7, 1                                             ; be870081
	s_branch BB31                                               ; bfa00001
BB30:
	s_mov_b32 s7, 0                                             ; be870080
BB31:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mov_b32 exec_lo, s7                                       ; befe0007
	s_cbranch_execz BB43                                        ; bfa5000e
BB32:
	s_ctz_i32_b32 s7, exec_lo                                   ; be87087e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s7, 1, s7                                        ; 84070781
	s_and_saveexec_b32 s7, s7                                   ; be872007
	s_cbranch_execz BB43                                        ; bfa50009
BB33:
	s_add_co_u32 s8, s8, 20                                     ; 80089408
	s_buffer_load_b32 s8, s[20:23], s8 offset:0x0               ; f402020a 10000000
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s8, s8, 2                                        ; 84088208
	buffer_atomic_max_u32 v1, off, s[24:27], s8                 ; c40ec008 00803001 00000000
BB43:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
BB45:
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
BB47:
	v_and_b32_e32 v3, 31, v0                                    ; 3606009f
	v_and_b32_e32 v7, 15, v0                                    ; 360e008f
	s_lshr_b32 s7, s6, 4                                        ; 85078406
	s_lshr_b32 s8, s12, 4                                       ; 8508840c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshlrev_b32_e32 v4, 2, v3                                 ; 30080682
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	s_mul_i32 s9, s8, s7                                        ; 96090708
	v_lshlrev_b32_e32 v8, 4, v7                                 ; 30100e84
	s_lshl_b32 s9, s9, 8                                        ; 84098809
	s_add_co_u32 s10, 16, s12                                   ; 800a0c90
	v_bfe_u32 v1, v0, 5, 2                                      ; d6100001 02090b00
	v_lshlrev_b32_e32 v3, 3, v3                                 ; 30060683
	s_lshr_b32 s11, s10, 4                                      ; 850b840a
	v_add3_u32 v9, v8, s1, s9                                   ; d6550009 00240308
	s_mul_i32 s14, s11, s7                                      ; 960e070b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s14, s14, 8                                      ; 840e880e
	s_add_co_u32 s15, 32, s12                                   ; 800f0ca0
	v_add_nc_u32_e32 v9, v9, v3                                 ; 4a120709
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v10, v8, s1, s14                                 ; d655000a 00380308
	s_lshr_b32 s17, s15, 4                                      ; 8511840f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_mul_i32 s18, s17, s7                                      ; 96120711
	v_add_nc_u32_e32 v10, v10, v3                               ; 4a14070a
	s_lshl_b32 s18, s18, 8                                      ; 84128812
	s_add_co_u32 s19, 48, s12                                   ; 80130cb0
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v16, 0              ; ca100080 11100080
	v_add3_u32 v11, v8, s1, s18                                 ; d655000b 00480308
	s_lshr_b32 s20, s19, 4                                      ; 85148413
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s21, s20, s7                                      ; 96150714
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0              ; ca100080 18180080
	v_add_nc_u32_e32 v11, v11, v3                               ; 4a16070b
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0              ; ca100080 1c1c0080
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s21, s21, 8                                      ; 84158815
	s_lshl_b32 s13, s13, 8                                      ; 840d880d
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_lshr_b32 s6, s6, 5                                        ; 85068506
	v_lshrrev_b32_e32 v9, 2, v9                                 ; 32121282
	v_lshrrev_b32_e32 v10, 2, v10                               ; 32141482
	v_lshrrev_b32_e32 v11, 2, v11                               ; 32161682
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v8, v8, s1, s21                                  ; d6550008 00540308
	s_mov_b32 s1, 0                                             ; be810080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_lshl_add_u32 v1, v1, 6, s13                               ; d6460001 00350d01
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_add_nc_u32_e32 v8, v8, v3                                 ; 4a100708
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_add_nc_u32_e32 v5, 32, v1                                 ; 4a0a02a0
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	v_lshrrev_b32_e32 v2, 5, v1                                 ; 32040285
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v60, 0              ; ca100080 3d3c0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v62, 0              ; ca100080 3f3e0080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v64, 0              ; ca100080 41400080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0              ; ca100080 43420080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v68, 0              ; ca100080 45440080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v70, 0              ; ca100080 47460080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v72, 0              ; ca100080 49480080
	v_lshrrev_b32_e32 v8, 2, v8                                 ; 32101082
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v74, 0              ; ca100080 4b4a0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v76, 0              ; ca100080 4d4c0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v78, 0              ; ca100080 4f4e0080
	v_lshrrev_b32_e32 v6, 5, v5                                 ; 320c0a85
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v80, 0              ; ca100080 51500080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v82, 0              ; ca100080 53520080
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v2, v7, vcc_lo                        ; 02000f02
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v84, 0              ; ca100080 55540080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v86, 0              ; ca100080 57560080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v88, 0              ; ca100080 59580080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v90, 0              ; ca100080 5b5a0080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v92, 0              ; ca100080 5d5c0080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v94, 0              ; ca100080 5f5e0080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v96, 0              ; ca100080 61600080
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v98, 0              ; ca100080 63620080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v100, 0            ; ca100080 65640080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v102, 0            ; ca100080 67660080
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v104, 0            ; ca100080 69680080
	v_dual_mov_b32 v107, 0 :: v_dual_mov_b32 v106, 0            ; ca100080 6b6a0080
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v6, v7, vcc_lo                        ; 02000f06
	v_dual_mov_b32 v109, 0 :: v_dual_mov_b32 v108, 0            ; ca100080 6d6c0080
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v110, 0            ; ca100080 6f6e0080
	v_dual_mov_b32 v113, 0 :: v_dual_mov_b32 v112, 0            ; ca100080 71700080
	v_dual_mov_b32 v115, 0 :: v_dual_mov_b32 v114, 0            ; ca100080 73720080
	v_dual_mov_b32 v117, 0 :: v_dual_mov_b32 v116, 0            ; ca100080 75740080
	v_dual_mov_b32 v119, 0 :: v_dual_mov_b32 v118, 0            ; ca100080 77760080
	v_dual_mov_b32 v121, 0 :: v_dual_mov_b32 v120, 0            ; ca100080 79780080
	v_dual_mov_b32 v123, 0 :: v_dual_mov_b32 v122, 0            ; ca100080 7b7a0080
	v_dual_mov_b32 v125, 0 :: v_dual_mov_b32 v124, 0            ; ca100080 7d7c0080
	v_lshl_add_u32 v2, v2, 7, s3                                ; d6460002 000d0f02
	v_dual_mov_b32 v127, 0 :: v_dual_mov_b32 v126, 0            ; ca100080 7f7e0080
	v_dual_mov_b32 v129, 0 :: v_dual_mov_b32 v128, 0            ; ca100080 81800080
	v_dual_mov_b32 v131, 0 :: v_dual_mov_b32 v130, 0            ; ca100080 83820080
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v132, 0            ; ca100080 85840080
	v_dual_mov_b32 v135, 0 :: v_dual_mov_b32 v134, 0            ; ca100080 87860080
	v_dual_mov_b32 v137, 0 :: v_dual_mov_b32 v136, 0            ; ca100080 89880080
	v_dual_mov_b32 v139, 0 :: v_dual_mov_b32 v138, 0            ; ca100080 8b8a0080
	v_dual_mov_b32 v141, 0 :: v_dual_mov_b32 v140, 0            ; ca100080 8d8c0080
	v_dual_mov_b32 v143, 0 :: v_dual_mov_b32 v142, 0            ; ca100080 8f8e0080
	v_lshl_add_u32 v6, v6, 7, s3                                ; d6460006 000d0f06
	s_branch BB48                                               ; bfa0008f
BB50:
	s_mov_b32 s22, s0                                           ; be960000
	s_movk_i32 s23, 0x8000                                      ; b0178000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[22:23], 0x70                        ; f400460b f8000070
	s_load_b128 s[28:31], s[22:23], 0x30                        ; f400470b f8000030
	s_lshl_b32 s3, s1, 5                                        ; 84038501
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s3, s3, 4                                        ; 85038403
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s7, s3, 8                                        ; 84078803
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s7, s7, 2                                        ; 85078207
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v3, s7, v9, 2                                ; d6470003 020a1207
	v_add_lshl_u32 v12, s7, v10, 2                              ; d647000c 020a1407
	v_add_lshl_u32 v13, s7, v11, 2                              ; d647000d 020a1607
	v_add_lshl_u32 v14, s7, v8, 2                               ; d647000e 020a1007
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[144:145], v3, s[24:27], null offen        ; c405407c 40803090 00000003
	buffer_load_b64 v[146:147], v12, s[24:27], null offen       ; c405407c 40803092 0000000c
	buffer_load_b64 v[148:149], v13, s[24:27], null offen       ; c405407c 40803094 0000000d
	buffer_load_b64 v[150:151], v14, s[24:27], null offen       ; c405407c 40803096 0000000e
	s_lshl_b32 s3, s3, 7                                        ; 84038703
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v15, s3, v2, v4                                  ; d655000f 04120403
	v_add3_u32 v152, s3, v6, v4                                 ; d6550098 04120c03
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshlrev_b32_e32 v15, 2, v15                               ; 301e1e82
	v_lshlrev_b32_e32 v152, 2, v152                             ; 31313082
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[156:159], v15, s[28:31], null offen      ; c405c07c 4080389c 0000000f
	buffer_load_b128 v[160:163], v152, s[28:31], null offen     ; c405c07c 408038a0 00000098
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[154:155], v3, s[24:27], null offen offset:256 ; c405407c 4080309a 00010003
	buffer_load_b64 v[164:165], v12, s[24:27], null offen offset:256 ; c405407c 408030a4 0001000c
	buffer_load_b64 v[12:13], v13, s[24:27], null offen offset:256 ; c405407c 4080300c 0001000d
	buffer_load_b64 v[166:167], v14, s[24:27], null offen offset:256 ; c405407c 408030a6 0001000e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[168:171], v15, s[28:31], null offen offset:512 ; c405c07c 408038a8 0002000f
	buffer_load_b128 v[172:175], v152, s[28:31], null offen offset:512 ; c405c07c 408038ac 00020098
	s_add_co_u32 s1, s1, 1                                      ; 80018101
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[146:147], v[156:157], v[48:55] ; cc464030 1cc33992
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[146:147], v[158:159], v[56:63] ; cc464038 1ce33d92
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[148:149], v[158:159], v[88:95] ; cc464058 1d633d94
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[148:149], v[156:157], v[80:87] ; cc464050 1d433994
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[150:151], v[156:157], v[112:119] ; cc464070 1dc33996
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[150:151], v[158:159], v[120:127] ; cc464078 1de33d96
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[144:145], v[156:157], v[16:23] ; cc464010 1c433990
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[144:145], v[158:159], v[24:31] ; cc464018 1c633d90
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[144:145], v[160:161], v[32:39] ; cc464020 1c834190
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[144:145], v[162:163], v[40:47] ; cc464028 1ca34590
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[146:147], v[160:161], v[64:71] ; cc464040 1d034192
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[146:147], v[162:163], v[72:79] ; cc464048 1d234592
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[148:149], v[160:161], v[96:103] ; cc464060 1d834194
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[148:149], v[162:163], v[104:111] ; cc464068 1da34594
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[150:151], v[160:161], v[128:135] ; cc464080 1e034196
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[150:151], v[162:163], v[136:143] ; cc464088 1e234596
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[164:165], v[168:169], v[48:55] ; cc464030 1cc351a4
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[164:165], v[170:171], v[56:63] ; cc464038 1ce355a4
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[168:169], v[80:87] ; cc464050 1d43510c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[170:171], v[88:95] ; cc464058 1d63550c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[166:167], v[168:169], v[112:119] ; cc464070 1dc351a6
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[166:167], v[170:171], v[120:127] ; cc464078 1de355a6
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[154:155], v[168:169], v[16:23] ; cc464010 1c43519a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[154:155], v[170:171], v[24:31] ; cc464018 1c63559a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[154:155], v[172:173], v[32:39] ; cc464020 1c83599a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[154:155], v[174:175], v[40:47] ; cc464028 1ca35d9a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[164:165], v[172:173], v[64:71] ; cc464040 1d0359a4
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[164:165], v[174:175], v[72:79] ; cc464048 1d235da4
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[172:173], v[96:103] ; cc464060 1d83590c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[174:175], v[104:111] ; cc464068 1da35d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[166:167], v[172:173], v[128:135] ; cc464080 1e0359a6
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[166:167], v[174:175], v[136:143] ; cc464088 1e235da6
BB48:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s1, s6                                         ; bf090601
	s_cbranch_scc0 BB50                                         ; bfa1ff6e
BB51:
	s_cmp_lt_u32 s12, s4                                        ; bf0a040c
	s_cbranch_scc0 BB53                                         ; bfa100ae
BB52:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[24:27], s[6:7], 0x10                          ; f4004603 f8000010
	s_mov_b32 s6, 0xbd650000                                    ; be8600ff bd650000
	v_maxmin_num_f32 v4, -4.0, v16, 4.0                         ; d6690004 03da20f7
	s_mov_b32 s7, 0x3ee50000                                    ; be8700ff 3ee50000
	v_maxmin_num_f32 v11, -4.0, v17, 4.0                        ; d669000b 03da22f7
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_lshr_b32 s3, s5, 4                                        ; 85038405
	v_lshrrev_b32_e32 v2, 4, v1                                 ; 32040284
	v_maxmin_num_f32 v146, -4.0, v19, 4.0                       ; d6690092 03da26f7
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d5080206
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                        ; 02020806
	s_mul_i32 s3, s8, s3                                        ; 96030308
(invalid instruction)                                        ; d508020c
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                       ; 02021606
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d5080293
	v_cndmask_b32_e32 v1, s6, v146, vcc_lo                      ; 02032406
	v_fmaak_f32 v6, v6, v4, 0x3f650000                          ; 5a0c0906 3f650000
	v_maxmin_num_f32 v151, -4.0, v20, 4.0                       ; d6690097 03da28f7
	v_fmaak_f32 v12, v12, v11, 0x3f650000                       ; 5a18170c 3f650000
	v_maxmin_num_f32 v156, -4.0, v21, 4.0                       ; d669009c 03da2af7
	v_fmaak_f32 v147, v147, v146, 0x3f650000                    ; 5b272593 3f650000
	v_fmac_f32_e32 v6, s7, v4                                   ; 560c0807
(invalid instruction)                                        ; d5080298
	v_cndmask_b32_e32 v1, s6, v151, vcc_lo                      ; 02032e06
	v_dual_fmac_f32 v12, s7, v11 :: v_dual_and_b32 v3, 16, v0   ; c8241607 0c020090
(invalid instruction)                                        ; d508029d
	v_cndmask_b32_e32 v1, s6, v156, vcc_lo                      ; 02033806
	v_fmac_f32_e32 v147, s7, v146                               ; 57272407
	v_fma_mixlo_f16 v8, v16, v6, neg(0) op_sel_hi:[0,0,1]       ; cc214008 82020d10
	v_maxmin_num_f32 v16, -4.0, v18, 4.0                        ; d6690010 03da24f7
	v_fma_mixlo_f16 v13, v17, v12, neg(0) op_sel_hi:[0,0,1]     ; cc21400d 82021911
	v_lshl_or_b32 v3, v3, 3, v7                                 ; d6560003 041d0703
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 ; c843399d 9d992f98 3f650000
	v_maxmin_num_f32 v161, -4.0, v22, 4.0                       ; d66900a1 03da2cf7
	v_maxmin_num_f32 v166, -4.0, v23, 4.0                       ; d66900a6 03da2ef7
	v_maxmin_num_f16 v8, 0xdf00, v8, neg(0xdf00)                ; d66b0008 83fe10ff 0000df00
(invalid instruction)                                        ; d5080211
	v_cndmask_b32_e32 v1, s6, v16, vcc_lo                       ; 02022006
	v_maxmin_num_f16 v13, 0xdf00, v13, neg(0xdf00)              ; d66b000d 83fe1aff 0000df00
	v_fma_mixlo_f16 v148, v19, v147, neg(0) op_sel_hi:[0,0,1]   ; cc214094 82032713
	v_dual_fmac_f32 v157, s7, v156 :: v_dual_fmac_f32 v152, s7, v151 ; c8013807 9d992e07
(invalid instruction)                                        ; d50802a2
	v_cndmask_b32_e32 v1, s6, v161, vcc_lo                      ; 02034206
(invalid instruction)                                        ; d50802a7
	v_cndmask_b32_e32 v1, s6, v166, vcc_lo                      ; 02034c06
	v_cvt_f32_f16_e32 v9, v8                                    ; 7e121708
	v_fmaak_f32 v17, v17, v16, 0x3f650000                       ; 5a222111 3f650000
	v_cvt_f32_f16_e32 v14, v13                                  ; 7e1c170d
	v_maxmin_num_f16 v148, 0xdf00, v148, neg(0xdf00)            ; d66b0094 83ff28ff 0000df00
	v_fma_mixlo_f16 v153, v20, v152, neg(0) op_sel_hi:[0,0,1]   ; cc214099 82033114
	v_fma_mixlo_f16 v158, v21, v157, neg(0) op_sel_hi:[0,0,1]   ; cc21409e 82033b15
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c8434da7 a7a343a2 3f650000
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v0, v9, v128, vcc_lo                      ; 02010109
	v_fmac_f32_e32 v17, s7, v16                                 ; 56222007
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
(invalid instruction)                                        ; d58b0095
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                    ; 02010194
	v_maxmin_num_f16 v153, 0xdf00, v153, neg(0xdf00)            ; d66b0099 83ff32ff 0000df00
	v_maxmin_num_f16 v158, 0xdf00, v158, neg(0xdf00)            ; d66b009e 83ff3cff 0000df00
	v_dual_fmac_f32 v167, s7, v166 :: v_dual_fmac_f32 v162, s7, v161 ; c8014c07 a7a34207
	v_fma_mixlo_f16 v18, v18, v17, neg(0) op_sel_hi:[0,0,1]     ; cc214012 82022312
(invalid instruction)                                        ; d7690096
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                    ; 02010195
(invalid instruction)                                        ; d58b009a
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                    ; 02010199
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v2, s3, v2, 8                                ; d6470002 02220403
(invalid instruction)                                        ; d58b009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
	v_fma_mixlo_f16 v163, v22, v162, neg(0) op_sel_hi:[0,0,1]   ; cc2140a3 82034516
	v_fma_mixlo_f16 v168, v23, v167, neg(0) op_sel_hi:[0,0,1]   ; cc2140a8 82034f17
	v_maxmin_num_f16 v18, 0xdf00, v18, neg(0xdf00)              ; d66b0012 83fe24ff 0000df00
(invalid instruction)                                        ; d769009b
	v_cndmask_b32_e32 v0, v154, v128, vcc_lo                    ; 0201019a
	v_add3_u32 v3, v3, s2, v2                                   ; d6550003 04080503
(invalid instruction)                                        ; d76900a0
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                    ; 0201019f
	v_maxmin_num_f16 v163, 0xdf00, v163, neg(0xdf00)            ; d66b00a3 83ff46ff 0000df00
	v_maxmin_num_f16 v168, 0xdf00, v168, neg(0xdf00)            ; d66b00a8 83ff50ff 0000df00
	v_cvt_f32_f16_e32 v144, v18                                 ; 7f201712
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
(invalid instruction)                                        ; d58b00a4
	v_cndmask_b32_e32 v0, v163, v128, vcc_lo                    ; 020101a3
(invalid instruction)                                        ; d58b00a9
	v_cndmask_b32_e32 v0, v168, v128, vcc_lo                    ; 020101a8
(invalid instruction)                                        ; d7690091
	v_cndmask_b32_e32 v0, v144, v128, vcc_lo                    ; 02010190
(invalid instruction)                                        ; d76900a5
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
(invalid instruction)                                        ; d76900aa
	v_cndmask_b32_e32 v0, v169, v128, vcc_lo                    ; 020101a9
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v10, v3, s[24:27], null offen               ; c406007c 4080300a 00000003
	buffer_store_b8 v15, v3, s[24:27], null offen offset:16     ; c406007c 4080300f 00001003
	buffer_store_b8 v145, v3, s[24:27], null offen offset:32    ; c406007c 40803091 00002003
	buffer_store_b8 v150, v3, s[24:27], null offen offset:48    ; c406007c 40803096 00003003
	buffer_store_b8 v155, v3, s[24:27], null offen offset:64    ; c406007c 4080309b 00004003
	buffer_store_b8 v160, v3, s[24:27], null offen offset:80    ; c406007c 408030a0 00005003
	buffer_store_b8 v165, v3, s[24:27], null offen offset:96    ; c406007c 408030a5 00006003
	buffer_store_b8 v170, v3, s[24:27], null offen offset:112   ; c406007c 408030aa 00007003
	s_branch BB54                                               ; bfa00001
BB53:
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB54:
	v_add_nc_u32_e32 v2, 16, v1                                 ; 4a040290
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc0 BB56                                         ; bfa10148
BB55:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[24:27], s[6:7], 0x10                          ; f4004603 f8000010
	v_and_b32_e32 v4, 16, v0                                    ; 36080090
	s_mov_b32 s6, 0xbd650000                                    ; be8600ff bd650000
	v_maxmin_num_f32 v6, -4.0, v24, 4.0                         ; d6690006 03da30f7
	v_maxmin_num_f32 v12, -4.0, v25, 4.0                        ; d669000c 03da32f7
	s_mov_b32 s7, 0x3ee50000                                    ; be8700ff 3ee50000
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_lshr_b32 s3, s5, 4                                        ; 85038405
	v_lshrrev_b32_e32 v3, 4, v2                                 ; 32060484
	v_maxmin_num_f32 v17, -4.0, v26, 4.0                        ; d6690011 03da34f7
	v_maxmin_num_f32 v22, -4.0, v27, 4.0                        ; d6690016 03da36f7
	v_lshl_or_b32 v4, v4, 3, v7                                 ; d6560004 041d0704
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d5080208
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                        ; 02020c06
(invalid instruction)                                        ; d508020d
	v_cndmask_b32_e32 v1, s6, v12, vcc_lo                       ; 02021806
	s_mul_i32 s3, s8, s3                                        ; 96030308
	v_maxmin_num_f32 v148, -4.0, v29, 4.0                       ; d6690094 03da3af7
(invalid instruction)                                        ; d5080212
	v_cndmask_b32_e32 v1, s6, v17, vcc_lo                       ; 02022206
(invalid instruction)                                        ; d5080217
	v_cndmask_b32_e32 v1, s6, v22, vcc_lo                       ; 02022c06
	v_dual_fmaak_f32 v8, v8, v6, 0x3f650000 :: v_dual_fmaak_f32 v13, v13, v12, 0x3f650000 ; c8420d08 080c190d 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; d5080295
	v_cndmask_b32_e32 v1, s6, v148, vcc_lo                      ; 02032806
	v_dual_fmaak_f32 v23, v23, v22, 0x3f650000 :: v_dual_fmaak_f32 v18, v18, v17, 0x3f650000 ; c8422d17 17122312 3f650000
	v_dual_fmac_f32 v8, s7, v6 :: v_dual_fmac_f32 v13, s7, v12  ; c8000c07 080c1807
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_dual_fmac_f32 v23, s7, v22 :: v_dual_fmac_f32 v18, s7, v17 ; c8002c07 17122207
	v_fma_mixlo_f16 v14, v25, v13, neg(0) op_sel_hi:[0,0,1]     ; cc21400e 82021b19
	v_fma_mixlo_f16 v9, v24, v8, neg(0) op_sel_hi:[0,0,1]       ; cc214009 82021118
	v_maxmin_num_f32 v153, -4.0, v30, 4.0                       ; d6690099 03da3cf7
	v_fma_mixlo_f16 v24, v27, v23, neg(0) op_sel_hi:[0,0,1]     ; cc214018 82022f1b
	v_maxmin_num_f32 v27, -4.0, v28, 4.0                        ; d669001b 03da38f7
	v_fma_mixlo_f16 v19, v26, v18, neg(0) op_sel_hi:[0,0,1]     ; cc214013 8202251a
	v_maxmin_num_f32 v158, -4.0, v31, 4.0                       ; d669009e 03da3ef7
	v_maxmin_num_f16 v14, 0xdf00, v14, neg(0xdf00)              ; d66b000e 83fe1cff 0000df00
	v_maxmin_num_f16 v9, 0xdf00, v9, neg(0xdf00)                ; d66b0009 83fe12ff 0000df00
(invalid instruction)                                        ; d508029a
	v_cndmask_b32_e32 v1, s6, v153, vcc_lo                      ; 02033206
	v_maxmin_num_f16 v24, 0xdf00, v24, neg(0xdf00)              ; d66b0018 83fe30ff 0000df00
(invalid instruction)                                        ; d5080290
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                       ; 02023606
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
(invalid instruction)                                        ; d508029f
	v_cndmask_b32_e32 v1, s6, v158, vcc_lo                      ; 02033c06
	v_cvt_f32_f16_e32 v15, v14                                  ; 7e1e170e
	v_cvt_f32_f16_e32 v10, v9                                   ; 7e141709
	v_cvt_f32_f16_e32 v25, v24                                  ; 7e321718
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v27, 0x3f650000 ; c8432995 95903790 3f650000
	v_cvt_f32_f16_e32 v20, v19                                  ; 7e281713
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c8433d9f 9f9b339a 3f650000
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v0, v15, v128, vcc_lo                     ; 0201010f
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v10, v128, vcc_lo                     ; 0201010a
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v0, v25, v128, vcc_lo                     ; 02010119
	v_dual_fmac_f32 v149, s7, v148 :: v_dual_fmac_f32 v144, s7, v27 ; c8012807 95903607
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v0, v20, v128, vcc_lo                     ; 02010114
	v_dual_fmac_f32 v159, s7, v158 :: v_dual_fmac_f32 v154, s7, v153 ; c8013c07 9f9b3207
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mixlo_f16 v145, v28, v144, neg(0) op_sel_hi:[0,0,1]   ; cc214091 8203211c
	v_fma_mixlo_f16 v150, v29, v149, neg(0) op_sel_hi:[0,0,1]   ; cc214096 82032b1d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v3, s3, v3, 8                                ; d6470003 02220603
	v_fma_mixlo_f16 v155, v30, v154, neg(0) op_sel_hi:[0,0,1]   ; cc21409b 8203351e
	v_fma_mixlo_f16 v160, v31, v159, neg(0) op_sel_hi:[0,0,1]   ; cc2140a0 82033f1f
	v_maxmin_num_f16 v145, 0xdf00, v145, neg(0xdf00)            ; d66b0091 83ff22ff 0000df00
	v_maxmin_num_f16 v150, 0xdf00, v150, neg(0xdf00)            ; d66b0096 83ff2cff 0000df00
	v_add3_u32 v3, v4, s2, v3                                   ; d6550003 040c0504
	v_maxmin_num_f16 v155, 0xdf00, v155, neg(0xdf00)            ; d66b009b 83ff36ff 0000df00
	v_maxmin_num_f16 v160, 0xdf00, v160, neg(0xdf00)            ; d66b00a0 83ff40ff 0000df00
(invalid instruction)                                        ; d58b0092
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                    ; 02010191
(invalid instruction)                                        ; d58b0097
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                    ; 02010196
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; d58b009c
	v_cndmask_b32_e32 v0, v155, v128, vcc_lo                    ; 0201019b
(invalid instruction)                                        ; d58b00a1
	v_cndmask_b32_e32 v0, v160, v128, vcc_lo                    ; 020101a0
(invalid instruction)                                        ; d7690093
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                    ; 02010192
(invalid instruction)                                        ; d7690098
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                    ; 02010197
(invalid instruction)                                        ; d769009d
	v_cndmask_b32_e32 v0, v156, v128, vcc_lo                    ; 0201019c
(invalid instruction)                                        ; d76900a2
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v11, v3, s[24:27], null offen               ; c406007c 4080300b 00000003
	buffer_store_b8 v16, v3, s[24:27], null offen offset:16     ; c406007c 40803010 00001003
	buffer_store_b8 v21, v3, s[24:27], null offen offset:32     ; c406007c 40803015 00002003
	buffer_store_b8 v26, v3, s[24:27], null offen offset:48     ; c406007c 4080301a 00003003
	buffer_store_b8 v147, v3, s[24:27], null offen offset:64    ; c406007c 40803093 00004003
	buffer_store_b8 v152, v3, s[24:27], null offen offset:80    ; c406007c 40803098 00005003
	buffer_store_b8 v157, v3, s[24:27], null offen offset:96    ; c406007c 4080309d 00006003
	buffer_store_b8 v162, v3, s[24:27], null offen offset:112   ; c406007c 408030a2 00007003
	v_maxmin_num_f32 v169, -4.0, v33, 4.0                       ; d66900a9 03da42f7
	v_maxmin_num_f32 v179, -4.0, v35, 4.0                       ; d66900b3 03da46f7
	v_maxmin_num_f32 v164, -4.0, v32, 4.0                       ; d66900a4 03da40f7
	v_maxmin_num_f32 v189, -4.0, v37, 4.0                       ; d66900bd 03da4af7
	v_lshrrev_b32_e32 v163, 4, v5                               ; 33460a84
	v_maxmin_num_f32 v174, -4.0, v34, 4.0                       ; d66900ae 03da44f7
(invalid instruction)                                        ; d50802aa
	v_cndmask_b32_e32 v1, s6, v169, vcc_lo                      ; 02035206
	v_maxmin_num_f32 v3, -4.0, v38, 4.0                         ; d6690003 03da4cf7
(invalid instruction)                                        ; d50802b4
	v_cndmask_b32_e32 v1, s6, v179, vcc_lo                      ; 02036606
(invalid instruction)                                        ; d50802a5
	v_cndmask_b32_e32 v1, s6, v164, vcc_lo                      ; 02034806
(invalid instruction)                                        ; d50802be
	v_cndmask_b32_e32 v1, s6, v189, vcc_lo                      ; 02037a06
(invalid instruction)                                        ; d50802af
	v_cndmask_b32_e32 v1, s6, v174, vcc_lo                      ; 02035c06
	v_fmaak_f32 v170, v170, v169, 0x3f650000                    ; 5b5553aa 3f650000
(invalid instruction)                                        ; d5080206
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                        ; 02020606
	v_fmaak_f32 v180, v180, v179, 0x3f650000                    ; 5b6967b4 3f650000
	v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 ; c8437bbe bea549a5 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fmac_f32_e32 v170, s7, v169                               ; 57555207
	v_dual_fmaak_f32 v6, v6, v3, 0x3f650000 :: v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 ; c8420706 06af5daf 3f650000
	v_fmac_f32_e32 v180, s7, v179                               ; 57696607
	v_maxmin_num_f32 v184, -4.0, v36, 4.0                       ; d66900b8 03da48f7
	v_dual_fmac_f32 v190, s7, v189 :: v_dual_fmac_f32 v165, s7, v164 ; c8017a07 bea54807
	v_maxmin_num_f32 v11, -4.0, v39, 4.0                        ; d669000b 03da4ef7
	v_fma_mixlo_f16 v171, v33, v170, neg(0) op_sel_hi:[0,0,1]   ; cc2140ab 82035521
	v_dual_fmac_f32 v6, s7, v3 :: v_dual_fmac_f32 v175, s7, v174 ; c8000607 06af5c07
	v_fma_mixlo_f16 v181, v35, v180, neg(0) op_sel_hi:[0,0,1]   ; cc2140b5 82036923
(invalid instruction)                                        ; d50802b9
	v_cndmask_b32_e32 v1, s6, v184, vcc_lo                      ; 02037006
	v_fma_mixlo_f16 v166, v32, v165, neg(0) op_sel_hi:[0,0,1]   ; cc2140a6 82034b20
(invalid instruction)                                        ; d508020c
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                       ; 02021606
	v_maxmin_num_f16 v171, 0xdf00, v171, neg(0xdf00)            ; d66b00ab 83ff56ff 0000df00
	v_fma_mixlo_f16 v176, v34, v175, neg(0) op_sel_hi:[0,0,1]   ; cc2140b0 82035f22
	v_maxmin_num_f16 v181, 0xdf00, v181, neg(0xdf00)            ; d66b00b5 83ff6aff 0000df00
	v_maxmin_num_f16 v166, 0xdf00, v166, neg(0xdf00)            ; d66b00a6 83ff4cff 0000df00
	v_fma_mixlo_f16 v191, v37, v190, neg(0) op_sel_hi:[0,0,1]   ; cc2140bf 82037d25
	v_dual_fmaak_f32 v12, v12, v11, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 ; c842170c 0cb971b9 3f650000
(invalid instruction)                                        ; d58b00ac
	v_cndmask_b32_e32 v0, v171, v128, vcc_lo                    ; 020101ab
	v_maxmin_num_f16 v176, 0xdf00, v176, neg(0xdf00)            ; d66b00b0 83ff60ff 0000df00
(invalid instruction)                                        ; d58b00b6
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                    ; 020101b5
	v_fma_mixlo_f16 v8, v38, v6, neg(0) op_sel_hi:[0,0,1]       ; cc214008 82020d26
(invalid instruction)                                        ; d58b00a7
	v_cndmask_b32_e32 v0, v166, v128, vcc_lo                    ; 020101a6
	v_maxmin_num_f16 v191, 0xdf00, v191, neg(0xdf00)            ; d66b00bf 83ff7eff 0000df00
	v_dual_fmac_f32 v12, s7, v11 :: v_dual_fmac_f32 v185, s7, v184 ; c8001607 0cb97007
(invalid instruction)                                        ; d76900ad
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
(invalid instruction)                                        ; d58b00b1
	v_cndmask_b32_e32 v0, v176, v128, vcc_lo                    ; 020101b0
(invalid instruction)                                        ; d76900b7
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                    ; 020101b6
	v_maxmin_num_f16 v8, 0xdf00, v8, neg(0xdf00)                ; d66b0008 83fe10ff 0000df00
(invalid instruction)                                        ; d76900a8
	v_cndmask_b32_e32 v0, v167, v128, vcc_lo                    ; 020101a7
	v_add_lshl_u32 v163, s3, v163, 8                            ; d64700a3 02234603
(invalid instruction)                                        ; d58b00bf
	v_cndmask_b32_e32 v0, v191, v128, vcc_lo                    ; 020101bf
	v_fma_mixlo_f16 v186, v36, v185, neg(0) op_sel_hi:[0,0,1]   ; cc2140ba 82037324
	v_fma_mixlo_f16 v13, v39, v12, neg(0) op_sel_hi:[0,0,1]     ; cc21400d 82021927
(invalid instruction)                                        ; d76900b2
	v_cndmask_b32_e32 v0, v177, v128, vcc_lo                    ; 020101b1
	v_cvt_f32_f16_e32 v9, v8                                    ; 7e121708
	v_add3_u32 v4, v4, s2, v163                                 ; d6550004 068c0504
(invalid instruction)                                        ; d76900bf
	v_cndmask_b32_e32 v0, v191, v128, vcc_lo                    ; 020101bf
	v_maxmin_num_f16 v186, 0xdf00, v186, neg(0xdf00)            ; d66b00ba 83ff74ff 0000df00
	v_maxmin_num_f16 v13, 0xdf00, v13, neg(0xdf00)              ; d66b000d 83fe1aff 0000df00
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v0, v9, v128, vcc_lo                      ; 02010109
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; d58b00bb
	v_cndmask_b32_e32 v0, v186, v128, vcc_lo                    ; 020101ba
	v_cvt_f32_f16_e32 v14, v13                                  ; 7e1c170d
(invalid instruction)                                        ; d76900bc
	v_cndmask_b32_e32 v0, v187, v128, vcc_lo                    ; 020101bb
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v168, v4, s[24:27], null offen              ; c406007c 408030a8 00000004
	buffer_store_b8 v173, v4, s[24:27], null offen offset:16    ; c406007c 408030ad 00001004
	buffer_store_b8 v178, v4, s[24:27], null offen offset:32    ; c406007c 408030b2 00002004
	buffer_store_b8 v183, v4, s[24:27], null offen offset:48    ; c406007c 408030b7 00003004
	buffer_store_b8 v188, v4, s[24:27], null offen offset:64    ; c406007c 408030bc 00004004
	buffer_store_b8 v191, v4, s[24:27], null offen offset:80    ; c406007c 408030bf 00005004
	buffer_store_b8 v10, v4, s[24:27], null offen offset:96     ; c406007c 4080300a 00006004
	buffer_store_b8 v15, v4, s[24:27], null offen offset:112    ; c406007c 4080300f 00007004
	s_branch BB57                                               ; bfa00001
BB56:
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB57:
	v_add_nc_u32_e32 v3, 48, v1                                 ; 4a0602b0
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc0 BB60                                         ; bfa100a7
BB58:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[24:27], s[6:7], 0x10                          ; f4004603 f8000010
	v_and_b32_e32 v6, 16, v0                                    ; 360c0090
	s_mov_b32 s3, 0xbd650000                                    ; be8300ff bd650000
	v_maxmin_num_f32 v8, -4.0, v40, 4.0                         ; d6690008 03da50f7
	v_maxmin_num_f32 v13, -4.0, v41, 4.0                        ; d669000d 03da52f7
	s_mov_b32 s6, 0x3ee50000                                    ; be8600ff 3ee50000
	s_lshr_b32 s1, s5, 4                                        ; 85018405
	v_lshrrev_b32_e32 v4, 4, v3                                 ; 32080684
	v_maxmin_num_f32 v18, -4.0, v42, 4.0                        ; d6690012 03da54f7
	v_maxmin_num_f32 v23, -4.0, v43, 4.0                        ; d6690017 03da56f7
	v_lshl_or_b32 v6, v6, 3, v7                                 ; d6560006 041d0706
	v_maxmin_num_f32 v28, -4.0, v44, 4.0                        ; d669001c 03da58f7
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d5080209
	v_cndmask_b32_e32 v1, s3, v8, vcc_lo                        ; 02021003
	s_mul_i32 s1, s8, s1                                        ; 96010108
(invalid instruction)                                        ; d508020e
	v_cndmask_b32_e32 v1, s3, v13, vcc_lo                       ; 02021a03
	v_maxmin_num_f32 v33, -4.0, v45, 4.0                        ; d6690021 03da5af7
(invalid instruction)                                        ; d5080213
	v_cndmask_b32_e32 v1, s3, v18, vcc_lo                       ; 02022403
(invalid instruction)                                        ; d5080218
	v_cndmask_b32_e32 v1, s3, v23, vcc_lo                       ; 02022e03
(invalid instruction)                                        ; d508021d
	v_cndmask_b32_e32 v1, s3, v28, vcc_lo                       ; 02023803
	v_dual_fmaak_f32 v14, v14, v13, 0x3f650000 :: v_dual_fmaak_f32 v9, v9, v8, 0x3f650000 ; c8421b0e 0e081109 3f650000
(invalid instruction)                                        ; d5080222
	v_cndmask_b32_e32 v1, s3, v33, vcc_lo                       ; 02024203
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v24, v24, v23, 0x3f650000 :: v_dual_fmaak_f32 v19, v19, v18, 0x3f650000 ; c8422f18 18122513 3f650000
	v_dual_fmac_f32 v14, s6, v13 :: v_dual_fmac_f32 v9, s6, v8  ; c8001a06 0e081006
	v_dual_fmaak_f32 v34, v34, v33, 0x3f650000 :: v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 ; c8424322 221c391d 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_fmac_f32 v24, s6, v23 :: v_dual_fmac_f32 v19, s6, v18 ; c8002e06 18122406
	v_maxmin_num_f32 v38, -4.0, v46, 4.0                        ; d6690026 03da5cf7
	v_fma_mixlo_f16 v10, v40, v9, neg(0) op_sel_hi:[0,0,1]      ; cc21400a 82021328
	v_fma_mixlo_f16 v15, v41, v14, neg(0) op_sel_hi:[0,0,1]     ; cc21400f 82021d29
	v_dual_fmac_f32 v34, s6, v33 :: v_dual_fmac_f32 v29, s6, v28 ; c8004206 221c3806
	v_fma_mixlo_f16 v20, v42, v19, neg(0) op_sel_hi:[0,0,1]     ; cc214014 8202272a
	v_fma_mixlo_f16 v25, v43, v24, neg(0) op_sel_hi:[0,0,1]     ; cc214019 8202312b
	v_maxmin_num_f32 v43, -4.0, v47, 4.0                        ; d669002b 03da5ef7
(invalid instruction)                                        ; d5080227
	v_cndmask_b32_e32 v1, s3, v38, vcc_lo                       ; 02024c03
	v_maxmin_num_f16 v10, 0xdf00, v10, neg(0xdf00)              ; d66b000a 83fe14ff 0000df00
	v_maxmin_num_f16 v15, 0xdf00, v15, neg(0xdf00)              ; d66b000f 83fe1eff 0000df00
	v_fma_mixlo_f16 v30, v44, v29, neg(0) op_sel_hi:[0,0,1]     ; cc21401e 82023b2c
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
	v_maxmin_num_f16 v25, 0xdf00, v25, neg(0xdf00)              ; d66b0019 83fe32ff 0000df00
	v_fma_mixlo_f16 v35, v45, v34, neg(0) op_sel_hi:[0,0,1]     ; cc214023 8202452d
(invalid instruction)                                        ; d508022c
	v_cndmask_b32_e32 v1, s3, v43, vcc_lo                       ; 02025603
	v_cvt_f32_f16_e32 v11, v10                                  ; 7e16170a
	v_cvt_f32_f16_e32 v16, v15                                  ; 7e20170f
	v_maxmin_num_f16 v30, 0xdf00, v30, neg(0xdf00)              ; d66b001e 83fe3cff 0000df00
	v_cvt_f32_f16_e32 v21, v20                                  ; 7e2a1714
	v_cvt_f32_f16_e32 v26, v25                                  ; 7e341719
	v_maxmin_num_f16 v35, 0xdf00, v35, neg(0xdf00)              ; d66b0023 83fe46ff 0000df00
	v_dual_fmaak_f32 v44, v44, v43, 0x3f650000 :: v_dual_fmaak_f32 v39, v39, v38, 0x3f650000 ; c842572c 2c264d27 3f650000
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
	v_cvt_f32_f16_e32 v31, v30                                  ; 7e3e171e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v4, s1, v4, 8                                ; d6470004 02220801
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
	v_cvt_f32_f16_e32 v36, v35                                  ; 7e481723
	v_dual_fmac_f32 v44, s6, v43 :: v_dual_fmac_f32 v39, s6, v38 ; c8005606 2c264c06
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v0, v31, v128, vcc_lo                     ; 0201011f
	v_add3_u32 v6, v6, s2, v4                                   ; d6550006 04100506
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
	v_fma_mixlo_f16 v45, v47, v44, neg(0) op_sel_hi:[0,0,1]     ; cc21402d 8202592f
	v_fma_mixlo_f16 v40, v46, v39, neg(0) op_sel_hi:[0,0,1]     ; cc214028 82024f2e
	v_maxmin_num_f16 v45, 0xdf00, v45, neg(0xdf00)              ; d66b002d 83fe5aff 0000df00
	v_maxmin_num_f16 v40, 0xdf00, v40, neg(0xdf00)              ; d66b0028 83fe50ff 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v46, v45                                  ; 7e5c172d
	v_cvt_f32_f16_e32 v41, v40                                  ; 7e521728
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v0, v41, v128, vcc_lo                     ; 02010129
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v12, v6, s[24:27], null offen               ; c406007c 4080300c 00000006
	buffer_store_b8 v17, v6, s[24:27], null offen offset:16     ; c406007c 40803011 00001006
	buffer_store_b8 v22, v6, s[24:27], null offen offset:32     ; c406007c 40803016 00002006
	buffer_store_b8 v27, v6, s[24:27], null offen offset:48     ; c406007c 4080301b 00003006
	buffer_store_b8 v32, v6, s[24:27], null offen offset:64     ; c406007c 40803020 00004006
	buffer_store_b8 v37, v6, s[24:27], null offen offset:80     ; c406007c 40803025 00005006
	buffer_store_b8 v42, v6, s[24:27], null offen offset:96     ; c406007c 4080302a 00006006
	buffer_store_b8 v47, v6, s[24:27], null offen offset:112    ; c406007c 4080302f 00007006
BB60:
	s_cmp_lt_u32 s10, s4                                        ; bf0a040a
	s_cbranch_scc0 BB63                                         ; bfa10269
BB61:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[24:27], s[6:7], 0x10                          ; f4004603 f8000010
	v_and_b32_e32 v6, 16, v0                                    ; 360c0090
	s_mov_b32 s3, 0xbd650000                                    ; be8300ff bd650000
	v_maxmin_num_f32 v8, -4.0, v48, 4.0                         ; d6690008 03da60f7
	v_maxmin_num_f32 v13, -4.0, v49, 4.0                        ; d669000d 03da62f7
	s_mov_b32 s6, 0x3ee50000                                    ; be8600ff 3ee50000
	s_lshr_b32 s1, s5, 4                                        ; 85018405
	v_lshrrev_b32_e32 v4, 4, v1                                 ; 32080284
	v_maxmin_num_f32 v18, -4.0, v50, 4.0                        ; d6690012 03da64f7
	v_maxmin_num_f32 v23, -4.0, v51, 4.0                        ; d6690017 03da66f7
	v_lshl_or_b32 v6, v6, 3, v7                                 ; d6560006 041d0706
	v_maxmin_num_f32 v28, -4.0, v52, 4.0                        ; d669001c 03da68f7
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d5080209
	v_cndmask_b32_e32 v1, s3, v8, vcc_lo                        ; 02021003
	s_mul_i32 s11, s11, s1                                      ; 960b010b
(invalid instruction)                                        ; d508020e
	v_cndmask_b32_e32 v1, s3, v13, vcc_lo                       ; 02021a03
	v_maxmin_num_f32 v33, -4.0, v53, 4.0                        ; d6690021 03da6af7
(invalid instruction)                                        ; d5080213
	v_cndmask_b32_e32 v1, s3, v18, vcc_lo                       ; 02022403
(invalid instruction)                                        ; d5080218
	v_cndmask_b32_e32 v1, s3, v23, vcc_lo                       ; 02022e03
(invalid instruction)                                        ; d508021d
	v_cndmask_b32_e32 v1, s3, v28, vcc_lo                       ; 02023803
	v_dual_fmaak_f32 v14, v14, v13, 0x3f650000 :: v_dual_fmaak_f32 v9, v9, v8, 0x3f650000 ; c8421b0e 0e081109 3f650000
(invalid instruction)                                        ; d5080222
	v_cndmask_b32_e32 v1, s3, v33, vcc_lo                       ; 02024203
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v24, v24, v23, 0x3f650000 :: v_dual_fmaak_f32 v19, v19, v18, 0x3f650000 ; c8422f18 18122513 3f650000
	v_dual_fmac_f32 v14, s6, v13 :: v_dual_fmac_f32 v9, s6, v8  ; c8001a06 0e081006
	v_dual_fmaak_f32 v34, v34, v33, 0x3f650000 :: v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 ; c8424322 221c391d 3f650000
	v_maxmin_num_f32 v38, -4.0, v54, 4.0                        ; d6690026 03da6cf7
	v_dual_fmac_f32 v24, s6, v23 :: v_dual_fmac_f32 v19, s6, v18 ; c8002e06 18122406
	v_maxmin_num_f32 v43, -4.0, v55, 4.0                        ; d669002b 03da6ef7
	v_fma_mixlo_f16 v10, v48, v9, neg(0) op_sel_hi:[0,0,1]      ; cc21400a 82021330
	v_fma_mixlo_f16 v15, v49, v14, neg(0) op_sel_hi:[0,0,1]     ; cc21400f 82021d31
	v_dual_fmac_f32 v34, s6, v33 :: v_dual_fmac_f32 v29, s6, v28 ; c8004206 221c3806
(invalid instruction)                                        ; d5080227
	v_cndmask_b32_e32 v1, s3, v38, vcc_lo                       ; 02024c03
	v_fma_mixlo_f16 v20, v50, v19, neg(0) op_sel_hi:[0,0,1]     ; cc214014 82022732
	v_fma_mixlo_f16 v25, v51, v24, neg(0) op_sel_hi:[0,0,1]     ; cc214019 82023133
(invalid instruction)                                        ; d508022c
	v_cndmask_b32_e32 v1, s3, v43, vcc_lo                       ; 02025603
	v_maxmin_num_f16 v10, 0xdf00, v10, neg(0xdf00)              ; d66b000a 83fe14ff 0000df00
	v_maxmin_num_f16 v15, 0xdf00, v15, neg(0xdf00)              ; d66b000f 83fe1eff 0000df00
	v_fma_mixlo_f16 v30, v52, v29, neg(0) op_sel_hi:[0,0,1]     ; cc21401e 82023b34
	v_fma_mixlo_f16 v35, v53, v34, neg(0) op_sel_hi:[0,0,1]     ; cc214023 82024535
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
	v_maxmin_num_f16 v25, 0xdf00, v25, neg(0xdf00)              ; d66b0019 83fe32ff 0000df00
	v_dual_fmaak_f32 v44, v44, v43, 0x3f650000 :: v_dual_fmaak_f32 v39, v39, v38, 0x3f650000 ; c842572c 2c264d27 3f650000
	v_cvt_f32_f16_e32 v11, v10                                  ; 7e16170a
	v_cvt_f32_f16_e32 v16, v15                                  ; 7e20170f
	v_maxmin_num_f16 v30, 0xdf00, v30, neg(0xdf00)              ; d66b001e 83fe3cff 0000df00
	v_maxmin_num_f16 v35, 0xdf00, v35, neg(0xdf00)              ; d66b0023 83fe46ff 0000df00
	v_cvt_f32_f16_e32 v21, v20                                  ; 7e2a1714
	v_cvt_f32_f16_e32 v26, v25                                  ; 7e341719
	v_dual_fmac_f32 v44, s6, v43 :: v_dual_fmac_f32 v39, s6, v38 ; c8005606 2c264c06
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
	v_cvt_f32_f16_e32 v31, v30                                  ; 7e3e171e
	v_add_lshl_u32 v4, s11, v4, 8                               ; d6470004 0222080b
	v_cvt_f32_f16_e32 v36, v35                                  ; 7e481723
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
	v_fma_mixlo_f16 v45, v55, v44, neg(0) op_sel_hi:[0,0,1]     ; cc21402d 82025937
	v_fma_mixlo_f16 v40, v54, v39, neg(0) op_sel_hi:[0,0,1]     ; cc214028 82024f36
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v0, v31, v128, vcc_lo                     ; 0201011f
	v_add3_u32 v4, v6, s2, v4                                   ; d6550004 04100506
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
	v_maxmin_num_f16 v45, 0xdf00, v45, neg(0xdf00)              ; d66b002d 83fe5aff 0000df00
	v_maxmin_num_f16 v40, 0xdf00, v40, neg(0xdf00)              ; d66b0028 83fe50ff 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v46, v45                                  ; 7e5c172d
	v_cvt_f32_f16_e32 v41, v40                                  ; 7e521728
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v0, v41, v128, vcc_lo                     ; 02010129
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v12, v4, s[24:27], null offen               ; c406007c 4080300c 00000004
	buffer_store_b8 v17, v4, s[24:27], null offen offset:16     ; c406007c 40803011 00001004
	buffer_store_b8 v22, v4, s[24:27], null offen offset:32     ; c406007c 40803016 00002004
	buffer_store_b8 v27, v4, s[24:27], null offen offset:48     ; c406007c 4080301b 00003004
	buffer_store_b8 v32, v4, s[24:27], null offen offset:64     ; c406007c 40803020 00004004
	buffer_store_b8 v37, v4, s[24:27], null offen offset:80     ; c406007c 40803025 00005004
	buffer_store_b8 v42, v4, s[24:27], null offen offset:96     ; c406007c 4080302a 00006004
	buffer_store_b8 v47, v4, s[24:27], null offen offset:112    ; c406007c 4080302f 00007004
	v_maxmin_num_f32 v49, -4.0, v56, 4.0                        ; d6690031 03da70f7
	v_maxmin_num_f32 v54, -4.0, v57, 4.0                        ; d6690036 03da72f7
	v_maxmin_num_f32 v145, -4.0, v58, 4.0                       ; d6690091 03da74f7
	v_maxmin_num_f32 v150, -4.0, v59, 4.0                       ; d6690096 03da76f7
	v_lshrrev_b32_e32 v48, 4, v2                                ; 32600484
	v_maxmin_num_f32 v155, -4.0, v60, 4.0                       ; d669009b 03da78f7
	v_maxmin_num_f32 v160, -4.0, v61, 4.0                       ; d66900a0 03da7af7
(invalid instruction)                                        ; d5080232
	v_cndmask_b32_e32 v1, s3, v49, vcc_lo                       ; 02026203
(invalid instruction)                                        ; d5080237
	v_cndmask_b32_e32 v1, s3, v54, vcc_lo                       ; 02026c03
(invalid instruction)                                        ; d5080292
	v_cndmask_b32_e32 v1, s3, v145, vcc_lo                      ; 02032203
(invalid instruction)                                        ; d5080297
	v_cndmask_b32_e32 v1, s3, v150, vcc_lo                      ; 02032c03
(invalid instruction)                                        ; d508029c
	v_cndmask_b32_e32 v1, s3, v155, vcc_lo                      ; 02033603
(invalid instruction)                                        ; d50802a1
	v_cndmask_b32_e32 v1, s3, v160, vcc_lo                      ; 02034003
	v_dual_fmaak_f32 v55, v55, v54, 0x3f650000 :: v_dual_fmaak_f32 v50, v50, v49, 0x3f650000 ; c8426d37 37326332 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v145, 0x3f650000 ; c8432d97 97932392 3f650000
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 ; c84341a1 a19d379c 3f650000
	v_maxmin_num_f32 v165, -4.0, v62, 4.0                       ; d66900a5 03da7cf7
	v_dual_fmac_f32 v55, s6, v54 :: v_dual_fmac_f32 v50, s6, v49 ; c8006c06 37326206
	v_maxmin_num_f32 v170, -4.0, v63, 4.0                       ; d66900aa 03da7ef7
	v_dual_fmac_f32 v151, s6, v150 :: v_dual_fmac_f32 v146, s6, v145 ; c8012c06 97932206
	v_dual_fmac_f32 v161, s6, v160 :: v_dual_fmac_f32 v156, s6, v155 ; c8014006 a19d3606
(invalid instruction)                                        ; d50802a6
	v_cndmask_b32_e32 v1, s3, v165, vcc_lo                      ; 02034a03
	v_fma_mixlo_f16 v51, v56, v50, neg(0) op_sel_hi:[0,0,1]     ; cc214033 82026538
	v_fma_mixlo_f16 v56, v57, v55, neg(0) op_sel_hi:[0,0,1]     ; cc214038 82026f39
(invalid instruction)                                        ; d50802ab
	v_cndmask_b32_e32 v1, s3, v170, vcc_lo                      ; 02035403
	v_fma_mixlo_f16 v147, v58, v146, neg(0) op_sel_hi:[0,0,1]   ; cc214093 8203253a
	v_fma_mixlo_f16 v152, v59, v151, neg(0) op_sel_hi:[0,0,1]   ; cc214098 82032f3b
	v_fma_mixlo_f16 v157, v60, v156, neg(0) op_sel_hi:[0,0,1]   ; cc21409d 8203393c
	v_maxmin_num_f16 v51, 0xdf00, v51, neg(0xdf00)              ; d66b0033 83fe66ff 0000df00
	v_maxmin_num_f16 v56, 0xdf00, v56, neg(0xdf00)              ; d66b0038 83fe70ff 0000df00
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84355ab aba74ba6 3f650000
	v_fma_mixlo_f16 v162, v61, v161, neg(0) op_sel_hi:[0,0,1]   ; cc2140a2 8203433d
	v_maxmin_num_f16 v147, 0xdf00, v147, neg(0xdf00)            ; d66b0093 83ff26ff 0000df00
	v_maxmin_num_f16 v152, 0xdf00, v152, neg(0xdf00)            ; d66b0098 83ff30ff 0000df00
	v_maxmin_num_f16 v157, 0xdf00, v157, neg(0xdf00)            ; d66b009d 83ff3aff 0000df00
	v_cvt_f32_f16_e32 v52, v51                                  ; 7e681733
	v_cvt_f32_f16_e32 v57, v56                                  ; 7e721738
	v_dual_fmac_f32 v171, s6, v170 :: v_dual_fmac_f32 v166, s6, v165 ; c8015406 aba74a06
	v_maxmin_num_f16 v162, 0xdf00, v162, neg(0xdf00)            ; d66b00a2 83ff44ff 0000df00
(invalid instruction)                                        ; d58b0094
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                    ; 02010193
(invalid instruction)                                        ; d58b0099
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                    ; 02010198
(invalid instruction)                                        ; d58b009e
	v_cndmask_b32_e32 v0, v157, v128, vcc_lo                    ; 0201019d
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v0, v52, v128, vcc_lo                     ; 02010134
	v_add_lshl_u32 v48, s11, v48, 8                             ; d6470030 0222600b
(invalid instruction)                                        ; d7690090
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                     ; 02010139
	v_fma_mixlo_f16 v167, v62, v166, neg(0) op_sel_hi:[0,0,1]   ; cc2140a7 82034d3e
	v_fma_mixlo_f16 v172, v63, v171, neg(0) op_sel_hi:[0,0,1]   ; cc2140ac 8203573f
(invalid instruction)                                        ; d58b00a3
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
(invalid instruction)                                        ; d7690095
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                    ; 02010194
(invalid instruction)                                        ; d769009a
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                    ; 02010199
(invalid instruction)                                        ; d769009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
	v_add3_u32 v48, v6, s2, v48                                 ; d6550030 04c00506
	v_maxmin_num_f16 v167, 0xdf00, v167, neg(0xdf00)            ; d66b00a7 83ff4eff 0000df00
	v_maxmin_num_f16 v172, 0xdf00, v172, neg(0xdf00)            ; d66b00ac 83ff58ff 0000df00
(invalid instruction)                                        ; d76900a4
	v_cndmask_b32_e32 v0, v163, v128, vcc_lo                    ; 020101a3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; d58b00a8
	v_cndmask_b32_e32 v0, v167, v128, vcc_lo                    ; 020101a7
(invalid instruction)                                        ; d58b00ad
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
(invalid instruction)                                        ; d76900a9
	v_cndmask_b32_e32 v0, v168, v128, vcc_lo                    ; 020101a8
(invalid instruction)                                        ; d76900ae
	v_cndmask_b32_e32 v0, v173, v128, vcc_lo                    ; 020101ad
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v53, v48, s[24:27], null offen              ; c406007c 40803035 00000030
	buffer_store_b8 v144, v48, s[24:27], null offen offset:16   ; c406007c 40803090 00001030
	buffer_store_b8 v149, v48, s[24:27], null offen offset:32   ; c406007c 40803095 00002030
	buffer_store_b8 v154, v48, s[24:27], null offen offset:48   ; c406007c 4080309a 00003030
	buffer_store_b8 v159, v48, s[24:27], null offen offset:64   ; c406007c 4080309f 00004030
	buffer_store_b8 v164, v48, s[24:27], null offen offset:80   ; c406007c 408030a4 00005030
	buffer_store_b8 v169, v48, s[24:27], null offen offset:96   ; c406007c 408030a9 00006030
	buffer_store_b8 v174, v48, s[24:27], null offen offset:112  ; c406007c 408030ae 00007030
	v_maxmin_num_f32 v176, -4.0, v64, 4.0                       ; d66900b0 03da80f7
	v_maxmin_num_f32 v181, -4.0, v65, 4.0                       ; d66900b5 03da82f7
	v_maxmin_num_f32 v186, -4.0, v66, 4.0                       ; d66900ba 03da84f7
	v_maxmin_num_f32 v191, -4.0, v67, 4.0                       ; d66900bf 03da86f7
	v_lshrrev_b32_e32 v175, 4, v5                               ; 335e0a84
	v_maxmin_num_f32 v11, -4.0, v68, 4.0                        ; d669000b 03da88f7
	v_maxmin_num_f32 v16, -4.0, v69, 4.0                        ; d6690010 03da8af7
(invalid instruction)                                        ; d50802b1
	v_cndmask_b32_e32 v1, s3, v176, vcc_lo                      ; 02036003
(invalid instruction)                                        ; d50802b6
	v_cndmask_b32_e32 v1, s3, v181, vcc_lo                      ; 02036a03
(invalid instruction)                                        ; d50802bb
	v_cndmask_b32_e32 v1, s3, v186, vcc_lo                      ; 02037403
(invalid instruction)                                        ; d5080204
	v_cndmask_b32_e32 v1, s3, v191, vcc_lo                      ; 02037e03
(invalid instruction)                                        ; d508020c
	v_cndmask_b32_e32 v1, s3, v11, vcc_lo                       ; 02021603
(invalid instruction)                                        ; d5080211
	v_cndmask_b32_e32 v1, s3, v16, vcc_lo                       ; 02022003
	v_dual_fmaak_f32 v182, v182, v181, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 ; c8436bb6 b6b161b1 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v4, v4, v191, 0x3f650000 :: v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 ; c8437f04 04bb75bb 3f650000
	v_dual_fmaak_f32 v12, v12, v11, 0x3f650000 :: v_dual_fmaak_f32 v17, v17, v16, 0x3f650000 ; c842170c 0c102111 3f650000
	v_maxmin_num_f32 v21, -4.0, v70, 4.0                        ; d6690015 03da8cf7
	v_dual_fmac_f32 v182, s6, v181 :: v_dual_fmac_f32 v177, s6, v176 ; c8016a06 b6b16006
	v_maxmin_num_f32 v26, -4.0, v71, 4.0                        ; d669001a 03da8ef7
	v_dual_fmac_f32 v4, s6, v191 :: v_dual_fmac_f32 v187, s6, v186 ; c8017e06 04bb7406
	v_dual_fmac_f32 v17, s6, v16 :: v_dual_fmac_f32 v12, s6, v11 ; c8002006 110c1606
(invalid instruction)                                        ; d5080216
	v_cndmask_b32_e32 v1, s3, v21, vcc_lo                       ; 02022a03
	v_fma_mixlo_f16 v183, v65, v182, neg(0) op_sel_hi:[0,0,1]   ; cc2140b7 82036d41
	v_fma_mixlo_f16 v178, v64, v177, neg(0) op_sel_hi:[0,0,1]   ; cc2140b2 82036340
(invalid instruction)                                        ; d508021b
	v_cndmask_b32_e32 v1, s3, v26, vcc_lo                       ; 02023403
	v_fma_mixlo_f16 v8, v67, v4, neg(0) op_sel_hi:[0,0,1]       ; cc214008 82020943
	v_fma_mixlo_f16 v188, v66, v187, neg(0) op_sel_hi:[0,0,1]   ; cc2140bc 82037742
	v_fma_mixlo_f16 v13, v68, v12, neg(0) op_sel_hi:[0,0,1]     ; cc21400d 82021944
	v_maxmin_num_f16 v183, 0xdf00, v183, neg(0xdf00)            ; d66b00b7 83ff6eff 0000df00
	v_maxmin_num_f16 v178, 0xdf00, v178, neg(0xdf00)            ; d66b00b2 83ff64ff 0000df00
	v_fma_mixlo_f16 v18, v69, v17, neg(0) op_sel_hi:[0,0,1]     ; cc214012 82022345
	v_dual_fmaak_f32 v22, v22, v21, 0x3f650000 :: v_dual_fmaak_f32 v27, v27, v26, 0x3f650000 ; c8422b16 161a351b 3f650000
	v_maxmin_num_f16 v8, 0xdf00, v8, neg(0xdf00)                ; d66b0008 83fe10ff 0000df00
	v_maxmin_num_f16 v188, 0xdf00, v188, neg(0xdf00)            ; d66b00bc 83ff78ff 0000df00
	v_maxmin_num_f16 v13, 0xdf00, v13, neg(0xdf00)              ; d66b000d 83fe1aff 0000df00
(invalid instruction)                                        ; d58b00b8
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                    ; 020101b7
(invalid instruction)                                        ; d58b00b3
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                    ; 020101b2
	v_maxmin_num_f16 v18, 0xdf00, v18, neg(0xdf00)              ; d66b0012 83fe24ff 0000df00
	v_dual_fmac_f32 v27, s6, v26 :: v_dual_fmac_f32 v22, s6, v21 ; c8003406 1b162a06
	v_cvt_f32_f16_e32 v9, v8                                    ; 7e121708
(invalid instruction)                                        ; d58b00bd
	v_cndmask_b32_e32 v0, v188, v128, vcc_lo                    ; 020101bc
	v_cvt_f32_f16_e32 v14, v13                                  ; 7e1c170d
(invalid instruction)                                        ; d76900b9
	v_cndmask_b32_e32 v0, v184, v128, vcc_lo                    ; 020101b8
(invalid instruction)                                        ; d76900b4
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                    ; 020101b3
	v_add_lshl_u32 v175, s11, v175, 8                           ; d64700af 02235e0b
	v_cvt_f32_f16_e32 v19, v18                                  ; 7e261712
	v_fma_mixlo_f16 v28, v71, v27, neg(0) op_sel_hi:[0,0,1]     ; cc21401c 82023747
	v_fma_mixlo_f16 v23, v70, v22, neg(0) op_sel_hi:[0,0,1]     ; cc214017 82022d46
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v0, v9, v128, vcc_lo                      ; 02010109
(invalid instruction)                                        ; d76900be
	v_cndmask_b32_e32 v0, v189, v128, vcc_lo                    ; 020101bd
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	v_add3_u32 v175, v6, s2, v175                               ; d65500af 06bc0506
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v0, v19, v128, vcc_lo                     ; 02010113
	v_maxmin_num_f16 v28, 0xdf00, v28, neg(0xdf00)              ; d66b001c 83fe38ff 0000df00
	v_maxmin_num_f16 v23, 0xdf00, v23, neg(0xdf00)              ; d66b0017 83fe2eff 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v29, v28                                  ; 7e3a171c
	v_cvt_f32_f16_e32 v24, v23                                  ; 7e301717
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v0, v29, v128, vcc_lo                     ; 0201011d
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v0, v24, v128, vcc_lo                     ; 02010118
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v180, v175, s[24:27], null offen            ; c406007c 408030b4 000000af
	buffer_store_b8 v185, v175, s[24:27], null offen offset:16  ; c406007c 408030b9 000010af
	buffer_store_b8 v190, v175, s[24:27], null offen offset:32  ; c406007c 408030be 000020af
	buffer_store_b8 v10, v175, s[24:27], null offen offset:48   ; c406007c 4080300a 000030af
	buffer_store_b8 v15, v175, s[24:27], null offen offset:64   ; c406007c 4080300f 000040af
	buffer_store_b8 v20, v175, s[24:27], null offen offset:80   ; c406007c 40803014 000050af
	buffer_store_b8 v25, v175, s[24:27], null offen offset:96   ; c406007c 40803019 000060af
	buffer_store_b8 v30, v175, s[24:27], null offen offset:112  ; c406007c 4080301e 000070af
	v_maxmin_num_f32 v32, -4.0, v72, 4.0                        ; d6690020 03da90f7
	v_maxmin_num_f32 v37, -4.0, v73, 4.0                        ; d6690025 03da92f7
	v_maxmin_num_f32 v42, -4.0, v74, 4.0                        ; d669002a 03da94f7
	v_maxmin_num_f32 v47, -4.0, v75, 4.0                        ; d669002f 03da96f7
	v_lshrrev_b32_e32 v31, 4, v3                                ; 323e0684
	v_maxmin_num_f32 v52, -4.0, v76, 4.0                        ; d6690034 03da98f7
	v_maxmin_num_f32 v57, -4.0, v77, 4.0                        ; d6690039 03da9af7
(invalid instruction)                                        ; d5080221
	v_cndmask_b32_e32 v1, s3, v32, vcc_lo                       ; 02024003
(invalid instruction)                                        ; d5080226
	v_cndmask_b32_e32 v1, s3, v37, vcc_lo                       ; 02024a03
(invalid instruction)                                        ; d508022b
	v_cndmask_b32_e32 v1, s3, v42, vcc_lo                       ; 02025403
(invalid instruction)                                        ; d5080230
	v_cndmask_b32_e32 v1, s3, v47, vcc_lo                       ; 02025e03
(invalid instruction)                                        ; d5080235
	v_cndmask_b32_e32 v1, s3, v52, vcc_lo                       ; 02026803
(invalid instruction)                                        ; d508023a
	v_cndmask_b32_e32 v1, s3, v57, vcc_lo                       ; 02027203
	v_dual_fmaak_f32 v38, v38, v37, 0x3f650000 :: v_dual_fmaak_f32 v33, v33, v32, 0x3f650000 ; c8424b26 26204121 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v48, v48, v47, 0x3f650000 :: v_dual_fmaak_f32 v43, v43, v42, 0x3f650000 ; c8425f30 302a552b 3f650000
	v_dual_fmaak_f32 v58, v58, v57, 0x3f650000 :: v_dual_fmaak_f32 v53, v53, v52, 0x3f650000 ; c842733a 3a346935 3f650000
	v_maxmin_num_f32 v62, -4.0, v78, 4.0                        ; d669003e 03da9cf7
	v_dual_fmac_f32 v38, s6, v37 :: v_dual_fmac_f32 v33, s6, v32 ; c8004a06 26204006
	v_maxmin_num_f32 v67, -4.0, v79, 4.0                        ; d6690043 03da9ef7
	v_dual_fmac_f32 v48, s6, v47 :: v_dual_fmac_f32 v43, s6, v42 ; c8005e06 302a5406
	v_dual_fmac_f32 v58, s6, v57 :: v_dual_fmac_f32 v53, s6, v52 ; c8007206 3a346806
(invalid instruction)                                        ; d508023f
	v_cndmask_b32_e32 v1, s3, v62, vcc_lo                       ; 02027c03
	v_fma_mixlo_f16 v39, v73, v38, neg(0) op_sel_hi:[0,0,1]     ; cc214027 82024d49
	v_fma_mixlo_f16 v34, v72, v33, neg(0) op_sel_hi:[0,0,1]     ; cc214022 82024348
(invalid instruction)                                        ; d5080244
	v_cndmask_b32_e32 v1, s3, v67, vcc_lo                       ; 02028603
	v_fma_mixlo_f16 v49, v75, v48, neg(0) op_sel_hi:[0,0,1]     ; cc214031 8202614b
	v_fma_mixlo_f16 v44, v74, v43, neg(0) op_sel_hi:[0,0,1]     ; cc21402c 8202574a
	v_fma_mixlo_f16 v54, v76, v53, neg(0) op_sel_hi:[0,0,1]     ; cc214036 82026b4c
	v_maxmin_num_f16 v39, 0xdf00, v39, neg(0xdf00)              ; d66b0027 83fe4eff 0000df00
	v_maxmin_num_f16 v34, 0xdf00, v34, neg(0xdf00)              ; d66b0022 83fe44ff 0000df00
	v_fma_mixlo_f16 v59, v77, v58, neg(0) op_sel_hi:[0,0,1]     ; cc21403b 8202754d
	v_dual_fmaak_f32 v68, v68, v67, 0x3f650000 :: v_dual_fmaak_f32 v63, v63, v62, 0x3f650000 ; c8428744 443e7d3f 3f650000
	v_maxmin_num_f16 v49, 0xdf00, v49, neg(0xdf00)              ; d66b0031 83fe62ff 0000df00
	v_maxmin_num_f16 v44, 0xdf00, v44, neg(0xdf00)              ; d66b002c 83fe58ff 0000df00
	v_maxmin_num_f16 v54, 0xdf00, v54, neg(0xdf00)              ; d66b0036 83fe6cff 0000df00
	v_cvt_f32_f16_e32 v40, v39                                  ; 7e501727
	v_cvt_f32_f16_e32 v35, v34                                  ; 7e461722
	v_maxmin_num_f16 v59, 0xdf00, v59, neg(0xdf00)              ; d66b003b 83fe76ff 0000df00
	v_dual_fmac_f32 v68, s6, v67 :: v_dual_fmac_f32 v63, s6, v62 ; c8008606 443e7c06
	v_cvt_f32_f16_e32 v50, v49                                  ; 7e641731
	v_cvt_f32_f16_e32 v45, v44                                  ; 7e5a172c
	v_cvt_f32_f16_e32 v55, v54                                  ; 7e6e1736
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v0, v40, v128, vcc_lo                     ; 02010128
	v_add_lshl_u32 v31, s11, v31, 8                             ; d647001f 02223e0b
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v0, v35, v128, vcc_lo                     ; 02010123
	v_cvt_f32_f16_e32 v60, v59                                  ; 7e78173b
	v_fma_mixlo_f16 v69, v79, v68, neg(0) op_sel_hi:[0,0,1]     ; cc214045 8202894f
	v_fma_mixlo_f16 v64, v78, v63, neg(0) op_sel_hi:[0,0,1]     ; cc214040 82027f4e
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v0, v50, v128, vcc_lo                     ; 02010132
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v0, v45, v128, vcc_lo                     ; 0201012d
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v0, v55, v128, vcc_lo                     ; 02010137
	v_add3_u32 v6, v6, s2, v31                                  ; d6550006 047c0506
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v0, v60, v128, vcc_lo                     ; 0201013c
	v_maxmin_num_f16 v69, 0xdf00, v69, neg(0xdf00)              ; d66b0045 83fe8aff 0000df00
	v_maxmin_num_f16 v64, 0xdf00, v64, neg(0xdf00)              ; d66b0040 83fe80ff 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v70, v69                                  ; 7e8c1745
	v_cvt_f32_f16_e32 v65, v64                                  ; 7e821740
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v0, v70, v128, vcc_lo                     ; 02010146
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v0, v65, v128, vcc_lo                     ; 02010141
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v36, v6, s[24:27], null offen               ; c406007c 40803024 00000006
	buffer_store_b8 v41, v6, s[24:27], null offen offset:16     ; c406007c 40803029 00001006
	buffer_store_b8 v46, v6, s[24:27], null offen offset:32     ; c406007c 4080302e 00002006
	buffer_store_b8 v51, v6, s[24:27], null offen offset:48     ; c406007c 40803033 00003006
	buffer_store_b8 v56, v6, s[24:27], null offen offset:64     ; c406007c 40803038 00004006
	buffer_store_b8 v61, v6, s[24:27], null offen offset:80     ; c406007c 4080303d 00005006
	buffer_store_b8 v66, v6, s[24:27], null offen offset:96     ; c406007c 40803042 00006006
	buffer_store_b8 v71, v6, s[24:27], null offen offset:112    ; c406007c 40803047 00007006
BB63:
	s_cmp_lt_u32 s15, s4                                        ; bf0a040f
	s_cbranch_scc0 BB66                                         ; bfa1026d
BB64:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[12:15], s[6:7], 0x10                          ; f4004303 f8000010
	v_and_b32_e32 v6, 16, v0                                    ; 360c0090
	s_mov_b32 s3, 0xbd650000                                    ; be8300ff bd650000
	v_maxmin_num_f32 v8, -4.0, v80, 4.0                         ; d6690008 03daa0f7
	v_maxmin_num_f32 v13, -4.0, v81, 4.0                        ; d669000d 03daa2f7
	s_mov_b32 s6, 0x3ee50000                                    ; be8600ff 3ee50000
	s_lshr_b32 s1, s5, 4                                        ; 85018405
	v_lshrrev_b32_e32 v4, 4, v1                                 ; 32080284
	v_maxmin_num_f32 v18, -4.0, v82, 4.0                        ; d6690012 03daa4f7
	v_maxmin_num_f32 v23, -4.0, v83, 4.0                        ; d6690017 03daa6f7
	v_lshl_or_b32 v6, v6, 3, v7                                 ; d6560006 041d0706
	v_maxmin_num_f32 v28, -4.0, v84, 4.0                        ; d669001c 03daa8f7
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d5080209
	v_cndmask_b32_e32 v1, s3, v8, vcc_lo                        ; 02021003
	s_mul_i32 s17, s17, s1                                      ; 96110111
(invalid instruction)                                        ; d508020e
	v_cndmask_b32_e32 v1, s3, v13, vcc_lo                       ; 02021a03
	v_maxmin_num_f32 v33, -4.0, v85, 4.0                        ; d6690021 03daaaf7
(invalid instruction)                                        ; d5080213
	v_cndmask_b32_e32 v1, s3, v18, vcc_lo                       ; 02022403
(invalid instruction)                                        ; d5080218
	v_cndmask_b32_e32 v1, s3, v23, vcc_lo                       ; 02022e03
(invalid instruction)                                        ; d508021d
	v_cndmask_b32_e32 v1, s3, v28, vcc_lo                       ; 02023803
	v_dual_fmaak_f32 v14, v14, v13, 0x3f650000 :: v_dual_fmaak_f32 v9, v9, v8, 0x3f650000 ; c8421b0e 0e081109 3f650000
(invalid instruction)                                        ; d5080222
	v_cndmask_b32_e32 v1, s3, v33, vcc_lo                       ; 02024203
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v24, v24, v23, 0x3f650000 :: v_dual_fmaak_f32 v19, v19, v18, 0x3f650000 ; c8422f18 18122513 3f650000
	v_dual_fmac_f32 v14, s6, v13 :: v_dual_fmac_f32 v9, s6, v8  ; c8001a06 0e081006
	v_dual_fmaak_f32 v34, v34, v33, 0x3f650000 :: v_dual_fmaak_f32 v29, v29, v28, 0x3f650000 ; c8424322 221c391d 3f650000
	v_maxmin_num_f32 v38, -4.0, v86, 4.0                        ; d6690026 03daacf7
	v_dual_fmac_f32 v24, s6, v23 :: v_dual_fmac_f32 v19, s6, v18 ; c8002e06 18122406
	v_maxmin_num_f32 v43, -4.0, v87, 4.0                        ; d669002b 03daaef7
	v_fma_mixlo_f16 v10, v80, v9, neg(0) op_sel_hi:[0,0,1]      ; cc21400a 82021350
	v_fma_mixlo_f16 v15, v81, v14, neg(0) op_sel_hi:[0,0,1]     ; cc21400f 82021d51
	v_dual_fmac_f32 v34, s6, v33 :: v_dual_fmac_f32 v29, s6, v28 ; c8004206 221c3806
(invalid instruction)                                        ; d5080227
	v_cndmask_b32_e32 v1, s3, v38, vcc_lo                       ; 02024c03
	v_fma_mixlo_f16 v20, v82, v19, neg(0) op_sel_hi:[0,0,1]     ; cc214014 82022752
	v_fma_mixlo_f16 v25, v83, v24, neg(0) op_sel_hi:[0,0,1]     ; cc214019 82023153
(invalid instruction)                                        ; d508022c
	v_cndmask_b32_e32 v1, s3, v43, vcc_lo                       ; 02025603
	v_maxmin_num_f16 v10, 0xdf00, v10, neg(0xdf00)              ; d66b000a 83fe14ff 0000df00
	v_maxmin_num_f16 v15, 0xdf00, v15, neg(0xdf00)              ; d66b000f 83fe1eff 0000df00
	v_fma_mixlo_f16 v30, v84, v29, neg(0) op_sel_hi:[0,0,1]     ; cc21401e 82023b54
	v_fma_mixlo_f16 v35, v85, v34, neg(0) op_sel_hi:[0,0,1]     ; cc214023 82024555
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
	v_maxmin_num_f16 v25, 0xdf00, v25, neg(0xdf00)              ; d66b0019 83fe32ff 0000df00
	v_dual_fmaak_f32 v44, v44, v43, 0x3f650000 :: v_dual_fmaak_f32 v39, v39, v38, 0x3f650000 ; c842572c 2c264d27 3f650000
	v_cvt_f32_f16_e32 v11, v10                                  ; 7e16170a
	v_cvt_f32_f16_e32 v16, v15                                  ; 7e20170f
	v_maxmin_num_f16 v30, 0xdf00, v30, neg(0xdf00)              ; d66b001e 83fe3cff 0000df00
	v_maxmin_num_f16 v35, 0xdf00, v35, neg(0xdf00)              ; d66b0023 83fe46ff 0000df00
	v_cvt_f32_f16_e32 v21, v20                                  ; 7e2a1714
	v_cvt_f32_f16_e32 v26, v25                                  ; 7e341719
	v_dual_fmac_f32 v44, s6, v43 :: v_dual_fmac_f32 v39, s6, v38 ; c8005606 2c264c06
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
	v_cvt_f32_f16_e32 v31, v30                                  ; 7e3e171e
	v_add_lshl_u32 v4, s17, v4, 8                               ; d6470004 02220811
	v_cvt_f32_f16_e32 v36, v35                                  ; 7e481723
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
	v_fma_mixlo_f16 v45, v87, v44, neg(0) op_sel_hi:[0,0,1]     ; cc21402d 82025957
	v_fma_mixlo_f16 v40, v86, v39, neg(0) op_sel_hi:[0,0,1]     ; cc214028 82024f56
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v0, v31, v128, vcc_lo                     ; 0201011f
	v_add3_u32 v4, v6, s2, v4                                   ; d6550004 04100506
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
	v_maxmin_num_f16 v45, 0xdf00, v45, neg(0xdf00)              ; d66b002d 83fe5aff 0000df00
	v_maxmin_num_f16 v40, 0xdf00, v40, neg(0xdf00)              ; d66b0028 83fe50ff 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v46, v45                                  ; 7e5c172d
	v_cvt_f32_f16_e32 v41, v40                                  ; 7e521728
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v0, v41, v128, vcc_lo                     ; 02010129
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v12, v4, s[12:15], null offen               ; c406007c 4080180c 00000004
	buffer_store_b8 v17, v4, s[12:15], null offen offset:16     ; c406007c 40801811 00001004
	buffer_store_b8 v22, v4, s[12:15], null offen offset:32     ; c406007c 40801816 00002004
	buffer_store_b8 v27, v4, s[12:15], null offen offset:48     ; c406007c 4080181b 00003004
	buffer_store_b8 v32, v4, s[12:15], null offen offset:64     ; c406007c 40801820 00004004
	buffer_store_b8 v37, v4, s[12:15], null offen offset:80     ; c406007c 40801825 00005004
	buffer_store_b8 v42, v4, s[12:15], null offen offset:96     ; c406007c 4080182a 00006004
	buffer_store_b8 v47, v4, s[12:15], null offen offset:112    ; c406007c 4080182f 00007004
	v_maxmin_num_f32 v49, -4.0, v88, 4.0                        ; d6690031 03dab0f7
	v_maxmin_num_f32 v54, -4.0, v89, 4.0                        ; d6690036 03dab2f7
	v_maxmin_num_f32 v59, -4.0, v90, 4.0                        ; d669003b 03dab4f7
	v_maxmin_num_f32 v64, -4.0, v91, 4.0                        ; d6690040 03dab6f7
	v_lshrrev_b32_e32 v48, 4, v2                                ; 32600484
	v_maxmin_num_f32 v69, -4.0, v92, 4.0                        ; d6690045 03dab8f7
	v_maxmin_num_f32 v74, -4.0, v93, 4.0                        ; d669004a 03dabaf7
(invalid instruction)                                        ; d5080232
	v_cndmask_b32_e32 v1, s3, v49, vcc_lo                       ; 02026203
(invalid instruction)                                        ; d5080237
	v_cndmask_b32_e32 v1, s3, v54, vcc_lo                       ; 02026c03
(invalid instruction)                                        ; d508023c
	v_cndmask_b32_e32 v1, s3, v59, vcc_lo                       ; 02027603
(invalid instruction)                                        ; d5080241
	v_cndmask_b32_e32 v1, s3, v64, vcc_lo                       ; 02028003
(invalid instruction)                                        ; d5080246
	v_cndmask_b32_e32 v1, s3, v69, vcc_lo                       ; 02028a03
(invalid instruction)                                        ; d508024b
	v_cndmask_b32_e32 v1, s3, v74, vcc_lo                       ; 02029403
	v_dual_fmaak_f32 v55, v55, v54, 0x3f650000 :: v_dual_fmaak_f32 v50, v50, v49, 0x3f650000 ; c8426d37 37326332 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v65, v65, v64, 0x3f650000 :: v_dual_fmaak_f32 v60, v60, v59, 0x3f650000 ; c8428141 413c773c 3f650000
	v_dual_fmaak_f32 v75, v75, v74, 0x3f650000 :: v_dual_fmaak_f32 v70, v70, v69, 0x3f650000 ; c842954b 4b468b46 3f650000
	v_maxmin_num_f32 v79, -4.0, v94, 4.0                        ; d669004f 03dabcf7
	v_dual_fmac_f32 v55, s6, v54 :: v_dual_fmac_f32 v50, s6, v49 ; c8006c06 37326206
	v_maxmin_num_f32 v84, -4.0, v95, 4.0                        ; d6690054 03dabef7
	v_dual_fmac_f32 v65, s6, v64 :: v_dual_fmac_f32 v60, s6, v59 ; c8008006 413c7606
	v_dual_fmac_f32 v75, s6, v74 :: v_dual_fmac_f32 v70, s6, v69 ; c8009406 4b468a06
(invalid instruction)                                        ; d5080250
	v_cndmask_b32_e32 v1, s3, v79, vcc_lo                       ; 02029e03
	v_fma_mixlo_f16 v51, v88, v50, neg(0) op_sel_hi:[0,0,1]     ; cc214033 82026558
	v_fma_mixlo_f16 v56, v89, v55, neg(0) op_sel_hi:[0,0,1]     ; cc214038 82026f59
(invalid instruction)                                        ; d5080255
	v_cndmask_b32_e32 v1, s3, v84, vcc_lo                       ; 0202a803
	v_fma_mixlo_f16 v61, v90, v60, neg(0) op_sel_hi:[0,0,1]     ; cc21403d 8202795a
	v_fma_mixlo_f16 v66, v91, v65, neg(0) op_sel_hi:[0,0,1]     ; cc214042 8202835b
	v_fma_mixlo_f16 v71, v92, v70, neg(0) op_sel_hi:[0,0,1]     ; cc214047 82028d5c
	v_maxmin_num_f16 v51, 0xdf00, v51, neg(0xdf00)              ; d66b0033 83fe66ff 0000df00
	v_maxmin_num_f16 v56, 0xdf00, v56, neg(0xdf00)              ; d66b0038 83fe70ff 0000df00
	v_dual_fmaak_f32 v85, v85, v84, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v79, 0x3f650000 ; c842a955 55509f50 3f650000
	v_fma_mixlo_f16 v76, v93, v75, neg(0) op_sel_hi:[0,0,1]     ; cc21404c 8202975d
	v_maxmin_num_f16 v61, 0xdf00, v61, neg(0xdf00)              ; d66b003d 83fe7aff 0000df00
	v_maxmin_num_f16 v66, 0xdf00, v66, neg(0xdf00)              ; d66b0042 83fe84ff 0000df00
	v_maxmin_num_f16 v71, 0xdf00, v71, neg(0xdf00)              ; d66b0047 83fe8eff 0000df00
	v_cvt_f32_f16_e32 v52, v51                                  ; 7e681733
	v_cvt_f32_f16_e32 v57, v56                                  ; 7e721738
	v_dual_fmac_f32 v85, s6, v84 :: v_dual_fmac_f32 v80, s6, v79 ; c800a806 55509e06
	v_maxmin_num_f16 v76, 0xdf00, v76, neg(0xdf00)              ; d66b004c 83fe98ff 0000df00
	v_cvt_f32_f16_e32 v62, v61                                  ; 7e7c173d
	v_cvt_f32_f16_e32 v67, v66                                  ; 7e861742
	v_cvt_f32_f16_e32 v72, v71                                  ; 7e901747
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v0, v52, v128, vcc_lo                     ; 02010134
	v_add_lshl_u32 v48, s17, v48, 8                             ; d6470030 02226011
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                     ; 02010139
	v_fma_mixlo_f16 v81, v94, v80, neg(0) op_sel_hi:[0,0,1]     ; cc214051 8202a15e
	v_fma_mixlo_f16 v86, v95, v85, neg(0) op_sel_hi:[0,0,1]     ; cc214056 8202ab5f
	v_cvt_f32_f16_e32 v77, v76                                  ; 7e9a174c
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v0, v62, v128, vcc_lo                     ; 0201013e
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v0, v67, v128, vcc_lo                     ; 02010143
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v0, v72, v128, vcc_lo                     ; 02010148
	v_add3_u32 v48, v6, s2, v48                                 ; d6550030 04c00506
	v_maxmin_num_f16 v81, 0xdf00, v81, neg(0xdf00)              ; d66b0051 83fea2ff 0000df00
	v_maxmin_num_f16 v86, 0xdf00, v86, neg(0xdf00)              ; d66b0056 83feacff 0000df00
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v0, v77, v128, vcc_lo                     ; 0201014d
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_cvt_f32_f16_e32 v82, v81                                  ; 7ea41751
	v_cvt_f32_f16_e32 v87, v86                                  ; 7eae1756
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v0, v82, v128, vcc_lo                     ; 02010152
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v0, v87, v128, vcc_lo                     ; 02010157
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v53, v48, s[12:15], null offen              ; c406007c 40801835 00000030
	buffer_store_b8 v58, v48, s[12:15], null offen offset:16    ; c406007c 4080183a 00001030
	buffer_store_b8 v63, v48, s[12:15], null offen offset:32    ; c406007c 4080183f 00002030
	buffer_store_b8 v68, v48, s[12:15], null offen offset:48    ; c406007c 40801844 00003030
	buffer_store_b8 v73, v48, s[12:15], null offen offset:64    ; c406007c 40801849 00004030
	buffer_store_b8 v78, v48, s[12:15], null offen offset:80    ; c406007c 4080184e 00005030
	buffer_store_b8 v83, v48, s[12:15], null offen offset:96    ; c406007c 40801853 00006030
	buffer_store_b8 v88, v48, s[12:15], null offen offset:112   ; c406007c 40801858 00007030
	v_maxmin_num_f32 v90, -4.0, v96, 4.0                        ; d669005a 03dac0f7
	v_maxmin_num_f32 v95, -4.0, v97, 4.0                        ; d669005f 03dac2f7
	v_maxmin_num_f32 v146, -4.0, v98, 4.0                       ; d6690092 03dac4f7
	v_maxmin_num_f32 v151, -4.0, v99, 4.0                       ; d6690097 03dac6f7
	v_lshrrev_b32_e32 v89, 4, v5                                ; 32b20a84
	v_maxmin_num_f32 v156, -4.0, v100, 4.0                      ; d669009c 03dac8f7
(invalid instruction)                                        ; d508025b
	v_cndmask_b32_e32 v1, s3, v90, vcc_lo                       ; 0202b403
	v_maxmin_num_f32 v161, -4.0, v101, 4.0                      ; d66900a1 03dacaf7
(invalid instruction)                                        ; d5080293
	v_cndmask_b32_e32 v1, s3, v146, vcc_lo                      ; 02032403
(invalid instruction)                                        ; d5080298
	v_cndmask_b32_e32 v1, s3, v151, vcc_lo                      ; 02032e03
(invalid instruction)                                        ; d508029d
	v_cndmask_b32_e32 v1, s3, v156, vcc_lo                      ; 02033803
	v_fmaak_f32 v91, v91, v90, 0x3f650000                       ; 5ab6b55b 3f650000
(invalid instruction)                                        ; d50802a2
	v_cndmask_b32_e32 v1, s3, v161, vcc_lo                      ; 02034203
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 ; c8432f98 98932593 3f650000
	v_fmac_f32_e32 v91, s6, v90                                 ; 56b6b406
	v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c84343a2 a29d399d 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_fmac_f32 v152, s6, v151 :: v_dual_fmac_f32 v147, s6, v146 ; c8012e06 98932406
	v_fma_mixlo_f16 v92, v96, v91, neg(0) op_sel_hi:[0,0,1]     ; cc21405c 8202b760
(invalid instruction)                                        ; d5080260
	v_cndmask_b32_e32 v1, s3, v95, vcc_lo                       ; 0202be03
	v_maxmin_num_f32 v166, -4.0, v102, 4.0                      ; d66900a6 03daccf7
	v_dual_fmac_f32 v162, s6, v161 :: v_dual_fmac_f32 v157, s6, v156 ; c8014206 a29d3806
	v_maxmin_num_f32 v171, -4.0, v103, 4.0                      ; d66900ab 03dacef7
	v_fma_mixlo_f16 v148, v98, v147, neg(0) op_sel_hi:[0,0,1]   ; cc214094 82032762
	v_maxmin_num_f16 v92, 0xdf00, v92, neg(0xdf00)              ; d66b005c 83feb8ff 0000df00
	v_fma_mixlo_f16 v153, v99, v152, neg(0) op_sel_hi:[0,0,1]   ; cc214099 82033163
	v_fmaak_f32 v96, v96, v95, 0x3f650000                       ; 5ac0bf60 3f650000
(invalid instruction)                                        ; d50802a7
	v_cndmask_b32_e32 v1, s3, v166, vcc_lo                      ; 02034c03
(invalid instruction)                                        ; d50802ac
	v_cndmask_b32_e32 v1, s3, v171, vcc_lo                      ; 02035603
	v_maxmin_num_f16 v148, 0xdf00, v148, neg(0xdf00)            ; d66b0094 83ff28ff 0000df00
	v_fma_mixlo_f16 v158, v100, v157, neg(0) op_sel_hi:[0,0,1]  ; cc21409e 82033b64
	v_cvt_f32_f16_e32 v93, v92                                  ; 7eba175c
	v_maxmin_num_f16 v153, 0xdf00, v153, neg(0xdf00)            ; d66b0099 83ff32ff 0000df00
	v_fmac_f32_e32 v96, s6, v95                                 ; 56c0be06
	v_fma_mixlo_f16 v163, v101, v162, neg(0) op_sel_hi:[0,0,1]  ; cc2140a3 82034565
	v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 :: v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 ; c84357ac aca74da7 3f650000
(invalid instruction)                                        ; d58b0095
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                    ; 02010194
	v_maxmin_num_f16 v158, 0xdf00, v158, neg(0xdf00)            ; d66b009e 83ff3cff 0000df00
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v0, v93, v128, vcc_lo                     ; 0201015d
(invalid instruction)                                        ; d58b009a
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                    ; 02010199
	v_fma_mixlo_f16 v97, v97, v96, neg(0) op_sel_hi:[0,0,1]     ; cc214061 8202c161
	v_maxmin_num_f16 v163, 0xdf00, v163, neg(0xdf00)            ; d66b00a3 83ff46ff 0000df00
	v_dual_fmac_f32 v172, s6, v171 :: v_dual_fmac_f32 v167, s6, v166 ; c8015606 aca74c06
(invalid instruction)                                        ; d7690096
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                    ; 02010195
(invalid instruction)                                        ; d58b009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
(invalid instruction)                                        ; d769009b
	v_cndmask_b32_e32 v0, v154, v128, vcc_lo                    ; 0201019a
	v_add_lshl_u32 v89, s17, v89, 8                             ; d6470059 0222b211
	v_maxmin_num_f16 v97, 0xdf00, v97, neg(0xdf00)              ; d66b0061 83fec2ff 0000df00
(invalid instruction)                                        ; d58b00a4
	v_cndmask_b32_e32 v0, v163, v128, vcc_lo                    ; 020101a3
	v_fma_mixlo_f16 v173, v103, v172, neg(0) op_sel_hi:[0,0,1]  ; cc2140ad 82035967
	v_fma_mixlo_f16 v168, v102, v167, neg(0) op_sel_hi:[0,0,1]  ; cc2140a8 82034f66
(invalid instruction)                                        ; d76900a0
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                    ; 0201019f
	v_add3_u32 v89, v6, s2, v89                                 ; d6550059 05640506
	v_cvt_f32_f16_e32 v144, v97                                 ; 7f201761
(invalid instruction)                                        ; d76900a5
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
	v_maxmin_num_f16 v173, 0xdf00, v173, neg(0xdf00)            ; d66b00ad 83ff5aff 0000df00
	v_maxmin_num_f16 v168, 0xdf00, v168, neg(0xdf00)            ; d66b00a8 83ff50ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; d7690091
	v_cndmask_b32_e32 v0, v144, v128, vcc_lo                    ; 02010190
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v173, v128, vcc_lo                    ; 020101ad
(invalid instruction)                                        ; d58b00a9
	v_cndmask_b32_e32 v0, v168, v128, vcc_lo                    ; 020101a8
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900af
	v_cndmask_b32_e32 v0, v174, v128, vcc_lo                    ; 020101ae
(invalid instruction)                                        ; d76900aa
	v_cndmask_b32_e32 v0, v169, v128, vcc_lo                    ; 020101a9
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v94, v89, s[12:15], null offen              ; c406007c 4080185e 00000059
	buffer_store_b8 v145, v89, s[12:15], null offen offset:16   ; c406007c 40801891 00001059
	buffer_store_b8 v150, v89, s[12:15], null offen offset:32   ; c406007c 40801896 00002059
	buffer_store_b8 v155, v89, s[12:15], null offen offset:48   ; c406007c 4080189b 00003059
	buffer_store_b8 v160, v89, s[12:15], null offen offset:64   ; c406007c 408018a0 00004059
	buffer_store_b8 v165, v89, s[12:15], null offen offset:80   ; c406007c 408018a5 00005059
	buffer_store_b8 v170, v89, s[12:15], null offen offset:96   ; c406007c 408018aa 00006059
	buffer_store_b8 v175, v89, s[12:15], null offen offset:112  ; c406007c 408018af 00007059
	v_maxmin_num_f32 v177, -4.0, v104, 4.0                      ; d66900b1 03dad0f7
	v_maxmin_num_f32 v187, -4.0, v106, 4.0                      ; d66900bb 03dad4f7
	v_maxmin_num_f32 v182, -4.0, v105, 4.0                      ; d66900b6 03dad2f7
	v_maxmin_num_f32 v4, -4.0, v107, 4.0                        ; d6690004 03dad6f7
	v_lshrrev_b32_e32 v176, 4, v3                               ; 33600684
	v_maxmin_num_f32 v12, -4.0, v108, 4.0                       ; d669000c 03dad8f7
	v_maxmin_num_f32 v17, -4.0, v109, 4.0                       ; d6690011 03dadaf7
(invalid instruction)                                        ; d50802b2
	v_cndmask_b32_e32 v1, s3, v177, vcc_lo                      ; 02036203
(invalid instruction)                                        ; d50802bc
	v_cndmask_b32_e32 v1, s3, v187, vcc_lo                      ; 02037603
(invalid instruction)                                        ; d50802b7
	v_cndmask_b32_e32 v1, s3, v182, vcc_lo                      ; 02036c03
(invalid instruction)                                        ; d5080208
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                        ; 02020803
(invalid instruction)                                        ; d508020d
	v_cndmask_b32_e32 v1, s3, v12, vcc_lo                       ; 02021803
(invalid instruction)                                        ; d5080212
	v_cndmask_b32_e32 v1, s3, v17, vcc_lo                       ; 02022203
	v_fmaak_f32 v178, v178, v177, 0x3f650000                    ; 5b6563b2 3f650000
	v_fmaak_f32 v188, v188, v187, 0x3f650000                    ; 5b7977bc 3f650000
	v_dual_fmaak_f32 v8, v8, v4, 0x3f650000 :: v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 ; c8420908 08b76db7 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v18, v18, v17, 0x3f650000 :: v_dual_fmaak_f32 v13, v13, v12, 0x3f650000 ; c8422312 120c190d 3f650000
	v_fmac_f32_e32 v178, s6, v177                               ; 57656206
	v_maxmin_num_f32 v22, -4.0, v110, 4.0                       ; d6690016 03dadcf7
	v_fmac_f32_e32 v188, s6, v187                               ; 57797606
	v_dual_fmac_f32 v8, s6, v4 :: v_dual_fmac_f32 v183, s6, v182 ; c8000806 08b76c06
	v_maxmin_num_f32 v27, -4.0, v111, 4.0                       ; d669001b 03dadef7
	v_dual_fmac_f32 v18, s6, v17 :: v_dual_fmac_f32 v13, s6, v12 ; c8002206 120c1806
	v_fma_mixlo_f16 v179, v104, v178, neg(0) op_sel_hi:[0,0,1]  ; cc2140b3 82036568
(invalid instruction)                                        ; d5080217
	v_cndmask_b32_e32 v1, s3, v22, vcc_lo                       ; 02022c03
	v_fma_mixlo_f16 v189, v106, v188, neg(0) op_sel_hi:[0,0,1]  ; cc2140bd 8203796a
	v_fma_mixlo_f16 v9, v107, v8, neg(0) op_sel_hi:[0,0,1]      ; cc214009 8202116b
	v_fma_mixlo_f16 v184, v105, v183, neg(0) op_sel_hi:[0,0,1]  ; cc2140b8 82036f69
(invalid instruction)                                        ; d508021c
	v_cndmask_b32_e32 v1, s3, v27, vcc_lo                       ; 02023603
	v_fma_mixlo_f16 v14, v108, v13, neg(0) op_sel_hi:[0,0,1]    ; cc21400e 82021b6c
	v_maxmin_num_f16 v179, 0xdf00, v179, neg(0xdf00)            ; d66b00b3 83ff66ff 0000df00
	v_maxmin_num_f16 v189, 0xdf00, v189, neg(0xdf00)            ; d66b00bd 83ff7aff 0000df00
	v_maxmin_num_f16 v9, 0xdf00, v9, neg(0xdf00)                ; d66b0009 83fe12ff 0000df00
	v_fma_mixlo_f16 v19, v109, v18, neg(0) op_sel_hi:[0,0,1]    ; cc214013 8202256d
	v_maxmin_num_f16 v184, 0xdf00, v184, neg(0xdf00)            ; d66b00b8 83ff70ff 0000df00
	v_dual_fmaak_f32 v28, v28, v27, 0x3f650000 :: v_dual_fmaak_f32 v23, v23, v22, 0x3f650000 ; c842371c 1c162d17 3f650000
	v_maxmin_num_f16 v14, 0xdf00, v14, neg(0xdf00)              ; d66b000e 83fe1cff 0000df00
(invalid instruction)                                        ; d58b00b4
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                    ; 020101b3
(invalid instruction)                                        ; d58b00be
	v_cndmask_b32_e32 v0, v189, v128, vcc_lo                    ; 020101bd
	v_cvt_f32_f16_e32 v10, v9                                   ; 7e141709
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
(invalid instruction)                                        ; d58b00b9
	v_cndmask_b32_e32 v0, v184, v128, vcc_lo                    ; 020101b8
	v_dual_fmac_f32 v28, s6, v27 :: v_dual_fmac_f32 v23, s6, v22 ; c8003606 1c162c06
	v_cvt_f32_f16_e32 v15, v14                                  ; 7e1e170e
(invalid instruction)                                        ; d76900b5
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                    ; 020101b4
(invalid instruction)                                        ; d76900bf
	v_cndmask_b32_e32 v0, v190, v128, vcc_lo                    ; 020101be
	v_add_lshl_u32 v176, s17, v176, 8                           ; d64700b0 02236011
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v10, v128, vcc_lo                     ; 0201010a
	v_cvt_f32_f16_e32 v20, v19                                  ; 7e281713
(invalid instruction)                                        ; d76900ba
	v_cndmask_b32_e32 v0, v185, v128, vcc_lo                    ; 020101b9
	v_fma_mixlo_f16 v29, v111, v28, neg(0) op_sel_hi:[0,0,1]    ; cc21401d 8202396f
	v_fma_mixlo_f16 v24, v110, v23, neg(0) op_sel_hi:[0,0,1]    ; cc214018 82022f6e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v0, v15, v128, vcc_lo                     ; 0201010f
	v_add3_u32 v6, v6, s2, v176                                 ; d6550006 06c00506
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v0, v20, v128, vcc_lo                     ; 02010114
	v_maxmin_num_f16 v29, 0xdf00, v29, neg(0xdf00)              ; d66b001d 83fe3aff 0000df00
	v_maxmin_num_f16 v24, 0xdf00, v24, neg(0xdf00)              ; d66b0018 83fe30ff 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v30, v29                                  ; 7e3c171d
	v_cvt_f32_f16_e32 v25, v24                                  ; 7e321718
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v0, v30, v128, vcc_lo                     ; 0201011e
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v0, v25, v128, vcc_lo                     ; 02010119
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v181, v6, s[12:15], null offen              ; c406007c 408018b5 00000006
	buffer_store_b8 v186, v6, s[12:15], null offen offset:16    ; c406007c 408018ba 00001006
	buffer_store_b8 v191, v6, s[12:15], null offen offset:32    ; c406007c 408018bf 00002006
	buffer_store_b8 v11, v6, s[12:15], null offen offset:48     ; c406007c 4080180b 00003006
	buffer_store_b8 v16, v6, s[12:15], null offen offset:64     ; c406007c 40801810 00004006
	buffer_store_b8 v21, v6, s[12:15], null offen offset:80     ; c406007c 40801815 00005006
	buffer_store_b8 v26, v6, s[12:15], null offen offset:96     ; c406007c 4080181a 00006006
	buffer_store_b8 v31, v6, s[12:15], null offen offset:112    ; c406007c 4080181f 00007006
BB66:
	s_cmp_lt_u32 s19, s4                                        ; bf0a0413
	s_cbranch_scc0 BB69                                         ; bfa1026b
BB67:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[12:15], s[6:7], 0x10                          ; f4004303 f8000010
	v_and_b32_e32 v0, 16, v0                                    ; 36000090
	s_mov_b32 s1, 0xbd650000                                    ; be8100ff bd650000
	v_maxmin_num_f32 v4, -4.0, v112, 4.0                        ; d6690004 03dae0f7
	v_maxmin_num_f32 v10, -4.0, v113, 4.0                       ; d669000a 03dae2f7
	s_mov_b32 s3, 0x3ee50000                                    ; be8300ff 3ee50000
	s_lshr_b32 s5, s5, 4                                        ; 85058405
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	v_maxmin_num_f32 v15, -4.0, v114, 4.0                       ; d669000f 03dae4f7
	v_maxmin_num_f32 v20, -4.0, v115, 4.0                       ; d6690014 03dae6f7
	v_lshl_or_b32 v0, v0, 3, v7                                 ; d6560000 041d0700
	v_maxmin_num_f32 v25, -4.0, v116, 4.0                       ; d6690019 03dae8f7
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d5080206
	v_cndmask_b32_e32 v1, s1, v4, vcc_lo                        ; 02020801
	s_mul_i32 s20, s20, s5                                      ; 96140514
(invalid instruction)                                        ; d508020b
	v_cndmask_b32_e32 v1, s1, v10, vcc_lo                       ; 02021401
	v_maxmin_num_f32 v30, -4.0, v117, 4.0                       ; d669001e 03daeaf7
(invalid instruction)                                        ; d5080210
	v_cndmask_b32_e32 v1, s1, v15, vcc_lo                       ; 02021e01
(invalid instruction)                                        ; d5080215
	v_cndmask_b32_e32 v1, s1, v20, vcc_lo                       ; 02022801
(invalid instruction)                                        ; d508021a
	v_cndmask_b32_e32 v1, s1, v25, vcc_lo                       ; 02023201
	v_dual_fmaak_f32 v6, v6, v4, 0x3f650000 :: v_dual_fmaak_f32 v11, v11, v10, 0x3f650000 ; c8420906 060a150b 3f650000
(invalid instruction)                                        ; d508021f
	v_cndmask_b32_e32 v1, s1, v30, vcc_lo                       ; 02023c01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v21, v21, v20, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v15, 0x3f650000 ; c8422915 15101f10 3f650000
	v_dual_fmac_f32 v6, s3, v4 :: v_dual_fmac_f32 v11, s3, v10  ; c8000803 060a1403
	v_dual_fmaak_f32 v31, v31, v30, 0x3f650000 :: v_dual_fmaak_f32 v26, v26, v25, 0x3f650000 ; c8423d1f 1f1a331a 3f650000
	v_maxmin_num_f32 v35, -4.0, v118, 4.0                       ; d6690023 03daecf7
	v_dual_fmac_f32 v21, s3, v20 :: v_dual_fmac_f32 v16, s3, v15 ; c8002803 15101e03
	v_maxmin_num_f32 v40, -4.0, v119, 4.0                       ; d6690028 03daeef7
	v_fma_mixlo_f16 v7, v112, v6, neg(0) op_sel_hi:[0,0,1]      ; cc214007 82020d70
	v_fma_mixlo_f16 v12, v113, v11, neg(0) op_sel_hi:[0,0,1]    ; cc21400c 82021771
	v_dual_fmac_f32 v31, s3, v30 :: v_dual_fmac_f32 v26, s3, v25 ; c8003c03 1f1a3203
(invalid instruction)                                        ; d5080224
	v_cndmask_b32_e32 v1, s1, v35, vcc_lo                       ; 02024601
	v_fma_mixlo_f16 v17, v114, v16, neg(0) op_sel_hi:[0,0,1]    ; cc214011 82022172
	v_fma_mixlo_f16 v22, v115, v21, neg(0) op_sel_hi:[0,0,1]    ; cc214016 82022b73
(invalid instruction)                                        ; d5080229
	v_cndmask_b32_e32 v1, s1, v40, vcc_lo                       ; 02025001
	v_maxmin_num_f16 v7, 0xdf00, v7, neg(0xdf00)                ; d66b0007 83fe0eff 0000df00
	v_maxmin_num_f16 v12, 0xdf00, v12, neg(0xdf00)              ; d66b000c 83fe18ff 0000df00
	v_fma_mixlo_f16 v27, v116, v26, neg(0) op_sel_hi:[0,0,1]    ; cc21401b 82023574
	v_fma_mixlo_f16 v32, v117, v31, neg(0) op_sel_hi:[0,0,1]    ; cc214020 82023f75
	v_maxmin_num_f16 v17, 0xdf00, v17, neg(0xdf00)              ; d66b0011 83fe22ff 0000df00
	v_maxmin_num_f16 v22, 0xdf00, v22, neg(0xdf00)              ; d66b0016 83fe2cff 0000df00
	v_dual_fmaak_f32 v41, v41, v40, 0x3f650000 :: v_dual_fmaak_f32 v36, v36, v35, 0x3f650000 ; c8425129 29244724 3f650000
	v_cvt_f32_f16_e32 v8, v7                                    ; 7e101707
	v_cvt_f32_f16_e32 v13, v12                                  ; 7e1a170c
	v_maxmin_num_f16 v27, 0xdf00, v27, neg(0xdf00)              ; d66b001b 83fe36ff 0000df00
	v_maxmin_num_f16 v32, 0xdf00, v32, neg(0xdf00)              ; d66b0020 83fe40ff 0000df00
	v_cvt_f32_f16_e32 v18, v17                                  ; 7e241711
	v_cvt_f32_f16_e32 v23, v22                                  ; 7e2e1716
	v_dual_fmac_f32 v41, s3, v40 :: v_dual_fmac_f32 v36, s3, v35 ; c8005003 29244603
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v0, v8, v128, vcc_lo                      ; 02010108
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                     ; 0201010d
	v_cvt_f32_f16_e32 v28, v27                                  ; 7e38171b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v1, s20, v1, 8                               ; d6470001 02220214
	v_cvt_f32_f16_e32 v33, v32                                  ; 7e421720
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                     ; 02010112
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v0, v23, v128, vcc_lo                     ; 02010117
	v_fma_mixlo_f16 v42, v119, v41, neg(0) op_sel_hi:[0,0,1]    ; cc21402a 82025377
	v_fma_mixlo_f16 v37, v118, v36, neg(0) op_sel_hi:[0,0,1]    ; cc214025 82024976
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v0, v28, v128, vcc_lo                     ; 0201011c
	v_add3_u32 v1, v0, s2, v1                                   ; d6550001 04040500
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v0, v33, v128, vcc_lo                     ; 02010121
	v_maxmin_num_f16 v42, 0xdf00, v42, neg(0xdf00)              ; d66b002a 83fe54ff 0000df00
	v_maxmin_num_f16 v37, 0xdf00, v37, neg(0xdf00)              ; d66b0025 83fe4aff 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v43, v42                                  ; 7e56172a
	v_cvt_f32_f16_e32 v38, v37                                  ; 7e4c1725
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v0, v43, v128, vcc_lo                     ; 0201012b
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v0, v38, v128, vcc_lo                     ; 02010126
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v9, v1, s[12:15], null offen                ; c406007c 40801809 00000001
	buffer_store_b8 v14, v1, s[12:15], null offen offset:16     ; c406007c 4080180e 00001001
	buffer_store_b8 v19, v1, s[12:15], null offen offset:32     ; c406007c 40801813 00002001
	buffer_store_b8 v24, v1, s[12:15], null offen offset:48     ; c406007c 40801818 00003001
	buffer_store_b8 v29, v1, s[12:15], null offen offset:64     ; c406007c 4080181d 00004001
	buffer_store_b8 v34, v1, s[12:15], null offen offset:80     ; c406007c 40801822 00005001
	buffer_store_b8 v39, v1, s[12:15], null offen offset:96     ; c406007c 40801827 00006001
	buffer_store_b8 v44, v1, s[12:15], null offen offset:112    ; c406007c 4080182c 00007001
	v_maxmin_num_f32 v45, -4.0, v120, 4.0                       ; d669002d 03daf0f7
	v_maxmin_num_f32 v50, -4.0, v121, 4.0                       ; d6690032 03daf2f7
	v_maxmin_num_f32 v55, -4.0, v122, 4.0                       ; d6690037 03daf4f7
	v_maxmin_num_f32 v60, -4.0, v123, 4.0                       ; d669003c 03daf6f7
	v_lshrrev_b32_e32 v2, 4, v2                                 ; 32040484
	v_maxmin_num_f32 v65, -4.0, v124, 4.0                       ; d6690041 03daf8f7
	v_maxmin_num_f32 v70, -4.0, v125, 4.0                       ; d6690046 03dafaf7
(invalid instruction)                                        ; d508022e
	v_cndmask_b32_e32 v1, s1, v45, vcc_lo                       ; 02025a01
(invalid instruction)                                        ; d5080233
	v_cndmask_b32_e32 v1, s1, v50, vcc_lo                       ; 02026401
(invalid instruction)                                        ; d5080238
	v_cndmask_b32_e32 v1, s1, v55, vcc_lo                       ; 02026e01
(invalid instruction)                                        ; d508023d
	v_cndmask_b32_e32 v1, s1, v60, vcc_lo                       ; 02027801
(invalid instruction)                                        ; d5080242
	v_cndmask_b32_e32 v1, s1, v65, vcc_lo                       ; 02028201
(invalid instruction)                                        ; d5080247
	v_cndmask_b32_e32 v1, s1, v70, vcc_lo                       ; 02028c01
	v_dual_fmaak_f32 v51, v51, v50, 0x3f650000 :: v_dual_fmaak_f32 v46, v46, v45, 0x3f650000 ; c8426533 332e5b2e 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v61, v61, v60, 0x3f650000 :: v_dual_fmaak_f32 v56, v56, v55, 0x3f650000 ; c842793d 3d386f38 3f650000
	v_dual_fmaak_f32 v71, v71, v70, 0x3f650000 :: v_dual_fmaak_f32 v66, v66, v65, 0x3f650000 ; c8428d47 47428342 3f650000
	v_maxmin_num_f32 v75, -4.0, v126, 4.0                       ; d669004b 03dafcf7
	v_dual_fmac_f32 v51, s3, v50 :: v_dual_fmac_f32 v46, s3, v45 ; c8006403 332e5a03
	v_maxmin_num_f32 v80, -4.0, v127, 4.0                       ; d6690050 03dafef7
	v_dual_fmac_f32 v61, s3, v60 :: v_dual_fmac_f32 v56, s3, v55 ; c8007803 3d386e03
	v_dual_fmac_f32 v71, s3, v70 :: v_dual_fmac_f32 v66, s3, v65 ; c8008c03 47428203
(invalid instruction)                                        ; d508024c
	v_cndmask_b32_e32 v1, s1, v75, vcc_lo                       ; 02029601
	v_fma_mixlo_f16 v47, v120, v46, neg(0) op_sel_hi:[0,0,1]    ; cc21402f 82025d78
	v_fma_mixlo_f16 v52, v121, v51, neg(0) op_sel_hi:[0,0,1]    ; cc214034 82026779
(invalid instruction)                                        ; d5080251
	v_cndmask_b32_e32 v1, s1, v80, vcc_lo                       ; 0202a001
	v_fma_mixlo_f16 v57, v122, v56, neg(0) op_sel_hi:[0,0,1]    ; cc214039 8202717a
	v_fma_mixlo_f16 v62, v123, v61, neg(0) op_sel_hi:[0,0,1]    ; cc21403e 82027b7b
	v_fma_mixlo_f16 v67, v124, v66, neg(0) op_sel_hi:[0,0,1]    ; cc214043 8202857c
	v_maxmin_num_f16 v47, 0xdf00, v47, neg(0xdf00)              ; d66b002f 83fe5eff 0000df00
	v_maxmin_num_f16 v52, 0xdf00, v52, neg(0xdf00)              ; d66b0034 83fe68ff 0000df00
	v_dual_fmaak_f32 v81, v81, v80, 0x3f650000 :: v_dual_fmaak_f32 v76, v76, v75, 0x3f650000 ; c842a151 514c974c 3f650000
	v_fma_mixlo_f16 v72, v125, v71, neg(0) op_sel_hi:[0,0,1]    ; cc214048 82028f7d
	v_maxmin_num_f16 v57, 0xdf00, v57, neg(0xdf00)              ; d66b0039 83fe72ff 0000df00
	v_maxmin_num_f16 v62, 0xdf00, v62, neg(0xdf00)              ; d66b003e 83fe7cff 0000df00
	v_maxmin_num_f16 v67, 0xdf00, v67, neg(0xdf00)              ; d66b0043 83fe86ff 0000df00
	v_cvt_f32_f16_e32 v48, v47                                  ; 7e60172f
	v_cvt_f32_f16_e32 v53, v52                                  ; 7e6a1734
	v_dual_fmac_f32 v81, s3, v80 :: v_dual_fmac_f32 v76, s3, v75 ; c800a003 514c9603
	v_maxmin_num_f16 v72, 0xdf00, v72, neg(0xdf00)              ; d66b0048 83fe90ff 0000df00
	v_cvt_f32_f16_e32 v58, v57                                  ; 7e741739
	v_cvt_f32_f16_e32 v63, v62                                  ; 7e7e173e
	v_cvt_f32_f16_e32 v68, v67                                  ; 7e881743
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
	v_add_lshl_u32 v2, s20, v2, 8                               ; d6470002 02220414
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v0, v53, v128, vcc_lo                     ; 02010135
	v_fma_mixlo_f16 v77, v126, v76, neg(0) op_sel_hi:[0,0,1]    ; cc21404d 8202997e
	v_fma_mixlo_f16 v82, v127, v81, neg(0) op_sel_hi:[0,0,1]    ; cc214052 8202a37f
	v_cvt_f32_f16_e32 v73, v72                                  ; 7e921748
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v0, v58, v128, vcc_lo                     ; 0201013a
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v0, v63, v128, vcc_lo                     ; 0201013f
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v0, v68, v128, vcc_lo                     ; 02010144
	v_add3_u32 v2, v0, s2, v2                                   ; d6550002 04080500
	v_maxmin_num_f16 v77, 0xdf00, v77, neg(0xdf00)              ; d66b004d 83fe9aff 0000df00
	v_maxmin_num_f16 v82, 0xdf00, v82, neg(0xdf00)              ; d66b0052 83fea4ff 0000df00
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v0, v73, v128, vcc_lo                     ; 02010149
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_cvt_f32_f16_e32 v78, v77                                  ; 7e9c174d
	v_cvt_f32_f16_e32 v83, v82                                  ; 7ea61752
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v0, v78, v128, vcc_lo                     ; 0201014e
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v0, v83, v128, vcc_lo                     ; 02010153
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v49, v2, s[12:15], null offen               ; c406007c 40801831 00000002
	buffer_store_b8 v54, v2, s[12:15], null offen offset:16     ; c406007c 40801836 00001002
	buffer_store_b8 v59, v2, s[12:15], null offen offset:32     ; c406007c 4080183b 00002002
	buffer_store_b8 v64, v2, s[12:15], null offen offset:48     ; c406007c 40801840 00003002
	buffer_store_b8 v69, v2, s[12:15], null offen offset:64     ; c406007c 40801845 00004002
	buffer_store_b8 v74, v2, s[12:15], null offen offset:80     ; c406007c 4080184a 00005002
	buffer_store_b8 v79, v2, s[12:15], null offen offset:96     ; c406007c 4080184f 00006002
	buffer_store_b8 v84, v2, s[12:15], null offen offset:112    ; c406007c 40801854 00007002
	v_maxmin_num_f32 v85, -4.0, v128, 4.0                       ; d6690055 03db00f7
	v_maxmin_num_f32 v90, -4.0, v129, 4.0                       ; d669005a 03db02f7
	v_maxmin_num_f32 v95, -4.0, v130, 4.0                       ; d669005f 03db04f7
	v_maxmin_num_f32 v100, -4.0, v131, 4.0                      ; d6690064 03db06f7
	v_lshrrev_b32_e32 v5, 4, v5                                 ; 320a0a84
	v_maxmin_num_f32 v105, -4.0, v132, 4.0                      ; d6690069 03db08f7
	v_maxmin_num_f32 v110, -4.0, v133, 4.0                      ; d669006e 03db0af7
(invalid instruction)                                        ; d5080256
	v_cndmask_b32_e32 v1, s1, v85, vcc_lo                       ; 0202aa01
(invalid instruction)                                        ; d508025b
	v_cndmask_b32_e32 v1, s1, v90, vcc_lo                       ; 0202b401
(invalid instruction)                                        ; d5080260
	v_cndmask_b32_e32 v1, s1, v95, vcc_lo                       ; 0202be01
(invalid instruction)                                        ; d5080265
	v_cndmask_b32_e32 v1, s1, v100, vcc_lo                      ; 0202c801
(invalid instruction)                                        ; d508026a
	v_cndmask_b32_e32 v1, s1, v105, vcc_lo                      ; 0202d201
(invalid instruction)                                        ; d508026f
	v_cndmask_b32_e32 v1, s1, v110, vcc_lo                      ; 0202dc01
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842b55b 5b56ab56 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v101, v101, v100, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842c965 6560bf60 3f650000
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 ; c842dd6f 6f6ad36a 3f650000
	v_maxmin_num_f32 v115, -4.0, v134, 4.0                      ; d6690073 03db0cf7
	v_dual_fmac_f32 v91, s3, v90 :: v_dual_fmac_f32 v86, s3, v85 ; c800b403 5b56aa03
	v_maxmin_num_f32 v120, -4.0, v135, 4.0                      ; d6690078 03db0ef7
	v_dual_fmac_f32 v101, s3, v100 :: v_dual_fmac_f32 v96, s3, v95 ; c800c803 6560be03
	v_dual_fmac_f32 v111, s3, v110 :: v_dual_fmac_f32 v106, s3, v105 ; c800dc03 6f6ad203
(invalid instruction)                                        ; d5080274
	v_cndmask_b32_e32 v1, s1, v115, vcc_lo                      ; 0202e601
	v_fma_mixlo_f16 v92, v129, v91, neg(0) op_sel_hi:[0,0,1]    ; cc21405c 8202b781
	v_fma_mixlo_f16 v87, v128, v86, neg(0) op_sel_hi:[0,0,1]    ; cc214057 8202ad80
(invalid instruction)                                        ; d5080279
	v_cndmask_b32_e32 v1, s1, v120, vcc_lo                      ; 0202f001
	v_fma_mixlo_f16 v102, v131, v101, neg(0) op_sel_hi:[0,0,1]  ; cc214066 8202cb83
	v_fma_mixlo_f16 v97, v130, v96, neg(0) op_sel_hi:[0,0,1]    ; cc214061 8202c182
	v_fma_mixlo_f16 v107, v132, v106, neg(0) op_sel_hi:[0,0,1]  ; cc21406b 8202d584
	v_maxmin_num_f16 v92, 0xdf00, v92, neg(0xdf00)              ; d66b005c 83feb8ff 0000df00
	v_maxmin_num_f16 v87, 0xdf00, v87, neg(0xdf00)              ; d66b0057 83feaeff 0000df00
	v_fma_mixlo_f16 v112, v133, v111, neg(0) op_sel_hi:[0,0,1]  ; cc214070 8202df85
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 ; c842f179 7974e774 3f650000
	v_maxmin_num_f16 v102, 0xdf00, v102, neg(0xdf00)            ; d66b0066 83feccff 0000df00
	v_maxmin_num_f16 v97, 0xdf00, v97, neg(0xdf00)              ; d66b0061 83fec2ff 0000df00
	v_maxmin_num_f16 v107, 0xdf00, v107, neg(0xdf00)            ; d66b006b 83fed6ff 0000df00
	v_cvt_f32_f16_e32 v93, v92                                  ; 7eba175c
	v_cvt_f32_f16_e32 v88, v87                                  ; 7eb01757
	v_maxmin_num_f16 v112, 0xdf00, v112, neg(0xdf00)            ; d66b0070 83fee0ff 0000df00
	v_dual_fmac_f32 v121, s3, v120 :: v_dual_fmac_f32 v116, s3, v115 ; c800f003 7974e603
	v_cvt_f32_f16_e32 v103, v102                                ; 7ece1766
	v_cvt_f32_f16_e32 v98, v97                                  ; 7ec41761
	v_cvt_f32_f16_e32 v108, v107                                ; 7ed8176b
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v0, v93, v128, vcc_lo                     ; 0201015d
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v0, v88, v128, vcc_lo                     ; 02010158
	v_add_lshl_u32 v5, s20, v5, 8                               ; d6470005 02220a14
	v_cvt_f32_f16_e32 v113, v112                                ; 7ee21770
	v_fma_mixlo_f16 v122, v135, v121, neg(0) op_sel_hi:[0,0,1]  ; cc21407a 8202f387
	v_fma_mixlo_f16 v117, v134, v116, neg(0) op_sel_hi:[0,0,1]  ; cc214075 8202e986
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v0, v103, v128, vcc_lo                    ; 02010167
(invalid instruction)                                        ; d7690063
	v_cndmask_b32_e32 v0, v98, v128, vcc_lo                     ; 02010162
(invalid instruction)                                        ; d769006d
	v_cndmask_b32_e32 v0, v108, v128, vcc_lo                    ; 0201016c
	v_add3_u32 v5, v0, s2, v5                                   ; d6550005 04140500
(invalid instruction)                                        ; d7690072
	v_cndmask_b32_e32 v0, v113, v128, vcc_lo                    ; 02010171
	v_maxmin_num_f16 v122, 0xdf00, v122, neg(0xdf00)            ; d66b007a 83fef4ff 0000df00
	v_maxmin_num_f16 v117, 0xdf00, v117, neg(0xdf00)            ; d66b0075 83feeaff 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v123, v122                                ; 7ef6177a
	v_cvt_f32_f16_e32 v118, v117                                ; 7eec1775
(invalid instruction)                                        ; d769007c
	v_cndmask_b32_e32 v0, v123, v128, vcc_lo                    ; 0201017b
(invalid instruction)                                        ; d7690077
	v_cndmask_b32_e32 v0, v118, v128, vcc_lo                    ; 02010176
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v89, v5, s[12:15], null offen               ; c406007c 40801859 00000005
	buffer_store_b8 v94, v5, s[12:15], null offen offset:16     ; c406007c 4080185e 00001005
	buffer_store_b8 v99, v5, s[12:15], null offen offset:32     ; c406007c 40801863 00002005
	buffer_store_b8 v104, v5, s[12:15], null offen offset:48    ; c406007c 40801868 00003005
	buffer_store_b8 v109, v5, s[12:15], null offen offset:64    ; c406007c 4080186d 00004005
	buffer_store_b8 v114, v5, s[12:15], null offen offset:80    ; c406007c 40801872 00005005
	buffer_store_b8 v119, v5, s[12:15], null offen offset:96    ; c406007c 40801877 00006005
	buffer_store_b8 v124, v5, s[12:15], null offen offset:112   ; c406007c 4080187c 00007005
	v_maxmin_num_f32 v125, -4.0, v136, 4.0                      ; d669007d 03db10f7
	v_maxmin_num_f32 v135, -4.0, v138, 4.0                      ; d6690087 03db14f7
	v_maxmin_num_f32 v130, -4.0, v137, 4.0                      ; d6690082 03db12f7
	v_maxmin_num_f32 v145, -4.0, v139, 4.0                      ; d6690091 03db16f7
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_maxmin_num_f32 v150, -4.0, v140, 4.0                      ; d6690096 03db18f7
(invalid instruction)                                        ; d508027e
	v_cndmask_b32_e32 v1, s1, v125, vcc_lo                      ; 0202fa01
	v_maxmin_num_f32 v155, -4.0, v141, 4.0                      ; d669009b 03db1af7
(invalid instruction)                                        ; d5080283
	v_cndmask_b32_e32 v1, s1, v130, vcc_lo                      ; 02030401
(invalid instruction)                                        ; d5080292
	v_cndmask_b32_e32 v1, s1, v145, vcc_lo                      ; 02032201
(invalid instruction)                                        ; d5080297
	v_cndmask_b32_e32 v1, s1, v150, vcc_lo                      ; 02032c01
	v_fmaak_f32 v126, v126, v125, 0x3f650000                    ; 5afcfb7e 3f650000
(invalid instruction)                                        ; d508029c
	v_cndmask_b32_e32 v1, s1, v155, vcc_lo                      ; 02033601
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v146, v146, v145, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 ; c8432392 92830583 3f650000
	v_fmac_f32_e32 v126, s3, v125                               ; 56fcfa03
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 ; c843379c 9c972d97 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_fmac_f32 v146, s3, v145 :: v_dual_fmac_f32 v131, s3, v130 ; c8012203 92830403
	v_fma_mixlo_f16 v127, v136, v126, neg(0) op_sel_hi:[0,0,1]  ; cc21407f 8202fd88
(invalid instruction)                                        ; d5080288
	v_cndmask_b32_e32 v1, s1, v135, vcc_lo                      ; 02030e01
	v_maxmin_num_f32 v160, -4.0, v142, 4.0                      ; d66900a0 03db1cf7
	v_dual_fmac_f32 v156, s3, v155 :: v_dual_fmac_f32 v151, s3, v150 ; c8013603 9c972c03
	v_maxmin_num_f32 v165, -4.0, v143, 4.0                      ; d66900a5 03db1ef7
	v_fma_mixlo_f16 v132, v137, v131, neg(0) op_sel_hi:[0,0,1]  ; cc214084 82030789
	v_maxmin_num_f16 v127, 0xdf00, v127, neg(0xdf00)            ; d66b007f 83fefeff 0000df00
	v_fma_mixlo_f16 v147, v139, v146, neg(0) op_sel_hi:[0,0,1]  ; cc214093 8203258b
	v_fmaak_f32 v136, v136, v135, 0x3f650000                    ; 5b110f88 3f650000
(invalid instruction)                                        ; d50802a1
	v_cndmask_b32_e32 v1, s1, v160, vcc_lo                      ; 02034001
(invalid instruction)                                        ; d50802a6
	v_cndmask_b32_e32 v1, s1, v165, vcc_lo                      ; 02034a01
	v_fma_mixlo_f16 v152, v140, v151, neg(0) op_sel_hi:[0,0,1]  ; cc214098 82032f8c
	v_maxmin_num_f16 v132, 0xdf00, v132, neg(0xdf00)            ; d66b0084 83ff08ff 0000df00
	v_cvt_f32_f16_e32 v128, v127                                ; 7f00177f
	v_maxmin_num_f16 v147, 0xdf00, v147, neg(0xdf00)            ; d66b0093 83ff26ff 0000df00
	v_fmac_f32_e32 v136, s3, v135                               ; 57110e03
	v_fma_mixlo_f16 v157, v141, v156, neg(0) op_sel_hi:[0,0,1]  ; cc21409d 8203398d
	v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 ; c8434ba6 a6a141a1 3f650000
	v_maxmin_num_f16 v152, 0xdf00, v152, neg(0xdf00)            ; d66b0098 83ff30ff 0000df00
(invalid instruction)                                        ; d58b0085
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                    ; 02010184
(invalid instruction)                                        ; d7690081
	v_cndmask_b32_e32 v0, v128, v128, vcc_lo                    ; 02010180
(invalid instruction)                                        ; d58b0094
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                    ; 02010193
	v_fma_mixlo_f16 v137, v138, v136, neg(0) op_sel_hi:[0,0,1]  ; cc214089 8203118a
	v_maxmin_num_f16 v157, 0xdf00, v157, neg(0xdf00)            ; d66b009d 83ff3aff 0000df00
	v_dual_fmac_f32 v166, s3, v165 :: v_dual_fmac_f32 v161, s3, v160 ; c8014a03 a6a14003
(invalid instruction)                                        ; d58b0099
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                    ; 02010198
(invalid instruction)                                        ; d7690086
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                    ; 02010185
	v_add_lshl_u32 v3, s20, v3, 8                               ; d6470003 02220614
(invalid instruction)                                        ; d7690095
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                    ; 02010194
	v_maxmin_num_f16 v137, 0xdf00, v137, neg(0xdf00)            ; d66b0089 83ff12ff 0000df00
(invalid instruction)                                        ; d58b009e
	v_cndmask_b32_e32 v0, v157, v128, vcc_lo                    ; 0201019d
	v_fma_mixlo_f16 v162, v142, v161, neg(0) op_sel_hi:[0,0,1]  ; cc2140a2 8203438e
	v_fma_mixlo_f16 v167, v143, v166, neg(0) op_sel_hi:[0,0,1]  ; cc2140a7 82034d8f
(invalid instruction)                                        ; d769009a
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                    ; 02010199
	v_add3_u32 v0, v0, s2, v3                                   ; d6550000 040c0500
(invalid instruction)                                        ; d58b008a
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                    ; 02010189
(invalid instruction)                                        ; d769009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
	v_maxmin_num_f16 v162, 0xdf00, v162, neg(0xdf00)            ; d66b00a2 83ff44ff 0000df00
	v_maxmin_num_f16 v167, 0xdf00, v167, neg(0xdf00)            ; d66b00a7 83ff4eff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; d7690090
	v_cndmask_b32_e32 v0, v138, v128, vcc_lo                    ; 0201018a
(invalid instruction)                                        ; d58b00a3
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
(invalid instruction)                                        ; d58b00a8
	v_cndmask_b32_e32 v0, v167, v128, vcc_lo                    ; 020101a7
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900a4
	v_cndmask_b32_e32 v0, v163, v128, vcc_lo                    ; 020101a3
(invalid instruction)                                        ; d76900a9
	v_cndmask_b32_e32 v0, v168, v128, vcc_lo                    ; 020101a8
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v129, v0, s[12:15], null offen              ; c406007c 40801881 00000000
	buffer_store_b8 v134, v0, s[12:15], null offen offset:16    ; c406007c 40801886 00001000
	buffer_store_b8 v144, v0, s[12:15], null offen offset:32    ; c406007c 40801890 00002000
	buffer_store_b8 v149, v0, s[12:15], null offen offset:48    ; c406007c 40801895 00003000
	buffer_store_b8 v154, v0, s[12:15], null offen offset:64    ; c406007c 4080189a 00004000
	buffer_store_b8 v159, v0, s[12:15], null offen offset:80    ; c406007c 4080189f 00005000
	buffer_store_b8 v164, v0, s[12:15], null offen offset:96    ; c406007c 408018a4 00006000
	buffer_store_b8 v169, v0, s[12:15], null offen offset:112   ; c406007c 408018a9 00007000
BB69:
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s16, -1                                        ; bf01c110
	s_cbranch_scc0 BB78                                         ; bfa10010
BB70:
	s_mov_b32 exec_lo, 15                                       ; befe008f
BB71:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[0:3], s[0:1], 0x0                             ; f4004000 f8000000
	s_add_co_u32 s16, s16, s8                                   ; 80100810
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d71f0000
	v_cndmask_b32_e32 v0, -1, v16, vcc_lo                       ; 020020c1
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mov_b32 v1, 1 :: v_dual_lshlrev_b32 v0, 2, v0        ; ca220081 01000082
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_atomic_add_u32 v1, v0, s[0:3], null offen            ; c40d407c 40800001 00000000
BB78:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
