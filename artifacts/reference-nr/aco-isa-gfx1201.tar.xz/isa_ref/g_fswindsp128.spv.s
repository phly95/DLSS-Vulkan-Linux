BB0:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s10, s1                                           ; be8a0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_pack_ll_b32_b16 s21, ttmp7, 0                             ; 99158073
	s_clause 0x4                                                ; bf850004
	s_load_b128 s[12:15], s[0:1], 0x0                           ; f4004300 f8000000
	s_load_b128 s[16:19], s[10:11], 0x30                        ; f4004405 f8000030
	s_load_b32 s20, s[10:11], 0x40                              ; f4000505 f8000040
	s_load_b64 s[22:23], s[10:11], 0x20                         ; f4002585 f8000020
	s_load_b256 s[32:39], s[0:1], 0x30                          ; f4006800 f8000030
(invalid instruction)                                        ; d71f0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_lshrrev_b32_e32 v1, 5, v0                                 ; 32020085
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_and_b32_e32 v4, 15, v3                                    ; 3608068f
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_lshlrev_b32_e32 v2, 9, v1                                 ; 30040289
	v_lshlrev_b32_e32 v5, 4, v4                                 ; 300a0884
	v_lshlrev_b32_e32 v3, 3, v3                                 ; 30060683
	v_add_nc_u32_e32 v7, 0x100, v2                              ; 4a0e04ff 00000100
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl1_add_u32 s19, ttmp9, s19                             ; 87131375
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_max_i32 s24, s19, 0                                       ; 8a188013
	s_add_co_u32 s25, s17, -1                                   ; 8019c111
	s_min_i32 s24, s24, s25                                     ; 89181918
	s_add_co_u32 s26, s18, -1                                   ; 801ac112
	s_lshl1_add_u32 s21, s21, s20                               ; 87151415
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_max_i32 s27, s21, 0                                       ; 8a1b8015
	s_min_i32 s27, s27, s26                                     ; 891b1a1b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s27, s27, s17                                     ; 961b111b
	s_add_co_u32 s28, s27, s24                                  ; 801c181b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s28, s28, 11                                     ; 841c8b1c
	s_add_co_u32 s29, s2, s28                                   ; 801d1c02
	s_add_co_u32 s30, s19, 1                                    ; 801e8113
	v_add3_u32 v6, v5, s29, v2                                  ; d6550006 04083b05
	v_add3_u32 v8, v5, s29, v7                                  ; d6550008 041c3b05
	s_max_i32 s31, s30, 0                                       ; 8a1f801e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_min_i32 s31, s31, s25                                     ; 891f191f
	v_add_nc_u32_e32 v6, v6, v3                                 ; 4a0c0706
	v_add_nc_u32_e32 v8, v8, v3                                 ; 4a100708
	s_add_co_u32 s27, s27, s31                                  ; 801b1f1b
	s_lshl_b32 s27, s27, 11                                     ; 841b8b1b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s40, s2, s27                                   ; 80281b02
	s_add_co_u32 s41, s21, 1                                    ; 80298115
	v_add3_u32 v10, v5, s40, v7                                 ; d655000a 041c5105
	v_add3_u32 v9, v5, s40, v2                                  ; d6550009 04085105
	s_max_i32 s42, s41, 0                                       ; 8a2a8029
	s_min_i32 s42, s42, s26                                     ; 892a1a2a
	v_add_nc_u32_e32 v10, v10, v3                               ; 4a14070a
	v_add_nc_u32_e32 v9, v9, v3                                 ; 4a120709
	s_mul_i32 s42, s42, s17                                     ; 962a112a
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s24, s42, s24                                  ; 8018182a
	s_lshl_b32 s24, s24, 11                                     ; 84188b18
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s43, s2, s24                                   ; 802b1802
	s_add_co_u32 s42, s42, s31                                  ; 802a1f2a
	v_add3_u32 v12, v5, s43, v7                                 ; d655000c 041c5705
	v_add3_u32 v11, v5, s43, v2                                 ; d655000b 04085705
	s_lshl_b32 s42, s42, 11                                     ; 842a8b2a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s2, s2, s42                                    ; 80022a02
	v_add_nc_u32_e32 v12, v12, v3                               ; 4a18070c
	v_add_nc_u32_e32 v11, v11, v3                               ; 4a16070b
	v_add3_u32 v13, v5, s2, v2                                  ; d655000d 04080505
	v_add3_u32 v14, v5, s2, v7                                  ; d655000e 041c0505
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v13, v13, v3                               ; 4a1a070d
	v_add_nc_u32_e32 v14, v14, v3                               ; 4a1c070e
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[16:17], v6, s[12:15], null offen          ; c405407c 40801810 00000006
	buffer_load_b64 v[18:19], v8, s[12:15], null offen          ; c405407c 40801812 00000008
	buffer_load_b64 v[8:9], v9, s[12:15], null offen            ; c405407c 40801808 00000009
	buffer_load_b64 v[20:21], v10, s[12:15], null offen         ; c405407c 40801814 0000000a
	buffer_load_b64 v[10:11], v11, s[12:15], null offen         ; c405407c 4080180a 0000000b
	buffer_load_b64 v[22:23], v12, s[12:15], null offen         ; c405407c 40801816 0000000c
	buffer_load_b64 v[12:13], v13, s[12:15], null offen         ; c405407c 4080180c 0000000d
	buffer_load_b64 v[14:15], v14, s[12:15], null offen         ; c405407c 4080180e 0000000e
	v_lshlrev_b32_e32 v24, 3, v1                                ; 30300283
	v_and_b32_e32 v27, 31, v0                                   ; 3636009f
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_sub_nc_u32_e32 v25, 0, v24                                ; 4c323080
	v_med3_i32 v26, -1, v24, 1                                  ; d620001a 020630c1
	v_add_nc_u32_e32 v29, 2, v24                                ; 4a3a3082
	v_lshlrev_b32_e32 v28, 2, v27                               ; 30383682
	v_max_i32_e32 v25, v24, v25                                 ; 24323318
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_sub_nc_u32_e32 v30, 0, v29                                ; 4c3c3a80
	v_lshrrev_b32_e32 v25, 1, v25                               ; 32323281
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
	v_max_i32_e32 v30, v29, v30                                 ; 243c3d1d
	v_med3_i32 v29, -1, v29, 1                                  ; d620001d 02063ac1
(invalid instruction)                                        ; d72c001a
	v_cndmask_b32_e32 v1, v26, v25, vcc_lo                      ; 0202331a
	v_lshrrev_b32_e32 v30, 1, v30                               ; 323c3c81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d72c001d
	v_cndmask_b32_e32 v1, v29, v30, vcc_lo                      ; 02023d1d
	v_lshl_add_u32 v26, v26, 10, s4                             ; d646001a 0011151a
	v_add_lshl_u32 v26, v26, v28, 2                             ; d647001a 020a391a
	v_lshl_add_u32 v29, v29, 10, s4                             ; d646001d 0011151d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v29, v29, v28, 2                             ; d647001d 020a391d
	s_clause 0xa                                                ; bf85000a
	buffer_load_b128 v[32:35], v26, s[36:39], null offen        ; c405c07c 40804820 0000001a
	buffer_load_b128 v[36:39], v29, s[36:39], null offen        ; c405c07c 40804824 0000001d
	buffer_load_b128 v[40:43], v26, s[36:39], null offen offset:512 ; c405c07c 40804828 0002001a
	buffer_load_b128 v[44:47], v29, s[36:39], null offen offset:512 ; c405c07c 4080482c 0002001d
	buffer_load_b128 v[48:51], v26, s[36:39], null offen offset:1024 ; c405c07c 40804830 0004001a
	buffer_load_b128 v[52:55], v29, s[36:39], null offen offset:1024 ; c405c07c 40804834 0004001d
	buffer_load_b128 v[56:59], v26, s[36:39], null offen offset:1536 ; c405c07c 40804838 0006001a
	buffer_load_b128 v[60:63], v29, s[36:39], null offen offset:1536 ; c405c07c 4080483c 0006001d
	buffer_load_b128 v[64:67], v26, s[36:39], null offen offset:2048 ; c405c07c 40804840 0008001a
	buffer_load_b128 v[68:71], v29, s[36:39], null offen offset:2048 ; c405c07c 40804844 0008001d
	buffer_load_b128 v[72:75], v26, s[36:39], null offen offset:2560 ; c405c07c 40804848 000a001a
	v_add_nc_u32_e32 v31, v5, v3                                ; 4a3e0705
	s_min_i32 s44, s19, s21                                     ; 892c1513
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_cmp_lt_i32 s44, 0                                         ; bf04802c
	v_add_nc_u32_e32 v76, v2, v31                               ; 4a983f02
	s_cselect_b32 s45, -1, 0                                    ; 982d80c1
	s_cmp_ge_i32 s19, s17                                       ; bf031113
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s46, -1, 0                                    ; 982e80c1
	v_add_nc_u32_e32 v77, 0x800, v76                            ; 4a9a98ff 00000800
	v_add_nc_u32_e32 v78, 0x1000, v76                           ; 4a9c98ff 00001000
	v_add_nc_u32_e32 v79, 0x1800, v76                           ; 4a9e98ff 00001800
	s_or_b32 s45, s45, s46                                      ; 8c2d2e2d
	s_cmp_ge_i32 s21, s18                                       ; bf031215
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s47, -1, 0                                    ; 982f80c1
	s_or_b32 s45, s45, s47                                      ; 8c2d2f2d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_mov_b32 s48, src_scc                                      ; beb000fd
	s_min_i32 s49, s30, s21                                     ; 8931151e
	s_cmp_lt_i32 s49, 0                                         ; bf048031
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_cselect_b32 s50, -1, 0                                    ; 983280c1
	s_cmp_ge_i32 s30, s17                                       ; bf03111e
	s_cselect_b32 s51, -1, 0                                    ; 983380c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s50, s50, s51                                      ; 8c323332
	s_or_b32 s50, s50, s47                                      ; 8c322f32
	s_pack_hh_b32_b16 s59, ttmp7, 0                             ; 9a3b8073
	s_mov_b32 s52, src_scc                                      ; beb400fd
	s_min_i32 s53, s19, s41                                     ; 89352913
	v_lshl_add_u32 v80, s59, 4, v31                             ; d6460050 047d083b
	s_movk_i32 s60, 0x400                                       ; b03c0400
	s_cmp_lt_i32 s53, 0                                         ; bf048035
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s54, -1, 0                                    ; 983680c1
	s_or_b32 s54, s54, s46                                      ; 8c362e36
	s_cmp_ge_i32 s41, s18                                       ; bf031229
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s55, -1, 0                                    ; 983780c1
	s_or_b32 s54, s54, s55                                      ; 8c363736
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_mov_b32 s56, src_scc                                      ; beb800fd
	s_min_i32 s30, s30, s41                                     ; 891e291e
	s_cmp_lt_i32 s30, 0                                         ; bf04801e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s57, -1, 0                                    ; 983980c1
	s_or_b32 s57, s57, s51                                      ; 8c393339
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s57, s57, s55                                      ; 8c393739
	s_mov_b32 s58, src_scc                                      ; beba00fd
	s_wait_loadcnt 0x12                                         ; bfc00012
	v_cndmask_b32_e64 v82, v16, 0, s45                          ; d5010052 00b50110
	v_cndmask_b32_e64 v83, v17, 0, s45                          ; d5010053 00b50111
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_cndmask_b32_e64 v17, v19, 0, s45                          ; d5010011 00b50113
	v_cndmask_b32_e64 v16, v18, 0, s45                          ; d5010010 00b50112
	ds_store_2addr_b64 v76, v[82:83], v[16:17] offset1:32       ; d9382000 0010524c
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_cndmask_b32_e64 v16, v8, 0, s50                           ; d5010010 00c90108
	v_cndmask_b32_e64 v17, v9, 0, s50                           ; d5010011 00c90109
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_cndmask_b32_e64 v8, v20, 0, s50                           ; d5010008 00c90114
	v_cndmask_b32_e64 v9, v21, 0, s50                           ; d5010009 00c90115
	ds_store_2addr_b64 v77, v[16:17], v[8:9] offset1:32         ; d9382000 0008104d
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_cndmask_b32_e64 v8, v10, 0, s54                           ; d5010008 00d9010a
	v_cndmask_b32_e64 v9, v11, 0, s54                           ; d5010009 00d9010b
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_cndmask_b32_e64 v10, v22, 0, s54                          ; d501000a 00d90116
	v_cndmask_b32_e64 v11, v23, 0, s54                          ; d501000b 00d90117
	ds_store_2addr_b64 v78, v[8:9], v[10:11] offset1:32         ; d9382000 000a084e
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_cndmask_b32_e64 v9, v13, 0, s57                           ; d5010009 00e5010d
	v_cndmask_b32_e64 v8, v12, 0, s57                           ; d5010008 00e5010c
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_cndmask_b32_e64 v10, v14, 0, s57                          ; d501000a 00e5010e
	v_cndmask_b32_e64 v11, v15, 0, s57                          ; d501000b 00e5010f
	ds_store_2addr_b64 v79, v[8:9], v[10:11] offset1:32         ; d9382000 000a084f
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[8:9], v80                                     ; d9d80000 08000050
	ds_load_b64 v[10:11], v80 offset:2048                       ; d9d80800 0a000050
	ds_load_b64 v[12:13], v80 offset:4096                       ; d9d81000 0c000050
	ds_load_b64 v[14:15], v80 offset:6144                       ; d9d81800 0e000050
	ds_load_b64 v[16:17], v80 offset:256                        ; d9d80100 10000050
	ds_load_b64 v[18:19], v80 offset:2304                       ; d9d80900 12000050
	ds_load_b64 v[20:21], v80 offset:4352                       ; d9d81100 14000050
	ds_load_b64 v[22:23], v80 offset:6400                       ; d9d81900 16000050
	ds_load_b64 v[82:83], v80 offset:512                        ; d9d80200 52000050
	v_mov_b32_e32 v81, v7                                       ; 7ea20307
	v_mov_b32_e32 v25, v28                                      ; 7e32031c
	v_dual_mov_b32 v85, v31 :: v_dual_mov_b32 v84, v29          ; ca10011f 5554011d
	s_wait_loadcnt_dscnt 0xa08                                  ; bfc80a08
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[8:9], 0  ; cc464060 1a021122
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[12:13], 0 ; cc464098 1a021920
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[10:11], 0 ; cc464080 1a021522
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[34:35], v[12:13], 0 ; cc4640a0 1a021922
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[32:33], v[14:15], 0 ; cc4640b8 1a021d20
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[10:11], 0 ; cc464078 1a021520
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[8:9], 0   ; cc464058 1a021120
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[12:13], 0 ; cc4640b0 1a021926
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[8:9], 0 ; cc464070 1a021126
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[36:37], v[10:11], 0 ; cc464088 1a021524
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[8:9], 0 ; cc464068 1a021124
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[10:11], 0 ; cc464090 1a021526
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[36:37], v[12:13], 0 ; cc4640a8 1a021924
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[34:35], v[14:15], 0  ; cc464006 1a021d22
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[36:37], v[14:15], 0 ; cc46401c 1a021d24
	v_dual_mov_b32 v37, v15 :: v_dual_mov_b32 v36, v14          ; ca10010f 2524010e
	s_wait_loadcnt_dscnt 0x804                                  ; bfc80804
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[16:17], v[96:103] ; cc464060 1d82212a
	s_wait_dscnt 0x3                                            ; bfc60003
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[18:19], v[128:135] ; cc464080 1e02252a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[18:19], v[120:127] ; cc464078 1de22528
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[16:17], v[88:95] ; cc464058 1d622128
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[20:21], v[152:159] ; cc464098 1e622928
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[42:43], v[20:21], v[160:167] ; cc4640a0 1e82292a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[16:17], v[112:119] ; cc464070 1dc2212e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[44:45], v[18:19], v[136:143] ; cc464088 1e22252c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[20:21], v[176:183] ; cc4640b0 1ec2292e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[16:17], v[104:111] ; cc464068 1da2212c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[18:19], v[144:151] ; cc464090 1e42252e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[20:21], v[168:175] ; cc4640a8 1ea2292c
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[38:39], v[36:37], 0 ; cc46400e 1a024926
	s_wait_loadcnt_dscnt 0x600                                  ; bfc80600
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[82:83], v[96:103] ; cc464060 1d82a532
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[40:41], v[22:23], v[184:191] ; cc4640b8 1ee22d28
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[42:43], v[22:23], v[6:13] ; cc464006 1c1a2d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[82:83], v[88:95] ; cc464058 1d62a530
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[44:45], v[22:23], v[28:35] ; cc46401c 1c722d2c
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[82:83], v[104:111] ; cc464068 1da2a534
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[82:83], v[112:119] ; cc464070 1dc2a536
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[46:47], v[22:23], v[14:21] ; cc46400e 1c3a2d2e
	ds_load_b64 v[36:37], v80 offset:2560                       ; d9d80a00 24000050
	ds_load_b64 v[38:39], v80 offset:4608                       ; d9d81200 26000050
	ds_load_b64 v[40:41], v80 offset:6656                       ; d9d81a00 28000050
	ds_load_b64 v[42:43], v80 offset:768                        ; d9d80300 2a000050
	ds_load_b64 v[44:45], v80 offset:2816                       ; d9d80b00 2c000050
	ds_load_b64 v[22:23], v80 offset:4864                       ; d9d81300 16000050
	ds_load_b64 v[46:47], v80 offset:6912                       ; d9d81b00 2e000050
	ds_load_b64 v[82:83], v80 offset:1024                       ; d9d80400 52000050
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[36:37], v[136:143] ; cc464088 1e224934
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[36:37], v[120:127] ; cc464078 1de24930
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[36:37], v[128:135] ; cc464080 1e024932
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[36:37], v[144:151] ; cc464090 1e424936
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[38:39], v[176:183] ; cc4640b0 1ec24d36
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[38:39], v[160:167] ; cc4640a0 1e824d32
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[38:39], v[168:175] ; cc4640a8 1ea24d34
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[38:39], v[152:159] ; cc464098 1e624d30
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[52:53], v[40:41], v[28:35] ; cc46401c 1c725134
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[48:49], v[40:41], v[184:191] ; cc4640b8 1ee25130
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[50:51], v[40:41], v[6:13] ; cc464006 1c1a5132
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[54:55], v[40:41], v[14:21] ; cc46400e 1c3a5136
	ds_load_b64 v[36:37], v80 offset:3072                       ; d9d80c00 24000050
	ds_load_b64 v[38:39], v80 offset:5120                       ; d9d81400 26000050
	ds_load_b64 v[48:49], v80 offset:7168                       ; d9d81c00 30000050
	ds_load_b64 v[50:51], v80 offset:1280                       ; d9d80500 32000050
	ds_load_b64 v[52:53], v80 offset:3328                       ; d9d80d00 34000050
	ds_load_b64 v[40:41], v80 offset:5376                       ; d9d81500 28000050
	ds_load_b64 v[54:55], v80 offset:7424                       ; d9d81d00 36000050
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[42:43], v[88:95] ; cc464058 1d625538
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[42:43], v[96:103] ; cc464060 1d82553a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[44:45], v[120:127] ; cc464078 1de25938
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[44:45], v[128:135] ; cc464080 1e02593a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[22:23], v[160:167] ; cc4640a0 1e822d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[22:23], v[152:159] ; cc464098 1e622d38
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[46:47], v[184:191] ; cc4640b8 1ee25d38
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[42:43], v[104:111] ; cc464068 1da2553c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[44:45], v[136:143] ; cc464088 1e22593c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[22:23], v[168:175] ; cc4640a8 1ea22d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[42:43], v[112:119] ; cc464070 1dc2553e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[44:45], v[144:151] ; cc464090 1e42593e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[22:23], v[176:183] ; cc4640b0 1ec22d3e
	ds_load_b64 v[56:57], v80 offset:1536                       ; d9d80600 38000050
	ds_load_b64 v[42:43], v80 offset:3584                       ; d9d80e00 2a000050
	ds_load_b64 v[22:23], v80 offset:5632                       ; d9d81600 16000050
	ds_load_b64 v[44:45], v80 offset:7680                       ; d9d81e00 2c000050
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[60:61], v[46:47], v[28:35] ; cc46401c 1c725d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[58:59], v[46:47], v[6:13] ; cc464006 1c1a5d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[62:63], v[46:47], v[14:21] ; cc46400e 1c3a5d3e
	ds_load_b64 v[46:47], v80 offset:1792                       ; d9d80700 2e000050
	ds_load_b64 v[58:59], v80 offset:3840                       ; d9d80f00 3a000050
	s_wait_loadcnt_dscnt 0x20c                                  ; bfc8020c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[36:37], v[120:127] ; cc464078 1de24940
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[82:83], v[88:95] ; cc464058 1d62a540
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[38:39], v[152:159] ; cc464098 1e624d40
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[36:37], v[128:135] ; cc464080 1e024942
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[38:39], v[160:167] ; cc4640a0 1e824d42
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[36:37], v[136:143] ; cc464088 1e224944
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[38:39], v[168:175] ; cc4640a8 1ea24d44
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[36:37], v[144:151] ; cc464090 1e424946
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[38:39], v[176:183] ; cc4640b0 1ec24d46
	ds_load_b64 v[36:37], v80 offset:5888                       ; d9d81700 24000050
	ds_load_b64 v[38:39], v80 offset:7936                       ; d9d81f00 26000050
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[48:49], v[184:191] ; cc4640b8 1ee26140
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[82:83], v[96:103] ; cc464060 1d82a542
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[82:83], v[104:111] ; cc464068 1da2a544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[82:83], v[112:119] ; cc464070 1dc2a546
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[68:69], v[48:49], v[28:35] ; cc46401c 1c726144
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[66:67], v[48:49], v[6:13] ; cc464006 1c1a6142
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[48:49], v[14:21] ; cc46400e 1c3a6146
	v_mov_b32_e32 v48, v81                                      ; 7e600351
	v_mov_b32_e32 v49, v85                                      ; 7e620355
	s_clause 0x4                                                ; bf850004
	buffer_load_b128 v[60:63], v84, s[36:39], null offen offset:2560 ; c405c07c 4080483c 000a0054
	buffer_load_b128 v[64:67], v26, s[36:39], null offen offset:3072 ; c405c07c 40804840 000c001a
	buffer_load_b128 v[68:71], v84, s[36:39], null offen offset:3072 ; c405c07c 40804844 000c0054
	buffer_load_b128 v[80:83], v26, s[36:39], null offen offset:3584 ; c405c07c 40804850 000e001a
	buffer_load_b128 v[84:87], v84, s[36:39], null offen offset:3584 ; c405c07c 40804854 000e0054
	s_wait_loadcnt_dscnt 0x50b                                  ; bfc8050b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[50:51], v[88:95] ; cc464058 1d626548
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[52:53], v[120:127] ; cc464078 1de26948
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[40:41], v[152:159] ; cc464098 1e625148
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[72:73], v[54:55], v[184:191] ; cc4640b8 1ee26d48
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[74:75], v[50:51], v[96:103] ; cc464060 1d82654a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[52:53], v[128:135] ; cc464080 1e02694a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[74:75], v[40:41], v[160:167] ; cc4640a0 1e82514a
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[74:75], v[54:55], v[6:13] ; cc464006 1c1a6d4a
	v_mad_u32_u24 v72, s59, 0x50, v49                           ; d60b0048 04c5fe3b 00000050
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[40:41], v[168:175] ; cc4640a8 1ea2513c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[52:53], v[144:151] ; cc464090 1e42693e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[50:51], v[104:111] ; cc464068 1da2653c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[52:53], v[136:143] ; cc464088 1e22693c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[50:51], v[112:119] ; cc464070 1dc2653e
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[60:61], v[54:55], v[28:35] ; cc46401c 1c726d3c
	ds_load_b64 v[74:75], v72                                   ; d9d80000 4a000048
	ds_load_b64 v[60:61], v72 offset:2048                       ; d9d80800 3c000048
	ds_load_b64 v[50:51], v72 offset:4096                       ; d9d81000 32000048
	ds_load_b64 v[52:53], v72 offset:6144                       ; d9d81800 34000048
	v_add_nc_u32_e32 v73, 4, v24                                ; 4a923084
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[40:41], v[176:183] ; cc4640b0 1ec2513e
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[62:63], v[54:55], v[14:21] ; cc46400e 1c3a6d3e
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_dual_mov_b32 v55, v43 :: v_dual_mov_b32 v54, v42          ; ca10012b 3736012a
	v_sub_nc_u32_e32 v26, 0, v73                                ; 4c349280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v26, v73, v26                                 ; 24343549
	v_med3_i32 v73, -1, v73, 1                                  ; d6200049 020692c1
	v_lshrrev_b32_e32 v26, 1, v26                               ; 32343481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0049
	v_cndmask_b32_e32 v1, v73, v26, vcc_lo                      ; 02023549
	v_lshl_add_u32 v73, v73, 10, s4                             ; d6460049 00111549
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v73, v73, v25, 2                             ; d6470049 020a3349
	buffer_load_b128 v[40:43], v73, s[36:39], null offen        ; c405c07c 40804828 00000049
	v_add_nc_u32_e32 v24, 6, v24                                ; 4a303086
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[56:57], v[88:95] ; cc464058 1d627140
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[54:55], v[120:127] ; cc464078 1de26d40
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[22:23], v[152:159] ; cc464098 1e622d40
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[44:45], v[184:191] ; cc4640b8 1ee25940
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[56:57], v[96:103] ; cc464060 1d827142
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[54:55], v[128:135] ; cc464080 1e026d42
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[22:23], v[160:167] ; cc4640a0 1e822d42
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[66:67], v[44:45], v[6:13] ; cc464006 1c1a5942
	v_sub_nc_u32_e32 v62, 0, v24                                ; 4c7c3080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v62, v24, v62                                 ; 247c7d18
	v_med3_i32 v24, -1, v24, 1                                  ; d6200018 020630c1
	v_lshrrev_b32_e32 v62, 1, v62                               ; 327c7c81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0018
	v_cndmask_b32_e32 v1, v24, v62, vcc_lo                      ; 02027d18
	v_lshl_add_u32 v24, v24, 10, s4                             ; d6460018 00111518
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v24, v24, v25, 2                             ; d6470018 020a3318
	buffer_load_b128 v[64:67], v24, s[36:39], null offen        ; c405c07c 40804840 00000018
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[56:57], v[104:111] ; cc464068 1da27144
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[54:55], v[136:143] ; cc464088 1e226d44
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[22:23], v[168:175] ; cc4640a8 1ea22d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[56:57], v[112:119] ; cc464070 1dc27146
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[54:55], v[144:151] ; cc464090 1e426d46
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[22:23], v[176:183] ; cc4640b0 1ec22d46
	ds_load_b64 v[62:63], v72 offset:256                        ; d9d80100 3e000048
	ds_load_b64 v[56:57], v72 offset:2304                       ; d9d80900 38000048
	ds_load_b64 v[54:55], v72 offset:4352                       ; d9d81100 36000048
	ds_load_b64 v[22:23], v72 offset:6400                       ; d9d81900 16000048
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[68:69], v[44:45], v[28:35] ; cc46401c 1c725944
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[70:71], v[44:45], v[14:21] ; cc46400e 1c3a5946
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[80:81], v[46:47], v[88:95] ; cc464058 1d625d50
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[58:59], v[120:127] ; cc464078 1de27550
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[80:81], v[36:37], v[152:159] ; cc464098 1e624950
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[80:81], v[38:39], v[184:191] ; cc4640b8 1ee24d50
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[82:83], v[46:47], v[96:103] ; cc464060 1d825d52
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[58:59], v[128:135] ; cc464080 1e027552
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[82:83], v[36:37], v[160:167] ; cc4640a0 1e824952
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[82:83], v[38:39], v[6:13] ; cc464006 1c1a4d52
	v_maxmin_num_f32 v80, -4.0, v90, 4.0                        ; d6690050 03dab4f7
	v_maxmin_num_f32 v82, -4.0, v91, 4.0                        ; d6690052 03dab6f7
	v_maxmin_num_f32 v70, -4.0, v89, 4.0                        ; d6690046 03dab2f7
	v_maxmin_num_f32 v68, -4.0, v88, 4.0                        ; d6690044 03dab0f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_fma_mix_f32 v69, 0xab28, |v68|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe88ff 3728ab28
	v_maxmin_num_f32 v26, -4.0, v95, 4.0                        ; d669001a 03dabef7
	v_dual_fmaak_f32 v83, v83, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v81, 0x3f650000 ; c842a553 5350a350 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v71, v71, v70, 0x3f650000 :: v_dual_fmaak_f32 v68, v68, v69, 0x3f650000 ; c8428d47 47448b44 3f650000
	v_dual_mul_f32 v91, v91, v83 :: v_dual_mul_f32 v90, v90, v80 ; c8c6a75b 5b5aa15a
	v_maxmin_num_f32 v69, -4.0, v120, 4.0                       ; d6690045 03daf0f7
	v_dual_mul_f32 v89, v89, v71 :: v_dual_mul_f32 v88, v88, v68 ; c8c68f59 59588958
	v_fma_mix_f32 v68, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206244 0bfe34ff 3728ab28
	v_maxmin_num_f32 v71, -4.0, v121, 4.0                       ; d6690047 03daf2f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v70, 0xab28, |v69|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe8aff 3728ab28
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v92, 4.0                        ; d6690058 03dab8f7
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v90, -4.0, v93, 4.0                        ; d669005a 03dabaf7
	v_maxmin_num_f32 v81, -4.0, v122, 4.0                       ; d6690051 03daf4f7
	v_fma_mix_f32 v80, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe8eff 3728ab28
	v_maxmin_num_f32 v83, -4.0, v123, 4.0                       ; d6690053 03daf6f7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_dual_fmaak_f32 v69, v69, v70, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v71, 0x3f650000 ; c8428d45 45508f50 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 ; c842b75a 5a58b159 3f650000
	v_maxmin_num_f32 v91, -4.0, v125, 4.0                       ; d669005b 03dafaf7
	v_fma_mix_f32 v88, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfea6ff 3728ab28
	v_dual_mul_f32 v121, v121, v80 :: v_dual_mul_f32 v120, v120, v69 ; c8c6a179 79788b78
	v_dual_mul_f32 v93, v93, v90 :: v_dual_mul_f32 v92, v92, v89 ; c8c6b55d 5d5cb35c
	v_maxmin_num_f32 v89, -4.0, v124, 4.0                       ; d6690059 03daf8f7
	v_dual_fmaak_f32 v88, v88, v83, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 ; c842a758 5850a551 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v92, -4.0, v94, 4.0                        ; d669005c 03dabcf7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_mul_f32 v123, v123, v88 :: v_dual_mul_f32 v122, v122, v81 ; c8c6b17b 7b7aa37a
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmaak_f32 v26, v68, v26, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 ; c8423544 1a5cb95d 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v121, -4.0, v152, 4.0                      ; d6690079 03db30f7
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v123, -4.0, v153, 4.0                      ; d669007b 03db32f7
	v_dual_mul_f32 v95, v95, v26 :: v_dual_mul_f32 v94, v94, v93 ; c8c6355f 5f5ebb5e
	v_maxmin_num_f32 v93, -4.0, v126, 4.0                       ; d669005d 03dafcf7
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b95b 5b5ab35a 3f650000
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v127, 4.0                       ; d669005f 03dafef7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_mul_f32 v125, v125, v91 :: v_dual_mul_f32 v124, v124, v90 ; c8c6b77d 7d7cb57c
	v_fma_mix_f32 v120, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfebeff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v125, -4.0, v154, 4.0                      ; d669007d 03db34f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_fmaak_f32 v95, v95, v120, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842f15f 5f5ebb5e 3f650000
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c842f579 797cf77c 3f650000
	v_dual_mul_f32 v127, v127, v95 :: v_dual_mul_f32 v126, v126, v94 ; c8c6bf7f 7f7ebd7e
	v_maxmin_num_f32 v80, -4.0, v158, 4.0                       ; d6690050 03db3cf7
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_mul_f32 v153, v153, v124 :: v_dual_mul_f32 v152, v152, v121 ; c8c6f999 9998f398
	v_maxmin_num_f32 v82, -4.0, v159, 4.0                       ; d6690052 03db3ef7
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v127, -4.0, v155, 4.0                      ; d669007f 03db36f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v153, -4.0, v156, 4.0                      ; d6690099 03db38f7
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[84:85], v[46:47], v[104:111] ; cc464068 1da25d54
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[84:85], v[58:59], v[136:143] ; cc464088 1e227554
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[84:85], v[36:37], v[168:175] ; cc4640a8 1ea24954
	v_fma_mix_f32 v152, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bfefeff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[28:35], v[84:85], v[38:39], v[28:35] ; cc46401c 1c724d54
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[86:87], v[46:47], v[112:119] ; cc464070 1dc25d56
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[86:87], v[58:59], v[144:151] ; cc464090 1e427556
	v_dual_fmaak_f32 v81, v81, v80, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v83, 0x3f650000 ; c842a151 5152a752 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[86:87], v[36:37], v[176:183] ; cc4640b0 1ec24956
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[86:87], v[38:39], v[14:21] ; cc46400e 1c3a4d56
	v_dual_fmaak_f32 v152, v152, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842ff98 987cfd7d 3f650000
	v_maxmin_num_f32 v84, -4.0, v184, 4.0                       ; d6690054 03db70f7
	v_maxmin_num_f32 v86, -4.0, v185, 4.0                       ; d6690056 03db72f7
	v_dual_mul_f32 v159, v159, v82 :: v_dual_mul_f32 v158, v158, v81 ; c8c6a59f 9f9ea39e
	v_maxmin_num_f32 v88, -4.0, v186, 4.0                       ; d6690058 03db74f7
	v_maxmin_num_f32 v90, -4.0, v187, 4.0                       ; d669005a 03db76f7
	v_dual_mul_f32 v155, v155, v152 :: v_dual_mul_f32 v154, v154, v125 ; c8c7319b 9b9afb9a
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v188, 4.0                       ; d669005c 03db78f7
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_maxmin_num_f32 v94, -4.0, v189, 4.0                       ; d669005e 03db7af7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v155, -4.0, v157, 4.0                      ; d669009b 03db3af7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v120, -4.0, v190, 4.0                      ; d6690078 03db7cf7
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c842ad57 5754ab54 3f650000
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_maxmin_num_f32 v122, -4.0, v191, 4.0                      ; d669007a 03db7ef7
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	v_fma_mix_f32 v26, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bff36ff 3728ab28
	v_maxmin_num_f32 v124, -4.0, v96, 4.0                       ; d669007c 03dac0f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_dual_mul_f32 v185, v185, v87 :: v_dual_mul_f32 v184, v184, v84 ; c8c6afb9 b9b8a9b8
	v_maxmin_num_f32 v126, -4.0, v97, 4.0                       ; d669007e 03dac2f7
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c842b95d 5d5ebf5e 3f650000
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_dual_mul_f32 v187, v187, v91 :: v_dual_mul_f32 v186, v186, v88 ; c8c6b7bb bbbab1ba
	v_dual_fmaak_f32 v155, v155, v26, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c842359b 9b9b339a 3f650000
	v_maxmin_num_f32 v152, -4.0, v98, 4.0                       ; d6690098 03dac4f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_dual_mul_f32 v189, v189, v94 :: v_dual_mul_f32 v188, v188, v93 ; c8c6bdbd bdbcbbbc
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 ; c842f179 797af77a 3f650000
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_dual_mul_f32 v157, v157, v155 :: v_dual_mul_f32 v156, v156, v154 ; c8c7379d 9d9d359c
	v_maxmin_num_f32 v154, -4.0, v99, 4.0                       ; d669009a 03dac6f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 ; c842fd7f 7f7cfb7c 3f650000
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_dual_mul_f32 v191, v191, v122 :: v_dual_mul_f32 v190, v190, v121 ; c8c6f5bf bfbef3be
	v_maxmin_num_f32 v184, -4.0, v102, 4.0                      ; d66900b8 03daccf7
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_maxmin_num_f32 v156, -4.0, v100, 4.0                      ; d669009c 03dac8f7
	v_maxmin_num_f32 v158, -4.0, v101, 4.0                      ; d669009e 03dacaf7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v186, -4.0, v103, 4.0                      ; d66900ba 03dacef7
	v_dual_mul_f32 v97, v97, v127 :: v_dual_mul_f32 v96, v96, v124 ; c8c6ff61 6160f960
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v128, 4.0                      ; d66900bc 03db00f7
	v_maxmin_num_f32 v190, -4.0, v129, 4.0                      ; d66900be 03db02f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v47, -4.0, v131, 4.0                       ; d669002f 03db06f7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c843399d 9d9f3f9e 3f650000
	v_dual_mul_f32 v99, v99, v155 :: v_dual_mul_f32 v98, v98, v152 ; c8c73763 63633162
	v_maxmin_num_f32 v59, -4.0, v132, 4.0                       ; d669003b 03db08f7
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84371b9 b9bb77ba 3f650000
	v_maxmin_num_f32 v81, -4.0, v133, 4.0                       ; d6690051 03db0af7
	v_fma_mix_f32 v58, 0xab28, |v47|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623a 0bfe5eff 3728ab28
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8437dbf bfbd7bbc 3f650000
	v_dual_mul_f32 v101, v101, v158 :: v_dual_mul_f32 v100, v100, v157 ; c8c73d65 65653b64
	v_maxmin_num_f32 v83, -4.0, v134, 4.0                       ; d6690053 03db0cf7
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_fma_mix_f32 v80, 0xab28, |v59|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe76ff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v135, 4.0                       ; d6690055 03db0ef7
	v_dual_mul_f32 v103, v103, v186 :: v_dual_mul_f32 v102, v102, v185 ; c8c77567 67677366
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_dual_mul_f32 v129, v129, v191 :: v_dual_mul_f32 v128, v128, v188 ; c8c77f81 81817980
	v_maxmin_num_f32 v191, -4.0, v130, 4.0                      ; d66900bf 03db04f7
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v160, 4.0                       ; d6690057 03db40f7
	v_maxmin_num_f32 v89, -4.0, v161, 4.0                       ; d6690059 03db42f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v59, 0x3f650000 ; c842a551 51507750 3f650000
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v91, -4.0, v162, 4.0                       ; d669005b 03db44f7
	v_fma_mix_f32 v26, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bff7eff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v163, 4.0                       ; d669005d 03db46f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 ; c842ad55 5554a754 3f650000
	v_maxmin_num_f32 v95, -4.0, v164, 4.0                       ; d669005f 03db48f7
	v_dual_mul_f32 v133, v133, v81 :: v_dual_mul_f32 v132, v132, v80 ; c8c6a385 8584a184
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v165, 4.0                       ; d6690061 03db4af7
	v_dual_fmaak_f32 v58, v58, v47, 0x3f650000 :: v_dual_fmaak_f32 v191, v191, v26, 0x3f650000 ; c8425f3a 3abe35bf 3f650000
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b157 575ab35a 3f650000
	v_dual_mul_f32 v135, v135, v85 :: v_dual_mul_f32 v134, v134, v84 ; c8c6ab87 8786a986
	v_maxmin_num_f32 v99, -4.0, v166, 4.0                       ; d6690063 03db4cf7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v167, 4.0                      ; d6690065 03db4ef7
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_mul_f32 v131, v131, v58 :: v_dual_mul_f32 v130, v130, v191 ; c8c67583 83837f82
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842b95b 5b5ebb5e 3f650000
	v_dual_mul_f32 v161, v161, v90 :: v_dual_mul_f32 v160, v160, v87 ; c8c6b5a1 a1a0afa0
	v_maxmin_num_f32 v103, -4.0, v6, 4.0                        ; d6690067 03da0cf7
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v121, -4.0, v7, 4.0                        ; d6690079 03da0ef7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842c561 6160bf60 3f650000
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v123, -4.0, v8, 4.0                        ; d669007b 03da10f7
	v_dual_mul_f32 v163, v163, v94 :: v_dual_mul_f32 v162, v162, v91 ; c8c6bda3 a3a2b7a2
	v_maxmin_num_f32 v125, -4.0, v9, 4.0                        ; d669007d 03da12f7
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_fma_mix_f32 v120, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeceff 3728ab28
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v10, 4.0                       ; d669007f 03da14f7
	v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 ; c842cd65 6564c764 3f650000
	v_dual_mul_f32 v165, v165, v97 :: v_dual_mul_f32 v164, v164, v96 ; c8c6c3a5 a5a4c1a4
	v_maxmin_num_f32 v129, -4.0, v11, 4.0                       ; d6690081 03da16f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v12, 4.0                       ; d6690083 03da18f7
	v_dual_fmaak_f32 v103, v103, v120, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f167 677af37a 3f650000
	v_maxmin_num_f32 v133, -4.0, v13, 4.0                       ; d6690085 03da1af7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_dual_mul_f32 v167, v167, v101 :: v_dual_mul_f32 v166, v166, v100 ; c8c6cba7 a7a6c9a6
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v104, 4.0                      ; d6690087 03dad0f7
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c842f97b 7b7efb7e 3f650000
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_maxmin_num_f32 v153, -4.0, v105, 4.0                      ; d6690099 03dad2f7
	v_dual_mul_f32 v7, v7, v122 :: v_dual_mul_f32 v6, v6, v103  ; c8c6f507 0706cf06
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_maxmin_num_f32 v155, -4.0, v106, 4.0                      ; d669009b 03dad4f7
	v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 ; c8430581 8180ff80 3f650000
	v_fma_mix_f32 v152, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff0eff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v107, 4.0                      ; d669009d 03dad6f7
	v_dual_mul_f32 v9, v9, v126 :: v_dual_mul_f32 v8, v8, v123  ; c8c6fd09 0908f708
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
	v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 ; c8430d85 85850784 3f650000
	v_maxmin_num_f32 v159, -4.0, v108, 4.0                      ; d669009f 03dad8f7
	v_maxmin_num_f32 v161, -4.0, v109, 4.0                      ; d66900a1 03dadaf7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_mul_f32 v11, v11, v129 :: v_dual_mul_f32 v10, v10, v128 ; c8c7030b 0b0b010a
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
	v_maxmin_num_f32 v163, -4.0, v110, 4.0                      ; d66900a3 03dadcf7
	v_dual_fmaak_f32 v135, v135, v152, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c8433187 879b339a 3f650000
	v_dual_mul_f32 v13, v13, v133 :: v_dual_mul_f32 v12, v12, v132 ; c8c70b0d 0d0d090c
	v_maxmin_num_f32 v165, -4.0, v111, 4.0                      ; d66900a5 03dadef7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	v_maxmin_num_f32 v167, -4.0, v136, 4.0                      ; d66900a7 03db10f7
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 ; c843399b 9b9f3b9e 3f650000
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v137, 4.0                      ; d66900b9 03db12f7
	v_dual_mul_f32 v105, v105, v154 :: v_dual_mul_f32 v104, v104, v135 ; c8c73569 69690f68
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 ; c84345a1 a1a13fa0 3f650000
	v_maxmin_num_f32 v187, -4.0, v138, 4.0                      ; d66900bb 03db14f7
	v_maxmin_num_f32 v189, -4.0, v139, 4.0                      ; d66900bd 03db16f7
	v_fma_mix_f32 v184, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff4eff 3728ab28
	v_dual_mul_f32 v107, v107, v158 :: v_dual_mul_f32 v106, v106, v155 ; c8c73d6b 6b6b376a
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v191, -4.0, v140, 4.0                      ; d66900bf 03db18f7
	v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 ; c8434da5 a5a547a4 3f650000
	v_maxmin_num_f32 v12, -4.0, v141, 4.0                       ; d669000c 03db1af7
	v_dual_mul_f32 v109, v109, v161 :: v_dual_mul_f32 v108, v108, v160 ; c8c7436d 6d6d416c
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v26, -4.0, v142, 4.0                       ; d669001a 03db1cf7
	v_dual_fmaak_f32 v167, v167, v184, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84371a7 a7bb73ba 3f650000
	v_maxmin_num_f32 v81, -4.0, v143, 4.0                       ; d6690051 03db1ef7
	v_fma_mix_f32 v11, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620b 0bff7eff 3728ab28
	v_dual_mul_f32 v111, v111, v165 :: v_dual_mul_f32 v110, v110, v164 ; c8c74b6f 6f6f496e
	v_fma_mix_f32 v13, 0xab28, |v12|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620d 0bfe18ff 3728ab28
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v83, -4.0, v168, 4.0                       ; d6690053 03db50f7
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c84379bb bbbf7bbe 3f650000
	v_fma_mix_f32 v80, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe34ff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v169, 4.0                       ; d6690055 03db52f7
	v_dual_mul_f32 v137, v137, v186 :: v_dual_mul_f32 v136, v136, v167 ; c8c77589 89894f88
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_fmaak_f32 v12, v12, v13, 0x3f650000 :: v_dual_fmaak_f32 v11, v11, v191, 0x3f650000 ; c8421b0c 0c0b7f0b 3f650000
	v_maxmin_num_f32 v87, -4.0, v170, 4.0                       ; d6690057 03db54f7
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v171, 4.0                       ; d6690059 03db56f7
	v_dual_mul_f32 v139, v139, v190 :: v_dual_mul_f32 v138, v138, v187 ; c8c77d8b 8b8b778a
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_dual_fmaak_f32 v81, v82, v81, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v26, 0x3f650000 ; c842a352 51503550 3f650000
	v_maxmin_num_f32 v91, -4.0, v172, 4.0                       ; d669005b 03db58f7
	v_dual_mul_f32 v141, v141, v12 :: v_dual_mul_f32 v140, v140, v11 ; c8c6198d 8d8c178c
	v_maxmin_num_f32 v93, -4.0, v173, 4.0                       ; d669005d 03db5af7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 :: v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 ; c842ab56 5652a953 3f650000
	v_maxmin_num_f32 v95, -4.0, v174, 4.0                       ; d669005f 03db5cf7
	v_dual_mul_f32 v143, v143, v81 :: v_dual_mul_f32 v142, v142, v80 ; c8c6a38f 8f8ea18e
	v_maxmin_num_f32 v97, -4.0, v175, 4.0                       ; d6690061 03db5ef7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b157 575ab35a 3f650000
	v_maxmin_num_f32 v99, -4.0, v28, 4.0                        ; d6690063 03da38f7
	v_dual_mul_f32 v169, v169, v86 :: v_dual_mul_f32 v168, v168, v83 ; c8c6ada9 a9a8a7a8
	v_maxmin_num_f32 v101, -4.0, v29, 4.0                       ; d6690065 03da3af7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v30, 4.0                       ; d6690067 03da3cf7
	v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842bd5d 5d5cb75c 3f650000
	v_dual_mul_f32 v171, v171, v90 :: v_dual_mul_f32 v170, v170, v87 ; c8c6b5ab abaaafaa
	v_maxmin_num_f32 v105, -4.0, v31, 4.0                       ; d6690069 03da3ef7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v32, 4.0                       ; d669006b 03da40f7
	v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842c561 6160bf60 3f650000
	v_maxmin_num_f32 v109, -4.0, v33, 4.0                       ; d669006d 03da42f7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_mul_f32 v173, v173, v93 :: v_dual_mul_f32 v172, v172, v92 ; c8c6bbad adacb9ac
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_maxmin_num_f32 v111, -4.0, v34, 4.0                       ; d669006f 03da44f7
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c842c963 6366cb66 3f650000
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v35, 4.0                       ; d6690079 03da46f7
	v_dual_mul_f32 v175, v175, v97 :: v_dual_mul_f32 v174, v174, v96 ; c8c6c3af afaec1ae
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_maxmin_num_f32 v123, -4.0, v112, 4.0                      ; d669007b 03dae0f7
	v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 ; c842d167 676ad36a 3f650000
	v_fma_mix_f32 v120, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfedeff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v113, 4.0                      ; d669007d 03dae2f7
	v_dual_mul_f32 v29, v29, v102 :: v_dual_mul_f32 v28, v28, v99 ; c8c6cd1d 1d1cc71c
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_maxmin_num_f32 v127, -4.0, v114, 4.0                      ; d669007f 03dae4f7
	v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 ; c842dd6d 6d6cd76c 3f650000
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v115, 4.0                      ; d6690081 03dae6f7
	v_dual_mul_f32 v31, v31, v106 :: v_dual_mul_f32 v30, v30, v103 ; c8c6d51f 1f1ecf1e
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
	v_maxmin_num_f32 v131, -4.0, v116, 4.0                      ; d6690083 03dae8f7
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v111, 0x3f650000 ; c842f579 7978df78 3f650000
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v133, -4.0, v117, 4.0                      ; d6690085 03daeaf7
	v_dual_mul_f32 v33, v33, v109 :: v_dual_mul_f32 v32, v32, v108 ; c8c6db21 2120d920
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                      ; 02023f1e
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c842f97b 7b7efb7e 3f650000
	v_maxmin_num_f32 v135, -4.0, v118, 4.0                      ; d6690087 03daecf7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_maxmin_num_f32 v137, -4.0, v119, 4.0                      ; d6690089 03daeef7
	v_dual_mul_f32 v35, v35, v121 :: v_dual_mul_f32 v34, v34, v120 ; c8c6f323 2322f122
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	v_maxmin_num_f32 v139, -4.0, v144, 4.0                      ; d669008b 03db20f7
	v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 ; c843017f 7f830382 3f650000
	v_dual_mul_f32 v113, v113, v126 :: v_dual_mul_f32 v112, v112, v123 ; c8c6fd71 7170f770
	v_maxmin_num_f32 v141, -4.0, v145, 4.0                      ; d669008d 03db22f7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 ; c8430d85 85850784 3f650000
	v_maxmin_num_f32 v143, -4.0, v146, 4.0                      ; d669008f 03db24f7
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_mul_f32 v115, v115, v130 :: v_dual_mul_f32 v114, v114, v127 ; c8c70573 7372ff72
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 ; c8431589 89890f88 3f650000
	v_maxmin_num_f32 v153, -4.0, v148, 4.0                      ; d6690099 03db28f7
	v_dual_mul_f32 v117, v117, v133 :: v_dual_mul_f32 v116, v116, v132 ; c8c70b75 75750974
	v_maxmin_num_f32 v155, -4.0, v149, 4.0                      ; d669009b 03db2af7
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 ; c843198b 8b8f1b8e 3f650000
	v_maxmin_num_f32 v157, -4.0, v150, 4.0                      ; d669009d 03db2cf7
	v_dual_mul_f32 v119, v119, v137 :: v_dual_mul_f32 v118, v118, v136 ; c8c71377 77771176
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v159, -4.0, v151, 4.0                      ; d669009f 03db2ef7
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_mul_f32 v145, v145, v142 :: v_dual_mul_f32 v144, v144, v139 ; c8c71d91 91911790
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v176, 4.0                      ; d66900a1 03db60f7
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v163, -4.0, v177, 4.0                      ; d66900a3 03db62f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v145, -4.0, v147, 4.0                      ; d6690091 03db26f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v178, 4.0                      ; d66900a5 03db64f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v179, 4.0                      ; d66900a7 03db66f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 ; c843419f 9f9f3b9e 3f650000
	v_dual_mul_f32 v149, v149, v155 :: v_dual_mul_f32 v148, v148, v154 ; c8c73795 95953594
	v_fma_mix_f32 v152, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff22ff 3728ab28
	v_maxmin_num_f32 v169, -4.0, v180, 4.0                      ; d66900a9 03db68f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v181, 4.0                      ; d66900ab 03db6af7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 ; c84345a1 a1a547a4 3f650000
	v_dual_mul_f32 v151, v151, v159 :: v_dual_mul_f32 v150, v150, v158 ; c8c73f97 97973d96
	v_maxmin_num_f32 v173, -4.0, v182, 4.0                      ; d66900ad 03db6cf7
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_dual_fmaak_f32 v143, v143, v144, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v145, 0x3f650000 ; c843218f 8f992398 3f650000
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_maxmin_num_f32 v175, -4.0, v183, 4.0                      ; d66900af 03db6ef7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 ; c8434da5 a5a94fa8 3f650000
	v_dual_mul_f32 v177, v177, v164 :: v_dual_mul_f32 v176, v176, v161 ; c8c749b1 b1b143b0
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_mul_f32 v147, v147, v152 :: v_dual_mul_f32 v146, v146, v143 ; c8c73193 93931f92
	v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 ; c84359ab abab53aa 3f650000
	v_dual_mul_f32 v179, v179, v168 :: v_dual_mul_f32 v178, v178, v165 ; c8c751b3 b3b34bb2
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_maxmin_num_f32 v177, -4.0, v14, 4.0                       ; d66900b1 03da1cf7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_dual_fmaak_f32 v174, v174, v173, 0x3f650000 :: v_dual_mul_f32 v181, v181, v171 ; c8475bae aeb557b5 3f650000
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_maxmin_num_f32 v179, -4.0, v15, 4.0                       ; d66900b3 03da1ef7
	v_maxmin_num_f32 v185, -4.0, v18, 4.0                       ; d66900b9 03da24f7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v187, -4.0, v19, 4.0                       ; d66900bb 03da26f7
	v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 :: v_dual_mul_f32 v182, v182, v174 ; c84761af afb75db6 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_dual_fmaak_f32 v177, v178, v177, 0x3f650000 :: v_dual_mul_f32 v180, v180, v170 ; c84763b2 b1b555b4 3f650000
	v_maxmin_num_f32 v189, -4.0, v20, 4.0                       ; d66900bd 03da28f7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_maxmin_num_f32 v181, -4.0, v16, 4.0                       ; d66900b5 03da20f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_dual_mul_f32 v183, v183, v175 :: v_dual_mul_f32 v14, v14, v177 ; c8c75fb7 b70f630e
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v21, 4.0                       ; d66900bf 03da2af7
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[74:75], 0 ; cc464050 1a029528
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[60:61], 0 ; cc464058 1a027928
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_maxmin_num_f32 v183, -4.0, v17, 4.0                       ; d66900b7 03da22f7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[50:51], 0 ; cc464060 1a026528
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[52:53], 0 ; cc464068 1a026928
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 ; c8436db5 b5b567b4 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[74:75], 0 ; cc464070 1a02952a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[60:61], 0 ; cc464078 1a02792a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[50:51], 0 ; cc464080 1a02652a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[52:53], 0 ; cc464088 1a02692a
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_mul_f32 v15, v15, v180 ; c8476fb8 b80f690f 3f650000
	v_mul_f32_e32 v16, v16, v181                                ; 10216b10
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[64:65], v[50:51], 0 ; cc4640a0 1a026540
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[64:65], v[74:75], 0 ; cc464090 1a029540
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
	v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 :: v_dual_mul_f32 v17, v17, v184 ; c84773ba ba117111 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[60:61], 0 ; cc464098 1a027940
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[64:65], v[52:53], 0 ; cc4640a8 1a026940
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_fma_mix_f32 v16, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206210 0bff7eff 3728ab28
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_mul_f32 v18, v18, v186 ; c84779bb bb137512 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[66:67], v[74:75], 0 ; cc4640b0 1a029542
	v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 :: v_dual_mul_f32 v19, v19, v187 ; c8477bbe be137713 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v20, v20, v190 :: v_dual_fmaak_f32 v191, v191, v16, 0x3f650000 ; c8c37d14 14be21bf 3f650000
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_dual_mul_f32 v21, v21, v191 :: v_dual_mov_b32 v40, v14    ; c8d17f15 1528010e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[66:67], v[60:61], 0 ; cc4640b8 1a027942
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mov_b32 v41, v15 :: v_dual_mov_b32 v42, v58          ; ca10010f 292a013a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[66:67], v[50:51], 0 ; cc46400e 1a026542
	s_wait_dscnt 0x3                                            ; bfc60003
	v_dual_mov_b32 v50, v62 :: v_dual_mov_b32 v43, v59          ; ca10013e 322a013b
	v_dual_mov_b32 v26, v72 :: v_dual_mov_b32 v51, v63          ; ca100148 1a32013f
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[66:67], v[52:53], 0 ; cc46403a 1a026942
	v_mov_b32_e32 v52, v73                                      ; 7e680349
	buffer_load_b128 v[72:75], v73, s[36:39], null offen offset:512 ; c405c07c 40804848 00020049
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[54:55], v[128:135] ; cc464080 1e026d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[56:57], v[88:95] ; cc464058 1d627148
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[50:51], v[80:87] ; cc464050 1d426548
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[22:23], v[136:143] ; cc464088 1e222d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[50:51], v[112:119] ; cc464070 1dc2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[54:55], v[96:103] ; cc464060 1d826d48
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[22:23], v[104:111] ; cc464068 1da22d48
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[56:57], v[120:127] ; cc464078 1de2714a
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:512 ; c405c07c 40804848 00020018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[56:57], v[184:191] ; cc4640b8 1ee2714a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[54:55], v[14:21] ; cc46400e 1c3a6d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[54:55], v[160:167] ; cc4640a0 1e826d48
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[50:51], v[144:151] ; cc464090 1e426548
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[50:51], v[176:183] ; cc4640b0 1ec2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[56:57], v[152:159] ; cc464098 1e627148
	ds_load_b64 v[66:67], v26 offset:512                        ; d9d80200 4200001a
	ds_load_b64 v[50:51], v26 offset:2560                       ; d9d80a00 3200001a
	ds_load_b64 v[56:57], v26 offset:4608                       ; d9d81200 3800001a
	ds_load_b64 v[54:55], v26 offset:6656                       ; d9d81a00 3600001a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[22:23], v[168:175] ; cc4640a8 1ea22d48
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[22:23], v[58:65] ; cc46403a 1cea2d4a
	buffer_load_b128 v[72:75], v52, s[36:39], null offen offset:1024 ; c405c07c 40804848 00040034
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[54:55], v[104:111] ; cc464068 1da26d48
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[66:67], v[112:119] ; cc464070 1dc2854a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[50:51], v[120:127] ; cc464078 1de2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[56:57], v[128:135] ; cc464080 1e02714a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[66:67], v[80:87] ; cc464050 1d428548
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[56:57], v[96:103] ; cc464060 1d827148
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[50:51], v[88:95] ; cc464058 1d626548
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[54:55], v[136:143] ; cc464088 1e226d4a
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:1024 ; c405c07c 40804848 00040018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[50:51], v[184:191] ; cc4640b8 1ee2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[50:51], v[152:159] ; cc464098 1e626548
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[56:57], v[160:167] ; cc4640a0 1e827148
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[56:57], v[14:21] ; cc46400e 1c3a714a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[66:67], v[176:183] ; cc4640b0 1ec2854a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[66:67], v[144:151] ; cc464090 1e428548
	ds_load_b64 v[22:23], v26 offset:768                        ; d9d80300 1600001a
	ds_load_b64 v[66:67], v26 offset:2816                       ; d9d80b00 4200001a
	ds_load_b64 v[50:51], v26 offset:4864                       ; d9d81300 3200001a
	ds_load_b64 v[56:57], v26 offset:6912                       ; d9d81b00 3800001a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[54:55], v[168:175] ; cc4640a8 1ea26d48
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[54:55], v[58:65] ; cc46403a 1cea6d4a
	buffer_load_b128 v[72:75], v52, s[36:39], null offen offset:1536 ; c405c07c 40804848 00060034
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[56:57], v[104:111] ; cc464068 1da27148
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[22:23], v[112:119] ; cc464070 1dc22d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[66:67], v[120:127] ; cc464078 1de2854a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[50:51], v[128:135] ; cc464080 1e02654a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[56:57], v[136:143] ; cc464088 1e22714a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[22:23], v[80:87] ; cc464050 1d422d48
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[66:67], v[88:95] ; cc464058 1d628548
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[50:51], v[96:103] ; cc464060 1d826548
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:1536 ; c405c07c 40804848 00060018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[66:67], v[184:191] ; cc4640b8 1ee2854a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[50:51], v[14:21] ; cc46400e 1c3a654a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[22:23], v[144:151] ; cc464090 1e422d48
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[50:51], v[160:167] ; cc4640a0 1e826548
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[66:67], v[152:159] ; cc464098 1e628548
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[22:23], v[176:183] ; cc4640b0 1ec22d4a
	ds_load_b64 v[54:55], v26 offset:1024                       ; d9d80400 3600001a
	ds_load_b64 v[22:23], v26 offset:3072                       ; d9d80c00 1600001a
	ds_load_b64 v[66:67], v26 offset:5120                       ; d9d81400 4200001a
	ds_load_b64 v[50:51], v26 offset:7168                       ; d9d81c00 3200001a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[56:57], v[168:175] ; cc4640a8 1ea27148
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[56:57], v[58:65] ; cc46403a 1cea714a
	buffer_load_b128 v[72:75], v52, s[36:39], null offen offset:2048 ; c405c07c 40804848 00080034
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[50:51], v[104:111] ; cc464068 1da26548
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[54:55], v[112:119] ; cc464070 1dc26d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[22:23], v[120:127] ; cc464078 1de22d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[66:67], v[128:135] ; cc464080 1e02854a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[50:51], v[136:143] ; cc464088 1e22654a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[66:67], v[96:103] ; cc464060 1d828548
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[54:55], v[80:87] ; cc464050 1d426d48
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[22:23], v[88:95] ; cc464058 1d622d48
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:2048 ; c405c07c 40804848 00080018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[22:23], v[184:191] ; cc4640b8 1ee22d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[66:67], v[160:167] ; cc4640a0 1e828548
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[66:67], v[14:21] ; cc46400e 1c3a854a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[54:55], v[144:151] ; cc464090 1e426d48
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[54:55], v[176:183] ; cc4640b0 1ec26d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[22:23], v[152:159] ; cc464098 1e622d48
	ds_load_b64 v[56:57], v26 offset:1280                       ; d9d80500 3800001a
	ds_load_b64 v[54:55], v26 offset:3328                       ; d9d80d00 3600001a
	ds_load_b64 v[22:23], v26 offset:5376                       ; d9d81500 1600001a
	ds_load_b64 v[66:67], v26 offset:7424                       ; d9d81d00 4200001a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[50:51], v[168:175] ; cc4640a8 1ea26548
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[50:51], v[58:65] ; cc46403a 1cea654a
	buffer_load_b128 v[72:75], v52, s[36:39], null offen offset:2560 ; c405c07c 40804848 000a0034
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[66:67], v[104:111] ; cc464068 1da28548
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[56:57], v[112:119] ; cc464070 1dc2714a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[54:55], v[120:127] ; cc464078 1de26d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[22:23], v[128:135] ; cc464080 1e022d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[66:67], v[136:143] ; cc464088 1e22854a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[22:23], v[96:103] ; cc464060 1d822d48
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[56:57], v[80:87] ; cc464050 1d427148
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[54:55], v[88:95] ; cc464058 1d626d48
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:2560 ; c405c07c 40804848 000a0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[54:55], v[184:191] ; cc4640b8 1ee26d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[22:23], v[160:167] ; cc4640a0 1e822d48
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[22:23], v[14:21] ; cc46400e 1c3a2d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[56:57], v[144:151] ; cc464090 1e427148
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[56:57], v[176:183] ; cc4640b0 1ec2714a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[54:55], v[152:159] ; cc464098 1e626d48
	ds_load_b64 v[50:51], v26 offset:1536                       ; d9d80600 3200001a
	ds_load_b64 v[56:57], v26 offset:3584                       ; d9d80e00 3800001a
	ds_load_b64 v[54:55], v26 offset:5632                       ; d9d81600 3600001a
	ds_load_b64 v[22:23], v26 offset:7680                       ; d9d81e00 1600001a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[66:67], v[168:175] ; cc4640a8 1ea28548
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[66:67], v[58:65] ; cc46403a 1cea854a
	buffer_load_b128 v[72:75], v52, s[36:39], null offen offset:3072 ; c405c07c 40804848 000c0034
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[22:23], v[104:111] ; cc464068 1da22d48
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[50:51], v[112:119] ; cc464070 1dc2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[56:57], v[120:127] ; cc464078 1de2714a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[54:55], v[128:135] ; cc464080 1e026d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[22:23], v[136:143] ; cc464088 1e222d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[54:55], v[96:103] ; cc464060 1d826d48
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[50:51], v[80:87] ; cc464050 1d426548
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[56:57], v[88:95] ; cc464058 1d627148
	buffer_load_b128 v[72:75], v24, s[36:39], null offen offset:3072 ; c405c07c 40804848 000c0018
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[56:57], v[184:191] ; cc4640b8 1ee2714a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[54:55], v[160:167] ; cc4640a0 1e826d48
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[22:23], v[168:175] ; cc4640a8 1ea22d48
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[50:51], v[144:151] ; cc464090 1e426548
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[50:51], v[176:183] ; cc4640b0 1ec2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[56:57], v[152:159] ; cc464098 1e627148
	ds_load_b64 v[66:67], v26 offset:1792                       ; d9d80700 4200001a
	ds_load_b64 v[50:51], v26 offset:3840                       ; d9d80f00 3200001a
	ds_load_b64 v[56:57], v26 offset:5888                       ; d9d81700 3800001a
	ds_load_b64 v[72:73], v26 offset:7936                       ; d9d81f00 4800001a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[74:75], v[54:55], v[14:21] ; cc46400e 1c3a6d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[74:75], v[22:23], v[58:65] ; cc46403a 1cea2d4a
	v_mov_b32_e32 v74, v25                                      ; 7e940319
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[52:55], v52, s[36:39], null offen offset:3584 ; c405c07c 40804834 000e0034
	buffer_load_b128 v[22:25], v24, s[36:39], null offen offset:3584 ; c405c07c 40804816 000e0018
	s_wait_loadcnt_dscnt 0x103                                  ; bfc80103
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[66:67], v[112:119] ; cc464070 1dc28536
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[50:51], v[88:95] ; cc464058 1d626534
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[50:51], v[120:127] ; cc464078 1de26536
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[56:57], v[96:103] ; cc464060 1d827134
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[56:57], v[128:135] ; cc464080 1e027136
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[72:73], v[104:111] ; cc464068 1da29134
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[52:53], v[66:67], v[80:87] ; cc464050 1d428534
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[54:55], v[72:73], v[136:143] ; cc464088 1e229136
	v_maxmin_num_f32 v75, -4.0, v80, 4.0                        ; d669004b 03daa0f7
	v_maxmin_num_f32 v52, -4.0, v81, 4.0                        ; d6690034 03daa2f7
	v_maxmin_num_f32 v54, -4.0, v82, 4.0                        ; d6690036 03daa4f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v26, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe96ff 3728ab28
	v_fma_mix_f32 v53, 0xab28, |v52|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206235 0bfe68ff 3728ab28
	v_fma_mix_f32 v55, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe6cff 3728ab28
	v_fmaak_f32 v75, v75, v26, 0x3f650000                       ; 5a96354b 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmaak_f32 v53, v53, v52, 0x3f650000 :: v_dual_mul_f32 v80, v80, v75 ; c8466935 35509750 3f650000
	v_maxmin_num_f32 v75, -4.0, v83, 4.0                        ; d669004b 03daa6f7
	v_dual_mul_f32 v81, v81, v53 :: v_dual_fmaak_f32 v54, v54, v55, 0x3f650000 ; c8c26b51 51366f36 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v81, -4.0, v84, 4.0                        ; d6690051 03daa8f7
	v_fma_mix_f32 v80, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe96ff 3728ab28
	v_fmaak_f32 v80, v80, v75, 0x3f650000                       ; 5aa09750 3f650000
	v_maxmin_num_f32 v75, -4.0, v87, 4.0                        ; d669004b 03daaef7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v83, v83, v80 :: v_dual_mul_f32 v82, v82, v54 ; c8c6a153 53526d52
	v_maxmin_num_f32 v54, -4.0, v86, 4.0                        ; d6690036 03daacf7
	v_fma_mix_f32 v80, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe96ff 3728ab28
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v83, -4.0, v85, 4.0                        ; d6690053 03daaaf7
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_fma_mix_f32 v55, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe6cff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v26, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfea6ff 3728ab28
	v_dual_fmaak_f32 v55, v55, v54, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 ; c8426d37 3752a352 3f650000
	v_maxmin_num_f32 v81, -4.0, v88, 4.0                        ; d6690051 03dab0f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fmaak_f32 v83, v83, v26, 0x3f650000                       ; 5aa63553 3f650000
	v_dual_fmaak_f32 v75, v75, v80, 0x3f650000 :: v_dual_mul_f32 v86, v86, v55 ; c846a14b 4b566f56 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_mul_f32_e32 v85, v85, v83                                 ; 10aaa755
	v_maxmin_num_f32 v83, -4.0, v89, 4.0                        ; d6690053 03dab2f7
	v_dual_mul_f32 v87, v87, v75 :: v_dual_mul_f32 v84, v84, v82 ; c8c69757 5754a554
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v85, -4.0, v90, 4.0                        ; d6690055 03dab4f7
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v87, -4.0, v91, 4.0                        ; d6690057 03dab6f7
	v_maxmin_num_f32 v75, -4.0, v94, 4.0                        ; d669004b 03dabcf7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 ; c842a551 5154a754 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v80, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe96ff 3728ab28
	v_dual_mul_f32 v89, v89, v84 :: v_dual_mul_f32 v88, v88, v81 ; c8c6a959 5958a358
	v_maxmin_num_f32 v81, -4.0, v95, 4.0                        ; d6690051 03dabef7
	v_maxmin_num_f32 v83, -4.0, v96, 4.0                        ; d6690053 03dac0f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d3
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v89, -4.0, v92, 4.0                        ; d6690059 03dab8f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af58 5854ad55 3f650000
	v_maxmin_num_f32 v87, -4.0, v98, 4.0                        ; d6690057 03dac4f7
	v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v75, 0x3f650000 ; c842a551 51509750 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v91, v91, v88 :: v_dual_mul_f32 v90, v90, v85 ; c8c6b15b 5b5aab5a
	v_maxmin_num_f32 v85, -4.0, v97, 4.0                        ; d6690055 03dac2f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_mul_f32 v95, v95, v81 :: v_dual_mul_f32 v94, v94, v80 ; c8c6a35f 5f5ea15e
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v93, 4.0                        ; d669005b 03dabaf7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v26, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v83, v83, v84, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842a953 5356ab56 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v91, v91, v26, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842355b 5b5ab35a 3f650000
	v_maxmin_num_f32 v89, -4.0, v99, 4.0                        ; d6690059 03dac6f7
	v_dual_mul_f32 v97, v97, v86 :: v_dual_mul_f32 v96, v96, v83 ; c8c6ad61 6160a760
	v_dual_mul_f32 v93, v93, v91 :: v_dual_mul_f32 v92, v92, v90 ; c8c6b75d 5d5cb55c
	v_maxmin_num_f32 v91, -4.0, v100, 4.0                       ; d669005b 03dac8f7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v103, 4.0                       ; d6690061 03dacef7
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v93, -4.0, v101, 4.0                       ; d669005d 03dacaf7
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v102, 4.0                       ; d669005f 03daccf7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b157 575ab35a 3f650000
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_dual_mul_f32 v99, v99, v90 :: v_dual_mul_f32 v98, v98, v87 ; c8c6b563 6362af62
	v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842bd5d 5d5cb75c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v104, 4.0                       ; d6690063 03dad0f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_mul_f32 v101, v101, v93 :: v_dual_mul_f32 v100, v100, v92 ; c8c6bb65 6564b964
	v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842c561 6160bf60 3f650000
	v_maxmin_num_f32 v75, -4.0, v108, 4.0                       ; d669004b 03dad8f7
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v101, -4.0, v105, 4.0                      ; d6690065 03dad2f7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v84, -4.0, v109, 4.0                       ; d6690054 03dadaf7
	v_dual_mul_f32 v103, v103, v97 :: v_dual_mul_f32 v102, v102, v96 ; c8c6c367 6766c166
	v_fma_mix_f32 v83, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfe96ff 3728ab28
	v_maxmin_num_f32 v86, -4.0, v110, 4.0                       ; d6690056 03dadcf7
	v_maxmin_num_f32 v88, -4.0, v111, 4.0                       ; d6690058 03dadef7
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v103, -4.0, v106, 4.0                      ; d6690067 03dad4f7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v90, -4.0, v112, 4.0                       ; d669005a 03dae0f7
	v_maxmin_num_f32 v92, -4.0, v113, 4.0                       ; d669005c 03dae2f7
	v_dual_fmaak_f32 v83, v83, v75, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v85, 0x3f650000 ; c8429753 5354ab54 3f650000
	v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 :: v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 ; c842cb66 6662c963 3f650000
	v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 :: v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 ; c842b358 5856ad57 3f650000
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_maxmin_num_f32 v94, -4.0, v114, 4.0                       ; d669005e 03dae4f7
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v96, -4.0, v115, 4.0                       ; d6690060 03dae6f7
	v_dual_mul_f32 v109, v109, v84 :: v_dual_mul_f32 v108, v108, v83 ; c8c6a96d 6d6ca76c
	v_dual_mul_f32 v105, v105, v102 :: v_dual_mul_f32 v104, v104, v99 ; c8c6cd69 6968c768
	v_dual_mul_f32 v111, v111, v88 :: v_dual_mul_f32 v110, v110, v87 ; c8c6b16f 6f6eaf6e
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_maxmin_num_f32 v98, -4.0, v116, 4.0                       ; d6690062 03dae8f7
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 ; c842b95d 5d5ab75a 3f650000
	v_maxmin_num_f32 v100, -4.0, v117, 4.0                      ; d6690064 03daeaf7
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v105, -4.0, v107, 4.0                      ; d6690069 03dad6f7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v102, -4.0, v118, 4.0                      ; d6690066 03daecf7
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_dual_mul_f32 v113, v113, v93 :: v_dual_mul_f32 v112, v112, v90 ; c8c6bb71 7170b570
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c842c161 615ebf5e 3f650000
	v_fma_mix_f32 v26, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfed2ff 3728ab28
	v_maxmin_num_f32 v108, -4.0, v121, 4.0                      ; d669006c 03daf2f7
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c842c563 6364cb64 3f650000
	v_dual_mul_f32 v115, v115, v97 :: v_dual_mul_f32 v114, v114, v94 ; c8c6c373 7372bd72
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[22:23], v[66:67], v[144:151] ; cc464090 1e428516
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[22:23], v[50:51], v[152:159] ; cc464098 1e626516
	v_dual_fmaak_f32 v26, v26, v105, 0x3f650000 :: v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 ; c842d31a 1a66d167 3f650000
	v_maxmin_num_f32 v104, -4.0, v119, 4.0                      ; d6690068 03daeef7
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_dual_mul_f32 v117, v117, v100 :: v_dual_mul_f32 v116, v116, v99 ; c8c6c975 7574c774
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[22:23], v[56:57], v[160:167] ; cc4640a0 1e827116
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[72:73], v[168:175] ; cc4640a8 1ea29116
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[24:25], v[66:67], v[176:183] ; cc4640b0 1ec28518
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[24:25], v[50:51], v[184:191] ; cc4640b8 1ee26518
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[24:25], v[56:57], v[14:21] ; cc46400e 1c3a7118
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[24:25], v[72:73], v[58:65] ; cc46403a 1cea9118
	v_dual_mul_f32 v107, v107, v26 :: v_dual_mul_f32 v106, v106, v103 ; c8c6356b 6b6acf6a
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v110, -4.0, v122, 4.0                      ; d669006e 03daf4f7
	v_maxmin_num_f32 v112, -4.0, v123, 4.0                      ; d6690070 03daf6f7
	v_maxmin_num_f32 v114, -4.0, v124, 4.0                      ; d6690072 03daf8f7
	v_maxmin_num_f32 v116, -4.0, v125, 4.0                      ; d6690074 03dafaf7
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v106, -4.0, v120, 4.0                      ; d669006a 03daf0f7
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 ; c842cd67 6768d368 3f650000
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_dual_mul_f32 v119, v119, v104 :: v_dual_mul_f32 v118, v118, v103 ; c8c6d177 7776cf76
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c842e573 7374eb74 3f650000
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v107, 0x3f650000 ; c842d96d 6d6ad76a 3f650000
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v126, 4.0                      ; d6690076 03dafcf7
	v_dual_mul_f32 v123, v123, v113 :: v_dual_mul_f32 v122, v122, v110 ; c8c6e37b 7b7add7a
	v_dual_mul_f32 v125, v125, v116 :: v_dual_mul_f32 v124, v124, v115 ; c8c6e97d 7d7ce77c
	v_dual_mul_f32 v121, v121, v109 :: v_dual_mul_f32 v120, v120, v106 ; c8c6db79 7978d578
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v129, 4.0                      ; d669007c 03db02f7
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v127, 4.0                      ; d6690078 03dafef7
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v122, -4.0, v128, 4.0                      ; d669007a 03db00f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v119, v119, v118, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c842ed77 7778f378 3f650000
	v_maxmin_num_f32 v25, -4.0, v133, 4.0                       ; d6690019 03db0af7
	v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 ; c842f97d 7d7af77a 3f650000
	v_dual_mul_f32 v127, v127, v120 :: v_dual_mul_f32 v126, v126, v119 ; c8c6f17f 7f7eef7e
	v_fma_mix_f32 v26, 0xab28, |v25|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe32ff 3728ab28
	v_maxmin_num_f32 v50, -4.0, v134, 4.0                       ; d6690032 03db0cf7
	v_dual_mul_f32 v129, v129, v125 :: v_dual_mul_f32 v128, v128, v122 ; c8c6fb81 8180f580
	v_maxmin_num_f32 v56, -4.0, v135, 4.0                       ; d6690038 03db0ef7
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v130, 4.0                      ; d669007e 03db04f7
	v_maxmin_num_f32 v66, -4.0, v136, 4.0                       ; d6690042 03db10f7
	v_fma_mix_f32 v51, 0xab28, |v50|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206233 0bfe64ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v128, -4.0, v131, 4.0                      ; d6690080 03db06f7
	v_fma_mix_f32 v57, 0xab28, |v56|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206239 0bfe70ff 3728ab28
	v_maxmin_num_f32 v75, -4.0, v138, 4.0                       ; d669004b 03db14f7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_fma_mix_f32 v67, 0xab28, |v66|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206243 0bfe84ff 3728ab28
	v_maxmin_num_f32 v72, -4.0, v137, 4.0                       ; d6690048 03db12f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v139, 4.0                       ; d6690057 03db16f7
	v_dual_fmaak_f32 v51, v51, v50, 0x3f650000 :: v_dual_fmaak_f32 v56, v56, v57, 0x3f650000 ; c8426533 33387338 3f650000
	v_fma_mix_f32 v86, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfe96ff 3728ab28
	v_fma_mix_f32 v73, 0xab28, |v72|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206249 0bfe90ff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v140, 4.0                       ; d6690059 03db18f7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v127, 0x3f650000 ; c8430181 817eff7e 3f650000
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v66, v66, v67, 0x3f650000 :: v_dual_mul_f32 v135, v135, v56 ; c8468742 42867187 3f650000
	v_maxmin_num_f32 v91, -4.0, v141, 4.0                       ; d669005b 03db1af7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v142, 4.0                       ; d669005d 03db1cf7
	v_dual_mul_f32 v131, v131, v129 :: v_dual_mul_f32 v130, v130, v126 ; c8c70383 8382fd82
	v_dual_fmaak_f32 v75, v86, v75, 0x3f650000 :: v_dual_mul_f32 v136, v136, v66 ; c8469756 4b888588 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v144, 4.0                       ; d6690061 03db20f7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v130, -4.0, v132, 4.0                      ; d6690082 03db08f7
	v_dual_mul_f32 v138, v138, v75 :: v_dual_fmaak_f32 v73, v73, v72, 0x3f650000 ; c8c2978a 8a489149 3f650000
	v_maxmin_num_f32 v95, -4.0, v143, 4.0                       ; d669005f 03db1ef7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 :: v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 ; c842bb5e 5e5ab95b 3f650000
	v_maxmin_num_f32 v99, -4.0, v145, 4.0                       ; d6690063 03db22f7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v146, 4.0                      ; d6690065 03db24f7
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_mul_f32 v137, v137, v73 ; c846af58 58889389 3f650000
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_dual_mul_f32 v142, v142, v94 :: v_dual_mul_f32 v141, v141, v91 ; c8c6bd8e 8e8cb78d
	v_maxmin_num_f32 v103, -4.0, v147, 4.0                      ; d6690067 03db26f7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_fmaak_f32 v131, v131, v130, 0x3f650000                    ; 5b070583 3f650000
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 :: v_dual_mul_f32 v139, v139, v88 ; c846b35a 5a8ab18b 3f650000
	v_maxmin_num_f32 v105, -4.0, v148, 4.0                      ; d6690069 03db28f7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v149, 4.0                      ; d669006b 03db2af7
	v_dual_fmaak_f32 v25, v25, v26, 0x3f650000 :: v_dual_mul_f32 v132, v132, v131 ; c8463519 19850784 3f650000
	v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 :: v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 ; c842c764 6464cd65 3f650000
	v_maxmin_num_f32 v109, -4.0, v150, 4.0                      ; d669006d 03db2cf7
	v_dual_fmaak_f32 v97, v98, v97, 0x3f650000 :: v_dual_mul_f32 v140, v140, v90 ; c846c362 618cb58c 3f650000
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_maxmin_num_f32 v113, -4.0, v152, 4.0                      ; d6690071 03db30f7
	v_dual_mul_f32 v133, v133, v25 :: v_dual_mul_f32 v134, v134, v51 ; c8c63385 85866786
	v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 :: v_dual_mul_f32 v145, v145, v100 ; c846cf68 6890c991 3f650000
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_maxmin_num_f32 v111, -4.0, v151, 4.0                      ; d669006f 03db2ef7
	v_dual_mul_f32 v144, v144, v97 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c8c2c390 905ec15f 3f650000
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v115, -4.0, v153, 4.0                      ; d6690073 03db32f7
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v117, -4.0, v154, 4.0                      ; d6690075 03db34f7
	v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 :: v_dual_mul_f32 v147, v147, v104 ; c846d36a 6a92d193 3f650000
	v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 :: v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 ; c842db6e 6e6ad96b 3f650000
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v155, 4.0                      ; d6690077 03db36f7
	v_dual_mul_f32 v146, v146, v101 :: v_dual_mul_f32 v143, v143, v95 ; c8c6cb92 928ebf8f
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v156, 4.0                      ; d6690079 03db38f7
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_dual_fmaak_f32 v113, v114, v113, 0x3f650000 :: v_dual_mul_f32 v148, v148, v106 ; c846e372 7194d594 3f650000
	v_dual_mul_f32 v150, v150, v110 :: v_dual_mul_f32 v149, v149, v107 ; c8c6dd96 9694d795
	v_maxmin_num_f32 v123, -4.0, v157, 4.0                      ; d669007b 03db3af7
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v158, 4.0                      ; d669007d 03db3cf7
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842e774 7474ed75 3f650000
	v_maxmin_num_f32 v129, -4.0, v160, 4.0                      ; d6690081 03db40f7
	v_dual_mul_f32 v152, v152, v113 :: v_dual_fmaak_f32 v111, v111, v112, 0x3f650000 ; c8c2e398 986ee16f 3f650000
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v159, 4.0                      ; d669007f 03db3ef7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v161, 4.0                      ; d6690083 03db42f7
	v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 :: v_dual_mul_f32 v153, v153, v116 ; c846ef78 7898e999 3f650000
	v_maxmin_num_f32 v133, -4.0, v162, 4.0                      ; d6690085 03db44f7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_dual_mul_f32 v154, v154, v117 :: v_dual_mul_f32 v151, v151, v111 ; c8c6eb9a 9a96df97
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v163, 4.0                      ; d6690087 03db46f7
	v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 ; c842fb7e 7e7af97b 3f650000
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 :: v_dual_mul_f32 v155, v155, v120 ; c846f37a 7a9af19b 3f650000
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v137, -4.0, v164, 4.0                      ; d6690089 03db48f7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_maxmin_num_f32 v139, -4.0, v165, 4.0                      ; d669008b 03db4af7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_dual_mul_f32 v158, v158, v126 :: v_dual_mul_f32 v157, v157, v123 ; c8c6fd9e 9e9cf79d
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v141, -4.0, v166, 4.0                      ; d669008d 03db4cf7
	v_dual_fmaak_f32 v129, v130, v129, 0x3f650000 :: v_dual_mul_f32 v156, v156, v122 ; c8470382 819cf59c 3f650000
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	s_lshr_b32 s16, s16, 2                                      ; 85108210
	v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430784 84850d85 3f650000
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_mul_f32 v161, v161, v132 ; c8470f88 88a109a1 3f650000
	v_dual_fmaak_f32 v142, v141, v142, 0x3f650000 :: v_dual_lshlrev_b32 v143, 10, v1 ; c8631d8d 8e8e028a 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 :: v_dual_mul_f32 v163, v163, v136 ; c847138a 8aa311a3 3f650000
	v_add3_u32 v144, v74, s16, v143                             ; d6550090 063c214a
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 :: v_dual_mul_f32 v164, v164, v138 ; c847198b 8ba515a4 3f650000
	v_dual_mul_f32 v165, v165, v139 :: v_dual_lshlrev_b32 v144, 2, v144 ; c8e317a5 a5912082
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[88:91], v144, s[36:39], null offen       ; c405c07c 40804858 00000090
	buffer_load_b128 v[92:95], v144, s[36:39], null offen offset:512 ; c405c07c 4080485c 00020090
	v_maxmin_num_f32 v145, -4.0, v167, 4.0                      ; d6690091 03db4ef7
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_dual_mul_f32 v160, v160, v129 :: v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 ; c8c303a0 a07f017f 3f650000
	v_maxmin_num_f32 v147, -4.0, v168, 4.0                      ; d6690093 03db50f7
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_maxmin_num_f32 v149, -4.0, v169, 4.0                      ; d6690095 03db52f7
	v_maxmin_num_f32 v151, -4.0, v170, 4.0                      ; d6690097 03db54f7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_maxmin_num_f32 v153, -4.0, v171, 4.0                      ; d6690099 03db56f7
	v_dual_mul_f32 v162, v162, v133 :: v_dual_mul_f32 v159, v159, v127 ; c8c70ba2 a29eff9f
	buffer_load_b128 v[96:99], v144, s[36:39], null offen offset:1024 ; c405c07c 40804860 00040090
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v172, 4.0                      ; d669009b 03db58f7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_fmaak_f32 v145, v145, v146, 0x3f650000                    ; 5b232591 3f650000
	v_maxmin_num_f32 v157, -4.0, v173, 4.0                      ; d669009d 03db5af7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	buffer_load_b128 v[100:103], v144, s[36:39], null offen offset:1536 ; c405c07c 40804864 00060090
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_dual_fmaak_f32 v147, v147, v148, 0x3f650000 :: v_dual_mul_f32 v166, v166, v142 ; c8472993 93a71da6 3f650000
	v_maxmin_num_f32 v159, -4.0, v174, 4.0                      ; d669009f 03db5cf7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_fmaak_f32 v151, v151, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v149, 0x3f650000 ; c8433197 97972b96 3f650000
	v_maxmin_num_f32 v161, -4.0, v175, 4.0                      ; d66900a1 03db5ef7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_fmaak_f32 v154, v154, v153, 0x3f650000                    ; 5b35339a 3f650000
	buffer_load_b128 v[104:107], v144, s[36:39], null offen offset:2048 ; c405c07c 40804868 00080090
	v_dual_mul_f32 v167, v167, v145 :: v_dual_mul_f32 v168, v168, v147 ; c8c723a7 a7a927a8
	v_maxmin_num_f32 v163, -4.0, v176, 4.0                      ; d66900a3 03db60f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_dual_mul_f32 v170, v170, v151 :: v_dual_mul_f32 v169, v169, v150 ; c8c72faa aaa92da9
	v_maxmin_num_f32 v165, -4.0, v177, 4.0                      ; d66900a5 03db62f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 ; c8433d9d 9d9d379c 3f650000
	v_mul_f32_e32 v171, v171, v154                              ; 115735ab
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	buffer_load_b128 v[112:115], v144, s[36:39], null offen offset:2560 ; c405c07c 40804870 000a0090
	v_maxmin_num_f32 v167, -4.0, v178, 4.0                      ; d66900a7 03db64f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 ; c84345a1 a1a13fa0 3f650000
	v_maxmin_num_f32 v169, -4.0, v179, 4.0                      ; d66900a9 03db66f7
	v_dual_mul_f32 v173, v173, v157 :: v_dual_mul_f32 v172, v172, v156 ; c8c73bad adad39ac
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_maxmin_num_f32 v171, -4.0, v180, 4.0                      ; d66900ab 03db68f7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	buffer_load_b128 v[116:119], v144, s[36:39], null offen offset:3072 ; c405c07c 40804874 000c0090
	v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 :: v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 ; c8434ba6 a6a349a3 3f650000
	v_dual_mul_f32 v175, v175, v161 :: v_dual_mul_f32 v174, v174, v160 ; c8c743af afaf41ae
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_maxmin_num_f32 v173, -4.0, v181, 4.0                      ; d66900ad 03db6af7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_fmaak_f32 v167, v167, v168, 0x3f650000                    ; 5b4f51a7 3f650000
	v_dual_mul_f32 v177, v177, v166 :: v_dual_mul_f32 v176, v176, v163 ; c8c74db1 b1b147b0
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	buffer_load_b128 v[120:123], v144, s[36:39], null offen offset:3584 ; c405c07c 40804878 000e0090
	v_maxmin_num_f32 v175, -4.0, v182, 4.0                      ; d66900af 03db6cf7
	v_fmaak_f32 v170, v170, v169, 0x3f650000                    ; 5b5553aa 3f650000
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_fmaak_f32 v172, v172, v171, 0x3f650000                    ; 5b5957ac 3f650000
	v_mul_f32_e32 v178, v178, v167                              ; 11654fb2
(invalid instruction)                                        ; d769006c
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_maxmin_num_f32 v177, -4.0, v183, 4.0                      ; d66900b1 03db6ef7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_dual_mul_f32 v180, v180, v172 :: v_dual_mul_f32 v179, v179, v170 ; c8c759b4 b4b355b3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870242
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 ; c8435fb0 b0ad5dad 3f650000
(invalid instruction)                                        ; d769406c
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_maxmin_num_f32 v179, -4.0, v184, 4.0                      ; d66900b3 03db70f7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_dual_mul_f32 v182, v182, v176 :: v_dual_mul_f32 v181, v181, v173 ; c8c761b6 b6b55bb5
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_fmaak_f32 v177, v177, v178, 0x3f650000                    ; 5b6365b1 3f650000
	v_maxmin_num_f32 v75, -4.0, v188, 4.0                       ; d669004b 03db78f7
(invalid instruction)                                        ; d769006d
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_maxmin_num_f32 v181, -4.0, v185, 4.0                      ; d66900b5 03db72f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_maxmin_num_f32 v124, -4.0, v189, 4.0                      ; d669007c 03db7af7
	v_mul_f32_e32 v183, v183, v177                              ; 116f63b7
	v_maxmin_num_f32 v126, -4.0, v190, 4.0                      ; d669007e 03db7cf7
	v_fma_mix_f32 v111, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfe96ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
(invalid instruction)                                        ; d769406d
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_maxmin_num_f32 v183, -4.0, v186, 4.0                      ; d66900b7 03db74f7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_maxmin_num_f32 v128, -4.0, v191, 4.0                      ; d6690080 03db7ef7
	v_maxmin_num_f32 v130, -4.0, v14, 4.0                       ; d6690082 03da1cf7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v179, v179, v180, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v181, 0x3f650000 ; c84369b3 b3b76bb6 3f650000
	v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 :: v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 ; c842fb7c 7c7efd7f 3f650000
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v134, -4.0, v16, 4.0                       ; d6690086 03da20f7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_mul_f32 v185, v185, v182 :: v_dual_mul_f32 v184, v184, v179 ; c8c76db9 b9b967b8
	v_mul_f32_e32 v190, v190, v127                              ; 117cffbe
	v_maxmin_num_f32 v138, -4.0, v18, 4.0                       ; d669008a 03da24f7
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fmaak_f32 v130, v130, v131, 0x3f650000                    ; 5b050782 3f650000
	v_maxmin_num_f32 v132, -4.0, v15, 4.0                       ; d6690084 03da1ef7
(invalid instruction)                                        ; d769006e
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_maxmin_num_f32 v185, -4.0, v187, 4.0                      ; d66900b9 03db76f7
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v140, -4.0, v19, 4.0                       ; d669008c 03da26f7
	v_dual_mul_f32 v14, v14, v130 :: v_dual_mul_f32 v189, v189, v124 ; c8c7050e 0ebcf9bd
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v26, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bff72ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v17, 4.0                       ; d6690088 03da22f7
	v_fmaak_f32 v183, v183, v184, 0x3f650000                    ; 5b6f71b7 3f650000
	v_maxmin_num_f32 v142, -4.0, v20, 4.0                       ; d669008e 03da28f7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_lshrrev_b32_e32 v147, 4, v27                              ; 33263684
	v_dual_fmaak_f32 v26, v26, v185, 0x3f650000 :: v_dual_fmaak_f32 v111, v111, v75, 0x3f650000 ; c843731a 1a6e976f 3f650000
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_mul_f32_e32 v186, v186, v183                              ; 11756fba
	v_fma_mix_f32 v144, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1cff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 :: v_dual_mul_f32 v187, v187, v26 ; c8470380 80ba35bb 3f650000
	v_mul_f32_e32 v188, v188, v111                              ; 1178dfbc
	v_maxmin_num_f32 v145, -4.0, v21, 4.0                       ; d6690091 03da2af7
	v_dual_fmaak_f32 v144, v144, v142, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 ; c8431d90 90891189 3f650000
	v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 :: v_dual_mul_f32 v191, v191, v128 ; c8470f86 86bf01bf 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_dual_mul_f32 v20, v20, v144 :: v_dual_lshlrev_b32 v147, 3, v147 ; c8e32114 14932683
	v_dual_mul_f32 v17, v17, v137 :: v_dual_and_b32 v146, 0xffffffe0, v0 ; c8e51311 119200ff ffffffe0
	v_dual_mul_f32 v16, v134, v16 :: v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 ; c8c22186 108b158b 3f650000
	v_add3_u32 v148, v147, s9, v146                             ; d6550094 06481393
	v_dual_mul_f32 v18, v18, v139 :: v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 ; c8c31712 12850985 3f650000
(invalid instruction)                                        ; d769406e
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v140, v141, v140, 0x3f650000 :: v_dual_mul_f32 v15, v15, v133 ; c847198d 8c0f0b0f 3f650000
	v_dual_mul_f32 v19, v140, v19 :: v_dual_lshlrev_b32 v148, 2, v148 ; c8e2278c 13952882
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v148, s[32:35], null offen       ; c405c07c 40804010 00000094
	buffer_load_b128 v[124:127], v148, s[32:35], null offen offset:16 ; c405c07c 4080407c 00001094
(invalid instruction)                                        ; d769006f
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_maxmin_num_f32 v150, -4.0, v58, 4.0                       ; d6690096 03da74f7
	v_fma_mix_f32 v149, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff22ff 3728ab28
(invalid instruction)                                        ; d769406f
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v152, -4.0, v59, 4.0                       ; d6690098 03da76f7
	v_maxmin_num_f32 v154, -4.0, v60, 4.0                       ; d669009a 03da78f7
	v_maxmin_num_f32 v158, -4.0, v62, 4.0                       ; d669009e 03da7cf7
	v_maxmin_num_f32 v156, -4.0, v61, 4.0                       ; d669009c 03da7af7
	v_maxmin_num_f32 v160, -4.0, v63, 4.0                       ; d66900a0 03da7ef7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v64, 4.0                       ; d66900a2 03da80f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v65, 4.0                       ; d66900a4 03da82f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v149, 0x3f650000 ; c8432f96 96912b91 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fmaak_f32 v153, v153, v152, 0x3f650000                    ; 5b333199 3f650000
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_dual_mul_f32 v58, v58, v150 :: v_dual_mul_f32 v21, v21, v145 ; c8c72d3a 3a152315
	v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 :: v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 ; c84343a0 a0a345a3 3f650000
	v_dual_mul_f32 v59, v59, v153 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8c3333b 3b9b379a 3f650000
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 :: v_dual_mul_f32 v63, v63, v160 ; c8474ba4 a43f413f 3f650000
	v_dual_fmaak_f32 v159, v158, v159, 0x3f650000 :: v_dual_mul_f32 v60, v60, v154 ; c8473f9e 9f3d353c 3f650000
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
	v_dual_mov_b32 v26, v143 :: v_dual_mul_f32 v65, v65, v164   ; ca06018f 1a414941
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v62, v62, v159 ; c847399d 9d3f3f3e 3f650000
	v_dual_mul_f32 v64, v64, v163 :: v_dual_mul_f32 v61, v61, v157 ; c8c74740 403d3b3d
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[90:91], v[44:45], 0 ; cc4640b0 1a02595a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[88:89], v[68:69], 0 ; cc464098 1a028958
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[88:89], v[70:71], 0 ; cc4640a0 1a028d58
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[90:91], v[68:69], 0 ; cc4640b8 1a02895a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[88:89], v[36:37], 0 ; cc4640a8 1a024958
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[90:91], v[36:37], 0 ; cc464088 1a02495a
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[90:91], v[70:71], 0 ; cc46403a 1a028d5a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[88:89], v[44:45], 0 ; cc464080 1a025958
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[94:95], v[38:39], v[176:183] ; cc4640b0 1ec24d5e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[92:93], v[46:47], v[152:159] ; cc464098 1e625d5c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[94:95], v[46:47], v[184:191] ; cc4640b8 1ee25d5e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[38:39], v[128:135] ; cc464080 1e024d5c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[98:99], v[8:9], v[176:183] ; cc4640b0 1ec21162
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[10:11], v[152:159] ; cc464098 1e621560
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[10:11], v[184:191] ; cc4640b8 1ee21562
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[92:93], v[42:43], v[160:167] ; cc4640a0 1e82555c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[92:93], v[6:7], v[168:175] ; cc4640a8 1ea20d5c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[94:95], v[6:7], v[136:143] ; cc464088 1e220d5e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[96:97], v[8:9], v[128:135] ; cc464080 1e021160
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[102:103], v[30:31], v[176:183] ; cc4640b0 1ec23d66
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[96:97], v[28:29], v[168:175] ; cc4640a8 1ea23960
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[98:99], v[28:29], v[136:143] ; cc464088 1e223962
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[100:101], v[30:31], v[128:135] ; cc464080 1e023d64
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[8:11], v148, s[32:35], null offen offset:64 ; c405c07c 40804008 00004094
	buffer_load_b128 v[28:31], v148, s[32:35], null offen offset:80 ; c405c07c 4080401c 00005094
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[94:95], v[42:43], v[58:65] ; cc46403a 1cea555e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[100:101], v[32:33], v[152:159] ; cc464098 1e624164
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[102:103], v[32:33], v[184:191] ; cc4640b8 1ee24166
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[96:97], v[12:13], v[160:167] ; cc4640a0 1e821960
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[100:101], v[40:41], v[168:175] ; cc4640a8 1ea25164
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[102:103], v[40:41], v[136:143] ; cc464088 1e225166
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[106:107], v[52:53], v[176:183] ; cc4640b0 1ec2696a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[104:105], v[52:53], v[128:135] ; cc464080 1e026968
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[98:99], v[12:13], v[58:65] ; cc46403a 1cea1962
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v32, v74, s5, v26                                ; d6550020 04680b4a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[104:105], v[54:55], v[152:159] ; cc464098 1e626d68
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[106:107], v[54:55], v[184:191] ; cc4640b8 1ee26d6a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[100:101], v[34:35], v[160:167] ; cc4640a0 1e824564
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[104:105], v[82:83], v[168:175] ; cc4640a8 1ea2a568
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[106:107], v[82:83], v[136:143] ; cc464088 1e22a56a
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[84:85], v[176:183] ; cc4640b0 1ec2a972
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[112:113], v[84:85], v[128:135] ; cc464080 1e02a970
	v_lshlrev_b32_e32 v32, 2, v32                               ; 30404082
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[102:103], v[34:35], v[58:65] ; cc46403a 1cea4566
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[22:23], v[152:159] ; cc464098 1e622d70
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[22:23], v[184:191] ; cc4640b8 1ee22d72
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[104:105], v[80:81], v[160:167] ; cc4640a0 1e82a168
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[112:113], v[50:51], v[168:175] ; cc4640a8 1ea26570
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[114:115], v[50:51], v[136:143] ; cc464088 1e226572
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[118:119], v[56:57], v[176:183] ; cc4640b0 1ec27176
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[116:117], v[56:57], v[128:135] ; cc464080 1e027174
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[106:107], v[80:81], v[58:65] ; cc46403a 1ceaa16a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[66:67], v[152:159] ; cc464098 1e628574
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[66:67], v[184:191] ; cc4640b8 1ee28576
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[112:113], v[24:25], v[160:167] ; cc4640a0 1e823170
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[116:117], v[86:87], v[168:175] ; cc4640a8 1ea2ad74
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[118:119], v[86:87], v[136:143] ; cc464088 1e22ad76
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[122:123], v[108:109], v[176:183] ; cc4640b0 1ec2d97a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[120:121], v[108:109], v[128:135] ; cc464080 1e02d978
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[114:115], v[24:25], v[58:65] ; cc46403a 1cea3172
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[120:121], v[110:111], v[152:159] ; cc464098 1e62dd78
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[122:123], v[110:111], v[184:191] ; cc4640b8 1ee2dd7a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[116:117], v[72:73], v[160:167] ; cc4640a0 1e829174
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[120:121], v[20:21], v[168:175] ; cc4640a8 1ea22978
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[122:123], v[20:21], v[136:143] ; cc464088 1e22297a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	buffer_load_b128 v[36:39], v32, s[36:39], null offen        ; c405c07c 40804824 00000020
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[118:119], v[72:73], v[58:65] ; cc46403a 1cea9176
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[120:121], v[14:15], v[160:167] ; cc4640a0 1e821d78
	v_add_nc_u32_e32 v33, 0x2000, v76                           ; 4a4298ff 00002000
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_wmma_f32_16x16x16_fp8_fp8 v[58:65], v[122:123], v[14:15], v[58:65] ; cc46403a 1cea1d7a
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	ds_store_2addr_b64 v33, v[6:7], v[22:23] offset1:32         ; d9382000 00160621
	buffer_load_b128 v[44:47], v32, s[36:39], null offen offset:512 ; c405c07c 4080482c 00020020
	v_add_nc_u32_e32 v42, 0x2800, v76                           ; 4a5498ff 00002800
	v_add_nc_u32_e32 v43, 0x3000, v76                           ; 4a5698ff 00003000
	v_add_nc_u32_e32 v50, 0x3800, v76                           ; 4a6498ff 00003800
	ds_store_2addr_b64 v42, v[12:13], v[24:25] offset1:32       ; d9382000 00180c2a
	ds_store_2addr_b64 v43, v[14:15], v[34:35] offset1:32       ; d9382000 00220e2b
	ds_store_2addr_b64 v50, v[20:21], v[40:41] offset1:32       ; d9382000 00281432
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	buffer_load_b128 v[12:15], v32, s[36:39], null offen offset:1024 ; c405c07c 4080480c 00040020
	v_mad_u32_u24 v51, s59, 0x500, v2                           ; d60b0033 0409fe3b 00000500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v51, v51, v49                              ; 4a666333
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[6:7], v51                                     ; d9d80000 06000033
	ds_load_b64 v[20:21], v51 offset:2048                       ; d9d80800 14000033
	ds_load_b64 v[22:23], v51 offset:4096                       ; d9d81000 16000033
	buffer_load_b128 v[52:55], v32, s[36:39], null offen offset:1536 ; c405c07c 40804834 00060020
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[24:25], v6                           ; 7e30dd06
	s_wait_loadcnt 0x7                                          ; bfc00007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v57, v25, v17 :: v_dual_mul_f32 v56, v24, v16 ; c8c62319 39382118
	v_cvt_pk_f32_fp8_e32 v[24:25], v134                         ; 7e30dd86
	v_dual_mul_f32 v59, v25, v19 :: v_dual_mul_f32 v58, v24, v18 ; c8c62719 3b3a2518
	v_cvt_pk_f32_fp8_e32 v[24:25], v7                           ; 7e30dd07
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v61, v25, v125 :: v_dual_mul_f32 v60, v24, v124 ; c8c6fb19 3d3cf918
	ds_load_b64 v[24:25], v51 offset:6144                       ; d9d81800 18000033
	buffer_load_b128 v[68:71], v32, s[36:39], null offen offset:2048 ; c405c07c 40804844 00080020
	ds_load_b64 v[34:35], v51 offset:256                        ; d9d80100 22000033
	buffer_load_b128 v[80:83], v32, s[36:39], null offen offset:2560 ; c405c07c 40804850 000a0020
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v63, v7, v127 :: v_dual_mul_f32 v62, v6, v126 ; c8c6ff07 3f3efd06
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[6:7], v20                            ; 7e0cdd14
	v_dual_mul_f32 v65, v7, v17 :: v_dual_mul_f32 v64, v6, v16  ; c8c62307 41402106
	v_cvt_pk_f32_fp8_e32 v[6:7], v148                           ; 7e0cdd94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v67, v7, v19 :: v_dual_mul_f32 v66, v6, v18  ; c8c62707 43422506
	v_cvt_pk_f32_fp8_e32 v[6:7], v21                            ; 7e0cdd15
	v_cvt_pk_f32_fp8_e32 v[20:21], v149                         ; 7e28dd95
	v_dual_mul_f32 v85, v7, v125 :: v_dual_mul_f32 v84, v6, v124 ; c8c6fb07 5554f906
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v22                            ; 7e0cdd16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v89, v7, v17 :: v_dual_mul_f32 v88, v6, v16  ; c8c62307 59582106
	v_cvt_pk_f32_fp8_e32 v[6:7], v150                           ; 7e0cdd96
	v_dual_mul_f32 v91, v7, v19 :: v_dual_mul_f32 v90, v6, v18  ; c8c62707 5b5a2506
	v_cvt_pk_f32_fp8_e32 v[6:7], v23                            ; 7e0cdd17
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v87, v21, v127 :: v_dual_mul_f32 v92, v6, v124 ; c8c6ff15 575cf906
	v_dual_mul_f32 v93, v7, v125 :: v_dual_mul_f32 v86, v20, v126 ; c8c6fb07 5d56fd14
	v_cvt_pk_f32_fp8_e32 v[6:7], v151                           ; 7e0cdd97
	buffer_load_b128 v[20:23], v32, s[36:39], null offen offset:3072 ; c405c07c 40804814 000c0020
	ds_load_b64 v[40:41], v51 offset:2304                       ; d9d80900 28000033
	v_dual_mul_f32 v95, v7, v127 :: v_dual_mul_f32 v94, v6, v126 ; c8c6ff07 5f5efd06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v24                            ; 7e0cdd18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v97, v7, v17                                  ; 10c22307
	v_mul_f32_e32 v96, v6, v16                                  ; 10c02106
	v_cvt_pk_f32_fp8_e32 v[6:7], v152                           ; 7e0cdd98
	v_dual_mul_f32 v99, v7, v19 :: v_dual_mul_f32 v98, v6, v18  ; c8c62707 63622506
	buffer_load_b128 v[16:19], v32, s[36:39], null offen offset:3584 ; c405c07c 40804810 000e0020
	v_cvt_pk_f32_fp8_e32 v[6:7], v25                            ; 7e0cdd19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v101, v7, v125 :: v_dual_mul_f32 v100, v6, v124 ; c8c6fb07 6564f906
	v_cvt_pk_f32_fp8_e32 v[6:7], v153                           ; 7e0cdd99
	v_dual_mul_f32 v103, v7, v127 :: v_dual_mul_f32 v102, v6, v126 ; c8c6ff07 6766fd06
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[6:7], v34                            ; 7e0cdd22
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v105, v7, v9 :: v_dual_mul_f32 v104, v6, v8  ; c8c61307 69681106
	v_cvt_pk_f32_fp8_e32 v[6:7], v162                           ; 7e0cdda2
	v_dual_mul_f32 v107, v7, v11 :: v_dual_mul_f32 v106, v6, v10 ; c8c61707 6b6a1506
	v_cvt_pk_f32_fp8_e32 v[6:7], v35                            ; 7e0cdd23
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v109, v7, v29 :: v_dual_mul_f32 v108, v6, v28 ; c8c63b07 6d6c3906
	v_cvt_pk_f32_fp8_e32 v[6:7], v163                           ; 7e0cdda3
	ds_load_b64 v[24:25], v51 offset:4352                       ; d9d81100 18000033
	ds_load_b64 v[34:35], v51 offset:6400                       ; d9d81900 22000033
	v_dual_mul_f32 v111, v7, v31 :: v_dual_mul_f32 v110, v6, v30 ; c8c63f07 6f6e3d06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v40                            ; 7e0cdd28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v7, v9 :: v_dual_mul_f32 v112, v6, v8  ; c8c61307 71701106
	v_cvt_pk_f32_fp8_e32 v[6:7], v168                           ; 7e0cdda8
	v_dual_mul_f32 v115, v7, v11 :: v_dual_mul_f32 v114, v6, v10 ; c8c61707 73721506
	v_cvt_pk_f32_fp8_e32 v[6:7], v41                            ; 7e0cdd29
	v_add_lshl_u32 v72, s23, v1, 2                              ; d6470048 020a0217
	buffer_load_b32 v72, v72, s[32:35], null offen              ; c405007c 40804048 00000048
	v_dual_mul_f32 v117, v7, v29 :: v_dual_mul_f32 v116, v6, v28 ; c8c63b07 75743906
	v_cvt_pk_f32_fp8_e32 v[6:7], v169                           ; 7e0cdda9
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870119
	v_mad_u32_u24 v73, 0xc00, v1, s6                            ; d60b0049 001a02ff 00000c00
	v_dual_mul_f32 v119, v7, v31 :: v_dual_mul_f32 v118, v6, v30 ; c8c63f07 77763d06
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[6:7], v24                            ; 7e0cdd18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_add_lshl_u32 v73, v73, v74, 2                             ; d6470049 020a9549
	v_dual_mul_f32 v121, v7, v9 :: v_dual_mul_f32 v120, v6, v8  ; c8c61307 79781106
	v_cvt_pk_f32_fp8_e32 v[6:7], v152                           ; 7e0cdd98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v123, v7, v11 :: v_dual_mul_f32 v122, v6, v10 ; c8c61707 7b7a1506
	v_cvt_pk_f32_fp8_e32 v[6:7], v25                            ; 7e0cdd19
	v_dual_mul_f32 v125, v7, v29 :: v_dual_mul_f32 v124, v6, v28 ; c8c63b07 7d7c3906
	v_cvt_pk_f32_fp8_e32 v[6:7], v153                           ; 7e0cdd99
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v127, v7, v31 :: v_dual_mul_f32 v126, v6, v30 ; c8c63f07 7f7e3d06
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[6:7], v34                            ; 7e0cdd22
	v_dual_mul_f32 v129, v7, v9 :: v_dual_mul_f32 v128, v6, v8  ; c8c61307 81801106
	v_cvt_pk_f32_fp8_e32 v[6:7], v162                           ; 7e0cdda2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
	v_dual_mul_f32 v131, v7, v11 :: v_dual_mul_f32 v130, v6, v10 ; c8c61707 83821506
	buffer_load_b128 v[8:11], v73, s[36:39], null offen         ; c405c07c 40804808 00000049
	v_cvt_pk_f32_fp8_e32 v[6:7], v35                            ; 7e0cdd23
	v_lshl_add_u32 v75, s59, 10, v49                            ; d646004b 04c5143b
	v_dual_mul_f32 v133, v7, v29 :: v_dual_mul_f32 v132, v6, v28 ; c8c63b07 85843906
	v_cvt_pk_f32_fp8_e32 v[6:7], v163                           ; 7e0cdda3
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v135, v7, v31 :: v_dual_mul_f32 v134, v6, v30 ; c8c63f07 87863d06
	ds_load_b64 v[6:7], v75 offset:8192                         ; d9d82000 0600004b
	ds_load_b64 v[24:25], v75 offset:10240                      ; d9d82800 1800004b
	ds_load_b64 v[28:29], v75 offset:12288                      ; d9d83000 1c00004b
	ds_load_b64 v[30:31], v75 offset:14336                      ; d9d83800 1e00004b
	ds_load_b64 v[34:35], v75 offset:8448                       ; d9d82100 2200004b
	ds_load_b64 v[40:41], v75 offset:10496                      ; d9d82900 2800004b
	buffer_load_b128 v[136:139], v73, s[36:39], null offen offset:4096 ; c405c07c 40804888 00100049
	ds_load_b64 v[140:141], v75 offset:12544                    ; d9d83100 8c00004b
	ds_load_b64 v[142:143], v75 offset:14592                    ; d9d83900 8e00004b
	ds_load_b64 v[144:145], v75 offset:8704                     ; d9d82200 9000004b
	ds_load_b64 v[148:149], v75 offset:10752                    ; d9d82a00 9400004b
	ds_load_b64 v[150:151], v75 offset:12800                    ; d9d83200 9600004b
	ds_load_b64 v[152:153], v75 offset:14848                    ; d9d83a00 9800004b
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mov_b32 v159, v71 :: v_dual_mov_b32 v158, v70        ; ca100147 9f9e0146
	v_dual_mov_b32 v71, v87 :: v_dual_mov_b32 v70, v86          ; ca100157 47460156
	v_dual_mov_b32 v157, v69 :: v_dual_mov_b32 v156, v68        ; ca100145 9d9c0144
	v_dual_mov_b32 v69, v85 :: v_dual_mov_b32 v68, v84          ; ca100155 45440154
	buffer_load_b128 v[84:87], v73, s[36:39], null offen offset:512 ; c405c07c 40804854 00020049
	ds_load_b64 v[154:155], v75 offset:8960                     ; d9d82300 9a00004b
	ds_load_b64 v[160:161], v75 offset:11008                    ; d9d82b00 a000004b
	ds_load_b64 v[162:163], v75 offset:13056                    ; d9d83300 a200004b
	ds_load_b64 v[164:165], v75 offset:15104                    ; d9d83b00 a400004b
	buffer_load_b128 v[168:171], v73, s[36:39], null offen offset:4608 ; c405c07c 408048a8 00120049
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[36:37], v[6:7], v[56:63] ; cc464038 1ce20d24
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[6:7], v[104:111] ; cc464068 1da20d26
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[24:25], v[112:119] ; cc464070 1dc23126
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[28:29], v[88:95] ; cc464058 1d623924
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[30:31], v[96:103] ; cc464060 1d823d24
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[28:29], v[120:127] ; cc464078 1de23926
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[38:39], v[30:31], v[128:135] ; cc464080 1e023d26
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[36:37], v[24:25], v[64:71] ; cc464040 1d023124
	ds_load_b64 v[6:7], v75 offset:9216                         ; d9d82400 0600004b
	ds_load_b64 v[24:25], v75 offset:11264                      ; d9d82c00 1800004b
	ds_load_b64 v[28:29], v75 offset:13312                      ; d9d83400 1c00004b
	ds_load_b64 v[30:31], v75 offset:15360                      ; d9d83c00 1e00004b
	buffer_load_b128 v[36:39], v73, s[36:39], null offen offset:1024 ; c405c07c 40804824 00040049
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[34:35], v[56:63] ; cc464038 1ce2452c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[34:35], v[104:111] ; cc464068 1da2452e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[40:41], v[112:119] ; cc464070 1dc2512e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[140:141], v[88:95] ; cc464058 1d63192c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[142:143], v[96:103] ; cc464060 1d831d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[140:141], v[120:127] ; cc464078 1de3192e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[142:143], v[128:135] ; cc464080 1e031d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[44:45], v[40:41], v[64:71] ; cc464040 1d02512c
	ds_load_b64 v[34:35], v75 offset:9472                       ; d9d82500 2200004b
	ds_load_b64 v[40:41], v75 offset:11520                      ; d9d82d00 2800004b
	ds_load_b64 v[44:45], v75 offset:13568                      ; d9d83500 2c00004b
	ds_load_b64 v[46:47], v75 offset:15616                      ; d9d83d00 2e00004b
	buffer_load_b128 v[140:143], v73, s[36:39], null offen offset:5120 ; c405c07c 4080488c 00140049
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[12:13], v[144:145], v[56:63] ; cc464038 1ce3210c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[144:145], v[104:111] ; cc464068 1da3210e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[148:149], v[112:119] ; cc464070 1dc3290e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[150:151], v[88:95] ; cc464058 1d632d0c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[152:153], v[96:103] ; cc464060 1d83310c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[150:151], v[120:127] ; cc464078 1de32d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[152:153], v[128:135] ; cc464080 1e03310e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[12:13], v[148:149], v[64:71] ; cc464040 1d03290c
	ds_load_b64 v[12:13], v75 offset:9728                       ; d9d82600 0c00004b
	ds_load_b64 v[14:15], v75 offset:11776                      ; d9d82e00 0e00004b
	ds_load_b64 v[144:145], v75 offset:13824                    ; d9d83600 9000004b
	ds_load_b64 v[148:149], v75 offset:15872                    ; d9d83e00 9400004b
	buffer_load_b128 v[172:175], v73, s[36:39], null offen offset:1536 ; c405c07c 408048ac 00060049
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[52:53], v[154:155], v[56:63] ; cc464038 1ce33534
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[54:55], v[154:155], v[104:111] ; cc464068 1da33536
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[160:161], v[112:119] ; cc464070 1dc34136
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[162:163], v[88:95] ; cc464058 1d634534
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[164:165], v[96:103] ; cc464060 1d834934
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[162:163], v[120:127] ; cc464078 1de34536
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[164:165], v[128:135] ; cc464080 1e034936
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[52:53], v[160:161], v[64:71] ; cc464040 1d034134
	ds_load_b64 v[52:53], v75 offset:9984                       ; d9d82700 3400004b
	ds_load_b64 v[54:55], v75 offset:12032                      ; d9d82f00 3600004b
	ds_load_b64 v[150:151], v75 offset:14080                    ; d9d83700 9600004b
	ds_load_b64 v[152:153], v75 offset:16128                    ; d9d83f00 9800004b
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[156:157], v[6:7], v[56:63] ; cc464038 1ce20d9c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[158:159], v[6:7], v[104:111] ; cc464068 1da20d9e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[158:159], v[24:25], v[112:119] ; cc464070 1dc2319e
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[156:157], v[28:29], v[88:95] ; cc464058 1d62399c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[156:157], v[30:31], v[96:103] ; cc464060 1d823d9c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[158:159], v[28:29], v[120:127] ; cc464078 1de2399e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[158:159], v[30:31], v[128:135] ; cc464080 1e023d9e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[156:157], v[24:25], v[64:71] ; cc464040 1d02319c
	s_wait_loadcnt_dscnt 0xa0b                                  ; bfc80a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[80:81], v[34:35], v[56:63] ; cc464038 1ce24550
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[82:83], v[34:35], v[104:111] ; cc464068 1da24552
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[40:41], v[112:119] ; cc464070 1dc25152
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[80:81], v[44:45], v[88:95] ; cc464058 1d625950
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[80:81], v[46:47], v[96:103] ; cc464060 1d825d50
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[82:83], v[44:45], v[120:127] ; cc464078 1de25952
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[46:47], v[128:135] ; cc464080 1e025d52
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[80:81], v[40:41], v[64:71] ; cc464040 1d025150
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[20:21], v[12:13], v[56:63] ; cc464038 1ce21914
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[22:23], v[12:13], v[104:111] ; cc464068 1da21916
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[14:15], v[112:119] ; cc464070 1dc21d16
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[144:145], v[88:95] ; cc464058 1d632114
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[148:149], v[96:103] ; cc464060 1d832914
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[144:145], v[120:127] ; cc464078 1de32116
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[148:149], v[128:135] ; cc464080 1e032916
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[20:21], v[14:15], v[64:71] ; cc464040 1d021d14
	s_wait_loadcnt_dscnt 0x803                                  ; bfc80803
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[16:17], v[52:53], v[56:63] ; cc464038 1ce26910
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[52:53], v[104:111] ; cc464068 1da26912
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[54:55], v[112:119] ; cc464070 1dc26d12
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[150:151], v[88:95] ; cc464058 1d632d10
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[152:153], v[96:103] ; cc464060 1d833110
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[150:151], v[120:127] ; cc464078 1de32d12
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[152:153], v[128:135] ; cc464080 1e033112
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[16:17], v[54:55], v[64:71] ; cc464040 1d026d10
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v76, v[6:7], v[18:19] offset1:32         ; d9382000 0012064c
	ds_store_2addr_b64 v77, v[12:13], v[20:21] offset1:32       ; d9382000 00140c4d
	ds_store_2addr_b64 v78, v[14:15], v[22:23] offset1:32       ; d9382000 00160e4e
	ds_store_2addr_b64 v79, v[16:17], v[24:25] offset1:32       ; d9382000 0018104f
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_lshl_add_u32 v76, s59, 11, v49                            ; d646004c 04c5163b
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[6:7], v76                                     ; d9d80000 0600004c
	ds_load_b64 v[12:13], v76 offset:2048                       ; d9d80800 0c00004c
	ds_load_b64 v[14:15], v76 offset:4096                       ; d9d81000 0e00004c
	ds_load_b64 v[16:17], v76 offset:6144                       ; d9d81800 1000004c
	ds_load_b64 v[18:19], v76 offset:256                        ; d9d80100 1200004c
	ds_load_b64 v[20:21], v76 offset:2304                       ; d9d80900 1400004c
	ds_load_b64 v[22:23], v76 offset:4352                       ; d9d81100 1600004c
	ds_load_b64 v[24:25], v76 offset:6400                       ; d9d81900 1800004c
	s_wait_loadcnt_dscnt 0x607                                  ; bfc80607
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[8:9], v[6:7], 0     ; cc464038 1a020d08
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[6:7], 0 ; cc464068 1a020d0a
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[12:13], 0 ; cc464070 1a02190a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[8:9], v[12:13], 0   ; cc464040 1a021908
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[14:15], 0 ; cc464078 1a021d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[14:15], 0   ; cc464058 1a021d08
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[16:17], 0  ; cc464060 1a022108
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[16:17], 0 ; cc464080 1a02210a
	ds_load_b64 v[8:9], v76 offset:512                          ; d9d80200 0800004c
	ds_load_b64 v[10:11], v76 offset:2560                       ; d9d80a00 0a00004c
	ds_load_b64 v[28:29], v76 offset:4608                       ; d9d81200 1c00004c
	ds_load_b64 v[30:31], v76 offset:6656                       ; d9d81a00 1e00004c
	v_mov_b32_e32 v32, v76                                      ; 7e40034c
	v_dual_mov_b32 v34, v42 :: v_dual_mov_b32 v35, v43          ; ca10012a 2222012b
	v_dual_mov_b32 v52, v146 :: v_dual_mov_b32 v53, v147        ; ca100192 34340193
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[136:137], v[14:15], 0 ; cc4640b0 1a021d88
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[138:139], v[14:15], 0 ; cc464090 1a021d8a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[136:137], v[6:7], 0 ; cc464098 1a020d88
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[136:137], v[12:13], 0 ; cc4640a0 1a021988
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[136:137], v[16:17], 0 ; cc4640b8 1a022188
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[138:139], v[6:7], 0 ; cc46404c 1a020d8a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[138:139], v[12:13], 0 ; cc464028 1a02198a
	s_wait_loadcnt_dscnt 0x407                                  ; bfc80407
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[84:85], v[18:19], v[56:63] ; cc464038 1ce22554
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[84:85], v[20:21], v[64:71] ; cc464040 1d022954
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[84:85], v[22:23], v[88:95] ; cc464058 1d622d54
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[84:85], v[24:25], v[96:103] ; cc464060 1d823154
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[86:87], v[18:19], v[104:111] ; cc464068 1da22556
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[86:87], v[20:21], v[112:119] ; cc464070 1dc22956
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[86:87], v[22:23], v[120:127] ; cc464078 1de22d56
	s_wait_dscnt 0x3                                            ; bfc60003
	v_dual_mov_b32 v14, v8 :: v_dual_mov_b32 v15, v9            ; ca100108 0e0e0109
	s_wait_dscnt 0x2                                            ; bfc60002
	v_dual_mov_b32 v54, v10 :: v_dual_mov_b32 v55, v11          ; ca10010a 3636010b
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[138:139], v[16:17], 0 ; cc464006 1a02218a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[86:87], v[24:25], v[128:135] ; cc464080 1e023156
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[168:169], v[18:19], v[152:159] ; cc464098 1e6225a8
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[168:169], v[20:21], v[160:167] ; cc4640a0 1e8229a8
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[168:169], v[22:23], v[176:183] ; cc4640b0 1ec22da8
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[168:169], v[24:25], v[184:191] ; cc4640b8 1ee231a8
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[170:171], v[18:19], v[76:83] ; cc46404c 1d3225aa
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[170:171], v[20:21], v[40:47] ; cc464028 1ca229aa
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[170:171], v[22:23], v[144:151] ; cc464090 1e422daa
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[170:171], v[24:25], v[6:13] ; cc464006 1c1a31aa
	ds_load_b64 v[16:17], v32 offset:768                        ; d9d80300 10000020
	ds_load_b64 v[84:85], v32 offset:2816                       ; d9d80b00 54000020
	ds_load_b64 v[86:87], v32 offset:4864                       ; d9d81300 56000020
	ds_load_b64 v[136:137], v32 offset:6912                     ; d9d81b00 88000020
	ds_load_b64 v[18:19], v32 offset:1024                       ; d9d80400 12000020
	ds_load_b64 v[20:21], v32 offset:3072                       ; d9d80c00 14000020
	ds_load_b64 v[22:23], v32 offset:5120                       ; d9d81400 16000020
	ds_load_b64 v[24:25], v32 offset:7168                       ; d9d81c00 18000020
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[36:37], v[14:15], v[56:63] ; cc464038 1ce21d24
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[36:37], v[54:55], v[64:71] ; cc464040 1d026d24
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[28:29], v[88:95] ; cc464058 1d623924
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[30:31], v[96:103] ; cc464060 1d823d24
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[14:15], v[104:111] ; cc464068 1da21d26
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[54:55], v[112:119] ; cc464070 1dc26d26
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[28:29], v[120:127] ; cc464078 1de23926
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[38:39], v[30:31], v[128:135] ; cc464080 1e023d26
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[140:141], v[14:15], v[152:159] ; cc464098 1e621d8c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[140:141], v[54:55], v[160:167] ; cc4640a0 1e826d8c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[140:141], v[28:29], v[176:183] ; cc4640b0 1ec2398c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[140:141], v[30:31], v[184:191] ; cc4640b8 1ee23d8c
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[36:39], v73, s[36:39], null offen offset:5632 ; c405c07c 40804824 00160049
	buffer_load_b128 v[168:171], v73, s[36:39], null offen offset:2048 ; c405c07c 408048a8 00080049
	buffer_load_b128 v[138:141], v73, s[36:39], null offen offset:6144 ; c405c07c 4080488a 00180049
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[142:143], v[14:15], v[76:83] ; cc46404c 1d321d8e
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[142:143], v[54:55], v[40:47] ; cc464028 1ca26d8e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[142:143], v[28:29], v[144:151] ; cc464090 1e42398e
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[142:143], v[30:31], v[6:13] ; cc464006 1c1a3d8e
	ds_load_b64 v[14:15], v32 offset:1280                       ; d9d80500 0e000020
	ds_load_b64 v[28:29], v32 offset:3328                       ; d9d80d00 1c000020
	ds_load_b64 v[30:31], v32 offset:5376                       ; d9d81500 1e000020
	ds_load_b64 v[54:55], v32 offset:7424                       ; d9d81d00 36000020
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[172:173], v[16:17], v[56:63] ; cc464038 1ce221ac
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[172:173], v[84:85], v[64:71] ; cc464040 1d02a9ac
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[172:173], v[86:87], v[88:95] ; cc464058 1d62adac
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[172:173], v[136:137], v[96:103] ; cc464060 1d8311ac
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[174:175], v[16:17], v[104:111] ; cc464068 1da221ae
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[174:175], v[84:85], v[112:119] ; cc464070 1dc2a9ae
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[174:175], v[86:87], v[120:127] ; cc464078 1de2adae
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[174:175], v[136:137], v[128:135] ; cc464080 1e0311ae
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[36:37], v[136:137], v[184:191] ; cc4640b8 1ee31124
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[36:37], v[84:85], v[160:167] ; cc4640a0 1e82a924
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[38:39], v[16:17], v[76:83] ; cc46404c 1d322126
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[36:37], v[16:17], v[152:159] ; cc464098 1e622124
	v_dual_mov_b32 v17, v35 :: v_dual_mov_b32 v16, v34          ; ca100123 11100122
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[36:37], v[86:87], v[176:183] ; cc4640b0 1ec2ad24
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[172:175], v73, s[36:39], null offen offset:2560 ; c405c07c 408048ac 000a0049
	buffer_load_b128 v[34:37], v73, s[36:39], null offen offset:6656 ; c405c07c 40804822 001a0049
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[38:39], v[136:137], v[6:13] ; cc464006 1c1b1126
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[38:39], v[84:85], v[40:47] ; cc464028 1ca2a926
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[86:87], v[144:151] ; cc464090 1e42ad26
	ds_load_b64 v[84:85], v32 offset:1536                       ; d9d80600 54000020
	ds_load_b64 v[86:87], v32 offset:3584                       ; d9d80e00 56000020
	ds_load_b64 v[38:39], v32 offset:5632                       ; d9d81600 26000020
	ds_load_b64 v[136:137], v32 offset:7680                     ; d9d81e00 88000020
	s_wait_loadcnt_dscnt 0x30b                                  ; bfc8030b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[168:169], v[18:19], v[56:63] ; cc464038 1ce225a8
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[168:169], v[20:21], v[64:71] ; cc464040 1d0229a8
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[168:169], v[22:23], v[88:95] ; cc464058 1d622da8
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[168:169], v[24:25], v[96:103] ; cc464060 1d8231a8
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[170:171], v[18:19], v[104:111] ; cc464068 1da225aa
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[20:21], v[112:119] ; cc464070 1dc229aa
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[170:171], v[22:23], v[120:127] ; cc464078 1de22daa
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[170:171], v[24:25], v[128:135] ; cc464080 1e0231aa
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[138:139], v[18:19], v[152:159] ; cc464098 1e62258a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[138:139], v[20:21], v[160:167] ; cc4640a0 1e82298a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[138:139], v[22:23], v[176:183] ; cc4640b0 1ec22d8a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[138:139], v[24:25], v[184:191] ; cc4640b8 1ee2318a
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[140:141], v[18:19], v[76:83] ; cc46404c 1d32258c
	v_dual_mov_b32 v139, v17 :: v_dual_mov_b32 v138, v16        ; ca100111 8b8a0110
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[168:171], v73, s[36:39], null offen offset:3072 ; c405c07c 408048a8 000c0049
	buffer_load_b128 v[16:19], v73, s[36:39], null offen offset:7168 ; c405c07c 40804810 001c0049
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[140:141], v[20:21], v[40:47] ; cc464028 1ca2298c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[140:141], v[22:23], v[144:151] ; cc464090 1e422d8c
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[140:141], v[24:25], v[6:13] ; cc464006 1c1a318c
	ds_load_b64 v[20:21], v32 offset:1792                       ; d9d80700 14000020
	ds_load_b64 v[22:23], v32 offset:3840                       ; d9d80f00 16000020
	ds_load_b64 v[24:25], v32 offset:5888                       ; d9d81700 18000020
	ds_load_b64 v[140:141], v32 offset:7936                     ; d9d81f00 8c000020
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[172:173], v[30:31], v[88:95] ; cc464058 1d623dac
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[172:173], v[14:15], v[56:63] ; cc464038 1ce21dac
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[172:173], v[54:55], v[96:103] ; cc464060 1d826dac
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[174:175], v[14:15], v[104:111] ; cc464068 1da21dae
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[174:175], v[30:31], v[120:127] ; cc464078 1de23dae
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[172:173], v[28:29], v[64:71] ; cc464040 1d0239ac
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[174:175], v[28:29], v[112:119] ; cc464070 1dc239ae
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[174:175], v[54:55], v[128:135] ; cc464080 1e026dae
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[34:35], v[28:29], v[160:167] ; cc4640a0 1e823922
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[36:37], v[14:15], v[76:83] ; cc46404c 1d321d24
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[34:35], v[30:31], v[176:183] ; cc4640b0 1ec23d22
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[34:35], v[14:15], v[152:159] ; cc464098 1e621d22
	v_mov_b32_e32 v14, v33                                      ; 7e1c0321
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[34:35], v[54:55], v[184:191] ; cc4640b8 1ee26d22
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[172:175], v73, s[36:39], null offen offset:3584 ; c405c07c 408048ac 000e0049
	buffer_load_b128 v[32:35], v73, s[36:39], null offen offset:7680 ; c405c07c 40804820 001e0049
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[36:37], v[28:29], v[40:47] ; cc464028 1ca23924
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[30:31], v[144:151] ; cc464090 1e423d24
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[36:37], v[54:55], v[6:13] ; cc464006 1c1a6d24
	v_mad_u32_u24 v15, s59, 0x820, v49                          ; d60b000f 04c5fe3b 00000820
	ds_load_b64 v[28:29], v15                                   ; d9d80000 1c00000f
	ds_load_b64 v[30:31], v15 offset:2048                       ; d9d80800 1e00000f
	ds_load_b64 v[36:37], v15 offset:4096                       ; d9d81000 2400000f
	ds_load_b64 v[54:55], v15 offset:6144                       ; d9d81800 3600000f
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[86:87], v[112:119] ; cc464070 1dc2adaa
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[170:171], v[38:39], v[120:127] ; cc464078 1de24daa
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[170:171], v[136:137], v[128:135] ; cc464080 1e0311aa
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[168:169], v[86:87], v[64:71] ; cc464040 1d02ada8
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[168:169], v[84:85], v[56:63] ; cc464038 1ce2a9a8
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[168:169], v[136:137], v[96:103] ; cc464060 1d8311a8
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[168:169], v[38:39], v[88:95] ; cc464058 1d624da8
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[170:171], v[84:85], v[104:111] ; cc464068 1da2a9aa
	buffer_load_b128 v[168:171], v73, s[36:39], null offen offset:8192 ; c405c07c 408048a8 00200049
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[84:85], v[152:159] ; cc464098 1e62a910
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[86:87], v[160:167] ; cc4640a0 1e82ad10
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[38:39], v[176:183] ; cc4640b0 1ec24d10
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[16:17], v[136:137], v[184:191] ; cc4640b8 1ee31110
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[18:19], v[84:85], v[76:83] ; cc46404c 1d32a912
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[86:87], v[40:47] ; cc464028 1ca2ad12
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[18:19], v[38:39], v[144:151] ; cc464090 1e424d12
	ds_load_b64 v[16:17], v15 offset:256                        ; d9d80100 1000000f
	ds_load_b64 v[84:85], v15 offset:2304                       ; d9d80900 5400000f
	ds_load_b64 v[86:87], v15 offset:4352                       ; d9d81100 5600000f
	ds_load_b64 v[38:39], v15 offset:6400                       ; d9d81900 2600000f
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[18:19], v[136:137], v[6:13] ; cc464006 1c1b1112
	v_dual_mov_b32 v19, v139 :: v_dual_mov_b32 v18, v138        ; ca10018b 1312018a
	buffer_load_b128 v[136:139], v73, s[36:39], null offen offset:8704 ; c405c07c 40804888 00220049
	s_mov_b32 s61, 0x76543210                                   ; bebd00ff 76543210
	s_mov_b32 s62, 0xfedcba98                                   ; bebe00ff fedcba98
	s_movk_i32 s63, 0x410                                       ; b03f0410
	s_wait_loadcnt_dscnt 0x309                                  ; bfc80309
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[174:175], v[24:25], v[120:127] ; cc464078 1de231ae
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[174:175], v[20:21], v[104:111] ; cc464068 1da229ae
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[172:173], v[20:21], v[56:63] ; cc464038 1ce229ac
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[174:175], v[140:141], v[128:135] ; cc464080 1e0319ae
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[172:173], v[140:141], v[96:103] ; cc464060 1d8319ac
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[174:175], v[22:23], v[112:119] ; cc464070 1dc22dae
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[172:173], v[22:23], v[64:71] ; cc464040 1d022dac
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[172:173], v[24:25], v[88:95] ; cc464058 1d6231ac
	v_dual_mul_f32 v143, v107, v107 :: v_dual_mul_f32 v142, v105, v105 ; c8c6d76b 8f8ed369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v143, v59, v59 :: v_dual_fmac_f32 v142, v57, v57 ; c800773b 8f8e7339
	v_dual_fmac_f32 v143, v63, v63 :: v_dual_fmac_f32 v142, v61, v61 ; c8007f3f 8f8e7b3d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v143, v111, v111 :: v_dual_fmac_f32 v142, v109, v109 ; c800df6f 8f8edb6d
	v_dual_fmac_f32 v143, v58, v58 :: v_dual_fmac_f32 v142, v56, v56 ; c800753a 8f8e7138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v143, v106, v106 :: v_dual_fmac_f32 v142, v104, v104 ; c800d56a 8f8ed168
	v_dual_fmac_f32 v143, v62, v62 :: v_dual_fmac_f32 v142, v60, v60 ; c8007d3e 8f8e793c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v143, v110, v110 :: v_dual_fmac_f32 v142, v108, v108 ; c800dd6e 8f8ed96c
	v_fma_mixlo_f16 v172, 1.0, v142, v143                       ; cc2100ac 063f1cf2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5eb00ad
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	v_permlanex16_b32 v173, v173, s61, s62 op_sel:[1,1]         ; d65c18ad 00f87bad
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53200ac
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d53100ac
	v_cndmask_b32_e32 v1, s63, v172, vcc_lo                     ; 0203583f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
	v_rsq_f32_e32 v174, v174                                    ; 7f5c5dae
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v174, v174, v72                               ; 115c91ae
	v_dual_mul_f32 v104, v104, v174 :: v_dual_mul_f32 v105, v105, v174 ; c8c75d68 68695d69
	v_dual_mul_f32 v59, v59, v174 :: v_dual_mul_f32 v58, v58, v174 ; c8c75d3b 3b3b5d3a
	v_dual_mul_f32 v106, v106, v174 :: v_dual_mul_f32 v107, v107, v174 ; c8c75d6a 6a6b5d6b
	v_dual_mul_f32 v61, v61, v174 :: v_dual_mul_f32 v60, v60, v174 ; c8c75d3d 3d3d5d3c
	v_dual_mul_f32 v57, v57, v174 :: v_dual_mul_f32 v56, v56, v174 ; c8c75d39 39395d38
	v_dual_mul_f32 v108, v108, v174 :: v_dual_mul_f32 v109, v109, v174 ; c8c75d6c 6c6d5d6d
	v_dual_mul_f32 v63, v63, v174 :: v_dual_mul_f32 v62, v62, v174 ; c8c75d3f 3f3f5d3e
	v_dual_mul_f32 v111, v111, v174 :: v_dual_mul_f32 v110, v110, v174 ; c8c75d6f 6f6f5d6e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
	v_dual_mul_f32 v175, v113, v113 :: v_dual_mul_f32 v60, v115, v115 ; c8c6e371 af3ce773
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_dual_fmac_f32 v175, v65, v65 :: v_dual_fmac_f32 v60, v67, v67 ; c8008341 af3c8743
	v_dual_fmac_f32 v60, v71, v71 :: v_dual_fmac_f32 v175, v69, v69 ; c8008f47 3cae8b45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v60, v119, v119 :: v_dual_fmac_f32 v175, v117, v117 ; c800ef77 3caeeb75
	v_dual_fmac_f32 v60, v66, v66 :: v_dual_fmac_f32 v175, v64, v64 ; c8008542 3cae8140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v60, v114, v114 :: v_dual_fmac_f32 v175, v112, v112 ; c800e572 3caee170
	v_dual_fmac_f32 v60, v70, v70 :: v_dual_fmac_f32 v175, v68, v68 ; c8008d46 3cae8944
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v60, v118, v118 :: v_dual_fmac_f32 v175, v116, v116 ; c800ed76 3caee974
	v_fma_mixlo_f16 v61, 1.0, v175, v60                         ; cc21003d 04f35ef2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v62, v61                                  ; 7e7cd73d
	v_permlanex16_b32 v62, v62, s61, s62 op_sel:[1,1]           ; d65c183e 00f87b3e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v61, v61, v62                                 ; 647a7d3d
	v_max_num_f16_e32 v61, s63, v61                             ; 627a7a3f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v63, v61                                  ; 7e7e173d
	v_rsq_f32_e32 v63, v63                                      ; 7e7e5d3f
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v63, v63, v72                                 ; 107e913f
	v_dual_mul_f32 v113, v113, v63 :: v_dual_mul_f32 v112, v112, v63 ; c8c67f71 71707f70
	v_dual_mul_f32 v115, v115, v63 :: v_dual_mul_f32 v114, v114, v63 ; c8c67f73 73727f72
	v_dual_mul_f32 v117, v117, v63 :: v_dual_mul_f32 v116, v116, v63 ; c8c67f75 75747f74
	v_dual_mul_f32 v64, v64, v63 :: v_dual_mul_f32 v65, v65, v63 ; c8c67f40 40407f41
	v_dual_mul_f32 v119, v119, v63 :: v_dual_mul_f32 v118, v118, v63 ; c8c67f77 77767f76
	v_dual_mul_f32 v66, v66, v63 :: v_dual_mul_f32 v67, v67, v63 ; c8c67f42 42427f43
	v_dual_mul_f32 v68, v68, v63 :: v_dual_mul_f32 v69, v69, v63 ; c8c67f44 44447f45
	v_dual_mul_f32 v71, v71, v63 :: v_dual_mul_f32 v70, v70, v63 ; c8c67f47 47467f46
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v67, v123, v123 :: v_dual_mul_f32 v66, v121, v121 ; c8c6f77b 4342f379
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_dual_fmac_f32 v67, v91, v91 :: v_dual_fmac_f32 v66, v89, v89 ; c800b75b 4342b359
	v_dual_fmac_f32 v67, v95, v95 :: v_dual_fmac_f32 v66, v93, v93 ; c800bf5f 4342bb5d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v67, v127, v127 :: v_dual_fmac_f32 v66, v125, v125 ; c800ff7f 4342fb7d
	v_dual_fmac_f32 v67, v90, v90 :: v_dual_fmac_f32 v66, v88, v88 ; c800b55a 4342b158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v67, v122, v122 :: v_dual_fmac_f32 v66, v120, v120 ; c800f57a 4342f178
	v_dual_fmac_f32 v67, v94, v94 :: v_dual_fmac_f32 v66, v92, v92 ; c800bd5e 4342b95c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v67, v126, v126 :: v_dual_fmac_f32 v66, v124, v124 ; c800fd7e 4342f97c
	v_fma_mixlo_f16 v68, 1.0, v66, v67                          ; cc210044 050e84f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v69, v68                                  ; 7e8ad744
	v_permlanex16_b32 v69, v69, s61, s62 op_sel:[1,1]           ; d65c1845 00f87b45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v68, v68, v69                                 ; 64888b44
	v_max_num_f16_e32 v68, s63, v68                             ; 6288883f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v70, v68                                  ; 7e8c1744
	v_rsq_f32_e32 v70, v70                                      ; 7e8c5d46
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[20:21], v[152:159] ; cc464098 1e622920
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[32:33], v[22:23], v[160:167] ; cc4640a0 1e822d20
	v_mul_f32_e32 v70, v70, v72                                 ; 108c9146
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[32:33], v[24:25], v[176:183] ; cc4640b0 1ec23120
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[32:33], v[140:141], v[184:191] ; cc4640b8 1ee31920
	v_dual_mul_f32 v91, v91, v70 :: v_dual_mul_f32 v90, v90, v70 ; c8c68d5b 5b5a8d5a
	v_dual_mul_f32 v120, v120, v70 :: v_dual_mul_f32 v121, v121, v70 ; c8c68d78 78788d79
	v_dual_mul_f32 v89, v89, v70 :: v_dual_mul_f32 v88, v88, v70 ; c8c68d59 59588d58
	v_dual_mul_f32 v93, v93, v70 :: v_dual_mul_f32 v92, v92, v70 ; c8c68d5d 5d5c8d5c
	v_dual_mul_f32 v122, v122, v70 :: v_dual_mul_f32 v123, v123, v70 ; c8c68d7a 7a7a8d7b
	v_dual_mul_f32 v124, v124, v70 :: v_dual_mul_f32 v125, v125, v70 ; c8c68d7c 7c7c8d7d
	v_dual_mul_f32 v95, v95, v70 :: v_dual_mul_f32 v94, v94, v70 ; c8c68d5f 5f5e8d5e
	v_dual_mul_f32 v127, v127, v70 :: v_dual_mul_f32 v126, v126, v70 ; c8c68d7f 7f7e8d7e
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[34:35], v[20:21], v[76:83] ; cc46404c 1d322922
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[34:35], v[22:23], v[40:47] ; cc464028 1ca22d22
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[34:35], v[24:25], v[144:151] ; cc464090 1e423122
	v_wmma_f32_16x16x16_fp8_fp8 v[6:13], v[34:35], v[140:141], v[6:13] ; cc464006 1c1b1922
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_dual_mul_f32 v88, v131, v131 :: v_dual_mul_f32 v71, v129, v129 ; c8c70783 58470381
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_fmac_f32 v88, v99, v99 :: v_dual_fmac_f32 v71, v97, v97 ; c800c763 5846c361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v88, v103, v103 :: v_dual_fmac_f32 v71, v101, v101 ; c800cf67 5846cb65
	v_dual_fmac_f32 v88, v135, v135 :: v_dual_fmac_f32 v71, v133, v133 ; c8010f87 58470b85
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v88, v98, v98 :: v_dual_fmac_f32 v71, v96, v96 ; c800c562 5846c160
	v_dual_fmac_f32 v88, v130, v130 :: v_dual_fmac_f32 v71, v128, v128 ; c8010582 58470180
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v88, v102, v102 :: v_dual_fmac_f32 v71, v100, v100 ; c800cd66 5846c964
	v_dual_fmac_f32 v88, v134, v134 :: v_dual_fmac_f32 v71, v132, v132 ; c8010d86 58470984
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v89, 1.0, v71, v88                          ; cc210059 05628ef2
	v_cvt_u32_u16_e32 v90, v89                                  ; 7eb4d759
	v_dual_mul_f32 v93, v79, v79 :: v_dual_mul_f32 v92, v77, v77 ; c8c69f4f 5d5c9b4d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v90, v90, s61, s62 op_sel:[1,1]           ; d65c185a 00f87b5a
	v_dual_fmac_f32 v93, v155, v155 :: v_dual_fmac_f32 v92, v153, v153 ; c801379b 5d5d3399
	v_add_f16_e32 v89, v89, v90                                 ; 64b2b559
	v_dual_fmac_f32 v93, v159, v159 :: v_dual_fmac_f32 v92, v157, v157 ; c8013f9f 5d5d3b9d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_max_num_f16_e32 v89, s63, v89                             ; 62b2b23f
	v_dual_fmac_f32 v93, v83, v83 :: v_dual_fmac_f32 v92, v81, v81 ; c800a753 5d5ca351
	v_cvt_f32_f16_e32 v91, v89                                  ; 7eb61759
	v_dual_fmac_f32 v93, v154, v154 :: v_dual_fmac_f32 v92, v152, v152 ; c801359a 5d5d3198
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a2
	v_rsq_f32_e32 v91, v91                                      ; 7eb65d5b
	v_dual_fmac_f32 v93, v78, v78 :: v_dual_fmac_f32 v92, v76, v76 ; c8009d4e 5d5c994c
	v_mul_f32_e32 v91, v91, v72                                 ; 10b6915b
	v_dual_fmac_f32 v93, v158, v158 :: v_dual_fmac_f32 v92, v156, v156 ; c8013d9e 5d5d399c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v96, v96, v91 :: v_dual_mul_f32 v97, v97, v91 ; c8c6b760 6060b761
	v_dual_mul_f32 v135, v135, v91 :: v_dual_mul_f32 v134, v134, v91 ; c8c6b787 8786b786
	v_dual_mul_f32 v133, v133, v91 :: v_dual_mul_f32 v132, v132, v91 ; c8c6b785 8584b784
	v_dual_mul_f32 v103, v103, v91 :: v_dual_mul_f32 v102, v102, v91 ; c8c6b767 6766b766
	v_dual_mul_f32 v100, v100, v91 :: v_dual_mul_f32 v101, v101, v91 ; c8c6b764 6464b765
	v_dual_mul_f32 v98, v98, v91 :: v_dual_mul_f32 v99, v99, v91 ; c8c6b762 6262b763
	v_dual_mul_f32 v129, v129, v91 :: v_dual_mul_f32 v128, v128, v91 ; c8c6b781 8180b780
	v_dual_mul_f32 v131, v131, v91 :: v_dual_mul_f32 v130, v130, v91 ; c8c6b783 8382b782
	v_dual_fmac_f32 v93, v82, v82 :: v_dual_fmac_f32 v92, v80, v80 ; c800a552 5d5ca150
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	buffer_load_b128 v[68:71], v73, s[36:39], null offen offset:9216 ; c405c07c 40804844 00240049
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mixlo_f16 v94, 1.0, v92, v93                          ; cc21005e 0576b8f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v95, v94                                  ; 7ebed75e
	v_permlanex16_b32 v95, v95, s61, s62 op_sel:[1,1]           ; d65c185f 00f87b5f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v94, v94, v95                                 ; 64bcbf5e
	v_max_num_f16_e32 v94, s63, v94                             ; 62bcbc3f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v96, v94                                  ; 7ec0175e
	v_rsq_f32_e32 v96, v96                                      ; 7ec05d60
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870135
	v_mul_f32_e32 v152, v152, v96                               ; 1130c198
	v_dual_mul_f32 v77, v77, v96 :: v_dual_mul_f32 v76, v76, v96 ; c8c6c14d 4d4cc14c
	v_dual_mul_f32 v79, v79, v96 :: v_dual_mul_f32 v78, v78, v96 ; c8c6c14f 4f4ec14e
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	buffer_load_b128 v[76:79], v73, s[36:39], null offen offset:9728 ; c405c07c 4080484c 00260049
	v_dual_mul_f32 v81, v81, v96 :: v_dual_mul_f32 v80, v80, v96 ; c8c6c151 5150c150
	v_mul_f32_e32 v157, v157, v96                               ; 113ac19d
	v_dual_mul_f32 v155, v155, v96 :: v_dual_mul_f32 v156, v156, v96 ; c8c6c19b 9b9cc19c
	v_dual_mul_f32 v159, v159, v96 :: v_dual_mul_f32 v158, v158, v96 ; c8c6c19f 9f9ec19e
	v_dual_mul_f32 v153, v153, v96 :: v_dual_mul_f32 v154, v154, v96 ; c8c6c199 999ac19a
	v_mul_f32_e32 v83, v83, v96                                 ; 10a6c153
	v_mul_f32_e32 v97, v41, v41                                 ; 10c25329
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fmac_f32_e32 v97, v161, v161                              ; 56c343a1
	v_dual_fmac_f32 v97, v165, v165 :: v_dual_mul_f32 v82, v82, v96 ; c8074ba5 6152c152
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	buffer_load_b128 v[80:83], v73, s[36:39], null offen offset:10240 ; c405c07c 40804850 00280049
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_dual_fmac_f32 v97, v45, v45 :: v_dual_mul_f32 v98, v43, v43 ; c8065b2d 6162572b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v97, v160, v160 :: v_dual_fmac_f32 v98, v163, v163 ; c80141a0 616347a3
	v_dual_fmac_f32 v97, v40, v40 :: v_dual_fmac_f32 v98, v167, v167 ; c8005128 61634fa7
	buffer_load_b128 v[88:91], v73, s[36:39], null offen offset:10752 ; c405c07c 40804858 002a0049
	v_dual_fmac_f32 v97, v164, v164 :: v_dual_fmac_f32 v98, v47, v47 ; c80149a4 61625f2f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v98, v162, v162                              ; 56c545a2
	v_fmac_f32_e32 v98, v42, v42                                ; 56c4552a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v98, v166, v166                              ; 56c54da6
	v_dual_fmac_f32 v98, v46, v46 :: v_dual_fmac_f32 v97, v44, v44 ; c8005d2e 6260592c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v99, 1.0, v97, v98                          ; cc210063 058ac2f2
	v_cvt_u32_u16_e32 v100, v99                                 ; 7ec8d763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v100, v100, s61, s62 op_sel:[1,1]         ; d65c1864 00f87b64
	v_add_f16_e32 v99, v99, v100                                ; 64c6c963
	buffer_load_b128 v[92:95], v73, s[36:39], null offen offset:11264 ; c405c07c 4080485c 002c0049
	v_max_num_f16_e32 v99, s63, v99                             ; 62c6c63f
	v_mul_f32_e32 v102, v145, v145                              ; 10cd2391
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v101, v99                                 ; 7eca1763
	v_dual_fmac_f32 v102, v177, v177 :: v_dual_mul_f32 v103, v147, v147 ; c80763b1 66672793
	v_rsq_f32_e32 v101, v101                                    ; 7eca5d65
	v_dual_fmac_f32 v102, v181, v181 :: v_dual_fmac_f32 v103, v179, v179 ; c8016bb5 666767b3
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_fmac_f32 v102, v149, v149 :: v_dual_fmac_f32 v103, v183, v183 ; c8012b95 66676fb7
	v_dual_mul_f32 v160, v160, v101 :: v_dual_mul_f32 v161, v161, v101 ; c8c6cba0 a0a0cba1
	v_dual_mul_f32 v43, v43, v101 :: v_dual_mul_f32 v42, v42, v101 ; c8c6cb2b 2b2acb2a
	v_dual_mul_f32 v47, v47, v101 :: v_dual_mul_f32 v46, v46, v101 ; c8c6cb2f 2f2ecb2e
	v_dual_mul_f32 v45, v45, v101 :: v_dual_mul_f32 v44, v44, v101 ; c8c6cb2d 2d2ccb2c
	v_dual_mul_f32 v41, v41, v101 :: v_dual_mul_f32 v40, v40, v101 ; c8c6cb29 2928cb28
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	buffer_load_b128 v[44:47], v73, s[36:39], null offen offset:11776 ; c405c07c 4080482c 002e0049
	v_dual_mul_f32 v163, v163, v101 :: v_dual_mul_f32 v162, v162, v101 ; c8c6cba3 a3a2cba2
	v_dual_mul_f32 v167, v167, v101 :: v_dual_mul_f32 v166, v166, v101 ; c8c6cba7 a7a6cba6
	v_dual_mul_f32 v165, v165, v101 :: v_dual_mul_f32 v164, v164, v101 ; c8c6cba5 a5a4cba4
	v_fmac_f32_e32 v103, v151, v151                             ; 56cf2f97
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_dual_fmac_f32 v103, v178, v178 :: v_dual_fmac_f32 v102, v176, v176 ; c80165b2 676761b0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v103, v146, v146 :: v_dual_fmac_f32 v102, v144, v144 ; c8012592 67672190
	v_dual_fmac_f32 v103, v182, v182 :: v_dual_fmac_f32 v102, v180, v180 ; c8016db6 676769b4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v103, v150, v150 :: v_dual_fmac_f32 v102, v148, v148 ; c8012d96 67672994
	v_fma_mixlo_f16 v104, 1.0, v102, v103                       ; cc210068 059eccf2
	v_dual_mul_f32 v108, v9, v9 :: v_dual_mul_f32 v107, v7, v7  ; c8c61309 6c6a0f07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_u32_u16_e32 v105, v104                                ; 7ed2d768
	v_dual_fmac_f32 v108, v187, v187 :: v_dual_fmac_f32 v107, v185, v185 ; c80177bb 6c6b73b9
	v_permlanex16_b32 v105, v105, s61, s62 op_sel:[1,1]         ; d65c1869 00f87b69
	v_dual_fmac_f32 v108, v191, v191 :: v_dual_fmac_f32 v107, v189, v189 ; c8017fbf 6c6b7bbd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_add_f16_e32 v104, v104, v105                              ; 64d0d368
	v_dual_fmac_f32 v108, v13, v13 :: v_dual_fmac_f32 v107, v11, v11 ; c8001b0d 6c6a170b
	v_max_num_f16_e32 v104, s63, v104                           ; 62d0d03f
	v_dual_fmac_f32 v108, v186, v186 :: v_dual_fmac_f32 v107, v184, v184 ; c80175ba 6c6b71b8
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v106, v104                                ; 7ed41768
	v_dual_fmac_f32 v108, v8, v8 :: v_dual_fmac_f32 v107, v6, v6 ; c8001108 6c6a0d06
	v_rsq_f32_e32 v106, v106                                    ; 7ed45d6a
	v_dual_fmac_f32 v108, v190, v190 :: v_dual_fmac_f32 v107, v188, v188 ; c8017dbe 6c6b79bc
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v179, v179, v106 :: v_dual_mul_f32 v178, v178, v106 ; c8c6d5b3 b3b2d5b2
	v_dual_mul_f32 v147, v147, v106 :: v_dual_mul_f32 v146, v146, v106 ; c8c6d593 9392d592
	v_dual_mul_f32 v149, v149, v106 :: v_dual_mul_f32 v148, v148, v106 ; c8c6d595 9594d594
	v_dual_mul_f32 v151, v151, v106 :: v_dual_mul_f32 v150, v150, v106 ; c8c6d597 9796d596
	v_dual_mul_f32 v177, v177, v106 :: v_dual_mul_f32 v176, v176, v106 ; c8c6d5b1 b1b0d5b0
	v_dual_mul_f32 v183, v183, v106 :: v_dual_mul_f32 v182, v182, v106 ; c8c6d5b7 b7b6d5b6
	v_dual_mul_f32 v181, v181, v106 :: v_dual_mul_f32 v180, v180, v106 ; c8c6d5b5 b5b4d5b4
	v_dual_mul_f32 v145, v145, v106 :: v_dual_mul_f32 v144, v144, v106 ; c8c6d591 9190d590
	v_dual_fmac_f32 v108, v12, v12 :: v_dual_fmac_f32 v107, v10, v10 ; c800190c 6c6a150a
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_lshl_add_u32 v112, v1, 12, s8                             ; d6460070 00211901
	v_fma_mixlo_f16 v109, 1.0, v107, v108                       ; cc21006d 05b2d6f2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_lshl_add_u32 v4, v4, 6, v112                              ; d6460004 05c10d04
	v_add_lshl_u32 v4, v4, v3, 2                                ; d6470004 020a0704
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[100:103], v4, s[32:35], null offen       ; c405c07c 40804064 00000004
	buffer_load_b128 v[104:107], v4, s[32:35], null offen offset:16 ; c405c07c 40804068 00001004
	v_cvt_u32_u16_e32 v110, v109                                ; 7edcd76d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v110, v110, s61, s62 op_sel:[1,1]         ; d65c186e 00f87b6e
	v_add_f16_e32 v109, v109, v110                              ; 64dadd6d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v109, s63, v109                           ; 62dada3f
	v_cvt_f32_f16_e32 v111, v109                                ; 7ede176d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_rsq_f32_e32 v111, v111                                    ; 7ede5d6f
	ds_load_b64 v[98:99], v15 offset:512                        ; d9d80200 6200000f
	ds_load_b64 v[108:109], v15 offset:2560                     ; d9d80a00 6c00000f
	ds_load_b64 v[112:113], v15 offset:4608                     ; d9d81200 7000000f
	ds_load_b64 v[114:115], v15 offset:6656                     ; d9d81a00 7200000f
	v_dual_mul_f32 v184, v184, v111 :: v_dual_mul_f32 v185, v185, v111 ; c8c6dfb8 b8b8dfb9
	v_dual_mul_f32 v7, v7, v111 :: v_dual_mul_f32 v6, v6, v111  ; c8c6df07 0706df06
	v_mul_f32_e32 v188, v188, v111                              ; 1178dfbc
	v_dual_mul_f32 v191, v191, v111 :: v_dual_mul_f32 v190, v190, v111 ; c8c6dfbf bfbedfbe
	v_mul_f32_e32 v189, v189, v111                              ; 117adfbd
	v_dual_mul_f32 v11, v11, v111 :: v_dual_mul_f32 v10, v10, v111 ; c8c6df0b 0b0adf0a
	v_dual_mul_f32 v13, v13, v111 :: v_dual_mul_f32 v12, v12, v111 ; c8c6df0d 0d0cdf0c
	v_dual_mul_f32 v9, v9, v111 :: v_dual_mul_f32 v8, v8, v111  ; c8c6df09 0908df08
	v_dual_mul_f32 v186, v186, v111 :: v_dual_mul_f32 v187, v187, v111 ; c8c6dfba babadfbb
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
	ds_load_b64 v[8:9], v15 offset:768                          ; d9d80300 0800000f
	ds_load_b64 v[10:11], v15 offset:2816                       ; d9d80b00 0a00000f
	ds_load_b64 v[12:13], v15 offset:4864                       ; d9d81300 0c00000f
	ds_load_b64 v[110:111], v15 offset:6912                     ; d9d81b00 6e00000f
(invalid instruction)                                        ; d7690060
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	s_wait_loadcnt_dscnt 0x90f                                  ; bfc8090f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[168:169], 0 ; cc464078 1a03511c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[28:29], v[170:171], 0 ; cc4640a0 1a03551c
	v_dual_mov_b32 v29, v171 :: v_dual_mov_b32 v28, v170        ; ca1001ab 1d1c01aa
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[168:169], 0 ; cc464080 1a03511e
(invalid instruction)                                        ; d7690061
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694061
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[168:169], 0 ; cc464090 1a035124
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[54:55], v[168:169], 0 ; cc464098 1a035136
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[170:171], 0 ; cc4640b0 1a03551e
(invalid instruction)                                        ; d7694060
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[36:37], v[170:171], 0 ; cc4640b8 1a035524
	s_wait_loadcnt_dscnt 0x80b                                  ; bfc8080b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[136:137], v[120:127] ; cc464078 1de31110
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[54:55], v[28:29], 0 ; cc4640a8 1a023936
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[138:139], v[160:167] ; cc4640a0 1e831510
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[84:85], v[136:137], v[128:135] ; cc464080 1e031154
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[86:87], v[136:137], v[144:151] ; cc464090 1e431156
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[38:39], v[136:137], v[152:159] ; cc464098 1e631126
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[84:85], v[138:139], v[176:183] ; cc4640b0 1ec31554
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[86:87], v[138:139], v[184:191] ; cc4640b8 1ee31556
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[38:39], v[138:139], v[168:175] ; cc4640a8 1ea31526
	ds_load_b64 v[28:29], v15 offset:1024                       ; d9d80400 1c00000f
	ds_load_b64 v[30:31], v15 offset:3072                       ; d9d80c00 1e00000f
	ds_load_b64 v[36:37], v15 offset:5120                       ; d9d81400 2400000f
	ds_load_b64 v[54:55], v15 offset:7168                       ; d9d81c00 3600000f
	ds_load_b64 v[16:17], v15 offset:1280                       ; d9d80500 1000000f
	ds_load_b64 v[38:39], v15 offset:3328                       ; d9d80d00 2600000f
	ds_load_b64 v[84:85], v15 offset:5376                       ; d9d81500 5400000f
	ds_load_b64 v[86:87], v15 offset:7424                       ; d9d81d00 5600000f
	s_wait_loadcnt_dscnt 0x70f                                  ; bfc8070f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[98:99], v[68:69], v[120:127] ; cc464078 1de28962
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[108:109], v[68:69], v[128:135] ; cc464080 1e02896c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[98:99], v[70:71], v[160:167] ; cc4640a0 1e828d62
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[112:113], v[68:69], v[144:151] ; cc464090 1e428970
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[114:115], v[68:69], v[152:159] ; cc464098 1e628972
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[108:109], v[70:71], v[176:183] ; cc4640b0 1ec28d6c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[112:113], v[70:71], v[184:191] ; cc4640b8 1ee28d70
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[114:115], v[70:71], v[168:175] ; cc4640a8 1ea28d72
	s_wait_loadcnt_dscnt 0x60b                                  ; bfc8060b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[8:9], v[76:77], v[120:127] ; cc464078 1de29908
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[76:77], v[128:135] ; cc464080 1e02990a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[8:9], v[78:79], v[160:167] ; cc4640a0 1e829d08
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[12:13], v[76:77], v[144:151] ; cc464090 1e42990c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[110:111], v[76:77], v[152:159] ; cc464098 1e62996e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[10:11], v[78:79], v[176:183] ; cc4640b0 1ec29d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[12:13], v[78:79], v[184:191] ; cc4640b8 1ee29d0c
	ds_load_b64 v[68:69], v15 offset:1536                       ; d9d80600 4400000f
	ds_load_b64 v[70:71], v15 offset:3584                       ; d9d80e00 4600000f
	ds_load_b64 v[98:99], v15 offset:5632                       ; d9d81600 6200000f
	ds_load_b64 v[108:109], v15 offset:7680                     ; d9d81e00 6c00000f
	ds_load_b64 v[8:9], v15 offset:1792                         ; d9d80700 0800000f
	ds_load_b64 v[10:11], v15 offset:3840                       ; d9d80f00 0a00000f
	ds_load_b64 v[12:13], v15 offset:5888                       ; d9d81700 0c00000f
	ds_load_b64 v[76:77], v15 offset:7936                       ; d9d81f00 4c00000f
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[110:111], v[78:79], v[168:175] ; cc4640a8 1ea29d6e
	s_wait_loadcnt_dscnt 0x50f                                  ; bfc8050f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[80:81], v[120:127] ; cc464078 1de2a11c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[80:81], v[128:135] ; cc464080 1e02a11e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[28:29], v[82:83], v[160:167] ; cc4640a0 1e82a51c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[80:81], v[144:151] ; cc464090 1e42a124
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[54:55], v[80:81], v[152:159] ; cc464098 1e62a136
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[30:31], v[82:83], v[176:183] ; cc4640b0 1ec2a51e
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[28:31], v4, s[32:35], null offen offset:64 ; c405c07c 4080401c 00004004
	buffer_load_b128 v[112:115], v4, s[32:35], null offen offset:80 ; c405c07c 40804070 00005004
	buffer_load_b128 v[116:119], v4, s[32:35], null offen offset:128 ; c405c07c 40804074 00008004
	buffer_load_b128 v[136:139], v4, s[32:35], null offen offset:144 ; c405c07c 40804088 00009004
	buffer_load_b128 v[140:143], v4, s[32:35], null offen offset:192 ; c405c07c 4080408c 0000c004
	buffer_load_b128 v[78:81], v4, s[32:35], null offen offset:208 ; c405c07c 4080404e 0000d004
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[36:37], v[82:83], v[184:191] ; cc4640b8 1ee2a524
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[54:55], v[82:83], v[168:175] ; cc4640a8 1ea2a536
	s_wait_loadcnt_dscnt 0xa0b                                  ; bfc80a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[88:89], v[120:127] ; cc464078 1de2b110
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[38:39], v[88:89], v[128:135] ; cc464080 1e02b126
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[90:91], v[160:167] ; cc4640a0 1e82b510
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[84:85], v[88:89], v[144:151] ; cc464090 1e42b154
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[86:87], v[88:89], v[152:159] ; cc464098 1e62b156
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[90:91], v[176:183] ; cc4640b0 1ec2b526
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[84:85], v[90:91], v[184:191] ; cc4640b8 1ee2b554
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[86:87], v[90:91], v[168:175] ; cc4640a8 1ea2b556
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[92:93], v[120:127] ; cc464078 1de2b944
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[92:93], v[128:135] ; cc464080 1e02b946
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[94:95], v[160:167] ; cc4640a0 1e82bd44
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[98:99], v[92:93], v[144:151] ; cc464090 1e42b962
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[92:93], v[152:159] ; cc464098 1e62b96c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[94:95], v[176:183] ; cc4640b0 1ec2bd46
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[94:95], v[184:191] ; cc4640b8 1ee2bd62
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[108:109], v[94:95], v[168:175] ; cc4640a8 1ea2bd6c
	s_wait_loadcnt_dscnt 0x803                                  ; bfc80803
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[8:9], v[44:45], v[120:127] ; cc464078 1de25908
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[44:45], v[128:135] ; cc464080 1e02590a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[8:9], v[46:47], v[160:167] ; cc4640a0 1e825d08
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[12:13], v[44:45], v[144:151] ; cc464090 1e42590c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[76:77], v[44:45], v[152:159] ; cc464098 1e62594c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[10:11], v[46:47], v[176:183] ; cc4640b0 1ec25d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[12:13], v[46:47], v[184:191] ; cc4640b8 1ee25d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[76:77], v[46:47], v[168:175] ; cc4640a8 1ea25d4c
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[56:57], 0 ; cc464058 1a027120
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[66:67], v[56:57], 0 ; cc464078 1a027142
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[56:57], 0 ; cc464080 1a02712a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[56:57], 0 ; cc464090 1a027160
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[34:35], v[58:59], v[88:95] ; cc464058 1d627522
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[58:59], v[120:127] ; cc464078 1de27528
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[58:59], v[128:135] ; cc464080 1e027548
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[6:7], v[58:59], v[144:151] ; cc464090 1e427506
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[56:59], v4, s[32:35], null offen offset:4096 ; c405c07c 40804038 00100004
	buffer_load_b128 v[68:71], v4, s[32:35], null offen offset:4112 ; c405c07c 40804044 00101004
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s64, 0x3d380000                                   ; bec000ff 3d380000
	s_movk_i32 s65, 0x3e47                                      ; b0413e47
	s_movk_i32 s66, 0x3c20                                      ; b0423c20
	buffer_load_b128 v[84:87], v4, s[32:35], null offen offset:4160 ; c405c07c 40804054 00104004
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v152, s64, v88, v100                        ; cc210098 0592b040
	v_fma_mixhi_f16 v152, s64, v89, v101                        ; cc220098 0596b240
	v_fma_mixlo_f16 v153, s64, v90, v102                        ; cc210099 059ab440
	v_fma_mixhi_f16 v153, s64, v91, v103                        ; cc220099 059eb640
	buffer_load_b128 v[88:91], v4, s[32:35], null offen offset:4176 ; c405c07c 40804058 00105004
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v155, s64, v94, v106                        ; cc21009b 05aabc40
	v_fma_mixhi_f16 v155, s64, v95, v107                        ; cc22009b 05aebe40
	v_fma_mixlo_f16 v154, s64, v92, v104                        ; cc21009a 05a2b840
	v_fma_mixhi_f16 v154, s64, v93, v105                        ; cc22009a 05a6ba40
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v156, s64, v120, v28                        ; cc21009c 0472f040
	v_fma_mixhi_f16 v156, s64, v121, v29                        ; cc22009c 0476f240
	v_fma_mixlo_f16 v157, s64, v122, v30                        ; cc21009d 047af440
(invalid instruction)                                        ; cc1c0098
	v_subrev_f32_e32 v0, v152, v66                              ; 0a008598
	v_fma_mixhi_f16 v157, s64, v123, v31                        ; cc22009d 047ef640
(invalid instruction)                                        ; cc1c0099
	v_subrev_f32_e32 v0, v153, v66                              ; 0a008599
	s_mov_b32 s67, 0x7ff88000                                   ; bec300ff 7ff88000
(invalid instruction)                                        ; cc1c009b
	v_subrev_f32_e32 v0, v155, v66                              ; 0a00859b
(invalid instruction)                                        ; cc1c009a
	v_subrev_f32_e32 v0, v154, v66                              ; 0a00859a
(invalid instruction)                                        ; cc1c009c
	v_subrev_f32_e32 v0, v156, v66                              ; 0a00859c
(invalid instruction)                                        ; cc1b0098
	v_subrev_f32_e32 v0, v152, v65                              ; 0a008398
(invalid instruction)                                        ; cc1c009d
	v_subrev_f32_e32 v0, v157, v66                              ; 0a00859d
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v4, s[32:35], null offen offset:4224 ; c405c07c 4080401c 00108004
	buffer_load_b128 v[92:95], v4, s[32:35], null offen offset:4240 ; c405c07c 4080405c 00109004
(invalid instruction)                                        ; cc1b0099
	v_subrev_f32_e32 v0, v153, v65                              ; 0a008399
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v160, s64, v124, v112                       ; cc2100a0 05c2f840
(invalid instruction)                                        ; cc1b009b
	v_subrev_f32_e32 v0, v155, v65                              ; 0a00839b
	v_fma_mixhi_f16 v160, s64, v125, v113                       ; cc2200a0 05c6fa40
(invalid instruction)                                        ; cc1b009a
	v_subrev_f32_e32 v0, v154, v65                              ; 0a00839a
(invalid instruction)                                        ; cc1b009c
	v_subrev_f32_e32 v0, v156, v65                              ; 0a00839c
	v_lshl_add_u32 v152, v152, 5, s67                           ; d6460098 010d0b98
	v_fma_mixlo_f16 v161, s64, v126, v114                       ; cc2100a1 05cafc40
(invalid instruction)                                        ; cc1b009d
	v_subrev_f32_e32 v0, v157, v65                              ; 0a00839d
	v_fma_mixhi_f16 v161, s64, v127, v115                       ; cc2200a1 05cefe40
	v_lshl_add_u32 v153, v153, 5, s67                           ; d6460099 010d0b99
	v_lshl_add_u32 v155, v155, 5, s67                           ; d646009b 010d0b9b
(invalid instruction)                                        ; cc1c00a0
	v_subrev_f32_e32 v0, v160, v66                              ; 0a0085a0
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[32:33], v[60:61], 0 ; cc464068 1a027920
	v_lshl_add_u32 v154, v154, 5, s67                           ; d646009a 010d0b9a
	v_lshl_add_u32 v156, v156, 5, s67                           ; d646009c 010d0b9c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[100:103], v4, s[32:35], null offen offset:4288 ; c405c07c 40804064 0010c004
	buffer_load_b128 v[112:115], v4, s[32:35], null offen offset:4304 ; c405c07c 40804070 0010d004
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v164, s64, v128, v116                       ; cc2100a4 05d30040
	v_fma_mixhi_f16 v164, s64, v129, v117                       ; cc2200a4 05d70240
	v_lshl_add_u32 v157, v157, 5, s67                           ; d646009d 010d0b9d
(invalid instruction)                                        ; cc1c00a1
	v_subrev_f32_e32 v0, v161, v66                              ; 0a0085a1
(invalid instruction)                                        ; cc1b00a0
	v_subrev_f32_e32 v0, v160, v65                              ; 0a0083a0
	v_fma_mixlo_f16 v165, s64, v130, v118                       ; cc2100a5 05db0440
	v_fma_mixhi_f16 v165, s64, v131, v119                       ; cc2200a5 05df0640
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[152:153], v[156:157]            ; 1a033998
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[66:67], v[60:61], 0 ; cc464078 1a027942
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v66                              ; 0a0085a4
(invalid instruction)                                        ; cc0f009f
	v_min_num_f64_e32 v[1:2], v[153:154], v[157:158]            ; 1a033b99
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v166, s64, v132, v136                       ; cc2100a6 06230840
(invalid instruction)                                        ; cc1b00a1
	v_subrev_f32_e32 v0, v161, v65                              ; 0a0083a1
	v_lshl_add_u32 v160, v160, 5, s67                           ; d64600a0 010d0ba0
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v66                              ; 0a0085a5
	v_fma_mixhi_f16 v166, s64, v133, v137                       ; cc2200a6 06270a40
	v_fma_mixlo_f16 v167, s64, v134, v138                       ; cc2100a7 062b0c40
	v_fma_mixhi_f16 v167, s64, v135, v139                       ; cc2200a7 062f0e40
(invalid instruction)                                        ; cc1b00a4
	v_subrev_f32_e32 v0, v164, v65                              ; 0a0083a4
	v_lshl_add_u32 v161, v161, 5, s67                           ; d64600a1 010d0ba1
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[154:155], v[160:161]            ; 1a03419a
(invalid instruction)                                        ; cc1b00a5
	v_subrev_f32_e32 v0, v165, v65                              ; 0a0083a5
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[60:61], 0 ; cc464080 1a02792a
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v168, s64, v144, v140                       ; cc2100a8 06332040
(invalid instruction)                                        ; cc1c00a6
	v_subrev_f32_e32 v0, v166, v66                              ; 0a0085a6
	v_fma_mixhi_f16 v168, s64, v145, v141                       ; cc2200a8 06372240
(invalid instruction)                                        ; cc1c00a7
	v_subrev_f32_e32 v0, v167, v66                              ; 0a0085a7
	v_lshl_add_u32 v164, v164, 5, s67                           ; d64600a4 010d0ba4
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[155:156], v[161:162]            ; 1a03439b
	v_lshl_add_u32 v165, v165, 5, s67                           ; d64600a5 010d0ba5
	v_fma_mixlo_f16 v169, s64, v146, v142                       ; cc2100a9 063b2440
	v_fma_mixhi_f16 v169, s64, v147, v143                       ; cc2200a9 063f2640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v170, s64, v148, v78                        ; cc2100aa 053b2840
(invalid instruction)                                        ; cc1b00a6
	v_subrev_f32_e32 v0, v166, v65                              ; 0a0083a6
	v_fma_mixhi_f16 v170, s64, v149, v79                        ; cc2200aa 053f2a40
(invalid instruction)                                        ; cc1c00a8
	v_subrev_f32_e32 v0, v168, v66                              ; 0a0085a8
(invalid instruction)                                        ; cc1b00a7
	v_subrev_f32_e32 v0, v167, v65                              ; 0a0083a7
	v_fma_mixlo_f16 v171, s64, v150, v80                        ; cc2100ab 05432c40
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[164:165]            ; 1a03499e
	v_fma_mixhi_f16 v171, s64, v151, v81                        ; cc2200ab 05472e40
(invalid instruction)                                        ; cc0f009f
	v_min_num_f64_e32 v[1:2], v[159:160], v[165:166]            ; 1a034b9f
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v66                              ; 0a0085a9
	v_lshl_add_u32 v166, v166, 5, s67                           ; d64600a6 010d0ba6
(invalid instruction)                                        ; cc1c00aa
	v_subrev_f32_e32 v0, v170, v66                              ; 0a0085aa
(invalid instruction)                                        ; cc1b00a8
	v_subrev_f32_e32 v0, v168, v65                              ; 0a0083a8
	v_lshl_add_u32 v167, v167, 5, s67                           ; d64600a7 010d0ba7
(invalid instruction)                                        ; cc1c00ab
	v_subrev_f32_e32 v0, v171, v66                              ; 0a0085ab
(invalid instruction)                                        ; cc1b00a9
	v_subrev_f32_e32 v0, v169, v65                              ; 0a0083a9
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[162:163], v[166:167]            ; 1a034da2
(invalid instruction)                                        ; cc1b00aa
	v_subrev_f32_e32 v0, v170, v65                              ; 0a0083aa
	v_lshl_add_u32 v168, v168, 5, s67                           ; d64600a8 010d0ba8
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[167:168]            ; 1a034fa3
(invalid instruction)                                        ; cc1b00ab
	v_subrev_f32_e32 v0, v171, v65                              ; 0a0083ab
	v_lshl_add_u32 v169, v169, 5, s67                           ; d64600a9 010d0ba9
	v_lshl_add_u32 v170, v170, 5, s67                           ; d64600aa 010d0baa
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[168:169]            ; 1a03519e
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_lshl_add_u32 v171, v171, 5, s67                           ; d64600ab 010d0bab
(invalid instruction)                                        ; cc0f009f
	v_min_num_f64_e32 v[1:2], v[159:160], v[169:170]            ; 1a03539f
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[162:163], v[170:171]            ; 1a0355a2
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[171:172]            ; 1a0357a3
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[159:160]            ; 1a033f9e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[162:163]            ; 1a03459e
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[163:164]            ; 1a03479e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v172, v158, s61, s62 op_sel:[1,1]         ; d65c18ac 00f87b9e
(invalid instruction)                                        ; cc0f009e
	v_min_num_f64_e32 v[1:2], v[158:159], v[172:173]            ; 1a03599e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53210ad
	v_cndmask_b32_e32 v1, v158, v158, vcc_lo                    ; 02033d9e
(invalid instruction)                                        ; d53100ad
	v_cndmask_b32_e32 v1, s60, v173, vcc_lo                     ; 02035a3c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v173, v128, vcc_lo                    ; 020101ad
	v_rcp_f32_e32 v174, v174                                    ; 7f5c55ae
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v179, v156, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b3 8a035d9c
	v_fma_mix_f32 v176, v153, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b0 8a035d99
	v_fma_mix_f32 v153, v153, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a035d99
	v_fma_mix_f32 v178, v155, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b2 8a035d9b
	v_fma_mix_f32 v155, v155, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089b 8a035d9b
	v_fma_mix_f32 v156, v156, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089c 8a035d9c
	v_fma_mix_f32 v175, v152, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000af 8a035d98
	v_fma_mix_f32 v152, v152, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200898 8a035d98
	v_fma_mix_f32 v177, v154, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b1 8a035d9a
	v_fma_mix_f32 v154, v154, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089a 8a035d9a
	v_fma_mix_f32 v180, v157, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b4 8a035d9d
	v_fma_mix_f32 v157, v157, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a035d9d
	v_fma_mix_f32 v181, v160, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b5 8a035da0
	v_fma_mix_f32 v160, v160, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a0 8a035da0
	v_fma_mix_f32 v182, v161, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b6 8a035da1
	v_fma_mix_f32 v161, v161, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a1 8a035da1
	v_fma_mix_f32 v183, v164, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b7 8a035da4
	v_fma_mix_f32 v164, v164, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a4 8a035da4
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v179, v156, vcc_lo                    ; 020339b3
	v_fma_mix_f32 v184, v165, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b8 8a035da5
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v175, v152, vcc_lo                    ; 020331af
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v176, v153, vcc_lo                    ; 020333b0
	v_fma_mix_f32 v165, v165, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a035da5
	v_fma_mix_f32 v185, v166, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b9 8a035da6
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v177, v154, vcc_lo                    ; 020335b1
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v178, v155, vcc_lo                    ; 020337b2
	v_fma_mix_f32 v166, v166, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a6 8a035da6
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v180, v157, vcc_lo                    ; 02033bb4
	v_fma_mix_f32 v186, v167, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000ba 8a035da7
	v_fma_mix_f32 v167, v167, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a7 8a035da7
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v181, v160, vcc_lo                    ; 020341b5
	v_fma_mix_f32 v187, v168, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000bb 8a035da8
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v182, v161, vcc_lo                    ; 020343b6
	v_fma_mix_f32 v168, v168, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a8 8a035da8
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v183, v164, vcc_lo                    ; 020349b7
	v_fma_mix_f32 v188, v169, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000bc 8a035da9
	v_fma_mix_f32 v169, v169, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a035da9
	v_fma_mix_f32 v189, v170, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000bd 8a035daa
	v_fma_mix_f32 v170, v170, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008aa 8a035daa
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[116:119], v4, s[32:35], null offen offset:8192 ; c405c07c 40804074 00200004
	buffer_load_b128 v[144:147], v4, s[32:35], null offen offset:8208 ; c405c07c 40804090 00201004
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v184, v165, vcc_lo                    ; 02034bb8
	v_fma_mix_f32 v190, v171, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000be 8a035dab
	v_fma_mix_f32 v171, v171, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ab 8a035dab
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v185, v166, vcc_lo                    ; 02034db9
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[96:97], v[60:61], 0 ; cc464088 1a027960
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[34:35], v[64:65], v[104:111] ; cc464068 1da28122
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v186, v167, vcc_lo                    ; 02034fba
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[64:65], v[120:127] ; cc464078 1de28128
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[64:65], v[128:135] ; cc464080 1e028148
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v187, v168, vcc_lo                    ; 020351bb
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v188, v169, vcc_lo                    ; 020353bc
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v189, v170, vcc_lo                    ; 020355bd
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v190, v171, vcc_lo                    ; 020357be
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[6:7], v[64:65], v[136:143] ; cc464088 1e228106
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v15, s64, v106, v58                         ; cc21000f 04ead440
	v_fma_mixlo_f16 v191, s64, v104, v56                        ; cc2100bf 04e2d040
	v_fma_mixhi_f16 v191, s64, v105, v57                        ; cc2200bf 04e6d240
	v_fma_mixhi_f16 v15, s64, v107, v59                         ; cc22000f 04eed640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v56, s64, v108, v68                         ; cc210038 0512d840
	v_fma_mixlo_f16 v57, s64, v110, v70                         ; cc210039 051adc40
	v_fma_mixhi_f16 v57, s64, v111, v71                         ; cc220039 051ede40
	v_fma_mixhi_f16 v56, s64, v109, v69                         ; cc220038 0516da40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v4, s[32:35], null offen offset:8256 ; c405c07c 40804044 00204004
	buffer_load_b128 v[104:107], v4, s[32:35], null offen offset:8272 ; c405c07c 40804068 00205004
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v66                              ; 0a0085bf
(invalid instruction)                                        ; cc1c000f
	v_subrev_f32_e32 v0, v15, v66                               ; 0a00850f
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v58, s64, v120, v84                         ; cc21003a 0552f040
	v_fma_mixlo_f16 v59, s64, v122, v86                         ; cc21003b 055af440
	v_fma_mixhi_f16 v58, s64, v121, v85                         ; cc22003a 0556f240
	v_fma_mixhi_f16 v59, s64, v123, v87                         ; cc22003b 055ef640
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v66                               ; 0a008539
(invalid instruction)                                        ; cc1c0038
	v_subrev_f32_e32 v0, v56, v66                               ; 0a008538
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v60, s64, v124, v88                         ; cc21003c 0562f840
	v_fma_mixhi_f16 v60, s64, v125, v89                         ; cc22003c 0566fa40
	v_fma_mixlo_f16 v61, s64, v126, v90                         ; cc21003d 056afc40
	v_fma_mixhi_f16 v61, s64, v127, v91                         ; cc22003d 056efe40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[84:87], v4, s[32:35], null offen offset:8320 ; c405c07c 40804054 00208004
	buffer_load_b128 v[88:91], v4, s[32:35], null offen offset:8336 ; c405c07c 40804058 00209004
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v65                              ; 0a0083bf
(invalid instruction)                                        ; cc1b000f
	v_subrev_f32_e32 v0, v15, v65                               ; 0a00830f
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v66                               ; 0a00853a
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v66                               ; 0a00853b
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v65                               ; 0a008339
(invalid instruction)                                        ; cc1b0038
	v_subrev_f32_e32 v0, v56, v65                               ; 0a008338
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v66                               ; 0a00853c
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v66                               ; 0a00853d
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v65, s64, v130, v30                         ; cc210041 047b0440
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v65                               ; 0a00833a
	v_fma_mixlo_f16 v64, s64, v128, v28                         ; cc210040 04730040
	v_fma_mixhi_f16 v64, s64, v129, v29                         ; cc220040 04770240
	v_fma_mixhi_f16 v65, s64, v131, v31                         ; cc220041 047f0640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v83, s64, v134, v94                         ; cc210053 057b0c40
	v_fma_mixlo_f16 v82, s64, v132, v92                         ; cc210052 05730840
	v_fma_mixhi_f16 v82, s64, v133, v93                         ; cc220052 05770a40
	v_fma_mixhi_f16 v83, s64, v135, v95                         ; cc220053 057f0e40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[28:31], v4, s[32:35], null offen offset:8384 ; c405c07c 4080401c 0020c004
	buffer_load_b128 v[92:95], v4, s[32:35], null offen offset:8400 ; c405c07c 4080405c 0020d004
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v65                               ; 0a00833b
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v65                               ; 0a00833c
(invalid instruction)                                        ; cc1b003d
	v_subrev_f32_e32 v0, v61, v65                               ; 0a00833d
(invalid instruction)                                        ; cc1c0040
	v_subrev_f32_e32 v0, v64, v66                               ; 0a008540
(invalid instruction)                                        ; cc1c0041
	v_subrev_f32_e32 v0, v65, v66                               ; 0a008541
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v66                               ; 0a008552
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v66                               ; 0a008553
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b0040
	v_subrev_f32_e32 v0, v64, v65                               ; 0a008340
(invalid instruction)                                        ; cc1b0041
	v_subrev_f32_e32 v0, v65, v65                               ; 0a008341
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v65                               ; 0a008352
(invalid instruction)                                        ; cc1b0053
	v_subrev_f32_e32 v0, v83, v65                               ; 0a008353
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v98, s64, v136, v100                        ; cc210062 05931040
	v_fma_mixhi_f16 v98, s64, v137, v101                        ; cc220062 05971240
	v_fma_mixlo_f16 v99, s64, v138, v102                        ; cc210063 059b1440
	v_fma_mixhi_f16 v99, s64, v139, v103                        ; cc220063 059f1640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v100, s64, v140, v112                       ; cc210064 05c31840
	v_fma_mixhi_f16 v100, s64, v141, v113                       ; cc220064 05c71a40
	v_fma_mixlo_f16 v101, s64, v142, v114                       ; cc210065 05cb1c40
	v_fma_mixhi_f16 v101, s64, v143, v115                       ; cc220065 05cf1e40
	v_lshl_add_u32 v191, v191, 5, s67                           ; d64600bf 010d0bbf
	v_lshl_add_u32 v58, v58, 5, s67                             ; d646003a 010d0b3a
	v_lshl_add_u32 v64, v64, 5, s67                             ; d6460040 010d0b40
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v66                               ; 0a008562
	v_lshl_add_u32 v15, v15, 5, s67                             ; d646000f 010d0b0f
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v66                               ; 0a008563
	v_lshl_add_u32 v59, v59, 5, s67                             ; d646003b 010d0b3b
	v_lshl_add_u32 v65, v65, 5, s67                             ; d6460041 010d0b41
(invalid instruction)                                        ; cc1c0064
	v_subrev_f32_e32 v0, v100, v66                              ; 0a008564
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v66                              ; 0a008565
	v_lshl_add_u32 v56, v56, 5, s67                             ; d6460038 010d0b38
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[191:192], v[58:59]              ; 1a0275bf
	v_lshl_add_u32 v60, v60, 5, s67                             ; d646003c 010d0b3c
(invalid instruction)                                        ; cc1b0062
	v_subrev_f32_e32 v0, v98, v65                               ; 0a008362
	v_lshl_add_u32 v82, v82, 5, s67                             ; d6460052 010d0b52
(invalid instruction)                                        ; cc1b0063
	v_subrev_f32_e32 v0, v99, v65                               ; 0a008363
(invalid instruction)                                        ; cc0f0067
	v_min_num_f64_e32 v[1:2], v[15:16], v[59:60]                ; 1a02770f
	v_lshl_add_u32 v57, v57, 5, s67                             ; d6460039 010d0b39
(invalid instruction)                                        ; cc1b0064
	v_subrev_f32_e32 v0, v100, v65                              ; 0a008364
(invalid instruction)                                        ; cc1b0065
	v_subrev_f32_e32 v0, v101, v65                              ; 0a008365
	v_lshl_add_u32 v61, v61, 5, s67                             ; d646003d 010d0b3d
	v_lshl_add_u32 v83, v83, 5, s67                             ; d6460053 010d0b53
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[64:65]              ; 1a028166
(invalid instruction)                                        ; cc0f006c
	v_min_num_f64_e32 v[1:2], v[56:57], v[60:61]                ; 1a027938
	v_lshl_add_u32 v98, v98, 5, s67                             ; d6460062 010d0b62
	v_lshl_add_u32 v99, v99, 5, s67                             ; d6460063 010d0b63
(invalid instruction)                                        ; cc0f0067
	v_min_num_f64_e32 v[1:2], v[103:104], v[65:66]              ; 1a028367
	v_lshl_add_u32 v100, v100, 5, s67                           ; d6460064 010d0b64
	v_lshl_add_u32 v101, v101, 5, s67                           ; d6460065 010d0b65
(invalid instruction)                                        ; cc0f006d
	v_min_num_f64_e32 v[1:2], v[57:58], v[61:62]                ; 1a027b39
(invalid instruction)                                        ; cc0f006c
	v_min_num_f64_e32 v[1:2], v[108:109], v[82:83]              ; 1a02a56c
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[98:99]              ; 1a02c566
(invalid instruction)                                        ; cc0f0067
	v_min_num_f64_e32 v[1:2], v[103:104], v[99:100]             ; 1a02c767
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; cc0f006d
	v_min_num_f64_e32 v[1:2], v[109:110], v[83:84]              ; 1a02a76d
(invalid instruction)                                        ; cc0f006c
	v_min_num_f64_e32 v[1:2], v[108:109], v[100:101]            ; 1a02c96c
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[103:104]            ; 1a02cf66
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f006d
	v_min_num_f64_e32 v[1:2], v[109:110], v[101:102]            ; 1a02cb6d
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[108:109]            ; 1a02d966
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[109:110]            ; 1a02db66
	v_permlanex16_b32 v110, v102, s61, s62 op_sel:[1,1]         ; d65c186e 00f87b66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[110:111]            ; 1a02dd66
	v_add_f16_e32 v111, v102, v230/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64dfcd66
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v111, s60, v111                           ; 62dede3c
	v_cvt_f32_f16_e32 v112, v111                                ; 7ee0176f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v112, v112                                    ; 7ee05570
	v_fma_mix_f32 v121, v58, v112, neg(0) op_sel_hi:[1,0,0]     ; cc200079 8a02e13a
	v_fma_mix_f32 v113, v191, v112, neg(0) op_sel_hi:[1,0,0]    ; cc200071 8a02e1bf
	v_fma_mix_f32 v120, v57, v112, neg(0) op_sel_hi:[1,0,0]     ; cc200078 8a02e139
	v_fma_mix_f32 v115, v56, v112, neg(0) op_sel_hi:[1,0,0]     ; cc200073 8a02e138
	v_fma_mix_f32 v56, v56, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200838 8a02e138
	v_fma_mix_f32 v58, v58, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083a 8a02e13a
	v_fma_mix_f32 v57, v57, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200839 8a02e139
	v_fma_mix_f32 v114, v15, v112, neg(0) op_sel_hi:[1,0,0]     ; cc200072 8a02e10f
	v_fma_mix_f32 v191, v191, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a02e1bf
	v_fma_mix_f32 v15, v15, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080f 8a02e10f
	v_fma_mix_f32 v122, v59, v112, neg(0) op_sel_hi:[1,0,0]     ; cc20007a 8a02e13b
	v_fma_mix_f32 v59, v59, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083b 8a02e13b
	v_fma_mix_f32 v123, v60, v112, neg(0) op_sel_hi:[1,0,0]     ; cc20007b 8a02e13c
	v_fma_mix_f32 v60, v60, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083c 8a02e13c
	v_fma_mix_f32 v124, v61, v112, neg(0) op_sel_hi:[1,0,0]     ; cc20007c 8a02e13d
	v_fma_mix_f32 v61, v61, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083d 8a02e13d
	v_fma_mix_f32 v125, v64, v112, neg(0) op_sel_hi:[1,0,0]     ; cc20007d 8a02e140
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v1, v115, v56, vcc_lo                     ; 02027173
	v_fma_mix_f32 v64, v64, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200840 8a02e140
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v121, v58, vcc_lo                     ; 02027579
	v_fma_mix_f32 v126, v65, v112, neg(0) op_sel_hi:[1,0,0]     ; cc20007e 8a02e141
(invalid instruction)                                        ; d7694067
	v_cndmask_b32_e32 v1, v120, v57, vcc_lo                     ; 02027378
	v_fma_mix_f32 v65, v65, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200841 8a02e141
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v113, v191, vcc_lo                    ; 02037f71
(invalid instruction)                                        ; d7694066
	v_cndmask_b32_e32 v1, v114, v15, vcc_lo                     ; 02021f72
	v_fma_mix_f32 v127, v82, v112, neg(0) op_sel_hi:[1,0,0]     ; cc20007f 8a02e152
	v_fma_mix_f32 v82, v82, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200852 8a02e152
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v122, v59, vcc_lo                     ; 0202777a
	v_fma_mix_f32 v128, v83, v112, neg(0) op_sel_hi:[1,0,0]     ; cc200080 8a02e153
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v123, v60, vcc_lo                     ; 0202797b
	v_fma_mix_f32 v83, v83, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200853 8a02e153
	v_fma_mix_f32 v129, v98, v112, neg(0) op_sel_hi:[1,0,0]     ; cc200081 8a02e162
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v124, v61, vcc_lo                     ; 02027b7c
	v_fma_mix_f32 v98, v98, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200862 8a02e162
	v_fma_mix_f32 v130, v99, v112, neg(0) op_sel_hi:[1,0,0]     ; cc200082 8a02e163
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v125, v64, vcc_lo                     ; 0202817d
	v_fma_mix_f32 v99, v99, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200863 8a02e163
	v_fma_mix_f32 v131, v100, v112, neg(0) op_sel_hi:[1,0,0]    ; cc200083 8a02e164
	v_fma_mix_f32 v100, v100, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200864 8a02e164
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v126, v65, vcc_lo                     ; 0202837e
	v_fma_mix_f32 v132, v101, v112, neg(0) op_sel_hi:[1,0,0]    ; cc200084 8a02e165
	v_fma_mix_f32 v101, v101, v112, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200865 8a02e165
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[108:111], v4, s[32:35], null offen offset:12288 ; c405c07c 4080406c 00300004
	buffer_load_b128 v[112:115], v4, s[32:35], null offen offset:12304 ; c405c07c 40804070 00301004
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v127, v82, vcc_lo                     ; 0202a57f
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[62:63], 0 ; cc464078 1a027d20
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[62:63], 0 ; cc464088 1a027d2a
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v128, v83, vcc_lo                     ; 0202a780
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[62:63], 0 ; cc464098 1a027d60
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v129, v98, vcc_lo                     ; 0202c581
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v130, v99, vcc_lo                     ; 0202c782
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v131, v100, vcc_lo                    ; 0202c983
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v132, v101, vcc_lo                    ; 0202cb84
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[62:63], 0 ; cc464080 1a027d42
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[20:21], v[120:127] ; cc464078 1de22922
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[72:73], v[20:21], v[136:143] ; cc464088 1e222948
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[6:7], v[20:21], v[152:159] ; cc464098 1e622906
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[40:41], v[20:21], v[128:135] ; cc464080 1e022928
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v151, s64, v126, v146                       ; cc210097 064afc40
	v_fma_mixlo_f16 v148, s64, v120, v116                       ; cc210094 05d2f040
	v_fma_mixhi_f16 v148, s64, v121, v117                       ; cc220094 05d6f240
	v_fma_mixlo_f16 v149, s64, v122, v118                       ; cc210095 05daf440
	v_fma_mixhi_f16 v149, s64, v123, v119                       ; cc220095 05def640
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[116:119], v4, s[32:35], null offen offset:12352 ; c405c07c 40804074 00304004
	buffer_load_b128 v[120:123], v4, s[32:35], null offen offset:12368 ; c405c07c 40804078 00305004
	v_fma_mixhi_f16 v151, s64, v127, v147                       ; cc220097 064efe40
	v_fma_mixlo_f16 v150, s64, v124, v144                       ; cc210096 0642f840
	v_fma_mixhi_f16 v150, s64, v125, v145                       ; cc220096 0646fa40
(invalid instruction)                                        ; cc1c0094
	v_subrev_f32_e32 v0, v148, v66                              ; 0a008594
(invalid instruction)                                        ; cc1c0095
	v_subrev_f32_e32 v0, v149, v66                              ; 0a008595
(invalid instruction)                                        ; cc1c0097
	v_subrev_f32_e32 v0, v151, v66                              ; 0a008597
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c0096
	v_subrev_f32_e32 v0, v150, v66                              ; 0a008596
(invalid instruction)                                        ; cc1b0094
	v_subrev_f32_e32 v0, v148, v65                              ; 0a008394
(invalid instruction)                                        ; cc1b0095
	v_subrev_f32_e32 v0, v149, v65                              ; 0a008395
(invalid instruction)                                        ; cc1b0097
	v_subrev_f32_e32 v0, v151, v65                              ; 0a008397
(invalid instruction)                                        ; cc1b0096
	v_subrev_f32_e32 v0, v150, v65                              ; 0a008396
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v160, s64, v128, v68                        ; cc2100a0 05130040
	v_fma_mixhi_f16 v160, s64, v129, v69                        ; cc2200a0 05170240
	v_fma_mixlo_f16 v161, s64, v130, v70                        ; cc2100a1 051b0440
	v_fma_mixhi_f16 v161, s64, v131, v71                        ; cc2200a1 051f0640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v163, s64, v134, v106                       ; cc2100a3 05ab0c40
	v_fma_mixhi_f16 v163, s64, v135, v107                       ; cc2200a3 05af0e40
	v_fma_mixlo_f16 v162, s64, v132, v104                       ; cc2100a2 05a30840
	v_fma_mixhi_f16 v162, s64, v133, v105                       ; cc2200a2 05a70a40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v4, s[32:35], null offen offset:12416 ; c405c07c 40804044 00308004
	buffer_load_b128 v[104:107], v4, s[32:35], null offen offset:12432 ; c405c07c 40804068 00309004
(invalid instruction)                                        ; cc1c00a0
	v_subrev_f32_e32 v0, v160, v66                              ; 0a0085a0
(invalid instruction)                                        ; cc1c00a1
	v_subrev_f32_e32 v0, v161, v66                              ; 0a0085a1
(invalid instruction)                                        ; cc1c00a3
	v_subrev_f32_e32 v0, v163, v66                              ; 0a0085a3
(invalid instruction)                                        ; cc1c00a2
	v_subrev_f32_e32 v0, v162, v66                              ; 0a0085a2
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v164, s64, v136, v84                        ; cc2100a4 05531040
	v_fma_mixhi_f16 v164, s64, v137, v85                        ; cc2200a4 05571240
	v_fma_mixlo_f16 v165, s64, v138, v86                        ; cc2100a5 055b1440
	v_fma_mixhi_f16 v165, s64, v139, v87                        ; cc2200a5 055f1640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v167, s64, v142, v90                        ; cc2100a7 056b1c40
	v_fma_mixlo_f16 v166, s64, v140, v88                        ; cc2100a6 05631840
	v_fma_mixhi_f16 v166, s64, v141, v89                        ; cc2200a6 05671a40
	v_fma_mixhi_f16 v167, s64, v143, v91                        ; cc2200a7 056f1e40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[84:87], v4, s[32:35], null offen offset:12480 ; c405c07c 40804054 0030c004
	buffer_load_b128 v[88:91], v4, s[32:35], null offen offset:12496 ; c405c07c 40804058 0030d004
(invalid instruction)                                        ; cc1b00a0
	v_subrev_f32_e32 v0, v160, v65                              ; 0a0083a0
(invalid instruction)                                        ; cc1b00a1
	v_subrev_f32_e32 v0, v161, v65                              ; 0a0083a1
(invalid instruction)                                        ; cc1b00a3
	v_subrev_f32_e32 v0, v163, v65                              ; 0a0083a3
(invalid instruction)                                        ; cc1b00a2
	v_subrev_f32_e32 v0, v162, v65                              ; 0a0083a2
	v_add3_u32 v52, v53, s22, v52                               ; d6550034 04d02d35
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v66                              ; 0a0085a4
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v66                              ; 0a0085a5
(invalid instruction)                                        ; cc1c00a6
	v_subrev_f32_e32 v0, v166, v66                              ; 0a0085a6
(invalid instruction)                                        ; cc1c00a7
	v_subrev_f32_e32 v0, v167, v66                              ; 0a0085a7
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v169, s64, v154, v30                        ; cc2100a9 047b3440
	v_fma_mixhi_f16 v169, s64, v155, v31                        ; cc2200a9 047f3640
	v_fma_mixlo_f16 v168, s64, v152, v28                        ; cc2100a8 04733040
	v_fma_mixhi_f16 v168, s64, v153, v29                        ; cc2200a8 04773240
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v170, s64, v156, v92                        ; cc2100aa 05733840
	v_fma_mixhi_f16 v170, s64, v157, v93                        ; cc2200aa 05773a40
	v_lshlrev_b32_e32 v52, 2, v52                               ; 30686882
	v_fma_mixlo_f16 v171, s64, v158, v94                        ; cc2100ab 057b3c40
(invalid instruction)                                        ; cc1b00a4
	v_subrev_f32_e32 v0, v164, v65                              ; 0a0083a4
(invalid instruction)                                        ; cc1b00a5
	v_subrev_f32_e32 v0, v165, v65                              ; 0a0083a5
	v_fma_mixhi_f16 v171, s64, v159, v95                        ; cc2200ab 057f3e40
(invalid instruction)                                        ; cc1b00a6
	v_subrev_f32_e32 v0, v166, v65                              ; 0a0083a6
(invalid instruction)                                        ; cc1b00a7
	v_subrev_f32_e32 v0, v167, v65                              ; 0a0083a7
	v_lshl_add_u32 v148, v148, 5, s67                           ; d6460094 010d0b94
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v66                              ; 0a0085a9
	v_lshl_add_u32 v160, v160, 5, s67                           ; d64600a0 010d0ba0
(invalid instruction)                                        ; cc1c00a8
	v_subrev_f32_e32 v0, v168, v66                              ; 0a0085a8
(invalid instruction)                                        ; cc1c00aa
	v_subrev_f32_e32 v0, v170, v66                              ; 0a0085aa
	v_lshl_add_u32 v149, v149, 5, s67                           ; d6460095 010d0b95
	v_lshl_add_u32 v161, v161, 5, s67                           ; d64600a1 010d0ba1
	v_lshl_add_u32 v164, v164, 5, s67                           ; d64600a4 010d0ba4
	v_lshl_add_u32 v165, v165, 5, s67                           ; d64600a5 010d0ba5
(invalid instruction)                                        ; cc1c00ab
	v_subrev_f32_e32 v0, v171, v66                              ; 0a0085ab
	v_lshl_add_u32 v150, v150, 5, s67                           ; d6460096 010d0b96
(invalid instruction)                                        ; cc1b00a9
	v_subrev_f32_e32 v0, v169, v65                              ; 0a0083a9
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[148:149], v[160:161]            ; 1a034194
	v_lshl_add_u32 v162, v162, 5, s67                           ; d64600a2 010d0ba2
(invalid instruction)                                        ; cc1b00a8
	v_subrev_f32_e32 v0, v168, v65                              ; 0a0083a8
(invalid instruction)                                        ; cc1b00aa
	v_subrev_f32_e32 v0, v170, v65                              ; 0a0083aa
	v_lshl_add_u32 v166, v166, 5, s67                           ; d64600a6 010d0ba6
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[149:150], v[161:162]            ; 1a034395
	v_lshl_add_u32 v151, v151, 5, s67                           ; d6460097 010d0b97
	v_lshl_add_u32 v163, v163, 5, s67                           ; d64600a3 010d0ba3
(invalid instruction)                                        ; cc1b00ab
	v_subrev_f32_e32 v0, v171, v65                              ; 0a0083ab
	v_lshl_add_u32 v169, v169, 5, s67                           ; d64600a9 010d0ba9
	v_lshl_add_u32 v167, v167, 5, s67                           ; d64600a7 010d0ba7
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[164:165]            ; 1a0349ac
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[150:151], v[162:163]            ; 1a034596
	v_lshl_add_u32 v168, v168, 5, s67                           ; d64600a8 010d0ba8
	v_lshl_add_u32 v170, v170, 5, s67                           ; d64600aa 010d0baa
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[165:166]            ; 1a034bad
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[151:152], v[163:164]            ; 1a034797
	v_lshl_add_u32 v171, v171, 5, s67                           ; d64600ab 010d0bab
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[174:175], v[166:167]            ; 1a034dae
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[168:169]            ; 1a0351ac
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[169:170]            ; 1a0353ad
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[167:168]            ; 1a034faf
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[174:175], v[170:171]            ; 1a0355ae
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[173:174]            ; 1a035bac
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[171:172]            ; 1a0357af
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[174:175]            ; 1a035dac
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[175:176]            ; 1a035fac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v176, v172, s61, s62 op_sel:[1,1]         ; d65c18b0 00f87bac
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[176:177]            ; 1a0361ac
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53210b1
	v_cndmask_b32_e32 v1, v172, v172, vcc_lo                    ; 020359ac
(invalid instruction)                                        ; d53100b1
	v_cndmask_b32_e32 v1, s60, v177, vcc_lo                     ; 0203623c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00b2
	v_cndmask_b32_e32 v0, v177, v128, vcc_lo                    ; 020101b1
	v_rcp_f32_e32 v178, v178                                    ; 7f6455b2
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v180, v149, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b4 8a036595
	v_fma_mix_f32 v179, v148, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b3 8a036594
	v_fma_mix_f32 v148, v148, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200894 8a036594
	v_fma_mix_f32 v181, v150, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b5 8a036596
	v_fma_mix_f32 v150, v150, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200896 8a036596
	v_fma_mix_f32 v184, v161, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b8 8a0365a1
	v_fma_mix_f32 v149, v149, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a036595
	v_fma_mix_f32 v183, v160, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b7 8a0365a0
	v_fma_mix_f32 v160, v160, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a0 8a0365a0
	v_fma_mix_f32 v182, v151, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b6 8a036597
	v_fma_mix_f32 v151, v151, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a036597
	v_fma_mix_f32 v161, v161, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a1 8a0365a1
	v_fma_mix_f32 v185, v162, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000b9 8a0365a2
	v_fma_mix_f32 v162, v162, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a2 8a0365a2
	v_fma_mix_f32 v186, v163, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000ba 8a0365a3
	v_fma_mix_f32 v163, v163, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a3 8a0365a3
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v179, v148, vcc_lo                    ; 020329b3
	v_fma_mix_f32 v187, v164, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bb 8a0365a4
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v181, v150, vcc_lo                    ; 02032db5
	v_fma_mix_f32 v164, v164, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a4 8a0365a4
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v180, v149, vcc_lo                    ; 02032bb4
	v_fma_mix_f32 v188, v165, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bc 8a0365a5
	v_fma_mix_f32 v165, v165, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a0365a5
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v183, v160, vcc_lo                    ; 020341b7
	v_fma_mix_f32 v189, v166, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bd 8a0365a6
	v_fma_mix_f32 v166, v166, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a6 8a0365a6
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v182, v151, vcc_lo                    ; 02032fb6
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v184, v161, vcc_lo                    ; 020343b8
	v_fma_mix_f32 v190, v167, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000be 8a0365a7
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v185, v162, vcc_lo                    ; 020345b9
	v_fma_mix_f32 v167, v167, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a7 8a0365a7
	v_fma_mix_f32 v191, v168, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0365a8
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v186, v163, vcc_lo                    ; 020347ba
	v_fma_mix_f32 v168, v168, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a8 8a0365a8
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v187, v164, vcc_lo                    ; 020349bb
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v188, v165, vcc_lo                    ; 02034bbc
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v189, v166, vcc_lo                    ; 02034dbd
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[32:33], v[22:23], 0 ; cc464080 1a022d20
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[66:67], v[22:23], 0 ; cc464088 1a022d42
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[22:23], 0 ; cc464090 1a022d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[22:23], 0 ; cc464098 1a022d60
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v190, v167, vcc_lo                    ; 02034fbe
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v191, v168, vcc_lo                    ; 020351bf
	v_fma_mix_f32 v191, v169, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0365a9
	v_fma_mix_f32 v169, v169, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a0365a9
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[24:25], v[128:135] ; cc464080 1e023122
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[40:41], v[24:25], v[136:143] ; cc464088 1e223128
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[72:73], v[24:25], v[144:151] ; cc464090 1e423148
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v191, v169, vcc_lo                    ; 020353bf
	v_fma_mix_f32 v191, v170, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0365aa
	v_fma_mix_f32 v170, v170, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008aa 8a0365aa
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[6:7], v[24:25], v[152:159] ; cc464098 1e623106
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v4, s64, v130, v110                         ; cc210004 05bb0440
	v_fma_mixhi_f16 v4, s64, v131, v111                         ; cc220004 05bf0640
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v6, s64, v132, v112                         ; cc210006 05c30840
	v_fma_mixhi_f16 v6, s64, v133, v113                         ; cc220006 05c70a40
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v191, v170, vcc_lo                    ; 020355bf
	v_fma_mix_f32 v191, v171, v178, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a0365ab
	v_fma_mix_f32 v171, v171, v178, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ab 8a0365ab
	v_fma_mixlo_f16 v7, s64, v134, v114                         ; cc210007 05cb0c40
	v_fma_mixhi_f16 v7, s64, v135, v115                         ; cc220007 05cf0e40
(invalid instruction)                                        ; cc1c0004
	v_subrev_f32_e32 v0, v4, v66                                ; 0a008504
(invalid instruction)                                        ; cc1c0006
	v_subrev_f32_e32 v0, v6, v66                                ; 0a008506
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v191, v171, vcc_lo                    ; 020357bf
	v_fma_mixlo_f16 v191, s64, v128, v108                       ; cc2100bf 05b30040
	v_fma_mixhi_f16 v191, s64, v129, v109                       ; cc2200bf 05b70240
(invalid instruction)                                        ; cc1c0007
	v_subrev_f32_e32 v0, v7, v66                                ; 0a008507
(invalid instruction)                                        ; cc1b0004
	v_subrev_f32_e32 v0, v4, v65                                ; 0a008304
(invalid instruction)                                        ; cc1b0006
	v_subrev_f32_e32 v0, v6, v65                                ; 0a008306
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v66                              ; 0a0085bf
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v22, s64, v138, v118                        ; cc210016 05db1440
	v_fma_mixlo_f16 v15, s64, v136, v116                        ; cc21000f 05d31040
	v_fma_mixhi_f16 v15, s64, v137, v117                        ; cc22000f 05d71240
	v_fma_mixhi_f16 v22, s64, v139, v119                        ; cc220016 05df1640
(invalid instruction)                                        ; cc1b0007
	v_subrev_f32_e32 v0, v7, v65                                ; 0a008307
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v24, s64, v142, v122                        ; cc210018 05eb1c40
	v_fma_mixhi_f16 v24, s64, v143, v123                        ; cc220018 05ef1e40
	v_fma_mixlo_f16 v23, s64, v140, v120                        ; cc210017 05e31840
	v_fma_mixhi_f16 v23, s64, v141, v121                        ; cc220017 05e71a40
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v65                              ; 0a0083bf
(invalid instruction)                                        ; cc1c000f
	v_subrev_f32_e32 v0, v15, v66                               ; 0a00850f
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v66                               ; 0a008516
(invalid instruction)                                        ; cc1c0018
	v_subrev_f32_e32 v0, v24, v66                               ; 0a008518
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v66                               ; 0a008517
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b000f
	v_subrev_f32_e32 v0, v15, v65                               ; 0a00830f
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v65                               ; 0a008316
(invalid instruction)                                        ; cc1b0018
	v_subrev_f32_e32 v0, v24, v65                               ; 0a008318
(invalid instruction)                                        ; cc1b0017
	v_subrev_f32_e32 v0, v23, v65                               ; 0a008317
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v32, s64, v146, v70                         ; cc210020 051b2440
	v_fma_mixlo_f16 v25, s64, v144, v68                         ; cc210019 05132040
	v_fma_mixhi_f16 v32, s64, v147, v71                         ; cc220020 051f2640
	v_fma_mixhi_f16 v25, s64, v145, v69                         ; cc220019 05172240
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v33, s64, v148, v104                        ; cc210021 05a32840
	v_fma_mixhi_f16 v33, s64, v149, v105                        ; cc220021 05a72a40
	buffer_load_b128 v[40:43], v52, s[32:35], null offen        ; c405c07c 40804028 00000034
	v_fma_mixlo_f16 v34, s64, v150, v106                        ; cc210022 05ab2c40
	v_fma_mixhi_f16 v34, s64, v151, v107                        ; cc220022 05af2e40
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v66                               ; 0a008520
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v66                               ; 0a008519
(invalid instruction)                                        ; cc1c0021
	v_subrev_f32_e32 v0, v33, v66                               ; 0a008521
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v35, s64, v152, v84                         ; cc210023 05533040
	v_fma_mixhi_f16 v35, s64, v153, v85                         ; cc220023 05573240
	buffer_load_b128 v[68:71], v52, s[32:35], null offen offset:16 ; c405c07c 40804044 00001034
	v_fma_mixlo_f16 v64, s64, v154, v86                         ; cc210040 055b3440
	v_fma_mixhi_f16 v64, s64, v155, v87                         ; cc220040 055f3640
(invalid instruction)                                        ; cc1c0022
	v_subrev_f32_e32 v0, v34, v66                               ; 0a008522
(invalid instruction)                                        ; cc1b0020
	v_subrev_f32_e32 v0, v32, v65                               ; 0a008320
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v65, s64, v156, v88                         ; cc210041 05633840
	v_fma_mixhi_f16 v65, s64, v157, v89                         ; cc220041 05673a40
(invalid instruction)                                        ; cc1b0019
	v_subrev_f32_e32 v0, v25, v65                               ; 0a008319
	v_fma_mixlo_f16 v66, s64, v158, v90                         ; cc210042 056b3c40
(invalid instruction)                                        ; cc1b0021
	v_subrev_f32_e32 v0, v33, v65                               ; 0a008321
	v_fma_mixhi_f16 v66, s64, v159, v91                         ; cc220042 056f3e40
(invalid instruction)                                        ; cc1c0023
	v_subrev_f32_e32 v0, v35, v66                               ; 0a008523
	v_lshl_add_u32 v191, v191, 5, s67                           ; d64600bf 010d0bbf
	v_lshl_add_u32 v15, v15, 5, s67                             ; d646000f 010d0b0f
(invalid instruction)                                        ; cc1c0040
	v_subrev_f32_e32 v0, v64, v66                               ; 0a008540
(invalid instruction)                                        ; cc1b0022
	v_subrev_f32_e32 v0, v34, v65                               ; 0a008322
(invalid instruction)                                        ; cc1c0041
	v_subrev_f32_e32 v0, v65, v66                               ; 0a008541
	v_lshl_add_u32 v4, v4, 5, s67                               ; d6460004 010d0b04
	v_lshl_add_u32 v25, v25, 5, s67                             ; d6460019 010d0b19
	v_lshl_add_u32 v22, v22, 5, s67                             ; d6460016 010d0b16
	v_lshl_add_u32 v32, v32, 5, s67                             ; d6460020 010d0b20
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v66                               ; 0a008542
(invalid instruction)                                        ; cc1b0023
	v_subrev_f32_e32 v0, v35, v65                               ; 0a008323
	v_lshl_add_u32 v6, v6, 5, s67                               ; d6460006 010d0b06
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[191:192], v[15:16]              ; 1a021fbf
(invalid instruction)                                        ; cc1b0040
	v_subrev_f32_e32 v0, v64, v65                               ; 0a008340
	v_lshl_add_u32 v23, v23, 5, s67                             ; d6460017 010d0b17
(invalid instruction)                                        ; cc1b0041
	v_subrev_f32_e32 v0, v65, v65                               ; 0a008341
	v_lshl_add_u32 v33, v33, 5, s67                             ; d6460021 010d0b21
(invalid instruction)                                        ; cc0f0048
	v_min_num_f64_e32 v[1:2], v[4:5], v[22:23]                  ; 1a022d04
	v_lshl_add_u32 v7, v7, 5, s67                               ; d6460007 010d0b07
(invalid instruction)                                        ; cc1b0042
	v_subrev_f32_e32 v0, v66, v65                               ; 0a008342
	v_lshl_add_u32 v24, v24, 5, s67                             ; d6460018 010d0b18
	v_lshl_add_u32 v35, v35, 5, s67                             ; d6460023 010d0b23
	v_lshl_add_u32 v34, v34, 5, s67                             ; d6460022 010d0b22
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[25:26]                ; 1a023343
	v_lshl_add_u32 v64, v64, 5, s67                             ; d6460040 010d0b40
(invalid instruction)                                        ; cc0f0049
	v_min_num_f64_e32 v[1:2], v[6:7], v[23:24]                  ; 1a022f06
	v_lshl_add_u32 v65, v65, 5, s67                             ; d6460041 010d0b41
(invalid instruction)                                        ; cc0f0048
	v_min_num_f64_e32 v[1:2], v[72:73], v[32:33]                ; 1a024148
	v_lshl_add_u32 v66, v66, 5, s67                             ; d6460042 010d0b42
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[7:8], v[24:25]                  ; 1a023107
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[35:36]                ; 1a024743
(invalid instruction)                                        ; cc0f0049
	v_min_num_f64_e32 v[1:2], v[73:74], v[33:34]                ; 1a024349
(invalid instruction)                                        ; cc0f0048
	v_min_num_f64_e32 v[1:2], v[72:73], v[64:65]                ; 1a028148
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[82:83], v[34:35]                ; 1a024552
(invalid instruction)                                        ; cc0f0049
	v_min_num_f64_e32 v[1:2], v[73:74], v[65:66]                ; 1a028349
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[72:73]                ; 1a029143
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f0052
	v_min_num_f64_e32 v[1:2], v[82:83], v[66:67]                ; 1a028552
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[73:74]                ; 1a029343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[82:83]                ; 1a02a543
	v_permlanex16_b32 v83, v67, s61, s62 op_sel:[1,1]           ; d65c1853 00f87b43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[83:84]                ; 1a02a743
	v_add_f16_e32 v84, v67, v195/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64a98743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v84, s60, v84                             ; 62a8a83c
	v_cvt_f32_f16_e32 v85, v84                                  ; 7eaa1754
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v85, v85                                      ; 7eaa5555
	v_fma_mix_f32 v91, v22, v85, neg(0) op_sel_hi:[1,0,0]       ; cc20005b 8a02ab16
	v_fma_mix_f32 v86, v191, v85, neg(0) op_sel_hi:[1,0,0]      ; cc200056 8a02abbf
	v_fma_mix_f32 v191, v191, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a02abbf
	v_fma_mix_f32 v87, v4, v85, neg(0) op_sel_hi:[1,0,0]        ; cc200057 8a02ab04
	v_fma_mix_f32 v89, v7, v85, neg(0) op_sel_hi:[1,0,0]        ; cc200059 8a02ab07
	v_fma_mix_f32 v7, v7, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200807 8a02ab07
	v_fma_mix_f32 v90, v15, v85, neg(0) op_sel_hi:[1,0,0]       ; cc20005a 8a02ab0f
	v_fma_mix_f32 v15, v15, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080f 8a02ab0f
	v_fma_mix_f32 v88, v6, v85, neg(0) op_sel_hi:[1,0,0]        ; cc200058 8a02ab06
	v_fma_mix_f32 v6, v6, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200806 8a02ab06
	v_fma_mix_f32 v22, v22, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a02ab16
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v88, v6, vcc_lo                       ; 02020d58
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v89, v7, vcc_lo                       ; 02020f59
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v90, v15, vcc_lo                      ; 02021f5a
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v91, v22, vcc_lo                      ; 02022d5b
	v_fma_mix_f32 v4, v4, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200804 8a02ab04
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[88:91], v52, s[32:35], null offen offset:64 ; c405c07c 40804058 00004034
	buffer_load_b128 v[96:99], v52, s[32:35], null offen offset:80 ; c405c07c 40804060 00005034
	v_fma_mix_f32 v92, v23, v85, neg(0) op_sel_hi:[1,0,0]       ; cc20005c 8a02ab17
	v_fma_mix_f32 v23, v23, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a02ab17
	v_fma_mix_f32 v93, v24, v85, neg(0) op_sel_hi:[1,0,0]       ; cc20005d 8a02ab18
	v_fma_mix_f32 v24, v24, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200818 8a02ab18
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v86, v191, vcc_lo                     ; 02037f56
	v_fma_mix_f32 v94, v25, v85, neg(0) op_sel_hi:[1,0,0]       ; cc20005e 8a02ab19
	v_fma_mix_f32 v25, v25, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a02ab19
	v_fma_mix_f32 v95, v32, v85, neg(0) op_sel_hi:[1,0,0]       ; cc20005f 8a02ab20
	v_fma_mix_f32 v32, v32, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a02ab20
	s_lshr_b32 s7, s7, 2                                        ; 85078207
	v_fma_mix_f32 v100, v33, v85, neg(0) op_sel_hi:[1,0,0]      ; cc200064 8a02ab21
	v_fma_mix_f32 v33, v33, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200821 8a02ab21
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v87, v4, vcc_lo                       ; 02020957
	v_fma_mix_f32 v101, v34, v85, neg(0) op_sel_hi:[1,0,0]      ; cc200065 8a02ab22
	v_fma_mix_f32 v34, v34, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200822 8a02ab22
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v92, v23, vcc_lo                      ; 02022f5c
	v_fma_mix_f32 v104, v35, v85, neg(0) op_sel_hi:[1,0,0]      ; cc200068 8a02ab23
	v_fma_mix_f32 v35, v35, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200823 8a02ab23
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v93, v24, vcc_lo                      ; 0202315d
	v_fma_mix_f32 v105, v64, v85, neg(0) op_sel_hi:[1,0,0]      ; cc200069 8a02ab40
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v74, v74, s7, v26                                ; d655004a 04680f4a
	v_fma_mix_f32 v64, v64, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200840 8a02ab40
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v94, v25, vcc_lo                      ; 0202335e
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v95, v32, vcc_lo                      ; 0202415f
	v_fma_mix_f32 v106, v65, v85, neg(0) op_sel_hi:[1,0,0]      ; cc20006a 8a02ab41
	v_fma_mix_f32 v65, v65, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200841 8a02ab41
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v100, v33, vcc_lo                     ; 02024364
	v_fma_mix_f32 v107, v66, v85, neg(0) op_sel_hi:[1,0,0]      ; cc20006b 8a02ab42
	v_fma_mix_f32 v66, v66, v85, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200842 8a02ab42
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v101, v34, vcc_lo                     ; 02024565
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[8:9], v[102:103], 0 ; cc464070 1a02cd08
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[8:9], v[20:21], 0 ; cc464078 1a022908
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[8:9], v[72:73], 0 ; cc464080 1a029108
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v104, v35, vcc_lo                     ; 02024768
	v_lshlrev_b32_e32 v74, 2, v74                               ; 30949482
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v105, v64, vcc_lo                     ; 02028169
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v106, v65, vcc_lo                     ; 0202836a
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v107, v66, vcc_lo                     ; 0202856b
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[54:55], 0 ; cc464068 1a026d08
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[56:57], v[112:119] ; cc464070 1dc2710c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[12:13], v[28:29], v[120:127] ; cc464078 1de2390c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[12:13], v[6:7], v[128:135] ; cc464080 1e020d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[76:77], v[104:111] ; cc464068 1da2990c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[36:37], v[58:59], v[112:119] ; cc464070 1dc27524
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[30:31], v[120:127] ; cc464078 1de23d24
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[36:37], v[22:23], v[128:135] ; cc464080 1e022d24
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[78:79], v[104:111] ; cc464068 1da29d24
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[60:61], v[112:119] ; cc464070 1dc2792c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[62:63], v[120:127] ; cc464078 1de27d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[44:45], v[24:25], v[128:135] ; cc464080 1e02312c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[80:81], v[104:111] ; cc464068 1da2a12c
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[102:103], 0 ; cc464070 1a02cd0a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[20:21], 0 ; cc464078 1a02290a
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[56:57], v[112:119] ; cc464070 1dc27110
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[58:59], v[112:119] ; cc464070 1dc27526
	buffer_load_b128 v[56:59], v74, s[36:39], null offen        ; c405c07c 40804838 0000004a
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[72:73], 0 ; cc464080 1a02910a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[54:55], 0 ; cc464068 1a026d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[28:29], v[120:127] ; cc464078 1de23910
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[60:61], v[112:119] ; cc464070 1dc2792e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[16:17], v[6:7], v[128:135] ; cc464080 1e020d10
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[76:77], v[104:111] ; cc464068 1da29910
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[30:31], v[120:127] ; cc464078 1de23d26
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[38:39], v[22:23], v[128:135] ; cc464080 1e022d26
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[78:79], v[104:111] ; cc464068 1da29d26
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[62:63], v[120:127] ; cc464078 1de27d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[24:25], v[128:135] ; cc464080 1e02312e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[80:81], v[104:111] ; cc464068 1da2a12e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	ds_store_2addr_b64 v14, v[8:9], v[6:7] offset1:32           ; d9382000 0006080e
	buffer_load_b128 v[8:11], v74, s[36:39], null offen offset:512 ; c405c07c 40804808 0002004a
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	ds_store_2addr_b64 v18, v[12:13], v[6:7] offset1:32         ; d9382000 00060c12
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	ds_store_2addr_b64 v19, v[32:33], v[6:7] offset1:32         ; d9382000 00062013
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	ds_store_2addr_b64 v50, v[34:35], v[6:7] offset1:32         ; d9382000 00062232
	buffer_load_b128 v[12:15], v74, s[36:39], null offen offset:1024 ; c405c07c 4080480c 0004004a
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[6:7], v51                                     ; d9d80000 06000033
	ds_load_b64 v[16:17], v51 offset:2048                       ; d9d80800 10000033
	ds_load_b64 v[18:19], v51 offset:4096                       ; d9d81000 12000033
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[20:21], v6                           ; 7e28dd06
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v33, v21, v41 :: v_dual_mul_f32 v32, v20, v40 ; c8c65315 21205114
	v_cvt_pk_f32_fp8_e32 v[20:21], v134                         ; 7e28dd86
	v_dual_mul_f32 v35, v21, v43 :: v_dual_mul_f32 v34, v20, v42 ; c8c65715 23225514
	buffer_load_b128 v[20:23], v74, s[36:39], null offen offset:1536 ; c405c07c 40804814 0006004a
	v_cvt_pk_f32_fp8_e32 v[24:25], v7                           ; 7e30dd07
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v37, v25, v69 :: v_dual_mul_f32 v36, v24, v68 ; c8c68b19 25248918
	ds_load_b64 v[24:25], v51 offset:6144                       ; d9d81800 18000033
	buffer_load_b128 v[28:31], v74, s[36:39], null offen offset:2048 ; c405c07c 4080481c 0008004a
	ds_load_b64 v[44:45], v51 offset:256                        ; d9d80100 2c000033
	buffer_load_b128 v[60:63], v74, s[36:39], null offen offset:2560 ; c405c07c 4080483c 000a004a
	v_cvt_pk_f32_fp8_e32 v[6:7], v135                           ; 7e0cdd87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v39, v7, v71 :: v_dual_mul_f32 v38, v6, v70  ; c8c68f07 27268d06
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[6:7], v16                            ; 7e0cdd10
	v_dual_mul_f32 v81, v7, v41 :: v_dual_mul_f32 v80, v6, v40  ; c8c65307 51505106
	v_cvt_pk_f32_fp8_e32 v[6:7], v144                           ; 7e0cdd90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v83, v7, v43 :: v_dual_mul_f32 v82, v6, v42  ; c8c65707 53525506
	v_cvt_pk_f32_fp8_e32 v[6:7], v17                            ; 7e0cdd11
	v_cvt_pk_f32_fp8_e32 v[16:17], v145                         ; 7e20dd91
	v_dual_mul_f32 v85, v7, v69 :: v_dual_mul_f32 v84, v6, v68  ; c8c68b07 55548906
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v18                            ; 7e0cdd12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v105, v7, v41 :: v_dual_mul_f32 v104, v6, v40 ; c8c65307 69685106
	v_cvt_pk_f32_fp8_e32 v[6:7], v146                           ; 7e0cdd92
	v_dual_mul_f32 v107, v7, v43 :: v_dual_mul_f32 v106, v6, v42 ; c8c65707 6b6a5506
	v_cvt_pk_f32_fp8_e32 v[6:7], v19                            ; 7e0cdd13
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v87, v17, v71 :: v_dual_mul_f32 v108, v6, v68 ; c8c68f11 576c8906
	v_dual_mul_f32 v109, v7, v69 :: v_dual_mul_f32 v86, v16, v70 ; c8c68b07 6d568d10
	v_cvt_pk_f32_fp8_e32 v[6:7], v147                           ; 7e0cdd93
	buffer_load_b128 v[16:19], v74, s[36:39], null offen offset:3072 ; c405c07c 40804810 000c004a
	ds_load_b64 v[46:47], v51 offset:2304                       ; d9d80900 2e000033
	v_dual_mul_f32 v111, v7, v71 :: v_dual_mul_f32 v110, v6, v70 ; c8c68f07 6f6e8d06
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[6:7], v24                            ; 7e0cdd18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v113, v7, v41                                 ; 10e25307
	v_mul_f32_e32 v112, v6, v40                                 ; 10e05106
	v_cvt_pk_f32_fp8_e32 v[6:7], v152                           ; 7e0cdd98
	v_dual_mul_f32 v115, v7, v43 :: v_dual_mul_f32 v114, v6, v42 ; c8c65707 73725506
	buffer_load_b128 v[40:43], v74, s[36:39], null offen offset:3584 ; c405c07c 40804828 000e004a
	v_cvt_pk_f32_fp8_e32 v[6:7], v25                            ; 7e0cdd19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v117, v7, v69 :: v_dual_mul_f32 v116, v6, v68 ; c8c68b07 75748906
	v_cvt_pk_f32_fp8_e32 v[6:7], v153                           ; 7e0cdd99
	v_dual_mul_f32 v119, v7, v71 :: v_dual_mul_f32 v118, v6, v70 ; c8c68f07 77768d06
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[6:7], v44                            ; 7e0cdd2c
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v65, v7, v89 :: v_dual_mul_f32 v64, v6, v88  ; c8c6b307 4140b106
	v_cvt_pk_f32_fp8_e32 v[6:7], v172                           ; 7e0cddac
	v_dual_mul_f32 v67, v7, v91 :: v_dual_mul_f32 v66, v6, v90  ; c8c6b707 4342b506
	v_cvt_pk_f32_fp8_e32 v[6:7], v45                            ; 7e0cdd2d
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v69, v7, v97 :: v_dual_mul_f32 v68, v6, v96  ; c8c6c307 4544c106
	v_cvt_pk_f32_fp8_e32 v[6:7], v173                           ; 7e0cddad
	v_dual_mul_f32 v71, v7, v99 :: v_dual_mul_f32 v70, v6, v98  ; c8c6c707 4746c506
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[6:7], v46                            ; 7e0cdd2e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v121, v7, v89 :: v_dual_mul_f32 v120, v6, v88 ; c8c6b307 7978b106
	v_cvt_pk_f32_fp8_e32 v[6:7], v174                           ; 7e0cddae
	v_dual_mul_f32 v123, v7, v91 :: v_dual_mul_f32 v122, v6, v90 ; c8c6b707 7b7ab506
	v_cvt_pk_f32_fp8_e32 v[6:7], v47                            ; 7e0cdd2f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v125, v7, v97 :: v_dual_mul_f32 v124, v6, v96 ; c8c6c307 7d7cc106
	v_cvt_pk_f32_fp8_e32 v[6:7], v175                           ; 7e0cddaf
	ds_load_b64 v[24:25], v51 offset:4352                       ; d9d81100 18000033
	ds_load_b64 v[44:45], v51 offset:6400                       ; d9d81900 2c000033
	ds_load_b64 v[46:47], v75 offset:8192                       ; d9d82000 2e00004b
	ds_load_b64 v[50:51], v75 offset:10240                      ; d9d82800 3200004b
	ds_load_b64 v[54:55], v75 offset:12288                      ; d9d83000 3600004b
	ds_load_b64 v[72:73], v75 offset:14336                      ; d9d83800 4800004b
	v_dual_mul_f32 v127, v7, v99 :: v_dual_mul_f32 v126, v6, v98 ; c8c6c707 7f7ec506
	s_wait_dscnt 0x5                                            ; bfc60005
	v_cvt_pk_f32_fp8_e32 v[6:7], v24                            ; 7e0cdd18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v129, v7, v89 :: v_dual_mul_f32 v128, v6, v88 ; c8c6b307 8180b106
	v_cvt_pk_f32_fp8_e32 v[6:7], v152                           ; 7e0cdd98
	v_dual_mul_f32 v131, v7, v91 :: v_dual_mul_f32 v130, v6, v90 ; c8c6b707 8382b506
	v_cvt_pk_f32_fp8_e32 v[6:7], v25                            ; 7e0cdd19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v133, v7, v97 :: v_dual_mul_f32 v132, v6, v96 ; c8c6c307 8584c106
	v_cvt_pk_f32_fp8_e32 v[6:7], v153                           ; 7e0cdd99
	v_dual_mul_f32 v135, v7, v99 :: v_dual_mul_f32 v134, v6, v98 ; c8c6c707 8786c506
	s_wait_dscnt 0x4                                            ; bfc60004
	v_cvt_pk_f32_fp8_e32 v[6:7], v44                            ; 7e0cdd2c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v137, v7, v89                                 ; 1112b307
	v_mul_f32_e32 v136, v6, v88                                 ; 1110b106
	v_cvt_pk_f32_fp8_e32 v[6:7], v172                           ; 7e0cddac
	v_dual_mul_f32 v139, v7, v91 :: v_dual_mul_f32 v138, v6, v90 ; c8c6b707 8b8ab506
	v_cvt_pk_f32_fp8_e32 v[6:7], v45                            ; 7e0cdd2d
	s_wait_loadcnt_dscnt 0x703                                  ; bfc80703
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[56:57], v[46:47], v[32:39] ; cc464020 1c825d38
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[56:57], v[50:51], v[80:87] ; cc464050 1d426538
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[56:57], v[54:55], v[104:111] ; cc464068 1da26d38
	v_dual_mul_f32 v141, v7, v97 :: v_dual_mul_f32 v140, v6, v96 ; c8c6c307 8d8cc106
	v_cvt_pk_f32_fp8_e32 v[6:7], v173                           ; 7e0cddad
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v143, v7, v99 :: v_dual_mul_f32 v142, v6, v98 ; c8c6c707 8f8ec506
	ds_load_b64 v[24:25], v75 offset:8448                       ; d9d82100 1800004b
	ds_load_b64 v[76:77], v75 offset:10496                      ; d9d82900 4c00004b
	ds_load_b64 v[78:79], v75 offset:12544                      ; d9d83100 4e00004b
	ds_load_b64 v[92:93], v75 offset:14592                      ; d9d83900 5c00004b
	ds_load_b64 v[44:45], v75 offset:8704                       ; d9d82200 2c00004b
	ds_load_b64 v[88:89], v75 offset:10752                      ; d9d82a00 5800004b
	ds_load_b64 v[90:91], v75 offset:12800                      ; d9d83200 5a00004b
	ds_load_b64 v[94:95], v75 offset:14848                      ; d9d83a00 5e00004b
	ds_load_b64 v[6:7], v75 offset:8960                         ; d9d82300 0600004b
	ds_load_b64 v[96:97], v75 offset:11008                      ; d9d82b00 6000004b
	ds_load_b64 v[98:99], v75 offset:13056                      ; d9d83300 6200004b
	ds_load_b64 v[100:101], v75 offset:15104                    ; d9d83b00 6400004b
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[56:57], v[72:73], v[112:119] ; cc464070 1dc29138
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[58:59], v[46:47], v[64:71] ; cc464040 1d025d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[58:59], v[50:51], v[120:127] ; cc464078 1de2653a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[54:55], v[128:135] ; cc464080 1e026d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[58:59], v[72:73], v[136:143] ; cc464088 1e22913a
	s_wait_loadcnt_dscnt 0x60b                                  ; bfc8060b
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[8:9], v[24:25], v[32:39] ; cc464020 1c823108
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[76:77], v[80:87] ; cc464050 1d429908
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[78:79], v[104:111] ; cc464068 1da29d08
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[8:9], v[92:93], v[112:119] ; cc464070 1dc2b908
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[10:11], v[24:25], v[64:71] ; cc464040 1d02310a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[76:77], v[120:127] ; cc464078 1de2990a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[78:79], v[128:135] ; cc464080 1e029d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[92:93], v[136:143] ; cc464088 1e22b90a
	ds_load_b64 v[46:47], v75 offset:9216                       ; d9d82400 2e00004b
	ds_load_b64 v[50:51], v75 offset:11264                      ; d9d82c00 3200004b
	ds_load_b64 v[54:55], v75 offset:13312                      ; d9d83400 3600004b
	ds_load_b64 v[56:57], v75 offset:15360                      ; d9d83c00 3800004b
	ds_load_b64 v[8:9], v75 offset:9472                         ; d9d82500 0800004b
	ds_load_b64 v[10:11], v75 offset:11520                      ; d9d82d00 0a00004b
	ds_load_b64 v[24:25], v75 offset:13568                      ; d9d83500 1800004b
	ds_load_b64 v[58:59], v75 offset:15616                      ; d9d83d00 3a00004b
	s_wait_loadcnt_dscnt 0x50f                                  ; bfc8050f
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[12:13], v[44:45], v[32:39] ; cc464020 1c82590c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[88:89], v[80:87] ; cc464050 1d42b10c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[90:91], v[104:111] ; cc464068 1da2b50c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[94:95], v[112:119] ; cc464070 1dc2bd0c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[44:45], v[64:71] ; cc464040 1d02590e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[88:89], v[120:127] ; cc464078 1de2b10e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[90:91], v[128:135] ; cc464080 1e02b50e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[14:15], v[94:95], v[136:143] ; cc464088 1e22bd0e
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[20:21], v[6:7], v[32:39] ; cc464020 1c820d14
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[20:21], v[96:97], v[80:87] ; cc464050 1d42c114
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[20:21], v[98:99], v[104:111] ; cc464068 1da2c514
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[100:101], v[112:119] ; cc464070 1dc2c914
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[22:23], v[6:7], v[64:71] ; cc464040 1d020d16
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[96:97], v[120:127] ; cc464078 1de2c116
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[98:99], v[128:135] ; cc464080 1e02c516
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[100:101], v[136:143] ; cc464088 1e22c916
	ds_load_b64 v[12:13], v75 offset:9728                       ; d9d82600 0c00004b
	ds_load_b64 v[14:15], v75 offset:11776                      ; d9d82e00 0e00004b
	ds_load_b64 v[44:45], v75 offset:13824                      ; d9d83600 2c00004b
	ds_load_b64 v[72:73], v75 offset:15872                      ; d9d83e00 4800004b
	ds_load_b64 v[6:7], v75 offset:9984                         ; d9d82700 0600004b
	ds_load_b64 v[20:21], v75 offset:12032                      ; d9d82f00 1400004b
	ds_load_b64 v[22:23], v75 offset:14080                      ; d9d83700 1600004b
	ds_load_b64 v[74:75], v75 offset:16128                      ; d9d83f00 4a00004b
	s_wait_loadcnt_dscnt 0x30f                                  ; bfc8030f
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[28:29], v[46:47], v[32:39] ; cc464020 1c825d1c
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[30:31], v[46:47], v[64:71] ; cc464040 1d025d1e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[50:51], v[80:87] ; cc464050 1d42651c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[54:55], v[104:111] ; cc464068 1da26d1c
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[56:57], v[112:119] ; cc464070 1dc2711c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[50:51], v[120:127] ; cc464078 1de2651e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[54:55], v[128:135] ; cc464080 1e026d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[56:57], v[136:143] ; cc464088 1e22711e
	s_wait_loadcnt_dscnt 0x20b                                  ; bfc8020b
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[60:61], v[8:9], v[32:39] ; cc464020 1c82113c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[62:63], v[8:9], v[64:71] ; cc464040 1d02113e
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[10:11], v[80:87] ; cc464050 1d42153c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[24:25], v[104:111] ; cc464068 1da2313c
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[60:61], v[58:59], v[112:119] ; cc464070 1dc2753c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[62:63], v[10:11], v[120:127] ; cc464078 1de2153e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[24:25], v[128:135] ; cc464080 1e02313e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[62:63], v[58:59], v[136:143] ; cc464088 1e22753e
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[12:13], v[32:39] ; cc464020 1c821910
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[18:19], v[12:13], v[64:71] ; cc464040 1d021912
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[14:15], v[80:87] ; cc464050 1d421d10
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[44:45], v[104:111] ; cc464068 1da25910
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[72:73], v[112:119] ; cc464070 1dc29110
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[14:15], v[120:127] ; cc464078 1de21d12
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[44:45], v[128:135] ; cc464080 1e025912
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[72:73], v[136:143] ; cc464088 1e229112
	s_wait_loadcnt_dscnt 0x3                                    ; bfc80003
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[40:41], v[6:7], v[32:39] ; cc464020 1c820d28
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[42:43], v[6:7], v[64:71] ; cc464040 1d020d2a
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[20:21], v[80:87] ; cc464050 1d422928
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[22:23], v[104:111] ; cc464068 1da22d28
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[74:75], v[112:119] ; cc464070 1dc29528
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[20:21], v[120:127] ; cc464078 1de2292a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[22:23], v[128:135] ; cc464080 1e022d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[74:75], v[136:143] ; cc464088 1e22952a
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	v_dual_cndmask_b32 v145, v33, v37 :: v_dual_cndmask_b32 v144, v32, v36 ; ca524b21 91904920
	v_dual_cndmask_b32 v147, v35, v39 :: v_dual_cndmask_b32 v146, v34, v38 ; ca524f23 93924d22
	v_dual_cndmask_b32 v39, v39, v35 :: v_dual_cndmask_b32 v38, v38, v34 ; ca524727 27264526
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_cndmask_b32 v37, v37, v33 :: v_dual_cndmask_b32 v36, v36, v32 ; ca524325 25244124
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	v_and_b32_e32 v156, 1, v0                                   ; 37380081
	v_bfe_u32 v157, v27, 2, 1                                   ; d610009d 0205051b
	v_bfe_u32 v158, v27, 3, 1                                   ; d610009e 0205071b
	v_bfe_u32 v27, v27, 1, 1                                    ; d610001b 0205031b
	v_add_f32_dpp v38, v38, v146 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064d24fa ff0cb126
	v_add_f32_dpp v39, v39, v147 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064f26fa ff0cb127
	v_add_f32_dpp v37, v37, v145 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064b22fa ff0cb125
	v_add_f32_dpp v36, v36, v144 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064920fa ff0cb124
	v_lshl_add_u32 v156, v156, 2, v53                           ; d646009c 04d5059c
	v_lshl_add_u32 v158, v158, 2, v27                           ; d646009e 046d059e
(invalid instruction)                                        ; d58a0094
	v_cndmask_b32_e32 v0, v38, v128, vcc_lo                     ; 02010126
(invalid instruction)                                        ; d58a0095
	v_cndmask_b32_e32 v0, v39, v128, vcc_lo                     ; 02010127
(invalid instruction)                                        ; d58a0097
	v_cndmask_b32_e32 v0, v37, v128, vcc_lo                     ; 02010125
(invalid instruction)                                        ; d58a0096
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v38, v38, v36, vcc_lo                     ; 024c4926
	v_lshl_add_u32 v157, v157, 1, v156                          ; d646009d 0671039d
	v_lshl_add_u32 v158, v158, 4, v2                            ; d646009e 0409099e
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e32 v152, v150, v148, vcc_lo                  ; 03312996
	v_cndmask_b16 v152, v151, v149, vcc_lo                      ; d65d4098 01ab2b97
(invalid instruction)                                        ; d58a0099
	v_cndmask_b32_dpp v0, v38, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6426
	v_dual_cndmask_b32 v39, v39, v37 :: v_dual_add_nc_u32 v158, v157, v158 ; ca604b27 279f3d9d
(invalid instruction)                                        ; d58a4099
	v_cndmask_b32_dpp v0, v39, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6427
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; cc0f0098
	v_min_num_f64_e32 v[1:2], v[152:153], v[153:154]            ; 1a033398
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v154, 0, v152, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20109a 920330ff 3e800000
	v_fma_mix_f32 v152, 0, v152, neg(0) op_sel_hi:[0,1,0]       ; cc200098 920330ff 3e800000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769009b
	v_cndmask_b32_e32 v1, v152, v154, vcc_lo                    ; 02033598
	ds_store_b16 v158, v155                                     ; d87c0000 00009b9e
	s_cmp_lg_i32 s48, 0                                         ; bf018030
	s_cbranch_scc1 BB3                                          ; bfa20008
BB1:
	v_add3_u32 v4, v2, s3, s28                                  ; d6550004 00700702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v3, v4, v5                                   ; d6550004 04160903
	buffer_store_b64 v[6:7], v4, s[12:15], null offen           ; c406c07c 40801806 00000004
BB3:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v4, v80, v84, vcc_lo                      ; 0208a950
	v_cndmask_b32_e32 v8, v81, v85, vcc_lo                      ; 0210ab51
	v_dual_cndmask_b32 v84, v84, v80 :: v_dual_cndmask_b32 v85, v85, v81 ; ca52a154 5454a355
	v_dual_cndmask_b32 v10, v83, v87 :: v_dual_cndmask_b32 v9, v82, v86 ; ca52af53 0a08ad52
	v_dual_cndmask_b32 v86, v86, v82 :: v_dual_cndmask_b32 v87, v87, v83 ; ca52a556 5656a757
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v85, v85, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06aa10fa ff0cb155
	v_add_f32_dpp v84, v84, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06a808fa ff0cb154
	v_add_f32_dpp v87, v87, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ae14fa ff0cb157
	v_add_f32_dpp v86, v86, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ac12fa ff0cb156
	v_cvt_f16_f32_e32 v14, v85                                  ; 7e1c1555
	v_cvt_f16_f32_e32 v13, v84                                  ; 7e1a1554
	v_cvt_f16_f32_e32 v12, v87                                  ; 7e181557
	v_cvt_f16_f32_e32 v11, v86                                  ; 7e161556
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v87, v87, v85 :: v_dual_cndmask_b32 v86, v86, v84 ; ca52ab57 5756a956
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v15, v13, v11, vcc_lo                     ; 021e170d
	v_cndmask_b16 v15, v14, v12, vcc_lo                         ; d65d400f 01aa190e
	v_cvt_f16_f32_dpp v16, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d6456
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d6457
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v17, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201011 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel_hi:[0,1,0]         ; cc20000f 92021eff 3e800000
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v15, v17, vcc_lo                      ; 0202230f
	ds_store_b16 v158, v18 offset:32                            ; d87c0020 0000129e
	s_mov_b32 s2, src_scc                                       ; be8200fd
	s_cmp_lg_i32 s52, 0                                         ; bf018034
	s_cbranch_scc1 BB6                                          ; bfa20008
BB4:
	v_add3_u32 v4, v2, s3, s27                                  ; d6550004 006c0702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v3, v4, v5                                   ; d6550004 04160903
	buffer_store_b64 v[6:7], v4, s[12:15], null offen           ; c406c07c 40801806 00000004
BB6:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v4, v104, v108, vcc_lo                    ; 0208d968
	v_cndmask_b32_e32 v8, v105, v109, vcc_lo                    ; 0210db69
	v_dual_cndmask_b32 v108, v108, v104 :: v_dual_cndmask_b32 v109, v109, v105 ; ca52d16c 6c6cd36d
	v_dual_cndmask_b32 v10, v107, v111 :: v_dual_cndmask_b32 v9, v106, v110 ; ca52df6b 0a08dd6a
	v_dual_cndmask_b32 v110, v110, v106 :: v_dual_cndmask_b32 v111, v111, v107 ; ca52d56e 6e6ed76f
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v109, v109, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06da10fa ff0cb16d
	v_add_f32_dpp v108, v108, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06d808fa ff0cb16c
	v_add_f32_dpp v111, v111, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06de14fa ff0cb16f
	v_add_f32_dpp v110, v110, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06dc12fa ff0cb16e
	v_cvt_f16_f32_e32 v14, v109                                 ; 7e1c156d
	v_cvt_f16_f32_e32 v13, v108                                 ; 7e1a156c
	v_cvt_f16_f32_e32 v12, v111                                 ; 7e18156f
	v_cvt_f16_f32_e32 v11, v110                                 ; 7e16156e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v111, v111, v109 :: v_dual_cndmask_b32 v110, v110, v108 ; ca52db6f 6f6ed96e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v15, v13, v11, vcc_lo                     ; 021e170d
	v_cndmask_b16 v15, v14, v12, vcc_lo                         ; d65d400f 01aa190e
	v_cvt_f16_f32_dpp v16, v110 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d646e
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d646f
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v17, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201011 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel_hi:[0,1,0]         ; cc20000f 92021eff 3e800000
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v15, v17, vcc_lo                      ; 0202230f
	ds_store_b16 v158, v18 offset:128                           ; d87c0080 0000129e
	s_mov_b32 s4, src_scc                                       ; be8400fd
	s_cmp_lg_i32 s56, 0                                         ; bf018038
	s_cbranch_scc1 BB9                                          ; bfa20008
BB7:
	v_add3_u32 v4, v2, s3, s24                                  ; d6550004 00600702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v3, v4, v5                                   ; d6550004 04160903
	buffer_store_b64 v[6:7], v4, s[12:15], null offen           ; c406c07c 40801806 00000004
BB9:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v4, v112, v116, vcc_lo                    ; 0208e970
	v_cndmask_b32_e32 v8, v113, v117, vcc_lo                    ; 0210eb71
	v_dual_cndmask_b32 v116, v116, v112 :: v_dual_cndmask_b32 v117, v117, v113 ; ca52e174 7474e375
	v_dual_cndmask_b32 v10, v115, v119 :: v_dual_cndmask_b32 v9, v114, v118 ; ca52ef73 0a08ed72
	v_dual_cndmask_b32 v118, v118, v114 :: v_dual_cndmask_b32 v119, v119, v115 ; ca52e576 7676e777
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v117, v117, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ea10fa ff0cb175
	v_add_f32_dpp v116, v116, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06e808fa ff0cb174
	v_add_f32_dpp v119, v119, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ee14fa ff0cb177
	v_add_f32_dpp v118, v118, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ec12fa ff0cb176
	v_cvt_f16_f32_e32 v14, v117                                 ; 7e1c1575
	v_cvt_f16_f32_e32 v13, v116                                 ; 7e1a1574
	v_cvt_f16_f32_e32 v12, v119                                 ; 7e181577
	v_cvt_f16_f32_e32 v11, v118                                 ; 7e161576
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v119, v119, v117 :: v_dual_cndmask_b32 v118, v118, v116 ; ca52eb77 7776e976
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v15, v13, v11, vcc_lo                     ; 021e170d
	v_cndmask_b16 v15, v14, v12, vcc_lo                         ; d65d400f 01aa190e
	v_cvt_f16_f32_dpp v16, v118 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d6476
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d6477
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v17, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201011 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel_hi:[0,1,0]         ; cc20000f 92021eff 3e800000
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v15, v17, vcc_lo                      ; 0202230f
	ds_store_b16 v158, v18 offset:160                           ; d87c00a0 0000129e
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_cmp_lg_i32 s58, 0                                         ; bf01803a
	s_cbranch_scc1 BB12                                         ; bfa20008
BB10:
	v_add3_u32 v2, v2, s3, s42                                  ; d6550002 00a80702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[6:7], v2, s[12:15], null offen           ; c406c07c 40801806 00000002
BB12:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v2, v64, v68, vcc_lo                      ; 02048940
	v_cndmask_b32_e32 v4, v65, v69, vcc_lo                      ; 02088b41
	v_dual_cndmask_b32 v68, v68, v64 :: v_dual_cndmask_b32 v69, v69, v65 ; ca528144 44448345
	v_dual_cndmask_b32 v8, v66, v70 :: v_dual_cndmask_b32 v9, v67, v71 ; ca528d42 08088f43
	v_dual_cndmask_b32 v70, v70, v66 :: v_dual_cndmask_b32 v71, v71, v67 ; ca528546 46468747
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v69, v69, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068a08fa ff0cb145
	v_add_f32_dpp v68, v68, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068804fa ff0cb144
	v_add_f32_dpp v71, v71, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068e12fa ff0cb147
	v_add_f32_dpp v70, v70, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068c10fa ff0cb146
	v_cvt_f16_f32_e32 v13, v69                                  ; 7e1a1545
	v_cvt_f16_f32_e32 v12, v68                                  ; 7e181544
	v_cvt_f16_f32_e32 v11, v71                                  ; 7e161547
	v_cvt_f16_f32_e32 v10, v70                                  ; 7e141546
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v70, v70, v68 :: v_dual_cndmask_b32 v71, v71, v69 ; ca528946 46468b47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v14, v12, v10, vcc_lo                     ; 021c150c
	v_cndmask_b16 v14, v13, v11, vcc_lo                         ; d65d400e 01aa170d
	v_cvt_f16_f32_dpp v15, v70 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d6446
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d6447
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[15:16]                ; 1a021f0e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v16, 0, v14, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 92021cff 3e800000
	v_fma_mix_f32 v14, 0, v14, neg(0) op_sel_hi:[0,1,0]         ; cc20000e 92021cff 3e800000
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                      ; 0202210e
	ds_store_b16 v158, v17 offset:256                           ; d87c0100 0000119e
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_cmp_lg_i32 s2, 0                                          ; bf018002
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s2, vcc_lo                                        ; be82006a
	s_cbranch_scc1 BB15                                         ; bfa20008
BB13:
	v_add3_u32 v2, v48, s3, s28                                 ; d6550002 00700730
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[6:7], v2, s[12:15], null offen           ; c406c07c 40801806 00000002
BB15:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v2, v120, v124, vcc_lo                    ; 0204f978
	v_cndmask_b32_e32 v4, v121, v125, vcc_lo                    ; 0208fb79
	v_dual_cndmask_b32 v124, v124, v120 :: v_dual_cndmask_b32 v125, v125, v121 ; ca52f17c 7c7cf37d
	v_dual_cndmask_b32 v8, v122, v126 :: v_dual_cndmask_b32 v9, v123, v127 ; ca52fd7a 0808ff7b
	v_dual_cndmask_b32 v126, v126, v122 :: v_dual_cndmask_b32 v127, v127, v123 ; ca52f57e 7e7ef77f
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v125, v125, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06fa08fa ff0cb17d
	v_add_f32_dpp v124, v124, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06f804fa ff0cb17c
	v_add_f32_dpp v127, v127, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06fe12fa ff0cb17f
	v_add_f32_dpp v126, v126, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06fc10fa ff0cb17e
	v_cvt_f16_f32_e32 v13, v125                                 ; 7e1a157d
	v_cvt_f16_f32_e32 v12, v124                                 ; 7e18157c
	v_cvt_f16_f32_e32 v11, v127                                 ; 7e16157f
	v_cvt_f16_f32_e32 v10, v126                                 ; 7e14157e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v126, v126, v124 :: v_dual_cndmask_b32 v127, v127, v125 ; ca52f97e 7e7efb7f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v14, v12, v10, vcc_lo                     ; 021c150c
	v_cndmask_b16 v14, v13, v11, vcc_lo                         ; d65d400e 01aa170d
	v_cvt_f16_f32_dpp v15, v126 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d647e
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d647f
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[15:16]                ; 1a021f0e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v16, 0, v14, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 92021cff 3e800000
	v_fma_mix_f32 v14, 0, v14, neg(0) op_sel_hi:[0,1,0]         ; cc20000e 92021cff 3e800000
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                      ; 0202210e
	ds_store_b16 v158, v17 offset:288                           ; d87c0120 0000119e
	s_cmp_lg_i32 s4, 0                                          ; bf018004
	s_cbranch_scc1 BB18                                         ; bfa20008
BB16:
	v_add3_u32 v2, v48, s3, s27                                 ; d6550002 006c0730
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[6:7], v2, s[12:15], null offen           ; c406c07c 40801806 00000002
BB18:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v2, v128, v132, vcc_lo                    ; 02050980
	v_cndmask_b32_e32 v4, v129, v133, vcc_lo                    ; 02090b81
	v_dual_cndmask_b32 v132, v132, v128 :: v_dual_cndmask_b32 v133, v133, v129 ; ca530184 84850385
	v_dual_cndmask_b32 v8, v130, v134 :: v_dual_cndmask_b32 v9, v131, v135 ; ca530d82 08090f83
	v_dual_cndmask_b32 v134, v134, v130 :: v_dual_cndmask_b32 v135, v135, v131 ; ca530586 86870787
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v133, v133, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070a08fa ff0cb185
	v_add_f32_dpp v132, v132, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070804fa ff0cb184
	v_add_f32_dpp v135, v135, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070e12fa ff0cb187
	v_add_f32_dpp v134, v134, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 070c10fa ff0cb186
	v_cvt_f16_f32_e32 v13, v133                                 ; 7e1a1585
	v_cvt_f16_f32_e32 v12, v132                                 ; 7e181584
	v_cvt_f16_f32_e32 v11, v135                                 ; 7e161587
	v_cvt_f16_f32_e32 v10, v134                                 ; 7e141586
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v134, v134, v132 :: v_dual_cndmask_b32 v135, v135, v133 ; ca530986 86870b87
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v14, v12, v10, vcc_lo                     ; 021c150c
	v_cndmask_b16 v14, v13, v11, vcc_lo                         ; d65d400e 01aa170d
	v_cvt_f16_f32_dpp v15, v134 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d6486
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d6487
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[15:16]                ; 1a021f0e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v16, 0, v14, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 92021cff 3e800000
	v_fma_mix_f32 v14, 0, v14, neg(0) op_sel_hi:[0,1,0]         ; cc20000e 92021cff 3e800000
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                      ; 0202210e
	ds_store_b16 v158, v17 offset:384                           ; d87c0180 0000119e
	s_cmp_lg_i32 s5, 0                                          ; bf018005
	s_cbranch_scc1 BB21                                         ; bfa20008
BB19:
	v_add3_u32 v2, v48, s3, s24                                 ; d6550002 00600730
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v3, v2, v5                                   ; d6550002 04160503
	buffer_store_b64 v[6:7], v2, s[12:15], null offen           ; c406c07c 40801806 00000002
BB21:
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v2, v136, v140, vcc_lo                    ; 02051988
	v_cndmask_b32_e32 v4, v137, v141, vcc_lo                    ; 02091b89
	v_dual_cndmask_b32 v140, v140, v136 :: v_dual_cndmask_b32 v141, v141, v137 ; ca53118c 8c8d138d
	v_dual_cndmask_b32 v8, v138, v142 :: v_dual_cndmask_b32 v9, v139, v143 ; ca531d8a 08091f8b
	v_dual_cndmask_b32 v142, v142, v138 :: v_dual_cndmask_b32 v143, v143, v139 ; ca53158e 8e8f178f
	s_mov_b32 vcc_lo, 0xf0f0f0f0                                ; beea00ff f0f0f0f0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_add_f32_dpp v141, v141, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 071a08fa ff0cb18d
	v_add_f32_dpp v140, v140, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 071804fa ff0cb18c
	v_add_f32_dpp v143, v143, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 071e12fa ff0cb18f
	v_add_f32_dpp v142, v142, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 071c10fa ff0cb18e
	v_cvt_f16_f32_e32 v13, v141                                 ; 7e1a158d
	v_cvt_f16_f32_e32 v12, v140                                 ; 7e18158c
	v_cvt_f16_f32_e32 v11, v143                                 ; 7e16158f
	v_cvt_f16_f32_e32 v10, v142                                 ; 7e14158e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v142, v142, v140 :: v_dual_cndmask_b32 v143, v143, v141 ; ca53198e 8e8f1b8f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
	v_cndmask_b32_e32 v14, v12, v10, vcc_lo                     ; 021c150c
	v_cndmask_b16 v14, v13, v11, vcc_lo                         ; d65d400e 01aa170d
	v_cvt_f16_f32_dpp v15, v142 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d648e
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d648f
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[15:16]                ; 1a021f0e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v16, 0, v14, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201010 92021cff 3e800000
	v_fma_mix_f32 v14, 0, v14, neg(0) op_sel_hi:[0,1,0]         ; cc20000e 92021cff 3e800000
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                      ; 0202210e
	ds_store_b16 v158, v17 offset:416                           ; d87c01a0 0000119e
	s_cmp_lg_i32 s2, 0                                          ; bf018002
	s_cbranch_scc1 BB24                                         ; bfa20008
BB22:
	v_add3_u32 v48, v48, s3, s42                                ; d6550030 00a80730
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v48, v3, v48, v5                                 ; d6550030 04166103
	buffer_store_b64 v[6:7], v48, s[12:15], null offen          ; c406c07c 40801806 00000030
BB24:
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_and_b32_e32 v2, 3, v0                                     ; 36040083
	v_bfe_u32 v0, v0, 2, 2                                      ; d6100000 02090500
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_lshl_add_u32 v2, s19, 1, v2                               ; d6460002 04090213
	v_lshl_add_u32 v0, s21, 1, v0                               ; d6460000 04010215
	v_min_i32_e32 v4, v2, v0                                    ; 22080102
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_le_i32_e32 0, v4                                     ; 7d860880
	s_barrier_wait 0xffff                                       ; bf94ffff
	s_cbranch_execz BB30                                        ; bfa50006
BB25:
	s_load_b32 s2, s[10:11], 0x48                               ; f4000085 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s2, s2, 2                                        ; 84028202
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmp_gt_i32_e32 vcc_lo, s2, v2                             ; 7c880402
BB30:
	s_and_b32 s2, vcc_lo, exec_lo                               ; 8b027e6a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, s2                                       ; befe0002
	s_cbranch_execz BB36                                        ; bfa50006
BB31:
	s_load_b32 s2, s[10:11], 0x4c                               ; f4000085 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s2, s2, 2                                        ; 84028202
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmp_gt_i32_e32 vcc_lo, s2, v0                             ; 7c880002
BB36:
	s_load_b32 s3, s[10:11], 0x6c                               ; f40000c5 f800006c
	s_and_b32 s2, vcc_lo, exec_lo                               ; 8b027e6a
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_eq_i32 s3, 0                                          ; bf008003
	s_cbranch_scc0 BB38                                         ; bfa10003
BB37:
	s_load_b32 s4, s[10:11], 0x64                               ; f4000105 f8000064
	s_branch BB39                                               ; bfa00001
BB38:
	s_mov_b32 s4, s3                                            ; be840003
BB39:
	s_clause 0x2                                                ; bf850002
	s_load_b128 s[12:15], s[0:1], 0x20                          ; f4004300 f8000020
	s_load_b256 s[16:23], s[10:11], 0x5c                        ; f4006405 f800005c
	s_load_b96 s[24:26], s[10:11], 0x50                         ; f400a605 f8000050
	v_mad_u32_u24 v49, s59, 0x600, v49                          ; d60b0031 04c5fe3b 00000600
	v_max_i32_e32 v2, 0, v2                                     ; 24040480
	v_max_i32_e32 v0, 0, v0                                     ; 24000080
	s_cmp_lg_i32 s3, 0                                          ; bf018003
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s19, 2                                         ; bf018213
	s_mov_b32 s6, src_scc                                       ; be8600fd
	s_cmp_eq_i32 s16, s17                                       ; bf001110
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s7, s6, src_scc                                   ; 8b07fd06
	s_cmp_eq_i32 s4, s18                                        ; bf001204
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s7, s7, src_scc                                   ; 8b07fd07
	s_mov_b32 s7, 0                                             ; be870080
	s_mov_b32 s8, src_scc                                       ; be8800fd
	s_lshr_b32 s21, s21, 4                                      ; 85158415
	s_cmp_lg_i32 s22, 0                                         ; bf018016
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s9, -1, 0                                     ; 980980c1
	s_branch BB40                                               ; bfa00002
BB84:
	s_mov_b32 s5, s17                                           ; be850011
	s_mov_b32 s6, s16                                           ; be860010
BB40:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v4, v1, 2, s7                                ; d6460004 001d0501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshlrev_b32_e32 v6, 11, v4                                ; 300c088b
	v_add3_u32 v7, v5, s24, v6                                  ; d6550007 04183105
	v_add3_u32 v8, s24, 0x100, v6                               ; d6550008 0419fe18 00000100
	v_add3_u32 v9, s24, 0x200, v6                               ; d6550009 0419fe18 00000200
	v_add3_u32 v10, s24, 0x300, v6                              ; d655000a 0419fe18 00000300
	v_add3_u32 v11, s24, 0x400, v6                              ; d655000b 0419fe18 00000400
	v_add3_u32 v12, s24, 0x500, v6                              ; d655000c 0419fe18 00000500
	v_add3_u32 v13, s24, 0x600, v6                              ; d655000d 0419fe18 00000600
	v_add3_u32 v6, s24, 0x700, v6                               ; d6550006 0419fe18 00000700
	v_add_nc_u32_e32 v7, v7, v3                                 ; 4a0e0707
	v_add3_u32 v8, v3, v8, v5                                   ; d6550008 04161103
	v_add3_u32 v9, v3, v9, v5                                   ; d6550009 04161303
	v_add3_u32 v10, v3, v10, v5                                 ; d655000a 04161503
	v_add3_u32 v11, v3, v11, v5                                 ; d655000b 04161703
	v_add3_u32 v12, v3, v12, v5                                 ; d655000c 04161903
	v_add3_u32 v13, v3, v13, v5                                 ; d655000d 04161b03
	v_add3_u32 v6, v3, v6, v5                                   ; d6550006 04160d03
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[14:15], v7, s[12:15], null offen          ; c405407c 4080180e 00000007
	buffer_load_b64 v[16:17], v8, s[12:15], null offen          ; c405407c 40801810 00000008
	buffer_load_b64 v[8:9], v9, s[12:15], null offen            ; c405407c 40801808 00000009
	buffer_load_b64 v[18:19], v10, s[12:15], null offen         ; c405407c 40801812 0000000a
	buffer_load_b64 v[10:11], v11, s[12:15], null offen         ; c405407c 4080180a 0000000b
	buffer_load_b64 v[20:21], v12, s[12:15], null offen         ; c405407c 40801814 0000000c
	buffer_load_b64 v[12:13], v13, s[12:15], null offen         ; c405407c 4080180c 0000000d
	buffer_load_b64 v[6:7], v6, s[12:15], null offen            ; c405407c 40801806 00000006
	ds_load_b64 v[22:23], v49                                   ; d9d80000 16000031
	ds_load_b64 v[24:25], v49 offset:256                        ; d9d80100 18000031
	ds_load_b64 v[26:27], v49 offset:512                        ; d9d80200 1a000031
	ds_load_b64 v[28:29], v49 offset:768                        ; d9d80300 1c000031
	ds_load_b64 v[30:31], v49 offset:1024                       ; d9d80400 1e000031
	ds_load_b64 v[32:33], v49 offset:1280                       ; d9d80500 20000031
	ds_load_b64 v[34:35], v49 offset:1536                       ; d9d80600 22000031
	ds_load_b64 v[36:37], v49 offset:1792                       ; d9d80700 24000031
	s_wait_loadcnt_dscnt 0x707                                  ; bfc80707
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[14:15], v[22:23], 0 ; cc464028 1a022d0e
	s_cmp_lg_i32 s8, 0                                          ; bf018008
	s_wait_loadcnt_dscnt 0x606                                  ; bfc80606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[24:25], v[40:47] ; cc464028 1ca23110
	s_wait_loadcnt_dscnt 0x505                                  ; bfc80505
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[8:9], v[26:27], v[40:47] ; cc464028 1ca23508
	s_wait_loadcnt_dscnt 0x404                                  ; bfc80404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[28:29], v[40:47] ; cc464028 1ca23912
	s_wait_loadcnt_dscnt 0x303                                  ; bfc80303
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[10:11], v[30:31], v[40:47] ; cc464028 1ca23d0a
	s_wait_loadcnt_dscnt 0x202                                  ; bfc80202
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[20:21], v[32:33], v[40:47] ; cc464028 1ca24114
	s_wait_loadcnt_dscnt 0x101                                  ; bfc80101
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[34:35], v[40:47] ; cc464028 1ca2450c
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[6:7], v[36:37], v[40:47] ; cc464028 1ca24906
	v_cvt_f16_f32_e32 v21, v47                                  ; 7e2a152f
	v_cvt_f16_f32_e32 v14, v40                                  ; 7e1c1528
	v_cvt_f16_f32_e32 v15, v41                                  ; 7e1e1529
	v_cvt_f16_f32_e32 v16, v42                                  ; 7e20152a
	v_cvt_f16_f32_e32 v17, v43                                  ; 7e22152b
	v_cvt_f16_f32_e32 v18, v44                                  ; 7e24152c
	v_cvt_f16_f32_e32 v19, v45                                  ; 7e26152d
	v_cvt_f16_f32_e32 v20, v46                                  ; 7e28152e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc1 BB45                                         ; bfa20063
BB41:
	s_mov_b32 s8, src_scc                                       ; be8800fd
	s_cmp_eq_i32 s19, 2                                         ; bf008213
	s_cbranch_scc0 BB43                                         ; bfa1000c
BB42:
	s_load_b64 s[16:17], s[10:11], 0x60                         ; f4002405 f8000060
	s_wait_kmcnt 0x0                                            ; bfc70000
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v0, v4, v17, vcc_lo                       ; 02002304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v4, v4, v0                                 ; 4a080104
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v0, v4, v16, vcc_lo                       ; 02002104
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v4, v4, v2                                 ; 4a080504
	s_branch BB44                                               ; bfa0000b
BB43:
	s_load_b32 s16, s[10:11], 0x5c                              ; f4000405 f800005c
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v0, v4, v4, vcc_lo                        ; 02000904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_add_nc_u32_e32 v4, v4, v0                                 ; 4a080104
	s_wait_kmcnt 0x0                                            ; bfc70000
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v0, v4, v16, vcc_lo                       ; 02002104
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v4, v4, v2                                 ; 4a080504
BB44:
	s_load_b64 s[16:17], s[10:11], 0x60                         ; f4002405 f8000060
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s17, s16, s17                                     ; 96111110
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_f32_u32 s18, s17                                      ; be926511
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840012
	v_cndmask_b32_e32 v0, s18, v128, vcc_lo                     ; 02010012
	s_cvt_f32_u32 s29, s16                                      ; be9d6510
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d684001d
	v_cndmask_b32_e32 v0, s29, v128, vcc_lo                     ; 0201001d
	s_mul_f32 s18, s18, 0x4f7ffffe                              ; a212ff12 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s18, s18                                      ; be926712
	s_mul_f32 s29, s29, 0x4f7ffffe                              ; a21dff1d 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s20, s17, s18                                     ; 96141211
	s_cvt_u32_f32 s29, s29                                      ; be9d671d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s20, 0, s20                                    ; 81941480
	s_mul_i32 s30, s16, s29                                     ; 961e1d10
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s20, s18, s20                                  ; 96941412
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s18, s18, s20                                  ; 80121412
	s_sub_co_i32 s30, 0, s30                                    ; 819e1e80
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d0006
	v_cndmask_b32_e32 v0, v4, v18, vcc_lo                       ; 02002504
	s_mul_hi_u32 s30, s29, s30                                  ; 969e1e1d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_add_co_u32 s29, s29, s30                                  ; 801d1e1d
(invalid instruction)                                        ; d72c0007
	v_cndmask_b32_e32 v0, v6, v17, vcc_lo                       ; 02002306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v4, v4, v7                                 ; 4c080f04
(invalid instruction)                                        ; d7026a08
	v_cndmask_b32_e32 v1, s17, v4, vcc_lo                       ; 02020811
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v8, v8, v4, vcc_lo                        ; 02100908
	v_subrev_co_ci_u32_e64 v6, s27, -1, v6, vcc_lo              ; d5221b06 01aa0cc1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d7026a09
	v_cndmask_b32_e32 v1, s17, v8, vcc_lo                       ; 02021011
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v9, v9, v8, vcc_lo                        ; 02121109
	v_subrev_co_ci_u32_e64 v4, s28, -1, v6, vcc_lo              ; d5221c04 01aa0cc1
(invalid instruction)                                        ; d72d000a
	v_cndmask_b32_e32 v0, v9, v29, vcc_lo                       ; 02003b09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c000b
	v_cndmask_b32_e32 v0, v10, v16, vcc_lo                      ; 0200210a
	v_sub_nc_u32_e32 v9, v9, v11                                ; 4c121709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
(invalid instruction)                                        ; d7026a0c
	v_cndmask_b32_e32 v1, s16, v9, vcc_lo                       ; 02021210
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v12, v12, v9, vcc_lo                      ; 0218130c
	v_subrev_co_ci_u32_e32 v10, vcc_lo, -1, v10, vcc_lo         ; 441414c1
(invalid instruction)                                        ; d702100d
	v_cndmask_b32_e32 v1, s16, v12, vcc_lo                      ; 02021810
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v13, v13, v12, s16                        ; d501000d 0042190d
	v_subrev_co_ci_u32_e64 v10, vcc_lo, -1, v10, s16            ; d5226a0a 004214c1
	s_branch BB46                                               ; bfa00003
BB45:
	v_dual_mov_b32 v13, v2 :: v_dual_mov_b32 v10, v0            ; ca100102 0d0a0100
	s_mov_b32 s8, src_scc                                       ; be8800fd
BB46:
	s_cmp_lg_i32 s6, 0                                          ; bf018006
	s_cbranch_scc0 BB54                                         ; bfa10009
BB47:
	v_cmpx_gt_u32_e32 s4, v0                                    ; 7d980004
	s_cbranch_execz BB50                                        ; bfa50004
BB48:
	s_load_b32 s6, s[10:11], 0x5c                               ; f4000185 f800005c
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_cmp_le_u32_e32 vcc_lo, s6, v2                             ; 7c960406
BB50:
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_or_not1_b32 s17, vcc_lo, exec_lo                          ; 92117e6a
	s_branch BB55                                               ; bfa00002
BB54:
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_mov_b32 s17, 0                                            ; be910080
BB55:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_not_b32 exec_lo, s17                                      ; befe1e11
	s_cbranch_execz BB61                                        ; bfa50006
BB56:
	s_load_b32 s6, s[10:11], 0x58                               ; f4000185 f8000058
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 2                                        ; 84068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmp_le_u32_e32 vcc_lo, s6, v13                            ; 7c961a06
BB61:
	s_and_not1_b32 s6, exec_lo, vcc_lo                          ; 91066a7e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, s6                                       ; befe0006
	s_cbranch_execz BB67                                        ; bfa50006
BB62:
	s_load_b32 s6, s[10:11], 0x70                               ; f4000185 f8000070
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshr_b32 s6, s6, 4                                        ; 85068406
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmp_le_u32_e32 vcc_lo, s6, v4                             ; 7c960806
BB67:
	s_and_not1_b32 s6, exec_lo, vcc_lo                          ; 91066a7e
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_cmp_lg_i32 s5, 0                                          ; bf018005
	s_cbranch_scc0 BB75                                         ; bfa1000a
BB68:
	v_cmpx_gt_u32_e32 s3, v10                                   ; 7d981403
	s_cbranch_execz BB74                                        ; bfa50004
BB69:
	s_load_b32 s5, s[10:11], 0x5c                               ; f4000145 f800005c
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_cmp_le_u32_e32 vcc_lo, s5, v13                            ; 7c961a05
BB74:
	s_mov_b32 s17, src_scc                                      ; be9100fd
	s_or_not1_b32 s18, vcc_lo, exec_lo                          ; 92127e6a
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_branch BB76                                               ; bfa00002
BB75:
	s_mov_b32 s17, src_scc                                      ; be9100fd
	s_mov_b32 s18, 0                                            ; be920080
BB76:
	v_cmp_le_u32_e32 vcc_lo, s22, v13                           ; 7c961a16
(invalid instruction)                                        ; d44b0005
	v_cndmask_b32_e32 v1, s23, v10, vcc_lo                      ; 02021417
	v_lshrrev_b32_e32 v7, 2, v13                                ; 320e1a82
	v_lshrrev_b32_e32 v6, 2, v10                                ; 320c1482
	s_or_b32 s5, vcc_lo, s5                                     ; 8c05056a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v6, v26, vcc_lo                       ; 02003506
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s5, s9, s5                                        ; 8b050509
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_nor_b32 vcc_lo, s5, s18                                   ; 8f6a1205
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                       ; 02282880
	v_dual_cndmask_b32 v18, 0, v18 :: v_dual_cndmask_b32 v21, 0, v21 ; ca522480 12142a80
	v_dual_cndmask_b32 v16, 0, v16 :: v_dual_cndmask_b32 v19, 0, v19 ; ca522080 10122680
	v_dual_cndmask_b32 v14, 0, v14 :: v_dual_and_b32 v13, 3, v13 ; ca641c80 0e0c1a83
	v_dual_cndmask_b32 v15, 0, v15 :: v_dual_and_b32 v10, 3, v10 ; ca641e80 0f0a1483
	v_dual_cndmask_b32 v17, 0, v17 :: v_dual_add_nc_u32 v6, v6, v7 ; ca602280 11060f06
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v10, v10, 2, v13                             ; d646000a 0435050a
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v6, v21, vcc_lo                       ; 02002b06
	s_and_b32 exec_lo, s2, s6                                   ; 8b7e0602
	s_cbranch_execz BB82                                        ; bfa5001f
BB77:
	s_load_b128 s[28:31], s[0:1], 0x50                          ; f4004700 f8000050
	s_and_b32 s5, s25, -4                                       ; 8b05c419
	v_cvt_f32_f16_e32 v7, v15                                   ; 7e0e170f
	v_cvt_f32_f16_e32 v8, v14                                   ; 7e10170e
	v_cvt_f32_f16_e32 v9, v17                                   ; 7e121711
	v_cvt_f32_f16_e32 v11, v16                                  ; 7e161710
	v_cvt_f32_f16_e32 v12, v19                                  ; 7e181713
	v_cvt_f32_f16_e32 v13, v18                                  ; 7e1a1712
	v_cvt_f32_f16_e32 v14, v21                                  ; 7e1c1715
	v_cvt_f32_f16_e32 v15, v20                                  ; 7e1e1714
	v_add_lshl_u32 v6, v6, v4, 8                                ; d6470006 02220906
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v8, v7, vcc_lo                        ; 02020f08
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v11, v9, vcc_lo                       ; 0202130b
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v13, v12, vcc_lo                      ; 0202190d
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v15, v14, vcc_lo                      ; 02021d0f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_nc_u32_e32 v6, s5, v6                                 ; 4a0c0c05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v10, v10, 4, v6                              ; d646000a 0419090a
	v_add_nc_u32_e32 v10, v10, v53                              ; 4a146b0a
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b64 v[8:9], v10, s[28:31], null offen          ; c406c07c 40803808 0000000a
BB82:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_add_co_u32 s7, s7, 1                                      ; 80078107
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_i32 s7, 4                                          ; bf038407
	s_cbranch_scc0 BB84                                         ; bfa1fea6
BB85:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
