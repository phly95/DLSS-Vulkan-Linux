BB0:
	s_cmp_lg_i32 s10, -1                                        ; bf01c10a
	s_cbranch_scc0 BB2                                          ; bfa1000f
BB1:
	s_mov_b32 s14, s0                                           ; be8e0000
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b128 s[16:19], s[14:15], 0x30                        ; f4004407 f8000030
	s_lshl2_add_u32 s13, s10, 24                                ; 878d980a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s13, s[16:19], s13 offset:0x0             ; f4020348 1a000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s13, 0x54434852                                ; bf01ff0d 54434852
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s13, vcc_lo, exec_lo                              ; 8b0d7e6a
	s_cselect_b32 s10, -1, s10                                  ; 980a0ac1
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s10, -1                                        ; bf01c10a
	s_cbranch_scc0 BB5                                          ; bfa1000b
BB4:
	s_mov_b32 s14, s0                                           ; be8e0000
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b128 s[16:19], s[14:15], 0x30                        ; f4004407 f8000030
	s_mov_b32 s13, src_scc                                      ; be8d00fd
	s_lshl2_add_u32 s14, s10, 12                                ; 878e8c0a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s14, s[16:19], s14 offset:0x0             ; f4020388 1c000000
	s_branch BB6                                                ; bfa00002
BB5:
	s_mov_b32 s13, src_scc                                      ; be8d00fd
	s_mov_b32 s14, -1                                           ; be8e00c1
BB6:
	s_mov_b32 s15, ttmp9                                        ; be8f0075
	s_mov_b32 s16, ttmp7                                        ; be900073
	s_cmp_lg_i32 s9, 0                                          ; bf018009
	s_cbranch_scc0 BB9                                          ; bfa1004c
BB7:
	s_mul_i32 s15, s11, ttmp7                                   ; 960f730b
	s_mul_i32 s16, s9, s12                                      ; 96100c09
	s_add_co_u32 s15, ttmp9, s15                                ; 800f0f75
	s_cvt_f32_u32 s17, s16                                      ; be916510
(invalid instruction)                                        ; d6840011
	v_cndmask_b32_e32 v0, s17, v128, vcc_lo                     ; 02010011
	s_mul_f32 s17, s17, 0x4f7ffffe                              ; a211ff11 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s17, s17                                      ; be916711
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s18, s16, s17                                     ; 96121110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s18, 0, s18                                    ; 81921280
	s_mul_hi_u32 s18, s17, s18                                  ; 96921211
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s17, s17, s18                                  ; 80111211
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s17, s15, s17                                  ; 9691110f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s19, s17, s16                                     ; 96131011
	s_sub_co_i32 s19, s15, s19                                  ; 8193130f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s20, s19, s16                                  ; 80941013
	s_absdiff_i32 s22, src_scc, 1                               ; 831681fd
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_add_co_u32 s17, s17, s22                                  ; 80111611
	s_sub_co_u32 s20, s19, s16                                  ; 80941013
	s_cselect_b32 s19, s19, s20                                 ; 98131413
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_ge_u32 s19, s16                                       ; bf091013
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s17, src_scc                              ; 8011fd11
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s17, s17, s9                                      ; 96110911
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s11, s11, s17                                  ; 818b110b
	s_mul_i32 s12, s17, s12                                     ; 960c0c11
	s_min_u32 s9, s9, s11                                       ; 89890b09
	s_sub_co_i32 s15, s15, s12                                  ; 818f0c0f
	s_cvt_f32_u32 s23, s9                                       ; be976509
(invalid instruction)                                        ; d6840017
	v_cndmask_b32_e32 v0, s23, v128, vcc_lo                     ; 02010017
	s_mul_f32 s23, s23, 0x4f7ffffe                              ; a217ff17 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s23, s23                                      ; be976717
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s24, s9, s23                                      ; 96181709
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s24, 0, s24                                    ; 81981880
	s_mul_hi_u32 s24, s23, s24                                  ; 96981817
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s23, s23, s24                                  ; 80171817
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s23, s15, s23                                  ; 9697170f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s25, s23, s9                                      ; 96190917
	s_sub_co_i32 s15, s15, s25                                  ; 818f190f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s26, s15, s9                                   ; 809a090f
	s_absdiff_i32 s28, src_scc, 1                               ; 831c81fd
	s_sub_co_u32 s26, s15, s9                                   ; 809a090f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s15, s15, s26                                 ; 980f1a0f
	s_sub_co_u32 s9, s15, s9                                    ; 8089090f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mov_b32 s29, src_scc                                      ; be9d00fd
	s_absdiff_i32 s30, src_scc, 1                               ; 831e81fd
	s_cmp_lg_i32 s29, 0                                         ; bf01801d
	s_cselect_b32 s15, s15, s9                                  ; 980f090f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s15, s17, s15                                  ; 800f0f11
	s_add_co_u32 s23, s23, s28                                  ; 80171c17
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s23, s30                                  ; 80101e17
BB9:
	s_cmp_lg_i32 s13, 0                                         ; bf01800d
	s_cbranch_scc0 BB11                                         ; bfa1000e
BB10:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[20:23], s[12:13], 0x30                        ; f4004506 f8000030
	s_lshl2_add_u32 s9, s10, 8                                  ; 8789880a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_buffer_load_b32 s9, s[20:23], s9 offset:0x0               ; f402024a 12000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s9, -1                                         ; bf01c109
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB12                                               ; bfa00001
BB11:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB12:
	s_lshl_b32 s15, s15, 5                                      ; 840f850f
	s_and_b32 s9, vcc_lo, exec_lo                               ; 8b097e6a
	s_cbranch_scc0 BB53                                         ; bfa1007b
BB13:
	s_and_b32 s9, ttmp8, 0x3e000000                             ; 8b09ff74 3e000000
	s_cbranch_scc1 BB51                                         ; bfa20076
BB14:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[20:23], s[12:13], 0x30                        ; f4004506 f8000030
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s11, s10, 8                                    ; 800b880a
	s_add_co_u32 s17, s10, 16                                   ; 8011900a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_clause 0x2                                                ; bf850002
	s_buffer_load_b32 s9, s[20:23], s10 offset:0x0              ; f402024a 14000000
	s_buffer_load_b32 s11, s[20:23], s11 offset:0x0             ; f40202ca 16000000
	s_buffer_load_b32 s17, s[20:23], s17 offset:0x0             ; f402044a 22000000
	s_load_b128 s[24:27], s[12:13], 0x0                         ; f4004606 f8000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s17, s17, 2                                      ; 84118211
	buffer_load_b32 v1, off, s[24:27], s17 scope:SCOPE_DEV      ; c4050011 00883001 00000000
	s_lshr_b32 s18, s15, 4                                      ; 8512840f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s11, s11, s18                                  ; 800b120b
	s_lshl_b32 s11, s11, 2                                      ; 840b820b
	s_buffer_load_b32 s19, s[20:23], s11 offset:0x0             ; f40204ca 16000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s19, -1                                        ; bf01c113
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s28, v1                                 ; 7e380501
	s_cbranch_scc0 BB23                                         ; bfa1001b
BB15:
	s_bfm_b32 s12, 1, 16                                        ; 950c9081
BB16:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s12, 0                                         ; bf01800c
	s_cbranch_scc0 BB18                                         ; bfa10011
BB17:
	s_and_b32 s13, s19, 0xfffff                                 ; 8b0dff13 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s13, s9, s13                                   ; 800d0d09
	s_lshl_b32 s13, s13, 2                                      ; 840d820d
	buffer_load_b32 v1, off, s[24:27], s13 scope:SCOPE_DEV      ; c405000d 00883001 00000000
	s_lshr_b32 s17, s19, 20                                     ; 85119413
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s17, s17, s28                                     ; 96111c11
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s18, v1                                 ; 7e240501
	s_cmp_lt_u32 s18, s17                                       ; bf0a1112
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s29, -1, 0                                    ; 981d80c1
	s_branch BB19                                               ; bfa00001
BB18:
	s_mov_b32 s29, 0                                            ; be9d0080
BB19:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s29, exec_lo, s29                            ; 911d1d7e
	s_cbranch_scc1 BB24                                         ; bfa20003
BB21:
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	s_branch BB16                                               ; bfa0ffe6
BB23:
	s_bfm_b32 s12, 1, 16                                        ; 950c9081
BB24:
	s_add_co_u32 s11, s11, 4                                    ; 800b840b
	s_buffer_load_b32 s11, s[20:23], s11 offset:0x0             ; f40202ca 16000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s11, -1                                        ; bf01c10b
	s_cbranch_scc0 BB34                                         ; bfa1001a
BB25:
	s_branch BB26                                               ; bfa00001
BB31:
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
BB26:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s12, 0                                         ; bf01800c
	s_cbranch_scc0 BB28                                         ; bfa10011
BB27:
	s_and_b32 s13, s11, 0xfffff                                 ; 8b0dff0b 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s13, s9, s13                                   ; 800d0d09
	s_lshl_b32 s13, s13, 2                                      ; 840d820d
	buffer_load_b32 v1, off, s[24:27], s13 scope:SCOPE_DEV      ; c405000d 00883001 00000000
	s_lshr_b32 s17, s11, 20                                     ; 8511940b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s17, s17, s28                                     ; 96111c11
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s18, v1                                 ; 7e240501
	s_cmp_lt_u32 s18, s17                                       ; bf0a1112
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s19, -1, 0                                    ; 981380c1
	s_branch BB29                                               ; bfa00001
BB28:
	s_mov_b32 s19, 0                                            ; be930080
BB29:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s19, exec_lo, s19                            ; 9113137e
	s_cbranch_scc0 BB31                                         ; bfa1ffe7
BB34:
	s_cmp_eq_i32 s12, 0                                         ; bf00800c
	s_cbranch_scc0 BB36                                         ; bfa10002
BB35:
	s_mov_b32 s9, 1                                             ; be890081
	s_branch BB37                                               ; bfa00001
BB36:
	s_mov_b32 s9, 0                                             ; be890080
BB37:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mov_b32 exec_lo, s9                                       ; befe0009
	s_cbranch_execz BB49                                        ; bfa5000e
BB38:
	s_ctz_i32_b32 s9, exec_lo                                   ; be89087e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s9, 1, s9                                        ; 84090981
	s_and_saveexec_b32 s9, s9                                   ; be892009
	s_cbranch_execz BB49                                        ; bfa50009
BB39:
	s_add_co_u32 s10, s10, 20                                   ; 800a940a
	s_buffer_load_b32 s10, s[20:23], s10 offset:0x0             ; f402028a 14000000
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	buffer_atomic_max_u32 v1, off, s[24:27], s10                ; c40ec00a 00803001 00000000
BB49:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
BB51:
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
BB53:
	v_and_b32_e32 v3, 31, v0                                    ; 3606009f
	v_and_b32_e32 v4, 15, v0                                    ; 3608008f
	s_lshr_b32 s9, s8, 4                                        ; 85098408
	s_lshr_b32 s10, s15, 4                                      ; 850a840f
	v_bfe_u32 v1, v0, 5, 2                                      ; d6100001 02090b00
	s_mul_i32 s11, s10, s9                                      ; 960b090a
	v_lshlrev_b32_e32 v5, 4, v4                                 ; 300a0884
	s_lshl_b32 s11, s11, 8                                      ; 840b880b
	s_add_co_u32 s12, 16, s15                                   ; 800c0f90
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v6, v5, s1, s11                                  ; d6550006 002c0305
	s_lshr_b32 s13, s12, 4                                      ; 850d840c
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0                ; ca100080 09080080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0              ; ca100080 0b0a0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v12, 0              ; ca100080 0d0c0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, 0              ; ca100080 0f0e0080
	s_mul_i32 s17, s13, s9                                      ; 9611090d
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v16, 0              ; ca100080 11100080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s17, s17, 8                                      ; 84118811
	s_lshl_b32 s16, s16, 7                                      ; 84108710
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_lshr_b32 s8, s8, 8                                        ; 85088808
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v5, v5, s1, s17                                  ; d6550005 00440305
	s_mov_b32 s1, 0                                             ; be810080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_lshl_add_u32 v1, v1, 5, s16                               ; d6460001 00410b01
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_lshrrev_b32_e32 v2, 5, v1                                 ; 32040285
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                        ; 02001302
	v_lshl_add_u32 v2, v2, 7, s4                                ; d6460002 00110f02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshl_add_u32 v2, v3, 2, v2                                ; d6460002 04090503
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_lshlrev_b32_e32 v3, 3, v3                                 ; 30060683
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_add_nc_u32_e32 v6, v6, v3                                 ; 4a0c0706
	v_add_nc_u32_e32 v5, v5, v3                                 ; 4a0a0705
	v_lshrrev_b32_e32 v6, 2, v6                                 ; 320c0c82
	v_lshrrev_b32_e32 v5, 2, v5                                 ; 320a0a82
	s_branch BB54                                               ; bfa00148
	s_nop 0                                                     ; bf800000
BB56:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[16:17], 0x70                        ; f4004508 f8000070
	s_load_b128 s[16:19], s[16:17], 0x30                        ; f4004408 f8000030
	s_lshl_b32 s4, s1, 8                                        ; 84048801
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s4, s4, 4                                        ; 85048404
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v40, s4, 7, v2                               ; d6460028 04090e04
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v40, 2, v40                               ; 30505082
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[44:47], v40, s[16:19], null offen        ; c405c07c 4080202c 00000028
	buffer_load_b128 v[48:51], v40, s[16:19], null offen offset:512 ; c405c07c 40802030 00020028
	buffer_load_b128 v[52:55], v40, s[16:19], null offen offset:1024 ; c405c07c 40802034 00040028
	buffer_load_b128 v[56:59], v40, s[16:19], null offen offset:1536 ; c405c07c 40802038 00060028
	buffer_load_b128 v[60:63], v40, s[16:19], null offen offset:2048 ; c405c07c 4080203c 00080028
	buffer_load_b128 v[64:67], v40, s[16:19], null offen offset:2560 ; c405c07c 40802040 000a0028
	s_lshl_b32 s9, s4, 8                                        ; 84098804
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s9, s9, 2                                        ; 85098209
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v3, s9, v6, 2                                ; d6470003 020a0c09
	v_add_lshl_u32 v7, s9, v5, 2                                ; d6470007 020a0a09
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0xd                                                ; bf85000d
	buffer_load_b64 v[42:43], v3, s[20:23], null offen          ; c405407c 4080282a 00000003
	buffer_load_b64 v[68:69], v7, s[20:23], null offen          ; c405407c 40802844 00000007
	buffer_load_b64 v[70:71], v3, s[20:23], null offen offset:256 ; c405407c 40802846 00010003
	buffer_load_b64 v[72:73], v7, s[20:23], null offen offset:256 ; c405407c 40802848 00010007
	buffer_load_b64 v[74:75], v3, s[20:23], null offen offset:512 ; c405407c 4080284a 00020003
	buffer_load_b64 v[76:77], v7, s[20:23], null offen offset:512 ; c405407c 4080284c 00020007
	buffer_load_b64 v[78:79], v3, s[20:23], null offen offset:768 ; c405407c 4080284e 00030003
	buffer_load_b64 v[80:81], v7, s[20:23], null offen offset:768 ; c405407c 40802850 00030007
	buffer_load_b64 v[82:83], v3, s[20:23], null offen offset:1024 ; c405407c 40802852 00040003
	buffer_load_b64 v[84:85], v7, s[20:23], null offen offset:1024 ; c405407c 40802854 00040007
	buffer_load_b64 v[86:87], v3, s[20:23], null offen offset:1280 ; c405407c 40802856 00050003
	buffer_load_b64 v[88:89], v7, s[20:23], null offen offset:1280 ; c405407c 40802858 00050007
	buffer_load_b64 v[90:91], v3, s[20:23], null offen offset:1536 ; c405407c 4080285a 00060003
	buffer_load_b64 v[92:93], v7, s[20:23], null offen offset:1536 ; c405407c 4080285c 00060007
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[42:43], v[44:45], v[8:15] ; cc464008 1c22592a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[42:43], v[46:47], v[16:23] ; cc464010 1c425d2a
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[68:69], v[44:45], v[24:31] ; cc464018 1c625944
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[68:69], v[46:47], v[32:39] ; cc464020 1c825d44
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[70:71], v[48:49], v[8:15] ; cc464008 1c226146
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[70:71], v[50:51], v[16:23] ; cc464010 1c426546
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[72:73], v[48:49], v[24:31] ; cc464018 1c626148
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[72:73], v[50:51], v[32:39] ; cc464020 1c826548
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[74:75], v[52:53], v[8:15] ; cc464008 1c22694a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[74:75], v[54:55], v[16:23] ; cc464010 1c426d4a
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[76:77], v[52:53], v[24:31] ; cc464018 1c62694c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[76:77], v[54:55], v[32:39] ; cc464020 1c826d4c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[78:79], v[56:57], v[8:15] ; cc464008 1c22714e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[78:79], v[58:59], v[16:23] ; cc464010 1c42754e
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[80:81], v[56:57], v[24:31] ; cc464018 1c627150
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[80:81], v[58:59], v[32:39] ; cc464020 1c827550
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[82:83], v[60:61], v[8:15] ; cc464008 1c227952
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[82:83], v[62:63], v[16:23] ; cc464010 1c427d52
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[84:85], v[60:61], v[24:31] ; cc464018 1c627954
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[84:85], v[62:63], v[32:39] ; cc464020 1c827d54
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[86:87], v[64:65], v[8:15] ; cc464008 1c228156
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[86:87], v[66:67], v[16:23] ; cc464010 1c428556
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[88:89], v[64:65], v[24:31] ; cc464018 1c628158
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[88:89], v[66:67], v[32:39] ; cc464020 1c828558
	s_clause 0x6                                                ; bf850006
	buffer_load_b128 v[42:45], v40, s[16:19], null offen offset:3072 ; c405c07c 4080202a 000c0028
	buffer_load_b128 v[68:71], v40, s[16:19], null offen offset:3584 ; c405c07c 40802044 000e0028
	buffer_load_b128 v[48:51], v40, s[16:19], null offen offset:4096 ; c405c07c 40802030 00100028
	buffer_load_b128 v[52:55], v40, s[16:19], null offen offset:4608 ; c405c07c 40802034 00120028
	buffer_load_b128 v[56:59], v40, s[16:19], null offen offset:5120 ; c405c07c 40802038 00140028
	buffer_load_b128 v[60:63], v40, s[16:19], null offen offset:5632 ; c405c07c 4080203c 00160028
	buffer_load_b128 v[64:67], v40, s[16:19], null offen offset:6144 ; c405c07c 40802040 00180028
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[90:91], v[44:45], v[16:23] ; cc464010 1c42595a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[92:93], v[42:43], v[24:31] ; cc464018 1c62555c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[92:93], v[44:45], v[32:39] ; cc464020 1c82595c
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[90:91], v[42:43], v[8:15] ; cc464008 1c22555a
	s_clause 0xd                                                ; bf85000d
	buffer_load_b64 v[42:43], v3, s[20:23], null offen offset:1792 ; c405407c 4080282a 00070003
	buffer_load_b64 v[44:45], v7, s[20:23], null offen offset:1792 ; c405407c 4080282c 00070007
	buffer_load_b64 v[46:47], v3, s[20:23], null offen offset:2048 ; c405407c 4080282e 00080003
	buffer_load_b64 v[72:73], v7, s[20:23], null offen offset:2048 ; c405407c 40802848 00080007
	buffer_load_b64 v[74:75], v3, s[20:23], null offen offset:2304 ; c405407c 4080284a 00090003
	buffer_load_b64 v[76:77], v7, s[20:23], null offen offset:2304 ; c405407c 4080284c 00090007
	buffer_load_b64 v[78:79], v3, s[20:23], null offen offset:2560 ; c405407c 4080284e 000a0003
	buffer_load_b64 v[80:81], v7, s[20:23], null offen offset:2560 ; c405407c 40802850 000a0007
	buffer_load_b64 v[82:83], v3, s[20:23], null offen offset:2816 ; c405407c 40802852 000b0003
	buffer_load_b64 v[84:85], v7, s[20:23], null offen offset:2816 ; c405407c 40802854 000b0007
	buffer_load_b64 v[86:87], v3, s[20:23], null offen offset:3072 ; c405407c 40802856 000c0003
	buffer_load_b64 v[88:89], v7, s[20:23], null offen offset:3072 ; c405407c 40802858 000c0007
	buffer_load_b64 v[90:91], v3, s[20:23], null offen offset:3328 ; c405407c 4080285a 000d0003
	buffer_load_b64 v[92:93], v7, s[20:23], null offen offset:3328 ; c405407c 4080285c 000d0007
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[42:43], v[68:69], v[8:15] ; cc464008 1c22892a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[42:43], v[70:71], v[16:23] ; cc464010 1c428d2a
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[44:45], v[70:71], v[32:39] ; cc464020 1c828d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[44:45], v[68:69], v[24:31] ; cc464018 1c62892c
	v_mov_b32_e32 v68, v40                                      ; 7e880328
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[46:47], v[48:49], v[8:15] ; cc464008 1c22612e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[50:51], v[16:23] ; cc464010 1c42652e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v40, s[16:19], null offen offset:6656 ; c405c07c 40802028 001a0028
	buffer_load_b128 v[44:47], v68, s[16:19], null offen offset:7168 ; c405c07c 4080202c 001c0044
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[72:73], v[50:51], v[32:39] ; cc464020 1c826548
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[72:73], v[48:49], v[24:31] ; cc464018 1c626148
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[48:49], v3, s[20:23], null offen offset:3584 ; c405407c 40802830 000e0003
	buffer_load_b64 v[50:51], v7, s[20:23], null offen offset:3584 ; c405407c 40802832 000e0007
	buffer_load_b64 v[70:71], v3, s[20:23], null offen offset:3840 ; c405407c 40802846 000f0003
	buffer_load_b64 v[72:73], v7, s[20:23], null offen offset:3840 ; c405407c 40802848 000f0007
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_dual_mov_b32 v95, v71 :: v_dual_mov_b32 v94, v70          ; ca100147 5f5e0146
	buffer_load_b128 v[68:71], v68, s[16:19], null offen offset:7680 ; c405c07c 40802044 001e0044
	s_add_co_u32 s1, s1, 1                                      ; 80018101
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[74:75], v[52:53], v[8:15] ; cc464008 1c22694a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[74:75], v[54:55], v[16:23] ; cc464010 1c426d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[76:77], v[54:55], v[32:39] ; cc464020 1c826d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[76:77], v[52:53], v[24:31] ; cc464018 1c62694c
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[78:79], v[56:57], v[8:15] ; cc464008 1c22714e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[78:79], v[58:59], v[16:23] ; cc464010 1c42754e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[80:81], v[58:59], v[32:39] ; cc464020 1c827550
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[80:81], v[56:57], v[24:31] ; cc464018 1c627150
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[82:83], v[60:61], v[8:15] ; cc464008 1c227952
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[82:83], v[62:63], v[16:23] ; cc464010 1c427d52
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[84:85], v[62:63], v[32:39] ; cc464020 1c827d54
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[84:85], v[60:61], v[24:31] ; cc464018 1c627954
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[86:87], v[64:65], v[8:15] ; cc464008 1c228156
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[86:87], v[66:67], v[16:23] ; cc464010 1c428556
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[88:89], v[66:67], v[32:39] ; cc464020 1c828558
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[88:89], v[64:65], v[24:31] ; cc464018 1c628158
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[90:91], v[40:41], v[8:15] ; cc464008 1c22515a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[90:91], v[42:43], v[16:23] ; cc464010 1c42555a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[92:93], v[42:43], v[32:39] ; cc464020 1c82555c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[92:93], v[40:41], v[24:31] ; cc464018 1c62515c
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[48:49], v[44:45], v[8:15] ; cc464008 1c225930
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[48:49], v[46:47], v[16:23] ; cc464010 1c425d30
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[50:51], v[46:47], v[32:39] ; cc464020 1c825d32
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[50:51], v[44:45], v[24:31] ; cc464018 1c625932
	s_wait_loadcnt 0x0                                          ; bfc00000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[72:73], v[68:69], v[24:31] ; cc464018 1c628948
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[72:73], v[70:71], v[32:39] ; cc464020 1c828d48
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[94:95], v[68:69], v[8:15] ; cc464008 1c22895e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[94:95], v[70:71], v[16:23] ; cc464010 1c428d5e
BB54:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s1, s8                                         ; bf090801
	s_cbranch_scc0 BB56                                         ; bfa1feb6
BB57:
	s_cmp_lt_u32 s15, s6                                        ; bf0a060f
	s_cbranch_scc0 BB59                                         ; bfa100a6
BB58:
	s_mov_b32 s8, s0                                            ; be880000
	s_movk_i32 s9, 0x8000                                       ; b0098000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[8:9], 0x40                          ; f4004404 f8000040
	s_load_b128 s[20:23], s[8:9], 0x10                          ; f4004504 f8000010
	v_add3_u32 v2, v4, s5, v1                                   ; d6550002 04040b04
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v2, 1, v2                                 ; 30040481
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v3, v2, s[16:19], null offen            ; c408007c 40802003 00000002
	v_and_b32_e32 v6, 16, v0                                    ; 360c0090
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_lshr_b32 s4, s7, 4                                        ; 85048407
	v_lshrrev_b32_e32 v5, 4, v1                                 ; 320a0284
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s4, s10, s4                                       ; 9604040a
	v_lshl_or_b32 v6, v6, 3, v4                                 ; d6560006 04110706
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_add_lshl_u32 v5, s4, v5, 8                                ; d6470005 02220a04
	v_add3_u32 v7, v6, s2, v5                                   ; d6550007 04140506
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v40, v7, s[20:23], null offen            ; c407807c 40802828 00000007
	buffer_load_d16_u8 v41, v7, s[20:23], null offen offset:16  ; c407807c 40802829 00001007
	buffer_load_d16_u8 v42, v7, s[20:23], null offen offset:32  ; c407807c 4080282a 00002007
	buffer_load_d16_u8 v43, v7, s[20:23], null offen offset:48  ; c407807c 4080282b 00003007
	buffer_load_d16_u8 v44, v7, s[20:23], null offen offset:64  ; c407807c 4080282c 00004007
	buffer_load_d16_u8 v45, v7, s[20:23], null offen offset:80  ; c407807c 4080282d 00005007
	buffer_load_d16_u8 v46, v7, s[20:23], null offen offset:96  ; c407807c 4080282e 00006007
	buffer_load_d16_u8 v47, v7, s[20:23], null offen offset:112 ; c407807c 4080282f 00007007
	v_add3_u32 v6, v6, s3, v5                                   ; d6550006 04140706
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v48, v40                                  ; 7e60d928
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v52, v41                                  ; 7e68d929
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v56, v42                                  ; 7e70d92a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v60, v43                                  ; 7e78d92b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v49, v3, v48, v8 op_sel_hi:[1,0,0]          ; cc210031 0c226103
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v64, v44                                  ; 7e80d92c
	v_fma_mixlo_f16 v53, v3, v52, v9 op_sel_hi:[1,0,0]          ; cc210035 0c266903
	v_fma_mixlo_f16 v57, v3, v56, v10 op_sel_hi:[1,0,0]         ; cc210039 0c2a7103
	v_fma_mixlo_f16 v61, v3, v60, v11 op_sel_hi:[1,0,0]         ; cc21003d 0c2e7903
	v_maxmin_num_f16 v49, 0xdf00, v49, neg(0xdf00)              ; d66b0031 83fe62ff 0000df00
	v_fma_mixlo_f16 v65, v3, v64, v12 op_sel_hi:[1,0,0]         ; cc210041 0c328103
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v68, v45                                  ; 7e88d92d
	v_maxmin_num_f16 v53, 0xdf00, v53, neg(0xdf00)              ; d66b0035 83fe6aff 0000df00
	v_maxmin_num_f16 v57, 0xdf00, v57, neg(0xdf00)              ; d66b0039 83fe72ff 0000df00
	v_maxmin_num_f16 v61, 0xdf00, v61, neg(0xdf00)              ; d66b003d 83fe7aff 0000df00
	v_cvt_f32_f16_e32 v50, v49                                  ; 7e641731
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v72, v46                                  ; 7e90d92e
	v_maxmin_num_f16 v65, 0xdf00, v65, neg(0xdf00)              ; d66b0041 83fe82ff 0000df00
	v_fma_mixlo_f16 v69, v3, v68, v13 op_sel_hi:[1,0,0]         ; cc210045 0c368903
	v_cvt_f32_f16_e32 v54, v53                                  ; 7e6c1735
	v_cvt_f32_f16_e32 v58, v57                                  ; 7e741739
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v76, v47                                  ; 7e98d92f
	v_cvt_f32_f16_e32 v62, v61                                  ; 7e7c173d
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v0, v50, v128, vcc_lo                     ; 02010132
	v_fma_mixlo_f16 v73, v3, v72, v14 op_sel_hi:[1,0,0]         ; cc210049 0c3a9103
	v_cvt_f32_f16_e32 v66, v65                                  ; 7e841741
	v_maxmin_num_f16 v69, 0xdf00, v69, neg(0xdf00)              ; d66b0045 83fe8aff 0000df00
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v0, v54, v128, vcc_lo                     ; 02010136
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v0, v58, v128, vcc_lo                     ; 0201013a
	v_fma_mixlo_f16 v3, v3, v76, v15 op_sel_hi:[1,0,0]          ; cc210003 0c3e9903
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v0, v62, v128, vcc_lo                     ; 0201013e
	v_maxmin_num_f16 v73, 0xdf00, v73, neg(0xdf00)              ; d66b0049 83fe92ff 0000df00
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v0, v66, v128, vcc_lo                     ; 02010142
	v_cvt_f32_f16_e32 v70, v69                                  ; 7e8c1745
	v_maxmin_num_f16 v3, 0xdf00, v3, neg(0xdf00)                ; d66b0003 83fe06ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_cvt_f32_f16_e32 v74, v73                                  ; 7e941749
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v0, v70, v128, vcc_lo                     ; 02010146
	v_cvt_f32_f16_e32 v77, v3                                   ; 7e9a1703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v0, v74, v128, vcc_lo                     ; 0201014a
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v0, v77, v128, vcc_lo                     ; 0201014d
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v51, v6, s[20:23], null offen               ; c406007c 40802833 00000006
	buffer_store_b8 v55, v6, s[20:23], null offen offset:16     ; c406007c 40802837 00001006
	buffer_store_b8 v59, v6, s[20:23], null offen offset:32     ; c406007c 4080283b 00002006
	buffer_store_b8 v63, v6, s[20:23], null offen offset:48     ; c406007c 4080283f 00003006
	buffer_store_b8 v67, v6, s[20:23], null offen offset:64     ; c406007c 40802843 00004006
	buffer_store_b8 v71, v6, s[20:23], null offen offset:80     ; c406007c 40802847 00005006
	buffer_store_b8 v75, v6, s[20:23], null offen offset:96     ; c406007c 4080284b 00006006
	buffer_store_b8 v78, v6, s[20:23], null offen offset:112    ; c406007c 4080284e 00007006
	s_branch BB60                                               ; bfa00001
BB59:
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB60:
	v_add_nc_u32_e32 v2, 16, v1                                 ; 4a040290
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc0 BB63                                         ; bfa100a5
BB61:
	s_mov_b32 s8, s0                                            ; be880000
	s_movk_i32 s9, 0x8000                                       ; b0098000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[8:9], 0x40                          ; f4004404 f8000040
	s_load_b128 s[20:23], s[8:9], 0x10                          ; f4004504 f8000010
	v_add3_u32 v3, v4, s5, v1                                   ; d6550003 04040b04
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v3, 1, v3                                 ; 30060681
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v5, v3, s[16:19], null offen offset:32  ; c408007c 40802005 00002003
	v_and_b32_e32 v7, 16, v0                                    ; 360e0090
	s_lshr_b32 s1, s7, 4                                        ; 85018407
	v_lshrrev_b32_e32 v6, 4, v2                                 ; 320c0484
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s1, s10, s1                                       ; 9601010a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshl_or_b32 v7, v7, 3, v4                                 ; d6560007 04110707
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v6, s1, v6, 8                                ; d6470006 02220c01
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v8, v7, s2, v6                                   ; d6550008 04180507
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v9, v8, s[20:23], null offen             ; c407807c 40802809 00000008
	buffer_load_d16_u8 v10, v8, s[20:23], null offen offset:16  ; c407807c 4080280a 00001008
	buffer_load_d16_u8 v11, v8, s[20:23], null offen offset:32  ; c407807c 4080280b 00002008
	buffer_load_d16_u8 v12, v8, s[20:23], null offen offset:48  ; c407807c 4080280c 00003008
	buffer_load_d16_u8 v13, v8, s[20:23], null offen offset:64  ; c407807c 4080280d 00004008
	buffer_load_d16_u8 v14, v8, s[20:23], null offen offset:80  ; c407807c 4080280e 00005008
	buffer_load_d16_u8 v15, v8, s[20:23], null offen offset:96  ; c407807c 4080280f 00006008
	buffer_load_d16_u8 v40, v8, s[20:23], null offen offset:112 ; c407807c 40802828 00007008
	v_add3_u32 v7, v7, s3, v6                                   ; d6550007 04180707
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v41, v9                                   ; 7e52d909
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v45, v10                                  ; 7e5ad90a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v49, v11                                  ; 7e62d90b
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v53, v12                                  ; 7e6ad90c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v42, v5, v41, v16 op_sel_hi:[1,0,0]         ; cc21002a 0c425305
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v57, v13                                  ; 7e72d90d
	v_fma_mixlo_f16 v46, v5, v45, v17 op_sel_hi:[1,0,0]         ; cc21002e 0c465b05
	v_fma_mixlo_f16 v50, v5, v49, v18 op_sel_hi:[1,0,0]         ; cc210032 0c4a6305
	v_fma_mixlo_f16 v54, v5, v53, v19 op_sel_hi:[1,0,0]         ; cc210036 0c4e6b05
	v_maxmin_num_f16 v42, 0xdf00, v42, neg(0xdf00)              ; d66b002a 83fe54ff 0000df00
	v_fma_mixlo_f16 v58, v5, v57, v20 op_sel_hi:[1,0,0]         ; cc21003a 0c527305
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v61, v14                                  ; 7e7ad90e
	v_maxmin_num_f16 v46, 0xdf00, v46, neg(0xdf00)              ; d66b002e 83fe5cff 0000df00
	v_maxmin_num_f16 v50, 0xdf00, v50, neg(0xdf00)              ; d66b0032 83fe64ff 0000df00
	v_maxmin_num_f16 v54, 0xdf00, v54, neg(0xdf00)              ; d66b0036 83fe6cff 0000df00
	v_cvt_f32_f16_e32 v43, v42                                  ; 7e56172a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v65, v15                                  ; 7e82d90f
	v_maxmin_num_f16 v58, 0xdf00, v58, neg(0xdf00)              ; d66b003a 83fe74ff 0000df00
	v_fma_mixlo_f16 v62, v5, v61, v21 op_sel_hi:[1,0,0]         ; cc21003e 0c567b05
	v_cvt_f32_f16_e32 v47, v46                                  ; 7e5e172e
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
	v_cvt_f32_f16_e32 v55, v54                                  ; 7e6e1736
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v69, v40                                  ; 7e8ad928
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v0, v43, v128, vcc_lo                     ; 0201012b
	v_fma_mixlo_f16 v66, v5, v65, v22 op_sel_hi:[1,0,0]         ; cc210042 0c5a8305
	v_cvt_f32_f16_e32 v59, v58                                  ; 7e76173a
	v_maxmin_num_f16 v62, 0xdf00, v62, neg(0xdf00)              ; d66b003e 83fe7cff 0000df00
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v0, v47, v128, vcc_lo                     ; 0201012f
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v0, v55, v128, vcc_lo                     ; 02010137
	v_fma_mixlo_f16 v5, v5, v69, v23 op_sel_hi:[1,0,0]          ; cc210005 0c5e8b05
	v_maxmin_num_f16 v66, 0xdf00, v66, neg(0xdf00)              ; d66b0042 83fe84ff 0000df00
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v0, v59, v128, vcc_lo                     ; 0201013b
	v_cvt_f32_f16_e32 v63, v62                                  ; 7e7e173e
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_maxmin_num_f16 v5, 0xdf00, v5, neg(0xdf00)                ; d66b0005 83fe0aff 0000df00
	v_cvt_f32_f16_e32 v67, v66                                  ; 7e861742
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v0, v63, v128, vcc_lo                     ; 0201013f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_cvt_f32_f16_e32 v70, v5                                   ; 7e8c1705
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v0, v67, v128, vcc_lo                     ; 02010143
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v0, v70, v128, vcc_lo                     ; 02010146
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v44, v7, s[20:23], null offen               ; c406007c 4080282c 00000007
	buffer_store_b8 v48, v7, s[20:23], null offen offset:16     ; c406007c 40802830 00001007
	buffer_store_b8 v52, v7, s[20:23], null offen offset:32     ; c406007c 40802834 00002007
	buffer_store_b8 v56, v7, s[20:23], null offen offset:48     ; c406007c 40802838 00003007
	buffer_store_b8 v60, v7, s[20:23], null offen offset:64     ; c406007c 4080283c 00004007
	buffer_store_b8 v64, v7, s[20:23], null offen offset:80     ; c406007c 40802840 00005007
	buffer_store_b8 v68, v7, s[20:23], null offen offset:96     ; c406007c 40802844 00006007
	buffer_store_b8 v71, v7, s[20:23], null offen offset:112    ; c406007c 40802847 00007007
BB63:
	s_cmp_lt_u32 s12, s6                                        ; bf0a060c
	s_cbranch_scc0 BB66                                         ; bfa10131
BB64:
	s_mov_b32 s8, s0                                            ; be880000
	s_movk_i32 s9, 0x8000                                       ; b0098000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[16:19], s[8:9], 0x40                          ; f4004404 f8000040
	s_load_b128 s[20:23], s[8:9], 0x10                          ; f4004504 f8000010
	v_and_b32_e32 v0, 16, v0                                    ; 36000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshl_or_b32 v0, v0, 3, v4                                 ; d6560000 04110700
	v_add3_u32 v4, v4, s5, v1                                   ; d6550004 04040b04
	v_lshlrev_b32_e32 v4, 1, v4                                 ; 30080881
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v5, v4, s[16:19], null offen            ; c408007c 40802005 00000004
	v_lshrrev_b32_e32 v3, 4, v1                                 ; 32060284
	s_lshr_b32 s7, s7, 4                                        ; 85078407
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b9
	s_mul_i32 s13, s13, s7                                      ; 960d070d
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v3, s13, v3, 8                               ; d6470003 0222060d
	v_add3_u32 v6, v0, s2, v3                                   ; d6550006 040c0500
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v7, v6, s[20:23], null offen             ; c407807c 40802807 00000006
	buffer_load_d16_u8 v8, v6, s[20:23], null offen offset:16   ; c407807c 40802808 00001006
	buffer_load_d16_u8 v9, v6, s[20:23], null offen offset:32   ; c407807c 40802809 00002006
	buffer_load_d16_u8 v10, v6, s[20:23], null offen offset:48  ; c407807c 4080280a 00003006
	buffer_load_d16_u8 v11, v6, s[20:23], null offen offset:64  ; c407807c 4080280b 00004006
	buffer_load_d16_u8 v12, v6, s[20:23], null offen offset:80  ; c407807c 4080280c 00005006
	buffer_load_d16_u8 v13, v6, s[20:23], null offen offset:96  ; c407807c 4080280d 00006006
	buffer_load_d16_u8 v14, v6, s[20:23], null offen offset:112 ; c407807c 4080280e 00007006
	buffer_load_d16_b16 v15, v4, s[16:19], null offen offset:32 ; c408007c 4080200f 00002004
	v_lshrrev_b32_e32 v2, 4, v2                                 ; 32040484
	v_add3_u32 v3, v0, s3, v3                                   ; d6550003 040c0700
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_add_lshl_u32 v2, s13, v2, 8                               ; d6470002 0222040d
	v_add3_u32 v16, v0, s2, v2                                  ; d6550010 04080500
	v_add3_u32 v0, v0, s3, v2                                   ; d6550000 04080700
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cvt_f32_fp8_e32 v17, v7                                   ; 7e22d907
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v21, v8                                   ; 7e2ad908
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v42, v10                                  ; 7e54d90a
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mixlo_f16 v18, v5, v17, v24 op_sel_hi:[1,0,0]         ; cc210012 0c622305
	v_fma_mixlo_f16 v22, v5, v21, v25 op_sel_hi:[1,0,0]         ; cc210016 0c662b05
	v_cvt_f32_fp8_e32 v25, v9                                   ; 7e32d909
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v46, v11                                  ; 7e5cd90b
	v_fma_mixlo_f16 v43, v5, v42, v27 op_sel_hi:[1,0,0]         ; cc21002b 0c6e5505
	v_maxmin_num_f16 v18, 0xdf00, v18, neg(0xdf00)              ; d66b0012 83fe24ff 0000df00
	v_maxmin_num_f16 v22, 0xdf00, v22, neg(0xdf00)              ; d66b0016 83fe2cff 0000df00
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v50, v12                                  ; 7e64d90c
	v_fma_mixlo_f16 v26, v5, v25, v26 op_sel_hi:[1,0,0]         ; cc21001a 0c6a3305
	v_fma_mixlo_f16 v47, v5, v46, v28 op_sel_hi:[1,0,0]         ; cc21002f 0c725d05
	v_maxmin_num_f16 v43, 0xdf00, v43, neg(0xdf00)              ; d66b002b 83fe56ff 0000df00
	v_cvt_f32_f16_e32 v19, v18                                  ; 7e261712
	v_cvt_f32_f16_e32 v23, v22                                  ; 7e2e1716
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v54, v13                                  ; 7e6cd90d
	v_fma_mixlo_f16 v51, v5, v50, v29 op_sel_hi:[1,0,0]         ; cc210033 0c766505
	v_maxmin_num_f16 v26, 0xdf00, v26, neg(0xdf00)              ; d66b001a 83fe34ff 0000df00
	v_maxmin_num_f16 v47, 0xdf00, v47, neg(0xdf00)              ; d66b002f 83fe5eff 0000df00
	v_cvt_f32_f16_e32 v44, v43                                  ; 7e58172b
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v0, v19, v128, vcc_lo                     ; 02010113
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v58, v14                                  ; 7e74d90e
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v0, v23, v128, vcc_lo                     ; 02010117
	v_fma_mixlo_f16 v55, v5, v54, v30 op_sel_hi:[1,0,0]         ; cc210037 0c7a6d05
	v_maxmin_num_f16 v51, 0xdf00, v51, neg(0xdf00)              ; d66b0033 83fe66ff 0000df00
	v_cvt_f32_f16_e32 v40, v26                                  ; 7e50171a
	v_cvt_f32_f16_e32 v48, v47                                  ; 7e60172f
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v0, v44, v128, vcc_lo                     ; 0201012c
	v_fma_mixlo_f16 v5, v5, v58, v31 op_sel_hi:[1,0,0]          ; cc210005 0c7e7505
	v_maxmin_num_f16 v55, 0xdf00, v55, neg(0xdf00)              ; d66b0037 83fe6eff 0000df00
	v_cvt_f32_f16_e32 v52, v51                                  ; 7e681733
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v0, v40, v128, vcc_lo                     ; 02010128
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
	v_maxmin_num_f16 v5, 0xdf00, v5, neg(0xdf00)                ; d66b0005 83fe0aff 0000df00
	v_cvt_f32_f16_e32 v56, v55                                  ; 7e701737
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v0, v52, v128, vcc_lo                     ; 02010134
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_cvt_f32_f16_e32 v59, v5                                   ; 7e761705
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v0, v56, v128, vcc_lo                     ; 02010138
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v0, v59, v128, vcc_lo                     ; 0201013b
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v20, v3, s[20:23], null offen               ; c406007c 40802814 00000003
	buffer_store_b8 v24, v3, s[20:23], null offen offset:16     ; c406007c 40802818 00001003
	buffer_store_b8 v41, v3, s[20:23], null offen offset:32     ; c406007c 40802829 00002003
	buffer_store_b8 v45, v3, s[20:23], null offen offset:48     ; c406007c 4080282d 00003003
	buffer_store_b8 v49, v3, s[20:23], null offen offset:64     ; c406007c 40802831 00004003
	buffer_store_b8 v53, v3, s[20:23], null offen offset:80     ; c406007c 40802835 00005003
	buffer_store_b8 v57, v3, s[20:23], null offen offset:96     ; c406007c 40802839 00006003
	buffer_store_b8 v60, v3, s[20:23], null offen offset:112    ; c406007c 4080283c 00007003
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v61, v16, s[20:23], null offen           ; c407807c 4080283d 00000010
	buffer_load_d16_u8 v62, v16, s[20:23], null offen offset:16 ; c407807c 4080283e 00001010
	buffer_load_d16_u8 v63, v16, s[20:23], null offen offset:32 ; c407807c 4080283f 00002010
	buffer_load_d16_u8 v64, v16, s[20:23], null offen offset:48 ; c407807c 40802840 00003010
	buffer_load_d16_u8 v65, v16, s[20:23], null offen offset:64 ; c407807c 40802841 00004010
	buffer_load_d16_u8 v66, v16, s[20:23], null offen offset:80 ; c407807c 40802842 00005010
	buffer_load_d16_u8 v67, v16, s[20:23], null offen offset:96 ; c407807c 40802843 00006010
	buffer_load_d16_u8 v68, v16, s[20:23], null offen offset:112 ; c407807c 40802844 00007010
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v69, v61                                  ; 7e8ad93d
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v73, v62                                  ; 7e92d93e
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v77, v63                                  ; 7e9ad93f
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v81, v64                                  ; 7ea2d940
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v70, v15, v69, v32 op_sel_hi:[1,0,0]        ; cc210046 0c828b0f
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v85, v65                                  ; 7eaad941
	v_fma_mixlo_f16 v74, v15, v73, v33 op_sel_hi:[1,0,0]        ; cc21004a 0c86930f
	v_fma_mixlo_f16 v78, v15, v77, v34 op_sel_hi:[1,0,0]        ; cc21004e 0c8a9b0f
	v_fma_mixlo_f16 v82, v15, v81, v35 op_sel_hi:[1,0,0]        ; cc210052 0c8ea30f
	v_maxmin_num_f16 v70, 0xdf00, v70, neg(0xdf00)              ; d66b0046 83fe8cff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v89, v66                                  ; 7eb2d942
	v_fma_mixlo_f16 v86, v15, v85, v36 op_sel_hi:[1,0,0]        ; cc210056 0c92ab0f
	v_maxmin_num_f16 v74, 0xdf00, v74, neg(0xdf00)              ; d66b004a 83fe94ff 0000df00
	v_maxmin_num_f16 v78, 0xdf00, v78, neg(0xdf00)              ; d66b004e 83fe9cff 0000df00
	v_maxmin_num_f16 v82, 0xdf00, v82, neg(0xdf00)              ; d66b0052 83fea4ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v93, v67                                  ; 7ebad943
	v_cvt_f32_f16_e32 v71, v70                                  ; 7e8e1746
	v_fma_mixlo_f16 v90, v15, v89, v37 op_sel_hi:[1,0,0]        ; cc21005a 0c96b30f
	v_maxmin_num_f16 v86, 0xdf00, v86, neg(0xdf00)              ; d66b0056 83feacff 0000df00
	v_cvt_f32_f16_e32 v75, v74                                  ; 7e96174a
	v_cvt_f32_f16_e32 v79, v78                                  ; 7e9e174e
	v_cvt_f32_f16_e32 v83, v82                                  ; 7ea61752
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v1, v68                                   ; 7e02d944
	v_fma_mixlo_f16 v94, v15, v93, v38 op_sel_hi:[1,0,0]        ; cc21005e 0c9abb0f
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v0, v71, v128, vcc_lo                     ; 02010147
	v_maxmin_num_f16 v90, 0xdf00, v90, neg(0xdf00)              ; d66b005a 83feb4ff 0000df00
	v_cvt_f32_f16_e32 v87, v86                                  ; 7eae1756
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v0, v75, v128, vcc_lo                     ; 0201014b
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v0, v79, v128, vcc_lo                     ; 0201014f
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v0, v83, v128, vcc_lo                     ; 02010153
	v_fma_mixlo_f16 v15, v15, v1, v39 op_sel_hi:[1,0,0]         ; cc21000f 0c9e030f
	v_maxmin_num_f16 v94, 0xdf00, v94, neg(0xdf00)              ; d66b005e 83febcff 0000df00
	v_cvt_f32_f16_e32 v91, v90                                  ; 7eb6175a
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v0, v87, v128, vcc_lo                     ; 02010157
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v15, 0xdf00, v15, neg(0xdf00)              ; d66b000f 83fe1eff 0000df00
	v_cvt_f32_f16_e32 v95, v94                                  ; 7ebe175e
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v0, v91, v128, vcc_lo                     ; 0201015b
	v_cvt_f32_f16_e32 v2, v15                                   ; 7e04170f
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v0, v95, v128, vcc_lo                     ; 0201015f
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v0, v2, v128, vcc_lo                      ; 02010102
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v72, v0, s[20:23], null offen               ; c406007c 40802848 00000000
	buffer_store_b8 v76, v0, s[20:23], null offen offset:16     ; c406007c 4080284c 00001000
	buffer_store_b8 v80, v0, s[20:23], null offen offset:32     ; c406007c 40802850 00002000
	buffer_store_b8 v84, v0, s[20:23], null offen offset:48     ; c406007c 40802854 00003000
	buffer_store_b8 v88, v0, s[20:23], null offen offset:64     ; c406007c 40802858 00004000
	buffer_store_b8 v92, v0, s[20:23], null offen offset:80     ; c406007c 4080285c 00005000
	buffer_store_b8 v95, v0, s[20:23], null offen offset:96     ; c406007c 4080285f 00006000
	buffer_store_b8 v3, v0, s[20:23], null offen offset:112     ; c406007c 40802803 00007000
BB66:
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s14, -1                                        ; bf01c10e
	s_cbranch_scc0 BB75                                         ; bfa1000f
BB67:
	s_mov_b32 exec_lo, 3                                        ; befe0083
BB68:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[0:3], s[0:1], 0x0                             ; f4004000 f8000000
	s_add_co_u32 s14, s14, s10                                  ; 800e0a0e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
(invalid instruction)                                        ; d71f0000
	v_cndmask_b32_e32 v0, -1, v14, vcc_lo                       ; 02001cc1
	v_dual_mov_b32 v1, 1 :: v_dual_lshlrev_b32 v0, 2, v0        ; ca220081 01000082
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_atomic_add_u32 v1, v0, s[0:3], null offen            ; c40d407c 40800001 00000000
BB75:
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
