BB0:
	v_and_b32_e32 v10, 15, v0                                   ; 3614008f
	s_lshr_b32 s9, s8, 4                                        ; 85098408
	s_lshl_b32 s10, ttmp9, 6                                    ; 840a8675
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_lshr_b32 s11, s10, 4                                      ; 850b840a
	v_lshlrev_b32_e32 v11, 4, v10                               ; 30161484
	v_bfe_u32 v1, v0, 5, 2                                      ; d6100001 02090b00
	s_mul_i32 s12, s11, s9                                      ; 960c090b
	s_lshl_b32 s12, s12, 8                                      ; 840c880c
	s_add_co_u32 s13, 16, s10                                   ; 800d0a90
	v_bfe_u32 v13, v0, 4, 1                                     ; d610000d 02050900
	s_lshr_b32 s14, s13, 4                                      ; 850e840d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_mul_i32 s15, s14, s9                                      ; 960f090e
	v_lshlrev_b32_e32 v13, 3, v13                               ; 301a1a83
	s_lshl_b32 s15, s15, 8                                      ; 840f880f
	s_add_co_u32 s16, 32, s10                                   ; 80100aa0
	v_add3_u32 v12, v11, s1, s12                                ; d655000c 0030030b
	v_add3_u32 v14, v11, s1, s15                                ; d655000e 003c030b
	s_lshr_b32 s17, s16, 4                                      ; 85118410
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mul_i32 s18, s17, s9                                      ; 96120911
	v_add_nc_u32_e32 v12, v12, v13                              ; 4a181b0c
	v_add_nc_u32_e32 v14, v14, v13                              ; 4a1c1b0e
	s_lshl_b32 s18, s18, 8                                      ; 84128812
	s_add_co_u32 s19, 48, s10                                   ; 80130ab0
	v_add3_u32 v15, v11, s1, s18                                ; d655000f 0048030b
	s_lshr_b32 s20, s19, 4                                      ; 85148413
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mul_i32 s21, s20, s9                                      ; 96150914
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0              ; ca100080 10100080
	v_add_nc_u32_e32 v15, v15, v13                              ; 4a1e1b0f
	s_lshl_b32 s21, s21, 8                                      ; 84158815
	s_lshl_b32 s22, ttmp7, 8                                    ; 84168873
	v_add3_u32 v11, v11, s1, s21                                ; d655000b 0054030b
	v_lshl_add_u32 v1, v1, 6, s22                               ; d6460001 00590d01
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v11, v11, v13                              ; 4a161b0b
	v_add_nc_u32_e32 v4, 16, v1                                 ; 4a080290
	v_add_nc_u32_e32 v6, 32, v1                                 ; 4a0c02a0
	v_add_nc_u32_e32 v8, 48, v1                                 ; 4a1002b0
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_lshrrev_b32_e32 v2, 4, v1                                 ; 32040284
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	s_lshr_b32 s8, s8, 5                                        ; 85088508
	v_lshrrev_b32_e32 v4, 4, v4                                 ; 32080884
	v_lshrrev_b32_e32 v6, 4, v6                                 ; 320c0c84
	v_lshrrev_b32_e32 v12, 2, v12                               ; 32181882
	v_lshrrev_b32_e32 v8, 4, v8                                 ; 32101084
	v_lshrrev_b32_e32 v14, 2, v14                               ; 321c1c82
	v_lshrrev_b32_e32 v15, 2, v15                               ; 321e1e82
	v_lshrrev_b32_e32 v11, 2, v11                               ; 32161682
(invalid instruction)                                        ; d72c0003
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                        ; 02001302
	s_mov_b32 s1, 0                                             ; be810080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v0, v4, v9, vcc_lo                        ; 02001304
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
(invalid instruction)                                        ; d72c0007
	v_cndmask_b32_e32 v0, v6, v9, vcc_lo                        ; 02001306
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
(invalid instruction)                                        ; d72c0009
	v_cndmask_b32_e32 v0, v8, v9, vcc_lo                        ; 02001308
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	v_lshl_add_u32 v3, v3, 8, s4                                ; d6460003 00111103
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v60, 0              ; ca100080 3d3c0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v62, 0              ; ca100080 3f3e0080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v64, 0              ; ca100080 41400080
	v_lshl_add_u32 v5, v5, 8, s4                                ; d6460005 00111105
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0              ; ca100080 43420080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v68, 0              ; ca100080 45440080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v70, 0              ; ca100080 47460080
	v_lshl_add_u32 v7, v7, 8, s4                                ; d6460007 00111107
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v72, 0              ; ca100080 49480080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v74, 0              ; ca100080 4b4a0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v76, 0              ; ca100080 4d4c0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v78, 0              ; ca100080 4f4e0080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v80, 0              ; ca100080 51500080
	v_lshl_add_u32 v9, v9, 8, s4                                ; d6460009 00111109
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v82, 0              ; ca100080 53520080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v84, 0              ; ca100080 55540080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v86, 0              ; ca100080 57560080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v88, 0              ; ca100080 59580080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v90, 0              ; ca100080 5b5a0080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v92, 0              ; ca100080 5d5c0080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v94, 0              ; ca100080 5f5e0080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v96, 0              ; ca100080 61600080
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v98, 0              ; ca100080 63620080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v100, 0            ; ca100080 65640080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v102, 0            ; ca100080 67660080
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v104, 0            ; ca100080 69680080
	v_dual_mov_b32 v107, 0 :: v_dual_mov_b32 v106, 0            ; ca100080 6b6a0080
	v_dual_mov_b32 v109, 0 :: v_dual_mov_b32 v108, 0            ; ca100080 6d6c0080
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v110, 0            ; ca100080 6f6e0080
	v_dual_mov_b32 v113, 0 :: v_dual_mov_b32 v112, 0            ; ca100080 71700080
	v_dual_mov_b32 v115, 0 :: v_dual_mov_b32 v114, 0            ; ca100080 73720080
	v_dual_mov_b32 v117, 0 :: v_dual_mov_b32 v116, 0            ; ca100080 75740080
	v_dual_mov_b32 v119, 0 :: v_dual_mov_b32 v118, 0            ; ca100080 77760080
	v_dual_mov_b32 v121, 0 :: v_dual_mov_b32 v120, 0            ; ca100080 79780080
	v_dual_mov_b32 v123, 0 :: v_dual_mov_b32 v122, 0            ; ca100080 7b7a0080
	v_dual_mov_b32 v125, 0 :: v_dual_mov_b32 v124, 0            ; ca100080 7d7c0080
	v_dual_mov_b32 v127, 0 :: v_dual_mov_b32 v126, 0            ; ca100080 7f7e0080
	v_dual_mov_b32 v129, 0 :: v_dual_mov_b32 v128, 0            ; ca100080 81800080
	v_dual_mov_b32 v131, 0 :: v_dual_mov_b32 v130, 0            ; ca100080 83820080
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v132, 0            ; ca100080 85840080
	v_dual_mov_b32 v135, 0 :: v_dual_mov_b32 v134, 0            ; ca100080 87860080
	v_dual_mov_b32 v137, 0 :: v_dual_mov_b32 v136, 0            ; ca100080 89880080
	v_dual_mov_b32 v139, 0 :: v_dual_mov_b32 v138, 0            ; ca100080 8b8a0080
	v_dual_mov_b32 v141, 0 :: v_dual_mov_b32 v140, 0            ; ca100080 8d8c0080
	v_dual_mov_b32 v143, 0 :: v_dual_mov_b32 v142, 0            ; ca100080 8f8e0080
	s_branch BB1                                                ; bfa000bd
	s_nop 0                                                     ; bf800000
	(then repeated 5 times)
BB3:
	s_mov_b32 s22, s0                                           ; be960000
	s_movk_i32 s23, 0x8000                                      ; b0178000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[22:23], 0x70                        ; f400460b f8000070
	s_load_b128 s[28:31], s[22:23], 0x30                        ; f400470b f8000030
	s_lshl_b32 s4, s1, 5                                        ; 84048501
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s4, s4, 4                                        ; 85048404
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s4, s4, 8                                        ; 84048804
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s9, s4, 2                                        ; 85098204
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v13, s9, v12, 2                              ; d647000d 020a1809
	v_add_lshl_u32 v144, s9, v14, 2                             ; d6470090 020a1c09
	v_add_lshl_u32 v145, s9, v15, 2                             ; d6470091 020a1e09
	v_add_lshl_u32 v146, s9, v11, 2                             ; d6470092 020a1609
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[148:149], v13, s[24:27], null offen       ; c405407c 40803094 0000000d
	buffer_load_b64 v[150:151], v144, s[24:27], null offen      ; c405407c 40803096 00000090
	buffer_load_b64 v[152:153], v145, s[24:27], null offen      ; c405407c 40803098 00000091
	buffer_load_b64 v[154:155], v146, s[24:27], null offen      ; c405407c 4080309a 00000092
(invalid instruction)                                        ; d71f009c
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_add_nc_u32_e32 v147, s4, v3                               ; 4b260604
	v_add_nc_u32_e32 v159, s4, v5                               ; 4b3e0a04
	v_add_nc_u32_e32 v161, s4, v7                               ; 4b420e04
	v_add_nc_u32_e32 v163, s4, v9                               ; 4b461204
	v_and_b32_e32 v157, 15, v156                                ; 373b388f
	v_lshrrev_b32_e32 v156, 4, v156                             ; 33393884
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_lshlrev_b32_e32 v157, 4, v157                             ; 313b3a84
	v_lshlrev_b32_e32 v156, 3, v156                             ; 31393883
	v_add3_u32 v158, v156, v147, v157                           ; d655009e 0677279c
	v_add3_u32 v160, v156, v159, v157                           ; d65500a0 06773f9c
	v_add3_u32 v162, v156, v161, v157                           ; d65500a2 0677439c
	v_add3_u32 v164, v156, v163, v157                           ; d65500a4 0677479c
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[166:167], v158, s[28:31], null offen      ; c405407c 408038a6 0000009e
	buffer_load_b64 v[168:169], v160, s[28:31], null offen      ; c405407c 408038a8 000000a0
	buffer_load_b64 v[170:171], v162, s[28:31], null offen      ; c405407c 408038aa 000000a2
	buffer_load_b64 v[164:165], v164, s[28:31], null offen      ; c405407c 408038a4 000000a4
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[172:173], v13, s[24:27], null offen offset:256 ; c405407c 408030ac 0001000d
	buffer_load_b64 v[174:175], v144, s[24:27], null offen offset:256 ; c405407c 408030ae 00010090
	buffer_load_b64 v[144:145], v145, s[24:27], null offen offset:256 ; c405407c 40803090 00010091
	buffer_load_b64 v[176:177], v146, s[24:27], null offen offset:256 ; c405407c 408030b0 00010092
	s_movk_i32 s12, 0x100                                       ; b00c0100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v147, v157, s12, v147                            ; d6550093 064c199d
	v_add3_u32 v159, v157, s12, v159                            ; d655009f 067c199d
	v_add3_u32 v161, v157, s12, v161                            ; d65500a1 0684199d
	v_add3_u32 v157, v157, s12, v163                            ; d655009d 068c199d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add_nc_u32_e32 v147, v147, v156                           ; 4b273993
	v_add_nc_u32_e32 v159, v159, v156                           ; 4b3f399f
	v_add_nc_u32_e32 v161, v161, v156                           ; 4b4339a1
	v_add_nc_u32_e32 v157, v157, v156                           ; 4b3b399d
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[146:147], v147, s[28:31], null offen      ; c405407c 40803892 00000093
	buffer_load_b64 v[158:159], v159, s[28:31], null offen      ; c405407c 4080389e 0000009f
	buffer_load_b64 v[160:161], v161, s[28:31], null offen      ; c405407c 408038a0 000000a1
	buffer_load_b64 v[156:157], v157, s[28:31], null offen      ; c405407c 4080389c 0000009d
	s_add_co_u32 s1, s1, 1                                      ; 80018101
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[152:153], v[166:167], v[80:87] ; cc464050 1d434d98
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[154:155], v[166:167], v[112:119] ; cc464070 1dc34d9a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[148:149], v[166:167], v[16:23] ; cc464010 1c434d94
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[150:151], v[166:167], v[48:55] ; cc464030 1cc34d96
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[148:149], v[168:169], v[24:31] ; cc464018 1c635194
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[154:155], v[168:169], v[120:127] ; cc464078 1de3519a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[150:151], v[168:169], v[56:63] ; cc464038 1ce35196
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[152:153], v[168:169], v[88:95] ; cc464058 1d635198
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[148:149], v[170:171], v[32:39] ; cc464020 1c835594
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[150:151], v[170:171], v[64:71] ; cc464040 1d035596
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[152:153], v[170:171], v[96:103] ; cc464060 1d835598
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[154:155], v[170:171], v[128:135] ; cc464080 1e03559a
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[150:151], v[164:165], v[72:79] ; cc464048 1d234996
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[152:153], v[164:165], v[104:111] ; cc464068 1da34998
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[154:155], v[164:165], v[136:143] ; cc464088 1e23499a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[148:149], v[164:165], v[40:47] ; cc464028 1ca34994
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[144:145], v[146:147], v[80:87] ; cc464050 1d432590
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[176:177], v[146:147], v[112:119] ; cc464070 1dc325b0
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[172:173], v[146:147], v[16:23] ; cc464010 1c4325ac
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[174:175], v[146:147], v[48:55] ; cc464030 1cc325ae
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[172:173], v[158:159], v[24:31] ; cc464018 1c633dac
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[176:177], v[158:159], v[120:127] ; cc464078 1de33db0
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[174:175], v[158:159], v[56:63] ; cc464038 1ce33dae
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[144:145], v[158:159], v[88:95] ; cc464058 1d633d90
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[172:173], v[160:161], v[32:39] ; cc464020 1c8341ac
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[174:175], v[160:161], v[64:71] ; cc464040 1d0341ae
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[144:145], v[160:161], v[96:103] ; cc464060 1d834190
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[176:177], v[160:161], v[128:135] ; cc464080 1e0341b0
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[174:175], v[156:157], v[72:79] ; cc464048 1d2339ae
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[144:145], v[156:157], v[104:111] ; cc464068 1da33990
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[176:177], v[156:157], v[136:143] ; cc464088 1e2339b0
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[172:173], v[156:157], v[40:47] ; cc464028 1ca339ac
BB1:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s1, s8                                         ; bf090801
	s_cbranch_scc0 BB3                                          ; bfa1ff46
BB4:
	s_cmp_lt_u32 s10, s6                                        ; bf0a060a
	s_cbranch_scc0 BB7                                          ; bfa10261
BB5:
	s_mov_b32 s8, s0                                            ; be880000
	s_movk_i32 s9, 0x8000                                       ; b0098000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[8:9], 0x40                          ; f4004604 f8000040
	s_load_b128 s[28:31], s[8:9], 0x10                          ; f4004704 f8000010
	v_add3_u32 v3, v10, s5, v1                                  ; d6550003 04040b0a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v3, 1, v3                                 ; 30060681
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v5, v3, s[24:27], null offen            ; c408007c 40803005 00000003
	v_and_b32_e32 v7, 16, v0                                    ; 360e0090
	s_lshr_b32 s1, s7, 4                                        ; 85018407
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s11, s11, s1                                      ; 960b010b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshl_or_b32 v7, v7, 3, v10                                ; d6560007 04290707
	v_add_lshl_u32 v9, s11, v2, 8                               ; d6470009 0222040b
	v_add3_u32 v11, v7, s2, v9                                  ; d655000b 04240507
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v12, v11, s[28:31], null offen           ; c407807c 4080380c 0000000b
	buffer_load_d16_u8 v13, v11, s[28:31], null offen offset:16 ; c407807c 4080380d 0000100b
	buffer_load_d16_u8 v14, v11, s[28:31], null offen offset:32 ; c407807c 4080380e 0000200b
	buffer_load_d16_u8 v15, v11, s[28:31], null offen offset:48 ; c407807c 4080380f 0000300b
	buffer_load_d16_u8 v144, v11, s[28:31], null offen offset:64 ; c407807c 40803890 0000400b
	buffer_load_d16_u8 v145, v11, s[28:31], null offen offset:80 ; c407807c 40803891 0000500b
	buffer_load_d16_u8 v146, v11, s[28:31], null offen offset:96 ; c407807c 40803892 0000600b
	buffer_load_d16_u8 v147, v11, s[28:31], null offen offset:112 ; c407807c 40803893 0000700b
	s_clause 0x2                                                ; bf850002
	buffer_load_d16_b16 v148, v3, s[24:27], null offen offset:32 ; c408007c 40803094 00002003
	buffer_load_d16_b16 v149, v3, s[24:27], null offen offset:64 ; c408007c 40803095 00004003
	buffer_load_d16_b16 v150, v3, s[24:27], null offen offset:96 ; c408007c 40803096 00006003
	v_add_lshl_u32 v151, s11, v4, 8                             ; d6470097 0222080b
	v_add3_u32 v9, v7, s3, v9                                   ; d6550009 04240707
	v_add_lshl_u32 v153, s11, v6, 8                             ; d6470099 02220c0b
	v_add_lshl_u32 v155, s11, v8, 8                             ; d647009b 0222100b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add3_u32 v152, v7, s2, v151                               ; d6550098 065c0507
	v_add3_u32 v151, v7, s3, v151                               ; d6550097 065c0707
	v_add3_u32 v154, v7, s2, v153                               ; d655009a 06640507
	v_add3_u32 v153, v7, s3, v153                               ; d6550099 06640707
	v_add3_u32 v156, v7, s2, v155                               ; d655009c 066c0507
	v_add3_u32 v7, v7, s3, v155                                 ; d6550007 066c0707
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cvt_f32_fp8_e32 v157, v12                                 ; 7f3ad90c
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_cvt_f32_fp8_e32 v161, v13                                 ; 7f42d90d
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cvt_f32_fp8_e32 v165, v14                                 ; 7f4ad90e
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v169, v15                                 ; 7f52d90f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v158, v5, v157, v16 op_sel_hi:[1,0,0]       ; cc21009e 0c433b05
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v173, v144                                ; 7f5ad990
	v_fma_mixlo_f16 v162, v5, v161, v17 op_sel_hi:[1,0,0]       ; cc2100a2 0c474305
	v_fma_mixlo_f16 v166, v5, v165, v18 op_sel_hi:[1,0,0]       ; cc2100a6 0c4b4b05
	v_fma_mixlo_f16 v170, v5, v169, v19 op_sel_hi:[1,0,0]       ; cc2100aa 0c4f5305
	v_maxmin_num_f16 v158, 0xdf00, v158, neg(0xdf00)            ; d66b009e 83ff3cff 0000df00
	v_fma_mixlo_f16 v174, v5, v173, v20 op_sel_hi:[1,0,0]       ; cc2100ae 0c535b05
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v177, v145                                ; 7f62d991
	v_maxmin_num_f16 v162, 0xdf00, v162, neg(0xdf00)            ; d66b00a2 83ff44ff 0000df00
	v_maxmin_num_f16 v166, 0xdf00, v166, neg(0xdf00)            ; d66b00a6 83ff4cff 0000df00
	v_maxmin_num_f16 v170, 0xdf00, v170, neg(0xdf00)            ; d66b00aa 83ff54ff 0000df00
(invalid instruction)                                        ; d58b009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v181, v146                                ; 7f6ad992
	v_maxmin_num_f16 v174, 0xdf00, v174, neg(0xdf00)            ; d66b00ae 83ff5cff 0000df00
	v_fma_mixlo_f16 v178, v5, v177, v21 op_sel_hi:[1,0,0]       ; cc2100b2 0c576305
(invalid instruction)                                        ; d58b00a3
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
(invalid instruction)                                        ; d58b00a7
	v_cndmask_b32_e32 v0, v166, v128, vcc_lo                    ; 020101a6
(invalid instruction)                                        ; d58b00ab
	v_cndmask_b32_e32 v0, v170, v128, vcc_lo                    ; 020101aa
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v185, v147                                ; 7f72d993
(invalid instruction)                                        ; d76900a0
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                    ; 0201019f
	v_fma_mixlo_f16 v182, v5, v181, v22 op_sel_hi:[1,0,0]       ; cc2100b6 0c5b6b05
(invalid instruction)                                        ; d58b00af
	v_cndmask_b32_e32 v0, v174, v128, vcc_lo                    ; 020101ae
	v_maxmin_num_f16 v178, 0xdf00, v178, neg(0xdf00)            ; d66b00b2 83ff64ff 0000df00
(invalid instruction)                                        ; d76900a4
	v_cndmask_b32_e32 v0, v163, v128, vcc_lo                    ; 020101a3
(invalid instruction)                                        ; d76900a8
	v_cndmask_b32_e32 v0, v167, v128, vcc_lo                    ; 020101a7
(invalid instruction)                                        ; d76900ac
	v_cndmask_b32_e32 v0, v171, v128, vcc_lo                    ; 020101ab
	v_fma_mixlo_f16 v5, v5, v185, v23 op_sel_hi:[1,0,0]         ; cc210005 0c5f7305
	v_maxmin_num_f16 v182, 0xdf00, v182, neg(0xdf00)            ; d66b00b6 83ff6cff 0000df00
(invalid instruction)                                        ; d76900b0
	v_cndmask_b32_e32 v0, v175, v128, vcc_lo                    ; 020101af
(invalid instruction)                                        ; d58b00b3
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                    ; 020101b2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_maxmin_num_f16 v5, 0xdf00, v5, neg(0xdf00)                ; d66b0005 83fe0aff 0000df00
(invalid instruction)                                        ; d58b00b7
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                    ; 020101b6
(invalid instruction)                                        ; d76900b4
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                    ; 020101b3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_cvt_f32_f16_e32 v186, v5                                  ; 7f741705
(invalid instruction)                                        ; d76900b8
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                    ; 020101b7
(invalid instruction)                                        ; d76900bb
	v_cndmask_b32_e32 v0, v186, v128, vcc_lo                    ; 020101ba
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v160, v9, s[28:31], null offen              ; c406007c 408038a0 00000009
	buffer_store_b8 v164, v9, s[28:31], null offen offset:16    ; c406007c 408038a4 00001009
	buffer_store_b8 v168, v9, s[28:31], null offen offset:32    ; c406007c 408038a8 00002009
	buffer_store_b8 v172, v9, s[28:31], null offen offset:48    ; c406007c 408038ac 00003009
	buffer_store_b8 v176, v9, s[28:31], null offen offset:64    ; c406007c 408038b0 00004009
	buffer_store_b8 v180, v9, s[28:31], null offen offset:80    ; c406007c 408038b4 00005009
	buffer_store_b8 v184, v9, s[28:31], null offen offset:96    ; c406007c 408038b8 00006009
	buffer_store_b8 v187, v9, s[28:31], null offen offset:112   ; c406007c 408038bb 00007009
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v188, v152, s[28:31], null offen         ; c407807c 408038bc 00000098
	buffer_load_d16_u8 v189, v152, s[28:31], null offen offset:16 ; c407807c 408038bd 00001098
	buffer_load_d16_u8 v190, v152, s[28:31], null offen offset:32 ; c407807c 408038be 00002098
	buffer_load_d16_u8 v191, v152, s[28:31], null offen offset:48 ; c407807c 408038bf 00003098
	buffer_load_d16_u8 v3, v152, s[28:31], null offen offset:64 ; c407807c 40803803 00004098
	buffer_load_d16_u8 v5, v152, s[28:31], null offen offset:80 ; c407807c 40803805 00005098
	buffer_load_d16_u8 v9, v152, s[28:31], null offen offset:96 ; c407807c 40803809 00006098
	buffer_load_d16_u8 v11, v152, s[28:31], null offen offset:112 ; c407807c 4080380b 00007098
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v12, v188                                 ; 7e18d9bc
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v16, v189                                 ; 7e20d9bd
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v20, v190                                 ; 7e28d9be
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mixlo_f16 v13, v148, v12, v24 op_sel_hi:[1,0,0]       ; cc21000d 0c621994
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v24, v191                                 ; 7e30d9bf
	v_fma_mixlo_f16 v17, v148, v16, v25 op_sel_hi:[1,0,0]       ; cc210011 0c662194
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v144, v3                                  ; 7f20d903
	v_fma_mixlo_f16 v21, v148, v20, v26 op_sel_hi:[1,0,0]       ; cc210015 0c6a2994
	v_maxmin_num_f16 v13, 0xdf00, v13, neg(0xdf00)              ; d66b000d 83fe1aff 0000df00
	v_fma_mixlo_f16 v25, v148, v24, v27 op_sel_hi:[1,0,0]       ; cc210019 0c6e3194
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v152, v5                                  ; 7f30d905
	v_maxmin_num_f16 v17, 0xdf00, v17, neg(0xdf00)              ; d66b0011 83fe22ff 0000df00
	v_fma_mixlo_f16 v145, v148, v144, v28 op_sel_hi:[1,0,0]     ; cc210091 0c732194
	v_maxmin_num_f16 v21, 0xdf00, v21, neg(0xdf00)              ; d66b0015 83fe2aff 0000df00
	v_cvt_f32_f16_e32 v14, v13                                  ; 7e1c170d
	v_maxmin_num_f16 v25, 0xdf00, v25, neg(0xdf00)              ; d66b0019 83fe32ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v159, v9                                  ; 7f3ed909
	v_fma_mixlo_f16 v155, v148, v152, v29 op_sel_hi:[1,0,0]     ; cc21009b 0c773194
	v_cvt_f32_f16_e32 v18, v17                                  ; 7e241711
	v_maxmin_num_f16 v145, 0xdf00, v145, neg(0xdf00)            ; d66b0091 83ff22ff 0000df00
	v_cvt_f32_f16_e32 v22, v21                                  ; 7e2c1715
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v163, v11                                 ; 7f46d90b
	v_cvt_f32_f16_e32 v26, v25                                  ; 7e341719
	v_fma_mixlo_f16 v160, v148, v159, v30 op_sel_hi:[1,0,0]     ; cc2100a0 0c7b3f94
	v_maxmin_num_f16 v155, 0xdf00, v155, neg(0xdf00)            ; d66b009b 83ff36ff 0000df00
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                     ; 02010112
(invalid instruction)                                        ; d58b0092
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                    ; 02010191
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v0, v22, v128, vcc_lo                     ; 02010116
	v_fma_mixlo_f16 v148, v148, v163, v31 op_sel_hi:[1,0,0]     ; cc210094 0c7f4794
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
	v_maxmin_num_f16 v160, 0xdf00, v160, neg(0xdf00)            ; d66b00a0 83ff40ff 0000df00
(invalid instruction)                                        ; d58b009d
	v_cndmask_b32_e32 v0, v155, v128, vcc_lo                    ; 0201019b
(invalid instruction)                                        ; d7690093
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                    ; 02010192
	v_maxmin_num_f16 v148, 0xdf00, v148, neg(0xdf00)            ; d66b0094 83ff28ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; d58b00a1
	v_cndmask_b32_e32 v0, v160, v128, vcc_lo                    ; 020101a0
(invalid instruction)                                        ; d769009e
	v_cndmask_b32_e32 v0, v157, v128, vcc_lo                    ; 0201019d
(invalid instruction)                                        ; d58b00a4
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                    ; 02010194
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d76900a2
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
(invalid instruction)                                        ; d76900a5
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v15, v151, s[28:31], null offen             ; c406007c 4080380f 00000097
	buffer_store_b8 v19, v151, s[28:31], null offen offset:16   ; c406007c 40803813 00001097
	buffer_store_b8 v23, v151, s[28:31], null offen offset:32   ; c406007c 40803817 00002097
	buffer_store_b8 v27, v151, s[28:31], null offen offset:48   ; c406007c 4080381b 00003097
	buffer_store_b8 v147, v151, s[28:31], null offen offset:64  ; c406007c 40803893 00004097
	buffer_store_b8 v158, v151, s[28:31], null offen offset:80  ; c406007c 4080389e 00005097
	buffer_store_b8 v162, v151, s[28:31], null offen offset:96  ; c406007c 408038a2 00006097
	buffer_store_b8 v165, v151, s[28:31], null offen offset:112 ; c406007c 408038a5 00007097
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v166, v154, s[28:31], null offen         ; c407807c 408038a6 0000009a
	buffer_load_d16_u8 v167, v154, s[28:31], null offen offset:16 ; c407807c 408038a7 0000109a
	buffer_load_d16_u8 v168, v154, s[28:31], null offen offset:32 ; c407807c 408038a8 0000209a
	buffer_load_d16_u8 v169, v154, s[28:31], null offen offset:48 ; c407807c 408038a9 0000309a
	buffer_load_d16_u8 v170, v154, s[28:31], null offen offset:64 ; c407807c 408038aa 0000409a
	buffer_load_d16_u8 v171, v154, s[28:31], null offen offset:80 ; c407807c 408038ab 0000509a
	buffer_load_d16_u8 v172, v154, s[28:31], null offen offset:96 ; c407807c 408038ac 0000609a
	buffer_load_d16_u8 v173, v154, s[28:31], null offen offset:112 ; c407807c 408038ad 0000709a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v174, v166                                ; 7f5cd9a6
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v178, v167                                ; 7f64d9a7
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v182, v168                                ; 7f6cd9a8
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v186, v169                                ; 7f74d9a9
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v175, v149, v174, v32 op_sel_hi:[1,0,0]     ; cc2100af 0c835d95
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v190, v170                                ; 7f7cd9aa
	v_fma_mixlo_f16 v179, v149, v178, v33 op_sel_hi:[1,0,0]     ; cc2100b3 0c876595
	v_fma_mixlo_f16 v183, v149, v182, v34 op_sel_hi:[1,0,0]     ; cc2100b7 0c8b6d95
	v_fma_mixlo_f16 v187, v149, v186, v35 op_sel_hi:[1,0,0]     ; cc2100bb 0c8f7595
	v_maxmin_num_f16 v175, 0xdf00, v175, neg(0xdf00)            ; d66b00af 83ff5eff 0000df00
	v_fma_mixlo_f16 v191, v149, v190, v36 op_sel_hi:[1,0,0]     ; cc2100bf 0c937d95
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v3, v171                                  ; 7e06d9ab
	v_maxmin_num_f16 v179, 0xdf00, v179, neg(0xdf00)            ; d66b00b3 83ff66ff 0000df00
	v_maxmin_num_f16 v183, 0xdf00, v183, neg(0xdf00)            ; d66b00b7 83ff6eff 0000df00
	v_maxmin_num_f16 v187, 0xdf00, v187, neg(0xdf00)            ; d66b00bb 83ff76ff 0000df00
(invalid instruction)                                        ; d58b00b0
	v_cndmask_b32_e32 v0, v175, v128, vcc_lo                    ; 020101af
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v12, v172                                 ; 7e18d9ac
	v_maxmin_num_f16 v191, 0xdf00, v191, neg(0xdf00)            ; d66b00bf 83ff7eff 0000df00
	v_fma_mixlo_f16 v5, v149, v3, v37 op_sel_hi:[1,0,0]         ; cc210005 0c960795
(invalid instruction)                                        ; d58b00b4
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                    ; 020101b3
(invalid instruction)                                        ; d58b00b8
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                    ; 020101b7
(invalid instruction)                                        ; d58b00bc
	v_cndmask_b32_e32 v0, v187, v128, vcc_lo                    ; 020101bb
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v16, v173                                 ; 7e20d9ad
(invalid instruction)                                        ; d76900b1
	v_cndmask_b32_e32 v0, v176, v128, vcc_lo                    ; 020101b0
	v_fma_mixlo_f16 v13, v149, v12, v38 op_sel_hi:[1,0,0]       ; cc21000d 0c9a1995
(invalid instruction)                                        ; d58b00bf
	v_cndmask_b32_e32 v0, v191, v128, vcc_lo                    ; 020101bf
	v_maxmin_num_f16 v5, 0xdf00, v5, neg(0xdf00)                ; d66b0005 83fe0aff 0000df00
(invalid instruction)                                        ; d76900b5
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                    ; 020101b4
(invalid instruction)                                        ; d76900b9
	v_cndmask_b32_e32 v0, v184, v128, vcc_lo                    ; 020101b8
(invalid instruction)                                        ; d76900bd
	v_cndmask_b32_e32 v0, v188, v128, vcc_lo                    ; 020101bc
	v_fma_mixlo_f16 v149, v149, v16, v39 op_sel_hi:[1,0,0]      ; cc210095 0c9e2195
	v_maxmin_num_f16 v13, 0xdf00, v13, neg(0xdf00)              ; d66b000d 83fe1aff 0000df00
(invalid instruction)                                        ; d76900bf
	v_cndmask_b32_e32 v0, v191, v128, vcc_lo                    ; 020101bf
	v_cvt_f32_f16_e32 v9, v5                                    ; 7e121705
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_maxmin_num_f16 v149, 0xdf00, v149, neg(0xdf00)            ; d66b0095 83ff2aff 0000df00
	v_cvt_f32_f16_e32 v14, v13                                  ; 7e1c170d
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v9, v128, vcc_lo                      ; 02010109
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; d58b0011
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                    ; 02010195
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v177, v153, s[28:31], null offen            ; c406007c 408038b1 00000099
	buffer_store_b8 v181, v153, s[28:31], null offen offset:16  ; c406007c 408038b5 00001099
	buffer_store_b8 v185, v153, s[28:31], null offen offset:32  ; c406007c 408038b9 00002099
	buffer_store_b8 v189, v153, s[28:31], null offen offset:48  ; c406007c 408038bd 00003099
	buffer_store_b8 v191, v153, s[28:31], null offen offset:64  ; c406007c 408038bf 00004099
	buffer_store_b8 v11, v153, s[28:31], null offen offset:80   ; c406007c 4080380b 00005099
	buffer_store_b8 v15, v153, s[28:31], null offen offset:96   ; c406007c 4080380f 00006099
	buffer_store_b8 v18, v153, s[28:31], null offen offset:112  ; c406007c 40803812 00007099
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v19, v156, s[28:31], null offen          ; c407807c 40803813 0000009c
	buffer_load_d16_u8 v20, v156, s[28:31], null offen offset:16 ; c407807c 40803814 0000109c
	buffer_load_d16_u8 v21, v156, s[28:31], null offen offset:32 ; c407807c 40803815 0000209c
	buffer_load_d16_u8 v22, v156, s[28:31], null offen offset:48 ; c407807c 40803816 0000309c
	buffer_load_d16_u8 v23, v156, s[28:31], null offen offset:64 ; c407807c 40803817 0000409c
	buffer_load_d16_u8 v24, v156, s[28:31], null offen offset:80 ; c407807c 40803818 0000509c
	buffer_load_d16_u8 v25, v156, s[28:31], null offen offset:96 ; c407807c 40803819 0000609c
	buffer_load_d16_u8 v26, v156, s[28:31], null offen offset:112 ; c407807c 4080381a 0000709c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v27, v19                                  ; 7e36d913
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v31, v20                                  ; 7e3ed914
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v35, v21                                  ; 7e46d915
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v39, v22                                  ; 7e4ed916
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v28, v150, v27, v40 op_sel_hi:[1,0,0]       ; cc21001c 0ca23796
	v_fma_mixlo_f16 v32, v150, v31, v41 op_sel_hi:[1,0,0]       ; cc210020 0ca63f96
	v_fma_mixlo_f16 v36, v150, v35, v42 op_sel_hi:[1,0,0]       ; cc210024 0caa4796
	v_fma_mixlo_f16 v40, v150, v39, v43 op_sel_hi:[1,0,0]       ; cc210028 0cae4f96
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v43, v23                                  ; 7e56d917
	v_maxmin_num_f16 v28, 0xdf00, v28, neg(0xdf00)              ; d66b001c 83fe38ff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v146, v24                                 ; 7f24d918
	v_maxmin_num_f16 v32, 0xdf00, v32, neg(0xdf00)              ; d66b0020 83fe40ff 0000df00
	v_maxmin_num_f16 v36, 0xdf00, v36, neg(0xdf00)              ; d66b0024 83fe48ff 0000df00
	v_maxmin_num_f16 v40, 0xdf00, v40, neg(0xdf00)              ; d66b0028 83fe50ff 0000df00
	v_fma_mixlo_f16 v44, v150, v43, v44 op_sel_hi:[1,0,0]       ; cc21002c 0cb25796
	v_cvt_f32_f16_e32 v29, v28                                  ; 7e3a171c
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v151, v25                                 ; 7f2ed919
	v_fma_mixlo_f16 v147, v150, v146, v45 op_sel_hi:[1,0,0]     ; cc210093 0cb72596
	v_cvt_f32_f16_e32 v33, v32                                  ; 7e421720
	v_cvt_f32_f16_e32 v37, v36                                  ; 7e4a1724
	v_cvt_f32_f16_e32 v41, v40                                  ; 7e521728
	v_maxmin_num_f16 v44, 0xdf00, v44, neg(0xdf00)              ; d66b002c 83fe58ff 0000df00
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v155, v26                                 ; 7f36d91a
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v0, v29, v128, vcc_lo                     ; 0201011d
	v_fma_mixlo_f16 v152, v150, v151, v46 op_sel_hi:[1,0,0]     ; cc210098 0cbb2f96
	v_maxmin_num_f16 v147, 0xdf00, v147, neg(0xdf00)            ; d66b0093 83ff26ff 0000df00
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v0, v33, v128, vcc_lo                     ; 02010121
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v0, v37, v128, vcc_lo                     ; 02010125
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v0, v41, v128, vcc_lo                     ; 02010129
	v_cvt_f32_f16_e32 v144, v44                                 ; 7f20172c
	v_fma_mixlo_f16 v150, v150, v155, v47 op_sel_hi:[1,0,0]     ; cc210096 0cbf3796
	v_maxmin_num_f16 v152, 0xdf00, v152, neg(0xdf00)            ; d66b0098 83ff30ff 0000df00
(invalid instruction)                                        ; d58b0094
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                    ; 02010193
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; d7690091
	v_cndmask_b32_e32 v0, v144, v128, vcc_lo                    ; 02010190
	v_maxmin_num_f16 v150, 0xdf00, v150, neg(0xdf00)            ; d66b0096 83ff2cff 0000df00
(invalid instruction)                                        ; d58b0099
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                    ; 02010198
(invalid instruction)                                        ; d7690095
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                    ; 02010194
(invalid instruction)                                        ; d58b009c
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                    ; 02010196
(invalid instruction)                                        ; d769009a
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                    ; 02010199
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769009d
	v_cndmask_b32_e32 v0, v156, v128, vcc_lo                    ; 0201019c
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v30, v7, s[28:31], null offen               ; c406007c 4080381e 00000007
	buffer_store_b8 v34, v7, s[28:31], null offen offset:16     ; c406007c 40803822 00001007
	buffer_store_b8 v38, v7, s[28:31], null offen offset:32     ; c406007c 40803826 00002007
	buffer_store_b8 v42, v7, s[28:31], null offen offset:48     ; c406007c 4080382a 00003007
	buffer_store_b8 v145, v7, s[28:31], null offen offset:64    ; c406007c 40803891 00004007
	buffer_store_b8 v149, v7, s[28:31], null offen offset:80    ; c406007c 40803895 00005007
	buffer_store_b8 v154, v7, s[28:31], null offen offset:96    ; c406007c 4080389a 00006007
	buffer_store_b8 v157, v7, s[28:31], null offen offset:112   ; c406007c 4080389d 00007007
BB7:
	s_cmp_lt_u32 s13, s6                                        ; bf0a060d
	s_cbranch_scc0 BB10                                         ; bfa10257
BB8:
	s_mov_b32 s8, s0                                            ; be880000
	s_movk_i32 s9, 0x8000                                       ; b0098000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[8:9], 0x40                          ; f4004604 f8000040
	s_load_b128 s[8:11], s[8:9], 0x10                           ; f4004204 f8000010
	v_add3_u32 v3, v10, s5, v1                                  ; d6550003 04040b0a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v3, 1, v3                                 ; 30060681
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v5, v3, s[24:27], null offen            ; c408007c 40803005 00000003
	v_and_b32_e32 v7, 16, v0                                    ; 360e0090
	s_lshr_b32 s1, s7, 4                                        ; 85018407
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s14, s14, s1                                      ; 960e010e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_lshl_or_b32 v7, v7, 3, v10                                ; d6560007 04290707
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v9, s14, v2, 8                               ; d6470009 0222040e
	v_add3_u32 v11, v7, s2, v9                                  ; d655000b 04240507
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v12, v11, s[8:11], null offen            ; c407807c 4080100c 0000000b
	buffer_load_d16_u8 v13, v11, s[8:11], null offen offset:16  ; c407807c 4080100d 0000100b
	buffer_load_d16_u8 v14, v11, s[8:11], null offen offset:32  ; c407807c 4080100e 0000200b
	buffer_load_d16_u8 v15, v11, s[8:11], null offen offset:48  ; c407807c 4080100f 0000300b
	buffer_load_d16_u8 v16, v11, s[8:11], null offen offset:64  ; c407807c 40801010 0000400b
	buffer_load_d16_u8 v17, v11, s[8:11], null offen offset:80  ; c407807c 40801011 0000500b
	buffer_load_d16_u8 v18, v11, s[8:11], null offen offset:96  ; c407807c 40801012 0000600b
	buffer_load_d16_u8 v19, v11, s[8:11], null offen offset:112 ; c407807c 40801013 0000700b
	s_clause 0x2                                                ; bf850002
	buffer_load_d16_b16 v20, v3, s[24:27], null offen offset:32 ; c408007c 40803014 00002003
	buffer_load_d16_b16 v21, v3, s[24:27], null offen offset:64 ; c408007c 40803015 00004003
	buffer_load_d16_b16 v22, v3, s[24:27], null offen offset:96 ; c408007c 40803016 00006003
	v_add_lshl_u32 v23, s14, v4, 8                              ; d6470017 0222080e
	v_add3_u32 v9, v7, s3, v9                                   ; d6550009 04240707
	v_add_lshl_u32 v25, s14, v6, 8                              ; d6470019 02220c0e
	v_add_lshl_u32 v27, s14, v8, 8                              ; d647001b 0222100e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add3_u32 v24, v7, s2, v23                                 ; d6550018 045c0507
	v_add3_u32 v23, v7, s3, v23                                 ; d6550017 045c0707
	v_add3_u32 v26, v7, s2, v25                                 ; d655001a 04640507
	v_add3_u32 v25, v7, s3, v25                                 ; d6550019 04640707
	v_add3_u32 v28, v7, s2, v27                                 ; d655001c 046c0507
	v_add3_u32 v7, v7, s3, v27                                  ; d6550007 046c0707
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cvt_f32_fp8_e32 v29, v12                                  ; 7e3ad90c
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_cvt_f32_fp8_e32 v33, v13                                  ; 7e42d90d
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cvt_f32_fp8_e32 v37, v14                                  ; 7e4ad90e
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v41, v15                                  ; 7e52d90f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v30, v5, v29, v48 op_sel_hi:[1,0,0]         ; cc21001e 0cc23b05
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v45, v16                                  ; 7e5ad910
	v_fma_mixlo_f16 v34, v5, v33, v49 op_sel_hi:[1,0,0]         ; cc210022 0cc64305
	v_fma_mixlo_f16 v38, v5, v37, v50 op_sel_hi:[1,0,0]         ; cc210026 0cca4b05
	v_fma_mixlo_f16 v42, v5, v41, v51 op_sel_hi:[1,0,0]         ; cc21002a 0cce5305
	v_maxmin_num_f16 v30, 0xdf00, v30, neg(0xdf00)              ; d66b001e 83fe3cff 0000df00
	v_fma_mixlo_f16 v46, v5, v45, v52 op_sel_hi:[1,0,0]         ; cc21002e 0cd25b05
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v49, v17                                  ; 7e62d911
	v_maxmin_num_f16 v34, 0xdf00, v34, neg(0xdf00)              ; d66b0022 83fe44ff 0000df00
	v_maxmin_num_f16 v38, 0xdf00, v38, neg(0xdf00)              ; d66b0026 83fe4cff 0000df00
	v_maxmin_num_f16 v42, 0xdf00, v42, neg(0xdf00)              ; d66b002a 83fe54ff 0000df00
	v_cvt_f32_f16_e32 v31, v30                                  ; 7e3e171e
	v_maxmin_num_f16 v46, 0xdf00, v46, neg(0xdf00)              ; d66b002e 83fe5cff 0000df00
	v_fma_mixlo_f16 v50, v5, v49, v53 op_sel_hi:[1,0,0]         ; cc210032 0cd66305
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v53, v18                                  ; 7e6ad912
	v_cvt_f32_f16_e32 v35, v34                                  ; 7e461722
	v_cvt_f32_f16_e32 v39, v38                                  ; 7e4e1726
	v_cvt_f32_f16_e32 v43, v42                                  ; 7e56172a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v146, v19                                 ; 7f24d913
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v0, v31, v128, vcc_lo                     ; 0201011f
	v_cvt_f32_f16_e32 v47, v46                                  ; 7e5e172e
	v_maxmin_num_f16 v50, 0xdf00, v50, neg(0xdf00)              ; d66b0032 83fe64ff 0000df00
	v_fma_mixlo_f16 v54, v5, v53, v54 op_sel_hi:[1,0,0]         ; cc210036 0cda6b05
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v0, v35, v128, vcc_lo                     ; 02010123
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v0, v39, v128, vcc_lo                     ; 02010127
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v0, v43, v128, vcc_lo                     ; 0201012b
	v_fma_mixlo_f16 v5, v5, v146, v55 op_sel_hi:[1,0,0]         ; cc210005 0cdf2505
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v0, v47, v128, vcc_lo                     ; 0201012f
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
	v_maxmin_num_f16 v54, 0xdf00, v54, neg(0xdf00)              ; d66b0036 83fe6cff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_maxmin_num_f16 v5, 0xdf00, v5, neg(0xdf00)                ; d66b0005 83fe0aff 0000df00
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
	v_cvt_f32_f16_e32 v144, v54                                 ; 7f201736
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_cvt_f32_f16_e32 v147, v5                                  ; 7f261705
(invalid instruction)                                        ; d7690091
	v_cndmask_b32_e32 v0, v144, v128, vcc_lo                    ; 02010190
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690094
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                    ; 02010193
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v32, v9, s[8:11], null offen                ; c406007c 40801020 00000009
	buffer_store_b8 v36, v9, s[8:11], null offen offset:16      ; c406007c 40801024 00001009
	buffer_store_b8 v40, v9, s[8:11], null offen offset:32      ; c406007c 40801028 00002009
	buffer_store_b8 v44, v9, s[8:11], null offen offset:48      ; c406007c 4080102c 00003009
	buffer_store_b8 v48, v9, s[8:11], null offen offset:64      ; c406007c 40801030 00004009
	buffer_store_b8 v52, v9, s[8:11], null offen offset:80      ; c406007c 40801034 00005009
	buffer_store_b8 v145, v9, s[8:11], null offen offset:96     ; c406007c 40801091 00006009
	buffer_store_b8 v148, v9, s[8:11], null offen offset:112    ; c406007c 40801094 00007009
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v149, v24, s[8:11], null offen           ; c407807c 40801095 00000018
	buffer_load_d16_u8 v150, v24, s[8:11], null offen offset:16 ; c407807c 40801096 00001018
	buffer_load_d16_u8 v151, v24, s[8:11], null offen offset:32 ; c407807c 40801097 00002018
	buffer_load_d16_u8 v152, v24, s[8:11], null offen offset:48 ; c407807c 40801098 00003018
	buffer_load_d16_u8 v153, v24, s[8:11], null offen offset:64 ; c407807c 40801099 00004018
	buffer_load_d16_u8 v154, v24, s[8:11], null offen offset:80 ; c407807c 4080109a 00005018
	buffer_load_d16_u8 v155, v24, s[8:11], null offen offset:96 ; c407807c 4080109b 00006018
	buffer_load_d16_u8 v156, v24, s[8:11], null offen offset:112 ; c407807c 4080109c 00007018
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v157, v149                                ; 7f3ad995
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v161, v150                                ; 7f42d996
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v165, v151                                ; 7f4ad997
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v169, v152                                ; 7f52d998
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v158, v20, v157, v56 op_sel_hi:[1,0,0]      ; cc21009e 0ce33b14
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v173, v153                                ; 7f5ad999
	v_fma_mixlo_f16 v162, v20, v161, v57 op_sel_hi:[1,0,0]      ; cc2100a2 0ce74314
	v_fma_mixlo_f16 v166, v20, v165, v58 op_sel_hi:[1,0,0]      ; cc2100a6 0ceb4b14
	v_fma_mixlo_f16 v170, v20, v169, v59 op_sel_hi:[1,0,0]      ; cc2100aa 0cef5314
	v_maxmin_num_f16 v158, 0xdf00, v158, neg(0xdf00)            ; d66b009e 83ff3cff 0000df00
	v_fma_mixlo_f16 v174, v20, v173, v60 op_sel_hi:[1,0,0]      ; cc2100ae 0cf35b14
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v177, v154                                ; 7f62d99a
	v_maxmin_num_f16 v162, 0xdf00, v162, neg(0xdf00)            ; d66b00a2 83ff44ff 0000df00
	v_maxmin_num_f16 v166, 0xdf00, v166, neg(0xdf00)            ; d66b00a6 83ff4cff 0000df00
	v_maxmin_num_f16 v170, 0xdf00, v170, neg(0xdf00)            ; d66b00aa 83ff54ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v181, v155                                ; 7f6ad99b
(invalid instruction)                                        ; d58b009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
	v_maxmin_num_f16 v174, 0xdf00, v174, neg(0xdf00)            ; d66b00ae 83ff5cff 0000df00
	v_fma_mixlo_f16 v178, v20, v177, v61 op_sel_hi:[1,0,0]      ; cc2100b2 0cf76314
(invalid instruction)                                        ; d58b00a3
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
(invalid instruction)                                        ; d58b00a7
	v_cndmask_b32_e32 v0, v166, v128, vcc_lo                    ; 020101a6
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v185, v156                                ; 7f72d99c
(invalid instruction)                                        ; d58b00ab
	v_cndmask_b32_e32 v0, v170, v128, vcc_lo                    ; 020101aa
	v_fma_mixlo_f16 v182, v20, v181, v62 op_sel_hi:[1,0,0]      ; cc2100b6 0cfb6b14
(invalid instruction)                                        ; d76900a0
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                    ; 0201019f
(invalid instruction)                                        ; d58b00af
	v_cndmask_b32_e32 v0, v174, v128, vcc_lo                    ; 020101ae
	v_maxmin_num_f16 v178, 0xdf00, v178, neg(0xdf00)            ; d66b00b2 83ff64ff 0000df00
(invalid instruction)                                        ; d76900a4
	v_cndmask_b32_e32 v0, v163, v128, vcc_lo                    ; 020101a3
(invalid instruction)                                        ; d76900a8
	v_cndmask_b32_e32 v0, v167, v128, vcc_lo                    ; 020101a7
	v_fma_mixlo_f16 v20, v20, v185, v63 op_sel_hi:[1,0,0]       ; cc210014 0cff7314
(invalid instruction)                                        ; d76900ac
	v_cndmask_b32_e32 v0, v171, v128, vcc_lo                    ; 020101ab
	v_maxmin_num_f16 v182, 0xdf00, v182, neg(0xdf00)            ; d66b00b6 83ff6cff 0000df00
(invalid instruction)                                        ; d76900b0
	v_cndmask_b32_e32 v0, v175, v128, vcc_lo                    ; 020101af
(invalid instruction)                                        ; d58b00b3
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                    ; 020101b2
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; d58b00b7
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                    ; 020101b6
(invalid instruction)                                        ; d76900b4
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                    ; 020101b3
	v_cvt_f32_f16_e32 v186, v20                                 ; 7f741714
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d76900b8
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                    ; 020101b7
(invalid instruction)                                        ; d76900bb
	v_cndmask_b32_e32 v0, v186, v128, vcc_lo                    ; 020101ba
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v160, v23, s[8:11], null offen              ; c406007c 408010a0 00000017
	buffer_store_b8 v164, v23, s[8:11], null offen offset:16    ; c406007c 408010a4 00001017
	buffer_store_b8 v168, v23, s[8:11], null offen offset:32    ; c406007c 408010a8 00002017
	buffer_store_b8 v172, v23, s[8:11], null offen offset:48    ; c406007c 408010ac 00003017
	buffer_store_b8 v176, v23, s[8:11], null offen offset:64    ; c406007c 408010b0 00004017
	buffer_store_b8 v180, v23, s[8:11], null offen offset:80    ; c406007c 408010b4 00005017
	buffer_store_b8 v184, v23, s[8:11], null offen offset:96    ; c406007c 408010b8 00006017
	buffer_store_b8 v187, v23, s[8:11], null offen offset:112   ; c406007c 408010bb 00007017
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v188, v26, s[8:11], null offen           ; c407807c 408010bc 0000001a
	buffer_load_d16_u8 v189, v26, s[8:11], null offen offset:16 ; c407807c 408010bd 0000101a
	buffer_load_d16_u8 v190, v26, s[8:11], null offen offset:32 ; c407807c 408010be 0000201a
	buffer_load_d16_u8 v191, v26, s[8:11], null offen offset:48 ; c407807c 408010bf 0000301a
	buffer_load_d16_u8 v3, v26, s[8:11], null offen offset:64   ; c407807c 40801003 0000401a
	buffer_load_d16_u8 v5, v26, s[8:11], null offen offset:80   ; c407807c 40801005 0000501a
	buffer_load_d16_u8 v9, v26, s[8:11], null offen offset:96   ; c407807c 40801009 0000601a
	buffer_load_d16_u8 v11, v26, s[8:11], null offen offset:112 ; c407807c 4080100b 0000701a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v12, v188                                 ; 7e18d9bc
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v16, v189                                 ; 7e20d9bd
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v20, v190                                 ; 7e28d9be
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v27, v191                                 ; 7e36d9bf
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v13, v21, v12, v64 op_sel_hi:[1,0,0]        ; cc21000d 0d021915
	v_fma_mixlo_f16 v17, v21, v16, v65 op_sel_hi:[1,0,0]        ; cc210011 0d062115
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v32, v3                                   ; 7e40d903
	v_fma_mixlo_f16 v23, v21, v20, v66 op_sel_hi:[1,0,0]        ; cc210017 0d0a2915
	v_fma_mixlo_f16 v29, v21, v27, v67 op_sel_hi:[1,0,0]        ; cc21001d 0d0e3715
	v_maxmin_num_f16 v13, 0xdf00, v13, neg(0xdf00)              ; d66b000d 83fe1aff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v36, v5                                   ; 7e48d905
	v_maxmin_num_f16 v17, 0xdf00, v17, neg(0xdf00)              ; d66b0011 83fe22ff 0000df00
	v_fma_mixlo_f16 v33, v21, v32, v68 op_sel_hi:[1,0,0]        ; cc210021 0d124115
	v_maxmin_num_f16 v23, 0xdf00, v23, neg(0xdf00)              ; d66b0017 83fe2eff 0000df00
	v_maxmin_num_f16 v29, 0xdf00, v29, neg(0xdf00)              ; d66b001d 83fe3aff 0000df00
	v_cvt_f32_f16_e32 v14, v13                                  ; 7e1c170d
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v40, v9                                   ; 7e50d909
	v_fma_mixlo_f16 v37, v21, v36, v69 op_sel_hi:[1,0,0]        ; cc210025 0d164915
	v_cvt_f32_f16_e32 v18, v17                                  ; 7e241711
	v_maxmin_num_f16 v33, 0xdf00, v33, neg(0xdf00)              ; d66b0021 83fe42ff 0000df00
	v_cvt_f32_f16_e32 v24, v23                                  ; 7e301717
	v_cvt_f32_f16_e32 v30, v29                                  ; 7e3c171d
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v44, v11                                  ; 7e58d90b
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	v_fma_mixlo_f16 v41, v21, v40, v70 op_sel_hi:[1,0,0]        ; cc210029 0d1a5115
	v_maxmin_num_f16 v37, 0xdf00, v37, neg(0xdf00)              ; d66b0025 83fe4aff 0000df00
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                     ; 02010112
	v_cvt_f32_f16_e32 v34, v33                                  ; 7e441721
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v0, v24, v128, vcc_lo                     ; 02010118
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v0, v30, v128, vcc_lo                     ; 0201011e
	v_fma_mixlo_f16 v21, v21, v44, v71 op_sel_hi:[1,0,0]        ; cc210015 0d1e5915
	v_maxmin_num_f16 v41, 0xdf00, v41, neg(0xdf00)              ; d66b0029 83fe52ff 0000df00
	v_cvt_f32_f16_e32 v38, v37                                  ; 7e4c1725
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v0, v34, v128, vcc_lo                     ; 02010122
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v21, 0xdf00, v21, neg(0xdf00)              ; d66b0015 83fe2aff 0000df00
	v_cvt_f32_f16_e32 v42, v41                                  ; 7e541729
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v0, v38, v128, vcc_lo                     ; 02010126
	v_cvt_f32_f16_e32 v45, v21                                  ; 7e5a1715
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v0, v42, v128, vcc_lo                     ; 0201012a
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v0, v45, v128, vcc_lo                     ; 0201012d
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v15, v25, s[8:11], null offen               ; c406007c 4080100f 00000019
	buffer_store_b8 v19, v25, s[8:11], null offen offset:16     ; c406007c 40801013 00001019
	buffer_store_b8 v26, v25, s[8:11], null offen offset:32     ; c406007c 4080101a 00002019
	buffer_store_b8 v31, v25, s[8:11], null offen offset:48     ; c406007c 4080101f 00003019
	buffer_store_b8 v35, v25, s[8:11], null offen offset:64     ; c406007c 40801023 00004019
	buffer_store_b8 v39, v25, s[8:11], null offen offset:80     ; c406007c 40801027 00005019
	buffer_store_b8 v43, v25, s[8:11], null offen offset:96     ; c406007c 4080102b 00006019
	buffer_store_b8 v46, v25, s[8:11], null offen offset:112    ; c406007c 4080102e 00007019
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v47, v28, s[8:11], null offen            ; c407807c 4080102f 0000001c
	buffer_load_d16_u8 v48, v28, s[8:11], null offen offset:16  ; c407807c 40801030 0000101c
	buffer_load_d16_u8 v49, v28, s[8:11], null offen offset:32  ; c407807c 40801031 0000201c
	buffer_load_d16_u8 v50, v28, s[8:11], null offen offset:48  ; c407807c 40801032 0000301c
	buffer_load_d16_u8 v51, v28, s[8:11], null offen offset:64  ; c407807c 40801033 0000401c
	buffer_load_d16_u8 v52, v28, s[8:11], null offen offset:80  ; c407807c 40801034 0000501c
	buffer_load_d16_u8 v53, v28, s[8:11], null offen offset:96  ; c407807c 40801035 0000601c
	buffer_load_d16_u8 v54, v28, s[8:11], null offen offset:112 ; c407807c 40801036 0000701c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v55, v47                                  ; 7e6ed92f
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v59, v48                                  ; 7e76d930
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v63, v49                                  ; 7e7ed931
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v67, v50                                  ; 7e86d932
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v56, v22, v55, v72 op_sel_hi:[1,0,0]        ; cc210038 0d226f16
	v_fma_mixlo_f16 v60, v22, v59, v73 op_sel_hi:[1,0,0]        ; cc21003c 0d267716
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v71, v51                                  ; 7e8ed933
	v_fma_mixlo_f16 v64, v22, v63, v74 op_sel_hi:[1,0,0]        ; cc210040 0d2a7f16
	v_fma_mixlo_f16 v68, v22, v67, v75 op_sel_hi:[1,0,0]        ; cc210044 0d2e8716
	v_maxmin_num_f16 v56, 0xdf00, v56, neg(0xdf00)              ; d66b0038 83fe70ff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v75, v52                                  ; 7e96d934
	v_maxmin_num_f16 v60, 0xdf00, v60, neg(0xdf00)              ; d66b003c 83fe78ff 0000df00
	v_fma_mixlo_f16 v72, v22, v71, v76 op_sel_hi:[1,0,0]        ; cc210048 0d328f16
	v_maxmin_num_f16 v64, 0xdf00, v64, neg(0xdf00)              ; d66b0040 83fe80ff 0000df00
	v_maxmin_num_f16 v68, 0xdf00, v68, neg(0xdf00)              ; d66b0044 83fe88ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v145, v53                                 ; 7f22d935
	v_cvt_f32_f16_e32 v57, v56                                  ; 7e721738
	v_fma_mixlo_f16 v76, v22, v75, v77 op_sel_hi:[1,0,0]        ; cc21004c 0d369716
	v_cvt_f32_f16_e32 v61, v60                                  ; 7e7a173c
	v_maxmin_num_f16 v72, 0xdf00, v72, neg(0xdf00)              ; d66b0048 83fe90ff 0000df00
	v_cvt_f32_f16_e32 v65, v64                                  ; 7e821740
	v_cvt_f32_f16_e32 v69, v68                                  ; 7e8a1744
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v149, v54                                 ; 7f2ad936
	v_fma_mixlo_f16 v146, v22, v145, v78 op_sel_hi:[1,0,0]      ; cc210092 0d3b2316
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                     ; 02010139
	v_maxmin_num_f16 v76, 0xdf00, v76, neg(0xdf00)              ; d66b004c 83fe98ff 0000df00
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v0, v61, v128, vcc_lo                     ; 0201013d
	v_cvt_f32_f16_e32 v73, v72                                  ; 7e921748
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v0, v65, v128, vcc_lo                     ; 02010141
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v0, v69, v128, vcc_lo                     ; 02010145
	v_fma_mixlo_f16 v22, v22, v149, v79 op_sel_hi:[1,0,0]       ; cc210016 0d3f2b16
	v_maxmin_num_f16 v146, 0xdf00, v146, neg(0xdf00)            ; d66b0092 83ff24ff 0000df00
	v_cvt_f32_f16_e32 v77, v76                                  ; 7e9a174c
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v0, v73, v128, vcc_lo                     ; 02010149
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v22, 0xdf00, v22, neg(0xdf00)              ; d66b0016 83fe2cff 0000df00
(invalid instruction)                                        ; d58b0093
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                    ; 02010192
(invalid instruction)                                        ; d7690090
	v_cndmask_b32_e32 v0, v77, v128, vcc_lo                     ; 0201014d
	v_cvt_f32_f16_e32 v150, v22                                 ; 7f2c1716
(invalid instruction)                                        ; d7690094
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                    ; 02010193
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690097
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                    ; 02010196
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v58, v7, s[8:11], null offen                ; c406007c 4080103a 00000007
	buffer_store_b8 v62, v7, s[8:11], null offen offset:16      ; c406007c 4080103e 00001007
	buffer_store_b8 v66, v7, s[8:11], null offen offset:32      ; c406007c 40801042 00002007
	buffer_store_b8 v70, v7, s[8:11], null offen offset:48      ; c406007c 40801046 00003007
	buffer_store_b8 v74, v7, s[8:11], null offen offset:64      ; c406007c 4080104a 00004007
	buffer_store_b8 v144, v7, s[8:11], null offen offset:80     ; c406007c 40801090 00005007
	buffer_store_b8 v148, v7, s[8:11], null offen offset:96     ; c406007c 40801094 00006007
	buffer_store_b8 v151, v7, s[8:11], null offen offset:112    ; c406007c 40801097 00007007
BB10:
	s_cmp_lt_u32 s16, s6                                        ; bf0a0610
	s_cbranch_scc0 BB13                                         ; bfa10254
BB11:
	s_mov_b32 s8, s0                                            ; be880000
	s_movk_i32 s9, 0x8000                                       ; b0098000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[12:15], s[8:9], 0x40                          ; f4004304 f8000040
	s_load_b128 s[8:11], s[8:9], 0x10                           ; f4004204 f8000010
	v_add3_u32 v3, v10, s5, v1                                  ; d6550003 04040b0a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v3, 1, v3                                 ; 30060681
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v5, v3, s[12:15], null offen            ; c408007c 40801805 00000003
	v_and_b32_e32 v7, 16, v0                                    ; 360e0090
	s_lshr_b32 s1, s7, 4                                        ; 85018407
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s17, s17, s1                                      ; 96110111
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshl_or_b32 v7, v7, 3, v10                                ; d6560007 04290707
	v_add_lshl_u32 v9, s17, v2, 8                               ; d6470009 02220411
	v_add3_u32 v11, v7, s2, v9                                  ; d655000b 04240507
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v12, v11, s[8:11], null offen            ; c407807c 4080100c 0000000b
	buffer_load_d16_u8 v13, v11, s[8:11], null offen offset:16  ; c407807c 4080100d 0000100b
	buffer_load_d16_u8 v14, v11, s[8:11], null offen offset:32  ; c407807c 4080100e 0000200b
	buffer_load_d16_u8 v15, v11, s[8:11], null offen offset:48  ; c407807c 4080100f 0000300b
	buffer_load_d16_u8 v16, v11, s[8:11], null offen offset:64  ; c407807c 40801010 0000400b
	buffer_load_d16_u8 v17, v11, s[8:11], null offen offset:80  ; c407807c 40801011 0000500b
	buffer_load_d16_u8 v18, v11, s[8:11], null offen offset:96  ; c407807c 40801012 0000600b
	buffer_load_d16_u8 v19, v11, s[8:11], null offen offset:112 ; c407807c 40801013 0000700b
	s_clause 0x2                                                ; bf850002
	buffer_load_d16_b16 v20, v3, s[12:15], null offen offset:32 ; c408007c 40801814 00002003
	buffer_load_d16_b16 v21, v3, s[12:15], null offen offset:64 ; c408007c 40801815 00004003
	buffer_load_d16_b16 v22, v3, s[12:15], null offen offset:96 ; c408007c 40801816 00006003
	v_add_lshl_u32 v23, s17, v4, 8                              ; d6470017 02220811
	v_add3_u32 v9, v7, s3, v9                                   ; d6550009 04240707
	v_add_lshl_u32 v25, s17, v6, 8                              ; d6470019 02220c11
	v_add_lshl_u32 v27, s17, v8, 8                              ; d647001b 02221011
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add3_u32 v24, v7, s2, v23                                 ; d6550018 045c0507
	v_add3_u32 v23, v7, s3, v23                                 ; d6550017 045c0707
	v_add3_u32 v26, v7, s2, v25                                 ; d655001a 04640507
	v_add3_u32 v25, v7, s3, v25                                 ; d6550019 04640707
	v_add3_u32 v28, v7, s2, v27                                 ; d655001c 046c0507
	v_add3_u32 v7, v7, s3, v27                                  ; d6550007 046c0707
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cvt_f32_fp8_e32 v29, v12                                  ; 7e3ad90c
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_cvt_f32_fp8_e32 v33, v13                                  ; 7e42d90d
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cvt_f32_fp8_e32 v37, v14                                  ; 7e4ad90e
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v41, v15                                  ; 7e52d90f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v30, v5, v29, v80 op_sel_hi:[1,0,0]         ; cc21001e 0d423b05
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v45, v16                                  ; 7e5ad910
	v_fma_mixlo_f16 v34, v5, v33, v81 op_sel_hi:[1,0,0]         ; cc210022 0d464305
	v_fma_mixlo_f16 v38, v5, v37, v82 op_sel_hi:[1,0,0]         ; cc210026 0d4a4b05
	v_fma_mixlo_f16 v42, v5, v41, v83 op_sel_hi:[1,0,0]         ; cc21002a 0d4e5305
	v_maxmin_num_f16 v30, 0xdf00, v30, neg(0xdf00)              ; d66b001e 83fe3cff 0000df00
	v_fma_mixlo_f16 v46, v5, v45, v84 op_sel_hi:[1,0,0]         ; cc21002e 0d525b05
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v49, v17                                  ; 7e62d911
	v_maxmin_num_f16 v34, 0xdf00, v34, neg(0xdf00)              ; d66b0022 83fe44ff 0000df00
	v_maxmin_num_f16 v38, 0xdf00, v38, neg(0xdf00)              ; d66b0026 83fe4cff 0000df00
	v_maxmin_num_f16 v42, 0xdf00, v42, neg(0xdf00)              ; d66b002a 83fe54ff 0000df00
	v_cvt_f32_f16_e32 v31, v30                                  ; 7e3e171e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v53, v18                                  ; 7e6ad912
	v_maxmin_num_f16 v46, 0xdf00, v46, neg(0xdf00)              ; d66b002e 83fe5cff 0000df00
	v_fma_mixlo_f16 v50, v5, v49, v85 op_sel_hi:[1,0,0]         ; cc210032 0d566305
	v_cvt_f32_f16_e32 v35, v34                                  ; 7e461722
	v_cvt_f32_f16_e32 v39, v38                                  ; 7e4e1726
	v_cvt_f32_f16_e32 v43, v42                                  ; 7e56172a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v57, v19                                  ; 7e72d913
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v0, v31, v128, vcc_lo                     ; 0201011f
	v_fma_mixlo_f16 v54, v5, v53, v86 op_sel_hi:[1,0,0]         ; cc210036 0d5a6b05
	v_cvt_f32_f16_e32 v47, v46                                  ; 7e5e172e
	v_maxmin_num_f16 v50, 0xdf00, v50, neg(0xdf00)              ; d66b0032 83fe64ff 0000df00
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v0, v35, v128, vcc_lo                     ; 02010123
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v0, v39, v128, vcc_lo                     ; 02010127
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v0, v43, v128, vcc_lo                     ; 0201012b
	v_fma_mixlo_f16 v5, v5, v57, v87 op_sel_hi:[1,0,0]          ; cc210005 0d5e7305
	v_maxmin_num_f16 v54, 0xdf00, v54, neg(0xdf00)              ; d66b0036 83fe6cff 0000df00
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v0, v47, v128, vcc_lo                     ; 0201012f
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_maxmin_num_f16 v5, 0xdf00, v5, neg(0xdf00)                ; d66b0005 83fe0aff 0000df00
	v_cvt_f32_f16_e32 v55, v54                                  ; 7e6e1736
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_cvt_f32_f16_e32 v58, v5                                   ; 7e741705
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v0, v55, v128, vcc_lo                     ; 02010137
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v0, v58, v128, vcc_lo                     ; 0201013a
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v32, v9, s[8:11], null offen                ; c406007c 40801020 00000009
	buffer_store_b8 v36, v9, s[8:11], null offen offset:16      ; c406007c 40801024 00001009
	buffer_store_b8 v40, v9, s[8:11], null offen offset:32      ; c406007c 40801028 00002009
	buffer_store_b8 v44, v9, s[8:11], null offen offset:48      ; c406007c 4080102c 00003009
	buffer_store_b8 v48, v9, s[8:11], null offen offset:64      ; c406007c 40801030 00004009
	buffer_store_b8 v52, v9, s[8:11], null offen offset:80      ; c406007c 40801034 00005009
	buffer_store_b8 v56, v9, s[8:11], null offen offset:96      ; c406007c 40801038 00006009
	buffer_store_b8 v59, v9, s[8:11], null offen offset:112     ; c406007c 4080103b 00007009
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v60, v24, s[8:11], null offen            ; c407807c 4080103c 00000018
	buffer_load_d16_u8 v61, v24, s[8:11], null offen offset:16  ; c407807c 4080103d 00001018
	buffer_load_d16_u8 v62, v24, s[8:11], null offen offset:32  ; c407807c 4080103e 00002018
	buffer_load_d16_u8 v63, v24, s[8:11], null offen offset:48  ; c407807c 4080103f 00003018
	buffer_load_d16_u8 v64, v24, s[8:11], null offen offset:64  ; c407807c 40801040 00004018
	buffer_load_d16_u8 v65, v24, s[8:11], null offen offset:80  ; c407807c 40801041 00005018
	buffer_load_d16_u8 v66, v24, s[8:11], null offen offset:96  ; c407807c 40801042 00006018
	buffer_load_d16_u8 v67, v24, s[8:11], null offen offset:112 ; c407807c 40801043 00007018
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v68, v60                                  ; 7e88d93c
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v72, v61                                  ; 7e90d93d
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v76, v62                                  ; 7e98d93e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v80, v63                                  ; 7ea0d93f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v69, v20, v68, v88 op_sel_hi:[1,0,0]        ; cc210045 0d628914
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v84, v64                                  ; 7ea8d940
	v_fma_mixlo_f16 v73, v20, v72, v89 op_sel_hi:[1,0,0]        ; cc210049 0d669114
	v_fma_mixlo_f16 v77, v20, v76, v90 op_sel_hi:[1,0,0]        ; cc21004d 0d6a9914
	v_fma_mixlo_f16 v81, v20, v80, v91 op_sel_hi:[1,0,0]        ; cc210051 0d6ea114
	v_maxmin_num_f16 v69, 0xdf00, v69, neg(0xdf00)              ; d66b0045 83fe8aff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v88, v65                                  ; 7eb0d941
	v_fma_mixlo_f16 v85, v20, v84, v92 op_sel_hi:[1,0,0]        ; cc210055 0d72a914
	v_maxmin_num_f16 v73, 0xdf00, v73, neg(0xdf00)              ; d66b0049 83fe92ff 0000df00
	v_maxmin_num_f16 v77, 0xdf00, v77, neg(0xdf00)              ; d66b004d 83fe9aff 0000df00
	v_maxmin_num_f16 v81, 0xdf00, v81, neg(0xdf00)              ; d66b0051 83fea2ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v92, v66                                  ; 7eb8d942
	v_cvt_f32_f16_e32 v70, v69                                  ; 7e8c1745
	v_fma_mixlo_f16 v89, v20, v88, v93 op_sel_hi:[1,0,0]        ; cc210059 0d76b114
	v_maxmin_num_f16 v85, 0xdf00, v85, neg(0xdf00)              ; d66b0055 83feaaff 0000df00
	v_cvt_f32_f16_e32 v74, v73                                  ; 7e941749
	v_cvt_f32_f16_e32 v78, v77                                  ; 7e9c174d
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v145, v67                                 ; 7f22d943
	v_cvt_f32_f16_e32 v82, v81                                  ; 7ea41751
	v_fma_mixlo_f16 v93, v20, v92, v94 op_sel_hi:[1,0,0]        ; cc21005d 0d7ab914
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v0, v70, v128, vcc_lo                     ; 02010146
	v_maxmin_num_f16 v89, 0xdf00, v89, neg(0xdf00)              ; d66b0059 83feb2ff 0000df00
	v_cvt_f32_f16_e32 v86, v85                                  ; 7eac1755
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v0, v74, v128, vcc_lo                     ; 0201014a
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v0, v78, v128, vcc_lo                     ; 0201014e
	v_fma_mixlo_f16 v20, v20, v145, v95 op_sel_hi:[1,0,0]       ; cc210014 0d7f2314
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v0, v82, v128, vcc_lo                     ; 02010152
	v_maxmin_num_f16 v93, 0xdf00, v93, neg(0xdf00)              ; d66b005d 83febaff 0000df00
	v_cvt_f32_f16_e32 v90, v89                                  ; 7eb41759
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v0, v86, v128, vcc_lo                     ; 02010156
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_cvt_f32_f16_e32 v94, v93                                  ; 7ebc175d
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v0, v90, v128, vcc_lo                     ; 0201015a
	v_cvt_f32_f16_e32 v146, v20                                 ; 7f241714
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d7690090
	v_cndmask_b32_e32 v0, v94, v128, vcc_lo                     ; 0201015e
(invalid instruction)                                        ; d7690093
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                    ; 02010192
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v71, v23, s[8:11], null offen               ; c406007c 40801047 00000017
	buffer_store_b8 v75, v23, s[8:11], null offen offset:16     ; c406007c 4080104b 00001017
	buffer_store_b8 v79, v23, s[8:11], null offen offset:32     ; c406007c 4080104f 00002017
	buffer_store_b8 v83, v23, s[8:11], null offen offset:48     ; c406007c 40801053 00003017
	buffer_store_b8 v87, v23, s[8:11], null offen offset:64     ; c406007c 40801057 00004017
	buffer_store_b8 v91, v23, s[8:11], null offen offset:80     ; c406007c 4080105b 00005017
	buffer_store_b8 v144, v23, s[8:11], null offen offset:96    ; c406007c 40801090 00006017
	buffer_store_b8 v147, v23, s[8:11], null offen offset:112   ; c406007c 40801093 00007017
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v148, v26, s[8:11], null offen           ; c407807c 40801094 0000001a
	buffer_load_d16_u8 v149, v26, s[8:11], null offen offset:16 ; c407807c 40801095 0000101a
	buffer_load_d16_u8 v150, v26, s[8:11], null offen offset:32 ; c407807c 40801096 0000201a
	buffer_load_d16_u8 v151, v26, s[8:11], null offen offset:48 ; c407807c 40801097 0000301a
	buffer_load_d16_u8 v152, v26, s[8:11], null offen offset:64 ; c407807c 40801098 0000401a
	buffer_load_d16_u8 v153, v26, s[8:11], null offen offset:80 ; c407807c 40801099 0000501a
	buffer_load_d16_u8 v154, v26, s[8:11], null offen offset:96 ; c407807c 4080109a 0000601a
	buffer_load_d16_u8 v155, v26, s[8:11], null offen offset:112 ; c407807c 4080109b 0000701a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v156, v148                                ; 7f38d994
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v160, v149                                ; 7f40d995
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v164, v150                                ; 7f48d996
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v168, v151                                ; 7f50d997
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v157, v21, v156, v96 op_sel_hi:[1,0,0]      ; cc21009d 0d833915
	v_fma_mixlo_f16 v161, v21, v160, v97 op_sel_hi:[1,0,0]      ; cc2100a1 0d874115
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v172, v152                                ; 7f58d998
	v_fma_mixlo_f16 v165, v21, v164, v98 op_sel_hi:[1,0,0]      ; cc2100a5 0d8b4915
	v_fma_mixlo_f16 v169, v21, v168, v99 op_sel_hi:[1,0,0]      ; cc2100a9 0d8f5115
	v_maxmin_num_f16 v157, 0xdf00, v157, neg(0xdf00)            ; d66b009d 83ff3aff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v176, v153                                ; 7f60d999
	v_maxmin_num_f16 v161, 0xdf00, v161, neg(0xdf00)            ; d66b00a1 83ff42ff 0000df00
	v_fma_mixlo_f16 v173, v21, v172, v100 op_sel_hi:[1,0,0]     ; cc2100ad 0d935915
	v_maxmin_num_f16 v165, 0xdf00, v165, neg(0xdf00)            ; d66b00a5 83ff4aff 0000df00
	v_maxmin_num_f16 v169, 0xdf00, v169, neg(0xdf00)            ; d66b00a9 83ff52ff 0000df00
(invalid instruction)                                        ; d58b009e
	v_cndmask_b32_e32 v0, v157, v128, vcc_lo                    ; 0201019d
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v180, v154                                ; 7f68d99a
	v_fma_mixlo_f16 v177, v21, v176, v101 op_sel_hi:[1,0,0]     ; cc2100b1 0d976115
(invalid instruction)                                        ; d58b00a2
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
	v_maxmin_num_f16 v173, 0xdf00, v173, neg(0xdf00)            ; d66b00ad 83ff5aff 0000df00
(invalid instruction)                                        ; d58b00a6
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
(invalid instruction)                                        ; d58b00aa
	v_cndmask_b32_e32 v0, v169, v128, vcc_lo                    ; 020101a9
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v184, v155                                ; 7f70d99b
(invalid instruction)                                        ; d769009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
	v_fma_mixlo_f16 v181, v21, v180, v102 op_sel_hi:[1,0,0]     ; cc2100b5 0d9b6915
	v_maxmin_num_f16 v177, 0xdf00, v177, neg(0xdf00)            ; d66b00b1 83ff62ff 0000df00
(invalid instruction)                                        ; d76900a3
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v173, v128, vcc_lo                    ; 020101ad
(invalid instruction)                                        ; d76900a7
	v_cndmask_b32_e32 v0, v166, v128, vcc_lo                    ; 020101a6
(invalid instruction)                                        ; d76900ab
	v_cndmask_b32_e32 v0, v170, v128, vcc_lo                    ; 020101aa
	v_fma_mixlo_f16 v21, v21, v184, v103 op_sel_hi:[1,0,0]      ; cc210015 0d9f7115
	v_maxmin_num_f16 v181, 0xdf00, v181, neg(0xdf00)            ; d66b00b5 83ff6aff 0000df00
(invalid instruction)                                        ; d58b00b2
	v_cndmask_b32_e32 v0, v177, v128, vcc_lo                    ; 020101b1
(invalid instruction)                                        ; d76900af
	v_cndmask_b32_e32 v0, v174, v128, vcc_lo                    ; 020101ae
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v21, 0xdf00, v21, neg(0xdf00)              ; d66b0015 83fe2aff 0000df00
(invalid instruction)                                        ; d58b00b6
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                    ; 020101b5
(invalid instruction)                                        ; d76900b3
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                    ; 020101b2
	v_cvt_f32_f16_e32 v185, v21                                 ; 7f721715
(invalid instruction)                                        ; d76900b7
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                    ; 020101b6
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900ba
	v_cndmask_b32_e32 v0, v185, v128, vcc_lo                    ; 020101b9
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v159, v25, s[8:11], null offen              ; c406007c 4080109f 00000019
	buffer_store_b8 v163, v25, s[8:11], null offen offset:16    ; c406007c 408010a3 00001019
	buffer_store_b8 v167, v25, s[8:11], null offen offset:32    ; c406007c 408010a7 00002019
	buffer_store_b8 v171, v25, s[8:11], null offen offset:48    ; c406007c 408010ab 00003019
	buffer_store_b8 v175, v25, s[8:11], null offen offset:64    ; c406007c 408010af 00004019
	buffer_store_b8 v179, v25, s[8:11], null offen offset:80    ; c406007c 408010b3 00005019
	buffer_store_b8 v183, v25, s[8:11], null offen offset:96    ; c406007c 408010b7 00006019
	buffer_store_b8 v186, v25, s[8:11], null offen offset:112   ; c406007c 408010ba 00007019
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v187, v28, s[8:11], null offen           ; c407807c 408010bb 0000001c
	buffer_load_d16_u8 v188, v28, s[8:11], null offen offset:16 ; c407807c 408010bc 0000101c
	buffer_load_d16_u8 v189, v28, s[8:11], null offen offset:32 ; c407807c 408010bd 0000201c
	buffer_load_d16_u8 v190, v28, s[8:11], null offen offset:48 ; c407807c 408010be 0000301c
	buffer_load_d16_u8 v191, v28, s[8:11], null offen offset:64 ; c407807c 408010bf 0000401c
	buffer_load_d16_u8 v3, v28, s[8:11], null offen offset:80   ; c407807c 40801003 0000501c
	buffer_load_d16_u8 v5, v28, s[8:11], null offen offset:96   ; c407807c 40801005 0000601c
	buffer_load_d16_u8 v9, v28, s[8:11], null offen offset:112  ; c407807c 40801009 0000701c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v11, v187                                 ; 7e16d9bb
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v15, v188                                 ; 7e1ed9bc
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v19, v189                                 ; 7e26d9bd
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v24, v190                                 ; 7e30d9be
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v12, v22, v11, v104 op_sel_hi:[1,0,0]       ; cc21000c 0da21716
	v_fma_mixlo_f16 v16, v22, v15, v105 op_sel_hi:[1,0,0]       ; cc210010 0da61f16
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v28, v191                                 ; 7e38d9bf
	v_fma_mixlo_f16 v20, v22, v19, v106 op_sel_hi:[1,0,0]       ; cc210014 0daa2716
	v_fma_mixlo_f16 v25, v22, v24, v107 op_sel_hi:[1,0,0]       ; cc210019 0dae3116
	v_maxmin_num_f16 v12, 0xdf00, v12, neg(0xdf00)              ; d66b000c 83fe18ff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v32, v3                                   ; 7e40d903
	v_maxmin_num_f16 v16, 0xdf00, v16, neg(0xdf00)              ; d66b0010 83fe20ff 0000df00
	v_fma_mixlo_f16 v29, v22, v28, v108 op_sel_hi:[1,0,0]       ; cc21001d 0db23916
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
	v_maxmin_num_f16 v25, 0xdf00, v25, neg(0xdf00)              ; d66b0019 83fe32ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v36, v5                                   ; 7e48d905
	v_cvt_f32_f16_e32 v13, v12                                  ; 7e1a170c
	v_fma_mixlo_f16 v33, v22, v32, v109 op_sel_hi:[1,0,0]       ; cc210021 0db64116
	v_cvt_f32_f16_e32 v17, v16                                  ; 7e221710
	v_maxmin_num_f16 v29, 0xdf00, v29, neg(0xdf00)              ; d66b001d 83fe3aff 0000df00
	v_cvt_f32_f16_e32 v21, v20                                  ; 7e2a1714
	v_cvt_f32_f16_e32 v26, v25                                  ; 7e341719
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v40, v9                                   ; 7e50d909
	v_fma_mixlo_f16 v37, v22, v36, v110 op_sel_hi:[1,0,0]       ; cc210025 0dba4916
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                     ; 0201010d
	v_maxmin_num_f16 v33, 0xdf00, v33, neg(0xdf00)              ; d66b0021 83fe42ff 0000df00
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
	v_cvt_f32_f16_e32 v30, v29                                  ; 7e3c171d
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
	v_fma_mixlo_f16 v22, v22, v40, v111 op_sel_hi:[1,0,0]       ; cc210016 0dbe5116
	v_maxmin_num_f16 v37, 0xdf00, v37, neg(0xdf00)              ; d66b0025 83fe4aff 0000df00
	v_cvt_f32_f16_e32 v34, v33                                  ; 7e441721
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v0, v30, v128, vcc_lo                     ; 0201011e
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v22, 0xdf00, v22, neg(0xdf00)              ; d66b0016 83fe2cff 0000df00
	v_cvt_f32_f16_e32 v38, v37                                  ; 7e4c1725
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v0, v34, v128, vcc_lo                     ; 02010122
	v_cvt_f32_f16_e32 v41, v22                                  ; 7e521716
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v0, v38, v128, vcc_lo                     ; 02010126
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v0, v41, v128, vcc_lo                     ; 02010129
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v14, v7, s[8:11], null offen                ; c406007c 4080100e 00000007
	buffer_store_b8 v18, v7, s[8:11], null offen offset:16      ; c406007c 40801012 00001007
	buffer_store_b8 v23, v7, s[8:11], null offen offset:32      ; c406007c 40801017 00002007
	buffer_store_b8 v27, v7, s[8:11], null offen offset:48      ; c406007c 4080101b 00003007
	buffer_store_b8 v31, v7, s[8:11], null offen offset:64      ; c406007c 4080101f 00004007
	buffer_store_b8 v35, v7, s[8:11], null offen offset:80      ; c406007c 40801023 00005007
	buffer_store_b8 v39, v7, s[8:11], null offen offset:96      ; c406007c 40801027 00006007
	buffer_store_b8 v42, v7, s[8:11], null offen offset:112     ; c406007c 4080102a 00007007
BB13:
	s_cmp_lt_u32 s19, s6                                        ; bf0a0613
	s_cbranch_scc0 BB16                                         ; bfa10253
BB14:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[8:11], s[0:1], 0x40                           ; f4004200 f8000040
	s_load_b128 s[12:15], s[0:1], 0x10                          ; f4004300 f8000010
	v_and_b32_e32 v0, 16, v0                                    ; 36000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshl_or_b32 v0, v0, 3, v10                                ; d6560000 04290700
	v_add3_u32 v10, v10, s5, v1                                 ; d655000a 04040b0a
	v_lshlrev_b32_e32 v10, 1, v10                               ; 30141481
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v1, v10, s[8:11], null offen            ; c408007c 40801001 0000000a
	s_lshr_b32 s7, s7, 4                                        ; 85078407
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b9
	s_mul_i32 s20, s20, s7                                      ; 96140714
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v2, s20, v2, 8                               ; d6470002 02220414
	v_add3_u32 v3, v0, s2, v2                                   ; d6550003 04080500
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v5, v3, s[12:15], null offen             ; c407807c 40801805 00000003
	buffer_load_d16_u8 v7, v3, s[12:15], null offen offset:16   ; c407807c 40801807 00001003
	buffer_load_d16_u8 v9, v3, s[12:15], null offen offset:32   ; c407807c 40801809 00002003
	buffer_load_d16_u8 v11, v3, s[12:15], null offen offset:48  ; c407807c 4080180b 00003003
	buffer_load_d16_u8 v12, v3, s[12:15], null offen offset:64  ; c407807c 4080180c 00004003
	buffer_load_d16_u8 v13, v3, s[12:15], null offen offset:80  ; c407807c 4080180d 00005003
	buffer_load_d16_u8 v14, v3, s[12:15], null offen offset:96  ; c407807c 4080180e 00006003
	buffer_load_d16_u8 v15, v3, s[12:15], null offen offset:112 ; c407807c 4080180f 00007003
	s_clause 0x2                                                ; bf850002
	buffer_load_d16_b16 v16, v10, s[8:11], null offen offset:32 ; c408007c 40801010 0000200a
	buffer_load_d16_b16 v17, v10, s[8:11], null offen offset:64 ; c408007c 40801011 0000400a
	buffer_load_d16_b16 v18, v10, s[8:11], null offen offset:96 ; c408007c 40801012 0000600a
	v_add_lshl_u32 v4, s20, v4, 8                               ; d6470004 02220814
	v_add3_u32 v2, v0, s3, v2                                   ; d6550002 04080700
	v_add_lshl_u32 v6, s20, v6, 8                               ; d6470006 02220c14
	v_add_lshl_u32 v8, s20, v8, 8                               ; d6470008 02221014
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add3_u32 v19, v0, s2, v4                                  ; d6550013 04100500
	v_add3_u32 v4, v0, s3, v4                                   ; d6550004 04100700
	v_add3_u32 v20, v0, s2, v6                                  ; d6550014 04180500
	v_add3_u32 v6, v0, s3, v6                                   ; d6550006 04180700
	v_add3_u32 v21, v0, s2, v8                                  ; d6550015 04200500
	v_add3_u32 v0, v0, s3, v8                                   ; d6550000 04200700
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cvt_f32_fp8_e32 v22, v5                                   ; 7e2cd905
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_cvt_f32_fp8_e32 v26, v7                                   ; 7e34d907
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cvt_f32_fp8_e32 v30, v9                                   ; 7e3cd909
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v34, v11                                  ; 7e44d90b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v23, v1, v22, v112 op_sel_hi:[1,0,0]        ; cc210017 0dc22d01
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v38, v12                                  ; 7e4cd90c
	v_fma_mixlo_f16 v27, v1, v26, v113 op_sel_hi:[1,0,0]        ; cc21001b 0dc63501
	v_fma_mixlo_f16 v31, v1, v30, v114 op_sel_hi:[1,0,0]        ; cc21001f 0dca3d01
	v_fma_mixlo_f16 v35, v1, v34, v115 op_sel_hi:[1,0,0]        ; cc210023 0dce4501
	v_maxmin_num_f16 v23, 0xdf00, v23, neg(0xdf00)              ; d66b0017 83fe2eff 0000df00
	v_fma_mixlo_f16 v39, v1, v38, v116 op_sel_hi:[1,0,0]        ; cc210027 0dd24d01
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v42, v13                                  ; 7e54d90d
	v_maxmin_num_f16 v27, 0xdf00, v27, neg(0xdf00)              ; d66b001b 83fe36ff 0000df00
	v_maxmin_num_f16 v31, 0xdf00, v31, neg(0xdf00)              ; d66b001f 83fe3eff 0000df00
	v_maxmin_num_f16 v35, 0xdf00, v35, neg(0xdf00)              ; d66b0023 83fe46ff 0000df00
	v_cvt_f32_f16_e32 v24, v23                                  ; 7e301717
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v46, v14                                  ; 7e5cd90e
	v_maxmin_num_f16 v39, 0xdf00, v39, neg(0xdf00)              ; d66b0027 83fe4eff 0000df00
	v_fma_mixlo_f16 v43, v1, v42, v117 op_sel_hi:[1,0,0]        ; cc21002b 0dd65501
	v_cvt_f32_f16_e32 v28, v27                                  ; 7e38171b
	v_cvt_f32_f16_e32 v32, v31                                  ; 7e40171f
	v_cvt_f32_f16_e32 v36, v35                                  ; 7e481723
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v50, v15                                  ; 7e64d90f
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v0, v24, v128, vcc_lo                     ; 02010118
	v_fma_mixlo_f16 v47, v1, v46, v118 op_sel_hi:[1,0,0]        ; cc21002f 0dda5d01
	v_cvt_f32_f16_e32 v40, v39                                  ; 7e501727
	v_maxmin_num_f16 v43, 0xdf00, v43, neg(0xdf00)              ; d66b002b 83fe56ff 0000df00
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v0, v28, v128, vcc_lo                     ; 0201011c
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v0, v32, v128, vcc_lo                     ; 02010120
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
	v_fma_mixlo_f16 v1, v1, v50, v119 op_sel_hi:[1,0,0]         ; cc210001 0dde6501
	v_maxmin_num_f16 v47, 0xdf00, v47, neg(0xdf00)              ; d66b002f 83fe5eff 0000df00
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v0, v40, v128, vcc_lo                     ; 02010128
	v_cvt_f32_f16_e32 v44, v43                                  ; 7e58172b
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_maxmin_num_f16 v1, 0xdf00, v1, neg(0xdf00)                ; d66b0001 83fe02ff 0000df00
	v_cvt_f32_f16_e32 v48, v47                                  ; 7e60172f
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v0, v44, v128, vcc_lo                     ; 0201012c
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_cvt_f32_f16_e32 v51, v1                                   ; 7e661701
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v25, v2, s[12:15], null offen               ; c406007c 40801819 00000002
	buffer_store_b8 v29, v2, s[12:15], null offen offset:16     ; c406007c 4080181d 00001002
	buffer_store_b8 v33, v2, s[12:15], null offen offset:32     ; c406007c 40801821 00002002
	buffer_store_b8 v37, v2, s[12:15], null offen offset:48     ; c406007c 40801825 00003002
	buffer_store_b8 v41, v2, s[12:15], null offen offset:64     ; c406007c 40801829 00004002
	buffer_store_b8 v45, v2, s[12:15], null offen offset:80     ; c406007c 4080182d 00005002
	buffer_store_b8 v49, v2, s[12:15], null offen offset:96     ; c406007c 40801831 00006002
	buffer_store_b8 v52, v2, s[12:15], null offen offset:112    ; c406007c 40801834 00007002
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v53, v19, s[12:15], null offen           ; c407807c 40801835 00000013
	buffer_load_d16_u8 v54, v19, s[12:15], null offen offset:16 ; c407807c 40801836 00001013
	buffer_load_d16_u8 v55, v19, s[12:15], null offen offset:32 ; c407807c 40801837 00002013
	buffer_load_d16_u8 v56, v19, s[12:15], null offen offset:48 ; c407807c 40801838 00003013
	buffer_load_d16_u8 v57, v19, s[12:15], null offen offset:64 ; c407807c 40801839 00004013
	buffer_load_d16_u8 v58, v19, s[12:15], null offen offset:80 ; c407807c 4080183a 00005013
	buffer_load_d16_u8 v59, v19, s[12:15], null offen offset:96 ; c407807c 4080183b 00006013
	buffer_load_d16_u8 v60, v19, s[12:15], null offen offset:112 ; c407807c 4080183c 00007013
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v61, v53                                  ; 7e7ad935
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v65, v54                                  ; 7e82d936
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v69, v55                                  ; 7e8ad937
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v73, v56                                  ; 7e92d938
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v62, v16, v61, v120 op_sel_hi:[1,0,0]       ; cc21003e 0de27b10
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v77, v57                                  ; 7e9ad939
	v_fma_mixlo_f16 v66, v16, v65, v121 op_sel_hi:[1,0,0]       ; cc210042 0de68310
	v_fma_mixlo_f16 v70, v16, v69, v122 op_sel_hi:[1,0,0]       ; cc210046 0dea8b10
	v_fma_mixlo_f16 v74, v16, v73, v123 op_sel_hi:[1,0,0]       ; cc21004a 0dee9310
	v_maxmin_num_f16 v62, 0xdf00, v62, neg(0xdf00)              ; d66b003e 83fe7cff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v81, v58                                  ; 7ea2d93a
	v_fma_mixlo_f16 v78, v16, v77, v124 op_sel_hi:[1,0,0]       ; cc21004e 0df29b10
	v_maxmin_num_f16 v66, 0xdf00, v66, neg(0xdf00)              ; d66b0042 83fe84ff 0000df00
	v_maxmin_num_f16 v70, 0xdf00, v70, neg(0xdf00)              ; d66b0046 83fe8cff 0000df00
	v_maxmin_num_f16 v74, 0xdf00, v74, neg(0xdf00)              ; d66b004a 83fe94ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v85, v59                                  ; 7eaad93b
	v_cvt_f32_f16_e32 v63, v62                                  ; 7e7e173e
	v_fma_mixlo_f16 v82, v16, v81, v125 op_sel_hi:[1,0,0]       ; cc210052 0df6a310
	v_maxmin_num_f16 v78, 0xdf00, v78, neg(0xdf00)              ; d66b004e 83fe9cff 0000df00
	v_cvt_f32_f16_e32 v67, v66                                  ; 7e861742
	v_cvt_f32_f16_e32 v71, v70                                  ; 7e8e1746
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v89, v60                                  ; 7eb2d93c
	v_cvt_f32_f16_e32 v75, v74                                  ; 7e96174a
	v_fma_mixlo_f16 v86, v16, v85, v126 op_sel_hi:[1,0,0]       ; cc210056 0dfaab10
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v0, v63, v128, vcc_lo                     ; 0201013f
	v_maxmin_num_f16 v82, 0xdf00, v82, neg(0xdf00)              ; d66b0052 83fea4ff 0000df00
	v_cvt_f32_f16_e32 v79, v78                                  ; 7e9e174e
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v0, v67, v128, vcc_lo                     ; 02010143
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v0, v71, v128, vcc_lo                     ; 02010147
	v_fma_mixlo_f16 v16, v16, v89, v127 op_sel_hi:[1,0,0]       ; cc210010 0dfeb310
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v0, v75, v128, vcc_lo                     ; 0201014b
	v_maxmin_num_f16 v86, 0xdf00, v86, neg(0xdf00)              ; d66b0056 83feacff 0000df00
	v_cvt_f32_f16_e32 v83, v82                                  ; 7ea61752
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v0, v79, v128, vcc_lo                     ; 0201014f
	v_maxmin_num_f16 v16, 0xdf00, v16, neg(0xdf00)              ; d66b0010 83fe20ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_cvt_f32_f16_e32 v87, v86                                  ; 7eae1756
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v0, v83, v128, vcc_lo                     ; 02010153
	v_cvt_f32_f16_e32 v90, v16                                  ; 7eb41710
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v0, v87, v128, vcc_lo                     ; 02010157
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v0, v90, v128, vcc_lo                     ; 0201015a
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v64, v4, s[12:15], null offen               ; c406007c 40801840 00000004
	buffer_store_b8 v68, v4, s[12:15], null offen offset:16     ; c406007c 40801844 00001004
	buffer_store_b8 v72, v4, s[12:15], null offen offset:32     ; c406007c 40801848 00002004
	buffer_store_b8 v76, v4, s[12:15], null offen offset:48     ; c406007c 4080184c 00003004
	buffer_store_b8 v80, v4, s[12:15], null offen offset:64     ; c406007c 40801850 00004004
	buffer_store_b8 v84, v4, s[12:15], null offen offset:80     ; c406007c 40801854 00005004
	buffer_store_b8 v88, v4, s[12:15], null offen offset:96     ; c406007c 40801858 00006004
	buffer_store_b8 v91, v4, s[12:15], null offen offset:112    ; c406007c 4080185b 00007004
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v92, v20, s[12:15], null offen           ; c407807c 4080185c 00000014
	buffer_load_d16_u8 v93, v20, s[12:15], null offen offset:16 ; c407807c 4080185d 00001014
	buffer_load_d16_u8 v94, v20, s[12:15], null offen offset:32 ; c407807c 4080185e 00002014
	buffer_load_d16_u8 v95, v20, s[12:15], null offen offset:48 ; c407807c 4080185f 00003014
	buffer_load_d16_u8 v96, v20, s[12:15], null offen offset:64 ; c407807c 40801860 00004014
	buffer_load_d16_u8 v97, v20, s[12:15], null offen offset:80 ; c407807c 40801861 00005014
	buffer_load_d16_u8 v98, v20, s[12:15], null offen offset:96 ; c407807c 40801862 00006014
	buffer_load_d16_u8 v99, v20, s[12:15], null offen offset:112 ; c407807c 40801863 00007014
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v100, v92                                 ; 7ec8d95c
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v104, v93                                 ; 7ed0d95d
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v108, v94                                 ; 7ed8d95e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v112, v95                                 ; 7ee0d95f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v101, v17, v100, v128 op_sel_hi:[1,0,0]     ; cc210065 0e02c911
	v_fma_mixlo_f16 v105, v17, v104, v129 op_sel_hi:[1,0,0]     ; cc210069 0e06d111
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v116, v96                                 ; 7ee8d960
	v_fma_mixlo_f16 v109, v17, v108, v130 op_sel_hi:[1,0,0]     ; cc21006d 0e0ad911
	v_fma_mixlo_f16 v113, v17, v112, v131 op_sel_hi:[1,0,0]     ; cc210071 0e0ee111
	v_maxmin_num_f16 v101, 0xdf00, v101, neg(0xdf00)            ; d66b0065 83fecaff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v120, v97                                 ; 7ef0d961
	v_maxmin_num_f16 v105, 0xdf00, v105, neg(0xdf00)            ; d66b0069 83fed2ff 0000df00
	v_fma_mixlo_f16 v117, v17, v116, v132 op_sel_hi:[1,0,0]     ; cc210075 0e12e911
	v_maxmin_num_f16 v109, 0xdf00, v109, neg(0xdf00)            ; d66b006d 83fedaff 0000df00
	v_maxmin_num_f16 v113, 0xdf00, v113, neg(0xdf00)            ; d66b0071 83fee2ff 0000df00
	v_cvt_f32_f16_e32 v102, v101                                ; 7ecc1765
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v124, v98                                 ; 7ef8d962
	v_fma_mixlo_f16 v121, v17, v120, v133 op_sel_hi:[1,0,0]     ; cc210079 0e16f111
	v_cvt_f32_f16_e32 v106, v105                                ; 7ed41769
	v_maxmin_num_f16 v117, 0xdf00, v117, neg(0xdf00)            ; d66b0075 83feeaff 0000df00
	v_cvt_f32_f16_e32 v110, v109                                ; 7edc176d
	v_cvt_f32_f16_e32 v114, v113                                ; 7ee41771
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v128, v99                                 ; 7f00d963
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v0, v102, v128, vcc_lo                    ; 02010166
	v_fma_mixlo_f16 v125, v17, v124, v134 op_sel_hi:[1,0,0]     ; cc21007d 0e1af911
	v_maxmin_num_f16 v121, 0xdf00, v121, neg(0xdf00)            ; d66b0079 83fef2ff 0000df00
(invalid instruction)                                        ; d769006b
	v_cndmask_b32_e32 v0, v106, v128, vcc_lo                    ; 0201016a
	v_cvt_f32_f16_e32 v118, v117                                ; 7eec1775
(invalid instruction)                                        ; d769006f
	v_cndmask_b32_e32 v0, v110, v128, vcc_lo                    ; 0201016e
(invalid instruction)                                        ; d7690073
	v_cndmask_b32_e32 v0, v114, v128, vcc_lo                    ; 02010172
	v_fma_mixlo_f16 v17, v17, v128, v135 op_sel_hi:[1,0,0]      ; cc210011 0e1f0111
	v_maxmin_num_f16 v125, 0xdf00, v125, neg(0xdf00)            ; d66b007d 83fefaff 0000df00
	v_cvt_f32_f16_e32 v122, v121                                ; 7ef41779
(invalid instruction)                                        ; d7690077
	v_cndmask_b32_e32 v0, v118, v128, vcc_lo                    ; 02010176
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v17, 0xdf00, v17, neg(0xdf00)              ; d66b0011 83fe22ff 0000df00
	v_cvt_f32_f16_e32 v126, v125                                ; 7efc177d
(invalid instruction)                                        ; d769007b
	v_cndmask_b32_e32 v0, v122, v128, vcc_lo                    ; 0201017a
	v_cvt_f32_f16_e32 v129, v17                                 ; 7f021711
(invalid instruction)                                        ; d769007f
	v_cndmask_b32_e32 v0, v126, v128, vcc_lo                    ; 0201017e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690082
	v_cndmask_b32_e32 v0, v129, v128, vcc_lo                    ; 02010181
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v103, v6, s[12:15], null offen              ; c406007c 40801867 00000006
	buffer_store_b8 v107, v6, s[12:15], null offen offset:16    ; c406007c 4080186b 00001006
	buffer_store_b8 v111, v6, s[12:15], null offen offset:32    ; c406007c 4080186f 00002006
	buffer_store_b8 v115, v6, s[12:15], null offen offset:48    ; c406007c 40801873 00003006
	buffer_store_b8 v119, v6, s[12:15], null offen offset:64    ; c406007c 40801877 00004006
	buffer_store_b8 v123, v6, s[12:15], null offen offset:80    ; c406007c 4080187b 00005006
	buffer_store_b8 v127, v6, s[12:15], null offen offset:96    ; c406007c 4080187f 00006006
	buffer_store_b8 v130, v6, s[12:15], null offen offset:112   ; c406007c 40801882 00007006
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v131, v21, s[12:15], null offen          ; c407807c 40801883 00000015
	buffer_load_d16_u8 v132, v21, s[12:15], null offen offset:16 ; c407807c 40801884 00001015
	buffer_load_d16_u8 v133, v21, s[12:15], null offen offset:32 ; c407807c 40801885 00002015
	buffer_load_d16_u8 v134, v21, s[12:15], null offen offset:48 ; c407807c 40801886 00003015
	buffer_load_d16_u8 v135, v21, s[12:15], null offen offset:64 ; c407807c 40801887 00004015
	buffer_load_d16_u8 v144, v21, s[12:15], null offen offset:80 ; c407807c 40801890 00005015
	buffer_load_d16_u8 v145, v21, s[12:15], null offen offset:96 ; c407807c 40801891 00006015
	buffer_load_d16_u8 v146, v21, s[12:15], null offen offset:112 ; c407807c 40801892 00007015
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v147, v131                                ; 7f26d983
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v151, v132                                ; 7f2ed984
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v155, v133                                ; 7f36d985
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v159, v134                                ; 7f3ed986
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v148, v18, v147, v136 op_sel_hi:[1,0,0]     ; cc210094 0e232712
	v_fma_mixlo_f16 v152, v18, v151, v137 op_sel_hi:[1,0,0]     ; cc210098 0e272f12
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v163, v135                                ; 7f46d987
	v_fma_mixlo_f16 v156, v18, v155, v138 op_sel_hi:[1,0,0]     ; cc21009c 0e2b3712
	v_fma_mixlo_f16 v160, v18, v159, v139 op_sel_hi:[1,0,0]     ; cc2100a0 0e2f3f12
	v_maxmin_num_f16 v148, 0xdf00, v148, neg(0xdf00)            ; d66b0094 83ff28ff 0000df00
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v167, v144                                ; 7f4ed990
	v_maxmin_num_f16 v152, 0xdf00, v152, neg(0xdf00)            ; d66b0098 83ff30ff 0000df00
	v_fma_mixlo_f16 v164, v18, v163, v140 op_sel_hi:[1,0,0]     ; cc2100a4 0e334712
	v_maxmin_num_f16 v156, 0xdf00, v156, neg(0xdf00)            ; d66b009c 83ff38ff 0000df00
	v_maxmin_num_f16 v160, 0xdf00, v160, neg(0xdf00)            ; d66b00a0 83ff40ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v171, v145                                ; 7f56d991
(invalid instruction)                                        ; d58b0095
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                    ; 02010194
	v_fma_mixlo_f16 v168, v18, v167, v141 op_sel_hi:[1,0,0]     ; cc2100a8 0e374f12
(invalid instruction)                                        ; d58b0099
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                    ; 02010198
	v_maxmin_num_f16 v164, 0xdf00, v164, neg(0xdf00)            ; d66b00a4 83ff48ff 0000df00
(invalid instruction)                                        ; d58b009d
	v_cndmask_b32_e32 v0, v156, v128, vcc_lo                    ; 0201019c
(invalid instruction)                                        ; d58b00a1
	v_cndmask_b32_e32 v0, v160, v128, vcc_lo                    ; 020101a0
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v175, v146                                ; 7f5ed992
	v_fma_mixlo_f16 v172, v18, v171, v142 op_sel_hi:[1,0,0]     ; cc2100ac 0e3b5712
(invalid instruction)                                        ; d7690096
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                    ; 02010195
	v_maxmin_num_f16 v168, 0xdf00, v168, neg(0xdf00)            ; d66b00a8 83ff50ff 0000df00
(invalid instruction)                                        ; d769009a
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                    ; 02010199
(invalid instruction)                                        ; d58b00a5
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
(invalid instruction)                                        ; d769009e
	v_cndmask_b32_e32 v0, v157, v128, vcc_lo                    ; 0201019d
(invalid instruction)                                        ; d76900a2
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
	v_fma_mixlo_f16 v18, v18, v175, v143 op_sel_hi:[1,0,0]      ; cc210012 0e3f5f12
	v_maxmin_num_f16 v172, 0xdf00, v172, neg(0xdf00)            ; d66b00ac 83ff58ff 0000df00
(invalid instruction)                                        ; d58b00a9
	v_cndmask_b32_e32 v0, v168, v128, vcc_lo                    ; 020101a8
(invalid instruction)                                        ; d76900a6
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_maxmin_num_f16 v18, 0xdf00, v18, neg(0xdf00)              ; d66b0012 83fe24ff 0000df00
(invalid instruction)                                        ; d58b00ad
	v_cndmask_b32_e32 v0, v172, v128, vcc_lo                    ; 020101ac
(invalid instruction)                                        ; d76900aa
	v_cndmask_b32_e32 v0, v169, v128, vcc_lo                    ; 020101a9
	v_cvt_f32_f16_e32 v176, v18                                 ; 7f601712
(invalid instruction)                                        ; d76900ae
	v_cndmask_b32_e32 v0, v173, v128, vcc_lo                    ; 020101ad
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900b1
	v_cndmask_b32_e32 v0, v176, v128, vcc_lo                    ; 020101b0
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v150, v0, s[12:15], null offen              ; c406007c 40801896 00000000
	buffer_store_b8 v154, v0, s[12:15], null offen offset:16    ; c406007c 4080189a 00001000
	buffer_store_b8 v158, v0, s[12:15], null offen offset:32    ; c406007c 4080189e 00002000
	buffer_store_b8 v162, v0, s[12:15], null offen offset:48    ; c406007c 408018a2 00003000
	buffer_store_b8 v166, v0, s[12:15], null offen offset:64    ; c406007c 408018a6 00004000
	buffer_store_b8 v170, v0, s[12:15], null offen offset:80    ; c406007c 408018aa 00005000
	buffer_store_b8 v174, v0, s[12:15], null offen offset:96    ; c406007c 408018ae 00006000
	buffer_store_b8 v177, v0, s[12:15], null offen offset:112   ; c406007c 408018b1 00007000
BB16:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
