BB0:
	s_cmp_lg_i32 s9, -1                                         ; bf01c109
	s_cbranch_scc0 BB2                                          ; bfa1000f
BB1:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[12:15], s[12:13], 0x30                        ; f4004306 f8000030
	s_lshl2_add_u32 s16, s9, 24                                 ; 87909809
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s13, 14                                       ; be8d108e
	s_buffer_load_b32 s16, s[12:15], s16 offset:0x0             ; f4020406 20000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s16, 0x54434852                                ; bf01ff10 54434852
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s12, vcc_lo, exec_lo                              ; 8b0c7e6a
	s_cselect_b32 s9, -1, s9                                    ; 980909c1
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s9, -1                                         ; bf01c109
	s_cbranch_scc0 BB5                                          ; bfa1000b
BB4:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[12:15], s[12:13], 0x30                        ; f4004306 f8000030
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_lshl2_add_u32 s17, s9, 12                                 ; 87918c09
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s13, 14                                       ; be8d108e
	s_buffer_load_b32 s17, s[12:15], s17 offset:0x0             ; f4020446 22000000
	s_branch BB6                                                ; bfa00002
BB5:
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_mov_b32 s17, -1                                           ; be9100c1
BB6:
	s_mov_b32 s12, ttmp9                                        ; be8c0075
	s_mov_b32 s13, ttmp7                                        ; be8d0073
	s_cmp_lg_i32 s8, 0                                          ; bf018008
	s_cbranch_scc0 BB9                                          ; bfa1004e
BB7:
	s_mul_i32 s12, s10, ttmp7                                   ; 960c730a
	s_mul_i32 s13, s8, s11                                      ; 960d0b08
	s_add_co_u32 s12, ttmp9, s12                                ; 800c0c75
	s_cvt_f32_u32 s14, s13                                      ; be8e650d
(invalid instruction)                                        ; d684000e
	v_cndmask_b32_e32 v0, s14, v128, vcc_lo                     ; 0201000e
	s_mul_f32 s14, s14, 0x4f7ffffe                              ; a20eff0e 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s14, s14                                      ; be8e670e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s15, s13, s14                                     ; 960f0e0d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s15, 0, s15                                    ; 818f0f80
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s15, s14, s15                                  ; 968f0f0e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s14, s14, s15                                  ; 800e0f0e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s14, s12, s14                                  ; 968e0e0c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s18, s14, s13                                     ; 96120d0e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s18, s12, s18                                  ; 8192120c
	s_sub_co_u32 s19, s18, s13                                  ; 80930d12
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_absdiff_i32 s21, src_scc, 1                               ; 831581fd
	s_add_co_u32 s14, s14, s21                                  ; 800e150e
	s_sub_co_u32 s19, s18, s13                                  ; 80930d12
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s18, s18, s19                                 ; 98121312
	s_cmp_ge_u32 s18, s13                                       ; bf090d12
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s14, s14, src_scc                              ; 800efd0e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s14, s14, s8                                      ; 960e080e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s10, s10, s14                                  ; 818a0e0a
	s_mul_i32 s11, s14, s11                                     ; 960b0b0e
	s_min_u32 s8, s8, s10                                       ; 89880a08
	s_sub_co_i32 s12, s12, s11                                  ; 818c0b0c
	s_cvt_f32_u32 s22, s8                                       ; be966508
(invalid instruction)                                        ; d6840016
	v_cndmask_b32_e32 v0, s22, v128, vcc_lo                     ; 02010016
	s_mul_f32 s22, s22, 0x4f7ffffe                              ; a216ff16 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s22, s22                                      ; be966716
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s23, s8, s22                                      ; 96171608
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s23, 0, s23                                    ; 81971780
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s23, s22, s23                                  ; 96971716
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s22, s22, s23                                  ; 80161716
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s22, s12, s22                                  ; 9696160c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s24, s22, s8                                      ; 96180816
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s12, s12, s24                                  ; 818c180c
	s_sub_co_u32 s25, s12, s8                                   ; 8099080c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_absdiff_i32 s27, src_scc, 1                               ; 831b81fd
	s_sub_co_u32 s25, s12, s8                                   ; 8099080c
	s_cselect_b32 s12, s12, s25                                 ; 980c190c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s8, s12, s8                                    ; 8088080c
	s_mov_b32 s28, src_scc                                      ; be9c00fd
	s_absdiff_i32 s29, src_scc, 1                               ; 831d81fd
	s_cmp_lg_i32 s28, 0                                         ; bf01801c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s12, s12, s8                                  ; 980c080c
	s_add_co_u32 s12, s14, s12                                  ; 800c0c0e
	s_add_co_u32 s22, s22, s27                                  ; 80161b16
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s13, s22, s29                                  ; 800d1d16
BB9:
	s_cmp_lg_i32 s16, 0                                         ; bf018010
	s_cbranch_scc0 BB11                                         ; bfa1000e
BB10:
	s_mov_b32 s10, s0                                           ; be8a0000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_load_b128 s[20:23], s[10:11], 0x30                        ; f4004505 f8000030
	s_lshl2_add_u32 s8, s9, 8                                   ; 87888809
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_buffer_load_b32 s8, s[20:23], s8 offset:0x0               ; f402020a 10000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s8, -1                                         ; bf01c108
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB12                                               ; bfa00001
BB11:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB12:
	s_lshl_b32 s12, s12, 5                                      ; 840c850c
	s_and_b32 s8, vcc_lo, exec_lo                               ; 8b087e6a
	s_cbranch_scc0 BB53                                         ; bfa1007c
BB13:
	s_and_b32 s8, ttmp8, 0x3e000000                             ; 8b08ff74 3e000000
	s_cbranch_scc1 BB51                                         ; bfa20077
BB14:
	s_mov_b32 s10, s0                                           ; be8a0000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_load_b128 s[20:23], s[10:11], 0x30                        ; f4004505 f8000030
	s_lshl_b32 s9, s9, 2                                        ; 84098209
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s14, s9, 8                                     ; 800e8809
	s_add_co_u32 s15, s9, 16                                    ; 800f9009
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_clause 0x2                                                ; bf850002
	s_buffer_load_b32 s8, s[20:23], s9 offset:0x0               ; f402020a 12000000
	s_buffer_load_b32 s14, s[20:23], s14 offset:0x0             ; f402038a 1c000000
	s_buffer_load_b32 s15, s[20:23], s15 offset:0x0             ; f40203ca 1e000000
	s_load_b128 s[24:27], s[10:11], 0x0                         ; f4004605 f8000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s15, s15, 2                                      ; 840f820f
	buffer_load_b32 v1, off, s[24:27], s15 scope:SCOPE_DEV      ; c405000f 00883001 00000000
	s_lshr_b32 s16, s12, 4                                      ; 8510840c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s14, s14, s16                                  ; 800e100e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s14, s14, 2                                      ; 840e820e
	s_buffer_load_b32 s18, s[20:23], s14 offset:0x0             ; f402048a 1c000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s18, -1                                        ; bf01c112
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s19, v1                                 ; 7e260501
	s_cbranch_scc0 BB23                                         ; bfa1001b
BB15:
	s_bfm_b32 s10, 1, 16                                        ; 950a9081
BB16:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s10, 0                                         ; bf01800a
	s_cbranch_scc0 BB18                                         ; bfa10011
BB17:
	s_and_b32 s11, s18, 0xfffff                                 ; 8b0bff12 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s11, s8, s11                                   ; 800b0b08
	s_lshl_b32 s11, s11, 2                                      ; 840b820b
	buffer_load_b32 v1, off, s[24:27], s11 scope:SCOPE_DEV      ; c405000b 00883001 00000000
	s_lshr_b32 s15, s18, 20                                     ; 850f9412
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s15, s15, s19                                     ; 960f130f
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s16, v1                                 ; 7e200501
	s_cmp_lt_u32 s16, s15                                       ; bf0a0f10
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s28, -1, 0                                    ; 981c80c1
	s_branch BB19                                               ; bfa00001
BB18:
	s_mov_b32 s28, 0                                            ; be9c0080
BB19:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s28, exec_lo, s28                            ; 911c1c7e
	s_cbranch_scc1 BB24                                         ; bfa20003
BB21:
	s_add_co_u32 s10, s10, -1                                   ; 800ac10a
	s_branch BB16                                               ; bfa0ffe6
BB23:
	s_bfm_b32 s10, 1, 16                                        ; 950a9081
BB24:
	s_add_co_u32 s14, s14, 4                                    ; 800e840e
	s_buffer_load_b32 s14, s[20:23], s14 offset:0x0             ; f402038a 1c000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s14, -1                                        ; bf01c10e
	s_cbranch_scc0 BB34                                         ; bfa1001a
BB25:
	s_branch BB26                                               ; bfa00001
BB31:
	s_add_co_u32 s10, s10, -1                                   ; 800ac10a
BB26:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s10, 0                                         ; bf01800a
	s_cbranch_scc0 BB28                                         ; bfa10011
BB27:
	s_and_b32 s11, s14, 0xfffff                                 ; 8b0bff0e 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s11, s8, s11                                   ; 800b0b08
	s_lshl_b32 s11, s11, 2                                      ; 840b820b
	buffer_load_b32 v1, off, s[24:27], s11 scope:SCOPE_DEV      ; c405000b 00883001 00000000
	s_lshr_b32 s15, s14, 20                                     ; 850f940e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s15, s15, s19                                     ; 960f130f
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s16, v1                                 ; 7e200501
	s_cmp_lt_u32 s16, s15                                       ; bf0a0f10
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s18, -1, 0                                    ; 981280c1
	s_branch BB29                                               ; bfa00001
BB28:
	s_mov_b32 s18, 0                                            ; be920080
BB29:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s18, exec_lo, s18                            ; 9112127e
	s_cbranch_scc0 BB31                                         ; bfa1ffe7
BB34:
	s_cmp_eq_i32 s10, 0                                         ; bf00800a
	s_cbranch_scc0 BB36                                         ; bfa10002
BB35:
	s_mov_b32 s8, 1                                             ; be880081
	s_branch BB37                                               ; bfa00001
BB36:
	s_mov_b32 s8, 0                                             ; be880080
BB37:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mov_b32 exec_lo, s8                                       ; befe0008
	s_cbranch_execz BB49                                        ; bfa5000e
BB38:
	s_ctz_i32_b32 s8, exec_lo                                   ; be88087e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s8, 1, s8                                        ; 84080881
	s_and_saveexec_b32 s8, s8                                   ; be882008
	s_cbranch_execz BB49                                        ; bfa50009
BB39:
	s_add_co_u32 s9, s9, 20                                     ; 80099409
	s_buffer_load_b32 s9, s[20:23], s9 offset:0x0               ; f402024a 12000000
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s9, s9, 2                                        ; 84098209
	buffer_atomic_max_u32 v1, off, s[24:27], s9                 ; c40ec009 00803001 00000000
BB49:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
BB51:
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
BB53:
	v_and_b32_e32 v4, 31, v0                                    ; 3608009f
	v_bfe_u32 v1, v0, 5, 2                                      ; d6100001 02090b00
	s_mulk_i32 s13, 0x180                                       ; b80d0180
	v_and_b32_e32 v0, 15, v0                                    ; 3600008f
	s_lshr_b32 s8, s7, 4                                        ; 85088407
	s_lshr_b32 s9, s12, 4                                       ; 8509840c
	v_lshlrev_b32_e32 v5, 2, v4                                 ; 300a0882
	v_lshrrev_b32_e32 v4, 4, v4                                 ; 32080884
	v_mad_u32_u24 v1, 0x60, v1, s13                             ; d60b0001 003602ff 00000060
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0              ; ca100080 10100080
	s_mul_i32 s10, s9, s8                                       ; 960a0809
	v_lshlrev_b32_e32 v0, 4, v0                                 ; 30000084
	v_lshlrev_b32_e32 v4, 3, v4                                 ; 30080883
	s_lshl_b32 s10, s10, 8                                      ; 840a880a
	s_add_co_u32 s11, 16, s12                                   ; 800b0c90
	v_lshrrev_b32_e32 v2, 5, v1                                 ; 32040285
	v_add_nc_u32_e32 v6, 32, v1                                 ; 4a0c02a0
	v_add_nc_u32_e32 v9, 64, v1                                 ; 4a1202c0
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0              ; ca100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0              ; ca100080 14140080
	v_add3_u32 v12, v0, s1, s10                                 ; d655000c 00280300
	s_lshr_b32 s14, s11, 4                                      ; 850e840b
(invalid instruction)                                        ; d72c0003
	v_cndmask_b32_e32 v0, v2, v8, vcc_lo                        ; 02001102
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0              ; ca100080 16160080
	v_lshrrev_b32_e32 v7, 5, v6                                 ; 320e0c85
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0              ; ca100080 18180080
	v_lshrrev_b32_e32 v10, 5, v9                                ; 32141285
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s15, s14, s8                                      ; 960f080e
	v_add_nc_u32_e32 v12, v12, v4                               ; 4a18090c
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0              ; ca100080 1a1a0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0              ; ca100080 1c1c0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
(invalid instruction)                                        ; d72c0008
	v_cndmask_b32_e32 v0, v7, v8, vcc_lo                        ; 02001107
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s15, s15, 8                                      ; 840f880f
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_lshr_b32 s7, s7, 5                                        ; 85078507
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
(invalid instruction)                                        ; d72c000b
	v_cndmask_b32_e32 v0, v10, v8, vcc_lo                       ; 0200110a
	v_lshrrev_b32_e32 v12, 2, v12                               ; 32181882
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v0, v0, s1, s15                                  ; d6550000 003c0300
	s_mov_b32 s1, 0                                             ; be810080
	v_lshl_add_u32 v3, v3, 7, s4                                ; d6460003 00110f03
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	v_lshl_add_u32 v8, v8, 7, s4                                ; d6460008 00110f08
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v60, 0              ; ca100080 3d3c0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v62, 0              ; ca100080 3f3e0080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v64, 0              ; ca100080 41400080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0              ; ca100080 43420080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v68, 0              ; ca100080 45440080
	v_lshl_add_u32 v11, v11, 7, s4                              ; d646000b 00110f0b
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v70, 0              ; ca100080 47460080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v72, 0              ; ca100080 49480080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v74, 0              ; ca100080 4b4a0080
	v_add_nc_u32_e32 v0, v0, v4                                 ; 4a000900
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v76, 0              ; ca100080 4d4c0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v78, 0              ; ca100080 4f4e0080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v80, 0              ; ca100080 51500080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v82, 0              ; ca100080 53520080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v84, 0              ; ca100080 55540080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v86, 0              ; ca100080 57560080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v88, 0              ; ca100080 59580080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v90, 0              ; ca100080 5b5a0080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v92, 0              ; ca100080 5d5c0080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v94, 0              ; ca100080 5f5e0080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v96, 0              ; ca100080 61600080
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v98, 0              ; ca100080 63620080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v100, 0            ; ca100080 65640080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v102, 0            ; ca100080 67660080
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v104, 0            ; ca100080 69680080
	v_dual_mov_b32 v107, 0 :: v_dual_mov_b32 v106, 0            ; ca100080 6b6a0080
	v_dual_mov_b32 v109, 0 :: v_dual_mov_b32 v108, 0            ; ca100080 6d6c0080
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v110, 0            ; ca100080 6f6e0080
	v_lshrrev_b32_e32 v0, 2, v0                                 ; 32000082
	s_branch BB54                                               ; bfa0007f
	s_nop 0                                                     ; bf800000
	(then repeated 4 times)
BB56:
	s_mov_b32 s18, s0                                           ; be920000
	s_movk_i32 s19, 0x8000                                      ; b0138000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[18:19], 0x70                        ; f4004509 f8000070
	s_load_b128 s[24:27], s[18:19], 0x30                        ; f4004609 f8000030
	s_lshl_b32 s4, s1, 5                                        ; 84048501
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s4, s4, 4                                        ; 85048404
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s8, s4, 8                                        ; 84088804
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s8, s8, 2                                        ; 85088208
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v4, s8, v12, 2                               ; d6470004 020a1808
	v_add_lshl_u32 v13, s8, v0, 2                               ; d647000d 020a0008
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[14:15], v4, s[20:23], null offen          ; c405407c 4080280e 00000004
	buffer_load_b64 v[112:113], v13, s[20:23], null offen       ; c405407c 40802870 0000000d
	s_lshl_b32 s4, s4, 7                                        ; 84048704
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v116, s4, v11, v5                                ; d6550074 04161604
	v_add3_u32 v114, s4, v3, v5                                 ; d6550072 04160604
	v_add3_u32 v115, s4, v8, v5                                 ; d6550073 04161004
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_lshlrev_b32_e32 v116, 2, v116                             ; 30e8e882
	v_lshlrev_b32_e32 v114, 2, v114                             ; 30e4e482
	v_lshlrev_b32_e32 v115, 2, v115                             ; 30e6e682
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[120:123], v114, s[24:27], null offen     ; c405c07c 40803078 00000072
	buffer_load_b128 v[124:127], v115, s[24:27], null offen     ; c405c07c 4080307c 00000073
	buffer_load_b128 v[128:131], v116, s[24:27], null offen     ; c405c07c 40803080 00000074
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[118:119], v4, s[20:23], null offen offset:256 ; c405407c 40802876 00010004
	buffer_load_b64 v[132:133], v13, s[20:23], null offen offset:256 ; c405407c 40802884 0001000d
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[136:139], v114, s[24:27], null offen offset:512 ; c405c07c 40803088 00020072
	buffer_load_b128 v[140:143], v115, s[24:27], null offen offset:512 ; c405c07c 4080308c 00020073
	buffer_load_b128 v[114:117], v116, s[24:27], null offen offset:512 ; c405c07c 40803072 00020074
	s_add_co_u32 s1, s1, 1                                      ; 80018101
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[14:15], v[122:123], v[24:31] ; cc464018 1c62f50e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[14:15], v[120:121], v[16:23] ; cc464010 1c42f10e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[112:113], v[120:121], v[64:71] ; cc464040 1d02f170
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[112:113], v[122:123], v[72:79] ; cc464048 1d22f570
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[112:113], v[124:125], v[80:87] ; cc464050 1d42f970
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[14:15], v[124:125], v[32:39] ; cc464020 1c82f90e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[112:113], v[126:127], v[88:95] ; cc464058 1d62fd70
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[14:15], v[126:127], v[40:47] ; cc464028 1ca2fd0e
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[14:15], v[128:129], v[48:55] ; cc464030 1cc3010e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[14:15], v[130:131], v[56:63] ; cc464038 1ce3050e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[112:113], v[128:129], v[96:103] ; cc464060 1d830170
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[112:113], v[130:131], v[104:111] ; cc464068 1da30570
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[118:119], v[138:139], v[24:31] ; cc464018 1c631576
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[118:119], v[136:137], v[16:23] ; cc464010 1c431176
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[132:133], v[136:137], v[64:71] ; cc464040 1d031184
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[132:133], v[138:139], v[72:79] ; cc464048 1d231584
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[132:133], v[140:141], v[80:87] ; cc464050 1d431984
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[118:119], v[140:141], v[32:39] ; cc464020 1c831976
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[132:133], v[142:143], v[88:95] ; cc464058 1d631d84
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[118:119], v[142:143], v[40:47] ; cc464028 1ca31d76
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[118:119], v[114:115], v[48:55] ; cc464030 1cc2e576
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[118:119], v[116:117], v[56:63] ; cc464038 1ce2e976
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[132:133], v[114:115], v[96:103] ; cc464060 1d82e584
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[132:133], v[116:117], v[104:111] ; cc464068 1da2e984
BB54:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s1, s7                                         ; bf090701
	s_cbranch_scc0 BB56                                         ; bfa1ff83
BB57:
	s_cmp_lt_u32 s12, s5                                        ; bf0a050c
	s_cbranch_scc0 BB204                                        ; bfa10630
BB58:
	v_cvt_f16_f32_e32 v0, v16                                   ; 7e001510
(invalid instruction)                                        ; 7f001511
	v_cvt_f16_f32_e32 v3, v24                                   ; 7e061518
(invalid instruction)                                        ; 7f061519
	v_cmpx_gt_u32_e32 0x800, v1                                 ; 7d9802ff 00000800
	s_mov_b32 vcc_lo, exec_lo                                   ; beea007e
	s_cbranch_execz BB70                                        ; bfa5004c
BB59:
(invalid instruction)                                        ; cc100004
	v_min_num_f64_e32 v[1:2], v[3:4], v[3:4]                    ; 1a020703
(invalid instruction)                                        ; cc100005
	v_min_num_f64_e32 v[1:2], v[0:1], v[0:1]                    ; 1a020100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[4:5]                    ; 1a020905
(invalid instruction)                                        ; cc100010
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                     ; 020202ff 00000400
	v_mov_b32_dpp v8, v5 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1002fa ff0d2805
(invalid instruction)                                        ; cc100011
	v_subrev_f32_e32 v0, v0, v255                               ; 0a01ff00
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v3, v3, v16, s1                           ; d5010003 00062103
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[8:9]                    ; 1a021105
	v_cndmask_b32_e64 v0, v0, v17, s1                           ; d5010000 00062300
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1602fa ff0d6405
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[11:12]                  ; 1a021705
	v_mov_b32_dpp v12, v5 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1802fa ff0c4e05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[12:13]                  ; 1a021905
	v_mov_b32_dpp v13, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a02fa ff0cb105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[13:14]                  ; 1a021b05
(invalid instruction)                                        ; cc1c0005
	v_subrev_f32_e32 v0, v5, v255                               ; 0a01ff05
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v14, v5                                   ; 7e1c1705
	v_cvt_f32_f16_e32 v5, v133/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a1785
	v_rsq_f32_e32 v14, v14                                      ; 7e1c5d0e
	v_rsq_f32_e32 v5, v5                                        ; 7e0a5d05
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v15, v14                                  ; 7e1e150e
(invalid instruction)                                        ; 7f1e1505
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[0:1], v[15:16]                  ; 1a021f00
(invalid instruction)                                        ; cc100003
	v_min_num_f64_e32 v[1:2], v[3:4], v[15:16]                  ; 1a021f03
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB70                                        ; bfa50011
BB60:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[20:23], s[12:13], 0x30                        ; f4004506 f8000030
	v_add_lshl_u32 v4, s2, v2, 2                                ; d6470004 020a0402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v4, v4, s[20:23], null offen                ; c405007c 40802804 00000004
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v5, v4                                    ; 7e0a1504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100000
	v_subrev_f32_e32 v1, v0, v5                                 ; 0a020b00
(invalid instruction)                                        ; cc100003
	v_subrev_f32_e32 v1, v3, v5                                 ; 0a020b03
BB70:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v14, v18                                  ; 7e1c1512
(invalid instruction)                                        ; 7f1c1513
	v_cvt_f16_f32_e32 v15, v26                                  ; 7e1e151a
(invalid instruction)                                        ; 7f1e151b
(invalid instruction)                                        ; cc1c0000
	v_subrev_f32_e32 v0, v0, v255                               ; 0a01ff00
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b0000
	v_subrev_f32_e32 v0, v0, v255                               ; 0a01ff00
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b0003
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v4, v0                                    ; 7e081700
	v_cvt_f32_f16_e32 v0, v128/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e001780
	v_cvt_f32_f16_e32 v11, v3                                   ; 7e161703
	v_cvt_f32_f16_e32 v3, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e061783
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v0, v4, v128, vcc_lo                      ; 02010104
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v0, v3, v128, vcc_lo                      ; 02010103
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB82                                        ; bfa5004c
BB71:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[15:16], v[15:16]                ; 1a021f0f
(invalid instruction)                                        ; cc100003
	v_min_num_f64_e32 v[1:2], v[14:15], v[14:15]                ; 1a021d0e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[0:1]                    ; 1a020103
(invalid instruction)                                        ; cc100018
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                     ; 020202ff 00000400
	v_mov_b32_dpp v4, v3 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0802fa ff0d2803
(invalid instruction)                                        ; cc100019
	v_subrev_f32_e32 v0, v14, v255                              ; 0a01ff0e
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v15, v15, v24, s1                         ; d501000f 0006310f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[4:5]                    ; 1a020903
	v_cndmask_b32_e64 v14, v14, v25, s1                         ; d501000e 0006330e
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1602fa ff0d6403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[11:12]                  ; 1a021703
	v_mov_b32_dpp v16, v3 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2002fa ff0c4e03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[16:17]                  ; 1a022103
	v_mov_b32_dpp v17, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2202fa ff0cb103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[17:18]                  ; 1a022303
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v18, v3                                   ; 7e241703
	v_cvt_f32_f16_e32 v3, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e061783
	v_rsq_f32_e32 v18, v18                                      ; 7e245d12
	v_rsq_f32_e32 v3, v3                                        ; 7e065d03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v19, v18                                  ; 7e261512
(invalid instruction)                                        ; 7f261503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[19:20]                ; 1a02270e
(invalid instruction)                                        ; cc10000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[19:20]                ; 1a02270f
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB82                                        ; bfa50011
BB72:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[20:23], s[12:13], 0x30                        ; f4004506 f8000030
	v_add_lshl_u32 v0, s2, v2, 2                                ; d6470000 020a0402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[20:23], null offen                ; c405007c 40802800 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v3, v0                                    ; 7e061500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000e
	v_subrev_f32_e32 v1, v14, v3                                ; 0a02070e
(invalid instruction)                                        ; cc10000f
	v_subrev_f32_e32 v1, v15, v3                                ; 0a02070f
BB82:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v16, v20                                  ; 7e201514
(invalid instruction)                                        ; 7f201515
	v_cvt_f16_f32_e32 v17, v28                                  ; 7e22151c
(invalid instruction)                                        ; 7f22151d
(invalid instruction)                                        ; cc1c000e
	v_subrev_f32_e32 v0, v14, v255                              ; 0a01ff0e
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c000f
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b000e
	v_subrev_f32_e32 v0, v14, v255                              ; 0a01ff0e
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b000f
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v14                                   ; 7e00170e
	v_cvt_f32_f16_e32 v14, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1c178e
	v_cvt_f32_f16_e32 v11, v15                                  ; 7e16170f
	v_cvt_f32_f16_e32 v15, v143/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e178f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v15, v128, vcc_lo                     ; 0201010f
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB94                                        ; bfa5004c
BB83:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[17:18], v[17:18]                ; 1a022311
(invalid instruction)                                        ; cc10000b
	v_min_num_f64_e32 v[1:2], v[16:17], v[16:17]                ; 1a022110
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[0:1]                  ; 1a02010b
(invalid instruction)                                        ; cc10001a
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                     ; 020202ff 00000400
	v_mov_b32_dpp v18, v11 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2402fa ff0d280b
(invalid instruction)                                        ; cc10001b
	v_subrev_f32_e32 v0, v16, v255                              ; 0a01ff10
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v17, v17, v26, s1                         ; d5010011 00063511
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[18:19]                ; 1a02250b
	v_cndmask_b32_e64 v16, v16, v27, s1                         ; d5010010 00063710
	v_mov_b32_dpp v19, v11 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2602fa ff0d640b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[19:20]                ; 1a02270b
	v_mov_b32_dpp v20, v11 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2802fa ff0c4e0b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[20:21]                ; 1a02290b
	v_mov_b32_dpp v21, v11 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2a02fa ff0cb10b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[21:22]                ; 1a022b0b
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v255                              ; 0a01ff0b
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v24, v11                                  ; 7e30170b
	v_cvt_f32_f16_e32 v11, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e16178b
	v_rsq_f32_e32 v24, v24                                      ; 7e305d18
	v_rsq_f32_e32 v11, v11                                      ; 7e165d0b
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v25, v24                                  ; 7e321518
(invalid instruction)                                        ; 7f32150b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100010
	v_min_num_f64_e32 v[1:2], v[16:17], v[25:26]                ; 1a023310
(invalid instruction)                                        ; cc100011
	v_min_num_f64_e32 v[1:2], v[17:18], v[25:26]                ; 1a023311
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB94                                        ; bfa50011
BB84:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[20:23], s[12:13], 0x30                        ; f4004506 f8000030
	v_add_lshl_u32 v0, s2, v2, 2                                ; d6470000 020a0402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[20:23], null offen                ; c405007c 40802800 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v11, v0                                   ; 7e161500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100010
	v_subrev_f32_e32 v1, v16, v11                               ; 0a021710
(invalid instruction)                                        ; cc100011
	v_subrev_f32_e32 v1, v17, v11                               ; 0a021711
BB94:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v21, v22                                  ; 7e2a1516
(invalid instruction)                                        ; 7f2a1517
	v_cvt_f16_f32_e32 v22, v30                                  ; 7e2c151e
(invalid instruction)                                        ; 7f2c151f
(invalid instruction)                                        ; cc1c0010
	v_subrev_f32_e32 v0, v16, v255                              ; 0a01ff10
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b0010
	v_subrev_f32_e32 v0, v16, v255                              ; 0a01ff10
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v16                                   ; 7e001710
	v_cvt_f32_f16_e32 v16, v144/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e201790
	v_cvt_f32_f16_e32 v18, v17                                  ; 7e241711
	v_cvt_f32_f16_e32 v17, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221791
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                     ; 02010112
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB106                                       ; bfa50048
BB95:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[22:23], v[22:23]                ; 1a022d16
(invalid instruction)                                        ; cc100011
	v_min_num_f64_e32 v[1:2], v[21:22], v[21:22]                ; 1a022b15
(invalid instruction)                                        ; cc10001c
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 000045a8
	v_cmp_gt_u32_e32 vcc_lo, 0x400, v1                          ; 7c9802ff 00000400
(invalid instruction)                                        ; cc10001d
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 000045a8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[0:1]                  ; 1a020111
	v_dual_cndmask_b32 v21, v21, v29 :: v_dual_cndmask_b32 v22, v22, v28 ; ca523b15 15163916
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_mov_b32_dpp v18, v17 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2402fa ff0d2811
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[18:19]                ; 1a022511
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v23, v17 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2e02fa ff0d6411
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[23:24]                ; 1a022f11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v24, v17 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3002fa ff0c4e11
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[24:25]                ; 1a023111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v25, v17 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3202fa ff0cb111
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[25:26]                ; 1a023311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 00000410
	v_cvt_f32_f16_e32 v26, v17                                  ; 7e341711
	v_cvt_f32_f16_e32 v17, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221791
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v26, v26                                      ; 7e345d1a
	v_rsq_f32_e32 v17, v17                                      ; 7e225d11
	v_cvt_f16_f32_e32 v27, v26                                  ; 7e36151a
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
(invalid instruction)                                        ; 7f361511
(invalid instruction)                                        ; cc100015
	v_min_num_f64_e32 v[1:2], v[21:22], v[27:28]                ; 1a023715
(invalid instruction)                                        ; cc100016
	v_min_num_f64_e32 v[1:2], v[22:23], v[27:28]                ; 1a023716
	s_and_saveexec_b32 s1, vcc_lo                               ; be81206a
	s_cbranch_execz BB106                                       ; bfa50011
BB96:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[20:23], s[12:13], 0x30                        ; f4004506 f8000030
	v_add_lshl_u32 v0, s2, v2, 2                                ; d6470000 020a0402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[20:23], null offen                ; c405007c 40802800 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v17, v0                                   ; 7e221500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100015
	v_subrev_f32_e32 v1, v21, v17                               ; 0a022315
(invalid instruction)                                        ; cc100016
	v_subrev_f32_e32 v1, v22, v17                               ; 0a022316
BB106:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[20:23], s[12:13], 0x10                        ; f4004506 f8000010
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_lshr_b32 s1, s6, 4                                        ; 85018406
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 0000df00
	v_lshrrev_b32_e32 v25, 4, v1                                ; 32320284
(invalid instruction)                                        ; d71f001a
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s1, s9, s1                                        ; 96010109
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 0000df00
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v25, s1, v25, 8                              ; d6470019 02223201
	v_lshrrev_b32_e32 v27, 4, v26                               ; 32363484
	v_and_b32_e32 v26, 15, v26                                  ; 3634348f
	v_cvt_f32_f16_e32 v0, v21                                   ; 7e001715
	v_cvt_f32_f16_e32 v21, v149/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2a1795
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 00005f00
	v_add_nc_u32_e32 v25, s3, v25                               ; 4a323203
	v_lshlrev_b32_e32 v27, 7, v27                               ; 30363687
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
	v_cvt_f32_f16_e32 v21, v22                                  ; 7e2a1716
	v_cvt_f32_f16_e32 v22, v150/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2c1796
	v_add_nc_u32_e32 v115, 64, v27                              ; 4ae636c0
	v_add_nc_u32_e32 v117, 0x50, v27                            ; 4aea36ff 00000050
	v_add_nc_u32_e32 v119, 0x60, v27                            ; 4aee36ff 00000060
	v_add3_u32 v28, v26, v25, v27                               ; d655001c 046e331a
	v_add_nc_u32_e32 v121, 0x70, v27                            ; 4af236ff 00000070
	v_add_nc_u32_e32 v29, 16, v27                               ; 4a3a3690
	v_add_nc_u32_e32 v31, 32, v27                               ; 4a3e36a0
	v_add_nc_u32_e32 v113, 48, v27                              ; 4ae236b0
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v0, v22, v128, vcc_lo                     ; 02010116
	v_add3_u32 v116, v26, v25, v115                             ; d6550074 05ce331a
	v_add3_u32 v118, v26, v25, v117                             ; d6550076 05d6331a
	v_add3_u32 v120, v26, v25, v119                             ; d6550078 05de331a
	v_add3_u32 v122, v26, v25, v121                             ; d655007a 05e6331a
	v_add3_u32 v30, v26, v25, v29                               ; d655001e 0476331a
	v_add3_u32 v112, v26, v25, v31                              ; d6550070 047e331a
	v_add3_u32 v114, v26, v25, v113                             ; d6550072 05c6331a
	v_add_nc_u32_e32 v25, 0x100, v25                            ; 4a3232ff 00000100
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v123, v26, v25, v27                              ; d655007b 046e331a
	v_add3_u32 v124, v26, v25, v29                              ; d655007c 0476331a
	v_add3_u32 v125, v26, v25, v31                              ; d655007d 047e331a
	v_add3_u32 v129, v26, v25, v119                             ; d6550081 05de331a
	v_add3_u32 v126, v26, v25, v113                             ; d655007e 05c6331a
	v_add3_u32 v127, v26, v25, v115                             ; d655007f 05ce331a
	v_add3_u32 v128, v26, v25, v117                             ; d6550080 05d6331a
	v_add3_u32 v25, v26, v25, v121                              ; d6550019 05e6331a
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0xf                                                ; bf85000f
	buffer_store_b8 v5, v28, s[20:23], null offen               ; c406007c 40802805 0000001c
	buffer_store_b8 v8, v30, s[20:23], null offen               ; c406007c 40802808 0000001e
	buffer_store_b8 v3, v112, s[20:23], null offen              ; c406007c 40802803 00000070
	buffer_store_b8 v4, v114, s[20:23], null offen              ; c406007c 40802804 00000072
	buffer_store_b8 v11, v116, s[20:23], null offen             ; c406007c 4080280b 00000074
	buffer_store_b8 v16, v118, s[20:23], null offen             ; c406007c 40802810 00000076
	buffer_store_b8 v17, v120, s[20:23], null offen             ; c406007c 40802811 00000078
	buffer_store_b8 v18, v122, s[20:23], null offen             ; c406007c 40802812 0000007a
	buffer_store_b8 v12, v123, s[20:23], null offen             ; c406007c 4080280c 0000007b
	buffer_store_b8 v13, v124, s[20:23], null offen             ; c406007c 4080280d 0000007c
	buffer_store_b8 v14, v125, s[20:23], null offen             ; c406007c 4080280e 0000007d
	buffer_store_b8 v15, v126, s[20:23], null offen             ; c406007c 4080280f 0000007e
	buffer_store_b8 v19, v127, s[20:23], null offen             ; c406007c 40802813 0000007f
	buffer_store_b8 v20, v128, s[20:23], null offen             ; c406007c 40802814 00000080
	buffer_store_b8 v23, v129, s[20:23], null offen             ; c406007c 40802817 00000081
	buffer_store_b8 v24, v25, s[20:23], null offen              ; c406007c 40802818 00000019
(invalid instruction)                                        ; d58a0082
	v_cndmask_b32_e32 v0, v32, v128, vcc_lo                     ; 02010120
(invalid instruction)                                        ; d58a4082
	v_cndmask_b32_e32 v0, v33, v128, vcc_lo                     ; 02010121
(invalid instruction)                                        ; d58a0083
	v_cndmask_b32_e32 v0, v40, v128, vcc_lo                     ; 02010128
(invalid instruction)                                        ; d58a4083
	v_cndmask_b32_e32 v0, v41, v128, vcc_lo                     ; 02010129
	v_cmpx_gt_u32_e32 0x800, v6                                 ; 7d980cff 00000800
	s_mov_b32 vcc_lo, exec_lo                                   ; beea007e
	s_cbranch_execz BB118                                       ; bfa5004a
BB107:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[131:132], v[131:132]            ; 1a030783
(invalid instruction)                                        ; cc100003
	v_min_num_f64_e32 v[1:2], v[130:131], v[130:131]            ; 1a030582
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[0:1]                    ; 1a020103
(invalid instruction)                                        ; cc10000e
	v_subrev_f32_e32 v0, v131, v255                             ; 0a01ff83
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0004
	v_cndmask_b32_e32 v1, 0x400, v6, vcc_lo                     ; 02020cff 00000400
	v_mov_b32_dpp v4, v3 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0802fa ff0d2803
(invalid instruction)                                        ; cc10000f
	v_subrev_f32_e32 v0, v130, v255                             ; 0a01ff82
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v131, v131, v14, s4                       ; d5010083 00121d83
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[4:5]                    ; 1a020903
	v_cndmask_b32_e64 v130, v130, v15, s4                       ; d5010082 00121f82
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0a02fa ff0d6403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[5:6]                    ; 1a020b03
	v_mov_b32_dpp v8, v3 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1002fa ff0c4e03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[8:9]                    ; 1a021103
	v_mov_b32_dpp v11, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1602fa ff0cb103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[11:12]                  ; 1a021703
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v12, v3                                   ; 7e181703
	v_cvt_f32_f16_e32 v3, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e061783
	v_rsq_f32_e32 v12, v12                                      ; 7e185d0c
	v_rsq_f32_e32 v3, v3                                        ; 7e065d03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v13, v12                                  ; 7e1a150c
(invalid instruction)                                        ; 7f1a1503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100082
	v_min_num_f64_e32 v[1:2], v[130:131], v[13:14]              ; 1a021b82
(invalid instruction)                                        ; cc100083
	v_min_num_f64_e32 v[1:2], v[131:132], v[13:14]              ; 1a021b83
	s_and_saveexec_b32 s4, s4                                   ; be842004
	s_cbranch_execz BB118                                       ; bfa5000f
BB108:
	s_load_b128 s[24:27], s[12:13], 0x30                        ; f4004606 f8000030
	v_add_lshl_u32 v0, s2, v7, 2                                ; d6470000 020a0e02
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v3, v0                                    ; 7e061500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100082
	v_subrev_f32_e32 v1, v130, v3                               ; 0a020782
(invalid instruction)                                        ; cc100083
	v_subrev_f32_e32 v1, v131, v3                               ; 0a020783
BB118:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v12, v34                                  ; 7e181522
(invalid instruction)                                        ; 7f181523
	v_cvt_f16_f32_e32 v13, v42                                  ; 7e1a152a
(invalid instruction)                                        ; 7f1a152b
(invalid instruction)                                        ; cc1c0082
	v_subrev_f32_e32 v0, v130, v255                             ; 0a01ff82
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c0083
	v_subrev_f32_e32 v0, v131, v255                             ; 0a01ff83
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b0082
	v_subrev_f32_e32 v0, v130, v255                             ; 0a01ff82
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b0083
	v_subrev_f32_e32 v0, v131, v255                             ; 0a01ff83
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; d58b0000
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                    ; 02010182
(invalid instruction)                                        ; d58b0882
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                    ; 02010182
(invalid instruction)                                        ; d58b0005
	v_cndmask_b32_e32 v0, v131, v128, vcc_lo                    ; 02010183
(invalid instruction)                                        ; d58b0883
	v_cndmask_b32_e32 v0, v131, v128, vcc_lo                    ; 02010183
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                    ; 02010182
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v0, v5, v128, vcc_lo                      ; 02010105
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v131, v128, vcc_lo                    ; 02010183
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB130                                       ; bfa5004a
BB119:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[13:14], v[13:14]                ; 1a021b0d
(invalid instruction)                                        ; cc100005
	v_min_num_f64_e32 v[1:2], v[12:13], v[12:13]                ; 1a02190c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[0:1]                    ; 1a020105
(invalid instruction)                                        ; cc100014
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0004
	v_cndmask_b32_e32 v1, 0x400, v6, vcc_lo                     ; 02020cff 00000400
	v_mov_b32_dpp v14, v5 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1c02fa ff0d2805
(invalid instruction)                                        ; cc100015
	v_subrev_f32_e32 v0, v12, v255                              ; 0a01ff0c
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v13, v13, v20, s4                         ; d501000d 0012290d
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[14:15]                  ; 1a021d05
	v_cndmask_b32_e64 v12, v12, v21, s4                         ; d501000c 00122b0c
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e02fa ff0d6405
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[15:16]                  ; 1a021f05
	v_mov_b32_dpp v16, v5 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2002fa ff0c4e05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[16:17]                  ; 1a022105
	v_mov_b32_dpp v17, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2202fa ff0cb105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[17:18]                  ; 1a022305
(invalid instruction)                                        ; cc1c0005
	v_subrev_f32_e32 v0, v5, v255                               ; 0a01ff05
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v18, v5                                   ; 7e241705
	v_cvt_f32_f16_e32 v5, v133/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a1785
	v_rsq_f32_e32 v18, v18                                      ; 7e245d12
	v_rsq_f32_e32 v5, v5                                        ; 7e0a5d05
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v19, v18                                  ; 7e261512
(invalid instruction)                                        ; 7f261505
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[19:20]                ; 1a02270c
(invalid instruction)                                        ; cc10000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[19:20]                ; 1a02270d
	s_and_saveexec_b32 s4, s4                                   ; be842004
	s_cbranch_execz BB130                                       ; bfa5000f
BB120:
	s_load_b128 s[24:27], s[12:13], 0x30                        ; f4004606 f8000030
	v_add_lshl_u32 v0, s2, v7, 2                                ; d6470000 020a0e02
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v5, v0                                    ; 7e0a1500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000c
	v_subrev_f32_e32 v1, v12, v5                                ; 0a020b0c
(invalid instruction)                                        ; cc10000d
	v_subrev_f32_e32 v1, v13, v5                                ; 0a020b0d
BB130:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v17, v36                                  ; 7e221524
(invalid instruction)                                        ; 7f221525
	v_cvt_f16_f32_e32 v18, v44                                  ; 7e24152c
(invalid instruction)                                        ; 7f24152d
(invalid instruction)                                        ; cc1c000c
	v_subrev_f32_e32 v0, v12, v255                              ; 0a01ff0c
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b000c
	v_subrev_f32_e32 v0, v12, v255                              ; 0a01ff0c
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v12                                   ; 7e00170c
	v_cvt_f32_f16_e32 v12, v140/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e18178c
	v_cvt_f32_f16_e32 v14, v13                                  ; 7e1c170d
	v_cvt_f32_f16_e32 v13, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1a178d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                     ; 0201010c
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                     ; 0201010d
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB142                                       ; bfa5004a
BB131:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[18:19], v[18:19]                ; 1a022512
(invalid instruction)                                        ; cc10000d
	v_min_num_f64_e32 v[1:2], v[17:18], v[17:18]                ; 1a022311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[0:1]                  ; 1a02010d
(invalid instruction)                                        ; cc100018
	v_subrev_f32_e32 v0, v18, v255                              ; 0a01ff12
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0004
	v_cndmask_b32_e32 v1, 0x400, v6, vcc_lo                     ; 02020cff 00000400
	v_mov_b32_dpp v14, v13 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1c02fa ff0d280d
(invalid instruction)                                        ; cc100019
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v18, v18, v24, s4                         ; d5010012 00123112
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[14:15]                ; 1a021d0d
	v_cndmask_b32_e64 v17, v17, v25, s4                         ; d5010011 00123311
	v_mov_b32_dpp v19, v13 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2602fa ff0d640d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[19:20]                ; 1a02270d
	v_mov_b32_dpp v20, v13 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2802fa ff0c4e0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[20:21]                ; 1a02290d
	v_mov_b32_dpp v21, v13 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2a02fa ff0cb10d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[21:22]                ; 1a022b0d
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v22, v13                                  ; 7e2c170d
	v_cvt_f32_f16_e32 v13, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1a178d
	v_rsq_f32_e32 v22, v22                                      ; 7e2c5d16
	v_rsq_f32_e32 v13, v13                                      ; 7e1a5d0d
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v23, v22                                  ; 7e2e1516
(invalid instruction)                                        ; 7f2e150d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100011
	v_min_num_f64_e32 v[1:2], v[17:18], v[23:24]                ; 1a022f11
(invalid instruction)                                        ; cc100012
	v_min_num_f64_e32 v[1:2], v[18:19], v[23:24]                ; 1a022f12
	s_and_saveexec_b32 s4, s4                                   ; be842004
	s_cbranch_execz BB142                                       ; bfa5000f
BB132:
	s_load_b128 s[24:27], s[12:13], 0x30                        ; f4004606 f8000030
	v_add_lshl_u32 v0, s2, v7, 2                                ; d6470000 020a0e02
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v13, v0                                   ; 7e1a1500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100011
	v_subrev_f32_e32 v1, v17, v13                               ; 0a021b11
(invalid instruction)                                        ; cc100012
	v_subrev_f32_e32 v1, v18, v13                               ; 0a021b12
BB142:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v21, v38                                  ; 7e2a1526
(invalid instruction)                                        ; 7f2a1527
	v_cvt_f16_f32_e32 v22, v46                                  ; 7e2c152e
(invalid instruction)                                        ; 7f2c152f
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v255                              ; 0a01ff12
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b0012
	v_subrev_f32_e32 v0, v18, v255                              ; 0a01ff12
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v17                                   ; 7e001711
	v_cvt_f32_f16_e32 v17, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221791
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
	v_cvt_f32_f16_e32 v17, v18                                  ; 7e221712
	v_cvt_f32_f16_e32 v18, v146/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e241792
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                     ; 02010112
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB154                                       ; bfa50047
BB143:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[22:23], v[22:23]                ; 1a022d16
(invalid instruction)                                        ; cc100011
	v_min_num_f64_e32 v[1:2], v[21:22], v[21:22]                ; 1a022b15
(invalid instruction)                                        ; cc100020
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 000045a8
	v_cmp_gt_u32_e32 vcc_lo, 0x400, v6                          ; 7c980cff 00000400
(invalid instruction)                                        ; cc100021
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 000045a8
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[0:1]                  ; 1a020111
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_dual_cndmask_b32 v21, v21, v33 :: v_dual_cndmask_b32 v22, v22, v32 ; ca524315 15164116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_mov_b32_dpp v18, v17 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2402fa ff0d2811
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[18:19]                ; 1a022511
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v23, v17 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2e02fa ff0d6411
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[23:24]                ; 1a022f11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v24, v17 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3002fa ff0c4e11
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[24:25]                ; 1a023111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v25, v17 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3202fa ff0cb111
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[25:26]                ; 1a023311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 00000410
	v_cvt_f32_f16_e32 v28, v17                                  ; 7e381711
	v_cvt_f32_f16_e32 v17, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221791
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v28, v28                                      ; 7e385d1c
	v_rsq_f32_e32 v17, v17                                      ; 7e225d11
	v_cvt_f16_f32_e32 v30, v28                                  ; 7e3c151c
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
(invalid instruction)                                        ; 7f3c1511
(invalid instruction)                                        ; cc100015
	v_min_num_f64_e32 v[1:2], v[21:22], v[30:31]                ; 1a023d15
(invalid instruction)                                        ; cc100016
	v_min_num_f64_e32 v[1:2], v[22:23], v[30:31]                ; 1a023d16
	s_and_saveexec_b32 s4, vcc_lo                               ; be84206a
	s_cbranch_execz BB154                                       ; bfa5000f
BB144:
	s_load_b128 s[24:27], s[12:13], 0x30                        ; f4004606 f8000030
	v_add_lshl_u32 v0, s2, v7, 2                                ; d6470000 020a0e02
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v17, v0                                   ; 7e221500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100015
	v_subrev_f32_e32 v1, v21, v17                               ; 0a022315
(invalid instruction)                                        ; cc100016
	v_subrev_f32_e32 v1, v22, v17                               ; 0a022316
BB154:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_lshrrev_b32_e32 v25, 4, v6                                ; 32320c84
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_add_lshl_u32 v25, s1, v25, 8                              ; d6470019 02223201
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 00005f00
	v_add_nc_u32_e32 v25, s3, v25                               ; 4a323203
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v21                                   ; 7e001715
	v_cvt_f32_f16_e32 v21, v149/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2a1795
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add3_u32 v28, v26, v25, v27                               ; d655001c 046e331a
	v_add3_u32 v30, v26, v25, v29                               ; d655001e 0476331a
	v_add3_u32 v32, v26, v25, v31                               ; d6550020 047e331a
	v_add3_u32 v33, v26, v25, v113                              ; d6550021 05c6331a
	v_add3_u32 v34, v26, v25, v115                              ; d6550022 05ce331a
	v_add3_u32 v35, v26, v25, v117                              ; d6550023 05d6331a
	v_add3_u32 v36, v26, v25, v119                              ; d6550024 05de331a
	v_add3_u32 v37, v26, v25, v121                              ; d6550025 05e6331a
	v_add_nc_u32_e32 v25, 0x100, v25                            ; 4a3232ff 00000100
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
	v_cvt_f32_f16_e32 v21, v22                                  ; 7e2a1716
	v_cvt_f32_f16_e32 v22, v150/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2c1796
	v_add3_u32 v38, v26, v25, v27                               ; d6550026 046e331a
	v_add3_u32 v39, v26, v25, v29                               ; d6550027 0476331a
	v_add3_u32 v40, v26, v25, v31                               ; d6550028 047e331a
	v_add3_u32 v41, v26, v25, v113                              ; d6550029 05c6331a
	v_add3_u32 v42, v26, v25, v115                              ; d655002a 05ce331a
	v_add3_u32 v43, v26, v25, v117                              ; d655002b 05d6331a
	v_add3_u32 v44, v26, v25, v119                              ; d655002c 05de331a
	v_add3_u32 v25, v26, v25, v121                              ; d6550019 05e6331a
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v0, v22, v128, vcc_lo                     ; 02010116
	s_clause 0xf                                                ; bf85000f
	buffer_store_b8 v3, v28, s[20:23], null offen               ; c406007c 40802803 0000001c
	buffer_store_b8 v4, v30, s[20:23], null offen               ; c406007c 40802804 0000001e
	buffer_store_b8 v5, v32, s[20:23], null offen               ; c406007c 40802805 00000020
	buffer_store_b8 v12, v33, s[20:23], null offen              ; c406007c 4080280c 00000021
	buffer_store_b8 v13, v34, s[20:23], null offen              ; c406007c 4080280d 00000022
	buffer_store_b8 v14, v35, s[20:23], null offen              ; c406007c 4080280e 00000023
	buffer_store_b8 v17, v36, s[20:23], null offen              ; c406007c 40802811 00000024
	buffer_store_b8 v18, v37, s[20:23], null offen              ; c406007c 40802812 00000025
	buffer_store_b8 v8, v38, s[20:23], null offen               ; c406007c 40802808 00000026
	buffer_store_b8 v11, v39, s[20:23], null offen              ; c406007c 4080280b 00000027
	buffer_store_b8 v15, v40, s[20:23], null offen              ; c406007c 4080280f 00000028
	buffer_store_b8 v16, v41, s[20:23], null offen              ; c406007c 40802810 00000029
	buffer_store_b8 v19, v42, s[20:23], null offen              ; c406007c 40802813 0000002a
	buffer_store_b8 v20, v43, s[20:23], null offen              ; c406007c 40802814 0000002b
	buffer_store_b8 v23, v44, s[20:23], null offen              ; c406007c 40802817 0000002c
	buffer_store_b8 v24, v25, s[20:23], null offen              ; c406007c 40802818 00000019
	v_cvt_f16_f32_e32 v45, v48                                  ; 7e5a1530
(invalid instruction)                                        ; 7f5a1531
	v_cvt_f16_f32_e32 v46, v56                                  ; 7e5c1538
(invalid instruction)                                        ; 7f5c1539
	v_cmpx_gt_u32_e32 0x800, v9                                 ; 7d9812ff 00000800
	s_mov_b32 vcc_lo, exec_lo                                   ; beea007e
	s_cbranch_execz BB166                                       ; bfa5004a
BB155:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[46:47], v[46:47]                ; 1a025d2e
(invalid instruction)                                        ; cc100003
	v_min_num_f64_e32 v[1:2], v[45:46], v[45:46]                ; 1a025b2d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[0:1]                    ; 1a020103
(invalid instruction)                                        ; cc10000e
	v_subrev_f32_e32 v0, v46, v255                              ; 0a01ff2e
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0004
	v_cndmask_b32_e32 v1, 0x400, v9, vcc_lo                     ; 020212ff 00000400
	v_mov_b32_dpp v4, v3 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0802fa ff0d2803
(invalid instruction)                                        ; cc10000f
	v_subrev_f32_e32 v0, v45, v255                              ; 0a01ff2d
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v46, v46, v14, s4                         ; d501002e 00121d2e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[4:5]                    ; 1a020903
	v_cndmask_b32_e64 v45, v45, v15, s4                         ; d501002d 00121f2d
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0a02fa ff0d6403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[5:6]                    ; 1a020b03
	v_mov_b32_dpp v8, v3 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1002fa ff0c4e03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[8:9]                    ; 1a021103
	v_mov_b32_dpp v11, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1602fa ff0cb103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[11:12]                  ; 1a021703
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v12, v3                                   ; 7e181703
	v_cvt_f32_f16_e32 v3, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e061783
	v_rsq_f32_e32 v12, v12                                      ; 7e185d0c
	v_rsq_f32_e32 v3, v3                                        ; 7e065d03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v13, v12                                  ; 7e1a150c
(invalid instruction)                                        ; 7f1a1503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[13:14]                ; 1a021b2d
(invalid instruction)                                        ; cc10002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[13:14]                ; 1a021b2e
	s_and_saveexec_b32 s4, s4                                   ; be842004
	s_cbranch_execz BB166                                       ; bfa5000f
BB156:
	s_load_b128 s[24:27], s[12:13], 0x30                        ; f4004606 f8000030
	v_add_lshl_u32 v0, s2, v10, 2                               ; d6470000 020a1402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v3, v0                                    ; 7e061500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10002d
	v_subrev_f32_e32 v1, v45, v3                                ; 0a02072d
(invalid instruction)                                        ; cc10002e
	v_subrev_f32_e32 v1, v46, v3                                ; 0a02072e
BB166:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v12, v50                                  ; 7e181532
(invalid instruction)                                        ; 7f181533
	v_cvt_f16_f32_e32 v13, v58                                  ; 7e1a153a
(invalid instruction)                                        ; 7f1a153b
(invalid instruction)                                        ; cc1c002d
	v_subrev_f32_e32 v0, v45, v255                              ; 0a01ff2d
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c002e
	v_subrev_f32_e32 v0, v46, v255                              ; 0a01ff2e
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b002d
	v_subrev_f32_e32 v0, v45, v255                              ; 0a01ff2d
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b002e
	v_subrev_f32_e32 v0, v46, v255                              ; 0a01ff2e
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v45                                   ; 7e00172d
	v_cvt_f32_f16_e32 v45, v173/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e5a17ad
	v_cvt_f32_f16_e32 v5, v46                                   ; 7e0a172e
	v_cvt_f32_f16_e32 v46, v174/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e5c17ae
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v0, v45, v128, vcc_lo                     ; 0201012d
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v0, v5, v128, vcc_lo                      ; 02010105
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB178                                       ; bfa5004a
BB167:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[13:14], v[13:14]                ; 1a021b0d
(invalid instruction)                                        ; cc100005
	v_min_num_f64_e32 v[1:2], v[12:13], v[12:13]                ; 1a02190c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[0:1]                    ; 1a020105
(invalid instruction)                                        ; cc100014
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0004
	v_cndmask_b32_e32 v1, 0x400, v9, vcc_lo                     ; 020212ff 00000400
	v_mov_b32_dpp v14, v5 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1c02fa ff0d2805
(invalid instruction)                                        ; cc100015
	v_subrev_f32_e32 v0, v12, v255                              ; 0a01ff0c
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v13, v13, v20, s4                         ; d501000d 0012290d
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[14:15]                  ; 1a021d05
	v_cndmask_b32_e64 v12, v12, v21, s4                         ; d501000c 00122b0c
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e02fa ff0d6405
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[15:16]                  ; 1a021f05
	v_mov_b32_dpp v16, v5 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2002fa ff0c4e05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[16:17]                  ; 1a022105
	v_mov_b32_dpp v17, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2202fa ff0cb105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[17:18]                  ; 1a022305
(invalid instruction)                                        ; cc1c0005
	v_subrev_f32_e32 v0, v5, v255                               ; 0a01ff05
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v18, v5                                   ; 7e241705
	v_cvt_f32_f16_e32 v5, v133/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a1785
	v_rsq_f32_e32 v18, v18                                      ; 7e245d12
	v_rsq_f32_e32 v5, v5                                        ; 7e0a5d05
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v19, v18                                  ; 7e261512
(invalid instruction)                                        ; 7f261505
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000c
	v_min_num_f64_e32 v[1:2], v[12:13], v[19:20]                ; 1a02270c
(invalid instruction)                                        ; cc10000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[19:20]                ; 1a02270d
	s_and_saveexec_b32 s4, s4                                   ; be842004
	s_cbranch_execz BB178                                       ; bfa5000f
BB168:
	s_load_b128 s[24:27], s[12:13], 0x30                        ; f4004606 f8000030
	v_add_lshl_u32 v0, s2, v10, 2                               ; d6470000 020a1402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v5, v0                                    ; 7e0a1500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000c
	v_subrev_f32_e32 v1, v12, v5                                ; 0a020b0c
(invalid instruction)                                        ; cc10000d
	v_subrev_f32_e32 v1, v13, v5                                ; 0a020b0d
BB178:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v17, v52                                  ; 7e221534
(invalid instruction)                                        ; 7f221535
	v_cvt_f16_f32_e32 v18, v60                                  ; 7e24153c
(invalid instruction)                                        ; 7f24153d
(invalid instruction)                                        ; cc1c000c
	v_subrev_f32_e32 v0, v12, v255                              ; 0a01ff0c
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b000c
	v_subrev_f32_e32 v0, v12, v255                              ; 0a01ff0c
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v12                                   ; 7e00170c
	v_cvt_f32_f16_e32 v12, v140/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e18178c
	v_cvt_f32_f16_e32 v14, v13                                  ; 7e1c170d
	v_cvt_f32_f16_e32 v13, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1a178d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                     ; 0201010c
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                     ; 0201010d
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB190                                       ; bfa5004a
BB179:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[18:19], v[18:19]                ; 1a022512
(invalid instruction)                                        ; cc10000d
	v_min_num_f64_e32 v[1:2], v[17:18], v[17:18]                ; 1a022311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[0:1]                  ; 1a02010d
(invalid instruction)                                        ; cc100018
	v_subrev_f32_e32 v0, v18, v255                              ; 0a01ff12
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0004
	v_cndmask_b32_e32 v1, 0x400, v9, vcc_lo                     ; 020212ff 00000400
	v_mov_b32_dpp v14, v13 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1c02fa ff0d280d
(invalid instruction)                                        ; cc100019
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v18, v18, v24, s4                         ; d5010012 00123112
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[14:15]                ; 1a021d0d
	v_cndmask_b32_e64 v17, v17, v25, s4                         ; d5010011 00123311
	v_mov_b32_dpp v19, v13 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2602fa ff0d640d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[19:20]                ; 1a02270d
	v_mov_b32_dpp v20, v13 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2802fa ff0c4e0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[20:21]                ; 1a02290d
	v_mov_b32_dpp v21, v13 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2a02fa ff0cb10d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[21:22]                ; 1a022b0d
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v22, v13                                  ; 7e2c170d
	v_cvt_f32_f16_e32 v13, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1a178d
	v_rsq_f32_e32 v22, v22                                      ; 7e2c5d16
	v_rsq_f32_e32 v13, v13                                      ; 7e1a5d0d
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v23, v22                                  ; 7e2e1516
(invalid instruction)                                        ; 7f2e150d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100011
	v_min_num_f64_e32 v[1:2], v[17:18], v[23:24]                ; 1a022f11
(invalid instruction)                                        ; cc100012
	v_min_num_f64_e32 v[1:2], v[18:19], v[23:24]                ; 1a022f12
	s_and_saveexec_b32 s4, s4                                   ; be842004
	s_cbranch_execz BB190                                       ; bfa5000f
BB180:
	s_load_b128 s[24:27], s[12:13], 0x30                        ; f4004606 f8000030
	v_add_lshl_u32 v0, s2, v10, 2                               ; d6470000 020a1402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v13, v0                                   ; 7e1a1500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100011
	v_subrev_f32_e32 v1, v17, v13                               ; 0a021b11
(invalid instruction)                                        ; cc100012
	v_subrev_f32_e32 v1, v18, v13                               ; 0a021b12
BB190:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v21, v54                                  ; 7e2a1536
(invalid instruction)                                        ; 7f2a1537
	v_cvt_f16_f32_e32 v22, v62                                  ; 7e2c153e
(invalid instruction)                                        ; 7f2c153f
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v255                              ; 0a01ff12
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b0012
	v_subrev_f32_e32 v0, v18, v255                              ; 0a01ff12
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v17                                   ; 7e001711
	v_cvt_f32_f16_e32 v17, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221791
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
	v_cvt_f32_f16_e32 v17, v18                                  ; 7e221712
	v_cvt_f32_f16_e32 v18, v146/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e241792
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                     ; 02010112
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB202                                       ; bfa50047
BB191:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[22:23], v[22:23]                ; 1a022d16
(invalid instruction)                                        ; cc100011
	v_min_num_f64_e32 v[1:2], v[21:22], v[21:22]                ; 1a022b15
(invalid instruction)                                        ; cc100020
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 000045a8
	v_cmp_gt_u32_e32 vcc_lo, 0x400, v9                          ; 7c9812ff 00000400
(invalid instruction)                                        ; cc100021
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 000045a8
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[0:1]                  ; 1a020111
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_dual_cndmask_b32 v21, v21, v33 :: v_dual_cndmask_b32 v22, v22, v32 ; ca524315 15164116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_mov_b32_dpp v18, v17 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2402fa ff0d2811
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[18:19]                ; 1a022511
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v23, v17 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2e02fa ff0d6411
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[23:24]                ; 1a022f11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v24, v17 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3002fa ff0c4e11
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[24:25]                ; 1a023111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v25, v17 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3202fa ff0cb111
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[25:26]                ; 1a023311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 00000410
	v_cvt_f32_f16_e32 v28, v17                                  ; 7e381711
	v_cvt_f32_f16_e32 v17, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221791
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v28, v28                                      ; 7e385d1c
	v_rsq_f32_e32 v17, v17                                      ; 7e225d11
	v_cvt_f16_f32_e32 v30, v28                                  ; 7e3c151c
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
(invalid instruction)                                        ; 7f3c1511
(invalid instruction)                                        ; cc100015
	v_min_num_f64_e32 v[1:2], v[21:22], v[30:31]                ; 1a023d15
(invalid instruction)                                        ; cc100016
	v_min_num_f64_e32 v[1:2], v[22:23], v[30:31]                ; 1a023d16
	s_and_saveexec_b32 s4, vcc_lo                               ; be84206a
	s_cbranch_execz BB202                                       ; bfa5000f
BB192:
	s_load_b128 s[24:27], s[12:13], 0x30                        ; f4004606 f8000030
	v_add_lshl_u32 v0, s2, v10, 2                               ; d6470000 020a1402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v17, v0                                   ; 7e221500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100015
	v_subrev_f32_e32 v1, v21, v17                               ; 0a022315
(invalid instruction)                                        ; cc100016
	v_subrev_f32_e32 v1, v22, v17                               ; 0a022316
BB202:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_lshrrev_b32_e32 v25, 4, v9                                ; 32321284
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_add_lshl_u32 v25, s1, v25, 8                              ; d6470019 02223201
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 00005f00
	v_add_nc_u32_e32 v25, s3, v25                               ; 4a323203
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v21                                   ; 7e001715
	v_cvt_f32_f16_e32 v21, v149/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2a1795
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add3_u32 v28, v26, v25, v27                               ; d655001c 046e331a
	v_add3_u32 v30, v26, v25, v29                               ; d655001e 0476331a
	v_add3_u32 v32, v26, v25, v31                               ; d6550020 047e331a
	v_add3_u32 v33, v26, v25, v113                              ; d6550021 05c6331a
	v_add3_u32 v34, v26, v25, v115                              ; d6550022 05ce331a
	v_add3_u32 v35, v26, v25, v117                              ; d6550023 05d6331a
	v_add3_u32 v36, v26, v25, v119                              ; d6550024 05de331a
	v_add3_u32 v37, v26, v25, v121                              ; d6550025 05e6331a
	v_add_nc_u32_e32 v25, 0x100, v25                            ; 4a3232ff 00000100
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
	v_cvt_f32_f16_e32 v21, v22                                  ; 7e2a1716
	v_cvt_f32_f16_e32 v22, v150/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2c1796
	v_add3_u32 v27, v26, v25, v27                               ; d655001b 046e331a
	v_add3_u32 v29, v26, v25, v29                               ; d655001d 0476331a
	v_add3_u32 v31, v26, v25, v31                               ; d655001f 047e331a
	v_add3_u32 v113, v26, v25, v113                             ; d6550071 05c6331a
	v_add3_u32 v115, v26, v25, v115                             ; d6550073 05ce331a
	v_add3_u32 v117, v26, v25, v117                             ; d6550075 05d6331a
	v_add3_u32 v119, v26, v25, v119                             ; d6550077 05de331a
	v_add3_u32 v26, v26, v25, v121                              ; d655001a 05e6331a
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v0, v22, v128, vcc_lo                     ; 02010116
	s_clause 0xf                                                ; bf85000f
	buffer_store_b8 v3, v28, s[20:23], null offen               ; c406007c 40802803 0000001c
	buffer_store_b8 v4, v30, s[20:23], null offen               ; c406007c 40802804 0000001e
	buffer_store_b8 v5, v32, s[20:23], null offen               ; c406007c 40802805 00000020
	buffer_store_b8 v12, v33, s[20:23], null offen              ; c406007c 4080280c 00000021
	buffer_store_b8 v13, v34, s[20:23], null offen              ; c406007c 4080280d 00000022
	buffer_store_b8 v14, v35, s[20:23], null offen              ; c406007c 4080280e 00000023
	buffer_store_b8 v17, v36, s[20:23], null offen              ; c406007c 40802811 00000024
	buffer_store_b8 v18, v37, s[20:23], null offen              ; c406007c 40802812 00000025
	buffer_store_b8 v8, v27, s[20:23], null offen               ; c406007c 40802808 0000001b
	buffer_store_b8 v11, v29, s[20:23], null offen              ; c406007c 4080280b 0000001d
	buffer_store_b8 v15, v31, s[20:23], null offen              ; c406007c 4080280f 0000001f
	buffer_store_b8 v16, v113, s[20:23], null offen             ; c406007c 40802810 00000071
	buffer_store_b8 v19, v115, s[20:23], null offen             ; c406007c 40802813 00000073
	buffer_store_b8 v20, v117, s[20:23], null offen             ; c406007c 40802814 00000075
	buffer_store_b8 v23, v119, s[20:23], null offen             ; c406007c 40802817 00000077
	buffer_store_b8 v24, v26, s[20:23], null offen              ; c406007c 40802818 0000001a
BB204:
	s_cmp_lt_u32 s11, s5                                        ; bf0a050b
	s_cbranch_scc0 BB351                                        ; bfa10629
BB205:
	v_cvt_f16_f32_e32 v0, v64                                   ; 7e001540
(invalid instruction)                                        ; 7f001541
	v_cvt_f16_f32_e32 v3, v72                                   ; 7e061548
(invalid instruction)                                        ; 7f061549
	v_cmpx_gt_u32_e32 0x800, v1                                 ; 7d9802ff 00000800
	s_mov_b32 vcc_lo, exec_lo                                   ; beea007e
	s_cbranch_execz BB217                                       ; bfa5004c
BB206:
(invalid instruction)                                        ; cc100004
	v_min_num_f64_e32 v[1:2], v[3:4], v[3:4]                    ; 1a020703
(invalid instruction)                                        ; cc100005
	v_min_num_f64_e32 v[1:2], v[0:1], v[0:1]                    ; 1a020100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[4:5]                    ; 1a020905
(invalid instruction)                                        ; cc100010
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                     ; 020202ff 00000400
	v_mov_b32_dpp v8, v5 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1002fa ff0d2805
(invalid instruction)                                        ; cc100011
	v_subrev_f32_e32 v0, v0, v255                               ; 0a01ff00
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v3, v3, v16, s1                           ; d5010003 00062103
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[8:9]                    ; 1a021105
	v_cndmask_b32_e64 v0, v0, v17, s1                           ; d5010000 00062300
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1602fa ff0d6405
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[11:12]                  ; 1a021705
	v_mov_b32_dpp v12, v5 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1802fa ff0c4e05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[12:13]                  ; 1a021905
	v_mov_b32_dpp v13, v5 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a02fa ff0cb105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[13:14]                  ; 1a021b05
(invalid instruction)                                        ; cc1c0005
	v_subrev_f32_e32 v0, v5, v255                               ; 0a01ff05
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v14, v5                                   ; 7e1c1705
	v_cvt_f32_f16_e32 v5, v133/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a1785
	v_rsq_f32_e32 v14, v14                                      ; 7e1c5d0e
	v_rsq_f32_e32 v5, v5                                        ; 7e0a5d05
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v15, v14                                  ; 7e1e150e
(invalid instruction)                                        ; 7f1e1505
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[0:1], v[15:16]                  ; 1a021f00
(invalid instruction)                                        ; cc100003
	v_min_num_f64_e32 v[1:2], v[3:4], v[15:16]                  ; 1a021f03
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB217                                       ; bfa50011
BB207:
	s_mov_b32 s4, s0                                            ; be840000
	s_movk_i32 s5, 0x8000                                       ; b0058000
	s_load_b128 s[20:23], s[4:5], 0x30                          ; f4004502 f8000030
	v_add_lshl_u32 v4, s2, v2, 2                                ; d6470004 020a0402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v4, v4, s[20:23], null offen                ; c405007c 40802804 00000004
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v5, v4                                    ; 7e0a1504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100000
	v_subrev_f32_e32 v1, v0, v5                                 ; 0a020b00
(invalid instruction)                                        ; cc100003
	v_subrev_f32_e32 v1, v3, v5                                 ; 0a020b03
BB217:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v14, v66                                  ; 7e1c1542
(invalid instruction)                                        ; 7f1c1543
	v_cvt_f16_f32_e32 v15, v74                                  ; 7e1e154a
(invalid instruction)                                        ; 7f1e154b
(invalid instruction)                                        ; cc1c0000
	v_subrev_f32_e32 v0, v0, v255                               ; 0a01ff00
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b0000
	v_subrev_f32_e32 v0, v0, v255                               ; 0a01ff00
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b0003
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v4, v0                                    ; 7e081700
	v_cvt_f32_f16_e32 v0, v128/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e001780
	v_cvt_f32_f16_e32 v11, v3                                   ; 7e161703
	v_cvt_f32_f16_e32 v3, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e061783
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v0, v4, v128, vcc_lo                      ; 02010104
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v0, v3, v128, vcc_lo                      ; 02010103
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB229                                       ; bfa5004c
BB218:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[15:16], v[15:16]                ; 1a021f0f
(invalid instruction)                                        ; cc100003
	v_min_num_f64_e32 v[1:2], v[14:15], v[14:15]                ; 1a021d0e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[0:1]                    ; 1a020103
(invalid instruction)                                        ; cc100014
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                     ; 020202ff 00000400
	v_mov_b32_dpp v4, v3 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0802fa ff0d2803
(invalid instruction)                                        ; cc100015
	v_subrev_f32_e32 v0, v14, v255                              ; 0a01ff0e
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v15, v15, v20, s1                         ; d501000f 0006290f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[4:5]                    ; 1a020903
	v_cndmask_b32_e64 v14, v14, v21, s1                         ; d501000e 00062b0e
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1602fa ff0d6403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[11:12]                  ; 1a021703
	v_mov_b32_dpp v16, v3 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2002fa ff0c4e03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[16:17]                  ; 1a022103
	v_mov_b32_dpp v17, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2202fa ff0cb103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[17:18]                  ; 1a022303
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v18, v3                                   ; 7e241703
	v_cvt_f32_f16_e32 v3, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e061783
	v_rsq_f32_e32 v18, v18                                      ; 7e245d12
	v_rsq_f32_e32 v3, v3                                        ; 7e065d03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v19, v18                                  ; 7e261512
(invalid instruction)                                        ; 7f261503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[19:20]                ; 1a02270e
(invalid instruction)                                        ; cc10000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[19:20]                ; 1a02270f
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB229                                       ; bfa50011
BB219:
	s_mov_b32 s4, s0                                            ; be840000
	s_movk_i32 s5, 0x8000                                       ; b0058000
	s_load_b128 s[20:23], s[4:5], 0x30                          ; f4004502 f8000030
	v_add_lshl_u32 v0, s2, v2, 2                                ; d6470000 020a0402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[20:23], null offen                ; c405007c 40802800 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v3, v0                                    ; 7e061500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000e
	v_subrev_f32_e32 v1, v14, v3                                ; 0a02070e
(invalid instruction)                                        ; cc10000f
	v_subrev_f32_e32 v1, v15, v3                                ; 0a02070f
BB229:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v16, v68                                  ; 7e201544
(invalid instruction)                                        ; 7f201545
	v_cvt_f16_f32_e32 v17, v76                                  ; 7e22154c
(invalid instruction)                                        ; 7f22154d
(invalid instruction)                                        ; cc1c000e
	v_subrev_f32_e32 v0, v14, v255                              ; 0a01ff0e
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c000f
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b000e
	v_subrev_f32_e32 v0, v14, v255                              ; 0a01ff0e
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b000f
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v14                                   ; 7e00170e
	v_cvt_f32_f16_e32 v14, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1c178e
	v_cvt_f32_f16_e32 v11, v15                                  ; 7e16170f
	v_cvt_f32_f16_e32 v15, v143/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e178f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v15, v128, vcc_lo                     ; 0201010f
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB241                                       ; bfa5004c
BB230:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[17:18], v[17:18]                ; 1a022311
(invalid instruction)                                        ; cc10000b
	v_min_num_f64_e32 v[1:2], v[16:17], v[16:17]                ; 1a022110
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[0:1]                  ; 1a02010b
(invalid instruction)                                        ; cc100018
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                     ; 020202ff 00000400
	v_mov_b32_dpp v18, v11 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2402fa ff0d280b
(invalid instruction)                                        ; cc100019
	v_subrev_f32_e32 v0, v16, v255                              ; 0a01ff10
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v17, v17, v24, s1                         ; d5010011 00063111
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[18:19]                ; 1a02250b
	v_cndmask_b32_e64 v16, v16, v25, s1                         ; d5010010 00063310
	v_mov_b32_dpp v19, v11 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2602fa ff0d640b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[19:20]                ; 1a02270b
	v_mov_b32_dpp v20, v11 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2802fa ff0c4e0b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[20:21]                ; 1a02290b
	v_mov_b32_dpp v21, v11 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2a02fa ff0cb10b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[21:22]                ; 1a022b0b
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v255                              ; 0a01ff0b
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v22, v11                                  ; 7e2c170b
	v_cvt_f32_f16_e32 v11, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e16178b
	v_rsq_f32_e32 v22, v22                                      ; 7e2c5d16
	v_rsq_f32_e32 v11, v11                                      ; 7e165d0b
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v23, v22                                  ; 7e2e1516
(invalid instruction)                                        ; 7f2e150b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100010
	v_min_num_f64_e32 v[1:2], v[16:17], v[23:24]                ; 1a022f10
(invalid instruction)                                        ; cc100011
	v_min_num_f64_e32 v[1:2], v[17:18], v[23:24]                ; 1a022f11
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB241                                       ; bfa50011
BB231:
	s_mov_b32 s4, s0                                            ; be840000
	s_movk_i32 s5, 0x8000                                       ; b0058000
	s_load_b128 s[20:23], s[4:5], 0x30                          ; f4004502 f8000030
	v_add_lshl_u32 v0, s2, v2, 2                                ; d6470000 020a0402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[20:23], null offen                ; c405007c 40802800 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v11, v0                                   ; 7e161500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100010
	v_subrev_f32_e32 v1, v16, v11                               ; 0a021710
(invalid instruction)                                        ; cc100011
	v_subrev_f32_e32 v1, v17, v11                               ; 0a021711
BB241:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v21, v70                                  ; 7e2a1546
(invalid instruction)                                        ; 7f2a1547
	v_cvt_f16_f32_e32 v22, v78                                  ; 7e2c154e
(invalid instruction)                                        ; 7f2c154f
(invalid instruction)                                        ; cc1c0010
	v_subrev_f32_e32 v0, v16, v255                              ; 0a01ff10
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b0010
	v_subrev_f32_e32 v0, v16, v255                              ; 0a01ff10
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v16                                   ; 7e001710
	v_cvt_f32_f16_e32 v16, v144/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e201790
	v_cvt_f32_f16_e32 v18, v17                                  ; 7e241711
	v_cvt_f32_f16_e32 v17, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221791
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                     ; 02010112
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB253                                       ; bfa50049
BB242:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[22:23], v[22:23]                ; 1a022d16
(invalid instruction)                                        ; cc100011
	v_min_num_f64_e32 v[1:2], v[21:22], v[21:22]                ; 1a022b15
(invalid instruction)                                        ; cc10001c
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 000045a8
	v_cmp_gt_u32_e32 vcc_lo, 0x400, v1                          ; 7c9802ff 00000400
(invalid instruction)                                        ; cc10001d
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 000045a8
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[0:1]                  ; 1a020111
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_dual_cndmask_b32 v21, v21, v29 :: v_dual_cndmask_b32 v22, v22, v28 ; ca523b15 15163916
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_mov_b32_dpp v18, v17 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2402fa ff0d2811
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[18:19]                ; 1a022511
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v23, v17 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2e02fa ff0d6411
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[23:24]                ; 1a022f11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v24, v17 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3002fa ff0c4e11
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[24:25]                ; 1a023111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v25, v17 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3202fa ff0cb111
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[25:26]                ; 1a023311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 00000410
	v_cvt_f32_f16_e32 v26, v17                                  ; 7e341711
	v_cvt_f32_f16_e32 v17, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221791
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v26, v26                                      ; 7e345d1a
	v_rsq_f32_e32 v17, v17                                      ; 7e225d11
	v_cvt_f16_f32_e32 v27, v26                                  ; 7e36151a
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
(invalid instruction)                                        ; 7f361511
(invalid instruction)                                        ; cc100015
	v_min_num_f64_e32 v[1:2], v[21:22], v[27:28]                ; 1a023715
(invalid instruction)                                        ; cc100016
	v_min_num_f64_e32 v[1:2], v[22:23], v[27:28]                ; 1a023716
	s_and_saveexec_b32 s1, vcc_lo                               ; be81206a
	s_cbranch_execz BB253                                       ; bfa50011
BB243:
	s_mov_b32 s4, s0                                            ; be840000
	s_movk_i32 s5, 0x8000                                       ; b0058000
	s_load_b128 s[20:23], s[4:5], 0x30                          ; f4004502 f8000030
	v_add_lshl_u32 v2, s2, v2, 2                                ; d6470002 020a0402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v2, v2, s[20:23], null offen                ; c405007c 40802802 00000002
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v0, v2                                    ; 7e001502
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100015
	v_subrev_f32_e32 v1, v21, v0                                ; 0a020115
(invalid instruction)                                        ; cc100016
	v_subrev_f32_e32 v1, v22, v0                                ; 0a020116
BB253:
	s_mov_b32 s4, s0                                            ; be840000
	s_movk_i32 s5, 0x8000                                       ; b0058000
	s_load_b128 s[20:23], s[4:5], 0x10                          ; f4004502 f8000010
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_lshr_b32 s6, s6, 4                                        ; 85068406
(invalid instruction)                                        ; cc1c0015
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 0000df00
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
(invalid instruction)                                        ; d71f0017
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_mul_i32 s14, s14, s6                                      ; 960e060e
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; cc1b0015
	v_subrev_f32_e32 v0, v21, v255                              ; 0a01ff15
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 0000df00
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v1, s14, v1, 8                               ; d6470001 0222020e
	v_lshrrev_b32_e32 v24, 4, v23                               ; 32302e84
	v_and_b32_e32 v23, 15, v23                                  ; 362e2e8f
	v_cvt_f32_f16_e32 v0, v21                                   ; 7e001715
	v_cvt_f32_f16_e32 v21, v149/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2a1795
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v255                              ; 0a01ff16
(invalid instruction)                                        ; 00005f00
	v_add_nc_u32_e32 v1, s3, v1                                 ; 4a020203
	v_lshlrev_b32_e32 v24, 7, v24                               ; 30303087
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
	v_cvt_f32_f16_e32 v18, v22                                  ; 7e241716
	v_cvt_f32_f16_e32 v22, v150/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2c1796
	v_add_nc_u32_e32 v32, 64, v24                               ; 4a4030c0
	v_add_nc_u32_e32 v34, 0x50, v24                             ; 4a4430ff 00000050
	v_add_nc_u32_e32 v36, 0x60, v24                             ; 4a4830ff 00000060
	v_add3_u32 v25, v23, v1, v24                                ; d6550019 04620317
	v_add_nc_u32_e32 v38, 0x70, v24                             ; 4a4c30ff 00000070
	v_add_nc_u32_e32 v26, 16, v24                               ; 4a343090
	v_add_nc_u32_e32 v28, 32, v24                               ; 4a3830a0
	v_add_nc_u32_e32 v30, 48, v24                               ; 4a3c30b0
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                     ; 02010112
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v0, v22, v128, vcc_lo                     ; 02010116
	v_add3_u32 v33, v23, v1, v32                                ; d6550021 04820317
	v_add3_u32 v35, v23, v1, v34                                ; d6550023 048a0317
	v_add3_u32 v37, v23, v1, v36                                ; d6550025 04920317
	v_add3_u32 v39, v23, v1, v38                                ; d6550027 049a0317
	v_add3_u32 v27, v23, v1, v26                                ; d655001b 046a0317
	v_add3_u32 v29, v23, v1, v28                                ; d655001d 04720317
	v_add3_u32 v31, v23, v1, v30                                ; d655001f 047a0317
	v_add_nc_u32_e32 v1, 0x100, v1                              ; 4a0202ff 00000100
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v40, v23, v1, v24                                ; d6550028 04620317
	v_add3_u32 v41, v23, v1, v26                                ; d6550029 046a0317
	v_add3_u32 v42, v23, v1, v28                                ; d655002a 04720317
	v_add3_u32 v46, v23, v1, v36                                ; d655002e 04920317
	v_add3_u32 v43, v23, v1, v30                                ; d655002b 047a0317
	v_add3_u32 v44, v23, v1, v32                                ; d655002c 04820317
	v_add3_u32 v45, v23, v1, v34                                ; d655002d 048a0317
	v_add3_u32 v1, v23, v1, v38                                 ; d6550001 049a0317
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0xf                                                ; bf85000f
	buffer_store_b8 v5, v25, s[20:23], null offen               ; c406007c 40802805 00000019
	buffer_store_b8 v8, v27, s[20:23], null offen               ; c406007c 40802808 0000001b
	buffer_store_b8 v3, v29, s[20:23], null offen               ; c406007c 40802803 0000001d
	buffer_store_b8 v4, v31, s[20:23], null offen               ; c406007c 40802804 0000001f
	buffer_store_b8 v11, v33, s[20:23], null offen              ; c406007c 4080280b 00000021
	buffer_store_b8 v16, v35, s[20:23], null offen              ; c406007c 40802810 00000023
	buffer_store_b8 v2, v37, s[20:23], null offen               ; c406007c 40802802 00000025
	buffer_store_b8 v17, v39, s[20:23], null offen              ; c406007c 40802811 00000027
	buffer_store_b8 v12, v40, s[20:23], null offen              ; c406007c 4080280c 00000028
	buffer_store_b8 v13, v41, s[20:23], null offen              ; c406007c 4080280d 00000029
	buffer_store_b8 v14, v42, s[20:23], null offen              ; c406007c 4080280e 0000002a
	buffer_store_b8 v15, v43, s[20:23], null offen              ; c406007c 4080280f 0000002b
	buffer_store_b8 v19, v44, s[20:23], null offen              ; c406007c 40802813 0000002c
	buffer_store_b8 v20, v45, s[20:23], null offen              ; c406007c 40802814 0000002d
	buffer_store_b8 v21, v46, s[20:23], null offen              ; c406007c 40802815 0000002e
	buffer_store_b8 v22, v1, s[20:23], null offen               ; c406007c 40802816 00000001
	v_cvt_f16_f32_e32 v47, v80                                  ; 7e5e1550
(invalid instruction)                                        ; 7f5e1551
	v_cvt_f16_f32_e32 v48, v88                                  ; 7e601558
(invalid instruction)                                        ; 7f601559
	v_cmpx_gt_u32_e32 0x800, v6                                 ; 7d980cff 00000800
	s_mov_b32 vcc_lo, exec_lo                                   ; beea007e
	s_cbranch_execz BB265                                       ; bfa5004a
BB254:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[48:49], v[48:49]                ; 1a026130
(invalid instruction)                                        ; cc100001
	v_min_num_f64_e32 v[1:2], v[47:48], v[47:48]                ; 1a025f2f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0001
	v_min_num_f64_e32 v[1:2], v[1:2], v[0:1]                    ; 1a020101
(invalid instruction)                                        ; cc10000c
	v_subrev_f32_e32 v0, v48, v255                              ; 0a01ff30
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v6, vcc_lo                     ; 02020cff 00000400
	v_mov_b32_dpp v2, v1 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0402fa ff0d2801
(invalid instruction)                                        ; cc10000d
	v_subrev_f32_e32 v0, v47, v255                              ; 0a01ff2f
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v48, v48, v12, s1                         ; d5010030 00061930
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0001
	v_min_num_f64_e32 v[1:2], v[1:2], v[2:3]                    ; 1a020501
	v_cndmask_b32_e64 v47, v47, v13, s1                         ; d501002f 00061b2f
	v_mov_b32_dpp v3, v1 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0602fa ff0d6401
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0001
	v_min_num_f64_e32 v[1:2], v[1:2], v[3:4]                    ; 1a020701
	v_mov_b32_dpp v4, v1 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0802fa ff0c4e01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0001
	v_min_num_f64_e32 v[1:2], v[1:2], v[4:5]                    ; 1a020901
	v_mov_b32_dpp v5, v1 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0a02fa ff0cb101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0001
	v_min_num_f64_e32 v[1:2], v[1:2], v[5:6]                    ; 1a020b01
(invalid instruction)                                        ; cc1c0001
	v_subrev_f32_e32 v0, v1, v255                               ; 0a01ff01
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v8, v1                                    ; 7e101701
	v_cvt_f32_f16_e32 v1, v129/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e021781
	v_rsq_f32_e32 v8, v8                                        ; 7e105d08
	v_rsq_f32_e32 v1, v1                                        ; 7e025d01
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v11, v8                                   ; 7e161508
(invalid instruction)                                        ; 7f161501
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10002f
	v_min_num_f64_e32 v[1:2], v[47:48], v[11:12]                ; 1a02172f
(invalid instruction)                                        ; cc100030
	v_min_num_f64_e32 v[1:2], v[48:49], v[11:12]                ; 1a021730
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB265                                       ; bfa5000f
BB255:
	s_load_b128 s[24:27], s[4:5], 0x30                          ; f4004602 f8000030
	v_add_lshl_u32 v0, s2, v7, 2                                ; d6470000 020a0e02
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v1, v0                                    ; 7e021500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10002f
	v_subrev_f32_e32 v1, v47, v1                                ; 0a02032f
(invalid instruction)                                        ; cc100030
	v_subrev_f32_e32 v1, v48, v1                                ; 0a020330
BB265:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v8, v82                                   ; 7e101552
(invalid instruction)                                        ; 7f101553
	v_cvt_f16_f32_e32 v11, v90                                  ; 7e16155a
(invalid instruction)                                        ; 7f16155b
(invalid instruction)                                        ; cc1c002f
	v_subrev_f32_e32 v0, v47, v255                              ; 0a01ff2f
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c0030
	v_subrev_f32_e32 v0, v48, v255                              ; 0a01ff30
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b002f
	v_subrev_f32_e32 v0, v47, v255                              ; 0a01ff2f
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b0030
	v_subrev_f32_e32 v0, v48, v255                              ; 0a01ff30
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v47                                   ; 7e00172f
	v_cvt_f32_f16_e32 v47, v175/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e5e17af
	v_cvt_f32_f16_e32 v3, v48                                   ; 7e061730
	v_cvt_f32_f16_e32 v48, v176/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e6017b0
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v0, v47, v128, vcc_lo                     ; 0201012f
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v0, v3, v128, vcc_lo                      ; 02010103
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB277                                       ; bfa5004a
BB266:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[11:12], v[11:12]                ; 1a02170b
(invalid instruction)                                        ; cc100003
	v_min_num_f64_e32 v[1:2], v[8:9], v[8:9]                    ; 1a021108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[0:1]                    ; 1a020103
(invalid instruction)                                        ; cc100012
	v_subrev_f32_e32 v0, v11, v255                              ; 0a01ff0b
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v6, vcc_lo                     ; 02020cff 00000400
	v_mov_b32_dpp v12, v3 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1802fa ff0d2803
(invalid instruction)                                        ; cc100013
	v_subrev_f32_e32 v0, v8, v255                               ; 0a01ff08
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v11, v11, v18, s1                         ; d501000b 0006250b
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[12:13]                  ; 1a021903
	v_cndmask_b32_e64 v8, v8, v19, s1                           ; d5010008 00062708
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a02fa ff0d6403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[13:14]                  ; 1a021b03
	v_mov_b32_dpp v14, v3 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1c02fa ff0c4e03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[14:15]                  ; 1a021d03
	v_mov_b32_dpp v15, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e02fa ff0cb103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[15:16]                  ; 1a021f03
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v16, v3                                   ; 7e201703
	v_cvt_f32_f16_e32 v3, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e061783
	v_rsq_f32_e32 v16, v16                                      ; 7e205d10
	v_rsq_f32_e32 v3, v3                                        ; 7e065d03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v17, v16                                  ; 7e221510
(invalid instruction)                                        ; 7f221503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100008
	v_min_num_f64_e32 v[1:2], v[8:9], v[17:18]                  ; 1a022308
(invalid instruction)                                        ; cc10000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[17:18]                ; 1a02230b
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB277                                       ; bfa5000f
BB267:
	s_load_b128 s[24:27], s[4:5], 0x30                          ; f4004602 f8000030
	v_add_lshl_u32 v0, s2, v7, 2                                ; d6470000 020a0e02
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v3, v0                                    ; 7e061500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100008
	v_subrev_f32_e32 v1, v8, v3                                 ; 0a020708
(invalid instruction)                                        ; cc10000b
	v_subrev_f32_e32 v1, v11, v3                                ; 0a02070b
BB277:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v15, v84                                  ; 7e1e1554
(invalid instruction)                                        ; 7f1e1555
	v_cvt_f16_f32_e32 v16, v92                                  ; 7e20155c
(invalid instruction)                                        ; 7f20155d
(invalid instruction)                                        ; cc1c0008
	v_subrev_f32_e32 v0, v8, v255                               ; 0a01ff08
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v255                              ; 0a01ff0b
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b0008
	v_subrev_f32_e32 v0, v8, v255                               ; 0a01ff08
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b000b
	v_subrev_f32_e32 v0, v11, v255                              ; 0a01ff0b
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v8                                    ; 7e001708
	v_cvt_f32_f16_e32 v8, v136/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e101788
	v_cvt_f32_f16_e32 v12, v11                                  ; 7e18170b
	v_cvt_f32_f16_e32 v11, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e16178b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v0, v8, v128, vcc_lo                      ; 02010108
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                     ; 0201010c
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB289                                       ; bfa5004a
BB278:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[16:17], v[16:17]                ; 1a022110
(invalid instruction)                                        ; cc10000b
	v_min_num_f64_e32 v[1:2], v[15:16], v[15:16]                ; 1a021f0f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[0:1]                  ; 1a02010b
(invalid instruction)                                        ; cc100016
	v_subrev_f32_e32 v0, v16, v255                              ; 0a01ff10
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v6, vcc_lo                     ; 02020cff 00000400
	v_mov_b32_dpp v12, v11 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1802fa ff0d280b
(invalid instruction)                                        ; cc100019
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v16, v16, v22, s1                         ; d5010010 00062d10
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[12:13]                ; 1a02190b
	v_cndmask_b32_e64 v15, v15, v25, s1                         ; d501000f 0006330f
	v_mov_b32_dpp v17, v11 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2202fa ff0d640b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[17:18]                ; 1a02230b
	v_mov_b32_dpp v18, v11 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2402fa ff0c4e0b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[18:19]                ; 1a02250b
	v_mov_b32_dpp v19, v11 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2602fa ff0cb10b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000b
	v_min_num_f64_e32 v[1:2], v[11:12], v[19:20]                ; 1a02270b
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v255                              ; 0a01ff0b
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v20, v11                                  ; 7e28170b
	v_cvt_f32_f16_e32 v11, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e16178b
	v_rsq_f32_e32 v20, v20                                      ; 7e285d14
	v_rsq_f32_e32 v11, v11                                      ; 7e165d0b
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v21, v20                                  ; 7e2a1514
(invalid instruction)                                        ; 7f2a150b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[21:22]                ; 1a022b0f
(invalid instruction)                                        ; cc100010
	v_min_num_f64_e32 v[1:2], v[16:17], v[21:22]                ; 1a022b10
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB289                                       ; bfa5000f
BB279:
	s_load_b128 s[24:27], s[4:5], 0x30                          ; f4004602 f8000030
	v_add_lshl_u32 v0, s2, v7, 2                                ; d6470000 020a0e02
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v11, v0                                   ; 7e161500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000f
	v_subrev_f32_e32 v1, v15, v11                               ; 0a02170f
(invalid instruction)                                        ; cc100010
	v_subrev_f32_e32 v1, v16, v11                               ; 0a021710
BB289:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v19, v86                                  ; 7e261556
(invalid instruction)                                        ; 7f261557
	v_cvt_f16_f32_e32 v20, v94                                  ; 7e28155e
(invalid instruction)                                        ; 7f28155f
(invalid instruction)                                        ; cc1c000f
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c0010
	v_subrev_f32_e32 v0, v16, v255                              ; 0a01ff10
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b000f
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b0010
	v_subrev_f32_e32 v0, v16, v255                              ; 0a01ff10
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v15                                   ; 7e00170f
	v_cvt_f32_f16_e32 v15, v143/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e178f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v15, v128, vcc_lo                     ; 0201010f
	v_cvt_f32_f16_e32 v15, v16                                  ; 7e1e1710
	v_cvt_f32_f16_e32 v16, v144/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e201790
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v15, v128, vcc_lo                     ; 0201010f
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB301                                       ; bfa50047
BB290:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[20:21], v[20:21]                ; 1a022914
(invalid instruction)                                        ; cc10000f
	v_min_num_f64_e32 v[1:2], v[19:20], v[19:20]                ; 1a022713
(invalid instruction)                                        ; cc10001f
	v_subrev_f32_e32 v0, v20, v255                              ; 0a01ff14
(invalid instruction)                                        ; 000045a8
	v_cmp_gt_u32_e32 vcc_lo, 0x400, v6                          ; 7c980cff 00000400
(invalid instruction)                                        ; cc100021
	v_subrev_f32_e32 v0, v19, v255                              ; 0a01ff13
(invalid instruction)                                        ; 000045a8
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[0:1]                  ; 1a02010f
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_dual_cndmask_b32 v19, v19, v33 :: v_dual_cndmask_b32 v20, v20, v31 ; ca524313 13143f14
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_mov_b32_dpp v16, v15 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2002fa ff0d280f
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v21, v15 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2a02fa ff0d640f
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[21:22]                ; 1a022b0f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v22, v15 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2c02fa ff0c4e0f
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[22:23]                ; 1a022d0f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v25, v15 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3202fa ff0cb10f
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[25:26]                ; 1a02330f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c000f
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 00000410
	v_cvt_f32_f16_e32 v27, v15                                  ; 7e36170f
	v_cvt_f32_f16_e32 v15, v143/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e178f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v27, v27                                      ; 7e365d1b
	v_rsq_f32_e32 v15, v15                                      ; 7e1e5d0f
	v_cvt_f16_f32_e32 v29, v27                                  ; 7e3a151b
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
(invalid instruction)                                        ; 7f3a150f
(invalid instruction)                                        ; cc100013
	v_min_num_f64_e32 v[1:2], v[19:20], v[29:30]                ; 1a023b13
(invalid instruction)                                        ; cc100014
	v_min_num_f64_e32 v[1:2], v[20:21], v[29:30]                ; 1a023b14
	s_and_saveexec_b32 s1, vcc_lo                               ; be81206a
	s_cbranch_execz BB301                                       ; bfa5000f
BB291:
	s_load_b128 s[24:27], s[4:5], 0x30                          ; f4004602 f8000030
	v_add_lshl_u32 v7, s2, v7, 2                                ; d6470007 020a0e02
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v7, v7, s[24:27], null offen                ; c405007c 40803007 00000007
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v0, v7                                    ; 7e001507
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100013
	v_subrev_f32_e32 v1, v19, v0                                ; 0a020113
(invalid instruction)                                        ; cc100014
	v_subrev_f32_e32 v1, v20, v0                                ; 0a020114
BB301:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_lshrrev_b32_e32 v6, 4, v6                                 ; 320c0c84
(invalid instruction)                                        ; cc1c0013
	v_subrev_f32_e32 v0, v19, v255                              ; 0a01ff13
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_add_lshl_u32 v6, s14, v6, 8                               ; d6470006 02220c0e
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v255                              ; 0a01ff14
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1b0013
	v_subrev_f32_e32 v0, v19, v255                              ; 0a01ff13
(invalid instruction)                                        ; 00005f00
	v_add_nc_u32_e32 v6, s3, v6                                 ; 4a0c0c03
(invalid instruction)                                        ; cc1b0014
	v_subrev_f32_e32 v0, v20, v255                              ; 0a01ff14
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v19                                   ; 7e001713
	v_cvt_f32_f16_e32 v19, v147/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e261793
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add3_u32 v21, v23, v6, v24                                ; d6550015 04620d17
	v_add3_u32 v22, v23, v6, v26                                ; d6550016 046a0d17
	v_add3_u32 v25, v23, v6, v28                                ; d6550019 04720d17
	v_add3_u32 v27, v23, v6, v30                                ; d655001b 047a0d17
	v_add3_u32 v29, v23, v6, v32                                ; d655001d 04820d17
	v_add3_u32 v31, v23, v6, v34                                ; d655001f 048a0d17
	v_add3_u32 v33, v23, v6, v36                                ; d6550021 04920d17
	v_add3_u32 v35, v23, v6, v38                                ; d6550023 049a0d17
	v_add_nc_u32_e32 v6, 0x100, v6                              ; 4a0c0cff 00000100
	v_cvt_f32_f16_e32 v16, v20                                  ; 7e201714
	v_cvt_f32_f16_e32 v20, v148/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e281794
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v19, v128, vcc_lo                     ; 02010113
	v_add3_u32 v37, v23, v6, v24                                ; d6550025 04620d17
	v_add3_u32 v39, v23, v6, v26                                ; d6550027 046a0d17
	v_add3_u32 v40, v23, v6, v28                                ; d6550028 04720d17
	v_add3_u32 v41, v23, v6, v30                                ; d6550029 047a0d17
	v_add3_u32 v42, v23, v6, v32                                ; d655002a 04820d17
	v_add3_u32 v43, v23, v6, v34                                ; d655002b 048a0d17
	v_add3_u32 v44, v23, v6, v36                                ; d655002c 04920d17
	v_add3_u32 v6, v23, v6, v38                                 ; d6550006 049a0d17
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v0, v20, v128, vcc_lo                     ; 02010114
	s_clause 0xf                                                ; bf85000f
	buffer_store_b8 v1, v21, s[20:23], null offen               ; c406007c 40802801 00000015
	buffer_store_b8 v2, v22, s[20:23], null offen               ; c406007c 40802802 00000016
	buffer_store_b8 v3, v25, s[20:23], null offen               ; c406007c 40802803 00000019
	buffer_store_b8 v8, v27, s[20:23], null offen               ; c406007c 40802808 0000001b
	buffer_store_b8 v11, v29, s[20:23], null offen              ; c406007c 4080280b 0000001d
	buffer_store_b8 v12, v31, s[20:23], null offen              ; c406007c 4080280c 0000001f
	buffer_store_b8 v7, v33, s[20:23], null offen               ; c406007c 40802807 00000021
	buffer_store_b8 v15, v35, s[20:23], null offen              ; c406007c 4080280f 00000023
	buffer_store_b8 v4, v37, s[20:23], null offen               ; c406007c 40802804 00000025
	buffer_store_b8 v5, v39, s[20:23], null offen               ; c406007c 40802805 00000027
	buffer_store_b8 v13, v40, s[20:23], null offen              ; c406007c 4080280d 00000028
	buffer_store_b8 v14, v41, s[20:23], null offen              ; c406007c 4080280e 00000029
	buffer_store_b8 v17, v42, s[20:23], null offen              ; c406007c 40802811 0000002a
	buffer_store_b8 v18, v43, s[20:23], null offen              ; c406007c 40802812 0000002b
	buffer_store_b8 v19, v44, s[20:23], null offen              ; c406007c 40802813 0000002c
	buffer_store_b8 v20, v6, s[20:23], null offen               ; c406007c 40802814 00000006
	v_cvt_f16_f32_e32 v45, v96                                  ; 7e5a1560
(invalid instruction)                                        ; 7f5a1561
	v_cvt_f16_f32_e32 v46, v104                                 ; 7e5c1568
(invalid instruction)                                        ; 7f5c1569
	v_cmpx_gt_u32_e32 0x800, v9                                 ; 7d9812ff 00000800
	s_mov_b32 vcc_lo, exec_lo                                   ; beea007e
	s_cbranch_execz BB313                                       ; bfa5004a
BB302:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[46:47], v[46:47]                ; 1a025d2e
(invalid instruction)                                        ; cc100001
	v_min_num_f64_e32 v[1:2], v[45:46], v[45:46]                ; 1a025b2d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0001
	v_min_num_f64_e32 v[1:2], v[1:2], v[0:1]                    ; 1a020101
(invalid instruction)                                        ; cc100008
	v_subrev_f32_e32 v0, v46, v255                              ; 0a01ff2e
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v9, vcc_lo                     ; 020212ff 00000400
	v_mov_b32_dpp v2, v1 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0402fa ff0d2801
(invalid instruction)                                        ; cc10000b
	v_subrev_f32_e32 v0, v45, v255                              ; 0a01ff2d
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v46, v46, v8, s1                          ; d501002e 0006112e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0001
	v_min_num_f64_e32 v[1:2], v[1:2], v[2:3]                    ; 1a020501
	v_cndmask_b32_e64 v45, v45, v11, s1                         ; d501002d 0006172d
	v_mov_b32_dpp v3, v1 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0602fa ff0d6401
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0001
	v_min_num_f64_e32 v[1:2], v[1:2], v[3:4]                    ; 1a020701
	v_mov_b32_dpp v4, v1 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0802fa ff0c4e01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0001
	v_min_num_f64_e32 v[1:2], v[1:2], v[4:5]                    ; 1a020901
	v_mov_b32_dpp v5, v1 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e0a02fa ff0cb101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0001
	v_min_num_f64_e32 v[1:2], v[1:2], v[5:6]                    ; 1a020b01
(invalid instruction)                                        ; cc1c0001
	v_subrev_f32_e32 v0, v1, v255                               ; 0a01ff01
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v6, v1                                    ; 7e0c1701
	v_cvt_f32_f16_e32 v1, v129/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e021781
	v_rsq_f32_e32 v6, v6                                        ; 7e0c5d06
	v_rsq_f32_e32 v1, v1                                        ; 7e025d01
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v7, v6                                    ; 7e0e1506
(invalid instruction)                                        ; 7f0e1501
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10002d
	v_min_num_f64_e32 v[1:2], v[45:46], v[7:8]                  ; 1a020f2d
(invalid instruction)                                        ; cc10002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[7:8]                  ; 1a020f2e
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB313                                       ; bfa5000f
BB303:
	s_load_b128 s[24:27], s[4:5], 0x30                          ; f4004602 f8000030
	v_add_lshl_u32 v0, s2, v10, 2                               ; d6470000 020a1402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v1, v0                                    ; 7e021500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10002d
	v_subrev_f32_e32 v1, v45, v1                                ; 0a02032d
(invalid instruction)                                        ; cc10002e
	v_subrev_f32_e32 v1, v46, v1                                ; 0a02032e
BB313:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v6, v98                                   ; 7e0c1562
(invalid instruction)                                        ; 7f0c1563
	v_cvt_f16_f32_e32 v7, v106                                  ; 7e0e156a
(invalid instruction)                                        ; 7f0e156b
(invalid instruction)                                        ; cc1c002d
	v_subrev_f32_e32 v0, v45, v255                              ; 0a01ff2d
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c002e
	v_subrev_f32_e32 v0, v46, v255                              ; 0a01ff2e
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b002d
	v_subrev_f32_e32 v0, v45, v255                              ; 0a01ff2d
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b002e
	v_subrev_f32_e32 v0, v46, v255                              ; 0a01ff2e
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v45                                   ; 7e00172d
	v_cvt_f32_f16_e32 v45, v173/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e5a17ad
	v_cvt_f32_f16_e32 v3, v46                                   ; 7e06172e
	v_cvt_f32_f16_e32 v46, v174/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e5c17ae
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v0, v45, v128, vcc_lo                     ; 0201012d
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v0, v3, v128, vcc_lo                      ; 02010103
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB325                                       ; bfa5004a
BB314:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[7:8], v[7:8]                    ; 1a020f07
(invalid instruction)                                        ; cc100003
	v_min_num_f64_e32 v[1:2], v[6:7], v[6:7]                    ; 1a020d06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[0:1]                    ; 1a020103
(invalid instruction)                                        ; cc100010
	v_subrev_f32_e32 v0, v7, v255                               ; 0a01ff07
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v9, vcc_lo                     ; 020212ff 00000400
	v_mov_b32_dpp v8, v3 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1002fa ff0d2803
(invalid instruction)                                        ; cc100011
	v_subrev_f32_e32 v0, v6, v255                               ; 0a01ff06
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v7, v7, v16, s1                           ; d5010007 00062107
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[8:9]                    ; 1a021103
	v_cndmask_b32_e64 v6, v6, v17, s1                           ; d5010006 00062306
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1602fa ff0d6403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[11:12]                  ; 1a021703
	v_mov_b32_dpp v12, v3 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1802fa ff0c4e03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[12:13]                  ; 1a021903
	v_mov_b32_dpp v13, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1a02fa ff0cb103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[13:14]                  ; 1a021b03
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v255                               ; 0a01ff03
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v14, v3                                   ; 7e1c1703
	v_cvt_f32_f16_e32 v3, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e061783
	v_rsq_f32_e32 v14, v14                                      ; 7e1c5d0e
	v_rsq_f32_e32 v3, v3                                        ; 7e065d03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v15, v14                                  ; 7e1e150e
(invalid instruction)                                        ; 7f1e1503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100006
	v_min_num_f64_e32 v[1:2], v[6:7], v[15:16]                  ; 1a021f06
(invalid instruction)                                        ; cc100007
	v_min_num_f64_e32 v[1:2], v[7:8], v[15:16]                  ; 1a021f07
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB325                                       ; bfa5000f
BB315:
	s_load_b128 s[24:27], s[4:5], 0x30                          ; f4004602 f8000030
	v_add_lshl_u32 v0, s2, v10, 2                               ; d6470000 020a1402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v3, v0                                    ; 7e061500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100006
	v_subrev_f32_e32 v1, v6, v3                                 ; 0a020706
(invalid instruction)                                        ; cc100007
	v_subrev_f32_e32 v1, v7, v3                                 ; 0a020707
BB325:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v13, v100                                 ; 7e1a1564
(invalid instruction)                                        ; 7f1a1565
	v_cvt_f16_f32_e32 v14, v108                                 ; 7e1c156c
(invalid instruction)                                        ; 7f1c156d
(invalid instruction)                                        ; cc1c0006
	v_subrev_f32_e32 v0, v6, v255                               ; 0a01ff06
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c0007
	v_subrev_f32_e32 v0, v7, v255                               ; 0a01ff07
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b0006
	v_subrev_f32_e32 v0, v6, v255                               ; 0a01ff06
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b0007
	v_subrev_f32_e32 v0, v7, v255                               ; 0a01ff07
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v6                                    ; 7e001706
	v_cvt_f32_f16_e32 v6, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0c1786
	v_cvt_f32_f16_e32 v8, v7                                    ; 7e101707
	v_cvt_f32_f16_e32 v7, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0e1787
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v0, v6, v128, vcc_lo                      ; 02010106
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v8, v128, vcc_lo                      ; 02010108
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v7, v128, vcc_lo                      ; 02010107
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB337                                       ; bfa5004a
BB326:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[14:15], v[14:15]                ; 1a021d0e
(invalid instruction)                                        ; cc100007
	v_min_num_f64_e32 v[1:2], v[13:14], v[13:14]                ; 1a021b0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
(invalid instruction)                                        ; cc0f0007
	v_min_num_f64_e32 v[1:2], v[7:8], v[0:1]                    ; 1a020107
(invalid instruction)                                        ; cc100014
	v_subrev_f32_e32 v0, v14, v255                              ; 0a01ff0e
(invalid instruction)                                        ; 000045a8
(invalid instruction)                                        ; d44c0001
	v_cndmask_b32_e32 v1, 0x400, v9, vcc_lo                     ; 020212ff 00000400
	v_mov_b32_dpp v8, v7 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1002fa ff0d2807
(invalid instruction)                                        ; cc100015
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 000045a8
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v14, v14, v20, s1                         ; d501000e 0006290e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0007
	v_min_num_f64_e32 v[1:2], v[7:8], v[8:9]                    ; 1a021107
	v_cndmask_b32_e64 v13, v13, v21, s1                         ; d501000d 00062b0d
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e02fa ff0d6407
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0007
	v_min_num_f64_e32 v[1:2], v[7:8], v[15:16]                  ; 1a021f07
	v_mov_b32_dpp v16, v7 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2002fa ff0c4e07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0007
	v_min_num_f64_e32 v[1:2], v[7:8], v[16:17]                  ; 1a022107
	v_mov_b32_dpp v17, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2202fa ff0cb107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0007
	v_min_num_f64_e32 v[1:2], v[7:8], v[17:18]                  ; 1a022307
(invalid instruction)                                        ; cc1c0007
	v_subrev_f32_e32 v0, v7, v255                               ; 0a01ff07
(invalid instruction)                                        ; 00000410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v18, v7                                   ; 7e241707
	v_cvt_f32_f16_e32 v7, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0e1787
	v_rsq_f32_e32 v18, v18                                      ; 7e245d12
	v_rsq_f32_e32 v7, v7                                        ; 7e0e5d07
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_cvt_f16_f32_e32 v19, v18                                  ; 7e261512
(invalid instruction)                                        ; 7f261507
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[19:20]                ; 1a02270d
(invalid instruction)                                        ; cc10000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[19:20]                ; 1a02270e
	s_and_saveexec_b32 s1, s1                                   ; be812001
	s_cbranch_execz BB337                                       ; bfa5000f
BB327:
	s_load_b128 s[24:27], s[4:5], 0x30                          ; f4004602 f8000030
	v_add_lshl_u32 v0, s2, v10, 2                               ; d6470000 020a1402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v0, v0, s[24:27], null offen                ; c405007c 40803000 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v7, v0                                    ; 7e0e1500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc10000d
	v_subrev_f32_e32 v1, v13, v7                                ; 0a020f0d
(invalid instruction)                                        ; cc10000e
	v_subrev_f32_e32 v1, v14, v7                                ; 0a020f0e
BB337:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_cvt_f16_f32_e32 v17, v102                                 ; 7e221566
(invalid instruction)                                        ; 7f221567
	v_cvt_f16_f32_e32 v18, v110                                 ; 7e24156e
(invalid instruction)                                        ; 7f24156f
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1c000e
	v_subrev_f32_e32 v0, v14, v255                              ; 0a01ff0e
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 00005f00
(invalid instruction)                                        ; cc1b000e
	v_subrev_f32_e32 v0, v14, v255                              ; 0a01ff0e
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v13                                   ; 7e00170d
	v_cvt_f32_f16_e32 v13, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1a178d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                     ; 0201010d
	v_cvt_f32_f16_e32 v13, v14                                  ; 7e1a170e
	v_cvt_f32_f16_e32 v14, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1c178e
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                     ; 0201010d
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB349                                       ; bfa50047
BB338:
(invalid instruction)                                        ; cc100000
	v_min_num_f64_e32 v[1:2], v[18:19], v[18:19]                ; 1a022512
(invalid instruction)                                        ; cc10000d
	v_min_num_f64_e32 v[1:2], v[17:18], v[17:18]                ; 1a022311
(invalid instruction)                                        ; cc10001b
	v_subrev_f32_e32 v0, v18, v255                              ; 0a01ff12
(invalid instruction)                                        ; 000045a8
	v_cmp_gt_u32_e32 vcc_lo, 0x400, v9                          ; 7c9812ff 00000400
(invalid instruction)                                        ; cc10001d
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 000045a8
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[0:1]                  ; 1a02010d
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_dual_cndmask_b32 v17, v17, v29 :: v_dual_cndmask_b32 v18, v18, v27 ; ca523b11 11123712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_mov_b32_dpp v14, v13 row_ror:8 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1c02fa ff0d280d
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[14:15]                ; 1a021d0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v19, v13 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2602fa ff0d640d
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[19:20]                ; 1a02270d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v20, v13 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2802fa ff0c4e0d
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[20:21]                ; 1a02290d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mov_b32_dpp v21, v13 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2a02fa ff0cb10d
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[21:22]                ; 1a022b0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v255                              ; 0a01ff0d
(invalid instruction)                                        ; 00000410
	v_cvt_f32_f16_e32 v22, v13                                  ; 7e2c170d
	v_cvt_f32_f16_e32 v13, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1a178d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v22, v22                                      ; 7e2c5d16
	v_rsq_f32_e32 v13, v13                                      ; 7e1a5d0d
	v_cvt_f16_f32_e32 v25, v22                                  ; 7e321516
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
(invalid instruction)                                        ; 7f32150d
(invalid instruction)                                        ; cc100011
	v_min_num_f64_e32 v[1:2], v[17:18], v[25:26]                ; 1a023311
(invalid instruction)                                        ; cc100012
	v_min_num_f64_e32 v[1:2], v[18:19], v[25:26]                ; 1a023312
	s_and_saveexec_b32 s1, vcc_lo                               ; be81206a
	s_cbranch_execz BB349                                       ; bfa5000f
BB339:
	s_load_b128 s[4:7], s[4:5], 0x30                            ; f4004102 f8000030
	v_add_lshl_u32 v10, s2, v10, 2                              ; d647000a 020a1402
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v10, v10, s[4:7], null offen                ; c405007c 4080080a 0000000a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f16_f32_e32 v0, v10                                   ; 7e00150a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc100011
	v_subrev_f32_e32 v1, v17, v0                                ; 0a020111
(invalid instruction)                                        ; cc100012
	v_subrev_f32_e32 v1, v18, v0                                ; 0a020112
BB349:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_lshrrev_b32_e32 v9, 4, v9                                 ; 32121284
(invalid instruction)                                        ; cc1c0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 0000df00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_add_lshl_u32 v9, s14, v9, 8                               ; d6470009 0222120e
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v255                              ; 0a01ff12
(invalid instruction)                                        ; 0000df00
(invalid instruction)                                        ; cc1b0011
	v_subrev_f32_e32 v0, v17, v255                              ; 0a01ff11
(invalid instruction)                                        ; 00005f00
	v_add_nc_u32_e32 v9, s3, v9                                 ; 4a121203
(invalid instruction)                                        ; cc1b0012
	v_subrev_f32_e32 v0, v18, v255                              ; 0a01ff12
(invalid instruction)                                        ; 00005f00
	v_cvt_f32_f16_e32 v0, v17                                   ; 7e001711
	v_cvt_f32_f16_e32 v17, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221791
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add3_u32 v19, v23, v9, v24                                ; d6550013 04621317
	v_add3_u32 v20, v23, v9, v26                                ; d6550014 046a1317
	v_add3_u32 v21, v23, v9, v28                                ; d6550015 04721317
	v_add3_u32 v22, v23, v9, v30                                ; d6550016 047a1317
	v_add3_u32 v25, v23, v9, v32                                ; d6550019 04821317
	v_add3_u32 v27, v23, v9, v34                                ; d655001b 048a1317
	v_add3_u32 v29, v23, v9, v36                                ; d655001d 04921317
	v_add3_u32 v31, v23, v9, v38                                ; d655001f 049a1317
	v_add_nc_u32_e32 v9, 0x100, v9                              ; 4a1212ff 00000100
	v_cvt_f32_f16_e32 v14, v18                                  ; 7e1c1712
	v_cvt_f32_f16_e32 v18, v146/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e241792
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v0, v0, v128, vcc_lo                      ; 02010100
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
	v_add3_u32 v24, v23, v9, v24                                ; d6550018 04621317
	v_add3_u32 v26, v23, v9, v26                                ; d655001a 046a1317
	v_add3_u32 v28, v23, v9, v28                                ; d655001c 04721317
	v_add3_u32 v30, v23, v9, v30                                ; d655001e 047a1317
	v_add3_u32 v32, v23, v9, v32                                ; d6550020 04821317
	v_add3_u32 v34, v23, v9, v34                                ; d6550022 048a1317
	v_add3_u32 v36, v23, v9, v36                                ; d6550024 04921317
	v_add3_u32 v23, v23, v9, v38                                ; d6550017 049a1317
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                     ; 02010112
	s_clause 0xf                                                ; bf85000f
	buffer_store_b8 v1, v19, s[20:23], null offen               ; c406007c 40802801 00000013
	buffer_store_b8 v2, v20, s[20:23], null offen               ; c406007c 40802802 00000014
	buffer_store_b8 v3, v21, s[20:23], null offen               ; c406007c 40802803 00000015
	buffer_store_b8 v6, v22, s[20:23], null offen               ; c406007c 40802806 00000016
	buffer_store_b8 v7, v25, s[20:23], null offen               ; c406007c 40802807 00000019
	buffer_store_b8 v8, v27, s[20:23], null offen               ; c406007c 40802808 0000001b
	buffer_store_b8 v10, v29, s[20:23], null offen              ; c406007c 4080280a 0000001d
	buffer_store_b8 v13, v31, s[20:23], null offen              ; c406007c 4080280d 0000001f
	buffer_store_b8 v4, v24, s[20:23], null offen               ; c406007c 40802804 00000018
	buffer_store_b8 v5, v26, s[20:23], null offen               ; c406007c 40802805 0000001a
	buffer_store_b8 v11, v28, s[20:23], null offen              ; c406007c 4080280b 0000001c
	buffer_store_b8 v12, v30, s[20:23], null offen              ; c406007c 4080280c 0000001e
	buffer_store_b8 v15, v32, s[20:23], null offen              ; c406007c 4080280f 00000020
	buffer_store_b8 v16, v34, s[20:23], null offen              ; c406007c 40802810 00000022
	buffer_store_b8 v17, v36, s[20:23], null offen              ; c406007c 40802811 00000024
	buffer_store_b8 v18, v23, s[20:23], null offen              ; c406007c 40802812 00000017
BB351:
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s17, -1                                        ; bf01c111
	s_cbranch_scc0 BB360                                        ; bfa1000f
BB352:
	s_mov_b32 exec_lo, 3                                        ; befe0083
BB353:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[0:3], s[0:1], 0x0                             ; f4004000 f8000000
	s_add_co_u32 s17, s17, s9                                   ; 80110911
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
(invalid instruction)                                        ; d71f0000
	v_cndmask_b32_e32 v0, -1, v17, vcc_lo                       ; 020022c1
	v_dual_mov_b32 v1, 1 :: v_dual_lshlrev_b32 v0, 2, v0        ; ca220081 01000082
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_atomic_add_u32 v1, v0, s[0:3], null offen            ; c40d407c 40800001 00000000
BB360:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
