BB0:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s10, s1                                           ; be8a0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_clause 0x4                                                ; bf850004
	s_load_b128 s[12:15], s[10:11], 0x30                        ; f4004305 f8000030
	s_load_b32 s16, s[10:11], 0x40                              ; f4000405 f8000040
	s_load_b64 s[18:19], s[10:11], 0x20                         ; f4002485 f8000020
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	s_load_b256 s[32:39], s[0:1], 0x30                          ; f4006800 f8000030
(invalid instruction)                                        ; d71f0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_lshrrev_b32_e32 v1, 5, v0                                 ; 32020085
	s_pack_ll_b32_b16 s17, ttmp7, 0                             ; 99118073
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_and_b32_e32 v4, 15, v3                                    ; 3608068f
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_lshlrev_b32_e32 v2, 9, v1                                 ; 30040289
	v_lshlrev_b32_e32 v5, 4, v4                                 ; 300a0884
	v_lshlrev_b32_e32 v6, 3, v3                                 ; 300c0683
	v_add_nc_u32_e32 v8, 0x100, v2                              ; 4a1004ff 00000100
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl1_add_u32 s24, ttmp9, s15                             ; 87180f75
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_max_i32 s25, s24, 0                                       ; 8a198018
	s_add_co_u32 s26, s13, -1                                   ; 801ac10d
	s_min_i32 s25, s25, s26                                     ; 89191a19
	s_add_co_u32 s27, s14, -1                                   ; 801bc10e
	s_lshl1_add_u32 s17, s17, s16                               ; 87111011
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_max_i32 s28, s17, 0                                       ; 8a1c8011
	s_min_i32 s28, s28, s27                                     ; 891c1b1c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s28, s28, s13                                     ; 961c0d1c
	s_add_co_u32 s29, s28, s25                                  ; 801d191c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s29, s29, 10                                     ; 841d8a1d
	s_add_co_u32 s30, s2, s29                                   ; 801e1d02
	s_add_co_u32 s31, s24, 1                                    ; 801f8118
	v_add3_u32 v7, v5, s30, v2                                  ; d6550007 04083d05
	v_add3_u32 v9, v5, s30, v8                                  ; d6550009 04203d05
	s_max_i32 s40, s31, 0                                       ; 8a28801f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_min_i32 s40, s40, s26                                     ; 89281a28
	v_add_nc_u32_e32 v7, v7, v6                                 ; 4a0e0d07
	v_add_nc_u32_e32 v9, v9, v6                                 ; 4a120d09
	s_add_co_u32 s28, s28, s40                                  ; 801c281c
	s_lshl_b32 s28, s28, 10                                     ; 841c8a1c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s41, s2, s28                                   ; 80291c02
	s_add_co_u32 s42, s17, 1                                    ; 802a8111
	v_add3_u32 v10, v5, s41, v2                                 ; d655000a 04085305
	v_add3_u32 v11, v5, s41, v8                                 ; d655000b 04205305
	s_max_i32 s43, s42, 0                                       ; 8a2b802a
	s_min_i32 s43, s43, s27                                     ; 892b1b2b
	v_add_nc_u32_e32 v10, v10, v6                               ; 4a140d0a
	v_add_nc_u32_e32 v11, v11, v6                               ; 4a160d0b
	s_mul_i32 s43, s43, s13                                     ; 962b0d2b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s25, s43, s25                                  ; 8019192b
	s_lshl_b32 s25, s25, 10                                     ; 84198a19
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s44, s2, s25                                   ; 802c1902
	s_add_co_u32 s43, s43, s40                                  ; 802b282b
	v_add3_u32 v13, v5, s44, v8                                 ; d655000d 04205905
	v_add3_u32 v12, v5, s44, v2                                 ; d655000c 04085905
	s_lshl_b32 s43, s43, 10                                     ; 842b8a2b
	s_add_co_u32 s2, s2, s43                                    ; 80022b02
	v_add_nc_u32_e32 v13, v13, v6                               ; 4a1a0d0d
	v_add_nc_u32_e32 v12, v12, v6                               ; 4a180d0c
	v_add3_u32 v14, v5, s2, v2                                  ; d655000e 04080505
	v_add3_u32 v15, v5, s2, v8                                  ; d655000f 04200505
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v14, v14, v6                               ; 4a1c0d0e
	v_add_nc_u32_e32 v15, v15, v6                               ; 4a1e0d0f
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[16:17], v7, s[20:23], null offen          ; c405407c 40802810 00000007
	buffer_load_b64 v[18:19], v9, s[20:23], null offen          ; c405407c 40802812 00000009
	buffer_load_b64 v[20:21], v10, s[20:23], null offen         ; c405407c 40802814 0000000a
	buffer_load_b64 v[10:11], v11, s[20:23], null offen         ; c405407c 4080280a 0000000b
	buffer_load_b64 v[22:23], v12, s[20:23], null offen         ; c405407c 40802816 0000000c
	buffer_load_b64 v[12:13], v13, s[20:23], null offen         ; c405407c 4080280c 0000000d
	buffer_load_b64 v[24:25], v14, s[20:23], null offen         ; c405407c 40802818 0000000e
	buffer_load_b64 v[14:15], v15, s[20:23], null offen         ; c405407c 4080280e 0000000f
	v_lshlrev_b32_e32 v26, 3, v1                                ; 30340283
	v_and_b32_e32 v29, 31, v0                                   ; 363a009f
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c2
	v_med3_i32 v28, -1, v26, 1                                  ; d620001c 020634c1
	v_sub_nc_u32_e32 v27, 0, v26                                ; 4c363480
	v_add_nc_u32_e32 v31, 2, v26                                ; 4a3e3482
	v_lshlrev_b32_e32 v30, 2, v29                               ; 303c3a82
	v_max_i32_e32 v27, v26, v27                                 ; 2436371a
	v_sub_nc_u32_e32 v32, 0, v31                                ; 4c403e80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_lshrrev_b32_e32 v27, 1, v27                               ; 32363681
	v_max_i32_e32 v32, v31, v32                                 ; 2440411f
	v_med3_i32 v31, -1, v31, 1                                  ; d620001f 02063ec1
(invalid instruction)                                        ; d72c001c
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                      ; 0202371c
	v_lshrrev_b32_e32 v32, 1, v32                               ; 32404081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d72c001f
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                      ; 0202411f
	v_lshl_add_u32 v28, v28, 9, s4                              ; d646001c 0011131c
	v_add_lshl_u32 v28, v28, v30, 2                             ; d647001c 020a3d1c
	v_lshl_add_u32 v31, v31, 9, s4                              ; d646001f 0011131f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v31, v31, v30, 2                             ; d647001f 020a3d1f
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[32:35], v28, s[36:39], null offen        ; c405c07c 40804820 0000001c
	buffer_load_b128 v[36:39], v31, s[36:39], null offen        ; c405c07c 40804824 0000001f
	buffer_load_b128 v[40:43], v28, s[36:39], null offen offset:512 ; c405c07c 40804828 0002001c
	buffer_load_b128 v[44:47], v31, s[36:39], null offen offset:512 ; c405c07c 4080482c 0002001f
	buffer_load_b128 v[48:51], v28, s[36:39], null offen offset:1024 ; c405c07c 40804830 0004001c
	buffer_load_b128 v[52:55], v31, s[36:39], null offen offset:1024 ; c405c07c 40804834 0004001f
	buffer_load_b128 v[56:59], v28, s[36:39], null offen offset:1536 ; c405c07c 40804838 0006001c
	buffer_load_b128 v[60:63], v31, s[36:39], null offen offset:1536 ; c405c07c 4080483c 0006001f
	v_add_nc_u32_e32 v64, v5, v6                                ; 4a800d05
	s_min_i32 s45, s24, s17                                     ; 892d1118
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s45, 0                                         ; bf04802d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b1
	v_add_nc_u32_e32 v65, v2, v64                               ; 4a828102
	s_cselect_b32 s46, -1, 0                                    ; 982e80c1
	s_cmp_ge_i32 s24, s13                                       ; bf030d18
	s_cselect_b32 s47, -1, 0                                    ; 982f80c1
	v_add_nc_u32_e32 v66, 0x800, v65                            ; 4a8482ff 00000800
	s_or_b32 s46, s46, s47                                      ; 8c2e2f2e
	s_cmp_ge_i32 s17, s14                                       ; bf030e11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_mov_b32 s49, src_scc                                      ; beb100fd
	s_cselect_b32 s48, -1, 0                                    ; 983080c1
	s_nor_b32 vcc_lo, s46, s48                                  ; 8f6a302e
	s_min_i32 s50, s31, s17                                     ; 8932111f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s50, 0                                         ; bf048032
	s_cselect_b32 s51, -1, 0                                    ; 983380c1
	s_cmp_ge_i32 s31, s13                                       ; bf030d1f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s52, -1, 0                                    ; 983480c1
	s_or_b32 s51, s51, s52                                      ; 8c333433
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_nor_b32 s51, s51, s48                                     ; 8f333033
	s_min_i32 s53, s24, s42                                     ; 89352a18
	s_pack_hh_b32_b16 s59, ttmp7, 0                             ; 9a3b8073
	s_movk_i32 s60, 0x400                                       ; b03c0400
	s_cmp_lt_i32 s53, 0                                         ; bf048035
	v_lshl_add_u32 v67, s59, 4, v64                             ; d6460043 0501083b
	s_cselect_b32 s54, -1, 0                                    ; 983680c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_or_b32 s54, s54, s47                                      ; 8c362f36
	s_cmp_ge_i32 s42, s14                                       ; bf030e2a
	s_cselect_b32 s55, -1, 0                                    ; 983780c1
	s_mov_b32 s56, src_scc                                      ; beb800fd
	s_nor_b32 s54, s54, s55                                     ; 8f363736
	s_min_i32 s57, s31, s42                                     ; 89392a1f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s57, 0                                         ; bf048039
	s_cselect_b32 s58, -1, 0                                    ; 983a80c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s58, s58, s52                                      ; 8c3a343a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_nor_b32 s58, s58, s55                                     ; 8f3a373a
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_dual_cndmask_b32 v68, 0, v16 :: v_dual_cndmask_b32 v69, 0, v17 ; ca522080 44442280
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_dual_cndmask_b32 v16, 0, v18 :: v_dual_cndmask_b32 v17, 0, v19 ; ca522480 10102680
	ds_store_2addr_b64 v65, v[68:69], v[16:17] offset1:32       ; d9382000 00104441
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_cndmask_b32_e64 v16, 0, v20, s51                          ; d5010010 00ce2880
	v_cndmask_b32_e64 v17, 0, v21, s51                          ; d5010011 00ce2a80
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_cndmask_b32_e64 v18, 0, v10, s51                          ; d5010012 00ce1480
	v_cndmask_b32_e64 v19, 0, v11, s51                          ; d5010013 00ce1680
	ds_store_2addr_b64 v65, v[16:17], v[18:19] offset0:128 offset1:160 ; d938a080 00121041
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_cndmask_b32_e64 v10, 0, v22, s54                          ; d501000a 00da2c80
	v_cndmask_b32_e64 v11, 0, v23, s54                          ; d501000b 00da2e80
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cndmask_b32_e64 v16, 0, v12, s54                          ; d5010010 00da1880
	v_cndmask_b32_e64 v17, 0, v13, s54                          ; d5010011 00da1a80
	ds_store_2addr_b64 v66, v[10:11], v[16:17] offset1:32       ; d9382000 00100a42
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v11, 0, v25, s58                          ; d501000b 00ea3280
	v_cndmask_b32_e64 v10, 0, v24, s58                          ; d501000a 00ea3080
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cndmask_b32_e64 v12, 0, v14, s58                          ; d501000c 00ea1c80
	v_cndmask_b32_e64 v13, 0, v15, s58                          ; d501000d 00ea1e80
	ds_store_2addr_b64 v66, v[10:11], v[12:13] offset0:128 offset1:160 ; d938a080 000c0a42
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[10:11], v67                                   ; d9d80000 0a000043
	ds_load_b64 v[12:13], v67 offset:1024                       ; d9d80400 0c000043
	ds_load_b64 v[14:15], v67 offset:2048                       ; d9d80800 0e000043
	ds_load_b64 v[16:17], v67 offset:3072                       ; d9d80c00 10000043
	ds_load_b64 v[18:19], v67 offset:256                        ; d9d80100 12000043
	ds_load_b64 v[20:21], v67 offset:1280                       ; d9d80500 14000043
	ds_load_b64 v[22:23], v67 offset:2304                       ; d9d80900 16000043
	ds_load_b64 v[24:25], v67 offset:3328                       ; d9d80d00 18000043
	ds_load_b64 v[68:69], v67 offset:512                        ; d9d80200 44000043
	ds_load_b64 v[70:71], v67 offset:1536                       ; d9d80600 46000043
	ds_load_b64 v[72:73], v67 offset:2560                       ; d9d80a00 48000043
	ds_load_b64 v[74:75], v67 offset:3584                       ; d9d80e00 4a000043
	ds_load_b64 v[76:77], v67 offset:768                        ; d9d80300 4c000043
	ds_load_b64 v[78:79], v67 offset:1792                       ; d9d80700 4e000043
	ds_load_b64 v[80:81], v67 offset:2816                       ; d9d80b00 50000043
	ds_load_b64 v[82:83], v67 offset:3840                       ; d9d80f00 52000043
	s_wait_loadcnt_dscnt 0x70c                                  ; bfc8070c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[32:33], v[16:17], 0 ; cc4640b8 1a022120
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[32:33], v[12:13], 0 ; cc464078 1a021920
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[12:13], 0 ; cc464080 1a021922
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[34:35], v[14:15], 0 ; cc4640a0 1a021d22
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[14:15], 0 ; cc464098 1a021d20
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[10:11], 0 ; cc464058 1a021520
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[10:11], 0 ; cc464060 1a021522
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[38:39], v[12:13], 0 ; cc464090 1a021926
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[36:37], v[12:13], 0 ; cc464088 1a021924
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[36:37], v[14:15], 0 ; cc4640a8 1a021d24
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[36:37], v[10:11], 0 ; cc464068 1a021524
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[10:11], 0 ; cc464070 1a021526
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[14:15], 0 ; cc4640b0 1a021d26
	v_dual_mov_b32 v15, v29 :: v_dual_mov_b32 v86, v8           ; ca10011d 0f560108
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[34:35], v[16:17], 0  ; cc464007 1a022122
	v_dual_mov_b32 v35, v30 :: v_dual_add_nc_u32 v84, 4, v26    ; ca20011e 23543484
	v_wmma_f32_16x16x16_fp8_fp8 v[27:34], v[36:37], v[16:17], 0 ; cc46401b 1a022124
	v_dual_mov_b32 v37, v17 :: v_dual_mov_b32 v36, v16          ; ca100111 25240110
	v_mad_u32_u24 v85, s59, 0x50, v64                           ; d60b0055 0501fe3b 00000050
	s_wait_loadcnt_dscnt 0x50b                                  ; bfc8050b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[18:19], v[88:95] ; cc464058 1d622528
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[40:41], v[20:21], v[120:127] ; cc464078 1de22928
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[18:19], v[96:103] ; cc464060 1d82252a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[20:21], v[128:135] ; cc464080 1e02292a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[44:45], v[20:21], v[136:143] ; cc464088 1e22292c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[20:21], v[144:151] ; cc464090 1e42292e
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[22:23], v[152:159] ; cc464098 1e622d28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[18:19], v[104:111] ; cc464068 1da2252c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[42:43], v[22:23], v[160:167] ; cc4640a0 1e822d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[22:23], v[168:175] ; cc4640a8 1ea22d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[18:19], v[112:119] ; cc464070 1dc2252e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[46:47], v[22:23], v[176:183] ; cc4640b0 1ec22d2e
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[40:41], v[24:25], v[184:191] ; cc4640b8 1ee23128
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[38:39], v[36:37], 0 ; cc464010 1a024926
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[42:43], v[24:25], v[7:14] ; cc464007 1c1e312a
	ds_load_b64 v[36:37], v85                                   ; d9d80000 24000055
	ds_load_b64 v[38:39], v85 offset:1024                       ; d9d80400 26000055
	ds_load_b64 v[40:41], v85 offset:2048                       ; d9d80800 28000055
	ds_load_b64 v[42:43], v85 offset:3072                       ; d9d80c00 2a000055
	v_wmma_f32_16x16x16_fp8_fp8 v[27:34], v[44:45], v[24:25], v[27:34] ; cc46401b 1c6e312c
	v_sub_nc_u32_e32 v44, 0, v84                                ; 4c58a880
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[24:25], v[16:23] ; cc464010 1c42312e
	v_max_i32_e32 v44, v84, v44                                 ; 24585954
	v_med3_i32 v84, -1, v84, 1                                  ; d6200054 0206a8c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_lshrrev_b32_e32 v44, 1, v44                               ; 32585881
(invalid instruction)                                        ; d72c0054
	v_cndmask_b32_e32 v1, v84, v44, vcc_lo                      ; 02025954
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v84, v84, 9, s4                              ; d6460054 00111354
	v_add_lshl_u32 v84, v84, v35, 2                             ; d6470054 020a4754
	buffer_load_b128 v[44:47], v84, s[36:39], null offen        ; c405c07c 4080482c 00000054
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[68:69], v[88:95] ; cc464058 1d628930
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[68:69], v[96:103] ; cc464060 1d828932
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[70:71], v[128:135] ; cc464080 1e028d32
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[50:51], v[72:73], v[160:167] ; cc4640a0 1e829132
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[50:51], v[74:75], v[7:14] ; cc464007 1c1e9532
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[70:71], v[120:127] ; cc464078 1de28d30
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[72:73], v[152:159] ; cc464098 1e629130
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[48:49], v[74:75], v[184:191] ; cc4640b8 1ee29530
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[68:69], v[104:111] ; cc464068 1da28934
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[70:71], v[136:143] ; cc464088 1e228d34
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[72:73], v[168:175] ; cc4640a8 1ea29134
	s_wait_loadcnt_dscnt 0x207                                  ; bfc80207
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[76:77], v[88:95] ; cc464058 1d629938
	v_wmma_f32_16x16x16_fp8_fp8 v[27:34], v[52:53], v[74:75], v[27:34] ; cc46401b 1c6e9534
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[68:69], v[112:119] ; cc464070 1dc28936
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[54:55], v[70:71], v[144:151] ; cc464090 1e428d36
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[72:73], v[176:183] ; cc4640b0 1ec29136
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[74:75], v[16:23] ; cc464010 1c429536
	v_maxmin_num_f32 v48, -4.0, v88, 4.0                        ; d6690030 03dab0f7
	v_maxmin_num_f32 v52, -4.0, v90, 4.0                        ; d6690034 03dab4f7
	v_maxmin_num_f32 v50, -4.0, v89, 4.0                        ; d6690032 03dab2f7
	v_maxmin_num_f32 v54, -4.0, v91, 4.0                        ; d6690036 03dab6f7
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[78:79], v[120:127] ; cc464078 1de29d38
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[80:81], v[152:159] ; cc464098 1e62a138
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[82:83], v[184:191] ; cc4640b8 1ee2a538
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[76:77], v[96:103] ; cc464060 1d82993a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[78:79], v[128:135] ; cc464080 1e029d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[80:81], v[160:167] ; cc4640a0 1e82a13a
	v_wmma_f32_16x16x16_fp8_fp8 v[7:14], v[58:59], v[82:83], v[7:14] ; cc464007 1c1ea53a
	v_maxmin_num_f32 v58, -4.0, v93, 4.0                        ; d669003a 03dabaf7
	v_fma_mix_f32 v49, 0xab28, |v48|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206231 0bfe60ff 3728ab28
	v_fma_mix_f32 v53, 0xab28, |v52|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206235 0bfe68ff 3728ab28
	v_fma_mix_f32 v51, 0xab28, |v50|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206233 0bfe64ff 3728ab28
	v_fma_mix_f32 v55, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe6cff 3728ab28
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[76:77], v[104:111] ; cc464068 1da2993c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[78:79], v[136:143] ; cc464088 1e229d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[60:61], v[80:81], v[168:175] ; cc4640a8 1ea2a13c
	v_wmma_f32_16x16x16_fp8_fp8 v[27:34], v[60:61], v[82:83], v[27:34] ; cc46401b 1c6ea53c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[76:77], v[112:119] ; cc464070 1dc2993e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[78:79], v[144:151] ; cc464090 1e429d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[80:81], v[176:183] ; cc4640b0 1ec2a13e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[62:63], v[82:83], v[16:23] ; cc464010 1c42a53e
	v_maxmin_num_f32 v56, -4.0, v92, 4.0                        ; d6690038 03dab8f7
	v_fma_mix_f32 v59, 0xab28, |v58|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623b 0bfe74ff 3728ab28
	v_fmaak_f32 v51, v51, v50, 0x3f650000                       ; 5a666533 3f650000
	v_maxmin_num_f32 v62, -4.0, v95, 4.0                        ; d669003e 03dabef7
	v_maxmin_num_f32 v60, -4.0, v94, 4.0                        ; d669003c 03dabcf7
	v_maxmin_num_f32 v67, -4.0, v120, 4.0                       ; d6690043 03daf0f7
	v_maxmin_num_f32 v69, -4.0, v121, 4.0                       ; d6690045 03daf2f7
	v_fma_mix_f32 v57, 0xab28, |v56|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206239 0bfe70ff 3728ab28
	v_dual_mul_f32 v89, v89, v51 :: v_dual_fmaak_f32 v48, v48, v49, 0x3f650000 ; c8c26759 59306330 3f650000
	v_maxmin_num_f32 v71, -4.0, v122, 4.0                       ; d6690047 03daf4f7
	v_fma_mix_f32 v63, 0xab28, |v62|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623f 0bfe7cff 3728ab28
	v_fma_mix_f32 v61, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623d 0bfe78ff 3728ab28
	v_maxmin_num_f32 v73, -4.0, v123, 4.0                       ; d6690049 03daf6f7
	v_fma_mix_f32 v68, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206244 0bfe86ff 3728ab28
	v_fma_mix_f32 v70, 0xab28, |v69|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe8aff 3728ab28
	v_dual_fmaak_f32 v55, v55, v54, 0x3f650000 :: v_dual_mul_f32 v88, v88, v48 ; c8466d37 37586158 3f650000
	v_fma_mix_f32 v72, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe8eff 3728ab28
	v_maxmin_num_f32 v75, -4.0, v124, 4.0                       ; d669004b 03daf8f7
	v_maxmin_num_f32 v77, -4.0, v125, 4.0                       ; d669004d 03dafaf7
	v_fma_mix_f32 v74, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe92ff 3728ab28
	v_dual_fmaak_f32 v67, v67, v68, 0x3f650000 :: v_dual_fmaak_f32 v70, v70, v69, 0x3f650000 ; c8428943 43468b46 3f650000
	v_dual_mul_f32 v91, v91, v55 :: v_dual_fmaak_f32 v52, v52, v53, 0x3f650000 ; c8c26f5b 5b346b34 3f650000
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_fma_mix_f32 v76, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624c 0bfe96ff 3728ab28
	v_maxmin_num_f32 v79, -4.0, v126, 4.0                       ; d669004f 03dafcf7
	v_fma_mix_f32 v78, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe9aff 3728ab28
	v_dual_fmaak_f32 v71, v71, v72, 0x3f650000 :: v_dual_fmaak_f32 v74, v74, v73, 0x3f650000 ; c8429147 474a934a 3f650000
	v_maxmin_num_f32 v81, -4.0, v127, 4.0                       ; d6690051 03dafef7
	v_dual_fmaak_f32 v59, v59, v58, 0x3f650000 :: v_dual_mul_f32 v90, v90, v52 ; c846753b 3b5a695a 3f650000
	v_fma_mix_f32 v80, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe9eff 3728ab28
	v_maxmin_num_f32 v83, -4.0, v152, 4.0                       ; d6690053 03db30f7
	v_dual_fmaak_f32 v75, v75, v76, 0x3f650000 :: v_dual_fmaak_f32 v78, v78, v77, 0x3f650000 ; c842994b 4b4e9b4e 3f650000
	v_dual_mul_f32 v123, v123, v74 :: v_dual_mul_f32 v120, v120, v67 ; c8c6957b 7b788778
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v153, 4.0                       ; d6690058 03db32f7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_dual_mul_f32 v93, v93, v59 :: v_dual_fmaak_f32 v56, v56, v57, 0x3f650000 ; c8c2775d 5d387338 3f650000
	v_fma_mix_f32 v87, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfea6ff 3728ab28
	v_dual_mul_f32 v125, v125, v78 :: v_dual_mul_f32 v122, v122, v71 ; c8c69d7d 7d7a8f7a
	v_maxmin_num_f32 v90, -4.0, v154, 4.0                       ; d669005a 03db34f7
	v_dual_fmaak_f32 v79, v79, v80, 0x3f650000 :: v_dual_fmaak_f32 v82, v82, v81, 0x3f650000 ; c842a14f 4f52a352 3f650000
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_dual_fmaak_f32 v63, v63, v62, 0x3f650000 :: v_dual_mul_f32 v92, v92, v56 ; c8467d3f 3f5c715c 3f650000
	v_fmaak_f32 v83, v83, v87, 0x3f650000                       ; 5aa6af53 3f650000
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_dual_mul_f32 v127, v127, v82 :: v_dual_mul_f32 v124, v124, v75 ; c8c6a57f 7f7c977c
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_mul_f32 v126, v126, v79 ; c846b159 597e9f7e 3f650000
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v92, -4.0, v155, 4.0                       ; d669005c 03db36f7
	v_dual_mul_f32 v95, v95, v63 :: v_dual_fmaak_f32 v60, v60, v61, 0x3f650000 ; c8c27f5f 5f3c7b3c 3f650000
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_mul_f32 v153, v153, v89 :: v_dual_mul_f32 v152, v152, v83 ; c8c6b399 9998a798
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_mul_f32 v121, v121, v70 :: v_dual_mul_f32 v94, v94, v60 ; c8c68d79 795e795e
	v_maxmin_num_f32 v124, -4.0, v159, 4.0                      ; d669007c 03db3ef7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 ; c842b95d 5d5ab75a 3f650000
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v120, -4.0, v157, 4.0                      ; d6690078 03db3af7
	v_maxmin_num_f32 v122, -4.0, v158, 4.0                      ; d669007a 03db3cf7
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v94, -4.0, v156, 4.0                       ; d669005e 03db38f7
	v_maxmin_num_f32 v126, -4.0, v184, 4.0                      ; d669007e 03db70f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v185, 4.0                      ; d6690098 03db72f7
	v_dual_mul_f32 v155, v155, v93 :: v_dual_mul_f32 v154, v154, v90 ; c8c6bb9b 9b9ab59a
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v154, -4.0, v186, 4.0                      ; d669009a 03db74f7
	v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 ; c842f97d 7d7af77a 3f650000
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c842f179 795ebf5e 3f650000
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v127, 0x3f650000 ; c8433199 997eff7e 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_mul_f32 v159, v159, v125 :: v_dual_mul_f32 v158, v158, v122 ; c8c6fb9f 9f9ef59e
	v_dual_mul_f32 v157, v157, v121 :: v_dual_mul_f32 v156, v156, v94 ; c8c6f39d 9d9cbd9c
	v_dual_mul_f32 v185, v185, v153 :: v_dual_mul_f32 v184, v184, v126 ; c8c733b9 b9b8fdb8
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_maxmin_num_f32 v156, -4.0, v187, 4.0                      ; d669009c 03db76f7
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_maxmin_num_f32 v158, -4.0, v188, 4.0                      ; d669009e 03db78f7
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_maxmin_num_f32 v184, -4.0, v189, 4.0                      ; d66900b8 03db7af7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c843399d 9d9b379a 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84371b9 b99f3f9e 3f650000
	v_dual_mul_f32 v187, v187, v157 :: v_dual_mul_f32 v186, v186, v154 ; c8c73bbb bbbb35ba
	v_dual_mul_f32 v189, v189, v185 :: v_dual_mul_f32 v188, v188, v158 ; c8c773bd bdbd3dbc
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v186, -4.0, v190, 4.0                      ; d66900ba 03db7cf7
	v_maxmin_num_f32 v55, -4.0, v98, 4.0                        ; d6690037 03dac4f7
	v_maxmin_num_f32 v57, -4.0, v99, 4.0                        ; d6690039 03dac6f7
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_maxmin_num_f32 v188, -4.0, v191, 4.0                      ; d66900bc 03db7ef7
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v56, 0xab28, |v55|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206238 0bfe6eff 3728ab28
	v_maxmin_num_f32 v59, -4.0, v100, 4.0                       ; d669003b 03dac8f7
	v_fma_mix_f32 v58, 0xab28, |v57|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623a 0bfe72ff 3728ab28
	v_maxmin_num_f32 v61, -4.0, v101, 4.0                       ; d669003d 03dacaf7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v60, 0xab28, |v59|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623c 0bfe76ff 3728ab28
	v_dual_fmaak_f32 v58, v58, v57, 0x3f650000 :: v_dual_fmaak_f32 v55, v55, v56, 0x3f650000 ; c842733a 3a367137 3f650000
	v_maxmin_num_f32 v63, -4.0, v102, 4.0                       ; d669003f 03daccf7
	v_fma_mix_f32 v62, 0xab28, |v61|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623e 0bfe7aff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84379bd bdbb77ba 3f650000
	v_maxmin_num_f32 v68, -4.0, v103, 4.0                       ; d6690044 03dacef7
	v_dual_mul_f32 v98, v98, v55 :: v_dual_mul_f32 v99, v99, v58 ; c8c66f62 62627563
	v_fma_mix_f32 v67, 0xab28, |v63|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206243 0bfe7eff 3728ab28
	v_dual_fmaak_f32 v62, v62, v61, 0x3f650000 :: v_dual_fmaak_f32 v59, v59, v60, 0x3f650000 ; c8427b3e 3e3a793b 3f650000
	v_maxmin_num_f32 v70, -4.0, v128, 4.0                       ; d6690046 03db00f7
	v_dual_mul_f32 v191, v191, v189 :: v_dual_mul_f32 v190, v190, v186 ; c8c77bbf bfbf75be
	v_fma_mix_f32 v69, 0xab28, |v68|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe88ff 3728ab28
	v_maxmin_num_f32 v72, -4.0, v129, 4.0                       ; d6690048 03db02f7
	v_fmaak_f32 v63, v63, v67, 0x3f650000                       ; 5a7e873f 3f650000
	v_dual_mul_f32 v101, v101, v62 :: v_dual_mul_f32 v100, v100, v59 ; c8c67d65 65647764
	v_fma_mix_f32 v71, 0xab28, |v70|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe8cff 3728ab28
	v_maxmin_num_f32 v74, -4.0, v130, 4.0                       ; d669004a 03db04f7
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v190, -4.0, v96, 4.0                       ; d66900be 03dac0f7
	v_fma_mix_f32 v73, 0xab28, |v72|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206249 0bfe90ff 3728ab28
	v_maxmin_num_f32 v76, -4.0, v131, 4.0                       ; d669004c 03db06f7
	v_dual_fmaak_f32 v69, v69, v68, 0x3f650000 :: v_dual_mul_f32 v102, v102, v63 ; c8468945 45667f66 3f650000
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v75, 0xab28, |v74|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624b 0bfe94ff 3728ab28
	v_maxmin_num_f32 v78, -4.0, v132, 4.0                       ; d669004e 03db08f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_maxmin_num_f32 v80, -4.0, v133, 4.0                       ; d6690050 03db0af7
	v_fma_mix_f32 v77, 0xab28, |v76|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624d 0bfe98ff 3728ab28
	v_dual_fmaak_f32 v70, v70, v71, 0x3f650000 :: v_dual_mul_f32 v103, v103, v69 ; c8468f46 46668b67 3f650000
	v_fma_mix_f32 v79, 0xab28, |v78|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624f 0bfe9cff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v135, 4.0                       ; d6690057 03db0ef7
	v_fmaak_f32 v190, v190, v191, 0x3f650000                    ; 5b7d7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v97, 4.0                       ; d66900bf 03dac2f7
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_dual_fmaak_f32 v73, v73, v72, 0x3f650000 :: v_dual_mul_f32 v128, v128, v70 ; c8469149 49808d80 3f650000
	v_maxmin_num_f32 v82, -4.0, v134, 4.0                       ; d6690052 03db0cf7
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v160, 4.0                       ; d6690059 03db40f7
	v_fma_mix_f32 v54, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206236 0bff7eff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v161, 4.0                       ; d669005b 03db42f7
	v_dual_fmaak_f32 v74, v74, v75, 0x3f650000 :: v_dual_mul_f32 v129, v129, v73 ; c846974a 4a809381 3f650000
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v162, 4.0                       ; d669005d 03db44f7
	v_fmaak_f32 v54, v54, v191, 0x3f650000                      ; 5a6d7f36 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v77, v77, v76, 0x3f650000 :: v_dual_mul_f32 v130, v130, v74 ; c846994d 4d829582 3f650000
	v_maxmin_num_f32 v95, -4.0, v163, 4.0                       ; d669005f 03db46f7
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_mul_f32 v96, v190, v96 :: v_dual_mul_f32 v97, v97, v54 ; c8c6c1be 60606d61
	v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842b559 595cb75c 3f650000
	v_dual_fmaak_f32 v78, v78, v79, 0x3f650000 :: v_dual_mul_f32 v131, v131, v77 ; c8469f4e 4e829b83 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v97, -4.0, v164, 4.0                       ; d6690061 03db48f7
	v_maxmin_num_f32 v99, -4.0, v165, 4.0                       ; d6690063 03db4af7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_dual_fmaak_f32 v81, v81, v80, 0x3f650000 :: v_dual_mul_f32 v132, v132, v78 ; c846a151 51849d84 3f650000
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v101, -4.0, v166, 4.0                      ; d6690065 03db4cf7
	v_maxmin_num_f32 v103, -4.0, v167, 4.0                      ; d6690067 03db4ef7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842bd5d 5d60bf60 3f650000
	v_maxmin_num_f32 v121, -4.0, v7, 4.0                        ; d6690079 03da0ef7
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_mul_f32 v133, v133, v81 ; c846af58 5884a385 3f650000
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v8, 4.0                        ; d669007b 03da10f7
	v_fma_mix_f32 v120, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeceff 3728ab28
	v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 ; c842c561 6164c764 3f650000
	v_dual_mul_f32 v163, v163, v96 :: v_dual_mul_f32 v160, v160, v89 ; c8c6c1a3 a3a0b3a0
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v9, 4.0                        ; d669007d 03da12f7
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v135, v135, v88 :: v_dual_fmaak_f32 v82, v82, v83, 0x3f650000 ; c8c2b187 8752a752 3f650000
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v10, 4.0                       ; d669007f 03da14f7
	v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v103, 0x3f650000 ; c842cd65 6578cf78 3f650000
	v_dual_mul_f32 v165, v165, v100 :: v_dual_mul_f32 v162, v162, v93 ; c8c6c9a5 a5a2bba2
	v_maxmin_num_f32 v129, -4.0, v11, 4.0                       ; d6690081 03da16f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_dual_mul_f32 v161, v161, v92 :: v_dual_mul_f32 v134, v134, v82 ; c8c6b9a1 a186a586
	v_maxmin_num_f32 v131, -4.0, v12, 4.0                       ; d6690083 03da18f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_mul_f32 v166, v166, v101 ; c846f579 79a6cba6 3f650000
	v_dual_mul_f32 v167, v167, v120 :: v_dual_mul_f32 v164, v164, v97 ; c8c6f1a7 a7a4c3a4
	v_maxmin_num_f32 v133, -4.0, v13, 4.0                       ; d6690085 03da1af7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v135, -4.0, v14, 4.0                       ; d6690087 03da1cf7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_mul_f32 v7, v7, v121 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c8c2f307 077cf77c 3f650000
	v_maxmin_num_f32 v153, -4.0, v104, 4.0                      ; d6690099 03dad0f7
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v105, 4.0                      ; d669009b 03dad2f7
	v_fma_mix_f32 v152, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff0eff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v106, 4.0                      ; d669009d 03dad4f7
	v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 :: v_dual_mul_f32 v8, v8, v124 ; c846fd7d 7d08f908 3f650000
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v159, -4.0, v107, 4.0                      ; d669009f 03dad6f7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v108, 4.0                      ; d66900a1 03dad8f7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v109, 4.0                      ; d66900a3 03dadaf7
	v_dual_mul_f32 v9, v9, v125 :: v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 ; c8c2fb09 0980ff80 3f650000
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                        ; 02021107
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c843379c 9c993599 3f650000
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v110, 4.0                      ; d66900a5 03dadcf7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v111, 4.0                      ; d66900a7 03dadef7
	v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 :: v_dual_mul_f32 v10, v10, v128 ; c8470581 810b010a 3f650000
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c8433fa0 a09d3d9d 3f650000
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v136, 4.0                      ; d66900b9 03db10f7
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 ; c84345a1 a1a547a4 3f650000
	v_fma_mix_f32 v184, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff4eff 3728ab28
	v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 :: v_dual_mul_f32 v11, v11, v129 ; c8470784 840b030b 3f650000
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                       ; 02021509
	v_dual_mul_f32 v107, v107, v160 :: v_dual_mul_f32 v104, v104, v153 ; c8c7416b 6b693368
	v_maxmin_num_f32 v187, -4.0, v137, 4.0                      ; d66900bb 03db12f7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v138, 4.0                      ; d66900bd 03db14f7
	v_dual_mul_f32 v109, v109, v164 :: v_dual_mul_f32 v106, v106, v157 ; c8c7496d 6d6b3b6a
	v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v167, 0x3f650000 ; c8434da5 a5b94fb8 3f650000
	v_maxmin_num_f32 v191, -4.0, v139, 4.0                      ; d66900bf 03db16f7
	v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 :: v_dual_mul_f32 v12, v12, v132 ; c8470d85 850d090c 3f650000
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_mul_f32 v111, v111, v184 :: v_dual_mul_f32 v108, v108, v161 ; c8c7716f 6f6d436c
	v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 :: v_dual_mul_f32 v110, v110, v165 ; c84775b9 b96f4b6e 3f650000
	v_fma_mix_f32 v7, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206207 0bff7eff 3728ab28
	v_dual_fmaak_f32 v152, v152, v135, 0x3f650000 :: v_dual_mul_f32 v13, v13, v133 ; c8470f98 980d0b0d 3f650000
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v11, v12, vcc_lo                      ; 0202190b
	v_maxmin_num_f32 v11, -4.0, v140, 4.0                       ; d669000b 03db18f7
	v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 ; c8437dbd bdbd77bc 3f650000
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v67, -4.0, v143, 4.0                       ; d6690043 03db1ef7
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_fmaak_f32 v7, v7, v191, 0x3f650000 :: v_dual_mul_f32 v136, v136, v185 ; c8477f07 07897388 3f650000
	v_maxmin_num_f32 v62, -4.0, v142, 4.0                       ; d669003e 03db1cf7
	v_dual_mul_f32 v105, v156, v105 :: v_dual_mul_f32 v14, v14, v152 ; c8c6d39c 690f310e
	v_fma_mix_f32 v12, 0xab28, |v11|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620c 0bfe16ff 3728ab28
	v_maxmin_num_f32 v69, -4.0, v168, 4.0                       ; d6690045 03db50f7
	v_fma_mix_f32 v68, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206244 0bfe86ff 3728ab28
	v_maxmin_num_f32 v71, -4.0, v169, 4.0                       ; d6690047 03db52f7
	v_fma_mix_f32 v63, 0xab28, |v62|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623f 0bfe7cff 3728ab28
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                      ; 02021d0d
	v_maxmin_num_f32 v13, -4.0, v141, 4.0                       ; d669000d 03db1af7
	v_dual_fmaak_f32 v11, v11, v12, 0x3f650000 :: v_dual_mul_f32 v138, v138, v189 ; c846190b 0b8b7b8a 3f650000
	v_maxmin_num_f32 v73, -4.0, v170, 4.0                       ; d6690049 03db54f7
	v_fma_mix_f32 v70, 0xab28, |v69|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe8aff 3728ab28
	v_fma_mix_f32 v72, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe8eff 3728ab28
	v_maxmin_num_f32 v75, -4.0, v171, 4.0                       ; d669004b 03db56f7
	v_maxmin_num_f32 v77, -4.0, v172, 4.0                       ; d669004d 03db58f7
	v_fma_mix_f32 v14, 0xab28, |v13|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620e 0bfe1aff 3728ab28
	v_dual_mul_f32 v140, v140, v11 :: v_dual_mul_f32 v137, v137, v188 ; c8c6178c 8c897989
	v_fma_mix_f32 v74, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe92ff 3728ab28
	v_maxmin_num_f32 v79, -4.0, v173, 4.0                       ; d669004f 03db5af7
	v_dual_fmaak_f32 v72, v72, v71, 0x3f650000 :: v_dual_fmaak_f32 v69, v69, v70, 0x3f650000 ; c8428f48 48448d45 3f650000
	v_fma_mix_f32 v76, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624c 0bfe96ff 3728ab28
	v_fma_mix_f32 v78, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe9aff 3728ab28
	v_dual_mul_f32 v139, v139, v7 :: v_dual_fmaak_f32 v14, v14, v13, 0x3f650000 ; c8c20f8b 8b0e1b0e 3f650000
	v_maxmin_num_f32 v81, -4.0, v174, 4.0                       ; d6690051 03db5cf7
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_maxmin_num_f32 v83, -4.0, v175, 4.0                       ; d6690053 03db5ef7
	v_fma_mix_f32 v80, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe9eff 3728ab28
	v_dual_fmaak_f32 v73, v73, v74, 0x3f650000 :: v_dual_fmaak_f32 v76, v76, v75, 0x3f650000 ; c8429549 494c974c 3f650000
	v_maxmin_num_f32 v88, -4.0, v27, 4.0                        ; d6690058 03da36f7
	v_dual_fmaak_f32 v68, v68, v67, 0x3f650000 :: v_dual_mul_f32 v141, v141, v14 ; c8468744 448c1d8d 3f650000
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_fma_mix_f32 v87, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfea6ff 3728ab28
	v_dual_fmaak_f32 v77, v77, v78, 0x3f650000 :: v_dual_fmaak_f32 v80, v80, v79, 0x3f650000 ; c8429d4d 4d509f50 3f650000
	v_dual_mul_f32 v171, v171, v76 :: v_dual_mul_f32 v168, v168, v69 ; c8c699ab aba88ba8
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v68 :: v_dual_fmaak_f32 v62, v62, v63, 0x3f650000 ; c8c2898f 8f3e7f3e 3f650000
	v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 :: v_dual_mul_f32 v172, v172, v77 ; c846a551 51ac9bac 3f650000
	v_dual_mul_f32 v173, v173, v80 :: v_dual_mul_f32 v170, v170, v73 ; c8c6a1ad adaa93aa
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
	v_dual_mul_f32 v169, v169, v72 :: v_dual_mul_f32 v142, v142, v62 ; c8c691a9 a98e7d8e
	v_dual_fmaak_f32 v87, v87, v83, 0x3f650000 :: v_dual_mul_f32 v174, v174, v81 ; c846a757 57aea3ae 3f650000
	v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 :: v_dual_mul_f32 v175, v175, v87 ; c846b358 58aeafaf 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v27, v27, v88 :: v_dual_add_nc_u32 v26, 6, v26 ; c8e0b11b 1b1a3486
	v_sub_nc_u32_e32 v90, 0, v26                                ; 4cb43480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v90, v26, v90                                 ; 24b4b51a
	v_med3_i32 v26, -1, v26, 1                                  ; d620001a 020634c1
	v_lshrrev_b32_e32 v90, 1, v90                               ; 32b4b481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c001a
	v_cndmask_b32_e32 v1, v26, v90, vcc_lo                      ; 0202b51a
	v_lshl_add_u32 v26, v26, 9, s4                              ; d646001a 0011131a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v26, v26, v35, 2                             ; d647001a 020a471a
	buffer_load_b128 v[68:71], v26, s[36:39], null offen        ; c405c07c 40804844 0000001a
	v_maxmin_num_f32 v91, -4.0, v28, 4.0                        ; d669005b 03da38f7
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_maxmin_num_f32 v93, -4.0, v29, 4.0                        ; d669005d 03da3af7
	v_maxmin_num_f32 v95, -4.0, v30, 4.0                        ; d669005f 03da3cf7
	v_maxmin_num_f32 v97, -4.0, v31, 4.0                        ; d6690061 03da3ef7
	v_maxmin_num_f32 v99, -4.0, v32, 4.0                        ; d6690063 03da40f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v33, 4.0                       ; d6690065 03da42f7
	v_maxmin_num_f32 v103, -4.0, v34, 4.0                       ; d6690067 03da44f7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v105, -4.0, v112, 4.0                      ; d6690069 03dae0f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v113, 4.0                      ; d669006b 03dae2f7
	v_fmaak_f32 v92, v92, v91, 0x3f650000                       ; 5ab8b75c 3f650000
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_maxmin_num_f32 v109, -4.0, v114, 4.0                      ; d669006d 03dae4f7
	v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 :: v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 ; c842c764 6460c561 3f650000
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_maxmin_num_f32 v111, -4.0, v115, 4.0                      ; d669006f 03dae6f7
	v_mul_f32_e32 v28, v28, v92                                 ; 1038b91c
	v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 :: v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 ; c842cf68 6864cd65 3f650000
	v_dual_mul_f32 v30, v30, v96 :: v_dual_mul_f32 v29, v29, v93 ; c8c6c11e 1e1cbb1d
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_dual_mul_f32 v32, v32, v100 :: v_dual_mul_f32 v31, v31, v97 ; c8c6c920 201ec31f
	v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 :: v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 ; c842d76c 6c68d569 3f650000
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                      ; 0202391b
	v_dual_mul_f32 v34, v34, v104 :: v_dual_mul_f32 v33, v33, v101 ; c8c6d122 2220cb21
	v_maxmin_num_f32 v121, -4.0, v118, 4.0                      ; d6690079 03daecf7
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v29, v30, vcc_lo                      ; 02023d1d
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                      ; 0202411f
	v_maxmin_num_f32 v123, -4.0, v119, 4.0                      ; d669007b 03daeef7
	v_dual_mul_f32 v113, v113, v108 :: v_dual_mul_f32 v112, v112, v105 ; c8c6d971 7170d370
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                      ; 02024521
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v144, 4.0                      ; d669007d 03db20f7
	v_maxmin_num_f32 v127, -4.0, v145, 4.0                      ; d669007f 03db22f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v113, -4.0, v116, 4.0                      ; d6690071 03dae8f7
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v146, 4.0                      ; d6690081 03db24f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c842f579 797cf77c 3f650000
	v_maxmin_num_f32 v131, -4.0, v147, 4.0                      ; d6690083 03db26f7
	v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 :: v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 ; c842df70 706cdd6d 3f650000
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842ff80 807cfd7d 3f650000
	v_maxmin_num_f32 v133, -4.0, v148, 4.0                      ; d6690085 03db28f7
	v_dual_mul_f32 v119, v119, v124 :: v_dual_mul_f32 v118, v118, v121 ; c8c6f977 7776f376
	v_maxmin_num_f32 v135, -4.0, v149, 4.0                      ; d6690087 03db2af7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_mul_f32 v115, v115, v112 :: v_dual_mul_f32 v114, v114, v109 ; c8c6e173 7372db72
	v_dual_mul_f32 v145, v145, v128 :: v_dual_mul_f32 v144, v144, v125 ; c8c70191 9190fb90
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v137, -4.0, v150, 4.0                      ; d6690089 03db2cf7
	v_maxmin_num_f32 v139, -4.0, v151, 4.0                      ; d669008b 03db2ef7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 ; c8430784 84810581 3f650000
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v115, -4.0, v117, 4.0                      ; d6690073 03daeaf7
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_maxmin_num_f32 v141, -4.0, v176, 4.0                      ; d669008d 03db60f7
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430f88 88850d85 3f650000
	v_maxmin_num_f32 v143, -4.0, v177, 4.0                      ; d669008f 03db62f7
	v_dual_mul_f32 v147, v147, v132 :: v_dual_mul_f32 v146, v146, v129 ; c8c70993 93930392
	v_fma_mix_f32 v120, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfee6ff 3728ab28
	v_maxmin_num_f32 v145, -4.0, v178, 4.0                      ; d6690091 03db64f7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_dual_fmaak_f32 v140, v140, v139, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 ; c843178c 8c891589 3f650000
	v_dual_mul_f32 v149, v149, v136 :: v_dual_mul_f32 v148, v148, v133 ; c8c71195 95950b94
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_maxmin_num_f32 v147, -4.0, v179, 4.0                      ; d6690093 03db66f7
	v_dual_fmaak_f32 v120, v120, v115, 0x3f650000 :: v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 ; c842e778 7870e571 3f650000
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_dual_mul_f32 v151, v151, v140 :: v_dual_mul_f32 v150, v150, v137 ; c8c71997 97971396
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v149, -4.0, v180, 4.0                      ; d6690095 03db68f7
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c8431f90 908d1d8d 3f650000
	v_maxmin_num_f32 v153, -4.0, v182, 4.0                      ; d6690099 03db6cf7
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_dual_mul_f32 v117, v117, v120 :: v_dual_mul_f32 v116, v116, v113 ; c8c6f175 7574e374
	v_maxmin_num_f32 v155, -4.0, v183, 4.0                      ; d669009b 03db6ef7
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_maxmin_num_f32 v151, -4.0, v181, 4.0                      ; d6690097 03db6af7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_mul_f32 v177, v177, v144 :: v_dual_mul_f32 v176, v176, v141 ; c8c721b1 b1b11bb0
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v16, 4.0                       ; d669009d 03da20f7
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8432794 94912591 3f650000
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v159, -4.0, v17, 4.0                       ; d669009f 03da22f7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v18, 4.0                       ; d66900a1 03da24f7
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_maxmin_num_f32 v163, -4.0, v19, 4.0                       ; d66900a3 03da26f7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_mul_f32 v179, v179, v148 :: v_dual_mul_f32 v178, v178, v145 ; c8c729b3 b3b323b2
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v20, 4.0                       ; d66900a5 03da28f7
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c843379c 9c993599 3f650000
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432f98 98952d95 3f650000
	v_maxmin_num_f32 v167, -4.0, v21, 4.0                       ; d66900a7 03da2af7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c8433fa0 a09d3d9d 3f650000
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_mul_f32 v183, v183, v156 :: v_dual_mul_f32 v182, v182, v153 ; c8c739b7 b7b733b6
	v_dual_mul_f32 v181, v181, v152 :: v_dual_mul_f32 v180, v180, v149 ; c8c731b5 b5b52bb4
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c84347a4 a4a145a1 3f650000
	v_dual_mul_f32 v17, v17, v160 :: v_dual_mul_f32 v16, v16, v157 ; c8c74111 11113b10
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 ; c8434fa8 a8a54da5 3f650000
	v_dual_mul_f32 v19, v19, v164 :: v_dual_mul_f32 v18, v18, v161 ; c8c74913 13134312
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_dual_mul_f32 v21, v21, v168 :: v_dual_mul_f32 v20, v20, v165 ; c8c75115 15154b14
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	ds_load_b64 v[18:19], v85 offset:256                        ; d9d80100 12000055
	ds_load_b64 v[20:21], v85 offset:1280                       ; d9d80500 14000055
	ds_load_b64 v[72:73], v85 offset:2304                       ; d9d80900 48000055
	ds_load_b64 v[74:75], v85 offset:3328                       ; d9d80d00 4a000055
	v_maxmin_num_f32 v169, -4.0, v22, 4.0                       ; d66900a9 03da2cf7
	v_maxmin_num_f32 v171, -4.0, v23, 4.0                       ; d66900ab 03da2ef7
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[36:37], 0 ; cc464058 1a02492c
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[38:39], 0 ; cc464060 1a024d2c
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[40:41], 0 ; cc464068 1a02512c
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[42:43], 0 ; cc464070 1a02552c
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[36:37], 0 ; cc464078 1a02492e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[38:39], 0 ; cc464080 1a024d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[40:41], 0 ; cc464088 1a02512e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[46:47], v[42:43], 0 ; cc464090 1a02552e
	v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 ; c84357ac aca955a9 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_mul_f32_e32 v23, v23, v172                                ; 102f5917
	v_dual_mov_b32 v7, v35 :: v_dual_mul_f32 v22, v22, v169     ; ca060123 07175316
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	v_dual_mov_b32 v23, v33 :: v_dual_mov_b32 v22, v32          ; ca100121 17160120
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[38:39], 0 ; cc4640a0 1a024d44
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[70:71], v[38:39], 0 ; cc46404c 1a024d46
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[36:37], 0 ; cc464098 1a024944
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[68:69], v[42:43], 0 ; cc4640b0 1a025544
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[36:37], 0 ; cc4640b8 1a024946
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[70:71], v[40:41], 0 ; cc464020 1a025146
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[40:41], 0 ; cc4640a8 1a025144
	v_dual_mov_b32 v69, v43 :: v_dual_mov_b32 v68, v42          ; ca10012b 4544012a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[70:71], v[68:69], 0 ; cc464028 1a028946
	buffer_load_b128 v[68:71], v84, s[36:39], null offen offset:512 ; c405c07c 40804844 00020054
	v_mov_b32_e32 v14, v66                                      ; 7e1c0342
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[68:69], v[74:75], v[112:119] ; cc464070 1dc29544
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[20:21], v[96:103] ; cc464060 1d822944
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[18:19], v[88:95] ; cc464058 1d622544
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[72:73], v[104:111] ; cc464068 1da29144
	buffer_load_b128 v[66:69], v26, s[36:39], null offen offset:512 ; c405c07c 40804842 0002001a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[18:19], v[120:127] ; cc464078 1de22546
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[20:21], v[128:135] ; cc464080 1e022946
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[72:73], v[136:143] ; cc464088 1e229146
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[74:75], v[144:151] ; cc464090 1e429546
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[66:67], v[18:19], v[152:159] ; cc464098 1e622542
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[68:69], v[20:21], v[76:83] ; cc46404c 1d322944
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[66:67], v[72:73], v[168:175] ; cc4640a8 1ea29142
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[20:21], v[160:167] ; cc4640a0 1e822942
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[66:67], v[74:75], v[176:183] ; cc4640b0 1ec29542
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[68:69], v[18:19], v[184:191] ; cc4640b8 1ee22544
	ds_load_b64 v[70:71], v85 offset:512                        ; d9d80200 46000055
	ds_load_b64 v[66:67], v85 offset:1536                       ; d9d80600 42000055
	ds_load_b64 v[18:19], v85 offset:2560                       ; d9d80a00 12000055
	ds_load_b64 v[20:21], v85 offset:3584                       ; d9d80e00 14000055
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[68:69], v[74:75], v[40:47] ; cc464028 1ca29544
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[68:69], v[72:73], v[32:39] ; cc464020 1c829144
	buffer_load_b128 v[72:75], v84, s[36:39], null offen offset:1024 ; c405c07c 40804848 00040054
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mov_b32 v68, v75 :: v_dual_mov_b32 v27, v74          ; ca10014b 441a014a
	s_wait_dscnt 0x3                                            ; bfc60003
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[70:71], v[88:95] ; cc464058 1d628d48
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[18:19], v[104:111] ; cc464068 1da22548
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[72:73], v[20:21], v[112:119] ; cc464070 1dc22948
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[66:67], v[96:103] ; cc464060 1d828548
	buffer_load_b128 v[72:75], v26, s[36:39], null offen offset:1024 ; c405c07c 40804848 0004001a
	v_dual_mov_b32 v69, v68 :: v_dual_mov_b32 v68, v27          ; ca100144 4544011b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[18:19], v[136:143] ; cc464088 1e222544
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[70:71], v[120:127] ; cc464078 1de28d44
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[68:69], v[66:67], v[128:135] ; cc464080 1e028544
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[20:21], v[144:151] ; cc464090 1e422944
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[72:73], v[20:21], v[176:183] ; cc4640b0 1ec22948
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[74:75], v[70:71], v[184:191] ; cc4640b8 1ee28d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[66:67], v[160:167] ; cc4640a0 1e828548
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[74:75], v[66:67], v[76:83] ; cc46404c 1d32854a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[72:73], v[70:71], v[152:159] ; cc464098 1e628d48
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[18:19], v[168:175] ; cc4640a8 1ea22548
	ds_load_b64 v[68:69], v85 offset:768                        ; d9d80300 44000055
	ds_load_b64 v[72:73], v85 offset:1792                       ; d9d80700 48000055
	ds_load_b64 v[70:71], v85 offset:2816                       ; d9d80b00 46000055
	ds_load_b64 v[66:67], v85 offset:3840                       ; d9d80f00 42000055
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[74:75], v[18:19], v[32:39] ; cc464020 1c82254a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[74:75], v[20:21], v[40:47] ; cc464028 1ca2294a
	v_mov_b32_e32 v74, v86                                      ; 7e940356
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[18:21], v84, s[36:39], null offen offset:1536 ; c405c07c 40804812 00060054
	buffer_load_b128 v[84:87], v26, s[36:39], null offen offset:1536 ; c405c07c 40804854 0006001a
	s_lshr_b32 s12, s12, 2                                      ; 850c820c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	v_lshl_add_u32 v75, v1, 10, s12                             ; d646004b 00311501
	v_add_lshl_u32 v75, v75, v7, 2                              ; d647004b 020a0f4b
	s_wait_loadcnt_dscnt 0x102                                  ; bfc80102
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[18:19], v[72:73], v[96:103] ; cc464060 1d829112
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[20:21], v[66:67], v[144:151] ; cc464090 1e428514
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[70:71], v[104:111] ; cc464068 1da28d12
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[66:67], v[112:119] ; cc464070 1dc28512
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[20:21], v[68:69], v[120:127] ; cc464078 1de28914
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[20:21], v[72:73], v[128:135] ; cc464080 1e029114
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[20:21], v[70:71], v[136:143] ; cc464088 1e228d14
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[18:19], v[68:69], v[88:95] ; cc464058 1d628912
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_maxmin_num_f32 v18, -4.0, v88, 4.0                        ; d6690012 03dab0f7
	v_maxmin_num_f32 v20, -4.0, v89, 4.0                        ; d6690014 03dab2f7
	v_maxmin_num_f32 v26, -4.0, v90, 4.0                        ; d669001a 03dab4f7
	v_fma_mix_f32 v19, 0xab28, |v18|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206213 0bfe24ff 3728ab28
	v_fma_mix_f32 v21, 0xab28, |v20|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfe28ff 3728ab28
	v_fma_mix_f32 v27, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe34ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v21, v21, v20, 0x3f650000 :: v_dual_fmaak_f32 v18, v18, v19, 0x3f650000 ; c8422915 15122712 3f650000
	v_maxmin_num_f32 v19, -4.0, v93, 4.0                        ; d6690013 03dabaf7
	v_dual_mul_f32 v89, v89, v21 :: v_dual_mul_f32 v88, v88, v18 ; c8c62b59 59582558
	v_maxmin_num_f32 v21, -4.0, v94, 4.0                        ; d6690015 03dabcf7
	v_fma_mix_f32 v20, 0xab28, |v19|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206214 0bfe26ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v91, 4.0                        ; d6690058 03dab6f7
	v_fmaak_f32 v20, v20, v19, 0x3f650000                       ; 5a282714 3f650000
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_fmaak_f32 v26, v26, v27, 0x3f650000 ; c842b159 591a371a 3f650000
	v_maxmin_num_f32 v27, -4.0, v95, 4.0                        ; d669001b 03dabef7
	v_dual_mul_f32 v91, v91, v89 :: v_dual_mul_f32 v90, v90, v26 ; c8c6b35b 5b5a355a
	v_fma_mix_f32 v26, 0xab28, |v21|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe2aff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v96, 4.0                        ; d6690059 03dac0f7
	v_fma_mix_f32 v88, 0xab28, |v27|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfe36ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v90, -4.0, v92, 4.0                        ; d669005a 03dab8f7
	v_dual_fmaak_f32 v88, v88, v27, 0x3f650000 :: v_dual_fmaak_f32 v21, v21, v26, 0x3f650000 ; c8423758 58143515 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_dual_mul_f32 v94, v94, v21 :: v_dual_mul_f32 v95, v95, v88 ; c8c62b5e 5e5eb15f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmaak_f32 v90, v90, v91, 0x3f650000                       ; 5ab4b75a 3f650000
	v_maxmin_num_f32 v91, -4.0, v97, 4.0                        ; d669005b 03dac2f7
	v_dual_mul_f32 v92, v92, v90 :: v_dual_mul_f32 v93, v93, v20 ; c8c6b55c 5c5c295d
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v93, -4.0, v98, 4.0                        ; d669005d 03dac4f7
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v99, 4.0                        ; d669005f 03dac6f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v26, -4.0, v102, 4.0                       ; d669001a 03daccf7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v103, 4.0                       ; d6690058 03dacef7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842b559 595cb75c 3f650000
	v_fma_mix_f32 v27, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe34ff 3728ab28
	v_dual_mul_f32 v97, v97, v92 :: v_dual_mul_f32 v96, v96, v89 ; c8c6b961 6160b360
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v90, -4.0, v104, 4.0                       ; d669005a 03dad0f7
	v_maxmin_num_f32 v92, -4.0, v105, 4.0                       ; d669005c 03dad2f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v100, 4.0                       ; d6690061 03dac8f7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_dual_fmaak_f32 v89, v89, v88, 0x3f650000 :: v_dual_fmaak_f32 v26, v26, v27, 0x3f650000 ; c842b159 591a371a 3f650000
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_maxmin_num_f32 v94, -4.0, v106, 4.0                       ; d669005e 03dad4f7
	v_dual_mul_f32 v103, v103, v89 :: v_dual_mul_f32 v102, v102, v26 ; c8c6b367 67663566
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v99, v99, v96 :: v_dual_mul_f32 v98, v98, v93 ; c8c6c163 6362bb62
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v96, -4.0, v107, 4.0                       ; d6690060 03dad6f7
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v101, 4.0                       ; d6690063 03dacaf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 ; c842b95d 5d5ab75a 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_fma_mix_f32 v21, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bfec6ff 3728ab28
	v_fmaak_f32 v97, v97, v98, 0x3f650000                       ; 5ac2c561 3f650000
	v_maxmin_num_f32 v98, -4.0, v108, 4.0                       ; d6690062 03dad8f7
	v_dual_mul_f32 v105, v105, v93 :: v_dual_mul_f32 v104, v104, v90 ; c8c6bb69 6968b568
	v_dual_fmaak_f32 v21, v21, v99, 0x3f650000 :: v_dual_mul_f32 v100, v100, v97 ; c846c715 1564c364 3f650000
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v104, -4.0, v111, 4.0                      ; d6690068 03dadef7
	v_mul_f32_e32 v101, v101, v21                               ; 10ca2b65
	v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c842c161 615ebf5e 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v100, -4.0, v109, 4.0                      ; d6690064 03dadaf7
	v_maxmin_num_f32 v102, -4.0, v110, 4.0                      ; d6690066 03dadcf7
	v_dual_mul_f32 v107, v107, v97 :: v_dual_mul_f32 v106, v106, v94 ; c8c6c36b 6b6abd6a
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v106, -4.0, v112, 4.0                      ; d669006a 03dae0f7
	v_dual_fmaak_f32 v101, v101, v100, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v99, 0x3f650000 ; c842c965 6562c762 3f650000
	v_dual_fmaak_f32 v105, v105, v104, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 ; c842d169 6966cf66 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_dual_mul_f32 v109, v109, v101 :: v_dual_mul_f32 v108, v108, v98 ; c8c6cb6d 6d6cc56c
	v_dual_mul_f32 v111, v111, v105 :: v_dual_mul_f32 v110, v110, v102 ; c8c6d36f 6f6ecd6e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870252
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v108, -4.0, v113, 4.0                      ; d669006c 03dae2f7
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v110, -4.0, v114, 4.0                      ; d669006e 03dae4f7
	v_maxmin_num_f32 v89, -4.0, v117, 4.0                       ; d6690059 03daeaf7
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v118, 4.0                       ; d669005b 03daecf7
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v119, 4.0                       ; d669005d 03daeef7
	v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v107, 0x3f650000 ; c842d96d 6d6ad76a 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v120, 4.0                       ; d669005f 03daf0f7
	v_fmaak_f32 v90, v90, v89, 0x3f650000                       ; 5ab4b35a 3f650000
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v121, 4.0                       ; d6690061 03daf2f7
	v_dual_mul_f32 v113, v113, v109 :: v_dual_mul_f32 v112, v112, v106 ; c8c6db71 7170d570
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 :: v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 ; c842bb5e 5e5ab95b 3f650000
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v122, 4.0                       ; d6690063 03daf4f7
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v112, -4.0, v115, 4.0                      ; d6690070 03dae6f7
	v_maxmin_num_f32 v101, -4.0, v123, 4.0                      ; d6690065 03daf6f7
	v_dual_mul_f32 v118, v118, v91 :: v_dual_mul_f32 v119, v119, v94 ; c8c6b776 7676bd77
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c842c362 625ec15f 3f650000
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v124, 4.0                      ; d6690067 03daf8f7
	v_maxmin_num_f32 v105, -4.0, v125, 4.0                      ; d6690069 03dafaf7
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_dual_mul_f32 v121, v121, v98 :: v_dual_mul_f32 v120, v120, v95 ; c8c6c579 7978bf78
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v126, 4.0                      ; d669006b 03dafcf7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e171 716edf6e 3f650000
	v_maxmin_num_f32 v109, -4.0, v127, 4.0                      ; d669006d 03dafef7
	v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 :: v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 ; c842cb66 6662c963 3f650000
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 :: v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 ; c842d36a 6a66d167 3f650000
	v_dual_mul_f32 v115, v115, v113 :: v_dual_mul_f32 v114, v114, v110 ; c8c6e373 7372dd72
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[84:85], v[68:69], v[152:159] ; cc464098 1e628954
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[84:85], v[72:73], v[160:167] ; cc4640a0 1e829154
	v_dual_mul_f32 v123, v123, v102 :: v_dual_mul_f32 v122, v122, v99 ; c8c6cd7b 7b7ac77a
	v_dual_mul_f32 v125, v125, v106 :: v_dual_mul_f32 v124, v124, v103 ; c8c6d57d 7d7ccf7c
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v114, -4.0, v116, 4.0                      ; d6690072 03dae8f7
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[84:85], v[70:71], v[168:175] ; cc4640a8 1ea28d54
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[84:85], v[66:67], v[176:183] ; cc4640b0 1ec28554
	v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 :: v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 ; c842db6e 6e6ad96b 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[86:87], v[68:69], v[184:191] ; cc4640b8 1ee28956
	v_wmma_f32_16x16x16_fp8_fp8 v[76:83], v[86:87], v[72:73], v[76:83] ; cc46404c 1d329156
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[86:87], v[70:71], v[32:39] ; cc464020 1c828d56
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[86:87], v[66:67], v[40:47] ; cc464028 1ca28556
	v_maxmin_num_f32 v111, -4.0, v128, 4.0                      ; d669006f 03db00f7
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v113, -4.0, v129, 4.0                      ; d6690071 03db02f7
	v_dual_mul_f32 v127, v127, v110 :: v_dual_mul_f32 v126, v126, v107 ; c8c6dd7f 7f7ed77e
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_fmaak_f32 v114, v114, v115, 0x3f650000                    ; 5ae4e772 3f650000
	v_maxmin_num_f32 v115, -4.0, v130, 4.0                      ; d6690073 03db04f7
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_mul_f32 v116, v114, v116 :: v_dual_mul_f32 v117, v117, v90 ; c8c6e972 7474b575
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v133, 4.0                      ; d6690079 03db0af7
	v_maxmin_num_f32 v123, -4.0, v134, 4.0                      ; d669007b 03db0cf7
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v117, -4.0, v131, 4.0                      ; d6690075 03db06f7
	v_maxmin_num_f32 v119, -4.0, v132, 4.0                      ; d6690077 03db08f7
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v135, 4.0                      ; d669007d 03db0ef7
	v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 :: v_dual_fmaak_f32 v111, v111, v112, 0x3f650000 ; c842e372 726ee16f 3f650000
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v136, 4.0                      ; d669007f 03db10f7
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_dual_mul_f32 v129, v129, v114 :: v_dual_mul_f32 v128, v128, v111 ; c8c6e581 8180df80
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v118, v118, v117, 0x3f650000 :: v_dual_fmaak_f32 v115, v115, v116, 0x3f650000 ; c842eb76 7672e973 3f650000
	v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 :: v_dual_fmaak_f32 v119, v119, v120, 0x3f650000 ; c842f37a 7a76f177 3f650000
	v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 ; c842fb7e 7e7af97b 3f650000
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v129, -4.0, v137, 4.0                      ; d6690081 03db12f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_dual_mul_f32 v131, v131, v118 :: v_dual_mul_f32 v130, v130, v115 ; c8c6ed83 8382e782
	v_dual_mul_f32 v133, v133, v122 :: v_dual_mul_f32 v132, v132, v119 ; c8c6f585 8584ef84
	v_dual_mul_f32 v135, v135, v126 :: v_dual_mul_f32 v134, v134, v123 ; c8c6fd87 8786f786
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v131, -4.0, v138, 4.0                      ; d6690083 03db14f7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v133, -4.0, v139, 4.0                      ; d6690085 03db16f7
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v135, -4.0, v140, 4.0                      ; d6690087 03db18f7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 :: v_dual_fmaak_f32 v127, v127, v128, 0x3f650000 ; c8430382 827f017f 3f650000
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v137, v137, v130 :: v_dual_mul_f32 v136, v136, v127 ; c8c70589 8988ff88
	v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 ; c8430983 83870b86 3f650000
	v_maxmin_num_f32 v71, -4.0, v144, 4.0                       ; d6690047 03db20f7
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_maxmin_num_f32 v137, -4.0, v141, 4.0                      ; d6690089 03db1af7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_maxmin_num_f32 v73, -4.0, v145, 4.0                       ; d6690049 03db22f7
	v_dual_mul_f32 v139, v139, v134 :: v_dual_mul_f32 v138, v138, v131 ; c8c70d8b 8b8b078a
	v_fma_mix_f32 v72, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe8eff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v146, 4.0                       ; d6690055 03db24f7
	v_maxmin_num_f32 v87, -4.0, v147, 4.0                       ; d6690057 03db26f7
	v_fma_mix_f32 v84, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfe92ff 3728ab28
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_maxmin_num_f32 v139, -4.0, v142, 4.0                      ; d669008b 03db1cf7
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v148, 4.0                       ; d669005d 03db28f7
	v_fma_mix_f32 v92, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeaeff 3728ab28
	v_maxmin_num_f32 v95, -4.0, v149, 4.0                       ; d669005f 03db2af7
	v_dual_fmaak_f32 v71, v71, v72, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v73, 0x3f650000 ; c8429147 47549354 3f650000
	v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 :: v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 ; c843138a 8a871187 3f650000
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v87, 0x3f650000 ; c842ad55 555caf5c 3f650000
	v_maxmin_num_f32 v97, -4.0, v150, 4.0                       ; d6690061 03db2cf7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v151, 4.0                       ; d6690063 03db2ef7
	v_dual_mul_f32 v141, v141, v138 :: v_dual_mul_f32 v140, v140, v135 ; c8c7158d 8d8d0f8c
	v_dual_mul_f32 v147, v147, v92 :: v_dual_mul_f32 v144, v144, v71 ; c8c6b993 93908f90
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v152, 4.0                      ; d6690065 03db30f7
	v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842bd5d 5d60bf60 3f650000
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v153, 4.0                      ; d6690067 03db32f7
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_maxmin_num_f32 v141, -4.0, v143, 4.0                      ; d669008d 03db1ef7
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v105, -4.0, v154, 4.0                      ; d6690069 03db34f7
	v_dual_mul_f32 v149, v149, v96 :: v_dual_mul_f32 v146, v146, v85 ; c8c6c195 9592ab92
	v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 ; c842c561 6164c764 3f650000
	v_maxmin_num_f32 v107, -4.0, v155, 4.0                      ; d669006b 03db36f7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_fma_mix_f32 v70, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bff1aff 3728ab28
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_maxmin_num_f32 v109, -4.0, v156, 4.0                      ; d669006d 03db38f7
	v_maxmin_num_f32 v111, -4.0, v157, 4.0                      ; d669006f 03db3af7
	v_dual_mul_f32 v151, v151, v100 :: v_dual_mul_f32 v148, v148, v93 ; c8c6c997 9794bb94
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 ; c842cd65 6568cf68 3f650000
	v_dual_fmaak_f32 v70, v70, v141, 0x3f650000 :: v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 ; c8431b46 468b198b 3f650000
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_maxmin_num_f32 v113, -4.0, v158, 4.0                      ; d6690071 03db3cf7
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_maxmin_num_f32 v115, -4.0, v159, 4.0                      ; d6690073 03db3ef7
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 ; c842d569 696cd76c 3f650000
	v_dual_mul_f32 v153, v153, v104 :: v_dual_mul_f32 v150, v150, v97 ; c8c6d199 9996c396
	v_mul_f32_e32 v143, v143, v70                               ; 111e8d8f
	v_dual_mul_f32 v145, v145, v84 :: v_dual_mul_f32 v142, v142, v139 ; c8c6a991 918f178e
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v117, -4.0, v160, 4.0                      ; d6690075 03db40f7
	v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 ; c842dd6d 6d70df70 3f650000
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v161, 4.0                      ; d6690077 03db42f7
	v_dual_mul_f32 v155, v155, v108 :: v_dual_mul_f32 v152, v152, v101 ; c8c6d99b 9b98cb98
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_maxmin_num_f32 v121, -4.0, v162, 4.0                      ; d6690079 03db44f7
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v163, 4.0                      ; d669007b 03db46f7
	v_dual_mul_f32 v157, v157, v112 :: v_dual_mul_f32 v154, v154, v105 ; c8c6e19d 9d9ad39a
	v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 ; c842e571 7174e774 3f650000
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v125, -4.0, v164, 4.0                      ; d669007d 03db48f7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v165, 4.0                      ; d669007f 03db4af7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v166, 4.0                      ; d6690081 03db4cf7
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_dual_mul_f32 v159, v159, v116 :: v_dual_mul_f32 v156, v156, v109 ; c8c6e99f 9f9cdb9c
	v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 ; c842ed75 7578ef78 3f650000
	v_maxmin_num_f32 v131, -4.0, v167, 4.0                      ; d6690083 03db4ef7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v133, -4.0, v168, 4.0                      ; d6690085 03db50f7
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c842f579 797cf77c 3f650000
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v169, 4.0                      ; d6690087 03db52f7
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_dual_mul_f32 v161, v161, v120 :: v_dual_mul_f32 v158, v158, v113 ; c8c6f1a1 a19ee39e
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 ; c842fd7d 7d80ff80 3f650000
	v_maxmin_num_f32 v137, -4.0, v170, 4.0                      ; d6690089 03db54f7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v171, 4.0                      ; d669008b 03db56f7
	v_dual_mul_f32 v163, v163, v124 :: v_dual_mul_f32 v160, v160, v117 ; c8c6f9a3 a3a0eba0
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 ; c8430581 81850784 3f650000
	v_maxmin_num_f32 v141, -4.0, v172, 4.0                      ; d669008d 03db58f7
	v_dual_mul_f32 v165, v165, v128 :: v_dual_mul_f32 v162, v162, v121 ; c8c701a5 a5a2f3a2
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_maxmin_num_f32 v143, -4.0, v173, 4.0                      ; d669008f 03db5af7
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 ; c8430d85 85890f88 3f650000
	v_maxmin_num_f32 v145, -4.0, v174, 4.0                      ; d6690091 03db5cf7
	v_dual_mul_f32 v167, v167, v132 :: v_dual_mul_f32 v164, v164, v125 ; c8c709a7 a7a4fba4
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	buffer_load_b128 v[92:95], v75, s[36:39], null offen        ; c405c07c 4080485c 0000004b
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v139, 0x3f650000 ; c8431589 898d178c 3f650000
	v_maxmin_num_f32 v147, -4.0, v175, 4.0                      ; d6690093 03db5ef7
	v_dual_mul_f32 v169, v169, v136 :: v_dual_mul_f32 v166, v166, v129 ; c8c711a9 a9a703a6
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_maxmin_num_f32 v149, -4.0, v176, 4.0                      ; d6690095 03db60f7
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	buffer_load_b128 v[96:99], v75, s[36:39], null offen offset:512 ; c405c07c 40804860 0002004b
	v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 ; c8431d8d 8d911f90 3f650000
	v_maxmin_num_f32 v151, -4.0, v177, 4.0                      ; d6690097 03db62f7
	v_dual_mul_f32 v171, v171, v140 :: v_dual_mul_f32 v168, v168, v133 ; c8c719ab aba90ba8
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_maxmin_num_f32 v153, -4.0, v178, 4.0                      ; d6690099 03db64f7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_mul_f32 v173, v173, v144 :: v_dual_mul_f32 v170, v170, v137 ; c8c721ad adab13aa
	v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 :: v_dual_mul_f32 v172, v172, v141 ; c8472591 91ad1bac 3f650000
	buffer_load_b128 v[104:107], v75, s[36:39], null offen offset:1024 ; c405c07c 40804868 0004004b
	v_maxmin_num_f32 v155, -4.0, v179, 4.0                      ; d669009b 03db66f7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v180, 4.0                      ; d669009d 03db68f7
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432794 94952d95 3f650000
	v_maxmin_num_f32 v159, -4.0, v181, 4.0                      ; d669009f 03db6af7
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_mul_f32_e32 v174, v174, v145                              ; 115d23ae
	buffer_load_b128 v[108:111], v75, s[36:39], null offen offset:1536 ; c405c07c 4080486c 0006004b
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v182, 4.0                      ; d66900a1 03db6cf7
	v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 ; c8433599 99992f98 3f650000
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_mul_f32 v176, v176, v149 :: v_dual_mul_f32 v175, v175, v148 ; c8c72bb0 b0af29af
	v_maxmin_num_f32 v163, -4.0, v183, 4.0                      ; d66900a3 03db6ef7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	buffer_load_b128 v[112:115], v75, s[36:39], null offen offset:2048 ; c405c07c 40804870 0008004b
	v_fmaak_f32 v156, v156, v155, 0x3f650000                    ; 5b39379c 3f650000
	v_maxmin_num_f32 v165, -4.0, v184, 4.0                      ; d66900a5 03db70f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_mul_f32 v178, v178, v153 :: v_dual_mul_f32 v177, v177, v152 ; c8c733b2 b2b131b1
	v_maxmin_num_f32 v167, -4.0, v185, 4.0                      ; d66900a7 03db72f7
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c8433fa0 a09d3d9d 3f650000
	v_maxmin_num_f32 v169, -4.0, v186, 4.0                      ; d66900a9 03db74f7
	buffer_load_b128 v[116:119], v75, s[36:39], null offen offset:2560 ; c405c07c 40804874 000a004b
	v_mul_f32_e32 v179, v179, v156                              ; 116739b3
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v187, 4.0                      ; d66900ab 03db76f7
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c84347a4 a4a145a1 3f650000
	v_dual_mul_f32 v181, v181, v160 :: v_dual_mul_f32 v180, v180, v157 ; c8c741b5 b5b53bb4
	v_maxmin_num_f32 v173, -4.0, v188, 4.0                      ; d66900ad 03db78f7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	buffer_load_b128 v[120:123], v75, s[36:39], null offen offset:3072 ; c405c07c 40804878 000c004b
(invalid instruction)                                        ; d7694064
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_maxmin_num_f32 v175, -4.0, v189, 4.0                      ; d66900af 03db7af7
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 ; c8434fa8 a8a54da5 3f650000
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_maxmin_num_f32 v177, -4.0, v190, 4.0                      ; d66900b1 03db7cf7
	v_dual_mul_f32 v183, v183, v164 :: v_dual_mul_f32 v182, v182, v161 ; c8c749b7 b7b743b6
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_fmaak_f32 v169, v169, v170, 0x3f650000                    ; 5b5355a9 3f650000
	buffer_load_b128 v[124:127], v75, s[36:39], null offen offset:3584 ; c405c07c 4080487c 000e004b
	v_maxmin_num_f32 v179, -4.0, v191, 4.0                      ; d66900b3 03db7ef7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_dual_mul_f32 v185, v185, v168 :: v_dual_mul_f32 v184, v184, v165 ; c8c751b9 b9b94bb8
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v181, -4.0, v76, 4.0                       ; d66900b5 03da98f7
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 ; c8435dad adad57ac 3f650000
	v_maxmin_num_f32 v183, -4.0, v77, 4.0                       ; d66900b7 03da9af7
	v_mul_f32_e32 v186, v186, v169                              ; 117553ba
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_maxmin_num_f32 v185, -4.0, v78, 4.0                       ; d66900b9 03da9cf7
	v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 ; c84365b1 b1b15fb0 3f650000
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_dual_mul_f32 v188, v188, v173 :: v_dual_mul_f32 v187, v187, v172 ; c8c75bbc bcbb59bb
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fmaak_f32 v180, v180, v179, 0x3f650000                    ; 5b6967b4 3f650000
	v_dual_mul_f32 v190, v190, v177 :: v_dual_mul_f32 v189, v189, v176 ; c8c763be bebd61bd
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694066
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v187, -4.0, v79, 4.0                       ; d66900bb 03da9ef7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c8436fb8 b8b56db5 3f650000
	v_mul_f32_e32 v191, v191, v180                              ; 117f69bf
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_maxmin_num_f32 v189, -4.0, v80, 4.0                       ; d66900bd 03daa0f7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_mul_f32_e32 v77, v77, v184                                ; 109b714d
(invalid instruction)                                        ; d7694067
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v191, -4.0, v81, 4.0                       ; d66900bf 03daa2f7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 ; c84375b9 b9bd77bc 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v75, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624b 0bff7eff 3728ab28
	v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 :: v_dual_mul_f32 v76, v76, v181 ; c8477dbd bd4d6b4c 3f650000
	v_mul_f32_e32 v79, v79, v188                                ; 109f794f
	v_dual_fmaak_f32 v75, v75, v191, 0x3f650000 :: v_dual_mul_f32 v78, v78, v185 ; c8477f4b 4b4f734e 3f650000
	v_maxmin_num_f32 v128, -4.0, v33, 4.0                       ; d6690080 03da42f7
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	v_maxmin_num_f32 v130, -4.0, v34, 4.0                       ; d6690082 03da44f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v81, v81, v75 :: v_dual_mul_f32 v80, v80, v189 ; c8c69751 51517b50
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_maxmin_num_f32 v78, -4.0, v82, 4.0                        ; d669004e 03daa4f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v35, 4.0                       ; d6690084 03da46f7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_maxmin_num_f32 v134, -4.0, v36, 4.0                       ; d6690086 03da48f7
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v80, -4.0, v83, 4.0                        ; d6690050 03daa6f7
	v_maxmin_num_f32 v136, -4.0, v37, 4.0                       ; d6690088 03da4af7
	v_fma_mix_f32 v79, 0xab28, |v78|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624f 0bfe9cff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 ; c8430782 82810181 3f650000
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_maxmin_num_f32 v138, -4.0, v38, 4.0                       ; d669008a 03da4cf7
	v_fma_mix_f32 v81, 0xab28, |v80|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206251 0bfea0ff 3728ab28
	v_lshrrev_b32_e32 v141, 4, v15                              ; 331a1e84
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v34, v34, v130 :: v_dual_mul_f32 v33, v33, v129 ; c8c70522 22210321
	v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 ; c8430f86 86850985 3f650000
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_dual_fmaak_f32 v81, v81, v80, 0x3f650000 :: v_dual_fmaak_f32 v78, v78, v79, 0x3f650000 ; c842a151 514e9f4e 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_mul_f32 v36, v36, v134 ; c8471189 89250d24 3f650000
	v_dual_mul_f32 v35, v35, v133 :: v_dual_and_b32 v140, 0xffffffe0, v0 ; c8e50b23 238c00ff ffffffe0
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_lshlrev_b32 v141, 3, v141 ; c863178a 8a8d1a83 3f650000
	v_dual_mul_f32 v83, v83, v81 :: v_dual_mul_f32 v82, v82, v78 ; c8c6a353 53529d52
	v_add3_u32 v142, v141, s9, v140                             ; d655008e 0630138d
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v82, -4.0, v32, 4.0                        ; d6690052 03da40f7
	v_maxmin_num_f32 v143, -4.0, v39, 4.0                       ; d669008f 03da4ef7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v37, v37, v137 :: v_dual_lshlrev_b32 v142, 2, v142 ; c8e31325 258f1c82
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmaak_f32 v82, v82, v83, 0x3f650000                       ; 5aa4a752 3f650000
	v_fmaak_f32 v144, v144, v143, 0x3f650000                    ; 5b211f90 3f650000
	v_mul_f32_e32 v32, v32, v82                                 ; 1040a520
	v_dual_mul_f32 v38, v38, v138 :: v_dual_mul_f32 v39, v39, v144 ; c8c71526 26272127
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[80:83], v142, s[32:35], null offen       ; c405c07c 40804050 0000008e
	buffer_load_b128 v[36:39], v142, s[32:35], null offen offset:16 ; c405c07c 40804024 0000108e
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	v_maxmin_num_f32 v145, -4.0, v40, 4.0                       ; d6690091 03da50f7
	v_maxmin_num_f32 v147, -4.0, v41, 4.0                       ; d6690093 03da52f7
	v_maxmin_num_f32 v149, -4.0, v42, 4.0                       ; d6690095 03da54f7
	v_maxmin_num_f32 v151, -4.0, v43, 4.0                       ; d6690097 03da56f7
	v_maxmin_num_f32 v153, -4.0, v44, 4.0                       ; d6690099 03da58f7
	v_maxmin_num_f32 v155, -4.0, v45, 4.0                       ; d669009b 03da5af7
	v_maxmin_num_f32 v157, -4.0, v46, 4.0                       ; d669009d 03da5cf7
	v_maxmin_num_f32 v159, -4.0, v47, 4.0                       ; d669009f 03da5ef7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8432794 94912591 3f650000
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432f98 98952d95 3f650000
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c843379c 9c993599 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c8433fa0 a09d3d9d 3f650000
	v_dual_mul_f32 v41, v41, v148 :: v_dual_mul_f32 v40, v40, v145 ; c8c72929 29292328
	v_dual_mul_f32 v43, v43, v152 :: v_dual_mul_f32 v42, v42, v149 ; c8c7312b 2b2b2b2a
	v_dual_mul_f32 v45, v45, v156 :: v_dual_mul_f32 v44, v44, v153 ; c8c7392d 2d2d332c
	v_dual_mul_f32 v47, v47, v160 :: v_dual_mul_f32 v46, v46, v157 ; c8c7412f 2f2f3b2e
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[92:93], v[50:51], 0 ; cc464090 1a02655c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[92:93], v[52:53], 0 ; cc464098 1a02695c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[94:95], v[52:53], 0 ; cc4640b8 1a02695e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[48:49], 0 ; cc464080 1a02615c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[94:95], v[48:49], 0 ; cc4640a8 1a02615e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[94:95], v[50:51], 0 ; cc4640b0 1a02655e
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[92:93], v[24:25], 0 ; cc464028 1a02315c
	buffer_load_b128 v[48:51], v142, s[32:35], null offen offset:64 ; c405c07c 40804030 0000408e
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[94:95], v[24:25], 0 ; cc4640a0 1a02315e
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[58:59], v[144:151] ; cc464090 1e427560
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[60:61], v[152:159] ; cc464098 1e627960
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[60:61], v[184:191] ; cc4640b8 1ee27962
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[96:97], v[56:57], v[128:135] ; cc464080 1e027160
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[98:99], v[56:57], v[168:175] ; cc4640a8 1ea27162
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[98:99], v[58:59], v[176:183] ; cc4640b0 1ec27562
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[96:97], v[54:55], v[40:47] ; cc464028 1ca26d60
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[98:99], v[54:55], v[160:167] ; cc4640a0 1e826d62
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[104:105], v[10:11], v[128:135] ; cc464080 1e021568
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[106:107], v[10:11], v[168:175] ; cc4640a8 1ea2156a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[104:105], v[8:9], v[40:47] ; cc464028 1ca21168
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[106:107], v[8:9], v[160:167] ; cc4640a0 1e82116a
	buffer_load_b128 v[8:11], v142, s[32:35], null offen offset:80 ; c405c07c 40804008 0000508e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[104:105], v[12:13], v[144:151] ; cc464090 1e421968
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[104:105], v[62:63], v[152:159] ; cc464098 1e627d68
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[106:107], v[62:63], v[184:191] ; cc4640b8 1ee27d6a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[106:107], v[12:13], v[176:183] ; cc4640b0 1ec2196a
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[108:109], v[30:31], v[128:135] ; cc464080 1e023d6c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[110:111], v[30:31], v[168:175] ; cc4640a8 1ea23d6e
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[108:109], v[28:29], v[40:47] ; cc464028 1ca2396c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[110:111], v[28:29], v[160:167] ; cc4640a0 1e82396e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[22:23], v[144:151] ; cc464090 1e422d6c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[16:17], v[152:159] ; cc464098 1e62216c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[16:17], v[184:191] ; cc4640b8 1ee2216e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[110:111], v[22:23], v[176:183] ; cc4640b0 1ec22d6e
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[112:113], v[20:21], v[128:135] ; cc464080 1e022970
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[114:115], v[20:21], v[168:175] ; cc4640a8 1ea22972
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v20, v7, s5, v2                                  ; d6550014 04080b07
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[112:113], v[18:19], v[40:47] ; cc464028 1ca22570
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[114:115], v[18:19], v[160:167] ; cc4640a0 1e822572
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[112:113], v[26:27], v[144:151] ; cc464090 1e423570
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[88:89], v[152:159] ; cc464098 1e62b170
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[88:89], v[184:191] ; cc4640b8 1ee2b172
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[26:27], v[176:183] ; cc4640b0 1ec23572
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[116:117], v[66:67], v[128:135] ; cc464080 1e028574
	v_lshlrev_b32_e32 v20, 2, v20                               ; 30282882
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[118:119], v[66:67], v[168:175] ; cc4640a8 1ea28576
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[116:117], v[90:91], v[40:47] ; cc464028 1ca2b574
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[118:119], v[90:91], v[160:167] ; cc4640a0 1e82b576
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[116:117], v[68:69], v[144:151] ; cc464090 1e428974
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[70:71], v[152:159] ; cc464098 1e628d74
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[70:71], v[184:191] ; cc4640b8 1ee28d76
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[118:119], v[68:69], v[176:183] ; cc4640b0 1ec28976
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[120:121], v[84:85], v[128:135] ; cc464080 1e02a978
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[122:123], v[84:85], v[168:175] ; cc4640a8 1ea2a97a
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[120:121], v[72:73], v[40:47] ; cc464028 1ca29178
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[122:123], v[72:73], v[160:167] ; cc4640a0 1e82917a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[120:121], v[86:87], v[144:151] ; cc464090 1e42ad78
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[120:121], v[100:101], v[152:159] ; cc464098 1e62c978
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[122:123], v[100:101], v[184:191] ; cc4640b8 1ee2c97a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[122:123], v[86:87], v[176:183] ; cc4640b0 1ec2ad7a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[124:125], v[76:77], v[128:135] ; cc464080 1e02997c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[126:127], v[76:77], v[168:175] ; cc4640a8 1ea2997e
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[124:125], v[102:103], v[40:47] ; cc464028 1ca2cd7c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[126:127], v[102:103], v[160:167] ; cc4640a0 1e82cd7e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[124:125], v[32:33], v[144:151] ; cc464090 1e42417c
	buffer_load_b128 v[24:27], v20, s[36:39], null offen        ; c405c07c 40804818 00000014
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[124:125], v[34:35], v[152:159] ; cc464098 1e62457c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[126:127], v[34:35], v[184:191] ; cc4640b8 1ee2457e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[126:127], v[32:33], v[176:183] ; cc4640b0 1ec2417e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	v_add_nc_u32_e32 v21, 0x1000, v65                           ; 4a2a82ff 00001000
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	buffer_load_b128 v[40:43], v20, s[36:39], null offen offset:512 ; c405c07c 40804828 00020014
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	ds_store_2addr_b64 v21, v[12:13], v[28:29] offset1:32       ; d9382000 001c0c15
	ds_store_2addr_b64 v21, v[16:17], v[30:31] offset0:128 offset1:160 ; d938a080 001e1015
	v_add_nc_u32_e32 v28, 0x1800, v65                           ; 4a3882ff 00001800
	ds_store_2addr_b64 v28, v[18:19], v[32:33] offset1:32       ; d9382000 0020121c
	ds_store_2addr_b64 v28, v[22:23], v[34:35] offset0:128 offset1:160 ; d938a080 0022161c
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	buffer_load_b128 v[16:19], v20, s[36:39], null offen offset:1024 ; c405c07c 40804810 00040014
	v_mad_u32_u24 v29, s59, 0x500, v2                           ; d60b001d 0409fe3b 00000500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v29, v29, v64                              ; 4a3a811d
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[12:13], v29                                   ; d9d80000 0c00001d
	ds_load_b64 v[22:23], v29 offset:1024                       ; d9d80400 1600001d
	ds_load_b64 v[30:31], v29 offset:2048                       ; d9d80800 1e00001d
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[32:33], v12                          ; 7e40dd0c
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v57, v33, v81 :: v_dual_mul_f32 v56, v32, v80 ; c8c6a321 3938a120
	v_cvt_pk_f32_fp8_e32 v[32:33], v140                         ; 7e40dd8c
	v_dual_mul_f32 v59, v33, v83 :: v_dual_mul_f32 v58, v32, v82 ; c8c6a721 3b3aa520
	buffer_load_b128 v[32:35], v20, s[36:39], null offen offset:1536 ; c405c07c 40804820 00060014
	v_cvt_pk_f32_fp8_e32 v[44:45], v13                          ; 7e58dd0d
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_dual_mul_f32 v61, v45, v37 :: v_dual_mul_f32 v60, v44, v36 ; c8c64b2d 3d3c492c
	ds_load_b64 v[44:45], v29 offset:3072                       ; d9d80c00 2c00001d
	ds_load_b64 v[46:47], v29 offset:256                        ; d9d80100 2e00001d
	v_cvt_pk_f32_fp8_e32 v[12:13], v141                         ; 7e18dd8d
	v_dual_mul_f32 v63, v13, v39 :: v_dual_mul_f32 v62, v12, v38 ; c8c64f0d 3f3e4d0c
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[12:13], v22                          ; 7e18dd16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v89, v13, v81 :: v_dual_mul_f32 v88, v12, v80 ; c8c6a30d 5958a10c
	v_cvt_pk_f32_fp8_e32 v[12:13], v150                         ; 7e18dd96
	v_dual_mul_f32 v91, v13, v83 :: v_dual_mul_f32 v90, v12, v82 ; c8c6a70d 5b5aa50c
	v_cvt_pk_f32_fp8_e32 v[12:13], v23                          ; 7e18dd17
	v_cvt_pk_f32_fp8_e32 v[22:23], v151                         ; 7e2cdd97
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
	v_dual_mul_f32 v93, v13, v37 :: v_dual_mul_f32 v92, v12, v36 ; c8c64b0d 5d5c490c
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[12:13], v30                          ; 7e18dd1e
	v_dual_mul_f32 v97, v13, v81 :: v_dual_mul_f32 v96, v12, v80 ; c8c6a30d 6160a10c
	v_cvt_pk_f32_fp8_e32 v[12:13], v158                         ; 7e18dd9e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v99, v13, v83 :: v_dual_mul_f32 v98, v12, v82 ; c8c6a70d 6362a50c
	v_cvt_pk_f32_fp8_e32 v[12:13], v31                          ; 7e18dd1f
	v_mul_f32_e32 v100, v12, v36                                ; 10c8490c
	v_dual_mul_f32 v94, v22, v38 :: v_dual_mul_f32 v101, v13, v37 ; c8c64d16 5e644b0d
	v_cvt_pk_f32_fp8_e32 v[12:13], v159                         ; 7e18dd9f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v102, v12, v38 :: v_dual_mul_f32 v103, v13, v39 ; c8c64d0c 66664f0d
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[12:13], v44                          ; 7e18dd2c
	v_dual_mul_f32 v104, v12, v80 :: v_dual_mul_f32 v95, v23, v39 ; c8c6a10c 685e4f17
	ds_load_b64 v[22:23], v29 offset:1280                       ; d9d80500 1600001d
	v_add_lshl_u32 v30, s19, v1, 2                              ; d647001e 020a0213
	buffer_load_b32 v30, v30, s[32:35], null offen              ; c405007c 4080401e 0000001e
	v_mul_f32_e32 v105, v13, v81                                ; 10d2a30d
	v_cvt_pk_f32_fp8_e32 v[12:13], v172                         ; 7e18ddac
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v107, v13, v83 :: v_dual_mul_f32 v106, v12, v82 ; c8c6a70d 6b6aa50c
	v_cvt_pk_f32_fp8_e32 v[12:13], v45                          ; 7e18dd2d
	v_dual_mul_f32 v109, v13, v37 :: v_dual_mul_f32 v108, v12, v36 ; c8c64b0d 6d6c490c
	ds_load_b64 v[36:37], v29 offset:2304                       ; d9d80900 2400001d
	v_cvt_pk_f32_fp8_e32 v[12:13], v173                         ; 7e18ddad
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870119
	v_mad_u32_u24 v31, 0x600, v1, s6                            ; d60b001f 001a02ff 00000600
	v_dual_mul_f32 v111, v13, v39 :: v_dual_mul_f32 v110, v12, v38 ; c8c64f0d 6f6e4d0c
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[12:13], v46                          ; 7e18dd2e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_add_lshl_u32 v31, v31, v7, 2                              ; d647001f 020a0f1f
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v81, v13, v49 :: v_dual_mul_f32 v80, v12, v48 ; c8c6630d 5150610c
	v_cvt_pk_f32_fp8_e32 v[12:13], v174                         ; 7e18ddae
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v83, v13, v51 :: v_dual_mul_f32 v82, v12, v50 ; c8c6670d 5352650c
	v_cvt_pk_f32_fp8_e32 v[12:13], v47                          ; 7e18dd2f
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_mul_f32 v85, v13, v9 :: v_dual_mul_f32 v84, v12, v8  ; c8c6130d 5554110c
	v_cvt_pk_f32_fp8_e32 v[12:13], v175                         ; 7e18ddaf
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[52:55], v31, s[36:39], null offen        ; c405c07c 40804834 0000001f
	buffer_load_b128 v[44:47], v31, s[36:39], null offen offset:2048 ; c405c07c 4080482c 0008001f
	ds_load_b64 v[38:39], v29 offset:3328                       ; d9d80d00 2600001d
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v31, s[36:39], null offen offset:512 ; c405c07c 40804844 0002001f
	buffer_load_b128 v[76:79], v31, s[36:39], null offen offset:2560 ; c405c07c 4080484c 000a001f
	v_mul_f32_e32 v86, v12, v10                                 ; 10ac150c
	v_mul_f32_e32 v87, v13, v11                                 ; 10ae170d
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[12:13], v22                          ; 7e18dd16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v13, v49 :: v_dual_mul_f32 v112, v12, v48 ; c8c6630d 7170610c
	v_cvt_pk_f32_fp8_e32 v[12:13], v150                         ; 7e18dd96
	v_dual_mul_f32 v115, v13, v51 :: v_dual_mul_f32 v114, v12, v50 ; c8c6670d 7372650c
	buffer_load_b128 v[132:135], v31, s[36:39], null offen offset:1024 ; c405c07c 40804884 0004001f
	v_cvt_pk_f32_fp8_e32 v[12:13], v23                          ; 7e18dd17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v117, v13, v9 :: v_dual_mul_f32 v116, v12, v8 ; c8c6130d 7574110c
	v_cvt_pk_f32_fp8_e32 v[12:13], v151                         ; 7e18dd97
	v_dual_mul_f32 v119, v13, v11 :: v_dual_mul_f32 v118, v12, v10 ; c8c6170d 7776150c
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[12:13], v36                          ; 7e18dd24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v121, v13, v49 :: v_dual_mul_f32 v120, v12, v48 ; c8c6630d 7978610c
	v_cvt_pk_f32_fp8_e32 v[12:13], v164                         ; 7e18dda4
	v_dual_mul_f32 v123, v13, v51 :: v_dual_mul_f32 v122, v12, v50 ; c8c6670d 7b7a650c
	v_cvt_pk_f32_fp8_e32 v[12:13], v37                          ; 7e18dd25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v125, v13, v9 :: v_dual_mul_f32 v124, v12, v8 ; c8c6130d 7d7c110c
	v_cvt_pk_f32_fp8_e32 v[12:13], v165                         ; 7e18dda5
	v_dual_mul_f32 v127, v13, v11 :: v_dual_mul_f32 v126, v12, v10 ; c8c6170d 7f7e150c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[12:13], v38                          ; 7e18dd26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v129, v13, v49 :: v_dual_mul_f32 v128, v12, v48 ; c8c6630d 8180610c
	v_cvt_pk_f32_fp8_e32 v[12:13], v166                         ; 7e18dda6
	v_dual_mul_f32 v131, v13, v51 :: v_dual_mul_f32 v130, v12, v50 ; c8c6670d 8382650c
	v_cvt_pk_f32_fp8_e32 v[12:13], v39                          ; 7e18dd27
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v149, v13, v9 :: v_dual_mul_f32 v148, v12, v8 ; c8c6130d 9594110c
	v_cvt_pk_f32_fp8_e32 v[8:9], v167                           ; 7e10dda7
	buffer_load_b128 v[36:39], v31, s[36:39], null offen offset:3072 ; c405c07c 40804824 000c001f
	v_lshl_add_u32 v48, s59, 10, v64                            ; d6460030 0501143b
	v_mul_f32_e32 v151, v9, v11                                 ; 112e1709
	v_mul_f32_e32 v150, v8, v10                                 ; 112c1508
	ds_load_b64 v[8:9], v48 offset:4096                         ; d9d81000 08000030
	ds_load_b64 v[10:11], v48 offset:5120                       ; d9d81400 0a000030
	ds_load_b64 v[12:13], v48 offset:6144                       ; d9d81800 0c000030
	ds_load_b64 v[22:23], v48 offset:7168                       ; d9d81c00 16000030
	ds_load_b64 v[50:51], v48 offset:4352                       ; d9d81100 32000030
	ds_load_b64 v[66:67], v48 offset:5376                       ; d9d81500 42000030
	ds_load_b64 v[72:73], v48 offset:6400                       ; d9d81900 48000030
	ds_load_b64 v[136:137], v48 offset:7424                     ; d9d81d00 88000030
	ds_load_b64 v[138:139], v48 offset:4608                     ; d9d81200 8a000030
	ds_load_b64 v[142:143], v48 offset:5632                     ; d9d81600 8e000030
	ds_load_b64 v[144:145], v48 offset:6656                     ; d9d81a00 90000030
	ds_load_b64 v[146:147], v48 offset:7680                     ; d9d81e00 92000030
	buffer_load_b128 v[152:155], v31, s[36:39], null offen offset:1536 ; c405c07c 40804898 0006001f
	ds_load_b64 v[156:157], v48 offset:4864                     ; d9d81300 9c000030
	ds_load_b64 v[158:159], v48 offset:5888                     ; d9d81700 9e000030
	ds_load_b64 v[160:161], v48 offset:6912                     ; d9d81b00 a0000030
	ds_load_b64 v[162:163], v48 offset:7936                     ; d9d81f00 a2000030
	s_wait_loadcnt_dscnt 0xb0f                                  ; bfc80b0f
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[24:25], v[8:9], v[56:63] ; cc464038 1ce21118
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[26:27], v[8:9], v[80:87] ; cc464050 1d42111a
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[10:11], v[88:95] ; cc464058 1d621518
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[10:11], v[112:119] ; cc464070 1dc2151a
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[12:13], v[120:127] ; cc464078 1de2191a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[12:13], v[96:103] ; cc464060 1d821918
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[22:23], v[104:111] ; cc464068 1da22d18
	s_wait_loadcnt_dscnt 0xa0b                                  ; bfc80a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[40:41], v[50:51], v[56:63] ; cc464038 1ce26528
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[42:43], v[50:51], v[80:87] ; cc464050 1d42652a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[66:67], v[88:95] ; cc464058 1d628528
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[66:67], v[112:119] ; cc464070 1dc2852a
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[72:73], v[120:127] ; cc464078 1de2912a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[72:73], v[96:103] ; cc464060 1d829128
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[136:137], v[104:111] ; cc464068 1da31128
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[16:17], v[138:139], v[56:63] ; cc464038 1ce31510
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[138:139], v[80:87] ; cc464050 1d431512
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[142:143], v[88:95] ; cc464058 1d631d10
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[142:143], v[112:119] ; cc464070 1dc31d12
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[144:145], v[120:127] ; cc464078 1de32112
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[144:145], v[96:103] ; cc464060 1d832110
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[146:147], v[104:111] ; cc464068 1da32510
	s_wait_loadcnt_dscnt 0x803                                  ; bfc80803
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[32:33], v[156:157], v[56:63] ; cc464038 1ce33920
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[34:35], v[156:157], v[80:87] ; cc464050 1d433922
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[158:159], v[88:95] ; cc464058 1d633d20
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[158:159], v[112:119] ; cc464070 1dc33d22
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[160:161], v[120:127] ; cc464078 1de34122
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[160:161], v[96:103] ; cc464060 1d834120
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[32:33], v[162:163], v[104:111] ; cc464068 1da34520
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mov_b32 v9, v133 :: v_dual_mov_b32 v8, v132          ; ca100185 09080184
	v_dual_mov_b32 v133, v149 :: v_dual_mov_b32 v132, v148      ; ca100195 85840194
	v_dual_mov_b32 v11, v135 :: v_dual_mov_b32 v10, v134        ; ca100187 0b0a0186
	v_dual_mov_b32 v135, v151 :: v_dual_mov_b32 v134, v150      ; ca100197 87860196
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[22:23], v[128:135] ; cc464080 1e022d1a
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[136:137], v[128:135] ; cc464080 1e03112a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[146:147], v[128:135] ; cc464080 1e032512
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[162:163], v[128:135] ; cc464080 1e034522
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v65, v[12:13], v[24:25] offset1:32       ; d9382000 00180c41
	ds_store_2addr_b64 v65, v[16:17], v[26:27] offset0:128 offset1:160 ; d938a080 001a1041
	ds_store_2addr_b64 v14, v[18:19], v[32:33] offset1:32       ; d9382000 0020120e
	ds_store_2addr_b64 v14, v[22:23], v[34:35] offset0:128 offset1:160 ; d938a080 0022160e
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_lshl_add_u32 v49, s59, 11, v64                            ; d6460031 0501163b
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[12:13], v49                                   ; d9d80000 0c000031
	ds_load_b64 v[16:17], v49 offset:1024                       ; d9d80400 10000031
	ds_load_b64 v[18:19], v49 offset:2048                       ; d9d80800 12000031
	ds_load_b64 v[22:23], v49 offset:3072                       ; d9d80c00 16000031
	ds_load_b64 v[24:25], v49 offset:256                        ; d9d80100 18000031
	ds_load_b64 v[26:27], v49 offset:1280                       ; d9d80500 1a000031
	ds_load_b64 v[32:33], v49 offset:2304                       ; d9d80900 20000031
	ds_load_b64 v[34:35], v49 offset:3328                       ; d9d80d00 22000031
	ds_load_b64 v[40:41], v49 offset:512                        ; d9d80200 28000031
	ds_load_b64 v[42:43], v49 offset:1536                       ; d9d80600 2a000031
	ds_load_b64 v[50:51], v49 offset:2560                       ; d9d80a00 32000031
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[52:53], v[12:13], 0 ; cc464038 1a021934
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[52:53], v[16:17], 0 ; cc464050 1a022134
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[18:19], 0 ; cc464058 1a022534
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[22:23], 0 ; cc464060 1a022d34
	ds_load_b64 v[52:53], v49 offset:3584                       ; d9d80e00 34000031
	v_dual_mov_b32 v67, v74 :: v_dual_mov_b32 v66, v15          ; ca10014a 4342010f
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[54:55], v[12:13], 0 ; cc464068 1a021936
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[44:45], v[12:13], 0 ; cc464090 1a02192c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[16:17], 0 ; cc464070 1a022136
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[44:45], v[16:17], 0 ; cc4640a0 1a02212c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[18:19], 0 ; cc464078 1a022536
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[44:45], v[18:19], 0 ; cc4640a8 1a02252c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[22:23], 0 ; cc464080 1a022d36
	v_dual_mov_b32 v55, v141 :: v_dual_mov_b32 v54, v140        ; ca10018d 3736018c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[44:45], v[22:23], 0 ; cc4640b0 1a022d2c
	v_dual_mov_b32 v45, v19 :: v_dual_mov_b32 v44, v18          ; ca100113 2d2c0112
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mov_b32 v73, v153 :: v_dual_mov_b32 v72, v152        ; ca100199 49480198
	v_dual_mov_b32 v75, v155 :: v_dual_mov_b32 v74, v154        ; ca10019b 4b4a019a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[46:47], v[12:13], 0 ; cc4640b8 1a02192e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[16:17], 0 ; cc464088 1a02212e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[22:23], 0 ; cc464098 1a022d2e
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[68:69], v[24:25], v[56:63] ; cc464038 1ce23144
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[26:27], v[80:87] ; cc464050 1d423544
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[32:33], v[88:95] ; cc464058 1d624144
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[34:35], v[96:103] ; cc464060 1d824544
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[46:47], v[44:45], 0 ; cc46400c 1a02592e
	ds_load_b64 v[22:23], v49 offset:768                        ; d9d80300 16000031
	ds_load_b64 v[44:45], v49 offset:1792                       ; d9d80700 2c000031
	ds_load_b64 v[46:47], v49 offset:2816                       ; d9d80b00 2e000031
	ds_load_b64 v[68:69], v49 offset:3840                       ; d9d80f00 44000031
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[24:25], v[104:111] ; cc464068 1da23146
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[26:27], v[112:119] ; cc464070 1dc23546
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[32:33], v[120:127] ; cc464078 1de24146
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[34:35], v[128:135] ; cc464080 1e024546
	v_dual_mov_b32 v71, v79 :: v_dual_mov_b32 v70, v78          ; ca10014f 4746014e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[76:77], v[24:25], v[144:151] ; cc464090 1e42314c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[76:77], v[26:27], v[160:167] ; cc4640a0 1e82354c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[76:77], v[32:33], v[168:175] ; cc4640a8 1ea2414c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[76:77], v[34:35], v[176:183] ; cc4640b0 1ec2454c
	buffer_load_b128 v[76:79], v31, s[36:39], null offen offset:3584 ; c405c07c 4080484c 000e001f
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[8:9], v[40:41], v[56:63] ; cc464038 1ce25108
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[42:43], v[80:87] ; cc464050 1d425508
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[50:51], v[88:95] ; cc464058 1d626508
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[52:53], v[96:103] ; cc464060 1d826908
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[40:41], v[104:111] ; cc464068 1da2510a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[24:25], v[184:191] ; cc4640b8 1ee23146
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[26:27], v[136:143] ; cc464088 1e223546
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[70:71], v[32:33], v[12:19] ; cc46400c 1c324146
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[70:71], v[34:35], v[152:159] ; cc464098 1e624546
	s_wait_dscnt 0x3                                            ; bfc60003
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[72:73], v[22:23], v[56:63] ; cc464038 1ce22d48
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[72:73], v[44:45], v[80:87] ; cc464050 1d425948
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[42:43], v[112:119] ; cc464070 1dc2550a
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[72:73], v[46:47], v[88:95] ; cc464058 1d625d48
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[50:51], v[120:127] ; cc464078 1de2650a
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[68:69], v[96:103] ; cc464060 1d828948
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[52:53], v[128:135] ; cc464080 1e02690a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[74:75], v[22:23], v[104:111] ; cc464068 1da22d4a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[40:41], v[144:151] ; cc464090 1e425124
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[36:37], v[42:43], v[160:167] ; cc4640a0 1e825524
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[36:37], v[50:51], v[168:175] ; cc4640a8 1ea26524
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[36:37], v[52:53], v[176:183] ; cc4640b0 1ec26924
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[38:39], v[40:41], v[184:191] ; cc4640b8 1ee25126
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[38:39], v[42:43], v[136:143] ; cc464088 1e225526
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[38:39], v[50:51], v[12:19] ; cc46400c 1c326526
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[38:39], v[52:53], v[152:159] ; cc464098 1e626926
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[44:45], v[112:119] ; cc464070 1dc2594a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[46:47], v[120:127] ; cc464078 1de25d4a
	v_dual_mul_f32 v73, v107, v107 :: v_dual_mul_f32 v72, v105, v105 ; c8c6d76b 4948d369
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[74:75], v[68:69], v[128:135] ; cc464080 1e02894a
	s_mov_b32 s61, 0x76543210                                   ; bebd00ff 76543210
	s_mov_b32 s62, 0xfedcba98                                   ; bebe00ff fedcba98
	s_movk_i32 s63, 0x410                                       ; b03f0410
	v_dual_fmac_f32 v73, v59, v59 :: v_dual_fmac_f32 v72, v57, v57 ; c800773b 49487339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v73, v63, v63 :: v_dual_fmac_f32 v72, v61, v61 ; c8007f3f 49487b3d
	v_dual_fmac_f32 v73, v111, v111 :: v_dual_fmac_f32 v72, v109, v109 ; c800df6f 4948db6d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v73, v58, v58 :: v_dual_fmac_f32 v72, v56, v56 ; c800753a 49487138
	v_dual_fmac_f32 v73, v106, v106 :: v_dual_fmac_f32 v72, v104, v104 ; c800d56a 4948d168
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v73, v62, v62 :: v_dual_fmac_f32 v72, v60, v60 ; c8007d3e 4948793c
	v_dual_fmac_f32 v73, v110, v110 :: v_dual_fmac_f32 v72, v108, v108 ; c800dd6e 4948d96c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v74, 1.0, v72, v73                          ; cc21004a 052690f2
	v_cvt_u32_u16_e32 v75, v74                                  ; 7e96d74a
	v_dual_mul_f32 v20, v115, v115 :: v_dual_mul_f32 v9, v113, v113 ; c8c6e773 1408e371
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v75, v75, s61, s62 op_sel:[1,1]           ; d65c184b 00f87b4b
	v_dual_fmac_f32 v20, v83, v83 :: v_dual_fmac_f32 v9, v81, v81 ; c800a753 1408a351
	v_add_f16_e32 v74, v74, v75                                 ; 6494974a
	v_dual_fmac_f32 v20, v87, v87 :: v_dual_fmac_f32 v9, v85, v85 ; c800af57 1408ab55
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_max_num_f16_e32 v74, s63, v74                             ; 6294943f
	v_dual_fmac_f32 v20, v119, v119 :: v_dual_fmac_f32 v9, v117, v117 ; c800ef77 1408eb75
	v_cvt_f32_f16_e32 v8, v74                                   ; 7e10174a
	v_dual_fmac_f32 v20, v82, v82 :: v_dual_fmac_f32 v9, v80, v80 ; c800a552 1408a150
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a2
	v_rsq_f32_e32 v8, v8                                        ; 7e105d08
	v_dual_fmac_f32 v20, v114, v114 :: v_dual_fmac_f32 v9, v112, v112 ; c800e572 1408e170
	v_mul_f32_e32 v8, v8, v30                                   ; 10103d08
	v_dual_fmac_f32 v20, v86, v86 :: v_dual_fmac_f32 v9, v84, v84 ; c800ad56 1408a954
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v111, v111, v8 :: v_dual_mul_f32 v110, v110, v8 ; c8c6116f 6f6e116e
	v_dual_mul_f32 v61, v61, v8 :: v_dual_mul_f32 v60, v60, v8  ; c8c6113d 3d3c113c
	v_dual_mul_f32 v106, v106, v8 :: v_dual_mul_f32 v107, v107, v8 ; c8c6116a 6a6a116b
	v_dual_mul_f32 v104, v104, v8 :: v_dual_mul_f32 v105, v105, v8 ; c8c61168 68681169
	v_dual_mul_f32 v57, v57, v8 :: v_dual_mul_f32 v56, v56, v8  ; c8c61139 39381138
	v_dual_mul_f32 v108, v108, v8 :: v_dual_mul_f32 v109, v109, v8 ; c8c6116c 6c6c116d
	v_dual_mul_f32 v62, v62, v8 :: v_dual_mul_f32 v63, v63, v8  ; c8c6113e 3e3e113f
	v_dual_mul_f32 v59, v59, v8 :: v_dual_mul_f32 v58, v58, v8  ; c8c6113b 3b3a113a
	v_dual_fmac_f32 v20, v118, v118 :: v_dual_fmac_f32 v9, v116, v116 ; c800ed76 1408e974
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	v_fma_mixlo_f16 v26, 1.0, v9, v20                           ; cc21001a 045212f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_u32_u16_e32 v27, v26                                  ; 7e36d71a
	v_dual_mul_f32 v34, v123, v123 :: v_dual_mul_f32 v33, v121, v121 ; c8c6f77b 2220f379
	v_permlanex16_b32 v27, v27, s61, s62 op_sel:[1,1]           ; d65c181b 00f87b1b
	v_dual_fmac_f32 v34, v91, v91 :: v_dual_fmac_f32 v33, v89, v89 ; c800b75b 2220b359
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_add_f16_e32 v26, v26, v27                                 ; 6434371a
	v_dual_fmac_f32 v34, v95, v95 :: v_dual_fmac_f32 v33, v93, v93 ; c800bf5f 2220bb5d
	v_max_num_f16_e32 v26, s63, v26                             ; 6234343f
	v_dual_fmac_f32 v34, v127, v127 :: v_dual_fmac_f32 v33, v125, v125 ; c800ff7f 2220fb7d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v32, v26                                  ; 7e40171a
	v_dual_fmac_f32 v34, v90, v90 :: v_dual_fmac_f32 v33, v88, v88 ; c800b55a 2220b158
	v_rsq_f32_e32 v32, v32                                      ; 7e405d20
	v_dual_fmac_f32 v34, v122, v122 :: v_dual_fmac_f32 v33, v120, v120 ; c800f57a 2220f178
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870125
	v_mul_f32_e32 v32, v32, v30                                 ; 10403d20
	v_dual_fmac_f32 v34, v94, v94 :: v_dual_fmac_f32 v33, v92, v92 ; c800bd5e 2220b95c
	v_dual_mul_f32 v119, v119, v32 :: v_dual_mul_f32 v118, v118, v32 ; c8c64177 77764176
	v_dual_mul_f32 v80, v80, v32 :: v_dual_mul_f32 v81, v81, v32 ; c8c64150 50504151
	v_dual_mul_f32 v87, v87, v32 :: v_dual_mul_f32 v86, v86, v32 ; c8c64157 57564156
	v_dual_mul_f32 v82, v82, v32 :: v_dual_mul_f32 v83, v83, v32 ; c8c64152 52524153
	v_dual_mul_f32 v116, v116, v32 :: v_dual_mul_f32 v117, v117, v32 ; c8c64174 74744175
	v_dual_mul_f32 v114, v114, v32 :: v_dual_mul_f32 v115, v115, v32 ; c8c64172 72724173
	v_dual_mul_f32 v112, v112, v32 :: v_dual_mul_f32 v113, v113, v32 ; c8c64170 70704171
	v_dual_mul_f32 v84, v84, v32 :: v_dual_mul_f32 v85, v85, v32 ; c8c64154 54544155
	v_dual_fmac_f32 v34, v126, v126 :: v_dual_fmac_f32 v33, v124, v124 ; c800fd7e 2220f97c
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_fma_mixlo_f16 v35, 1.0, v33, v34                          ; cc210023 048a42f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_u32_u16_e32 v36, v35                                  ; 7e48d723
	v_dual_mul_f32 v39, v131, v131 :: v_dual_mul_f32 v38, v129, v129 ; c8c70783 27270381
	v_permlanex16_b32 v36, v36, s61, s62 op_sel:[1,1]           ; d65c1824 00f87b24
	v_dual_fmac_f32 v39, v99, v99 :: v_dual_fmac_f32 v38, v97, v97 ; c800c763 2726c361
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_add_f16_e32 v35, v35, v36                                 ; 64464923
	v_dual_fmac_f32 v39, v103, v103 :: v_dual_fmac_f32 v38, v101, v101 ; c800cf67 2726cb65
	v_max_num_f16_e32 v35, s63, v35                             ; 6246463f
	v_dual_fmac_f32 v39, v135, v135 :: v_dual_fmac_f32 v38, v133, v133 ; c8010f87 27270b85
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v37, v35                                  ; 7e4a1723
	v_dual_fmac_f32 v39, v98, v98 :: v_dual_fmac_f32 v38, v96, v96 ; c800c562 2726c160
	v_rsq_f32_e32 v37, v37                                      ; 7e4a5d25
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[76:77], v[22:23], v[144:151] ; cc464090 1e422d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[76:77], v[44:45], v[160:167] ; cc4640a0 1e82594c
	v_mul_f32_e32 v37, v37, v30                                 ; 104a3d25
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[76:77], v[46:47], v[168:175] ; cc4640a8 1ea25d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[76:77], v[68:69], v[176:183] ; cc4640b0 1ec2894c
	v_dual_mul_f32 v95, v95, v37 :: v_dual_mul_f32 v94, v94, v37 ; c8c64b5f 5f5e4b5e
	v_dual_mul_f32 v88, v88, v37 :: v_dual_mul_f32 v89, v89, v37 ; c8c64b58 58584b59
	v_dual_mul_f32 v90, v90, v37 :: v_dual_mul_f32 v91, v91, v37 ; c8c64b5a 5a5a4b5b
	v_dual_mul_f32 v125, v125, v37 :: v_dual_mul_f32 v124, v124, v37 ; c8c64b7d 7d7c4b7c
	v_dual_mul_f32 v127, v127, v37 :: v_dual_mul_f32 v126, v126, v37 ; c8c64b7f 7f7e4b7e
	v_dual_mul_f32 v121, v121, v37 :: v_dual_mul_f32 v120, v120, v37 ; c8c64b79 79784b78
	v_dual_mul_f32 v123, v123, v37 :: v_dual_mul_f32 v122, v122, v37 ; c8c64b7b 7b7a4b7a
	v_dual_mul_f32 v92, v92, v37 :: v_dual_mul_f32 v93, v93, v37 ; c8c64b5c 5c5c4b5d
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[78:79], v[22:23], v[184:191] ; cc4640b8 1ee22d4e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[78:79], v[44:45], v[136:143] ; cc464088 1e22594e
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[78:79], v[46:47], v[12:19] ; cc46400c 1c325d4e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[78:79], v[68:69], v[152:159] ; cc464098 1e62894e
	v_dual_fmac_f32 v39, v130, v130 :: v_dual_fmac_f32 v38, v128, v128 ; c8010582 27270180
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_dual_fmac_f32 v39, v102, v102 :: v_dual_fmac_f32 v38, v100, v100 ; c800cd66 2726c964
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v39, v134, v134 :: v_dual_fmac_f32 v38, v132, v132 ; c8010d86 27270984
	v_fma_mixlo_f16 v40, 1.0, v38, v39                          ; cc210028 049e4cf2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v41, v40                                  ; 7e52d728
	v_permlanex16_b32 v41, v41, s61, s62 op_sel:[1,1]           ; d65c1829 00f87b29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v40, v40, v41                                 ; 64505328
	v_max_num_f16_e32 v40, s63, v40                             ; 6250503f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v42, v40                                  ; 7e541728
	v_rsq_f32_e32 v42, v42                                      ; 7e545d2a
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v42, v42, v30                                 ; 10543d2a
	v_mul_f32_e32 v97, v97, v42                                 ; 10c25561
	v_dual_mul_f32 v129, v129, v42 :: v_dual_mul_f32 v102, v102, v42 ; c8c65581 81665566
	v_dual_mul_f32 v133, v133, v42 :: v_dual_mul_f32 v130, v130, v42 ; c8c65585 85825582
	v_dual_mul_f32 v131, v131, v42 :: v_dual_mul_f32 v128, v128, v42 ; c8c65583 83805580
	v_dual_mul_f32 v99, v99, v42 :: v_dual_mul_f32 v96, v96, v42 ; c8c65563 63605560
	v_dual_mul_f32 v135, v135, v42 :: v_dual_mul_f32 v132, v132, v42 ; c8c65587 87845584
	v_dual_mul_f32 v43, v185, v185 :: v_dual_mul_f32 v134, v134, v42 ; c8c773b9 2b865586
	buffer_load_b128 v[56:59], v31, s[36:39], null offen offset:4096 ; c405c07c 40804838 0010001f
	v_dual_mul_f32 v101, v101, v42 :: v_dual_mul_f32 v98, v98, v42 ; c8c65565 65625562
	v_dual_mul_f32 v103, v103, v42 :: v_dual_mul_f32 v100, v100, v42 ; c8c65567 67645564
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_fmac_f32 v43, v145, v145 :: v_dual_mul_f32 v44, v187, v187 ; c8072391 2b2d77bb
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_fmac_f32 v43, v149, v149 :: v_dual_fmac_f32 v44, v147, v147 ; c8012b95 2b2d2793
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v43, v189, v189 :: v_dual_fmac_f32 v44, v151, v151 ; c8017bbd 2b2d2f97
	v_dual_fmac_f32 v43, v144, v144 :: v_dual_fmac_f32 v44, v191, v191 ; c8012190 2b2d7fbf
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v44, v146, v146                              ; 56592592
	v_dual_fmac_f32 v44, v186, v186 :: v_dual_fmac_f32 v43, v184, v184 ; c80175ba 2c2b71b8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v44, v150, v150 :: v_dual_fmac_f32 v43, v148, v148 ; c8012d96 2c2b2994
	v_dual_fmac_f32 v44, v190, v190 :: v_dual_fmac_f32 v43, v188, v188 ; c8017dbe 2c2b79bc
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_fma_mixlo_f16 v45, 1.0, v43, v44                          ; cc21002d 04b256f2
	buffer_load_b128 v[40:43], v31, s[36:39], null offen offset:4608 ; c405c07c 40804828 0012001f
	v_cvt_u32_u16_e32 v46, v45                                  ; 7e5cd72d
	v_permlanex16_b32 v46, v46, s61, s62 op_sel:[1,1]           ; d65c182e 00f87b2e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_add_f16_e32 v45, v45, v46                                 ; 645a5d2d
	buffer_load_b128 v[60:63], v31, s[36:39], null offen offset:5120 ; c405c07c 4080483c 0014001f
	v_max_num_f16_e32 v45, s63, v45                             ; 625a5a3f
	v_cvt_f32_f16_e32 v47, v45                                  ; 7e5e172d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v47, v47                                      ; 7e5e5d2f
	v_mul_f32_e32 v145, v145, v47                               ; 11225f91
	v_dual_mul_f32 v191, v191, v47 :: v_dual_mul_f32 v188, v188, v47 ; c8c65fbf bfbc5fbc
	v_mul_f32_e32 v144, v144, v47                               ; 11205f90
	v_dual_mul_f32 v147, v147, v47 :: v_dual_mul_f32 v146, v146, v47 ; c8c65f93 93925f92
	v_dual_mul_f32 v149, v149, v47 :: v_dual_mul_f32 v148, v148, v47 ; c8c65f95 95945f94
	v_mul_f32_e32 v187, v187, v47                               ; 11765fbb
	buffer_load_b128 v[68:71], v31, s[36:39], null offen offset:5632 ; c405c07c 40804844 0016001f
	v_dual_mul_f32 v49, v137, v137 :: v_dual_mul_f32 v190, v190, v47 ; c8c71389 31be5fbe
	v_dual_mul_f32 v185, v185, v47 :: v_dual_mul_f32 v184, v184, v47 ; c8c65fb9 b9b85fb8
	v_dual_mul_f32 v151, v151, v47 :: v_dual_mul_f32 v150, v150, v47 ; c8c65f97 97965f96
	v_dual_mul_f32 v189, v189, v47 :: v_dual_mul_f32 v186, v186, v47 ; c8c65fbd bdba5fba
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_dual_fmac_f32 v49, v161, v161 :: v_dual_mul_f32 v50, v139, v139 ; c80743a1 3133178b
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_dual_fmac_f32 v49, v165, v165 :: v_dual_fmac_f32 v50, v163, v163 ; c8014ba5 313347a3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v50, v167, v167                              ; 56654fa7
	v_dual_fmac_f32 v50, v143, v143 :: v_dual_fmac_f32 v49, v141, v141 ; c8011f8f 32311b8d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v50, v162, v162 :: v_dual_fmac_f32 v49, v160, v160 ; c80145a2 323141a0
	v_dual_fmac_f32 v50, v138, v138 :: v_dual_fmac_f32 v49, v136, v136 ; c801158a 32311188
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v50, v166, v166 :: v_dual_fmac_f32 v49, v164, v164 ; c8014da6 323149a4
	v_dual_fmac_f32 v50, v142, v142 :: v_dual_fmac_f32 v49, v140, v140 ; c8011d8e 3231198c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_fma_mixlo_f16 v51, 1.0, v49, v50                          ; cc210033 04ca62f2
	v_dual_mul_f32 v73, v15, v15 :: v_dual_mul_f32 v72, v13, v13 ; c8c61f0f 49481b0d
	v_cvt_u32_u16_e32 v52, v51                                  ; 7e68d733
	v_dual_fmac_f32 v73, v171, v171 :: v_dual_fmac_f32 v72, v169, v169 ; c80157ab 494953a9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v52, v52, s61, s62 op_sel:[1,1]           ; d65c1834 00f87b34
	v_dual_fmac_f32 v73, v175, v175 :: v_dual_fmac_f32 v72, v173, v173 ; c8015faf 49495bad
	v_add_f16_e32 v51, v51, v52                                 ; 64666933
	v_dual_fmac_f32 v73, v19, v19 :: v_dual_fmac_f32 v72, v17, v17 ; c8002713 49482311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_max_num_f16_e32 v51, s63, v51                             ; 6266663f
	v_dual_fmac_f32 v73, v170, v170 :: v_dual_fmac_f32 v72, v168, v168 ; c80155aa 494951a8
	v_cvt_f32_f16_e32 v53, v51                                  ; 7e6a1733
	v_dual_fmac_f32 v73, v14, v14 :: v_dual_fmac_f32 v72, v12, v12 ; c8001d0e 4948190c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a2
	v_rsq_f32_e32 v53, v53                                      ; 7e6a5d35
	v_dual_fmac_f32 v73, v174, v174 :: v_dual_fmac_f32 v72, v172, v172 ; c8015dae 494959ac
	v_dual_mul_f32 v164, v164, v53 :: v_dual_mul_f32 v165, v165, v53 ; c8c66ba4 a4a46ba5
	v_dual_mul_f32 v160, v160, v53 :: v_dual_mul_f32 v161, v161, v53 ; c8c66ba0 a0a06ba1
	v_dual_mul_f32 v162, v162, v53 :: v_dual_mul_f32 v163, v163, v53 ; c8c66ba2 a2a26ba3
	v_dual_mul_f32 v136, v136, v53 :: v_dual_mul_f32 v137, v137, v53 ; c8c66b88 88886b89
	v_dual_mul_f32 v166, v166, v53 :: v_dual_mul_f32 v167, v167, v53 ; c8c66ba6 a6a66ba7
	v_dual_mul_f32 v139, v139, v53 :: v_dual_mul_f32 v138, v138, v53 ; c8c66b8b 8b8a6b8a
	v_dual_mul_f32 v141, v141, v53 :: v_dual_mul_f32 v140, v140, v53 ; c8c66b8d 8d8c6b8c
	v_dual_mul_f32 v143, v143, v53 :: v_dual_mul_f32 v142, v142, v53 ; c8c66b8f 8f8e6b8e
	v_dual_fmac_f32 v73, v18, v18 :: v_dual_fmac_f32 v72, v16, v16 ; c8002512 49482110
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_fma_mixlo_f16 v74, 1.0, v72, v73                          ; cc21004a 052690f2
	v_lshl_add_u32 v77, v1, 12, s8                              ; d646004d 00211901
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_u32_u16_e32 v75, v74                                  ; 7e96d74a
	v_lshl_add_u32 v77, v4, 6, v77                              ; d646004d 05350d04
	v_permlanex16_b32 v75, v75, s61, s62 op_sel:[1,1]           ; d65c184b 00f87b4b
	v_add_lshl_u32 v77, v77, v6, 2                              ; d647004d 020a0d4d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_add_f16_e32 v74, v74, v75                                 ; 6494974a
	v_max_num_f16_e32 v74, s63, v74                             ; 6294943f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(TRANS32_DEP_1) ; bf8702d1
	v_cvt_f32_f16_e32 v76, v74                                  ; 7e98174a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v77, s[32:35], null offen        ; c405c07c 40804048 0000004d
	buffer_load_b128 v[80:83], v77, s[32:35], null offen offset:16 ; c405c07c 40804050 0000104d
	v_rsq_f32_e32 v76, v76                                      ; 7e985d4c
	v_dual_mul_f32 v169, v169, v76 :: v_dual_mul_f32 v168, v168, v76 ; c8c699a9 a9a899a8
	v_mul_f32_e32 v174, v174, v76                               ; 115c99ae
	v_dual_mul_f32 v14, v14, v76 :: v_dual_mul_f32 v13, v13, v76 ; c8c6990e 0e0c990d
	v_dual_mul_f32 v16, v16, v76 :: v_dual_mul_f32 v15, v15, v76 ; c8c69910 100e990f
	v_dual_mul_f32 v12, v12, v76 :: v_dual_mul_f32 v175, v175, v76 ; c8c6990c 0cae99af
	v_dual_mul_f32 v18, v18, v76 :: v_dual_mul_f32 v17, v17, v76 ; c8c69912 12109911
	v_dual_mul_f32 v78, v153, v153 :: v_dual_mul_f32 v19, v19, v76 ; c8c73399 4e129913
	v_dual_mul_f32 v171, v171, v76 :: v_dual_mul_f32 v170, v170, v76 ; c8c699ab abaa99aa
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v77, s[32:35], null offen offset:64 ; c405c07c 40804010 0000404d
	buffer_load_b128 v[84:87], v77, s[32:35], null offen offset:80 ; c405c07c 40804054 0000504d
	v_dual_mul_f32 v173, v173, v76 :: v_dual_mul_f32 v172, v172, v76 ; c8c699ad adac99ac
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
	v_dual_fmac_f32 v78, v177, v177 :: v_dual_mul_f32 v79, v155, v155 ; c80763b1 4e4f379b
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_dual_fmac_f32 v78, v181, v181 :: v_dual_fmac_f32 v79, v179, v179 ; c8016bb5 4e4f67b3
	v_dual_fmac_f32 v79, v183, v183 :: v_dual_fmac_f32 v78, v157, v157 ; c8016fb7 4f4f3b9d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v79, v159, v159                              ; 569f3f9f
	v_dual_fmac_f32 v79, v178, v178 :: v_dual_fmac_f32 v78, v176, v176 ; c80165b2 4f4f61b0
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[92:95], v77, s[32:35], null offen offset:128 ; c405c07c 4080405c 0000804d
	buffer_load_b128 v[96:99], v77, s[32:35], null offen offset:144 ; c405c07c 40804060 0000904d
	v_dual_fmac_f32 v79, v154, v154 :: v_dual_fmac_f32 v78, v152, v152 ; c801359a 4f4f3198
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v79, v182, v182 :: v_dual_fmac_f32 v78, v180, v180 ; c8016db6 4f4f69b4
	v_dual_fmac_f32 v79, v158, v158 :: v_dual_fmac_f32 v78, v156, v156 ; c8013d9e 4f4f399c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v88, 1.0, v78, v79                          ; cc210058 053e9cf2
	v_cvt_u32_u16_e32 v89, v88                                  ; 7eb2d758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v89, v89, s61, s62 op_sel:[1,1]           ; d65c1859 00f87b59
	v_add_f16_e32 v88, v88, v89                                 ; 64b0b358
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v88, s63, v88                             ; 62b0b03f
	v_cvt_f32_f16_e32 v90, v88                                  ; 7eb41758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v90, v90                                      ; 7eb45d5a
	v_dual_mul_f32 v183, v183, v90 :: v_dual_mul_f32 v182, v182, v90 ; c8c6b5b7 b7b6b5b6
	v_dual_mul_f32 v177, v177, v90 :: v_dual_mul_f32 v176, v176, v90 ; c8c6b5b1 b1b0b5b0
	v_dual_mul_f32 v153, v153, v90 :: v_dual_mul_f32 v152, v152, v90 ; c8c6b599 9998b598
	v_dual_mul_f32 v155, v155, v90 :: v_dual_mul_f32 v154, v154, v90 ; c8c6b59b 9b9ab59a
	v_mad_u32_u24 v64, s59, 0x820, v64                          ; d60b0040 0501fe3b 00000820
	ds_load_b64 v[78:79], v64                                   ; d9d80000 4e000040
	v_dual_mul_f32 v157, v157, v90 :: v_dual_mul_f32 v156, v156, v90 ; c8c6b59d 9d9cb59c
	v_mul_f32_e32 v181, v181, v90                               ; 116ab5b5
	v_dual_mul_f32 v159, v159, v90 :: v_dual_mul_f32 v158, v158, v90 ; c8c6b59f 9f9eb59e
	v_dual_mul_f32 v179, v179, v90 :: v_dual_mul_f32 v178, v178, v90 ; c8c6b5b3 b3b2b5b2
	v_mul_f32_e32 v180, v180, v90                               ; 1168b5b4
	buffer_load_b128 v[88:91], v77, s[32:35], null offen offset:192 ; c405c07c 40804058 0000c04d
	ds_load_b64 v[100:101], v64 offset:1024                     ; d9d80400 64000040
	buffer_load_b128 v[104:107], v77, s[32:35], null offen offset:208 ; c405c07c 40804068 0000d04d
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	ds_load_b64 v[102:103], v64 offset:2048                     ; d9d80800 66000040
	ds_load_b64 v[108:109], v64 offset:3072                     ; d9d80c00 6c000040
	ds_load_b64 v[110:111], v64 offset:256                      ; d9d80100 6e000040
	ds_load_b64 v[112:113], v64 offset:1280                     ; d9d80500 70000040
	ds_load_b64 v[114:115], v64 offset:2304                     ; d9d80900 72000040
	ds_load_b64 v[116:117], v64 offset:3328                     ; d9d80d00 74000040
	ds_load_b64 v[118:119], v64 offset:512                      ; d9d80200 76000040
	ds_load_b64 v[120:121], v64 offset:1536                     ; d9d80600 78000040
	ds_load_b64 v[122:123], v64 offset:2560                     ; d9d80a00 7a000040
	ds_load_b64 v[124:125], v64 offset:3584                     ; d9d80e00 7c000040
	ds_load_b64 v[126:127], v64 offset:768                      ; d9d80300 7e000040
	ds_load_b64 v[128:129], v64 offset:1792                     ; d9d80700 80000040
	ds_load_b64 v[130:131], v64 offset:2816                     ; d9d80b00 82000040
	ds_load_b64 v[132:133], v64 offset:3840                     ; d9d80f00 84000040
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_mov_b32_e32 v20, v77                                      ; 7e28034d
	s_wait_loadcnt_dscnt 0xb0f                                  ; bfc80b0f
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[56:57], v[78:79], 0 ; cc464088 1a029d38
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[58:59], v[78:79], 0 ; cc4640a8 1a029d3a
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[58:59], v[100:101], 0 ; cc4640b0 1a02c93a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[100:101], 0 ; cc464090 1a02c938
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[58:59], v[102:103], 0 ; cc4640b8 1a02cd3a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[102:103], 0 ; cc464098 1a02cd38
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[56:57], v[108:109], 0 ; cc4640a0 1a02d938
	s_wait_loadcnt_dscnt 0xa0b                                  ; bfc80a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[40:41], v[110:111], v[136:143] ; cc464088 1e22dd28
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[42:43], v[110:111], v[168:175] ; cc4640a8 1ea2dd2a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[112:113], v[176:183] ; cc4640b0 1ec2e12a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[40:41], v[112:113], v[144:151] ; cc464090 1e42e128
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[42:43], v[114:115], v[184:191] ; cc4640b8 1ee2e52a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[114:115], v[152:159] ; cc464098 1e62e528
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[40:41], v[116:117], v[160:167] ; cc4640a0 1e82e928
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[118:119], v[136:143] ; cc464088 1e22ed3c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[62:63], v[118:119], v[168:175] ; cc4640a8 1ea2ed3e
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[120:121], v[176:183] ; cc4640b0 1ec2f13e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[120:121], v[144:151] ; cc464090 1e42f13c
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[62:63], v[122:123], v[184:191] ; cc4640b8 1ee2f53e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[60:61], v[122:123], v[152:159] ; cc464098 1e62f53c
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[60:61], v[124:125], v[160:167] ; cc4640a0 1e82f93c
	s_wait_loadcnt_dscnt 0x803                                  ; bfc80803
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[126:127], v[136:143] ; cc464088 1e22fd44
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[70:71], v[126:127], v[168:175] ; cc4640a8 1ea2fd46
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[128:129], v[176:183] ; cc4640b0 1ec30146
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[68:69], v[128:129], v[144:151] ; cc464090 1e430144
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[70:71], v[130:131], v[184:191] ; cc4640b8 1ee30546
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[130:131], v[152:159] ; cc464098 1e630544
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[68:69], v[132:133], v[160:167] ; cc4640a0 1e830944
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mov_b32 v76, v96 :: v_dual_mov_b32 v77, v97          ; ca100160 4c4c0161
	v_dual_mov_b32 v78, v98 :: v_dual_mov_b32 v79, v99          ; ca100162 4e4e0163
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[108:109], 0 ; cc464060 1a02d93a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[116:117], v[96:103] ; cc464060 1d82e92a
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[62:63], v[124:125], v[96:103] ; cc464060 1d82f93e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[132:133], v[96:103] ; cc464060 1d830946
	ds_store_2addr_b64 v21, v[40:41], v[42:43] offset1:32       ; d9382000 002a2815
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	ds_store_2addr_b64 v21, v[40:41], v[42:43] offset0:128 offset1:160 ; d938a080 002a2815
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	ds_store_2addr_b64 v28, v[40:41], v[42:43] offset1:32       ; d9382000 002a281c
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v28, v[40:41], v[42:43] offset0:128 offset1:160 ; d938a080 002a281c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v20, s[32:35], null offen offset:4096 ; c405c07c 40804028 00100014
	buffer_load_b128 v[68:71], v20, s[32:35], null offen offset:4112 ; c405c07c 40804044 00101014
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[38:39], v[10:11], 0 ; cc464038 1a021526
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[30:31], v[10:11], 0 ; cc464060 1a02151e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[10:11], 0 ; cc464070 1a021532
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[10:11], 0 ; cc464078 1a02150e
	s_mov_b32 s64, 0x3d380000                                   ; bec000ff 3d380000
	s_movk_i32 s65, 0x3e47                                      ; b0413e47
	s_movk_i32 s66, 0x3c20                                      ; b0423c20
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[44:45], v[24:25], v[56:63] ; cc464038 1ce2312c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[24:25], v[96:103] ; cc464060 1d82312e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[24:25], v[112:119] ; cc464070 1dc2310c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[52:53], v[24:25], v[120:127] ; cc464078 1de23134
	v_fma_mixlo_f16 v24, s64, v56, v72                          ; cc210018 05227040
	v_fma_mixlo_f16 v56, s64, v62, v82                          ; cc210038 054a7c40
	v_fma_mixlo_f16 v25, s64, v58, v74                          ; cc210019 052a7440
	v_fma_mixhi_f16 v24, s64, v57, v73                          ; cc220018 05267240
	v_fma_mixhi_f16 v56, s64, v63, v83                          ; cc220038 054e7e40
	v_fma_mixhi_f16 v25, s64, v59, v75                          ; cc220019 052e7640
	v_fma_mixlo_f16 v49, s64, v60, v80                          ; cc210031 05427840
	v_fma_mixhi_f16 v49, s64, v61, v81                          ; cc220031 05467a40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v20, s[32:35], null offen offset:4160 ; c405c07c 4080403c 00104014
	buffer_load_b128 v[72:75], v20, s[32:35], null offen offset:4176 ; c405c07c 40804048 00105014
	v_fma_mixlo_f16 v57, s64, v96, v16                          ; cc210039 0442c040
	v_fma_mixhi_f16 v57, s64, v97, v17                          ; cc220039 0446c240
	v_fma_mixlo_f16 v58, s64, v98, v18                          ; cc21003a 044ac440
	v_fma_mixhi_f16 v58, s64, v99, v19                          ; cc22003a 044ec640
(invalid instruction)                                        ; cc1c0018
	v_subrev_f32_e32 v0, v24, v66                               ; 0a008518
(invalid instruction)                                        ; cc1c0038
	v_subrev_f32_e32 v0, v56, v66                               ; 0a008538
	v_fma_mixlo_f16 v59, s64, v100, v84                         ; cc21003b 0552c840
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v66                               ; 0a008519
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v20, s[32:35], null offen offset:4224 ; c405c07c 40804010 00108014
	buffer_load_b128 v[80:83], v20, s[32:35], null offen offset:4240 ; c405c07c 40804050 00109014
	v_fma_mixhi_f16 v59, s64, v101, v85                         ; cc22003b 0556ca40
(invalid instruction)                                        ; cc1c0031
	v_subrev_f32_e32 v0, v49, v66                               ; 0a008531
	v_fma_mixlo_f16 v64, s64, v102, v86                         ; cc210040 055acc40
	v_fma_mixhi_f16 v64, s64, v103, v87                         ; cc220040 055ece40
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v66                               ; 0a008539
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v66                               ; 0a00853a
(invalid instruction)                                        ; cc1b0018
	v_subrev_f32_e32 v0, v24, v65                               ; 0a008318
(invalid instruction)                                        ; cc1b0038
	v_subrev_f32_e32 v0, v56, v65                               ; 0a008338
	v_fma_mixlo_f16 v84, s64, v112, v92                         ; cc210054 0572e040
	v_fma_mixhi_f16 v84, s64, v113, v93                         ; cc220054 0576e240
(invalid instruction)                                        ; cc1b0019
	v_subrev_f32_e32 v0, v25, v65                               ; 0a008319
	v_fma_mixlo_f16 v85, s64, v114, v94                         ; cc210055 057ae440
	v_fma_mixhi_f16 v85, s64, v115, v95                         ; cc220055 057ee640
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v66                               ; 0a00853b
(invalid instruction)                                        ; cc1b0031
	v_subrev_f32_e32 v0, v49, v65                               ; 0a008331
	v_fma_mixlo_f16 v86, s64, v116, v76                         ; cc210056 0532e840
	v_fma_mixhi_f16 v86, s64, v117, v77                         ; cc220056 0536ea40
(invalid instruction)                                        ; cc1c0040
	v_subrev_f32_e32 v0, v64, v66                               ; 0a008540
	v_fma_mixlo_f16 v87, s64, v118, v78                         ; cc210057 053aec40
	v_fma_mixhi_f16 v87, s64, v119, v79                         ; cc220057 053eee40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[76:79], v20, s[32:35], null offen offset:4288 ; c405c07c 4080404c 0010c014
	buffer_load_b128 v[92:95], v20, s[32:35], null offen offset:4304 ; c405c07c 4080405c 0010d014
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v65                               ; 0a008339
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v65                               ; 0a00833a
(invalid instruction)                                        ; cc1c0054
	v_subrev_f32_e32 v0, v84, v66                               ; 0a008554
(invalid instruction)                                        ; cc1c0055
	v_subrev_f32_e32 v0, v85, v66                               ; 0a008555
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v88, s64, v120, v88                         ; cc210058 0562f040
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v65                               ; 0a00833b
	v_fma_mixhi_f16 v88, s64, v121, v89                         ; cc220058 0566f240
(invalid instruction)                                        ; cc1c0056
	v_subrev_f32_e32 v0, v86, v66                               ; 0a008556
(invalid instruction)                                        ; cc1b0040
	v_subrev_f32_e32 v0, v64, v65                               ; 0a008340
	v_fma_mixlo_f16 v89, s64, v122, v90                         ; cc210059 056af440
	v_fma_mixhi_f16 v89, s64, v123, v91                         ; cc220059 056ef640
(invalid instruction)                                        ; cc1c0057
	v_subrev_f32_e32 v0, v87, v66                               ; 0a008557
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v90, s64, v124, v104                        ; cc21005a 05a2f840
	v_fma_mixhi_f16 v90, s64, v125, v105                        ; cc22005a 05a6fa40
(invalid instruction)                                        ; cc1b0054
	v_subrev_f32_e32 v0, v84, v65                               ; 0a008354
(invalid instruction)                                        ; cc1b0055
	v_subrev_f32_e32 v0, v85, v65                               ; 0a008355
	v_fma_mixlo_f16 v91, s64, v126, v106                        ; cc21005b 05aafc40
	v_fma_mixhi_f16 v91, s64, v127, v107                        ; cc22005b 05aefe40
(invalid instruction)                                        ; cc1c0058
	v_subrev_f32_e32 v0, v88, v66                               ; 0a008558
	s_mov_b32 s67, 0x7ff88000                                   ; bec300ff 7ff88000
(invalid instruction)                                        ; cc1b0056
	v_subrev_f32_e32 v0, v86, v65                               ; 0a008356
(invalid instruction)                                        ; cc1c0059
	v_subrev_f32_e32 v0, v89, v66                               ; 0a008559
(invalid instruction)                                        ; cc1b0057
	v_subrev_f32_e32 v0, v87, v65                               ; 0a008357
(invalid instruction)                                        ; cc1c005a
	v_subrev_f32_e32 v0, v90, v66                               ; 0a00855a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v57, v57, 5, s67                             ; d6460039 010d0b39
	v_lshl_add_u32 v84, v84, 5, s67                             ; d6460054 010d0b54
	v_lshl_add_u32 v58, v58, 5, s67                             ; d646003a 010d0b3a
	v_lshl_add_u32 v25, v25, 5, s67                             ; d6460019 010d0b19
	v_lshl_add_u32 v24, v24, 5, s67                             ; d6460018 010d0b18
(invalid instruction)                                        ; cc1c005b
	v_subrev_f32_e32 v0, v91, v66                               ; 0a00855b
(invalid instruction)                                        ; cc1b0058
	v_subrev_f32_e32 v0, v88, v65                               ; 0a008358
	v_lshl_add_u32 v85, v85, 5, s67                             ; d6460055 010d0b55
(invalid instruction)                                        ; cc1b0059
	v_subrev_f32_e32 v0, v89, v65                               ; 0a008359
	v_lshl_add_u32 v49, v49, 5, s67                             ; d6460031 010d0b31
	v_lshl_add_u32 v59, v59, 5, s67                             ; d646003b 010d0b3b
(invalid instruction)                                        ; cc1b005a
	v_subrev_f32_e32 v0, v90, v65                               ; 0a00835a
	v_lshl_add_u32 v86, v86, 5, s67                             ; d6460056 010d0b56
(invalid instruction)                                        ; cc0f0061
	v_min_num_f64_e32 v[1:2], v[25:26], v[58:59]                ; 1a027519
(invalid instruction)                                        ; cc0f0060
	v_min_num_f64_e32 v[1:2], v[24:25], v[57:58]                ; 1a027318
(invalid instruction)                                        ; cc1b005b
	v_subrev_f32_e32 v0, v91, v65                               ; 0a00835b
	v_lshl_add_u32 v56, v56, 5, s67                             ; d6460038 010d0b38
	v_lshl_add_u32 v88, v88, 5, s67                             ; d6460058 010d0b58
	v_lshl_add_u32 v64, v64, 5, s67                             ; d6460040 010d0b40
	v_lshl_add_u32 v89, v89, 5, s67                             ; d6460059 010d0b59
	v_lshl_add_u32 v87, v87, 5, s67                             ; d6460057 010d0b57
(invalid instruction)                                        ; cc0f0062
	v_min_num_f64_e32 v[1:2], v[49:50], v[59:60]                ; 1a027731
	v_lshl_add_u32 v90, v90, 5, s67                             ; d646005a 010d0b5a
(invalid instruction)                                        ; cc0f0061
	v_min_num_f64_e32 v[1:2], v[97:98], v[85:86]                ; 1a02ab61
(invalid instruction)                                        ; cc0f0060
	v_min_num_f64_e32 v[1:2], v[96:97], v[84:85]                ; 1a02a960
	v_lshl_add_u32 v91, v91, 5, s67                             ; d646005b 010d0b5b
(invalid instruction)                                        ; cc0f0063
	v_min_num_f64_e32 v[1:2], v[56:57], v[64:65]                ; 1a028138
(invalid instruction)                                        ; cc0f0062
	v_min_num_f64_e32 v[1:2], v[98:99], v[86:87]                ; 1a02ad62
(invalid instruction)                                        ; cc0f0061
	v_min_num_f64_e32 v[1:2], v[97:98], v[89:90]                ; 1a02b361
(invalid instruction)                                        ; cc0f0060
	v_min_num_f64_e32 v[1:2], v[96:97], v[88:89]                ; 1a02b160
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; cc0f0063
	v_min_num_f64_e32 v[1:2], v[99:100], v[87:88]               ; 1a02af63
(invalid instruction)                                        ; cc0f0062
	v_min_num_f64_e32 v[1:2], v[98:99], v[90:91]                ; 1a02b562
(invalid instruction)                                        ; cc0f0060
	v_min_num_f64_e32 v[1:2], v[96:97], v[97:98]                ; 1a02c360
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f0063
	v_min_num_f64_e32 v[1:2], v[99:100], v[91:92]               ; 1a02b763
(invalid instruction)                                        ; cc0f0060
	v_min_num_f64_e32 v[1:2], v[96:97], v[98:99]                ; 1a02c560
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0060
	v_min_num_f64_e32 v[1:2], v[96:97], v[99:100]               ; 1a02c760
	v_permlanex16_b32 v100, v96, s61, s62 op_sel:[1,1]          ; d65c1864 00f87b60
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0060
	v_min_num_f64_e32 v[1:2], v[96:97], v[100:101]              ; 1a02c960
	v_add_f16_e32 v101, v96, v224/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64cbc160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v101, s60, v101                           ; 62caca3c
	v_cvt_f32_f16_e32 v102, v101                                ; 7ecc1765
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v102, v102                                    ; 7ecc5566
	v_fma_mix_f32 v106, v56, v102, neg(0) op_sel_hi:[1,0,0]     ; cc20006a 8a02cd38
	v_fma_mix_f32 v108, v58, v102, neg(0) op_sel_hi:[1,0,0]     ; cc20006c 8a02cd3a
	v_fma_mix_f32 v105, v49, v102, neg(0) op_sel_hi:[1,0,0]     ; cc200069 8a02cd31
	v_fma_mix_f32 v104, v25, v102, neg(0) op_sel_hi:[1,0,0]     ; cc200068 8a02cd19
	v_fma_mix_f32 v25, v25, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200819 8a02cd19
	v_fma_mix_f32 v49, v49, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200831 8a02cd31
	v_fma_mix_f32 v103, v24, v102, neg(0) op_sel_hi:[1,0,0]     ; cc200067 8a02cd18
	v_fma_mix_f32 v56, v56, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200838 8a02cd38
	v_fma_mix_f32 v107, v57, v102, neg(0) op_sel_hi:[1,0,0]     ; cc20006b 8a02cd39
	v_fma_mix_f32 v57, v57, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200839 8a02cd39
	v_fma_mix_f32 v24, v24, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200818 8a02cd18
	v_fma_mix_f32 v58, v58, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083a 8a02cd3a
	v_fma_mix_f32 v109, v59, v102, neg(0) op_sel_hi:[1,0,0]     ; cc20006d 8a02cd3b
	v_fma_mix_f32 v59, v59, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083b 8a02cd3b
	v_fma_mix_f32 v110, v64, v102, neg(0) op_sel_hi:[1,0,0]     ; cc20006e 8a02cd40
	v_fma_mix_f32 v64, v64, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200840 8a02cd40
	v_fma_mix_f32 v111, v84, v102, neg(0) op_sel_hi:[1,0,0]     ; cc20006f 8a02cd54
	v_fma_mix_f32 v84, v84, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200854 8a02cd54
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v105, v49, vcc_lo                     ; 02026369
	v_fma_mix_f32 v112, v85, v102, neg(0) op_sel_hi:[1,0,0]     ; cc200070 8a02cd55
	v_fma_mix_f32 v85, v85, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200855 8a02cd55
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v106, v56, vcc_lo                     ; 0202716a
	v_fma_mix_f32 v113, v86, v102, neg(0) op_sel_hi:[1,0,0]     ; cc200071 8a02cd56
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v103, v24, vcc_lo                     ; 02023167
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v104, v25, vcc_lo                     ; 02023368
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v107, v57, vcc_lo                     ; 0202736b
	v_fma_mix_f32 v86, v86, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200856 8a02cd56
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v108, v58, vcc_lo                     ; 0202756c
	v_fma_mix_f32 v114, v87, v102, neg(0) op_sel_hi:[1,0,0]     ; cc200072 8a02cd57
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v109, v59, vcc_lo                     ; 0202776d
	v_fma_mix_f32 v87, v87, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200857 8a02cd57
	v_fma_mix_f32 v115, v88, v102, neg(0) op_sel_hi:[1,0,0]     ; cc200073 8a02cd58
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v110, v64, vcc_lo                     ; 0202816e
	v_fma_mix_f32 v88, v88, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200858 8a02cd58
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v111, v84, vcc_lo                     ; 0202a96f
	v_fma_mix_f32 v116, v89, v102, neg(0) op_sel_hi:[1,0,0]     ; cc200074 8a02cd59
	v_fma_mix_f32 v89, v89, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200859 8a02cd59
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v112, v85, vcc_lo                     ; 0202ab70
	v_fma_mix_f32 v117, v90, v102, neg(0) op_sel_hi:[1,0,0]     ; cc200075 8a02cd5a
	v_fma_mix_f32 v90, v90, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085a 8a02cd5a
	v_fma_mix_f32 v118, v91, v102, neg(0) op_sel_hi:[1,0,0]     ; cc200076 8a02cd5b
	v_fma_mix_f32 v91, v91, v102, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085b 8a02cd5b
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v113, v86, vcc_lo                     ; 0202ad71
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v114, v87, vcc_lo                     ; 0202af72
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v115, v88, vcc_lo                     ; 0202b173
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v116, v89, vcc_lo                     ; 0202b374
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v117, v90, vcc_lo                     ; 0202b575
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v118, v91, vcc_lo                     ; 0202b776
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[84:87], v20, s[32:35], null offen offset:8192 ; c405c07c 40804054 00200014
	buffer_load_b128 v[88:91], v20, s[32:35], null offen offset:8208 ; c405c07c 40804058 00201014
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[8:9], 0  ; cc464060 1a021126
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[8:9], 0 ; cc464068 1a02111e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[8:9], 0 ; cc464070 1a021132
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[8:9], 0 ; cc464078 1a02110e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[26:27], v[96:103] ; cc464060 1d82352c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[26:27], v[104:111] ; cc464068 1da2352e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[26:27], v[112:119] ; cc464070 1dc2350c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[52:53], v[26:27], v[120:127] ; cc464078 1de23534
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v129, s64, v98, v42                         ; cc210081 04aac440
	v_fma_mixhi_f16 v129, s64, v99, v43                         ; cc220081 04aec640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v131, s64, v102, v70                        ; cc210083 051acc40
	v_fma_mixhi_f16 v131, s64, v103, v71                        ; cc220083 051ece40
	v_fma_mixlo_f16 v130, s64, v100, v68                        ; cc210082 0512c840
	v_fma_mixhi_f16 v130, s64, v101, v69                        ; cc220082 0516ca40
	v_fma_mixlo_f16 v128, s64, v96, v40                         ; cc210080 04a2c040
	v_fma_mixhi_f16 v128, s64, v97, v41                         ; cc220080 04a6c240
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v20, s[32:35], null offen offset:8256 ; c405c07c 40804028 00204014
	buffer_load_b128 v[68:71], v20, s[32:35], null offen offset:8272 ; c405c07c 40804044 00205014
(invalid instruction)                                        ; cc1c0081
	v_subrev_f32_e32 v0, v129, v66                              ; 0a008581
(invalid instruction)                                        ; cc1c0083
	v_subrev_f32_e32 v0, v131, v66                              ; 0a008583
(invalid instruction)                                        ; cc1c0082
	v_subrev_f32_e32 v0, v130, v66                              ; 0a008582
(invalid instruction)                                        ; cc1c0080
	v_subrev_f32_e32 v0, v128, v66                              ; 0a008580
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b0081
	v_subrev_f32_e32 v0, v129, v65                              ; 0a008381
(invalid instruction)                                        ; cc1b0083
	v_subrev_f32_e32 v0, v131, v65                              ; 0a008383
(invalid instruction)                                        ; cc1b0082
	v_subrev_f32_e32 v0, v130, v65                              ; 0a008382
(invalid instruction)                                        ; cc1b0080
	v_subrev_f32_e32 v0, v128, v65                              ; 0a008380
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v132, s64, v104, v60                        ; cc210084 04f2d040
	v_fma_mixhi_f16 v132, s64, v105, v61                        ; cc220084 04f6d240
	v_fma_mixlo_f16 v133, s64, v106, v62                        ; cc210085 04fad440
	v_fma_mixhi_f16 v133, s64, v107, v63                        ; cc220085 04fed640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v135, s64, v110, v74                        ; cc210087 052adc40
	v_fma_mixlo_f16 v134, s64, v108, v72                        ; cc210086 0522d840
	v_fma_mixhi_f16 v134, s64, v109, v73                        ; cc220086 0526da40
	v_fma_mixhi_f16 v135, s64, v111, v75                        ; cc220087 052ede40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v20, s[32:35], null offen offset:8320 ; c405c07c 4080403c 00208014
	buffer_load_b128 v[72:75], v20, s[32:35], null offen offset:8336 ; c405c07c 40804048 00209014
(invalid instruction)                                        ; cc1c0084
	v_subrev_f32_e32 v0, v132, v66                              ; 0a008584
(invalid instruction)                                        ; cc1c0085
	v_subrev_f32_e32 v0, v133, v66                              ; 0a008585
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v137, s64, v114, v18                        ; cc210089 044ae440
	v_fma_mixhi_f16 v137, s64, v115, v19                        ; cc220089 044ee640
	v_fma_mixlo_f16 v136, s64, v112, v16                        ; cc210088 0442e040
	v_fma_mixhi_f16 v136, s64, v113, v17                        ; cc220088 0446e240
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v138, s64, v116, v80                        ; cc21008a 0542e840
	v_fma_mixhi_f16 v138, s64, v117, v81                        ; cc22008a 0546ea40
(invalid instruction)                                        ; cc1c0086
	v_subrev_f32_e32 v0, v134, v66                              ; 0a008586
	v_fma_mixlo_f16 v139, s64, v118, v82                        ; cc21008b 054aec40
	v_fma_mixhi_f16 v139, s64, v119, v83                        ; cc22008b 054eee40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[16:19], v20, s[32:35], null offen offset:8384 ; c405c07c 40804010 0020c014
	buffer_load_b128 v[80:83], v20, s[32:35], null offen offset:8400 ; c405c07c 40804050 0020d014
(invalid instruction)                                        ; cc1c0087
	v_subrev_f32_e32 v0, v135, v66                              ; 0a008587
(invalid instruction)                                        ; cc1b0084
	v_subrev_f32_e32 v0, v132, v65                              ; 0a008384
(invalid instruction)                                        ; cc1b0085
	v_subrev_f32_e32 v0, v133, v65                              ; 0a008385
(invalid instruction)                                        ; cc1c0089
	v_subrev_f32_e32 v0, v137, v66                              ; 0a008589
(invalid instruction)                                        ; cc1c0088
	v_subrev_f32_e32 v0, v136, v66                              ; 0a008588
(invalid instruction)                                        ; cc1c008a
	v_subrev_f32_e32 v0, v138, v66                              ; 0a00858a
(invalid instruction)                                        ; cc1b0086
	v_subrev_f32_e32 v0, v134, v65                              ; 0a008386
(invalid instruction)                                        ; cc1c008b
	v_subrev_f32_e32 v0, v139, v66                              ; 0a00858b
(invalid instruction)                                        ; cc1b0087
	v_subrev_f32_e32 v0, v135, v65                              ; 0a008387
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v140, s64, v120, v76                        ; cc21008c 0532f040
(invalid instruction)                                        ; cc1b0089
	v_subrev_f32_e32 v0, v137, v65                              ; 0a008389
	v_fma_mixhi_f16 v140, s64, v121, v77                        ; cc22008c 0536f240
	v_fma_mixlo_f16 v141, s64, v122, v78                        ; cc21008d 053af440
	v_fma_mixhi_f16 v141, s64, v123, v79                        ; cc22008d 053ef640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v142, s64, v124, v92                        ; cc21008e 0572f840
	v_fma_mixlo_f16 v143, s64, v126, v94                        ; cc21008f 057afc40
(invalid instruction)                                        ; cc1b0088
	v_subrev_f32_e32 v0, v136, v65                              ; 0a008388
	v_fma_mixhi_f16 v142, s64, v125, v93                        ; cc22008e 0576fa40
(invalid instruction)                                        ; cc1b008a
	v_subrev_f32_e32 v0, v138, v65                              ; 0a00838a
	v_fma_mixhi_f16 v143, s64, v127, v95                        ; cc22008f 057efe40
(invalid instruction)                                        ; cc1b008b
	v_subrev_f32_e32 v0, v139, v65                              ; 0a00838b
	v_lshl_add_u32 v128, v128, 5, s67                           ; d6460080 010d0b80
	v_lshl_add_u32 v132, v132, 5, s67                           ; d6460084 010d0b84
(invalid instruction)                                        ; cc1c008c
	v_subrev_f32_e32 v0, v140, v66                              ; 0a00858c
(invalid instruction)                                        ; cc1c008d
	v_subrev_f32_e32 v0, v141, v66                              ; 0a00858d
	v_lshl_add_u32 v129, v129, 5, s67                           ; d6460081 010d0b81
	v_lshl_add_u32 v136, v136, 5, s67                           ; d6460088 010d0b88
	v_lshl_add_u32 v133, v133, 5, s67                           ; d6460085 010d0b85
(invalid instruction)                                        ; cc1c008e
	v_subrev_f32_e32 v0, v142, v66                              ; 0a00858e
	v_lshl_add_u32 v137, v137, 5, s67                           ; d6460089 010d0b89
(invalid instruction)                                        ; cc1c008f
	v_subrev_f32_e32 v0, v143, v66                              ; 0a00858f
(invalid instruction)                                        ; cc0f0090
	v_min_num_f64_e32 v[1:2], v[128:129], v[132:133]            ; 1a030980
	v_lshl_add_u32 v130, v130, 5, s67                           ; d6460082 010d0b82
(invalid instruction)                                        ; cc1b008c
	v_subrev_f32_e32 v0, v140, v65                              ; 0a00838c
	v_lshl_add_u32 v134, v134, 5, s67                           ; d6460086 010d0b86
(invalid instruction)                                        ; cc1b008d
	v_subrev_f32_e32 v0, v141, v65                              ; 0a00838d
	v_lshl_add_u32 v138, v138, 5, s67                           ; d646008a 010d0b8a
(invalid instruction)                                        ; cc0f0091
	v_min_num_f64_e32 v[1:2], v[129:130], v[133:134]            ; 1a030b81
(invalid instruction)                                        ; cc1b008e
	v_subrev_f32_e32 v0, v142, v65                              ; 0a00838e
	v_lshl_add_u32 v131, v131, 5, s67                           ; d6460083 010d0b83
	v_lshl_add_u32 v135, v135, 5, s67                           ; d6460087 010d0b87
(invalid instruction)                                        ; cc1b008f
	v_subrev_f32_e32 v0, v143, v65                              ; 0a00838f
(invalid instruction)                                        ; cc0f0090
	v_min_num_f64_e32 v[1:2], v[144:145], v[136:137]            ; 1a031190
	v_lshl_add_u32 v139, v139, 5, s67                           ; d646008b 010d0b8b
	v_lshl_add_u32 v140, v140, 5, s67                           ; d646008c 010d0b8c
(invalid instruction)                                        ; cc0f0092
	v_min_num_f64_e32 v[1:2], v[130:131], v[134:135]            ; 1a030d82
	v_lshl_add_u32 v141, v141, 5, s67                           ; d646008d 010d0b8d
(invalid instruction)                                        ; cc0f0091
	v_min_num_f64_e32 v[1:2], v[145:146], v[137:138]            ; 1a031391
	v_lshl_add_u32 v142, v142, 5, s67                           ; d646008e 010d0b8e
(invalid instruction)                                        ; cc0f0093
	v_min_num_f64_e32 v[1:2], v[131:132], v[135:136]            ; 1a030f83
	v_lshl_add_u32 v143, v143, 5, s67                           ; d646008f 010d0b8f
(invalid instruction)                                        ; cc0f0090
	v_min_num_f64_e32 v[1:2], v[144:145], v[140:141]            ; 1a031990
(invalid instruction)                                        ; cc0f0092
	v_min_num_f64_e32 v[1:2], v[146:147], v[138:139]            ; 1a031592
(invalid instruction)                                        ; cc0f0091
	v_min_num_f64_e32 v[1:2], v[145:146], v[141:142]            ; 1a031b91
(invalid instruction)                                        ; cc0f0093
	v_min_num_f64_e32 v[1:2], v[147:148], v[139:140]            ; 1a031793
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
(invalid instruction)                                        ; cc0f0092
	v_min_num_f64_e32 v[1:2], v[146:147], v[142:143]            ; 1a031d92
(invalid instruction)                                        ; cc0f0090
	v_min_num_f64_e32 v[1:2], v[144:145], v[145:146]            ; 1a032390
(invalid instruction)                                        ; cc0f0093
	v_min_num_f64_e32 v[1:2], v[147:148], v[143:144]            ; 1a031f93
(invalid instruction)                                        ; cc0f0090
	v_min_num_f64_e32 v[1:2], v[144:145], v[146:147]            ; 1a032590
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0090
	v_min_num_f64_e32 v[1:2], v[144:145], v[147:148]            ; 1a032790
	v_permlanex16_b32 v148, v144, s61, s62 op_sel:[1,1]         ; d65c1894 00f87b90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0090
	v_min_num_f64_e32 v[1:2], v[144:145], v[148:149]            ; 1a032990
(invalid instruction)                                        ; d5321095
	v_cndmask_b32_e32 v1, v144, v144, vcc_lo                    ; 02032190
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5310095
	v_cndmask_b32_e32 v1, s60, v149, vcc_lo                     ; 02032a3c
(invalid instruction)                                        ; d58b0096
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                    ; 02010195
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v150, v150                                    ; 7f2c5596
	v_fma_mix_f32 v154, v131, v150, neg(0) op_sel_hi:[1,0,0]    ; cc20009a 8a032d83
	v_fma_mix_f32 v152, v129, v150, neg(0) op_sel_hi:[1,0,0]    ; cc200098 8a032d81
	v_fma_mix_f32 v131, v131, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200883 8a032d83
	v_fma_mix_f32 v129, v129, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a032d81
	v_fma_mix_f32 v156, v133, v150, neg(0) op_sel_hi:[1,0,0]    ; cc20009c 8a032d85
	v_fma_mix_f32 v153, v130, v150, neg(0) op_sel_hi:[1,0,0]    ; cc200099 8a032d82
	v_fma_mix_f32 v130, v130, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200882 8a032d82
	v_fma_mix_f32 v155, v132, v150, neg(0) op_sel_hi:[1,0,0]    ; cc20009b 8a032d84
	v_fma_mix_f32 v132, v132, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200884 8a032d84
	v_fma_mix_f32 v151, v128, v150, neg(0) op_sel_hi:[1,0,0]    ; cc200097 8a032d80
	v_fma_mix_f32 v128, v128, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200880 8a032d80
	v_fma_mix_f32 v133, v133, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200885 8a032d85
	v_fma_mix_f32 v157, v134, v150, neg(0) op_sel_hi:[1,0,0]    ; cc20009d 8a032d86
	v_fma_mix_f32 v134, v134, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200886 8a032d86
	v_fma_mix_f32 v158, v135, v150, neg(0) op_sel_hi:[1,0,0]    ; cc20009e 8a032d87
	v_fma_mix_f32 v135, v135, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200887 8a032d87
	v_fma_mix_f32 v159, v136, v150, neg(0) op_sel_hi:[1,0,0]    ; cc20009f 8a032d88
	v_fma_mix_f32 v136, v136, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200888 8a032d88
	v_fma_mix_f32 v160, v137, v150, neg(0) op_sel_hi:[1,0,0]    ; cc2000a0 8a032d89
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v153, v130, vcc_lo                    ; 02030599
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v154, v131, vcc_lo                    ; 0203079a
	v_fma_mix_f32 v137, v137, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200889 8a032d89
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v155, v132, vcc_lo                    ; 0203099b
	v_fma_mix_f32 v161, v138, v150, neg(0) op_sel_hi:[1,0,0]    ; cc2000a1 8a032d8a
	v_fma_mix_f32 v138, v138, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088a 8a032d8a
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v151, v128, vcc_lo                    ; 02030197
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v152, v129, vcc_lo                    ; 02030398
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v156, v133, vcc_lo                    ; 02030b9c
	v_fma_mix_f32 v162, v139, v150, neg(0) op_sel_hi:[1,0,0]    ; cc2000a2 8a032d8b
	v_fma_mix_f32 v139, v139, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088b 8a032d8b
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v157, v134, vcc_lo                    ; 02030d9d
	v_fma_mix_f32 v163, v140, v150, neg(0) op_sel_hi:[1,0,0]    ; cc2000a3 8a032d8c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v158, v135, vcc_lo                    ; 02030f9e
	v_fma_mix_f32 v140, v140, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088c 8a032d8c
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v159, v136, vcc_lo                    ; 0203119f
	v_fma_mix_f32 v164, v141, v150, neg(0) op_sel_hi:[1,0,0]    ; cc2000a4 8a032d8d
	v_fma_mix_f32 v141, v141, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088d 8a032d8d
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v160, v137, vcc_lo                    ; 020313a0
	v_fma_mix_f32 v165, v142, v150, neg(0) op_sel_hi:[1,0,0]    ; cc2000a5 8a032d8e
	v_fma_mix_f32 v142, v142, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088e 8a032d8e
	v_fma_mix_f32 v166, v143, v150, neg(0) op_sel_hi:[1,0,0]    ; cc2000a6 8a032d8f
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v161, v138, vcc_lo                    ; 020315a1
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[92:95], v20, s[32:35], null offen offset:12288 ; c405c07c 4080405c 00300014
	buffer_load_b128 v[128:131], v20, s[32:35], null offen offset:12304 ; c405c07c 40804080 00301014
	v_fma_mix_f32 v143, v143, v150, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088f 8a032d8f
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[32:33], 0 ; cc464060 1a024126
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[32:33], 0 ; cc464068 1a02411e
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v162, v139, vcc_lo                    ; 020317a2
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[32:33], 0 ; cc464070 1a024132
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[32:33], 0 ; cc464078 1a02410e
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v163, v140, vcc_lo                    ; 020319a3
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v164, v141, vcc_lo                    ; 02031ba4
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v165, v142, vcc_lo                    ; 02031da5
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v166, v143, vcc_lo                    ; 02031fa6
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[34:35], v[96:103] ; cc464060 1d82452c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[34:35], v[104:111] ; cc464068 1da2452e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[34:35], v[112:119] ; cc464070 1dc2450c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[52:53], v[34:35], v[120:127] ; cc464078 1de24534
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v170, s64, v102, v90                        ; cc2100aa 056acc40
	v_fma_mixlo_f16 v167, s64, v96, v84                         ; cc2100a7 0552c040
	v_fma_mixhi_f16 v167, s64, v97, v85                         ; cc2200a7 0556c240
	v_fma_mixlo_f16 v168, s64, v98, v86                         ; cc2100a8 055ac440
	v_fma_mixhi_f16 v168, s64, v99, v87                         ; cc2200a8 055ec640
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[32:35], v20, s[32:35], null offen offset:12352 ; c405c07c 40804020 00304014
	buffer_load_b128 v[84:87], v20, s[32:35], null offen offset:12368 ; c405c07c 40804054 00305014
	v_fma_mixhi_f16 v170, s64, v103, v91                        ; cc2200aa 056ece40
	v_fma_mixlo_f16 v169, s64, v100, v88                        ; cc2100a9 0562c840
	v_fma_mixhi_f16 v169, s64, v101, v89                        ; cc2200a9 0566ca40
(invalid instruction)                                        ; cc1c00a7
	v_subrev_f32_e32 v0, v167, v66                              ; 0a0085a7
(invalid instruction)                                        ; cc1c00a8
	v_subrev_f32_e32 v0, v168, v66                              ; 0a0085a8
(invalid instruction)                                        ; cc1c00aa
	v_subrev_f32_e32 v0, v170, v66                              ; 0a0085aa
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v66                              ; 0a0085a9
(invalid instruction)                                        ; cc1b00a7
	v_subrev_f32_e32 v0, v167, v65                              ; 0a0083a7
(invalid instruction)                                        ; cc1b00a8
	v_subrev_f32_e32 v0, v168, v65                              ; 0a0083a8
(invalid instruction)                                        ; cc1b00aa
	v_subrev_f32_e32 v0, v170, v65                              ; 0a0083aa
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v171, s64, v104, v40                        ; cc2100ab 04a2d040
	v_fma_mixlo_f16 v172, s64, v106, v42                        ; cc2100ac 04aad440
	v_fma_mixhi_f16 v171, s64, v105, v41                        ; cc2200ab 04a6d240
	v_fma_mixhi_f16 v172, s64, v107, v43                        ; cc2200ac 04aed640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v173, s64, v108, v68                        ; cc2100ad 0512d840
	v_fma_mixhi_f16 v173, s64, v109, v69                        ; cc2200ad 0516da40
	v_fma_mixlo_f16 v174, s64, v110, v70                        ; cc2100ae 051adc40
	v_fma_mixhi_f16 v174, s64, v111, v71                        ; cc2200ae 051ede40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v20, s[32:35], null offen offset:12416 ; c405c07c 40804028 00308014
	buffer_load_b128 v[68:71], v20, s[32:35], null offen offset:12432 ; c405c07c 40804044 00309014
(invalid instruction)                                        ; cc1b00a9
	v_subrev_f32_e32 v0, v169, v65                              ; 0a0083a9
(invalid instruction)                                        ; cc1c00ab
	v_subrev_f32_e32 v0, v171, v66                              ; 0a0085ab
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v66                              ; 0a0085ac
(invalid instruction)                                        ; cc1c00ad
	v_subrev_f32_e32 v0, v173, v66                              ; 0a0085ad
(invalid instruction)                                        ; cc1c00ae
	v_subrev_f32_e32 v0, v174, v66                              ; 0a0085ae
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b00ab
	v_subrev_f32_e32 v0, v171, v65                              ; 0a0083ab
(invalid instruction)                                        ; cc1b00ac
	v_subrev_f32_e32 v0, v172, v65                              ; 0a0083ac
(invalid instruction)                                        ; cc1b00ad
	v_subrev_f32_e32 v0, v173, v65                              ; 0a0083ad
(invalid instruction)                                        ; cc1b00ae
	v_subrev_f32_e32 v0, v174, v65                              ; 0a0083ae
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v175, s64, v112, v60                        ; cc2100af 04f2e040
	v_fma_mixhi_f16 v175, s64, v113, v61                        ; cc2200af 04f6e240
	v_fma_mixlo_f16 v176, s64, v114, v62                        ; cc2100b0 04fae440
	v_fma_mixhi_f16 v176, s64, v115, v63                        ; cc2200b0 04fee640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v178, s64, v118, v74                        ; cc2100b2 052aec40
	v_fma_mixhi_f16 v178, s64, v119, v75                        ; cc2200b2 052eee40
	v_fma_mixlo_f16 v177, s64, v116, v72                        ; cc2100b1 0522e840
	v_fma_mixhi_f16 v177, s64, v117, v73                        ; cc2200b1 0526ea40
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v20, s[32:35], null offen offset:12480 ; c405c07c 4080403c 0030c014
	buffer_load_b128 v[72:75], v20, s[32:35], null offen offset:12496 ; c405c07c 40804048 0030d014
	v_add3_u32 v54, v55, s18, v54                               ; d6550036 04d82537
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v66                              ; 0a0085af
(invalid instruction)                                        ; cc1c00b0
	v_subrev_f32_e32 v0, v176, v66                              ; 0a0085b0
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v66                              ; 0a0085b2
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v66                              ; 0a0085b1
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v179, s64, v120, v16                        ; cc2100b3 0442f040
	v_fma_mixhi_f16 v179, s64, v121, v17                        ; cc2200b3 0446f240
	v_fma_mixlo_f16 v180, s64, v122, v18                        ; cc2100b4 044af440
	v_fma_mixhi_f16 v180, s64, v123, v19                        ; cc2200b4 044ef640
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v181, s64, v124, v80                        ; cc2100b5 0542f840
	v_fma_mixhi_f16 v181, s64, v125, v81                        ; cc2200b5 0546fa40
	v_lshlrev_b32_e32 v54, 2, v54                               ; 306c6c82
	v_fma_mixlo_f16 v182, s64, v126, v82                        ; cc2100b6 054afc40
(invalid instruction)                                        ; cc1b00af
	v_subrev_f32_e32 v0, v175, v65                              ; 0a0083af
(invalid instruction)                                        ; cc1b00b0
	v_subrev_f32_e32 v0, v176, v65                              ; 0a0083b0
	v_fma_mixhi_f16 v182, s64, v127, v83                        ; cc2200b6 054efe40
(invalid instruction)                                        ; cc1b00b2
	v_subrev_f32_e32 v0, v178, v65                              ; 0a0083b2
(invalid instruction)                                        ; cc1b00b1
	v_subrev_f32_e32 v0, v177, v65                              ; 0a0083b1
	v_lshl_add_u32 v167, v167, 5, s67                           ; d64600a7 010d0ba7
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v66                              ; 0a0085b3
	v_lshl_add_u32 v171, v171, 5, s67                           ; d64600ab 010d0bab
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v66                              ; 0a0085b4
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v66                              ; 0a0085b5
	v_lshl_add_u32 v168, v168, 5, s67                           ; d64600a8 010d0ba8
	v_lshl_add_u32 v172, v172, 5, s67                           ; d64600ac 010d0bac
	v_lshl_add_u32 v175, v175, 5, s67                           ; d64600af 010d0baf
(invalid instruction)                                        ; cc1c00b6
	v_subrev_f32_e32 v0, v182, v66                              ; 0a0085b6
	v_lshl_add_u32 v176, v176, 5, s67                           ; d64600b0 010d0bb0
	v_lshl_add_u32 v169, v169, 5, s67                           ; d64600a9 010d0ba9
(invalid instruction)                                        ; cc1b00b3
	v_subrev_f32_e32 v0, v179, v65                              ; 0a0083b3
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[167:168], v[171:172]            ; 1a0357a7
	v_lshl_add_u32 v173, v173, 5, s67                           ; d64600ad 010d0bad
(invalid instruction)                                        ; cc1b00b4
	v_subrev_f32_e32 v0, v180, v65                              ; 0a0083b4
(invalid instruction)                                        ; cc1b00b5
	v_subrev_f32_e32 v0, v181, v65                              ; 0a0083b5
	v_lshl_add_u32 v177, v177, 5, s67                           ; d64600b1 010d0bb1
(invalid instruction)                                        ; cc0f00b8
	v_min_num_f64_e32 v[1:2], v[168:169], v[172:173]            ; 1a0359a8
(invalid instruction)                                        ; cc1b00b6
	v_subrev_f32_e32 v0, v182, v65                              ; 0a0083b6
	v_lshl_add_u32 v170, v170, 5, s67                           ; d64600aa 010d0baa
	v_lshl_add_u32 v174, v174, 5, s67                           ; d64600ae 010d0bae
	v_lshl_add_u32 v178, v178, 5, s67                           ; d64600b2 010d0bb2
	v_lshl_add_u32 v179, v179, 5, s67                           ; d64600b3 010d0bb3
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[175:176]            ; 1a035fb7
(invalid instruction)                                        ; cc0f00b9
	v_min_num_f64_e32 v[1:2], v[169:170], v[173:174]            ; 1a035ba9
	v_lshl_add_u32 v180, v180, 5, s67                           ; d64600b4 010d0bb4
	v_lshl_add_u32 v181, v181, 5, s67                           ; d64600b5 010d0bb5
(invalid instruction)                                        ; cc0f00b8
	v_min_num_f64_e32 v[1:2], v[184:185], v[176:177]            ; 1a0361b8
	v_lshl_add_u32 v182, v182, 5, s67                           ; d64600b6 010d0bb6
(invalid instruction)                                        ; cc0f00ba
	v_min_num_f64_e32 v[1:2], v[170:171], v[174:175]            ; 1a035daa
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[179:180]            ; 1a0367b7
(invalid instruction)                                        ; cc0f00b9
	v_min_num_f64_e32 v[1:2], v[185:186], v[177:178]            ; 1a0363b9
(invalid instruction)                                        ; cc0f00b8
	v_min_num_f64_e32 v[1:2], v[184:185], v[180:181]            ; 1a0369b8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f00ba
	v_min_num_f64_e32 v[1:2], v[186:187], v[178:179]            ; 1a0365ba
(invalid instruction)                                        ; cc0f00b9
	v_min_num_f64_e32 v[1:2], v[185:186], v[181:182]            ; 1a036bb9
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[184:185]            ; 1a0371b7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f00ba
	v_min_num_f64_e32 v[1:2], v[186:187], v[182:183]            ; 1a036dba
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[185:186]            ; 1a0373b7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[186:187]            ; 1a0375b7
	v_permlanex16_b32 v187, v183, s61, s62 op_sel:[1,1]         ; d65c18bb 00f87bb7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00b7
	v_min_num_f64_e32 v[1:2], v[183:184], v[187:188]            ; 1a0377b7
(invalid instruction)                                        ; d53210bc
	v_cndmask_b32_e32 v1, v183, v183, vcc_lo                    ; 02036fb7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53100bc
	v_cndmask_b32_e32 v1, s60, v188, vcc_lo                     ; 0203783c
(invalid instruction)                                        ; d58b00bd
	v_cndmask_b32_e32 v0, v188, v128, vcc_lo                    ; 020101bc
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v189, v189                                    ; 7f7a55bd
	v_fma_mix_f32 v191, v168, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037ba8
	v_fma_mix_f32 v190, v167, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000be 8a037ba7
	v_fma_mix_f32 v167, v167, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a7 8a037ba7
	v_fma_mix_f32 v168, v168, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a8 8a037ba8
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c2
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v190, v167, vcc_lo                    ; 02034fbe
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v191, v168, vcc_lo                    ; 020351bf
	v_fma_mix_f32 v191, v169, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037ba9
	v_fma_mix_f32 v169, v169, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a037ba9
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v191, v169, vcc_lo                    ; 020353bf
	v_fma_mix_f32 v191, v170, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037baa
	v_fma_mix_f32 v170, v170, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008aa 8a037baa
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v191, v170, vcc_lo                    ; 020355bf
	v_fma_mix_f32 v191, v171, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037bab
	v_fma_mix_f32 v171, v171, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ab 8a037bab
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v191, v171, vcc_lo                    ; 020357bf
	v_fma_mix_f32 v191, v172, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037bac
	v_fma_mix_f32 v172, v172, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ac 8a037bac
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v191, v172, vcc_lo                    ; 020359bf
	v_fma_mix_f32 v191, v173, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037bad
	v_fma_mix_f32 v173, v173, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ad 8a037bad
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v191, v173, vcc_lo                    ; 02035bbf
	v_fma_mix_f32 v191, v174, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037bae
	v_fma_mix_f32 v174, v174, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ae 8a037bae
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v191, v174, vcc_lo                    ; 02035dbf
	v_fma_mix_f32 v191, v175, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037baf
	v_fma_mix_f32 v175, v175, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a037baf
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v191, v175, vcc_lo                    ; 02035fbf
	v_fma_mix_f32 v191, v176, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037bb0
	v_fma_mix_f32 v176, v176, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b0 8a037bb0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v191, v176, vcc_lo                    ; 020361bf
	v_fma_mix_f32 v191, v177, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037bb1
	v_fma_mix_f32 v177, v177, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a037bb1
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v191, v177, vcc_lo                    ; 020363bf
	v_fma_mix_f32 v191, v178, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037bb2
	v_fma_mix_f32 v178, v178, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a037bb2
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[22:23], 0 ; cc464060 1a022d26
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[22:23], 0 ; cc464068 1a022d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[22:23], 0 ; cc464070 1a022d32
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v191, v178, vcc_lo                    ; 020365bf
	v_fma_mix_f32 v191, v179, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037bb3
	v_fma_mix_f32 v179, v179, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a037bb3
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[22:23], 0 ; cc464078 1a022d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[36:37], v[96:103] ; cc464060 1d82492c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[36:37], v[104:111] ; cc464068 1da2492e
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v191, v179, vcc_lo                    ; 020367bf
	v_fma_mix_f32 v191, v180, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037bb4
	v_fma_mix_f32 v180, v180, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a037bb4
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[36:37], v[112:119] ; cc464070 1dc2490c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[52:53], v[36:37], v[120:127] ; cc464078 1de24934
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v12, s64, v98, v94                          ; cc21000c 057ac440
	v_fma_mixhi_f16 v12, s64, v99, v95                          ; cc22000c 057ec640
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v191, v180, vcc_lo                    ; 020369bf
	v_fma_mix_f32 v191, v181, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037bb5
	v_fma_mix_f32 v181, v181, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a037bb5
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v13, s64, v100, v128                        ; cc21000d 0602c840
	v_fma_mixhi_f16 v13, s64, v101, v129                        ; cc22000d 0606ca40
	v_fma_mixlo_f16 v14, s64, v102, v130                        ; cc21000e 060acc40
	v_fma_mixhi_f16 v14, s64, v103, v131                        ; cc22000e 060ece40
(invalid instruction)                                        ; cc1c000c
	v_subrev_f32_e32 v0, v12, v66                               ; 0a00850c
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v15, s64, v104, v32                         ; cc21000f 0482d040
	v_fma_mixhi_f16 v15, s64, v105, v33                         ; cc22000f 0486d240
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v191, v181, vcc_lo                    ; 02036bbf
	v_fma_mix_f32 v191, v182, v189, neg(0) op_sel_hi:[1,0,0]    ; cc2000bf 8a037bb6
	v_fma_mix_f32 v182, v182, v189, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a037bb6
	v_fma_mixlo_f16 v20, s64, v106, v34                         ; cc210014 048ad440
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v66                               ; 0a00850d
	v_fma_mixhi_f16 v20, s64, v107, v35                         ; cc220014 048ed640
(invalid instruction)                                        ; cc1c000e
	v_subrev_f32_e32 v0, v14, v66                               ; 0a00850e
(invalid instruction)                                        ; cc1b000c
	v_subrev_f32_e32 v0, v12, v65                               ; 0a00830c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v22, s64, v108, v84                         ; cc210016 0552d840
(invalid instruction)                                        ; cc1c000f
	v_subrev_f32_e32 v0, v15, v66                               ; 0a00850f
	v_fma_mixhi_f16 v22, s64, v109, v85                         ; cc220016 0556da40
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v191, v182, vcc_lo                    ; 02036dbf
	v_fma_mixlo_f16 v191, s64, v96, v92                         ; cc2100bf 0572c040
	v_fma_mixhi_f16 v191, s64, v97, v93                         ; cc2200bf 0576c240
	v_fma_mixlo_f16 v23, s64, v110, v86                         ; cc210017 055adc40
	v_fma_mixhi_f16 v23, s64, v111, v87                         ; cc220017 055ede40
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v65                               ; 0a00830d
(invalid instruction)                                        ; cc1c0014
	v_subrev_f32_e32 v0, v20, v66                               ; 0a008514
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v30, s64, v112, v40                         ; cc21001e 04a2e040
(invalid instruction)                                        ; cc1b000e
	v_subrev_f32_e32 v0, v14, v65                               ; 0a00830e
	v_fma_mixhi_f16 v30, s64, v113, v41                         ; cc22001e 04a6e240
(invalid instruction)                                        ; cc1b000f
	v_subrev_f32_e32 v0, v15, v65                               ; 0a00830f
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v66                               ; 0a008516
	v_fma_mixlo_f16 v31, s64, v114, v42                         ; cc21001f 04aae440
	v_fma_mixhi_f16 v31, s64, v115, v43                         ; cc22001f 04aee640
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v66                              ; 0a0085bf
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v32, s64, v116, v68                         ; cc210020 0512e840
	v_fma_mixhi_f16 v32, s64, v117, v69                         ; cc220020 0516ea40
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v66                               ; 0a008517
(invalid instruction)                                        ; cc1b0014
	v_subrev_f32_e32 v0, v20, v65                               ; 0a008314
	v_fma_mixlo_f16 v33, s64, v118, v70                         ; cc210021 051aec40
	v_fma_mixhi_f16 v33, s64, v119, v71                         ; cc220021 051eee40
(invalid instruction)                                        ; cc1c001e
	v_subrev_f32_e32 v0, v30, v66                               ; 0a00851e
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v65                               ; 0a008316
(invalid instruction)                                        ; cc1c001f
	v_subrev_f32_e32 v0, v31, v66                               ; 0a00851f
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v65                              ; 0a0083bf
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v66                               ; 0a008520
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v34, s64, v120, v60                         ; cc210022 04f2f040
	v_fma_mixhi_f16 v34, s64, v121, v61                         ; cc220022 04f6f240
(invalid instruction)                                        ; cc1b0017
	v_subrev_f32_e32 v0, v23, v65                               ; 0a008317
	v_fma_mixlo_f16 v35, s64, v122, v62                         ; cc210023 04faf440
	v_fma_mixhi_f16 v35, s64, v123, v63                         ; cc220023 04fef640
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v36, s64, v124, v72                         ; cc210024 0522f840
(invalid instruction)                                        ; cc1c0021
	v_subrev_f32_e32 v0, v33, v66                               ; 0a008521
	v_fma_mixhi_f16 v36, s64, v125, v73                         ; cc220024 0526fa40
(invalid instruction)                                        ; cc1b001e
	v_subrev_f32_e32 v0, v30, v65                               ; 0a00831e
(invalid instruction)                                        ; cc1b001f
	v_subrev_f32_e32 v0, v31, v65                               ; 0a00831f
	v_fma_mixlo_f16 v37, s64, v126, v74                         ; cc210025 052afc40
	v_fma_mixhi_f16 v37, s64, v127, v75                         ; cc220025 052efe40
(invalid instruction)                                        ; cc1b0020
	v_subrev_f32_e32 v0, v32, v65                               ; 0a008320
(invalid instruction)                                        ; cc1c0022
	v_subrev_f32_e32 v0, v34, v66                               ; 0a008522
	v_lshl_add_u32 v191, v191, 5, s67                           ; d64600bf 010d0bbf
	v_lshl_add_u32 v15, v15, 5, s67                             ; d646000f 010d0b0f
(invalid instruction)                                        ; cc1c0023
	v_subrev_f32_e32 v0, v35, v66                               ; 0a008523
(invalid instruction)                                        ; cc1b0021
	v_subrev_f32_e32 v0, v33, v65                               ; 0a008321
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v66                               ; 0a008524
	v_lshl_add_u32 v30, v30, 5, s67                             ; d646001e 010d0b1e
	v_lshl_add_u32 v12, v12, 5, s67                             ; d646000c 010d0b0c
	v_lshl_add_u32 v20, v20, 5, s67                             ; d6460014 010d0b14
(invalid instruction)                                        ; cc1c0025
	v_subrev_f32_e32 v0, v37, v66                               ; 0a008525
	v_lshl_add_u32 v31, v31, 5, s67                             ; d646001f 010d0b1f
(invalid instruction)                                        ; cc1b0022
	v_subrev_f32_e32 v0, v34, v65                               ; 0a008322
	v_lshl_add_u32 v13, v13, 5, s67                             ; d646000d 010d0b0d
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[191:192], v[15:16]              ; 1a021fbf
	v_lshl_add_u32 v22, v22, 5, s67                             ; d6460016 010d0b16
(invalid instruction)                                        ; cc1b0023
	v_subrev_f32_e32 v0, v35, v65                               ; 0a008323
(invalid instruction)                                        ; cc1b0024
	v_subrev_f32_e32 v0, v36, v65                               ; 0a008324
	v_lshl_add_u32 v32, v32, 5, s67                             ; d6460020 010d0b20
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[12:13], v[20:21]                ; 1a02290c
(invalid instruction)                                        ; cc1b0025
	v_subrev_f32_e32 v0, v37, v65                               ; 0a008325
	v_lshl_add_u32 v14, v14, 5, s67                             ; d646000e 010d0b0e
	v_lshl_add_u32 v23, v23, 5, s67                             ; d6460017 010d0b17
	v_lshl_add_u32 v34, v34, 5, s67                             ; d6460022 010d0b22
	v_lshl_add_u32 v33, v33, 5, s67                             ; d6460021 010d0b21
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[30:31]                ; 1a023d26
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[13:14], v[22:23]                ; 1a022d0d
	v_lshl_add_u32 v35, v35, 5, s67                             ; d6460023 010d0b23
	v_lshl_add_u32 v36, v36, 5, s67                             ; d6460024 010d0b24
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[31:32]                ; 1a023f27
	v_lshl_add_u32 v37, v37, 5, s67                             ; d6460025 010d0b25
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[14:15], v[23:24]                ; 1a022f0e
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[34:35]                ; 1a024526
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[40:41], v[32:33]                ; 1a024128
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[35:36]                ; 1a024727
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[41:42], v[33:34]                ; 1a024329
(invalid instruction)                                        ; cc0f0028
	v_min_num_f64_e32 v[1:2], v[40:41], v[36:37]                ; 1a024928
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[39:40]                ; 1a024f26
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[41:42], v[37:38]                ; 1a024b29
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[40:41]                ; 1a025126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[41:42]                ; 1a025326
	v_permlanex16_b32 v42, v38, s61, s62 op_sel:[1,1]           ; d65c182a 00f87b26
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0026
	v_min_num_f64_e32 v[1:2], v[38:39], v[42:43]                ; 1a025526
	v_add_f16_e32 v43, v38, v166/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64574d26
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v43, s60, v43                             ; 6256563c
	v_cvt_f32_f16_e32 v44, v43                                  ; 7e58172b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v44, v44                                      ; 7e58552c
	v_fma_mix_f32 v46, v12, v44, neg(0) op_sel_hi:[1,0,0]       ; cc20002e 8a02590c
	v_fma_mix_f32 v50, v15, v44, neg(0) op_sel_hi:[1,0,0]       ; cc200032 8a02590f
	v_fma_mix_f32 v51, v20, v44, neg(0) op_sel_hi:[1,0,0]       ; cc200033 8a025914
	v_fma_mix_f32 v15, v15, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080f 8a02590f
	v_fma_mix_f32 v12, v12, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080c 8a02590c
	v_fma_mix_f32 v45, v191, v44, neg(0) op_sel_hi:[1,0,0]      ; cc20002d 8a0259bf
	v_fma_mix_f32 v191, v191, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a0259bf
	v_fma_mix_f32 v49, v14, v44, neg(0) op_sel_hi:[1,0,0]       ; cc200031 8a02590e
	buffer_load_b128 v[40:43], v54, s[32:35], null offen        ; c405c07c 40804028 00000036
	v_fma_mix_f32 v14, v14, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080e 8a02590e
	v_fma_mix_f32 v47, v13, v44, neg(0) op_sel_hi:[1,0,0]       ; cc20002f 8a02590d
	v_fma_mix_f32 v13, v13, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080d 8a02590d
	v_fma_mix_f32 v20, v20, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200814 8a025914
	v_fma_mix_f32 v52, v22, v44, neg(0) op_sel_hi:[1,0,0]       ; cc200034 8a025916
	v_fma_mix_f32 v22, v22, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200816 8a025916
	v_fma_mix_f32 v53, v23, v44, neg(0) op_sel_hi:[1,0,0]       ; cc200035 8a025917
	v_fma_mix_f32 v23, v23, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200817 8a025917
	v_fma_mix_f32 v60, v30, v44, neg(0) op_sel_hi:[1,0,0]       ; cc20003c 8a02591e
	v_fma_mix_f32 v30, v30, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081e 8a02591e
	v_fma_mix_f32 v61, v31, v44, neg(0) op_sel_hi:[1,0,0]       ; cc20003d 8a02591f
	v_fma_mix_f32 v31, v31, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081f 8a02591f
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v47, v13, vcc_lo                      ; 02021b2f
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v49, v14, vcc_lo                      ; 02021d31
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v60, v30, vcc_lo                      ; 02023d3c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v61, v31, vcc_lo                      ; 02023f3d
	buffer_load_b128 v[60:63], v54, s[32:35], null offen offset:16 ; c405c07c 4080403c 00001036
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v45, v191, vcc_lo                     ; 02037f2d
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v46, v12, vcc_lo                      ; 0202192e
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v50, v15, vcc_lo                      ; 02021f32
	v_mad_u32_u24 v73, s59, 0xc00, v2                           ; d60b0049 0409fe3b 00000c00
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v51, v20, vcc_lo                      ; 02022933
	v_lshl_add_u32 v3, v3, 7, v4                                ; d6460003 04110f03
	v_fma_mix_f32 v64, v32, v44, neg(0) op_sel_hi:[1,0,0]       ; cc200040 8a025920
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v52, v22, vcc_lo                      ; 02022d34
	v_fma_mix_f32 v32, v32, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a025920
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v53, v23, vcc_lo                      ; 02022f35
	v_fma_mix_f32 v68, v33, v44, neg(0) op_sel_hi:[1,0,0]       ; cc200044 8a025921
	v_fma_mix_f32 v33, v33, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200821 8a025921
	v_fma_mix_f32 v69, v34, v44, neg(0) op_sel_hi:[1,0,0]       ; cc200045 8a025922
	v_fma_mix_f32 v34, v34, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200822 8a025922
	v_fma_mix_f32 v70, v35, v44, neg(0) op_sel_hi:[1,0,0]       ; cc200046 8a025923
	v_fma_mix_f32 v35, v35, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200823 8a025923
	v_fma_mix_f32 v71, v36, v44, neg(0) op_sel_hi:[1,0,0]       ; cc200047 8a025924
	v_fma_mix_f32 v36, v36, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200824 8a025924
	v_fma_mix_f32 v72, v37, v44, neg(0) op_sel_hi:[1,0,0]       ; cc200048 8a025925
	v_fma_mix_f32 v37, v37, v44, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200825 8a025925
	v_add_nc_u32_e32 v73, v73, v3                               ; 4a920749
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v64, v32, vcc_lo                      ; 02024140
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v68, v33, vcc_lo                      ; 02024344
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v69, v34, vcc_lo                      ; 02024545
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v70, v35, vcc_lo                      ; 02024746
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v71, v36, vcc_lo                      ; 02024947
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v72, v37, vcc_lo                      ; 02024b48
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_load_u8_d16 v30, v73 offset:4096                         ; da881000 1e000049
	ds_load_u8_d16 v74, v73 offset:4112                         ; da881010 4a000049
	ds_load_u8_d16_hi v32, v73 offset:4128                      ; da8c1020 20000049
	ds_load_u8_d16 v75, v73 offset:4144                         ; da881030 4b000049
	ds_load_u8_d16 v31, v73 offset:4160                         ; da881040 1f000049
	ds_load_u8_d16 v84, v73 offset:4176                         ; da881050 54000049
	ds_load_u8_d16_hi v33, v73 offset:4192                      ; da8c1060 21000049
	ds_load_u8_d16 v85, v73 offset:4208                         ; da881070 55000049
	ds_load_u8_d16 v34, v73 offset:5120                         ; da881400 22000049
	ds_load_u8_d16 v86, v73 offset:5136                         ; da881410 56000049
	ds_load_u8_d16_hi v36, v73 offset:5152                      ; da8c1420 24000049
	ds_load_u8_d16 v87, v73 offset:5168                         ; da881430 57000049
	ds_load_u8_d16 v35, v73 offset:5184                         ; da881440 23000049
	ds_load_u8_d16 v88, v73 offset:5200                         ; da881450 58000049
	ds_load_u8_d16_hi v37, v73 offset:5216                      ; da8c1460 25000049
	ds_load_u8_d16 v89, v73 offset:5232                         ; da881470 59000049
	ds_load_u8_d16 v44, v73 offset:6144                         ; da881800 2c000049
	ds_load_u8_d16 v90, v73 offset:6160                         ; da881810 5a000049
	ds_load_u8_d16_hi v46, v73 offset:6176                      ; da8c1820 2e000049
	ds_load_u8_d16 v91, v73 offset:6192                         ; da881830 5b000049
	ds_load_u8_d16 v45, v73 offset:6208                         ; da881840 2d000049
	ds_load_u8_d16 v92, v73 offset:6224                         ; da881850 5c000049
	ds_load_u8_d16_hi v47, v73 offset:6240                      ; da8c1860 2f000049
	ds_load_u8_d16 v93, v73 offset:6256                         ; da881870 5d000049
	ds_load_u8_d16 v50, v73 offset:7168                         ; da881c00 32000049
	ds_load_u8_d16 v94, v73 offset:7184                         ; da881c10 5e000049
	ds_load_u8_d16_hi v52, v73 offset:7200                      ; da8c1c20 34000049
	ds_load_u8_d16 v95, v73 offset:7216                         ; da881c30 5f000049
	ds_load_u8_d16 v51, v73 offset:7232                         ; da881c40 33000049
	ds_load_u8_d16 v96, v73 offset:7248                         ; da881c50 60000049
	ds_load_u8_d16_hi v53, v73 offset:7264                      ; da8c1c60 35000049
	ds_load_u8_d16 v97, v73 offset:7280                         ; da881c70 61000049
	s_wait_dscnt 0x1e                                           ; bfc6001e
	v_perm_b32 v30, v30, v74, 0x7060004                         ; d644001e 03fe951e 07060004
	s_wait_dscnt 0x1a                                           ; bfc6001a
	v_perm_b32 v31, v31, v84, 0x7060004                         ; d644001f 03fea91f 07060004
	s_wait_dscnt 0x16                                           ; bfc60016
	v_perm_b32 v34, v34, v86, 0x7060004                         ; d6440022 03fead22 07060004
	s_wait_dscnt 0x12                                           ; bfc60012
	v_perm_b32 v35, v35, v88, 0x7060004                         ; d6440023 03feb123 07060004
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_perm_b32 v30, v30, v32, 0x7020504                         ; d644001e 03fe411e 07020504
	v_perm_b32 v31, v31, v33, 0x7020504                         ; d644001f 03fe431f 07020504
	v_perm_b32 v34, v34, v36, 0x7020504                         ; d6440022 03fe4922 07020504
	s_wait_dscnt 0x11                                           ; bfc60011
	v_perm_b32 v35, v35, v37, 0x7020504                         ; d6440023 03fe4b23 07020504
	v_perm_b32 v30, v30, v75, 0x60504                           ; d644001e 03fe971e 00060504
	v_perm_b32 v31, v31, v85, 0x60504                           ; d644001f 03feab1f 00060504
	v_perm_b32 v34, v34, v87, 0x60504                           ; d6440022 03feaf22 00060504
	s_wait_dscnt 0x10                                           ; bfc60010
	v_perm_b32 v35, v35, v89, 0x60504                           ; d6440023 03feb323 00060504
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[10:11], 0 ; cc464068 1a02151e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[16:17], 0 ; cc464078 1a02211e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[8:9], 0 ; cc464070 1a02111e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[38:39], 0 ; cc464080 1a024d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[34:35], v[24:25], v[104:111] ; cc464068 1da23122
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[18:19], v[120:127] ; cc464078 1de22522
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[26:27], v[112:119] ; cc464070 1dc23522
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[12:13], v[128:135] ; cc464080 1e021922
	buffer_load_b128 v[32:35], v54, s[32:35], null offen offset:64 ; c405c07c 40804020 00004036
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_perm_b32 v44, v44, v90, 0x7060004                         ; d644002c 03feb52c 07060004
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_perm_b32 v45, v45, v92, 0x7060004                         ; d644002d 03feb92d 07060004
	s_wait_dscnt 0x6                                            ; bfc60006
	v_perm_b32 v50, v50, v94, 0x7060004                         ; d6440032 03febd32 07060004
	s_wait_dscnt 0x2                                            ; bfc60002
	v_perm_b32 v51, v51, v96, 0x7060004                         ; d6440033 03fec133 07060004
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_perm_b32 v44, v44, v46, 0x7020504                         ; d644002c 03fe5d2c 07020504
	v_perm_b32 v45, v45, v47, 0x7020504                         ; d644002d 03fe5f2d 07020504
	v_perm_b32 v44, v44, v91, 0x60504                           ; d644002c 03feb72c 00060504
	v_perm_b32 v45, v45, v93, 0x60504                           ; d644002d 03febb2d 00060504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[76:77], v[112:119] ; cc464070 1dc2992c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[80:81], v[120:127] ; cc464078 1de2a12c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[56:57], v[104:111] ; cc464068 1da2712c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[44:45], v[14:15], v[128:135] ; cc464080 1e021d2c
	buffer_load_b128 v[44:47], v54, s[32:35], null offen offset:80 ; c405c07c 4080402c 00005036
	v_perm_b32 v50, v50, v52, 0x7020504                         ; d6440032 03fe6932 07020504
	s_wait_dscnt 0x1                                            ; bfc60001
	v_perm_b32 v51, v51, v53, 0x7020504                         ; d6440033 03fe6b33 07020504
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
	v_perm_b32 v50, v50, v95, 0x60504                           ; d6440032 03febf32 00060504
	s_wait_dscnt 0x0                                            ; bfc60000
	v_perm_b32 v51, v51, v97, 0x60504                           ; d6440033 03fec333 00060504
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[78:79], v[112:119] ; cc464070 1dc29d32
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[22:23], v[128:135] ; cc464080 1e022d32
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[82:83], v[120:127] ; cc464078 1de2a532
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[50:51], v[58:59], v[104:111] ; cc464068 1da27532
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	ds_store_2addr_stride64_b64 v65, v[30:31], v[36:37] offset0:8 offset1:10 ; d93c0a08 00241e41
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	ds_store_2addr_stride64_b64 v65, v[30:31], v[36:37] offset0:12 offset1:14 ; d93c0e0c 00241e41
	ds_load_u8_d16 v30, v73 offset:4352                         ; da881100 1e000049
	ds_load_u8_d16 v98, v73 offset:4368                         ; da881110 62000049
	ds_load_u8_d16_hi v36, v73 offset:4384                      ; da8c1120 24000049
	ds_load_u8_d16 v99, v73 offset:4400                         ; da881130 63000049
	ds_load_u8_d16 v31, v73 offset:4416                         ; da881140 1f000049
	ds_load_u8_d16 v100, v73 offset:4432                        ; da881150 64000049
	ds_load_u8_d16_hi v37, v73 offset:4448                      ; da8c1160 25000049
	ds_load_u8_d16 v101, v73 offset:4464                        ; da881170 65000049
	ds_load_u8_d16 v50, v73 offset:5376                         ; da881500 32000049
	ds_load_u8_d16 v102, v73 offset:5392                        ; da881510 66000049
	ds_load_u8_d16_hi v52, v73 offset:5408                      ; da8c1520 34000049
	ds_load_u8_d16 v103, v73 offset:5424                        ; da881530 67000049
	ds_load_u8_d16 v51, v73 offset:5440                         ; da881540 33000049
	ds_load_u8_d16 v104, v73 offset:5456                        ; da881550 68000049
	ds_load_u8_d16_hi v53, v73 offset:5472                      ; da8c1560 35000049
	ds_load_u8_d16 v105, v73 offset:5488                        ; da881570 69000049
	ds_load_u8_d16 v64, v73 offset:6400                         ; da881900 40000049
	ds_load_u8_d16 v106, v73 offset:6416                        ; da881910 6a000049
	ds_load_u8_d16_hi v68, v73 offset:6432                      ; da8c1920 44000049
	ds_load_u8_d16 v107, v73 offset:6448                        ; da881930 6b000049
	ds_load_u8_d16 v65, v73 offset:6464                         ; da881940 41000049
	ds_load_u8_d16 v108, v73 offset:6480                        ; da881950 6c000049
	ds_load_u8_d16_hi v69, v73 offset:6496                      ; da8c1960 45000049
	ds_load_u8_d16 v109, v73 offset:6512                        ; da881970 6d000049
	ds_load_u8_d16 v70, v73 offset:7424                         ; da881d00 46000049
	ds_load_u8_d16 v110, v73 offset:7440                        ; da881d10 6e000049
	ds_load_u8_d16_hi v74, v73 offset:7456                      ; da8c1d20 4a000049
	ds_load_u8_d16 v111, v73 offset:7472                        ; da881d30 6f000049
	ds_load_u8_d16 v71, v73 offset:7488                         ; da881d40 47000049
	ds_load_u8_d16 v112, v73 offset:7504                        ; da881d50 70000049
	ds_load_u8_d16_hi v75, v73 offset:7520                      ; da8c1d60 4b000049
	ds_load_u8_d16 v113, v73 offset:7536                        ; da881d70 71000049
	s_lshr_b32 s7, s7, 2                                        ; 85078207
	s_wait_dscnt 0x1e                                           ; bfc6001e
	v_perm_b32 v30, v30, v98, 0x7060004                         ; d644001e 03fec51e 07060004
	s_wait_dscnt 0x1a                                           ; bfc6001a
	v_perm_b32 v31, v31, v100, 0x7060004                        ; d644001f 03fec91f 07060004
	s_wait_dscnt 0x16                                           ; bfc60016
	v_perm_b32 v50, v50, v102, 0x7060004                        ; d6440032 03fecd32 07060004
	s_wait_dscnt 0x12                                           ; bfc60012
	v_perm_b32 v51, v51, v104, 0x7060004                        ; d6440033 03fed133 07060004
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v7, v7, s7, v2                                   ; d6550007 04080f07
	v_perm_b32 v30, v30, v36, 0x7020504                         ; d644001e 03fe491e 07020504
	v_perm_b32 v31, v31, v37, 0x7020504                         ; d644001f 03fe4b1f 07020504
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
	v_lshlrev_b32_e32 v7, 2, v7                                 ; 300e0e82
	v_perm_b32 v30, v30, v99, 0x60504                           ; d644001e 03fec71e 00060504
	v_perm_b32 v31, v31, v101, 0x60504                          ; d644001f 03fecb1f 00060504
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[8:9], 0 ; cc464078 1a02111e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[30:31], v[10:11], 0 ; cc464058 1a02151e
	buffer_load_b128 v[8:11], v7, s[36:39], null offen          ; c405c07c 40804808 00000007
	v_perm_b32 v50, v50, v52, 0x7020504                         ; d6440032 03fe6932 07020504
	s_wait_dscnt 0x11                                           ; bfc60011
	v_perm_b32 v51, v51, v53, 0x7020504                         ; d6440033 03fe6b33 07020504
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_perm_b32 v64, v64, v106, 0x7060004                        ; d6440040 03fed540 07060004
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[30:31], v[16:17], 0 ; cc464080 1a02211e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[30:31], v[38:39], 0 ; cc464088 1a024d1e
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_perm_b32 v65, v65, v108, 0x7060004                        ; d6440041 03fed941 07060004
	v_perm_b32 v50, v50, v103, 0x60504                          ; d6440032 03fecf32 00060504
	v_perm_b32 v51, v51, v105, 0x60504                          ; d6440033 03fed333 00060504
	v_perm_b32 v64, v64, v68, 0x7020504                         ; d6440040 03fe8940 07020504
	s_wait_dscnt 0x6                                            ; bfc60006
	v_perm_b32 v70, v70, v110, 0x7060004                        ; d6440046 03fedd46 07060004
	s_wait_dscnt 0x2                                            ; bfc60002
	v_perm_b32 v71, v71, v112, 0x7060004                        ; d6440047 03fee147 07060004
	v_perm_b32 v65, v65, v69, 0x7020504                         ; d6440041 03fe8b41 07020504
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[26:27], v[120:127] ; cc464078 1de23532
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[50:51], v[24:25], v[88:95] ; cc464058 1d623132
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[18:19], v[128:135] ; cc464080 1e022532
	v_perm_b32 v64, v64, v107, 0x60504                          ; d6440040 03fed740 00060504
	v_perm_b32 v70, v70, v74, 0x7020504                         ; d6440046 03fe9546 07020504
	s_wait_dscnt 0x1                                            ; bfc60001
	v_perm_b32 v71, v71, v75, 0x7020504                         ; d6440047 03fe9747 07020504
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[50:51], v[12:13], v[136:143] ; cc464088 1e221932
	v_perm_b32 v65, v65, v109, 0x60504                          ; d6440041 03fedb41 00060504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[76:77], v[120:127] ; cc464078 1de29940
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[56:57], v[88:95] ; cc464058 1d627140
	v_perm_b32 v70, v70, v111, 0x60504                          ; d6440046 03fedf46 00060504
	buffer_load_b128 v[16:19], v7, s[36:39], null offen offset:512 ; c405c07c 40804810 00020007
	s_wait_dscnt 0x0                                            ; bfc60000
	v_perm_b32 v71, v71, v113, 0x60504                          ; d6440047 03fee347 00060504
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[64:65], v[80:81], v[128:135] ; cc464080 1e02a140
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[64:65], v[14:15], v[136:143] ; cc464088 1e221d40
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[78:79], v[120:127] ; cc464078 1de29d46
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[70:71], v[58:59], v[88:95] ; cc464058 1d627546
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[82:83], v[128:135] ; cc464080 1e02a546
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[22:23], v[136:143] ; cc464088 1e222d46
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	ds_store_2addr_b64 v21, v[12:13], v[14:15] offset0:32 offset1:160 ; d938a020 000e0c15
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	ds_store_2addr_b64 v28, v[12:13], v[14:15] offset0:32 offset1:160 ; d938a020 000e0c1c
	buffer_load_b128 v[12:15], v7, s[36:39], null offen offset:1024 ; c405c07c 4080480c 00040007
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[20:21], v29                                   ; d9d80000 1400001d
	ds_load_b64 v[22:23], v29 offset:1024                       ; d9d80400 1600001d
	ds_load_b64 v[24:25], v29 offset:2048                       ; d9d80800 1800001d
	buffer_load_b128 v[36:39], v7, s[36:39], null offen offset:1536 ; c405c07c 40804824 00060007
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[26:27], v20                          ; 7e34dd14
	s_wait_loadcnt 0x7                                          ; bfc00007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v73, v27, v41 :: v_dual_mul_f32 v72, v26, v40 ; c8c6531b 4948511a
	v_cvt_pk_f32_fp8_e32 v[26:27], v148                         ; 7e34dd94
	v_dual_mul_f32 v75, v27, v43 :: v_dual_mul_f32 v74, v26, v42 ; c8c6571b 4b4a551a
	v_cvt_pk_f32_fp8_e32 v[26:27], v21                          ; 7e34dd15
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
	v_dual_mul_f32 v77, v27, v61 :: v_dual_mul_f32 v76, v26, v60 ; c8c67b1b 4d4c791a
	ds_load_b64 v[26:27], v29 offset:3072                       ; d9d80c00 1a00001d
	ds_load_b64 v[30:31], v29 offset:256                        ; d9d80100 1e00001d
	v_cvt_pk_f32_fp8_e32 v[20:21], v149                         ; 7e28dd95
	v_dual_mul_f32 v79, v21, v63 :: v_dual_mul_f32 v78, v20, v62 ; c8c67f15 4f4e7d14
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[20:21], v22                          ; 7e28dd16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v81, v21, v41 :: v_dual_mul_f32 v80, v20, v40 ; c8c65315 51505114
	v_cvt_pk_f32_fp8_e32 v[20:21], v150                         ; 7e28dd96
	v_dual_mul_f32 v83, v21, v43 :: v_dual_mul_f32 v82, v20, v42 ; c8c65715 53525514
	v_cvt_pk_f32_fp8_e32 v[20:21], v23                          ; 7e28dd17
	v_cvt_pk_f32_fp8_e32 v[22:23], v151                         ; 7e2cdd97
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
	v_dual_mul_f32 v85, v21, v61 :: v_dual_mul_f32 v84, v20, v60 ; c8c67b15 55547914
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[20:21], v24                          ; 7e28dd18
	v_dual_mul_f32 v89, v21, v41 :: v_dual_mul_f32 v88, v20, v40 ; c8c65315 59585114
	v_cvt_pk_f32_fp8_e32 v[20:21], v152                         ; 7e28dd98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v91, v21, v43 :: v_dual_mul_f32 v90, v20, v42 ; c8c65715 5b5a5514
	v_cvt_pk_f32_fp8_e32 v[20:21], v25                          ; 7e28dd19
	v_mul_f32_e32 v92, v20, v60                                 ; 10b87914
	v_dual_mul_f32 v86, v22, v62 :: v_dual_mul_f32 v93, v21, v61 ; c8c67d16 565c7b15
	v_cvt_pk_f32_fp8_e32 v[20:21], v153                         ; 7e28dd99
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v94, v20, v62 :: v_dual_mul_f32 v95, v21, v63 ; c8c67d14 5e5e7f15
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[20:21], v26                          ; 7e28dd1a
	v_dual_mul_f32 v96, v20, v40 :: v_dual_mul_f32 v87, v23, v63 ; c8c65114 60567f17
	ds_load_b64 v[22:23], v29 offset:1280                       ; d9d80500 1600001d
	ds_load_b64 v[24:25], v29 offset:2304                       ; d9d80900 1800001d
	v_mul_f32_e32 v97, v21, v41                                 ; 10c25315
	v_cvt_pk_f32_fp8_e32 v[20:21], v154                         ; 7e28dd9a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v99, v21, v43 :: v_dual_mul_f32 v98, v20, v42 ; c8c65715 63625514
	v_cvt_pk_f32_fp8_e32 v[20:21], v27                          ; 7e28dd1b
	v_dual_mul_f32 v101, v21, v61 :: v_dual_mul_f32 v100, v20, v60 ; c8c67b15 65647914
	v_cvt_pk_f32_fp8_e32 v[20:21], v155                         ; 7e28dd9b
	ds_load_b64 v[26:27], v29 offset:3328                       ; d9d80d00 1a00001d
	v_dual_mul_f32 v103, v21, v63 :: v_dual_mul_f32 v102, v20, v62 ; c8c67f15 67667d14
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[20:21], v30                          ; 7e28dd1e
	s_wait_loadcnt 0x5                                          ; bfc00005
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v57, v21, v33 :: v_dual_mul_f32 v56, v20, v32 ; c8c64315 39384114
	v_cvt_pk_f32_fp8_e32 v[20:21], v158                         ; 7e28dd9e
	v_dual_mul_f32 v59, v21, v35 :: v_dual_mul_f32 v58, v20, v34 ; c8c64715 3b3a4514
	v_cvt_pk_f32_fp8_e32 v[20:21], v31                          ; 7e28dd1f
	s_wait_loadcnt 0x4                                          ; bfc00004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v61, v21, v45 :: v_dual_mul_f32 v60, v20, v44 ; c8c65b15 3d3c5914
	v_cvt_pk_f32_fp8_e32 v[20:21], v159                         ; 7e28dd9f
	v_dual_mul_f32 v63, v21, v47 :: v_dual_mul_f32 v62, v20, v46 ; c8c65f15 3f3e5d14
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[20:21], v22                          ; 7e28dd16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v105, v21, v33 :: v_dual_mul_f32 v104, v20, v32 ; c8c64315 69684114
	v_cvt_pk_f32_fp8_e32 v[20:21], v150                         ; 7e28dd96
	v_dual_mul_f32 v107, v21, v35 :: v_dual_mul_f32 v106, v20, v34 ; c8c64715 6b6a4514
	v_cvt_pk_f32_fp8_e32 v[20:21], v23                          ; 7e28dd17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v109, v21, v45 :: v_dual_mul_f32 v108, v20, v44 ; c8c65b15 6d6c5914
	v_cvt_pk_f32_fp8_e32 v[20:21], v151                         ; 7e28dd97
	v_dual_mul_f32 v111, v21, v47 :: v_dual_mul_f32 v110, v20, v46 ; c8c65f15 6f6e5d14
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[20:21], v24                          ; 7e28dd18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v21, v33 :: v_dual_mul_f32 v112, v20, v32 ; c8c64315 71704114
	v_cvt_pk_f32_fp8_e32 v[20:21], v152                         ; 7e28dd98
	v_dual_mul_f32 v115, v21, v35 :: v_dual_mul_f32 v114, v20, v34 ; c8c64715 73724514
	v_cvt_pk_f32_fp8_e32 v[20:21], v25                          ; 7e28dd19
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v117, v21, v45 :: v_dual_mul_f32 v116, v20, v44 ; c8c65b15 75745914
	v_cvt_pk_f32_fp8_e32 v[20:21], v153                         ; 7e28dd99
	ds_load_b64 v[22:23], v48 offset:4096                       ; d9d81000 16000030
	ds_load_b64 v[28:29], v48 offset:5120                       ; d9d81400 1c000030
	ds_load_b64 v[30:31], v48 offset:6144                       ; d9d81800 1e000030
	ds_load_b64 v[40:41], v48 offset:7168                       ; d9d81c00 28000030
	ds_load_b64 v[24:25], v48 offset:4352                       ; d9d81100 18000030
	ds_load_b64 v[42:43], v48 offset:5376                       ; d9d81500 2a000030
	ds_load_b64 v[50:51], v48 offset:6400                       ; d9d81900 32000030
	ds_load_b64 v[52:53], v48 offset:7424                       ; d9d81d00 34000030
	v_dual_mul_f32 v119, v21, v47 :: v_dual_mul_f32 v118, v20, v46 ; c8c65f15 77765d14
	s_wait_dscnt 0x8                                            ; bfc60008
	v_cvt_pk_f32_fp8_e32 v[20:21], v26                          ; 7e28dd1a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v121, v21, v33                                ; 10f24315
	v_mul_f32_e32 v120, v20, v32                                ; 10f04114
	v_cvt_pk_f32_fp8_e32 v[20:21], v154                         ; 7e28dd9a
	s_wait_loadcnt_dscnt 0x307                                  ; bfc80307
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[8:9], v[22:23], v[72:79] ; cc464048 1d222d08
	v_dual_mul_f32 v123, v21, v35 :: v_dual_mul_f32 v122, v20, v34 ; c8c64715 7b7a4514
	v_cvt_pk_f32_fp8_e32 v[20:21], v27                          ; 7e28dd1b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v125, v21, v45 :: v_dual_mul_f32 v124, v20, v44 ; c8c65b15 7d7c5914
	v_cvt_pk_f32_fp8_e32 v[20:21], v155                         ; 7e28dd9b
	v_dual_mul_f32 v127, v21, v47 :: v_dual_mul_f32 v126, v20, v46 ; c8c65f15 7f7e5d14
	ds_load_b64 v[26:27], v48 offset:4608                       ; d9d81200 1a000030
	ds_load_b64 v[32:33], v48 offset:5632                       ; d9d81600 20000030
	ds_load_b64 v[34:35], v48 offset:6656                       ; d9d81a00 22000030
	ds_load_b64 v[44:45], v48 offset:7680                       ; d9d81e00 2c000030
	ds_load_b64 v[20:21], v48 offset:4864                       ; d9d81300 14000030
	ds_load_b64 v[46:47], v48 offset:5888                       ; d9d81700 2e000030
	ds_load_b64 v[64:65], v48 offset:6912                       ; d9d81b00 40000030
	ds_load_b64 v[48:49], v48 offset:7936                       ; d9d81f00 30000030
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[8:9], v[28:29], v[80:87] ; cc464050 1d423908
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[30:31], v[88:95] ; cc464058 1d623d08
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[40:41], v[96:103] ; cc464060 1d825108
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[10:11], v[22:23], v[56:63] ; cc464038 1ce22d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[28:29], v[104:111] ; cc464068 1da2390a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[30:31], v[112:119] ; cc464070 1dc23d0a
	s_wait_loadcnt_dscnt 0x20b                                  ; bfc8020b
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[16:17], v[24:25], v[72:79] ; cc464048 1d223110
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[40:41], v[120:127] ; cc464078 1de2510a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[42:43], v[80:87] ; cc464050 1d425510
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[50:51], v[88:95] ; cc464058 1d626510
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[16:17], v[52:53], v[96:103] ; cc464060 1d826910
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[18:19], v[24:25], v[56:63] ; cc464038 1ce23112
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[18:19], v[42:43], v[104:111] ; cc464068 1da25512
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[50:51], v[112:119] ; cc464070 1dc26512
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[12:13], v[26:27], v[72:79] ; cc464048 1d22350c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[52:53], v[120:127] ; cc464078 1de26912
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[12:13], v[32:33], v[80:87] ; cc464050 1d42410c
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[34:35], v[88:95] ; cc464058 1d62450c
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[44:45], v[96:103] ; cc464060 1d82590c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[14:15], v[26:27], v[56:63] ; cc464038 1ce2350e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[32:33], v[104:111] ; cc464068 1da2410e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[34:35], v[112:119] ; cc464070 1dc2450e
	s_wait_loadcnt_dscnt 0x3                                    ; bfc80003
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[36:37], v[20:21], v[72:79] ; cc464048 1d222924
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[44:45], v[120:127] ; cc464078 1de2590e
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[46:47], v[80:87] ; cc464050 1d425d24
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[64:65], v[88:95] ; cc464058 1d628124
	s_cmp_ge_i32 s45, 0                                         ; bf03802d
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[48:49], v[96:103] ; cc464060 1d826124
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[38:39], v[20:21], v[56:63] ; cc464038 1ce22926
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[46:47], v[104:111] ; cc464068 1da25d26
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[64:65], v[112:119] ; cc464070 1dc28126
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[38:39], v[48:49], v[120:127] ; cc464078 1de26126
	s_cselect_b32 s68, -1, 0                                    ; 984480c1
	s_cbranch_scc0 BB2                                          ; bfa10009
BB1:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s24, s0                                        ; bf040018
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00002
BB2:
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB5                                          ; bfa10008
BB4:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s17, s0                                        ; bf040011
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB6                                                ; bfa00001
BB5:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB6:
	v_lshlrev_b32_e32 v1, 1, v1                                 ; 30020281
	v_and_b32_e32 v0, 1, v0                                     ; 36000081
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_cndmask_b32_e64 v3, v72, v76, s0                          ; d5010003 00029948
	v_cndmask_b32_e64 v76, v76, v72, s0                         ; d501004c 0002914c
	v_cndmask_b32_e64 v4, v73, v77, s0                          ; d5010004 00029b49
	v_cndmask_b32_e64 v77, v77, v73, s0                         ; d501004d 0002934d
	v_cndmask_b32_e64 v7, v74, v78, s0                          ; d5010007 00029d4a
	v_cndmask_b32_e64 v78, v78, v74, s0                         ; d501004e 0002954e
	v_cndmask_b32_e64 v10, v75, v79, s0                         ; d501000a 00029f4b
	v_cndmask_b32_e64 v79, v79, v75, s0                         ; d501004f 0002974f
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v76, v76, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069806fa ff0cb14c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	v_add_f32_dpp v77, v77, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069a08fa ff0cb14d
	v_add_f32_dpp v78, v78, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069c0efa ff0cb14e
	v_add_f32_dpp v79, v79, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069e14fa ff0cb14f
	v_cvt_f16_f32_e32 v13, v76                                  ; 7e1a154c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_cvt_f16_f32_e32 v14, v77                                  ; 7e1c154d
	v_cvt_f16_f32_e32 v11, v78                                  ; 7e16154e
	v_cndmask_b32_e64 v78, v78, v76, s2                         ; d501004e 000a994e
	v_cvt_f16_f32_e32 v12, v79                                  ; 7e18154f
	v_cndmask_b32_e64 v79, v79, v77, s2                         ; d501004f 000a9b4f
	v_cndmask_b32_e64 v15, v13, v11, s2                         ; d501000f 000a170d
	v_cvt_f16_f32_dpp v16, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d644e
	v_cndmask_b16 v15, v14, v12, s2                             ; d65d400f 000a190e
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d644f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB9                                          ; bfa1003a
BB7:
	s_load_b64 s[4:5], s[10:11], 0x44                           ; f4002105 f8000044
	s_ashr_i32 s0, s17, 1                                       ; 86008111
	s_ashr_i32 s2, s24, 1                                       ; 86028118
	v_bfe_u32 v3, v66, 1, 1                                     ; d6100003 02050342
	v_bfe_u32 v4, v66, 3, 1                                     ; d6100004 02050742
	s_and_b32 s6, s15, 1                                        ; 8b06810f
	v_fma_mix_f32 v7, 0, v15, neg(0) op_sel_hi:[0,1,0]          ; cc200007 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100f 92021eff 3e800000
	v_bfe_u32 v11, v66, 2, 1                                    ; d610000b 02050542
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s6, s6, 5                                        ; 84068506
	s_and_b32 s7, s16, 1                                        ; 8b078110
	v_lshl_add_u32 v4, v4, 2, v3                                ; d6460004 040d0504
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v7, v15, vcc_lo                       ; 02021f07
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s7, s7, 7                                        ; 84078707
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v4, v4, 4, v55                               ; d6460004 04dd0904
	v_perm_b32 v13, v13, v10, 0x7060501                         ; d644000d 03fe150d 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s5                                        ; 96000500
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s2                                     ; 80000200
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v12, s0, 2, v1                               ; d646000c 04050400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v12, v12, 8, s4                              ; d646000c 0011110c
	v_add3_u32 v12, v12, s7, s6                                 ; d655000c 00180f0c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v12, v12, v4                               ; 4a18090c
	v_lshl_add_u32 v12, v0, 2, v12                              ; d646000c 04310500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v11, v11, 1, v12                             ; d646000b 0431030b
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v10, v11, s[20:23], null offen              ; c406007c 4080280a 0000000b
	buffer_store_b8 v13, v11, s[20:23], null offen offset:1     ; c406007c 4080280d 0000010b
BB9:
	s_or_not1_b32 s68, s47, s68                                 ; 9244442f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s0, src_scc, s49                                   ; 8c0031fd
	s_cbranch_scc1 BB12                                         ; bfa20008
BB10:
	v_add3_u32 v3, v2, s3, s29                                  ; d6550003 00740702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v3, v6, v3, v5                                   ; d6550003 04160706
	buffer_store_b64 v[8:9], v3, s[20:23], null offen           ; c406c07c 40802808 00000003
BB12:
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_ge_i32 s50, 0                                         ; bf038032
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s2, -1, 0                                     ; 980280c1
	s_cbranch_scc0 BB14                                         ; bfa1000a
BB13:
	s_load_b32 s4, s[10:11], 0x48                               ; f4000105 f8000048
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s4, s4, 1                                        ; 84048104
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s4                                        ; bf04041f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB15                                               ; bfa00002
BB14:
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB15:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	s_cbranch_scc0 BB17                                         ; bfa10009
BB16:
	s_load_b32 s4, s[10:11], 0x4c                               ; f4000105 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s4, s4, 1                                        ; 84048104
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s17, s4                                        ; bf040411
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB18                                               ; bfa00001
BB17:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB18:
	s_mov_b32 s4, 0xaaaaaaaa                                    ; be8400ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v3, v80, v84, s4                          ; d5010003 0012a950
	v_cndmask_b32_e64 v84, v84, v80, s4                         ; d5010054 0012a154
	v_cndmask_b32_e64 v4, v81, v85, s4                          ; d5010004 0012ab51
	v_cndmask_b32_e64 v85, v85, v81, s4                         ; d5010055 0012a355
	v_cndmask_b32_e64 v7, v82, v86, s4                          ; d5010007 0012ad52
	v_cndmask_b32_e64 v86, v86, v82, s4                         ; d5010056 0012a556
	v_cndmask_b32_e64 v10, v83, v87, s4                         ; d501000a 0012af53
	v_cndmask_b32_e64 v87, v87, v83, s4                         ; d5010057 0012a757
	s_mov_b32 s6, 0xf0f0f0f0                                    ; be8600ff f0f0f0f0
	v_add_f32_dpp v84, v84, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06a806fa ff0cb154
	s_and_b32 s7, vcc_lo, exec_lo                               ; 8b077e6a
	v_add_f32_dpp v85, v85, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06aa08fa ff0cb155
	v_add_f32_dpp v86, v86, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ac0efa ff0cb156
	v_add_f32_dpp v87, v87, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ae14fa ff0cb157
	v_cvt_f16_f32_e32 v13, v84                                  ; 7e1a1554
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v14, v85                                  ; 7e1c1555
	v_cvt_f16_f32_e32 v11, v86                                  ; 7e161556
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v86, v86, v84, s6                         ; d5010056 001aa956
	v_cvt_f16_f32_e32 v12, v87                                  ; 7e181557
	v_cndmask_b32_e64 v87, v87, v85, s6                         ; d5010057 001aab57
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v15, v13, v11, s6                         ; d501000f 001a170d
	v_cvt_f16_f32_dpp v16, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d6456
	v_cndmask_b16 v15, v14, v12, s6                             ; d65d400f 001a190e
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d6457
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB21                                         ; bfa1003a
BB19:
	s_load_b64 s[6:7], s[10:11], 0x44                           ; f4002185 f8000044
	s_ashr_i32 s4, s17, 1                                       ; 86048111
	s_ashr_i32 s8, s31, 1                                       ; 8608811f
	v_bfe_u32 v3, v66, 1, 1                                     ; d6100003 02050342
	v_bfe_u32 v4, v66, 3, 1                                     ; d6100004 02050742
	s_and_b32 s9, s31, 1                                        ; 8b09811f
	v_fma_mix_f32 v7, 0, v15, neg(0) op_sel_hi:[0,1,0]          ; cc200007 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100f 92021eff 3e800000
	v_bfe_u32 v11, v66, 2, 1                                    ; d610000b 02050542
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s9, s9, 5                                        ; 84098509
	s_and_b32 s12, s16, 1                                       ; 8b0c8110
	v_lshl_add_u32 v4, v4, 2, v3                                ; d6460004 040d0504
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v7, v15, vcc_lo                       ; 02021f07
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s12, s12, 7                                      ; 840c870c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v4, v4, 4, v55                               ; d6460004 04dd0904
	v_perm_b32 v13, v13, v10, 0x7060501                         ; d644000d 03fe150d 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s4, s4, s7                                        ; 96040704
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s4, s8                                     ; 80040804
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v12, s4, 2, v1                               ; d646000c 04050404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v12, v12, 8, s6                              ; d646000c 0019110c
	v_add3_u32 v12, v12, s12, s9                                ; d655000c 0024190c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v12, v12, v4                               ; 4a18090c
	v_lshl_add_u32 v12, v0, 2, v12                              ; d646000c 04310500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v11, v11, 1, v12                             ; d646000b 0431030b
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v10, v11, s[20:23], null offen              ; c406007c 4080280a 0000000b
	buffer_store_b8 v13, v11, s[20:23], null offen offset:1     ; c406007c 4080280d 0000010b
BB21:
	s_or_not1_b32 s2, s52, s2                                   ; 92020234
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s49, src_scc, s49                                  ; 8c3131fd
	s_cbranch_scc1 BB24                                         ; bfa20008
BB22:
	v_add3_u32 v3, v2, s3, s28                                  ; d6550003 00700702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v3, v6, v3, v5                                   ; d6550003 04160706
	buffer_store_b64 v[8:9], v3, s[20:23], null offen           ; c406c07c 40802808 00000003
BB24:
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s2, src_scc                                       ; be8200fd
	s_cmp_ge_i32 s53, 0                                         ; bf038035
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s4, -1, 0                                     ; 980480c1
	s_cbranch_scc0 BB26                                         ; bfa1000a
BB25:
	s_load_b32 s6, s[10:11], 0x48                               ; f4000185 f8000048
	s_mov_b32 s7, src_scc                                       ; be8700fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s24, s6                                        ; bf040618
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB27                                               ; bfa00002
BB26:
	s_mov_b32 s7, src_scc                                       ; be8700fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB27:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	s_cbranch_scc0 BB29                                         ; bfa10009
BB28:
	s_load_b32 s6, s[10:11], 0x4c                               ; f4000185 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s6                                        ; bf04062a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB30                                               ; bfa00001
BB29:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB30:
	s_mov_b32 s6, 0xaaaaaaaa                                    ; be8600ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v3, v88, v92, s6                          ; d5010003 001ab958
	v_cndmask_b32_e64 v92, v92, v88, s6                         ; d501005c 001ab15c
	v_cndmask_b32_e64 v4, v89, v93, s6                          ; d5010004 001abb59
	v_cndmask_b32_e64 v93, v93, v89, s6                         ; d501005d 001ab35d
	v_cndmask_b32_e64 v7, v90, v94, s6                          ; d5010007 001abd5a
	v_cndmask_b32_e64 v94, v94, v90, s6                         ; d501005e 001ab55e
	v_cndmask_b32_e64 v10, v91, v95, s6                         ; d501000a 001abf5b
	v_cndmask_b32_e64 v95, v95, v91, s6                         ; d501005f 001ab75f
	s_mov_b32 s8, 0xf0f0f0f0                                    ; be8800ff f0f0f0f0
	v_add_f32_dpp v92, v92, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06b806fa ff0cb15c
	s_and_b32 s9, vcc_lo, exec_lo                               ; 8b097e6a
	v_add_f32_dpp v93, v93, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ba08fa ff0cb15d
	v_add_f32_dpp v94, v94, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06bc0efa ff0cb15e
	v_add_f32_dpp v95, v95, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06be14fa ff0cb15f
	v_cvt_f16_f32_e32 v13, v92                                  ; 7e1a155c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v14, v93                                  ; 7e1c155d
	v_cvt_f16_f32_e32 v11, v94                                  ; 7e16155e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v94, v94, v92, s8                         ; d501005e 0022b95e
	v_cvt_f16_f32_e32 v12, v95                                  ; 7e18155f
	v_cndmask_b32_e64 v95, v95, v93, s8                         ; d501005f 0022bb5f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v15, v13, v11, s8                         ; d501000f 0022170d
	v_cvt_f16_f32_dpp v16, v94 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d645e
	v_cndmask_b16 v15, v14, v12, s8                             ; d65d400f 0022190e
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d645f
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB33                                         ; bfa10039
BB31:
	s_load_b64 s[8:9], s[10:11], 0x44                           ; f4002205 f8000044
	s_ashr_i32 s6, s42, 1                                       ; 8606812a
	s_ashr_i32 s12, s24, 1                                      ; 860c8118
	v_bfe_u32 v3, v66, 1, 1                                     ; d6100003 02050342
	v_bfe_u32 v4, v66, 3, 1                                     ; d6100004 02050742
	s_and_b32 s13, s15, 1                                       ; 8b0d810f
	v_fma_mix_f32 v7, 0, v15, neg(0) op_sel_hi:[0,1,0]          ; cc200007 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100f 92021eff 3e800000
	v_bfe_u32 v11, v66, 2, 1                                    ; d610000b 02050542
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s13, s13, 5                                      ; 840d850d
	s_and_b32 s14, s42, 1                                       ; 8b0e812a
	v_lshl_add_u32 v4, v4, 2, v3                                ; d6460004 040d0504
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v7, v15, vcc_lo                       ; 02021f07
	s_lshl_b32 s14, s14, 7                                      ; 840e870e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v4, v4, 4, v55                               ; d6460004 04dd0904
	v_perm_b32 v13, v13, v10, 0x7060501                         ; d644000d 03fe150d 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s6, s6, s9                                        ; 96060906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s12                                    ; 80060c06
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v12, s6, 2, v1                               ; d646000c 04050406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v12, v12, 8, s8                              ; d646000c 0021110c
	v_add3_u32 v12, v12, s14, s13                               ; d655000c 00341d0c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v12, v12, v4                               ; 4a18090c
	v_lshl_add_u32 v12, v0, 2, v12                              ; d646000c 04310500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v11, v11, 1, v12                             ; d646000b 0431030b
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v10, v11, s[20:23], null offen              ; c406007c 4080280a 0000000b
	buffer_store_b8 v13, v11, s[20:23], null offen offset:1     ; c406007c 4080280d 0000010b
BB33:
	s_or_not1_b32 s47, s47, s4                                  ; 922f042f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s4, src_scc, s56                                   ; 8c0438fd
	s_cbranch_scc1 BB36                                         ; bfa20008
BB34:
	v_add3_u32 v3, v2, s3, s25                                  ; d6550003 00640702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v3, v6, v3, v5                                   ; d6550003 04160706
	buffer_store_b64 v[8:9], v3, s[20:23], null offen           ; c406c07c 40802808 00000003
BB36:
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s4, src_scc                                       ; be8400fd
	s_cmp_ge_i32 s57, 0                                         ; bf038039
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s6, -1, 0                                     ; 980680c1
	s_cbranch_scc0 BB38                                         ; bfa1000a
BB37:
	s_load_b32 s8, s[10:11], 0x48                               ; f4000205 f8000048
	s_mov_b32 s9, src_scc                                       ; be8900fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s8, s8, 1                                        ; 84088108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s8                                        ; bf04081f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB39                                               ; bfa00002
BB38:
	s_mov_b32 s9, src_scc                                       ; be8900fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB39:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s8, vcc_lo, exec_lo                               ; 8b087e6a
	s_cbranch_scc0 BB41                                         ; bfa10009
BB40:
	s_load_b32 s8, s[10:11], 0x4c                               ; f4000205 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s8, s8, 1                                        ; 84088108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s8                                        ; bf04082a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB42                                               ; bfa00001
BB41:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB42:
	s_mov_b32 s8, 0xaaaaaaaa                                    ; be8800ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v3, v96, v100, s8                         ; d5010003 0022c960
	v_cndmask_b32_e64 v100, v100, v96, s8                       ; d5010064 0022c164
	v_cndmask_b32_e64 v4, v97, v101, s8                         ; d5010004 0022cb61
	v_cndmask_b32_e64 v101, v101, v97, s8                       ; d5010065 0022c365
	v_cndmask_b32_e64 v7, v98, v102, s8                         ; d5010007 0022cd62
	v_cndmask_b32_e64 v102, v102, v98, s8                       ; d5010066 0022c566
	v_cndmask_b32_e64 v10, v99, v103, s8                        ; d501000a 0022cf63
	v_cndmask_b32_e64 v103, v103, v99, s8                       ; d5010067 0022c767
	s_mov_b32 s12, 0xf0f0f0f0                                   ; be8c00ff f0f0f0f0
	v_add_f32_dpp v100, v100, v3 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06c806fa ff0cb164
	s_and_b32 s13, vcc_lo, exec_lo                              ; 8b0d7e6a
	v_add_f32_dpp v101, v101, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ca08fa ff0cb165
	v_add_f32_dpp v102, v102, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cc0efa ff0cb166
	v_add_f32_dpp v103, v103, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ce14fa ff0cb167
	v_cvt_f16_f32_e32 v13, v100                                 ; 7e1a1564
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v14, v101                                 ; 7e1c1565
	v_cvt_f16_f32_e32 v11, v102                                 ; 7e161566
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v102, v102, v100, s12                     ; d5010066 0032c966
	v_cvt_f16_f32_e32 v12, v103                                 ; 7e181567
	v_cndmask_b32_e64 v103, v103, v101, s12                     ; d5010067 0032cb67
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v15, v13, v11, s12                        ; d501000f 0032170d
	v_cvt_f16_f32_dpp v16, v102 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e2014fa ff0d6466
	v_cndmask_b16 v15, v14, v12, s12                            ; d65d400f 0032190e
(invalid instruction)                                        ; 7f2014fa
(invalid instruction)                                        ; ff0d6467
(invalid instruction)                                        ; cc0f000f
	v_min_num_f64_e32 v[1:2], v[15:16], v[16:17]                ; 1a02210f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB45                                         ; bfa1003a
BB43:
	s_load_b64 s[12:13], s[10:11], 0x44                         ; f4002305 f8000044
	s_ashr_i32 s8, s42, 1                                       ; 8608812a
	s_ashr_i32 s14, s31, 1                                      ; 860e811f
	v_bfe_u32 v3, v66, 1, 1                                     ; d6100003 02050342
	v_bfe_u32 v4, v66, 3, 1                                     ; d6100004 02050742
	s_and_b32 s18, s31, 1                                       ; 8b12811f
	v_fma_mix_f32 v7, 0, v15, neg(0) op_sel_hi:[0,1,0]          ; cc200007 92021eff 3e800000
	v_fma_mix_f32 v15, 0, v15, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100f 92021eff 3e800000
	v_bfe_u32 v11, v66, 2, 1                                    ; d610000b 02050542
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s18, s18, 5                                      ; 84128512
	s_and_b32 s19, s42, 1                                       ; 8b13812a
	v_lshl_add_u32 v4, v4, 2, v3                                ; d6460004 040d0504
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v7, v15, vcc_lo                       ; 02021f07
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s19, s19, 7                                      ; 84138713
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v4, v4, 4, v55                               ; d6460004 04dd0904
	v_perm_b32 v13, v13, v10, 0x7060501                         ; d644000d 03fe150d 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s8, s8, s13                                       ; 96080d08
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s8, s8, s14                                    ; 80080e08
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v12, s8, 2, v1                               ; d646000c 04050408
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v12, v12, 8, s12                             ; d646000c 0031110c
	v_add3_u32 v12, v12, s19, s18                               ; d655000c 0048270c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v12, v12, v4                               ; 4a18090c
	v_lshl_add_u32 v12, v0, 2, v12                              ; d646000c 04310500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v11, v11, 1, v12                             ; d646000b 0431030b
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v10, v11, s[20:23], null offen              ; c406007c 4080280a 0000000b
	buffer_store_b8 v13, v11, s[20:23], null offen offset:1     ; c406007c 4080280d 0000010b
BB45:
	s_or_not1_b32 s52, s52, s6                                  ; 92340634
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s56, src_scc, s56                                  ; 8c3838fd
	s_cbranch_scc1 BB48                                         ; bfa20008
BB46:
	v_add3_u32 v2, v2, s3, s43                                  ; d6550002 00ac0702
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v2, v6, v2, v5                                   ; d6550002 04160506
	buffer_store_b64 v[8:9], v2, s[20:23], null offen           ; c406c07c 40802808 00000002
BB48:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s1, vcc_lo                                        ; be81006a
	s_cbranch_scc0 BB50                                         ; bfa10009
BB49:
	s_load_b32 s6, s[10:11], 0x48                               ; f4000185 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s24, s6                                        ; bf040618
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB51                                               ; bfa00001
BB50:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB51:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	s_cbranch_scc0 BB53                                         ; bfa10009
BB52:
	s_load_b32 s6, s[10:11], 0x4c                               ; f4000185 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s17, s6                                        ; bf040611
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB54                                               ; bfa00001
BB53:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB54:
	s_mov_b32 s6, 0xaaaaaaaa                                    ; be8600ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v56, v60, s6                          ; d5010004 001a7938
	v_cndmask_b32_e64 v60, v60, v56, s6                         ; d501003c 001a713c
	v_cndmask_b32_e64 v7, v57, v61, s6                          ; d5010007 001a7b39
	v_cndmask_b32_e64 v61, v61, v57, s6                         ; d501003d 001a733d
	v_cndmask_b32_e64 v8, v58, v62, s6                          ; d5010008 001a7d3a
	v_cndmask_b32_e64 v62, v62, v58, s6                         ; d501003e 001a753e
	v_cndmask_b32_e64 v9, v59, v63, s6                          ; d5010009 001a7f3b
	v_cndmask_b32_e64 v63, v63, v59, s6                         ; d501003f 001a773f
	s_mov_b32 s8, 0xf0f0f0f0                                    ; be8800ff f0f0f0f0
	v_add_f32_dpp v60, v60, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067808fa ff0cb13c
	s_and_b32 s12, vcc_lo, exec_lo                              ; 8b0c7e6a
	v_add_f32_dpp v61, v61, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067a0efa ff0cb13d
	v_add_f32_dpp v62, v62, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067c10fa ff0cb13e
	v_add_f32_dpp v63, v63, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067e12fa ff0cb13f
	v_cvt_f16_f32_e32 v12, v60                                  ; 7e18153c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v13, v61                                  ; 7e1a153d
	v_cvt_f16_f32_e32 v10, v62                                  ; 7e14153e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v62, v62, v60, s8                         ; d501003e 0022793e
	v_cvt_f16_f32_e32 v11, v63                                  ; 7e16153f
	v_cndmask_b32_e64 v63, v63, v61, s8                         ; d501003f 00227b3f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v14, v12, v10, s8                         ; d501000e 0022150c
	v_cvt_f16_f32_dpp v15, v62 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d643e
	v_cndmask_b16 v14, v13, v11, s8                             ; d65d400e 0022170d
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d643f
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[15:16]                ; 1a021f0e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB57                                         ; bfa1003c
BB55:
	s_load_b64 s[12:13], s[10:11], 0x44                         ; f4002305 f8000044
	s_ashr_i32 s6, s17, 1                                       ; 86068111
	s_ashr_i32 s8, s24, 1                                       ; 86088118
	v_bfe_u32 v4, v66, 1, 1                                     ; d6100004 02050342
	v_bfe_u32 v7, v66, 3, 1                                     ; d6100007 02050742
	s_and_b32 s14, s15, 1                                       ; 8b0e810f
	v_fma_mix_f32 v8, 0, v14, neg(0) op_sel_hi:[0,1,0]          ; cc200008 92021cff 3e800000
	v_fma_mix_f32 v14, 0, v14, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100e 92021cff 3e800000
	v_bfe_u32 v10, v66, 2, 1                                    ; d610000a 02050542
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s14, s14, 5                                      ; 840e850e
	s_and_b32 s18, s16, 1                                       ; 8b128110
	v_lshl_add_u32 v7, v7, 2, v4                                ; d6460007 04110507
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v8, v14, vcc_lo                       ; 02021d08
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s18, s18, 7                                      ; 84128712
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s18, s18, s14                                  ; 80120e12
	v_lshl_add_u32 v7, v7, 4, v55                               ; d6460007 04dd0907
	v_perm_b32 v12, v12, v9, 0x7060501                          ; d644000c 03fe130c 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s6, s6, s13                                       ; 96060d06
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s8                                     ; 80060806
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v11, s6, 2, v1                               ; d646000b 04050406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v11, v11, 8, 0x100                           ; d646000b 03fd110b 00000100
	v_add3_u32 v11, s18, s12, v11                               ; d655000b 042c1812
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v11, v11, v7                               ; 4a160f0b
	v_lshl_add_u32 v11, v0, 2, v11                              ; d646000b 042d0500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v10, v10, 1, v11                             ; d646000a 042d030a
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v9, v10, s[20:23], null offen               ; c406007c 40802809 0000000a
	buffer_store_b8 v12, v10, s[20:23], null offen offset:1     ; c406007c 4080280c 0000010a
BB57:
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB60                                         ; bfa20008
BB58:
	v_add3_u32 v4, v67, s3, s29                                 ; d6550004 00740743
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v6, v4, v5                                   ; d6550004 04160906
	buffer_store_b64 v[2:3], v4, s[20:23], null offen           ; c406c07c 40802802 00000004
BB60:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s5, 0                                          ; bf018005
	s_cbranch_scc0 BB62                                         ; bfa10009
BB61:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s0                                        ; bf04001f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB63                                               ; bfa00001
BB62:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB63:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB65                                         ; bfa10009
BB64:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s17, s0                                        ; bf040011
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB66                                               ; bfa00001
BB65:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB66:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v104, v108, s0                        ; d5010004 0002d968
	v_cndmask_b32_e64 v108, v108, v104, s0                      ; d501006c 0002d16c
	v_cndmask_b32_e64 v7, v105, v109, s0                        ; d5010007 0002db69
	v_cndmask_b32_e64 v109, v109, v105, s0                      ; d501006d 0002d36d
	v_cndmask_b32_e64 v8, v106, v110, s0                        ; d5010008 0002dd6a
	v_cndmask_b32_e64 v110, v110, v106, s0                      ; d501006e 0002d56e
	v_cndmask_b32_e64 v9, v107, v111, s0                        ; d5010009 0002df6b
	v_cndmask_b32_e64 v111, v111, v107, s0                      ; d501006f 0002d76f
	s_mov_b32 s5, 0xf0f0f0f0                                    ; be8500ff f0f0f0f0
	v_add_f32_dpp v108, v108, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06d808fa ff0cb16c
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	v_add_f32_dpp v109, v109, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06da0efa ff0cb16d
	v_add_f32_dpp v110, v110, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06dc10fa ff0cb16e
	v_add_f32_dpp v111, v111, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06de12fa ff0cb16f
	v_cvt_f16_f32_e32 v12, v108                                 ; 7e18156c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v13, v109                                 ; 7e1a156d
	v_cvt_f16_f32_e32 v10, v110                                 ; 7e14156e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v110, v110, v108, s5                      ; d501006e 0016d96e
	v_cvt_f16_f32_e32 v11, v111                                 ; 7e16156f
	v_cndmask_b32_e64 v111, v111, v109, s5                      ; d501006f 0016db6f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v14, v12, v10, s5                         ; d501000e 0016150c
	v_cvt_f16_f32_dpp v15, v110 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d646e
	v_cndmask_b16 v14, v13, v11, s5                             ; d65d400e 0016170d
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d646f
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[15:16]                ; 1a021f0e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB69                                         ; bfa1003a
BB67:
	s_load_b64 s[12:13], s[10:11], 0x44                         ; f4002305 f8000044
	s_ashr_i32 s17, s17, 1                                      ; 86118111
	s_ashr_i32 s0, s31, 1                                       ; 8600811f
	v_bfe_u32 v4, v66, 1, 1                                     ; d6100004 02050342
	v_bfe_u32 v7, v66, 3, 1                                     ; d6100007 02050742
	s_and_b32 s5, s31, 1                                        ; 8b05811f
	v_fma_mix_f32 v8, 0, v14, neg(0) op_sel_hi:[0,1,0]          ; cc200008 92021cff 3e800000
	v_fma_mix_f32 v14, 0, v14, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100e 92021cff 3e800000
	v_bfe_u32 v10, v66, 2, 1                                    ; d610000a 02050542
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s5, s5, 5                                        ; 84058505
	s_and_b32 s16, s16, 1                                       ; 8b108110
	v_lshl_add_u32 v7, v7, 2, v4                                ; d6460007 04110507
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v8, v14, vcc_lo                       ; 02021d08
	s_lshl_b32 s16, s16, 7                                      ; 84108710
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s16, s5                                   ; 80100510
	v_lshl_add_u32 v7, v7, 4, v55                               ; d6460007 04dd0907
	v_perm_b32 v12, v12, v9, 0x7060501                          ; d644000c 03fe130c 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s17, s17, s13                                     ; 96110d11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s17, s17, s0                                   ; 80110011
	v_lshl_add_u32 v11, s17, 2, v1                              ; d646000b 04050411
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v11, v11, 8, 0x100                           ; d646000b 03fd110b 00000100
	v_add3_u32 v11, s16, s12, v11                               ; d655000b 042c1810
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v11, v11, v7                               ; 4a160f0b
	v_lshl_add_u32 v11, v0, 2, v11                              ; d646000b 042d0500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v10, v10, 1, v11                             ; d646000a 042d030a
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v9, v10, s[20:23], null offen               ; c406007c 40802809 0000000a
	buffer_store_b8 v12, v10, s[20:23], null offen offset:1     ; c406007c 4080280c 0000010a
BB69:
	s_cmp_lg_i32 s2, 0                                          ; bf018002
	s_cbranch_scc1 BB72                                         ; bfa20008
BB70:
	v_add3_u32 v4, v67, s3, s28                                 ; d6550004 00700743
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v6, v4, v5                                   ; d6550004 04160906
	buffer_store_b64 v[2:3], v4, s[20:23], null offen           ; c406c07c 40802802 00000004
BB72:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s7, 0                                          ; bf018007
	s_cbranch_scc0 BB74                                         ; bfa10009
BB73:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s24, s0                                        ; bf040018
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB75                                               ; bfa00001
BB74:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB75:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB77                                         ; bfa10009
BB76:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s0                                        ; bf04002a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB78                                               ; bfa00001
BB77:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB78:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v112, v116, s0                        ; d5010004 0002e970
	v_cndmask_b32_e64 v116, v116, v112, s0                      ; d5010074 0002e174
	v_cndmask_b32_e64 v7, v113, v117, s0                        ; d5010007 0002eb71
	v_cndmask_b32_e64 v117, v117, v113, s0                      ; d5010075 0002e375
	v_cndmask_b32_e64 v8, v114, v118, s0                        ; d5010008 0002ed72
	v_cndmask_b32_e64 v118, v118, v114, s0                      ; d5010076 0002e576
	v_cndmask_b32_e64 v9, v115, v119, s0                        ; d5010009 0002ef73
	v_cndmask_b32_e64 v119, v119, v115, s0                      ; d5010077 0002e777
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v116, v116, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06e808fa ff0cb174
	s_and_b32 s5, vcc_lo, exec_lo                               ; 8b057e6a
	v_add_f32_dpp v117, v117, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ea0efa ff0cb175
	v_add_f32_dpp v118, v118, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ec10fa ff0cb176
	v_add_f32_dpp v119, v119, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ee12fa ff0cb177
	v_cvt_f16_f32_e32 v12, v116                                 ; 7e181574
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v13, v117                                 ; 7e1a1575
	v_cvt_f16_f32_e32 v10, v118                                 ; 7e141576
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v118, v118, v116, s2                      ; d5010076 000ae976
	v_cvt_f16_f32_e32 v11, v119                                 ; 7e161577
	v_cndmask_b32_e64 v119, v119, v117, s2                      ; d5010077 000aeb77
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v14, v12, v10, s2                         ; d501000e 000a150c
	v_cvt_f16_f32_dpp v15, v118 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d6476
	v_cndmask_b16 v14, v13, v11, s2                             ; d65d400e 000a170d
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d6477
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[15:16]                ; 1a021f0e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB81                                         ; bfa1003c
BB79:
	s_load_b64 s[6:7], s[10:11], 0x44                           ; f4002185 f8000044
	s_ashr_i32 s0, s42, 1                                       ; 8600812a
	s_ashr_i32 s24, s24, 1                                      ; 86188118
	v_bfe_u32 v4, v66, 1, 1                                     ; d6100004 02050342
	v_bfe_u32 v7, v66, 3, 1                                     ; d6100007 02050742
	s_and_b32 s15, s15, 1                                       ; 8b0f810f
	v_fma_mix_f32 v8, 0, v14, neg(0) op_sel_hi:[0,1,0]          ; cc200008 92021cff 3e800000
	v_fma_mix_f32 v14, 0, v14, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100e 92021cff 3e800000
	v_bfe_u32 v10, v66, 2, 1                                    ; d610000a 02050542
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s15, s15, 5                                      ; 840f850f
	s_and_b32 s2, s42, 1                                        ; 8b02812a
	v_lshl_add_u32 v7, v7, 2, v4                                ; d6460007 04110507
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v8, v14, vcc_lo                       ; 02021d08
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s2, s2, 7                                        ; 84028702
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s2, s2, s15                                    ; 80020f02
	v_lshl_add_u32 v7, v7, 4, v55                               ; d6460007 04dd0907
	v_perm_b32 v12, v12, v9, 0x7060501                          ; d644000c 03fe130c 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s7                                        ; 96000700
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s24                                    ; 80001800
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v11, s0, 2, v1                               ; d646000b 04050400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v11, v11, 8, 0x100                           ; d646000b 03fd110b 00000100
	v_add3_u32 v11, s2, s6, v11                                 ; d655000b 042c0c02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v11, v11, v7                               ; 4a160f0b
	v_lshl_add_u32 v11, v0, 2, v11                              ; d646000b 042d0500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v10, v10, 1, v11                             ; d646000a 042d030a
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v9, v10, s[20:23], null offen               ; c406007c 40802809 0000000a
	buffer_store_b8 v12, v10, s[20:23], null offen offset:1     ; c406007c 4080280c 0000010a
BB81:
	s_cmp_lg_i32 s4, 0                                          ; bf018004
	s_cbranch_scc1 BB84                                         ; bfa20008
BB82:
	v_add3_u32 v4, v67, s3, s25                                 ; d6550004 00640743
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v4, v6, v4, v5                                   ; d6550004 04160906
	buffer_store_b64 v[2:3], v4, s[20:23], null offen           ; c406c07c 40802802 00000004
BB84:
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s9, 0                                          ; bf018009
	s_cbranch_scc0 BB86                                         ; bfa10009
BB85:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s31, s0                                        ; bf04001f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB87                                               ; bfa00001
BB86:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB87:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB89                                         ; bfa10009
BB88:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s42, s0                                        ; bf04002a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB90                                               ; bfa00001
BB89:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB90:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v120, v124, s0                        ; d5010004 0002f978
	v_cndmask_b32_e64 v124, v124, v120, s0                      ; d501007c 0002f17c
	v_cndmask_b32_e64 v7, v121, v125, s0                        ; d5010007 0002fb79
	v_cndmask_b32_e64 v125, v125, v121, s0                      ; d501007d 0002f37d
	v_cndmask_b32_e64 v8, v122, v126, s0                        ; d5010008 0002fd7a
	v_cndmask_b32_e64 v126, v126, v122, s0                      ; d501007e 0002f57e
	v_cndmask_b32_e64 v9, v123, v127, s0                        ; d5010009 0002ff7b
	v_cndmask_b32_e64 v127, v127, v123, s0                      ; d501007f 0002f77f
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v124, v124, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06f808fa ff0cb17c
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	v_add_f32_dpp v125, v125, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06fa0efa ff0cb17d
	v_add_f32_dpp v126, v126, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06fc10fa ff0cb17e
	v_add_f32_dpp v127, v127, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06fe12fa ff0cb17f
	v_cvt_f16_f32_e32 v12, v124                                 ; 7e18157c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v13, v125                                 ; 7e1a157d
	v_cvt_f16_f32_e32 v10, v126                                 ; 7e14157e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v126, v126, v124, s2                      ; d501007e 000af97e
	v_cvt_f16_f32_e32 v11, v127                                 ; 7e16157f
	v_cndmask_b32_e64 v127, v127, v125, s2                      ; d501007f 000afb7f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v14, v12, v10, s2                         ; d501000e 000a150c
	v_cvt_f16_f32_dpp v15, v126 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1e14fa ff0d647e
	v_cndmask_b16 v14, v13, v11, s2                             ; d65d400e 000a170d
(invalid instruction)                                        ; 7f1e14fa
(invalid instruction)                                        ; ff0d647f
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[15:16]                ; 1a021f0e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB93                                         ; bfa1003c
BB91:
	s_load_b64 s[4:5], s[10:11], 0x44                           ; f4002105 f8000044
	s_ashr_i32 s0, s42, 1                                       ; 8600812a
	s_ashr_i32 s2, s31, 1                                       ; 8602811f
	v_bfe_u32 v4, v66, 1, 1                                     ; d6100004 02050342
	v_bfe_u32 v7, v66, 3, 1                                     ; d6100007 02050742
	s_and_b32 s31, s31, 1                                       ; 8b1f811f
	v_fma_mix_f32 v8, 0, v14, neg(0) op_sel_hi:[0,1,0]          ; cc200008 92021cff 3e800000
	v_fma_mix_f32 v14, 0, v14, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100e 92021cff 3e800000
	v_bfe_u32 v66, v66, 2, 1                                    ; d6100042 02050542
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s31, s31, 5                                      ; 841f851f
	s_and_b32 s42, s42, 1                                       ; 8b2a812a
	v_lshl_add_u32 v7, v7, 2, v4                                ; d6460007 04110507
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v8, v14, vcc_lo                       ; 02021d08
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s42, s42, 7                                      ; 842a872a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s42, s42, s31                                  ; 802a1f2a
	v_lshl_add_u32 v7, v7, 4, v55                               ; d6460007 04dd0907
	v_perm_b32 v10, v10, v9, 0x7060501                          ; d644000a 03fe130a 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s5                                        ; 96000500
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s2                                     ; 80000200
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v1, s0, 2, v1                                ; d6460001 04050400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v1, v1, 8, 0x100                             ; d6460001 03fd1101 00000100
	v_add3_u32 v1, s42, s4, v1                                  ; d6550001 0404082a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v1, v1, v7                                 ; 4a020f01
	v_lshl_add_u32 v0, v0, 2, v1                                ; d6460000 04050500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v66, v66, 1, v0                              ; d6460042 04010342
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v9, v66, s[20:23], null offen               ; c406007c 40802809 00000042
	buffer_store_b8 v10, v66, s[20:23], null offen offset:1     ; c406007c 4080280a 00000142
BB93:
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc1 BB96                                         ; bfa20008
BB94:
	v_add3_u32 v67, v67, s3, s43                                ; d6550043 00ac0743
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v6, v6, v67, v5                                  ; d6550006 04168706
	buffer_store_b64 v[2:3], v6, s[20:23], null offen           ; c406c07c 40802802 00000006
BB96:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
