BB0:
	s_cmp_eq_i32 s8, -1                                         ; bf00c108
	s_cbranch_scc0 BB3                                          ; bfa10013
BB1:
	s_mov_b32 s10, s0                                           ; be8a0000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_load_b256 s[16:23], s[10:11], 0x0                         ; f4006405 f8000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_u8 v1, off, s[16:19], null offset:1 scope:SCOPE_DEV ; c407807c 00882001 00000100
	s_wait_loadcnt 0x0                                          ; bfc00000
	buffer_store_b8 v1, off, s[16:19], null scope:SCOPE_DEV     ; c406007c 00882001 00000000
	buffer_load_d16_b16 v2, off, s[20:23], null offset:2 scope:SCOPE_DEV ; c408007c 00882802 00000200
	s_wait_loadcnt 0x0                                          ; bfc00000
	buffer_store_b16 v2, off, s[20:23], null scope:SCOPE_DEV    ; c406407c 00882802 00000000
BB3:
	s_mov_b32 s9, s1                                            ; be890001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[12:15], s[0:1], 0x50                          ; f4004300 f8000050
	s_lshl_b32 s10, s2, 2                                       ; 840a8202
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s11, s10, 8                                    ; 800b880a
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b32 v1, off, s[12:15], s11 scope:SCOPE_DEV      ; c405000b 00881801 00000000
	v_and_b32_e32 v3, 31, v0                                    ; 3606009f
	s_add_co_u32 s16, s2, 4                                     ; 80108402
	v_lshrrev_b32_e32 v2, 5, v0                                 ; 32040085
	s_pack_hh_b32_b16 s19, ttmp7, 0                             ; 9a138073
	v_cmp_eq_i32_e32 vcc_lo, 0, v0                              ; 7c840080
	s_add_co_u32 s16, s16, s5                                   ; 80100510
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_add_co_u32 s17, s16, ttmp9                                ; 80117510
	s_add_co_u32 s16, s16, s8                                   ; 80100810
	s_add_co_u32 s18, s16, s5                                   ; 80120510
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s20, s18, 19                                   ; 80149312
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s21, v1                                 ; 7e2a0501
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v4, -1              ; ca100004 010400c1
	s_add_co_u32 s22, s21, 1                                    ; 80168115
	s_pack_ll_b32_b16 s21, 0, s21                               ; 99151580
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s21, s21, 0x10000                              ; 8015ff15 00010000
BB4:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB70                                        ; bfa500f9
BB5:
	s_load_b128 s[24:27], s[0:1], 0x40                          ; f4004600 f8000040
	s_mul_i32 s4, 7, s5                                         ; 96040587
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s6, s4                                     ; 80040406
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl2_add_u32 s4, s4, 0x80                                ; 8784ff04 00000080
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mov_b64 s[28:29], s[24:25]                                ; be9c0118
	s_mov_b64 s[30:31], s[26:27]                                ; be9e011a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_bitset0_b32 s29, 14                                       ; be9d108e
	s_buffer_load_b64 s[28:29], s[28:31], s4 offset:0x0         ; f402270e 08000000
(invalid instruction)                                        ; d4450017
	v_cndmask_b32_e32 v1, -1, v4, vcc_lo                        ; 020208c1
	s_cmp_lt_u32 ttmp9, 0x80                                    ; bf0aff75 00000080
	s_cselect_b32 s30, -1, 0                                    ; 981e80c1
	s_mov_b32 s32, src_scc                                      ; bea000fd
	v_cndmask_b32_e64 v5, -1, v4, s23                           ; d5010005 005e08c1
	v_cndmask_b32_e64 v4, v4, -1, s23                           ; d5010004 005d8304
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d442001f
	v_cndmask_b32_e32 v1, -1, v5, vcc_lo                        ; 02020ac1
	s_and_b32 s33, s30, s31                                     ; 8b211f1e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_saveexec_b32 s33, s33                                 ; bea12021
	s_cbranch_execz BB7                                         ; bfa50011
BB6:
	s_lshl2_add_u32 s4, s18, 4                                  ; 87848412
	buffer_load_b64 v[6:7], off, s[12:15], s4 scope:SCOPE_DEV   ; c4054004 00881806 00000000
	s_and_not1_b32 s34, s23, exec_lo                            ; 91227e17
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s35, v6                                 ; 7e460506
	v_readfirstlane_b32 s36, v7                                 ; 7e480507
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_min_u32 s36, s29, s36                                     ; 89a4241d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_u32 s35, s36                                       ; bf0a2423
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s37, exec_lo, 0                               ; 9825807e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s37, s37, s34                                      ; 8c252225
	s_branch BB11                                               ; bfa00001
BB7:
	s_mov_b32 s37, s23                                          ; bea50017
BB11:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, s33                                      ; befe0021
	s_and_b32 s37, s37, s31                                     ; 8b251f25
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 exec_lo, s37, exec_lo                             ; 8b7e7e25
	s_cbranch_execz BB17                                        ; bfa5000d
BB12:
	v_mov_b32_e32 v5, 1                                         ; 7e0a0281
	s_lshl2_add_u32 s4, s18, 4                                  ; 87848412
	buffer_atomic_add_u32 v5, off, s[12:15], s4 th:TH_ATOMIC_RETURN ; c40d4004 00901805 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_add_nc_u32_e32 v6, s20, v5                                ; 4a0c0a14
	s_wait_kmcnt 0x0                                            ; bfc70000
(invalid instruction)                                        ; d44c001f
	v_cndmask_b32_e32 v1, s29, v5, vcc_lo                       ; 02020a1d
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v5, -1, v6, s31                           ; d5010005 007e0cc1
BB17:
	s_mov_b32 exec_lo, s33                                      ; befe0021
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_ne_i32_e32 -1, v5                                    ; 7d8a0ac1
BB18:
	v_dual_mov_b32 v6, v5 :: v_dual_mov_b32 v5, s5              ; ca100105 06040005
	s_mov_b32 s4, s23                                           ; be840017
	s_and_not1_b32 exec_lo, s33, exec_lo                        ; 917e7e21
	s_cbranch_execz BB38                                        ; bfa50043
BB21:
	v_mov_b32_e32 v5, 1                                         ; 7e0a0281
	buffer_atomic_add_u32 v5, off, s[12:15], s10 th:TH_ATOMIC_RETURN ; c40d400a 00901805 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	s_wait_kmcnt 0x0                                            ; bfc70000
(invalid instruction)                                        ; d44b001c
	v_cndmask_b32_e32 v1, s28, v5, vcc_lo                       ; 02020a1c
	s_and_saveexec_b32 s28, s28                                 ; be9c201c
	s_cbranch_execz BB27                                        ; bfa50013
BB22:
	s_cmp_lg_i32 s32, 0                                         ; bf018020
	s_cbranch_scc0 BB24                                         ; bfa1000d
BB23:
	v_mov_b32_e32 v5, 1                                         ; 7e0a0281
	s_lshl2_add_u32 s31, s18, 4                                 ; 879f8412
	buffer_atomic_add_u32 v5, off, s[12:15], s31 th:TH_ATOMIC_RETURN ; c40d401f 00901805 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_add_nc_u32_e32 v6, s20, v5                                ; 4a0c0a14
(invalid instruction)                                        ; d44c0020
	v_cndmask_b32_e32 v1, s29, v5, vcc_lo                       ; 02020a1d
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v5, -1, v6, s32                           ; d5010005 00820cc1
	s_branch BB25                                               ; bfa00001
BB24:
	v_mov_b32_e32 v5, -1                                        ; 7e0a02c1
BB25:
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mov_b32 v6, v5 :: v_dual_mov_b32 v5, s5              ; ca100105 06040005
BB27:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 exec_lo, s28, exec_lo                        ; 917e7e1c
	s_cbranch_execz BB36                                        ; bfa5001c
BB28:
(invalid instruction)                                        ; d7021f06
	v_cndmask_b32_e32 v1, s7, v5, vcc_lo                        ; 02020a07
	s_not_b32 s31, s31                                          ; be9f1e1f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_saveexec_b32 s31, s31                                 ; be9f201f
BB29:
	v_add_nc_u32_e32 v5, s16, v6                                ; 4a0a0c10
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mov_b32 v6, v5 :: v_dual_mov_b32 v5, s5              ; ca100105 06040005
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 exec_lo, s31, exec_lo                        ; 917e7e1f
	s_cbranch_execz BB34                                        ; bfa5000a
BB32:
	s_mul_i32 s32, 5, s5                                        ; 96200585
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v5, v5, s6, s32                                  ; d6550005 00800d05
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v5, 2, v5                                 ; 300a0a82
	buffer_load_b32 v5, v5, s[24:27], null offen                ; c405007c 40803005 00000005
	v_mov_b32_e32 v6, -1                                        ; 7e0c02c1
BB34:
	s_mov_b32 exec_lo, s31                                      ; befe001f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s23, s23, exec_lo                            ; 91177e17
(invalid instruction)                                        ; d4450018
	v_cndmask_b32_e32 v1, -1, v6, vcc_lo                        ; 02020cc1
	s_or_b32 s23, s23, s24                                      ; 8c171817
BB36:
	s_mov_b32 exec_lo, s28                                      ; befe001c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s4, s4, exec_lo                              ; 91047e04
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s23, s23, exec_lo                                 ; 8b177e17
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s4, s4, s23                                        ; 8c041704
BB38:
	s_mov_b32 exec_lo, s33                                      ; befe0021
	v_cmpx_ne_i32_e32 -1, v6                                    ; 7d8a0cc1
	s_cbranch_execz BB65                                        ; bfa50060
BB39:
	v_lshlrev_b32_e32 v7, 2, v6                                 ; 300e0c82
	buffer_load_b32 v7, v7, s[12:15], null offen scope:SCOPE_DEV ; c405007c 40881807 00000007
	v_mov_b32_e32 v8, 0                                         ; 7e100280
	s_mov_b32 s23, exec_lo                                      ; be97007e
	s_mov_b32 s24, 0                                            ; be980080
BB40:
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_and_b32_e32 v9, 0xffff0000, v7                            ; 36120eff ffff0000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d4420019
	v_cndmask_b32_e32 v1, s21, v9, vcc_lo                       ; 02021215
	s_and_saveexec_b32 s26, s25                                 ; be9a2019
BB41:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s27, s25, exec_lo                                 ; 8b1b7e19
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s24, s24, s27                                      ; 8c181b18
	s_and_not1_b32 s26, s26, exec_lo                            ; 911a7e1a
	s_cbranch_scc0 BB60                                         ; bfa10047
BB45:
	s_mov_b32 exec_lo, s26                                      ; befe001a
	v_cmpx_eq_i32_e32 0, v1                                     ; 7d840280
	s_cbranch_execz BB50                                        ; bfa5000a
BB46:
	v_mov_b32_e32 v6, 1                                         ; 7e0c0281
	s_add_co_u32 s27, s10, 12                                   ; 801b8c0a
	buffer_atomic_max_u32 v6, off, s[12:15], s27                ; c40ec01b 00801806 00000000
	s_and_b32 s25, s25, exec_lo                                 ; 8b197e19
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s24, s24, s25                                      ; 8c181918
	s_and_not1_b32 s26, s26, exec_lo                            ; 911a7e1a
	s_cbranch_scc0 BB60                                         ; bfa1003a
BB50:
	s_mov_b32 exec_lo, s26                                      ; befe001a
	s_and_b32 s25, s30, s4                                      ; 8b19041e
	v_add_nc_u32_e32 v7, 1, v8                                  ; 4a0e1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_and_b32_e32 v7, 31, v7                                    ; 360e0e9f
(invalid instruction)                                        ; d442001b
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                         ; 02020e80
	s_and_b32 s27, s25, s27                                     ; 8b1b1b19
	v_add_co_ci_u32_e64 v8, s25, 0, v8, s25                     ; d5201908 00661080
	s_and_b32 exec_lo, s27, exec_lo                             ; 8b7e7e1b
	s_cbranch_execz BB59                                        ; bfa50026
BB51:
	s_lshl2_add_u32 s25, s18, 4                                 ; 87998412
	buffer_load_b64 v[10:11], off, s[12:15], s25 scope:SCOPE_DEV ; c4054019 0088180a 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s27, v10                                ; 7e36050a
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_readfirstlane_b32 s28, v11                                ; 7e38050b
	s_min_u32 s28, s29, s28                                     ; 899c1c1d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_u32 s27, s28                                       ; bf0a1c1b
	s_cbranch_scc0 BB53                                         ; bfa1000b
BB52:
	s_add_co_u32 s28, s27, 1                                    ; 801c811b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_mov_b32 v13, v10 :: v_dual_mov_b32 v12, s28          ; ca10010a 0d0c001c
	buffer_atomic_cmpswap_b32 v[12:13], off, s[12:15], s25 th:TH_ATOMIC_RETURN ; c40d0019 0090180c 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
(invalid instruction)                                        ; d442001f
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                      ; 0202190a
	s_branch BB54                                               ; bfa00001
BB53:
	s_mov_b32 s31, 0                                            ; be9f0080
BB54:
	s_add_co_u32 s27, s20, s27                                  ; 801b1b14
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v4, v4, v6, s31                           ; d5010004 007e0d04
	s_and_not1_b32 s25, s4, s31                                 ; 91191f04
	s_and_not1_b32 s4, s4, exec_lo                              ; 91047e04
	v_cndmask_b32_e64 v7, v6, s27, s31                          ; d5010007 007c3706
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s25, s25, exec_lo                                 ; 8b197e19
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s4, s25, s4                                        ; 8c040419
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mov_b32_e32 v6, v7                                        ; 7e0c0307
BB59:
	s_mov_b32 exec_lo, s26                                      ; befe001a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v7, 2, v6                                 ; 300e0c82
	buffer_load_b32 v7, v7, s[12:15], null offen scope:SCOPE_DEV ; c405007c 40881807 00000007
	v_add_nc_u32_e32 v1, -1, v1                                 ; 4a0202c1
	s_branch BB40                                               ; bfa0ffac
BB60:
	s_mov_b32 exec_lo, s23                                      ; befe0017
	v_cvt_u32_u16_e32 v7, v7                                    ; 7e0ed707
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cndmask_b32_e64 v5, v5, v7, s24                           ; d5010005 00620f05
BB65:
	s_mov_b32 exec_lo, s33                                      ; befe0021
	s_lshl_b32 s4, s17, 2                                       ; 84048211
	s_wait_loadcnt 0x0                                          ; bfc00000
	buffer_store_b32 v5, off, s[12:15], s4 scope:SCOPE_DEV      ; c4068004 00881805 00000000
BB70:
	s_wait_storecnt 0x0                                         ; bfc10000
	s_barrier_signal -1                                         ; be804ec1
	s_mov_b32 s4, 1                                             ; be840081
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_not_b32 exec_lo, s4                                       ; befe1e04
	s_barrier_wait 0xffff                                       ; bf94ffff
BB71:
	v_mov_b32_e32 v5, 0                                         ; 7e0a0280
	s_and_not1_b32 exec_lo, -1, exec_lo                         ; 917e7ec1
	s_cbranch_execz BB76                                        ; bfa50004
BB74:
	s_lshl_b32 s4, s17, 2                                       ; 84048211
	buffer_load_b32 v5, off, s[12:15], s4 scope:SCOPE_DEV       ; c4050004 00881805 00000000
BB76:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_barrier_signal -1                                         ; be804ec1
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s4, v5                                  ; 7e080505
	s_cmp_ge_u32 s4, s5                                         ; bf090504
	s_barrier_wait 0xffff                                       ; bf94ffff
	s_cbranch_scc1 BB146                                        ; bfa21e8a
BB78:
	s_mov_b32 s23, 0                                            ; be970080
	s_branch BB79                                               ; bfa00001
BB84:
	s_mov_b32 s23, s24                                          ; be970018
BB79:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s24, s23, 1                                    ; 80188117
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_u32 s24, s3                                        ; bf0a0318
	s_cbranch_scc0 BB81                                         ; bfa10012
BB80:
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_load_b128 s[28:31], s[0:1], 0x40                          ; f4004700 f8000040
	s_mul_i32 s25, s24, 24                                      ; 96199818
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s25, s9, s25                                   ; 80191909
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl2_add_u32 s25, s25, 0x5c                              ; 8799ff19 0000005c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s29, 14                                       ; be9d108e
	s_buffer_load_b32 s25, s[28:31], s25 offset:0x0             ; f402064e 32000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_ge_u32 s4, s25                                        ; bf091904
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s26, -1, 0                                    ; 981a80c1
	s_branch BB82                                               ; bfa00001
BB81:
	s_mov_b32 s26, 0                                            ; be9a0080
BB82:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 s26, exec_lo, s26                            ; 911a1a7e
	s_cbranch_scc0 BB84                                         ; bfa1ffe4
BB85:
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_load_b256 s[24:31], s[0:1], 0x30                          ; f4006600 f8000030
	s_mul_i32 s23, s23, 24                                      ; 96179817
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s23, s9, s23                                   ; 80171709
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s23, s23, 2                                      ; 84178217
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_and_b32 s33, s29, 0xffffbfff                              ; 8b21ff1d ffffbfff
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s36, s23, 32                                   ; 8024a017
	s_mov_b32 s32, s28                                          ; bea0001c
	s_mov_b64 s[34:35], s[30:31]                                ; bea2011e
	s_clause 0x1                                                ; bf850001
	s_buffer_load_b256 s[40:47], s[32:35], s23 offset:0x0       ; f4026a10 2e000000
	s_buffer_load_b64 s[36:37], s[32:35], s36 offset:0x0        ; f4022910 48000000
	s_load_b128 s[48:51], s[0:1], 0x0                           ; f4004c00 f8000000
	s_add_co_u32 s38, s23, 48                                   ; 8026b017
	s_add_co_u32 s39, s23, 64                                   ; 8027c017
	s_add_co_u32 s56, s23, 0x50                                 ; 8038ff17 00000050
	s_addk_co_i32 s23, 0x5c                                     ; b797005c
	s_clause 0x3                                                ; bf850003
	s_buffer_load_b128 s[52:55], s[32:35], s38 offset:0x0       ; f4024d10 4c000000
	s_buffer_load_b32 s39, s[32:35], s39 offset:0x0             ; f40209d0 4e000000
	s_buffer_load_b32 s56, s[32:35], s56 offset:0x0             ; f4020e10 70000000
	s_buffer_load_b32 s23, s[32:35], s23 offset:0x0             ; f40205d0 2e000000
(invalid instruction)                                        ; d71f0006
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_lshlrev_b32_e32 v5, 9, v2                                 ; 300a0489
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_and_b32_e32 v7, 15, v6                                    ; 360e0c8f
	v_lshrrev_b32_e32 v6, 4, v6                                 ; 320c0c84
	v_lshlrev_b32_e32 v8, 4, v7                                 ; 30100e84
	v_lshlrev_b32_e32 v6, 3, v6                                 ; 300c0c83
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_add_co_u32 s57, s53, -1                                   ; 8039c135
	s_add_co_u32 s58, s54, -1                                   ; 803ac136
	s_cvt_f32_u32 s59, s56                                      ; bebb6538
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d684003b
	v_cndmask_b32_e32 v0, s59, v128, vcc_lo                     ; 0201003b
	s_mul_f32 s59, s59, 0x4f7ffffe                              ; a23bff3b 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s59, s59                                      ; bebb673b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s60, s56, s59                                     ; 963c3b38
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s60, 0, s60                                    ; 81bc3c80
	s_mul_hi_u32 s60, s59, s60                                  ; 96bc3c3b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s59, s59, s60                                  ; 803b3c3b
	s_sub_co_i32 s23, s4, s23                                   ; 81971704
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s59, s23, s59                                  ; 96bb3b17
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s61, s59, s56                                     ; 963d383b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_sub_co_i32 s23, s23, s61                                  ; 81973d17
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_u32 s62, s23, s56                                  ; 80be3817
	s_absdiff_i32 s64, src_scc, 1                               ; 834081fd
	s_sub_co_u32 s62, s23, s56                                  ; 80be3817
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_cselect_b32 s23, s23, s62                                 ; 98173e17
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_u32 s56, s23, s56                                  ; 80b83817
	s_mov_b32 s65, src_scc                                      ; bec100fd
	s_absdiff_i32 s66, src_scc, 1                               ; 834281fd
	s_cmp_lg_i32 s65, 0                                         ; bf018041
	v_add_nc_u32_e32 v10, 0x100, v5                             ; 4a140aff 00000100
	s_cselect_b32 s23, s23, s56                                 ; 98173817
	s_add_co_u32 s59, s59, s64                                  ; 803b403b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s59, s59, s66                                  ; 803b423b
	s_lshl1_add_u32 s23, s23, s55                               ; 87173717
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_max_i32 s67, s23, 0                                       ; 8a438017
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s67, s67, s57                                     ; 89433943
	s_lshl1_add_u32 s59, s59, s39                               ; 873b273b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_max_i32 s68, s59, 0                                       ; 8a44803b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s68, s68, s58                                     ; 89443a44
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s68, s68, s53                                     ; 96443544
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s69, s68, s67                                  ; 80454344
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s69, s69, 11                                     ; 84458b45
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s70, s40, s69                                  ; 80464528
	s_add_co_u32 s71, s23, 1                                    ; 80478117
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v11, v8, s70, v10                                ; d655000b 04288d08
	v_add3_u32 v9, v8, s70, v5                                  ; d6550009 04148d08
	s_max_i32 s72, s71, 0                                       ; 8a488047
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s72, s72, s57                                     ; 89483948
	v_add_nc_u32_e32 v11, v11, v6                               ; 4a160d0b
	v_add_nc_u32_e32 v9, v9, v6                                 ; 4a120d09
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s68, s68, s72                                  ; 80444844
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s68, s68, 11                                     ; 84448b44
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s73, s40, s68                                  ; 80494428
	s_add_co_u32 s74, s59, 1                                    ; 804a813b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v12, v8, s73, v5                                 ; d655000c 04149308
	v_add3_u32 v13, v8, s73, v10                                ; d655000d 04289308
	s_max_i32 s75, s74, 0                                       ; 8a4b804a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s75, s75, s58                                     ; 894b3a4b
	v_add_nc_u32_e32 v12, v12, v6                               ; 4a180d0c
	v_add_nc_u32_e32 v13, v13, v6                               ; 4a1a0d0d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s75, s75, s53                                     ; 964b354b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s67, s75, s67                                  ; 8043434b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s67, s67, 11                                     ; 84438b43
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s76, s40, s67                                  ; 804c4328
	s_add_co_u32 s75, s75, s72                                  ; 804b484b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v15, v8, s76, v10                                ; d655000f 04289908
	v_add3_u32 v14, v8, s76, v5                                 ; d655000e 04149908
	s_lshl_b32 s75, s75, 11                                     ; 844b8b4b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s40, s40, s75                                  ; 80284b28
	v_add_nc_u32_e32 v15, v15, v6                               ; 4a1e0d0f
	v_add_nc_u32_e32 v14, v14, v6                               ; 4a1c0d0e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v16, v8, s40, v5                                 ; d6550010 04145108
	v_add3_u32 v17, v8, s40, v10                                ; d6550011 04285108
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v16, v16, v6                               ; 4a200d10
	v_add_nc_u32_e32 v17, v17, v6                               ; 4a220d11
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[18:19], v9, s[48:51], null offen scope:SCOPE_DEV ; c405407c 40886012 00000009
	buffer_load_b64 v[20:21], v11, s[48:51], null offen scope:SCOPE_DEV ; c405407c 40886014 0000000b
	buffer_load_b64 v[22:23], v12, s[48:51], null offen scope:SCOPE_DEV ; c405407c 40886016 0000000c
	buffer_load_b64 v[12:13], v13, s[48:51], null offen scope:SCOPE_DEV ; c405407c 4088600c 0000000d
	buffer_load_b64 v[24:25], v14, s[48:51], null offen scope:SCOPE_DEV ; c405407c 40886018 0000000e
	buffer_load_b64 v[14:15], v15, s[48:51], null offen scope:SCOPE_DEV ; c405407c 4088600e 0000000f
	buffer_load_b64 v[26:27], v16, s[48:51], null offen scope:SCOPE_DEV ; c405407c 4088601a 00000010
	buffer_load_b64 v[16:17], v17, s[48:51], null offen scope:SCOPE_DEV ; c405407c 40886010 00000011
	v_lshlrev_b32_e32 v28, 3, v2                                ; 30380483
	v_lshlrev_b32_e32 v31, 2, v3                                ; 303e0682
	s_lshr_b32 s42, s42, 2                                      ; 852a822a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_add_nc_u32_e32 v32, 2, v28                                ; 4a403882
	v_med3_i32 v30, -1, v28, 1                                  ; d620001e 020638c1
	v_sub_nc_u32_e32 v29, 0, v28                                ; 4c3a3880
	v_sub_nc_u32_e32 v33, 0, v32                                ; 4c424080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_max_i32_e32 v29, v28, v29                                 ; 243a3b1c
	v_max_i32_e32 v33, v32, v33                                 ; 24424320
	v_med3_i32 v32, -1, v32, 1                                  ; d6200020 020640c1
	v_lshrrev_b32_e32 v29, 1, v29                               ; 323a3a81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_lshrrev_b32_e32 v33, 1, v33                               ; 32424281
(invalid instruction)                                        ; d72c001e
	v_cndmask_b32_e32 v1, v30, v29, vcc_lo                      ; 02023b1e
(invalid instruction)                                        ; d72c0020
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v30, v30, 10, s42                            ; d646001e 00a9151e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshl_add_u32 v32, v32, 10, s42                            ; d6460020 00a91520
	v_add_lshl_u32 v30, v30, v31, 2                             ; d647001e 020a3f1e
	v_add_lshl_u32 v32, v32, v31, 2                             ; d6470020 020a3f20
	s_clause 0x9                                                ; bf850009
	buffer_load_b128 v[36:39], v30, s[28:31], null offen        ; c405c07c 40803824 0000001e
	buffer_load_b128 v[40:43], v32, s[28:31], null offen        ; c405c07c 40803828 00000020
	buffer_load_b128 v[44:47], v30, s[28:31], null offen offset:512 ; c405c07c 4080382c 0002001e
	buffer_load_b128 v[48:51], v32, s[28:31], null offen offset:512 ; c405c07c 40803830 00020020
	buffer_load_b128 v[52:55], v30, s[28:31], null offen offset:1024 ; c405c07c 40803834 0004001e
	buffer_load_b128 v[56:59], v32, s[28:31], null offen offset:1024 ; c405c07c 40803838 00040020
	buffer_load_b128 v[60:63], v30, s[28:31], null offen offset:1536 ; c405c07c 4080383c 0006001e
	buffer_load_b128 v[64:67], v32, s[28:31], null offen offset:1536 ; c405c07c 40803840 00060020
	buffer_load_b128 v[68:71], v30, s[28:31], null offen offset:2048 ; c405c07c 40803844 0008001e
	buffer_load_b128 v[72:75], v32, s[28:31], null offen offset:2048 ; c405c07c 40803848 00080020
	v_add_nc_u32_e32 v34, v8, v6                                ; 4a440d08
	s_min_i32 s77, s23, s59                                     ; 894d3b17
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s77, 0                                         ; bf04804d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b1
	v_add_nc_u32_e32 v35, v5, v34                               ; 4a464505
	s_cselect_b32 s78, -1, 0                                    ; 984e80c1
	s_cmp_ge_i32 s23, s53                                       ; bf033517
	s_cselect_b32 s79, -1, 0                                    ; 984f80c1
	v_add_nc_u32_e32 v76, 0x800, v35                            ; 4a9846ff 00000800
	v_add_nc_u32_e32 v77, 0x1000, v35                           ; 4a9a46ff 00001000
	v_add_nc_u32_e32 v78, 0x1800, v35                           ; 4a9c46ff 00001800
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s78, s78, s79                                      ; 8c4e4f4e
	s_cmp_ge_i32 s59, s54                                       ; bf03363b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_cselect_b32 s80, -1, 0                                    ; 985080c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s78, s78, s80                                      ; 8c4e504e
	s_mov_b32 s81, src_scc                                      ; bed100fd
	s_min_i32 s59, s71, s59                                     ; 893b3b47
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s59, 0                                         ; bf04803b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_cselect_b32 s82, -1, 0                                    ; 985280c1
	s_cmp_ge_i32 s71, s53                                       ; bf033547
	s_cselect_b32 s83, -1, 0                                    ; 985380c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s82, s82, s83                                      ; 8c525352
	v_lshl_add_u32 v79, s19, 4, v34                             ; d646004f 04890813
	s_movk_i32 s89, 0x400                                       ; b0590400
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s82, s82, s80                                      ; 8c525052
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mov_b32 s84, src_scc                                      ; bed400fd
	s_min_i32 s23, s23, s74                                     ; 89174a17
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s23, 0                                         ; bf048017
	s_cselect_b32 s85, -1, 0                                    ; 985580c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s85, s85, s79                                      ; 8c554f55
	s_cmp_ge_i32 s74, s54                                       ; bf03364a
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_cselect_b32 s86, -1, 0                                    ; 985680c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s85, s85, s86                                      ; 8c555655
	s_mov_b32 s87, src_scc                                      ; bed700fd
	s_min_i32 s71, s71, s74                                     ; 89474a47
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s71, 0                                         ; bf048047
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s88, -1, 0                                    ; 985880c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s88, s88, s83                                      ; 8c585358
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s88, s88, s86                                      ; 8c585658
	s_wait_loadcnt 0x11                                         ; bfc00011
	v_cndmask_b32_e64 v80, v18, 0, s78                          ; d5010050 01390112
	v_cndmask_b32_e64 v81, v19, 0, s78                          ; d5010051 01390113
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_cndmask_b32_e64 v19, v21, 0, s78                          ; d5010013 01390115
	v_cndmask_b32_e64 v18, v20, 0, s78                          ; d5010012 01390114
	ds_store_2addr_b64 v35, v[80:81], v[18:19] offset1:32       ; d9382000 00125023
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_cndmask_b32_e64 v19, v23, 0, s82                          ; d5010013 01490117
	v_cndmask_b32_e64 v18, v22, 0, s82                          ; d5010012 01490116
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_cndmask_b32_e64 v21, v13, 0, s82                          ; d5010015 0149010d
	v_cndmask_b32_e64 v20, v12, 0, s82                          ; d5010014 0149010c
	ds_store_2addr_b64 v76, v[18:19], v[20:21] offset1:32       ; d9382000 0014124c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_cndmask_b32_e64 v13, v25, 0, s85                          ; d501000d 01550119
	v_cndmask_b32_e64 v12, v24, 0, s85                          ; d501000c 01550118
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_cndmask_b32_e64 v19, v15, 0, s85                          ; d5010013 0155010f
	v_cndmask_b32_e64 v18, v14, 0, s85                          ; d5010012 0155010e
	ds_store_2addr_b64 v77, v[12:13], v[18:19] offset1:32       ; d9382000 00120c4d
	s_wait_loadcnt 0xb                                          ; bfc0000b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v13, v27, 0, s88                          ; d501000d 0161011b
	v_cndmask_b32_e64 v12, v26, 0, s88                          ; d501000c 0161011a
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cndmask_b32_e64 v15, v17, 0, s88                          ; d501000f 01610111
	v_cndmask_b32_e64 v14, v16, 0, s88                          ; d501000e 01610110
	ds_store_2addr_b64 v78, v[12:13], v[14:15] offset1:32       ; d9382000 000e0c4e
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[12:13], v79                                   ; d9d80000 0c00004f
	ds_load_b64 v[14:15], v79 offset:2048                       ; d9d80800 0e00004f
	ds_load_b64 v[16:17], v79 offset:4096                       ; d9d81000 1000004f
	ds_load_b64 v[18:19], v79 offset:6144                       ; d9d81800 1200004f
	ds_load_b64 v[20:21], v79 offset:256                        ; d9d80100 1400004f
	ds_load_b64 v[22:23], v79 offset:2304                       ; d9d80900 1600004f
	ds_load_b64 v[24:25], v79 offset:4352                       ; d9d81100 1800004f
	ds_load_b64 v[26:27], v79 offset:6400                       ; d9d81900 1a00004f
	ds_load_b64 v[80:81], v79 offset:512                        ; d9d80200 5000004f
	ds_load_b64 v[82:83], v79 offset:2560                       ; d9d80a00 5200004f
	v_mov_b32_e32 v29, v34                                      ; 7e3a0322
	v_dual_mov_b32 v85, v35 :: v_dual_mov_b32 v84, v10          ; ca100123 5554010a
	s_wait_loadcnt_dscnt 0x909                                  ; bfc80909
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[12:13], 0 ; cc464058 1a021924
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[12:13], 0 ; cc464060 1a021926
	s_wait_loadcnt_dscnt 0x808                                  ; bfc80808
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[40:41], v[14:15], 0 ; cc464088 1a021d28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[12:13], 0 ; cc464070 1a02192a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[36:37], v[14:15], 0 ; cc464078 1a021d24
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[38:39], v[14:15], 0 ; cc464080 1a021d26
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[14:15], 0 ; cc464090 1a021d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[12:13], 0 ; cc464068 1a021928
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[16:17], 0 ; cc4640b0 1a02212a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[36:37], v[16:17], 0 ; cc464098 1a022124
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[16:17], 0 ; cc4640a8 1a022128
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[38:39], v[16:17], 0 ; cc4640a0 1a022126
	v_mov_b32_e32 v17, v32                                      ; 7e220320
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[36:37], v[18:19], 0 ; cc4640b8 1a022524
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[38:39], v[18:19], 0  ; cc464009 1a022526
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[40:41], v[18:19], 0 ; cc464020 1a022528
	v_dual_mov_b32 v41, v19 :: v_dual_mov_b32 v40, v18          ; ca100113 29280112
	s_wait_loadcnt_dscnt 0x705                                  ; bfc80705
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[20:21], v[88:95] ; cc464058 1d62292c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[20:21], v[96:103] ; cc464060 1d82292e
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[20:21], v[112:119] ; cc464070 1dc22932
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[22:23], v[120:127] ; cc464078 1de22d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[22:23], v[128:135] ; cc464080 1e022d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[48:49], v[22:23], v[136:143] ; cc464088 1e222d30
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[50:51], v[22:23], v[144:151] ; cc464090 1e422d32
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[20:21], v[104:111] ; cc464068 1da22930
	s_wait_dscnt 0x3                                            ; bfc60003
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[44:45], v[24:25], v[152:159] ; cc464098 1e62312c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[50:51], v[24:25], v[176:183] ; cc4640b0 1ec23132
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[48:49], v[24:25], v[168:175] ; cc4640a8 1ea23130
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[46:47], v[24:25], v[160:167] ; cc4640a0 1e82312e
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[42:43], v[40:41], 0 ; cc464012 1a02512a
	s_wait_loadcnt_dscnt 0x501                                  ; bfc80501
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[80:81], v[88:95] ; cc464058 1d62a134
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[54:55], v[80:81], v[96:103] ; cc464060 1d82a136
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[52:53], v[82:83], v[120:127] ; cc464078 1de2a534
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[80:81], v[112:119] ; cc464070 1dc2a13a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[82:83], v[128:135] ; cc464080 1e02a536
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[56:57], v[82:83], v[136:143] ; cc464088 1e22a538
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[58:59], v[82:83], v[144:151] ; cc464090 1e42a53a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[56:57], v[80:81], v[104:111] ; cc464068 1da2a138
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[44:45], v[26:27], v[184:191] ; cc4640b8 1ee2352c
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[46:47], v[26:27], v[9:16] ; cc464009 1c26352e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[48:49], v[26:27], v[32:39] ; cc464020 1c823530
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[50:51], v[26:27], v[18:25] ; cc464012 1c4a3532
	ds_load_b64 v[40:41], v79 offset:4608                       ; d9d81200 2800004f
	ds_load_b64 v[42:43], v79 offset:6656                       ; d9d81a00 2a00004f
	ds_load_b64 v[80:81], v79 offset:768                        ; d9d80300 5000004f
	ds_load_b64 v[82:83], v79 offset:2816                       ; d9d80b00 5200004f
	ds_load_b64 v[44:45], v79 offset:4864                       ; d9d81300 2c00004f
	ds_load_b64 v[46:47], v79 offset:6912                       ; d9d81b00 2e00004f
	ds_load_b64 v[48:49], v79 offset:1024                       ; d9d80400 3000004f
	ds_load_b64 v[26:27], v79 offset:3072                       ; d9d80c00 1a00004f
	ds_load_b64 v[50:51], v79 offset:5120                       ; d9d81400 3200004f
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[54:55], v[40:41], v[160:167] ; cc4640a0 1e825136
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[56:57], v[40:41], v[168:175] ; cc4640a8 1ea25138
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[40:41], v[152:159] ; cc464098 1e625134
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[58:59], v[40:41], v[176:183] ; cc4640b0 1ec2513a
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[56:57], v[42:43], v[32:39] ; cc464020 1c825538
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[54:55], v[42:43], v[9:16] ; cc464009 1c265536
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[52:53], v[42:43], v[184:191] ; cc4640b8 1ee25534
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[58:59], v[42:43], v[18:25] ; cc464012 1c4a553a
	ds_load_b64 v[40:41], v79 offset:7168                       ; d9d81c00 2800004f
	ds_load_b64 v[52:53], v79 offset:1280                       ; d9d80500 3400004f
	ds_load_b64 v[54:55], v79 offset:3328                       ; d9d80d00 3600004f
	ds_load_b64 v[56:57], v79 offset:5376                       ; d9d81500 3800004f
	ds_load_b64 v[42:43], v79 offset:7424                       ; d9d81d00 2a00004f
	ds_load_b64 v[58:59], v79 offset:1536                       ; d9d80600 3a00004f
	s_wait_loadcnt_dscnt 0x30c                                  ; bfc8030c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[60:61], v[80:81], v[88:95] ; cc464058 1d62a13c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[62:63], v[80:81], v[96:103] ; cc464060 1d82a13e
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[60:61], v[82:83], v[120:127] ; cc464078 1de2a53c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[82:83], v[128:135] ; cc464080 1e02a53e
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[62:63], v[44:45], v[160:167] ; cc4640a0 1e82593e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[60:61], v[44:45], v[152:159] ; cc464098 1e62593c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[62:63], v[46:47], v[9:16] ; cc464009 1c265d3e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[64:65], v[44:45], v[168:175] ; cc4640a8 1ea25940
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[64:65], v[46:47], v[32:39] ; cc464020 1c825d40
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[60:61], v[46:47], v[184:191] ; cc4640b8 1ee25d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[66:67], v[44:45], v[176:183] ; cc4640b0 1ec25942
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[66:67], v[46:47], v[18:25] ; cc464012 1c4a5d42
	ds_load_b64 v[60:61], v79 offset:3584                       ; d9d80e00 3c00004f
	ds_load_b64 v[44:45], v79 offset:5632                       ; d9d81600 2c00004f
	ds_load_b64 v[46:47], v79 offset:7680                       ; d9d81e00 2e00004f
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[64:65], v[80:81], v[104:111] ; cc464068 1da2a140
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[64:65], v[82:83], v[136:143] ; cc464088 1e22a540
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[80:81], v[112:119] ; cc464070 1dc2a142
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[66:67], v[82:83], v[144:151] ; cc464090 1e42a542
	s_wait_loadcnt_dscnt 0x10b                                  ; bfc8010b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[48:49], v[88:95] ; cc464058 1d626144
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[26:27], v[120:127] ; cc464078 1de23544
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[68:69], v[50:51], v[152:159] ; cc464098 1e626544
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[48:49], v[96:103] ; cc464060 1d826146
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[26:27], v[128:135] ; cc464080 1e023546
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[70:71], v[50:51], v[160:167] ; cc4640a0 1e826546
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[70:71], v[40:41], v[9:16] ; cc464009 1c265146
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[68:69], v[40:41], v[184:191] ; cc4640b8 1ee25144
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[50:51], v[168:175] ; cc4640a8 1ea26548
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[72:73], v[40:41], v[32:39] ; cc464020 1c825148
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[48:49], v[104:111] ; cc464068 1da26148
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[72:73], v[26:27], v[136:143] ; cc464088 1e223548
	v_dual_mov_b32 v63, v75 :: v_dual_mov_b32 v62, v74          ; ca10014b 3f3e014a
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[64:67], v30, s[28:31], null offen offset:2560 ; c405c07c 40803840 000a001e
	buffer_load_b128 v[68:71], v17, s[28:31], null offen offset:2560 ; c405c07c 40803844 000a0011
	buffer_load_b128 v[80:83], v30, s[28:31], null offen offset:3072 ; c405c07c 40803850 000c001e
	buffer_load_b128 v[72:75], v17, s[28:31], null offen offset:3072 ; c405c07c 40803848 000c0011
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[48:49], v[112:119] ; cc464070 1dc2613e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[62:63], v[50:51], v[176:183] ; cc4640b0 1ec2653e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[62:63], v[26:27], v[144:151] ; cc464090 1e42353e
	ds_load_b64 v[48:49], v79 offset:1792                       ; d9d80700 3000004f
	ds_load_b64 v[26:27], v79 offset:3840                       ; d9d80f00 1a00004f
	ds_load_b64 v[50:51], v79 offset:5888                       ; d9d81700 3200004f
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[62:63], v[40:41], v[18:25] ; cc464012 1c4a513e
	v_dual_mov_b32 v41, v85 :: v_dual_mov_b32 v40, v84          ; ca100155 29280154
	buffer_load_b128 v[84:87], v30, s[28:31], null offen offset:3584 ; c405c07c 40803854 000e001e
	ds_load_b64 v[62:63], v79 offset:7936                       ; d9d81f00 3e00004f
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[52:53], v[88:95] ; cc464058 1d626940
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[56:57], v[152:159] ; cc464098 1e627140
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[42:43], v[184:191] ; cc4640b8 1ee25540
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[52:53], v[96:103] ; cc464060 1d826942
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[54:55], v[128:135] ; cc464080 1e026d42
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[54:55], v[120:127] ; cc464078 1de26d40
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[56:57], v[160:167] ; cc4640a0 1e827142
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[66:67], v[42:43], v[9:16] ; cc464009 1c265542
	buffer_load_b128 v[64:67], v17, s[28:31], null offen offset:3584 ; c405c07c 40803840 000e0011
	v_mad_u32_u24 v79, s19, 0x50, v29                           ; d60b004f 0475fe13 00000050
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[56:57], v[168:175] ; cc4640a8 1ea27144
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[68:69], v[42:43], v[32:39] ; cc464020 1c825544
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[54:55], v[136:143] ; cc464088 1e226d44
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[52:53], v[104:111] ; cc464068 1da26944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[52:53], v[112:119] ; cc464070 1dc26946
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[54:55], v[144:151] ; cc464090 1e426d46
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[56:57], v[176:183] ; cc4640b0 1ec27146
	ds_load_b64 v[68:69], v79                                   ; d9d80000 4400004f
	ds_load_b64 v[52:53], v79 offset:2048                       ; d9d80800 3400004f
	ds_load_b64 v[54:55], v79 offset:4096                       ; d9d81000 3600004f
	ds_load_b64 v[56:57], v79 offset:6144                       ; d9d81800 3800004f
	v_add_nc_u32_e32 v17, 4, v28                                ; 4a223884
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[70:71], v[42:43], v[18:25] ; cc464012 1c4a5546
	v_mov_b32_e32 v70, v41                                      ; 7e8c0329
	v_sub_nc_u32_e32 v30, 0, v17                                ; 4c3c2280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v30, v17, v30                                 ; 243c3d11
	v_med3_i32 v17, -1, v17, 1                                  ; d6200011 020622c1
	v_lshrrev_b32_e32 v30, 1, v30                               ; 323c3c81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; d72c0011
	v_cndmask_b32_e32 v1, v17, v30, vcc_lo                      ; 02023d11
	v_mov_b32_e32 v30, v40                                      ; 7e3c0328
	v_lshl_add_u32 v17, v17, 10, s42                            ; d6460011 00a91511
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v17, v17, v31, 2                             ; d6470011 020a3f11
	buffer_load_b128 v[40:43], v17, s[28:31], null offen        ; c405c07c 40803828 00000011
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[80:81], v[58:59], v[88:95] ; cc464058 1d627550
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[60:61], v[120:127] ; cc464078 1de27950
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[80:81], v[44:45], v[152:159] ; cc464098 1e625950
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[80:81], v[46:47], v[184:191] ; cc4640b8 1ee25d50
	v_add_nc_u32_e32 v28, 6, v28                                ; 4a383886
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[82:83], v[58:59], v[96:103] ; cc464060 1d827552
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[60:61], v[128:135] ; cc464080 1e027952
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[82:83], v[44:45], v[160:167] ; cc4640a0 1e825952
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[82:83], v[46:47], v[9:16] ; cc464009 1c265d52
	v_sub_nc_u32_e32 v71, 0, v28                                ; 4c8e3880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_max_i32_e32 v71, v28, v71                                 ; 248e8f1c
	v_med3_i32 v28, -1, v28, 1                                  ; d620001c 020638c1
	v_lshrrev_b32_e32 v71, 1, v71                               ; 328e8e81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c001c
	v_cndmask_b32_e32 v1, v28, v71, vcc_lo                      ; 02028f1c
	v_lshl_add_u32 v28, v28, 10, s42                            ; d646001c 00a9151c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v28, v28, v31, 2                             ; d647001c 020a3f1c
	buffer_load_b128 v[80:83], v28, s[28:31], null offen        ; c405c07c 40803850 0000001c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[58:59], v[104:111] ; cc464068 1da27548
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[72:73], v[60:61], v[136:143] ; cc464088 1e227948
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[44:45], v[168:175] ; cc4640a8 1ea25948
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[58:59], v[112:119] ; cc464070 1dc2754a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[74:75], v[60:61], v[144:151] ; cc464090 1e42794a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[74:75], v[44:45], v[176:183] ; cc4640b0 1ec2594a
	ds_load_b64 v[58:59], v79 offset:256                        ; d9d80100 3a00004f
	ds_load_b64 v[60:61], v79 offset:2304                       ; d9d80900 3c00004f
	ds_load_b64 v[44:45], v79 offset:4352                       ; d9d81100 2c00004f
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[72:73], v[46:47], v[32:39] ; cc464020 1c825d48
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[74:75], v[46:47], v[18:25] ; cc464012 1c4a5d4a
	s_wait_loadcnt_dscnt 0x30a                                  ; bfc8030a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[84:85], v[48:49], v[88:95] ; cc464058 1d626154
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[84:85], v[26:27], v[120:127] ; cc464078 1de23554
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[84:85], v[50:51], v[152:159] ; cc464098 1e626554
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[84:85], v[62:63], v[184:191] ; cc4640b8 1ee27d54
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[86:87], v[48:49], v[96:103] ; cc464060 1d826156
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[86:87], v[26:27], v[128:135] ; cc464080 1e023556
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[86:87], v[50:51], v[160:167] ; cc4640a0 1e826556
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[86:87], v[62:63], v[9:16] ; cc464009 1c267d56
	v_maxmin_num_f32 v86, -4.0, v91, 4.0                        ; d6690056 03dab6f7
	v_maxmin_num_f32 v84, -4.0, v90, 4.0                        ; d6690054 03dab4f7
	v_maxmin_num_f32 v74, -4.0, v89, 4.0                        ; d669004a 03dab2f7
	v_maxmin_num_f32 v72, -4.0, v88, 4.0                        ; d6690048 03dab0f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_fma_mix_f32 v75, 0xab28, |v74|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624b 0bfe94ff 3728ab28
	v_fma_mix_f32 v73, 0xab28, |v72|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206249 0bfe90ff 3728ab28
	v_dual_fmaak_f32 v86, v86, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v84, 0x3f650000 ; c842af56 5654a955 3f650000
	v_maxmin_num_f32 v71, -4.0, v95, 4.0                        ; d6690047 03dabef7
	v_dual_fmaak_f32 v75, v75, v74, 0x3f650000 :: v_dual_fmaak_f32 v72, v72, v73, 0x3f650000 ; c842954b 4b489348 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_mul_f32 v91, v91, v86 :: v_dual_mul_f32 v90, v90, v85 ; c8c6ad5b 5b5aab5a
	v_dual_mul_f32 v89, v89, v75 :: v_dual_mul_f32 v88, v88, v72 ; c8c69759 59589158
	v_fma_mix_f32 v72, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe8eff 3728ab28
	v_maxmin_num_f32 v73, -4.0, v120, 4.0                       ; d6690049 03daf0f7
	v_maxmin_num_f32 v75, -4.0, v121, 4.0                       ; d669004b 03daf2f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v92, 4.0                        ; d6690058 03dab8f7
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v90, -4.0, v93, 4.0                        ; d669005a 03dabaf7
	v_fmaak_f32 v71, v71, v72, 0x3f650000                       ; 5a8e9147 3f650000
	v_fma_mix_f32 v74, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe92ff 3728ab28
	v_fma_mix_f32 v84, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfe96ff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v122, 4.0                       ; d6690055 03daf4f7
	v_maxmin_num_f32 v87, -4.0, v123, 4.0                       ; d6690057 03daf6f7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_dual_fmaak_f32 v73, v73, v74, 0x3f650000 :: v_dual_fmaak_f32 v84, v84, v75, 0x3f650000 ; c8429549 49549754 3f650000
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842b55b 5b58b358 3f650000
	v_maxmin_num_f32 v89, -4.0, v124, 4.0                       ; d6690059 03daf8f7
	v_dual_mul_f32 v121, v121, v84 :: v_dual_mul_f32 v120, v120, v73 ; c8c6a979 79789378
	v_dual_mul_f32 v93, v93, v91 :: v_dual_mul_f32 v92, v92, v88 ; c8c6b75d 5d5cb15c
	v_maxmin_num_f32 v91, -4.0, v125, 4.0                       ; d669005b 03dafaf7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v92, -4.0, v94, 4.0                        ; d669005c 03dabcf7
	v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842b157 5756ab56 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_mul_f32 v123, v123, v87 :: v_dual_mul_f32 v122, v122, v86 ; c8c6af7b 7b7aad7a
	v_maxmin_num_f32 v121, -4.0, v152, 4.0                      ; d6690079 03db30f7
	v_fmaak_f32 v93, v93, v92, 0x3f650000                       ; 5abab95d 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v123, -4.0, v153, 4.0                      ; d669007b 03db32f7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_dual_mul_f32 v95, v95, v71 :: v_dual_mul_f32 v94, v94, v93 ; c8c68f5f 5f5ebb5e
	v_maxmin_num_f32 v93, -4.0, v126, 4.0                       ; d669005d 03dafcf7
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c842b75c 5c58b559 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v127, 4.0                       ; d669005f 03dafef7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_mul_f32 v125, v125, v92 :: v_dual_mul_f32 v124, v124, v89 ; c8c6b97d 7d7cb37c
	v_fma_mix_f32 v120, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfebeff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v125, -4.0, v154, 4.0                      ; d669007d 03db34f7
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_fmaak_f32 v95, v95, v120, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842f15f 5f5ebb5e 3f650000
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c842f579 797cf77c 3f650000
	v_dual_mul_f32 v127, v127, v95 :: v_dual_mul_f32 v126, v126, v94 ; c8c6bf7f 7f7ebd7e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v153, v153, v124 :: v_dual_mul_f32 v152, v152, v121 ; c8c6f999 9998f398
	v_maxmin_num_f32 v84, -4.0, v158, 4.0                       ; d6690054 03db3cf7
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v127, -4.0, v155, 4.0                      ; d669007f 03db36f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v86, -4.0, v159, 4.0                       ; d6690056 03db3ef7
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v153, -4.0, v156, 4.0                      ; d6690099 03db38f7
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_maxmin_num_f32 v90, -4.0, v185, 4.0                       ; d669005a 03db72f7
	v_fma_mix_f32 v152, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bfefeff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v184, 4.0                       ; d6690058 03db70f7
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v186, 4.0                       ; d669005c 03db74f7
	v_dual_fmaak_f32 v127, v127, v152, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 ; c843317f 7f7efb7e 3f650000
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v94, -4.0, v187, 4.0                       ; d669005e 03db76f7
	v_dual_fmaak_f32 v85, v85, v84, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v87, 0x3f650000 ; c842a955 5556af56 3f650000
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_mul_f32 v155, v155, v127 :: v_dual_mul_f32 v154, v154, v126 ; c8c6ff9b 9b9afd9a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[64:65], v[48:49], v[104:111] ; cc464068 1da26140
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_mul_f32 v158, v158, v85 ; c846b55b 5b9eab9e 3f650000
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v155, -4.0, v157, 4.0                      ; d669009b 03db3af7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[64:65], v[26:27], v[136:143] ; cc464088 1e223540
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[64:65], v[50:51], v[168:175] ; cc4640a8 1ea26540
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[64:65], v[62:63], v[32:39] ; cc464020 1c827d40
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[48:49], v[112:119] ; cc464070 1dc26142
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[66:67], v[26:27], v[144:151] ; cc464090 1e423542
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[66:67], v[50:51], v[176:183] ; cc4640b0 1ec26542
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c842b95d 5d5ebf5e 3f650000
	v_dual_mul_f32 v185, v185, v91 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c8c2b7b9 b958b358 3f650000
	v_fma_mix_f32 v71, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bff36ff 3728ab28
	v_fmaak_f32 v153, v153, v154, 0x3f650000                    ; 5b333599 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[66:67], v[62:63], v[18:25] ; cc464012 1c4a7d42
	v_maxmin_num_f32 v122, -4.0, v189, 4.0                      ; d669007a 03db7af7
	v_maxmin_num_f32 v120, -4.0, v188, 4.0                      ; d6690078 03db78f7
	v_maxmin_num_f32 v124, -4.0, v190, 4.0                      ; d669007c 03db7cf7
	v_dual_mul_f32 v187, v187, v94 :: v_dual_mul_f32 v184, v184, v88 ; c8c6bdbb bbb8b1b8
	v_fmaak_f32 v71, v71, v155, 0x3f650000                      ; 5a8f3747 3f650000
	v_dual_mul_f32 v159, v159, v86 :: v_dual_mul_f32 v156, v156, v153 ; c8c6ad9f 9f9d339c
	v_maxmin_num_f32 v126, -4.0, v191, 4.0                      ; d669007e 03db7ef7
	v_maxmin_num_f32 v154, -4.0, v97, 4.0                       ; d669009a 03dac2f7
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v96, 4.0                       ; d6690098 03dac0f7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_mul_f32_e32 v157, v157, v71                               ; 113a8f9d
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 :: v_dual_mul_f32 v186, v186, v93 ; c846f57b 7bbabbba 3f650000
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_maxmin_num_f32 v156, -4.0, v98, 4.0                       ; d669009c 03dac4f7
	v_maxmin_num_f32 v158, -4.0, v99, 4.0                       ; d669009e 03dac6f7
	v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 :: v_dual_fmaak_f32 v126, v126, v127, 0x3f650000 ; c842f97d 7d7eff7e 3f650000
	v_dual_mul_f32 v189, v189, v123 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c8c2f7bd bd78f378 3f650000
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_maxmin_num_f32 v186, -4.0, v101, 4.0                      ; d66900ba 03dacaf7
	v_maxmin_num_f32 v184, -4.0, v100, 4.0                      ; d66900b8 03dac8f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_mul_f32 v190, v190, v125 ; c847359b 9bbefbbe 3f650000
	v_dual_mul_f32 v191, v191, v126 :: v_dual_mul_f32 v188, v188, v120 ; c8c6fdbf bfbcf1bc
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c843399d 9d9f3f9e 3f650000
	v_dual_mul_f32 v97, v97, v155 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c8c33761 61993398 3f650000
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_maxmin_num_f32 v188, -4.0, v102, 4.0                      ; d66900bc 03daccf7
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_maxmin_num_f32 v190, -4.0, v103, 4.0                      ; d66900be 03dacef7
	v_maxmin_num_f32 v51, -4.0, v129, 4.0                       ; d6690033 03db02f7
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_mul_f32 v98, v98, v157 ; c84775bb bb633b62 3f650000
	v_maxmin_num_f32 v65, -4.0, v131, 4.0                       ; d6690041 03db06f7
	v_dual_mul_f32 v99, v99, v158 :: v_dual_mul_f32 v96, v96, v152 ; c8c73d63 63613160
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v67, -4.0, v132, 4.0                       ; d6690043 03db08f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_fma_mix_f32 v62, 0xab28, |v51|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623e 0bfe66ff 3728ab28
	v_dual_mul_f32 v101, v101, v187 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8c37765 65b973b8 3f650000
	v_fma_mix_f32 v66, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206242 0bfe82ff 3728ab28
	v_maxmin_num_f32 v63, -4.0, v130, 4.0                       ; d669003f 03db04f7
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_fma_mix_f32 v71, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206247 0bfe86ff 3728ab28
	v_maxmin_num_f32 v84, -4.0, v133, 4.0                       ; d6690054 03db0af7
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c84379bd bdbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v128, 4.0                      ; d66900bf 03db00f7
	v_maxmin_num_f32 v86, -4.0, v134, 4.0                       ; d6690056 03db0cf7
	v_fma_mix_f32 v64, 0xab28, |v63|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206240 0bfe7eff 3728ab28
	v_maxmin_num_f32 v88, -4.0, v135, 4.0                       ; d6690058 03db0ef7
	v_fmaak_f32 v67, v67, v71, 0x3f650000                       ; 5a868f43 3f650000
	v_fma_mix_f32 v85, 0xab28, |v84|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206255 0bfea8ff 3728ab28
	v_dual_fmaak_f32 v65, v65, v66, 0x3f650000 :: v_dual_mul_f32 v102, v102, v189 ; c8468541 41677b66 3f650000
	v_dual_mul_f32 v103, v103, v190 :: v_dual_mul_f32 v100, v100, v184 ; c8c77d67 67657164
	v_fma_mix_f32 v50, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206232 0bff7eff 3728ab28
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_maxmin_num_f32 v92, -4.0, v161, 4.0                       ; d669005c 03db42f7
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_maxmin_num_f32 v90, -4.0, v160, 4.0                       ; d669005a 03db40f7
	v_dual_fmaak_f32 v85, v85, v84, 0x3f650000 :: v_dual_fmaak_f32 v64, v64, v63, 0x3f650000 ; c842a955 55407f40 3f650000
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v94, -4.0, v162, 4.0                       ; d669005e 03db44f7
	v_dual_fmaak_f32 v191, v191, v50, 0x3f650000 :: v_dual_fmaak_f32 v62, v62, v51, 0x3f650000 ; c84265bf bf3e673e 3f650000
	v_maxmin_num_f32 v96, -4.0, v163, 4.0                       ; d6690060 03db46f7
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_dual_fmaak_f32 v87, v87, v86, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 ; c842ad57 5758b358 3f650000
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_dual_mul_f32 v133, v133, v85 :: v_dual_mul_f32 v130, v130, v64 ; c8c6ab85 85828182
	v_maxmin_num_f32 v100, -4.0, v165, 4.0                      ; d6690064 03db4af7
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_mul_f32_e32 v129, v129, v62                               ; 11027d81
	v_dual_mul_f32 v131, v131, v65 :: v_dual_mul_f32 v128, v128, v191 ; c8c68383 83817f80
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_maxmin_num_f32 v98, -4.0, v164, 4.0                       ; d6690062 03db48f7
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_mul_f32 v134, v134, v87 ; c846b95d 5d86af86 3f650000
	v_dual_mul_f32 v135, v135, v88 :: v_dual_mul_f32 v132, v132, v67 ; c8c6b187 87848784
	v_maxmin_num_f32 v102, -4.0, v166, 4.0                      ; d6690066 03db4cf7
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_maxmin_num_f32 v120, -4.0, v167, 4.0                      ; d6690078 03db4ef7
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v97, 0x3f650000 ; c842bd5f 5f60c360 3f650000
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_maxmin_num_f32 v122, -4.0, v9, 4.0                        ; d669007a 03da12f7
	v_dual_mul_f32 v161, v161, v93 :: v_dual_fmaak_f32 v90, v90, v91, 0x3f650000 ; c8c2bba1 a15ab75a 3f650000
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_maxmin_num_f32 v124, -4.0, v10, 4.0                       ; d669007c 03da14f7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_dual_fmaak_f32 v101, v101, v100, 0x3f650000 :: v_dual_mul_f32 v162, v162, v95 ; c846c965 65a2bfa2 3f650000
	v_maxmin_num_f32 v126, -4.0, v11, 4.0                       ; d669007e 03da16f7
	v_maxmin_num_f32 v130, -4.0, v13, 4.0                       ; d6690082 03da1af7
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_dual_mul_f32 v163, v163, v96 :: v_dual_mul_f32 v160, v160, v90 ; c8c6c1a3 a3a0b5a0
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_maxmin_num_f32 v128, -4.0, v12, 4.0                       ; d6690080 03da18f7
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c842cd67 6778f378 3f650000
	v_dual_mul_f32 v165, v165, v101 :: v_dual_fmaak_f32 v98, v98, v99, 0x3f650000 ; c8c2cba5 a562c762 3f650000
	v_maxmin_num_f32 v132, -4.0, v14, 4.0                       ; d6690084 03da1cf7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_maxmin_num_f32 v134, -4.0, v15, 4.0                       ; d6690086 03da1ef7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 :: v_dual_mul_f32 v166, v166, v103 ; c846f97d 7da6cfa6 3f650000
	v_dual_mul_f32 v167, v167, v120 :: v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 ; c8c2f1a7 a77af77a 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v16, 4.0                       ; d6690098 03da20f7
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c842fd7f 7f830782 3f650000
	v_maxmin_num_f32 v156, -4.0, v105, 4.0                      ; d669009c 03dad2f7
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_mul_f32 v9, v122, v9 :: v_dual_mul_f32 v164, v164, v98 ; c8c6137a 09a4c5a4
	v_maxmin_num_f32 v158, -4.0, v106, 4.0                      ; d669009e 03dad4f7
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430985 85810380 3f650000
	v_maxmin_num_f32 v160, -4.0, v107, 4.0                      ; d66900a0 03dad6f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_mul_f32 v13, v13, v130 :: v_dual_mul_f32 v10, v10, v125 ; c8c7050d 0d0afb0a
	v_mul_f32_e32 v11, v11, v127                                ; 1016ff0b
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v154, -4.0, v104, 4.0                      ; d669009a 03dad0f7
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_mul_f32 v12, v12, v128 ; c8470d87 870d010c 3f650000
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v109, 4.0                      ; d66900a4 03dadaf7
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                       ; 02021509
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843399d 9d993398 3f650000
	v_maxmin_num_f32 v166, -4.0, v110, 4.0                      ; d66900a6 03dadcf7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v111, 4.0                      ; d66900b8 03dadef7
	v_dual_mul_f32 v15, v15, v135 :: v_dual_mul_f32 v14, v14, v133 ; c8c70f0f 0f0f0b0e
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v11, v12, vcc_lo                      ; 0202190b
	v_maxmin_num_f32 v162, -4.0, v108, 4.0                      ; d66900a2 03dad8f7
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c8433d9f 9fa143a0 3f650000
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_mul_f32 v105, v105, v157 :: v_dual_mul_f32 v16, v16, v152 ; c8c73b69 69113110
	v_maxmin_num_f32 v188, -4.0, v137, 4.0                      ; d66900bc 03db12f7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v138, 4.0                      ; d66900be 03db14f7
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                      ; 02021d0d
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_mul_f32 v107, v107, v160 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8c3416b 6b9b379a 3f650000
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v15, v16, vcc_lo                      ; 0202210f
	v_maxmin_num_f32 v186, -4.0, v136, 4.0                      ; d66900ba 03db10f7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8434da7 a7b973b8 3f650000
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_mul_f32 v104, v104, v154 ; c84749a5 a5693568 3f650000
	v_maxmin_num_f32 v13, -4.0, v140, 4.0                       ; d669000d 03db18f7
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v15, -4.0, v141, 4.0                       ; d669000f 03db1af7
	v_dual_mul_f32 v111, v111, v184 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8c3716f 6fa347a2 3f650000
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_mul_f32 v110, v110, v167 ; c8477dbf bf6f4f6e 3f650000
	v_dual_mul_f32 v109, v109, v165 :: v_dual_mul_f32 v106, v106, v159 ; c8c74b6d 6d6b3f6a
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_fma_mix_f32 v14, 0xab28, |v13|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20620e 0bfe1aff 3728ab28
	v_maxmin_num_f32 v66, -4.0, v142, 4.0                       ; d6690042 03db1cf7
	v_fma_mix_f32 v16, 0xab28, |v15|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206210 0bfe1eff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v108, v108, v162 ; c84779bd bd6d456c 3f650000
	v_maxmin_num_f32 v71, -4.0, v143, 4.0                       ; d6690047 03db1ef7
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_fma_mix_f32 v67, 0xab28, |v66|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206243 0bfe84ff 3728ab28
	v_dual_fmaak_f32 v13, v13, v14, 0x3f650000 :: v_dual_fmaak_f32 v16, v16, v15, 0x3f650000 ; c8421d0d 0d101f10 3f650000
	v_maxmin_num_f32 v85, -4.0, v168, 4.0                       ; d6690055 03db50f7
	v_dual_mul_f32 v137, v137, v189 :: v_dual_mul_f32 v138, v138, v191 ; c8c77b89 898b7f8a
	v_maxmin_num_f32 v191, -4.0, v139, 4.0                      ; d66900bf 03db16f7
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v84, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfe8eff 3728ab28
	v_maxmin_num_f32 v87, -4.0, v169, 4.0                       ; d6690057 03db52f7
	v_fmaak_f32 v67, v67, v66, 0x3f650000                       ; 5a868543 3f650000
	v_mul_f32_e32 v141, v141, v16                               ; 111a218d
	v_maxmin_num_f32 v89, -4.0, v170, 4.0                       ; d6690059 03db54f7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_fma_mix_f32 v9, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206209 0bff7eff 3728ab28
	v_maxmin_num_f32 v91, -4.0, v171, 4.0                       ; d669005b 03db56f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v71, v71, v84, 0x3f650000 :: v_dual_mul_f32 v142, v142, v67 ; c846a947 478e878e 3f650000
	v_maxmin_num_f32 v93, -4.0, v172, 4.0                       ; d669005d 03db58f7
	v_maxmin_num_f32 v95, -4.0, v173, 4.0                       ; d669005f 03db5af7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_fmaak_f32 v191, v191, v9, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84213bf bfbb77ba 3f650000
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 :: v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 ; c842ad55 5558af58 3f650000
	v_maxmin_num_f32 v97, -4.0, v174, 4.0                       ; d6690061 03db5cf7
	v_dual_mul_f32 v143, v143, v71 :: v_dual_mul_f32 v140, v140, v13 ; c8c68f8f 8f8c1b8c
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v175, 4.0                       ; d6690063 03db5ef7
	v_dual_mul_f32 v139, v139, v191 :: v_dual_mul_f32 v136, v136, v186 ; c8c77f8b 8b897588
	v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b95b 5b5ab35a 3f650000
	v_dual_mul_f32 v169, v169, v88 :: v_dual_mul_f32 v168, v168, v85 ; c8c6b1a9 a9a8aba8
	v_maxmin_num_f32 v101, -4.0, v32, 4.0                       ; d6690065 03da40f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_maxmin_num_f32 v103, -4.0, v33, 4.0                       ; d6690067 03da42f7
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_dual_mul_f32 v171, v171, v91 :: v_dual_mul_f32 v170, v170, v90 ; c8c6b7ab abaab5aa
	v_maxmin_num_f32 v105, -4.0, v34, 4.0                       ; d6690069 03da44f7
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v35, 4.0                       ; d669006b 03da46f7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_mul_f32 v173, v173, v96 :: v_dual_mul_f32 v172, v172, v93 ; c8c6c1ad adacbbac
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 ; c842c963 6362c362 3f650000
	v_maxmin_num_f32 v109, -4.0, v36, 4.0                       ; d669006d 03da48f7
	v_maxmin_num_f32 v111, -4.0, v37, 4.0                       ; d669006f 03da4af7
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v38, 4.0                       ; d6690079 03da4cf7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 :: v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 ; c842cf68 6864cd65 3f650000
	v_maxmin_num_f32 v123, -4.0, v39, 4.0                       ; d669007b 03da4ef7
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_dual_mul_f32 v175, v175, v99 :: v_dual_mul_f32 v174, v174, v98 ; c8c6c7af afaec5ae
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_fma_mix_f32 v120, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfedeff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v112, 4.0                      ; d669007d 03dae0f7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v113, 4.0                      ; d669007f 03dae2f7
	v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 ; c842d96b 6b6ad36a 3f650000
	v_dual_mul_f32 v33, v33, v104 :: v_dual_mul_f32 v32, v32, v101 ; c8c6d121 2120cb20
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_maxmin_num_f32 v129, -4.0, v114, 4.0                      ; d6690081 03dae4f7
	v_dual_fmaak_f32 v120, v120, v111, 0x3f650000 :: v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 ; c842df78 786cdd6d 3f650000
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v115, 4.0                      ; d6690083 03dae6f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_dual_mul_f32 v35, v35, v107 :: v_dual_mul_f32 v34, v34, v106 ; c8c6d723 2322d522
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	v_maxmin_num_f32 v133, -4.0, v116, 4.0                      ; d6690085 03dae8f7
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f97b 7b7af37a 3f650000
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v117, 4.0                      ; d6690087 03daeaf7
	v_dual_mul_f32 v37, v37, v120 :: v_dual_mul_f32 v36, v36, v109 ; c8c6f125 2524db24
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842ff80 807cfd7d 3f650000
	v_maxmin_num_f32 v137, -4.0, v118, 4.0                      ; d6690089 03daecf7
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v119, 4.0                      ; d669008b 03daeef7
	v_dual_mul_f32 v39, v39, v123 :: v_dual_mul_f32 v38, v38, v122 ; c8c6f727 2726f526
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
	v_maxmin_num_f32 v141, -4.0, v144, 4.0                      ; d669008d 03db20f7
	v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 ; c8430983 83830382 3f650000
	v_dual_mul_f32 v113, v113, v128 :: v_dual_mul_f32 v112, v112, v125 ; c8c70171 7170fb70
	v_maxmin_num_f32 v143, -4.0, v145, 4.0                      ; d669008f 03db22f7
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	v_maxmin_num_f32 v153, -4.0, v146, 4.0                      ; d6690099 03db24f7
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430f88 88850d85 3f650000
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v147, 4.0                      ; d669009b 03db26f7
	v_dual_mul_f32 v115, v115, v131 :: v_dual_mul_f32 v114, v114, v130 ; c8c70773 73730572
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_fma_mix_f32 v152, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff1eff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v148, 4.0                      ; d669009d 03db28f7
	v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 ; c843198b 8b8b138a 3f650000
	v_maxmin_num_f32 v159, -4.0, v149, 4.0                      ; d669009f 03db2af7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_mul_f32 v117, v117, v136 :: v_dual_mul_f32 v116, v116, v133 ; c8c71175 75750b74
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v161, -4.0, v150, 4.0                      ; d66900a1 03db2cf7
	v_dual_fmaak_f32 v152, v152, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c8431f98 988d1d8d 3f650000
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v151, 4.0                      ; d66900a3 03db2ef7
	v_dual_mul_f32 v119, v119, v139 :: v_dual_mul_f32 v118, v118, v138 ; c8c71777 77771576
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
	v_maxmin_num_f32 v165, -4.0, v176, 4.0                      ; d66900a5 03db60f7
	v_maxmin_num_f32 v167, -4.0, v177, 4.0                      ; d66900a7 03db62f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_mul_f32 v145, v145, v152 :: v_dual_mul_f32 v144, v144, v141 ; c8c73191 91911b90
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v169, -4.0, v178, 4.0                      ; d66900a9 03db64f7
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c8433fa0 a09d3d9d 3f650000
	v_dual_mul_f32 v147, v147, v155 :: v_dual_mul_f32 v146, v146, v154 ; c8c73793 93933592
	v_maxmin_num_f32 v171, -4.0, v179, 4.0                      ; d66900ab 03db66f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c84349a3 a3a343a2 3f650000
	v_maxmin_num_f32 v173, -4.0, v180, 4.0                      ; d66900ad 03db68f7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_maxmin_num_f32 v175, -4.0, v181, 4.0                      ; d66900af 03db6af7
	v_dual_mul_f32 v149, v149, v160 :: v_dual_mul_f32 v148, v148, v157 ; c8c74195 95953b94
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 ; c8434fa8 a8a54da5 3f650000
	v_dual_mul_f32 v151, v151, v163 :: v_dual_mul_f32 v150, v150, v162 ; c8c74797 97974596
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 ; c84359ab abab53aa 3f650000
	v_dual_mul_f32 v177, v177, v168 :: v_dual_mul_f32 v176, v176, v165 ; c8c751b1 b1b14bb0
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_dual_mul_f32 v179, v179, v171 :: v_dual_mul_f32 v178, v178, v170 ; c8c757b3 b3b355b2
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
	v_maxmin_num_f32 v177, -4.0, v182, 4.0                      ; d66900b1 03db6cf7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_maxmin_num_f32 v179, -4.0, v183, 4.0                      ; d66900b3 03db6ef7
	v_maxmin_num_f32 v187, -4.0, v21, 4.0                       ; d66900bb 03da2af7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 ; c8435dad adb15fb0 3f650000
	v_maxmin_num_f32 v185, -4.0, v20, 4.0                       ; d66900b9 03da28f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v22, 4.0                       ; d66900bd 03da2cf7
	v_dual_mul_f32 v181, v181, v176 :: v_dual_mul_f32 v180, v180, v173 ; c8c761b5 b5b55bb4
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v23, 4.0                       ; d66900bf 03da2ef7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	v_maxmin_num_f32 v181, -4.0, v18, 4.0                       ; d66900b5 03da24f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fma_mix_f32 v9, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206209 0bff7eff 3728ab28
	v_maxmin_num_f32 v16, -4.0, v24, 4.0                        ; d6690010 03da30f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_dual_fmaak_f32 v179, v179, v180, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v177, 0x3f650000 ; c84369b3 b3b363b2 3f650000
	v_dual_mul_f32 v183, v183, v179 :: v_dual_mul_f32 v182, v182, v178 ; c8c767b7 b7b765b6
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_maxmin_num_f32 v183, -4.0, v19, 4.0                       ; d66900b7 03da26f7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	s_wait_loadcnt_dscnt 0x106                                  ; bfc80106
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[68:69], 0 ; cc464058 1a028928
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[52:53], 0 ; cc464060 1a026928
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[54:55], 0 ; cc464068 1a026d28
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c8436fb8 b8b56db5 3f650000
	s_wait_dscnt 0x3                                            ; bfc60003
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[56:57], 0 ; cc464070 1a027128
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_mul_f32 v18, v18, v181 ; c84779bb bb136b12 3f650000
	v_mul_f32_e32 v19, v19, v184                                ; 10277113
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[68:69], 0 ; cc464078 1a02892a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[52:53], 0 ; cc464080 1a02692a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[54:55], 0 ; cc464088 1a026d2a
	v_dual_mul_f32 v21, v21, v187 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c8c37715 15bb73ba 3f650000
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[56:57], 0 ; cc464090 1a02712a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[80:81], v[52:53], 0 ; cc4640a0 1a026950
	v_dual_fmaak_f32 v189, v190, v189, 0x3f650000 :: v_dual_mul_f32 v20, v20, v186 ; c8477bbe bd157514 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[80:81], v[68:69], 0 ; cc464098 1a028950
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[80:81], v[54:55], 0 ; cc4640a8 1a026d50
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[80:81], v[56:57], 0 ; cc4640b0 1a027150
	v_dual_fmaak_f32 v9, v9, v191, 0x3f650000 :: v_dual_mul_f32 v22, v22, v189 ; c8477f09 09177b16 3f650000
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	v_fma_mix_f32 v20, 0xab28, |v16|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206214 0bfe20ff 3728ab28
	v_maxmin_num_f32 v21, -4.0, v25, 4.0                        ; d6690015 03da32f7
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[82:83], v[68:69], 0 ; cc4640b8 1a028952
	v_dual_mul_f32 v23, v23, v9 :: v_dual_fmaak_f32 v20, v20, v16, 0x3f650000 ; c8c21317 17142114 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	v_fma_mix_f32 v22, 0xab28, |v21|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206216 0bfe2aff 3728ab28
	v_dual_fmaak_f32 v21, v21, v22, 0x3f650000 :: v_dual_mul_f32 v24, v24, v20 ; c8462d15 15182918 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_mul_f32 v25, v25, v21 :: v_dual_mov_b32 v40, v18     ; c8d02b19 19280112
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mov_b32 v41, v19 :: v_dual_mov_b32 v42, v82          ; ca100113 292a0152
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[82:83], v[52:53], 0 ; cc464012 1a026952
	v_dual_mov_b32 v52, v64 :: v_dual_mov_b32 v43, v83          ; ca100140 342a0153
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[42:43], v[54:55], 0 ; cc464050 1a026d2a
	v_dual_mov_b32 v54, v70 :: v_dual_mov_b32 v53, v65          ; ca100146 36340141
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[42:43], v[56:57], 0 ; cc464040 1a02712a
	ds_load_b64 v[42:43], v79 offset:6400                       ; d9d81900 2a00004f
	v_mov_b32_e32 v9, v54                                       ; 7e120336
	buffer_load_b128 v[54:57], v17, s[28:31], null offen offset:512 ; c405c07c 40803836 00020011
	s_wait_loadcnt_dscnt 0x3                                    ; bfc80003
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[56:57], v[58:59], v[120:127] ; cc464078 1de27538
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[56:57], v[44:45], v[136:143] ; cc464088 1e225938
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[54:55], v[44:45], v[104:111] ; cc464068 1da25936
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[42:43], v[112:119] ; cc464070 1dc25536
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[54:55], v[60:61], v[96:103] ; cc464060 1d827936
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[54:55], v[58:59], v[88:95] ; cc464058 1d627536
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[42:43], v[144:151] ; cc464090 1e425538
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[60:61], v[128:135] ; cc464080 1e027938
	buffer_load_b128 v[54:57], v28, s[28:31], null offen offset:512 ; c405c07c 40803836 0002001c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[54:55], v[44:45], v[168:175] ; cc4640a8 1ea25936
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[56:57], v[44:45], v[80:87] ; cc464050 1d425938
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[54:55], v[42:43], v[176:183] ; cc4640b0 1ec25536
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[56:57], v[58:59], v[184:191] ; cc4640b8 1ee27538
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[56:57], v[42:43], v[64:71] ; cc464040 1d025538
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[54:55], v[58:59], v[152:159] ; cc464098 1e627536
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[54:55], v[60:61], v[160:167] ; cc4640a0 1e827936
	ds_load_b64 v[54:55], v79 offset:512                        ; d9d80200 3600004f
	ds_load_b64 v[58:59], v79 offset:2560                       ; d9d80a00 3a00004f
	ds_load_b64 v[44:45], v79 offset:4608                       ; d9d81200 2c00004f
	ds_load_b64 v[42:43], v79 offset:6656                       ; d9d81a00 2a00004f
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[56:57], v[60:61], v[18:25] ; cc464012 1c4a7938
	s_wait_dscnt 0x2                                            ; bfc60002
	v_dual_mov_b32 v61, v59 :: v_dual_mov_b32 v60, v58          ; ca10013b 3d3c013a
	buffer_load_b128 v[56:59], v17, s[28:31], null offen offset:1024 ; c405c07c 40803838 00040011
	s_wait_loadcnt_dscnt 0x1                                    ; bfc80001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[56:57], v[44:45], v[104:111] ; cc464068 1da25938
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[56:57], v[42:43], v[112:119] ; cc464070 1dc25538
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[58:59], v[54:55], v[120:127] ; cc464078 1de26d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[60:61], v[128:135] ; cc464080 1e02793a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[58:59], v[44:45], v[136:143] ; cc464088 1e22593a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[56:57], v[60:61], v[96:103] ; cc464060 1d827938
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[58:59], v[42:43], v[144:151] ; cc464090 1e42553a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[54:55], v[88:95] ; cc464058 1d626d38
	buffer_load_b128 v[56:59], v28, s[28:31], null offen offset:1024 ; c405c07c 40803838 0004001c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[54:55], v[152:159] ; cc464098 1e626d38
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[56:57], v[60:61], v[160:167] ; cc4640a0 1e827938
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[58:59], v[44:45], v[80:87] ; cc464050 1d42593a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[58:59], v[42:43], v[64:71] ; cc464040 1d02553a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[56:57], v[44:45], v[168:175] ; cc4640a8 1ea25938
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[56:57], v[42:43], v[176:183] ; cc4640b0 1ec25538
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[58:59], v[54:55], v[184:191] ; cc4640b8 1ee26d3a
	ds_load_b64 v[54:55], v79 offset:768                        ; d9d80300 3600004f
	ds_load_b64 v[56:57], v79 offset:2816                       ; d9d80b00 3800004f
	ds_load_b64 v[44:45], v79 offset:4864                       ; d9d81300 2c00004f
	ds_load_b64 v[42:43], v79 offset:6912                       ; d9d81b00 2a00004f
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[58:59], v[60:61], v[18:25] ; cc464012 1c4a793a
	buffer_load_b128 v[58:61], v17, s[28:31], null offen offset:1536 ; c405c07c 4080383a 00060011
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[42:43], v[112:119] ; cc464070 1dc2553a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[60:61], v[54:55], v[120:127] ; cc464078 1de26d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[56:57], v[128:135] ; cc464080 1e02713c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[44:45], v[136:143] ; cc464088 1e22593c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[42:43], v[144:151] ; cc464090 1e42553c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[58:59], v[54:55], v[88:95] ; cc464058 1d626d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[58:59], v[44:45], v[104:111] ; cc464068 1da2593a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[56:57], v[96:103] ; cc464060 1d82713a
	buffer_load_b128 v[58:61], v28, s[28:31], null offen offset:1536 ; c405c07c 4080383a 0006001c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[58:59], v[44:45], v[168:175] ; cc4640a8 1ea2593a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[44:45], v[80:87] ; cc464050 1d42593c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[58:59], v[42:43], v[176:183] ; cc4640b0 1ec2553a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[60:61], v[42:43], v[64:71] ; cc464040 1d02553c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[60:61], v[54:55], v[184:191] ; cc4640b8 1ee26d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[60:61], v[56:57], v[18:25] ; cc464012 1c4a713c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[56:57], v[160:167] ; cc4640a0 1e82713a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[54:55], v[152:159] ; cc464098 1e626d3a
	ds_load_b64 v[54:55], v79 offset:1024                       ; d9d80400 3600004f
	ds_load_b64 v[56:57], v79 offset:3072                       ; d9d80c00 3800004f
	ds_load_b64 v[44:45], v79 offset:5120                       ; d9d81400 2c00004f
	ds_load_b64 v[42:43], v79 offset:7168                       ; d9d81c00 2a00004f
	buffer_load_b128 v[58:61], v17, s[28:31], null offen offset:2048 ; c405c07c 4080383a 00080011
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[42:43], v[112:119] ; cc464070 1dc2553a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[60:61], v[54:55], v[120:127] ; cc464078 1de26d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[56:57], v[128:135] ; cc464080 1e02713c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[44:45], v[136:143] ; cc464088 1e22593c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[42:43], v[144:151] ; cc464090 1e42553c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[58:59], v[44:45], v[104:111] ; cc464068 1da2593a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[58:59], v[54:55], v[88:95] ; cc464058 1d626d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[56:57], v[96:103] ; cc464060 1d82713a
	buffer_load_b128 v[58:61], v28, s[28:31], null offen offset:2048 ; c405c07c 4080383a 0008001c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[58:59], v[42:43], v[176:183] ; cc4640b0 1ec2553a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[44:45], v[80:87] ; cc464050 1d42593c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[60:61], v[54:55], v[184:191] ; cc4640b8 1ee26d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[60:61], v[42:43], v[64:71] ; cc464040 1d02553c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[54:55], v[152:159] ; cc464098 1e626d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[58:59], v[44:45], v[168:175] ; cc4640a8 1ea2593a
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[60:61], v[56:57], v[18:25] ; cc464012 1c4a713c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[56:57], v[160:167] ; cc4640a0 1e82713a
	ds_load_b64 v[54:55], v79 offset:1280                       ; d9d80500 3600004f
	ds_load_b64 v[56:57], v79 offset:3328                       ; d9d80d00 3800004f
	ds_load_b64 v[44:45], v79 offset:5376                       ; d9d81500 2c00004f
	ds_load_b64 v[42:43], v79 offset:7424                       ; d9d81d00 2a00004f
	buffer_load_b128 v[58:61], v17, s[28:31], null offen offset:2560 ; c405c07c 4080383a 000a0011
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[42:43], v[112:119] ; cc464070 1dc2553a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[60:61], v[54:55], v[120:127] ; cc464078 1de26d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[56:57], v[128:135] ; cc464080 1e02713c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[44:45], v[136:143] ; cc464088 1e22593c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[58:59], v[44:45], v[104:111] ; cc464068 1da2593a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[42:43], v[144:151] ; cc464090 1e42553c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[58:59], v[54:55], v[88:95] ; cc464058 1d626d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[56:57], v[96:103] ; cc464060 1d82713a
	buffer_load_b128 v[58:61], v28, s[28:31], null offen offset:2560 ; c405c07c 4080383a 000a001c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[58:59], v[42:43], v[176:183] ; cc4640b0 1ec2553a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[44:45], v[80:87] ; cc464050 1d42593c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[60:61], v[54:55], v[184:191] ; cc4640b8 1ee26d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[60:61], v[42:43], v[64:71] ; cc464040 1d02553c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[58:59], v[44:45], v[168:175] ; cc4640a8 1ea2593a
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[60:61], v[56:57], v[18:25] ; cc464012 1c4a713c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[54:55], v[152:159] ; cc464098 1e626d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[56:57], v[160:167] ; cc4640a0 1e82713a
	ds_load_b64 v[54:55], v79 offset:1536                       ; d9d80600 3600004f
	ds_load_b64 v[56:57], v79 offset:3584                       ; d9d80e00 3800004f
	ds_load_b64 v[44:45], v79 offset:5632                       ; d9d81600 2c00004f
	ds_load_b64 v[42:43], v79 offset:7680                       ; d9d81e00 2a00004f
	buffer_load_b128 v[58:61], v17, s[28:31], null offen offset:3072 ; c405c07c 4080383a 000c0011
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[42:43], v[112:119] ; cc464070 1dc2553a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[60:61], v[54:55], v[120:127] ; cc464078 1de26d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[60:61], v[56:57], v[128:135] ; cc464080 1e02713c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[60:61], v[44:45], v[136:143] ; cc464088 1e22593c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[60:61], v[42:43], v[144:151] ; cc464090 1e42553c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[58:59], v[44:45], v[104:111] ; cc464068 1da2593a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[58:59], v[54:55], v[88:95] ; cc464058 1d626d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[58:59], v[56:57], v[96:103] ; cc464060 1d82713a
	buffer_load_b128 v[58:61], v28, s[28:31], null offen offset:3072 ; c405c07c 4080383a 000c001c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[58:59], v[42:43], v[176:183] ; cc4640b0 1ec2553a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[60:61], v[44:45], v[80:87] ; cc464050 1d42593c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[60:61], v[54:55], v[184:191] ; cc4640b8 1ee26d3c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[58:59], v[44:45], v[168:175] ; cc4640a8 1ea2593a
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[60:61], v[56:57], v[18:25] ; cc464012 1c4a713c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[54:55], v[152:159] ; cc464098 1e626d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[58:59], v[56:57], v[160:167] ; cc4640a0 1e82713a
	ds_load_b64 v[54:55], v79 offset:1792                       ; d9d80700 3600004f
	ds_load_b64 v[56:57], v79 offset:3840                       ; d9d80f00 3800004f
	ds_load_b64 v[44:45], v79 offset:5888                       ; d9d81700 2c00004f
	ds_load_b64 v[58:59], v79 offset:7936                       ; d9d81f00 3a00004f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[60:61], v[42:43], v[64:71] ; cc464040 1d02553c
	v_dual_mov_b32 v61, v41 :: v_dual_mov_b32 v60, v40          ; ca100129 3d3c0128
	buffer_load_b128 v[40:43], v17, s[28:31], null offen offset:3584 ; c405c07c 40803828 000e0011
	s_wait_loadcnt_dscnt 0x2                                    ; bfc80002
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[56:57], v[96:103] ; cc464060 1d827128
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[44:45], v[104:111] ; cc464068 1da25928
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[58:59], v[112:119] ; cc464070 1dc27528
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[54:55], v[88:95] ; cc464058 1d626d28
	v_dual_mov_b32 v17, v43 :: v_dual_mov_b32 v16, v42          ; ca10012b 1110012a
	buffer_load_b128 v[40:43], v28, s[28:31], null offen offset:3584 ; c405c07c 40803828 000e001c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[16:17], v[58:59], v[144:151] ; cc464090 1e427510
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[54:55], v[120:127] ; cc464078 1de26d10
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[16:17], v[56:57], v[128:135] ; cc464080 1e027110
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[16:17], v[44:45], v[136:143] ; cc464088 1e225910
	v_maxmin_num_f32 v28, -4.0, v88, 4.0                        ; d669001c 03dab0f7
	v_maxmin_num_f32 v16, -4.0, v89, 4.0                        ; d6690010 03dab2f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mix_f32 v79, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624f 0bfe38ff 3728ab28
	v_fma_mix_f32 v17, 0xab28, |v16|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206211 0bfe20ff 3728ab28
	v_dual_fmaak_f32 v17, v17, v16, 0x3f650000 :: v_dual_fmaak_f32 v28, v28, v79, 0x3f650000 ; c8422111 111c9f1c 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_mul_f32 v89, v89, v17 :: v_dual_mul_f32 v88, v88, v28 ; c8c62359 59583958
	v_maxmin_num_f32 v28, -4.0, v90, 4.0                        ; d669001c 03dab4f7
	v_maxmin_num_f32 v17, -4.0, v93, 4.0                        ; d6690011 03dabaf7
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v88, -4.0, v91, 4.0                        ; d6690058 03dab6f7
	v_fma_mix_f32 v79, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624f 0bfe38ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v89, 0xab28, |v88|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfeb0ff 3728ab28
	v_dual_fmaak_f32 v88, v88, v89, 0x3f650000 :: v_dual_fmaak_f32 v79, v79, v28, 0x3f650000 ; c842b358 584e394f 3f650000
	v_maxmin_num_f32 v89, -4.0, v95, 4.0                        ; d6690059 03dabef7
	v_fma_mix_f32 v28, 0xab28, |v17|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621c 0bfe22ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_mul_f32 v91, v91, v88 :: v_dual_mul_f32 v90, v90, v79 ; c8c6b15b 5b5a9f5a
	v_maxmin_num_f32 v79, -4.0, v94, 4.0                        ; d669004f 03dabcf7
	v_fmaak_f32 v28, v28, v17, 0x3f650000                       ; 5a38231c 3f650000
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v90, -4.0, v92, 4.0                        ; d669005a 03dab8f7
	v_fma_mix_f32 v88, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfe9eff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fmaak_f32 v90, v90, v91, 0x3f650000                       ; 5ab4b75a 3f650000
	v_maxmin_num_f32 v91, -4.0, v96, 4.0                        ; d669005b 03dac0f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_mul_f32 v92, v92, v90 :: v_dual_mul_f32 v93, v93, v28 ; c8c6b55c 5c5c395d
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v93, -4.0, v97, 4.0                        ; d669005d 03dac2f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v88, v88, v79, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c8429f58 5858b559 3f650000
	v_maxmin_num_f32 v79, -4.0, v100, 4.0                       ; d669004f 03dac8f7
	v_maxmin_num_f32 v90, -4.0, v101, 4.0                       ; d669005a 03dacaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_mul_f32 v94, v94, v88 :: v_dual_mul_f32 v95, v95, v89 ; c8c6b15e 5e5eb35f
	v_fma_mix_f32 v89, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206259 0bfe9eff 3728ab28
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v98, 4.0                        ; d669005f 03dac4f7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 :: v_dual_fmaak_f32 v91, v91, v92, 0x3f650000 ; c842bb5e 5e5ab95b 3f650000
	v_maxmin_num_f32 v92, -4.0, v102, 4.0                       ; d669005c 03daccf7
	v_dual_mul_f32 v97, v97, v94 :: v_dual_mul_f32 v96, v96, v91 ; c8c6bd61 6160b760
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_maxmin_num_f32 v94, -4.0, v103, 4.0                       ; d669005e 03dacef7
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v99, 4.0                        ; d6690061 03dac6f7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_fma_mix_f32 v28, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621c 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v79, v79, v89, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842b34f 4f60bf60 3f650000
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_fmaak_f32 v97, v97, v28, 0x3f650000                       ; 5ac23961 3f650000
	v_dual_fmaak_f32 v91, v91, v90, 0x3f650000 :: v_dual_mul_f32 v98, v98, v96 ; c846b55b 5b62c162 3f650000
	v_maxmin_num_f32 v96, -4.0, v104, 4.0                       ; d6690060 03dad0f7
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c842b95d 5d5ebf5e 3f650000
	v_mul_f32_e32 v99, v99, v97                                 ; 10c6c363
	v_dual_mul_f32 v101, v91, v101 :: v_dual_mul_f32 v100, v100, v79 ; c8c6cb5b 65649f64
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_dual_mul_f32 v103, v103, v94 :: v_dual_mul_f32 v102, v102, v93 ; c8c6bd67 6766bb66
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v98, -4.0, v105, 4.0                       ; d6690062 03dad2f7
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v100, -4.0, v106, 4.0                      ; d6690064 03dad4f7
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v102, -4.0, v107, 4.0                      ; d6690066 03dad6f7
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_maxmin_num_f32 v28, -4.0, v111, 4.0                       ; d669001c 03dadef7
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v97, 0x3f650000 ; c842c563 6360c360 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_fmaak_f32 v101, v101, v100, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 ; c842c965 6566cf66 3f650000
	v_fma_mix_f32 v79, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624f 0bfe38ff 3728ab28
	v_dual_mul_f32 v105, v105, v99 :: v_dual_mul_f32 v104, v104, v96 ; c8c6c769 6968c168
	v_maxmin_num_f32 v92, -4.0, v112, 4.0                       ; d669005c 03dae0f7
	v_maxmin_num_f32 v94, -4.0, v113, 4.0                       ; d669005e 03dae2f7
	v_dual_mul_f32 v107, v107, v102 :: v_dual_mul_f32 v106, v106, v101 ; c8c6cd6b 6b6acb6a
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v104, -4.0, v108, 4.0                      ; d6690068 03dad8f7
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_maxmin_num_f32 v96, -4.0, v114, 4.0                       ; d6690060 03dae4f7
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_maxmin_num_f32 v98, -4.0, v115, 4.0                       ; d6690062 03dae6f7
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v106, -4.0, v109, 4.0                      ; d669006a 03dadaf7
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_maxmin_num_f32 v100, -4.0, v116, 4.0                      ; d6690064 03dae8f7
	v_fma_mix_f32 v97, 0xab28, |v96|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfec0ff 3728ab28
	v_dual_fmaak_f32 v95, v95, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v93, 0x3f650000 ; c842bd5f 5f5cbb5c 3f650000
	v_maxmin_num_f32 v102, -4.0, v117, 4.0                      ; d6690066 03daeaf7
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_dual_mul_f32 v113, v113, v95 :: v_dual_mul_f32 v112, v112, v92 ; c8c6bf71 7170b970
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_dual_fmaak_f32 v98, v98, v99, 0x3f650000 :: v_dual_fmaak_f32 v97, v97, v96, 0x3f650000 ; c842c762 6260c161 3f650000
	v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 ; c842d56b 6b68d368 3f650000
	v_maxmin_num_f32 v106, -4.0, v119, 4.0                      ; d669006a 03daeef7
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c842cd67 6764cb64 3f650000
	v_dual_mul_f32 v115, v115, v98 :: v_dual_mul_f32 v114, v114, v97 ; c8c6c573 7372c372
	v_dual_mul_f32 v109, v109, v107 :: v_dual_mul_f32 v108, v108, v104 ; c8c6d76d 6d6cd16c
	v_maxmin_num_f32 v104, -4.0, v118, 4.0                      ; d6690068 03daecf7
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_dual_mul_f32 v117, v117, v103 :: v_dual_mul_f32 v116, v116, v100 ; c8c6cf75 7574c974
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v108, -4.0, v110, 4.0                      ; d669006c 03dadcf7
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_maxmin_num_f32 v112, -4.0, v122, 4.0                      ; d6690070 03daf4f7
	v_maxmin_num_f32 v114, -4.0, v123, 4.0                      ; d6690072 03daf6f7
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_dual_fmaak_f32 v106, v106, v107, 0x3f650000 :: v_dual_fmaak_f32 v105, v105, v104, 0x3f650000 ; c842d76a 6a68d169 3f650000
	v_fma_mix_f32 v113, 0xab28, |v112|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206271 0bfee0ff 3728ab28
	v_maxmin_num_f32 v116, -4.0, v124, 4.0                      ; d6690074 03daf8f7
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_dual_fmaak_f32 v28, v28, v79, 0x3f650000 :: v_dual_fmaak_f32 v109, v109, v108, 0x3f650000 ; c8429f1c 1c6cd96d 3f650000
	v_maxmin_num_f32 v108, -4.0, v120, 4.0                      ; d669006c 03daf0f7
	v_dual_mul_f32 v119, v119, v106 :: v_dual_mul_f32 v118, v118, v105 ; c8c6d577 7776d376
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	v_dual_fmaak_f32 v114, v114, v115, 0x3f650000 :: v_dual_fmaak_f32 v113, v113, v112, 0x3f650000 ; c842e772 7270e171 3f650000
	v_dual_mul_f32 v111, v111, v28 :: v_dual_mul_f32 v110, v110, v109 ; c8c6396f 6f6edb6e
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v118, -4.0, v125, 4.0                      ; d6690076 03dafaf7
	v_dual_mul_f32 v123, v123, v114 :: v_dual_mul_f32 v122, v122, v113 ; c8c6e57b 7b7ae37a
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v110, -4.0, v121, 4.0                      ; d669006e 03daf2f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmaak_f32 v119, v119, v118, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c842ed77 7774eb74 3f650000
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v109, 0x3f650000 ; c842dd6f 6f6cdb6c 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_mul_f32 v125, v125, v119 :: v_dual_mul_f32 v124, v124, v116 ; c8c6ef7d 7d7ce97c
	v_dual_mul_f32 v121, v121, v111 :: v_dual_mul_f32 v120, v120, v108 ; c8c6df79 7978d978
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a2
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v128, 4.0                      ; d669007c 03db00f7
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v126, 4.0                      ; d6690078 03dafcf7
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v122, -4.0, v127, 4.0                      ; d669007a 03dafef7
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 ; c842f179 797af77a 3f650000
	v_dual_mul_f32 v127, v127, v122 :: v_dual_mul_f32 v126, v126, v121 ; c8c6f57f 7f7ef37e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v129, 4.0                      ; d669007e 03db02f7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_maxmin_num_f32 v28, -4.0, v131, 4.0                       ; d669001c 03db06f7
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v125, 0x3f650000 ; c842fd7f 7f7cfb7c 3f650000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[18:25], v[42:43], v[56:57], v[18:25] ; cc464012 1c4a712a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[42:43], v[58:59], v[64:71] ; cc464040 1d02752a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[40:41], v[58:59], v[176:183] ; cc4640b0 1ec27528
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[42:43], v[44:45], v[80:87] ; cc464050 1d42592a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[40:41], v[56:57], v[160:167] ; cc4640a0 1e827128
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[40:41], v[54:55], v[152:159] ; cc464098 1e626d28
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[42:43], v[54:55], v[184:191] ; cc4640b8 1ee26d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[40:41], v[44:45], v[168:175] ; cc4640a8 1ea25928
	v_fma_mix_f32 v41, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206229 0bfe38ff 3728ab28
	v_dual_mul_f32 v129, v129, v127 :: v_dual_mul_f32 v128, v128, v124 ; c8c6ff81 8180f980
	v_maxmin_num_f32 v42, -4.0, v132, 4.0                       ; d669002a 03db08f7
	v_maxmin_num_f32 v54, -4.0, v134, 4.0                       ; d6690036 03db0cf7
	v_maxmin_num_f32 v44, -4.0, v133, 4.0                       ; d669002c 03db0af7
	v_maxmin_num_f32 v56, -4.0, v135, 4.0                       ; d6690038 03db0ef7
	v_maxmin_num_f32 v58, -4.0, v136, 4.0                       ; d669003a 03db10f7
	v_fmaak_f32 v28, v28, v41, 0x3f650000                       ; 5a38531c 3f650000
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v128, -4.0, v130, 4.0                      ; d6690080 03db04f7
	v_fma_mix_f32 v43, 0xab28, |v42|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622b 0bfe54ff 3728ab28
	v_fma_mix_f32 v55, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe6cff 3728ab28
	v_maxmin_num_f32 v79, -4.0, v137, 4.0                       ; d669004f 03db12f7
	v_fma_mix_f32 v45, 0xab28, |v44|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622d 0bfe58ff 3728ab28
	v_fma_mix_f32 v57, 0xab28, |v56|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206239 0bfe70ff 3728ab28
	v_fma_mix_f32 v59, 0xab28, |v58|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623b 0bfe74ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v138, 4.0                       ; d6690061 03db14f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fmaak_f32 v42, v42, v43, 0x3f650000                       ; 5a54572a 3f650000
	v_maxmin_num_f32 v99, -4.0, v139, 4.0                       ; d6690063 03db16f7
	v_fma_mix_f32 v96, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfe9eff 3728ab28
	v_dual_fmaak_f32 v56, v56, v57, 0x3f650000 :: v_dual_fmaak_f32 v45, v45, v44, 0x3f650000 ; c8427338 382c592d 3f650000
	v_maxmin_num_f32 v101, -4.0, v140, 4.0                      ; d6690065 03db18f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_fmaak_f32 v129, v129, v128, 0x3f650000                    ; 5b030181 3f650000
	v_maxmin_num_f32 v103, -4.0, v141, 4.0                      ; d6690067 03db1af7
	v_dual_mul_f32 v132, v42, v132 :: v_dual_fmaak_f32 v55, v55, v54, 0x3f650000 ; c8c3092a 84366d37 3f650000
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_dual_fmaak_f32 v96, v96, v79, 0x3f650000 :: v_dual_mul_f32 v135, v135, v56 ; c8469f60 60867187 3f650000
	v_dual_fmaak_f32 v58, v58, v59, 0x3f650000 :: v_dual_mul_f32 v133, v133, v45 ; c846773a 3a845b85 3f650000
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v105, -4.0, v142, 4.0                      ; d6690069 03db1cf7
	v_mul_f32_e32 v130, v130, v129                              ; 11050382
	v_maxmin_num_f32 v107, -4.0, v143, 4.0                      ; d669006b 03db1ef7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_mul_f32 v134, v134, v55 :: v_dual_mul_f32 v131, v131, v28 ; c8c66f86 86823983
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 ; c842c362 6262c963 3f650000
	v_maxmin_num_f32 v109, -4.0, v144, 4.0                      ; d669006d 03db20f7
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v136, v136, v58 :: v_dual_mul_f32 v137, v137, v96 ; c8c67588 8888c189
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_maxmin_num_f32 v111, -4.0, v145, 4.0                      ; d669006f 03db22f7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 :: v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 ; c842cf68 6864cd65 3f650000
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v138, v138, v98 :: v_dual_mul_f32 v139, v139, v99 ; c8c6c58a 8a8ac78b
	v_maxmin_num_f32 v113, -4.0, v146, 4.0                      ; d6690071 03db24f7
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_maxmin_num_f32 v115, -4.0, v147, 4.0                      ; d6690073 03db26f7
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_dual_fmaak_f32 v107, v107, v108, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 ; c842d96b 6b6ad36a 3f650000
	v_dual_mul_f32 v141, v141, v104 :: v_dual_mul_f32 v140, v140, v101 ; c8c6d18d 8d8ccb8c
	v_maxmin_num_f32 v117, -4.0, v148, 4.0                      ; d6690075 03db28f7
	v_maxmin_num_f32 v119, -4.0, v149, 4.0                      ; d6690077 03db2af7
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v150, 4.0                      ; d6690079 03db2cf7
	v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 :: v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 ; c842df70 706cdd6d 3f650000
	v_maxmin_num_f32 v123, -4.0, v151, 4.0                      ; d669007b 03db2ef7
	v_dual_mul_f32 v143, v143, v107 :: v_dual_mul_f32 v142, v142, v106 ; c8c6d78f 8f8ed58e
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v152, 4.0                      ; d669007d 03db30f7
	v_dual_fmaak_f32 v115, v115, v116, 0x3f650000 :: v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 ; c842e973 7372e372 3f650000
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v153, 4.0                      ; d669007f 03db32f7
	v_dual_mul_f32 v145, v145, v112 :: v_dual_mul_f32 v144, v144, v109 ; c8c6e191 9190db90
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_maxmin_num_f32 v129, -4.0, v154, 4.0                      ; d6690081 03db34f7
	v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842ef78 7874ed75 3f650000
	v_maxmin_num_f32 v131, -4.0, v155, 4.0                      ; d6690083 03db36f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_dual_mul_f32 v147, v147, v115 :: v_dual_mul_f32 v146, v146, v114 ; c8c6e793 9392e592
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f97b 7b7af37a 3f650000
	v_maxmin_num_f32 v133, -4.0, v156, 4.0                      ; d6690085 03db38f7
	v_maxmin_num_f32 v135, -4.0, v157, 4.0                      ; d6690087 03db3af7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_dual_mul_f32 v149, v149, v120 :: v_dual_mul_f32 v148, v148, v117 ; c8c6f195 9594eb94
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_maxmin_num_f32 v137, -4.0, v158, 4.0                      ; d6690089 03db3cf7
	v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842ff80 807cfd7d 3f650000
	v_dual_mul_f32 v151, v151, v123 :: v_dual_mul_f32 v150, v150, v122 ; c8c6f797 9796f596
	v_maxmin_num_f32 v139, -4.0, v159, 4.0                      ; d669008b 03db3ef7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v141, -4.0, v160, 4.0                      ; d669008d 03db40f7
	v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v129, 0x3f650000 ; c8430983 83830382 3f650000
	v_maxmin_num_f32 v143, -4.0, v161, 4.0                      ; d669008f 03db42f7
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_dual_mul_f32 v153, v153, v128 :: v_dual_mul_f32 v152, v152, v125 ; c8c70199 9998fb98
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430f88 88850d85 3f650000
	v_maxmin_num_f32 v145, -4.0, v162, 4.0                      ; d6690091 03db44f7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_maxmin_num_f32 v147, -4.0, v163, 4.0                      ; d6690093 03db46f7
	v_dual_mul_f32 v155, v155, v131 :: v_dual_mul_f32 v154, v154, v130 ; c8c7079b 9b9b059a
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v149, -4.0, v164, 4.0                      ; d6690095 03db48f7
	v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 ; c843198b 8b8b138a 3f650000
	v_dual_mul_f32 v157, v157, v136 :: v_dual_mul_f32 v156, v156, v133 ; c8c7119d 9d9d0b9c
	v_maxmin_num_f32 v151, -4.0, v165, 4.0                      ; d6690097 03db4af7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c8431f90 908d1d8d 3f650000
	v_maxmin_num_f32 v153, -4.0, v166, 4.0                      ; d6690099 03db4cf7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v167, 4.0                      ; d669009b 03db4ef7
	v_dual_mul_f32 v159, v159, v139 :: v_dual_mul_f32 v158, v158, v138 ; c8c7179f 9f9f159e
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_dual_fmaak_f32 v147, v147, v148, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v145, 0x3f650000 ; c8432993 93932392 3f650000
	v_maxmin_num_f32 v157, -4.0, v168, 4.0                      ; d669009d 03db50f7
	v_dual_mul_f32 v161, v161, v144 :: v_dual_mul_f32 v160, v160, v141 ; c8c721a1 a1a11ba0
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_maxmin_num_f32 v159, -4.0, v169, 4.0                      ; d669009f 03db52f7
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432f98 98952d95 3f650000
	v_dual_mul_f32 v163, v163, v147 :: v_dual_mul_f32 v162, v162, v146 ; c8c727a3 a3a325a2
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	v_maxmin_num_f32 v161, -4.0, v170, 4.0                      ; d66900a1 03db54f7
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_dual_mul_f32 v165, v165, v152 :: v_dual_mul_f32 v164, v164, v149 ; c8c731a5 a5a52ba4
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_maxmin_num_f32 v163, -4.0, v171, 4.0                      ; d66900a3 03db56f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_mul_f32 v167, v167, v155 :: v_dual_mul_f32 v166, v166, v154 ; c8c737a7 a7a735a6
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c8433fa0 a09d3d9d 3f650000
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
	v_maxmin_num_f32 v165, -4.0, v172, 4.0                      ; d66900a5 03db58f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	s_mov_b32 s90, src_scc                                      ; beda00fd
	s_lshr_b32 s52, s52, 2                                      ; 85348234
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_maxmin_num_f32 v167, -4.0, v173, 4.0                      ; d66900a7 03db5af7
	v_dual_mul_f32 v169, v169, v160 :: v_dual_mul_f32 v168, v168, v157 ; c8c741a9 a9a93ba8
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c84349a3 a3a343a2 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_maxmin_num_f32 v169, -4.0, v174, 4.0                      ; d66900a9 03db5cf7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_mul_f32 v171, v171, v163 :: v_dual_mul_f32 v170, v170, v162 ; c8c747ab abab45aa
	v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 ; c8434da5 a5a94fa8 3f650000
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_maxmin_num_f32 v79, -4.0, v176, 4.0                       ; d669004f 03db60f7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v173, v173, v168 :: v_dual_mul_f32 v172, v172, v165 ; c8c751ad adad4bac
	v_fma_mix_f32 v100, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfe9eff 3728ab28
	v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 :: v_dual_lshlrev_b32 v171, 10, v2 ; c86353aa aaaa048a 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
	v_dual_fmaak_f32 v79, v79, v100, 0x3f650000 :: v_dual_mul_f32 v174, v174, v170 ; c846c94f 4faf55ae 3f650000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v172, v31, s52, v171                             ; d65500ac 06ac691f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v172, 2, v172                             ; 31595882
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[96:99], v172, s[28:31], null offen       ; c405c07c 40803860 000000ac
	buffer_load_b128 v[100:103], v172, s[28:31], null offen offset:512 ; c405c07c 40803864 000200ac
	buffer_load_b128 v[112:115], v172, s[28:31], null offen offset:1024 ; c405c07c 40803870 000400ac
	v_maxmin_num_f32 v173, -4.0, v175, 4.0                      ; d66900ad 03db5ef7
	v_maxmin_num_f32 v104, -4.0, v177, 4.0                      ; d6690068 03db62f7
	v_maxmin_num_f32 v106, -4.0, v178, 4.0                      ; d669006a 03db64f7
	v_maxmin_num_f32 v108, -4.0, v179, 4.0                      ; d669006c 03db66f7
	v_maxmin_num_f32 v110, -4.0, v180, 4.0                      ; d669006e 03db68f7
	v_maxmin_num_f32 v116, -4.0, v181, 4.0                      ; d6690074 03db6af7
	v_fma_mix_f32 v28, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621c 0bff5aff 3728ab28
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_fma_mix_f32 v109, 0xab28, |v108|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626d 0bfed8ff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fmaak_f32 v108, v108, v109, 0x3f650000                    ; 5ad8db6c 3f650000
	v_dual_fmaak_f32 v117, v117, v116, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v111, 0x3f650000 ; c842e975 756edf6e 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_mul_f32_e32 v179, v179, v108                              ; 1166d9b3
	v_dual_mul_f32 v181, v181, v117 :: v_dual_mul_f32 v180, v180, v110 ; c8c6ebb5 b5b4ddb4
	buffer_load_b128 v[108:111], v172, s[28:31], null offen offset:1536 ; c405c07c 4080386c 000600ac
	v_maxmin_num_f32 v118, -4.0, v182, 4.0                      ; d6690076 03db6cf7
	v_maxmin_num_f32 v120, -4.0, v183, 4.0                      ; d6690078 03db6ef7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 :: v_dual_fmaak_f32 v119, v119, v118, 0x3f650000 ; c842f378 7876ed77 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v183, v183, v120 :: v_dual_mul_f32 v182, v182, v119 ; c8c6f1b7 b7b6efb6
	buffer_load_b128 v[116:119], v172, s[28:31], null offen offset:2048 ; c405c07c 40803874 000800ac
	v_fmaak_f32 v173, v173, v28, 0x3f650000                     ; 5b5a39ad 3f650000
	v_fmaak_f32 v105, v105, v104, 0x3f650000                    ; 5ad2d169 3f650000
	v_fmaak_f32 v107, v107, v106, 0x3f650000                    ; 5ad6d56b 3f650000
	v_maxmin_num_f32 v122, -4.0, v184, 4.0                      ; d669007a 03db70f7
	v_maxmin_num_f32 v124, -4.0, v185, 4.0                      ; d669007c 03db72f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 ; c842f97d 7d7af77a 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v185, v185, v125 :: v_dual_mul_f32 v184, v184, v122 ; c8c6fbb9 b9b8f5b8
	buffer_load_b128 v[120:123], v172, s[28:31], null offen offset:2560 ; c405c07c 40803878 000a00ac
	v_maxmin_num_f32 v126, -4.0, v186, 4.0                      ; d669007e 03db74f7
	v_dual_mul_f32 v175, v175, v173 :: v_dual_mul_f32 v176, v176, v79 ; c8c75baf afb09fb0
	v_dual_mul_f32 v177, v177, v105 :: v_dual_mul_f32 v178, v178, v107 ; c8c6d3b1 b1b2d7b2
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_maxmin_num_f32 v128, -4.0, v187, 4.0                      ; d6690080 03db76f7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v127, v127, v126, 0x3f650000                    ; 5afefd7f 3f650000
	v_mul_f32_e32 v186, v186, v127                              ; 1174ffba
	buffer_load_b128 v[124:127], v172, s[28:31], null offen offset:3072 ; c405c07c 4080387c 000c00ac
	v_maxmin_num_f32 v130, -4.0, v188, 4.0                      ; d6690082 03db78f7
(invalid instruction)                                        ; d769006a
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
	v_maxmin_num_f32 v132, -4.0, v189, 4.0                      ; d6690084 03db7af7
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fmaak_f32 v128, v128, v129, 0x3f650000                    ; 5b010380 3f650000
	v_fmaak_f32 v130, v130, v131, 0x3f650000                    ; 5b050782 3f650000
	v_dual_mul_f32 v188, v188, v130 :: v_dual_mul_f32 v187, v187, v128 ; c8c705bc bcbb01bb
	buffer_load_b128 v[128:131], v172, s[28:31], null offen offset:3584 ; c405c07c 40803880 000e00ac
	v_maxmin_num_f32 v134, -4.0, v190, 4.0                      ; d6690086 03db7cf7
	v_maxmin_num_f32 v136, -4.0, v191, 4.0                      ; d6690088 03db7ef7
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v138, -4.0, v18, 4.0                       ; d669008a 03da24f7
	v_maxmin_num_f32 v140, -4.0, v19, 4.0                       ; d669008c 03da26f7
	v_maxmin_num_f32 v144, -4.0, v21, 4.0                       ; d6690090 03da2af7
(invalid instruction)                                        ; d769406a
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v20, 4.0                       ; d669008e 03da28f7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v22, 4.0                       ; d6690092 03da2cf7
	v_fmaak_f32 v133, v133, v132, 0x3f650000                    ; 5b0b0985 3f650000
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v24, 4.0                       ; d6690096 03da30f7
	v_fmaak_f32 v135, v135, v134, 0x3f650000                    ; 5b0f0d87 3f650000
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_fmaak_f32 v136, v136, v137, 0x3f650000                    ; 5b111388 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v23, 4.0                       ; d6690094 03da2ef7
	v_maxmin_num_f32 v152, -4.0, v25, 4.0                       ; d6690098 03da32f7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_mul_f32 v189, v189, v133 :: v_dual_mul_f32 v190, v190, v135 ; c8c70bbd bdbf0fbe
	v_maxmin_num_f32 v154, -4.0, v80, 4.0                       ; d669009a 03daa0f7
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_mul_f32 v191, v191, v136 ; c847178a 8abf11bf 3f650000
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 ; c8432792 928f1d8f 3f650000
	v_maxmin_num_f32 v156, -4.0, v81, 4.0                       ; d669009c 03daa2f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v82, 4.0                       ; d669009e 03daa4f7
(invalid instruction)                                        ; d769006b
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
(invalid instruction)                                        ; d769406b
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_dual_mul_f32 v18, v18, v138 :: v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 ; c8c31512 128d198d 3f650000
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_mul_f32 v20, v20, v143 ; c8472d97 97151f14 3f650000
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v83, 4.0                       ; d66900a0 03daa6f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v84, 4.0                       ; d66900a2 03daa8f7
	v_maxmin_num_f32 v166, -4.0, v86, 4.0                       ; d66900a6 03daacf7
	v_dual_fmaak_f32 v144, v145, v144, 0x3f650000 :: v_dual_mul_f32 v19, v19, v141 ; c8472191 90131b13 3f650000
	v_dual_mul_f32 v24, v24, v151 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c8c32f18 18952995 3f650000
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c843399d 9d9b379a 3f650000
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v85, 4.0                       ; d66900a4 03daaaf7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                      ; 02022712
	v_dual_mul_f32 v22, v22, v146 :: v_dual_mul_f32 v21, v21, v144 ; c8c72516 16152115
	v_lshrrev_b32_e32 v170, 4, v3                               ; 33540684
	v_dual_fmaak_f32 v152, v153, v152, 0x3f650000 :: v_dual_mul_f32 v23, v23, v149 ; c8473199 98172b17 3f650000
	v_dual_mul_f32 v80, v154, v80 :: v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 ; c8c2a19a 509f3d9f 3f650000
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v87, 4.0                       ; d66900a8 03daaef7
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                      ; 02022b14
	v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 :: v_dual_mul_f32 v25, v25, v152 ; c84743a0 a0193119 3f650000
	v_dual_mul_f32 v82, v82, v159 :: v_dual_mul_f32 v81, v81, v157 ; c8c73f52 52513b51
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_lshlrev_b32 v170, 3, v170 ; c86349a5 a5ab5483 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 :: v_dual_mul_f32 v83, v83, v160 ; c84747a2 a2534153 3f650000
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
	v_maxmin_num_f32 v174, -4.0, v64, 4.0                       ; d66900ae 03da80f7
	v_fma_mix_f32 v173, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff50ff 3728ab28
	v_dual_fmaak_f32 v167, v166, v167, 0x3f650000 :: v_dual_mul_f32 v84, v84, v162 ; c8474fa6 a7554554 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fmaak_f32 v168, v168, v173, 0x3f650000                    ; 5b515ba8 3f650000
	v_dual_mul_f32 v86, v86, v167 :: v_dual_and_b32 v169, 0xffffffe0, v0 ; c8e54f56 56a800ff ffffffe0
	v_fmaak_f32 v174, v174, v175, 0x3f650000                    ; 5b5d5fae 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_add3_u32 v172, v170, s47, v169                            ; d65500ac 06a45faa
	v_dual_mul_f32 v64, v64, v174 :: v_dual_mul_f32 v87, v87, v168 ; c8c75d40 40575157
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_mul_f32 v85, v85, v165 :: v_dual_lshlrev_b32 v172, 2, v172 ; c8e34b55 55ad5882
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[80:83], v172, s[24:27], null offen       ; c405c07c 40803050 000000ac
	buffer_load_b128 v[84:87], v172, s[24:27], null offen offset:16 ; c405c07c 40803054 000010ac
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
	v_maxmin_num_f32 v176, -4.0, v65, 4.0                       ; d66900b0 03da82f7
	v_maxmin_num_f32 v178, -4.0, v66, 4.0                       ; d66900b2 03da84f7
	v_maxmin_num_f32 v180, -4.0, v67, 4.0                       ; d66900b4 03da86f7
	v_maxmin_num_f32 v182, -4.0, v68, 4.0                       ; d66900b6 03da88f7
	v_maxmin_num_f32 v184, -4.0, v69, 4.0                       ; d66900b8 03da8af7
	v_maxmin_num_f32 v186, -4.0, v70, 4.0                       ; d66900ba 03da8cf7
	v_maxmin_num_f32 v188, -4.0, v71, 4.0                       ; d66900bc 03da8ef7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_dual_mov_b32 v28, v78 :: v_dual_mov_b32 v25, v77          ; ca10014e 1c18014d
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fmaak_f32 v177, v177, v176, 0x3f650000                    ; 5b6361b1 3f650000
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c84365b3 b3b56bb4 3f650000
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84371b9 b9b76fb6 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 :: v_dual_mul_f32 v67, v67, v180 ; c8477bbc bc436943 3f650000
	v_dual_mul_f32 v65, v65, v177 :: v_dual_mul_f32 v66, v66, v179 ; c8c76341 41436742
	v_dual_mul_f32 v68, v182, v68 :: v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 ; c8c289b6 44bb75bb 3f650000
	v_dual_mov_b32 v24, v76 :: v_dual_mul_f32 v71, v71, v188    ; ca06014c 18477947
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v70, v70, v187 :: v_dual_mul_f32 v69, v69, v185 ; c8c77746 46457345
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[74:75], 0 ; cc4640b8 1a029562
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[98:99], v[46:47], 0 ; cc4640a0 1a025d62
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[98:99], v[72:73], 0 ; cc4640b0 1a029162
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[96:97], v[72:73], 0 ; cc464088 1a029160
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[96:97], v[46:47], 0 ; cc464040 1a025d60
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[74:75], 0 ; cc464090 1a029560
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[98:99], v[26:27], 0 ; cc464048 1a023562
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[26:27], 0 ; cc464098 1a023560
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[102:103], v[62:63], v[184:191] ; cc4640b8 1ee27d66
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[102:103], v[50:51], v[176:183] ; cc4640b0 1ec26566
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[100:101], v[50:51], v[136:143] ; cc464088 1e226564
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[62:63], v[144:151] ; cc464090 1e427d64
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[14:15], v[184:191] ; cc4640b8 1ee21d72
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[12:13], v[176:183] ; cc4640b0 1ec21972
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[12:13], v[136:143] ; cc464088 1e221970
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[102:103], v[48:49], v[160:167] ; cc4640a0 1e826166
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[100:101], v[48:49], v[64:71] ; cc464040 1d026164
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[102:103], v[52:53], v[72:79] ; cc464048 1d226966
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[100:101], v[52:53], v[152:159] ; cc464098 1e626964
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[112:113], v[14:15], v[144:151] ; cc464090 1e421d70
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[114:115], v[10:11], v[160:167] ; cc4640a0 1e821572
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[112:113], v[10:11], v[64:71] ; cc464040 1d021570
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[114:115], v[32:33], v[72:79] ; cc464048 1d224172
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[32:33], v[152:159] ; cc464098 1e624170
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[110:111], v[34:35], v[160:167] ; cc4640a0 1e82456e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[108:109], v[34:35], v[64:71] ; cc464040 1d02456c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[12:15], v172, s[24:27], null offen offset:64 ; c405c07c 4080300c 000040ac
	buffer_load_b128 v[32:35], v172, s[24:27], null offen offset:80 ; c405c07c 40803020 000050ac
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[110:111], v[36:37], v[176:183] ; cc4640b0 1ec2496e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[36:37], v[136:143] ; cc464088 1e22496c
	s_lshr_b32 s43, s43, 2                                      ; 852b822b
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[38:39], v[184:191] ; cc4640b8 1ee24d6e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[38:39], v[144:151] ; cc464090 1e424d6c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[110:111], v[60:61], v[72:79] ; cc464048 1d22796e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[60:61], v[152:159] ; cc464098 1e62796c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[118:119], v[16:17], v[160:167] ; cc4640a0 1e822176
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[116:117], v[16:17], v[64:71] ; cc464040 1d022174
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v36, v31, s43, v171                              ; d6550024 06ac571f
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[118:119], v[88:89], v[176:183] ; cc4640b0 1ec2b176
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[116:117], v[88:89], v[136:143] ; cc464088 1e22b174
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[90:91], v[184:191] ; cc4640b8 1ee2b576
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[116:117], v[90:91], v[144:151] ; cc464090 1e42b574
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[118:119], v[92:93], v[72:79] ; cc464048 1d22b976
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[92:93], v[152:159] ; cc464098 1e62b974
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[122:123], v[94:95], v[160:167] ; cc4640a0 1e82bd7a
	v_lshlrev_b32_e32 v36, 2, v36                               ; 30484882
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[120:121], v[94:95], v[64:71] ; cc464040 1d02bd78
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[122:123], v[40:41], v[176:183] ; cc4640b0 1ec2517a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[120:121], v[40:41], v[136:143] ; cc464088 1e225178
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[122:123], v[42:43], v[184:191] ; cc4640b8 1ee2557a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[120:121], v[42:43], v[144:151] ; cc464090 1e425578
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[122:123], v[44:45], v[72:79] ; cc464048 1d22597a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[120:121], v[44:45], v[152:159] ; cc464098 1e625978
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[126:127], v[54:55], v[160:167] ; cc4640a0 1e826d7e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[124:125], v[54:55], v[64:71] ; cc464040 1d026d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[126:127], v[56:57], v[176:183] ; cc4640b0 1ec2717e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[124:125], v[56:57], v[136:143] ; cc464088 1e22717c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[126:127], v[58:59], v[184:191] ; cc4640b8 1ee2757e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[124:125], v[58:59], v[144:151] ; cc464090 1e42757c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[126:127], v[104:105], v[72:79] ; cc464048 1d22d17e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[124:125], v[104:105], v[152:159] ; cc464098 1e62d17c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[130:131], v[106:107], v[160:167] ; cc4640a0 1e82d582
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[128:129], v[106:107], v[64:71] ; cc464040 1d02d580
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[130:131], v[18:19], v[176:183] ; cc4640b0 1ec22582
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[128:129], v[18:19], v[136:143] ; cc464088 1e222580
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[130:131], v[20:21], v[184:191] ; cc4640b8 1ee22982
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[128:129], v[20:21], v[144:151] ; cc464090 1e422980
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[130:131], v[22:23], v[72:79] ; cc464048 1d222d82
	buffer_load_b128 v[40:43], v36, s[28:31], null offen        ; c405c07c 40803828 00000024
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[128:129], v[22:23], v[152:159] ; cc464098 1e622d80
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_add_nc_u32_e32 v37, 0x2000, v9                            ; 4a4a12ff 00002000
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	ds_store_2addr_b64 v37, v[10:11], v[22:23] offset1:32       ; d9382000 00160a25
	buffer_load_b128 v[48:51], v36, s[28:31], null offen offset:512 ; c405c07c 40803830 00020024
	v_add_nc_u32_e32 v46, 0x2800, v9                            ; 4a5c12ff 00002800
	v_add_nc_u32_e32 v47, 0x3000, v9                            ; 4a5e12ff 00003000
	v_add_nc_u32_e32 v52, 0x3800, v9                            ; 4a6812ff 00003800
	ds_store_2addr_b64 v46, v[16:17], v[26:27] offset1:32       ; d9382000 001a102e
	ds_store_2addr_b64 v47, v[18:19], v[38:39] offset1:32       ; d9382000 0026122f
	ds_store_2addr_b64 v52, v[20:21], v[44:45] offset1:32       ; d9382000 002c1434
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	buffer_load_b128 v[16:19], v36, s[28:31], null offen offset:1024 ; c405c07c 40803810 00040024
	v_mad_u32_u24 v53, s19, 0x500, v5                           ; d60b0035 0415fe13 00000500
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v53, v53, v29                              ; 4a6a3b35
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[10:11], v53                                   ; d9d80000 0a000035
	ds_load_b64 v[20:21], v53 offset:2048                       ; d9d80800 14000035
	ds_load_b64 v[22:23], v53 offset:4096                       ; d9d81000 16000035
	buffer_load_b128 v[60:63], v36, s[28:31], null offen offset:1536 ; c405c07c 4080383c 00060024
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[26:27], v10                          ; 7e34dd0a
	s_wait_loadcnt 0x7                                          ; bfc00007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v57, v27, v81 :: v_dual_mul_f32 v56, v26, v80 ; c8c6a31b 3938a11a
	v_cvt_pk_f32_fp8_e32 v[26:27], v138                         ; 7e34dd8a
	v_dual_mul_f32 v59, v27, v83 :: v_dual_mul_f32 v58, v26, v82 ; c8c6a71b 3b3aa51a
	v_cvt_pk_f32_fp8_e32 v[26:27], v11                          ; 7e34dd0b
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v69, v27, v85 :: v_dual_mul_f32 v68, v26, v84 ; c8c6ab1b 4544a91a
	ds_load_b64 v[26:27], v53 offset:6144                       ; d9d81800 1a000035
	buffer_load_b128 v[64:67], v36, s[28:31], null offen offset:2048 ; c405c07c 40803840 00080024
	ds_load_b64 v[38:39], v53 offset:256                        ; d9d80100 26000035
	buffer_load_b128 v[92:95], v36, s[28:31], null offen offset:2560 ; c405c07c 4080385c 000a0024
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v71, v11, v87 :: v_dual_mul_f32 v70, v10, v86 ; c8c6af0b 4746ad0a
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[10:11], v20                          ; 7e14dd14
	v_dual_mul_f32 v73, v11, v81 :: v_dual_mul_f32 v72, v10, v80 ; c8c6a30b 4948a10a
	v_cvt_pk_f32_fp8_e32 v[10:11], v148                         ; 7e14dd94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v75, v11, v83 :: v_dual_mul_f32 v74, v10, v82 ; c8c6a70b 4b4aa50a
	v_cvt_pk_f32_fp8_e32 v[10:11], v21                          ; 7e14dd15
	v_cvt_pk_f32_fp8_e32 v[20:21], v149                         ; 7e28dd95
	v_dual_mul_f32 v77, v11, v85 :: v_dual_mul_f32 v76, v10, v84 ; c8c6ab0b 4d4ca90a
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[10:11], v22                          ; 7e14dd16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v89, v11, v81 :: v_dual_mul_f32 v88, v10, v80 ; c8c6a30b 5958a10a
	v_cvt_pk_f32_fp8_e32 v[10:11], v150                         ; 7e14dd96
	v_dual_mul_f32 v91, v11, v83 :: v_dual_mul_f32 v90, v10, v82 ; c8c6a70b 5b5aa50a
	v_cvt_pk_f32_fp8_e32 v[10:11], v23                          ; 7e14dd17
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v101, v11, v85 :: v_dual_mul_f32 v78, v20, v86 ; c8c6ab0b 654ead14
	v_dual_mul_f32 v79, v21, v87 :: v_dual_mul_f32 v100, v10, v84 ; c8c6af15 4f64a90a
	v_cvt_pk_f32_fp8_e32 v[10:11], v151                         ; 7e14dd97
	buffer_load_b128 v[20:23], v36, s[28:31], null offen offset:3072 ; c405c07c 40803814 000c0024
	ds_load_b64 v[44:45], v53 offset:2304                       ; d9d80900 2c000035
	v_dual_mul_f32 v103, v11, v87 :: v_dual_mul_f32 v102, v10, v86 ; c8c6af0b 6766ad0a
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[10:11], v26                          ; 7e14dd1a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v105, v11, v81                                ; 10d2a30b
	v_mul_f32_e32 v104, v10, v80                                ; 10d0a10a
	v_cvt_pk_f32_fp8_e32 v[10:11], v154                         ; 7e14dd9a
	v_dual_mul_f32 v107, v11, v83 :: v_dual_mul_f32 v106, v10, v82 ; c8c6a70b 6b6aa50a
	buffer_load_b128 v[80:83], v36, s[28:31], null offen offset:3584 ; c405c07c 40803850 000e0024
	v_cvt_pk_f32_fp8_e32 v[10:11], v27                          ; 7e14dd1b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v109, v11, v85 :: v_dual_mul_f32 v108, v10, v84 ; c8c6ab0b 6d6ca90a
	v_cvt_pk_f32_fp8_e32 v[10:11], v155                         ; 7e14dd9b
	v_dual_mul_f32 v111, v11, v87 :: v_dual_mul_f32 v110, v10, v86 ; c8c6af0b 6f6ead0a
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[10:11], v38                          ; 7e14dd26
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v11, v13 :: v_dual_mul_f32 v112, v10, v12 ; c8c61b0b 7170190a
	v_cvt_pk_f32_fp8_e32 v[10:11], v166                         ; 7e14dda6
	v_dual_mul_f32 v115, v11, v15 :: v_dual_mul_f32 v114, v10, v14 ; c8c61f0b 73721d0a
	v_cvt_pk_f32_fp8_e32 v[10:11], v39                          ; 7e14dd27
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v117, v11, v33 :: v_dual_mul_f32 v116, v10, v32 ; c8c6430b 7574410a
	v_cvt_pk_f32_fp8_e32 v[10:11], v167                         ; 7e14dda7
	ds_load_b64 v[26:27], v53 offset:4352                       ; d9d81100 1a000035
	ds_load_b64 v[38:39], v53 offset:6400                       ; d9d81900 26000035
	v_dual_mul_f32 v119, v11, v35 :: v_dual_mul_f32 v118, v10, v34 ; c8c6470b 7776450a
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[10:11], v44                          ; 7e14dd2c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v121, v11, v13 :: v_dual_mul_f32 v120, v10, v12 ; c8c61b0b 7978190a
	v_cvt_pk_f32_fp8_e32 v[10:11], v172                         ; 7e14ddac
	v_dual_mul_f32 v123, v11, v15 :: v_dual_mul_f32 v122, v10, v14 ; c8c61f0b 7b7a1d0a
	v_cvt_pk_f32_fp8_e32 v[10:11], v45                          ; 7e14dd2d
	v_add_lshl_u32 v54, s37, v2, 2                              ; d6470036 020a0425
	buffer_load_b32 v54, v54, s[24:27], null offen              ; c405007c 40803036 00000036
	v_dual_mul_f32 v125, v11, v33 :: v_dual_mul_f32 v124, v10, v32 ; c8c6430b 7d7c410a
	v_cvt_pk_f32_fp8_e32 v[10:11], v173                         ; 7e14ddad
	s_lshr_b32 s44, s44, 2                                      ; 852c822c
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_mad_u32_u24 v55, 0xc00, v2, s44                           ; d60b0037 00b204ff 00000c00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_dual_mul_f32 v127, v11, v35 :: v_dual_mul_f32 v126, v10, v34 ; c8c6470b 7f7e450a
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[10:11], v26                          ; 7e14dd1a
	v_add_lshl_u32 v55, v55, v31, 2                             ; d6470037 020a3f37
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_mul_f32 v129, v11, v13 :: v_dual_mul_f32 v128, v10, v12 ; c8c61b0b 8180190a
	v_cvt_pk_f32_fp8_e32 v[10:11], v154                         ; 7e14dd9a
	v_dual_mul_f32 v131, v11, v15 :: v_dual_mul_f32 v130, v10, v14 ; c8c61f0b 83821d0a
	v_cvt_pk_f32_fp8_e32 v[10:11], v27                          ; 7e14dd1b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v133, v11, v33 :: v_dual_mul_f32 v132, v10, v32 ; c8c6430b 8584410a
	v_cvt_pk_f32_fp8_e32 v[10:11], v155                         ; 7e14dd9b
	v_dual_mul_f32 v135, v11, v35 :: v_dual_mul_f32 v134, v10, v34 ; c8c6470b 8786450a
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[10:11], v38                          ; 7e14dd26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v137, v11, v13 :: v_dual_mul_f32 v136, v10, v12 ; c8c61b0b 8988190a
	v_cvt_pk_f32_fp8_e32 v[10:11], v166                         ; 7e14dda6
	v_dual_mul_f32 v139, v11, v15 :: v_dual_mul_f32 v138, v10, v14 ; c8c61f0b 8b8a1d0a
	buffer_load_b128 v[12:15], v55, s[28:31], null offen        ; c405c07c 4080380c 00000037
	v_cvt_pk_f32_fp8_e32 v[10:11], v39                          ; 7e14dd27
	v_lshl_add_u32 v84, s19, 10, v29                            ; d6460054 04751413
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_mul_f32 v141, v11, v33 :: v_dual_mul_f32 v140, v10, v32 ; c8c6430b 8d8c410a
	v_cvt_pk_f32_fp8_e32 v[10:11], v167                         ; 7e14dda7
	v_dual_mul_f32 v143, v11, v35 :: v_dual_mul_f32 v142, v10, v34 ; c8c6470b 8f8e450a
	ds_load_b64 v[10:11], v84 offset:8192                       ; d9d82000 0a000054
	ds_load_b64 v[26:27], v84 offset:10240                      ; d9d82800 1a000054
	ds_load_b64 v[32:33], v84 offset:12288                      ; d9d83000 20000054
	ds_load_b64 v[34:35], v84 offset:14336                      ; d9d83800 22000054
	ds_load_b64 v[38:39], v84 offset:8448                       ; d9d82100 26000054
	ds_load_b64 v[44:45], v84 offset:10496                      ; d9d82900 2c000054
	buffer_load_b128 v[96:99], v55, s[28:31], null offen offset:4096 ; c405c07c 40803860 00100037
	ds_load_b64 v[86:87], v84 offset:12544                      ; d9d83100 56000054
	ds_load_b64 v[144:145], v84 offset:14592                    ; d9d83900 90000054
	ds_load_b64 v[146:147], v84 offset:8704                     ; d9d82200 92000054
	ds_load_b64 v[148:149], v84 offset:10752                    ; d9d82a00 94000054
	ds_load_b64 v[150:151], v84 offset:12800                    ; d9d83200 96000054
	ds_load_b64 v[152:153], v84 offset:14848                    ; d9d83a00 98000054
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mov_b32 v159, v63 :: v_dual_mov_b32 v158, v62        ; ca10013f 9f9e013e
	v_dual_mov_b32 v63, v71 :: v_dual_mov_b32 v62, v70          ; ca100147 3f3e0146
	v_dual_mov_b32 v157, v61 :: v_dual_mov_b32 v156, v60        ; ca10013d 9d9c013c
	v_dual_mov_b32 v61, v69 :: v_dual_mov_b32 v60, v68          ; ca100145 3d3c0144
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_mov_b32 v71, v95 :: v_dual_mov_b32 v70, v94          ; ca10015f 4746015e
	v_dual_mov_b32 v95, v103 :: v_dual_mov_b32 v94, v102        ; ca100167 5f5e0166
	v_dual_mov_b32 v69, v93 :: v_dual_mov_b32 v68, v92          ; ca10015d 4544015c
	v_dual_mov_b32 v93, v101 :: v_dual_mov_b32 v92, v100        ; ca100165 5d5c0164
	buffer_load_b128 v[100:103], v55, s[28:31], null offen offset:512 ; c405c07c 40803864 00020037
	ds_load_b64 v[154:155], v84 offset:8960                     ; d9d82300 9a000054
	ds_load_b64 v[160:161], v84 offset:11008                    ; d9d82b00 a0000054
	ds_load_b64 v[162:163], v84 offset:13056                    ; d9d83300 a2000054
	ds_load_b64 v[164:165], v84 offset:15104                    ; d9d83b00 a4000054
	buffer_load_b128 v[172:175], v55, s[28:31], null offen offset:4608 ; c405c07c 408038ac 00120037
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[40:41], v[26:27], v[72:79] ; cc464048 1d223528
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[32:33], v[88:95] ; cc464058 1d624128
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[40:41], v[10:11], v[56:63] ; cc464038 1ce21528
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[34:35], v[104:111] ; cc464068 1da24528
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[10:11], v[112:119] ; cc464070 1dc2152a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[26:27], v[120:127] ; cc464078 1de2352a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[32:33], v[128:135] ; cc464080 1e02412a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[34:35], v[136:143] ; cc464088 1e22452a
	ds_load_b64 v[10:11], v84 offset:9216                       ; d9d82400 0a000054
	ds_load_b64 v[26:27], v84 offset:11264                      ; d9d82c00 1a000054
	ds_load_b64 v[32:33], v84 offset:13312                      ; d9d83400 20000054
	ds_load_b64 v[34:35], v84 offset:15360                      ; d9d83c00 22000054
	buffer_load_b128 v[40:43], v55, s[28:31], null offen offset:1024 ; c405c07c 40803828 00040037
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[48:49], v[44:45], v[72:79] ; cc464048 1d225930
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[86:87], v[88:95] ; cc464058 1d62ad30
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[48:49], v[38:39], v[56:63] ; cc464038 1ce24d30
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[144:145], v[104:111] ; cc464068 1da32130
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[38:39], v[112:119] ; cc464070 1dc24d32
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[44:45], v[120:127] ; cc464078 1de25932
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[86:87], v[128:135] ; cc464080 1e02ad32
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[50:51], v[144:145], v[136:143] ; cc464088 1e232132
	ds_load_b64 v[38:39], v84 offset:9472                       ; d9d82500 26000054
	ds_load_b64 v[44:45], v84 offset:11520                      ; d9d82d00 2c000054
	ds_load_b64 v[48:49], v84 offset:13568                      ; d9d83500 30000054
	ds_load_b64 v[50:51], v84 offset:15616                      ; d9d83d00 32000054
	buffer_load_b128 v[176:179], v55, s[28:31], null offen offset:5120 ; c405c07c 408038b0 00140037
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[16:17], v[148:149], v[72:79] ; cc464048 1d232910
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[150:151], v[88:95] ; cc464058 1d632d10
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[16:17], v[146:147], v[56:63] ; cc464038 1ce32510
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[152:153], v[104:111] ; cc464068 1da33110
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[146:147], v[112:119] ; cc464070 1dc32512
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[148:149], v[120:127] ; cc464078 1de32912
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[150:151], v[128:135] ; cc464080 1e032d12
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[152:153], v[136:143] ; cc464088 1e233112
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[156:157], v[160:161], v[72:79] ; cc464048 1d23419c
	ds_load_b64 v[16:17], v84 offset:9728                       ; d9d82600 10000054
	ds_load_b64 v[18:19], v84 offset:11776                      ; d9d82e00 12000054
	ds_load_b64 v[86:87], v84 offset:13824                      ; d9d83600 56000054
	ds_load_b64 v[144:145], v84 offset:15872                    ; d9d83e00 90000054
	ds_load_b64 v[146:147], v84 offset:9984                     ; d9d82700 92000054
	ds_load_b64 v[148:149], v84 offset:12032                    ; d9d82f00 94000054
	ds_load_b64 v[150:151], v84 offset:14080                    ; d9d83700 96000054
	ds_load_b64 v[152:153], v84 offset:16128                    ; d9d83f00 98000054
	s_wait_dscnt 0x11                                           ; bfc60011
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[156:157], v[162:163], v[88:95] ; cc464058 1d63459c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[156:157], v[154:155], v[56:63] ; cc464038 1ce3359c
	s_wait_dscnt 0x10                                           ; bfc60010
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[156:157], v[164:165], v[104:111] ; cc464068 1da3499c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[158:159], v[154:155], v[112:119] ; cc464070 1dc3359e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[158:159], v[160:161], v[120:127] ; cc464078 1de3419e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[158:159], v[162:163], v[128:135] ; cc464080 1e03459e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[158:159], v[164:165], v[136:143] ; cc464088 1e23499e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[64:65], v[26:27], v[72:79] ; cc464048 1d223540
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[32:33], v[88:95] ; cc464058 1d624140
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[64:65], v[10:11], v[56:63] ; cc464038 1ce21540
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[64:65], v[34:35], v[104:111] ; cc464068 1da24540
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[10:11], v[112:119] ; cc464070 1dc21542
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[66:67], v[26:27], v[120:127] ; cc464078 1de23542
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[32:33], v[128:135] ; cc464080 1e024142
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[66:67], v[34:35], v[136:143] ; cc464088 1e224542
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[68:69], v[44:45], v[72:79] ; cc464048 1d225944
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[68:69], v[48:49], v[88:95] ; cc464058 1d626144
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[68:69], v[38:39], v[56:63] ; cc464038 1ce24d44
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[50:51], v[104:111] ; cc464068 1da26544
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[38:39], v[112:119] ; cc464070 1dc24d46
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[44:45], v[120:127] ; cc464078 1de25946
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[48:49], v[128:135] ; cc464080 1e026146
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[70:71], v[50:51], v[136:143] ; cc464088 1e226546
	s_wait_loadcnt_dscnt 0x806                                  ; bfc80806
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[20:21], v[18:19], v[72:79] ; cc464048 1d222514
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[86:87], v[88:95] ; cc464058 1d62ad14
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[20:21], v[16:17], v[56:63] ; cc464038 1ce22114
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[20:21], v[144:145], v[104:111] ; cc464068 1da32114
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[16:17], v[112:119] ; cc464070 1dc22116
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[18:19], v[120:127] ; cc464078 1de22516
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[86:87], v[128:135] ; cc464080 1e02ad16
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[144:145], v[136:143] ; cc464088 1e232116
	s_wait_loadcnt_dscnt 0x702                                  ; bfc80702
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[80:81], v[148:149], v[72:79] ; cc464048 1d232950
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[80:81], v[150:151], v[88:95] ; cc464058 1d632d50
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[80:81], v[146:147], v[56:63] ; cc464038 1ce32550
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[80:81], v[152:153], v[104:111] ; cc464068 1da33150
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[146:147], v[112:119] ; cc464070 1dc32552
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[82:83], v[148:149], v[120:127] ; cc464078 1de32952
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[150:151], v[128:135] ; cc464080 1e032d52
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[82:83], v[152:153], v[136:143] ; cc464088 1e233152
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_store_2addr_b64 v9, v[10:11], v[22:23] offset1:32        ; d9382000 00160a09
	ds_store_2addr_b64 v24, v[16:17], v[26:27] offset1:32       ; d9382000 001a1018
	ds_store_2addr_b64 v25, v[18:19], v[32:33] offset1:32       ; d9382000 00201219
	ds_store_2addr_b64 v28, v[20:21], v[34:35] offset1:32       ; d9382000 0022141c
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_lshl_add_u32 v85, s19, 11, v29                            ; d6460055 04751613
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[10:11], v85                                   ; d9d80000 0a000055
	ds_load_b64 v[16:17], v85 offset:2048                       ; d9d80800 10000055
	ds_load_b64 v[18:19], v85 offset:4096                       ; d9d81000 12000055
	ds_load_b64 v[20:21], v85 offset:6144                       ; d9d81800 14000055
	ds_load_b64 v[22:23], v85 offset:256                        ; d9d80100 16000055
	ds_load_b64 v[24:25], v85 offset:2304                       ; d9d80900 18000055
	ds_load_b64 v[26:27], v85 offset:4352                       ; d9d81100 1a000055
	ds_load_b64 v[32:33], v85 offset:6400                       ; d9d81900 20000055
	s_wait_loadcnt_dscnt 0x507                                  ; bfc80507
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[12:13], v[10:11], 0 ; cc464038 1a02150c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[10:11], 0 ; cc464068 1a02150e
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[12:13], v[16:17], 0 ; cc464040 1a02210c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[16:17], 0 ; cc464070 1a02210e
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[12:13], v[18:19], 0 ; cc464048 1a02250c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[18:19], 0 ; cc464078 1a02250e
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[20:21], 0 ; cc464080 1a02290e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[20:21], 0 ; cc464058 1a02290c
	ds_load_b64 v[12:13], v85 offset:512                        ; d9d80200 0c000055
	ds_load_b64 v[14:15], v85 offset:2560                       ; d9d80a00 0e000055
	ds_load_b64 v[34:35], v85 offset:4608                       ; d9d81200 22000055
	ds_load_b64 v[38:39], v85 offset:6656                       ; d9d81a00 26000055
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[10:11], 0 ; cc4640b8 1a021562
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[96:97], v[10:11], 0 ; cc464088 1a021560
	v_dual_mov_b32 v10, v47 :: v_dual_mov_b32 v9, v46           ; ca10012f 0a08012e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[16:17], 0 ; cc464090 1a022160
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[98:99], v[16:17], 0 ; cc46402c 1a022162
	v_dual_mov_b32 v16, v85 :: v_dual_mov_b32 v11, v84          ; ca100155 100a0154
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[96:97], v[18:19], 0 ; cc464098 1a022560
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[98:99], v[18:19], 0 ; cc464050 1a022562
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b32_e32 v18, v178                                     ; 7e2403b2
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[96:97], v[20:21], 0 ; cc4640a0 1a022960
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[100:101], v[22:23], v[56:63] ; cc464038 1ce22d64
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[100:101], v[24:25], v[64:71] ; cc464040 1d023164
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[100:101], v[26:27], v[72:79] ; cc464048 1d223564
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[100:101], v[32:33], v[88:95] ; cc464058 1d624164
	v_dual_mov_b32 v28, v16 :: v_dual_mov_b32 v19, v179         ; ca100110 1c1201b3
	v_dual_mov_b32 v16, v176 :: v_dual_mov_b32 v17, v177        ; ca1001b0 101001b1
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[98:99], v[20:21], 0 ; cc4640b0 1a022962
	ds_load_b64 v[20:21], v28 offset:768                        ; d9d80300 1400001c
	ds_load_b64 v[96:97], v28 offset:2816                       ; d9d80b00 6000001c
	ds_load_b64 v[98:99], v28 offset:4864                       ; d9d81300 6200001c
	ds_load_b64 v[100:101], v28 offset:6912                     ; d9d81b00 6400001c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[102:103], v[22:23], v[104:111] ; cc464068 1da22d66
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[102:103], v[24:25], v[112:119] ; cc464070 1dc23166
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[102:103], v[26:27], v[120:127] ; cc464078 1de23566
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[102:103], v[32:33], v[128:135] ; cc464080 1e024166
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[172:173], v[22:23], v[136:143] ; cc464088 1e222dac
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[172:173], v[24:25], v[144:151] ; cc464090 1e4231ac
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[172:173], v[26:27], v[152:159] ; cc464098 1e6235ac
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[172:173], v[32:33], v[160:167] ; cc4640a0 1e8241ac
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[174:175], v[22:23], v[184:191] ; cc4640b8 1ee22dae
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[174:175], v[24:25], v[44:51] ; cc46402c 1cb231ae
	v_mov_b32_e32 v36, v170                                     ; 7e4803aa
	v_mov_b32_e32 v102, v171                                    ; 7ecc03ab
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[22:25], v55, s[28:31], null offen offset:1536 ; c405c07c 40803816 00060037
	buffer_load_b128 v[170:173], v55, s[28:31], null offen offset:5632 ; c405c07c 408038aa 00160037
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[174:175], v[26:27], v[80:87] ; cc464050 1d4235ae
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[174:175], v[32:33], v[176:183] ; cc4640b0 1ec241ae
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[40:41], v[12:13], v[56:63] ; cc464038 1ce21928
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[40:41], v[14:15], v[64:71] ; cc464040 1d021d28
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[40:41], v[34:35], v[72:79] ; cc464048 1d224528
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[38:39], v[88:95] ; cc464058 1d624d28
	ds_load_b64 v[26:27], v28 offset:1024                       ; d9d80400 1a00001c
	ds_load_b64 v[32:33], v28 offset:3072                       ; d9d80c00 2000001c
	ds_load_b64 v[174:175], v28 offset:5120                     ; d9d81400 ae00001c
	ds_load_b64 v[40:41], v28 offset:7168                       ; d9d81c00 2800001c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[12:13], v[104:111] ; cc464068 1da2192a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[14:15], v[112:119] ; cc464070 1dc21d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[34:35], v[120:127] ; cc464078 1de2452a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[38:39], v[128:135] ; cc464080 1e024d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[16:17], v[12:13], v[136:143] ; cc464088 1e221910
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[16:17], v[14:15], v[144:151] ; cc464090 1e421d10
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[34:35], v[152:159] ; cc464098 1e624510
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[38:39], v[160:167] ; cc4640a0 1e824d10
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[18:19], v[12:13], v[184:191] ; cc4640b8 1ee21912
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[18:19], v[14:15], v[44:51] ; cc46402c 1cb21d12
	v_dual_mov_b32 v43, v19 :: v_dual_mov_b32 v42, v18          ; ca100113 2b2a0112
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[12:15], v55, s[28:31], null offen offset:2048 ; c405c07c 4080380c 00080037
	buffer_load_b128 v[16:19], v55, s[28:31], null offen offset:6144 ; c405c07c 40803810 00180037
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[42:43], v[34:35], v[80:87] ; cc464050 1d42452a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[38:39], v[176:183] ; cc4640b0 1ec24d2a
	s_wait_loadcnt_dscnt 0x305                                  ; bfc80305
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[22:23], v[98:99], v[72:79] ; cc464048 1d22c516
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[22:23], v[96:97], v[64:71] ; cc464040 1d02c116
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[22:23], v[20:21], v[56:63] ; cc464038 1ce22916
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[22:23], v[100:101], v[88:95] ; cc464058 1d62c916
	ds_load_b64 v[34:35], v28 offset:1280                       ; d9d80500 2200001c
	ds_load_b64 v[38:39], v28 offset:3328                       ; d9d80d00 2600001c
	ds_load_b64 v[42:43], v28 offset:5376                       ; d9d81500 2a00001c
	ds_load_b64 v[22:23], v28 offset:7424                       ; d9d81d00 1600001c
	v_mov_b32_e32 v103, v169                                    ; 7ece03a9
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[20:21], v[104:111] ; cc464068 1da22918
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[98:99], v[120:127] ; cc464078 1de2c518
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[96:97], v[112:119] ; cc464070 1dc2c118
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[24:25], v[100:101], v[128:135] ; cc464080 1e02c918
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[170:171], v[96:97], v[144:151] ; cc464090 1e42c1aa
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[170:171], v[20:21], v[136:143] ; cc464088 1e2229aa
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[170:171], v[98:99], v[152:159] ; cc464098 1e62c5aa
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[170:171], v[100:101], v[160:167] ; cc4640a0 1e82c9aa
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[172:173], v[20:21], v[184:191] ; cc4640b8 1ee229ac
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v25, v23 :: v_dual_mov_b32 v24, v22          ; ca100117 19180116
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[168:171], v55, s[28:31], null offen offset:2560 ; c405c07c 408038a8 000a0037
	buffer_load_b128 v[20:23], v55, s[28:31], null offen offset:6656 ; c405c07c 40803814 001a0037
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[172:173], v[96:97], v[44:51] ; cc46402c 1cb2c1ac
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[172:173], v[98:99], v[80:87] ; cc464050 1d42c5ac
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[100:101], v[176:183] ; cc4640b0 1ec2c9ac
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[12:13], v[174:175], v[72:79] ; cc464048 1d235d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[40:41], v[88:95] ; cc464058 1d62510c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[12:13], v[26:27], v[56:63] ; cc464038 1ce2350c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[12:13], v[32:33], v[64:71] ; cc464040 1d02410c
	ds_load_b64 v[96:97], v28 offset:1536                       ; d9d80600 6000001c
	ds_load_b64 v[98:99], v28 offset:3584                       ; d9d80e00 6200001c
	ds_load_b64 v[100:101], v28 offset:5632                     ; d9d81600 6400001c
	ds_load_b64 v[12:13], v28 offset:7680                       ; d9d81e00 0c00001c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[26:27], v[104:111] ; cc464068 1da2350e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[174:175], v[120:127] ; cc464078 1de35d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[32:33], v[112:119] ; cc464070 1dc2410e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[40:41], v[128:135] ; cc464080 1e02510e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[16:17], v[26:27], v[136:143] ; cc464088 1e223510
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[174:175], v[152:159] ; cc464098 1e635d10
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[16:17], v[40:41], v[160:167] ; cc4640a0 1e825110
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[16:17], v[32:33], v[144:151] ; cc464090 1e424110
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[18:19], v[26:27], v[184:191] ; cc4640b8 1ee23512
	v_dual_mov_b32 v173, v29 :: v_dual_mov_b32 v172, v28        ; ca10011d adac011c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[14:17], v55, s[28:31], null offen offset:3072 ; c405c07c 4080380e 000c0037
	buffer_load_b128 v[26:29], v55, s[28:31], null offen offset:7168 ; c405c07c 4080381a 001c0037
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[18:19], v[32:33], v[44:51] ; cc46402c 1cb24112
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[174:175], v[80:87] ; cc464050 1d435d12
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[18:19], v[40:41], v[176:183] ; cc4640b0 1ec25112
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[168:169], v[42:43], v[72:79] ; cc464048 1d2255a8
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[168:169], v[24:25], v[88:95] ; cc464058 1d6231a8
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[168:169], v[34:35], v[56:63] ; cc464038 1ce245a8
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[168:169], v[38:39], v[64:71] ; cc464040 1d024da8
	ds_load_b64 v[32:33], v172 offset:1792                      ; d9d80700 200000ac
	ds_load_b64 v[18:19], v172 offset:3840                      ; d9d80f00 120000ac
	ds_load_b64 v[40:41], v172 offset:5888                      ; d9d81700 280000ac
	ds_load_b64 v[168:169], v172 offset:7936                    ; d9d81f00 a80000ac
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[170:171], v[38:39], v[112:119] ; cc464070 1dc24daa
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[170:171], v[34:35], v[104:111] ; cc464068 1da245aa
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[20:21], v[38:39], v[144:151] ; cc464090 1e424d14
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[20:21], v[34:35], v[136:143] ; cc464088 1e224514
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[20:21], v[24:25], v[160:167] ; cc4640a0 1e823114
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[20:21], v[42:43], v[152:159] ; cc464098 1e625514
	v_mov_b32_e32 v20, v173                                     ; 7e2803ad
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[22:23], v[34:35], v[184:191] ; cc4640b8 1ee24516
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[22:23], v[38:39], v[44:51] ; cc46402c 1cb24d16
	v_dual_mov_b32 v34, v37 :: v_dual_mov_b32 v21, v36          ; ca100125 22140124
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[172:175], v55, s[28:31], null offen offset:3584 ; c405c07c 408038ac 000e0037
	buffer_load_b128 v[36:39], v55, s[28:31], null offen offset:7680 ; c405c07c 40803824 001e0037
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[170:171], v[42:43], v[120:127] ; cc464078 1de255aa
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[170:171], v[24:25], v[128:135] ; cc464080 1e0231aa
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[22:23], v[42:43], v[80:87] ; cc464050 1d425516
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[22:23], v[24:25], v[176:183] ; cc4640b0 1ec23116
	v_mad_u32_u24 v20, s19, 0x820, v20                          ; d60b0014 0451fe13 00000820
	s_wait_loadcnt_dscnt 0x307                                  ; bfc80307
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[14:15], v[96:97], v[56:63] ; cc464038 1ce2c10e
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[100:101], v[72:79] ; cc464048 1d22c90e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[98:99], v[64:71] ; cc464040 1d02c50e
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[14:15], v[12:13], v[88:95] ; cc464058 1d62190e
	ds_load_b64 v[22:23], v20                                   ; d9d80000 16000014
	ds_load_b64 v[24:25], v20 offset:2048                       ; d9d80800 18000014
	ds_load_b64 v[42:43], v20 offset:4096                       ; d9d81000 2a000014
	ds_load_b64 v[14:15], v20 offset:6144                       ; d9d81800 0e000014
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[16:17], v[98:99], v[112:119] ; cc464070 1dc2c510
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[96:97], v[104:111] ; cc464068 1da2c110
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[16:17], v[100:101], v[120:127] ; cc464078 1de2c910
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[16:17], v[12:13], v[128:135] ; cc464080 1e021910
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mov_b32 v17, v29 :: v_dual_mov_b32 v16, v28          ; ca10011d 1110011c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[96:97], v[136:143] ; cc464088 1e22c11a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[26:27], v[98:99], v[144:151] ; cc464090 1e42c51a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[26:27], v[100:101], v[152:159] ; cc464098 1e62c91a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[26:27], v[12:13], v[160:167] ; cc4640a0 1e82191a
	buffer_load_b128 v[26:29], v55, s[28:31], null offen offset:8192 ; c405c07c 4080381a 00200037
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[16:17], v[98:99], v[44:51] ; cc46402c 1cb2c510
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[100:101], v[80:87] ; cc464050 1d42c910
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[12:13], v[176:183] ; cc4640b0 1ec21910
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[16:17], v[96:97], v[184:191] ; cc4640b8 1ee2c110
	ds_load_b64 v[96:97], v20 offset:256                        ; d9d80100 60000014
	ds_load_b64 v[98:99], v20 offset:2304                       ; d9d80900 62000014
	ds_load_b64 v[100:101], v20 offset:4352                     ; d9d81100 64000014
	ds_load_b64 v[12:13], v20 offset:6400                       ; d9d81900 0c000014
	s_mov_b32 s91, 0x76543210                                   ; bedb00ff 76543210
	s_mov_b32 s92, 0xfedcba98                                   ; bedc00ff fedcba98
	s_movk_i32 s93, 0x410                                       ; b05d0410
	s_wait_loadcnt_dscnt 0x209                                  ; bfc80209
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[174:175], v[40:41], v[120:127] ; cc464078 1de251ae
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[174:175], v[168:169], v[128:135] ; cc464080 1e0351ae
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[172:173], v[40:41], v[72:79] ; cc464048 1d2251ac
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[174:175], v[32:33], v[104:111] ; cc464068 1da241ae
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[172:173], v[168:169], v[88:95] ; cc464058 1d6351ac
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[172:173], v[32:33], v[56:63] ; cc464038 1ce241ac
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[174:175], v[18:19], v[112:119] ; cc464070 1dc225ae
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[172:173], v[18:19], v[64:71] ; cc464040 1d0225ac
	v_dual_mul_f32 v170, v107, v107 :: v_dual_mul_f32 v35, v105, v105 ; c8c6d76b aa22d369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v170, v59, v59 :: v_dual_fmac_f32 v35, v57, v57 ; c800773b aa227339
	v_dual_fmac_f32 v170, v63, v63 :: v_dual_fmac_f32 v35, v61, v61 ; c8007f3f aa227b3d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v170, v111, v111 :: v_dual_fmac_f32 v35, v109, v109 ; c800df6f aa22db6d
	v_dual_fmac_f32 v170, v58, v58 :: v_dual_fmac_f32 v35, v56, v56 ; c800753a aa227138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v170, v106, v106 :: v_dual_fmac_f32 v35, v104, v104 ; c800d56a aa22d168
	v_dual_fmac_f32 v170, v62, v62 :: v_dual_fmac_f32 v35, v60, v60 ; c8007d3e aa22793c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v170, v110, v110 :: v_dual_fmac_f32 v35, v108, v108 ; c800dd6e aa22d96c
	v_fma_mixlo_f16 v171, 1.0, v35, v170                        ; cc2100ab 06aa46f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
(invalid instruction)                                        ; d5eb00ac
	v_cndmask_b32_e32 v0, v171, v128, vcc_lo                    ; 020101ab
	v_dual_mul_f32 v175, v115, v115 :: v_dual_mul_f32 v174, v113, v113 ; c8c6e773 afaee371
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_permlanex16_b32 v172, v172, s91, s92 op_sel:[1,1]         ; d65c18ac 0170b7ac
	v_dual_fmac_f32 v175, v67, v67 :: v_dual_fmac_f32 v174, v65, v65 ; c8008743 afae8341
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d53200ab
	v_cndmask_b32_e32 v1, v171, v172, vcc_lo                    ; 020359ab
	v_dual_fmac_f32 v175, v71, v71 :: v_dual_fmac_f32 v174, v69, v69 ; c8008f47 afae8b45
(invalid instruction)                                        ; d53100ab
	v_cndmask_b32_e32 v1, s93, v171, vcc_lo                     ; 0203565d
	v_dual_fmac_f32 v175, v119, v119 :: v_dual_fmac_f32 v174, v117, v117 ; c800ef77 afaeeb75
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d58b00ad
	v_cndmask_b32_e32 v0, v171, v128, vcc_lo                    ; 020101ab
	v_dual_fmac_f32 v175, v66, v66 :: v_dual_fmac_f32 v174, v64, v64 ; c8008542 afae8140
	v_rsq_f32_e32 v173, v173                                    ; 7f5a5dad
	v_dual_fmac_f32 v175, v114, v114 :: v_dual_fmac_f32 v174, v112, v112 ; c800e572 afaee170
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870125
	v_mul_f32_e32 v173, v173, v54                               ; 115a6dad
	v_dual_fmac_f32 v175, v70, v70 :: v_dual_fmac_f32 v174, v68, v68 ; c8008d46 afae8944
	v_dual_mul_f32 v111, v111, v173 :: v_dual_mul_f32 v110, v110, v173 ; c8c75b6f 6f6f5b6e
	v_dual_mul_f32 v63, v63, v173 :: v_dual_mul_f32 v62, v62, v173 ; c8c75b3f 3f3f5b3e
	v_dual_mul_f32 v105, v105, v173 :: v_dual_mul_f32 v104, v104, v173 ; c8c75b69 69695b68
	v_dual_mul_f32 v107, v107, v173 :: v_dual_mul_f32 v106, v106, v173 ; c8c75b6b 6b6b5b6a
	v_dual_mul_f32 v56, v56, v173 :: v_dual_mul_f32 v57, v57, v173 ; c8c75b38 38395b39
	v_dual_mul_f32 v60, v60, v173 :: v_dual_mul_f32 v61, v61, v173 ; c8c75b3c 3c3d5b3d
	v_dual_mul_f32 v58, v58, v173 :: v_dual_mul_f32 v59, v59, v173 ; c8c75b3a 3a3b5b3b
	v_dual_mul_f32 v109, v109, v173 :: v_dual_mul_f32 v108, v108, v173 ; c8c75b6d 6d6d5b6c
	v_dual_fmac_f32 v175, v118, v118 :: v_dual_fmac_f32 v174, v116, v116 ; c800ed76 afaee974
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mixlo_f16 v35, 1.0, v174, v175                        ; cc210023 06bf5cf2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v58, v35                                  ; 7e74d723
	v_permlanex16_b32 v58, v58, s91, s92 op_sel:[1,1]           ; d65c183a 0170b73a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v35, v35, v58                                 ; 64467523
	v_max_num_f16_e32 v35, s93, v35                             ; 6246465d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v59, v35                                  ; 7e761723
	v_rsq_f32_e32 v59, v59                                      ; 7e765d3b
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v59, v59, v54                                 ; 10766d3b
	v_dual_mul_f32 v65, v65, v59 :: v_dual_mul_f32 v64, v64, v59 ; c8c67741 41407740
	v_dual_mul_f32 v115, v115, v59 :: v_dual_mul_f32 v114, v114, v59 ; c8c67773 73727772
	v_dual_mul_f32 v71, v71, v59 :: v_dual_mul_f32 v70, v70, v59 ; c8c67747 47467746
	v_dual_mul_f32 v113, v113, v59 :: v_dual_mul_f32 v112, v112, v59 ; c8c67771 71707770
	v_dual_mul_f32 v67, v67, v59 :: v_dual_mul_f32 v66, v66, v59 ; c8c67743 43427742
	v_dual_mul_f32 v69, v69, v59 :: v_dual_mul_f32 v68, v68, v59 ; c8c67745 45447744
	v_dual_mul_f32 v117, v117, v59 :: v_dual_mul_f32 v116, v116, v59 ; c8c67775 75747774
	v_dual_mul_f32 v119, v119, v59 :: v_dual_mul_f32 v118, v118, v59 ; c8c67777 77767776
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_dual_mul_f32 v65, v123, v123 :: v_dual_mul_f32 v64, v121, v121 ; c8c6f77b 4140f379
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_fmac_f32 v65, v75, v75 :: v_dual_fmac_f32 v64, v73, v73 ; c800974b 41409349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v65, v79, v79 :: v_dual_fmac_f32 v64, v77, v77 ; c8009f4f 41409b4d
	v_dual_fmac_f32 v65, v127, v127 :: v_dual_fmac_f32 v64, v125, v125 ; c800ff7f 4140fb7d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v65, v74, v74 :: v_dual_fmac_f32 v64, v72, v72 ; c800954a 41409148
	v_dual_fmac_f32 v65, v122, v122 :: v_dual_fmac_f32 v64, v120, v120 ; c800f57a 4140f178
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v65, v78, v78 :: v_dual_fmac_f32 v64, v76, v76 ; c8009d4e 4140994c
	v_dual_fmac_f32 v65, v126, v126 :: v_dual_fmac_f32 v64, v124, v124 ; c800fd7e 4140f97c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v66, 1.0, v64, v65                          ; cc210042 050680f2
	v_cvt_u32_u16_e32 v67, v66                                  ; 7e86d742
	v_dual_mul_f32 v70, v131, v131 :: v_dual_mul_f32 v69, v129, v129 ; c8c70783 46450381
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v67, v67, s91, s92 op_sel:[1,1]           ; d65c1843 0170b743
	v_dual_fmac_f32 v70, v91, v91 :: v_dual_fmac_f32 v69, v89, v89 ; c800b75b 4644b359
	v_add_f16_e32 v66, v66, v67                                 ; 64848742
	v_dual_fmac_f32 v70, v95, v95 :: v_dual_fmac_f32 v69, v93, v93 ; c800bf5f 4644bb5d
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_max_num_f16_e32 v66, s93, v66                             ; 6284845d
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[36:37], v[32:33], v[136:143] ; cc464088 1e224124
	v_cvt_f32_f16_e32 v68, v66                                  ; 7e881742
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[36:37], v[18:19], v[144:151] ; cc464090 1e422524
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[36:37], v[40:41], v[152:159] ; cc464098 1e625124
	v_rsq_f32_e32 v68, v68                                      ; 7e885d44
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[36:37], v[168:169], v[160:167] ; cc4640a0 1e835124
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[38:39], v[32:33], v[184:191] ; cc4640b8 1ee24126
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[38:39], v[18:19], v[44:51] ; cc46402c 1cb22526
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[38:39], v[40:41], v[80:87] ; cc464050 1d425126
	v_mul_f32_e32 v68, v68, v54                                 ; 10886d44
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[38:39], v[168:169], v[176:183] ; cc4640b0 1ec35126
	v_dual_fmac_f32 v70, v135, v135 :: v_dual_fmac_f32 v69, v133, v133 ; c8010f87 46450b85
	v_dual_mul_f32 v79, v79, v68 :: v_dual_mul_f32 v78, v78, v68 ; c8c6894f 4f4e894e
	v_dual_mul_f32 v120, v120, v68 :: v_dual_mul_f32 v121, v121, v68 ; c8c68978 78788979
	v_dual_mul_f32 v122, v122, v68 :: v_dual_mul_f32 v123, v123, v68 ; c8c6897a 7a7a897b
	v_dual_mul_f32 v75, v75, v68 :: v_dual_mul_f32 v74, v74, v68 ; c8c6894b 4b4a894a
	v_dual_mul_f32 v124, v124, v68 :: v_dual_mul_f32 v125, v125, v68 ; c8c6897c 7c7c897d
	v_dual_mul_f32 v73, v73, v68 :: v_dual_mul_f32 v72, v72, v68 ; c8c68949 49488948
	v_dual_mul_f32 v77, v77, v68 :: v_dual_mul_f32 v76, v76, v68 ; c8c6894d 4d4c894c
	v_dual_mul_f32 v127, v127, v68 :: v_dual_mul_f32 v126, v126, v68 ; c8c6897f 7f7e897e
	v_dual_fmac_f32 v70, v90, v90 :: v_dual_fmac_f32 v69, v88, v88 ; c800b55a 4644b158
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_fmac_f32 v70, v130, v130 :: v_dual_fmac_f32 v69, v128, v128 ; c8010582 46450180
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v70, v94, v94 :: v_dual_fmac_f32 v69, v92, v92 ; c800bd5e 4644b95c
	v_dual_fmac_f32 v70, v134, v134 :: v_dual_fmac_f32 v69, v132, v132 ; c8010d86 46450984
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_fma_mixlo_f16 v71, 1.0, v69, v70                          ; cc210047 051a8af2
	v_mul_f32_e32 v74, v185, v185                               ; 109573b9
	v_cvt_u32_u16_e32 v72, v71                                  ; 7e90d747
	v_dual_mul_f32 v75, v187, v187 :: v_dual_fmac_f32 v74, v137, v137 ; c8c177bb 4b4b1389
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v72, v72, s91, s92 op_sel:[1,1]           ; d65c1848 0170b748
	v_dual_fmac_f32 v74, v141, v141 :: v_dual_fmac_f32 v75, v139, v139 ; c8011b8d 4a4b178b
	v_add_f16_e32 v71, v71, v72                                 ; 648e9147
	v_dual_fmac_f32 v75, v143, v143 :: v_dual_fmac_f32 v74, v189, v189 ; c8011f8f 4b4b7bbd
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_max_num_f16_e32 v71, s93, v71                             ; 628e8e5d
	v_dual_fmac_f32 v74, v136, v136 :: v_dual_fmac_f32 v75, v191, v191 ; c8011188 4a4b7fbf
	v_cvt_f32_f16_e32 v73, v71                                  ; 7e921747
	v_dual_fmac_f32 v75, v138, v138 :: v_dual_fmac_f32 v74, v184, v184 ; c801158a 4b4b71b8
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1) ; bf8702a2
	v_rsq_f32_e32 v73, v73                                      ; 7e925d49
	v_dual_fmac_f32 v75, v186, v186 :: v_dual_fmac_f32 v74, v140, v140 ; c80175ba 4b4b198c
	v_mul_f32_e32 v73, v73, v54                                 ; 10926d49
	v_dual_fmac_f32 v75, v142, v142 :: v_dual_fmac_f32 v74, v188, v188 ; c8011d8e 4b4b79bc
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_dual_mul_f32 v92, v92, v73 :: v_dual_mul_f32 v93, v93, v73 ; c8c6935c 5c5c935d
	v_dual_mul_f32 v133, v133, v73 :: v_dual_mul_f32 v132, v132, v73 ; c8c69385 85849384
	buffer_load_b128 v[64:67], v55, s[28:31], null offen offset:8704 ; c405c07c 40803840 00220037
	v_dual_mul_f32 v95, v95, v73 :: v_dual_mul_f32 v94, v94, v73 ; c8c6935f 5f5e935e
	v_dual_mul_f32 v129, v129, v73 :: v_dual_mul_f32 v128, v128, v73 ; c8c69381 81809380
	v_dual_mul_f32 v88, v88, v73 :: v_dual_mul_f32 v89, v89, v73 ; c8c69358 58589359
	v_dual_mul_f32 v90, v90, v73 :: v_dual_mul_f32 v91, v91, v73 ; c8c6935a 5a5a935b
	v_dual_mul_f32 v135, v135, v73 :: v_dual_mul_f32 v134, v134, v73 ; c8c69387 87869386
	v_dual_mul_f32 v131, v131, v73 :: v_dual_mul_f32 v130, v130, v73 ; c8c69383 83829382
	v_fmac_f32_e32 v75, v190, v190                              ; 56977dbe
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	buffer_load_b128 v[68:71], v55, s[28:31], null offen offset:9216 ; c405c07c 40803844 00240037
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mixlo_f16 v76, 1.0, v74, v75                          ; cc21004c 052e94f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_u32_u16_e32 v77, v76                                  ; 7e9ad74c
	v_permlanex16_b32 v77, v77, s91, s92 op_sel:[1,1]           ; d65c184d 0170b74d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v76, v76, v77                                 ; 64989b4c
	v_max_num_f16_e32 v76, s93, v76                             ; 6298985d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v78, v76                                  ; 7e9c174c
	v_rsq_f32_e32 v78, v78                                      ; 7e9c5d4e
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v185, v185, v78 :: v_dual_mul_f32 v184, v184, v78 ; c8c69db9 b9b89db8
	buffer_load_b128 v[72:75], v55, s[28:31], null offen offset:9728 ; c405c07c 40803848 00260037
	v_dual_mul_f32 v189, v189, v78 :: v_dual_mul_f32 v188, v188, v78 ; c8c69dbd bdbc9dbc
	v_mul_f32_e32 v136, v136, v78                               ; 11109d88
	v_dual_mul_f32 v187, v187, v78 :: v_dual_mul_f32 v186, v186, v78 ; c8c69dbb bbba9dba
	v_dual_mul_f32 v143, v143, v78 :: v_dual_mul_f32 v142, v142, v78 ; c8c69d8f 8f8e9d8e
	v_mul_f32_e32 v141, v141, v78                               ; 111a9d8d
	v_dual_mul_f32 v139, v139, v78 :: v_dual_mul_f32 v140, v140, v78 ; c8c69d8b 8b8c9d8c
	v_dual_mul_f32 v137, v137, v78 :: v_dual_mul_f32 v138, v138, v78 ; c8c69d89 898a9d8a
	v_mul_f32_e32 v191, v191, v78                               ; 117e9dbf
	v_mul_f32_e32 v79, v45, v45                                 ; 109e5b2d
	buffer_load_b128 v[92:95], v55, s[28:31], null offen offset:10240 ; c405c07c 4080385c 00280037
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_fmac_f32_e32 v79, v145, v145                              ; 569f2391
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v79, v149, v149 :: v_dual_mul_f32 v190, v190, v78 ; c8072b95 4fbe9dbe
	v_dual_fmac_f32 v79, v49, v49 :: v_dual_mul_f32 v88, v47, v47 ; c8066331 4f585f2f
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmac_f32 v79, v144, v144 :: v_dual_fmac_f32 v88, v147, v147 ; c8012190 4f592793
	v_dual_fmac_f32 v79, v44, v44 :: v_dual_fmac_f32 v88, v151, v151 ; c800592c 4f592f97
	buffer_load_b128 v[104:107], v55, s[28:31], null offen offset:10752 ; c405c07c 40803868 002a0037
	v_dual_fmac_f32 v79, v148, v148 :: v_dual_fmac_f32 v88, v51, v51 ; c8012994 4f586733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v88, v146, v146                              ; 56b12592
	v_fmac_f32_e32 v88, v46, v46                                ; 56b05d2e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v88, v150, v150                              ; 56b12d96
	v_dual_fmac_f32 v88, v50, v50 :: v_dual_fmac_f32 v79, v48, v48 ; c8006532 584e6130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mixlo_f16 v89, 1.0, v79, v88                          ; cc210059 05629ef2
	v_cvt_u32_u16_e32 v90, v89                                  ; 7eb4d759
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v90, v90, s91, s92 op_sel:[1,1]           ; d65c185a 0170b75a
	v_add_f16_e32 v89, v89, v90                                 ; 64b2b559
	buffer_load_b128 v[108:111], v55, s[28:31], null offen offset:11264 ; c405c07c 4080386c 002c0037
	v_max_num_f16_e32 v89, s93, v89                             ; 62b2b25d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v91, v89                                  ; 7eb61759
	v_rsq_f32_e32 v91, v91                                      ; 7eb65d5b
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v47, v47, v91 :: v_dual_mul_f32 v46, v46, v91 ; c8c6b72f 2f2eb72e
	v_dual_mul_f32 v50, v50, v91 :: v_dual_mul_f32 v49, v49, v91 ; c8c6b732 3230b731
	v_dual_mul_f32 v144, v144, v91 :: v_dual_mul_f32 v145, v145, v91 ; c8c6b790 9090b791
	v_dual_mul_f32 v112, v81, v81 :: v_dual_mul_f32 v51, v51, v91 ; c8c6a351 7032b733
	v_dual_mul_f32 v149, v149, v91 :: v_dual_mul_f32 v148, v148, v91 ; c8c6b795 9594b794
	v_dual_mul_f32 v147, v147, v91 :: v_dual_mul_f32 v146, v146, v91 ; c8c6b793 9392b792
	v_mul_f32_e32 v48, v48, v91                                 ; 1060b730
	v_dual_mul_f32 v45, v45, v91 :: v_dual_mul_f32 v44, v44, v91 ; c8c6b72d 2d2cb72c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	buffer_load_b128 v[48:51], v55, s[28:31], null offen offset:11776 ; c405c07c 40803830 002e0037
	v_dual_mul_f32 v151, v151, v91 :: v_dual_mul_f32 v150, v150, v91 ; c8c6b797 9796b796
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_dual_fmac_f32 v112, v153, v153 :: v_dual_mul_f32 v113, v83, v83 ; c8073399 7070a753
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_dual_fmac_f32 v112, v157, v157 :: v_dual_fmac_f32 v113, v155, v155 ; c8013b9d 7071379b
	v_dual_fmac_f32 v112, v85, v85 :: v_dual_fmac_f32 v113, v159, v159 ; c800ab55 70713f9f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmac_f32_e32 v113, v87, v87                               ; 56e2af57
	v_dual_fmac_f32 v113, v154, v154 :: v_dual_fmac_f32 v112, v152, v152 ; c801359a 71713198
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v113, v82, v82 :: v_dual_fmac_f32 v112, v80, v80 ; c800a552 7170a150
	v_dual_fmac_f32 v113, v158, v158 :: v_dual_fmac_f32 v112, v156, v156 ; c8013d9e 7171399c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v113, v86, v86 :: v_dual_fmac_f32 v112, v84, v84 ; c800ad56 7170a954
	v_fma_mixlo_f16 v114, 1.0, v112, v113                       ; cc210072 05c6e0f2
	v_dual_mul_f32 v118, v179, v179 :: v_dual_mul_f32 v117, v177, v177 ; c8c767b3 767563b1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_u32_u16_e32 v115, v114                                ; 7ee6d772
	v_dual_fmac_f32 v118, v163, v163 :: v_dual_fmac_f32 v117, v161, v161 ; c80147a3 767543a1
	v_permlanex16_b32 v115, v115, s91, s92 op_sel:[1,1]         ; d65c1873 0170b773
	v_dual_fmac_f32 v118, v167, v167 :: v_dual_fmac_f32 v117, v165, v165 ; c8014fa7 76754ba5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_add_f16_e32 v114, v114, v115                              ; 64e4e772
	v_dual_fmac_f32 v118, v183, v183 :: v_dual_fmac_f32 v117, v181, v181 ; c8016fb7 76756bb5
	v_max_num_f16_e32 v114, s93, v114                           ; 62e4e45d
	v_dual_fmac_f32 v118, v162, v162 :: v_dual_fmac_f32 v117, v160, v160 ; c80145a2 767541a0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_cvt_f32_f16_e32 v116, v114                                ; 7ee81772
	v_dual_fmac_f32 v118, v178, v178 :: v_dual_fmac_f32 v117, v176, v176 ; c80165b2 767561b0
	v_rsq_f32_e32 v116, v116                                    ; 7ee85d74
	v_dual_fmac_f32 v118, v166, v166 :: v_dual_fmac_f32 v117, v164, v164 ; c8014da6 767549a4
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v159, v159, v116 :: v_dual_mul_f32 v158, v158, v116 ; c8c6e99f 9f9ee99e
	v_dual_mul_f32 v157, v157, v116 :: v_dual_mul_f32 v156, v156, v116 ; c8c6e99d 9d9ce99c
	v_dual_mul_f32 v87, v87, v116 :: v_dual_mul_f32 v86, v86, v116 ; c8c6e957 5756e956
	v_dual_mul_f32 v153, v153, v116 :: v_dual_mul_f32 v152, v152, v116 ; c8c6e999 9998e998
	v_dual_mul_f32 v155, v155, v116 :: v_dual_mul_f32 v154, v154, v116 ; c8c6e99b 9b9ae99a
	v_dual_mul_f32 v81, v81, v116 :: v_dual_mul_f32 v80, v80, v116 ; c8c6e951 5150e950
	v_dual_mul_f32 v83, v83, v116 :: v_dual_mul_f32 v82, v82, v116 ; c8c6e953 5352e952
	v_dual_mul_f32 v85, v85, v116 :: v_dual_mul_f32 v84, v84, v116 ; c8c6e955 5554e954
	v_dual_fmac_f32 v118, v182, v182 :: v_dual_fmac_f32 v117, v180, v180 ; c8016db6 767569b4
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_lshl_add_u32 v122, v2, 12, s46                            ; d646007a 00b91902
	v_fma_mixlo_f16 v119, 1.0, v117, v118                       ; cc210077 05daeaf2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_lshl_add_u32 v7, v7, 6, v122                              ; d6460007 05e90d07
	v_add_lshl_u32 v7, v7, v6, 2                                ; d6470007 020a0d07
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[80:83], v7, s[24:27], null offen         ; c405c07c 40803050 00000007
	buffer_load_b128 v[84:87], v7, s[24:27], null offen offset:16 ; c405c07c 40803054 00001007
	v_cvt_u32_u16_e32 v120, v119                                ; 7ef0d777
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v120, v120, s91, s92 op_sel:[1,1]         ; d65c1878 0170b778
	v_add_f16_e32 v119, v119, v120                              ; 64eef177
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v119, s93, v119                           ; 62eeee5d
	v_cvt_f32_f16_e32 v121, v119                                ; 7ef21777
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_rsq_f32_e32 v121, v121                                    ; 7ef25d79
	ds_load_b64 v[90:91], v20 offset:512                        ; d9d80200 5a000014
	ds_load_b64 v[112:113], v20 offset:2560                     ; d9d80a00 70000014
	ds_load_b64 v[114:115], v20 offset:4608                     ; d9d81200 72000014
	ds_load_b64 v[116:117], v20 offset:6656                     ; d9d81a00 74000014
	v_dual_mul_f32 v160, v160, v121 :: v_dual_mul_f32 v161, v161, v121 ; c8c6f3a0 a0a0f3a1
	v_mul_f32_e32 v165, v165, v121                              ; 114af3a5
	v_dual_mul_f32 v167, v167, v121 :: v_dual_mul_f32 v166, v166, v121 ; c8c6f3a7 a7a6f3a6
	v_dual_mul_f32 v181, v181, v121 :: v_dual_mul_f32 v180, v180, v121 ; c8c6f3b5 b5b4f3b4
	v_dual_mul_f32 v183, v183, v121 :: v_dual_mul_f32 v182, v182, v121 ; c8c6f3b7 b7b6f3b6
	v_mul_f32_e32 v164, v164, v121                              ; 1148f3a4
	v_dual_mul_f32 v162, v162, v121 :: v_dual_mul_f32 v163, v163, v121 ; c8c6f3a2 a2a2f3a3
	v_dual_mul_f32 v177, v177, v121 :: v_dual_mul_f32 v176, v176, v121 ; c8c6f3b1 b1b0f3b0
	v_dual_mul_f32 v179, v179, v121 :: v_dual_mul_f32 v178, v178, v121 ; c8c6f3b3 b3b2f3b2
	ds_load_b64 v[118:119], v20 offset:768                      ; d9d80300 76000014
	ds_load_b64 v[120:121], v20 offset:2816                     ; d9d80b00 78000014
	ds_load_b64 v[122:123], v20 offset:4864                     ; d9d81300 7a000014
	ds_load_b64 v[124:125], v20 offset:6912                     ; d9d81b00 7c000014
	s_wait_loadcnt_dscnt 0x90f                                  ; bfc8090f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[26:27], 0 ; cc464080 1a023516
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[24:25], v[26:27], 0 ; cc464088 1a023518
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[26:27], 0 ; cc464090 1a02352a
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[14:15], v[26:27], 0 ; cc464098 1a02350e
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[24:25], v[28:29], 0 ; cc4640a8 1a023918
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[22:23], v[28:29], 0 ; cc4640a0 1a023916
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[14:15], v[28:29], 0 ; cc4640b8 1a02390e
	ds_load_b64 v[14:15], v20 offset:1024                       ; d9d80400 0e000014
	ds_load_b64 v[22:23], v20 offset:3072                       ; d9d80c00 16000014
	ds_load_b64 v[24:25], v20 offset:5120                       ; d9d81400 18000014
	ds_load_b64 v[26:27], v20 offset:7168                       ; d9d81c00 1a000014
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[28:29], 0 ; cc4640b0 1a02392a
	s_wait_loadcnt_dscnt 0x80f                                  ; bfc8080f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[96:97], v[64:65], v[128:135] ; cc464080 1e028160
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[98:99], v[64:65], v[136:143] ; cc464088 1e228162
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[64:65], v[144:151] ; cc464090 1e428164
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[12:13], v[64:65], v[152:159] ; cc464098 1e62810c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[12:13], v[66:67], v[184:191] ; cc4640b8 1ee2850c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[98:99], v[66:67], v[168:175] ; cc4640a8 1ea28562
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[96:97], v[66:67], v[160:167] ; cc4640a0 1e828560
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[100:101], v[66:67], v[176:183] ; cc4640b0 1ec28564
	s_wait_loadcnt_dscnt 0x70b                                  ; bfc8070b
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[90:91], v[68:69], v[128:135] ; cc464080 1e02895a
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[68:69], v[136:143] ; cc464088 1e228970
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[114:115], v[68:69], v[144:151] ; cc464090 1e428972
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[68:69], v[152:159] ; cc464098 1e628974
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[116:117], v[70:71], v[184:191] ; cc4640b8 1ee28d74
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[112:113], v[70:71], v[168:175] ; cc4640a8 1ea28d70
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[90:91], v[70:71], v[160:167] ; cc4640a0 1e828d5a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[114:115], v[70:71], v[176:183] ; cc4640b0 1ec28d72
	ds_load_b64 v[12:13], v20 offset:1280                       ; d9d80500 0c000014
	ds_load_b64 v[28:29], v20 offset:3328                       ; d9d80d00 1c000014
	ds_load_b64 v[42:43], v20 offset:5376                       ; d9d81500 2a000014
	ds_load_b64 v[64:65], v20 offset:7424                       ; d9d81d00 40000014
	ds_load_b64 v[66:67], v20 offset:1536                       ; d9d80600 42000014
	ds_load_b64 v[68:69], v20 offset:3584                       ; d9d80e00 44000014
	ds_load_b64 v[70:71], v20 offset:5632                       ; d9d81600 46000014
	ds_load_b64 v[90:91], v20 offset:7680                       ; d9d81e00 5a000014
	s_wait_loadcnt_dscnt 0x60f                                  ; bfc8060f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[118:119], v[72:73], v[128:135] ; cc464080 1e029176
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[120:121], v[72:73], v[136:143] ; cc464088 1e229178
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[122:123], v[72:73], v[144:151] ; cc464090 1e42917a
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[124:125], v[72:73], v[152:159] ; cc464098 1e62917c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[120:121], v[74:75], v[168:175] ; cc4640a8 1ea29578
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[124:125], v[74:75], v[184:191] ; cc4640b8 1ee2957c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[118:119], v[74:75], v[160:167] ; cc4640a0 1e829576
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[122:123], v[74:75], v[176:183] ; cc4640b0 1ec2957a
	ds_load_b64 v[72:73], v20 offset:1792                       ; d9d80700 48000014
	ds_load_b64 v[74:75], v20 offset:3840                       ; d9d80f00 4a000014
	ds_load_b64 v[96:97], v20 offset:5888                       ; d9d81700 60000014
	ds_load_b64 v[98:99], v20 offset:7936                       ; d9d81f00 62000014
	s_wait_loadcnt_dscnt 0x50f                                  ; bfc8050f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[92:93], v[128:135] ; cc464080 1e02b90e
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[92:93], v[136:143] ; cc464088 1e22b916
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[94:95], v[168:175] ; cc4640a8 1ea2bd16
	v_mov_b32_e32 v35, v103                                     ; 7e460367
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[14:15], v[94:95], v[160:167] ; cc4640a0 1e82bd0e
	v_mov_b32_e32 v14, v21                                      ; 7e1c0315
	v_mov_b32_e32 v15, v102                                     ; 7e1e0366
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[112:115], v7, s[24:27], null offen offset:64 ; c405c07c 40803070 00004007
	buffer_load_b128 v[116:119], v7, s[24:27], null offen offset:80 ; c405c07c 40803074 00005007
	buffer_load_b128 v[120:123], v7, s[24:27], null offen offset:128 ; c405c07c 40803078 00008007
	buffer_load_b128 v[124:127], v7, s[24:27], null offen offset:144 ; c405c07c 4080307c 00009007
	buffer_load_b128 v[20:23], v7, s[24:27], null offen offset:192 ; c405c07c 40803014 0000c007
	buffer_load_b128 v[100:103], v7, s[24:27], null offen offset:208 ; c405c07c 40803064 0000d007
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[24:25], v[92:93], v[144:151] ; cc464090 1e42b918
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[26:27], v[92:93], v[152:159] ; cc464098 1e62b91a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[26:27], v[94:95], v[184:191] ; cc4640b8 1ee2bd1a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[24:25], v[94:95], v[176:183] ; cc4640b0 1ec2bd18
	s_wait_loadcnt_dscnt 0xa0b                                  ; bfc80a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[12:13], v[104:105], v[128:135] ; cc464080 1e02d10c
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[28:29], v[104:105], v[136:143] ; cc464088 1e22d11c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[28:29], v[106:107], v[168:175] ; cc4640a8 1ea2d51c
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[12:13], v[106:107], v[160:167] ; cc4640a0 1e82d50c
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[42:43], v[104:105], v[144:151] ; cc464090 1e42d12a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[64:65], v[104:105], v[152:159] ; cc464098 1e62d140
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[64:65], v[106:107], v[184:191] ; cc4640b8 1ee2d540
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[42:43], v[106:107], v[176:183] ; cc4640b0 1ec2d52a
	s_wait_loadcnt_dscnt 0x907                                  ; bfc80907
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[108:109], v[128:135] ; cc464080 1e02d942
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[108:109], v[136:143] ; cc464088 1e22d944
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[68:69], v[110:111], v[168:175] ; cc4640a8 1ea2dd44
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[66:67], v[110:111], v[160:167] ; cc4640a0 1e82dd42
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[70:71], v[108:109], v[144:151] ; cc464090 1e42d946
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[90:91], v[108:109], v[152:159] ; cc464098 1e62d95a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[90:91], v[110:111], v[184:191] ; cc4640b8 1ee2dd5a
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[70:71], v[110:111], v[176:183] ; cc4640b0 1ec2dd46
	s_wait_loadcnt_dscnt 0x803                                  ; bfc80803
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[48:49], v[128:135] ; cc464080 1e026148
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[74:75], v[48:49], v[136:143] ; cc464088 1e22614a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[74:75], v[50:51], v[168:175] ; cc4640a8 1ea2654a
	v_wmma_f32_16x16x16_fp8_fp8 v[160:167], v[72:73], v[50:51], v[160:167] ; cc4640a0 1e826548
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[48:49], v[144:151] ; cc464090 1e426160
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[98:99], v[48:49], v[152:159] ; cc464098 1e626162
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[98:99], v[50:51], v[184:191] ; cc4640b8 1ee26562
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[96:97], v[50:51], v[176:183] ; cc4640b0 1ec26560
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v7, s[24:27], null offen offset:4096 ; c405c07c 40803044 00100007
	buffer_load_b128 v[72:75], v7, s[24:27], null offen offset:4112 ; c405c07c 40803048 00101007
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[16:17], 0 ; cc464068 1a022126
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[16:17], 0 ; cc464080 1a02214c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[46:47], v[16:17], 0 ; cc464088 1a02212e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[78:79], v[16:17], 0 ; cc464090 1a02214e
	s_mov_b32 s94, 0x3d380000                                   ; bede00ff 3d380000
	s_movk_i32 s95, 0x3e47                                      ; b05f3e47
	s_movk_i32 s96, 0x3c20                                      ; b0603c20
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[56:57], v[104:111] ; cc464068 1da27128
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[44:45], v[56:57], v[128:135] ; cc464080 1e02712c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[54:55], v[56:57], v[136:143] ; cc464088 1e227136
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[88:89], v[56:57], v[144:151] ; cc464090 1e427158
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_mixlo_f16 v56, s94, v104, v80                         ; cc210038 0542d05e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v66, s94, v108, v84                         ; cc210042 0552d85e
	v_fma_mixlo_f16 v57, s94, v106, v82                         ; cc210039 054ad45e
	v_fma_mixhi_f16 v57, s94, v107, v83                         ; cc220039 054ed65e
	v_fma_mixhi_f16 v56, s94, v105, v81                         ; cc220038 0546d25e
	v_fma_mixlo_f16 v67, s94, v110, v86                         ; cc210043 055adc5e
	v_fma_mixhi_f16 v66, s94, v109, v85                         ; cc220042 0556da5e
	v_fma_mixhi_f16 v67, s94, v111, v87                         ; cc220043 055ede5e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[80:83], v7, s[24:27], null offen offset:4160 ; c405c07c 40803050 00104007
	buffer_load_b128 v[84:87], v7, s[24:27], null offen offset:4176 ; c405c07c 40803054 00105007
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v90, s94, v128, v112                        ; cc21005a 05c3005e
	v_fma_mixhi_f16 v90, s94, v129, v113                        ; cc22005a 05c7025e
	v_fma_mixlo_f16 v91, s94, v130, v114                        ; cc21005b 05cb045e
	v_fma_mixhi_f16 v91, s94, v131, v115                        ; cc22005b 05cf065e
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v96                               ; 0a00c139
(invalid instruction)                                        ; cc1c0038
	v_subrev_f32_e32 v0, v56, v96                               ; 0a00c138
	s_mov_b32 s97, 0x7ff88000                                   ; bee100ff 7ff88000
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v96                               ; 0a00c142
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v96                               ; 0a00c143
(invalid instruction)                                        ; cc1c005a
	v_subrev_f32_e32 v0, v90, v96                               ; 0a00c15a
(invalid instruction)                                        ; cc1c005b
	v_subrev_f32_e32 v0, v91, v96                               ; 0a00c15b
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[96:99], v7, s[24:27], null offen offset:4224 ; c405c07c 40803060 00108007
	buffer_load_b128 v[112:115], v7, s[24:27], null offen offset:4240 ; c405c07c 40803070 00109007
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v95                               ; 0a00bf39
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[60:61], 0 ; cc464068 1a027926
(invalid instruction)                                        ; cc1b0038
	v_subrev_f32_e32 v0, v56, v95                               ; 0a00bf38
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[76:77], v[60:61], 0 ; cc464098 1a02794c
(invalid instruction)                                        ; cc1b0042
	v_subrev_f32_e32 v0, v66, v95                               ; 0a00bf42
(invalid instruction)                                        ; cc1b0043
	v_subrev_f32_e32 v0, v67, v95                               ; 0a00bf43
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v94, s94, v132, v116                        ; cc21005e 05d3085e
(invalid instruction)                                        ; cc1b005a
	v_subrev_f32_e32 v0, v90, v95                               ; 0a00bf5a
(invalid instruction)                                        ; cc1b005b
	v_subrev_f32_e32 v0, v91, v95                               ; 0a00bf5b
	v_lshl_add_u32 v57, v57, 5, s97                             ; d6460039 01850b39
	v_fma_mixhi_f16 v94, s94, v133, v117                        ; cc22005e 05d70a5e
	v_lshl_add_u32 v56, v56, 5, s97                             ; d6460038 01850b38
	v_fma_mixlo_f16 v95, s94, v134, v118                        ; cc21005f 05db0c5e
	v_fma_mixhi_f16 v95, s94, v135, v119                        ; cc22005f 05df0e5e
	v_lshl_add_u32 v66, v66, 5, s97                             ; d6460042 01850b42
	v_lshl_add_u32 v67, v67, 5, s97                             ; d6460043 01850b43
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[60:61], 0 ; cc464080 1a02792e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[160:163], v7, s[24:27], null offen offset:4288 ; c405c07c 408030a0 0010c007
	buffer_load_b128 v[164:167], v7, s[24:27], null offen offset:4304 ; c405c07c 408030a4 0010d007
	v_lshl_add_u32 v90, v90, 5, s97                             ; d646005a 01850b5a
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v118, s94, v136, v120                       ; cc210076 05e3105e
	v_lshl_add_u32 v91, v91, 5, s97                             ; d646005b 01850b5b
	v_fma_mixhi_f16 v118, s94, v137, v121                       ; cc220076 05e7125e
(invalid instruction)                                        ; cc1c005e
	v_subrev_f32_e32 v0, v94, v96                               ; 0a00c15e
(invalid instruction)                                        ; cc1c005f
	v_subrev_f32_e32 v0, v95, v96                               ; 0a00c15f
	v_fma_mixlo_f16 v119, s94, v138, v122                       ; cc210077 05eb145e
	v_fma_mixhi_f16 v119, s94, v139, v123                       ; cc220077 05ef165e
(invalid instruction)                                        ; cc0f005c
	v_min_num_f64_e32 v[1:2], v[56:57], v[90:91]                ; 1a02b538
(invalid instruction)                                        ; cc0f005d
	v_min_num_f64_e32 v[1:2], v[57:58], v[91:92]                ; 1a02b739
(invalid instruction)                                        ; cc1c0076
	v_subrev_f32_e32 v0, v118, v96                              ; 0a00c176
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[78:79], v[60:61], 0 ; cc4640a8 1a02794e
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v120, s94, v140, v124                       ; cc210078 05f3185e
(invalid instruction)                                        ; cc1b005e
	v_subrev_f32_e32 v0, v94, v95                               ; 0a00bf5e
(invalid instruction)                                        ; cc1b005f
	v_subrev_f32_e32 v0, v95, v95                               ; 0a00bf5f
	v_fma_mixhi_f16 v120, s94, v141, v125                       ; cc220078 05f71a5e
(invalid instruction)                                        ; cc1c0077
	v_subrev_f32_e32 v0, v119, v96                              ; 0a00c177
(invalid instruction)                                        ; cc1b0076
	v_subrev_f32_e32 v0, v118, v95                              ; 0a00bf76
	v_fma_mixlo_f16 v121, s94, v142, v126                       ; cc210079 05fb1c5e
	v_fma_mixhi_f16 v121, s94, v143, v127                       ; cc220079 05ff1e5e
	v_lshl_add_u32 v94, v94, 5, s97                             ; d646005e 01850b5e
	v_lshl_add_u32 v95, v95, 5, s97                             ; d646005f 01850b5f
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v122, s94, v144, v20                        ; cc21007a 0453205e
(invalid instruction)                                        ; cc1c0078
	v_subrev_f32_e32 v0, v120, v96                              ; 0a00c178
	v_fma_mixhi_f16 v122, s94, v145, v21                        ; cc22007a 0457225e
(invalid instruction)                                        ; cc1b0077
	v_subrev_f32_e32 v0, v119, v95                              ; 0a00bf77
	v_lshl_add_u32 v118, v118, 5, s97                           ; d6460076 01850b76
	v_fma_mixlo_f16 v123, s94, v146, v22                        ; cc21007b 045b245e
(invalid instruction)                                        ; cc1c0079
	v_subrev_f32_e32 v0, v121, v96                              ; 0a00c179
(invalid instruction)                                        ; cc0f0074
	v_min_num_f64_e32 v[1:2], v[66:67], v[94:95]                ; 1a02bd42
	v_fma_mixhi_f16 v123, s94, v147, v23                        ; cc22007b 045f265e
(invalid instruction)                                        ; cc0f0075
	v_min_num_f64_e32 v[1:2], v[67:68], v[95:96]                ; 1a02bf43
(invalid instruction)                                        ; cc1b0078
	v_subrev_f32_e32 v0, v120, v95                              ; 0a00bf78
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v124, s94, v148, v100                       ; cc21007c 0593285e
(invalid instruction)                                        ; cc1c007a
	v_subrev_f32_e32 v0, v122, v96                              ; 0a00c17a
	v_fma_mixhi_f16 v124, s94, v149, v101                       ; cc22007c 05972a5e
	v_lshl_add_u32 v119, v119, 5, s97                           ; d6460077 01850b77
(invalid instruction)                                        ; cc0f005c
	v_min_num_f64_e32 v[1:2], v[92:93], v[118:119]              ; 1a02ed5c
	v_fma_mixlo_f16 v125, s94, v150, v102                       ; cc21007d 059b2c5e
(invalid instruction)                                        ; cc1b0079
	v_subrev_f32_e32 v0, v121, v95                              ; 0a00bf79
	v_fma_mixhi_f16 v125, s94, v151, v103                       ; cc22007d 059f2e5e
(invalid instruction)                                        ; cc1c007b
	v_subrev_f32_e32 v0, v123, v96                              ; 0a00c17b
	v_lshl_add_u32 v120, v120, 5, s97                           ; d6460078 01850b78
(invalid instruction)                                        ; cc1b007a
	v_subrev_f32_e32 v0, v122, v95                              ; 0a00bf7a
(invalid instruction)                                        ; cc1c007c
	v_subrev_f32_e32 v0, v124, v96                              ; 0a00c17c
(invalid instruction)                                        ; cc0f005d
	v_min_num_f64_e32 v[1:2], v[93:94], v[119:120]              ; 1a02ef5d
	v_lshl_add_u32 v121, v121, 5, s97                           ; d6460079 01850b79
(invalid instruction)                                        ; cc1c007d
	v_subrev_f32_e32 v0, v125, v96                              ; 0a00c17d
(invalid instruction)                                        ; cc1b007b
	v_subrev_f32_e32 v0, v123, v95                              ; 0a00bf7b
(invalid instruction)                                        ; cc0f0074
	v_min_num_f64_e32 v[1:2], v[116:117], v[120:121]            ; 1a02f174
	v_lshl_add_u32 v122, v122, 5, s97                           ; d646007a 01850b7a
(invalid instruction)                                        ; cc1b007c
	v_subrev_f32_e32 v0, v124, v95                              ; 0a00bf7c
(invalid instruction)                                        ; cc0f0075
	v_min_num_f64_e32 v[1:2], v[117:118], v[121:122]            ; 1a02f375
(invalid instruction)                                        ; cc1b007d
	v_subrev_f32_e32 v0, v125, v95                              ; 0a00bf7d
	v_lshl_add_u32 v123, v123, 5, s97                           ; d646007b 01850b7b
(invalid instruction)                                        ; cc0f005c
	v_min_num_f64_e32 v[1:2], v[92:93], v[122:123]              ; 1a02f55c
	v_lshl_add_u32 v124, v124, 5, s97                           ; d646007c 01850b7c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_lshl_add_u32 v125, v125, 5, s97                           ; d646007d 01850b7d
(invalid instruction)                                        ; cc0f005d
	v_min_num_f64_e32 v[1:2], v[93:94], v[123:124]              ; 1a02f75d
(invalid instruction)                                        ; cc0f0074
	v_min_num_f64_e32 v[1:2], v[116:117], v[124:125]            ; 1a02f974
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; cc0f0075
	v_min_num_f64_e32 v[1:2], v[117:118], v[125:126]            ; 1a02fb75
(invalid instruction)                                        ; cc0f005c
	v_min_num_f64_e32 v[1:2], v[92:93], v[93:94]                ; 1a02bb5c
(invalid instruction)                                        ; cc0f005c
	v_min_num_f64_e32 v[1:2], v[92:93], v[116:117]              ; 1a02e95c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f005c
	v_min_num_f64_e32 v[1:2], v[92:93], v[117:118]              ; 1a02eb5c
	v_permlanex16_b32 v126, v92, s91, s92 op_sel:[1,1]          ; d65c187e 0170b75c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f005c
	v_min_num_f64_e32 v[1:2], v[92:93], v[126:127]              ; 1a02fd5c
	v_add_f16_e32 v127, v92, v220/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64ffb95c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v127, s89, v127                           ; 62fefe59
	v_cvt_f32_f16_e32 v136, v127                                ; 7f10177f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v136, v136                                    ; 7f105588
	v_fma_mix_f32 v140, v67, v136, neg(0) op_sel_hi:[1,0,0]     ; cc20008c 8a031143
	v_fma_mix_f32 v142, v91, v136, neg(0) op_sel_hi:[1,0,0]     ; cc20008e 8a03115b
	v_fma_mix_f32 v137, v56, v136, neg(0) op_sel_hi:[1,0,0]     ; cc200089 8a031138
	v_fma_mix_f32 v67, v67, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200843 8a031143
	v_fma_mix_f32 v141, v90, v136, neg(0) op_sel_hi:[1,0,0]     ; cc20008d 8a03115a
	v_fma_mix_f32 v90, v90, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085a 8a03115a
	v_fma_mix_f32 v138, v57, v136, neg(0) op_sel_hi:[1,0,0]     ; cc20008a 8a031139
	v_fma_mix_f32 v57, v57, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200839 8a031139
	v_fma_mix_f32 v139, v66, v136, neg(0) op_sel_hi:[1,0,0]     ; cc20008b 8a031142
	v_fma_mix_f32 v66, v66, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200842 8a031142
	v_fma_mix_f32 v56, v56, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200838 8a031138
	v_fma_mix_f32 v91, v91, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085b 8a03115b
	v_fma_mix_f32 v143, v94, v136, neg(0) op_sel_hi:[1,0,0]     ; cc20008f 8a03115e
	v_fma_mix_f32 v94, v94, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085e 8a03115e
	v_fma_mix_f32 v144, v95, v136, neg(0) op_sel_hi:[1,0,0]     ; cc200090 8a03115f
	v_fma_mix_f32 v95, v95, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085f 8a03115f
	v_fma_mix_f32 v145, v118, v136, neg(0) op_sel_hi:[1,0,0]    ; cc200091 8a031176
	v_fma_mix_f32 v118, v118, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200876 8a031176
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v141, v90, vcc_lo                     ; 0202b58d
	v_fma_mix_f32 v146, v119, v136, neg(0) op_sel_hi:[1,0,0]    ; cc200092 8a031177
	v_fma_mix_f32 v119, v119, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a031177
	v_fma_mix_f32 v147, v120, v136, neg(0) op_sel_hi:[1,0,0]    ; cc200093 8a031178
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v139, v66, vcc_lo                     ; 0202858b
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v140, v67, vcc_lo                     ; 0202878c
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v137, v56, vcc_lo                     ; 02027189
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v138, v57, vcc_lo                     ; 0202738a
	v_fma_mix_f32 v120, v120, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200878 8a031178
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v142, v91, vcc_lo                     ; 0202b78e
	v_fma_mix_f32 v148, v121, v136, neg(0) op_sel_hi:[1,0,0]    ; cc200094 8a031179
	v_fma_mix_f32 v121, v121, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200879 8a031179
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v143, v94, vcc_lo                     ; 0202bd8f
	v_fma_mix_f32 v149, v122, v136, neg(0) op_sel_hi:[1,0,0]    ; cc200095 8a03117a
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v144, v95, vcc_lo                     ; 0202bf90
	v_fma_mix_f32 v122, v122, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087a 8a03117a
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v145, v118, vcc_lo                    ; 0202ed91
	v_fma_mix_f32 v150, v123, v136, neg(0) op_sel_hi:[1,0,0]    ; cc200096 8a03117b
	v_fma_mix_f32 v123, v123, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087b 8a03117b
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v146, v119, vcc_lo                    ; 0202ef92
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[92:95], v7, s[24:27], null offen offset:8192 ; c405c07c 4080305c 00200007
	buffer_load_b128 v[100:103], v7, s[24:27], null offen offset:8208 ; c405c07c 40803064 00201007
	v_fma_mix_f32 v151, v124, v136, neg(0) op_sel_hi:[1,0,0]    ; cc200097 8a03117c
	v_fma_mix_f32 v124, v124, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087c 8a03117c
	v_fma_mix_f32 v176, v125, v136, neg(0) op_sel_hi:[1,0,0]    ; cc2000b0 8a03117d
	v_fma_mix_f32 v125, v125, v136, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087d 8a03117d
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v147, v120, vcc_lo                    ; 0202f193
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[62:63], v[104:111] ; cc464068 1da27d28
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[44:45], v[62:63], v[152:159] ; cc464098 1e627d2c
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v148, v121, vcc_lo                    ; 0202f394
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[62:63], v[128:135] ; cc464080 1e027d36
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[88:89], v[62:63], v[168:175] ; cc4640a8 1ea27d58
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v149, v122, vcc_lo                    ; 0202f595
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v150, v123, vcc_lo                    ; 0202f796
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v151, v124, vcc_lo                    ; 0202f997
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v176, v125, vcc_lo                    ; 0202fbb0
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v178, s94, v106, v70                        ; cc2100b2 051ad45e
	v_fma_mixlo_f16 v177, s94, v104, v68                        ; cc2100b1 0512d05e
	v_fma_mixhi_f16 v177, s94, v105, v69                        ; cc2200b1 0516d25e
	v_fma_mixhi_f16 v178, s94, v107, v71                        ; cc2200b2 051ed65e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v7, s[24:27], null offen offset:8256 ; c405c07c 4080303c 00204007
	buffer_load_b128 v[68:71], v7, s[24:27], null offen offset:8272 ; c405c07c 40803044 00205007
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v179, s94, v108, v72                        ; cc2100b3 0522d85e
	v_fma_mixhi_f16 v179, s94, v109, v73                        ; cc2200b3 0526da5e
	v_fma_mixlo_f16 v180, s94, v110, v74                        ; cc2100b4 052adc5e
	v_fma_mixhi_f16 v180, s94, v111, v75                        ; cc2200b4 052ede5e
(invalid instruction)                                        ; cc1c00b1
	v_subrev_f32_e32 v0, v177, v96                              ; 0a00c1b1
(invalid instruction)                                        ; cc1c00b2
	v_subrev_f32_e32 v0, v178, v96                              ; 0a00c1b2
(invalid instruction)                                        ; cc1c00b3
	v_subrev_f32_e32 v0, v179, v96                              ; 0a00c1b3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c00b4
	v_subrev_f32_e32 v0, v180, v96                              ; 0a00c1b4
(invalid instruction)                                        ; cc1b00b1
	v_subrev_f32_e32 v0, v177, v95                              ; 0a00bfb1
(invalid instruction)                                        ; cc1b00b2
	v_subrev_f32_e32 v0, v178, v95                              ; 0a00bfb2
(invalid instruction)                                        ; cc1b00b3
	v_subrev_f32_e32 v0, v179, v95                              ; 0a00bfb3
(invalid instruction)                                        ; cc1b00b4
	v_subrev_f32_e32 v0, v180, v95                              ; 0a00bfb4
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v182, s94, v154, v82                        ; cc2100b6 054b345e
	v_fma_mixhi_f16 v182, s94, v155, v83                        ; cc2200b6 054f365e
	v_fma_mixlo_f16 v181, s94, v152, v80                        ; cc2100b5 0543305e
	v_fma_mixhi_f16 v181, s94, v153, v81                        ; cc2200b5 0547325e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v7, s[24:27], null offen offset:8320 ; c405c07c 40803048 00208007
	buffer_load_b128 v[80:83], v7, s[24:27], null offen offset:8336 ; c405c07c 40803050 00209007
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v184, s94, v158, v86                        ; cc2100b8 055b3c5e
	v_fma_mixhi_f16 v184, s94, v159, v87                        ; cc2200b8 055f3e5e
	v_fma_mixlo_f16 v183, s94, v156, v84                        ; cc2100b7 0553385e
	v_fma_mixhi_f16 v183, s94, v157, v85                        ; cc2200b7 05573a5e
(invalid instruction)                                        ; cc1c00b6
	v_subrev_f32_e32 v0, v182, v96                              ; 0a00c1b6
(invalid instruction)                                        ; cc1c00b5
	v_subrev_f32_e32 v0, v181, v96                              ; 0a00c1b5
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v96                              ; 0a00c1b8
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v186, s94, v130, v98                        ; cc2100ba 058b045e
	v_fma_mixhi_f16 v186, s94, v131, v99                        ; cc2200ba 058f065e
	v_fma_mixlo_f16 v185, s94, v128, v96                        ; cc2100b9 0583005e
	v_fma_mixhi_f16 v185, s94, v129, v97                        ; cc2200b9 0587025e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v187, s94, v132, v112                       ; cc2100bb 05c3085e
	v_fma_mixhi_f16 v187, s94, v133, v113                       ; cc2200bb 05c70a5e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[84:87], v7, s[24:27], null offen offset:8384 ; c405c07c 40803054 0020c007
	buffer_load_b128 v[96:99], v7, s[24:27], null offen offset:8400 ; c405c07c 40803060 0020d007
(invalid instruction)                                        ; cc1c00b7
	v_subrev_f32_e32 v0, v183, v96                              ; 0a00c1b7
	v_fma_mixlo_f16 v188, s94, v134, v114                       ; cc2100bc 05cb0c5e
(invalid instruction)                                        ; cc1b00b6
	v_subrev_f32_e32 v0, v182, v95                              ; 0a00bfb6
(invalid instruction)                                        ; cc1b00b5
	v_subrev_f32_e32 v0, v181, v95                              ; 0a00bfb5
	v_fma_mixhi_f16 v188, s94, v135, v115                       ; cc2200bc 05cf0e5e
(invalid instruction)                                        ; cc1b00b8
	v_subrev_f32_e32 v0, v184, v95                              ; 0a00bfb8
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v96                              ; 0a00c1ba
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v96                              ; 0a00c1b9
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v96                              ; 0a00c1bb
(invalid instruction)                                        ; cc1b00b7
	v_subrev_f32_e32 v0, v183, v95                              ; 0a00bfb7
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v96                              ; 0a00c1bc
(invalid instruction)                                        ; cc1b00ba
	v_subrev_f32_e32 v0, v186, v95                              ; 0a00bfba
(invalid instruction)                                        ; cc1b00b9
	v_subrev_f32_e32 v0, v185, v95                              ; 0a00bfb9
(invalid instruction)                                        ; cc1b00bb
	v_subrev_f32_e32 v0, v187, v95                              ; 0a00bfbb
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b00bc
	v_subrev_f32_e32 v0, v188, v95                              ; 0a00bfbc
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v190, s94, v170, v162                       ; cc2100be 068b545e
	v_fma_mixlo_f16 v189, s94, v168, v160                       ; cc2100bd 0683505e
	v_fma_mixhi_f16 v190, s94, v171, v163                       ; cc2200be 068f565e
	v_fma_mixhi_f16 v189, s94, v169, v161                       ; cc2200bd 0687525e
	v_lshl_add_u32 v177, v177, 5, s97                           ; d64600b1 01850bb1
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v191, s94, v172, v164                       ; cc2100bf 0693585e
	v_fma_mixhi_f16 v191, s94, v173, v165                       ; cc2200bf 06975a5e
	v_fma_mixlo_f16 v66, s94, v174, v166                        ; cc210042 069b5c5e
	v_fma_mixhi_f16 v66, s94, v175, v167                        ; cc220042 069f5e5e
	v_lshl_add_u32 v181, v181, 5, s97                           ; d64600b5 01850bb5
	v_lshl_add_u32 v185, v185, 5, s97                           ; d64600b9 01850bb9
(invalid instruction)                                        ; cc1c00be
	v_subrev_f32_e32 v0, v190, v96                              ; 0a00c1be
	v_lshl_add_u32 v178, v178, 5, s97                           ; d64600b2 01850bb2
	v_lshl_add_u32 v182, v182, 5, s97                           ; d64600b6 01850bb6
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v96                              ; 0a00c1bd
	v_lshl_add_u32 v186, v186, 5, s97                           ; d64600ba 01850bba
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v96                              ; 0a00c1bf
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v96                               ; 0a00c142
	v_lshl_add_u32 v179, v179, 5, s97                           ; d64600b3 01850bb3
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[177:178], v[181:182]            ; 1a036bb1
	v_lshl_add_u32 v183, v183, 5, s97                           ; d64600b7 01850bb7
(invalid instruction)                                        ; cc1b00be
	v_subrev_f32_e32 v0, v190, v95                              ; 0a00bfbe
	v_lshl_add_u32 v187, v187, 5, s97                           ; d64600bb 01850bbb
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[178:179], v[182:183]            ; 1a036db2
(invalid instruction)                                        ; cc1b00bd
	v_subrev_f32_e32 v0, v189, v95                              ; 0a00bfbd
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v95                              ; 0a00bfbf
	v_lshl_add_u32 v180, v180, 5, s97                           ; d64600b4 01850bb4
	v_lshl_add_u32 v184, v184, 5, s97                           ; d64600b8 01850bb8
(invalid instruction)                                        ; cc1b0042
	v_subrev_f32_e32 v0, v66, v95                               ; 0a00bf42
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[185:186]              ; 1a037343
	v_lshl_add_u32 v188, v188, 5, s97                           ; d64600bc 01850bbc
(invalid instruction)                                        ; cc0f005b
	v_min_num_f64_e32 v[1:2], v[179:180], v[183:184]            ; 1a036fb3
	v_lshl_add_u32 v190, v190, 5, s97                           ; d64600be 01850bbe
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[186:187]              ; 1a03755a
	v_lshl_add_u32 v189, v189, 5, s97                           ; d64600bd 01850bbd
	v_lshl_add_u32 v191, v191, 5, s97                           ; d64600bf 01850bbf
(invalid instruction)                                        ; cc0f0068
	v_min_num_f64_e32 v[1:2], v[180:181], v[184:185]            ; 1a0371b4
	v_lshl_add_u32 v66, v66, 5, s97                             ; d6460042 01850b42
(invalid instruction)                                        ; cc0f005b
	v_min_num_f64_e32 v[1:2], v[91:92], v[187:188]              ; 1a03775b
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[190:191]              ; 1a037d5a
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[189:190]              ; 1a037b43
(invalid instruction)                                        ; cc0f0068
	v_min_num_f64_e32 v[1:2], v[104:105], v[188:189]            ; 1a037968
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f005b
	v_min_num_f64_e32 v[1:2], v[91:92], v[191:192]              ; 1a037f5b
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[90:91]                ; 1a02b543
(invalid instruction)                                        ; cc0f0068
	v_min_num_f64_e32 v[1:2], v[104:105], v[66:67]              ; 1a028568
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[91:92]                ; 1a02b743
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[104:105]              ; 1a02d143
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v105, v67, s91, s92 op_sel:[1,1]          ; d65c1869 0170b743
(invalid instruction)                                        ; cc0f0043
	v_min_num_f64_e32 v[1:2], v[67:68], v[105:106]              ; 1a02d343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v106, v67, v195/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64d58743
	v_max_num_f16_e32 v106, s89, v106                           ; 62d4d459
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v107, v106                                ; 7ed6176a
	v_rcp_f32_e32 v107, v107                                    ; 7ed6556b
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v109, v178, v107, neg(0) op_sel_hi:[1,0,0]    ; cc20006d 8a02d7b2
	v_fma_mix_f32 v178, v178, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b2 8a02d7b2
	v_fma_mix_f32 v112, v181, v107, neg(0) op_sel_hi:[1,0,0]    ; cc200070 8a02d7b5
	v_fma_mix_f32 v181, v181, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a02d7b5
	v_fma_mix_f32 v113, v182, v107, neg(0) op_sel_hi:[1,0,0]    ; cc200071 8a02d7b6
	v_fma_mix_f32 v111, v180, v107, neg(0) op_sel_hi:[1,0,0]    ; cc20006f 8a02d7b4
	v_fma_mix_f32 v180, v180, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b4 8a02d7b4
	v_fma_mix_f32 v110, v179, v107, neg(0) op_sel_hi:[1,0,0]    ; cc20006e 8a02d7b3
	v_fma_mix_f32 v179, v179, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a02d7b3
	v_fma_mix_f32 v108, v177, v107, neg(0) op_sel_hi:[1,0,0]    ; cc20006c 8a02d7b1
	v_fma_mix_f32 v177, v177, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a02d7b1
	v_fma_mix_f32 v182, v182, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b6 8a02d7b6
	v_fma_mix_f32 v114, v183, v107, neg(0) op_sel_hi:[1,0,0]    ; cc200072 8a02d7b7
	v_fma_mix_f32 v183, v183, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a02d7b7
	v_fma_mix_f32 v115, v184, v107, neg(0) op_sel_hi:[1,0,0]    ; cc200073 8a02d7b8
	v_fma_mix_f32 v184, v184, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a02d7b8
	v_fma_mix_f32 v116, v185, v107, neg(0) op_sel_hi:[1,0,0]    ; cc200074 8a02d7b9
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v112, v181, vcc_lo                    ; 02036b70
	v_fma_mix_f32 v185, v185, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a02d7b9
	v_fma_mix_f32 v117, v186, v107, neg(0) op_sel_hi:[1,0,0]    ; cc200075 8a02d7ba
	v_fma_mix_f32 v186, v186, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a02d7ba
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v110, v179, vcc_lo                    ; 0203676e
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v111, v180, vcc_lo                    ; 0203696f
	v_fma_mix_f32 v118, v187, v107, neg(0) op_sel_hi:[1,0,0]    ; cc200076 8a02d7bb
	v_fma_mix_f32 v187, v187, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a02d7bb
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v108, v177, vcc_lo                    ; 0203636c
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v109, v178, vcc_lo                    ; 0203656d
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v113, v182, vcc_lo                    ; 02036d71
	v_fma_mix_f32 v119, v188, v107, neg(0) op_sel_hi:[1,0,0]    ; cc200077 8a02d7bc
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v114, v183, vcc_lo                    ; 02036f72
	v_fma_mix_f32 v188, v188, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a02d7bc
	v_fma_mix_f32 v120, v189, v107, neg(0) op_sel_hi:[1,0,0]    ; cc200078 8a02d7bd
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v115, v184, vcc_lo                    ; 02037173
	v_fma_mix_f32 v189, v189, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a02d7bd
(invalid instruction)                                        ; d769006c
	v_cndmask_b32_e32 v1, v116, v185, vcc_lo                    ; 02037374
	v_fma_mix_f32 v121, v190, v107, neg(0) op_sel_hi:[1,0,0]    ; cc200079 8a02d7be
	v_fma_mix_f32 v190, v190, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008be 8a02d7be
(invalid instruction)                                        ; d769406c
	v_cndmask_b32_e32 v1, v117, v186, vcc_lo                    ; 02037575
	v_fma_mix_f32 v122, v191, v107, neg(0) op_sel_hi:[1,0,0]    ; cc20007a 8a02d7bf
	v_fma_mix_f32 v191, v191, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a02d7bf
(invalid instruction)                                        ; d769006d
	v_cndmask_b32_e32 v1, v118, v187, vcc_lo                    ; 02037776
	v_fma_mix_f32 v123, v66, v107, neg(0) op_sel_hi:[1,0,0]     ; cc20007b 8a02d742
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[144:147], v7, s[24:27], null offen offset:12288 ; c405c07c 40803090 00300007
	buffer_load_b128 v[148:151], v7, s[24:27], null offen offset:12304 ; c405c07c 40803094 00301007
	v_fma_mix_f32 v66, v66, v107, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200842 8a02d742
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[58:59], 0 ; cc464080 1a02752e
(invalid instruction)                                        ; d769406d
	v_cndmask_b32_e32 v1, v119, v188, vcc_lo                    ; 02037977
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[58:59], 0 ; cc464070 1a027526
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[78:79], v[58:59], 0 ; cc464088 1a02754e
(invalid instruction)                                        ; d769006e
	v_cndmask_b32_e32 v1, v120, v189, vcc_lo                    ; 02037b78
(invalid instruction)                                        ; d769406e
	v_cndmask_b32_e32 v1, v121, v190, vcc_lo                    ; 02037d79
(invalid instruction)                                        ; d769006f
	v_cndmask_b32_e32 v1, v122, v191, vcc_lo                    ; 02037f7a
(invalid instruction)                                        ; d769406f
	v_cndmask_b32_e32 v1, v123, v66, vcc_lo                     ; 0202857b
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[76:77], v[58:59], 0 ; cc464078 1a02754c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[18:19], v[128:135] ; cc464080 1e022536
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[18:19], v[112:119] ; cc464070 1dc22528
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[88:89], v[18:19], v[136:143] ; cc464088 1e222558
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[18:19], v[120:127] ; cc464078 1de2252c
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v152, s94, v112, v92                        ; cc210098 0572e05e
	v_fma_mixlo_f16 v153, s94, v114, v94                        ; cc210099 057ae45e
	v_fma_mixhi_f16 v152, s94, v113, v93                        ; cc220098 0576e25e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v154, s94, v116, v100                       ; cc21009a 0592e85e
	v_fma_mixhi_f16 v154, s94, v117, v101                       ; cc22009a 0596ea5e
	v_fma_mixhi_f16 v153, s94, v115, v95                        ; cc220099 057ee65e
	v_fma_mixlo_f16 v155, s94, v118, v102                       ; cc21009b 059aec5e
	v_fma_mixhi_f16 v155, s94, v119, v103                       ; cc22009b 059eee5e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[92:95], v7, s[24:27], null offen offset:12352 ; c405c07c 4080305c 00304007
	buffer_load_b128 v[100:103], v7, s[24:27], null offen offset:12368 ; c405c07c 40803064 00305007
(invalid instruction)                                        ; cc1c0098
	v_subrev_f32_e32 v0, v152, v96                              ; 0a00c198
(invalid instruction)                                        ; cc1c009a
	v_subrev_f32_e32 v0, v154, v96                              ; 0a00c19a
(invalid instruction)                                        ; cc1c0099
	v_subrev_f32_e32 v0, v153, v96                              ; 0a00c199
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v156, s94, v120, v60                        ; cc21009c 04f2f05e
	v_fma_mixhi_f16 v156, s94, v121, v61                        ; cc22009c 04f6f25e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v158, s94, v124, v68                        ; cc21009e 0512f85e
	v_fma_mixhi_f16 v158, s94, v125, v69                        ; cc22009e 0516fa5e
	v_fma_mixlo_f16 v157, s94, v122, v62                        ; cc21009d 04faf45e
	v_fma_mixhi_f16 v157, s94, v123, v63                        ; cc22009d 04fef65e
	v_fma_mixlo_f16 v159, s94, v126, v70                        ; cc21009f 051afc5e
	v_fma_mixhi_f16 v159, s94, v127, v71                        ; cc22009f 051efe5e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[60:63], v7, s[24:27], null offen offset:12416 ; c405c07c 4080303c 00308007
	buffer_load_b128 v[68:71], v7, s[24:27], null offen offset:12432 ; c405c07c 40803044 00309007
(invalid instruction)                                        ; cc1c009b
	v_subrev_f32_e32 v0, v155, v96                              ; 0a00c19b
(invalid instruction)                                        ; cc1b0098
	v_subrev_f32_e32 v0, v152, v95                              ; 0a00bf98
(invalid instruction)                                        ; cc1b009a
	v_subrev_f32_e32 v0, v154, v95                              ; 0a00bf9a
(invalid instruction)                                        ; cc1b0099
	v_subrev_f32_e32 v0, v153, v95                              ; 0a00bf99
(invalid instruction)                                        ; cc1c009c
	v_subrev_f32_e32 v0, v156, v96                              ; 0a00c19c
(invalid instruction)                                        ; cc1c009e
	v_subrev_f32_e32 v0, v158, v96                              ; 0a00c19e
(invalid instruction)                                        ; cc1c009d
	v_subrev_f32_e32 v0, v157, v96                              ; 0a00c19d
(invalid instruction)                                        ; cc1c009f
	v_subrev_f32_e32 v0, v159, v96                              ; 0a00c19f
(invalid instruction)                                        ; cc1b009b
	v_subrev_f32_e32 v0, v155, v95                              ; 0a00bf9b
(invalid instruction)                                        ; cc1b009c
	v_subrev_f32_e32 v0, v156, v95                              ; 0a00bf9c
(invalid instruction)                                        ; cc1b009e
	v_subrev_f32_e32 v0, v158, v95                              ; 0a00bf9e
(invalid instruction)                                        ; cc1b009d
	v_subrev_f32_e32 v0, v157, v95                              ; 0a00bf9d
(invalid instruction)                                        ; cc1b009f
	v_subrev_f32_e32 v0, v159, v95                              ; 0a00bf9f
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v161, s94, v130, v74                        ; cc2100a1 052b045e
	v_fma_mixhi_f16 v161, s94, v131, v75                        ; cc2200a1 052f065e
	v_fma_mixlo_f16 v160, s94, v128, v72                        ; cc2100a0 0523005e
	v_fma_mixhi_f16 v160, s94, v129, v73                        ; cc2200a0 0527025e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v162, s94, v132, v80                        ; cc2100a2 0543085e
	v_fma_mixhi_f16 v162, s94, v133, v81                        ; cc2200a2 05470a5e
	v_fma_mixlo_f16 v163, s94, v134, v82                        ; cc2100a3 054b0c5e
	v_fma_mixhi_f16 v163, s94, v135, v83                        ; cc2200a3 054f0e5e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[72:75], v7, s[24:27], null offen offset:12480 ; c405c07c 40803048 0030c007
	buffer_load_b128 v[80:83], v7, s[24:27], null offen offset:12496 ; c405c07c 40803050 0030d007
	v_add3_u32 v14, v14, s36, v35                               ; d655000e 048c490e
(invalid instruction)                                        ; cc1c00a1
	v_subrev_f32_e32 v0, v161, v96                              ; 0a00c1a1
(invalid instruction)                                        ; cc1c00a0
	v_subrev_f32_e32 v0, v160, v96                              ; 0a00c1a0
(invalid instruction)                                        ; cc1c00a2
	v_subrev_f32_e32 v0, v162, v96                              ; 0a00c1a2
(invalid instruction)                                        ; cc1c00a3
	v_subrev_f32_e32 v0, v163, v96                              ; 0a00c1a3
	v_lshlrev_b32_e32 v14, 2, v14                               ; 301c1c82
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v165, s94, v138, v86                        ; cc2100a5 055b145e
	v_fma_mixhi_f16 v165, s94, v139, v87                        ; cc2200a5 055f165e
	v_fma_mixlo_f16 v164, s94, v136, v84                        ; cc2100a4 0553105e
	v_fma_mixhi_f16 v164, s94, v137, v85                        ; cc2200a4 0557125e
(invalid instruction)                                        ; cc1b00a1
	v_subrev_f32_e32 v0, v161, v95                              ; 0a00bfa1
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v166, s94, v140, v96                        ; cc2100a6 0583185e
	v_fma_mixhi_f16 v166, s94, v141, v97                        ; cc2200a6 05871a5e
(invalid instruction)                                        ; cc1b00a0
	v_subrev_f32_e32 v0, v160, v95                              ; 0a00bfa0
	v_fma_mixlo_f16 v167, s94, v142, v98                        ; cc2100a7 058b1c5e
(invalid instruction)                                        ; cc1b00a2
	v_subrev_f32_e32 v0, v162, v95                              ; 0a00bfa2
	v_fma_mixhi_f16 v167, s94, v143, v99                        ; cc2200a7 058f1e5e
(invalid instruction)                                        ; cc1b00a3
	v_subrev_f32_e32 v0, v163, v95                              ; 0a00bfa3
	v_lshl_add_u32 v152, v152, 5, s97                           ; d6460098 01850b98
	v_lshl_add_u32 v156, v156, 5, s97                           ; d646009c 01850b9c
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v96                              ; 0a00c1a5
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v96                              ; 0a00c1a4
	v_lshl_add_u32 v153, v153, 5, s97                           ; d6460099 01850b99
(invalid instruction)                                        ; cc1c00a6
	v_subrev_f32_e32 v0, v166, v96                              ; 0a00c1a6
	v_lshl_add_u32 v160, v160, 5, s97                           ; d64600a0 01850ba0
	v_lshl_add_u32 v157, v157, 5, s97                           ; d646009d 01850b9d
	v_lshl_add_u32 v161, v161, 5, s97                           ; d64600a1 01850ba1
(invalid instruction)                                        ; cc1c00a7
	v_subrev_f32_e32 v0, v167, v96                              ; 0a00c1a7
(invalid instruction)                                        ; cc0f00a8
	v_min_num_f64_e32 v[1:2], v[152:153], v[156:157]            ; 1a033998
	v_lshl_add_u32 v154, v154, 5, s97                           ; d646009a 01850b9a
	v_lshl_add_u32 v158, v158, 5, s97                           ; d646009e 01850b9e
(invalid instruction)                                        ; cc1b00a5
	v_subrev_f32_e32 v0, v165, v95                              ; 0a00bfa5
(invalid instruction)                                        ; cc1b00a4
	v_subrev_f32_e32 v0, v164, v95                              ; 0a00bfa4
	v_lshl_add_u32 v162, v162, 5, s97                           ; d64600a2 01850ba2
(invalid instruction)                                        ; cc1b00a6
	v_subrev_f32_e32 v0, v166, v95                              ; 0a00bfa6
(invalid instruction)                                        ; cc0f00a9
	v_min_num_f64_e32 v[1:2], v[153:154], v[157:158]            ; 1a033b99
	v_lshl_add_u32 v155, v155, 5, s97                           ; d646009b 01850b9b
	v_lshl_add_u32 v159, v159, 5, s97                           ; d646009f 01850b9f
(invalid instruction)                                        ; cc1b00a7
	v_subrev_f32_e32 v0, v167, v95                              ; 0a00bfa7
(invalid instruction)                                        ; cc0f00a8
	v_min_num_f64_e32 v[1:2], v[168:169], v[160:161]            ; 1a0341a8
	v_lshl_add_u32 v163, v163, 5, s97                           ; d64600a3 01850ba3
(invalid instruction)                                        ; cc0f00aa
	v_min_num_f64_e32 v[1:2], v[154:155], v[158:159]            ; 1a033d9a
	v_lshl_add_u32 v165, v165, 5, s97                           ; d64600a5 01850ba5
	v_lshl_add_u32 v164, v164, 5, s97                           ; d64600a4 01850ba4
	v_lshl_add_u32 v166, v166, 5, s97                           ; d64600a6 01850ba6
(invalid instruction)                                        ; cc0f00a9
	v_min_num_f64_e32 v[1:2], v[169:170], v[161:162]            ; 1a0343a9
(invalid instruction)                                        ; cc0f00ab
	v_min_num_f64_e32 v[1:2], v[155:156], v[159:160]            ; 1a033f9b
	v_lshl_add_u32 v167, v167, 5, s97                           ; d64600a7 01850ba7
(invalid instruction)                                        ; cc0f00aa
	v_min_num_f64_e32 v[1:2], v[170:171], v[162:163]            ; 1a0345aa
(invalid instruction)                                        ; cc0f00a8
	v_min_num_f64_e32 v[1:2], v[168:169], v[164:165]            ; 1a0349a8
(invalid instruction)                                        ; cc0f00a9
	v_min_num_f64_e32 v[1:2], v[169:170], v[165:166]            ; 1a034ba9
(invalid instruction)                                        ; cc0f00ab
	v_min_num_f64_e32 v[1:2], v[171:172], v[163:164]            ; 1a0347ab
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f00aa
	v_min_num_f64_e32 v[1:2], v[170:171], v[166:167]            ; 1a034daa
(invalid instruction)                                        ; cc0f00a8
	v_min_num_f64_e32 v[1:2], v[168:169], v[169:170]            ; 1a0353a8
(invalid instruction)                                        ; cc0f00ab
	v_min_num_f64_e32 v[1:2], v[171:172], v[167:168]            ; 1a034fab
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f00a8
	v_min_num_f64_e32 v[1:2], v[168:169], v[170:171]            ; 1a0355a8
(invalid instruction)                                        ; cc0f00a8
	v_min_num_f64_e32 v[1:2], v[168:169], v[171:172]            ; 1a0357a8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v172, v168, s91, s92 op_sel:[1,1]         ; d65c18ac 0170b7a8
(invalid instruction)                                        ; cc0f00a8
	v_min_num_f64_e32 v[1:2], v[168:169], v[172:173]            ; 1a0359a8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53210ad
	v_cndmask_b32_e32 v1, v168, v168, vcc_lo                    ; 020351a8
(invalid instruction)                                        ; d53100ad
	v_cndmask_b32_e32 v1, s89, v173, vcc_lo                     ; 02035a59
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v173, v128, vcc_lo                    ; 020101ad
	v_rcp_f32_e32 v174, v174                                    ; 7f5c55ae
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v179, v156, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b3 8a035d9c
	v_fma_mix_f32 v156, v156, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089c 8a035d9c
	v_fma_mix_f32 v178, v155, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b2 8a035d9b
	v_fma_mix_f32 v155, v155, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089b 8a035d9b
	v_fma_mix_f32 v177, v154, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b1 8a035d9a
	v_fma_mix_f32 v154, v154, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089a 8a035d9a
	v_fma_mix_f32 v180, v157, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b4 8a035d9d
	v_fma_mix_f32 v176, v153, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b0 8a035d99
	v_fma_mix_f32 v175, v152, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000af 8a035d98
	v_fma_mix_f32 v152, v152, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200898 8a035d98
	v_fma_mix_f32 v153, v153, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a035d99
	v_fma_mix_f32 v157, v157, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a035d9d
	v_fma_mix_f32 v181, v158, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b5 8a035d9e
	v_fma_mix_f32 v158, v158, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089e 8a035d9e
	v_fma_mix_f32 v182, v159, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b6 8a035d9f
	v_fma_mix_f32 v159, v159, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089f 8a035d9f
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v179, v156, vcc_lo                    ; 020339b3
	v_fma_mix_f32 v183, v160, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b7 8a035da0
	v_fma_mix_f32 v160, v160, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a0 8a035da0
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v177, v154, vcc_lo                    ; 020335b1
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v178, v155, vcc_lo                    ; 020337b2
	v_fma_mix_f32 v184, v161, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b8 8a035da1
	v_fma_mix_f32 v161, v161, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a1 8a035da1
	v_fma_mix_f32 v185, v162, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000b9 8a035da2
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v175, v152, vcc_lo                    ; 020331af
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v176, v153, vcc_lo                    ; 020333b0
	v_fma_mix_f32 v162, v162, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a2 8a035da2
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v180, v157, vcc_lo                    ; 02033bb4
	v_fma_mix_f32 v186, v163, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000ba 8a035da3
	v_fma_mix_f32 v163, v163, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a3 8a035da3
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v181, v158, vcc_lo                    ; 02033db5
	v_fma_mix_f32 v187, v164, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000bb 8a035da4
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v182, v159, vcc_lo                    ; 02033fb6
	v_fma_mix_f32 v164, v164, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a4 8a035da4
	v_fma_mix_f32 v188, v165, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000bc 8a035da5
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v183, v160, vcc_lo                    ; 020341b7
	v_fma_mix_f32 v165, v165, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a035da5
	v_fma_mix_f32 v189, v166, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000bd 8a035da6
	v_fma_mix_f32 v166, v166, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a6 8a035da6
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v184, v161, vcc_lo                    ; 020343b8
	v_fma_mix_f32 v190, v167, v174, neg(0) op_sel_hi:[1,0,0]    ; cc2000be 8a035da7
	v_fma_mix_f32 v167, v167, v174, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a7 8a035da7
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v185, v162, vcc_lo                    ; 020345b9
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[32:33], 0 ; cc464070 1a024126
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[76:77], v[32:33], 0 ; cc464078 1a02414c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[46:47], v[32:33], 0 ; cc464080 1a02412e
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v186, v163, vcc_lo                    ; 020347ba
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[78:79], v[32:33], 0 ; cc464088 1a02414e
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v187, v164, vcc_lo                    ; 020349bb
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v188, v165, vcc_lo                    ; 02034bbc
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v189, v166, vcc_lo                    ; 02034dbd
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v190, v167, vcc_lo                    ; 02034fbe
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[36:37], v[112:119] ; cc464070 1dc24928
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[44:45], v[36:37], v[120:127] ; cc464078 1de2492c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[54:55], v[36:37], v[128:135] ; cc464080 1e024936
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[88:89], v[36:37], v[136:143] ; cc464088 1e224958
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v191, s94, v112, v144                       ; cc2100bf 0642e05e
	v_fma_mixlo_f16 v7, s94, v114, v146                         ; cc210007 064ae45e
	v_fma_mixhi_f16 v7, s94, v115, v147                         ; cc220007 064ee65e
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v32, s94, v116, v148                        ; cc210020 0652e85e
	v_fma_mixlo_f16 v33, s94, v118, v150                        ; cc210021 065aec5e
	v_fma_mixhi_f16 v191, s94, v113, v145                       ; cc2200bf 0646e25e
	v_fma_mixhi_f16 v32, s94, v117, v149                        ; cc220020 0656ea5e
	v_fma_mixhi_f16 v33, s94, v119, v151                        ; cc220021 065eee5e
(invalid instruction)                                        ; cc1c0007
	v_subrev_f32_e32 v0, v7, v96                                ; 0a00c107
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c00bf
	v_subrev_f32_e32 v0, v191, v96                              ; 0a00c1bf
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v96                               ; 0a00c120
(invalid instruction)                                        ; cc1c0021
	v_subrev_f32_e32 v0, v33, v96                               ; 0a00c121
(invalid instruction)                                        ; cc1b0007
	v_subrev_f32_e32 v0, v7, v95                                ; 0a00bf07
(invalid instruction)                                        ; cc1b00bf
	v_subrev_f32_e32 v0, v191, v95                              ; 0a00bfbf
(invalid instruction)                                        ; cc1b0020
	v_subrev_f32_e32 v0, v32, v95                               ; 0a00bf20
(invalid instruction)                                        ; cc1b0021
	v_subrev_f32_e32 v0, v33, v95                               ; 0a00bf21
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v36, s94, v120, v92                         ; cc210024 0572f05e
	v_fma_mixhi_f16 v36, s94, v121, v93                         ; cc220024 0576f25e
	v_fma_mixlo_f16 v37, s94, v122, v94                         ; cc210025 057af45e
	v_fma_mixhi_f16 v37, s94, v123, v95                         ; cc220025 057ef65e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v38, s94, v124, v100                        ; cc210026 0592f85e
	v_fma_mixhi_f16 v38, s94, v125, v101                        ; cc220026 0596fa5e
	v_fma_mixlo_f16 v39, s94, v126, v102                        ; cc210027 059afc5e
	v_fma_mixhi_f16 v39, s94, v127, v103                        ; cc220027 059efe5e
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v96                               ; 0a00c124
(invalid instruction)                                        ; cc1c0025
	v_subrev_f32_e32 v0, v37, v96                               ; 0a00c125
(invalid instruction)                                        ; cc1c0026
	v_subrev_f32_e32 v0, v38, v96                               ; 0a00c126
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v40, s94, v128, v60                         ; cc210028 04f3005e
	v_fma_mixhi_f16 v40, s94, v129, v61                         ; cc220028 04f7025e
(invalid instruction)                                        ; cc1c0027
	v_subrev_f32_e32 v0, v39, v96                               ; 0a00c127
	v_fma_mixlo_f16 v41, s94, v130, v62                         ; cc210029 04fb045e
	v_fma_mixhi_f16 v41, s94, v131, v63                         ; cc220029 04ff065e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v44, s94, v132, v68                         ; cc21002c 0513085e
(invalid instruction)                                        ; cc1b0024
	v_subrev_f32_e32 v0, v36, v95                               ; 0a00bf24
	v_fma_mixhi_f16 v44, s94, v133, v69                         ; cc22002c 05170a5e
	v_fma_mixlo_f16 v45, s94, v134, v70                         ; cc21002d 051b0c5e
(invalid instruction)                                        ; cc1b0025
	v_subrev_f32_e32 v0, v37, v95                               ; 0a00bf25
	v_fma_mixhi_f16 v45, s94, v135, v71                         ; cc22002d 051f0e5e
	buffer_load_b128 v[60:63], v14, s[24:27], null offen        ; c405c07c 4080303c 0000000e
(invalid instruction)                                        ; cc1b0026
	v_subrev_f32_e32 v0, v38, v95                               ; 0a00bf26
(invalid instruction)                                        ; cc1c0028
	v_subrev_f32_e32 v0, v40, v96                               ; 0a00c128
(invalid instruction)                                        ; cc1b0027
	v_subrev_f32_e32 v0, v39, v95                               ; 0a00bf27
(invalid instruction)                                        ; cc1c0029
	v_subrev_f32_e32 v0, v41, v96                               ; 0a00c129
(invalid instruction)                                        ; cc1c002c
	v_subrev_f32_e32 v0, v44, v96                               ; 0a00c12c
(invalid instruction)                                        ; cc1c002d
	v_subrev_f32_e32 v0, v45, v96                               ; 0a00c12d
(invalid instruction)                                        ; cc1b0028
	v_subrev_f32_e32 v0, v40, v95                               ; 0a00bf28
	buffer_load_b128 v[68:71], v14, s[24:27], null offen offset:16 ; c405c07c 40803044 0000100e
(invalid instruction)                                        ; cc1b0029
	v_subrev_f32_e32 v0, v41, v95                               ; 0a00bf29
(invalid instruction)                                        ; cc1b002c
	v_subrev_f32_e32 v0, v44, v95                               ; 0a00bf2c
(invalid instruction)                                        ; cc1b002d
	v_subrev_f32_e32 v0, v45, v95                               ; 0a00bf2d
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v47, s94, v138, v74                         ; cc21002f 052b145e
	v_fma_mixlo_f16 v46, s94, v136, v72                         ; cc21002e 0523105e
	v_fma_mixhi_f16 v46, s94, v137, v73                         ; cc22002e 0527125e
	v_fma_mixhi_f16 v47, s94, v139, v75                         ; cc22002f 052f165e
	v_lshl_add_u32 v191, v191, 5, s97                           ; d64600bf 01850bbf
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v55, s94, v142, v82                         ; cc210037 054b1c5e
	v_fma_mixlo_f16 v54, s94, v140, v80                         ; cc210036 0543185e
	v_fma_mixhi_f16 v55, s94, v143, v83                         ; cc220037 054f1e5e
	v_fma_mixhi_f16 v54, s94, v141, v81                         ; cc220036 05471a5e
	v_lshl_add_u32 v36, v36, 5, s97                             ; d6460024 01850b24
	v_lshl_add_u32 v40, v40, 5, s97                             ; d6460028 01850b28
(invalid instruction)                                        ; cc1c002e
	v_subrev_f32_e32 v0, v46, v96                               ; 0a00c12e
	v_lshl_add_u32 v7, v7, 5, s97                               ; d6460007 01850b07
(invalid instruction)                                        ; cc1c002f
	v_subrev_f32_e32 v0, v47, v96                               ; 0a00c12f
	v_lshl_add_u32 v37, v37, 5, s97                             ; d6460025 01850b25
	v_lshl_add_u32 v41, v41, 5, s97                             ; d6460029 01850b29
(invalid instruction)                                        ; cc1c0037
	v_subrev_f32_e32 v0, v55, v96                               ; 0a00c137
(invalid instruction)                                        ; cc1c0036
	v_subrev_f32_e32 v0, v54, v96                               ; 0a00c136
(invalid instruction)                                        ; cc0f0048
	v_min_num_f64_e32 v[1:2], v[191:192], v[36:37]              ; 1a0249bf
	v_lshl_add_u32 v32, v32, 5, s97                             ; d6460020 01850b20
	v_lshl_add_u32 v38, v38, 5, s97                             ; d6460026 01850b26
(invalid instruction)                                        ; cc1b002e
	v_subrev_f32_e32 v0, v46, v95                               ; 0a00bf2e
	v_lshl_add_u32 v44, v44, 5, s97                             ; d646002c 01850b2c
(invalid instruction)                                        ; cc1b002f
	v_subrev_f32_e32 v0, v47, v95                               ; 0a00bf2f
(invalid instruction)                                        ; cc0f0049
	v_min_num_f64_e32 v[1:2], v[7:8], v[37:38]                  ; 1a024b07
	v_lshl_add_u32 v33, v33, 5, s97                             ; d6460021 01850b21
(invalid instruction)                                        ; cc1b0037
	v_subrev_f32_e32 v0, v55, v95                               ; 0a00bf37
(invalid instruction)                                        ; cc1b0036
	v_subrev_f32_e32 v0, v54, v95                               ; 0a00bf36
	v_lshl_add_u32 v39, v39, 5, s97                             ; d6460027 01850b27
(invalid instruction)                                        ; cc0f0048
	v_min_num_f64_e32 v[1:2], v[72:73], v[40:41]                ; 1a025148
	v_lshl_add_u32 v45, v45, 5, s97                             ; d646002d 01850b2d
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[32:33], v[38:39]                ; 1a024d20
	v_lshl_add_u32 v46, v46, 5, s97                             ; d646002e 01850b2e
	v_lshl_add_u32 v47, v47, 5, s97                             ; d646002f 01850b2f
(invalid instruction)                                        ; cc0f0049
	v_min_num_f64_e32 v[1:2], v[73:74], v[41:42]                ; 1a025349
	v_lshl_add_u32 v55, v55, 5, s97                             ; d6460037 01850b37
	v_lshl_add_u32 v54, v54, 5, s97                             ; d6460036 01850b36
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[33:34], v[39:40]                ; 1a024f21
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[44:45]                ; 1a02594a
(invalid instruction)                                        ; cc0f0048
	v_min_num_f64_e32 v[1:2], v[72:73], v[46:47]                ; 1a025d48
(invalid instruction)                                        ; cc0f0049
	v_min_num_f64_e32 v[1:2], v[73:74], v[47:48]                ; 1a025f49
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[45:46]                ; 1a025b4b
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[54:55]                ; 1a026d4a
(invalid instruction)                                        ; cc0f0048
	v_min_num_f64_e32 v[1:2], v[72:73], v[73:74]                ; 1a029348
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[55:56]                ; 1a026f4b
(invalid instruction)                                        ; cc0f0048
	v_min_num_f64_e32 v[1:2], v[72:73], v[74:75]                ; 1a029548
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0048
	v_min_num_f64_e32 v[1:2], v[72:73], v[75:76]                ; 1a029748
	v_permlanex16_b32 v76, v72, s91, s92 op_sel:[1,1]           ; d65c184c 0170b748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0048
	v_min_num_f64_e32 v[1:2], v[72:73], v[76:77]                ; 1a029948
	v_add_f16_e32 v77, v72, v200/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 649b9148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v77, s89, v77                             ; 629a9a59
	v_cvt_f32_f16_e32 v78, v77                                  ; 7e9c174d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v78, v78                                      ; 7e9c554e
	v_fma_mix_f32 v80, v7, v78, neg(0) op_sel_hi:[1,0,0]        ; cc200050 8a029d07
	v_fma_mix_f32 v7, v7, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200807 8a029d07
	v_fma_mix_f32 v82, v33, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200052 8a029d21
	v_fma_mix_f32 v33, v33, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200821 8a029d21
	v_fma_mix_f32 v79, v191, v78, neg(0) op_sel_hi:[1,0,0]      ; cc20004f 8a029dbf
	v_fma_mix_f32 v191, v191, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a029dbf
	v_fma_mix_f32 v83, v36, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200053 8a029d24
	v_fma_mix_f32 v36, v36, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200824 8a029d24
	v_fma_mix_f32 v81, v32, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200051 8a029d20
	v_fma_mix_f32 v32, v32, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a029d20
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v79, v191, vcc_lo                     ; 02037f4f
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v80, v7, vcc_lo                       ; 02020f50
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v81, v32, vcc_lo                      ; 02024151
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v82, v33, vcc_lo                      ; 02024352
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v83, v36, vcc_lo                      ; 02024953
	v_fma_mix_f32 v86, v37, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200056 8a029d25
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[80:83], v14, s[24:27], null offen offset:64 ; c405c07c 40803050 0000400e
	buffer_load_b128 v[96:99], v14, s[24:27], null offen offset:80 ; c405c07c 40803060 0000500e
	v_fma_mix_f32 v37, v37, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200825 8a029d25
	v_fma_mix_f32 v87, v38, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200057 8a029d26
	v_fma_mix_f32 v38, v38, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200826 8a029d26
	v_fma_mix_f32 v88, v39, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200058 8a029d27
	v_fma_mix_f32 v39, v39, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200827 8a029d27
	v_fma_mix_f32 v89, v40, v78, neg(0) op_sel_hi:[1,0,0]       ; cc200059 8a029d28
	v_fma_mix_f32 v40, v40, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200828 8a029d28
	v_fma_mix_f32 v92, v41, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005c 8a029d29
	v_fma_mix_f32 v41, v41, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200829 8a029d29
	s_lshr_b32 s45, s45, 2                                      ; 852d822d
	v_fma_mix_f32 v93, v44, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005d 8a029d2c
	v_fma_mix_f32 v44, v44, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082c 8a029d2c
	v_fma_mix_f32 v94, v45, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005e 8a029d2d
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v86, v37, vcc_lo                      ; 02024b56
	v_fma_mix_f32 v45, v45, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082d 8a029d2d
	v_fma_mix_f32 v95, v46, v78, neg(0) op_sel_hi:[1,0,0]       ; cc20005f 8a029d2e
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v87, v38, vcc_lo                      ; 02024d57
	v_fma_mix_f32 v46, v46, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082e 8a029d2e
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v88, v39, vcc_lo                      ; 02024f58
	v_fma_mix_f32 v100, v47, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200064 8a029d2f
	v_fma_mix_f32 v47, v47, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082f 8a029d2f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v31, v31, s45, v15                               ; d655001f 043c5b1f
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v89, v40, vcc_lo                      ; 02025159
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v92, v41, vcc_lo                      ; 0202535c
	v_fma_mix_f32 v101, v54, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200065 8a029d36
	v_fma_mix_f32 v54, v54, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200836 8a029d36
	v_fma_mix_f32 v102, v55, v78, neg(0) op_sel_hi:[1,0,0]      ; cc200066 8a029d37
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v93, v44, vcc_lo                      ; 0202595d
	v_fma_mix_f32 v55, v55, v78, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200837 8a029d37
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[16:17], 0 ; cc464070 1a02210c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v94, v45, vcc_lo                      ; 02025b5e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[12:13], v[90:91], 0 ; cc464078 1a02b50c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[12:13], v[18:19], 0 ; cc464080 1a02250c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[12:13], v[72:73], 0 ; cc464088 1a02910c
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v95, v46, vcc_lo                      ; 02025d5f
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v100, v47, vcc_lo                     ; 02025f64
	v_lshlrev_b32_e32 v31, 2, v31                               ; 303e3e82
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v101, v54, vcc_lo                     ; 02026d65
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v102, v55, vcc_lo                     ; 02026f66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[20:21], v[112:119] ; cc464070 1dc2291a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[104:105], v[120:127] ; cc464078 1de2d11a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[58:59], v[128:135] ; cc464080 1e02751a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[26:27], v[32:33], v[136:143] ; cc464088 1e22411a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[22:23], v[112:119] ; cc464070 1dc22d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[108:109], v[120:127] ; cc464078 1de2d92a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[66:67], v[128:135] ; cc464080 1e02852a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[42:43], v[36:37], v[136:143] ; cc464088 1e22492a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[56:57], v[112:119] ; cc464070 1dc27132
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[110:111], v[120:127] ; cc464078 1de2dd32
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[84:85], v[128:135] ; cc464080 1e02a932
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[50:51], v[38:39], v[136:143] ; cc464088 1e224d32
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[16:17], 0 ; cc464070 1a022118
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[24:25], v[90:91], 0 ; cc464078 1a02b518
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[18:19], 0 ; cc464058 1a022518
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	buffer_load_b128 v[16:19], v31, s[28:31], null offen        ; c405c07c 40803810 0000001f
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[24:25], v[72:73], 0 ; cc464080 1a029118
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[28:29], v[20:21], v[112:119] ; cc464070 1dc2291c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[28:29], v[104:105], v[120:127] ; cc464078 1de2d11c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[58:59], v[88:95] ; cc464058 1d62751c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[28:29], v[32:33], v[128:135] ; cc464080 1e02411c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[22:23], v[112:119] ; cc464070 1dc22d30
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[48:49], v[108:109], v[120:127] ; cc464078 1de2d930
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[66:67], v[88:95] ; cc464058 1d628530
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[48:49], v[36:37], v[128:135] ; cc464080 1e024930
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[64:65], v[56:57], v[112:119] ; cc464070 1dc27140
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[64:65], v[110:111], v[120:127] ; cc464078 1de2dd40
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[64:65], v[84:85], v[88:95] ; cc464058 1d62a940
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[64:65], v[38:39], v[128:135] ; cc464080 1e024d40
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	ds_store_2addr_b64 v34, v[12:13], v[14:15] offset1:32       ; d9382000 000e0c22
	buffer_load_b128 v[20:23], v31, s[28:31], null offen offset:512 ; c405c07c 40803814 0002001f
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	ds_store_2addr_b64 v9, v[26:27], v[12:13] offset1:32        ; d9382000 000c1a09
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	ds_store_2addr_b64 v10, v[40:41], v[12:13] offset1:32       ; d9382000 000c280a
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	ds_store_2addr_b64 v52, v[42:43], v[12:13] offset1:32       ; d9382000 000c2a34
	buffer_load_b128 v[12:15], v31, s[28:31], null offen offset:1024 ; c405c07c 4080380c 0004001f
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b64 v[24:25], v53                                   ; d9d80000 18000035
	ds_load_b64 v[26:27], v53 offset:2048                       ; d9d80800 1a000035
	ds_load_b64 v[28:29], v53 offset:4096                       ; d9d81000 1c000035
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[32:33], v24                          ; 7e40dd18
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v41, v33, v61 :: v_dual_mul_f32 v40, v32, v60 ; c8c67b21 29287920
	v_cvt_pk_f32_fp8_e32 v[32:33], v152                         ; 7e40dd98
	v_dual_mul_f32 v43, v33, v63 :: v_dual_mul_f32 v42, v32, v62 ; c8c67f21 2b2a7d20
	buffer_load_b128 v[32:35], v31, s[28:31], null offen offset:1536 ; c405c07c 40803820 0006001f
	v_cvt_pk_f32_fp8_e32 v[36:37], v25                          ; 7e48dd19
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v45, v37, v69 :: v_dual_mul_f32 v44, v36, v68 ; c8c68b25 2d2c8924
	ds_load_b64 v[36:37], v53 offset:6144                       ; d9d81800 24000035
	buffer_load_b128 v[48:51], v31, s[28:31], null offen offset:2048 ; c405c07c 40803830 0008001f
	ds_load_b64 v[38:39], v53 offset:256                        ; d9d80100 26000035
	buffer_load_b128 v[56:59], v31, s[28:31], null offen offset:2560 ; c405c07c 40803838 000a001f
	v_cvt_pk_f32_fp8_e32 v[24:25], v153                         ; 7e30dd99
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v47, v25, v71 :: v_dual_mul_f32 v46, v24, v70 ; c8c68f19 2f2e8d18
	s_wait_dscnt 0x3                                            ; bfc60003
	v_cvt_pk_f32_fp8_e32 v[24:25], v26                          ; 7e30dd1a
	v_dual_mul_f32 v73, v25, v61 :: v_dual_mul_f32 v72, v24, v60 ; c8c67b19 49487918
	v_cvt_pk_f32_fp8_e32 v[24:25], v154                         ; 7e30dd9a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_dual_mul_f32 v75, v25, v63 :: v_dual_mul_f32 v74, v24, v62 ; c8c67f19 4b4a7d18
	v_cvt_pk_f32_fp8_e32 v[24:25], v27                          ; 7e30dd1b
	v_cvt_pk_f32_fp8_e32 v[26:27], v155                         ; 7e34dd9b
	v_dual_mul_f32 v77, v25, v69 :: v_dual_mul_f32 v76, v24, v68 ; c8c68b19 4d4c8918
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[24:25], v28                          ; 7e30dd1c
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v89, v25, v61 :: v_dual_mul_f32 v88, v24, v60 ; c8c67b19 59587918
	v_cvt_pk_f32_fp8_e32 v[24:25], v156                         ; 7e30dd9c
	v_dual_mul_f32 v91, v25, v63 :: v_dual_mul_f32 v90, v24, v62 ; c8c67f19 5b5a7d18
	v_cvt_pk_f32_fp8_e32 v[24:25], v29                          ; 7e30dd1d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_dual_mul_f32 v79, v27, v71 :: v_dual_mul_f32 v92, v24, v68 ; c8c68f1b 4f5c8918
	v_dual_mul_f32 v93, v25, v69 :: v_dual_mul_f32 v78, v26, v70 ; c8c68b19 5d4e8d1a
	v_cvt_pk_f32_fp8_e32 v[24:25], v157                         ; 7e30dd9d
	v_dual_mul_f32 v95, v25, v71 :: v_dual_mul_f32 v94, v24, v70 ; c8c68f19 5f5e8d18
	buffer_load_b128 v[24:27], v31, s[28:31], null offen offset:3072 ; c405c07c 40803818 000c001f
	ds_load_b64 v[54:55], v53 offset:2304                       ; d9d80900 36000035
	s_wait_dscnt 0x2                                            ; bfc60002
	v_cvt_pk_f32_fp8_e32 v[28:29], v36                          ; 7e38dd24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v104, v28, v60                                ; 10d0791c
	v_mul_f32_e32 v105, v29, v61                                ; 10d27b1d
	v_cvt_pk_f32_fp8_e32 v[28:29], v164                         ; 7e38dda4
	v_dual_mul_f32 v107, v29, v63 :: v_dual_mul_f32 v106, v28, v62 ; c8c67f1d 6b6a7d1c
	buffer_load_b128 v[60:63], v31, s[28:31], null offen offset:3584 ; c405c07c 4080383c 000e001f
	v_cvt_pk_f32_fp8_e32 v[28:29], v37                          ; 7e38dd25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v109, v29, v69 :: v_dual_mul_f32 v108, v28, v68 ; c8c68b1d 6d6c891c
	v_cvt_pk_f32_fp8_e32 v[28:29], v165                         ; 7e38dda5
	v_dual_mul_f32 v111, v29, v71 :: v_dual_mul_f32 v110, v28, v70 ; c8c68f1d 6f6e8d1c
	s_wait_dscnt 0x1                                            ; bfc60001
	v_cvt_pk_f32_fp8_e32 v[28:29], v38                          ; 7e38dd26
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v65, v29, v81 :: v_dual_mul_f32 v64, v28, v80 ; c8c6a31d 4140a11c
	v_cvt_pk_f32_fp8_e32 v[28:29], v166                         ; 7e38dda6
	v_dual_mul_f32 v67, v29, v83 :: v_dual_mul_f32 v66, v28, v82 ; c8c6a71d 4342a51c
	v_cvt_pk_f32_fp8_e32 v[28:29], v39                          ; 7e38dd27
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v69, v29, v97 :: v_dual_mul_f32 v68, v28, v96 ; c8c6c31d 4544c11c
	v_cvt_pk_f32_fp8_e32 v[28:29], v167                         ; 7e38dda7
	v_dual_mul_f32 v71, v29, v99 :: v_dual_mul_f32 v70, v28, v98 ; c8c6c71d 4746c51c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cvt_pk_f32_fp8_e32 v[28:29], v54                          ; 7e38dd36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v113, v29, v81 :: v_dual_mul_f32 v112, v28, v80 ; c8c6a31d 7170a11c
	v_cvt_pk_f32_fp8_e32 v[28:29], v182                         ; 7e38ddb6
	v_dual_mul_f32 v115, v29, v83 :: v_dual_mul_f32 v114, v28, v82 ; c8c6a71d 7372a51c
	v_cvt_pk_f32_fp8_e32 v[28:29], v55                          ; 7e38dd37
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v117, v29, v97 :: v_dual_mul_f32 v116, v28, v96 ; c8c6c31d 7574c11c
	v_cvt_pk_f32_fp8_e32 v[28:29], v183                         ; 7e38ddb7
	ds_load_b64 v[36:37], v53 offset:4352                       ; d9d81100 24000035
	ds_load_b64 v[38:39], v53 offset:6400                       ; d9d81900 26000035
	ds_load_b64 v[52:53], v11 offset:8192                       ; d9d82000 3400000b
	ds_load_b64 v[54:55], v11 offset:10240                      ; d9d82800 3600000b
	ds_load_b64 v[84:85], v11 offset:12288                      ; d9d83000 5400000b
	ds_load_b64 v[86:87], v11 offset:14336                      ; d9d83800 5600000b
	v_dual_mul_f32 v119, v29, v99 :: v_dual_mul_f32 v118, v28, v98 ; c8c6c71d 7776c51c
	s_wait_dscnt 0x5                                            ; bfc60005
	v_cvt_pk_f32_fp8_e32 v[28:29], v36                          ; 7e38dd24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v121, v29, v81 :: v_dual_mul_f32 v120, v28, v80 ; c8c6a31d 7978a11c
	v_cvt_pk_f32_fp8_e32 v[28:29], v164                         ; 7e38dda4
	v_dual_mul_f32 v123, v29, v83 :: v_dual_mul_f32 v122, v28, v82 ; c8c6a71d 7b7aa51c
	v_cvt_pk_f32_fp8_e32 v[28:29], v37                          ; 7e38dd25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v125, v29, v97 :: v_dual_mul_f32 v124, v28, v96 ; c8c6c31d 7d7cc11c
	v_cvt_pk_f32_fp8_e32 v[28:29], v165                         ; 7e38dda5
	v_dual_mul_f32 v127, v29, v99 :: v_dual_mul_f32 v126, v28, v98 ; c8c6c71d 7f7ec51c
	s_wait_dscnt 0x4                                            ; bfc60004
	v_cvt_pk_f32_fp8_e32 v[28:29], v38                          ; 7e38dd26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_mul_f32_e32 v129, v29, v81                                ; 1102a31d
	v_mul_f32_e32 v128, v28, v80                                ; 1100a11c
	v_cvt_pk_f32_fp8_e32 v[28:29], v166                         ; 7e38dda6
	v_dual_mul_f32 v139, v29, v83 :: v_dual_mul_f32 v138, v28, v82 ; c8c6a71d 8b8aa51c
	v_cvt_pk_f32_fp8_e32 v[28:29], v39                          ; 7e38dd27
	s_wait_loadcnt_dscnt 0x703                                  ; bfc80703
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[16:17], v[52:53], v[40:47] ; cc464028 1ca26910
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[16:17], v[54:55], v[72:79] ; cc464048 1d226d10
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[16:17], v[84:85], v[88:95] ; cc464058 1d62a910
	v_dual_mul_f32 v133, v29, v97 :: v_dual_mul_f32 v132, v28, v96 ; c8c6c31d 8584c11c
	v_cvt_pk_f32_fp8_e32 v[28:29], v167                         ; 7e38dda7
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v135, v29, v99 :: v_dual_mul_f32 v134, v28, v98 ; c8c6c71d 8786c51c
	ds_load_b64 v[36:37], v11 offset:8448                       ; d9d82100 2400000b
	ds_load_b64 v[100:101], v11 offset:10496                    ; d9d82900 6400000b
	ds_load_b64 v[102:103], v11 offset:12544                    ; d9d83100 6600000b
	ds_load_b64 v[130:131], v11 offset:14592                    ; d9d83900 8200000b
	ds_load_b64 v[38:39], v11 offset:8704                       ; d9d82200 2600000b
	ds_load_b64 v[80:81], v11 offset:10752                      ; d9d82a00 5000000b
	ds_load_b64 v[82:83], v11 offset:12800                      ; d9d83200 5200000b
	ds_load_b64 v[96:97], v11 offset:14848                      ; d9d83a00 6000000b
	ds_load_b64 v[28:29], v11 offset:8960                       ; d9d82300 1c00000b
	ds_load_b64 v[98:99], v11 offset:11008                      ; d9d82b00 6200000b
	ds_load_b64 v[136:137], v11 offset:13056                    ; d9d83300 8800000b
	ds_load_b64 v[140:141], v11 offset:15104                    ; d9d83b00 8c00000b
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[86:87], v[104:111] ; cc464068 1da2ad10
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[18:19], v[52:53], v[64:71] ; cc464040 1d026912
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[18:19], v[54:55], v[112:119] ; cc464070 1dc26d12
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[18:19], v[84:85], v[120:127] ; cc464078 1de2a912
	s_wait_loadcnt_dscnt 0x60b                                  ; bfc8060b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[20:21], v[36:37], v[40:47] ; cc464028 1ca24914
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[20:21], v[100:101], v[72:79] ; cc464048 1d22c914
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[102:103], v[88:95] ; cc464058 1d62cd14
	s_wait_dscnt 0x8                                            ; bfc60008
	v_dual_mov_b32 v17, v131 :: v_dual_mov_b32 v16, v130        ; ca100183 11100182
	v_dual_mov_b32 v131, v139 :: v_dual_mov_b32 v130, v138      ; ca10018b 8382018a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[18:19], v[86:87], v[128:135] ; cc464080 1e02ad12
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[22:23], v[36:37], v[64:71] ; cc464040 1d024916
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[100:101], v[112:119] ; cc464070 1dc2c916
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[102:103], v[120:127] ; cc464078 1de2cd16
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[20:21], v[16:17], v[104:111] ; cc464068 1da22114
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[16:17], v[128:135] ; cc464080 1e022116
	ds_load_b64 v[18:19], v11 offset:9216                       ; d9d82400 1200000b
	ds_load_b64 v[52:53], v11 offset:11264                      ; d9d82c00 3400000b
	ds_load_b64 v[54:55], v11 offset:13312                      ; d9d83400 3600000b
	ds_load_b64 v[84:85], v11 offset:15360                      ; d9d83c00 5400000b
	ds_load_b64 v[16:17], v11 offset:9472                       ; d9d82500 1000000b
	ds_load_b64 v[20:21], v11 offset:11520                      ; d9d82d00 1400000b
	ds_load_b64 v[22:23], v11 offset:13568                      ; d9d83500 1600000b
	ds_load_b64 v[36:37], v11 offset:15616                      ; d9d83d00 2400000b
	s_wait_loadcnt_dscnt 0x50f                                  ; bfc8050f
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[38:39], v[40:47] ; cc464028 1ca24d0c
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[12:13], v[80:81], v[72:79] ; cc464048 1d22a10c
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[82:83], v[88:95] ; cc464058 1d62a50c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[38:39], v[64:71] ; cc464040 1d024d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[80:81], v[112:119] ; cc464070 1dc2a10e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[14:15], v[82:83], v[120:127] ; cc464078 1de2a50e
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[96:97], v[104:111] ; cc464068 1da2c10c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[96:97], v[128:135] ; cc464080 1e02c10e
	s_wait_loadcnt_dscnt 0x40b                                  ; bfc8040b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[32:33], v[28:29], v[40:47] ; cc464028 1ca23920
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[32:33], v[98:99], v[72:79] ; cc464048 1d22c520
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[136:137], v[88:95] ; cc464058 1d631120
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[34:35], v[28:29], v[64:71] ; cc464040 1d023922
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[98:99], v[112:119] ; cc464070 1dc2c522
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[34:35], v[136:137], v[120:127] ; cc464078 1de31122
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[32:33], v[140:141], v[104:111] ; cc464068 1da31920
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[34:35], v[140:141], v[128:135] ; cc464080 1e031922
	ds_load_b64 v[12:13], v11 offset:9728                       ; d9d82600 0c00000b
	ds_load_b64 v[14:15], v11 offset:11776                      ; d9d82e00 0e00000b
	ds_load_b64 v[38:39], v11 offset:13824                      ; d9d83600 2600000b
	ds_load_b64 v[80:81], v11 offset:15872                      ; d9d83e00 5000000b
	ds_load_b64 v[28:29], v11 offset:9984                       ; d9d82700 1c00000b
	ds_load_b64 v[32:33], v11 offset:12032                      ; d9d82f00 2000000b
	ds_load_b64 v[34:35], v11 offset:14080                      ; d9d83700 2200000b
	ds_load_b64 v[10:11], v11 offset:16128                      ; d9d83f00 0a00000b
	s_wait_loadcnt_dscnt 0x30f                                  ; bfc8030f
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[48:49], v[18:19], v[40:47] ; cc464028 1ca22530
	s_wait_dscnt 0xe                                            ; bfc6000e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[48:49], v[52:53], v[72:79] ; cc464048 1d226930
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[54:55], v[88:95] ; cc464058 1d626d30
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[50:51], v[18:19], v[64:71] ; cc464040 1d022532
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[52:53], v[112:119] ; cc464070 1dc26932
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[54:55], v[120:127] ; cc464078 1de26d32
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[84:85], v[104:111] ; cc464068 1da2a930
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[50:51], v[84:85], v[128:135] ; cc464080 1e02a932
	s_wait_loadcnt_dscnt 0x20b                                  ; bfc8020b
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[56:57], v[16:17], v[40:47] ; cc464028 1ca22138
	s_wait_dscnt 0xa                                            ; bfc6000a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[56:57], v[20:21], v[72:79] ; cc464048 1d222938
	s_wait_dscnt 0x9                                            ; bfc60009
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[56:57], v[22:23], v[88:95] ; cc464058 1d622d38
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[58:59], v[16:17], v[64:71] ; cc464040 1d02213a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[20:21], v[112:119] ; cc464070 1dc2293a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[58:59], v[22:23], v[120:127] ; cc464078 1de22d3a
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[56:57], v[36:37], v[104:111] ; cc464068 1da24938
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[36:37], v[128:135] ; cc464080 1e02493a
	s_wait_loadcnt_dscnt 0x107                                  ; bfc80107
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[24:25], v[12:13], v[40:47] ; cc464028 1ca21918
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[14:15], v[72:79] ; cc464048 1d221d18
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[38:39], v[88:95] ; cc464058 1d624d18
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[26:27], v[12:13], v[64:71] ; cc464040 1d02191a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[14:15], v[112:119] ; cc464070 1dc21d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[38:39], v[120:127] ; cc464078 1de24d1a
	s_wait_dscnt 0x4                                            ; bfc60004
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[24:25], v[80:81], v[104:111] ; cc464068 1da2a118
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[26:27], v[80:81], v[128:135] ; cc464080 1e02a11a
	s_wait_loadcnt_dscnt 0x3                                    ; bfc80003
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[60:61], v[28:29], v[40:47] ; cc464028 1ca2393c
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[60:61], v[32:33], v[72:79] ; cc464048 1d22413c
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[60:61], v[34:35], v[88:95] ; cc464058 1d62453c
	s_cmp_lg_i32 s81, 0                                         ; bf018051
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[62:63], v[28:29], v[64:71] ; cc464040 1d02393e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[32:33], v[112:119] ; cc464070 1dc2413e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[62:63], v[34:35], v[120:127] ; cc464078 1de2453e
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[60:61], v[10:11], v[104:111] ; cc464068 1da2153c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[10:11], v[128:135] ; cc464080 1e02153e
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_cbranch_scc1 BB88                                         ; bfa20008
BB86:
	v_add3_u32 v7, v5, s41, s69                                 ; d6550007 01145305
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v7, v6, v7, v8                                   ; d6550007 04220f06
	buffer_store_b64 v[10:11], v7, s[48:51], null offen scope:SCOPE_DEV ; c406c07c 4088600a 00000007
BB88:
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_mov_b32 s23, src_scc                                      ; be9700fd
	s_cmp_lg_i32 s84, 0                                         ; bf018054
	s_cbranch_scc1 BB91                                         ; bfa20008
BB89:
	v_add3_u32 v7, v5, s41, s68                                 ; d6550007 01105305
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v7, v6, v7, v8                                   ; d6550007 04220f06
	buffer_store_b64 v[10:11], v7, s[48:51], null offen scope:SCOPE_DEV ; c406c07c 4088600a 00000007
BB91:
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_mov_b32 s24, src_scc                                      ; be9800fd
	s_cmp_lg_i32 s87, 0                                         ; bf018057
	s_cbranch_scc1 BB94                                         ; bfa20008
BB92:
	v_add3_u32 v7, v5, s41, s67                                 ; d6550007 010c5305
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v7, v6, v7, v8                                   ; d6550007 04220f06
	buffer_store_b64 v[10:11], v7, s[48:51], null offen scope:SCOPE_DEV ; c406c07c 4088600a 00000007
BB94:
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_mov_b32 s25, src_scc                                      ; be9900fd
	s_cmp_lg_i32 s90, 0                                         ; bf01805a
	s_cbranch_scc1 BB97                                         ; bfa20008
BB95:
	v_add3_u32 v5, v5, s41, s75                                 ; d6550005 012c5305
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v5, v6, v5, v8                                   ; d6550005 04220b06
	buffer_store_b64 v[10:11], v5, s[48:51], null offen scope:SCOPE_DEV ; c406c07c 4088600a 00000005
BB97:
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_mov_b32 s105, src_scc                                     ; bee900fd
	s_cmp_lg_i32 s23, 0                                         ; bf018017
	s_mov_b32 s23, s105                                         ; be970069
	s_cbranch_scc1 BB100                                        ; bfa20008
BB98:
	v_add3_u32 v5, v30, s41, s69                                ; d6550005 0114531e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v5, v6, v5, v8                                   ; d6550005 04220b06
	buffer_store_b64 v[10:11], v5, s[48:51], null offen scope:SCOPE_DEV ; c406c07c 4088600a 00000005
BB100:
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_cmp_lg_i32 s24, 0                                         ; bf018018
	s_cbranch_scc1 BB103                                        ; bfa20008
BB101:
	v_add3_u32 v5, v30, s41, s68                                ; d6550005 0110531e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v5, v6, v5, v8                                   ; d6550005 04220b06
	buffer_store_b64 v[10:11], v5, s[48:51], null offen scope:SCOPE_DEV ; c406c07c 4088600a 00000005
BB103:
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	s_cmp_lg_i32 s25, 0                                         ; bf018019
	s_cbranch_scc1 BB106                                        ; bfa20008
BB104:
	v_add3_u32 v5, v30, s41, s67                                ; d6550005 010c531e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v5, v6, v5, v8                                   ; d6550005 04220b06
	buffer_store_b64 v[10:11], v5, s[48:51], null offen scope:SCOPE_DEV ; c406c07c 4088600a 00000005
BB106:
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_cmp_lg_i32 s23, 0                                         ; bf018017
	s_cbranch_scc1 BB109                                        ; bfa20008
BB107:
	v_add3_u32 v30, v30, s41, s75                               ; d655001e 012c531e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v6, v6, v30, v8                                  ; d6550006 04223d06
	buffer_store_b64 v[10:11], v6, s[48:51], null offen scope:SCOPE_DEV ; c406c07c 4088600a 00000006
BB109:
	s_wait_storecnt 0x0                                         ; bfc10000
	s_barrier_signal -1                                         ; be804ec1
	v_cmpx_gt_u32_e32 4, v0                                     ; 7d980084
	s_barrier_wait 0xffff                                       ; bf94ffff
	s_cbranch_execz BB145                                       ; bfa50099
BB110:
	s_add_co_u32 s23, s6, s5                                    ; 80170506
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl2_add_u32 s4, s4, s23                                 ; 87841704
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v5, s4, v0, 2                                ; d6470005 020a0004
	buffer_load_b32 v5, v5, s[28:31], null offen                ; c405007c 40803805 00000005
	s_mov_b32 s24, exec_lo                                      ; be98007e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cmpx_ne_i32_e32 -1, v5                                    ; 7d8a0ac1
	s_cbranch_execz BB145                                       ; bfa5008c
BB111:
	v_add_lshl_u32 v6, s6, v5, 2                                ; d6470006 020a0a06
	buffer_load_b32 v6, v6, s[28:31], null offen                ; c405007c 40803806 00000006
	v_mov_b32_e32 v8, 1                                         ; 7e100281
	v_add_lshl_u32 v7, s2, v5, 2                                ; d6470007 020a0a02
	buffer_atomic_add_u32 v8, v7, s[12:15], null offen offset:16 th:TH_ATOMIC_RETURN ; c40d407c 40901808 00001007
	s_mov_b32 s4, exec_lo                                       ; be84007e
	s_wait_loadcnt 0x1                                          ; bfc00001
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v6, v22, vcc_lo                       ; 02002d06
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_add_nc_u32_e32 v8, 1, v8                                  ; 4a101081
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_eq_i32_e32 v8, v6                                    ; 7d840d08
	s_cbranch_execz BB145                                       ; bfa50078
BB112:
	s_mul_i32 s23, 6, s5                                        ; 96170586
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v6, v5, s6, s23                                  ; d6550006 005c0d05
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v6, 2, v6                                 ; 300c0c82
	buffer_load_b32 v6, v6, s[28:31], null offen                ; c405007c 40803806 00000006
	s_mul_i32 s25, 7, s5                                        ; 96190587
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s25, s6, s25                                   ; 80191906
	s_wait_loadcnt 0x0                                          ; bfc00000
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v7, v6, 1, s25                               ; d6460007 00650306
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v7, 2, v7                                 ; 300e0e82
	buffer_load_b64 v[8:9], v7, s[28:31], null offen            ; c405407c 40803808 00000007
	v_mov_b32_e32 v10, 1                                        ; 7e140281
	v_add_lshl_u32 v6, s18, v6, 2                               ; d6470006 020a0c12
	buffer_atomic_add_u32 v10, v6, s[12:15], null offen offset:12 th:TH_ATOMIC_RETURN ; c40d407c 4090180a 00000c06
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_max_u32_e32 v8, 1, v8                                     ; 28101081
	s_mov_b32 s28, exec_lo                                      ; be9c007e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_u32_e32 v11, v8                                   ; 7e160d08
	v_rcp_f32_e32 v11, v11                                      ; 7e16550b
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v11, 0x4f7ffffe, v11                          ; 101616ff 4f7ffffe
	v_cvt_u32_f32_e32 v11, v11                                  ; 7e160f0b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v1, v8, v11, vcc_lo                       ; 02021708
	v_sub_nc_u32_e32 v12, 0, v12                                ; 4c181880
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72d000c
	v_cndmask_b32_e32 v1, v11, v12, vcc_lo                      ; 0202190b
	v_add_nc_u32_e32 v11, v11, v12                              ; 4a16190b
	s_wait_loadcnt 0x0                                          ; bfc00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72d000b
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
(invalid instruction)                                        ; d72c000b
	v_cndmask_b32_e32 v1, v11, v8, vcc_lo                       ; 0202110b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v10, v10, v11                              ; 4c14170a
(invalid instruction)                                        ; d7011a0d
	v_cndmask_b32_e32 v1, v10, v8, vcc_lo                       ; 0202110a
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v13, v13, v10, s26                        ; d501000d 006a150d
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7011b08
	v_cndmask_b32_e32 v1, v13, v8, vcc_lo                       ; 0202110d
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v8, v8, v13, s27                          ; d5010008 006e1b08
	v_cmpx_ge_u32_e32 v8, v9                                    ; 7d9c1308
	s_cbranch_execz BB121                                       ; bfa5001a
BB113:
	s_bcnt1_i32_b32 s23, exec_lo                                ; be97187e
	s_ctz_i32_b32 s25, exec_lo                                  ; be99087e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s25, 1, s25                                      ; 84191981
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_saveexec_b32 s25, s25                                 ; be992019
	s_cbranch_execz BB119                                       ; bfa50005
BB114:
	v_mov_b32_e32 v6, s23                                       ; 7e0c0217
	s_lshl2_add_u32 s26, s18, 8                                 ; 879a8812
	buffer_atomic_add_u32 v6, off, s[12:15], s26 th:TH_ATOMIC_RETURN ; c40d401a 00901806 00000000
BB119:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, s25                                      ; befe0019
	v_or_b32_e32 v5, s21, v5                                    ; 380a0a15
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s23, v6                                 ; 7e2e0506
	s_wait_alu 0xf1ff                                           ; bf88f1ff
(invalid instruction)                                        ; d71f0006
	v_cndmask_b32_e32 v0, exec_lo, v23, vcc_lo                  ; 02002e7e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v6, s18, v6, 2                               ; d6470006 020a0c12
	buffer_store_b32 v5, v6, s[12:15], null offen offset:76 scope:SCOPE_DEV ; c406807c 40881805 00004c06
BB121:
	s_and_not1_b32 exec_lo, s28, exec_lo                        ; 917e7e1c
	s_cbranch_execz BB145                                       ; bfa5001a
BB122:
	s_bcnt1_i32_b32 s23, exec_lo                                ; be97187e
	s_ctz_i32_b32 s25, exec_lo                                  ; be99087e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s25, 1, s25                                      ; 84191981
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_saveexec_b32 s25, s25                                 ; be992019
	s_cbranch_execz BB128                                       ; bfa50005
BB123:
	v_mov_b32_e32 v6, s23                                       ; 7e0c0217
	s_lshl_b32 s26, s18, 2                                      ; 841a8212
	buffer_atomic_add_u32 v6, off, s[12:15], s26 th:TH_ATOMIC_RETURN ; c40d401a 00901806 00000000
BB128:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 exec_lo, s25                                      ; befe0019
	v_or_b32_e32 v5, s21, v5                                    ; 380a0a15
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s23, v6                                 ; 7e2e0506
	s_wait_alu 0xf1ff                                           ; bf88f1ff
(invalid instruction)                                        ; d71f0006
	v_cndmask_b32_e32 v0, exec_lo, v23, vcc_lo                  ; 02002e7e
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v6, s16, v6, 2                               ; d6470006 020a0c10
	buffer_store_b32 v5, v6, s[12:15], null offen scope:SCOPE_DEV ; c406807c 40881805 00000006
BB145:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	s_branch BB4                                                ; bfa0e065
BB146:
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB158                                       ; bfa5001c
BB147:
	v_mov_b32_e32 v0, 1                                         ; 7e000281
	s_add_co_u32 s0, s10, 4                                     ; 8000840a
	buffer_atomic_add_u32 v0, off, s[12:15], s0 th:TH_ATOMIC_RETURN ; c40d4000 00901800 00000000
	s_mov_b32 s1, exec_lo                                       ; be81007e
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_add_nc_u32_e32 v0, 1, v0                                  ; 4a000081
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cmpx_eq_i32_e32 s8, v0                                    ; 7d840008
	s_cbranch_execz BB158                                       ; bfa50011
BB148:
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0                ; ca100080 01000080
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0                ; ca100080 03020080
	v_dual_mov_b32 v5, s22 :: v_dual_mov_b32 v4, 0              ; ca100016 05040080
	s_lshl_b32 s18, s18, 2                                      ; 84128212
	s_clause 0x2                                                ; bf850002
	buffer_store_b64 v[0:1], off, s[12:15], s10 scope:SCOPE_DEV ; c406c00a 00881800 00000000
	buffer_store_b96 v[2:4], off, s[12:15], s18 scope:SCOPE_DEV ; c4070012 00881802 00000000
	buffer_store_b32 v5, off, s[12:15], s11 scope:SCOPE_DEV     ; c406800b 00881805 00000000
BB158:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
