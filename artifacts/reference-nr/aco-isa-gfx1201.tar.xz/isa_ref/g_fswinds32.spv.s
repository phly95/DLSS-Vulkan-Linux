BB0:
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_mov_b32 s10, s1                                           ; be8a0001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_clause 0x3                                                ; bf850003
	s_load_b128 s[12:15], s[0:1], 0x0                           ; f4004300 f8000000
	s_load_b256 s[16:23], s[0:1], 0x30                          ; f4006400 f8000030
	s_load_b128 s[24:27], s[10:11], 0x34                        ; f4004605 f8000034
	s_load_b64 s[0:1], s[10:11], 0x20                           ; f4002005 f8000020
(invalid instruction)                                        ; d71f0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870131
	v_and_b32_e32 v2, 15, v1                                    ; 3604028f
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	s_movk_i32 s36, 0x100                                       ; b0240100
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl1_add_u32 s28, ttmp9, s26                             ; 871c1a75
	s_lshl1_add_u32 s29, ttmp7, s27                             ; 871d1b73
	s_max_i32 s30, s28, 0                                       ; 8a1e801c
	s_add_co_u32 s31, s24, -1                                   ; 801fc118
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_min_i32 s30, s30, s31                                     ; 891e1f1e
	s_max_i32 s32, s29, 0                                       ; 8a20801d
	s_add_co_u32 s33, s25, -1                                   ; 8021c119
	s_min_i32 s32, s32, s33                                     ; 89202120
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s32, s32, s24                                     ; 96201820
	s_add_co_u32 s34, s32, s30                                  ; 80221e20
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s34, s34, 9                                      ; 84228922
	s_add_co_u32 s35, s2, s34                                   ; 80232202
	s_add_co_u32 s37, s28, 1                                    ; 8025811c
	v_add3_u32 v4, v1, s35, v3                                  ; d6550004 040c4701
	v_add3_u32 v5, v3, s35, s36                                 ; d6550005 00904703
	s_max_i32 s38, s37, 0                                       ; 8a268025
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_min_i32 s38, s38, s31                                     ; 89261f26
	v_add_nc_u32_e32 v5, v5, v1                                 ; 4a0a0305
	s_add_co_u32 s32, s32, s38                                  ; 80202620
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s32, s32, 9                                      ; 84208920
	s_add_co_u32 s39, s2, s32                                   ; 80272002
	s_add_co_u32 s40, s29, 1                                    ; 8028811d
	v_add3_u32 v7, v3, s39, s36                                 ; d6550007 00904f03
	v_add3_u32 v6, v1, s39, v3                                  ; d6550006 040c4f01
	s_max_i32 s41, s40, 0                                       ; 8a298028
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_min_i32 s41, s41, s33                                     ; 89292129
	v_add_nc_u32_e32 v7, v7, v1                                 ; 4a0e0307
	s_mul_i32 s41, s41, s24                                     ; 96291829
	s_add_co_u32 s30, s41, s30                                  ; 801e1e29
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s30, s30, 9                                      ; 841e891e
	s_add_co_u32 s42, s2, s30                                   ; 802a1e02
	s_add_co_u32 s41, s41, s38                                  ; 80292629
	v_add3_u32 v8, v1, s42, v3                                  ; d6550008 040c5501
	v_add3_u32 v9, v3, s42, s36                                 ; d6550009 00905503
	s_lshl_b32 s41, s41, 9                                      ; 84298929
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_add_co_u32 s2, s2, s41                                    ; 80022902
	v_add_nc_u32_e32 v9, v9, v1                                 ; 4a120309
	v_add3_u32 v10, v1, s2, v3                                  ; d655000a 040c0501
	v_add3_u32 v11, v3, s2, s36                                 ; d655000b 00900503
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v11, v11, v1                               ; 4a16030b
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[12:13], v4, s[12:15], null offen          ; c405407c 4080180c 00000004
	buffer_load_b64 v[4:5], v5, s[12:15], null offen            ; c405407c 40801804 00000005
	buffer_load_b64 v[14:15], v6, s[12:15], null offen          ; c405407c 4080180e 00000006
	buffer_load_b64 v[6:7], v7, s[12:15], null offen            ; c405407c 40801806 00000007
	buffer_load_b64 v[16:17], v8, s[12:15], null offen          ; c405407c 40801810 00000008
	buffer_load_b64 v[8:9], v9, s[12:15], null offen            ; c405407c 40801808 00000009
	buffer_load_b64 v[18:19], v10, s[12:15], null offen         ; c405407c 40801812 0000000a
	buffer_load_b64 v[10:11], v11, s[12:15], null offen         ; c405407c 4080180a 0000000b
	v_lshlrev_b32_e32 v20, 2, v0                                ; 30280082
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v21, s4, v20, 2                              ; d6470015 020a2804
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[24:27], v21, s[20:23], null offen        ; c405c07c 40802818 00000015
	buffer_load_b128 v[28:31], v21, s[20:23], null offen offset:512 ; c405c07c 4080281c 00020015
	buffer_load_b128 v[32:35], v21, s[20:23], null offen offset:1024 ; c405c07c 40802820 00040015
	buffer_load_b128 v[36:39], v21, s[20:23], null offen offset:1536 ; c405c07c 40802824 00060015
	buffer_load_b128 v[40:43], v21, s[20:23], null offen offset:2048 ; c405c07c 40802828 00080015
	buffer_load_b128 v[44:47], v21, s[20:23], null offen offset:2560 ; c405c07c 4080282c 000a0015
	s_min_i32 s43, s28, s29                                     ; 892b1d1c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s43, 0                                         ; bf04802b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_cselect_b32 s44, -1, 0                                    ; 982c80c1
	s_cmp_ge_i32 s28, s24                                       ; bf03181c
	s_cselect_b32 s45, -1, 0                                    ; 982d80c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_or_b32 s44, s44, s45                                      ; 8c2c2d2c
	s_cmp_ge_i32 s29, s25                                       ; bf03191d
	s_cselect_b32 s46, -1, 0                                    ; 982e80c1
	s_mov_b32 s47, src_scc                                      ; beaf00fd
	s_nor_b32 vcc_lo, s44, s46                                  ; 8f6a2e2c
	s_min_i32 s48, s37, s29                                     ; 89301d25
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s48, 0                                         ; bf048030
	s_cselect_b32 s49, -1, 0                                    ; 983180c1
	s_cmp_ge_i32 s37, s24                                       ; bf031825
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s50, -1, 0                                    ; 983280c1
	s_or_b32 s49, s49, s50                                      ; 8c313231
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_nor_b32 s49, s49, s46                                     ; 8f312e31
	s_min_i32 s51, s28, s40                                     ; 8933281c
	s_cmp_lt_i32 s51, 0                                         ; bf048033
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s52, -1, 0                                    ; 983480c1
	s_or_b32 s52, s52, s45                                      ; 8c342d34
	s_cmp_ge_i32 s40, s25                                       ; bf031928
	s_movk_i32 s57, 0x400                                       ; b0390400
	s_cselect_b32 s53, -1, 0                                    ; 983580c1
	s_mov_b32 s54, src_scc                                      ; beb600fd
	s_nor_b32 s52, s52, s53                                     ; 8f343534
	s_min_i32 s55, s37, s40                                     ; 89372825
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cmp_lt_i32 s55, 0                                         ; bf048037
	s_cselect_b32 s56, -1, 0                                    ; 983880c1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s56, s56, s50                                      ; 8c383238
	s_nor_b32 s56, s56, s53                                     ; 8f383538
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_dual_cndmask_b32 v13, 0, v13 :: v_dual_cndmask_b32 v12, 0, v12 ; ca521a80 0d0c1880
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_dual_cndmask_b32 v5, 0, v5 :: v_dual_cndmask_b32 v4, 0, v4 ; ca520a80 05040880
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_cndmask_b32_e64 v14, 0, v14, s49                          ; d501000e 00c61c80
	v_cndmask_b32_e64 v15, 0, v15, s49                          ; d501000f 00c61e80
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_cndmask_b32_e64 v7, 0, v7, s49                            ; d5010007 00c60e80
	v_cndmask_b32_e64 v6, 0, v6, s49                            ; d5010006 00c60c80
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_cndmask_b32_e64 v16, 0, v16, s52                          ; d5010010 00d22080
	v_cndmask_b32_e64 v17, 0, v17, s52                          ; d5010011 00d22280
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_cndmask_b32_e64 v9, 0, v9, s52                            ; d5010009 00d21280
	v_cndmask_b32_e64 v8, 0, v8, s52                            ; d5010008 00d21080
	v_dual_mov_b32 v23, v13 :: v_dual_mov_b32 v22, v12          ; ca10010d 1716010c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cndmask_b32_e64 v19, 0, v19, s56                          ; d5010013 00e22680
	v_cndmask_b32_e64 v18, 0, v18, s56                          ; d5010012 00e22480
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cndmask_b32_e64 v11, 0, v11, s56                          ; d501000b 00e21680
	v_cndmask_b32_e64 v10, 0, v10, s56                          ; d501000a 00e21480
	v_dual_mov_b32 v49, v5 :: v_dual_mov_b32 v48, v4            ; ca100105 31300104
	v_dual_mov_b32 v51, v15 :: v_dual_mov_b32 v50, v14          ; ca10010f 3332010e
	v_dual_mov_b32 v53, v7 :: v_dual_mov_b32 v52, v6            ; ca100107 35340106
	v_dual_mov_b32 v55, v17 :: v_dual_mov_b32 v54, v16          ; ca100111 37360110
	v_dual_mov_b32 v57, v9 :: v_dual_mov_b32 v56, v8            ; ca100109 39380108
	v_dual_mov_b32 v59, v19 :: v_dual_mov_b32 v58, v18          ; ca100113 3b3a0112
	v_dual_mov_b32 v61, v11 :: v_dual_mov_b32 v60, v10          ; ca10010b 3d3c010a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[22:23], 0 ; cc464040 1a022d18
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[26:27], v[22:23], 0 ; cc464060 1a022d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[50:51], 0 ; cc464048 1a026518
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[50:51], 0 ; cc464068 1a02651a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[24:25], v[54:55], 0 ; cc464050 1a026d18
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[54:55], 0 ; cc464070 1a026d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[26:27], v[58:59], 0 ; cc464078 1a02751a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[58:59], 0 ; cc464058 1a027518
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[28:29], v[48:49], v[64:71] ; cc464040 1d02611c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[28:29], v[52:53], v[72:79] ; cc464048 1d22691c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[28:29], v[56:57], v[80:87] ; cc464050 1d42711c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[28:29], v[60:61], v[88:95] ; cc464058 1d62791c
	v_maxmin_num_f32 v62, -4.0, v67, 4.0                        ; d669003e 03da86f7
	v_maxmin_num_f32 v26, -4.0, v65, 4.0                        ; d669001a 03da82f7
	v_maxmin_num_f32 v28, -4.0, v66, 4.0                        ; d669001c 03da84f7
	v_maxmin_num_f32 v24, -4.0, v64, 4.0                        ; d6690018 03da80f7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
	v_fma_mix_f32 v63, 0xab28, |v62|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623f 0bfe7cff 3728ab28
	v_fma_mix_f32 v27, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe34ff 3728ab28
	v_fma_mix_f32 v29, 0xab28, |v28|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621d 0bfe38ff 3728ab28
	v_fma_mix_f32 v25, 0xab28, |v24|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe30ff 3728ab28
	v_dual_fmaak_f32 v63, v63, v62, 0x3f650000 :: v_dual_fmaak_f32 v28, v28, v29, 0x3f650000 ; c8427d3f 3f1c3b1c 3f650000
	v_dual_fmaak_f32 v27, v27, v26, 0x3f650000 :: v_dual_fmaak_f32 v24, v24, v25, 0x3f650000 ; c842351b 1b183318 3f650000
	v_maxmin_num_f32 v128, -4.0, v71, 4.0                       ; d6690080 03da8ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_dual_mul_f32 v67, v67, v63 :: v_dual_mul_f32 v66, v66, v28 ; c8c67f43 43423942
	v_dual_mul_f32 v65, v65, v27 :: v_dual_mul_f32 v64, v64, v24 ; c8c63741 41403140
	v_maxmin_num_f32 v130, -4.0, v72, 4.0                       ; d6690082 03da90f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_maxmin_num_f32 v64, -4.0, v68, 4.0                        ; d6690040 03da88f7
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_maxmin_num_f32 v66, -4.0, v69, 4.0                        ; d6690042 03da8af7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_maxmin_num_f32 v132, -4.0, v73, 4.0                       ; d6690084 03da92f7
	v_maxmin_num_f32 v134, -4.0, v74, 4.0                       ; d6690086 03da94f7
	v_fma_mix_f32 v65, 0xab28, |v64|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe80ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v75, 4.0                       ; d6690088 03da96f7
	v_fma_mix_f32 v67, 0xab28, |v66|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206243 0bfe84ff 3728ab28
	v_maxmin_num_f32 v138, -4.0, v76, 4.0                       ; d669008a 03da98f7
	v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 ; c8430782 82810181 3f650000
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_fmaak_f32 v67, v67, v66, 0x3f650000 :: v_dual_fmaak_f32 v64, v64, v65, 0x3f650000 ; c8428543 43408340 3f650000
	v_maxmin_num_f32 v140, -4.0, v77, 4.0                       ; d669008c 03da9af7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_dual_mul_f32 v72, v72, v130 :: v_dual_mul_f32 v71, v71, v129 ; c8c70548 48470347
	v_maxmin_num_f32 v142, -4.0, v78, 4.0                       ; d669008e 03da9cf7
	v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 ; c8430f86 86850985 3f650000
	v_dual_mul_f32 v69, v69, v67 :: v_dual_mul_f32 v68, v68, v64 ; c8c68745 45448144
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v79, 4.0                       ; d6690090 03da9ef7
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 ; c843178a 8a891189 3f650000
	v_maxmin_num_f32 v146, -4.0, v80, 4.0                       ; d6690092 03daa0f7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_dual_mul_f32 v74, v74, v134 :: v_dual_mul_f32 v73, v73, v133 ; c8c70d4a 4a490b49
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_maxmin_num_f32 v68, -4.0, v70, 4.0                        ; d6690044 03da8cf7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_maxmin_num_f32 v148, -4.0, v81, 4.0                       ; d6690094 03daa2f7
	v_dual_mul_f32 v76, v76, v138 :: v_dual_mul_f32 v75, v75, v137 ; c8c7154c 4c4b134b
	v_maxmin_num_f32 v150, -4.0, v82, 4.0                       ; d6690096 03daa4f7
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 ; c8431f8e 8e8d198d 3f650000
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	v_fma_mix_f32 v69, 0xab28, |v68|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206245 0bfe88ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v83, 4.0                       ; d6690098 03daa6f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_maxmin_num_f32 v154, -4.0, v84, 4.0                       ; d669009a 03daa8f7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 ; c8432792 92912191 3f650000
	v_dual_mul_f32 v78, v78, v142 :: v_dual_mul_f32 v77, v77, v141 ; c8c71d4e 4e4d1b4d
	v_fmaak_f32 v68, v68, v69, 0x3f650000                       ; 5a888b44 3f650000
	v_maxmin_num_f32 v156, -4.0, v85, 4.0                       ; d669009c 03daaaf7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v158, -4.0, v86, 4.0                       ; d669009e 03daacf7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c8432f96 96952995 3f650000
	v_dual_mul_f32 v80, v80, v146 :: v_dual_mul_f32 v79, v79, v145 ; c8c72550 504f234f
	v_maxmin_num_f32 v160, -4.0, v87, 4.0                       ; d66900a0 03daaef7
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	v_mul_f32_e32 v70, v70, v68                                 ; 108c8946
	v_maxmin_num_f32 v162, -4.0, v88, 4.0                       ; d66900a2 03dab0f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 ; c843379a 9a993199 3f650000
	v_dual_mul_f32 v82, v82, v150 :: v_dual_mul_f32 v81, v81, v149 ; c8c72d52 52512b51
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_maxmin_num_f32 v164, -4.0, v89, 4.0                       ; d66900a4 03dab2f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v90, 4.0                       ; d66900a6 03dab4f7
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c8433f9e 9e9d399d 3f650000
	v_dual_mul_f32 v84, v84, v154 :: v_dual_mul_f32 v83, v83, v153 ; c8c73554 54533353
	v_maxmin_num_f32 v168, -4.0, v91, 4.0                       ; d66900a8 03dab6f7
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v170, -4.0, v92, 4.0                       ; d66900aa 03dab8f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v172, -4.0, v93, 4.0                       ; d66900ac 03dabaf7
	v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 ; c84347a2 a2a141a1 3f650000
	v_dual_mul_f32 v86, v86, v158 :: v_dual_mul_f32 v85, v85, v157 ; c8c73d56 56553b55
	v_maxmin_num_f32 v174, -4.0, v94, 4.0                       ; d66900ae 03dabcf7
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v95, 4.0                       ; d66900b0 03dabef7
	v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 ; c8434fa6 a6a549a5 3f650000
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_mul_f32 v88, v88, v162 :: v_dual_mul_f32 v87, v87, v161 ; c8c74558 58574357
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[30:31], v[48:49], v[96:103] ; cc464060 1d82611e
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 ; c84357aa aaa951a9 3f650000
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_dual_mul_f32 v90, v90, v166 :: v_dual_mul_f32 v89, v89, v165 ; c8c74d5a 5a594b59
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 ; c8435fae aead59ad 3f650000
	v_dual_mul_f32 v92, v92, v170 :: v_dual_mul_f32 v91, v91, v169 ; c8c7555c 5c5b535b
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[30:31], v[52:53], v[104:111] ; cc464068 1da2691e
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v182, -4.0, v98, 4.0                       ; d66900b6 03dac4f7
	v_maxmin_num_f32 v180, -4.0, v97, 4.0                       ; d66900b4 03dac2f7
	v_maxmin_num_f32 v178, -4.0, v96, 4.0                       ; d66900b2 03dac0f7
	v_dual_mul_f32 v94, v94, v174 :: v_dual_mul_f32 v93, v93, v173 ; c8c75d5e 5e5d5b5d
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[56:57], v[112:119] ; cc464070 1dc2711e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[30:31], v[60:61], v[120:127] ; cc464078 1de2791e
	v_maxmin_num_f32 v184, -4.0, v99, 4.0                       ; d66900b8 03dac6f7
	v_maxmin_num_f32 v186, -4.0, v100, 4.0                      ; d66900ba 03dac8f7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v188, -4.0, v101, 4.0                      ; d66900bc 03dacaf7
	v_maxmin_num_f32 v190, -4.0, v102, 4.0                      ; d66900be 03daccf7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 ; c8436fb6 b6b569b5 3f650000
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 ; c84367b2 b2b161b1 3f650000
	v_maxmin_num_f32 v65, -4.0, v104, 4.0                       ; d6690041 03dad0f7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_maxmin_num_f32 v67, -4.0, v105, 4.0                       ; d6690043 03dad2f7
	v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 ; c84377ba bab971b9 3f650000
	v_dual_mul_f32 v98, v98, v182 :: v_dual_mul_f32 v97, v97, v181 ; c8c76d62 62616b61
	v_dual_mul_f32 v96, v96, v178 :: v_dual_mul_f32 v95, v95, v177 ; c8c76560 605f635f
	v_fma_mix_f32 v66, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206242 0bfe82ff 3728ab28
	v_maxmin_num_f32 v69, -4.0, v106, 4.0                       ; d6690045 03dad4f7
	v_maxmin_num_f32 v71, -4.0, v107, 4.0                       ; d6690047 03dad6f7
	v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 :: v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 ; c8437fbe bebd79bd 3f650000
	v_maxmin_num_f32 v191, -4.0, v103, 4.0                      ; d66900bf 03dacef7
	v_fma_mix_f32 v68, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206244 0bfe86ff 3728ab28
	v_dual_mul_f32 v100, v100, v186 :: v_dual_mul_f32 v99, v99, v185 ; c8c77564 64637363
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v73, -4.0, v108, 4.0                       ; d6690049 03dad8f7
	v_fma_mix_f32 v70, 0xab28, |v69|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206246 0bfe8aff 3728ab28
	v_fma_mix_f32 v72, 0xab28, |v71|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe8eff 3728ab28
	v_maxmin_num_f32 v75, -4.0, v109, 4.0                       ; d669004b 03dadaf7
	v_fma_mix_f32 v64, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206240 0bff7eff 3728ab28
	v_dual_fmaak_f32 v68, v68, v67, 0x3f650000 :: v_dual_fmaak_f32 v65, v65, v66, 0x3f650000 ; c8428744 44408541 3f650000
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v77, -4.0, v110, 4.0                       ; d669004d 03dadcf7
	v_maxmin_num_f32 v79, -4.0, v111, 4.0                       ; d669004f 03dadef7
	v_fma_mix_f32 v74, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe92ff 3728ab28
	v_dual_fmaak_f32 v72, v72, v71, 0x3f650000 :: v_dual_fmaak_f32 v69, v69, v70, 0x3f650000 ; c8428f48 48448d45 3f650000
	v_fma_mix_f32 v76, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624c 0bfe96ff 3728ab28
	v_dual_fmaak_f32 v64, v64, v191, 0x3f650000 :: v_dual_mul_f32 v101, v101, v189 ; c8477f40 40657b65 3f650000
	v_maxmin_num_f32 v81, -4.0, v112, 4.0                       ; d6690051 03dae0f7
	v_dual_mul_f32 v104, v104, v65 :: v_dual_mul_f32 v105, v105, v68 ; c8c68368 68688969
	v_fma_mix_f32 v78, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe9aff 3728ab28
	v_maxmin_num_f32 v83, -4.0, v113, 4.0                       ; d6690053 03dae2f7
	v_fma_mix_f32 v80, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe9eff 3728ab28
	v_dual_mul_f32 v107, v107, v72 :: v_dual_mul_f32 v106, v106, v69 ; c8c6916b 6b6a8b6a
	v_dual_fmaak_f32 v76, v76, v75, 0x3f650000 :: v_dual_fmaak_f32 v73, v73, v74, 0x3f650000 ; c842974c 4c489549 3f650000
	v_dual_mul_f32 v102, v102, v190 :: v_dual_mul_f32 v103, v103, v64 ; c8c77d66 66668167
	v_maxmin_num_f32 v85, -4.0, v114, 4.0                       ; d6690055 03dae4f7
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v87, -4.0, v115, 4.0                       ; d6690057 03dae6f7
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_dual_fmaak_f32 v80, v80, v79, 0x3f650000 :: v_dual_fmaak_f32 v77, v77, v78, 0x3f650000 ; c8429f50 504c9d4d 3f650000
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v89, -4.0, v116, 4.0                       ; d6690059 03dae8f7
	v_dual_mul_f32 v109, v109, v76 :: v_dual_mul_f32 v108, v108, v73 ; c8c6996d 6d6c936c
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v91, -4.0, v117, 4.0                       ; d669005b 03daeaf7
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 ; c842a754 5450a551 3f650000
	v_maxmin_num_f32 v93, -4.0, v118, 4.0                       ; d669005d 03daecf7
	v_dual_mul_f32 v111, v111, v80 :: v_dual_mul_f32 v110, v110, v77 ; c8c6a16f 6f6e9b6e
	v_maxmin_num_f32 v95, -4.0, v119, 4.0                       ; d669005f 03daeef7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v120, 4.0                       ; d6690061 03daf0f7
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af58 5854ad55 3f650000
	v_maxmin_num_f32 v99, -4.0, v121, 4.0                       ; d6690063 03daf2f7
	v_dual_mul_f32 v113, v113, v84 :: v_dual_mul_f32 v112, v112, v81 ; c8c6a971 7170a370
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v122, 4.0                      ; d6690065 03daf4f7
	v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 :: v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 ; c842b75c 5c58b559 3f650000
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v123, 4.0                      ; d6690067 03daf6f7
	v_dual_mul_f32 v115, v115, v88 :: v_dual_mul_f32 v114, v114, v85 ; c8c6b173 7372ab72
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v105, -4.0, v124, 4.0                      ; d6690069 03daf8f7
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_maxmin_num_f32 v107, -4.0, v125, 4.0                      ; d669006b 03dafaf7
	v_dual_mul_f32 v117, v117, v92 :: v_dual_mul_f32 v116, v116, v89 ; c8c6b975 7574b374
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v109, -4.0, v126, 4.0                      ; d669006d 03dafcf7
	v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 :: v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 ; c842c764 6460c561 3f650000
	v_maxmin_num_f32 v111, -4.0, v127, 4.0                      ; d669006f 03dafef7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_mul_f32 v119, v119, v96 :: v_dual_mul_f32 v118, v118, v93 ; c8c6c177 7776bb76
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 :: v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 ; c842cf68 6864cd65 3f650000
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[32:33], v[22:23], 0 ; cc464048 1a022d20
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_dual_mul_f32 v121, v121, v100 :: v_dual_mul_f32 v120, v120, v97 ; c8c6c979 7978c378
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 :: v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 ; c842d76c 6c68d569 3f650000
	v_dual_mul_f32 v123, v123, v104 :: v_dual_mul_f32 v122, v122, v101 ; c8c6d17b 7b7acb7a
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 :: v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 ; c842df70 706cdd6d 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v125, v125, v108 :: v_dual_mul_f32 v124, v124, v105 ; c8c6d97d 7d7cd37c
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[36:37], v[48:49], v[72:79] ; cc464048 1d226124
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[50:51], 0 ; cc464050 1a026520
	v_dual_mul_f32 v127, v127, v112 :: v_dual_mul_f32 v126, v126, v109 ; c8c6e17f 7f7edb7e
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[54:55], 0 ; cc464058 1a026d20
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[58:59], 0 ; cc464060 1a027520
	v_maxmin_num_f32 v113, -4.0, v72, 4.0                       ; d6690071 03da90f7
	v_maxmin_num_f32 v119, -4.0, v75, 4.0                       ; d6690077 03da96f7
	v_maxmin_num_f32 v115, -4.0, v73, 4.0                       ; d6690073 03da92f7
	v_maxmin_num_f32 v117, -4.0, v74, 4.0                       ; d6690075 03da94f7
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[36:37], v[52:53], v[80:87] ; cc464050 1d426924
	v_maxmin_num_f32 v121, -4.0, v76, 4.0                       ; d6690079 03da98f7
	v_maxmin_num_f32 v123, -4.0, v77, 4.0                       ; d669007b 03da9af7
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[36:37], v[56:57], v[88:95] ; cc464058 1d627124
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[36:37], v[60:61], v[96:103] ; cc464060 1d827924
	v_maxmin_num_f32 v125, -4.0, v78, 4.0                       ; d669007d 03da9cf7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v79, 4.0                       ; d669007f 03da9ef7
	v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 :: v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 ; c842e774 7470e571 3f650000
	v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842ef78 7874ed75 3f650000
	v_maxmin_num_f32 v129, -4.0, v80, 4.0                       ; d6690081 03daa0f7
	v_maxmin_num_f32 v131, -4.0, v81, 4.0                       ; d6690083 03daa2f7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 :: v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 ; c842f77c 7c78f579 3f650000
	v_maxmin_num_f32 v133, -4.0, v82, 4.0                       ; d6690085 03daa4f7
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v83, 4.0                       ; d6690087 03daa6f7
	v_dual_mul_f32 v73, v73, v116 :: v_dual_mul_f32 v72, v72, v113 ; c8c6e949 4948e348
	v_dual_mul_f32 v75, v75, v120 :: v_dual_mul_f32 v74, v74, v117 ; c8c6f14b 4b4aeb4a
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_mul_f32 v77, v77, v124 :: v_dual_mul_f32 v76, v76, v121 ; c8c6f94d 4d4cf34c
	v_maxmin_num_f32 v137, -4.0, v84, 4.0                       ; d6690089 03daa8f7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v85, 4.0                       ; d669008b 03daaaf7
	v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842ff80 807cfd7d 3f650000
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 ; c8430784 84810581 3f650000
	v_maxmin_num_f32 v141, -4.0, v86, 4.0                       ; d669008d 03daacf7
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	v_maxmin_num_f32 v143, -4.0, v87, 4.0                       ; d669008f 03daaef7
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_mul_f32 v79, v79, v128 :: v_dual_mul_f32 v78, v78, v125 ; c8c7014f 4f4efb4e
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430f88 88850d85 3f650000
	v_maxmin_num_f32 v145, -4.0, v88, 4.0                       ; d6690091 03dab0f7
	v_maxmin_num_f32 v147, -4.0, v89, 4.0                       ; d6690093 03dab2f7
	v_dual_mul_f32 v81, v81, v132 :: v_dual_mul_f32 v80, v80, v129 ; c8c70951 51510350
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_maxmin_num_f32 v149, -4.0, v90, 4.0                       ; d6690095 03dab4f7
	v_dual_fmaak_f32 v140, v140, v139, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 ; c843178c 8c891589 3f650000
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_maxmin_num_f32 v151, -4.0, v91, 4.0                       ; d6690097 03dab6f7
	v_dual_mul_f32 v83, v83, v136 :: v_dual_mul_f32 v82, v82, v133 ; c8c71153 53530b52
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c8431f90 908d1d8d 3f650000
	v_maxmin_num_f32 v153, -4.0, v92, 4.0                       ; d6690099 03dab8f7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v93, 4.0                       ; d669009b 03dabaf7
	v_dual_mul_f32 v85, v85, v140 :: v_dual_mul_f32 v84, v84, v137 ; c8c71955 55551354
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v157, -4.0, v94, 4.0                       ; d669009d 03dabcf7
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8432794 94912591 3f650000
	v_dual_mul_f32 v87, v87, v144 :: v_dual_mul_f32 v86, v86, v141 ; c8c72157 57571b56
	v_maxmin_num_f32 v159, -4.0, v95, 4.0                       ; d669009f 03dabef7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v161, -4.0, v96, 4.0                       ; d66900a1 03dac0f7
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432f98 98952d95 3f650000
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v97, 4.0                       ; d66900a3 03dac2f7
	v_dual_mul_f32 v89, v89, v148 :: v_dual_mul_f32 v88, v88, v145 ; c8c72959 59592358
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c843379c 9c993599 3f650000
	v_maxmin_num_f32 v165, -4.0, v98, 4.0                       ; d66900a5 03dac4f7
	v_maxmin_num_f32 v167, -4.0, v99, 4.0                       ; d66900a7 03dac6f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_mul_f32 v91, v91, v152 :: v_dual_mul_f32 v90, v90, v149 ; c8c7315b 5b5b2b5a
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v169, -4.0, v100, 4.0                      ; d66900a9 03dac8f7
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c8433fa0 a09d3d9d 3f650000
	v_maxmin_num_f32 v171, -4.0, v101, 4.0                      ; d66900ab 03dacaf7
	v_dual_mul_f32 v93, v93, v156 :: v_dual_mul_f32 v92, v92, v153 ; c8c7395d 5d5d335c
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c84347a4 a4a145a1 3f650000
	v_maxmin_num_f32 v173, -4.0, v102, 4.0                      ; d66900ad 03daccf7
	v_maxmin_num_f32 v175, -4.0, v103, 4.0                      ; d66900af 03dacef7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_mul_f32 v95, v95, v160 :: v_dual_mul_f32 v94, v94, v157 ; c8c7415f 5f5f3b5e
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 ; c8434fa8 a8a54da5 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[34:35], v[22:23], 0 ; cc464050 1a022d22
	v_dual_mul_f32 v97, v97, v164 :: v_dual_mul_f32 v96, v96, v161 ; c8c74961 61614360
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 ; c84357ac aca955a9 3f650000
	v_dual_mul_f32 v99, v99, v168 :: v_dual_mul_f32 v98, v98, v165 ; c8c75163 63634b62
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 ; c8435fb0 b0ad5dad 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v101, v101, v172 :: v_dual_mul_f32 v100, v100, v169 ; c8c75965 65655364
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[38:39], v[48:49], v[80:87] ; cc464050 1d426126
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[34:35], v[50:51], 0 ; cc464058 1a026522
	v_dual_mul_f32 v103, v103, v176 :: v_dual_mul_f32 v102, v102, v173 ; c8c76167 67675b66
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[34:35], v[58:59], 0 ; cc464068 1a027522
	v_maxmin_num_f32 v179, -4.0, v81, 4.0                       ; d66900b3 03daa2f7
	v_maxmin_num_f32 v183, -4.0, v83, 4.0                       ; d66900b7 03daa6f7
	v_maxmin_num_f32 v181, -4.0, v82, 4.0                       ; d66900b5 03daa4f7
	v_maxmin_num_f32 v177, -4.0, v80, 4.0                       ; d66900b1 03daa0f7
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[54:55], 0 ; cc464060 1a026d22
	v_maxmin_num_f32 v185, -4.0, v84, 4.0                       ; d66900b9 03daa8f7
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[38:39], v[52:53], v[88:95] ; cc464058 1d626926
	v_maxmin_num_f32 v187, -4.0, v85, 4.0                       ; d66900bb 03daaaf7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[38:39], v[60:61], v[104:111] ; cc464068 1da27926
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v86, 4.0                       ; d66900bd 03daacf7
	v_maxmin_num_f32 v191, -4.0, v87, 4.0                       ; d66900bf 03daaef7
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[56:57], v[96:103] ; cc464060 1d827126
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c8436fb8 b8b56db5 3f650000
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 ; c84367b4 b4b165b1 3f650000
	v_maxmin_num_f32 v39, -4.0, v88, 4.0                        ; d6690027 03dab0f7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_fma_mix_f32 v38, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206226 0bff7eff 3728ab28
	v_maxmin_num_f32 v75, -4.0, v89, 4.0                        ; d669004b 03dab2f7
	v_maxmin_num_f32 v77, -4.0, v90, 4.0                        ; d669004d 03dab4f7
	v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 ; c84377bc bcb975b9 3f650000
	v_dual_mul_f32 v83, v83, v184 :: v_dual_mul_f32 v82, v82, v181 ; c8c77153 53536b52
	v_maxmin_num_f32 v79, -4.0, v91, 4.0                        ; d669004f 03dab6f7
	v_dual_mul_f32 v81, v81, v180 :: v_dual_mul_f32 v80, v80, v177 ; c8c76951 51516350
	v_fma_mix_f32 v74, 0xab28, |v39|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624a 0bfe4eff 3728ab28
	v_dual_fmaak_f32 v38, v38, v191, 0x3f650000 :: v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 ; c8437f26 26bd7dbd 3f650000
	v_fma_mix_f32 v76, 0xab28, |v75|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624c 0bfe96ff 3728ab28
	v_fma_mix_f32 v78, 0xab28, |v77|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20624e 0bfe9aff 3728ab28
	v_dual_mul_f32 v85, v85, v188 :: v_dual_mul_f32 v84, v84, v185 ; c8c77955 55557354
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v81, -4.0, v92, 4.0                        ; d6690051 03dab8f7
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v83, -4.0, v93, 4.0                        ; d6690053 03dabaf7
	v_fma_mix_f32 v80, 0xab28, |v79|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206250 0bfe9eff 3728ab28
	v_dual_mul_f32 v87, v87, v38 :: v_dual_mul_f32 v86, v86, v189 ; c8c64d57 57577b56
	v_dual_fmaak_f32 v76, v76, v75, 0x3f650000 :: v_dual_fmaak_f32 v39, v39, v74, 0x3f650000 ; c842974c 4c269527 3f650000
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_maxmin_num_f32 v85, -4.0, v94, 4.0                        ; d6690055 03dabcf7
	v_fma_mix_f32 v82, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206252 0bfea2ff 3728ab28
	v_fma_mix_f32 v84, 0xab28, |v83|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfea6ff 3728ab28
	v_dual_fmaak_f32 v80, v80, v79, 0x3f650000 :: v_dual_fmaak_f32 v77, v77, v78, 0x3f650000 ; c8429f50 504c9d4d 3f650000
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v87, -4.0, v95, 4.0                        ; d6690057 03dabef7
	v_dual_mul_f32 v89, v89, v76 :: v_dual_mul_f32 v88, v88, v39 ; c8c69959 59584f58
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_dual_fmaak_f32 v84, v84, v83, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v82, 0x3f650000 ; c842a754 5450a551 3f650000
	v_dual_mul_f32 v91, v91, v80 :: v_dual_mul_f32 v90, v90, v77 ; c8c6a15b 5b5a9b5a
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v89, -4.0, v96, 4.0                        ; d6690059 03dac0f7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_mul_f32 v93, v93, v84 :: v_dual_mul_f32 v92, v92, v81 ; c8c6a95d 5d5ca35c
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v97, 4.0                        ; d669005b 03dac2f7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_fmaak_f32 v88, v88, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af58 5854ad55 3f650000
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v93, -4.0, v98, 4.0                        ; d669005d 03dac4f7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_dual_mul_f32 v95, v95, v88 :: v_dual_mul_f32 v94, v94, v85 ; c8c6b15f 5f5eab5e
	v_dual_fmaak_f32 v89, v89, v90, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842b559 595cb75c 3f650000
	v_maxmin_num_f32 v113, -4.0, v102, 4.0                      ; d6690071 03daccf7
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v99, 4.0                        ; d669005f 03dac6f7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v115, -4.0, v103, 4.0                      ; d6690073 03dacef7
	v_dual_mul_f32 v97, v97, v92 :: v_dual_mul_f32 v96, v96, v89 ; c8c6b961 6160b360
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v117, -4.0, v104, 4.0                      ; d6690075 03dad0f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v100, 4.0                       ; d6690061 03dac8f7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v105, 4.0                      ; d6690077 03dad2f7
	v_maxmin_num_f32 v121, -4.0, v106, 4.0                      ; d6690079 03dad4f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842bf60 605cbd5d 3f650000
	v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842e774 7474ed75 3f650000
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v107, 4.0                      ; d669007b 03dad6f7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v108, 4.0                      ; d669007d 03dad8f7
	v_dual_mul_f32 v99, v99, v96 :: v_dual_mul_f32 v98, v98, v93 ; c8c6c163 6362bb62
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 :: v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 ; c842ef78 7878f579 3f650000
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v109, 4.0                      ; d669007f 03dadaf7
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v101, 4.0                       ; d6690063 03dacaf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v110, 4.0                      ; d6690081 03dadcf7
	v_dual_mul_f32 v106, v106, v121 :: v_dual_mul_f32 v103, v103, v116 ; c8c6f36a 6a66e967
	v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 ; c842f77c 7c7cfd7d 3f650000
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v111, 4.0                      ; d6690083 03dadef7
	v_fma_mix_f32 v112, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfec6ff 3728ab28
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[40:41], v[22:23], 0 ; cc464050 1a022d28
	v_fmaak_f32 v97, v97, v98, 0x3f650000                       ; 5ac2c561 3f650000
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_dual_mul_f32 v108, v108, v125 :: v_dual_mul_f32 v105, v105, v120 ; c8c6fb6c 6c68f169
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_fmaak_f32 v112, v112, v99, 0x3f650000 :: v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 ; c842c770 7070e571 3f650000
	v_mul_f32_e32 v100, v100, v97                               ; 10c8c364
	v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 ; c842ff80 80810581 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_mul_f32 v104, v104, v117 :: v_dual_mul_f32 v101, v101, v112 ; c8c6eb68 6864e165
	v_mul_f32_e32 v102, v102, v113                              ; 10cce366
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[44:45], v[48:49], v[80:87] ; cc464050 1d42612c
	v_dual_mul_f32 v110, v110, v129 :: v_dual_mul_f32 v107, v107, v124 ; c8c7036e 6e6af96b
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[50:51], 0 ; cc464058 1a026528
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[54:55], 0 ; cc464060 1a026d28
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v133, -4.0, v80, 4.0                       ; d6690085 03daa0f7
	v_maxmin_num_f32 v137, -4.0, v82, 4.0                       ; d6690089 03daa4f7
	v_maxmin_num_f32 v135, -4.0, v81, 4.0                       ; d6690087 03daa2f7
	v_maxmin_num_f32 v139, -4.0, v83, 4.0                       ; d669008b 03daa6f7
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[52:53], v[88:95] ; cc464058 1d62692c
	v_maxmin_num_f32 v141, -4.0, v84, 4.0                       ; d669008d 03daa8f7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[56:57], v[96:103] ; cc464060 1d82712c
	v_maxmin_num_f32 v143, -4.0, v85, 4.0                       ; d669008f 03daaaf7
	v_maxmin_num_f32 v145, -4.0, v86, 4.0                       ; d6690091 03daacf7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 ; c8430784 84850d85 3f650000
	v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 :: v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 ; c8430f88 88891589 3f650000
	v_maxmin_num_f32 v147, -4.0, v87, 4.0                       ; d6690093 03daaef7
	v_maxmin_num_f32 v149, -4.0, v88, 4.0                       ; d6690095 03dab0f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_dual_fmaak_f32 v140, v140, v139, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c843178c 8c8d1d8d 3f650000
	v_dual_mul_f32 v80, v80, v133 :: v_dual_mul_f32 v109, v109, v128 ; c8c70b50 506d016d
	v_dual_mul_f32 v82, v82, v137 :: v_dual_mul_f32 v111, v111, v132 ; c8c71352 526f096f
	v_maxmin_num_f32 v151, -4.0, v89, 4.0                       ; d6690097 03dab2f7
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_maxmin_num_f32 v153, -4.0, v90, 4.0                       ; d6690099 03dab4f7
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8431f90 90912591 3f650000
	v_dual_mul_f32 v84, v84, v141 :: v_dual_mul_f32 v81, v81, v136 ; c8c71b54 54511151
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[58:59], 0 ; cc464068 1a027528
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v91, 4.0                       ; d669009b 03dab6f7
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 ; c8432794 94952d95 3f650000
	v_maxmin_num_f32 v157, -4.0, v92, 4.0                       ; d669009d 03dab8f7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_mul_f32 v86, v86, v145 :: v_dual_mul_f32 v83, v83, v140 ; c8c72356 56531953
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_maxmin_num_f32 v159, -4.0, v93, 4.0                       ; d669009f 03dabaf7
	v_maxmin_num_f32 v161, -4.0, v94, 4.0                       ; d66900a1 03dabcf7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_dual_mul_f32 v88, v88, v149 :: v_dual_mul_f32 v85, v85, v144 ; c8c72b58 58552155
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c8432f98 98993599 3f650000
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_maxmin_num_f32 v163, -4.0, v95, 4.0                       ; d66900a3 03dabef7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[60:61], v[104:111] ; cc464068 1da2792c
	v_maxmin_num_f32 v165, -4.0, v96, 4.0                       ; d66900a5 03dac0f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 ; c843379c 9c9d3d9d 3f650000
	v_dual_mul_f32 v90, v90, v153 :: v_dual_mul_f32 v87, v87, v148 ; c8c7335a 5a572957
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v97, 4.0                       ; d66900a7 03dac2f7
	v_maxmin_num_f32 v169, -4.0, v98, 4.0                       ; d66900a9 03dac4f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c8433fa0 a0a145a1 3f650000
	v_maxmin_num_f32 v171, -4.0, v99, 4.0                       ; d66900ab 03dac6f7
	v_dual_mul_f32 v92, v92, v157 :: v_dual_mul_f32 v89, v89, v152 ; c8c73b5c 5c593159
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_maxmin_num_f32 v173, -4.0, v100, 4.0                      ; d66900ad 03dac8f7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 ; c84347a4 a4a54da5 3f650000
	v_maxmin_num_f32 v175, -4.0, v101, 4.0                      ; d66900af 03dacaf7
	v_dual_mul_f32 v94, v94, v161 :: v_dual_mul_f32 v91, v91, v156 ; c8c7435e 5e5b395b
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_maxmin_num_f32 v177, -4.0, v102, 4.0                      ; d66900b1 03daccf7
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 ; c8434fa8 a8a955a9 3f650000
	v_dual_mul_f32 v96, v96, v165 :: v_dual_mul_f32 v93, v93, v160 ; c8c74b60 605d415d
	v_maxmin_num_f32 v179, -4.0, v103, 4.0                      ; d66900b3 03dacef7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_maxmin_num_f32 v181, -4.0, v104, 4.0                      ; d66900b5 03dad0f7
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v183, -4.0, v105, 4.0                      ; d66900b7 03dad2f7
	v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 ; c84357ac acad5dad 3f650000
	v_dual_mul_f32 v98, v98, v169 :: v_dual_mul_f32 v95, v95, v164 ; c8c75362 625f495f
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	buffer_load_b128 v[80:83], v21, s[20:23], null offen offset:3072 ; c405c07c 40802850 000c0015
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v106, 4.0                      ; d66900b9 03dad4f7
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 ; c8435fb0 b0b165b1 3f650000
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	buffer_load_b128 v[88:91], v21, s[20:23], null offen offset:3584 ; c405c07c 40802858 000e0015
	v_dual_mul_f32 v100, v100, v173 :: v_dual_mul_f32 v97, v97, v168 ; c8c75b64 64615161
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v187, -4.0, v107, 4.0                      ; d66900bb 03dad6f7
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c84367b4 b4b56db5 3f650000
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_dual_mul_f32 v102, v102, v177 :: v_dual_mul_f32 v99, v99, v172 ; c8c76366 66635963
	v_maxmin_num_f32 v189, -4.0, v108, 4.0                      ; d66900bd 03dad8f7
	v_maxmin_num_f32 v191, -4.0, v109, 4.0                      ; d66900bf 03dadaf7
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_dual_mul_f32 v104, v104, v181 :: v_dual_mul_f32 v101, v101, v176 ; c8c76b68 68656165
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_mul_f32 v103, v103, v180 ; c8476fb8 b8676967 3f650000
	v_fmaak_f32 v185, v185, v186, 0x3f650000                    ; 5b7375b9 3f650000
	v_maxmin_num_f32 v86, -4.0, v110, 4.0                       ; d6690056 03dadcf7
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v92, -4.0, v111, 4.0                       ; d669005c 03dadef7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_fma_mix_f32 v21, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bff7eff 3728ab28
	v_fmaak_f32 v188, v188, v187, 0x3f650000                    ; 5b7977bc 3f650000
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_mul_f32 v105, v105, v184 :: v_dual_mul_f32 v106, v106, v185 ; c8c77169 696b736a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[22:23], 0 ; cc464060 1a022d2a
	v_fma_mix_f32 v87, 0xab28, |v86|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206257 0bfeacff 3728ab28
	v_fma_mix_f32 v93, 0xab28, |v92|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625d 0bfeb8ff 3728ab28
	v_fmaak_f32 v189, v189, v190, 0x3f650000                    ; 5b7b7dbd 3f650000
	v_mul_f32_e32 v107, v107, v188                              ; 10d7796b
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v93, v93, v92, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v87, 0x3f650000 ; c842b95d 5d56af56 3f650000
	v_dual_fmaak_f32 v21, v21, v191, 0x3f650000 :: v_dual_mul_f32 v108, v108, v189 ; c8477f15 156d7b6c 3f650000
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[48:49], v[96:103] ; cc464060 1d82612e
	v_dual_mul_f32 v111, v111, v93 :: v_dual_mul_f32 v110, v110, v86 ; c8c6bb6f 6f6ead6e
	v_mul_f32_e32 v109, v109, v21                               ; 10da2b6d
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[54:55], 0 ; cc464070 1a026d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[42:43], v[58:59], 0 ; cc464078 1a02752a
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[50:51], 0 ; cc464068 1a02652a
	v_maxmin_num_f32 v128, -4.0, v97, 4.0                       ; d6690080 03dac2f7
	v_maxmin_num_f32 v94, -4.0, v96, 4.0                        ; d669005e 03dac0f7
	v_maxmin_num_f32 v132, -4.0, v99, 4.0                       ; d6690084 03dac6f7
	v_maxmin_num_f32 v130, -4.0, v98, 4.0                       ; d6690082 03dac4f7
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[56:57], v[112:119] ; cc464070 1dc2712e
	v_maxmin_num_f32 v134, -4.0, v100, 4.0                      ; d6690086 03dac8f7
	v_maxmin_num_f32 v136, -4.0, v101, 4.0                      ; d6690088 03dacaf7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[46:47], v[60:61], v[120:127] ; cc464078 1de2792e
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v95, 0xab28, |v94|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625f 0bfebcff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[52:53], v[104:111] ; cc464068 1da2692e
	v_maxmin_num_f32 v138, -4.0, v102, 4.0                      ; d669008a 03daccf7
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_maxmin_num_f32 v140, -4.0, v103, 4.0                      ; d669008c 03dacef7
	v_dual_fmaak_f32 v129, v129, v128, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v95, 0x3f650000 ; c8430181 815ebf5e 3f650000
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 ; c8430985 85830782 3f650000
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_dual_fmaak_f32 v137, v137, v136, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v135, 0x3f650000 ; c8431189 89870f86 3f650000
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_dual_mul_f32 v97, v97, v129 :: v_dual_mul_f32 v96, v96, v94 ; c8c70361 6160bd60
	v_dual_mul_f32 v99, v99, v133 :: v_dual_mul_f32 v98, v98, v130 ; c8c70b63 63630562
	v_maxmin_num_f32 v148, -4.0, v107, 4.0                      ; d6690094 03dad6f7
	v_maxmin_num_f32 v142, -4.0, v104, 4.0                      ; d669008e 03dad0f7
	v_maxmin_num_f32 v144, -4.0, v105, 4.0                      ; d6690090 03dad2f7
	v_maxmin_num_f32 v146, -4.0, v106, 4.0                      ; d6690092 03dad4f7
	v_dual_mul_f32 v101, v101, v137 :: v_dual_mul_f32 v100, v100, v134 ; c8c71365 65650d64
	v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 ; c843198d 8d8b178a 3f650000
	v_maxmin_num_f32 v150, -4.0, v108, 4.0                      ; d6690096 03dad8f7
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v152, -4.0, v109, 4.0                      ; d6690098 03dadaf7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_mul_f32 v103, v103, v141 :: v_dual_mul_f32 v102, v102, v138 ; c8c71b67 67671566
	v_maxmin_num_f32 v154, -4.0, v110, 4.0                      ; d669009a 03dadcf7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v111, 4.0                      ; d669009c 03dadef7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_fmaak_f32 v142, v142, v143, 0x3f650000 ; c8432191 918f1f8e 3f650000
	v_maxmin_num_f32 v158, -4.0, v112, 4.0                      ; d669009e 03dae0f7
	v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8432995 95932792 3f650000
	v_maxmin_num_f32 v160, -4.0, v113, 4.0                      ; d66900a0 03dae2f7
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v114, 4.0                      ; d66900a2 03dae4f7
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 ; c8433199 99972f96 3f650000
	v_dual_mul_f32 v105, v105, v145 :: v_dual_mul_f32 v104, v104, v142 ; c8c72369 69691d68
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v115, 4.0                      ; d66900a4 03dae6f7
	v_dual_mul_f32 v107, v107, v149 :: v_dual_mul_f32 v106, v106, v146 ; c8c72b6b 6b6b256a
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c843399d 9d9b379a 3f650000
	v_maxmin_num_f32 v166, -4.0, v116, 4.0                      ; d66900a6 03dae8f7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_mul_f32 v109, v109, v153 :: v_dual_mul_f32 v108, v108, v150 ; c8c7336d 6d6d2d6c
	v_maxmin_num_f32 v168, -4.0, v117, 4.0                      ; d66900a8 03daeaf7
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v170, -4.0, v118, 4.0                      ; d66900aa 03daecf7
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c84341a1 a19f3f9e 3f650000
	v_dual_mul_f32 v111, v111, v157 :: v_dual_mul_f32 v110, v110, v154 ; c8c73b6f 6f6f356e
	v_maxmin_num_f32 v172, -4.0, v119, 4.0                      ; d66900ac 03daeef7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v120, 4.0                      ; d66900ae 03daf0f7
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84349a5 a5a347a2 3f650000
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v121, 4.0                      ; d66900b0 03daf2f7
	v_dual_mul_f32 v113, v113, v161 :: v_dual_mul_f32 v112, v112, v158 ; c8c74371 71713d70
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_maxmin_num_f32 v178, -4.0, v122, 4.0                      ; d66900b2 03daf4f7
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84351a9 a9a74fa6 3f650000
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v123, 4.0                      ; d66900b4 03daf6f7
	v_dual_mul_f32 v115, v115, v165 :: v_dual_mul_f32 v114, v114, v162 ; c8c74b73 73734572
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v182, -4.0, v124, 4.0                      ; d66900b6 03daf8f7
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84359ad adab57aa 3f650000
	v_maxmin_num_f32 v184, -4.0, v125, 4.0                      ; d66900b8 03dafaf7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_dual_mul_f32 v117, v117, v169 :: v_dual_mul_f32 v116, v116, v166 ; c8c75375 75754d74
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84361b1 b1af5fae 3f650000
	v_maxmin_num_f32 v186, -4.0, v126, 4.0                      ; d66900ba 03dafcf7
	v_maxmin_num_f32 v188, -4.0, v127, 4.0                      ; d66900bc 03dafef7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_mul_f32 v119, v119, v173 :: v_dual_mul_f32 v118, v118, v170 ; c8c75b77 77775576
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84369b5 b5b367b2 3f650000
	v_dual_mul_f32 v121, v121, v177 :: v_dual_mul_f32 v120, v120, v174 ; c8c76379 79795d78
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84371b9 b9b76fb6 3f650000
	v_dual_mul_f32 v123, v123, v181 :: v_dual_mul_f32 v122, v122, v178 ; c8c76b7b 7b7b657a
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84379bd bdbb77ba 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_dual_mul_f32 v125, v125, v185 :: v_dual_mul_f32 v124, v124, v182 ; c8c7737d 7d7d6d7c
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[80:81], v[54:55], 0 ; cc464070 1a026d50
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[80:81], v[22:23], 0 ; cc464060 1a022d50
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[80:81], v[50:51], 0 ; cc464068 1a026550
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[88:89], v[56:57], v[112:119] ; cc464070 1dc27158
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[88:89], v[48:49], v[96:103] ; cc464060 1d826158
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[88:89], v[52:53], v[104:111] ; cc464068 1da26958
	v_maxmin_num_f32 v190, -4.0, v96, 4.0                       ; d66900be 03dac0f7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_mul_f32 v127, v127, v189 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c8c37b7f 7fbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v97, 4.0                       ; d66900bf 03dac2f7
	v_maxmin_num_f32 v95, -4.0, v100, 4.0                       ; d669005f 03dac8f7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fma_mix_f32 v21, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bff7eff 3728ab28
	v_dual_fmaak_f32 v21, v21, v191, 0x3f650000 :: v_dual_mul_f32 v126, v126, v186 ; c8477f15 157f757e 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c1
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[58:59], 0 ; cc464078 1a027550
	v_maxmin_num_f32 v81, -4.0, v98, 4.0                        ; d6690051 03dac4f7
	v_dual_mul_f32 v97, v97, v21 :: v_dual_mul_f32 v96, v96, v190 ; c8c62b61 61617d60
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v101, 4.0                       ; d6690061 03dacaf7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[88:89], v[60:61], v[120:127] ; cc464078 1de27958
	v_maxmin_num_f32 v89, -4.0, v99, 4.0                        ; d6690059 03dac6f7
	v_fma_mix_f32 v88, 0xab28, |v81|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfea2ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v104, 4.0                      ; d6690081 03dad0f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v94, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfeb2ff 3728ab28
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v131, -4.0, v105, 4.0                      ; d6690083 03dad2f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_dual_fmaak_f32 v94, v94, v89, 0x3f650000 :: v_dual_fmaak_f32 v81, v81, v88, 0x3f650000 ; c842b35e 5e50b151 3f650000
	v_maxmin_num_f32 v133, -4.0, v106, 4.0                      ; d6690085 03dad4f7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_dual_mul_f32 v99, v99, v94 :: v_dual_mul_f32 v98, v98, v81 ; c8c6bd63 6362a362
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v102, 4.0                       ; d6690063 03daccf7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v107, 4.0                      ; d6690087 03dad6f7
	v_dual_fmaak_f32 v133, v133, v134, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 ; c8430d85 85850784 3f650000
	v_maxmin_num_f32 v137, -4.0, v108, 4.0                      ; d6690089 03dad8f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 ; c842c362 625ec15f 3f650000
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_dual_mul_f32 v106, v106, v133 :: v_dual_mul_f32 v105, v105, v132 ; c8c70b6a 6a690969
	v_maxmin_num_f32 v139, -4.0, v109, 4.0                      ; d669008b 03dadaf7
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_maxmin_num_f32 v141, -4.0, v110, 4.0                      ; d669008d 03dadcf7
	v_dual_mul_f32 v101, v101, v98 :: v_dual_mul_f32 v100, v100, v95 ; c8c6c565 6564bf64
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 ; c8431589 89890f88 3f650000
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_maxmin_num_f32 v143, -4.0, v111, 4.0                      ; d669008f 03dadef7
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v101, -4.0, v103, 4.0                      ; d6690065 03dacef7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v145, -4.0, v112, 4.0                      ; d6690091 03dae0f7
	v_dual_mul_f32 v108, v108, v137 :: v_dual_mul_f32 v107, v107, v136 ; c8c7136c 6c6b116b
	v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 :: v_dual_fmaak_f32 v140, v140, v139, 0x3f650000 ; c8431d8d 8d8d178c 3f650000
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_maxmin_num_f32 v147, -4.0, v113, 4.0                      ; d6690093 03dae2f7
	v_maxmin_num_f32 v149, -4.0, v114, 4.0                      ; d6690095 03dae4f7
	v_fma_mix_f32 v128, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfecaff 3728ab28
	v_fmaak_f32 v99, v99, v100, 0x3f650000                      ; 5ac6c963 3f650000
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_dual_mul_f32 v110, v110, v141 :: v_dual_mul_f32 v109, v109, v140 ; c8c71b6e 6e6d196d
	v_maxmin_num_f32 v151, -4.0, v115, 4.0                      ; d6690097 03dae6f7
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_maxmin_num_f32 v153, -4.0, v116, 4.0                      ; d6690099 03dae8f7
	v_dual_fmaak_f32 v128, v128, v101, 0x3f650000 :: v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 ; c842cb80 80810581 3f650000
	v_mul_f32_e32 v102, v102, v99                               ; 10ccc766
	v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 ; c8432591 91911f90 3f650000
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_maxmin_num_f32 v155, -4.0, v117, 4.0                      ; d669009b 03daeaf7
	v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 ; c8432d95 95952794 3f650000
	v_maxmin_num_f32 v157, -4.0, v118, 4.0                      ; d669009d 03daecf7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_mul_f32 v104, v104, v129 :: v_dual_mul_f32 v103, v103, v128 ; c8c70368 68670167
	v_dual_mul_f32 v112, v112, v145 :: v_dual_mul_f32 v111, v111, v144 ; c8c72370 706f216f
	v_maxmin_num_f32 v159, -4.0, v119, 4.0                      ; d669009f 03daeef7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v120, 4.0                      ; d66900a1 03daf0f7
	v_dual_mul_f32 v114, v114, v149 :: v_dual_mul_f32 v113, v113, v148 ; c8c72b72 72712971
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 ; c8433599 99992f98 3f650000
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v163, -4.0, v121, 4.0                      ; d66900a3 03daf2f7
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_lshrrev_b32_e32 v165, 4, v0                               ; 334a0084
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	s_mov_b64 s[60:61], s[16:17]                                ; bebc0110
	s_mov_b64 s[62:63], s[18:19]                                ; bebe0112
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 :: v_dual_lshlrev_b32 v165, 3, v165 ; c86347a4 a4a54a83 3f650000
	v_add_lshl_u32 v166, s9, v165, 2                            ; d64700a6 020b4a09
	buffer_load_b128 v[96:99], v166, s[60:63], null offen       ; c405c07c 40807860 000000a6
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 ; c8433d9d 9d9d379c 3f650000
	v_dual_mul_f32 v116, v116, v153 :: v_dual_mul_f32 v115, v115, v152 ; c8c73374 74733173
	buffer_load_b128 v[104:107], v166, s[60:63], null offen offset:16 ; c405c07c 40807868 000010a6
	v_maxmin_num_f32 v167, -4.0, v122, 4.0                      ; d66900a7 03daf4f7
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 ; c84345a1 a1a13fa0 3f650000
	v_maxmin_num_f32 v169, -4.0, v123, 4.0                      ; d66900a9 03daf6f7
	v_maxmin_num_f32 v171, -4.0, v124, 4.0                      ; d66900ab 03daf8f7
	v_dual_mul_f32 v118, v118, v157 :: v_dual_mul_f32 v117, v117, v156 ; c8c73b76 76753975
	v_maxmin_num_f32 v173, -4.0, v125, 4.0                      ; d66900ad 03dafaf7
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v175, -4.0, v126, 4.0                      ; d66900af 03dafcf7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_mul_f32 v120, v120, v161 :: v_dual_mul_f32 v119, v119, v160 ; c8c74378 78774177
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v177, -4.0, v127, 4.0                      ; d66900b1 03dafef7
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_fmaak_f32 v167, v167, v168, 0x3f650000                    ; 5b4f51a7 3f650000
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[22:23], 0 ; cc464070 1a022d52
	v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 :: v_dual_mul_f32 v121, v121, v164 ; c84753aa aa794979 3f650000
	v_fmaak_f32 v171, v171, v172, 0x3f650000                    ; 5b5759ab 3f650000
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v173, 0x3f650000 ; c84361af afaf5bae 3f650000
	v_mul_f32_e32 v122, v122, v167                              ; 10f54f7a
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v123, v123, v170 :: v_dual_mul_f32 v124, v124, v171 ; c8c7557b 7b7d577c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v125, v125, v174 :: v_dual_mul_f32 v126, v126, v175 ; c8c75d7d 7d7f5f7e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[54:55], 0 ; cc464080 1a026d52
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[90:91], v[48:49], v[112:119] ; cc464070 1dc2615a
(invalid instruction)                                        ; d7694064
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[82:83], v[58:59], 0 ; cc464088 1a027552
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[90:91], v[56:57], v[128:135] ; cc464080 1e02715a
	v_maxmin_num_f32 v185, -4.0, v115, 4.0                      ; d66900b9 03dae6f7
	v_maxmin_num_f32 v183, -4.0, v114, 4.0                      ; d66900b7 03dae4f7
	v_maxmin_num_f32 v181, -4.0, v113, 4.0                      ; d66900b5 03dae2f7
	v_maxmin_num_f32 v179, -4.0, v112, 4.0                      ; d66900b3 03dae0f7
	v_maxmin_num_f32 v187, -4.0, v116, 4.0                      ; d66900bb 03dae8f7
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[90:91], v[60:61], v[136:143] ; cc464088 1e22795a
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v189, s5, v20, 2                             ; d64700bd 020a2805
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_fmaak_f32 v179, v179, v180, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v177, 0x3f650000 ; c84369b3 b3b363b2 3f650000
	v_dual_mul_f32 v112, v112, v179 :: v_dual_mul_f32 v127, v127, v178 ; c8c76770 707f657f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[82:83], v[50:51], 0 ; cc464078 1a026552
	buffer_load_b128 v[48:51], v189, s[20:23], null offen       ; c405c07c 40802830 000000bd
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v117, 4.0                      ; d66900be 03daeaf7
	v_dual_fmaak_f32 v183, v183, v184, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v181, 0x3f650000 ; c84371b7 b7b76bb6 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84379bb bbbb73ba 3f650000
	buffer_load_b128 v[56:59], v189, s[20:23], null offen offset:512 ; c405c07c 40802838 000200bd
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_mul_f32 v114, v114, v183 :: v_dual_mul_f32 v113, v113, v182 ; c8c76f72 72716d71
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[90:91], v[52:53], v[120:127] ; cc464078 1de2695a
	v_maxmin_num_f32 v52, -4.0, v119, 4.0                       ; d6690034 03daeef7
	v_dual_mul_f32 v116, v116, v187 :: v_dual_mul_f32 v115, v115, v186 ; c8c77774 74737573
	buffer_load_b128 v[108:111], v189, s[20:23], null offen offset:1024 ; c405c07c 4080286c 000400bd
	v_fmaak_f32 v191, v191, v190, 0x3f650000                    ; 5b7f7dbf 3f650000
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_fma_mix_f32 v53, 0xab28, |v52|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206235 0bfe68ff 3728ab28
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
	v_mul_f32_e32 v117, v117, v191                              ; 10eb7f75
	v_maxmin_num_f32 v54, -4.0, v120, 4.0                       ; d6690036 03daf0f7
	v_fmaak_f32 v53, v53, v52, 0x3f650000                       ; 5a6a6935 3f650000
	v_maxmin_num_f32 v60, -4.0, v121, 4.0                       ; d669003c 03daf2f7
	v_fma_mix_f32 v55, 0xab28, |v54|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206237 0bfe6cff 3728ab28
	v_mul_f32_e32 v119, v119, v53                               ; 10ee6b77
	v_maxmin_num_f32 v191, -4.0, v118, 4.0                      ; d66900bf 03daecf7
	v_fma_mix_f32 v61, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623d 0bfe78ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_fmaak_f32 v54, v54, v55, 0x3f650000                       ; 5a6c6f36 3f650000
	v_dual_mul_f32 v120, v120, v54 :: v_dual_fmaak_f32 v61, v61, v60, 0x3f650000 ; c8c26d78 783c793d 3f650000
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[52:55], v189, s[20:23], null offen offset:1536 ; c405c07c 40802834 000600bd
	buffer_load_b128 v[112:115], v189, s[20:23], null offen offset:2048 ; c405c07c 40802870 000800bd
	v_maxmin_num_f32 v82, -4.0, v122, 4.0                       ; d6690052 03daf4f7
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_fma_mix_f32 v21, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206215 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v191, v191, v21, 0x3f650000                     ; 5b7e2bbf 3f650000
	v_mul_f32_e32 v118, v118, v191                              ; 10ed7f76
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[116:119], v189, s[20:23], null offen offset:2560 ; c405c07c 40802874 000a00bd
	buffer_load_b128 v[144:147], v189, s[20:23], null offen offset:3072 ; c405c07c 40802890 000c00bd
	v_maxmin_num_f32 v90, -4.0, v123, 4.0                       ; d669005a 03daf6f7
	v_maxmin_num_f32 v102, -4.0, v124, 4.0                      ; d6690066 03daf8f7
	v_fma_mix_f32 v83, 0xab28, |v82|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206253 0bfea4ff 3728ab28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_fma_mix_f32 v91, 0xab28, |v90|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625b 0bfeb4ff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_fmaak_f32 v82, v82, v83, 0x3f650000                       ; 5aa4a752 3f650000
	v_fmaak_f32 v91, v91, v90, 0x3f650000                       ; 5ab6b55b 3f650000
	v_fmaak_f32 v102, v102, v103, 0x3f650000                    ; 5acccf66 3f650000
	v_dual_mul_f32 v122, v122, v82 :: v_dual_mul_f32 v121, v121, v61 ; c8c6a57a 7a787b79
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_mul_f32_e32 v123, v123, v91                               ; 10f6b77b
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v120, -4.0, v125, 4.0                      ; d6690078 03dafaf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v122, -4.0, v126, 4.0                      ; d669007a 03dafcf7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_dual_mul_f32 v124, v124, v102 :: v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 ; c8c2cd7c 7c78f179 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_fmaak_f32 v122, v122, v123, 0x3f650000                    ; 5af4f77a 3f650000
	v_dual_mul_f32 v126, v126, v122 :: v_dual_mul_f32 v125, v125, v121 ; c8c6f57e 7e7cf37d
	buffer_load_b128 v[120:123], v189, s[20:23], null offen offset:3584 ; c405c07c 40802878 000e00bd
	v_maxmin_num_f32 v148, -4.0, v129, 4.0                      ; d6690094 03db02f7
	v_maxmin_num_f32 v150, -4.0, v130, 4.0                      ; d6690096 03db04f7
	v_maxmin_num_f32 v152, -4.0, v131, 4.0                      ; d6690098 03db06f7
	v_maxmin_num_f32 v154, -4.0, v132, 4.0                      ; d669009a 03db08f7
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v124, -4.0, v127, 4.0                      ; d669007c 03dafef7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v133, 4.0                      ; d669009c 03db0af7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v125, v125, v124, 0x3f650000                    ; 5afaf97d 3f650000
	v_mul_f32_e32 v127, v127, v125                              ; 10fefb7f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v126, -4.0, v128, 4.0                      ; d669007e 03db00f7
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fmaak_f32 v126, v126, v127, 0x3f650000                    ; 5afcff7e 3f650000
	v_mul_f32_e32 v128, v128, v126                              ; 1100fd80
	v_maxmin_num_f32 v158, -4.0, v134, 4.0                      ; d669009e 03db0cf7
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c8432f96 96952995 3f650000
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 ; c843379a 9a993199 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_mul_f32 v130, v130, v150 :: v_dual_mul_f32 v129, v129, v149 ; c8c72d82 82812b81
	v_dual_mul_f32 v132, v132, v154 :: v_dual_mul_f32 v131, v131, v153 ; c8c73584 84833383
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[124:127], v166, s[60:63], null offen offset:64 ; c405c07c 4080787c 000040a6
	buffer_load_b128 v[128:131], v166, s[60:63], null offen offset:80 ; c405c07c 40807880 000050a6
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v135, 4.0                      ; d66900a0 03db0ef7
	v_maxmin_num_f32 v162, -4.0, v136, 4.0                      ; d66900a2 03db10f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v137, 4.0                      ; d66900a4 03db12f7
	v_maxmin_num_f32 v167, -4.0, v138, 4.0                      ; d66900a7 03db14f7
	v_maxmin_num_f32 v169, -4.0, v139, 4.0                      ; d66900a9 03db16f7
	v_maxmin_num_f32 v171, -4.0, v140, 4.0                      ; d66900ab 03db18f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v173, -4.0, v141, 4.0                      ; d66900ad 03db1af7
	v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c8433f9e 9e9d399d 3f650000
	v_fma_mix_f32 v166, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff48ff 3728ab28
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_maxmin_num_f32 v175, -4.0, v142, 4.0                      ; d66900af 03db1cf7
	v_maxmin_num_f32 v177, -4.0, v143, 4.0                      ; d66900b1 03db1ef7
	v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 ; c84347a2 a2a141a1 3f650000
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_mul_f32 v134, v134, v158 :: v_dual_mul_f32 v133, v133, v157 ; c8c73d86 86853b85
	v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 :: v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 ; c84353aa aaa751a7 3f650000
	v_cvt_pk_f32_fp8_e32 v[102:103], v12                        ; 7eccdd0c
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_dual_fmaak_f32 v166, v166, v164, 0x3f650000 :: v_dual_mul_f32 v135, v135, v161 ; c84749a6 a6874387 3f650000
	v_dual_fmaak_f32 v174, v174, v173, 0x3f650000 :: v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 ; c8435bae aeab59ab 3f650000
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_mul_f32 v138, v138, v167 :: v_dual_mul_f32 v139, v139, v170 ; c8c74f8a 8a8b558b
	v_dual_fmaak_f32 v178, v178, v177, 0x3f650000 :: v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 ; c84363b2 b2af61af 3f650000
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v137, v166, v137 :: v_dual_mul_f32 v136, v136, v162 ; c8c713a6 89894588
	v_dual_mul_f32 v141, v141, v174 :: v_dual_mul_f32 v140, v140, v171 ; c8c75d8d 8d8d578c
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_mul_f32 v143, v143, v178 :: v_dual_mul_f32 v142, v142, v175 ; c8c7658f 8f8f5f8e
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_dual_mul_f32 v136, v102, v96 :: v_dual_mul_f32 v137, v103, v97 ; c8c6c166 8888c367
	v_cvt_pk_f32_fp8_e32 v[102:103], v140                       ; 7eccdd8c
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870144
	v_dual_mul_f32 v139, v103, v99 :: v_dual_mul_f32 v138, v102, v98 ; c8c6c767 8b8ac566
	v_cvt_pk_f32_fp8_e32 v[102:103], v13                        ; 7eccdd0d
	v_cvt_pk_f32_fp8_e32 v[12:13], v141                         ; 7e18dd8d
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_dual_mul_f32 v141, v103, v105 :: v_dual_mul_f32 v140, v102, v104 ; c8c6d367 8d8cd166
	v_dual_mul_f32 v143, v13, v107 :: v_dual_mul_f32 v142, v12, v106 ; c8c6d70d 8f8ed50c
	v_cvt_pk_f32_fp8_e32 v[12:13], v14                          ; 7e18dd0e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v153, v13, v97 :: v_dual_mul_f32 v152, v12, v96 ; c8c6c30d 9998c10c
	v_cvt_pk_f32_fp8_e32 v[12:13], v142                         ; 7e18dd8e
	v_dual_mul_f32 v155, v13, v99 :: v_dual_mul_f32 v154, v12, v98 ; c8c6c70d 9b9ac50c
	v_cvt_pk_f32_fp8_e32 v[12:13], v15                          ; 7e18dd0f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v157, v13, v105 :: v_dual_mul_f32 v156, v12, v104 ; c8c6d30d 9d9cd10c
	v_cvt_pk_f32_fp8_e32 v[12:13], v143                         ; 7e18dd8f
	v_dual_mul_f32 v159, v13, v107 :: v_dual_mul_f32 v158, v12, v106 ; c8c6d70d 9f9ed50c
	v_cvt_pk_f32_fp8_e32 v[12:13], v16                          ; 7e18dd10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v169, v13, v97 :: v_dual_mul_f32 v168, v12, v96 ; c8c6c30d a9a8c10c
	v_cvt_pk_f32_fp8_e32 v[12:13], v144                         ; 7e18dd90
	v_dual_mul_f32 v171, v13, v99 :: v_dual_mul_f32 v170, v12, v98 ; c8c6c70d abaac50c
	v_cvt_pk_f32_fp8_e32 v[12:13], v17                          ; 7e18dd11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v173, v13, v105 :: v_dual_mul_f32 v172, v12, v104 ; c8c6d30d adacd10c
	v_cvt_pk_f32_fp8_e32 v[12:13], v145                         ; 7e18dd91
	v_dual_mul_f32 v175, v13, v107 :: v_dual_mul_f32 v174, v12, v106 ; c8c6d70d afaed50c
	v_cvt_pk_f32_fp8_e32 v[12:13], v18                          ; 7e18dd12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_dual_mul_f32 v177, v13, v97 :: v_dual_mul_f32 v176, v12, v96 ; c8c6c30d b1b0c10c
	v_cvt_pk_f32_fp8_e32 v[12:13], v146                         ; 7e18dd92
	v_dual_mul_f32 v179, v13, v99 :: v_dual_mul_f32 v178, v12, v98 ; c8c6c70d b3b2c50c
	v_cvt_pk_f32_fp8_e32 v[12:13], v19                          ; 7e18dd13
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870119
	v_add_lshl_u32 v184, s6, v20, 2                             ; d64700b8 020a2806
	v_dual_mul_f32 v181, v13, v105 :: v_dual_mul_f32 v180, v12, v104 ; c8c6d30d b5b4d10c
	v_cvt_pk_f32_fp8_e32 v[12:13], v147                         ; 7e18dd93
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v183, v13, v107 :: v_dual_mul_f32 v182, v12, v106 ; c8c6d70d b7b6d50c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[12:15], v184, s[20:23], null offen       ; c405c07c 4080280c 000000b8
	buffer_load_b128 v[16:19], v184, s[20:23], null offen offset:1024 ; c405c07c 40802810 000400b8
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[48:49], v[24:25], v[136:143] ; cc464088 1e223130
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[48:49], v[28:29], v[168:175] ; cc4640a8 1ea23930
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[48:49], v[26:27], v[152:159] ; cc464098 1e623530
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[48:49], v[62:63], v[176:183] ; cc4640b0 1ec27d30
	buffer_load_b128 v[96:99], v184, s[20:23], null offen offset:2048 ; c405c07c 40802860 000800b8
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[56:57], v[30:31], v[136:143] ; cc464088 1e223d38
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[56:57], v[66:67], v[168:175] ; cc4640a8 1ea28538
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[64:65], v[152:159] ; cc464098 1e628138
	buffer_load_b128 v[104:107], v184, s[20:23], null offen offset:512 ; c405c07c 40802868 000200b8
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[56:57], v[68:69], v[176:183] ; cc4640b0 1ec28938
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[32:33], v[136:143] ; cc464088 1e22416c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[108:109], v[70:71], v[168:175] ; cc4640a8 1ea28d6c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[108:109], v[36:37], v[152:159] ; cc464098 1e62496c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[108:109], v[72:73], v[176:183] ; cc4640b0 1ec2916c
	buffer_load_b128 v[132:135], v184, s[20:23], null offen offset:1536 ; c405c07c 40802884 000600b8
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[52:53], v[34:35], v[136:143] ; cc464088 1e224534
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[74:75], v[168:175] ; cc4640a8 1ea29534
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[52:53], v[38:39], v[152:159] ; cc464098 1e624d34
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[52:53], v[76:77], v[176:183] ; cc4640b0 1ec29934
	buffer_load_b128 v[148:151], v184, s[20:23], null offen offset:2560 ; c405c07c 40802894 000a00b8
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[112:113], v[40:41], v[136:143] ; cc464088 1e225170
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[112:113], v[78:79], v[168:175] ; cc4640a8 1ea29d70
	v_cvt_pk_f32_fp8_e32 v[108:109], v4                         ; 7ed8dd04
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[112:113], v[44:45], v[152:159] ; cc464098 1e625970
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[112:113], v[84:85], v[176:183] ; cc4640b0 1ec2a970
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[116:117], v[42:43], v[136:143] ; cc464088 1e225574
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[116:117], v[86:87], v[168:175] ; cc4640a8 1ea2ad74
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[116:117], v[46:47], v[152:159] ; cc464098 1e625d74
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[116:117], v[92:93], v[176:183] ; cc4640b0 1ec2b974
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_dual_mul_f32 v185, v109, v125 :: v_dual_mul_f32 v184, v108, v124 ; c8c6fb6d b9b8f96c
	v_cvt_pk_f32_fp8_e32 v[108:109], v132                       ; 7ed8dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[144:145], v[80:81], v[136:143] ; cc464088 1e22a190
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[144:145], v[94:95], v[168:175] ; cc4640a8 1ea2bd90
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[144:145], v[88:89], v[152:159] ; cc464098 1e62b190
	v_dual_mul_f32 v187, v109, v127 :: v_dual_mul_f32 v186, v108, v126 ; c8c6ff6d bbbafd6c
	v_cvt_pk_f32_fp8_e32 v[108:109], v5                         ; 7ed8dd05
	v_cvt_pk_f32_fp8_e32 v[4:5], v133                           ; 7e08dd85
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[144:145], v[100:101], v[176:183] ; cc4640b0 1ec2c990
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[120:121], v[22:23], v[136:143] ; cc464088 1e222d78
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[120:121], v[82:83], v[168:175] ; cc4640a8 1ea2a578
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_dual_mul_f32 v189, v109, v129 :: v_dual_mul_f32 v188, v108, v128 ; c8c7036d bdbd016c
	v_dual_mul_f32 v191, v5, v131 :: v_dual_mul_f32 v190, v4, v130 ; c8c70705 bfbf0504
	v_cvt_pk_f32_fp8_e32 v[4:5], v6                             ; 7e08dd06
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[120:121], v[60:61], v[152:159] ; cc464098 1e627978
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[120:121], v[90:91], v[176:183] ; cc4640b0 1ec2b578
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_dual_mul_f32 v5, v5, v125 :: v_dual_mul_f32 v4, v4, v124  ; c8c6fb05 0504f904
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_cvt_pk_f32_fp8_e32 v[108:109], v134                       ; 7ed8dd86
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_lshl_b32 s1, s1, 2                                        ; 84018201
	s_buffer_load_b32 s1, s[16:19], s1 offset:0x0               ; f4020048 02000000
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_cvt_pk_f32_fp8_e32 v[112:113], v7                         ; 7ee0dd07
	v_cvt_pk_f32_fp8_e32 v[116:117], v135                       ; 7ee8dd87
	v_cvt_pk_f32_fp8_e32 v[120:121], v8                         ; 7ef0dd08
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694066
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694067
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_cvt_pk_f32_fp8_e32 v[144:145], v136                       ; 7f20dd88
	v_cvt_pk_f32_fp8_e32 v[160:161], v9                         ; 7f40dd09
	v_dual_mul_f32 v109, v109, v127 :: v_dual_mul_f32 v6, v108, v126 ; c8c6ff6d 6d06fd6c
	v_cvt_pk_f32_fp8_e32 v[8:9], v137                           ; 7e10dd89
	v_dual_mul_f32 v113, v113, v129 :: v_dual_mul_f32 v112, v112, v128 ; c8c70371 71710170
	v_dual_mul_f32 v117, v117, v131 :: v_dual_mul_f32 v116, v116, v130 ; c8c70775 75750574
	v_dual_mul_f32 v121, v121, v125 :: v_dual_mul_f32 v120, v120, v124 ; c8c6fb79 7978f978
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[50:51], v[24:25], v[184:191] ; cc4640b8 1ee23132
	v_dual_mul_f32 v145, v145, v127 :: v_dual_mul_f32 v144, v144, v126 ; c8c6ff91 9190fd90
	v_dual_mul_f32 v161, v161, v129 :: v_dual_mul_f32 v160, v160, v128 ; c8c703a1 a1a101a0
	v_dual_mul_f32 v163, v9, v131 :: v_dual_mul_f32 v162, v8, v130 ; c8c70709 a3a30508
	v_cvt_pk_f32_fp8_e32 v[8:9], v10                            ; 7e10dd0a
	v_swap_b32 v120, v156                                       ; 7ef0cb9c
	v_swap_b32 v121, v157                                       ; 7ef2cb9d
	v_swap_b32 v144, v158                                       ; 7f20cb9e
	v_swap_b32 v145, v159                                       ; 7f22cb9f
	v_dual_mul_f32 v9, v9, v125 :: v_dual_mul_f32 v8, v8, v124  ; c8c6fb09 0908f908
	v_cvt_pk_f32_fp8_e32 v[124:125], v138                       ; 7ef8dd8a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[58:59], v[30:31], v[184:191] ; cc4640b8 1ee23d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[50:51], v[28:29], v[156:163] ; cc46409c 1e723932
	v_swap_b32 v9, v113                                         ; 7e12cb71
	v_swap_b32 v8, v112                                         ; 7e10cb70
	v_dual_mul_f32 v125, v125, v127 :: v_dual_mul_f32 v10, v124, v126 ; c8c6ff7d 7d0afd7c
	v_cvt_pk_f32_fp8_e32 v[126:127], v11                        ; 7efcdd0b
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[110:111], v[32:33], v[184:191] ; cc4640b8 1ee2416e
	v_swap_b32 v113, v123                                       ; 7ee2cb7b
	v_swap_b32 v112, v122                                       ; 7ee0cb7a
	v_swap_b32 v10, v116                                        ; 7e14cb74
	v_dual_mul_f32 v127, v127, v129 :: v_dual_mul_f32 v126, v126, v128 ; c8c7037f 7f7f017e
	v_cvt_pk_f32_fp8_e32 v[128:129], v139                       ; 7f00dd8b
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[58:59], v[66:67], v[156:163] ; cc46409c 1e72853a
	v_dual_mov_b32 v11, v117 :: v_dual_mov_b32 v124, v116       ; ca100175 0b7c0174
	v_mul_f32_e32 v129, v129, v131                              ; 11030781
	v_dual_mov_b32 v7, v109 :: v_dual_mul_f32 v128, v128, v130  ; ca06016d 07810580
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[122:129], v[50:51], v[62:63], v[122:129] ; cc46407a 1dea7d32
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[54:55], v[34:35], v[184:191] ; cc4640b8 1ee24536
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[50:51], v[26:27], v[4:11] ; cc464004 1c123532
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[110:111], v[70:71], v[156:163] ; cc46409c 1e728d6e
	v_wmma_f32_16x16x16_fp8_fp8 v[122:129], v[58:59], v[68:69], v[122:129] ; cc46407a 1dea893a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[114:115], v[40:41], v[184:191] ; cc4640b8 1ee25172
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[58:59], v[64:65], v[4:11] ; cc464004 1c12813a
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[54:55], v[74:75], v[156:163] ; cc46409c 1e729536
	v_wmma_f32_16x16x16_fp8_fp8 v[122:129], v[110:111], v[72:73], v[122:129] ; cc46407a 1dea916e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[118:119], v[42:43], v[184:191] ; cc4640b8 1ee25576
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[110:111], v[36:37], v[4:11] ; cc464004 1c12496e
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[114:115], v[78:79], v[156:163] ; cc46409c 1e729d72
	v_wmma_f32_16x16x16_fp8_fp8 v[122:129], v[54:55], v[76:77], v[122:129] ; cc46407a 1dea9936
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[146:147], v[80:81], v[184:191] ; cc4640b8 1ee2a192
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[54:55], v[38:39], v[4:11] ; cc464004 1c124d36
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[118:119], v[86:87], v[156:163] ; cc46409c 1e72ad76
	v_wmma_f32_16x16x16_fp8_fp8 v[122:129], v[114:115], v[84:85], v[122:129] ; cc46407a 1deaa972
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[112:113], v[22:23], v[184:191] ; cc4640b8 1ee22d70
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[12:13], v[48:49], 0 ; cc464020 1a02610c
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[114:115], v[44:45], v[4:11] ; cc464004 1c125972
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[146:147], v[94:95], v[156:163] ; cc46409c 1e72bd92
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[16:17], v[48:49], 0 ; cc464040 1a026110
	v_wmma_f32_16x16x16_fp8_fp8 v[122:129], v[118:119], v[92:93], v[122:129] ; cc46407a 1deab976
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[18:19], v[48:49], 0 ; cc464048 1a026112
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[118:119], v[46:47], v[4:11] ; cc464004 1c125d76
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[14:15], v[48:49], 0 ; cc464028 1a02610e
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[112:113], v[82:83], v[156:163] ; cc46409c 1e72a570
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[96:97], 0 ; cc464050 1a02c130
	v_wmma_f32_16x16x16_fp8_fp8 v[122:129], v[146:147], v[100:101], v[122:129] ; cc46407a 1deac992
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[104:105], v[22:23], v[32:39] ; cc464020 1c822d68
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[132:133], v[22:23], v[64:71] ; cc464040 1d022d84
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[134:135], v[22:23], v[72:79] ; cc464048 1d222d86
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[146:147], v[88:89], v[4:11] ; cc464004 1c12b192
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[106:107], v[22:23], v[40:47] ; cc464028 1ca22d6a
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[22:23], v[148:149], v[80:87] ; cc464050 1d432916
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_wmma_f32_16x16x16_fp8_fp8 v[122:129], v[112:113], v[90:91], v[122:129] ; cc46407a 1deab570
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[98:99], 0 ; cc464058 1a02c530
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[112:113], v[60:61], v[4:11] ; cc464004 1c127970
	v_dual_mul_f32 v30, v75, v75 :: v_dual_mul_f32 v21, v41, v41 ; c8c6974b 1e145329
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[22:23], v[150:151], v[88:95] ; cc464058 1d632d16
	v_dual_mul_f32 v23, v43, v43 :: v_dual_mul_f32 v22, v73, v73 ; c8c6572b 17169349
	v_dual_fmac_f32 v30, v67, v67 :: v_dual_fmac_f32 v21, v33, v33 ; c8008743 1e144321
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                        ; 02020b04
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_fmac_f32 v23, v35, v35 :: v_dual_fmac_f32 v22, v65, v65 ; c8004723 17168341
	s_mov_b32 s58, 0x76543210                                   ; beba00ff 76543210
	s_mov_b32 s59, 0xfedcba98                                   ; bebb00ff fedcba98
	v_dual_fmac_f32 v30, v71, v71 :: v_dual_fmac_f32 v21, v37, v37 ; c8008f47 1e144b25
	s_movk_i32 s64, 0x410                                       ; b0400410
	v_dual_fmac_f32 v23, v39, v39 :: v_dual_fmac_f32 v22, v69, v69 ; c8004f27 17168b45
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v30, v79, v79 :: v_dual_fmac_f32 v21, v45, v45 ; c8009f4f 1e145b2d
	v_dual_fmac_f32 v23, v47, v47 :: v_dual_fmac_f32 v22, v77, v77 ; c8005f2f 17169b4d
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v30, v66, v66 :: v_dual_fmac_f32 v21, v32, v32 ; c8008542 1e144120
	v_dual_fmac_f32 v22, v64, v64 :: v_dual_fmac_f32 v23, v34, v34 ; c8008140 16164522
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v30, v74, v74 :: v_dual_fmac_f32 v21, v40, v40 ; c800954a 1e145128
	v_dual_fmac_f32 v22, v72, v72 :: v_dual_fmac_f32 v23, v42, v42 ; c8009148 1616552a
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v30, v70, v70 :: v_dual_fmac_f32 v21, v36, v36 ; c8008d46 1e144924
	v_dual_fmac_f32 v22, v68, v68 :: v_dual_fmac_f32 v23, v38, v38 ; c8008944 16164d26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v30, v78, v78 :: v_dual_fmac_f32 v21, v44, v44 ; c8009d4e 1e14592c
	v_dual_fmac_f32 v22, v76, v76 :: v_dual_fmac_f32 v23, v46, v46 ; c800994c 16165d2e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v31, 1.0, v21, v23                          ; cc21001f 045e2af2
	v_fma_mixhi_f16 v31, 1.0, v22, v30                          ; cc22001f 047a2cf2
	v_permlanex16_b32 v48, v31, s58, s59 op_sel:[1,1]           ; d65c1830 00ec751f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[48:49]                ; 1a02611f
(invalid instruction)                                        ; cc1c001f
	v_subrev_f32_e32 v0, v31, v64                               ; 0a00811f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v49, v31                                  ; 7e62171f
	v_cvt_f32_f16_e32 v31, v159/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3e179f
	v_rsq_f32_e32 v49, v49                                      ; 7e625d31
	v_rsq_f32_e32 v31, v31                                      ; 7e3e5d1f
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_mul_f32_e32 v49, s1, v49                                  ; 10626201
	v_dual_mul_f32 v67, v67, v31 :: v_dual_mul_f32 v66, v66, v31 ; c8c63f43 43423f42
	v_dual_mul_f32 v69, v69, v31 :: v_dual_mul_f32 v68, v68, v31 ; c8c63f45 45443f44
	v_dual_mul_f32 v65, v65, v31 :: v_dual_mul_f32 v64, v64, v31 ; c8c63f41 41403f40
	v_dual_mul_f32 v71, v71, v31 :: v_dual_mul_f32 v70, v70, v31 ; c8c63f47 47463f46
	v_dual_mul_f32 v37, v37, v49 :: v_dual_mul_f32 v36, v36, v49 ; c8c66325 25246324
	v_dual_mul_f32 v34, v34, v49 :: v_dual_mul_f32 v35, v35, v49 ; c8c66322 22226323
	v_dual_mul_f32 v73, v73, v31 :: v_dual_mul_f32 v72, v72, v31 ; c8c63f49 49483f48
	v_dual_mul_f32 v47, v47, v49 :: v_dual_mul_f32 v46, v46, v49 ; c8c6632f 2f2e632e
	v_dual_mul_f32 v39, v39, v49 :: v_dual_mul_f32 v38, v38, v49 ; c8c66327 27266326
	v_dual_mul_f32 v45, v45, v49 :: v_dual_mul_f32 v44, v44, v49 ; c8c6632d 2d2c632c
	v_dual_mul_f32 v43, v43, v49 :: v_dual_mul_f32 v42, v42, v49 ; c8c6632b 2b2a632a
	v_dual_mul_f32 v41, v41, v49 :: v_dual_mul_f32 v40, v40, v49 ; c8c66329 29286328
	v_dual_mul_f32 v32, v32, v49 :: v_dual_mul_f32 v33, v33, v49 ; c8c66320 20206321
	v_dual_mul_f32 v75, v75, v31 :: v_dual_mul_f32 v74, v74, v31 ; c8c63f4b 4b4a3f4a
	v_dual_mul_f32 v77, v77, v31 :: v_dual_mul_f32 v76, v76, v31 ; c8c63f4d 4d4c3f4c
	v_lshl_add_u32 v50, v2, 5, v1                               ; d6460032 04050b02
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
	v_dual_mul_f32 v79, v79, v31 :: v_dual_mul_f32 v78, v78, v31 ; c8c63f4f 4f4e3f4e
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v50, v[32:33], v[38:39] offset1:2        ; d9380200 00262032
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[52:53], 0 ; cc464028 1a02690c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[14:15], v[52:53], 0 ; cc464040 1a02690e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[16:17], v[52:53], 0 ; cc464048 1a026910
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[52:53], 0 ; cc464050 1a026912
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[96:97], 0 ; cc464058 1a02c134
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[52:53], v[98:99], 0 ; cc464070 1a02c534
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[104:105], v[24:25], v[40:47] ; cc464028 1ca23168
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[106:107], v[24:25], v[64:71] ; cc464040 1d02316a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[132:133], v[24:25], v[72:79] ; cc464048 1d223184
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[134:135], v[24:25], v[80:87] ; cc464050 1d423186
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[24:25], v[148:149], v[88:95] ; cc464058 1d632918
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[150:151], v[112:119] ; cc464070 1dc32d18
	v_dual_mul_f32 v54, v83, v83 :: v_dual_mul_f32 v51, v65, v65 ; c8c6a753 36328341
	v_dual_mul_f32 v53, v67, v67 :: v_dual_mul_f32 v52, v81, v81 ; c8c68743 3534a351
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v54, v75, v75 :: v_dual_fmac_f32 v51, v41, v41 ; c800974b 36325329
	v_dual_fmac_f32 v53, v43, v43 :: v_dual_fmac_f32 v52, v73, v73 ; c800572b 35349349
	v_dual_fmac_f32 v54, v79, v79 :: v_dual_fmac_f32 v51, v45, v45 ; c8009f4f 36325b2d
	v_dual_fmac_f32 v53, v47, v47 :: v_dual_fmac_f32 v52, v77, v77 ; c8005f2f 35349b4d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v54, v87, v87 :: v_dual_fmac_f32 v51, v69, v69 ; c800af57 36328b45
	v_dual_fmac_f32 v53, v71, v71 :: v_dual_fmac_f32 v52, v85, v85 ; c8008f47 3534ab55
	v_dual_fmac_f32 v54, v74, v74 :: v_dual_fmac_f32 v51, v40, v40 ; c800954a 36325128
	v_dual_fmac_f32 v52, v72, v72 :: v_dual_fmac_f32 v53, v42, v42 ; c8009148 3434552a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v54, v82, v82 :: v_dual_fmac_f32 v51, v64, v64 ; c800a552 36328140
	v_dual_fmac_f32 v52, v80, v80 :: v_dual_fmac_f32 v53, v66, v66 ; c800a150 34348542
	v_dual_fmac_f32 v54, v78, v78 :: v_dual_fmac_f32 v51, v44, v44 ; c8009d4e 3632592c
	v_dual_fmac_f32 v52, v76, v76 :: v_dual_fmac_f32 v53, v46, v46 ; c800994c 34345d2e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v54, v86, v86 :: v_dual_fmac_f32 v51, v68, v68 ; c800ad56 36328944
	v_dual_fmac_f32 v52, v84, v84 :: v_dual_fmac_f32 v53, v70, v70 ; c800a954 34348d46
	v_fma_mixlo_f16 v55, 1.0, v51, v53                          ; cc210037 04d666f2
	v_fma_mixhi_f16 v55, 1.0, v52, v54                          ; cc220037 04da68f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v58, v55, s58, s59 op_sel:[1,1]           ; d65c183a 00ec7537
(invalid instruction)                                        ; cc0f0037
	v_min_num_f64_e32 v[1:2], v[55:56], v[58:59]                ; 1a027537
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0037
	v_subrev_f32_e32 v0, v55, v64                               ; 0a008137
	v_cvt_f32_f16_e32 v59, v55                                  ; 7e761737
	v_cvt_f32_f16_e32 v55, v183/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e6e17b7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v59, v59                                      ; 7e765d3b
	v_rsq_f32_e32 v55, v55                                      ; 7e6e5d37
	v_mul_f32_e32 v59, s1, v59                                  ; 10767601
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v73, v73, v55 :: v_dual_mul_f32 v72, v72, v55 ; c8c66f49 49486f48
	v_dual_mul_f32 v77, v77, v55 :: v_dual_mul_f32 v76, v76, v55 ; c8c66f4d 4d4c6f4c
	v_dual_mul_f32 v79, v79, v55 :: v_dual_mul_f32 v78, v78, v55 ; c8c66f4f 4f4e6f4e
	v_dual_mul_f32 v75, v75, v55 :: v_dual_mul_f32 v74, v74, v55 ; c8c66f4b 4b4a6f4a
	v_dual_mul_f32 v81, v81, v55 :: v_dual_mul_f32 v80, v80, v55 ; c8c66f51 51506f50
	v_dual_mul_f32 v65, v65, v59 :: v_dual_mul_f32 v64, v64, v59 ; c8c67741 41407740
	v_dual_mul_f32 v67, v67, v59 :: v_dual_mul_f32 v66, v66, v59 ; c8c67743 43427742
	v_dual_mul_f32 v69, v69, v59 :: v_dual_mul_f32 v68, v68, v59 ; c8c67745 45447744
	v_dual_mul_f32 v71, v71, v59 :: v_dual_mul_f32 v70, v70, v59 ; c8c67747 47467746
	v_dual_mul_f32 v40, v40, v59 :: v_dual_mul_f32 v41, v41, v59 ; c8c67728 28287729
	v_dual_mul_f32 v42, v42, v59 :: v_dual_mul_f32 v43, v43, v59 ; c8c6772a 2a2a772b
	v_dual_mul_f32 v47, v47, v59 :: v_dual_mul_f32 v46, v46, v59 ; c8c6772f 2f2e772e
	v_dual_mul_f32 v44, v44, v59 :: v_dual_mul_f32 v45, v45, v59 ; c8c6772c 2c2c772d
	v_dual_mul_f32 v83, v83, v55 :: v_dual_mul_f32 v82, v82, v55 ; c8c66f53 53526f52
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	v_dual_mul_f32 v85, v85, v55 :: v_dual_mul_f32 v84, v84, v55 ; c8c66f55 55546f54
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v87, v87, v55 :: v_dual_mul_f32 v86, v86, v55 ; c8c66f57 57566f56
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v50, v[32:33], v[42:43] offset0:64 offset1:66 ; d9384240 002a2032
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[14:15], v[56:57], 0 ; cc464048 1a02710e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[18:19], v[56:57], 0 ; cc464058 1a027112
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[12:13], v[56:57], 0 ; cc464040 1a02710c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[16:17], v[56:57], 0 ; cc464050 1a027110
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[56:57], v[96:97], 0 ; cc464070 1a02c138
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[106:107], v[26:27], v[72:79] ; cc464048 1d22356a
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[56:57], v[98:99], 0 ; cc46402a 1a02c538
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[134:135], v[26:27], v[88:95] ; cc464058 1d623586
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[104:105], v[26:27], v[64:71] ; cc464040 1d023568
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[132:133], v[26:27], v[80:87] ; cc464050 1d423584
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[26:27], v[148:149], v[112:119] ; cc464070 1dc3291a
	v_wmma_f32_16x16x16_fp8_fp8 v[42:49], v[26:27], v[150:151], v[42:49] ; cc46402a 1cab2d1a
	v_dual_mul_f32 v63, v91, v91 :: v_dual_mul_f32 v60, v73, v73 ; c8c6b75b 3f3c9349
	v_dual_mul_f32 v62, v75, v75 :: v_dual_mul_f32 v61, v89, v89 ; c8c6974b 3e3cb359
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v63, v83, v83 :: v_dual_fmac_f32 v60, v65, v65 ; c800a753 3f3c8341
	v_dual_fmac_f32 v62, v67, v67 :: v_dual_fmac_f32 v61, v81, v81 ; c8008743 3e3ca351
	v_dual_fmac_f32 v63, v87, v87 :: v_dual_fmac_f32 v60, v69, v69 ; c800af57 3f3c8b45
	v_dual_fmac_f32 v62, v71, v71 :: v_dual_fmac_f32 v61, v85, v85 ; c8008f47 3e3cab55
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v63, v95, v95 :: v_dual_fmac_f32 v60, v77, v77 ; c800bf5f 3f3c9b4d
	v_dual_fmac_f32 v62, v79, v79 :: v_dual_fmac_f32 v61, v93, v93 ; c8009f4f 3e3cbb5d
	v_dual_fmac_f32 v63, v82, v82 :: v_dual_fmac_f32 v60, v64, v64 ; c800a552 3f3c8140
	v_dual_fmac_f32 v61, v80, v80 :: v_dual_fmac_f32 v62, v66, v66 ; c800a150 3d3e8542
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v63, v90, v90 :: v_dual_fmac_f32 v60, v72, v72 ; c800b55a 3f3c9148
	v_dual_fmac_f32 v61, v88, v88 :: v_dual_fmac_f32 v62, v74, v74 ; c800b158 3d3e954a
	v_dual_fmac_f32 v63, v86, v86 :: v_dual_fmac_f32 v60, v68, v68 ; c800ad56 3f3c8944
	v_dual_fmac_f32 v61, v84, v84 :: v_dual_fmac_f32 v62, v70, v70 ; c800a954 3d3e8d46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v63, v94, v94 :: v_dual_fmac_f32 v60, v76, v76 ; c800bd5e 3f3c994c
	v_dual_fmac_f32 v61, v92, v92 :: v_dual_fmac_f32 v62, v78, v78 ; c800b95c 3d3e9d4e
	v_fma_mixlo_f16 v100, 1.0, v60, v62                         ; cc210064 04fa78f2
	v_fma_mixhi_f16 v100, 1.0, v61, v63                         ; cc220064 04fe7af2
	v_lshl_add_u32 v2, v2, 6, s8                                ; d6460002 00210d02
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_permlanex16_b32 v101, v100, s58, s59 op_sel:[1,1]         ; d65c1865 00ec7564
	v_add_lshl_u32 v2, v2, v1, 2                                ; d6470002 020a0302
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[52:55], v2, s[60:63], null offen         ; c405c07c 40807834 00000002
	buffer_load_b128 v[56:59], v2, s[60:63], null offen offset:16 ; c405c07c 40807838 00001002
(invalid instruction)                                        ; cc0f0064
	v_min_num_f64_e32 v[1:2], v[100:101], v[101:102]            ; 1a02cb64
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0064
	v_subrev_f32_e32 v0, v100, v64                              ; 0a008164
	v_cvt_f32_f16_e32 v108, v100                                ; 7ed81764
	v_cvt_f32_f16_e32 v100, v228/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ec817e4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v108, v108                                    ; 7ed85d6c
	v_rsq_f32_e32 v100, v100                                    ; 7ec85d64
	v_mul_f32_e32 v108, s1, v108                                ; 10d8d801
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v85, v85, v100 :: v_dual_mul_f32 v84, v84, v100 ; c8c6c955 5554c954
	v_dual_mul_f32 v83, v83, v100 :: v_dual_mul_f32 v82, v82, v100 ; c8c6c953 5352c952
	v_dual_mul_f32 v87, v87, v100 :: v_dual_mul_f32 v86, v86, v100 ; c8c6c957 5756c956
	v_dual_mul_f32 v81, v81, v100 :: v_dual_mul_f32 v80, v80, v100 ; c8c6c951 5150c950
	v_dual_mul_f32 v65, v65, v108 :: v_dual_mul_f32 v64, v64, v108 ; c8c6d941 4140d940
	v_dual_mul_f32 v75, v75, v108 :: v_dual_mul_f32 v74, v74, v108 ; c8c6d94b 4b4ad94a
	v_dual_mul_f32 v67, v67, v108 :: v_dual_mul_f32 v66, v66, v108 ; c8c6d943 4342d942
	v_dual_mul_f32 v71, v71, v108 :: v_dual_mul_f32 v70, v70, v108 ; c8c6d947 4746d946
	v_dual_mul_f32 v69, v69, v108 :: v_dual_mul_f32 v68, v68, v108 ; c8c6d945 4544d944
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c1
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_dual_mul_f32 v73, v73, v108 :: v_dual_mul_f32 v72, v72, v108 ; c8c6d949 4948d948
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769401b
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v2, s[60:63], null offen offset:4096 ; c405c07c 40807844 00100002
	buffer_load_b128 v[72:75], v2, s[60:63], null offen offset:4112 ; c405c07c 40807848 00101002
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_dual_mul_f32 v77, v77, v108 :: v_dual_mul_f32 v76, v76, v108 ; c8c6d94d 4d4cd94c
	v_dual_mul_f32 v79, v79, v108 :: v_dual_mul_f32 v78, v78, v108 ; c8c6d94f 4f4ed94e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	buffer_load_b128 v[76:79], v2, s[60:63], null offen offset:8192 ; c405c07c 4080784c 00200002
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d769401a
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v89, v89, v100 :: v_dual_mul_f32 v88, v88, v100 ; c8c6c959 5958c958
	v_dual_mul_f32 v91, v91, v100 :: v_dual_mul_f32 v90, v90, v100 ; c8c6c95b 5b5ac95a
	v_dual_mul_f32 v93, v93, v100 :: v_dual_mul_f32 v92, v92, v100 ; c8c6c95d 5d5cc95c
	v_dual_mul_f32 v95, v95, v100 :: v_dual_mul_f32 v94, v94, v100 ; c8c6c95f 5f5ec95e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v50, v[60:61], v[66:67] offset0:128 offset1:130 ; d9388280 00423c32
	buffer_load_b128 v[80:83], v2, s[60:63], null offen offset:8208 ; c405c07c 40807850 00201002
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[12:13], v[102:103], 0 ; cc464058 1a02cd0c
	v_dual_mov_b32 v21, v10 :: v_dual_mov_b32 v12, v50          ; ca10010a 150c0132
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[14:15], v[102:103], 0 ; cc464070 1a02cd0e
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[16:17], v[102:103], 0 ; cc46402c 1a02cd10
	v_dual_mov_b32 v67, v107 :: v_dual_mov_b32 v66, v106        ; ca10016b 4342016a
	v_dual_mov_b32 v85, v99 :: v_dual_mov_b32 v84, v98          ; ca100163 55540162
	v_dual_mov_b32 v87, v103 :: v_dual_mov_b32 v86, v102        ; ca100167 57560166
	v_dual_mov_b32 v61, v12 :: v_dual_mov_b32 v60, v11          ; ca10010c 3d3c010b
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[18:19], v[102:103], 0 ; cc46400a 1a02cd12
	v_dual_mov_b32 v19, v105 :: v_dual_mov_b32 v18, v104        ; ca100169 13120168
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[102:103], v[96:97], 0 ; cc464068 1a02c166
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[86:87], v[84:85], 0 ; cc464060 1a02a956
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[132:133], v[28:29], v[44:51] ; cc46402c 1cb23984
	v_wmma_f32_16x16x16_fp8_fp8 v[10:17], v[134:135], v[28:29], v[10:17] ; cc46400a 1c2a3986
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[84:87], v2, s[60:63], null offen offset:12288 ; c405c07c 40807854 00300002
	buffer_load_b128 v[132:135], v2, s[60:63], null offen offset:12304 ; c405c07c 40807884 00301002
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[66:67], v[28:29], v[112:119] ; cc464070 1dc23942
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[18:19], v[28:29], v[88:95] ; cc464058 1d623912
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[28:29], v[148:149], v[104:111] ; cc464068 1da3291c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[28:29], v[150:151], v[96:103] ; cc464060 1d832d1c
	v_dual_mul_f32 v67, v11, v11 :: v_dual_mul_f32 v66, v113, v113 ; c8c6170b 4342e371
	v_dual_mul_f32 v131, v13, v13 :: v_dual_mul_f32 v130, v115, v115 ; c8c61b0d 8382e773
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmac_f32_e32 v67, v45, v45                                ; 56865b2d
	v_dual_fmac_f32 v131, v47, v47 :: v_dual_fmac_f32 v66, v89, v89 ; c8005f2f 8342b359
	v_dual_fmac_f32 v67, v49, v49 :: v_dual_fmac_f32 v130, v91, v91 ; c8006331 4382b75b
	buffer_load_b128 v[148:151], v2, s[60:63], null offen offset:64 ; c405c07c 40807894 00004002
	v_mov_b32_e32 v147, v165                                    ; 7f2603a5
	buffer_load_b128 v[164:167], v2, s[60:63], null offen offset:80 ; c405c07c 408078a4 00005002
	v_fmac_f32_e32 v130, v95, v95                               ; 5704bf5f
	v_dual_fmac_f32 v67, v15, v15 :: v_dual_fmac_f32 v66, v93, v93 ; c8001f0f 4342bb5d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v131, v51, v51 :: v_dual_fmac_f32 v66, v117, v117 ; c8006733 8342eb75
	v_dual_fmac_f32 v131, v17, v17 :: v_dual_fmac_f32 v130, v119, v119 ; c8002311 8382ef77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v67, v44, v44 :: v_dual_fmac_f32 v130, v90, v90 ; c800592c 4382b55a
	v_dual_fmac_f32 v67, v10, v10 :: v_dual_fmac_f32 v66, v88, v88 ; c800150a 4342b158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v67, v48, v48 :: v_dual_fmac_f32 v130, v114, v114 ; c8006130 4382e572
	v_dual_fmac_f32 v67, v14, v14 :: v_dual_fmac_f32 v66, v112, v112 ; c8001d0e 4342e170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v131, v46, v46 :: v_dual_fmac_f32 v66, v92, v92 ; c8005d2e 8342b95c
	v_dual_fmac_f32 v131, v12, v12 :: v_dual_fmac_f32 v130, v94, v94 ; c800190c 8382bd5e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v131, v50, v50 :: v_dual_fmac_f32 v66, v116, v116 ; c8006532 8342e974
	v_dual_fmac_f32 v131, v16, v16 :: v_dual_fmac_f32 v130, v118, v118 ; c8002110 8382ed76
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v146, 1.0, v66, v130                        ; cc210092 060a84f2
	v_fma_mixhi_f16 v146, 1.0, v67, v131                        ; cc220092 060e86f2
	v_permlanex16_b32 v18, v146, s58, s59 op_sel:[1,1]          ; d65c1812 00ec7592
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0092
	v_min_num_f64_e32 v[1:2], v[146:147], v[18:19]              ; 1a022592
(invalid instruction)                                        ; cc1c0092
	v_subrev_f32_e32 v0, v146, v64                              ; 0a008192
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b0013
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                    ; 02010192
	v_rsq_f32_e32 v19, v19                                      ; 7e265d13
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v19, s1, v19                                  ; 10262601
	v_dual_mul_f32 v91, v91, v19 :: v_dual_mul_f32 v90, v90, v19 ; c8c6275b 5b5a275a
	v_dual_mul_f32 v89, v89, v19 :: v_dual_mul_f32 v88, v88, v19 ; c8c62759 59582758
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	buffer_load_b128 v[88:91], v2, s[60:63], null offen offset:4160 ; c405c07c 40807858 00104002
(invalid instruction)                                        ; d58b0892
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                    ; 02010192
	v_dual_mul_f32 v113, v113, v19 :: v_dual_mul_f32 v112, v112, v19 ; c8c62771 71702770
	v_dual_mul_f32 v95, v95, v19 :: v_dual_mul_f32 v94, v94, v19 ; c8c6275f 5f5e275e
	v_dual_mul_f32 v93, v93, v19 :: v_dual_mul_f32 v92, v92, v19 ; c8c6275d 5d5c275c
	v_dual_mul_f32 v115, v115, v19 :: v_dual_mul_f32 v114, v114, v19 ; c8c62773 73722772
	v_dual_mul_f32 v117, v117, v19 :: v_dual_mul_f32 v116, v116, v19 ; c8c62775 75742774
	v_dual_mul_f32 v119, v119, v19 :: v_dual_mul_f32 v118, v118, v19 ; c8c62777 77762776
	v_rsq_f32_e32 v146, v146                                    ; 7f245d92
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v47, v47, v146 :: v_dual_mul_f32 v46, v46, v146 ; c8c7252f 2f2f252e
	v_dual_mul_f32 v13, v13, v146 :: v_dual_mul_f32 v12, v12, v146 ; c8c7250d 0d0d250c
	v_dual_mul_f32 v17, v17, v146 :: v_dual_mul_f32 v16, v16, v146 ; c8c72511 11112510
	v_dual_mul_f32 v45, v45, v146 :: v_dual_mul_f32 v44, v44, v146 ; c8c7252d 2d2d252c
	v_dual_mul_f32 v49, v49, v146 :: v_dual_mul_f32 v48, v48, v146 ; c8c72531 31312530
	v_dual_mul_f32 v11, v11, v146 :: v_dual_mul_f32 v10, v10, v146 ; c8c7250b 0b0b250a
	v_dual_mul_f32 v15, v15, v146 :: v_dual_mul_f32 v14, v14, v146 ; c8c7250f 0f0f250e
	v_dual_mul_f32 v51, v51, v146 :: v_dual_mul_f32 v50, v50, v146 ; c8c72533 33332532
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                      ; 02021b0c
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v14, v15, vcc_lo                      ; 02021f0e
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v61, v[44:45], v[10:11] offset0:192 offset1:194 ; d938c2c0 000a2c3d
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_load_b64 v[12:13], v61                                   ; d9d80000 0c00003d
	ds_load_b64 v[14:15], v61 offset:16                         ; d9d80010 0e00003d
	v_dual_mov_b32 v51, v21 :: v_dual_mov_b32 v50, v20          ; ca100115 33320114
	s_mov_b32 s65, 0x3d380000                                   ; bec100ff 3d380000
	s_movk_i32 s66, 0x3e47                                      ; b0423e47
	s_movk_i32 s67, 0x3c20                                      ; b0433c20
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[22:23], 0 ; cc464060 1a022d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[24:25], 0 ; cc464068 1a02310c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[12:13], v[26:27], 0 ; cc464070 1a02350c
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v45, v15 :: v_dual_mov_b32 v44, v14          ; ca10010f 2d2c010e
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[12:13], v[28:29], 0 ; cc46400e 1a02390c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[40:41], v[104:111] ; cc464068 1da2512c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[36:37], v[96:103] ; cc464060 1d82492c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[44:45], v[64:65], v[112:119] ; cc464070 1dc2812c
	s_wait_loadcnt 0xa                                          ; bfc0000a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_mixlo_f16 v52, s65, v96, v52                          ; cc210034 04d2c041
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[44:45], v[48:49], v[14:21] ; cc46400e 1c3a612c
	v_fma_mixhi_f16 v52, s65, v97, v53                          ; cc220034 04d6c241
	v_fma_mixlo_f16 v53, s65, v98, v54                          ; cc210035 04dac441
	v_fma_mixhi_f16 v53, s65, v99, v55                          ; cc220035 04dec641
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v54, s65, v100, v56                         ; cc210036 04e2c841
	v_fma_mixhi_f16 v54, s65, v101, v57                         ; cc220036 04e6ca41
	v_dual_mov_b32 v44, v103 :: v_dual_mov_b32 v13, v102        ; ca100167 2c0c0166
	v_dual_mov_b32 v66, v129 :: v_dual_mov_b32 v45, v128        ; ca100181 422c0180
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_mov_b32_e32 v12, v54                                      ; 7e180336
	s_clause 0x4                                                ; bf850004
	buffer_load_b128 v[92:95], v2, s[60:63], null offen offset:4176 ; c405c07c 4080785c 00105002
	buffer_load_b128 v[96:99], v2, s[60:63], null offen offset:8256 ; c405c07c 40807860 00204002
	buffer_load_b128 v[54:57], v2, s[60:63], null offen offset:8272 ; c405c07c 40807836 00205002
	buffer_load_b128 v[100:103], v2, s[60:63], null offen offset:12352 ; c405c07c 40807864 00304002
	buffer_load_b128 v[128:131], v2, s[60:63], null offen offset:12368 ; c405c07c 40807880 00305002
(invalid instruction)                                        ; cc1c0034
	v_subrev_f32_e32 v0, v52, v67                               ; 0a008734
(invalid instruction)                                        ; cc1c0035
	v_subrev_f32_e32 v0, v53, v67                               ; 0a008735
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_fma_mixlo_f16 v68, s65, v104, v68                         ; cc210044 0512d041
	v_fma_mixlo_f16 v67, s65, v13, v58                          ; cc210043 04ea1a41
	v_fma_mixhi_f16 v67, s65, v44, v59                          ; cc220043 04ee5841
	v_fma_mixhi_f16 v68, s65, v105, v69                         ; cc220044 0516d241
	v_fma_mixlo_f16 v69, s65, v106, v70                         ; cc210045 051ad441
	v_fma_mixhi_f16 v69, s65, v107, v71                         ; cc220045 051ed641
(invalid instruction)                                        ; cc1c000c
	v_subrev_f32_e32 v0, v12, v67                               ; 0a00870c
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v70, s65, v108, v72                         ; cc210046 0522d841
	v_fma_mixhi_f16 v70, s65, v109, v73                         ; cc220046 0526da41
(invalid instruction)                                        ; cc1b0034
	v_subrev_f32_e32 v0, v52, v66                               ; 0a008534
	v_fma_mixlo_f16 v71, s65, v110, v74                         ; cc210047 052adc41
(invalid instruction)                                        ; cc1b0035
	v_subrev_f32_e32 v0, v53, v66                               ; 0a008535
	v_fma_mixhi_f16 v71, s65, v111, v75                         ; cc220047 052ede41
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v67                               ; 0a008743
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v72, s65, v112, v76                         ; cc210048 0532e041
(invalid instruction)                                        ; cc1c0044
	v_subrev_f32_e32 v0, v68, v67                               ; 0a008744
	v_fma_mixhi_f16 v72, s65, v113, v77                         ; cc220048 0536e241
(invalid instruction)                                        ; cc1c0045
	v_subrev_f32_e32 v0, v69, v67                               ; 0a008745
	ds_load_b64 v[58:59], v61 offset:512                        ; d9d80200 3a00003d
(invalid instruction)                                        ; cc1b000c
	v_subrev_f32_e32 v0, v12, v66                               ; 0a00850c
	v_fma_mixlo_f16 v73, s65, v114, v78                         ; cc210049 053ae441
(invalid instruction)                                        ; cc1c0046
	v_subrev_f32_e32 v0, v70, v67                               ; 0a008746
	ds_load_b64 v[76:77], v61 offset:528                        ; d9d80210 4c00003d
	v_fma_mixhi_f16 v73, s65, v115, v79                         ; cc220049 053ee641
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mixlo_f16 v74, s65, v116, v80                         ; cc21004a 0542e841
(invalid instruction)                                        ; cc1c0047
	v_subrev_f32_e32 v0, v71, v67                               ; 0a008747
	v_fma_mixhi_f16 v74, s65, v117, v81                         ; cc22004a 0546ea41
(invalid instruction)                                        ; cc1b0043
	v_subrev_f32_e32 v0, v67, v66                               ; 0a008543
(invalid instruction)                                        ; cc1b0044
	v_subrev_f32_e32 v0, v68, v66                               ; 0a008544
(invalid instruction)                                        ; cc1c0048
	v_subrev_f32_e32 v0, v72, v67                               ; 0a008748
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v80, s65, v18, v132                         ; cc210050 06122441
	v_fma_mixhi_f16 v80, s65, v19, v133                         ; cc220050 06162641
(invalid instruction)                                        ; cc1b0045
	v_subrev_f32_e32 v0, v69, v66                               ; 0a008545
	v_fma_mixlo_f16 v81, s65, v20, v134                         ; cc210051 061a2841
(invalid instruction)                                        ; cc1b0046
	v_subrev_f32_e32 v0, v70, v66                               ; 0a008546
	v_fma_mixhi_f16 v81, s65, v21, v135                         ; cc220051 061e2a41
(invalid instruction)                                        ; cc1c0049
	v_subrev_f32_e32 v0, v73, v67                               ; 0a008749
(invalid instruction)                                        ; cc1b0047
	v_subrev_f32_e32 v0, v71, v66                               ; 0a008547
	v_fma_mixlo_f16 v75, s65, v118, v82                         ; cc21004b 054aec41
(invalid instruction)                                        ; cc1c004a
	v_subrev_f32_e32 v0, v74, v67                               ; 0a00874a
	v_fma_mixhi_f16 v75, s65, v119, v83                         ; cc22004b 054eee41
(invalid instruction)                                        ; cc1b0048
	v_subrev_f32_e32 v0, v72, v66                               ; 0a008548
	v_fma_mixlo_f16 v78, s65, v14, v84                          ; cc21004e 05521c41
	v_fma_mixhi_f16 v78, s65, v15, v85                          ; cc22004e 05561e41
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v67                               ; 0a008750
	v_fma_mixlo_f16 v79, s65, v16, v86                          ; cc21004f 055a2041
	v_fma_mixhi_f16 v79, s65, v17, v87                          ; cc22004f 055e2241
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v67                               ; 0a008751
(invalid instruction)                                        ; cc1b0049
	v_subrev_f32_e32 v0, v73, v66                               ; 0a008549
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[58:59], v[22:23], 0 ; cc464068 1a022d3a
(invalid instruction)                                        ; cc1b004a
	v_subrev_f32_e32 v0, v74, v66                               ; 0a00854a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[58:59], v[24:25], 0 ; cc464070 1a02313a
(invalid instruction)                                        ; cc1c004b
	v_subrev_f32_e32 v0, v75, v67                               ; 0a00874b
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[58:59], v[26:27], 0 ; cc46400e 1a02353a
(invalid instruction)                                        ; cc1c004e
	v_subrev_f32_e32 v0, v78, v67                               ; 0a00874e
(invalid instruction)                                        ; cc1b0050
	v_subrev_f32_e32 v0, v80, v66                               ; 0a008550
(invalid instruction)                                        ; cc1c004f
	v_subrev_f32_e32 v0, v79, v67                               ; 0a00874f
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v66                               ; 0a008551
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[76:77], v[36:37], v[104:111] ; cc464068 1da2494c
(invalid instruction)                                        ; cc1b004b
	v_subrev_f32_e32 v0, v75, v66                               ; 0a00854b
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[76:77], v[40:41], v[112:119] ; cc464070 1dc2514c
	v_dual_mov_b32 v44, v81 :: v_dual_mov_b32 v13, v80          ; ca100151 2c0c0150
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[58:59], v[28:29], 0 ; cc464050 1a02393a
	v_wmma_f32_16x16x16_fp8_fp8 v[14:21], v[76:77], v[64:65], v[14:21] ; cc46400e 1c3a814c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[76:77], v[48:49], v[80:87] ; cc464050 1d42614c
	ds_load_b64 v[76:77], v61 offset:1024                       ; d9d80400 4c00003d
(invalid instruction)                                        ; cc1b004e
	v_subrev_f32_e32 v0, v78, v66                               ; 0a00854e
(invalid instruction)                                        ; cc1b004f
	v_subrev_f32_e32 v0, v79, v66                               ; 0a00854f
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v59, s65, v106, v150                        ; cc21003b 065ad441
	v_fma_mixhi_f16 v59, s65, v107, v151                        ; cc22003b 065ed641
	v_fma_mixlo_f16 v58, s65, v104, v148                        ; cc21003a 0652d041
	v_fma_mixhi_f16 v58, s65, v105, v149                        ; cc22003a 0656d241
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v106, s65, v112, v88                        ; cc21006a 0562e041
	v_fma_mixhi_f16 v106, s65, v113, v89                        ; cc22006a 0566e241
	ds_load_b64 v[88:89], v61 offset:1040                       ; d9d80410 5800003d
	v_fma_mixlo_f16 v104, s65, v108, v164                       ; cc210068 0692d841
	v_fma_mixhi_f16 v104, s65, v109, v165                       ; cc220068 0696da41
	v_fma_mixlo_f16 v105, s65, v110, v166                       ; cc210069 069adc41
	v_fma_mixhi_f16 v105, s65, v111, v167                       ; cc220069 069ede41
(invalid instruction)                                        ; cc1c003b
	v_subrev_f32_e32 v0, v59, v67                               ; 0a00873b
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v67                               ; 0a00873a
	v_dual_mov_b32 v134, v147 :: v_dual_mov_b32 v133, v145      ; ca100193 86840191
	v_dual_mov_b32 v166, v13 :: v_dual_mov_b32 v167, v18        ; ca10010d a6a60112
(invalid instruction)                                        ; cc1c006a
	v_subrev_f32_e32 v0, v106, v67                              ; 0a00876a
	v_fma_mixlo_f16 v107, s65, v114, v90                        ; cc21006b 056ae441
	v_fma_mixhi_f16 v107, s65, v115, v91                        ; cc22006b 056ee641
(invalid instruction)                                        ; cc1c0068
	v_subrev_f32_e32 v0, v104, v67                              ; 0a008768
(invalid instruction)                                        ; cc1c0069
	v_subrev_f32_e32 v0, v105, v67                              ; 0a008769
(invalid instruction)                                        ; cc1b003b
	v_subrev_f32_e32 v0, v59, v66                               ; 0a00853b
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v66                               ; 0a00853a
(invalid instruction)                                        ; cc1b006a
	v_subrev_f32_e32 v0, v106, v66                              ; 0a00856a
(invalid instruction)                                        ; cc1c006b
	v_subrev_f32_e32 v0, v107, v67                              ; 0a00876b
(invalid instruction)                                        ; cc1b0068
	v_subrev_f32_e32 v0, v104, v66                              ; 0a008568
(invalid instruction)                                        ; cc1b0069
	v_subrev_f32_e32 v0, v105, v66                              ; 0a008569
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v132, v144 :: v_dual_mov_b32 v111, v89       ; ca100190 846e0159
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[76:77], v[26:27], 0 ; cc464090 1a02354c
	v_mov_b32_e32 v110, v88                                     ; 7edc0358
(invalid instruction)                                        ; cc1b006b
	v_subrev_f32_e32 v0, v107, v66                              ; 0a00856b
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v109, s65, v118, v94                        ; cc21006d 057aec41
	v_fma_mixhi_f16 v109, s65, v119, v95                        ; cc22006d 057eee41
	v_fma_mixlo_f16 v108, s65, v116, v92                        ; cc21006c 0572e841
	v_fma_mixhi_f16 v108, s65, v117, v93                        ; cc22006c 0576ea41
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[76:77], v[22:23], 0 ; cc464070 1a022d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[76:77], v[24:25], 0 ; cc464058 1a02314c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v164, s65, v16, v98                         ; cc2100a4 058a2041
	v_fma_mixhi_f16 v164, s65, v17, v99                         ; cc2200a4 058e2241
	v_fma_mixlo_f16 v135, s65, v14, v96                         ; cc210087 05821c41
	v_dual_mov_b32 v96, v19 :: v_dual_mov_b32 v165, v12         ; ca100113 60a4010c
	v_fma_mixhi_f16 v135, s65, v15, v97                         ; cc220087 05861e41
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[76:77], v[28:29], 0 ; cc46400c 1a02394c
(invalid instruction)                                        ; cc1c006d
	v_subrev_f32_e32 v0, v109, v67                              ; 0a00876d
(invalid instruction)                                        ; cc1c006c
	v_subrev_f32_e32 v0, v108, v67                              ; 0a00876c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[110:111], v[64:65], v[144:151] ; cc464090 1e42816e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v97, s65, v167, v54                         ; cc210061 04db4e41
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[110:111], v[36:37], v[112:119] ; cc464070 1dc2496e
(invalid instruction)                                        ; cc1c00a4
	v_subrev_f32_e32 v0, v164, v67                              ; 0a0087a4
	v_fma_mixhi_f16 v97, s65, v96, v55                          ; cc220061 04dec041
(invalid instruction)                                        ; cc1c0087
	v_subrev_f32_e32 v0, v135, v67                              ; 0a008787
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[110:111], v[40:41], v[88:95] ; cc464058 1d62516e
	v_fma_mixlo_f16 v98, s65, v20, v56                          ; cc210062 04e22841
	v_fma_mixhi_f16 v98, s65, v21, v57                          ; cc220062 04e62a41
(invalid instruction)                                        ; cc1b006d
	v_subrev_f32_e32 v0, v109, v66                              ; 0a00856d
(invalid instruction)                                        ; cc1b006c
	v_subrev_f32_e32 v0, v108, v66                              ; 0a00856c
	v_wmma_f32_16x16x16_fp8_fp8 v[12:19], v[110:111], v[48:49], v[12:19] ; cc46400c 1c32616e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v99, s65, v80, v100                         ; cc210063 0592a041
	v_fma_mixhi_f16 v99, s65, v81, v101                         ; cc220063 0596a241
(invalid instruction)                                        ; cc1b00a4
	v_subrev_f32_e32 v0, v164, v66                              ; 0a0085a4
	v_fma_mixlo_f16 v100, s65, v82, v102                        ; cc210064 059aa441
(invalid instruction)                                        ; cc1c0061
	v_subrev_f32_e32 v0, v97, v67                               ; 0a008761
	v_fma_mixhi_f16 v100, s65, v83, v103                        ; cc220064 059ea641
	v_dual_mov_b32 v21, v79 :: v_dual_mov_b32 v20, v78          ; ca10014f 1514014e
(invalid instruction)                                        ; cc1b0087
	v_subrev_f32_e32 v0, v135, v66                              ; 0a008587
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v101, s65, v84, v128                        ; cc210065 0602a841
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v67                               ; 0a008762
	v_fma_mixhi_f16 v101, s65, v85, v129                        ; cc220065 0606aa41
	v_mov_b32_e32 v96, v86                                      ; 7ec00356
	v_mov_b32_e32 v102, v87                                     ; 7ecc0357
	v_dual_mov_b32 v128, v109 :: v_dual_mov_b32 v103, v108      ; ca10016d 8066016c
	s_clause 0x4                                                ; bf850004
	buffer_load_b128 v[80:83], v2, s[60:63], null offen offset:128 ; c405c07c 40807850 00008002
	buffer_load_b128 v[54:57], v2, s[60:63], null offen offset:144 ; c405c07c 40807836 00009002
	buffer_load_b128 v[76:79], v2, s[60:63], null offen offset:4224 ; c405c07c 4080784c 00108002
	buffer_load_b128 v[84:87], v2, s[60:63], null offen offset:4240 ; c405c07c 40807854 00109002
	buffer_load_b128 v[108:111], v2, s[60:63], null offen offset:8320 ; c405c07c 4080786c 00208002
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v67                               ; 0a008763
(invalid instruction)                                        ; cc1b0061
	v_subrev_f32_e32 v0, v97, v66                               ; 0a008561
(invalid instruction)                                        ; cc1c0064
	v_subrev_f32_e32 v0, v100, v67                              ; 0a008764
(invalid instruction)                                        ; cc1b0062
	v_subrev_f32_e32 v0, v98, v66                               ; 0a008562
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v67                              ; 0a008765
	v_fma_mixlo_f16 v129, s65, v96, v130                        ; cc210081 060ac041
	v_fma_mixhi_f16 v129, s65, v102, v131                       ; cc220081 060ecc41
(invalid instruction)                                        ; cc1b0063
	v_subrev_f32_e32 v0, v99, v66                               ; 0a008563
(invalid instruction)                                        ; cc1b0064
	v_subrev_f32_e32 v0, v100, v66                              ; 0a008564
(invalid instruction)                                        ; cc1b0065
	v_subrev_f32_e32 v0, v101, v66                              ; 0a008565
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
(invalid instruction)                                        ; cc1c0081
	v_subrev_f32_e32 v0, v129, v67                              ; 0a008781
(invalid instruction)                                        ; cc1b0081
	v_subrev_f32_e32 v0, v129, v66                              ; 0a008581
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v167, s65, v116, v54                        ; cc2100a7 04dae841
	v_fma_mixlo_f16 v54, s65, v118, v56                         ; cc210036 04e2ec41
	v_fma_mixhi_f16 v54, s65, v119, v57                         ; cc220036 04e6ee41
	ds_load_b64 v[56:57], v61 offset:1536                       ; d9d80600 3800003d
	v_fma_mixlo_f16 v130, s65, v112, v80                        ; cc210082 0542e041
	v_fma_mixhi_f16 v130, s65, v113, v81                        ; cc220082 0546e241
	v_fma_mixlo_f16 v131, s65, v114, v82                        ; cc210083 054ae441
	v_fma_mixhi_f16 v131, s65, v115, v83                        ; cc220083 054ee641
	v_fma_mixhi_f16 v167, s65, v117, v55                        ; cc2200a7 04deea41
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v55, s65, v88, v76                          ; cc210037 0532b041
	v_fma_mixhi_f16 v55, s65, v89, v77                          ; cc220037 0536b241
	v_dual_mov_b32 v89, v79 :: v_dual_mov_b32 v88, v78          ; ca10014f 5958014e
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[80:83], v2, s[60:63], null offen offset:8336 ; c405c07c 40807850 00209002
	buffer_load_b128 v[112:115], v2, s[60:63], null offen offset:12416 ; c405c07c 40807870 00308002
	buffer_load_b128 v[116:119], v2, s[60:63], null offen offset:12432 ; c405c07c 40807874 00309002
	buffer_load_b128 v[76:79], v2, s[60:63], null offen offset:192 ; c405c07c 4080784c 0000c002
(invalid instruction)                                        ; cc1c0036
	v_subrev_f32_e32 v0, v54, v67                               ; 0a008736
(invalid instruction)                                        ; cc1c0082
	v_subrev_f32_e32 v0, v130, v67                              ; 0a008782
(invalid instruction)                                        ; cc1c0083
	v_subrev_f32_e32 v0, v131, v67                              ; 0a008783
(invalid instruction)                                        ; cc1c00a7
	v_subrev_f32_e32 v0, v167, v67                              ; 0a0087a7
(invalid instruction)                                        ; cc1c0037
	v_subrev_f32_e32 v0, v55, v67                               ; 0a008737
	v_fma_mixlo_f16 v90, s65, v90, v88                          ; cc21005a 0562b441
	v_fma_mixhi_f16 v90, s65, v91, v89                          ; cc22005a 0566b641
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v91, s65, v92, v84                          ; cc21005b 0552b841
	v_fma_mixhi_f16 v91, s65, v93, v85                          ; cc22005b 0556ba41
	v_fma_mixlo_f16 v92, s65, v94, v86                          ; cc21005c 055abc41
	v_fma_mixhi_f16 v92, s65, v95, v87                          ; cc22005c 055ebe41
	ds_load_b64 v[84:85], v61 offset:1552                       ; d9d80610 5400003d
(invalid instruction)                                        ; cc1b0036
	v_subrev_f32_e32 v0, v54, v66                               ; 0a008536
(invalid instruction)                                        ; cc1b0082
	v_subrev_f32_e32 v0, v130, v66                              ; 0a008582
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v93, s65, v144, v108                        ; cc21005d 05b32041
	v_fma_mixhi_f16 v93, s65, v145, v109                        ; cc22005d 05b72241
(invalid instruction)                                        ; cc1b0083
	v_subrev_f32_e32 v0, v131, v66                              ; 0a008583
(invalid instruction)                                        ; cc1b00a7
	v_subrev_f32_e32 v0, v167, v66                              ; 0a0085a7
(invalid instruction)                                        ; cc1b0037
	v_subrev_f32_e32 v0, v55, v66                               ; 0a008537
(invalid instruction)                                        ; cc1c005a
	v_subrev_f32_e32 v0, v90, v67                               ; 0a00875a
	v_fma_mixlo_f16 v94, s65, v146, v110                        ; cc21005e 05bb2441
	v_fma_mixhi_f16 v94, s65, v147, v111                        ; cc22005e 05bf2641
(invalid instruction)                                        ; cc1c005b
	v_subrev_f32_e32 v0, v91, v67                               ; 0a00875b
(invalid instruction)                                        ; cc1c005c
	v_subrev_f32_e32 v0, v92, v67                               ; 0a00875c
(invalid instruction)                                        ; cc1c005d
	v_subrev_f32_e32 v0, v93, v67                               ; 0a00875d
(invalid instruction)                                        ; cc1b005a
	v_subrev_f32_e32 v0, v90, v66                               ; 0a00855a
(invalid instruction)                                        ; cc1c005e
	v_subrev_f32_e32 v0, v94, v67                               ; 0a00875e
(invalid instruction)                                        ; cc1b005b
	v_subrev_f32_e32 v0, v91, v66                               ; 0a00855b
(invalid instruction)                                        ; cc1b005c
	v_subrev_f32_e32 v0, v92, v66                               ; 0a00855c
(invalid instruction)                                        ; cc1b005d
	v_subrev_f32_e32 v0, v93, v66                               ; 0a00855d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b005e
	v_subrev_f32_e32 v0, v94, v66                               ; 0a00855e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v96, s65, v150, v82                         ; cc210060 054b2c41
	v_fma_mixhi_f16 v96, s65, v151, v83                         ; cc220060 054f2e41
	v_fma_mixlo_f16 v95, s65, v148, v80                         ; cc21005f 05432841
	v_fma_mixhi_f16 v95, s65, v149, v81                         ; cc22005f 05472a41
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[56:57], v[22:23], 0 ; cc464090 1a022d38
	s_wait_dscnt 0x0                                            ; bfc60000
	v_dual_mov_b32 v22, v84 :: v_dual_mov_b32 v23, v85          ; ca100154 16160155
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v102, s65, v12, v112                        ; cc210066 05c21841
	v_mov_b32_e32 v12, v107                                     ; 7e18036b
	v_fma_mixhi_f16 v102, s65, v13, v113                        ; cc220066 05c61a41
	v_dual_mov_b32 v88, v21 :: v_dual_mov_b32 v61, v20          ; ca100115 583c0114
	v_fma_mixlo_f16 v108, s65, v14, v114                        ; cc21006c 05ca1c41
	v_fma_mixhi_f16 v14, s65, v15, v115                         ; cc22000e 05ce1e41
(invalid instruction)                                        ; cc1c0060
	v_subrev_f32_e32 v0, v96, v67                               ; 0a008760
(invalid instruction)                                        ; cc1c005f
	v_subrev_f32_e32 v0, v95, v67                               ; 0a00875f
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[56:57], v[26:27], 0 ; cc464050 1a023538
(invalid instruction)                                        ; cc1c0066
	v_subrev_f32_e32 v0, v102, v67                              ; 0a008766
	v_mov_b16_e32 v13.l, v108.l                                 ; 7e1a396c
	v_wmma_f32_16x16x16_fp8_fp8 v[107:114], v[56:57], v[24:25], 0 ; cc46406b 1a023138
	v_mov_b16_e32 v13.h, v14.h                                  ; 7f1a398e
	v_dual_mov_b32 v14, v22 :: v_dual_mov_b32 v15, v23          ; ca100116 0e0e0117
	v_wmma_f32_16x16x16_fp8_fp8 v[20:27], v[56:57], v[28:29], 0 ; cc464014 1a023938
(invalid instruction)                                        ; cc1b0060
	v_subrev_f32_e32 v0, v96, v66                               ; 0a008560
(invalid instruction)                                        ; cc1b005f
	v_subrev_f32_e32 v0, v95, v66                               ; 0a00855f
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v89, s65, v16, v116                         ; cc210059 05d22041
	v_fma_mixhi_f16 v89, s65, v17, v117                         ; cc220059 05d62241
(invalid instruction)                                        ; cc1b0066
	v_subrev_f32_e32 v0, v102, v66                              ; 0a008566
	v_fma_mixlo_f16 v115, s65, v18, v118                        ; cc210073 05da2441
	v_fma_mixhi_f16 v115, s65, v19, v119                        ; cc220073 05de2641
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v67                               ; 0a00870d
	buffer_load_b128 v[16:19], v2, s[60:63], null offen offset:208 ; c405c07c 40807810 0000d002
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[14:15], v[64:65], v[80:87] ; cc464050 1d42810e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[14:15], v[36:37], v[144:151] ; cc464090 1e42490e
	v_wmma_f32_16x16x16_fp8_fp8 v[107:114], v[14:15], v[40:41], v[107:114] ; cc46406b 1dae510e
	v_wmma_f32_16x16x16_fp8_fp8 v[20:27], v[14:15], v[48:49], v[20:27] ; cc464014 1c52610e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_mov_b32_e32 v14, v79                                      ; 7e1c034f
	v_dual_mov_b32 v29, v51 :: v_dual_mov_b32 v28, v50          ; ca100133 1d1c0132
(invalid instruction)                                        ; cc1c0059
	v_subrev_f32_e32 v0, v89, v67                               ; 0a008759
	v_mov_b32_e32 v15, v147                                     ; 7e1e0393
(invalid instruction)                                        ; cc1c0073
	v_subrev_f32_e32 v0, v115, v67                              ; 0a008773
	v_fma_mixlo_f16 v116, s65, v144, v76                        ; cc210074 05332041
	v_fma_mixhi_f16 v116, s65, v145, v77                        ; cc220074 05372241
	v_fma_mixlo_f16 v117, s65, v146, v78                        ; cc210075 053b2441
	v_dual_mov_b32 v37, v59 :: v_dual_mov_b32 v36, v58          ; ca10013b 2524013a
	v_dual_mov_b32 v41, v67 :: v_dual_mov_b32 v40, v66          ; ca100143 29280142
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v66                               ; 0a00850d
	v_fma_mixhi_f16 v117, s65, v15, v14                         ; cc220075 043a1e41
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_mov_b32_e32 v119, v13                                     ; 7eee030d
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v118, s65, v148, v16                        ; cc210076 04432841
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[76:79], v2, s[60:63], null offen offset:4288 ; c405c07c 4080784c 0010c002
	buffer_load_b128 v[144:147], v2, s[60:63], null offen offset:4304 ; c405c07c 40807890 0010d002
	buffer_load_b128 v[48:51], v2, s[60:63], null offen offset:8384 ; c405c07c 40807830 0020c002
	buffer_load_b128 v[56:59], v2, s[60:63], null offen offset:8400 ; c405c07c 40807838 0020d002
	buffer_load_b128 v[64:67], v2, s[60:63], null offen offset:12480 ; c405c07c 40807840 0030c002
	buffer_load_b128 v[13:16], v2, s[60:63], null offen offset:12496 ; c405c07c 4080780d 0030d002
(invalid instruction)                                        ; cc1b0059
	v_subrev_f32_e32 v0, v89, v66                               ; 0a008559
(invalid instruction)                                        ; cc1b0073
	v_subrev_f32_e32 v0, v115, v66                              ; 0a008573
(invalid instruction)                                        ; cc1c0074
	v_subrev_f32_e32 v0, v116, v67                              ; 0a008774
(invalid instruction)                                        ; cc1c0075
	v_subrev_f32_e32 v0, v117, v67                              ; 0a008775
	v_fma_mixhi_f16 v118, s65, v149, v17                        ; cc220076 04472a41
	v_fma_mixlo_f16 v148, s65, v150, v18                        ; cc210094 044b2c41
	v_fma_mixhi_f16 v148, s65, v151, v19                        ; cc220094 044f2e41
	s_mov_b32 s68, 0x7ff88000                                   ; bec400ff 7ff88000
(invalid instruction)                                        ; cc1b0074
	v_subrev_f32_e32 v0, v116, v66                              ; 0a008574
(invalid instruction)                                        ; cc1b0075
	v_subrev_f32_e32 v0, v117, v66                              ; 0a008575
	v_lshl_add_u32 v37, v37, 5, s68                             ; d6460025 01110b25
	v_lshl_add_u32 v131, v131, 5, s68                           ; d6460083 01110b83
	v_lshl_add_u32 v52, v52, 5, s68                             ; d6460034 01110b34
	v_lshl_add_u32 v36, v36, 5, s68                             ; d6460024 01110b24
(invalid instruction)                                        ; cc1c0076
	v_subrev_f32_e32 v0, v118, v67                              ; 0a008776
	v_lshl_add_u32 v53, v53, 5, s68                             ; d6460035 01110b35
	v_lshl_add_u32 v130, v130, 5, s68                           ; d6460082 01110b82
(invalid instruction)                                        ; cc1c0094
	v_subrev_f32_e32 v0, v148, v67                              ; 0a008794
	v_lshl_add_u32 v165, v165, 5, s68                           ; d64600a5 01110ba5
	v_lshl_add_u32 v116, v116, 5, s68                           ; d6460074 01110b74
	v_lshl_add_u32 v104, v104, 5, s68                           ; d6460068 01110b68
	v_lshl_add_u32 v117, v117, 5, s68                           ; d6460075 01110b75
	v_lshl_add_u32 v167, v167, 5, s68                           ; d64600a7 01110ba7
(invalid instruction)                                        ; cc0f0095
	v_min_num_f64_e32 v[1:2], v[52:53], v[36:37]                ; 1a024934
	v_lshl_add_u32 v41, v41, 5, s68                             ; d6460029 01110b29
(invalid instruction)                                        ; cc1b0076
	v_subrev_f32_e32 v0, v118, v66                              ; 0a008576
(invalid instruction)                                        ; cc0f0096
	v_min_num_f64_e32 v[1:2], v[53:54], v[37:38]                ; 1a024b35
	v_lshl_add_u32 v105, v105, 5, s68                           ; d6460069 01110b69
(invalid instruction)                                        ; cc1b0094
	v_subrev_f32_e32 v0, v148, v66                              ; 0a008594
	v_lshl_add_u32 v54, v54, 5, s68                             ; d6460036 01110b36
(invalid instruction)                                        ; cc0f0097
	v_min_num_f64_e32 v[1:2], v[165:166], v[104:105]            ; 1a02d1a5
(invalid instruction)                                        ; cc0f0095
	v_min_num_f64_e32 v[1:2], v[149:150], v[130:131]            ; 1a030595
	v_lshl_add_u32 v118, v118, 5, s68                           ; d6460076 01110b76
(invalid instruction)                                        ; cc0f0096
	v_min_num_f64_e32 v[1:2], v[150:151], v[131:132]            ; 1a030796
(invalid instruction)                                        ; cc0f0002
	v_min_num_f64_e32 v[1:2], v[41:42], v[105:106]              ; 1a02d329
	v_lshl_add_u32 v148, v148, 5, s68                           ; d6460094 01110b94
(invalid instruction)                                        ; cc0f0097
	v_min_num_f64_e32 v[1:2], v[151:152], v[167:168]            ; 1a034f97
(invalid instruction)                                        ; cc0f0095
	v_min_num_f64_e32 v[1:2], v[149:150], v[116:117]            ; 1a02e995
(invalid instruction)                                        ; cc0f0096
	v_min_num_f64_e32 v[1:2], v[150:151], v[117:118]            ; 1a02eb96
(invalid instruction)                                        ; cc0f0002
	v_min_num_f64_e32 v[1:2], v[2:3], v[54:55]                  ; 1a026d02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f0097
	v_min_num_f64_e32 v[1:2], v[151:152], v[118:119]            ; 1a02ed97
(invalid instruction)                                        ; cc0f0095
	v_min_num_f64_e32 v[1:2], v[149:150], v[150:151]            ; 1a032d95
(invalid instruction)                                        ; cc0f0002
	v_min_num_f64_e32 v[1:2], v[2:3], v[148:149]                ; 1a032902
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f0095
	v_min_num_f64_e32 v[1:2], v[149:150], v[151:152]            ; 1a032f95
(invalid instruction)                                        ; cc0f0095
	v_min_num_f64_e32 v[1:2], v[149:150], v[2:3]                ; 1a020595
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v17, v149, s58, s59 op_sel:[1,1]          ; d65c1811 00ec7595
(invalid instruction)                                        ; cc0f0095
	v_min_num_f64_e32 v[1:2], v[149:150], v[17:18]              ; 1a022395
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5321012
	v_cndmask_b32_e32 v1, v149, v149, vcc_lo                    ; 02032b95
	v_max_num_f16_e32 v18, s57, v18                             ; 62242439
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v19, v18                                  ; 7e261712
	v_rcp_f32_e32 v19, v19                                      ; 7e265513
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v151, v53, v19, neg(0) op_sel_hi:[1,0,0]      ; cc200097 8a022735
	v_fma_mix_f32 v17, v41, v19, neg(0) op_sel_hi:[1,0,0]       ; cc200011 8a022729
	v_fma_mix_f32 v149, v52, v19, neg(0) op_sel_hi:[1,0,0]      ; cc200095 8a022734
	v_fma_mix_f32 v2, v165, v19, neg(0) op_sel_hi:[1,0,0]       ; cc200002 8a0227a5
	v_fma_mix_f32 v53, v53, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200835 8a022735
	v_fma_mix_f32 v41, v41, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200829 8a022729
	v_fma_mix_f32 v18, v36, v19, neg(0) op_sel_hi:[1,0,0]       ; cc200012 8a022724
	v_fma_mix_f32 v165, v165, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a0227a5
	v_fma_mix_f32 v52, v52, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200834 8a022734
	v_fma_mix_f32 v36, v36, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200824 8a022724
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690096
	v_cndmask_b32_e32 v1, v149, v52, vcc_lo                     ; 02026995
(invalid instruction)                                        ; d7694096
	v_cndmask_b32_e32 v1, v151, v53, vcc_lo                     ; 02026b97
(invalid instruction)                                        ; d7690097
	v_cndmask_b32_e32 v1, v2, v165, vcc_lo                      ; 02034b02
(invalid instruction)                                        ; d7694097
	v_cndmask_b32_e32 v1, v17, v41, vcc_lo                      ; 02025311
	v_fma_mix_f32 v41, v105, v19, neg(0) op_sel_hi:[1,0,0]      ; cc200029 8a022769
	v_fma_mix_f32 v105, v105, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200869 8a022769
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v18, v36, vcc_lo                      ; 02024912
	v_fma_mix_f32 v36, v37, v19, neg(0) op_sel_hi:[1,0,0]       ; cc200024 8a022725
	v_fma_mix_f32 v37, v37, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200825 8a022725
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
	v_fma_mix_f32 v37, v104, v19, neg(0) op_sel_hi:[1,0,0]      ; cc200025 8a022768
	v_fma_mix_f32 v104, v104, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200868 8a022768
	v_fma_mix_f32 v149, v116, v19, neg(0) op_sel_hi:[1,0,0]     ; cc200095 8a022774
	v_fma_mix_f32 v116, v116, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200874 8a022774
	v_fma_mix_f32 v165, v117, v19, neg(0) op_sel_hi:[1,0,0]     ; cc2000a5 8a022775
	v_fma_mix_f32 v117, v117, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200875 8a022775
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v37, v104, vcc_lo                     ; 0202d125
	v_fma_mix_f32 v104, v130, v19, neg(0) op_sel_hi:[1,0,0]     ; cc200068 8a022782
	v_fma_mix_f32 v130, v130, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200882 8a022782
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v41, v105, vcc_lo                     ; 0202d329
	v_fma_mix_f32 v105, v131, v19, neg(0) op_sel_hi:[1,0,0]     ; cc200069 8a022783
	v_fma_mix_f32 v131, v131, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200883 8a022783
	v_fma_mix_f32 v2, v148, v19, neg(0) op_sel_hi:[1,0,0]       ; cc200002 8a022794
	v_fma_mix_f32 v148, v148, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200894 8a022794
	v_lshl_add_u32 v68, v68, 5, s68                             ; d6460044 01110b44
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v104, v130, vcc_lo                    ; 02030568
	v_fma_mix_f32 v130, v167, v19, neg(0) op_sel_hi:[1,0,0]     ; cc200082 8a0227a7
	v_fma_mix_f32 v167, v167, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a7 8a0227a7
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v149, v116, vcc_lo                    ; 0202e995
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v165, v117, vcc_lo                    ; 0202eba5
	v_lshl_add_u32 v106, v106, 5, s68                           ; d646006a 01110b6a
	v_lshl_add_u32 v55, v55, 5, s68                             ; d6460037 01110b37
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v105, v131, vcc_lo                    ; 02030769
	v_fma_mix_f32 v131, v54, v19, neg(0) op_sel_hi:[1,0,0]      ; cc200083 8a022736
	v_fma_mix_f32 v54, v54, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200836 8a022736
	v_lshl_add_u32 v69, v69, 5, s68                             ; d6460045 01110b45
	v_lshl_add_u32 v12, v12, 5, s68                             ; d646000c 01110b0c
	v_lshl_add_u32 v90, v90, 5, s68                             ; d646005a 01110b5a
	v_lshl_add_u32 v70, v70, 5, s68                             ; d6460046 01110b46
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v130, v167, vcc_lo                    ; 02034f82
	v_fma_mix_f32 v167, v118, v19, neg(0) op_sel_hi:[1,0,0]     ; cc2000a7 8a022776
	v_fma_mix_f32 v118, v118, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200876 8a022776
	v_lshl_add_u32 v103, v103, 5, s68                           ; d6460067 01110b67
	v_lshl_add_u32 v91, v91, 5, s68                             ; d646005b 01110b5b
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[68:69], v[106:107]              ; 1a02d544
	v_lshl_add_u32 v71, v71, 5, s68                             ; d6460047 01110b47
	v_lshl_add_u32 v128, v128, 5, s68                           ; d6460080 01110b80
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v131, v54, vcc_lo                     ; 02026d83
	v_lshl_add_u32 v92, v92, 5, s68                             ; d646005c 01110b5c
(invalid instruction)                                        ; cc0f0012
	v_min_num_f64_e32 v[1:2], v[69:70], v[12:13]                ; 1a021945
	v_lshl_add_u32 v72, v72, 5, s68                             ; d6460048 01110b48
	v_lshl_add_u32 v135, v135, 5, s68                           ; d6460087 01110b87
	v_lshl_add_u32 v93, v93, 5, s68                             ; d646005d 01110b5d
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v167, v118, vcc_lo                    ; 0202eda7
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v2, v148, vcc_lo                      ; 02032902
(invalid instruction)                                        ; cc0f0013
	v_min_num_f64_e32 v[1:2], v[70:71], v[103:104]              ; 1a02cf46
	v_lshl_add_u32 v73, v73, 5, s68                             ; d6460049 01110b49
	v_lshl_add_u32 v164, v164, 5, s68                           ; d64600a4 01110ba4
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[55:56]                ; 1a026f11
	v_lshl_add_u32 v94, v94, 5, s68                             ; d646005e 01110b5e
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[71:72], v[128:129]              ; 1a030147
	v_lshl_add_u32 v74, v74, 5, s68                             ; d646004a 01110b4a
	v_lshl_add_u32 v97, v97, 5, s68                             ; d6460061 01110b61
(invalid instruction)                                        ; cc0f0012
	v_min_num_f64_e32 v[1:2], v[18:19], v[90:91]                ; 1a02b512
	v_lshl_add_u32 v95, v95, 5, s68                             ; d646005f 01110b5f
(invalid instruction)                                        ; cc0f0036
	v_min_num_f64_e32 v[1:2], v[72:73], v[135:136]              ; 1a030f48
	v_lshl_add_u32 v75, v75, 5, s68                             ; d646004b 01110b4b
	v_lshl_add_u32 v98, v98, 5, s68                             ; d6460062 01110b62
(invalid instruction)                                        ; cc0f0013
	v_min_num_f64_e32 v[1:2], v[19:20], v[91:92]                ; 1a02b713
	v_lshl_add_u32 v96, v96, 5, s68                             ; d6460060 01110b60
(invalid instruction)                                        ; cc0f0074
	v_min_num_f64_e32 v[1:2], v[73:74], v[164:165]              ; 1a034949
	v_lshl_add_u32 v61, v61, 5, s68                             ; d646003d 01110b3d
	v_lshl_add_u32 v99, v99, 5, s68                             ; d6460063 01110b63
	v_lshl_add_u32 v102, v102, 5, s68                           ; d6460066 01110b66
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[41:42], v[92:93]                ; 1a02b929
(invalid instruction)                                        ; cc0f0075
	v_min_num_f64_e32 v[1:2], v[74:75], v[97:98]                ; 1a02c34a
	v_lshl_add_u32 v88, v88, 5, s68                             ; d6460058 01110b58
	v_lshl_add_u32 v100, v100, 5, s68                           ; d6460064 01110b64
	v_lshl_add_u32 v119, v119, 5, s68                           ; d6460077 01110b77
(invalid instruction)                                        ; cc0f0036
	v_min_num_f64_e32 v[1:2], v[54:55], v[93:94]                ; 1a02bb36
	v_lshl_add_u32 v166, v166, 5, s68                           ; d64600a6 01110ba6
(invalid instruction)                                        ; cc0f0076
	v_min_num_f64_e32 v[1:2], v[75:76], v[98:99]                ; 1a02c54b
	v_lshl_add_u32 v101, v101, 5, s68                           ; d6460065 01110b65
	v_lshl_add_u32 v89, v89, 5, s68                             ; d6460059 01110b59
(invalid instruction)                                        ; cc0f0074
	v_min_num_f64_e32 v[1:2], v[116:117], v[94:95]              ; 1a02bd74
(invalid instruction)                                        ; cc0f0082
	v_min_num_f64_e32 v[1:2], v[61:62], v[99:100]               ; 1a02c73d
	v_lshl_add_u32 v44, v44, 5, s68                             ; d646002c 01110b2c
	v_lshl_add_u32 v129, v129, 5, s68                           ; d6460081 01110b81
	v_lshl_add_u32 v115, v115, 5, s68                           ; d6460073 01110b73
(invalid instruction)                                        ; cc0f0075
	v_min_num_f64_e32 v[1:2], v[117:118], v[95:96]              ; 1a02bf75
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[88:89], v[100:101]              ; 1a02c958
(invalid instruction)                                        ; cc0f0076
	v_min_num_f64_e32 v[1:2], v[118:119], v[96:97]              ; 1a02c176
(invalid instruction)                                        ; cc0f0094
	v_min_num_f64_e32 v[1:2], v[166:167], v[101:102]            ; 1a02cba6
(invalid instruction)                                        ; cc0f0082
	v_min_num_f64_e32 v[1:2], v[130:131], v[102:103]            ; 1a02cd82
(invalid instruction)                                        ; cc0f0095
	v_min_num_f64_e32 v[1:2], v[44:45], v[129:130]              ; 1a03032c
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[131:132], v[119:120]            ; 1a02ef83
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc0f0094
	v_min_num_f64_e32 v[1:2], v[148:149], v[89:90]              ; 1a02b394
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v165, s65, v107, v76                        ; cc2100a5 0532d641
	v_fma_mixlo_f16 v167, s65, v109, v78                        ; cc2100a7 053ada41
	v_fma_mixhi_f16 v167, s65, v110, v79                        ; cc2200a7 053edc41
	v_fma_mixhi_f16 v165, s65, v108, v77                        ; cc2200a5 0536d841
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v2, s65, v111, v144                         ; cc210002 0642de41
	v_fma_mixlo_f16 v76, s65, v113, v146                        ; cc21004c 064ae241
	v_fma_mixhi_f16 v76, s65, v114, v147                        ; cc22004c 064ee441
	v_fma_mixhi_f16 v2, s65, v112, v145                         ; cc220002 0646e041
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v77, s65, v80, v48                          ; cc21004d 04c2a041
	v_fma_mixhi_f16 v77, s65, v81, v49                          ; cc22004d 04c6a241
	v_fma_mixlo_f16 v78, s65, v82, v50                          ; cc21004e 04caa441
	v_fma_mixhi_f16 v78, s65, v83, v51                          ; cc22004e 04cea641
(invalid instruction)                                        ; cc1c00a7
	v_subrev_f32_e32 v0, v167, v67                              ; 0a0087a7
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v79, s65, v84, v56                          ; cc21004f 04e2a841
(invalid instruction)                                        ; cc1c00a5
	v_subrev_f32_e32 v0, v165, v67                              ; 0a0087a5
	v_fma_mixhi_f16 v79, s65, v85, v57                          ; cc22004f 04e6aa41
(invalid instruction)                                        ; cc1c004c
	v_subrev_f32_e32 v0, v76, v67                               ; 0a00874c
(invalid instruction)                                        ; cc1c0002
	v_subrev_f32_e32 v0, v2, v67                                ; 0a008702
	v_fma_mixlo_f16 v80, s65, v86, v58                          ; cc210050 04eaac41
	v_fma_mixhi_f16 v80, s65, v87, v59                          ; cc220050 04eeae41
(invalid instruction)                                        ; cc1c004d
	v_subrev_f32_e32 v0, v77, v67                               ; 0a00874d
(invalid instruction)                                        ; cc1c004e
	v_subrev_f32_e32 v0, v78, v67                               ; 0a00874e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v81, s65, v20, v64                          ; cc210051 05022841
(invalid instruction)                                        ; cc1b00a7
	v_subrev_f32_e32 v0, v167, v66                              ; 0a0085a7
	v_fma_mixhi_f16 v81, s65, v21, v65                          ; cc220051 05062a41
(invalid instruction)                                        ; cc1b00a5
	v_subrev_f32_e32 v0, v165, v66                              ; 0a0085a5
(invalid instruction)                                        ; cc1c004f
	v_subrev_f32_e32 v0, v79, v67                               ; 0a00874f
	v_fma_mixlo_f16 v82, s65, v22, v66                          ; cc210052 050a2c41
	v_fma_mixhi_f16 v82, s65, v23, v67                          ; cc220052 050e2e41
(invalid instruction)                                        ; cc1b004c
	v_subrev_f32_e32 v0, v76, v66                               ; 0a00854c
(invalid instruction)                                        ; cc1b0002
	v_subrev_f32_e32 v0, v2, v66                                ; 0a008502
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v83, s65, v24, v13                          ; cc210053 04363041
(invalid instruction)                                        ; cc1c0050
	v_subrev_f32_e32 v0, v80, v67                               ; 0a008750
	v_fma_mixhi_f16 v83, s65, v25, v14                          ; cc220053 043a3241
(invalid instruction)                                        ; cc1b004d
	v_subrev_f32_e32 v0, v77, v66                               ; 0a00854d
(invalid instruction)                                        ; cc1b004e
	v_subrev_f32_e32 v0, v78, v66                               ; 0a00854e
	v_fma_mixlo_f16 v84, s65, v26, v15                          ; cc210054 043e3441
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v67                               ; 0a008751
	v_fma_mixhi_f16 v84, s65, v27, v16                          ; cc220054 04423641
(invalid instruction)                                        ; cc1b004f
	v_subrev_f32_e32 v0, v79, v66                               ; 0a00854f
	v_lshl_add_u32 v165, v165, 5, s68                           ; d64600a5 01110ba5
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v67                               ; 0a008752
	v_lshl_add_u32 v167, v167, 5, s68                           ; d64600a7 01110ba7
	v_lshl_add_u32 v2, v2, 5, s68                               ; d6460002 01110b02
(invalid instruction)                                        ; cc1b0050
	v_subrev_f32_e32 v0, v80, v66                               ; 0a008550
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v67                               ; 0a008753
	v_lshl_add_u32 v76, v76, 5, s68                             ; d646004c 01110b4c
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v66                               ; 0a008551
(invalid instruction)                                        ; cc1c0054
	v_subrev_f32_e32 v0, v84, v67                               ; 0a008754
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[165:166]              ; 1a034b11
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v66                               ; 0a008552
(invalid instruction)                                        ; cc0f0012
	v_min_num_f64_e32 v[1:2], v[18:19], v[167:168]              ; 1a034f12
(invalid instruction)                                        ; cc0f0013
	v_min_num_f64_e32 v[1:2], v[19:20], v[2:3]                  ; 1a020513
(invalid instruction)                                        ; cc1b0053
	v_subrev_f32_e32 v0, v83, v66                               ; 0a008553
(invalid instruction)                                        ; cc0f0029
	v_min_num_f64_e32 v[1:2], v[41:42], v[76:77]                ; 1a029929
(invalid instruction)                                        ; cc1b0054
	v_subrev_f32_e32 v0, v84, v66                               ; 0a008554
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[18:19]                ; 1a022511
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[19:20]                ; 1a022711
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[41:42]                ; 1a025311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v85, v17, s58, s59 op_sel:[1,1]           ; d65c1855 00ec7511
(invalid instruction)                                        ; cc0f0011
	v_min_num_f64_e32 v[1:2], v[17:18], v[85:86]                ; 1a02ab11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v86, v17, v145/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64ad2311
	v_max_num_f16_e32 v86, s57, v86                             ; 62acac39
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v87, v86                                  ; 7eae1756
	v_rcp_f32_e32 v87, v87                                      ; 7eae5557
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v109, v70, v87, neg(0) op_sel_hi:[1,0,0]      ; cc20006d 8a02af46
	v_fma_mix_f32 v111, v106, v87, neg(0) op_sel_hi:[1,0,0]     ; cc20006f 8a02af6a
	v_fma_mix_f32 v108, v69, v87, neg(0) op_sel_hi:[1,0,0]      ; cc20006c 8a02af45
	v_fma_mix_f32 v69, v69, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200845 8a02af45
	v_fma_mix_f32 v70, v70, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200846 8a02af46
	v_fma_mix_f32 v106, v106, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086a 8a02af6a
	v_fma_mix_f32 v107, v68, v87, neg(0) op_sel_hi:[1,0,0]      ; cc20006b 8a02af44
	v_fma_mix_f32 v68, v68, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200844 8a02af44
	v_fma_mix_f32 v110, v71, v87, neg(0) op_sel_hi:[1,0,0]      ; cc20006e 8a02af47
	v_fma_mix_f32 v71, v71, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200847 8a02af47
	v_fma_mix_f32 v112, v12, v87, neg(0) op_sel_hi:[1,0,0]      ; cc200070 8a02af0c
	v_fma_mix_f32 v12, v12, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080c 8a02af0c
	v_fma_mix_f32 v113, v103, v87, neg(0) op_sel_hi:[1,0,0]     ; cc200071 8a02af67
	v_fma_mix_f32 v103, v103, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200867 8a02af67
	v_fma_mix_f32 v114, v128, v87, neg(0) op_sel_hi:[1,0,0]     ; cc200072 8a02af80
	v_fma_mix_f32 v128, v128, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200880 8a02af80
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v109, v70, vcc_lo                     ; 02028d6d
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v111, v106, vcc_lo                    ; 0202d56f
	v_fma_mix_f32 v144, v90, v87, neg(0) op_sel_hi:[1,0,0]      ; cc200090 8a02af5a
	v_fma_mix_f32 v90, v90, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085a 8a02af5a
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v107, v68, vcc_lo                     ; 0202896b
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v108, v69, vcc_lo                     ; 02028b6c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v110, v71, vcc_lo                     ; 02028f6e
	v_fma_mix_f32 v145, v91, v87, neg(0) op_sel_hi:[1,0,0]      ; cc200091 8a02af5b
	v_fma_mix_f32 v91, v91, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085b 8a02af5b
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v112, v12, vcc_lo                     ; 02021970
	v_fma_mix_f32 v146, v92, v87, neg(0) op_sel_hi:[1,0,0]      ; cc200092 8a02af5c
	v_fma_mix_f32 v92, v92, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085c 8a02af5c
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v113, v103, vcc_lo                    ; 0202cf71
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                    ; 02030172
	v_fma_mix_f32 v128, v55, v87, neg(0) op_sel_hi:[1,0,0]      ; cc200080 8a02af37
	v_fma_mix_f32 v55, v55, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200837 8a02af37
	v_fma_mix_f32 v147, v165, v87, neg(0) op_sel_hi:[1,0,0]     ; cc200093 8a02afa5
	v_fma_mix_f32 v165, v165, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a02afa5
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v145, v91, vcc_lo                     ; 0202b791
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v146, v92, vcc_lo                     ; 0202b992
	v_lshl_add_u32 v77, v77, 5, s68                             ; d646004d 01110b4d
	v_lshl_add_u32 v78, v78, 5, s68                             ; d646004e 01110b4e
	v_lshl_add_u32 v79, v79, 5, s68                             ; d646004f 01110b4f
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v128, v55, vcc_lo                     ; 02026f80
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v144, v90, vcc_lo                     ; 0202b590
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v147, v165, vcc_lo                    ; 02034b93
	v_fma_mix_f32 v165, v167, v87, neg(0) op_sel_hi:[1,0,0]     ; cc2000a5 8a02afa7
	v_fma_mix_f32 v167, v167, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a7 8a02afa7
	v_lshl_add_u32 v80, v80, 5, s68                             ; d6460050 01110b50
(invalid instruction)                                        ; cc0f0036
	v_min_num_f64_e32 v[1:2], v[54:55], v[77:78]                ; 1a029b36
(invalid instruction)                                        ; cc0f0074
	v_min_num_f64_e32 v[1:2], v[116:117], v[78:79]              ; 1a029d74
(invalid instruction)                                        ; cc0f0075
	v_min_num_f64_e32 v[1:2], v[117:118], v[79:80]              ; 1a029f75
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v165, v167, vcc_lo                    ; 02034fa5
	v_fma_mix_f32 v167, v2, v87, neg(0) op_sel_hi:[1,0,0]       ; cc2000a7 8a02af02
	v_fma_mix_f32 v2, v2, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200802 8a02af02
(invalid instruction)                                        ; cc0f0076
	v_min_num_f64_e32 v[1:2], v[118:119], v[80:81]              ; 1a02a176
(invalid instruction)                                        ; cc0f0036
	v_min_num_f64_e32 v[1:2], v[54:55], v[116:117]              ; 1a02e936
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v167, v2, vcc_lo                      ; 020205a7
	v_fma_mix_f32 v2, v76, v87, neg(0) op_sel_hi:[1,0,0]        ; cc200002 8a02af4c
	v_fma_mix_f32 v76, v76, v87, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084c 8a02af4c
(invalid instruction)                                        ; cc0f0036
	v_min_num_f64_e32 v[1:2], v[54:55], v[117:118]              ; 1a02eb36
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v2, v76, vcc_lo                       ; 02029902
(invalid instruction)                                        ; cc0f0036
	v_min_num_f64_e32 v[1:2], v[54:55], v[118:119]              ; 1a02ed36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_permlanex16_b32 v20, v54, s58, s59 op_sel:[1,1]           ; d65c1814 00ec7536
	v_add_lshl_u32 v27, s0, v134, 2                             ; d647001b 020b0c00
(invalid instruction)                                        ; cc0f0036
	v_min_num_f64_e32 v[1:2], v[54:55], v[20:21]                ; 1a022936
	buffer_load_b128 v[48:51], v27, s[60:63], null offen        ; c405c07c 40807830 0000001b
	v_add_f16_e32 v21, v54, v182/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 642b6d36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v21, s57, v21                             ; 622a2a39
	v_cvt_f32_f16_e32 v22, v21                                  ; 7e2c1715
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_rcp_f32_e32 v22, v22                                      ; 7e2c5516
	buffer_load_b128 v[56:59], v27, s[60:63], null offen offset:16 ; c405c07c 40807838 0000101b
	v_fma_mix_f32 v23, v72, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200017 8a022d48
	v_fma_mix_f32 v72, v72, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200848 8a022d48
	v_fma_mix_f32 v24, v73, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200018 8a022d49
	v_fma_mix_f32 v73, v73, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200849 8a022d49
	v_fma_mix_f32 v41, v135, v22, neg(0) op_sel_hi:[1,0,0]      ; cc200029 8a022d87
	v_fma_mix_f32 v135, v135, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200887 8a022d87
	v_fma_mix_f32 v26, v75, v22, neg(0) op_sel_hi:[1,0,0]       ; cc20001a 8a022d4b
	v_fma_mix_f32 v75, v75, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084b 8a022d4b
	v_fma_mix_f32 v25, v74, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200019 8a022d4a
	v_fma_mix_f32 v74, v74, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084a 8a022d4a
	v_fma_mix_f32 v54, v164, v22, neg(0) op_sel_hi:[1,0,0]      ; cc200036 8a022da4
	v_fma_mix_f32 v164, v164, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a4 8a022da4
	v_fma_mix_f32 v55, v97, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200037 8a022d61
	v_fma_mix_f32 v97, v97, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200861 8a022d61
	v_fma_mix_f32 v64, v98, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200040 8a022d62
	v_fma_mix_f32 v98, v98, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200862 8a022d62
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v23, v72, vcc_lo                      ; 02029117
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v24, v73, vcc_lo                      ; 02029318
	v_fma_mix_f32 v65, v93, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200041 8a022d5d
	v_fma_mix_f32 v93, v93, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085d 8a022d5d
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v41, v135, vcc_lo                     ; 02030f29
	v_fma_mix_f32 v66, v94, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200042 8a022d5e
	v_fma_mix_f32 v94, v94, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085e 8a022d5e
	v_fma_mix_f32 v67, v95, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200043 8a022d5f
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v25, v74, vcc_lo                      ; 02029519
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v26, v75, vcc_lo                      ; 0202971a
	v_fma_mix_f32 v95, v95, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085f 8a022d5f
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v54, v164, vcc_lo                     ; 02034936
	v_fma_mix_f32 v68, v96, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200044 8a022d60
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v55, v97, vcc_lo                      ; 0202c337
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v65, v93, vcc_lo                      ; 0202bb41
	s_lshr_b32 s7, s7, 2                                        ; 85078207
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v66, v94, vcc_lo                      ; 0202bd42
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v67, v95, vcc_lo                      ; 0202bf43
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v28, s7, v28, 2                              ; d647001c 020a3807
	buffer_load_b64 v[66:67], v28, s[20:23], null offen         ; c405407c 40802842 0000001c
	v_fma_mix_f32 v96, v96, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200860 8a022d60
	v_fma_mix_f32 v69, v77, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200045 8a022d4d
	v_fma_mix_f32 v77, v77, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084d 8a022d4d
	v_fma_mix_f32 v70, v78, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200046 8a022d4e
	v_fma_mix_f32 v78, v78, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084e 8a022d4e
	v_fma_mix_f32 v71, v79, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200047 8a022d4f
	v_fma_mix_f32 v79, v79, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084f 8a022d4f
	v_fma_mix_f32 v72, v80, v22, neg(0) op_sel_hi:[1,0,0]       ; cc200048 8a022d50
	v_fma_mix_f32 v80, v80, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200850 8a022d50
	buffer_load_b64 v[22:23], v28, s[20:23], null offen offset:512 ; c405407c 40802816 0002001c
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v64, v98, vcc_lo                      ; 0202c540
	v_lshl_add_u32 v81, v81, 5, s68                             ; d6460051 01110b51
	v_lshl_add_u32 v82, v82, 5, s68                             ; d6460052 01110b52
	v_lshl_add_u32 v83, v83, 5, s68                             ; d6460053 01110b53
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v68, v96, vcc_lo                      ; 0202c144
(invalid instruction)                                        ; cc0f0095
	v_min_num_f64_e32 v[1:2], v[149:150], v[115:116]            ; 1a02e795
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v69, v77, vcc_lo                      ; 02029b45
	v_lshl_add_u32 v84, v84, 5, s68                             ; d6460054 01110b54
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v70, v78, vcc_lo                      ; 02029d46
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v71, v79, vcc_lo                      ; 02029f47
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v72, v80, vcc_lo                      ; 0202a148
(invalid instruction)                                        ; cc0f0082
	v_min_num_f64_e32 v[1:2], v[130:131], v[81:82]              ; 1a02a382
(invalid instruction)                                        ; cc0f0083
	v_min_num_f64_e32 v[1:2], v[131:132], v[82:83]              ; 1a02a583
(invalid instruction)                                        ; cc0f0094
	v_min_num_f64_e32 v[1:2], v[148:149], v[83:84]              ; 1a02a794
(invalid instruction)                                        ; cc0f0095
	v_min_num_f64_e32 v[1:2], v[149:150], v[84:85]              ; 1a02a995
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f0082
	v_min_num_f64_e32 v[1:2], v[130:131], v[131:132]            ; 1a030782
(invalid instruction)                                        ; cc0f0082
	v_min_num_f64_e32 v[1:2], v[130:131], v[148:149]            ; 1a032982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0082
	v_min_num_f64_e32 v[1:2], v[130:131], v[149:150]            ; 1a032b82
	v_permlanex16_b32 v73, v130, s58, s59 op_sel:[1,1]          ; d65c1849 00ec7582
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0082
	v_min_num_f64_e32 v[1:2], v[130:131], v[73:74]              ; 1a029382
(invalid instruction)                                        ; d532104a
	v_cndmask_b32_e32 v1, v130, v130, vcc_lo                    ; 02030582
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v74, s57, v74                             ; 62949439
	v_cvt_f32_f16_e32 v75, v74                                  ; 7e96174a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v75, v75                                      ; 7e96554b
	v_fma_mix_f32 v76, v61, v75, neg(0) op_sel_hi:[1,0,0]       ; cc20004c 8a02973d
	v_fma_mix_f32 v80, v99, v75, neg(0) op_sel_hi:[1,0,0]       ; cc200050 8a029763
	v_fma_mix_f32 v77, v88, v75, neg(0) op_sel_hi:[1,0,0]       ; cc20004d 8a029758
	v_fma_mix_f32 v88, v88, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200858 8a029758
	v_fma_mix_f32 v85, v100, v75, neg(0) op_sel_hi:[1,0,0]      ; cc200055 8a029764
	v_fma_mix_f32 v61, v61, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083d 8a02973d
	v_fma_mix_f32 v79, v44, v75, neg(0) op_sel_hi:[1,0,0]       ; cc20004f 8a02972c
	v_fma_mix_f32 v44, v44, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082c 8a02972c
	v_fma_mix_f32 v78, v166, v75, neg(0) op_sel_hi:[1,0,0]      ; cc20004e 8a0297a6
	v_fma_mix_f32 v166, v166, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a6 8a0297a6
	v_fma_mix_f32 v99, v99, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200863 8a029763
	v_fma_mix_f32 v100, v100, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200864 8a029764
	v_fma_mix_f32 v86, v101, v75, neg(0) op_sel_hi:[1,0,0]      ; cc200056 8a029765
	v_fma_mix_f32 v101, v101, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200865 8a029765
	v_fma_mix_f32 v87, v129, v75, neg(0) op_sel_hi:[1,0,0]      ; cc200057 8a029781
	v_fma_mix_f32 v129, v129, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a029781
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v76, v61, vcc_lo                      ; 02027b4c
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v77, v88, vcc_lo                      ; 0202b14d
	v_fma_mix_f32 v88, v102, v75, neg(0) op_sel_hi:[1,0,0]      ; cc200058 8a029766
	v_fma_mix_f32 v102, v102, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200866 8a029766
	v_fma_mix_f32 v90, v119, v75, neg(0) op_sel_hi:[1,0,0]      ; cc20005a 8a029777
	v_fma_mix_f32 v119, v119, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a029777
	v_fma_mix_f32 v91, v89, v75, neg(0) op_sel_hi:[1,0,0]       ; cc20005b 8a029759
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v78, v166, vcc_lo                     ; 02034d4e
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v79, v44, vcc_lo                      ; 0202594f
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v80, v99, vcc_lo                      ; 0202c750
	v_fma_mix_f32 v89, v89, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200859 8a029759
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v85, v100, vcc_lo                     ; 0202c955
	v_fma_mix_f32 v92, v115, v75, neg(0) op_sel_hi:[1,0,0]      ; cc20005c 8a029773
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v86, v101, vcc_lo                     ; 0202cb56
	v_fma_mix_f32 v115, v115, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200873 8a029773
	v_fma_mix_f32 v93, v81, v75, neg(0) op_sel_hi:[1,0,0]       ; cc20005d 8a029751
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v87, v129, vcc_lo                     ; 02030357
	v_fma_mix_f32 v81, v81, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200851 8a029751
	v_fma_mix_f32 v94, v82, v75, neg(0) op_sel_hi:[1,0,0]       ; cc20005e 8a029752
	v_fma_mix_f32 v82, v82, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200852 8a029752
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v88, v102, vcc_lo                     ; 0202cd58
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v90, v119, vcc_lo                     ; 0202ef5a
	v_fma_mix_f32 v95, v83, v75, neg(0) op_sel_hi:[1,0,0]       ; cc20005f 8a029753
	v_fma_mix_f32 v83, v83, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200853 8a029753
	v_fma_mix_f32 v96, v84, v75, neg(0) op_sel_hi:[1,0,0]       ; cc200060 8a029754
	v_fma_mix_f32 v84, v84, v75, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200854 8a029754
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v91, v89, vcc_lo                      ; 0202b35b
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v92, v115, vcc_lo                     ; 0202e75c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[34:35], v[68:69], 0 ; cc464070 1a028922
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v93, v81, vcc_lo                      ; 0202a35d
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v94, v82, vcc_lo                      ; 0202a55e
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v95, v83, vcc_lo                      ; 0202a75f
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[34:35], v[14:15], 0 ; cc464058 1a021d22
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v96, v84, vcc_lo                      ; 0202a960
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[34:35], v[150:151], 0 ; cc464050 1a032d22
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[34:35], v[20:21], 0 ; cc464060 1a022922
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[38:39], v[70:71], v[112:119] ; cc464070 1dc28d26
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[38:39], v[16:17], v[88:95] ; cc464058 1d622126
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[38:39], v[52:53], v[80:87] ; cc464050 1d426926
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[38:39], v[24:25], v[96:103] ; cc464060 1d823126
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[72:73], v[112:119] ; cc464070 1dc2913e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[62:63], v[12:13], v[88:95] ; cc464058 1d62193e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[62:63], v[36:37], v[80:87] ; cc464050 1d42493e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[62:63], v[54:55], v[96:103] ; cc464060 1d826d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[76:77], v[112:119] ; cc464070 1dc2992e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[46:47], v[18:19], v[88:95] ; cc464058 1d62252e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[104:105], v[80:87] ; cc464050 1d42d12e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v75, v139, v51 :: v_dual_mul_f32 v74, v138, v50 ; c8c6678b 4b4a658a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[64:65], v[96:103] ; cc464060 1d82812e
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[30:31], v[68:69], 0 ; cc464070 1a02891e
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v79, v143, v59 :: v_dual_mul_f32 v78, v142, v58 ; c8c6778f 4f4e758e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[30:31], v[150:151], 0 ; cc464050 1a032d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[30:31], v[14:15], 0 ; cc464058 1a021d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[30:31], v[20:21], 0 ; cc464060 1a02291e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[32:33], v[70:71], v[112:119] ; cc464070 1dc28d20
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[32:33], v[52:53], v[80:87] ; cc464050 1d426920
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[32:33], v[16:17], v[88:95] ; cc464058 1d622120
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[32:33], v[24:25], v[96:103] ; cc464060 1d823120
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[72:73], v[112:119] ; cc464070 1dc2912a
	v_dual_mul_f32 v73, v137, v49 :: v_dual_mul_f32 v72, v136, v48 ; c8c66389 49486188
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[42:43], v[36:37], v[80:87] ; cc464050 1d42492a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[42:43], v[12:13], v[88:95] ; cc464058 1d62192a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[54:55], v[96:103] ; cc464060 1d826d2a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[10:11], v[76:77], v[112:119] ; cc464070 1dc2990a
	v_dual_mul_f32 v77, v141, v57 :: v_dual_mul_f32 v76, v140, v56 ; c8c6738d 4d4c718c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[10:11], v[104:105], v[80:87] ; cc464050 1d42d10a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[10:11], v[18:19], v[88:95] ; cc464058 1d62250a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[10:11], v[64:65], v[96:103] ; cc464060 1d82810a
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_dual_mul_f32 v81, v153, v49 :: v_dual_mul_f32 v80, v152, v48 ; c8c66399 51506198
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_dual_mul_f32 v83, v155, v51 :: v_dual_mul_f32 v82, v154, v50 ; c8c6679b 5352659a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_dual_mul_f32 v85, v121, v57 :: v_dual_mul_f32 v84, v120, v56 ; c8c67379 55547178
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_dual_mul_f32 v87, v133, v59 :: v_dual_mul_f32 v86, v132, v58 ; c8c67785 57567584
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_dual_mul_f32 v89, v169, v49 :: v_dual_mul_f32 v88, v168, v48 ; c8c663a9 595861a8
	v_dual_mul_f32 v91, v171, v51 :: v_dual_mul_f32 v90, v170, v50 ; c8c667ab 5b5a65aa
	v_dual_mul_f32 v93, v173, v57 :: v_dual_mul_f32 v92, v172, v56 ; c8c673ad 5d5c71ac
	v_dual_mul_f32 v95, v175, v59 :: v_dual_mul_f32 v94, v174, v58 ; c8c677af 5f5e75ae
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_mul_f32 v101, v181, v57 :: v_dual_mul_f32 v100, v180, v56 ; c8c673b5 656471b4
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_mul_f32 v103, v183, v59 :: v_dual_mul_f32 v102, v182, v58 ; c8c677b7 676675b6
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_dual_mul_f32 v97, v177, v49 :: v_dual_mul_f32 v96, v176, v48 ; c8c663b1 616061b0
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_dual_mul_f32 v99, v179, v51 :: v_dual_mul_f32 v98, v178, v50 ; c8c667b3 636265b2
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[66:67], v[34:35], v[72:79] ; cc464048 1d224542
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[66:67], v[38:39], v[80:87] ; cc464050 1d424d42
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[66:67], v[46:47], v[88:95] ; cc464058 1d625d42
	s_cmp_ge_i32 s43, 0                                         ; bf03802b
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[66:67], v[62:63], v[96:103] ; cc464060 1d827d42
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[22:23], v[10:11], v[72:79] ; cc464048 1d221516
	s_cselect_b32 s69, -1, 0                                    ; 984580c1
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[22:23], v[12:13], v[80:87] ; cc464050 1d421916
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[22:23], v[14:15], v[88:95] ; cc464058 1d621d16
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[22:23], v[16:17], v[96:103] ; cc464060 1d822116
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cbranch_scc0 BB2                                          ; bfa1000a
BB1:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s28, s0                                        ; bf04001c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00002
BB2:
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB5                                          ; bfa10009
BB4:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s29, s0                                        ; bf04001d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB6                                                ; bfa00001
BB5:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB6:
	v_and_b32_e32 v32, 1, v0                                    ; 36400081
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v2, v72, v76, s0                          ; d5010002 00029948
	v_cndmask_b32_e64 v76, v76, v72, s0                         ; d501004c 0002914c
	v_cndmask_b32_e64 v20, v73, v77, s0                         ; d5010014 00029b49
	v_cndmask_b32_e64 v77, v77, v73, s0                         ; d501004d 0002934d
	v_cndmask_b32_e64 v21, v74, v78, s0                         ; d5010015 00029d4a
	v_cndmask_b32_e64 v78, v78, v74, s0                         ; d501004e 0002954e
	v_cndmask_b32_e64 v22, v75, v79, s0                         ; d5010016 00029f4b
	v_cndmask_b32_e64 v79, v79, v75, s0                         ; d501004f 0002974f
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v76, v76, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069804fa ff0cb14c
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	v_add_f32_dpp v77, v77, v20 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069a28fa ff0cb14d
	v_add_f32_dpp v78, v78, v21 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069c2afa ff0cb14e
	v_add_f32_dpp v79, v79, v22 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069e2cfa ff0cb14f
	v_cvt_f16_f32_e32 v25, v76                                  ; 7e32154c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v26, v77                                  ; 7e34154d
	v_cvt_f16_f32_e32 v23, v78                                  ; 7e2e154e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v78, v78, v76, s2                         ; d501004e 000a994e
	v_cvt_f16_f32_e32 v24, v79                                  ; 7e30154f
	v_cndmask_b32_e64 v79, v79, v77, s2                         ; d501004f 000a9b4f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v30, v25, v23, s2                         ; d501001e 000a2f19
	v_cvt_f16_f32_dpp v31, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3e14fa ff0d644e
	v_cndmask_b16 v30, v26, v24, s2                             ; d65d401e 000a311a
(invalid instruction)                                        ; 7f3e14fa
(invalid instruction)                                        ; ff0d644f
(invalid instruction)                                        ; cc0f001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[31:32]                ; 1a023f1e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB9                                          ; bfa10039
BB7:
	s_load_b64 s[4:5], s[10:11], 0x44                           ; f4002105 f8000044
	s_ashr_i32 s0, s29, 1                                       ; 8600811d
	s_ashr_i32 s2, s28, 1                                       ; 8602811c
	v_bfe_u32 v2, v0, 1, 1                                      ; d6100002 02050300
	v_bfe_u32 v20, v0, 3, 1                                     ; d6100014 02050700
	s_and_b32 s6, s26, 1                                        ; 8b06811a
	v_bfe_u32 v23, v0, 2, 1                                     ; d6100017 02050500
	v_fma_mix_f32 v21, 0, v30, neg(0) op_sel_hi:[0,1,0]         ; cc200015 92023cff 3e800000
	v_fma_mix_f32 v30, 0, v30, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20101e 92023cff 3e800000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s6, s6, 5                                        ; 84068506
	s_and_b32 s7, s27, 1                                        ; 8b07811b
	v_lshl_add_u32 v20, v20, 2, v2                              ; d6460014 04090514
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s7, s7, 7                                        ; 84078707
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                      ; 02023d15
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s7, s7, s6                                     ; 80070607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshl_add_u32 v20, v20, 4, v134                            ; d6460014 06190914
	v_perm_b32 v24, v24, v22, 0x7060501                         ; d6440018 03fe2d18 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s5                                        ; 96000500
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s2                                     ; 80000200
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s0, s0, 9                                        ; 84008900
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s4, s0                                     ; 80040004
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v20, v20, s4, s7                                 ; d6550014 001c0914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v20, v32, 2, v20                             ; d6460014 04510520
	v_lshl_add_u32 v23, v23, 1, v20                             ; d6460017 04510317
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v22, v23, s[12:15], null offen              ; c406007c 40801816 00000017
	buffer_store_b8 v24, v23, s[12:15], null offen offset:1     ; c406007c 40801818 00000117
BB9:
	s_or_not1_b32 s69, s45, s69                                 ; 9245452d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s0, src_scc, s47                                   ; 8c002ffd
	s_cbranch_scc1 BB12                                         ; bfa20007
BB10:
	v_add3_u32 v2, v3, s3, s34                                  ; d6550002 00880703
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[18:19], v2, s[12:15], null offen         ; c406c07c 40801812 00000002
BB12:
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s0, src_scc                                       ; be8000fd
	s_cmp_ge_i32 s48, 0                                         ; bf038030
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s2, -1, 0                                     ; 980280c1
	s_cbranch_scc0 BB14                                         ; bfa1000a
BB13:
	s_load_b32 s4, s[10:11], 0x48                               ; f4000105 f8000048
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s4, s4, 1                                        ; 84048104
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s37, s4                                        ; bf040425
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB15                                               ; bfa00002
BB14:
	s_mov_b32 s5, src_scc                                       ; be8500fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB15:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	s_cbranch_scc0 BB17                                         ; bfa10009
BB16:
	s_load_b32 s4, s[10:11], 0x4c                               ; f4000105 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s4, s4, 1                                        ; 84048104
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s29, s4                                        ; bf04041d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB18                                               ; bfa00001
BB17:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB18:
	s_mov_b32 s4, 0xaaaaaaaa                                    ; be8400ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v2, v80, v84, s4                          ; d5010002 0012a950
	v_cndmask_b32_e64 v84, v84, v80, s4                         ; d5010054 0012a154
	v_cndmask_b32_e64 v20, v81, v85, s4                         ; d5010014 0012ab51
	v_cndmask_b32_e64 v85, v85, v81, s4                         ; d5010055 0012a355
	v_cndmask_b32_e64 v21, v82, v86, s4                         ; d5010015 0012ad52
	v_cndmask_b32_e64 v86, v86, v82, s4                         ; d5010056 0012a556
	v_cndmask_b32_e64 v22, v83, v87, s4                         ; d5010016 0012af53
	v_cndmask_b32_e64 v87, v87, v83, s4                         ; d5010057 0012a757
	s_mov_b32 s6, 0xf0f0f0f0                                    ; be8600ff f0f0f0f0
	v_add_f32_dpp v84, v84, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06a804fa ff0cb154
	s_and_b32 s7, vcc_lo, exec_lo                               ; 8b077e6a
	v_add_f32_dpp v85, v85, v20 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06aa28fa ff0cb155
	v_add_f32_dpp v86, v86, v21 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ac2afa ff0cb156
	v_add_f32_dpp v87, v87, v22 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ae2cfa ff0cb157
	v_cvt_f16_f32_e32 v25, v84                                  ; 7e321554
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v26, v85                                  ; 7e341555
	v_cvt_f16_f32_e32 v23, v86                                  ; 7e2e1556
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v86, v86, v84, s6                         ; d5010056 001aa956
	v_cvt_f16_f32_e32 v24, v87                                  ; 7e301557
	v_cndmask_b32_e64 v87, v87, v85, s6                         ; d5010057 001aab57
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v30, v25, v23, s6                         ; d501001e 001a2f19
	v_cvt_f16_f32_dpp v31, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3e14fa ff0d6456
	v_cndmask_b16 v30, v26, v24, s6                             ; d65d401e 001a311a
(invalid instruction)                                        ; 7f3e14fa
(invalid instruction)                                        ; ff0d6457
(invalid instruction)                                        ; cc0f001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[31:32]                ; 1a023f1e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB21                                         ; bfa10038
BB19:
	s_load_b64 s[6:7], s[10:11], 0x44                           ; f4002185 f8000044
	s_ashr_i32 s4, s29, 1                                       ; 8604811d
	s_ashr_i32 s8, s37, 1                                       ; 86088125
	v_bfe_u32 v2, v0, 1, 1                                      ; d6100002 02050300
	v_bfe_u32 v20, v0, 3, 1                                     ; d6100014 02050700
	s_and_b32 s9, s37, 1                                        ; 8b098125
	v_bfe_u32 v23, v0, 2, 1                                     ; d6100017 02050500
	v_fma_mix_f32 v21, 0, v30, neg(0) op_sel_hi:[0,1,0]         ; cc200015 92023cff 3e800000
	v_fma_mix_f32 v30, 0, v30, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20101e 92023cff 3e800000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s9, s9, 5                                        ; 84098509
	s_and_b32 s16, s27, 1                                       ; 8b10811b
	v_lshl_add_u32 v20, v20, 2, v2                              ; d6460014 04090514
	s_lshl_b32 s16, s16, 7                                      ; 84108710
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                      ; 02023d15
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s16, s9                                   ; 80100910
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshl_add_u32 v20, v20, 4, v134                            ; d6460014 06190914
	v_perm_b32 v24, v24, v22, 0x7060501                         ; d6440018 03fe2d18 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s4, s4, s7                                        ; 96040704
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s4, s8                                     ; 80040804
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s4, s4, 9                                        ; 84048904
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s4                                     ; 80060406
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v20, v20, s6, s16                                ; d6550014 00400d14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v20, v32, 2, v20                             ; d6460014 04510520
	v_lshl_add_u32 v23, v23, 1, v20                             ; d6460017 04510317
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v22, v23, s[12:15], null offen              ; c406007c 40801816 00000017
	buffer_store_b8 v24, v23, s[12:15], null offen offset:1     ; c406007c 40801818 00000117
BB21:
	s_or_not1_b32 s2, s50, s2                                   ; 92020232
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s47, src_scc, s47                                  ; 8c2f2ffd
	s_cbranch_scc1 BB24                                         ; bfa20007
BB22:
	v_add3_u32 v2, v3, s3, s32                                  ; d6550002 00800703
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[18:19], v2, s[12:15], null offen         ; c406c07c 40801812 00000002
BB24:
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s2, src_scc                                       ; be8200fd
	s_cmp_ge_i32 s51, 0                                         ; bf038033
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s4, -1, 0                                     ; 980480c1
	s_cbranch_scc0 BB26                                         ; bfa1000a
BB25:
	s_load_b32 s6, s[10:11], 0x48                               ; f4000185 f8000048
	s_mov_b32 s7, src_scc                                       ; be8700fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s28, s6                                        ; bf04061c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB27                                               ; bfa00002
BB26:
	s_mov_b32 s7, src_scc                                       ; be8700fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB27:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	s_cbranch_scc0 BB29                                         ; bfa10009
BB28:
	s_load_b32 s6, s[10:11], 0x4c                               ; f4000185 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s40, s6                                        ; bf040628
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB30                                               ; bfa00001
BB29:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB30:
	s_mov_b32 s6, 0xaaaaaaaa                                    ; be8600ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v2, v88, v92, s6                          ; d5010002 001ab958
	v_cndmask_b32_e64 v92, v92, v88, s6                         ; d501005c 001ab15c
	v_cndmask_b32_e64 v20, v89, v93, s6                         ; d5010014 001abb59
	v_cndmask_b32_e64 v93, v93, v89, s6                         ; d501005d 001ab35d
	v_cndmask_b32_e64 v21, v90, v94, s6                         ; d5010015 001abd5a
	v_cndmask_b32_e64 v94, v94, v90, s6                         ; d501005e 001ab55e
	v_cndmask_b32_e64 v22, v91, v95, s6                         ; d5010016 001abf5b
	v_cndmask_b32_e64 v95, v95, v91, s6                         ; d501005f 001ab75f
	s_mov_b32 s8, 0xf0f0f0f0                                    ; be8800ff f0f0f0f0
	v_add_f32_dpp v92, v92, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06b804fa ff0cb15c
	s_and_b32 s9, vcc_lo, exec_lo                               ; 8b097e6a
	v_add_f32_dpp v93, v93, v20 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ba28fa ff0cb15d
	v_add_f32_dpp v94, v94, v21 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06bc2afa ff0cb15e
	v_add_f32_dpp v95, v95, v22 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06be2cfa ff0cb15f
	v_cvt_f16_f32_e32 v25, v92                                  ; 7e32155c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v26, v93                                  ; 7e34155d
	v_cvt_f16_f32_e32 v23, v94                                  ; 7e2e155e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v94, v94, v92, s8                         ; d501005e 0022b95e
	v_cvt_f16_f32_e32 v24, v95                                  ; 7e30155f
	v_cndmask_b32_e64 v95, v95, v93, s8                         ; d501005f 0022bb5f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v30, v25, v23, s8                         ; d501001e 00222f19
	v_cvt_f16_f32_dpp v31, v94 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3e14fa ff0d645e
	v_cndmask_b16 v30, v26, v24, s8                             ; d65d401e 0022311a
(invalid instruction)                                        ; 7f3e14fa
(invalid instruction)                                        ; ff0d645f
(invalid instruction)                                        ; cc0f001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[31:32]                ; 1a023f1e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB33                                         ; bfa10038
BB31:
	s_load_b64 s[8:9], s[10:11], 0x44                           ; f4002205 f8000044
	s_ashr_i32 s6, s40, 1                                       ; 86068128
	s_ashr_i32 s16, s28, 1                                      ; 8610811c
	v_bfe_u32 v2, v0, 1, 1                                      ; d6100002 02050300
	v_bfe_u32 v20, v0, 3, 1                                     ; d6100014 02050700
	s_and_b32 s17, s26, 1                                       ; 8b11811a
	v_bfe_u32 v23, v0, 2, 1                                     ; d6100017 02050500
	v_fma_mix_f32 v21, 0, v30, neg(0) op_sel_hi:[0,1,0]         ; cc200015 92023cff 3e800000
	v_fma_mix_f32 v30, 0, v30, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20101e 92023cff 3e800000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s17, s17, 5                                      ; 84118511
	s_and_b32 s18, s40, 1                                       ; 8b128128
	v_lshl_add_u32 v20, v20, 2, v2                              ; d6460014 04090514
	s_lshl_b32 s18, s18, 7                                      ; 84128712
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                      ; 02023d15
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s18, s18, s17                                  ; 80121112
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshl_add_u32 v20, v20, 4, v134                            ; d6460014 06190914
	v_perm_b32 v24, v24, v22, 0x7060501                         ; d6440018 03fe2d18 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s6, s6, s9                                        ; 96060906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s16                                    ; 80061006
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s6, s6, 9                                        ; 84068906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s8, s8, s6                                     ; 80080608
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v20, v20, s8, s18                                ; d6550014 00481114
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v20, v32, 2, v20                             ; d6460014 04510520
	v_lshl_add_u32 v23, v23, 1, v20                             ; d6460017 04510317
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v22, v23, s[12:15], null offen              ; c406007c 40801816 00000017
	buffer_store_b8 v24, v23, s[12:15], null offen offset:1     ; c406007c 40801818 00000117
BB33:
	s_or_not1_b32 s45, s45, s4                                  ; 922d042d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s4, src_scc, s54                                   ; 8c0436fd
	s_cbranch_scc1 BB36                                         ; bfa20007
BB34:
	v_add3_u32 v2, v3, s3, s30                                  ; d6550002 00780703
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[18:19], v2, s[12:15], null offen         ; c406c07c 40801812 00000002
BB36:
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s4, src_scc                                       ; be8400fd
	s_cmp_ge_i32 s55, 0                                         ; bf038037
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s6, -1, 0                                     ; 980680c1
	s_cbranch_scc0 BB38                                         ; bfa1000a
BB37:
	s_load_b32 s8, s[10:11], 0x48                               ; f4000205 f8000048
	s_mov_b32 s9, src_scc                                       ; be8900fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s8, s8, 1                                        ; 84088108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s37, s8                                        ; bf040825
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB39                                               ; bfa00002
BB38:
	s_mov_b32 s9, src_scc                                       ; be8900fd
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB39:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s8, vcc_lo, exec_lo                               ; 8b087e6a
	s_cbranch_scc0 BB41                                         ; bfa10009
BB40:
	s_load_b32 s8, s[10:11], 0x4c                               ; f4000205 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s8, s8, 1                                        ; 84088108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s40, s8                                        ; bf040828
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB42                                               ; bfa00001
BB41:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB42:
	s_mov_b32 s8, 0xaaaaaaaa                                    ; be8800ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v2, v96, v100, s8                         ; d5010002 0022c960
	v_cndmask_b32_e64 v100, v100, v96, s8                       ; d5010064 0022c164
	v_cndmask_b32_e64 v20, v97, v101, s8                        ; d5010014 0022cb61
	v_cndmask_b32_e64 v101, v101, v97, s8                       ; d5010065 0022c365
	v_cndmask_b32_e64 v21, v98, v102, s8                        ; d5010015 0022cd62
	v_cndmask_b32_e64 v102, v102, v98, s8                       ; d5010066 0022c566
	v_cndmask_b32_e64 v22, v99, v103, s8                        ; d5010016 0022cf63
	v_cndmask_b32_e64 v103, v103, v99, s8                       ; d5010067 0022c767
	s_mov_b32 s16, 0xf0f0f0f0                                   ; be9000ff f0f0f0f0
	v_add_f32_dpp v100, v100, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06c804fa ff0cb164
	s_and_b32 s17, vcc_lo, exec_lo                              ; 8b117e6a
	v_add_f32_dpp v101, v101, v20 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ca28fa ff0cb165
	v_add_f32_dpp v102, v102, v21 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cc2afa ff0cb166
	v_add_f32_dpp v103, v103, v22 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ce2cfa ff0cb167
	v_cvt_f16_f32_e32 v25, v100                                 ; 7e321564
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v26, v101                                 ; 7e341565
	v_cvt_f16_f32_e32 v23, v102                                 ; 7e2e1566
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v102, v102, v100, s16                     ; d5010066 0042c966
	v_cvt_f16_f32_e32 v24, v103                                 ; 7e301567
	v_cndmask_b32_e64 v103, v103, v101, s16                     ; d5010067 0042cb67
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v30, v25, v23, s16                        ; d501001e 00422f19
	v_cvt_f16_f32_dpp v31, v102 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3e14fa ff0d6466
	v_cndmask_b16 v30, v26, v24, s16                            ; d65d401e 0042311a
(invalid instruction)                                        ; 7f3e14fa
(invalid instruction)                                        ; ff0d6467
(invalid instruction)                                        ; cc0f001e
	v_min_num_f64_e32 v[1:2], v[30:31], v[31:32]                ; 1a023f1e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB45                                         ; bfa10038
BB43:
	s_load_b64 s[16:17], s[10:11], 0x44                         ; f4002405 f8000044
	s_ashr_i32 s8, s40, 1                                       ; 86088128
	s_ashr_i32 s18, s37, 1                                      ; 86128125
	v_bfe_u32 v2, v0, 1, 1                                      ; d6100002 02050300
	v_bfe_u32 v20, v0, 3, 1                                     ; d6100014 02050700
	s_and_b32 s19, s37, 1                                       ; 8b138125
	v_bfe_u32 v23, v0, 2, 1                                     ; d6100017 02050500
	v_fma_mix_f32 v21, 0, v30, neg(0) op_sel_hi:[0,1,0]         ; cc200015 92023cff 3e800000
	v_fma_mix_f32 v30, 0, v30, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20101e 92023cff 3e800000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s19, s19, 5                                      ; 84138513
	s_and_b32 s24, s40, 1                                       ; 8b188128
	v_lshl_add_u32 v20, v20, 2, v2                              ; d6460014 04090514
	s_lshl_b32 s24, s24, 7                                      ; 84188718
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                      ; 02023d15
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s24, s24, s19                                  ; 80181318
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshl_add_u32 v20, v20, 4, v134                            ; d6460014 06190914
	v_perm_b32 v24, v24, v22, 0x7060501                         ; d6440018 03fe2d18 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s8, s8, s17                                       ; 96081108
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s8, s8, s18                                    ; 80081208
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s8, s8, 9                                        ; 84088908
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s16, s8                                   ; 80100810
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v20, v20, s16, s24                               ; d6550014 00602114
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v20, v32, 2, v20                             ; d6460014 04510520
	v_lshl_add_u32 v23, v23, 1, v20                             ; d6460017 04510317
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v22, v23, s[12:15], null offen              ; c406007c 40801816 00000017
	buffer_store_b8 v24, v23, s[12:15], null offen offset:1     ; c406007c 40801818 00000117
BB45:
	s_or_not1_b32 s50, s50, s6                                  ; 92320632
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s54, src_scc, s54                                  ; 8c3636fd
	s_cbranch_scc1 BB48                                         ; bfa20007
BB46:
	v_add3_u32 v2, v3, s3, s41                                  ; d6550002 00a40703
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[18:19], v2, s[12:15], null offen         ; c406c07c 40801812 00000002
BB48:
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[20:23], v27, s[60:63], null offen offset:64 ; c405c07c 40807814 0000401b
	buffer_load_b128 v[24:27], v27, s[60:63], null offen offset:80 ; c405c07c 40807818 0000501b
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[18:19], v28, s[20:23], null offen offset:8 ; c405407c 40802812 0000081c
	buffer_load_b64 v[30:31], v28, s[20:23], null offen offset:520 ; c405407c 4080281e 0002081c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mul_f32 v49, v185, v21 :: v_dual_mul_f32 v48, v184, v20 ; c8c62bb9 313029b8
	v_dual_mul_f32 v51, v187, v23 :: v_dual_mul_f32 v50, v186, v22 ; c8c62fbb 33322dba
	v_dual_mul_f32 v65, v5, v21 :: v_dual_mul_f32 v64, v4, v20  ; c8c62b05 41402904
	v_dual_mul_f32 v67, v7, v23 :: v_dual_mul_f32 v66, v6, v22  ; c8c62f07 43422d06
	v_dual_mul_f32 v73, v157, v21 :: v_dual_mul_f32 v72, v156, v20 ; c8c62b9d 4948299c
	v_dual_mul_f32 v75, v159, v23 :: v_dual_mul_f32 v74, v158, v22 ; c8c62f9f 4b4a2d9e
	v_dual_mul_f32 v81, v123, v21 :: v_dual_mul_f32 v80, v122, v20 ; c8c62b7b 5150297a
	v_dual_mul_f32 v83, v125, v23 :: v_dual_mul_f32 v82, v124, v22 ; c8c62f7d 53522d7c
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v77, v161, v25 :: v_dual_mul_f32 v76, v160, v24 ; c8c633a1 4d4c31a0
	v_dual_mul_f32 v79, v163, v27 :: v_dual_mul_f32 v78, v162, v26 ; c8c637a3 4f4e35a2
	v_dual_mul_f32 v85, v127, v25 :: v_dual_mul_f32 v84, v126, v24 ; c8c6337f 5554317e
	v_dual_mul_f32 v87, v40, v27 :: v_dual_mul_f32 v86, v45, v26 ; c8c63728 5756352d
	v_dual_mul_f32 v53, v189, v25 :: v_dual_mul_f32 v52, v188, v24 ; c8c633bd 353431bc
	v_dual_mul_f32 v55, v191, v27 :: v_dual_mul_f32 v54, v190, v26 ; c8c637bf 373635be
	v_dual_mul_f32 v69, v9, v25 :: v_dual_mul_f32 v68, v8, v24  ; c8c63309 45443108
	v_dual_mul_f32 v71, v60, v27 :: v_dual_mul_f32 v70, v29, v26 ; c8c6373c 4746351d
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[18:19], v[34:35], v[48:55] ; cc464030 1cc24512
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[18:19], v[38:39], v[64:71] ; cc464040 1d024d12
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[18:19], v[46:47], v[72:79] ; cc464048 1d225d12
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[62:63], v[80:87] ; cc464050 1d427d12
	s_mov_b32 vcc_lo, src_scc                                   ; beea00fd
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[30:31], v[10:11], v[48:55] ; cc464030 1cc2151e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[30:31], v[12:13], v[64:71] ; cc464040 1d02191e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s1, vcc_lo                                        ; be81006a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[30:31], v[14:15], v[72:79] ; cc464048 1d221d1e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[30:31], v[16:17], v[80:87] ; cc464050 1d42211e
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cbranch_scc0 BB50                                         ; bfa10009
BB49:
	s_load_b32 s6, s[10:11], 0x48                               ; f4000185 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s28, s6                                        ; bf04061c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB51                                               ; bfa00001
BB50:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB51:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	s_cbranch_scc0 BB53                                         ; bfa10009
BB52:
	s_load_b32 s6, s[10:11], 0x4c                               ; f4000185 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s6, s6, 1                                        ; 84068106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s29, s6                                        ; bf04061d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB54                                               ; bfa00001
BB53:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB54:
	s_mov_b32 s6, 0xaaaaaaaa                                    ; be8600ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v2, v48, v52, s6                          ; d5010002 001a6930
	v_cndmask_b32_e64 v52, v52, v48, s6                         ; d5010034 001a6134
	v_cndmask_b32_e64 v6, v49, v53, s6                          ; d5010006 001a6b31
	v_cndmask_b32_e64 v53, v53, v49, s6                         ; d5010035 001a6335
	v_cndmask_b32_e64 v7, v50, v54, s6                          ; d5010007 001a6d32
	v_cndmask_b32_e64 v54, v54, v50, s6                         ; d5010036 001a6536
	v_cndmask_b32_e64 v8, v51, v55, s6                          ; d5010008 001a6f33
	v_cndmask_b32_e64 v55, v55, v51, s6                         ; d5010037 001a6737
	s_mov_b32 s8, 0xf0f0f0f0                                    ; be8800ff f0f0f0f0
	v_add_f32_dpp v52, v52, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066804fa ff0cb134
	s_and_b32 s16, vcc_lo, exec_lo                              ; 8b107e6a
	v_add_f32_dpp v53, v53, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066a0cfa ff0cb135
	v_add_f32_dpp v54, v54, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066c0efa ff0cb136
	v_add_f32_dpp v55, v55, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066e10fa ff0cb137
	v_cvt_f16_f32_e32 v11, v52                                  ; 7e161534
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v12, v53                                  ; 7e181535
	v_cvt_f16_f32_e32 v9, v54                                   ; 7e121536
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v54, v54, v52, s8                         ; d5010036 00226936
	v_cvt_f16_f32_e32 v10, v55                                  ; 7e141537
	v_cndmask_b32_e64 v55, v55, v53, s8                         ; d5010037 00226b37
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v13, v11, v9, s8                          ; d501000d 0022130b
	v_cvt_f16_f32_dpp v14, v54 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1c14fa ff0d6436
	v_cndmask_b16 v13, v12, v10, s8                             ; d65d400d 0022150c
(invalid instruction)                                        ; 7f1c14fa
(invalid instruction)                                        ; ff0d6437
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[14:15]                ; 1a021d0d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB57                                         ; bfa1003b
BB55:
	s_load_b64 s[16:17], s[10:11], 0x44                         ; f4002405 f8000044
	s_ashr_i32 s6, s29, 1                                       ; 8606811d
	s_ashr_i32 s8, s28, 1                                       ; 8608811c
	v_bfe_u32 v2, v0, 1, 1                                      ; d6100002 02050300
	v_bfe_u32 v6, v0, 3, 1                                      ; d6100006 02050700
	s_and_b32 s18, s26, 1                                       ; 8b12811a
	v_bfe_u32 v9, v0, 2, 1                                      ; d6100009 02050500
	v_fma_mix_f32 v7, 0, v13, neg(0) op_sel_hi:[0,1,0]          ; cc200007 92021aff 3e800000
	v_fma_mix_f32 v13, 0, v13, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100d 92021aff 3e800000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s18, s18, 5                                      ; 84128512
	s_and_b32 s19, s27, 1                                       ; 8b13811b
	v_lshl_add_u32 v6, v6, 2, v2                                ; d6460006 04090506
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s19, s19, 7                                      ; 84138713
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v7, v13, vcc_lo                       ; 02021b07
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s19, s19, s18                                  ; 80131213
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshl_add_u32 v6, v6, 4, v134                              ; d6460006 06190906
	v_perm_b32 v10, v10, v8, 0x7060501                          ; d644000a 03fe110a 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s6, s6, s17                                       ; 96061106
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s8                                     ; 80060806
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s6, s6, 9                                        ; 84068906
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_addk_co_i32 s6, 0x100                                     ; b7860100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s16, s6                                   ; 80100610
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v6, v6, s16, s19                                 ; d6550006 004c2106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v6, v32, 2, v6                               ; d6460006 04190520
	v_lshl_add_u32 v9, v9, 1, v6                                ; d6460009 04190309
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v8, v9, s[12:15], null offen                ; c406007c 40801808 00000009
	buffer_store_b8 v10, v9, s[12:15], null offen offset:1      ; c406007c 4080180a 00000109
BB57:
	s_cmp_lg_i32 s0, 0                                          ; bf018000
	s_cbranch_scc1 BB60                                         ; bfa2000a
BB58:
	s_add_co_u32 s0, s3, 0x100                                  ; 8000ff03 00000100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v2, v3, s0, s34                                  ; d6550002 00880103
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[4:5], v2, s[12:15], null offen           ; c406c07c 40801804 00000002
BB60:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s5, 0                                          ; bf018005
	s_cbranch_scc0 BB62                                         ; bfa10009
BB61:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s37, s0                                        ; bf040025
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB63                                               ; bfa00001
BB62:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB63:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB65                                         ; bfa10009
BB64:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s29, s0                                        ; bf04001d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB66                                               ; bfa00001
BB65:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB66:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v2, v64, v68, s0                          ; d5010002 00028940
	v_cndmask_b32_e64 v68, v68, v64, s0                         ; d5010044 00028144
	v_cndmask_b32_e64 v6, v65, v69, s0                          ; d5010006 00028b41
	v_cndmask_b32_e64 v69, v69, v65, s0                         ; d5010045 00028345
	v_cndmask_b32_e64 v7, v66, v70, s0                          ; d5010007 00028d42
	v_cndmask_b32_e64 v70, v70, v66, s0                         ; d5010046 00028546
	v_cndmask_b32_e64 v8, v67, v71, s0                          ; d5010008 00028f43
	v_cndmask_b32_e64 v71, v71, v67, s0                         ; d5010047 00028747
	s_mov_b32 s5, 0xf0f0f0f0                                    ; be8500ff f0f0f0f0
	v_add_f32_dpp v68, v68, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068804fa ff0cb144
	s_and_b32 s6, vcc_lo, exec_lo                               ; 8b067e6a
	v_add_f32_dpp v69, v69, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068a0cfa ff0cb145
	v_add_f32_dpp v70, v70, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068c0efa ff0cb146
	v_add_f32_dpp v71, v71, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 068e10fa ff0cb147
	v_cvt_f16_f32_e32 v11, v68                                  ; 7e161544
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v12, v69                                  ; 7e181545
	v_cvt_f16_f32_e32 v9, v70                                   ; 7e121546
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v70, v70, v68, s5                         ; d5010046 00168946
	v_cvt_f16_f32_e32 v10, v71                                  ; 7e141547
	v_cndmask_b32_e64 v71, v71, v69, s5                         ; d5010047 00168b47
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v13, v11, v9, s5                          ; d501000d 0016130b
	v_cvt_f16_f32_dpp v14, v70 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1c14fa ff0d6446
	v_cndmask_b16 v13, v12, v10, s5                             ; d65d400d 0016150c
(invalid instruction)                                        ; 7f1c14fa
(invalid instruction)                                        ; ff0d6447
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[14:15]                ; 1a021d0d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB69                                         ; bfa10038
BB67:
	s_load_b64 s[16:17], s[10:11], 0x44                         ; f4002405 f8000044
	s_ashr_i32 s29, s29, 1                                      ; 861d811d
	s_ashr_i32 s0, s37, 1                                       ; 86008125
	v_bfe_u32 v2, v0, 1, 1                                      ; d6100002 02050300
	v_bfe_u32 v6, v0, 3, 1                                      ; d6100006 02050700
	s_and_b32 s5, s37, 1                                        ; 8b058125
	v_bfe_u32 v9, v0, 2, 1                                      ; d6100009 02050500
	v_fma_mix_f32 v7, 0, v13, neg(0) op_sel_hi:[0,1,0]          ; cc200007 92021aff 3e800000
	v_fma_mix_f32 v13, 0, v13, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100d 92021aff 3e800000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s5, s5, 5                                        ; 84058505
	s_and_b32 s27, s27, 1                                       ; 8b1b811b
	v_lshl_add_u32 v6, v6, 2, v2                                ; d6460006 04090506
	s_lshl_b32 s27, s27, 7                                      ; 841b871b
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v7, v13, vcc_lo                       ; 02021b07
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s27, s27, s5                                   ; 801b051b
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshl_add_u32 v6, v6, 4, v134                              ; d6460006 06190906
	v_perm_b32 v10, v10, v8, 0x7060501                          ; d644000a 03fe110a 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s29, s29, s17                                     ; 961d111d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s29, s29, s0                                   ; 801d001d
	s_lshl_b32 s29, s29, 9                                      ; 841d891d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_addk_co_i32 s29, 0x100                                    ; b79d0100
	s_add_co_u32 s16, s16, s29                                  ; 80101d10
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v6, v6, s16, s27                                 ; d6550006 006c2106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v6, v32, 2, v6                               ; d6460006 04190520
	v_lshl_add_u32 v9, v9, 1, v6                                ; d6460009 04190309
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v8, v9, s[12:15], null offen                ; c406007c 40801808 00000009
	buffer_store_b8 v10, v9, s[12:15], null offen offset:1      ; c406007c 4080180a 00000109
BB69:
	s_cmp_lg_i32 s2, 0                                          ; bf018002
	s_cbranch_scc1 BB72                                         ; bfa2000a
BB70:
	s_add_co_u32 s0, s3, 0x100                                  ; 8000ff03 00000100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v2, v3, s0, s32                                  ; d6550002 00800103
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[4:5], v2, s[12:15], null offen           ; c406c07c 40801804 00000002
BB72:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s7, 0                                          ; bf018007
	s_cbranch_scc0 BB74                                         ; bfa10009
BB73:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s28, s0                                        ; bf04001c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB75                                               ; bfa00001
BB74:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB75:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB77                                         ; bfa10009
BB76:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s40, s0                                        ; bf040028
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB78                                               ; bfa00001
BB77:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB78:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v2, v72, v76, s0                          ; d5010002 00029948
	v_cndmask_b32_e64 v76, v76, v72, s0                         ; d501004c 0002914c
	v_cndmask_b32_e64 v6, v73, v77, s0                          ; d5010006 00029b49
	v_cndmask_b32_e64 v77, v77, v73, s0                         ; d501004d 0002934d
	v_cndmask_b32_e64 v7, v74, v78, s0                          ; d5010007 00029d4a
	v_cndmask_b32_e64 v78, v78, v74, s0                         ; d501004e 0002954e
	v_cndmask_b32_e64 v8, v75, v79, s0                          ; d5010008 00029f4b
	v_cndmask_b32_e64 v79, v79, v75, s0                         ; d501004f 0002974f
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v76, v76, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069804fa ff0cb14c
	s_and_b32 s5, vcc_lo, exec_lo                               ; 8b057e6a
	v_add_f32_dpp v77, v77, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069a0cfa ff0cb14d
	v_add_f32_dpp v78, v78, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069c0efa ff0cb14e
	v_add_f32_dpp v79, v79, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069e10fa ff0cb14f
	v_cvt_f16_f32_e32 v11, v76                                  ; 7e16154c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v12, v77                                  ; 7e18154d
	v_cvt_f16_f32_e32 v9, v78                                   ; 7e12154e
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v78, v78, v76, s2                         ; d501004e 000a994e
	v_cvt_f16_f32_e32 v10, v79                                  ; 7e14154f
	v_cndmask_b32_e64 v79, v79, v77, s2                         ; d501004f 000a9b4f
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v13, v11, v9, s2                          ; d501000d 000a130b
	v_cvt_f16_f32_dpp v14, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1c14fa ff0d644e
	v_cndmask_b16 v13, v12, v10, s2                             ; d65d400d 000a150c
(invalid instruction)                                        ; 7f1c14fa
(invalid instruction)                                        ; ff0d644f
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[14:15]                ; 1a021d0d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB81                                         ; bfa1003b
BB79:
	s_load_b64 s[6:7], s[10:11], 0x44                           ; f4002185 f8000044
	s_ashr_i32 s0, s40, 1                                       ; 86008128
	s_ashr_i32 s28, s28, 1                                      ; 861c811c
	v_bfe_u32 v2, v0, 1, 1                                      ; d6100002 02050300
	v_bfe_u32 v6, v0, 3, 1                                      ; d6100006 02050700
	s_and_b32 s26, s26, 1                                       ; 8b1a811a
	v_bfe_u32 v9, v0, 2, 1                                      ; d6100009 02050500
	v_fma_mix_f32 v7, 0, v13, neg(0) op_sel_hi:[0,1,0]          ; cc200007 92021aff 3e800000
	v_fma_mix_f32 v13, 0, v13, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100d 92021aff 3e800000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s26, s26, 5                                      ; 841a851a
	s_and_b32 s2, s40, 1                                        ; 8b028128
	v_lshl_add_u32 v6, v6, 2, v2                                ; d6460006 04090506
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s2, s2, 7                                        ; 84028702
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v7, v13, vcc_lo                       ; 02021b07
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s2, s2, s26                                    ; 80021a02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshl_add_u32 v6, v6, 4, v134                              ; d6460006 06190906
	v_perm_b32 v10, v10, v8, 0x7060501                          ; d644000a 03fe110a 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s7                                        ; 96000700
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s28                                    ; 80001c00
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s0, s0, 9                                        ; 84008900
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_addk_co_i32 s0, 0x100                                     ; b7800100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s0                                     ; 80060006
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v6, v6, s6, s2                                   ; d6550006 00080d06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v6, v32, 2, v6                               ; d6460006 04190520
	v_lshl_add_u32 v9, v9, 1, v6                                ; d6460009 04190309
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v8, v9, s[12:15], null offen                ; c406007c 40801808 00000009
	buffer_store_b8 v10, v9, s[12:15], null offen offset:1      ; c406007c 4080180a 00000109
BB81:
	s_cmp_lg_i32 s4, 0                                          ; bf018004
	s_cbranch_scc1 BB84                                         ; bfa2000a
BB82:
	s_add_co_u32 s0, s3, 0x100                                  ; 8000ff03 00000100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v2, v3, s0, s30                                  ; d6550002 00780103
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v2, v2, v1                                 ; 4a040302
	buffer_store_b64 v[4:5], v2, s[12:15], null offen           ; c406c07c 40801804 00000002
BB84:
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_cmp_lg_i32 s9, 0                                          ; bf018009
	s_cbranch_scc0 BB86                                         ; bfa10009
BB85:
	s_load_b32 s0, s[10:11], 0x48                               ; f4000005 f8000048
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s37, s0                                        ; bf040025
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB87                                               ; bfa00001
BB86:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB87:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 s0, vcc_lo, exec_lo                               ; 8b007e6a
	s_cbranch_scc0 BB89                                         ; bfa10009
BB88:
	s_load_b32 s0, s[10:11], 0x4c                               ; f4000005 f800004c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s0, s0, 1                                        ; 84008100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s40, s0                                        ; bf040028
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB90                                               ; bfa00001
BB89:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB90:
	s_mov_b32 s0, 0xaaaaaaaa                                    ; be8000ff aaaaaaaa
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v2, v80, v84, s0                          ; d5010002 0002a950
	v_cndmask_b32_e64 v84, v84, v80, s0                         ; d5010054 0002a154
	v_cndmask_b32_e64 v6, v81, v85, s0                          ; d5010006 0002ab51
	v_cndmask_b32_e64 v85, v85, v81, s0                         ; d5010055 0002a355
	v_cndmask_b32_e64 v7, v82, v86, s0                          ; d5010007 0002ad52
	v_cndmask_b32_e64 v86, v86, v82, s0                         ; d5010056 0002a556
	v_cndmask_b32_e64 v8, v83, v87, s0                          ; d5010008 0002af53
	v_cndmask_b32_e64 v87, v87, v83, s0                         ; d5010057 0002a757
	s_mov_b32 s2, 0xf0f0f0f0                                    ; be8200ff f0f0f0f0
	v_add_f32_dpp v84, v84, v2 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06a804fa ff0cb154
	s_and_b32 s4, vcc_lo, exec_lo                               ; 8b047e6a
	v_add_f32_dpp v85, v85, v6 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06aa0cfa ff0cb155
	v_add_f32_dpp v86, v86, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ac0efa ff0cb156
	v_add_f32_dpp v87, v87, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ae10fa ff0cb157
	v_cvt_f16_f32_e32 v11, v84                                  ; 7e161554
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f16_f32_e32 v12, v85                                  ; 7e181555
	v_cvt_f16_f32_e32 v9, v86                                   ; 7e121556
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cndmask_b32_e64 v86, v86, v84, s2                         ; d5010056 000aa956
	v_cvt_f16_f32_e32 v10, v87                                  ; 7e141557
	v_cndmask_b32_e64 v87, v87, v85, s2                         ; d5010057 000aab57
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c4
	v_cndmask_b32_e64 v13, v11, v9, s2                          ; d501000d 000a130b
	v_cvt_f16_f32_dpp v14, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e1c14fa ff0d6456
	v_cndmask_b16 v13, v12, v10, s2                             ; d65d400d 000a150c
(invalid instruction)                                        ; 7f1c14fa
(invalid instruction)                                        ; ff0d6457
(invalid instruction)                                        ; cc0f000d
	v_min_num_f64_e32 v[1:2], v[13:14], v[14:15]                ; 1a021d0d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB93                                         ; bfa1003b
BB91:
	s_load_b64 s[4:5], s[10:11], 0x44                           ; f4002105 f8000044
	s_ashr_i32 s0, s40, 1                                       ; 86008128
	s_ashr_i32 s2, s37, 1                                       ; 86028125
	v_bfe_u32 v2, v0, 1, 1                                      ; d6100002 02050300
	v_bfe_u32 v6, v0, 3, 1                                      ; d6100006 02050700
	s_and_b32 s37, s37, 1                                       ; 8b258125
	v_bfe_u32 v0, v0, 2, 1                                      ; d6100000 02050500
	v_fma_mix_f32 v7, 0, v13, neg(0) op_sel_hi:[0,1,0]          ; cc200007 92021aff 3e800000
	v_fma_mix_f32 v13, 0, v13, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20100d 92021aff 3e800000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s37, s37, 5                                      ; 84258525
	s_and_b32 s40, s40, 1                                       ; 8b288128
	v_lshl_add_u32 v6, v6, 2, v2                                ; d6460006 04090506
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s40, s40, 7                                      ; 84288728
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v7, v13, vcc_lo                       ; 02021b07
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s40, s40, s37                                  ; 80282528
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshl_add_u32 v6, v6, 4, v134                              ; d6460006 06190906
	v_perm_b32 v9, v9, v8, 0x7060501                            ; d6440009 03fe1109 07060501
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s0, s0, s5                                        ; 96000500
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s0, s0, s2                                     ; 80000200
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s0, s0, 9                                        ; 84008900
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_addk_co_i32 s0, 0x100                                     ; b7800100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s4, s0                                     ; 80040004
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v6, v6, s4, s40                                  ; d6550006 00a00906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v32, v32, 2, v6                              ; d6460020 04190520
	v_lshl_add_u32 v0, v0, 1, v32                               ; d6460000 04810300
	s_clause 0x1                                                ; bf850001
	buffer_store_b8 v8, v0, s[12:15], null offen                ; c406007c 40801808 00000000
	buffer_store_b8 v9, v0, s[12:15], null offen offset:1       ; c406007c 40801809 00000100
BB93:
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc1 BB96                                         ; bfa20009
BB94:
	s_addk_co_i32 s3, 0x100                                     ; b7830100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v3, v3, s3, s41                                  ; d6550003 00a40703
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v3, v3, v1                                 ; 4a060303
	buffer_store_b64 v[4:5], v3, s[12:15], null offen           ; c406c07c 40801804 00000003
BB96:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
