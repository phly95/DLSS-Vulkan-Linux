BB0:
	s_mov_b32 s14, s1                                           ; be8e0001
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b32 s1, s[14:15], 0x54                               ; f4000047 f8000054
	v_and_b32_e32 v1, 7, v0                                     ; 36020087
	v_lshrrev_b32_e32 v2, 3, v0                                 ; 32040083
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v1, ttmp9, 3, v1                             ; d6460001 04050675
	v_lshl_add_u32 v3, ttmp7, 3, v2                             ; d6460003 04090673
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_eq_i32 s1, 0                                          ; bf008001
	s_cbranch_scc0 BB2                                          ; bfa10006
BB1:
	s_load_b32 s11, s[14:15], 0x34                              ; f40002c7 f8000034
	s_mov_b32 s12, src_scc                                      ; be8c00fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s11, s11, 2                                      ; 840b820b
	s_branch BB3                                                ; bfa00002
BB2:
	s_mov_b32 s11, s1                                           ; be8b0001
	s_mov_b32 s12, src_scc                                      ; be8c00fd
BB3:
	s_load_b32 s16, s[14:15], 0x58                              ; f4000407 f8000058
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_eq_i32 s16, 0                                         ; bf008010
	s_cbranch_scc0 BB5                                          ; bfa10006
BB4:
	s_load_b32 s17, s[14:15], 0x38                              ; f4000447 f8000038
	s_mov_b32 s18, src_scc                                      ; be9200fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s17, s17, 2                                      ; 84118211
	s_branch BB6                                                ; bfa00002
BB5:
	s_mov_b32 s17, s16                                          ; be910010
	s_mov_b32 s18, src_scc                                      ; be9200fd
BB6:
	s_mov_b32 s20, s1                                           ; be940001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x2                                                ; bf850002
	s_load_b32 s19, s[14:15], 0x7c                              ; f40004c7 f800007c
	s_load_b256 s[24:31], s[0:1], 0x60                          ; f4006600 f8000060
	s_load_b128 s[32:35], s[0:1], 0x90                          ; f4004800 f8000090
	s_lshl1_add_u32 s21, s11, -2                                ; 8715c20b
	v_cmp_gt_u32_e32 vcc_lo, s11, v1                            ; 7c98020b
	s_cvt_f32_u32 s11, s11                                      ; be8b650b
	s_lshl1_add_u32 s22, s17, -2                                ; 8716c211
	s_bitcmp1_b32 s13, 0                                        ; bf0d800d
	v_sub_nc_u32_e32 v4, s21, v1                                ; 4c080215
	v_sub_nc_u32_e32 v5, s22, v3                                ; 4c0a0616
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d684000b
	v_cndmask_b32_e32 v0, s11, v128, vcc_lo                     ; 0201000b
	s_mov_b32 s23, src_scc                                      ; be9700fd
	v_cndmask_b32_e32 v4, v4, v1, vcc_lo                        ; 02080304
	v_cmp_gt_u32_e32 vcc_lo, s17, v3                            ; 7c980611
	s_cvt_f32_u32 s17, s17                                      ; be916511
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d2
	v_cvt_f32_i32_e32 v4, v4                                    ; 7e080b04
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840011
	v_cndmask_b32_e32 v0, s17, v128, vcc_lo                     ; 02010011
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v5, v5, v3, vcc_lo                        ; 020a0705
	v_cvt_f32_i32_e32 v5, v5                                    ; 7e0a0b05
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_and_b32 s36, s35, -2.0                                    ; 8b24f523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a1
	v_dual_add_f32 v5, 0.5, v5 :: v_dual_add_f32 v4, 0.5, v4    ; c9080af0 050408f0
	s_cmp_eq_i32 s36, -2.0                                      ; bf00f524
	s_and_b32 s23, s23, src_scc                                 ; 8b17fd17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c1
	v_dual_mul_f32 v5, s17, v5 :: v_dual_mul_f32 v4, s11, v4    ; c8c60a11 0504080b
	s_mov_b32 s37, src_scc                                      ; bea500fd
	s_and_b32 s38, s35, 0x3fffffff                              ; 8b26ff23 3fffffff
	s_cmp_lg_i32 s37, 0                                         ; bf018025
	s_cselect_b32 s35, s38, s35                                 ; 98232326
	image_sample_lz v[6:8], [v4, v5], s[24:31], s[32:35] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 10003006 00000504
	s_cmp_lg_i32 s19, 0                                         ; bf018013
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_cvt_f16_f32_e32 v9, v6                                    ; 7e121506
(invalid instruction)                                        ; 7f121507
	v_cvt_f16_f32_e32 v10, v8                                   ; 7e141508
	s_cbranch_scc0 BB8                                          ; bfa10011
BB7:
	s_load_b128 s[36:39], s[0:1], 0x40                          ; f4004900 f8000040
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_lshl_b32 s13, s10, 3                                      ; 840d830a
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v0, v3, v13, vcc_lo                       ; 02001b03
	v_add_lshl_u32 v4, v4, v1, 1                                ; d6470004 02060304
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v4, s19, v4, 2                               ; d6470004 020a0813
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b64 v[4:5], v4, s[36:39], null offen            ; c405407c 40804804 00000004
	s_branch BB9                                                ; bfa00088
BB8:
	s_clause 0x1                                                ; bf850001
	s_load_b32 s11, s[14:15], 0x5c                              ; f40002c7 f800005c
	s_load_b32 s21, s[14:15], 0x74                              ; f4000547 f8000074
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v1, 0x8da6b343, v1, vcc_lo                ; 020202ff 8da6b343
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v1, 0xd8163841, v3, vcc_lo                ; 020206ff d8163841
	s_mov_b32 s13, 0x108ef2d9                                   ; be8d00ff 108ef2d9
	s_mov_b32 s17, 0x33800000                                   ; be9100ff 33800000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s11, s11, 0x9e3779b9                              ; 960bff0b 9e3779b9
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_xor3_b32 v5, v5, s11, v4                                  ; d6400005 04101705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v5, 0x243f6a88, v5                            ; 3a0a0aff 243f6a88
	v_lshrrev_b32_e32 v6, 28, v5                                ; 320c0a9c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v6, 4, v6                                  ; 4a0c0c84
	v_lshrrev_b32_e32 v6, v6, v5                                ; 320c0b06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v6, v6, v5                                    ; 3a0c0b06
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v1, s13, v6, vcc_lo                       ; 02020c0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v7, 22, v6                                ; 320e0c96
	v_xor_b32_e32 v7, v7, v6                                    ; 3a0e0d07
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d72c0008
	v_cndmask_b32_e32 v1, 0x2c9277b5, v7, vcc_lo                ; 02020eff 2c9277b5
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v1, 0xfa6dc5f9, v7, vcc_lo                ; 02020eff fa6dc5f9
(invalid instruction)                                        ; d72c0010
	v_cndmask_b32_e32 v1, 0xcaa5b80d, v7, vcc_lo                ; 02020eff caa5b80d
(invalid instruction)                                        ; d72c0007
	v_cndmask_b32_e32 v1, 0x83232c31, v7, vcc_lo                ; 02020eff 83232c31
	v_add_nc_u32_e32 v8, 0xac564b05, v8                         ; 4a1010ff ac564b05
	v_add_nc_u32_e32 v13, 0x4712a88e, v13                       ; 4a1a1aff 4712a88e
	v_add_nc_u32_e32 v16, 0x21dd796b, v16                       ; 4a2020ff 21dd796b
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_lshrrev_b32_e32 v11, 28, v8                               ; 3216109c
	v_lshrrev_b32_e32 v14, 28, v13                              ; 321c1a9c
	v_add_nc_u32_e32 v7, 0x3463e0ac, v7                         ; 4a0e0eff 3463e0ac
	v_lshrrev_b32_e32 v17, 28, v16                              ; 3222209c
	v_add_nc_u32_e32 v11, 4, v11                                ; 4a161684
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_lshrrev_b32_e32 v19, 28, v7                               ; 32260e9c
	v_add_nc_u32_e32 v17, 4, v17                                ; 4a222284
	v_lshrrev_b32_e32 v11, v11, v8                              ; 3216110b
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_add_nc_u32_e32 v19, 4, v19                                ; 4a262684
	v_xor_b32_e32 v11, v11, v8                                  ; 3a16110b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c000b
	v_cndmask_b32_e32 v1, s13, v11, vcc_lo                      ; 0202160d
	v_lshrrev_b32_e32 v12, 8, v11                               ; 32181688
	v_lshrrev_b32_e32 v11, 30, v11                              ; 3216169e
	v_lshrrev_b32_e32 v17, v17, v16                             ; 32222111
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_xad_u32 v11, v11, v12, 1                                  ; d645000b 0206190b
	v_xor_b32_e32 v17, v17, v16                                 ; 3a222111
	v_cvt_f32_u32_e32 v11, v11                                  ; 7e160d0b
(invalid instruction)                                        ; d72c0011
	v_cndmask_b32_e32 v1, s13, v17, vcc_lo                      ; 0202220d
	v_dual_mul_f32 v11, s17, v11 :: v_dual_add_nc_u32 v14, 4, v14 ; c8e01611 0b0e1c84
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v14, v14, v13                             ; 321c1b0e
	v_log_f32_e32 v11, v11                                      ; 7e164f0b
	v_lshrrev_b32_e32 v19, v19, v7                              ; 32260f13
	v_lshrrev_b32_e32 v18, 8, v17                               ; 32242288
	v_lshrrev_b32_e32 v17, 30, v17                              ; 3222229e
	v_xor_b32_e32 v14, v14, v13                                 ; 3a1c1b0e
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_xor_b32_e32 v19, v19, v7                                  ; 3a260f13
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v1, s13, v14, vcc_lo                      ; 02021c0d
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v1, s13, v19, vcc_lo                      ; 0202260d
	v_xad_u32 v17, v17, v18, 1                                  ; d6450011 02062511
	v_lshrrev_b32_e32 v15, 8, v14                               ; 321e1c88
	v_lshrrev_b32_e32 v14, 30, v14                              ; 321c1c9e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_cvt_f32_u32_e32 v17, v17                                  ; 7e220d11
	v_lshrrev_b32_e32 v20, 8, v19                               ; 32282688
	v_lshrrev_b32_e32 v19, 30, v19                              ; 3226269e
	v_xad_u32 v14, v14, v15, 1                                  ; d645000e 02061f0e
	v_mul_f32_e32 v17, s17, v17                                 ; 10222211
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_xad_u32 v19, v19, v20, 1                                  ; d6450013 02062913
	v_cvt_f32_u32_e32 v14, v14                                  ; 7e1c0d0e
	v_log_f32_e32 v17, v17                                      ; 7e224f11
	v_cvt_f32_u32_e32 v19, v19                                  ; 7e260d13
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	v_dual_mul_f32 v11, 0xbfb17218, v11 :: v_dual_mul_f32 v14, s17, v14 ; c8c616ff 0b0e1c11 bfb17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_mul_f32_e32 v19, s17, v19                                 ; 10262611
	v_sqrt_f32_e32 v11, v11                                     ; 7e16670b
	v_cos_f32_e32 v21, v14                                      ; 7e2a6d0e
	v_sin_f32_e32 v14, v14                                      ; 7e1c6b0e
	v_mul_f32_e32 v17, 0xbfb17218, v17                          ; 102222ff bfb17218
	v_cos_f32_e32 v19, v19                                      ; 7e266d13
	v_mul_f32_e32 v21, v11, v21                                 ; 102a2b0b
	v_sqrt_f32_e32 v17, v17                                     ; 7e226711
	v_mul_f32_e32 v11, v11, v14                                 ; 10161d0b
	v_fma_mixlo_f16 v4, s21, v21, neg(0) op_sel_hi:[0,0,1]      ; cc214004 82022a15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mixhi_f16 v4, s21, v11, neg(0) op_sel_hi:[0,0,1]      ; cc224004 82021615
	v_mul_f32_e32 v17, v17, v19                                 ; 10222711
	v_fma_mixlo_f16 v5, s21, v17, neg(0) op_sel_hi:[0,0,1]      ; cc214005 82022215
BB9:
	s_clause 0x2                                                ; bf850002
	s_load_b32 s13, s[14:15], 0x78                              ; f4000347 f8000078
	s_load_b128 s[36:39], s[14:15], 0x60                        ; f4004907 f8000060
	s_load_b32 s17, s[14:15], 0x70                              ; f4000447 f8000070
	v_lshlrev_b32_e32 v2, 2, v2                                 ; 30040482
(invalid instruction)                                        ; cc0f0009
	v_subrev_f32_e32 v0, v9, v241                               ; 0a01e309
	v_add_f16_e32 v10, -0.5, v10                                ; 641414f1
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mov_b32 v12, v4 :: v_dual_and_b32 v7, 3, v0          ; ca240104 0c060083
	v_bfe_u32 v6, v1, 2, 1                                      ; d6100006 02050501
	v_bfe_u32 v3, v3, 2, 1                                      ; d6100003 02050503
(invalid instruction)                                        ; cc10000e
	v_subrev_f32_e32 v0, v9, v255                               ; 0a01ff09
(invalid instruction)                                        ; 00003000
	v_mul_f16_e32 v9, 0x3000, v10                               ; 6a1214ff 00003000
	v_add_nc_u32_e32 v10, 32, v0                                ; 4a1400a0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_lshl_add_u32 v3, v3, 1, v6                                ; d6460003 04190303
	v_mov_b32_e32 v8, v14                                       ; 7e10030e
	v_lshrrev_b32_e32 v10, 3, v10                               ; 32141483
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_lshl_add_u32 v3, v3, 4, v2                                ; d6460003 04090903
	v_perm_b32 v15, v8, v9, 0x5040100                           ; d644000f 03fe1308 05040100
	v_lshl_add_u32 v11, ttmp7, 3, v10                           ; d646000b 04290673
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d3
	v_add_lshl_u32 v3, v3, v7, 5                                ; d6470003 02160f03
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cvt_f16_f32 s13, s13                                      ; be8d680d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_mov_b16_e32 v17.h, s13                                    ; 7f22380d
	v_perm_b32 v13, v17, v5, 0x7060100                          ; d644000d 03fe0b11 07060100
	ds_store_b128 v3, v[12:15]                                  ; db7c0000 00000c03
	v_alignbyte_b32 v12, v9, v8, 2                              ; d617000c 020a1109
	s_cvt_f16_f32 s38, s38                                      ; bea66826
	s_cvt_f16_f32 s36, s36                                      ; bea46824
	s_cvt_f16_f32 s37, s37                                      ; bea56825
	s_cvt_f16_f32 s39, s39                                      ; bea76827
	s_cvt_f16_f32 s17, s17                                      ; be916811
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_pack_ll_b32_b16 s36, s36, s37                             ; 99242524
	s_pack_ll_b32_b16 s38, s38, s39                             ; 99262726
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_pack_ll_b32_b16 s17, s17, 0                               ; 99118011
	v_mov_b32_e32 v13, s36                                      ; 7e1a0224
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_mov_b32 v15, s17 :: v_dual_mov_b32 v14, s38          ; ca100011 0f0e0026
	ds_store_b128 v3, v[12:15] offset:16                        ; db7c0010 00000c03
	s_cmp_lg_i32 s12, 0                                         ; bf01800c
	s_cbranch_scc0 BB12                                         ; bfa10006
BB10:
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s12, s12, 2                                      ; 840c820c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s20, s12                                          ; be94000c
BB12:
	s_cmp_lg_i32 s18, 0                                         ; bf018012
	s_cbranch_scc0 BB15                                         ; bfa10004
BB13:
	s_load_b32 s12, s[14:15], 0x38                              ; f4000307 f8000038
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s16, s12, 2                                      ; 8410820c
BB15:
	s_lshl1_add_u32 s12, s20, -2                                ; 870cc214
	v_cmp_gt_u32_e32 vcc_lo, s20, v1                            ; 7c980214
	s_cvt_f32_u32 s20, s20                                      ; be946514
	s_lshl1_add_u32 s13, s16, -2                                ; 870dc210
	v_sub_nc_u32_e32 v2, s12, v1                                ; 4c04020c
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_sub_nc_u32_e32 v3, s13, v11                               ; 4c06160d
(invalid instruction)                                        ; d6840014
	v_cndmask_b32_e32 v0, s20, v128, vcc_lo                     ; 02010014
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_cndmask_b32_e32 v2, v2, v1, vcc_lo                        ; 02040302
	v_cmp_gt_u32_e32 vcc_lo, s16, v11                           ; 7c981610
	s_cvt_f32_u32 s16, s16                                      ; be906510
	v_cvt_f32_i32_e32 v2, v2                                    ; 7e040b02
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v3, v3, v11, vcc_lo                       ; 02061703
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840010
	v_cndmask_b32_e32 v0, s16, v128, vcc_lo                     ; 02010010
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_cvt_f32_i32_e32 v3, v3                                    ; 7e060b03
	v_dual_add_f32 v3, 0.5, v3 :: v_dual_add_f32 v2, 0.5, v2    ; c90806f0 030204f0
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v3, s16, v3 :: v_dual_mul_f32 v2, s20, v2    ; c8c60610 03020414
	image_sample_lz v[12:14], [v2, v3], s[24:31], s[32:35] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1000300c 00000302
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_cvt_f16_f32_e32 v15, v12                                  ; 7e1e150c
	v_cvt_f16_f32_e32 v16, v14                                  ; 7e20150e
(invalid instruction)                                        ; 7f1e150d
	s_cbranch_scc0 BB17                                         ; bfa10010
BB16:
	s_load_b128 s[20:23], s[0:1], 0x40                          ; f4004500 f8000040
	s_lshl_b32 s11, s10, 3                                      ; 840b830a
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v11, v11, vcc_lo                      ; 0200170b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v2, v2, v1, 1                                ; d6470002 02060302
	v_add_lshl_u32 v2, s19, v2, 2                               ; d6470002 020a0413
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b64 v[2:3], v2, s[20:23], null offen            ; c405407c 40802802 00000002
	s_branch BB18                                               ; bfa00085
BB17:
	s_clause 0x1                                                ; bf850001
	s_load_b32 s11, s[14:15], 0x5c                              ; f40002c7 f800005c
	s_load_b32 s16, s[14:15], 0x74                              ; f4000407 f8000074
(invalid instruction)                                        ; d72c0001
	v_cndmask_b32_e32 v1, 0x8da6b343, v1, vcc_lo                ; 020202ff 8da6b343
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v1, 0xd8163841, v11, vcc_lo               ; 020216ff d8163841
	s_mov_b32 s12, 0x108ef2d9                                   ; be8c00ff 108ef2d9
	s_mov_b32 s13, 0x33800000                                   ; be8d00ff 33800000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s11, s11, 0x9e3779b9                              ; 960bff0b 9e3779b9
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_xor3_b32 v2, v2, s11, v1                                  ; d6400002 04041702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v2, 0x243f6a88, v2                            ; 3a0404ff 243f6a88
	v_lshrrev_b32_e32 v3, 28, v2                                ; 3206049c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v3, 4, v3                                  ; 4a060684
	v_lshrrev_b32_e32 v3, v3, v2                                ; 32060503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v3, v3, v2                                    ; 3a060503
(invalid instruction)                                        ; d72c0003
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                       ; 0202060c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v4, 22, v3                                ; 32080696
	v_xor_b32_e32 v4, v4, v3                                    ; 3a080704
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v1, 0x2c9277b5, v4, vcc_lo                ; 020208ff 2c9277b5
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v1, 0xfa6dc5f9, v4, vcc_lo                ; 020208ff fa6dc5f9
(invalid instruction)                                        ; d72c0012
	v_cndmask_b32_e32 v1, 0xcaa5b80d, v4, vcc_lo                ; 020208ff caa5b80d
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v1, 0x83232c31, v4, vcc_lo                ; 020208ff 83232c31
	v_add_nc_u32_e32 v5, 0xac564b05, v5                         ; 4a0a0aff ac564b05
	v_add_nc_u32_e32 v12, 0x4712a88e, v12                       ; 4a1818ff 4712a88e
	v_add_nc_u32_e32 v18, 0x21dd796b, v18                       ; 4a2424ff 21dd796b
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_lshrrev_b32_e32 v8, 28, v5                                ; 32100a9c
	v_lshrrev_b32_e32 v13, 28, v12                              ; 321a189c
	v_add_nc_u32_e32 v4, 0x3463e0ac, v4                         ; 4a0808ff 3463e0ac
	v_lshrrev_b32_e32 v19, 28, v18                              ; 3226249c
	v_add_nc_u32_e32 v8, 4, v8                                  ; 4a101084
	v_add_nc_u32_e32 v13, 4, v13                                ; 4a1a1a84
	v_lshrrev_b32_e32 v21, 28, v4                               ; 322a089c
	v_add_nc_u32_e32 v19, 4, v19                                ; 4a262684
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_lshrrev_b32_e32 v8, v8, v5                                ; 32100b08
	v_lshrrev_b32_e32 v13, v13, v12                             ; 321a190d
	v_xor_b32_e32 v8, v8, v5                                    ; 3a100b08
	v_xor_b32_e32 v13, v13, v12                                 ; 3a1a190d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d2
(invalid instruction)                                        ; d72c0008
	v_cndmask_b32_e32 v1, s12, v8, vcc_lo                       ; 0202100c
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v1, s12, v13, vcc_lo                      ; 02021a0c
	v_lshrrev_b32_e32 v19, v19, v18                             ; 32262513
	v_lshrrev_b32_e32 v9, 8, v8                                 ; 32121088
	v_lshrrev_b32_e32 v8, 30, v8                                ; 3210109e
	v_xor_b32_e32 v19, v19, v18                                 ; 3a262513
	v_lshrrev_b32_e32 v14, 8, v13                               ; 321c1a88
	v_lshrrev_b32_e32 v13, 30, v13                              ; 321a1a9e
	v_xad_u32 v8, v8, v9, 1                                     ; d6450008 02061308
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v1, s12, v19, vcc_lo                      ; 0202260c
	v_xad_u32 v13, v13, v14, 1                                  ; d645000d 02061d0d
	v_cvt_f32_u32_e32 v8, v8                                    ; 7e100d08
	v_cvt_f32_u32_e32 v13, v13                                  ; 7e1a0d0d
	v_dual_mul_f32 v8, s13, v8 :: v_dual_add_nc_u32 v21, 4, v21 ; c8e0100d 08142a84
	v_lshrrev_b32_e32 v20, 8, v19                               ; 32282688
	v_lshrrev_b32_e32 v19, 30, v19                              ; 3226269e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
	v_log_f32_e32 v8, v8                                        ; 7e104f08
	v_lshrrev_b32_e32 v21, v21, v4                              ; 322a0915
	v_xad_u32 v19, v19, v20, 1                                  ; d6450013 02062913
	v_xor_b32_e32 v21, v21, v4                                  ; 3a2a0915
	v_cvt_f32_u32_e32 v19, v19                                  ; 7e260d13
	v_dual_mul_f32 v8, 0xbfb17218, v8 :: v_dual_mul_f32 v13, s13, v13 ; c8c610ff 080c1a0d bfb17218
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d72c0015
	v_cndmask_b32_e32 v1, s12, v21, vcc_lo                      ; 02022a0c
	v_mul_f32_e32 v19, s13, v19                                 ; 1026260d
	v_cos_f32_e32 v23, v13                                      ; 7e2e6d0d
	v_sin_f32_e32 v13, v13                                      ; 7e1a6b0d
	v_sqrt_f32_e32 v8, v8                                       ; 7e106708
	v_log_f32_e32 v19, v19                                      ; 7e264f13
	v_lshrrev_b32_e32 v22, 8, v21                               ; 322c2a88
	v_lshrrev_b32_e32 v21, 30, v21                              ; 322a2a9e
	v_mul_f32_e32 v23, v8, v23                                  ; 102e2f08
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_xad_u32 v21, v21, v22, 1                                  ; d6450015 02062d15
	v_mul_f32_e32 v19, 0xbfb17218, v19                          ; 102626ff bfb17218
	v_fma_mixlo_f16 v2, s16, v23, neg(0) op_sel_hi:[0,0,1]      ; cc214002 82022e10
	v_cvt_f32_u32_e32 v21, v21                                  ; 7e2a0d15
	v_sqrt_f32_e32 v19, v19                                     ; 7e266713
	v_mul_f32_e32 v21, s13, v21                                 ; 102a2a0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_cos_f32_e32 v21, v21                                      ; 7e2a6d15
	v_dual_mul_f32 v19, v21, v19 :: v_dual_mul_f32 v8, v8, v13  ; c8c62715 13081b08
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_fma_mixlo_f16 v3, s16, v19, neg(0) op_sel_hi:[0,0,1]      ; cc214003 82022610
	v_fma_mixhi_f16 v2, s16, v8, neg(0) op_sel_hi:[0,0,1]       ; cc224002 82021010
BB18:
	v_and_b32_e32 v10, 3, v10                                   ; 36141483
(invalid instruction)                                        ; cc0f000f
	v_subrev_f32_e32 v0, v15, v241                              ; 0a01e30f
	v_bfe_u32 v11, v11, 2, 1                                    ; d610000b 0205050b
	v_add_f16_e32 v16, -0.5, v16                                ; 642020f1
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v3.h, v17.h                                   ; 7f063991
	v_mov_b32_e32 v13, s36                                      ; 7e1a0224
(invalid instruction)                                        ; cc100004
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 00003000
	v_dual_mov_b32 v15, s17 :: v_dual_mov_b32 v14, s38          ; ca100011 0f0e0026
	v_lshl_add_u32 v11, v11, 1, v6                              ; d646000b 0419030b
(invalid instruction)                                        ; 6b1820ff
(invalid instruction)                                        ; 00003000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_dual_mov_b32 v1, v4 :: v_dual_lshlrev_b32 v10, 2, v10     ; ca220104 010a1482
	v_lshl_add_u32 v11, v11, 4, v10                             ; d646000b 0429090b
	v_alignbyte_b32 v5, v1, v12, 2                              ; d6170005 020a1901
	v_mov_b16_e32 v12.l, v1.h                                   ; 7e183981
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d3
	v_add_lshl_u32 v11, v11, v7, 5                              ; d647000b 02160f0b
	ds_store_b128 v11, v[2:5]                                   ; db7c0000 0000020b
	ds_store_b128 v11, v[12:15] offset:16                       ; db7c0010 00000c0b
	s_load_b32 s11, s[14:15], 0x50                              ; f40002c7 f8000050
(invalid instruction)                                        ; d71f0002
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_and_b32_e32 v3, 15, v2                                    ; 3606048f
	v_lshrrev_b32_e32 v2, 4, v2                                 ; 32040484
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_lshlrev_b32_e32 v4, 4, v3                                 ; 30080684
	v_lshlrev_b32_e32 v2, 3, v2                                 ; 30040483
	v_add_lshl_u32 v6, v4, v2, 1                                ; d6470006 02060504
	ds_load_b64 v[8:9], v6                                      ; d9d80000 08000006
	ds_load_b64 v[10:11], v6 offset:8                           ; d9d80008 0a000006
	ds_load_b64 v[12:13], v6 offset:512                         ; d9d80200 0c000006
	ds_load_b64 v[14:15], v6 offset:520                         ; d9d80208 0e000006
	ds_load_b64 v[16:17], v6 offset:1024                        ; d9d80400 10000006
	ds_load_b64 v[18:19], v6 offset:1032                        ; d9d80408 12000006
	ds_load_b64 v[20:21], v6 offset:1536                        ; d9d80600 14000006
	ds_load_b64 v[22:23], v6 offset:1544                        ; d9d80608 16000006
	s_clause 0x1                                                ; bf850001
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_load_b128 s[16:19], s[0:1], 0x40                          ; f4004400 f8000040
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_add3_u32 v5, v2, s11, v4                                  ; d6550005 04101702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
	v_lshlrev_b32_e32 v5, 1, v5                                 ; 300a0a81
	buffer_load_b128 v[24:27], v5, s[16:19], null offen         ; c405c07c 40802018 00000005
	s_cmp_eq_i32 s12, 0                                         ; bf00800c
	s_wait_loadcnt_dscnt 0x6                                    ; bfc80006
	v_wmma_f32_16x16x16_f16 v[32:39], v[24:27], v[8:11], 0      ; cc404020 1a021118
	v_cvt_f16_f32_e32 v7, v32                                   ; 7e0e1520
	v_cvt_f16_f32_e32 v24, v34                                  ; 7e301522
(invalid instruction)                                        ; 7f301523
(invalid instruction)                                        ; 7f0e1521
	v_cvt_f16_f32_e32 v25, v36                                  ; 7e321524
	v_cvt_f16_f32_e32 v26, v38                                  ; 7e341526
(invalid instruction)                                        ; 7f341527
(invalid instruction)                                        ; 7f321525
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB23                                         ; bfa1000f
BB19:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB22                                         ; bfa10007
BB20:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB22:
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v7, 0               ; ca100080 18060080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v25, 0              ; ca100080 1a180080
	s_branch BB24                                               ; bfa00001
BB23:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB24:
	buffer_load_b128 v[28:31], v5, s[16:19], null offen offset:512 ; c405c07c 4080201c 00020005
	v_cvt_f32_f16_e32 v1, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e021787
	v_cvt_f32_f16_e32 v6, v7                                    ; 7e0c1707
	v_cvt_f32_f16_e32 v27, v152/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e361798
	v_cvt_f32_f16_e32 v33, v24                                  ; 7e421718
	v_cvt_f32_f16_e32 v34, v153/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e441799
	v_cvt_f32_f16_e32 v35, v25                                  ; 7e461719
	v_cvt_f32_f16_e32 v36, v154/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e48179a
	v_cvt_f32_f16_e32 v37, v26                                  ; 7e4a171a
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v33, v27, vcc_lo                      ; 02023721
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v37, v36, vcc_lo                      ; 02024925
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[40:47], v[28:31], v[8:11], 0      ; cc404028 1a02111c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v39, v42                                  ; 7e4e152a
(invalid instruction)                                        ; 7f4e152b
	v_cvt_f16_f32_e32 v38, v40                                  ; 7e4c1528
	v_cvt_f16_f32_e32 v40, v44                                  ; 7e50152c
(invalid instruction)                                        ; 7f50152d
(invalid instruction)                                        ; 7f4c1529
	v_cvt_f16_f32_e32 v41, v46                                  ; 7e52152e
(invalid instruction)                                        ; 7f52152f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB29                                         ; bfa1000f
BB25:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB28                                         ; bfa10007
BB26:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB28:
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	s_branch BB30                                               ; bfa00001
BB29:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB30:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen          ; c405c07c 40802008 00000005
	v_cvt_f32_f16_e32 v1, v166/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217a6
	v_cvt_f32_f16_e32 v6, v38                                   ; 7e0c1726
	v_cvt_f32_f16_e32 v27, v167/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3617a7
	v_cvt_f32_f16_e32 v29, v39                                  ; 7e3a1727
	v_cvt_f32_f16_e32 v30, v168/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3c17a8
	v_cvt_f32_f16_e32 v31, v40                                  ; 7e3e1728
	v_cvt_f32_f16_e32 v34, v169/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417a9
	v_cvt_f32_f16_e32 v35, v41                                  ; 7e461729
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v29, v27, vcc_lo                      ; 0202371d
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v31, v30, vcc_lo                      ; 02023d1f
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt_dscnt 0x4                                    ; bfc80004
	v_wmma_f32_16x16x16_f16 v[48:55], v[8:11], v[12:15], 0      ; cc404030 1a021908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v37, v50                                  ; 7e4a1532
(invalid instruction)                                        ; 7f4a1533
	v_cvt_f16_f32_e32 v42, v52                                  ; 7e541534
(invalid instruction)                                        ; 7f541535
	v_cvt_f16_f32_e32 v43, v54                                  ; 7e561536
(invalid instruction)                                        ; 7f561537
	v_cvt_f16_f32_e32 v36, v48                                  ; 7e481530
(invalid instruction)                                        ; 7f481531
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB35                                         ; bfa1000f
BB31:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB34                                         ; bfa10007
BB32:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB34:
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	s_branch BB36                                               ; bfa00001
BB35:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB36:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen offset:512 ; c405c07c 40802008 00020005
	v_cvt_f32_f16_e32 v1, v164/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217a4
	v_cvt_f32_f16_e32 v6, v36                                   ; 7e0c1724
	v_cvt_f32_f16_e32 v27, v165/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3617a5
	v_cvt_f32_f16_e32 v31, v37                                  ; 7e3e1725
	v_cvt_f32_f16_e32 v34, v170/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417aa
	v_cvt_f32_f16_e32 v35, v42                                  ; 7e46172a
	v_cvt_f32_f16_e32 v44, v171/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e5817ab
	v_cvt_f32_f16_e32 v45, v43                                  ; 7e5a172b
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v31, v27, vcc_lo                      ; 0202371f
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v45, v44, vcc_lo                      ; 0202592d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[48:55], v[8:11], v[12:15], 0      ; cc404030 1a021908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v47, v50                                  ; 7e5e1532
(invalid instruction)                                        ; 7f5e1533
	v_cvt_f16_f32_e32 v46, v48                                  ; 7e5c1530
	v_cvt_f16_f32_e32 v48, v52                                  ; 7e601534
(invalid instruction)                                        ; 7f601535
(invalid instruction)                                        ; 7f5c1531
	v_cvt_f16_f32_e32 v49, v54                                  ; 7e621536
(invalid instruction)                                        ; 7f621537
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB41                                         ; bfa1000f
BB37:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB40                                         ; bfa10007
BB38:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB40:
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	s_branch BB42                                               ; bfa00001
BB41:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB42:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen          ; c405c07c 40802008 00000005
	v_cvt_f32_f16_e32 v1, v174/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217ae
	v_cvt_f32_f16_e32 v6, v46                                   ; 7e0c172e
	v_cvt_f32_f16_e32 v13, v175/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1a17af
	v_cvt_f32_f16_e32 v14, v47                                  ; 7e1c172f
	v_cvt_f32_f16_e32 v15, v176/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e17b0
	v_cvt_f32_f16_e32 v27, v48                                  ; 7e361730
	v_cvt_f32_f16_e32 v34, v177/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417b1
	v_cvt_f32_f16_e32 v35, v49                                  ; 7e461731
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v14, v13, vcc_lo                      ; 02021b0e
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v27, v15, vcc_lo                      ; 02021f1b
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt_dscnt 0x2                                    ; bfc80002
	v_wmma_f32_16x16x16_f16 v[56:63], v[8:11], v[16:19], 0      ; cc404038 1a022108
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v45, v58                                  ; 7e5a153a
(invalid instruction)                                        ; 7f5a153b
	v_cvt_f16_f32_e32 v50, v60                                  ; 7e64153c
(invalid instruction)                                        ; 7f64153d
	v_cvt_f16_f32_e32 v51, v62                                  ; 7e66153e
(invalid instruction)                                        ; 7f66153f
	v_cvt_f16_f32_e32 v44, v56                                  ; 7e581538
(invalid instruction)                                        ; 7f581539
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB47                                         ; bfa1000f
BB43:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB46                                         ; bfa10007
BB44:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB46:
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	s_branch BB48                                               ; bfa00001
BB47:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB48:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen offset:512 ; c405c07c 40802008 00020005
	v_cvt_f32_f16_e32 v1, v172/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217ac
	v_cvt_f32_f16_e32 v6, v44                                   ; 7e0c172c
	v_cvt_f32_f16_e32 v15, v173/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e17ad
	v_cvt_f32_f16_e32 v27, v45                                  ; 7e36172d
	v_cvt_f32_f16_e32 v34, v178/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417b2
	v_cvt_f32_f16_e32 v35, v50                                  ; 7e461732
	v_cvt_f32_f16_e32 v52, v179/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e6817b3
	v_cvt_f32_f16_e32 v53, v51                                  ; 7e6a1733
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v27, v15, vcc_lo                      ; 02021f1b
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v53, v52, vcc_lo                      ; 02026935
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[56:63], v[8:11], v[16:19], 0      ; cc404038 1a022108
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v55, v58                                  ; 7e6e153a
(invalid instruction)                                        ; 7f6e153b
	v_cvt_f16_f32_e32 v54, v56                                  ; 7e6c1538
	v_cvt_f16_f32_e32 v56, v60                                  ; 7e70153c
(invalid instruction)                                        ; 7f70153d
(invalid instruction)                                        ; 7f6c1539
	v_cvt_f16_f32_e32 v57, v62                                  ; 7e72153e
(invalid instruction)                                        ; 7f72153f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB53                                         ; bfa1000f
BB49:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB52                                         ; bfa10007
BB50:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB52:
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	s_branch BB54                                               ; bfa00001
BB53:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB54:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen          ; c405c07c 40802008 00000005
	v_cvt_f32_f16_e32 v1, v182/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217b6
	v_cvt_f32_f16_e32 v6, v54                                   ; 7e0c1736
	v_cvt_f32_f16_e32 v17, v183/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2217b7
	v_cvt_f32_f16_e32 v18, v55                                  ; 7e241737
	v_cvt_f32_f16_e32 v19, v184/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2617b8
	v_cvt_f32_f16_e32 v27, v56                                  ; 7e361738
	v_cvt_f32_f16_e32 v34, v185/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417b9
	v_cvt_f32_f16_e32 v35, v57                                  ; 7e461739
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v18, v17, vcc_lo                      ; 02022312
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v27, v19, vcc_lo                      ; 0202271b
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_f16 v[64:71], v[8:11], v[20:23], 0      ; cc404040 1a022908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v53, v66                                  ; 7e6a1542
(invalid instruction)                                        ; 7f6a1543
	v_cvt_f16_f32_e32 v58, v68                                  ; 7e741544
(invalid instruction)                                        ; 7f741545
	v_cvt_f16_f32_e32 v59, v70                                  ; 7e761546
(invalid instruction)                                        ; 7f761547
	v_cvt_f16_f32_e32 v52, v64                                  ; 7e681540
(invalid instruction)                                        ; 7f681541
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB59                                         ; bfa1000f
BB55:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB58                                         ; bfa10007
BB56:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB58:
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	s_branch BB60                                               ; bfa00001
BB59:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB60:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen offset:512 ; c405c07c 40802008 00020005
	v_cvt_f32_f16_e32 v1, v180/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217b4
	v_cvt_f32_f16_e32 v5, v52                                   ; 7e0a1734
	v_cvt_f32_f16_e32 v6, v181/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0c17b5
	v_cvt_f32_f16_e32 v19, v53                                  ; 7e261735
	v_cvt_f32_f16_e32 v27, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3617ba
	v_cvt_f32_f16_e32 v34, v58                                  ; 7e44173a
	v_cvt_f32_f16_e32 v35, v187/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4617bb
	v_cvt_f32_f16_e32 v60, v59                                  ; 7e78173b
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                        ; 02020305
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v19, v6, vcc_lo                       ; 02020d13
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v34, v27, vcc_lo                      ; 02023722
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v60, v35, vcc_lo                      ; 0202473c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[64:71], v[8:11], v[20:23], 0      ; cc404040 1a022908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v62, v66                                  ; 7e7c1542
(invalid instruction)                                        ; 7f7c1543
	v_cvt_f16_f32_e32 v63, v68                                  ; 7e7e1544
(invalid instruction)                                        ; 7f7e1545
	v_cvt_f16_f32_e32 v61, v64                                  ; 7e7a1540
	v_cvt_f16_f32_e32 v64, v70                                  ; 7e801546
(invalid instruction)                                        ; 7f801547
(invalid instruction)                                        ; 7f7a1541
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB66                                         ; bfa1000d
BB61:
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB64                                         ; bfa10007
BB62:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB64:
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v61, 0              ; ca100080 3e3c0080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v63, 0              ; ca100080 403e0080
BB66:
	v_lshlrev_b32_e32 v1, 2, v0                                 ; 30020082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v5, s3, v1, 2                                ; d6470005 020a0203
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[8:11], v5, s[16:19], null offen          ; c405c07c 40802008 00000005
	buffer_load_b128 v[20:23], v5, s[16:19], null offen offset:512 ; c405c07c 40802014 00020005
	buffer_load_b128 v[68:71], v5, s[16:19], null offen offset:1024 ; c405c07c 40802044 00040005
	buffer_load_b128 v[72:75], v5, s[16:19], null offen offset:1536 ; c405c07c 40802048 00060005
	buffer_load_b128 v[76:79], v5, s[16:19], null offen offset:2048 ; c405c07c 4080204c 00080005
	buffer_load_b128 v[80:83], v5, s[16:19], null offen offset:2560 ; c405c07c 40802050 000a0005
	v_cvt_f32_f16_e32 v6, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0c17bd
	v_cvt_f32_f16_e32 v27, v61                                  ; 7e36173d
	v_cvt_f32_f16_e32 v35, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4617be
	v_cvt_f32_f16_e32 v60, v62                                  ; 7e78173e
	v_cvt_f32_f16_e32 v65, v191/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8217bf
	v_cvt_f32_f16_e32 v66, v63                                  ; 7e84173f
	v_cvt_f32_f16_e32 v67, v192/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8617c0
	v_cvt_f32_f16_e32 v84, v64                                  ; 7ea81740
	s_movk_i32 s3, 0x400                                        ; b0030400
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v27, v6, vcc_lo                       ; 02020d1b
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v60, v35, vcc_lo                      ; 0202473c
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v66, v65, vcc_lo                      ; 02028342
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v84, v67, vcc_lo                      ; 02028754
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[14:15], 0 ; cc464068 1a021d08
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[8:9], v[18:19], 0 ; cc464070 1a022508
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[30:31], 0  ; cc464060 1a023d08
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[32:33], 0   ; cc464058 1a024108
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[32:33], 0 ; cc464078 1a02410a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[30:31], 0 ; cc464080 1a023d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[14:15], 0 ; cc464088 1a021d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[10:11], v[18:19], 0 ; cc464090 1a02250a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[12:13], v[96:103] ; cc464060 1d821914
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[28:29], v[88:95] ; cc464058 1d623914
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[20:21], v[16:17], v[104:111] ; cc464068 1da22114
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[34:35], v[112:119] ; cc464070 1dc24514
	v_maxmin_num_f32 v157, -4.0, v92, 4.0                       ; d669009d 03dab8f7
	v_maxmin_num_f32 v155, -4.0, v91, 4.0                       ; d669009b 03dab6f7
	v_maxmin_num_f32 v159, -4.0, v93, 4.0                       ; d669009f 03dabaf7
	v_maxmin_num_f32 v153, -4.0, v90, 4.0                       ; d6690099 03dab4f7
	v_maxmin_num_f32 v85, -4.0, v88, 4.0                        ; d6690055 03dab0f7
	v_maxmin_num_f32 v87, -4.0, v89, 4.0                        ; d6690057 03dab2f7
	v_maxmin_num_f32 v161, -4.0, v94, 4.0                       ; d66900a1 03dabcf7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v95, 4.0                       ; d66900a3 03dabef7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v96, 4.0                       ; d66900a5 03dac0f7
	v_fma_mix_f32 v152, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bfeaeff 3728ab28
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v97, 4.0                       ; d66900a7 03dac2f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 ; c843419f 9f9f3b9e 3f650000
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c843379c 9c993599 3f650000
	v_maxmin_num_f32 v169, -4.0, v98, 4.0                       ; d66900a9 03dac4f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v99, 4.0                       ; d66900ab 03dac6f7
	v_dual_fmaak_f32 v152, v152, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af98 9854ad55 3f650000
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c84349a3 a3a343a2 3f650000
	v_dual_mul_f32 v93, v93, v159 :: v_dual_mul_f32 v92, v92, v158 ; c8c73f5d 5d5d3d5c
	v_maxmin_num_f32 v173, -4.0, v100, 4.0                      ; d66900ad 03dac8f7
	v_dual_mul_f32 v91, v91, v156 :: v_dual_mul_f32 v90, v90, v153 ; c8c7395b 5b5b335a
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_maxmin_num_f32 v175, -4.0, v101, 4.0                      ; d66900af 03dacaf7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_mul_f32 v89, v89, v152 :: v_dual_mul_f32 v88, v88, v85 ; c8c73159 5958ab58
	v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 ; c8434da5 a5a94fa8 3f650000
	v_dual_mul_f32 v95, v95, v163 :: v_dual_mul_f32 v94, v94, v162 ; c8c7475f 5f5f455e
	v_maxmin_num_f32 v177, -4.0, v102, 4.0                      ; d66900b1 03daccf7
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_maxmin_num_f32 v179, -4.0, v103, 4.0                      ; d66900b3 03dacef7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 ; c84355a9 a9ad57ac 3f650000
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_dual_mul_f32 v97, v97, v168 :: v_dual_mul_f32 v96, v96, v165 ; c8c75161 61614b60
	v_maxmin_num_f32 v181, -4.0, v104, 4.0                      ; d66900b5 03dad0f7
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v183, -4.0, v105, 4.0                      ; d66900b7 03dad2f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v173, 0x3f650000 ; c84361af afaf5bae 3f650000
	v_maxmin_num_f32 v185, -4.0, v106, 4.0                      ; d66900b9 03dad4f7
	v_dual_mul_f32 v99, v99, v172 :: v_dual_mul_f32 v98, v98, v169 ; c8c75963 63635362
	v_maxmin_num_f32 v187, -4.0, v107, 4.0                      ; d66900bb 03dad6f7
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v108, 4.0                      ; d66900bd 03dad8f7
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_dual_fmaak_f32 v179, v179, v180, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v177, 0x3f650000 ; c84369b3 b3b363b2 3f650000
	v_dual_mul_f32 v101, v101, v175 :: v_dual_mul_f32 v100, v100, v174 ; c8c75f65 65655d64
	v_maxmin_num_f32 v191, -4.0, v109, 4.0                      ; d66900bf 03dadaf7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v27, -4.0, v110, 4.0                       ; d669001b 03dadcf7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_maxmin_num_f32 v65, -4.0, v111, 4.0                       ; d6690041 03dadef7
	v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 ; c8436db5 b5b96fb8 3f650000
	v_dual_mul_f32 v103, v103, v179 :: v_dual_mul_f32 v102, v102, v178 ; c8c76767 67676566
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v6, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206206 0bff7eff 3728ab28
	v_maxmin_num_f32 v67, -4.0, v112, 4.0                       ; d6690043 03dae0f7
	v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 ; c84375b9 b9bd77bc 3f650000
	v_fma_mix_f32 v60, 0xab28, |v27|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623c 0bfe36ff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v113, 4.0                       ; d6690055 03dae2f7
	v_fma_mix_f32 v66, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206242 0bfe82ff 3728ab28
	v_dual_mul_f32 v105, v105, v184 :: v_dual_mul_f32 v104, v104, v181 ; c8c77169 69696b68
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v87, -4.0, v114, 4.0                       ; d6690057 03dae4f7
	v_dual_fmaak_f32 v191, v191, v6, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c8420dbf bfbf7bbe 3f650000
	v_fma_mix_f32 v84, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfe86ff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v115, 4.0                       ; d6690059 03dae6f7
	v_dual_mul_f32 v107, v107, v188 :: v_dual_mul_f32 v106, v106, v185 ; c8c7796b 6b6b736a
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_dual_fmaak_f32 v65, v65, v66, 0x3f650000 :: v_dual_fmaak_f32 v60, v60, v27, 0x3f650000 ; c8428541 413c373c 3f650000
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v91, -4.0, v116, 4.0                       ; d669005b 03dae8f7
	v_maxmin_num_f32 v93, -4.0, v117, 4.0                       ; d669005d 03daeaf7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_mul_f32 v109, v109, v191 :: v_dual_mul_f32 v108, v108, v190 ; c8c77f6d 6d6d7d6c
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v95, -4.0, v118, 4.0                       ; d669005f 03daecf7
	v_dual_fmaak_f32 v67, v67, v84, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842a943 4356ab56 3f650000
	v_dual_mul_f32 v111, v111, v65 :: v_dual_mul_f32 v110, v110, v60 ; c8c6836f 6f6e796e
	v_maxmin_num_f32 v97, -4.0, v119, 4.0                       ; d6690061 03daeef7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[28:29], v[120:127] ; cc464078 1de23916
	v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b157 575ab35a 3f650000
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_dual_mul_f32 v113, v113, v86 :: v_dual_mul_f32 v112, v112, v67 ; c8c6ad71 71708770
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842bd5d 5d5cb75c 3f650000
	v_dual_mul_f32 v115, v115, v90 :: v_dual_mul_f32 v114, v114, v87 ; c8c6b573 7372af72
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842c561 6160bf60 3f650000
	v_dual_mul_f32 v117, v117, v93 :: v_dual_mul_f32 v116, v116, v92 ; c8c6bb75 7574b974
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[12:13], v[128:135] ; cc464080 1e021916
	v_maxmin_num_f32 v103, -4.0, v122, 4.0                      ; d6690067 03daf4f7
	v_maxmin_num_f32 v105, -4.0, v123, 4.0                      ; d6690069 03daf6f7
	v_maxmin_num_f32 v101, -4.0, v121, 4.0                      ; d6690065 03daf2f7
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v99, -4.0, v120, 4.0                       ; d6690063 03daf0f7
	v_dual_mul_f32 v119, v119, v97 :: v_dual_mul_f32 v118, v118, v96 ; c8c6c377 7776c176
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[16:17], v[136:143] ; cc464088 1e222116
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[22:23], v[34:35], v[144:151] ; cc464090 1e424516
	v_maxmin_num_f32 v107, -4.0, v124, 4.0                      ; d669006b 03daf8f7
	v_maxmin_num_f32 v109, -4.0, v125, 4.0                      ; d669006d 03dafaf7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v111, -4.0, v126, 4.0                      ; d669006f 03dafcf7
	v_maxmin_num_f32 v113, -4.0, v127, 4.0                      ; d6690071 03dafef7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_maxmin_num_f32 v115, -4.0, v128, 4.0                      ; d6690073 03db00f7
	v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 ; c842d167 676ad36a 3f650000
	v_maxmin_num_f32 v117, -4.0, v129, 4.0                      ; d6690075 03db02f7
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c842c963 6366cb66 3f650000
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v130, 4.0                      ; d6690077 03db04f7
	v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 ; c842dd6d 6d6cd76c 3f650000
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_dual_mul_f32 v123, v123, v106 :: v_dual_mul_f32 v122, v122, v103 ; c8c6d57b 7b7acf7a
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_dual_mul_f32 v121, v121, v102 :: v_dual_mul_f32 v120, v120, v99 ; c8c6cd79 7978c778
	v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 ; c842e571 7170df70 3f650000
	v_dual_mul_f32 v125, v125, v109 :: v_dual_mul_f32 v124, v124, v108 ; c8c6db7d 7d7cd97c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v115, v115, v116, 0x3f650000 :: v_dual_fmaak_f32 v118, v118, v117, 0x3f650000 ; c842e973 7376eb76 3f650000
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v121, -4.0, v131, 4.0                      ; d6690079 03db06f7
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v123, -4.0, v132, 4.0                      ; d669007b 03db08f7
	v_dual_mul_f32 v127, v127, v113 :: v_dual_mul_f32 v126, v126, v112 ; c8c6e37f 7f7ee17e
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v125, -4.0, v133, 4.0                      ; d669007d 03db0af7
	v_dual_mul_f32 v129, v129, v118 :: v_dual_mul_f32 v128, v128, v115 ; c8c6ed81 8180e780
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v127, -4.0, v134, 4.0                      ; d669007f 03db0cf7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v129, -4.0, v135, 4.0                      ; d6690081 03db0ef7
	v_dual_fmaak_f32 v119, v119, v120, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f177 777af37a 3f650000
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c842fd7d 7d7cf77c 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_mul_f32 v131, v131, v122 :: v_dual_mul_f32 v130, v130, v119 ; c8c6f583 8382ef82
	v_dual_mul_f32 v133, v133, v125 :: v_dual_mul_f32 v132, v132, v124 ; c8c6fb85 8584f984
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v131, -4.0, v136, 4.0                      ; d6690083 03db10f7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v133, -4.0, v137, 4.0                      ; d6690085 03db12f7
	v_maxmin_num_f32 v153, -4.0, v140, 4.0                      ; d6690099 03db18f7
	v_maxmin_num_f32 v155, -4.0, v141, 4.0                      ; d669009b 03db1af7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 ; c8430581 8180ff80 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v142, 4.0                      ; d669009d 03db1cf7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_maxmin_num_f32 v159, -4.0, v143, 4.0                      ; d669009f 03db1ef7
	v_dual_mul_f32 v135, v135, v129 :: v_dual_mul_f32 v134, v134, v128 ; c8c70387 87870186
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v135, -4.0, v138, 4.0                      ; d6690087 03db14f7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v144, 4.0                      ; d66900a1 03db20f7
	v_maxmin_num_f32 v163, -4.0, v145, 4.0                      ; d66900a3 03db22f7
	v_dual_mul_f32 v141, v141, v155 :: v_dual_mul_f32 v140, v140, v154 ; c8c7378d 8d8d358c
	v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 ; c843419f 9f9f3b9e 3f650000
	v_maxmin_num_f32 v165, -4.0, v146, 4.0                      ; d66900a5 03db24f7
	v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 ; c8430b86 86830983 3f650000
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v147, 4.0                      ; d66900a7 03db26f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v159 :: v_dual_mul_f32 v142, v142, v158 ; c8c73f8f 8f8f3d8e
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_mul_f32 v137, v137, v134 :: v_dual_mul_f32 v136, v136, v131 ; c8c70d89 89890788
	v_maxmin_num_f32 v169, -4.0, v148, 4.0                      ; d66900a9 03db28f7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v149, 4.0                      ; d66900ab 03db2af7
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 ; c84345a1 a1a547a4 3f650000
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_maxmin_num_f32 v173, -4.0, v150, 4.0                      ; d66900ad 03db2cf7
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_maxmin_num_f32 v137, -4.0, v139, 4.0                      ; d6690089 03db16f7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 ; c8434da5 a5a94fa8 3f650000
	v_maxmin_num_f32 v175, -4.0, v151, 4.0                      ; d66900af 03db2ef7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_mul_f32 v145, v145, v164 :: v_dual_mul_f32 v144, v144, v161 ; c8c74991 91914390
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[32:33], 0 ; cc464060 1a024144
	v_fma_mix_f32 v152, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff12ff 3728ab28
	v_dual_mul_f32 v147, v147, v168 :: v_dual_mul_f32 v146, v146, v165 ; c8c75193 93934b92
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 ; c84359ab abab53aa 3f650000
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_dual_fmaak_f32 v152, v152, v137, 0x3f650000 :: v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 ; c8431398 98871187 3f650000
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v173, 0x3f650000 ; c84361af afaf5bae 3f650000
	v_dual_mul_f32 v149, v149, v171 :: v_dual_mul_f32 v148, v148, v170 ; c8c75795 95955594
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[28:29], v[96:103] ; cc464060 1d823948
	v_dual_mul_f32 v139, v139, v152 :: v_dual_mul_f32 v138, v138, v135 ; c8c7318b 8b8b0f8a
	v_dual_mul_f32 v151, v151, v175 :: v_dual_mul_f32 v150, v150, v174 ; c8c75f97 97975d96
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[30:31], 0 ; cc464068 1a023d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[68:69], v[14:15], 0 ; cc464070 1a021d44
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[18:19], 0 ; cc464078 1a022544
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_maxmin_num_f32 v181, -4.0, v98, 4.0                       ; d66900b5 03dac4f7
	v_maxmin_num_f32 v177, -4.0, v96, 4.0                       ; d66900b1 03dac0f7
	v_maxmin_num_f32 v183, -4.0, v99, 4.0                       ; d66900b7 03dac6f7
	v_maxmin_num_f32 v179, -4.0, v97, 4.0                       ; d66900b3 03dac2f7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[12:13], v[104:111] ; cc464068 1da21948
	v_maxmin_num_f32 v185, -4.0, v100, 4.0                      ; d66900b9 03dac8f7
	v_maxmin_num_f32 v187, -4.0, v101, 4.0                      ; d66900bb 03dacaf7
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[72:73], v[16:17], v[112:119] ; cc464070 1dc22148
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[34:35], v[120:127] ; cc464078 1de24548
	v_maxmin_num_f32 v189, -4.0, v102, 4.0                      ; d66900bd 03daccf7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v103, 4.0                      ; d66900bf 03dacef7
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c8436fb8 b8b56db5 3f650000
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 ; c84367b4 b4b165b1 3f650000
	v_maxmin_num_f32 v27, -4.0, v104, 4.0                       ; d669001b 03dad0f7
	v_maxmin_num_f32 v65, -4.0, v105, 4.0                       ; d6690041 03dad2f7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_maxmin_num_f32 v73, -4.0, v106, 4.0                       ; d6690049 03dad4f7
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84379bb bbbb73ba 3f650000
	v_fma_mix_f32 v6, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206206 0bff7eff 3728ab28
	v_dual_mul_f32 v99, v99, v184 :: v_dual_mul_f32 v98, v98, v181 ; c8c77163 63636b62
	v_maxmin_num_f32 v91, -4.0, v107, 4.0                       ; d669005b 03dad6f7
	v_dual_mul_f32 v97, v97, v180 :: v_dual_mul_f32 v96, v96, v177 ; c8c76961 61616360
	v_fma_mix_f32 v60, 0xab28, |v27|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623c 0bfe36ff 3728ab28
	v_fma_mix_f32 v72, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe82ff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v108, 4.0                       ; d669005d 03dad8f7
	v_fma_mix_f32 v90, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfe92ff 3728ab28
	v_dual_mul_f32 v101, v101, v187 :: v_dual_mul_f32 v100, v100, v186 ; c8c77765 65657564
	v_dual_fmaak_f32 v191, v191, v6, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c8420dbf bfbf7bbe 3f650000
	v_maxmin_num_f32 v95, -4.0, v109, 4.0                       ; d669005f 03dadaf7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_dual_fmaak_f32 v27, v27, v60, 0x3f650000 :: v_dual_fmaak_f32 v72, v72, v65, 0x3f650000 ; c842791b 1b488348 3f650000
	v_maxmin_num_f32 v97, -4.0, v110, 4.0                       ; d6690061 03dadcf7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v111, 4.0                       ; d6690063 03dadef7
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_mul_f32 v103, v103, v191 :: v_dual_mul_f32 v102, v102, v190 ; c8c77f67 67677d66
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_dual_fmaak_f32 v73, v73, v90, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842b549 495cb75c 3f650000
	v_maxmin_num_f32 v101, -4.0, v112, 4.0                      ; d6690065 03dae0f7
	v_dual_mul_f32 v105, v105, v72 :: v_dual_mul_f32 v104, v104, v27 ; c8c69169 69683768
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v103, -4.0, v113, 4.0                      ; d6690067 03dae2f7
	v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842c15f 5f5ebb5e 3f650000
	v_dual_mul_f32 v107, v107, v92 :: v_dual_mul_f32 v106, v106, v73 ; c8c6b96b 6b6a936a
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v105, -4.0, v114, 4.0                      ; d6690069 03dae4f7
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 ; c842c963 6362c362 3f650000
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_mul_f32 v109, v109, v95 :: v_dual_mul_f32 v108, v108, v94 ; c8c6bf6d 6d6cbd6c
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v107, -4.0, v115, 4.0                      ; d669006b 03dae6f7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_mul_f32 v111, v111, v99 :: v_dual_mul_f32 v110, v110, v98 ; c8c6c76f 6f6ec56e
	v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 ; c842cd65 6568cf68 3f650000
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v109, -4.0, v116, 4.0                      ; d669006d 03dae8f7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v111, -4.0, v117, 4.0                      ; d669006f 03daeaf7
	v_dual_mul_f32 v113, v113, v104 :: v_dual_mul_f32 v112, v112, v101 ; c8c6d171 7170cb70
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 ; c842d569 696cd76c 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v113, -4.0, v118, 4.0                      ; d6690071 03daecf7
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_dual_mul_f32 v115, v115, v108 :: v_dual_mul_f32 v114, v114, v105 ; c8c6d973 7372d372
	v_dual_fmaak_f32 v111, v111, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 ; c842e16f 6f6edb6e 3f650000
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v115, -4.0, v119, 4.0                      ; d6690073 03daeef7
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v122, 4.0                      ; d6690081 03daf4f7
	v_maxmin_num_f32 v131, -4.0, v123, 4.0                      ; d6690083 03daf6f7
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v110 ; c8c6df75 7574dd74
	v_maxmin_num_f32 v133, -4.0, v124, 4.0                      ; d6690085 03daf8f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v125, 4.0                      ; d6690087 03dafaf7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v117, -4.0, v120, 4.0                      ; d6690075 03daf0f7
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v137, -4.0, v126, 4.0                      ; d6690089 03dafcf7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v127, 4.0                      ; d669008b 03dafef7
	v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 ; c8430581 81850784 3f650000
	v_dual_fmaak_f32 v115, v115, v116, 0x3f650000 :: v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 ; c842e973 7372e372 3f650000
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 ; c8431187 87870b86 3f650000
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[32:33], 0 ; cc464060 1a024146
	v_dual_mul_f32 v123, v123, v132 :: v_dual_mul_f32 v122, v122, v129 ; c8c7097b 7b7b037a
	v_dual_mul_f32 v119, v119, v115 :: v_dual_mul_f32 v118, v118, v114 ; c8c6e777 7776e576
	v_dual_mul_f32 v125, v125, v135 :: v_dual_mul_f32 v124, v124, v134 ; c8c70f7d 7d7d0d7c
	v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 ; c843198b 8b8b138a 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v119, -4.0, v121, 4.0                      ; d6690077 03daf2f7
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_mul_f32 v127, v127, v139 :: v_dual_mul_f32 v126, v126, v138 ; c8c7177f 7f7f157e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[74:75], v[28:29], v[96:103] ; cc464060 1d82394a
	v_fma_mix_f32 v128, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfeeeff 3728ab28
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[30:31], 0 ; cc464068 1a023d46
	v_dual_fmaak_f32 v128, v128, v119, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842ef80 8074ed75 3f650000
	v_maxmin_num_f32 v143, -4.0, v97, 4.0                       ; d669008f 03dac2f7
	v_maxmin_num_f32 v145, -4.0, v98, 4.0                       ; d6690091 03dac4f7
	v_maxmin_num_f32 v147, -4.0, v99, 4.0                       ; d6690093 03dac6f7
	v_maxmin_num_f32 v141, -4.0, v96, 4.0                       ; d669008d 03dac0f7
	v_dual_mul_f32 v121, v121, v128 :: v_dual_mul_f32 v120, v120, v117 ; c8c70179 7978eb78
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[14:15], 0 ; cc464070 1a021d46
	v_maxmin_num_f32 v149, -4.0, v100, 4.0                      ; d6690095 03dac8f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[74:75], v[12:13], v[104:111] ; cc464068 1da2194a
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[18:19], 0 ; cc464078 1a022546
	v_maxmin_num_f32 v151, -4.0, v101, 4.0                      ; d6690097 03dacaf7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8432794 94912591 3f650000
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c8431f90 908d1d8d 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[16:17], v[112:119] ; cc464070 1dc2214a
	v_maxmin_num_f32 v153, -4.0, v102, 4.0                      ; d6690099 03daccf7
	v_maxmin_num_f32 v155, -4.0, v103, 4.0                      ; d669009b 03dacef7
	v_maxmin_num_f32 v157, -4.0, v104, 4.0                      ; d669009d 03dad0f7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_dual_mul_f32 v99, v99, v148 :: v_dual_mul_f32 v98, v98, v145 ; c8c72963 63632362
	v_dual_mul_f32 v97, v97, v144 :: v_dual_mul_f32 v96, v96, v141 ; c8c72161 61611b60
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[34:35], v[120:127] ; cc464078 1de2454a
	v_maxmin_num_f32 v159, -4.0, v105, 4.0                      ; d669009f 03dad2f7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v106, 4.0                      ; d66900a1 03dad4f7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_fmaak_f32 v151, v151, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v149, 0x3f650000 ; c8433197 97972b96 3f650000
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v163, -4.0, v107, 4.0                      ; d66900a3 03dad6f7
	v_maxmin_num_f32 v165, -4.0, v108, 4.0                      ; d66900a5 03dad8f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v109, 4.0                      ; d66900a7 03dadaf7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
	v_dual_mul_f32 v101, v101, v151 :: v_dual_mul_f32 v100, v100, v150 ; c8c72f65 65652d64
	v_maxmin_num_f32 v169, -4.0, v110, 4.0                      ; d66900a9 03dadcf7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v111, 4.0                      ; d66900ab 03dadef7
	v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 ; c8433d9d 9da13fa0 3f650000
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_mul_f32 v103, v103, v155 :: v_dual_mul_f32 v102, v102, v154 ; c8c73767 67673566
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v173, -4.0, v112, 4.0                      ; d66900ad 03dae0f7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 ; c84345a1 a1a547a4 3f650000
	v_maxmin_num_f32 v175, -4.0, v113, 4.0                      ; d66900af 03dae2f7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_mul_f32 v105, v105, v160 :: v_dual_mul_f32 v104, v104, v157 ; c8c74169 69693b68
	v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84351a7 a7a74ba6 3f650000
	v_maxmin_num_f32 v177, -4.0, v114, 4.0                      ; d66900b1 03dae4f7
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_maxmin_num_f32 v179, -4.0, v115, 4.0                      ; d66900b3 03dae6f7
	v_dual_mul_f32 v107, v107, v164 :: v_dual_mul_f32 v106, v106, v161 ; c8c7496b 6b6b436a
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 ; c84359ab abab53aa 3f650000
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v181, -4.0, v116, 4.0                      ; d66900b5 03dae8f7
	v_dual_mul_f32 v109, v109, v167 :: v_dual_mul_f32 v108, v108, v166 ; c8c74f6d 6d6d4d6c
	v_maxmin_num_f32 v183, -4.0, v117, 4.0                      ; d66900b7 03daeaf7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v185, -4.0, v118, 4.0                      ; d66900b9 03daecf7
	v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 ; c8435dad adb15fb0 3f650000
	v_dual_mul_f32 v111, v111, v171 :: v_dual_mul_f32 v110, v110, v170 ; c8c7576f 6f6f556e
	v_maxmin_num_f32 v187, -4.0, v119, 4.0                      ; d66900bb 03daeef7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v120, 4.0                      ; d66900bd 03daf0f7
	v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 ; c84365b1 b1b567b4 3f650000
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v121, 4.0                      ; d66900bf 03daf2f7
	v_dual_mul_f32 v113, v113, v176 :: v_dual_mul_f32 v112, v112, v173 ; c8c76171 71715b70
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v27, -4.0, v122, 4.0                       ; d669001b 03daf4f7
	v_dual_fmaak_f32 v183, v183, v184, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v181, 0x3f650000 ; c84371b7 b7b76bb6 3f650000
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_mul_f32 v115, v115, v180 :: v_dual_mul_f32 v114, v114, v177 ; c8c76973 73736372
	v_maxmin_num_f32 v98, -4.0, v124, 4.0                       ; d6690062 03daf8f7
	v_fma_mix_f32 v6, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206206 0bff7eff 3728ab28
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v65, -4.0, v123, 4.0                       ; d6690041 03daf6f7
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84379bb bbbb73ba 3f650000
	v_fma_mix_f32 v60, 0xab28, |v27|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623c 0bfe36ff 3728ab28
	v_dual_mul_f32 v117, v117, v183 :: v_dual_mul_f32 v116, v116, v182 ; c8c76f75 75756d74
	v_maxmin_num_f32 v100, -4.0, v125, 4.0                      ; d6690064 03dafaf7
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 :: v_dual_fmaak_f32 v6, v6, v191, 0x3f650000 ; c8437dbd bd077f06 3f650000
	v_maxmin_num_f32 v102, -4.0, v126, 4.0                      ; d6690066 03dafcf7
	v_fma_mix_f32 v97, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfe82ff 3728ab28
	v_maxmin_num_f32 v104, -4.0, v127, 4.0                      ; d6690068 03dafef7
	v_dual_mul_f32 v119, v119, v187 :: v_dual_mul_f32 v118, v118, v186 ; c8c77777 77777576
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_mul_f32_e32 v121, v121, v6                                ; 10f20d79
	v_dual_fmaak_f32 v27, v27, v60, 0x3f650000 :: v_dual_mul_f32 v120, v120, v189 ; c846791b 1b797b78 3f650000
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
(invalid instruction)                                        ; d7690060
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_mul_f32 v122, v122, v27 ; c846c563 637a377a 3f650000
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 ; c842cd67 6768d368 3f650000
	v_dual_mul_f32 v124, v124, v99 :: v_dual_fmaak_f32 v97, v97, v65, 0x3f650000 ; c8c2c77c 7c608361 3f650000
	v_dual_mul_f32 v127, v127, v104 :: v_dual_mul_f32 v126, v126, v103 ; c8c6d17f 7f7ecf7e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[76:77], v[32:33], 0 ; cc464068 1a02414c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[76:77], v[30:31], 0 ; cc464070 1a023d4c
	v_dual_mul_f32 v123, v97, v123 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c8c2f761 7b64cb64 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[18:19], 0 ; cc464080 1a02254c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[80:81], v[28:29], v[104:111] ; cc464068 1da23950
(invalid instruction)                                        ; d7694060
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[80:81], v[12:13], v[112:119] ; cc464070 1dc21950
	v_maxmin_num_f32 v140, -4.0, v106, 4.0                      ; d669008c 03dad4f7
	v_maxmin_num_f32 v144, -4.0, v108, 4.0                      ; d6690090 03dad8f7
	v_maxmin_num_f32 v136, -4.0, v104, 4.0                      ; d6690088 03dad0f7
	v_maxmin_num_f32 v138, -4.0, v105, 4.0                      ; d669008a 03dad2f7
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[34:35], v[128:135] ; cc464080 1e024550
	v_maxmin_num_f32 v142, -4.0, v107, 4.0                      ; d669008e 03dad6f7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v109, 4.0                      ; d6690092 03dadaf7
	v_maxmin_num_f32 v148, -4.0, v110, 4.0                      ; d6690094 03dadcf7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v111, 4.0                      ; d6690096 03dadef7
	v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 :: v_dual_mul_f32 v125, v125, v100 ; c8471388 887cc97d 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v112, 4.0                      ; d6690098 03dae0f7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_mul_f32 v104, v104, v136 :: v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 ; c8c31168 688b158b 3f650000
	v_maxmin_num_f32 v154, -4.0, v113, 4.0                      ; d669009a 03dae2f7
(invalid instruction)                                        ; d7690061
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694061
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[76:77], v[14:15], 0 ; cc464078 1a021d4c
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c8432792 92952995 3f650000
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v114, 4.0                      ; d669009c 03dae4f7
	v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 :: v_dual_mul_f32 v105, v105, v139 ; c8471b8c 8c691769 3f650000
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v116, 4.0                      ; d66900a0 03dae8f7
	v_maxmin_num_f32 v158, -4.0, v115, 4.0                      ; d669009e 03dae6f7
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_mul_f32 v109, v109, v146 ; c8472f96 966d256d 3f650000
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_mul_f32 v106, v140, v106 :: v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 ; c8c2d58c 6a912191 3f650000
	v_maxmin_num_f32 v162, -4.0, v117, 4.0                      ; d66900a2 03daeaf7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v118, 4.0                      ; d66900a4 03daecf7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[16:17], v[120:127] ; cc464078 1de22150
	v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 :: v_dual_mul_f32 v111, v111, v150 ; c8473398 986f2d6f 3f650000
	v_dual_mul_f32 v108, v108, v145 :: v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 ; c8c3236c 6c8f1d8f 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v119, 4.0                      ; d66900a6 03daeef7
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_mul_f32 v112, v112, v152 ; c847359b 9b713170 3f650000
	v_dual_mul_f32 v110, v110, v149 :: v_dual_mul_f32 v107, v107, v143 ; c8c72b6e 6e6b1f6b
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 ; c84347a2 a2a549a5 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v120, 4.0                      ; d66900a8 03daf0f7
	v_maxmin_num_f32 v170, -4.0, v121, 4.0                      ; d66900aa 03daf2f7
	v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 :: v_dual_mul_f32 v113, v113, v155 ; c8473b9c 9c713771 3f650000
	v_maxmin_num_f32 v172, -4.0, v122, 4.0                      ; d66900ac 03daf4f7
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v176, -4.0, v124, 4.0                      ; d66900b0 03daf8f7
	v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 :: v_dual_mul_f32 v117, v117, v162 ; c8474fa6 a6754575 3f650000
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_dual_fmaak_f32 v161, v160, v161, 0x3f650000 :: v_dual_mul_f32 v114, v114, v156 ; c84743a0 a1733972 3f650000
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v174, -4.0, v123, 4.0                      ; d66900ae 03daf6f7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v178, -4.0, v125, 4.0                      ; d66900b2 03dafaf7
	v_maxmin_num_f32 v180, -4.0, v126, 4.0                      ; d66900b4 03dafcf7
	v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 :: v_dual_mul_f32 v119, v119, v166 ; c84753a8 a8774d77 3f650000
	v_dual_mul_f32 v116, v116, v161 :: v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 ; c8c34374 749f3d9f 3f650000
	v_maxmin_num_f32 v182, -4.0, v127, 4.0                      ; d66900b6 03dafef7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v128, 4.0                      ; d66900b8 03db00f7
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_mul_f32 v120, v120, v168 ; c84755ab ab795178 3f650000
	v_dual_mul_f32 v118, v118, v165 :: v_dual_mul_f32 v115, v115, v159 ; c8c74b76 76733f73
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v186, -4.0, v129, 4.0                      ; d66900ba 03db02f7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 ; c84367b2 b2b569b5 3f650000
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	buffer_load_b128 v[100:103], v5, s[16:19], null offen offset:3072 ; c405c07c 40802064 000c0005
	v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 :: v_dual_mul_f32 v121, v121, v171 ; c8475bac ac795779 3f650000
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v188, -4.0, v130, 4.0                      ; d66900bc 03db04f7
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	buffer_load_b128 v[108:111], v5, s[16:19], null offen offset:3584 ; c405c07c 4080206c 000e0005
	v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 :: v_dual_mul_f32 v125, v125, v178 ; c8476fb6 b67d657d 3f650000
	v_maxmin_num_f32 v190, -4.0, v131, 4.0                      ; d66900be 03db06f7
(invalid instruction)                                        ; d7690062
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_fmaak_f32 v177, v176, v177, 0x3f650000 :: v_dual_mul_f32 v122, v122, v172 ; c84763b0 b17b597a 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v6, -4.0, v133, 4.0                        ; d6690006 03db0af7
	v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 :: v_dual_mul_f32 v127, v127, v182 ; c84773b8 b87f6d7f 3f650000
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_mul_f32 v124, v124, v177 :: v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 ; c8c3637c 7caf5daf 3f650000
	v_fmaak_f32 v188, v188, v189, 0x3f650000                    ; 5b797bbc 3f650000
	v_maxmin_num_f32 v60, -4.0, v134, 4.0                       ; d669003c 03db0cf7
	v_fma_mix_f32 v27, 0xab28, |v6|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe0cff 3728ab28
	v_maxmin_num_f32 v106, -4.0, v135, 4.0                      ; d669006a 03db0ef7
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_mul_f32 v128, v128, v184 ; c84775bb bb817180 3f650000
	v_fmaak_f32 v191, v191, v190, 0x3f650000                    ; 5b7f7dbf 3f650000
(invalid instruction)                                        ; d7690063
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_mul_f32 v126, v126, v181 :: v_dual_mul_f32 v123, v123, v175 ; c8c76b7e 7e7b5f7b
	v_fma_mix_f32 v65, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe78ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[78:79], v[32:33], 0 ; cc464070 1a02414e
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_dual_mul_f32 v130, v130, v188 :: v_dual_mul_f32 v129, v129, v187 ; c8c77982 82817781
	v_mul_f32_e32 v131, v131, v191                              ; 11077f83
	v_maxmin_num_f32 v191, -4.0, v132, 4.0                      ; d66900bf 03db08f7
(invalid instruction)                                        ; d7694063
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7694062
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_fmaak_f32 v65, v65, v60, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v107, 0x3f650000 ; c8427941 416ad76a 3f650000
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v135, v135, v106 :: v_dual_mul_f32 v134, v134, v65 ; c8c6d587 87868386
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[28:29], v[112:119] ; cc464070 1dc23952
	v_dual_fmaak_f32 v5, v191, v5, 0x3f650000 :: v_dual_fmaak_f32 v6, v6, v27, 0x3f650000 ; c8420bbf 05063706 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[78:79], v[30:31], 0 ; cc464078 1a023d4e
	v_dual_mul_f32 v133, v133, v6 :: v_dual_mul_f32 v132, v132, v5 ; c8c60d85 85840b84
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[78:79], v[18:19], 0 ; cc464088 1a02254e
	v_maxmin_num_f32 v146, -4.0, v113, 4.0                      ; d6690092 03dae2f7
	v_maxmin_num_f32 v144, -4.0, v112, 4.0                      ; d6690090 03dae0f7
	v_maxmin_num_f32 v148, -4.0, v114, 4.0                      ; d6690094 03dae4f7
	v_maxmin_num_f32 v150, -4.0, v115, 4.0                      ; d6690096 03dae6f7
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[78:79], v[14:15], 0 ; cc464080 1a021d4e
	v_maxmin_num_f32 v152, -4.0, v116, 4.0                      ; d6690098 03dae8f7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[82:83], v[12:13], v[120:127] ; cc464078 1de21952
	v_maxmin_num_f32 v154, -4.0, v117, 4.0                      ; d669009a 03daeaf7
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[82:83], v[34:35], v[136:143] ; cc464088 1e224552
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v118, 4.0                      ; d669009c 03daecf7
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[16:17], v[128:135] ; cc464080 1e022152
	v_maxmin_num_f32 v158, -4.0, v119, 4.0                      ; d669009e 03daeef7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_maxmin_num_f32 v160, -4.0, v120, 4.0                      ; d66900a0 03daf0f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v121, 4.0                      ; d66900a2 03daf2f7
	v_maxmin_num_f32 v164, -4.0, v122, 4.0                      ; d66900a4 03daf4f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8433199 999b379a 3f650000
	v_maxmin_num_f32 v166, -4.0, v123, 4.0                      ; d66900a6 03daf6f7
	v_dual_mul_f32 v113, v113, v147 :: v_dual_mul_f32 v112, v112, v144 ; c8c72771 71712170
	v_dual_mul_f32 v115, v115, v151 :: v_dual_mul_f32 v114, v114, v148 ; c8c72f73 73732972
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v124, 4.0                      ; d66900a8 03daf8f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c843399d 9d9f3f9e 3f650000
	v_maxmin_num_f32 v170, -4.0, v125, 4.0                      ; d66900aa 03dafaf7
	v_dual_mul_f32 v117, v117, v154 :: v_dual_mul_f32 v116, v116, v153 ; c8c73575 75753374
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
	v_maxmin_num_f32 v172, -4.0, v126, 4.0                      ; d66900ac 03dafcf7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v127, 4.0                      ; d66900ae 03dafef7
	v_dual_mul_f32 v119, v119, v158 :: v_dual_mul_f32 v118, v118, v157 ; c8c73d77 77773b76
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	v_maxmin_num_f32 v176, -4.0, v128, 4.0                      ; d66900b0 03db00f7
	v_dual_mul_f32 v121, v121, v163 :: v_dual_mul_f32 v120, v120, v160 ; c8c74779 79794178
	v_maxmin_num_f32 v178, -4.0, v129, 4.0                      ; d66900b2 03db02f7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v180, -4.0, v130, 4.0                      ; d66900b4 03db04f7
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84351a9 a9ab57aa 3f650000
	v_maxmin_num_f32 v182, -4.0, v131, 4.0                      ; d66900b6 03db06f7
	v_dual_mul_f32 v123, v123, v167 :: v_dual_mul_f32 v122, v122, v164 ; c8c74f7b 7b7b497a
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84359ad adaf5fae 3f650000
	v_maxmin_num_f32 v184, -4.0, v132, 4.0                      ; d66900b8 03db08f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v186, -4.0, v133, 4.0                      ; d66900ba 03db0af7
	v_dual_mul_f32 v125, v125, v170 :: v_dual_mul_f32 v124, v124, v169 ; c8c7557d 7d7d537c
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v188, -4.0, v134, 4.0                      ; d66900bc 03db0cf7
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84365b3 b3b163b0 3f650000
	v_maxmin_num_f32 v190, -4.0, v135, 4.0                      ; d66900be 03db0ef7
	v_dual_mul_f32 v127, v127, v174 :: v_dual_mul_f32 v126, v126, v173 ; c8c75d7f 7f7f5b7e
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c8436db7 b7b56bb4 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_mul_f32 v129, v129, v179 :: v_dual_mul_f32 v128, v128, v176 ; c8c76781 81816180
	v_maxmin_num_f32 v6, -4.0, v137, 4.0                        ; d6690006 03db12f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v60, -4.0, v138, 4.0                       ; d669003c 03db14f7
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84371b9 b9bb77ba 3f650000
	v_dual_mul_f32 v131, v131, v183 :: v_dual_mul_f32 v130, v130, v180 ; c8c76f83 83836982
	v_maxmin_num_f32 v113, -4.0, v139, 4.0                      ; d6690071 03db16f7
(invalid instruction)                                        ; d769006a
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_fma_mix_f32 v27, 0xab28, |v6|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe0cff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c84379bd bdbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v136, 4.0                      ; d66900bf 03db10f7
	v_maxmin_num_f32 v115, -4.0, v140, 4.0                      ; d6690073 03db18f7
	v_fma_mix_f32 v65, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe78ff 3728ab28
	v_dual_mul_f32 v133, v133, v186 :: v_dual_mul_f32 v132, v132, v185 ; c8c77585 85857384
	v_maxmin_num_f32 v117, -4.0, v141, 4.0                      ; d6690075 03db1af7
(invalid instruction)                                        ; d769406a
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v142, 4.0                      ; d6690077 03db1cf7
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v143, 4.0                      ; d6690079 03db1ef7
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_dual_fmaak_f32 v60, v60, v65, 0x3f650000 :: v_dual_fmaak_f32 v27, v27, v6, 0x3f650000 ; c842833c 3c1a0d1b 3f650000
(invalid instruction)                                        ; d769006b
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_dual_fmaak_f32 v191, v5, v191, 0x3f650000 :: v_dual_mul_f32 v134, v134, v189 ; c8477f05 bf877b86 3f650000
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 :: v_dual_mul_f32 v137, v137, v27 ; c846e372 72883789 3f650000
	v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 ; c842ed75 7574e774 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_mul_f32 v136, v136, v191 :: v_dual_mul_f32 v135, v135, v190 ; c8c77f88 88877d87
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 ; c842f579 7978ef78 3f650000
	v_dual_mul_f32 v139, v139, v114 :: v_dual_mul_f32 v138, v138, v60 ; c8c6e58b 8b8a798a
	v_dual_mul_f32 v140, v140, v116 :: v_dual_mul_f32 v141, v141, v117 ; c8c6e98c 8c8ceb8d
(invalid instruction)                                        ; d769406b
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690070
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_dual_mul_f32 v143, v143, v121 :: v_dual_mul_f32 v142, v142, v120 ; c8c6f38f 8f8ef18e
(invalid instruction)                                        ; d7694070
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690071
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7694071
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[100:101], v[30:31], 0 ; cc464080 1a023d64
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[18:19], 0 ; cc464090 1a022564
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[100:101], v[32:33], 0 ; cc464078 1a024164
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[100:101], v[14:15], 0 ; cc464088 1a021d64
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[108:109], v[12:13], v[128:135] ; cc464080 1e02196c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[34:35], v[144:151] ; cc464090 1e42456c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[108:109], v[28:29], v[120:127] ; cc464078 1de2396c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[16:17], v[136:143] ; cc464088 1e22216c
	v_maxmin_num_f32 v160, -4.0, v124, 4.0                      ; d66900a0 03daf8f7
	v_maxmin_num_f32 v158, -4.0, v123, 4.0                      ; d669009e 03daf6f7
	v_maxmin_num_f32 v162, -4.0, v125, 4.0                      ; d66900a2 03dafaf7
	v_maxmin_num_f32 v154, -4.0, v121, 4.0                      ; d669009a 03daf2f7
	v_maxmin_num_f32 v156, -4.0, v122, 4.0                      ; d669009c 03daf4f7
	v_maxmin_num_f32 v152, -4.0, v120, 4.0                      ; d6690098 03daf0f7
	v_maxmin_num_f32 v164, -4.0, v126, 4.0                      ; d66900a4 03dafcf7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v127, 4.0                      ; d66900a6 03dafef7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v128, 4.0                      ; d66900a8 03db00f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v170, -4.0, v129, 4.0                      ; d66900aa 03db02f7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84341a1 a1a347a2 3f650000
	v_maxmin_num_f32 v172, -4.0, v130, 4.0                      ; d66900ac 03db04f7
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_maxmin_num_f32 v174, -4.0, v131, 4.0                      ; d66900ae 03db06f7
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84349a5 a5a74fa6 3f650000
	v_dual_mul_f32 v125, v125, v162 :: v_dual_mul_f32 v124, v124, v161 ; c8c7457d 7d7d437c
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v132, 4.0                      ; d66900b0 03db08f7
	v_dual_mul_f32 v123, v123, v159 :: v_dual_mul_f32 v122, v122, v156 ; c8c73f7b 7b7b397a
	v_maxmin_num_f32 v178, -4.0, v133, 4.0                      ; d66900b2 03db0af7
	v_dual_mul_f32 v121, v121, v155 :: v_dual_mul_f32 v120, v120, v152 ; c8c73779 79793178
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c84355ab aba953a8 3f650000
	v_dual_mul_f32 v127, v127, v166 :: v_dual_mul_f32 v126, v126, v165 ; c8c74d7f 7f7f4b7e
	v_maxmin_num_f32 v180, -4.0, v134, 4.0                      ; d66900b4 03db0cf7
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v135, 4.0                      ; d66900b6 03db0ef7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694064
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 ; c8435daf afad5bac 3f650000
	v_dual_mul_f32 v129, v129, v171 :: v_dual_mul_f32 v128, v128, v168 ; c8c75781 81815180
	v_maxmin_num_f32 v184, -4.0, v136, 4.0                      ; d66900b8 03db10f7
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v186, -4.0, v137, 4.0                      ; d66900ba 03db12f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84361b1 b1b367b2 3f650000
	v_maxmin_num_f32 v188, -4.0, v138, 4.0                      ; d66900bc 03db14f7
	v_dual_mul_f32 v131, v131, v175 :: v_dual_mul_f32 v130, v130, v172 ; c8c75f83 83835982
	v_maxmin_num_f32 v190, -4.0, v139, 4.0                      ; d66900be 03db16f7
(invalid instruction)                                        ; d769006c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84369b5 b5b76fb6 3f650000
	v_maxmin_num_f32 v6, -4.0, v141, 4.0                        ; d6690006 03db1af7
	v_dual_mul_f32 v133, v133, v178 :: v_dual_mul_f32 v132, v132, v177 ; c8c76585 85856384
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
(invalid instruction)                                        ; d769406c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_maxmin_num_f32 v60, -4.0, v142, 4.0                       ; d669003c 03db1cf7
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84375bb bbb973b8 3f650000
	v_maxmin_num_f32 v116, -4.0, v143, 4.0                      ; d6690074 03db1ef7
	v_dual_mul_f32 v135, v135, v182 :: v_dual_mul_f32 v134, v134, v181 ; c8c76d87 87876b86
	v_fma_mix_f32 v27, 0xab28, |v6|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe0cff 3728ab28
(invalid instruction)                                        ; d769006d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8437dbf bfbd7bbc 3f650000
	v_maxmin_num_f32 v118, -4.0, v144, 4.0                      ; d6690076 03db20f7
	v_fma_mix_f32 v65, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe78ff 3728ab28
	v_maxmin_num_f32 v120, -4.0, v145, 4.0                      ; d6690078 03db22f7
	v_dual_mul_f32 v137, v137, v187 :: v_dual_mul_f32 v136, v136, v184 ; c8c77789 89897188
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d769406d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v139, v139, v191 :: v_dual_mul_f32 v138, v138, v188 ; c8c77f8b 8b8b798a
	s_load_b128 s[20:23], s[0:1], 0x30                          ; f4004500 f8000030
	v_maxmin_num_f32 v191, -4.0, v140, 4.0                      ; d66900bf 03db18f7
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_lshrrev_b32_e32 v122, 4, v0                               ; 32f40084
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_dual_fmaak_f32 v65, v65, v60, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c8427941 4174eb74 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_lshlrev_b32_e32 v122, 3, v122                             ; 30f4f483
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 ; c842f179 7976ef76 3f650000
	v_dual_mul_f32 v143, v143, v116 :: v_dual_mul_f32 v142, v142, v65 ; c8c6e98f 8f8e838e
(invalid instruction)                                        ; d7690072
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_maxmin_num_f32 v124, -4.0, v146, 4.0                      ; d669007c 03db24f7
	v_add_lshl_u32 v123, s8, v122, 2                            ; d647007b 020af408
	v_dual_mul_f32 v145, v145, v121 :: v_dual_mul_f32 v144, v144, v118 ; c8c6f391 9190ed90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_fmaak_f32 v124, v124, v125, 0x3f650000                    ; 5af8fb7c 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v146, v146, v124                              ; 1124f992
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[116:119], v123, s[20:23], null offen     ; c405c07c 40802874 0000007b
	buffer_load_b128 v[124:127], v123, s[20:23], null offen offset:16 ; c405c07c 4080287c 0000107b
(invalid instruction)                                        ; d7694072
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	v_maxmin_num_f32 v128, -4.0, v147, 4.0                      ; d6690080 03db26f7
	v_maxmin_num_f32 v130, -4.0, v148, 4.0                      ; d6690082 03db28f7
(invalid instruction)                                        ; d7690078
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v132, -4.0, v149, 4.0                      ; d6690084 03db2af7
	v_maxmin_num_f32 v134, -4.0, v150, 4.0                      ; d6690086 03db2cf7
	v_maxmin_num_f32 v136, -4.0, v151, 4.0                      ; d6690088 03db2ef7
	v_dual_fmaak_f32 v5, v191, v5, 0x3f650000 :: v_dual_fmaak_f32 v6, v6, v27, 0x3f650000 ; c8420bbf 05063706 3f650000
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v141, v141, v6 :: v_dual_mul_f32 v140, v140, v5 ; c8c60d8d 8d8c0b8c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[102:103], v[18:19], 0 ; cc464098 1a022566
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	v_fmaak_f32 v129, v129, v128, 0x3f650000                    ; 5b030181 3f650000
	v_add_lshl_u32 v160, s4, v1, 2                              ; d64700a0 020a0204
	buffer_load_b128 v[164:167], v160, s[16:19], null offen     ; c405c07c 408020a4 000000a0
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430583 83850b84 3f650000
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c8430d87 87891388 3f650000
(invalid instruction)                                        ; d7690073
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694073
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_mul_f32_e32 v147, v147, v129                              ; 11270393
	v_dual_mul_f32 v149, v149, v132 :: v_dual_mul_f32 v148, v148, v131 ; c8c70995 95950794
	v_dual_mul_f32 v151, v151, v136 :: v_dual_mul_f32 v150, v150, v135 ; c8c71197 97970f96
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[102:103], v[30:31], 0 ; cc464088 1a023d66
(invalid instruction)                                        ; d7694078
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690079
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[102:103], v[32:33], 0 ; cc464080 1a024166
(invalid instruction)                                        ; d7694079
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[102:103], v[14:15], 0 ; cc464090 1a021d66
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[110:111], v[12:13], v[136:143] ; cc464088 1e22196e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[110:111], v[16:17], v[144:151] ; cc464090 1e42216e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[12:15], v160, s[16:19], null offen offset:512 ; c405c07c 4080200c 000200a0
	buffer_load_b128 v[16:19], v160, s[16:19], null offen offset:1024 ; c405c07c 40802010 000400a0
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[110:111], v[34:35], v[152:159] ; cc464098 1e62456e
	buffer_load_b128 v[32:35], v160, s[16:19], null offen offset:1536 ; c405c07c 40802020 000600a0
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[110:111], v[28:29], v[128:135] ; cc464080 1e02396e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870241
	v_maxmin_num_f32 v169, -4.0, v130, 4.0                      ; d66900a9 03db04f7
	v_maxmin_num_f32 v161, -4.0, v128, 4.0                      ; d66900a1 03db00f7
	v_maxmin_num_f32 v171, -4.0, v131, 4.0                      ; d66900ab 03db06f7
	v_maxmin_num_f32 v163, -4.0, v129, 4.0                      ; d66900a3 03db02f7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_fma_mix_f32 v168, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff46ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
	v_fmaak_f32 v169, v169, v170, 0x3f650000                    ; 5b5355a9 3f650000
	v_maxmin_num_f32 v173, -4.0, v132, 4.0                      ; d66900ad 03db08f7
	v_fmaak_f32 v161, v161, v162, 0x3f650000                    ; 5b4345a1 3f650000
	v_fmaak_f32 v172, v172, v171, 0x3f650000                    ; 5b5957ac 3f650000
	v_fmaak_f32 v168, v168, v163, 0x3f650000                    ; 5b5147a8 3f650000
	v_mul_f32_e32 v128, v128, v161                              ; 11014380
	v_mul_f32_e32 v131, v131, v172                              ; 11075983
	v_maxmin_num_f32 v175, -4.0, v133, 4.0                      ; d66900af 03db0af7
	v_maxmin_num_f32 v177, -4.0, v134, 4.0                      ; d66900b1 03db0cf7
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_mul_f32 v129, v129, v168 :: v_dual_mul_f32 v130, v130, v169 ; c8c75181 81835382
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v179, -4.0, v135, 4.0                      ; d66900b3 03db0ef7
	v_fmaak_f32 v174, v174, v173, 0x3f650000                    ; 5b5d5bae 3f650000
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fmaak_f32 v178, v178, v177, 0x3f650000                    ; 5b6563b2 3f650000
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_dual_mul_f32 v132, v132, v174 :: v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 ; c8c35d84 84af61af 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmaak_f32 v179, v179, v180, 0x3f650000                    ; 5b6769b3 3f650000
	v_dual_mul_f32 v134, v134, v178 :: v_dual_mul_f32 v133, v133, v175 ; c8c76586 86855f85
	v_mul_f32_e32 v135, v135, v179                              ; 110f6787
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[128:131], v160, s[16:19], null offen offset:2048 ; c405c07c 40802080 000800a0
	buffer_load_b128 v[168:171], v160, s[16:19], null offen offset:2560 ; c405c07c 408020a8 000a00a0
	buffer_load_b128 v[172:175], v160, s[16:19], null offen offset:3072 ; c405c07c 408020ac 000c00a0
	buffer_load_b128 v[132:135], v160, s[16:19], null offen offset:3584 ; c405c07c 40802084 000e00a0
	v_maxmin_num_f32 v181, -4.0, v136, 4.0                      ; d66900b5 03db10f7
	v_maxmin_num_f32 v183, -4.0, v137, 4.0                      ; d66900b7 03db12f7
	v_maxmin_num_f32 v185, -4.0, v138, 4.0                      ; d66900b9 03db14f7
	v_maxmin_num_f32 v187, -4.0, v139, 4.0                      ; d66900bb 03db16f7
	v_maxmin_num_f32 v191, -4.0, v141, 4.0                      ; d66900bf 03db1af7
	v_maxmin_num_f32 v189, -4.0, v140, 4.0                      ; d66900bd 03db18f7
	v_maxmin_num_f32 v6, -4.0, v142, 4.0                        ; d6690006 03db1cf7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c8436fb8 b8b56db5 3f650000
	v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 ; c84375b9 b9bd77bc 3f650000
	v_maxmin_num_f32 v60, -4.0, v143, 4.0                       ; d669003c 03db1ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_mul_f32_e32 v137, v137, v184                              ; 11137189
	v_dual_fmaak_f32 v191, v5, v191, 0x3f650000 :: v_dual_mul_f32 v138, v138, v185 ; c8477f05 bf8b738a 3f650000
	v_dual_mul_f32 v139, v139, v188 :: v_dual_mul_f32 v136, v136, v181 ; c8c7798b 8b896b88
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[136:139], v123, s[20:23], null offen offset:64 ; c405c07c 40802888 0000407b
	buffer_load_b128 v[160:163], v123, s[20:23], null offen offset:80 ; c405c07c 408028a0 0000507b
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_fma_mix_f32 v27, 0xab28, |v6|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe0cff 3728ab28
	v_maxmin_num_f32 v102, -4.0, v144, 4.0                      ; d6690066 03db20f7
	v_maxmin_num_f32 v110, -4.0, v145, 4.0                      ; d669006e 03db22f7
	v_fma_mix_f32 v65, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe78ff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v146, 4.0                      ; d669007b 03db24f7
	v_dual_mul_f32 v141, v141, v191 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c8c37f8d 8dbf7bbe 3f650000
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fmaak_f32 v60, v60, v65, 0x3f650000                       ; 5a78833c 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v27, v6, v27, 0x3f650000 :: v_dual_mul_f32 v140, v140, v190 ; c8463706 1b8d7d8c 3f650000
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 ; c842dd6f 6f66cf66 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870152
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_maxmin_num_f32 v141, -4.0, v147, 4.0                      ; d669008d 03db26f7
	v_fma_mix_f32 v140, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bfef6ff 3728ab28
	v_dual_mul_f32 v142, v142, v27 :: v_dual_mul_f32 v143, v143, v60 ; c8c6378e 8e8e798f
	v_dual_mul_f32 v145, v145, v111 :: v_dual_mul_f32 v144, v144, v102 ; c8c6df91 9190cd90
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_maxmin_num_f32 v143, -4.0, v148, 4.0                      ; d669008f 03db28f7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v145, -4.0, v149, 4.0                      ; d6690091 03db2af7
	v_maxmin_num_f32 v177, -4.0, v152, 4.0                      ; d66900b1 03db30f7
	v_maxmin_num_f32 v179, -4.0, v153, 4.0                      ; d66900b3 03db32f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v140, 0x3f650000 ; c8431b8e 8e7b197b 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v181, -4.0, v154, 4.0                      ; d66900b5 03db34f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_maxmin_num_f32 v183, -4.0, v155, 4.0                      ; d66900b7 03db36f7
	v_dual_mul_f32 v147, v147, v142 :: v_dual_mul_f32 v146, v146, v123 ; c8c71d93 9392f792
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 ; c84365b1 b1b567b4 3f650000
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
(invalid instruction)                                        ; d7694066
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_maxmin_num_f32 v147, -4.0, v150, 4.0                      ; d6690093 03db2cf7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v156, 4.0                      ; d66900b9 03db38f7
	v_maxmin_num_f32 v187, -4.0, v157, 4.0                      ; d66900bb 03db3af7
	v_dual_mul_f32 v153, v153, v180 :: v_dual_mul_f32 v152, v152, v177 ; c8c76999 99996398
	v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 ; c8436db5 b5b96fb8 3f650000
	v_maxmin_num_f32 v189, -4.0, v158, 4.0                      ; d66900bd 03db3cf7
	v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 ; c8432591 91911f90 3f650000
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v159, 4.0                      ; d66900bf 03db3ef7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
(invalid instruction)                                        ; d769006e
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_dual_mul_f32 v155, v155, v184 :: v_dual_mul_f32 v154, v154, v181 ; c8c7719b 9b9b6b9a
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_mul_f32 v149, v149, v145 :: v_dual_mul_f32 v148, v148, v144 ; c8c72395 95952194
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	s_mov_b64 s[24:25], s[20:21]                                ; be980114
	s_mov_b64 s[26:27], s[22:23]                                ; be9a0116
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84379bb bbbb73ba 3f650000
(invalid instruction)                                        ; d769406e
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v149, -4.0, v151, 4.0                      ; d6690095 03db2ef7
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_dual_fmaak_f32 v191, v5, v191, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c8437f05 bfbf7bbe 3f650000
	v_dual_mul_f32 v157, v157, v187 :: v_dual_mul_f32 v156, v156, v186 ; c8c7779d 9d9d759c
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v176, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff2aff 3728ab28
	v_dual_mul_f32 v159, v159, v191 :: v_dual_mul_f32 v158, v158, v190 ; c8c77f9f 9f9f7d9e
(invalid instruction)                                        ; d769006f
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_fmaak_f32 v149, v149, v176, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 ; c8436195 95952794 3f650000
(invalid instruction)                                        ; d769406f
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_mul_f32 v151, v151, v149 :: v_dual_mul_f32 v150, v150, v148 ; c8c72b97 97972996
(invalid instruction)                                        ; d7694067
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mix_f32 v154, v37, v118, neg(0) op_sel_hi:[1,0,0]     ; cc20009a 8a02ed25
	v_fma_mix_f32 v145, v7, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a02eb07
	v_fma_mix_f32 v146, v24, v118, neg(0) op_sel_hi:[1,0,0]     ; cc200092 8a02ed18
	v_fma_mix_f32 v153, v36, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a02eb24
	v_fma_mix_f32 v144, v7, v116, neg(0) op_sel_hi:[1,0,0]      ; cc200090 8a02e907
	v_fma_mix_f32 v152, v36, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200098 8a02e924
	v_fma_mix_f32 v155, v37, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089b 8a02ef25
	v_fma_mix_f32 v147, v24, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200893 8a02ef18
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mix_f32 v159, v43, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089f 8a02ff2b
	v_fma_mix_f32 v176, v44, v116, neg(0) op_sel_hi:[1,0,0]     ; cc2000b0 8a02e92c
	v_fma_mix_f32 v156, v42, v124, neg(0) op_sel_hi:[1,0,0]     ; cc20009c 8a02f92a
	v_fma_mix_f32 v151, v26, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a02ff1a
	v_fma_mix_f32 v148, v25, v124, neg(0) op_sel_hi:[1,0,0]     ; cc200094 8a02f919
	v_fma_mix_f32 v150, v26, v126, neg(0) op_sel_hi:[1,0,0]     ; cc200096 8a02fd1a
	v_fma_mix_f32 v149, v25, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a02fb19
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_fma_mix_f32 v157, v42, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a02fb2a
	v_fma_mix_f32 v177, v44, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a02eb2c
	v_fma_mix_f32 v178, v45, v118, neg(0) op_sel_hi:[1,0,0]     ; cc2000b2 8a02ed2d
	v_fma_mix_f32 v179, v45, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a02ef2d
	v_fma_mix_f32 v184, v52, v116, neg(0) op_sel_hi:[1,0,0]     ; cc2000b8 8a02e934
	v_fma_mix_f32 v158, v43, v126, neg(0) op_sel_hi:[1,0,0]     ; cc20009e 8a02fd2b
	v_fma_mix_f32 v180, v50, v124, neg(0) op_sel_hi:[1,0,0]     ; cc2000b4 8a02f932
	v_fma_mix_f32 v181, v50, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a02fb32
	v_fma_mix_f32 v182, v51, v126, neg(0) op_sel_hi:[1,0,0]     ; cc2000b6 8a02fd33
	v_fma_mix_f32 v183, v51, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a02ff33
	v_fma_mix_f32 v185, v52, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a02eb34
	v_fma_mix_f32 v186, v53, v118, neg(0) op_sel_hi:[1,0,0]     ; cc2000ba 8a02ed35
	v_fma_mix_f32 v187, v53, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a02ef35
	v_fma_mix_f32 v188, v58, v124, neg(0) op_sel_hi:[1,0,0]     ; cc2000bc 8a02f93a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v6, s5, v1, 2                                ; d6470006 020a0205
	v_fma_mix_f32 v189, v58, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a02fb3a
	v_fma_mix_f32 v190, v59, v126, neg(0) op_sel_hi:[1,0,0]     ; cc2000be 8a02fd3b
	v_fma_mix_f32 v191, v59, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a02ff3b
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[164:165], v[66:67], v[184:191] ; cc4640b8 1ee285a4
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[24:27], v6, s[16:19], null offen         ; c405c07c 40802018 00000006
	buffer_load_b128 v[116:119], v6, s[16:19], null offen offset:1024 ; c405c07c 40802074 00040006
	buffer_load_b128 v[124:127], v6, s[16:19], null offen offset:2048 ; c405c07c 4080207c 00080006
	buffer_load_b128 v[140:143], v6, s[16:19], null offen offset:512 ; c405c07c 4080208c 00020006
	buffer_load_b128 v[42:45], v6, s[16:19], null offen offset:1536 ; c405c07c 4080202a 00060006
	buffer_load_b128 v[50:53], v6, s[16:19], null offen offset:2560 ; c405c07c 40802032 000a0006
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[164:165], v[10:11], v[152:159] ; cc464098 1e6215a4
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[164:165], v[8:9], v[144:151] ; cc464090 1e4211a4
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[12:13], v[88:89], v[184:191] ; cc4640b8 1ee2b10c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[12:13], v[22:23], v[144:151] ; cc464090 1e422d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[12:13], v[84:85], v[152:159] ; cc464098 1e62a90c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[16:17], v[92:93], v[184:191] ; cc4640b8 1ee2b910
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[16:17], v[68:69], v[144:151] ; cc464090 1e428910
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[72:73], v[152:159] ; cc464098 1e629110
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[32:33], v[96:97], v[184:191] ; cc4640b8 1ee2c120
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[32:33], v[70:71], v[144:151] ; cc464090 1e428d20
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[74:75], v[152:159] ; cc464098 1e629520
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[128:129], v[104:105], v[184:191] ; cc4640b8 1ee2d180
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[128:129], v[76:77], v[144:151] ; cc464090 1e429980
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[128:129], v[80:81], v[152:159] ; cc464098 1e62a180
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[168:169], v[112:113], v[184:191] ; cc4640b8 1ee2e1a8
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[168:169], v[78:79], v[144:151] ; cc464090 1e429da8
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[168:169], v[82:83], v[152:159] ; cc464098 1e62a5a8
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[172:173], v[120:121], v[184:191] ; cc4640b8 1ee2f1ac
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[172:173], v[100:101], v[144:151] ; cc464090 1e42c9ac
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[172:173], v[108:109], v[152:159] ; cc464098 1e62d9ac
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[132:133], v[110:111], v[184:191] ; cc4640b8 1ee2dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[132:133], v[28:29], v[144:151] ; cc464090 1e423984
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[132:133], v[30:31], v[152:159] ; cc464098 1e623d84
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[164:165], v[20:21], v[176:183] ; cc4640b0 1ec229a4
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[86:87], v[176:183] ; cc4640b0 1ec2ad0c
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mix_f32 v36, v38, v136, neg(0) op_sel_hi:[1,0,0]      ; cc200024 8a031126
	v_fma_mix_f32 v37, v38, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200825 8a031326
	v_fma_mix_f32 v38, v39, v138, neg(0) op_sel_hi:[1,0,0]      ; cc200026 8a031527
	v_fma_mix_f32 v39, v39, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200827 8a031727
	s_load_b32 s4, s[14:15], 0x24                               ; f4000107 f8000024
	s_bitset0_b32 s25, 14                                       ; be99108e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[90:91], v[176:183] ; cc4640b0 1ec2b510
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s4, s4, 2                                        ; 84048204
	s_buffer_load_b32 s4, s[24:27], s4 offset:0x0               ; f402010c 08000000
	v_fma_mix_f32 v164, v54, v136, neg(0) op_sel_hi:[1,0,0]     ; cc2000a4 8a031136
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[32:33], v[94:95], v[176:183] ; cc4640b0 1ec2bd20
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_fma_mix_f32 v165, v54, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a031336
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mix_f32 v58, v40, v160, neg(0) op_sel_hi:[1,0,0]      ; cc20003a 8a034128
	v_fma_mix_f32 v59, v40, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083b 8a034328
	v_fma_mix_f32 v60, v41, v162, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a034529
	v_fma_mix_f32 v41, v41, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200829 8a034729
	v_fma_mix_f32 v65, v46, v136, neg(0) op_sel_hi:[1,0,0]      ; cc200041 8a03112e
	v_fma_mix_f32 v46, v46, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082e 8a03132e
	v_fma_mix_f32 v136, v61, v136, neg(0) op_sel_hi:[1,0,0]     ; cc200088 8a03113d
	v_fma_mix_f32 v137, v61, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200889 8a03133d
	v_fma_mix_f32 v123, v47, v138, neg(0) op_sel_hi:[1,0,0]     ; cc20007b 8a03152f
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[128:129], v[98:99], v[176:183] ; cc4640b0 1ec2c580
	v_fma_mix_f32 v47, v47, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082f 8a03172f
	v_fma_mix_f32 v128, v48, v160, neg(0) op_sel_hi:[1,0,0]     ; cc200080 8a034130
	v_fma_mix_f32 v129, v48, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a034330
	v_fma_mix_f32 v5, v57, v162, neg(0) op_sel_hi:[1,0,0]       ; cc200005 8a034539
	v_fma_mix_f32 v57, v57, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200839 8a034739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870251
	v_swap_b32 v39, v57                                         ; 7e4ecb39
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[168:169], v[106:107], v[176:183] ; cc4640b0 1ec2d5a8
	v_fma_mix_f32 v168, v55, v138, neg(0) op_sel_hi:[1,0,0]     ; cc2000a8 8a031537
	v_fma_mix_f32 v169, v55, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a031737
	v_dual_mov_b32 v55, v37 :: v_dual_mov_b32 v54, v36          ; ca100125 37360124
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[114:115], v[176:183] ; cc4640b0 1ec2e5ac
	v_fma_mix_f32 v172, v56, v160, neg(0) op_sel_hi:[1,0,0]     ; cc2000ac 8a034138
	v_fma_mix_f32 v173, v56, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ad 8a034338
	v_dual_mov_b32 v61, v41 :: v_dual_mov_b32 v56, v38          ; ca100129 3d380126
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mov_b32 v38, v127 :: v_dual_mov_b32 v37, v126        ; ca10017f 2624017e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[166:167], v[8:9], v[54:61] ; cc464036 1cda11a6
	v_mov_b32_e32 v8, v35                                       ; 7e100323
	v_dual_mov_b32 v36, v125 :: v_dual_mov_b32 v35, v124        ; ca10017d 2422017c
	v_dual_mov_b32 v124, v65 :: v_dual_mov_b32 v125, v46        ; ca100141 7c7c012e
	v_dual_mov_b32 v126, v123 :: v_dual_mov_b32 v127, v47       ; ca10017b 7e7e012f
	v_fma_mix_f32 v138, v62, v138, neg(0) op_sel_hi:[1,0,0]     ; cc20008a 8a03153e
	v_fma_mix_f32 v139, v62, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088b 8a03173e
	v_fma_mix_f32 v160, v63, v160, neg(0) op_sel_hi:[1,0,0]     ; cc2000a0 8a03413f
	v_fma_mix_f32 v161, v63, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a1 8a03433f
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[132:133], v[102:103], v[176:183] ; cc4640b0 1ec2cd84
	v_fma_mix_f32 v132, v49, v162, neg(0) op_sel_hi:[1,0,0]     ; cc200084 8a034531
	v_fma_mix_f32 v133, v49, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200885 8a034731
	v_fma_mix_f32 v162, v64, v162, neg(0) op_sel_hi:[1,0,0]     ; cc2000a2 8a034540
	v_fma_mix_f32 v163, v64, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a3 8a034740
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mov_b32 v46, v140 :: v_dual_mov_b32 v47, v141        ; ca10018c 2e2e018d
	v_dual_mov_b32 v49, v143 :: v_dual_mov_b32 v48, v142        ; ca10018f 3130018e
	v_dual_mov_b32 v141, v161 :: v_dual_mov_b32 v140, v160      ; ca1001a1 8d8c01a0
	v_dual_mov_b32 v9, v8 :: v_dual_mov_b32 v8, v34             ; ca100108 09080122
	v_swap_b32 v5, v170                                         ; 7e0acbaa
	v_swap_b32 v39, v171                                        ; 7e4ecbab
	v_swap_b32 v130, v132                                       ; 7f04cb84
	v_swap_b32 v131, v133                                       ; 7f06cb85
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[14:15], v[22:23], v[54:61] ; cc464036 1cda2d0e
	v_dual_mov_b32 v143, v163 :: v_dual_mov_b32 v142, v162      ; ca1001a3 8f8e01a2
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[166:167], v[10:11], v[124:131] ; cc46407c 1df215a6
	v_dual_mov_b32 v11, v167 :: v_dual_mov_b32 v10, v166        ; ca1001a7 0b0a01a6
	v_dual_mov_b32 v166, v168 :: v_dual_mov_b32 v167, v169      ; ca1001a8 a6a601a9
	v_dual_mov_b32 v168, v172 :: v_dual_mov_b32 v169, v173      ; ca1001ac a8a801ad
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[18:19], v[68:69], v[54:61] ; cc464036 1cda8912
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[10:11], v[20:21], v[164:171] ; cc4640a4 1e92290a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[66:67], v[136:143] ; cc464088 1e22850a
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[14:15], v[84:85], v[124:131] ; cc46407c 1df2a90e
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[8:9], v[70:71], v[54:61] ; cc464036 1cda8d08
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[14:15], v[86:87], v[164:171] ; cc4640a4 1e92ad0e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[14:15], v[88:89], v[136:143] ; cc464088 1e22b10e
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[18:19], v[72:73], v[124:131] ; cc46407c 1df29112
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[132:133], v[76:77], v[54:61] ; cc464036 1cda9984
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[18:19], v[90:91], v[164:171] ; cc4640a4 1e92b512
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[92:93], v[136:143] ; cc464088 1e22b912
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[8:9], v[74:75], v[124:131] ; cc46407c 1df29508
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[8:9], v[94:95], v[164:171] ; cc4640a4 1e92bd08
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[8:9], v[96:97], v[136:143] ; cc464088 1e22c108
	v_dual_mov_b32 v9, v39 :: v_dual_mov_b32 v8, v5             ; ca100127 09080105
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[132:133], v[80:81], v[124:131] ; cc46407c 1df2a184
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[118:119], v[6:7], 0 ; cc464058 1a020d76
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[132:133], v[98:99], v[164:171] ; cc4640a4 1e92c584
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[8:9], v[78:79], v[54:61] ; cc464036 1cda9d08
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[6:7], 0   ; cc464048 1a020d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[132:133], v[104:105], v[136:143] ; cc464088 1e22d184
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[8:9], v[82:83], v[124:131] ; cc46407c 1df2a508
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[8:9], v[106:107], v[164:171] ; cc4640a4 1e92d508
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[174:175], v[100:101], v[54:61] ; cc464036 1cdac9ae
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[8:9], v[112:113], v[136:143] ; cc464088 1e22e108
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[174:175], v[108:109], v[124:131] ; cc46407c 1df2d9ae
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[6:7], 0   ; cc464040 1a020d18
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[174:175], v[114:115], v[164:171] ; cc4640a4 1e92e5ae
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[116:117], v[6:7], 0 ; cc464050 1a020d74
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[134:135], v[28:29], v[54:61] ; cc464036 1cda3986
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[174:175], v[120:121], v[136:143] ; cc464088 1e22f1ae
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[134:135], v[30:31], v[124:131] ; cc46407c 1df23d86
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[134:135], v[102:103], v[164:171] ; cc4640a4 1e92cd86
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[134:135], v[110:111], v[136:143] ; cc464088 1e22dd86
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[42:43], v[8:9], v[80:87] ; cc464050 1d42112a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[8:9], v[64:71] ; cc464040 1d02112e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[48:49], v[8:9], v[72:79] ; cc464048 1d221130
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[8:9], v[88:95] ; cc464058 1d62112c
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[6:7], v[35:36], 0  ; cc464060 1a024706
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[6:7], v[37:38], 0 ; cc464068 1a024b06
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v21, v75, v75 :: v_dual_mul_f32 v20, v89, v89 ; c8c6974b 1514b359
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[50:51], v[96:103] ; cc464060 1d826508
	v_dual_fmac_f32 v21, v67, v67 :: v_dual_fmac_f32 v20, v81, v81 ; c8008743 1514a351
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[52:53], v[104:111] ; cc464068 1da26908
	v_dual_mul_f32 v22, v91, v91 :: v_dual_mul_f32 v9, v73, v73 ; c8c6b75b 16089349
	v_dual_fmac_f32 v21, v71, v71 :: v_dual_fmac_f32 v20, v85, v85 ; c8008f47 1514ab55
	s_mov_b32 s5, 0x76543210                                    ; be8500ff 76543210
	s_mov_b32 s8, 0xfedcba98                                    ; be8800ff fedcba98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_dual_fmac_f32 v22, v83, v83 :: v_dual_fmac_f32 v9, v65, v65 ; c800a753 16088341
	v_dual_fmac_f32 v21, v79, v79 :: v_dual_fmac_f32 v20, v93, v93 ; c8009f4f 1514bb5d
	s_movk_i32 s10, 0x410                                       ; b00a0410
	v_dual_fmac_f32 v22, v87, v87 :: v_dual_fmac_f32 v9, v69, v69 ; c800af57 16088b45
	v_dual_fmac_f32 v20, v80, v80 :: v_dual_fmac_f32 v21, v66, v66 ; c800a150 14148542
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v22, v95, v95 :: v_dual_fmac_f32 v9, v77, v77 ; c800bf5f 16089b4d
	v_dual_fmac_f32 v20, v88, v88 :: v_dual_fmac_f32 v21, v74, v74 ; c800b158 1414954a
	v_dual_fmac_f32 v22, v82, v82 :: v_dual_fmac_f32 v9, v64, v64 ; c800a552 16088140
	v_dual_fmac_f32 v20, v84, v84 :: v_dual_fmac_f32 v21, v70, v70 ; c800a954 14148d46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v22, v90, v90 :: v_dual_fmac_f32 v9, v72, v72 ; c800b55a 16089148
	v_dual_fmac_f32 v20, v92, v92 :: v_dual_fmac_f32 v21, v78, v78 ; c800b95c 14149d4e
	v_dual_fmac_f32 v22, v86, v86 :: v_dual_fmac_f32 v9, v68, v68 ; c800ad56 16088944
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v22, v94, v94 :: v_dual_fmac_f32 v9, v76, v76 ; c800bd5e 1608994c
	v_fma_mixlo_f16 v23, 1.0, v9, v21                           ; cc210017 045612f2
	v_fma_mixhi_f16 v23, 1.0, v20, v22                          ; cc220017 045a28f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v28, v23, s5, s8 op_sel:[1,1]             ; d65c181c 00200b17
(invalid instruction)                                        ; cc0f0017
	v_min_num_f64_e32 v[1:2], v[23:24], v[28:29]                ; 1a023917
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v10                               ; 0a001517
	v_cvt_f32_f16_e32 v29, v23                                  ; 7e3a1717
	v_cvt_f32_f16_e32 v23, v151/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2e1797
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(TRANS32_DEP_2) ; bf870332
	v_rsq_f32_e32 v29, v29                                      ; 7e3a5d1d
	v_rsq_f32_e32 v23, v23                                      ; 7e2e5d17
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_mul_f32_e32 v29, s4, v29                                  ; 103a3a04
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v83, v83, v23 :: v_dual_mul_f32 v82, v82, v23 ; c8c62f53 53522f52
	v_dual_mul_f32 v85, v85, v23 :: v_dual_mul_f32 v84, v84, v23 ; c8c62f55 55542f54
	v_dual_mul_f32 v87, v87, v23 :: v_dual_mul_f32 v86, v86, v23 ; c8c62f57 57562f56
	v_dual_mul_f32 v81, v81, v23 :: v_dual_mul_f32 v80, v80, v23 ; c8c62f51 51502f50
	v_dual_mul_f32 v69, v69, v29 :: v_dual_mul_f32 v68, v68, v29 ; c8c63b45 45443b44
	v_dual_mul_f32 v73, v73, v29 :: v_dual_mul_f32 v72, v72, v29 ; c8c63b49 49483b48
	v_dual_mul_f32 v71, v71, v29 :: v_dual_mul_f32 v70, v70, v29 ; c8c63b47 47463b46
	v_dual_mul_f32 v64, v64, v29 :: v_dual_mul_f32 v65, v65, v29 ; c8c63b40 40403b41
	v_dual_mul_f32 v66, v66, v29 :: v_dual_mul_f32 v67, v67, v29 ; c8c63b42 42423b43
	v_dual_mul_f32 v77, v77, v29 :: v_dual_mul_f32 v76, v76, v29 ; c8c63b4d 4d4c3b4c
	v_dual_mul_f32 v89, v89, v23 :: v_dual_mul_f32 v88, v88, v23 ; c8c62f59 59582f58
	v_dual_mul_f32 v75, v75, v29 :: v_dual_mul_f32 v74, v74, v29 ; c8c63b4b 4b4a3b4a
	v_dual_mul_f32 v79, v79, v29 :: v_dual_mul_f32 v78, v78, v29 ; c8c63b4f 4f4e3b4e
	v_dual_mul_f32 v91, v91, v23 :: v_dual_mul_f32 v90, v90, v23 ; c8c62f5b 5b5a2f5a
	v_dual_mul_f32 v93, v93, v23 :: v_dual_mul_f32 v92, v92, v23 ; c8c62f5d 5d5c2f5c
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_dual_mul_f32 v95, v95, v23 :: v_dual_mul_f32 v94, v94, v23 ; c8c62f5f 5f5e2f5e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[12:13], 0 ; cc464048 1a02191a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[12:13], 0 ; cc464040 1a021918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[116:117], v[12:13], 0 ; cc464050 1a021974
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[118:119], v[12:13], 0 ; cc464058 1a021976
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[48:49], v[10:11], v[72:79] ; cc464048 1d221530
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[35:36], 0 ; cc464060 1a02470c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[37:38], 0 ; cc464068 1a024b0c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[10:11], v[64:71] ; cc464040 1d02152e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[42:43], v[10:11], v[80:87] ; cc464050 1d42152a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[10:11], v[88:95] ; cc464058 1d62152c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[10:11], v[50:51], v[96:103] ; cc464060 1d82650a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[52:53], v[104:111] ; cc464068 1da2690a
	v_dual_mul_f32 v40, v75, v75 :: v_dual_mul_f32 v39, v89, v89 ; c8c6974b 2826b359
	v_dual_mul_f32 v41, v91, v91 :: v_dual_mul_f32 v34, v73, v73 ; c8c6b75b 29229349
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v40, v67, v67 :: v_dual_fmac_f32 v39, v81, v81 ; c8008743 2826a351
	v_dual_fmac_f32 v41, v83, v83 :: v_dual_fmac_f32 v34, v65, v65 ; c800a753 29228341
	v_dual_fmac_f32 v40, v71, v71 :: v_dual_fmac_f32 v39, v85, v85 ; c8008f47 2826ab55
	v_dual_fmac_f32 v41, v87, v87 :: v_dual_fmac_f32 v34, v69, v69 ; c800af57 29228b45
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v40, v79, v79 :: v_dual_fmac_f32 v39, v93, v93 ; c8009f4f 2826bb5d
	v_dual_fmac_f32 v41, v95, v95 :: v_dual_fmac_f32 v34, v77, v77 ; c800bf5f 29229b4d
	v_dual_fmac_f32 v39, v80, v80 :: v_dual_fmac_f32 v40, v66, v66 ; c800a150 27288542
	v_dual_fmac_f32 v41, v82, v82 :: v_dual_fmac_f32 v34, v64, v64 ; c800a552 29228140
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v39, v88, v88 :: v_dual_fmac_f32 v40, v74, v74 ; c800b158 2728954a
	v_dual_fmac_f32 v41, v90, v90 :: v_dual_fmac_f32 v34, v72, v72 ; c800b55a 29229148
	v_dual_fmac_f32 v39, v84, v84 :: v_dual_fmac_f32 v40, v70, v70 ; c800a954 27288d46
	v_dual_fmac_f32 v41, v86, v86 :: v_dual_fmac_f32 v34, v68, v68 ; c800ad56 29228944
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v39, v92, v92 :: v_dual_fmac_f32 v40, v78, v78 ; c800b95c 27289d4e
	v_dual_fmac_f32 v41, v94, v94 :: v_dual_fmac_f32 v34, v76, v76 ; c800bd5e 2922994c
	v_fma_mixlo_f16 v62, 1.0, v34, v40                          ; cc21003e 04a244f2
	v_fma_mixhi_f16 v62, 1.0, v39, v41                          ; cc22003e 04a64ef2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v63, v62, s5, s8 op_sel:[1,1]             ; d65c183f 00200b3e
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[63:64]                ; 1a027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c003e
	v_subrev_f32_e32 v0, v62, v10                               ; 0a00153e
	v_cvt_f32_f16_e32 v112, v62                                 ; 7ee0173e
	v_cvt_f32_f16_e32 v62, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7c17be
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v112, v112                                    ; 7ee05d70
	v_rsq_f32_e32 v62, v62                                      ; 7e7c5d3e
	v_mul_f32_e32 v112, s4, v112                                ; 10e0e004
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v89, v89, v62 :: v_dual_mul_f32 v86, v86, v62 ; c8c67d59 59567d56
	v_mul_f32_e32 v81, v81, v62                                 ; 10a27d51
	v_dual_mul_f32 v85, v85, v62 :: v_dual_mul_f32 v66, v66, v112 ; c8c67d55 5542e142
	v_mul_f32_e32 v67, v67, v112                                ; 1086e143
	v_dual_mul_f32 v73, v73, v112 :: v_dual_mul_f32 v70, v70, v112 ; c8c6e149 4946e146
	v_dual_mul_f32 v87, v87, v62 :: v_dual_mul_f32 v68, v68, v112 ; c8c67d57 5744e144
	v_dual_mul_f32 v83, v83, v62 :: v_dual_mul_f32 v64, v64, v112 ; c8c67d53 5340e140
	v_dual_mul_f32 v75, v75, v112 :: v_dual_mul_f32 v80, v80, v62 ; c8c6e14b 4b507d50
	v_dual_mul_f32 v77, v77, v112 :: v_dual_mul_f32 v82, v82, v62 ; c8c6e14d 4d527d52
	v_mul_f32_e32 v69, v69, v112                                ; 108ae145
	v_mul_f32_e32 v71, v71, v112                                ; 108ee147
	v_mul_f32_e32 v65, v65, v112                                ; 1082e141
	v_dual_mul_f32 v79, v79, v112 :: v_dual_mul_f32 v84, v84, v62 ; c8c6e14f 4f547d54
	v_dual_mul_f32 v91, v91, v62 :: v_dual_mul_f32 v72, v72, v112 ; c8c67d5b 5b48e148
	v_dual_mul_f32 v93, v93, v62 :: v_dual_mul_f32 v74, v74, v112 ; c8c67d5d 5d4ae14a
	v_dual_mul_f32 v95, v95, v62 :: v_dual_mul_f32 v76, v76, v112 ; c8c67d5f 5f4ce14c
	v_dual_mov_b32 v113, v128 :: v_dual_mul_f32 v78, v78, v112  ; ca060180 714ee14e
	v_dual_mov_b32 v115, v130 :: v_dual_mul_f32 v88, v88, v62   ; ca060182 73587d58
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[26:27], v[16:17], 0 ; cc464050 1a02211a
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[16:17], 0 ; cc464048 1a022118
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[118:119], v[16:17], 0 ; cc464060 1a022176
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[14:15], v[80:87] ; cc464050 1d421d30
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[46:47], v[14:15], v[72:79] ; cc464048 1d221d2e
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[14:15], v[96:103] ; cc464060 1d821d2c
	v_dual_mul_f32 v121, v81, v81 :: v_dual_mul_f32 v90, v90, v62 ; c8c6a351 795a7d5a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_dual_fmac_f32 v121, v73, v73 :: v_dual_mul_f32 v92, v92, v62 ; c8069349 795c7d5c
	v_mul_f32_e32 v161, v99, v99                                ; 1142c763
	v_dual_mul_f32 v123, v97, v97 :: v_dual_mul_f32 v94, v94, v62 ; c8c6c361 7b5e7d5e
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[35:36], 0 ; cc464068 1a024710
	v_fmac_f32_e32 v121, v77, v77                               ; 56f29b4d
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[116:117], v[16:17], 0 ; cc464058 1a022174
	v_fmac_f32_e32 v121, v85, v85                               ; 56f2ab55
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[50:51], v[104:111] ; cc464068 1da2650e
	v_dual_fmac_f32 v121, v72, v72 :: v_dual_mul_f32 v160, v83, v83 ; c8069148 79a0a753
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[42:43], v[14:15], v[88:95] ; cc464058 1d621d2a
	v_dual_fmac_f32 v121, v80, v80 :: v_dual_fmac_f32 v160, v75, v75 ; c800a150 79a0974b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmac_f32 v121, v76, v76 :: v_dual_fmac_f32 v160, v79, v79 ; c800994c 79a09f4f
	v_dual_fmac_f32 v161, v91, v91 :: v_dual_mov_b32 v114, v129 ; c810b75b a1720181
	v_dual_fmac_f32 v121, v84, v84 :: v_dual_fmac_f32 v160, v87, v87 ; c800a954 79a0af57
	v_fmac_f32_e32 v123, v89, v89                               ; 56f6b359
	v_fmac_f32_e32 v161, v95, v95                               ; 5742bf5f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmac_f32_e32 v123, v93, v93                               ; 56f6bb5d
	v_fmac_f32_e32 v161, v103, v103                             ; 5742cf67
	v_dual_fmac_f32 v123, v101, v101 :: v_dual_mov_b32 v120, v131 ; c810cb65 7b780183
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[16:17], v[37:38], 0 ; cc464080 1a024b10
	v_fmac_f32_e32 v161, v90, v90                               ; 5742b55a
	v_dual_fmac_f32 v123, v88, v88 :: v_dual_fmac_f32 v160, v74, v74 ; c800b158 7ba0954a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmac_f32_e32 v161, v98, v98                               ; 5742c562
	v_dual_fmac_f32 v123, v96, v96 :: v_dual_fmac_f32 v160, v82, v82 ; c800c160 7ba0a552
	v_fmac_f32_e32 v161, v94, v94                               ; 5742bd5e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[52:53], v[128:135] ; cc464080 1e02690e
	v_dual_fmac_f32 v123, v92, v92 :: v_dual_fmac_f32 v160, v78, v78 ; c800b95c 7ba09d4e
	v_fmac_f32_e32 v161, v102, v102                             ; 5742cd66
	v_lshl_add_u32 v3, v3, 6, s7                                ; d6460003 001d0d03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmac_f32 v123, v100, v100 :: v_dual_fmac_f32 v160, v86, v86 ; c800c964 7ba0ad56
	v_add_lshl_u32 v3, v3, v2, 2                                ; d6470003 020a0503
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mixlo_f16 v162, 1.0, v121, v160                       ; cc2100a2 0682f2f2
	v_fma_mixhi_f16 v162, 1.0, v123, v161                       ; cc2200a2 0686f6f2
	v_permlanex16_b32 v163, v162, s5, s8 op_sel:[1,1]           ; d65c18a3 00200ba2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[162:163], v[163:164]            ; 1a0347a2
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; cc1c00a2
	v_subrev_f32_e32 v0, v162, v10                              ; 0a0015a2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00ac
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
	v_rsq_f32_e32 v172, v172                                    ; 7f585dac
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v172, s4, v172                                ; 11595804
	v_dual_mul_f32 v73, v73, v172 :: v_dual_mul_f32 v72, v72, v172 ; c8c75949 49495948
	v_dual_mul_f32 v75, v75, v172 :: v_dual_mul_f32 v74, v74, v172 ; c8c7594b 4b4b594a
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v3, s[20:23], null offen         ; c405c07c 40802844 00000003
	buffer_load_b128 v[72:75], v3, s[20:23], null offen offset:16 ; c405c07c 40802848 00001003
	v_dual_mul_f32 v79, v79, v172 :: v_dual_mul_f32 v78, v78, v172 ; c8c7594f 4f4f594e
	v_dual_mul_f32 v77, v77, v172 :: v_dual_mul_f32 v76, v76, v172 ; c8c7594d 4d4d594c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	buffer_load_b128 v[76:79], v3, s[20:23], null offen offset:4096 ; c405c07c 4080284c 00100003
(invalid instruction)                                        ; d58b08a2
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
	v_dual_mul_f32 v81, v81, v172 :: v_dual_mul_f32 v80, v80, v172 ; c8c75951 51515950
	v_dual_mul_f32 v83, v83, v172 :: v_dual_mul_f32 v82, v82, v172 ; c8c75953 53535952
	v_dual_mul_f32 v85, v85, v172 :: v_dual_mul_f32 v84, v84, v172 ; c8c75955 55555954
	v_dual_mul_f32 v87, v87, v172 :: v_dual_mul_f32 v86, v86, v172 ; c8c75957 57575956
	v_rsq_f32_e32 v162, v162                                    ; 7f445da2
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v95, v95, v162 :: v_dual_mul_f32 v94, v94, v162 ; c8c7455f 5f5f455e
	v_dual_mul_f32 v99, v99, v162 :: v_dual_mul_f32 v98, v98, v162 ; c8c74563 63634562
	v_dual_mul_f32 v89, v89, v162 :: v_dual_mul_f32 v88, v88, v162 ; c8c74559 59594558
	v_dual_mul_f32 v93, v93, v162 :: v_dual_mul_f32 v92, v92, v162 ; c8c7455d 5d5d455c
	v_dual_mul_f32 v97, v97, v162 :: v_dual_mul_f32 v96, v96, v162 ; c8c74561 61614560
	v_dual_mul_f32 v91, v91, v162 :: v_dual_mul_f32 v90, v90, v162 ; c8c7455b 5b5b455a
	v_dual_mul_f32 v101, v101, v162 :: v_dual_mul_f32 v100, v100, v162 ; c8c74565 65654564
	v_dual_mul_f32 v103, v103, v162 :: v_dual_mul_f32 v102, v102, v162 ; c8c74567 67674566
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[32:33], 0 ; cc464068 1a02411a
	v_dual_mov_b32 v26, v122 :: v_dual_mov_b32 v5, v120         ; ca10017a 1a040178
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_mov_b32 v27, v156 :: v_dual_mov_b32 v34, v157        ; ca10019c 1b22019d
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[32:33], 0 ; cc464060 1a024118
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[116:117], v[32:33], 0 ; cc464080 1a024174
	v_dual_mov_b32 v25, v89 :: v_dual_mov_b32 v24, v88          ; ca100159 19180158
	v_wmma_f32_16x16x16_fp8_fp8 v[86:93], v[118:119], v[32:33], 0 ; cc464056 1a024176
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[32:33], v[35:36], 0 ; cc464074 1a024720
	v_dual_mov_b32 v36, v159 :: v_dual_mov_b32 v35, v158        ; ca10019f 2422019e
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[32:33], v[37:38], 0 ; cc46409c 1a024b20
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[18:19], v[104:111] ; cc464068 1da22530
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[18:19], v[96:103] ; cc464060 1d82252e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[18:19], v[128:135] ; cc464080 1e02252a
	v_wmma_f32_16x16x16_fp8_fp8 v[86:93], v[44:45], v[18:19], v[86:93] ; cc464056 1d5a252c
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[18:19], v[50:51], v[116:123] ; cc464074 1dd26512
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[18:19], v[52:53], v[156:163] ; cc46409c 1e726912
	v_dual_mul_f32 v38, v87, v87 :: v_dual_mul_f32 v37, v105, v105 ; c8c6af57 2624d369
	v_dual_mul_f32 v42, v89, v89 :: v_dual_mul_f32 v39, v107, v107 ; c8c6b359 2a26d76b
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmac_f32_e32 v38, v129, v129                              ; 564d0381
	v_dual_fmac_f32 v42, v131, v131 :: v_dual_fmac_f32 v37, v97, v97 ; c8010783 2a24c361
	v_dual_fmac_f32 v38, v133, v133 :: v_dual_fmac_f32 v39, v99, v99 ; c8010b85 2626c763
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmac_f32 v38, v91, v91 :: v_dual_fmac_f32 v37, v101, v101 ; c800b75b 2624cb65
	v_fmac_f32_e32 v39, v103, v103                              ; 564ecf67
	v_dual_fmac_f32 v42, v135, v135 :: v_dual_fmac_f32 v37, v109, v109 ; c8010f87 2a24db6d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v42, v93, v93 :: v_dual_fmac_f32 v39, v111, v111 ; c800bb5d 2a26df6f
	v_dual_fmac_f32 v38, v128, v128 :: v_dual_fmac_f32 v39, v98, v98 ; c8010180 2626c562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v38, v86, v86 :: v_dual_fmac_f32 v37, v96, v96 ; c800ad56 2624c160
	v_dual_fmac_f32 v38, v132, v132 :: v_dual_fmac_f32 v39, v106, v106 ; c8010984 2626d56a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v38, v90, v90 :: v_dual_fmac_f32 v37, v104, v104 ; c800b55a 2624d168
	v_dual_fmac_f32 v42, v130, v130 :: v_dual_fmac_f32 v37, v100, v100 ; c8010582 2a24c964
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v42, v88, v88 :: v_dual_fmac_f32 v39, v102, v102 ; c800b158 2a26cd66
	v_dual_fmac_f32 v42, v134, v134 :: v_dual_fmac_f32 v37, v108, v108 ; c8010d86 2a24d96c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v42, v92, v92 :: v_dual_fmac_f32 v39, v110, v110 ; c800b95c 2a26dd6e
	v_fma_mixlo_f16 v43, 1.0, v37, v39                          ; cc21002b 049e4af2
	v_mov_b32_e32 v19, v36                                      ; 7e260324
	v_fma_mixhi_f16 v43, 1.0, v38, v42                          ; cc22002b 04aa4cf2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v44, v43, s5, s8 op_sel:[1,1]             ; d65c182c 00200b2b
(invalid instruction)                                        ; cc0f002b
	v_min_num_f64_e32 v[1:2], v[43:44], v[44:45]                ; 1a02592b
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_dual_mov_b32 v42, v55 :: v_dual_mov_b32 v33, v54          ; ca100137 2a200136
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc1c002b
	v_subrev_f32_e32 v0, v43, v10                               ; 0a00152b
	v_cvt_f32_f16_e32 v45, v43                                  ; 7e5a172b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v45, v45                                      ; 7e5a5d2d
	v_mul_f32_e32 v45, s4, v45                                  ; 105a5a04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_dual_mul_f32 v96, v96, v45 :: v_dual_mul_f32 v97, v97, v45 ; c8c65b60 60605b61
	v_dual_mul_f32 v98, v98, v45 :: v_dual_mul_f32 v99, v99, v45 ; c8c65b62 62625b63
	v_mov_b32_e32 v32, v45                                      ; 7e40032d
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[48:51], v3, s[20:23], null offen offset:4112 ; c405c07c 40802830 00101003
	buffer_load_b128 v[96:99], v3, s[20:23], null offen offset:8192 ; c405c07c 40802860 00200003
	buffer_load_b128 v[172:175], v3, s[20:23], null offen offset:8208 ; c405c07c 408028ac 00201003
	buffer_load_b128 v[36:39], v3, s[20:23], null offen offset:12288 ; c405c07c 40802824 00300003
	buffer_load_b128 v[44:47], v3, s[20:23], null offen offset:12304 ; c405c07c 4080282c 00301003
	buffer_load_b128 v[52:55], v3, s[20:23], null offen offset:64 ; c405c07c 40802834 00004003
	v_cvt_f32_f16_e32 v43, v171/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e5617ab
	v_dual_mul_f32 v105, v105, v32 :: v_dual_mul_f32 v104, v104, v32 ; c8c64169 69684168
	v_mul_f32_e32 v100, v100, v32                               ; 10c84164
	v_dual_mul_f32 v102, v102, v32 :: v_dual_mul_f32 v101, v101, v32 ; c8c64166 66644165
	v_dual_mul_f32 v107, v107, v32 :: v_dual_mul_f32 v106, v106, v32 ; c8c6416b 6b6a416a
	v_dual_mul_f32 v109, v109, v32 :: v_dual_mul_f32 v108, v108, v32 ; c8c6416d 6d6c416c
	v_dual_mul_f32 v111, v111, v32 :: v_dual_mul_f32 v110, v110, v32 ; c8c6416f 6f6e416e
	v_dual_mov_b32 v94, v18 :: v_dual_mul_f32 v103, v103, v32   ; ca060112 5e664167
	v_rsq_f32_e32 v43, v43                                      ; 7e565d2b
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694066
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694067
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_mul_f32 v87, v87, v43 :: v_dual_mul_f32 v86, v86, v43 ; c8c65757 57565756
	v_dual_mul_f32 v91, v91, v43 :: v_dual_mul_f32 v90, v90, v43 ; c8c6575b 5b5a575a
	v_dual_mul_f32 v134, v134, v43 :: v_dual_mul_f32 v135, v135, v43 ; c8c65786 86865787
	v_dual_mul_f32 v128, v128, v43 :: v_dual_mul_f32 v129, v129, v43 ; c8c65780 80805781
	v_dual_mul_f32 v130, v130, v43 :: v_dual_mul_f32 v131, v131, v43 ; c8c65782 82825783
	v_dual_mul_f32 v93, v93, v43 :: v_dual_mul_f32 v92, v92, v43 ; c8c6575d 5d5c575c
	v_dual_mul_f32 v89, v89, v43 :: v_dual_mul_f32 v88, v88, v43 ; c8c65759 59585758
	v_dual_mul_f32 v132, v132, v43 :: v_dual_mul_f32 v133, v133, v43 ; c8c65784 84845785
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694064
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mov_b32_e32 v43, v113                                     ; 7e560371
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[8:9], v[6:7], 0   ; cc464080 1a020d08
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[8:9], v[10:11], 0 ; cc464074 1a021508
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[8:9], v[14:15], 0 ; cc46409c 1a021d08
	v_wmma_f32_16x16x16_fp8_fp8 v[106:113], v[8:9], v[94:95], 0 ; cc46406a 1a02bd08
	s_mov_b32 s11, 0x3d380000                                   ; be8b00ff 3d380000
	s_movk_i32 s13, 0x3c20                                      ; b00d3c20
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[28:29], v[30:31], v[128:135] ; cc464080 1e023d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[28:29], v[64:65], v[116:123] ; cc464074 1dd2811c
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[28:29], v[80:81], v[156:163] ; cc46409c 1e72a11c
	v_wmma_f32_16x16x16_fp8_fp8 v[106:113], v[28:29], v[104:105], v[106:113] ; cc46406a 1daad11c
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_mixlo_f16 v68, s11, v128, v68                         ; cc210044 0513000b
	v_fma_mixhi_f16 v68, s11, v129, v69                         ; cc220044 0517020b
	v_fma_mixlo_f16 v69, s11, v130, v70                         ; cc210045 051b040b
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v70, s11, v132, v72                         ; cc210046 0523080b
	v_fma_mixhi_f16 v69, s11, v131, v71                         ; cc220045 051f060b
	v_fma_mixlo_f16 v71, s11, v134, v74                         ; cc210047 052b0c0b
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v72, s11, v116, v76                         ; cc210048 0532e80b
	v_fma_mixhi_f16 v72, s11, v117, v77                         ; cc220048 0536ea0b
	v_fma_mixhi_f16 v70, s11, v133, v73                         ; cc220046 05270a0b
	v_fma_mixhi_f16 v71, s11, v135, v75                         ; cc220047 052f0e0b
	v_fma_mixlo_f16 v73, s11, v118, v78                         ; cc210049 053aec0b
	v_fma_mixhi_f16 v73, s11, v119, v79                         ; cc220049 053eee0b
(invalid instruction)                                        ; cc1c0044
	v_subrev_f32_e32 v0, v68, v13                               ; 0a001b44
(invalid instruction)                                        ; cc1c0045
	v_subrev_f32_e32 v0, v69, v13                               ; 0a001b45
(invalid instruction)                                        ; cc1c0048
	v_subrev_f32_e32 v0, v72, v13                               ; 0a001b48
(invalid instruction)                                        ; cc1c0046
	v_subrev_f32_e32 v0, v70, v13                               ; 0a001b46
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[12:13], v[6:7], 0 ; cc464080 1a020d0c
(invalid instruction)                                        ; cc1c0047
	v_subrev_f32_e32 v0, v71, v13                               ; 0a001b47
(invalid instruction)                                        ; cc1c0049
	v_subrev_f32_e32 v0, v73, v13                               ; 0a001b49
	v_mov_b32_e32 v8, v72                                       ; 7e100348
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[30:31], v[128:135] ; cc464080 1e023d42
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v74, s11, v120, v48                         ; cc21004a 04c2f00b
	v_fma_mixhi_f16 v74, s11, v121, v49                         ; cc22004a 04c6f20b
	v_dual_mov_b32 v48, v86 :: v_dual_mov_b32 v49, v87          ; ca100156 30300157
	v_fma_mixlo_f16 v75, s11, v122, v50                         ; cc21004b 04caf40b
	v_fma_mixhi_f16 v75, s11, v123, v51                         ; cc22004b 04cef60b
	v_dual_mov_b32 v50, v88 :: v_dual_mov_b32 v51, v89          ; ca100158 32320159
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[12:13], v[10:11], 0 ; cc464074 1a02150c
	v_wmma_f32_16x16x16_fp8_fp8 v[86:93], v[12:13], v[94:95], 0 ; cc464056 1a02bd0c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v29, s11, v156, v96                         ; cc21001d 0583380b
	v_fma_mixhi_f16 v29, s11, v157, v97                         ; cc22001d 05873a0b
	v_fma_mixlo_f16 v32, s11, v158, v98                         ; cc210020 058b3c0b
	v_fma_mixhi_f16 v32, s11, v159, v99                         ; cc220020 058f3e0b
(invalid instruction)                                        ; cc1c004a
	v_subrev_f32_e32 v0, v74, v13                               ; 0a001b4a
(invalid instruction)                                        ; cc1c004b
	v_subrev_f32_e32 v0, v75, v13                               ; 0a001b4b
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[66:67], v[64:65], v[116:123] ; cc464074 1dd28142
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v96, s11, v106, v36                         ; cc210060 0492d40b
	v_fma_mixhi_f16 v96, s11, v107, v37                         ; cc220060 0496d60b
(invalid instruction)                                        ; cc1c001d
	v_subrev_f32_e32 v0, v29, v13                               ; 0a001b1d
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v13                               ; 0a001b20
	v_mov_b32_e32 v18, v74                                      ; 7e24034a
	v_dual_mov_b32 v28, v75 :: v_dual_mov_b32 v9, v73           ; ca10014b 1c080149
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[12:13], v[14:15], 0 ; cc464048 1a021d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[86:93], v[66:67], v[104:105], v[86:93] ; cc464056 1d5ad142
	v_fma_mixlo_f16 v97, s11, v108, v38                         ; cc210061 049ad80b
	v_fma_mixhi_f16 v97, s11, v109, v39                         ; cc220061 049eda0b
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v98, s11, v110, v44                         ; cc210062 04b2dc0b
	v_fma_mixhi_f16 v98, s11, v111, v45                         ; cc220062 04b6de0b
(invalid instruction)                                        ; cc1c0060
	v_subrev_f32_e32 v0, v96, v13                               ; 0a001b60
	v_fma_mixlo_f16 v99, s11, v112, v46                         ; cc210063 04bae00b
	v_fma_mixhi_f16 v99, s11, v113, v47                         ; cc220063 04bee20b
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[66:67], v[80:81], v[72:79] ; cc464048 1d22a142
	v_fma_mixlo_f16 v66, s11, v160, v172                        ; cc210042 06b3400b
	v_fma_mixhi_f16 v66, s11, v161, v173                        ; cc220042 06b7420b
	v_fma_mixlo_f16 v67, s11, v162, v174                        ; cc210043 06bb440b
	v_fma_mixhi_f16 v67, s11, v163, v175                        ; cc220043 06bf460b
	v_dual_mov_b32 v107, v115 :: v_dual_mov_b32 v106, v114      ; ca100173 6b6a0172
	s_clause 0x6                                                ; bf850006
	buffer_load_b128 v[36:39], v3, s[20:23], null offen offset:80 ; c405c07c 40802824 00005003
	buffer_load_b128 v[44:47], v3, s[20:23], null offen offset:4160 ; c405c07c 4080282c 00104003
	buffer_load_b128 v[108:111], v3, s[20:23], null offen offset:4176 ; c405c07c 4080286c 00105003
	buffer_load_b128 v[156:159], v3, s[20:23], null offen offset:8256 ; c405c07c 4080289c 00204003
	buffer_load_b128 v[160:163], v3, s[20:23], null offen offset:8272 ; c405c07c 408028a0 00205003
	buffer_load_b128 v[172:175], v3, s[20:23], null offen offset:12352 ; c405c07c 408028ac 00304003
	buffer_load_b128 v[112:115], v3, s[20:23], null offen offset:12368 ; c405c07c 40802870 00305003
(invalid instruction)                                        ; cc1c0061
	v_subrev_f32_e32 v0, v97, v13                               ; 0a001b61
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v13                               ; 0a001b62
	v_mov_b32_e32 v12, v32                                      ; 7e180320
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v128, s11, v128, v52                        ; cc210080 04d3000b
	v_dual_mov_b32 v52, v34 :: v_dual_mov_b32 v13, v33          ; ca100122 340c0121
	v_fma_mixhi_f16 v128, s11, v129, v53                        ; cc220080 04d7020b
	v_fma_mixlo_f16 v129, s11, v130, v54                        ; cc210081 04db040b
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v13                               ; 0a001b42
	v_fma_mixhi_f16 v129, s11, v131, v55                        ; cc220081 04df060b
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v13                               ; 0a001b43
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v13                               ; 0a001b63
(invalid instruction)                                        ; cc1c0080
	v_subrev_f32_e32 v0, v128, v13                              ; 0a001b80
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c0081
	v_subrev_f32_e32 v0, v129, v13                              ; 0a001b81
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v130, s11, v132, v36                        ; cc210082 0493080b
	v_fma_mixlo_f16 v131, s11, v134, v38                        ; cc210083 049b0c0b
	v_fma_mixhi_f16 v130, s11, v133, v37                        ; cc220082 04970a0b
	v_fma_mixhi_f16 v131, s11, v135, v39                        ; cc220083 049f0e0b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v55, s11, v118, v46                         ; cc210037 04baec0b
	v_fma_mixlo_f16 v54, s11, v116, v44                         ; cc210036 04b2e80b
	v_dual_mov_b32 v44, v120 :: v_dual_mov_b32 v53, v35         ; ca100178 2c340123
	v_fma_mixhi_f16 v54, s11, v117, v45                         ; cc220036 04b6ea0b
	v_dual_mov_b32 v46, v122 :: v_dual_mov_b32 v45, v121        ; ca10017a 2e2c0179
	v_fma_mixhi_f16 v55, s11, v119, v47                         ; cc220037 04beee0b
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[6:7], 0   ; cc464020 1a020d10
(invalid instruction)                                        ; cc1c0082
	v_subrev_f32_e32 v0, v130, v13                              ; 0a001b82
(invalid instruction)                                        ; cc1c0083
	v_subrev_f32_e32 v0, v131, v13                              ; 0a001b83
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v108, s11, v44, v108                        ; cc21006c 05b2580b
(invalid instruction)                                        ; cc1c0036
	v_subrev_f32_e32 v0, v54, v13                               ; 0a001b36
	v_fma_mixhi_f16 v108, s11, v45, v109                        ; cc22006c 05b65a0b
	v_fma_mixlo_f16 v109, s11, v46, v110                        ; cc21006d 05ba5c0b
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v46, s11, v72, v156                         ; cc21002e 0672900b
	v_fma_mixhi_f16 v46, s11, v73, v157                         ; cc22002e 0676920b
	v_dual_mov_b32 v44, v130 :: v_dual_mov_b32 v47, v123        ; ca100182 2c2e017b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_fma_mixhi_f16 v109, s11, v47, v111                        ; cc22006d 05be5e0b
	v_dual_mov_b32 v156, v75 :: v_dual_mov_b32 v111, v129       ; ca10014b 9c6e0181
	v_fma_mixlo_f16 v47, s11, v74, v158                         ; cc21002f 067a940b
	buffer_load_b128 v[72:75], v3, s[20:23], null offen offset:128 ; c405c07c 40802848 00008003
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[16:17], v[10:11], 0 ; cc464074 1a021510
(invalid instruction)                                        ; cc1c0037
	v_subrev_f32_e32 v0, v55, v13                               ; 0a001b37
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v157, s11, v76, v160                        ; cc21009d 0682980b
	v_fma_mixhi_f16 v157, s11, v77, v161                        ; cc22009d 06869a0b
	v_dual_mov_b32 v110, v128 :: v_dual_mov_b32 v45, v131       ; ca100180 6e2c0183
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[16:17], v[14:15], 0 ; cc464080 1a021d10
	v_fma_mixlo_f16 v158, s11, v78, v162                        ; cc21009e 068a9c0b
	v_fma_mixhi_f16 v158, s11, v79, v163                        ; cc22009e 068e9e0b
(invalid instruction)                                        ; cc1c006c
	v_subrev_f32_e32 v0, v108, v13                              ; 0a001b6c
(invalid instruction)                                        ; cc1c002e
	v_subrev_f32_e32 v0, v46, v13                               ; 0a001b2e
(invalid instruction)                                        ; cc1c006d
	v_subrev_f32_e32 v0, v109, v13                              ; 0a001b6d
	v_fma_mixhi_f16 v47, s11, v156, v159                        ; cc22002f 067f380b
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[82:83], v[30:31], v[32:39] ; cc464020 1c823d52
(invalid instruction)                                        ; cc1c009d
	v_subrev_f32_e32 v0, v157, v13                              ; 0a001b9d
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v78, s11, v86, v172                         ; cc21004e 06b2ac0b
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[82:83], v[64:65], v[116:123] ; cc464074 1dd28152
	v_fma_mixhi_f16 v78, s11, v87, v173                         ; cc22004e 06b6ae0b
	v_fma_mixlo_f16 v79, s11, v88, v174                         ; cc21004f 06bab00b
	v_fma_mixhi_f16 v79, s11, v89, v175                         ; cc22004f 06beb20b
(invalid instruction)                                        ; cc1c009e
	v_subrev_f32_e32 v0, v158, v13                              ; 0a001b9e
(invalid instruction)                                        ; cc1c002f
	v_subrev_f32_e32 v0, v47, v13                               ; 0a001b2f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[80:81], v[128:135] ; cc464080 1e02a152
(invalid instruction)                                        ; cc1c004e
	v_subrev_f32_e32 v0, v78, v13                               ; 0a001b4e
(invalid instruction)                                        ; cc1c004f
	v_subrev_f32_e32 v0, v79, v13                               ; 0a001b4f
	v_dual_mov_b32 v77, v158 :: v_dual_mov_b32 v76, v157        ; ca10019e 4d4c019d
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[16:17], v[94:95], 0 ; cc46409c 1a02bd10
	v_mov_b32_e32 v16, v35                                      ; 7e200323
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[82:83], v[104:105], v[156:163] ; cc46409c 1e72d152
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v82, s11, v90, v112                         ; cc210052 05c2b40b
	v_fma_mixhi_f16 v82, s11, v91, v113                         ; cc220052 05c6b60b
	v_fma_mixlo_f16 v83, s11, v92, v114                         ; cc210053 05cab80b
	v_fma_mixhi_f16 v83, s11, v93, v115                         ; cc220053 05ceba0b
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v86, s11, v32, v72                          ; cc210056 0522400b
	v_fma_mixhi_f16 v86, s11, v33, v73                          ; cc220056 0526420b
	v_fma_mixlo_f16 v87, s11, v34, v74                          ; cc210057 052a440b
	v_mov_b32_e32 v17, v75                                      ; 7e22034b
	s_clause 0x4                                                ; bf850004
	buffer_load_b128 v[88:91], v3, s[20:23], null offen offset:144 ; c405c07c 40802858 00009003
	buffer_load_b128 v[112:115], v3, s[20:23], null offen offset:4224 ; c405c07c 40802870 00108003
	buffer_load_b128 v[172:175], v3, s[20:23], null offen offset:4240 ; c405c07c 408028ac 00109003
	buffer_load_b128 v[32:35], v3, s[20:23], null offen offset:8320 ; c405c07c 40802820 00208003
	buffer_load_b128 v[72:75], v3, s[20:23], null offen offset:8336 ; c405c07c 40802848 00209003
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v13                               ; 0a001b52
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v36, s11, v36, v88                          ; cc210024 0562480b
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v13                               ; 0a001b53
	v_fma_mixhi_f16 v36, s11, v37, v89                          ; cc220024 05664a0b
(invalid instruction)                                        ; cc1c0056
	v_subrev_f32_e32 v0, v86, v13                               ; 0a001b56
	v_fma_mixlo_f16 v37, s11, v38, v90                          ; cc210025 056a4c0b
	v_fma_mixhi_f16 v37, s11, v39, v91                          ; cc220025 056e4e0b
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v39, s11, v118, v114                        ; cc210027 05caec0b
	v_mov_b32_e32 v92, v115                                     ; 7eb80373
	v_fma_mixlo_f16 v38, s11, v116, v112                        ; cc210026 05c2e80b
	v_fma_mixhi_f16 v38, s11, v117, v113                        ; cc220026 05c6ea0b
	v_mov_b32_e32 v93, v119                                     ; 7eba0377
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[88:91], v3, s[20:23], null offen offset:12416 ; c405c07c 40802858 00308003
	buffer_load_b128 v[112:115], v3, s[20:23], null offen offset:12432 ; c405c07c 40802870 00309003
	buffer_load_b128 v[116:119], v3, s[20:23], null offen offset:192 ; c405c07c 40802874 0000c003
	v_fma_mixhi_f16 v87, s11, v16, v17                          ; cc220057 0446200b
	v_dual_mov_b32 v17, v171 :: v_dual_mov_b32 v16, v170        ; ca1001ab 111001aa
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v120, s11, v120, v172                       ; cc210078 06b2f00b
	v_fma_mixhi_f16 v120, s11, v121, v173                       ; cc220078 06b6f20b
	v_fma_mixlo_f16 v121, s11, v122, v174                       ; cc210079 06baf40b
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v13                               ; 0a001b24
	v_fma_mixhi_f16 v121, s11, v123, v175                       ; cc220079 06bef60b
	v_dual_mov_b32 v123, v169 :: v_dual_mov_b32 v122, v168      ; ca1001a9 7b7a01a8
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v32, s11, v128, v32                         ; cc210020 0483000b
	v_fma_mixhi_f16 v32, s11, v129, v33                         ; cc220020 0487020b
(invalid instruction)                                        ; cc1c0025
	v_subrev_f32_e32 v0, v37, v13                               ; 0a001b25
	v_fma_mixlo_f16 v33, s11, v130, v34                         ; cc210021 048b040b
	v_fma_mixhi_f16 v33, s11, v131, v35                         ; cc220021 048f060b
	v_dual_mov_b32 v35, v125 :: v_dual_mov_b32 v34, v124        ; ca10017d 2322017c
(invalid instruction)                                        ; cc1c0026
	v_subrev_f32_e32 v0, v38, v13                               ; 0a001b26
	v_fma_mixhi_f16 v39, s11, v93, v92                          ; cc220027 0572ba0b
	v_dual_mov_b32 v93, v127 :: v_dual_mov_b32 v92, v126        ; ca10017f 5d5c017e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v132, s11, v132, v72                        ; cc210084 0523080b
(invalid instruction)                                        ; cc1c0057
	v_subrev_f32_e32 v0, v87, v13                               ; 0a001b57
	v_fma_mixhi_f16 v132, s11, v133, v73                        ; cc220084 05270a0b
	v_dual_mov_b32 v73, v9 :: v_dual_mov_b32 v72, v8            ; ca100109 49480108
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[100:101], v[6:7], 0 ; cc4640a8 1a020d64
(invalid instruction)                                        ; cc1c0078
	v_subrev_f32_e32 v0, v120, v13                              ; 0a001b78
	v_fma_mixlo_f16 v133, s11, v134, v74                        ; cc210085 052b0c0b
	v_fma_mixhi_f16 v133, s11, v135, v75                        ; cc220085 052f0e0b
(invalid instruction)                                        ; cc1c0079
	v_subrev_f32_e32 v0, v121, v13                              ; 0a001b79
	v_dual_mov_b32 v135, v5 :: v_dual_mov_b32 v134, v4          ; ca100105 87860104
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v13                               ; 0a001b20
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[100:101], v[10:11], 0 ; cc46407c 1a021564
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[100:101], v[14:15], 0 ; cc464004 1a021d64
(invalid instruction)                                        ; cc1c0021
	v_subrev_f32_e32 v0, v33, v13                               ; 0a001b21
(invalid instruction)                                        ; cc1c0027
	v_subrev_f32_e32 v0, v39, v13                               ; 0a001b27
	v_dual_mov_b32 v15, v87 :: v_dual_mov_b32 v14, v86          ; ca100157 0f0e0156
(invalid instruction)                                        ; cc1c0084
	v_subrev_f32_e32 v0, v132, v13                              ; 0a001b84
(invalid instruction)                                        ; cc1c0085
	v_subrev_f32_e32 v0, v133, v13                              ; 0a001b85
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[48:49], v[30:31], v[168:175] ; cc4640a8 1ea23d30
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[48:49], v[64:65], v[124:131] ; cc46407c 1df28130
	v_wmma_f32_16x16x16_fp8_fp8 v[4:11], v[48:49], v[80:81], v[4:11] ; cc464004 1c12a130
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v74, s11, v156, v88                         ; cc21004a 0563380b
	v_fma_mixlo_f16 v75, s11, v158, v90                         ; cc21004b 056b3c0b
	v_fma_mixhi_f16 v74, s11, v157, v89                         ; cc22004a 05673a0b
	v_dual_mov_b32 v157, v93 :: v_dual_mov_b32 v156, v92        ; ca10015d 9d9c015c
	v_fma_mixhi_f16 v75, s11, v159, v91                         ; cc22004b 056f3e0b
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v159, s11, v162, v114                       ; cc21009f 05cb440b
	v_wmma_f32_16x16x16_fp8_fp8 v[86:93], v[100:101], v[94:95], 0 ; cc464056 1a02bd64
	v_fma_mixhi_f16 v159, s11, v163, v115                       ; cc22009f 05cf460b
	v_fma_mixlo_f16 v158, s11, v160, v112                       ; cc21009e 05c3400b
	v_fma_mixhi_f16 v158, s11, v161, v113                       ; cc22009e 05c7420b
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v160, s11, v168, v116                       ; cc2100a0 05d3500b
	v_fma_mixhi_f16 v160, s11, v169, v117                       ; cc2200a0 05d7520b
	v_fma_mixlo_f16 v161, s11, v170, v118                       ; cc2100a1 05db540b
	v_mov_b32_e32 v30, v119                                     ; 7e3c0377
(invalid instruction)                                        ; cc1c004a
	v_subrev_f32_e32 v0, v74, v13                               ; 0a001b4a
	v_mov_b32_e32 v31, v171                                     ; 7e3e03ab
	v_dual_mov_b32 v95, v83 :: v_dual_mov_b32 v94, v82          ; ca100153 5f5e0152
	v_dual_mov_b32 v101, v107 :: v_dual_mov_b32 v100, v106      ; ca10016b 6564016a
	v_wmma_f32_16x16x16_fp8_fp8 v[86:93], v[48:49], v[104:105], v[86:93] ; cc464056 1d5ad130
(invalid instruction)                                        ; cc1c004b
	v_subrev_f32_e32 v0, v75, v13                               ; 0a001b4b
	v_dual_mov_b32 v49, v67 :: v_dual_mov_b32 v48, v66          ; ca100143 31300142
	v_dual_mov_b32 v163, v29 :: v_dual_mov_b32 v162, v28        ; ca10011d a3a2011c
	v_fma_mixhi_f16 v161, s11, v31, v30                         ; cc2200a1 047a3e0b
	s_clause 0x6                                                ; bf850006
	buffer_load_b128 v[112:115], v3, s[20:23], null offen offset:208 ; c405c07c 40802870 0000d003
	buffer_load_b128 v[116:119], v3, s[20:23], null offen offset:4288 ; c405c07c 40802874 0010c003
	buffer_load_b128 v[168:171], v3, s[20:23], null offen offset:4304 ; c405c07c 408028a8 0010d003
	buffer_load_b128 v[64:67], v3, s[20:23], null offen offset:8384 ; c405c07c 40802840 0020c003
	buffer_load_b128 v[80:83], v3, s[20:23], null offen offset:8400 ; c405c07c 40802850 0020d003
	buffer_load_b128 v[104:107], v3, s[20:23], null offen offset:12480 ; c405c07c 40802868 0030c003
	buffer_load_b128 v[28:31], v3, s[20:23], null offen offset:12496 ; c405c07c 4080281c 0030d003
(invalid instruction)                                        ; cc1c009f
	v_subrev_f32_e32 v0, v159, v13                              ; 0a001b9f
(invalid instruction)                                        ; cc1c009e
	v_subrev_f32_e32 v0, v158, v13                              ; 0a001b9e
(invalid instruction)                                        ; cc1c00a0
	v_subrev_f32_e32 v0, v160, v13                              ; 0a001ba0
	s_mov_b32 s24, 0x7ff88000                                   ; be9800ff 7ff88000
(invalid instruction)                                        ; cc1c00a1
	v_subrev_f32_e32 v0, v161, v13                              ; 0a001ba1
	v_lshl_add_u32 v111, v111, 5, s24                           ; d646006f 00610b6f
	v_lshl_add_u32 v69, v69, 5, s24                             ; d6460045 00610b45
	v_lshl_add_u32 v110, v110, 5, s24                           ; d646006e 00610b6e
	v_lshl_add_u32 v68, v68, 5, s24                             ; d6460044 00610b44
	v_lshl_add_u32 v14, v14, 5, s24                             ; d646000e 00610b0e
	v_lshl_add_u32 v15, v15, 5, s24                             ; d646000f 00610b0f
	v_lshl_add_u32 v160, v160, 5, s24                           ; d64600a0 00610ba0
	v_lshl_add_u32 v161, v161, 5, s24                           ; d64600a1 00610ba1
	v_lshl_add_u32 v70, v70, 5, s24                             ; d6460046 00610b46
	v_lshl_add_u32 v44, v44, 5, s24                             ; d646002c 00610b2c
	v_lshl_add_u32 v36, v36, 5, s24                             ; d6460024 00610b24
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v112, s11, v172, v112                       ; cc210070 05c3580b
	v_fma_mixhi_f16 v112, s11, v173, v113                       ; cc220070 05c75a0b
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[68:69], v[110:111]              ; 1a02dd44
	v_fma_mixlo_f16 v172, s11, v174, v114                       ; cc2100ac 05cb5c0b
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[69:70], v[111:112]              ; 1a02df45
	v_fma_mixhi_f16 v172, s11, v175, v115                       ; cc2200ac 05cf5e0b
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[70:71], v[44:45]                ; 1a025946
	v_lshl_add_u32 v71, v71, 5, s24                             ; d6460047 00610b47
	v_lshl_add_u32 v45, v45, 5, s24                             ; d646002d 00610b2d
	v_lshl_add_u32 v37, v37, 5, s24                             ; d6460025 00610b25
(invalid instruction)                                        ; cc1c0070
	v_subrev_f32_e32 v0, v112, v13                              ; 0a001b70
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[14:15]              ; 1a021dad
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[174:175], v[15:16]              ; 1a021fae
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v13                              ; 0a001bac
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[36:37]              ; 1a0249af
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[71:72], v[45:46]                ; 1a025b47
	v_lshl_add_u32 v112, v112, 5, s24                           ; d6460070 00610b70
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[160:161]            ; 1a0341ad
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[174:175], v[161:162]            ; 1a0343ae
	v_lshl_add_u32 v172, v172, 5, s24                           ; d64600ac 00610bac
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[37:38]                  ; 1a024b03
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[112:113]            ; 1a02e1af
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[174:175]            ; 1a035dad
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[172:173]                ; 1a035903
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[175:176]            ; 1a035fad
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[3:4]                ; 1a0207ad
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v113, v173, s5, s8 op_sel:[1,1]           ; d65c1871 00200bad
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[113:114]            ; 1a02e3ad
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5321072
	v_cndmask_b32_e32 v1, v173, v173, vcc_lo                    ; 02035bad
	v_max_num_f16_e32 v114, s3, v114                            ; 62e4e403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v115, v114                                ; 7ee61772
	v_rcp_f32_e32 v115, v115                                    ; 7ee65573
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v173, v68, v115, neg(0) op_sel_hi:[1,0,0]     ; cc2000ad 8a02e744
	v_fma_mix_f32 v3, v70, v115, neg(0) op_sel_hi:[1,0,0]       ; cc200003 8a02e746
	v_fma_mix_f32 v175, v69, v115, neg(0) op_sel_hi:[1,0,0]     ; cc2000af 8a02e745
	v_fma_mix_f32 v69, v69, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200845 8a02e745
	v_fma_mix_f32 v68, v68, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200844 8a02e744
	v_fma_mix_f32 v70, v70, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200846 8a02e746
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900ae
	v_cndmask_b32_e32 v1, v173, v68, vcc_lo                     ; 020289ad
	v_fma_mix_f32 v68, v71, v115, neg(0) op_sel_hi:[1,0,0]      ; cc200044 8a02e747
	v_fma_mix_f32 v71, v71, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200847 8a02e747
(invalid instruction)                                        ; d76940ae
	v_cndmask_b32_e32 v1, v175, v69, vcc_lo                     ; 02028baf
	v_fma_mix_f32 v69, v110, v115, neg(0) op_sel_hi:[1,0,0]     ; cc200045 8a02e76e
	v_fma_mix_f32 v110, v110, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086e 8a02e76e
(invalid instruction)                                        ; d76900af
	v_cndmask_b32_e32 v1, v3, v70, vcc_lo                       ; 02028d03
	v_fma_mix_f32 v70, v111, v115, neg(0) op_sel_hi:[1,0,0]     ; cc200046 8a02e76f
	v_fma_mix_f32 v111, v111, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086f 8a02e76f
	v_fma_mix_f32 v113, v15, v115, neg(0) op_sel_hi:[1,0,0]     ; cc200071 8a02e70f
	v_fma_mix_f32 v15, v15, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080f 8a02e70f
(invalid instruction)                                        ; d76940af
	v_cndmask_b32_e32 v1, v68, v71, vcc_lo                      ; 02028f44
	v_fma_mix_f32 v71, v44, v115, neg(0) op_sel_hi:[1,0,0]      ; cc200047 8a02e72c
	v_fma_mix_f32 v44, v44, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082c 8a02e72c
	v_fma_mix_f32 v114, v36, v115, neg(0) op_sel_hi:[1,0,0]     ; cc200072 8a02e724
	v_fma_mix_f32 v36, v36, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200824 8a02e724
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v69, v110, vcc_lo                     ; 0202dd45
	v_fma_mix_f32 v110, v45, v115, neg(0) op_sel_hi:[1,0,0]     ; cc20006e 8a02e72d
	v_fma_mix_f32 v45, v45, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082d 8a02e72d
	v_fma_mix_f32 v173, v37, v115, neg(0) op_sel_hi:[1,0,0]     ; cc2000ad 8a02e725
	v_fma_mix_f32 v37, v37, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200825 8a02e725
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v70, v111, vcc_lo                     ; 0202df46
	v_fma_mix_f32 v111, v14, v115, neg(0) op_sel_hi:[1,0,0]     ; cc20006f 8a02e70e
	v_fma_mix_f32 v14, v14, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080e 8a02e70e
	v_fma_mix_f32 v3, v160, v115, neg(0) op_sel_hi:[1,0,0]      ; cc200003 8a02e7a0
	v_fma_mix_f32 v160, v160, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a0 8a02e7a0
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v71, v44, vcc_lo                      ; 02025947
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v110, v45, vcc_lo                     ; 02025b6e
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v114, v36, vcc_lo                     ; 02024972
	v_fma_mix_f32 v36, v112, v115, neg(0) op_sel_hi:[1,0,0]     ; cc200024 8a02e770
	v_fma_mix_f32 v112, v112, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200870 8a02e770
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v173, v37, vcc_lo                     ; 02024bad
	v_fma_mix_f32 v37, v172, v115, neg(0) op_sel_hi:[1,0,0]     ; cc200025 8a02e7ac
	v_fma_mix_f32 v172, v172, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ac 8a02e7ac
	v_lshl_add_u32 v72, v72, 5, s24                             ; d6460048 00610b48
	v_lshl_add_u32 v54, v54, 5, s24                             ; d6460036 00610b36
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v111, v14, vcc_lo                     ; 02021d6f
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v113, v15, vcc_lo                     ; 02021f71
	v_fma_mix_f32 v15, v161, v115, neg(0) op_sel_hi:[1,0,0]     ; cc20000f 8a02e7a1
	v_fma_mix_f32 v161, v161, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a1 8a02e7a1
	v_lshl_add_u32 v38, v38, 5, s24                             ; d6460026 00610b26
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v3, v160, vcc_lo                      ; 02034103
	v_lshl_add_u32 v73, v73, 5, s24                             ; d6460049 00610b49
	v_lshl_add_u32 v55, v55, 5, s24                             ; d6460037 00610b37
	v_lshl_add_u32 v39, v39, 5, s24                             ; d6460027 00610b27
	v_lshl_add_u32 v18, v18, 5, s24                             ; d6460012 00610b12
	v_lshl_add_u32 v108, v108, 5, s24                           ; d646006c 00610b6c
	v_lshl_add_u32 v120, v120, 5, s24                           ; d6460078 00610b78
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[72:73], v[54:55]                ; 1a026d48
	v_lshl_add_u32 v162, v162, 5, s24                           ; d64600a2 00610ba2
	v_lshl_add_u32 v109, v109, 5, s24                           ; d646006d 00610b6d
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v15, v161, vcc_lo                     ; 0203430f
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v36, v112, vcc_lo                     ; 0202e124
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v37, v172, vcc_lo                     ; 02035925
	v_lshl_add_u32 v121, v121, 5, s24                           ; d6460079 00610b79
	v_lshl_add_u32 v163, v163, 5, s24                           ; d64600a3 00610ba3
	v_lshl_add_u32 v46, v46, 5, s24                             ; d646002e 00610b2e
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[73:74], v[55:56]                ; 1a026f49
	v_lshl_add_u32 v32, v32, 5, s24                             ; d6460020 00610b20
	v_lshl_add_u32 v12, v12, 5, s24                             ; d646000c 00610b0c
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[18:19], v[108:109]              ; 1a02d912
	v_lshl_add_u32 v47, v47, 5, s24                             ; d646002f 00610b2f
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[38:39]                ; 1a024d46
	v_lshl_add_u32 v33, v33, 5, s24                             ; d6460021 00610b21
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[162:163], v[109:110]            ; 1a02dba2
	v_lshl_add_u32 v48, v48, 5, s24                             ; d6460030 00610b30
	v_lshl_add_u32 v76, v76, 5, s24                             ; d646004c 00610b4c
	v_lshl_add_u32 v132, v132, 5, s24                           ; d6460084 00610b84
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[163:164], v[46:47]              ; 1a025da3
	v_lshl_add_u32 v49, v49, 5, s24                             ; d6460031 00610b31
	v_lshl_add_u32 v77, v77, 5, s24                             ; d646004d 00610b4d
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[39:40]                ; 1a024f47
	v_lshl_add_u32 v133, v133, 5, s24                           ; d6460085 00610b85
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[120:121]            ; 1a02f16e
	v_lshl_add_u32 v96, v96, 5, s24                             ; d6460060 00610b60
(invalid instruction)                                        ; cc0f0071
	v_min_num_f64_e32 v[1:2], v[12:13], v[47:48]                ; 1a025f0c
	v_lshl_add_u32 v78, v78, 5, s24                             ; d646004e 00610b4e
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[121:122]            ; 1a02f36f
	v_lshl_add_u32 v74, v74, 5, s24                             ; d646004a 00610b4a
	v_lshl_add_u32 v97, v97, 5, s24                             ; d6460061 00610b61
(invalid instruction)                                        ; cc0f0072
	v_min_num_f64_e32 v[1:2], v[48:49], v[76:77]                ; 1a029930
	v_lshl_add_u32 v79, v79, 5, s24                             ; d646004f 00610b4f
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[112:113], v[32:33]              ; 1a024170
	v_lshl_add_u32 v75, v75, 5, s24                             ; d646004b 00610b4b
(invalid instruction)                                        ; cc0f0073
	v_min_num_f64_e32 v[1:2], v[49:50], v[77:78]                ; 1a029b31
	v_lshl_add_u32 v98, v98, 5, s24                             ; d6460062 00610b62
	v_lshl_add_u32 v94, v94, 5, s24                             ; d646005e 00610b5e
	v_lshl_add_u32 v158, v158, 5, s24                           ; d646009e 00610b9e
(invalid instruction)                                        ; cc0f0071
	v_min_num_f64_e32 v[1:2], v[113:114], v[33:34]              ; 1a024371
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[96:97], v[78:79]                ; 1a029d60
	v_lshl_add_u32 v99, v99, 5, s24                             ; d6460063 00610b63
	v_lshl_add_u32 v95, v95, 5, s24                             ; d646005f 00610b5f
	v_lshl_add_u32 v159, v159, 5, s24                           ; d646009f 00610b9f
(invalid instruction)                                        ; cc0f0072
	v_min_num_f64_e32 v[1:2], v[114:115], v[132:133]            ; 1a030972
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v3, s11, v124, v116                         ; cc210003 05d2f80b
(invalid instruction)                                        ; cc0f00a1
	v_min_num_f64_e32 v[1:2], v[97:98], v[79:80]                ; 1a029f61
	v_fma_mixhi_f16 v3, s11, v125, v117                         ; cc220003 05d6fa0b
	v_fma_mixlo_f16 v36, s11, v126, v118                        ; cc210024 05dafc0b
(invalid instruction)                                        ; cc0f0073
	v_min_num_f64_e32 v[1:2], v[115:116], v[133:134]            ; 1a030b73
	v_fma_mixhi_f16 v36, s11, v127, v119                        ; cc220024 05defe0b
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[98:99], v[94:95]                ; 1a02bd62
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v37, s11, v128, v168                        ; cc210025 06a3000b
	v_fma_mixhi_f16 v37, s11, v129, v169                        ; cc220025 06a7020b
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[74:75]              ; 1a0295a0
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[99:100], v[95:96]               ; 1a02bf63
	v_fma_mixlo_f16 v116, s11, v130, v170                       ; cc210074 06ab040b
	v_fma_mixhi_f16 v116, s11, v131, v171                       ; cc220074 06af060b
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v117, s11, v4, v64                          ; cc210075 0502080b
(invalid instruction)                                        ; cc0f00a1
	v_min_num_f64_e32 v[1:2], v[161:162], v[75:76]              ; 1a0297a1
	v_fma_mixhi_f16 v117, s11, v5, v65                          ; cc220075 05060a0b
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v13                                ; 0a001b03
	v_fma_mixlo_f16 v118, s11, v6, v66                          ; cc210076 050a0c0b
	v_fma_mixhi_f16 v118, s11, v7, v67                          ; cc220076 050e0e0b
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v13                               ; 0a001b24
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v119, s11, v8, v80                          ; cc210077 0542100b
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[158:159]            ; 1a033dac
	v_fma_mixhi_f16 v119, s11, v9, v81                          ; cc220077 0546120b
(invalid instruction)                                        ; cc1c0025
	v_subrev_f32_e32 v0, v37, v13                               ; 0a001b25
	v_fma_mixlo_f16 v124, s11, v10, v82                         ; cc21007c 054a140b
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[159:160]            ; 1a033fad
	v_fma_mixhi_f16 v124, s11, v11, v83                         ; cc22007c 054e160b
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v125, s11, v86, v104                        ; cc21007d 05a2ac0b
(invalid instruction)                                        ; cc1c0074
	v_subrev_f32_e32 v0, v116, v13                              ; 0a001b74
	v_fma_mixhi_f16 v125, s11, v87, v105                        ; cc22007d 05a6ae0b
	v_fma_mixlo_f16 v126, s11, v88, v106                        ; cc21007e 05aab00b
(invalid instruction)                                        ; cc1c0075
	v_subrev_f32_e32 v0, v117, v13                              ; 0a001b75
	v_lshl_add_u32 v3, v3, 5, s24                               ; d6460003 00610b03
	v_fma_mixhi_f16 v126, s11, v89, v107                        ; cc22007e 05aeb20b
(invalid instruction)                                        ; cc1c0076
	v_subrev_f32_e32 v0, v118, v13                              ; 0a001b76
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v127, s11, v90, v28                         ; cc21007f 0472b40b
	v_fma_mixhi_f16 v127, s11, v91, v29                         ; cc22007f 0476b60b
	v_fma_mixlo_f16 v128, s11, v92, v30                         ; cc210080 047ab80b
	v_fma_mixhi_f16 v128, s11, v93, v31                         ; cc220080 047eba0b
(invalid instruction)                                        ; cc1c0077
	v_subrev_f32_e32 v0, v119, v13                              ; 0a001b77
	v_lshl_add_u32 v36, v36, 5, s24                             ; d6460024 00610b24
(invalid instruction)                                        ; cc1c007c
	v_subrev_f32_e32 v0, v124, v13                              ; 0a001b7c
	v_lshl_add_u32 v37, v37, 5, s24                             ; d6460025 00610b25
	v_lshl_add_u32 v116, v116, 5, s24                           ; d6460074 00610b74
(invalid instruction)                                        ; cc1c007d
	v_subrev_f32_e32 v0, v125, v13                              ; 0a001b7d
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[3:4]                  ; 1a020746
(invalid instruction)                                        ; cc1c007e
	v_subrev_f32_e32 v0, v126, v13                              ; 0a001b7e
(invalid instruction)                                        ; cc1c007f
	v_subrev_f32_e32 v0, v127, v13                              ; 0a001b7f
(invalid instruction)                                        ; cc1c0080
	v_subrev_f32_e32 v0, v128, v13                              ; 0a001b80
(invalid instruction)                                        ; cc0f0047
	v_min_num_f64_e32 v[1:2], v[71:72], v[36:37]                ; 1a024947
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[37:38]              ; 1a024b6e
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[116:117]            ; 1a02e96f
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[71:72]                ; 1a028f46
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[110:111]              ; 1a02dd46
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[111:112]              ; 1a02df46
	v_permlanex16_b32 v129, v70, s5, s8 op_sel:[1,1]            ; d65c1881 00200b46
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[129:130]              ; 1a030346
(invalid instruction)                                        ; d5321082
	v_cndmask_b32_e32 v1, v70, v70, vcc_lo                      ; 02028d46
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d5310082
	v_cndmask_b32_e32 v1, s3, v130, vcc_lo                      ; 02030403
(invalid instruction)                                        ; d58b0083
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                    ; 02010182
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v131, v131                                    ; 7f065583
	v_fma_mix_f32 v6, v54, v131, neg(0) op_sel_hi:[1,0,0]       ; cc200006 8a030736
	v_fma_mix_f32 v171, v162, v131, neg(0) op_sel_hi:[1,0,0]    ; cc2000ab 8a0307a2
	v_fma_mix_f32 v168, v72, v131, neg(0) op_sel_hi:[1,0,0]     ; cc2000a8 8a030748
	v_fma_mix_f32 v72, v72, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200848 8a030748
	v_fma_mix_f32 v7, v55, v131, neg(0) op_sel_hi:[1,0,0]       ; cc200007 8a030737
	v_fma_mix_f32 v170, v18, v131, neg(0) op_sel_hi:[1,0,0]     ; cc2000aa 8a030712
	v_fma_mix_f32 v162, v162, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a2 8a0307a2
	v_fma_mix_f32 v169, v73, v131, neg(0) op_sel_hi:[1,0,0]     ; cc2000a9 8a030749
	v_fma_mix_f32 v18, v18, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200812 8a030712
	v_fma_mix_f32 v54, v54, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200836 8a030736
	v_fma_mix_f32 v73, v73, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200849 8a030749
	v_fma_mix_f32 v55, v55, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200837 8a030737
	v_fma_mix_f32 v8, v108, v131, neg(0) op_sel_hi:[1,0,0]      ; cc200008 8a03076c
	v_fma_mix_f32 v108, v108, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086c 8a03076c
	v_fma_mix_f32 v9, v109, v131, neg(0) op_sel_hi:[1,0,0]      ; cc200009 8a03076d
	v_fma_mix_f32 v109, v109, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086d 8a03076d
	v_fma_mix_f32 v10, v38, v131, neg(0) op_sel_hi:[1,0,0]      ; cc20000a 8a030726
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v168, v72, vcc_lo                     ; 020291a8
	v_fma_mix_f32 v38, v38, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200826 8a030726
	v_fma_mix_f32 v11, v39, v131, neg(0) op_sel_hi:[1,0,0]      ; cc20000b 8a030727
	v_fma_mix_f32 v39, v39, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200827 8a030727
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v170, v18, vcc_lo                     ; 020225aa
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v171, v162, vcc_lo                    ; 020345ab
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v6, v54, vcc_lo                       ; 02026d06
	v_fma_mix_f32 v18, v120, v131, neg(0) op_sel_hi:[1,0,0]     ; cc200012 8a030778
	v_fma_mix_f32 v120, v120, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200878 8a030778
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v169, v73, vcc_lo                     ; 020293a9
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v7, v55, vcc_lo                       ; 02026f07
	v_fma_mix_f32 v28, v121, v131, neg(0) op_sel_hi:[1,0,0]     ; cc20001c 8a030779
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v8, v108, vcc_lo                      ; 0202d908
	v_fma_mix_f32 v121, v121, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200879 8a030779
	v_fma_mix_f32 v29, v3, v131, neg(0) op_sel_hi:[1,0,0]       ; cc20001d 8a030703
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v9, v109, vcc_lo                      ; 0202db09
	v_fma_mix_f32 v3, v3, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200803 8a030703
	v_fma_mix_f32 v30, v36, v131, neg(0) op_sel_hi:[1,0,0]      ; cc20001e 8a030724
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v10, v38, vcc_lo                      ; 02024d0a
	v_fma_mix_f32 v36, v36, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200824 8a030724
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v11, v39, vcc_lo                      ; 02024f0b
	v_fma_mix_f32 v31, v37, v131, neg(0) op_sel_hi:[1,0,0]      ; cc20001f 8a030725
	v_fma_mix_f32 v37, v37, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200825 8a030725
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v18, v120, vcc_lo                     ; 0202f112
	v_lshl_add_u32 v117, v117, 5, s24                           ; d6460075 00610b75
	v_lshl_add_u32 v118, v118, 5, s24                           ; d6460076 00610b76
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v28, v121, vcc_lo                     ; 0202f31c
	v_lshl_add_u32 v119, v119, 5, s24                           ; d6460077 00610b77
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v29, v3, vcc_lo                       ; 0202071d
	v_lshl_add_u32 v124, v124, 5, s24                           ; d646007c 00610b7c
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v30, v36, vcc_lo                      ; 0202491e
	v_fma_mix_f32 v36, v116, v131, neg(0) op_sel_hi:[1,0,0]     ; cc200024 8a030774
	v_fma_mix_f32 v116, v116, v131, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200874 8a030774
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v31, v37, vcc_lo                      ; 02024b1f
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[112:113], v[117:118]            ; 1a02eb70
(invalid instruction)                                        ; cc0f0071
	v_min_num_f64_e32 v[1:2], v[113:114], v[118:119]            ; 1a02ed71
(invalid instruction)                                        ; cc0f0072
	v_min_num_f64_e32 v[1:2], v[114:115], v[119:120]            ; 1a02ef72
(invalid instruction)                                        ; cc0f0073
	v_min_num_f64_e32 v[1:2], v[115:116], v[124:125]            ; 1a02f973
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v36, v116, vcc_lo                     ; 0202e924
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[112:113], v[113:114]            ; 1a02e370
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[112:113], v[114:115]            ; 1a02e570
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[112:113], v[115:116]            ; 1a02e770
	v_add_lshl_u32 v65, s9, v26, 2                              ; d6470041 020a3409
	v_permlanex16_b32 v37, v112, s5, s8 op_sel:[1,1]            ; d65c1825 00200b70
	buffer_load_b128 v[80:83], v65, s[20:23], null offen        ; c405c07c 40802850 00000041
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[112:113], v[37:38]              ; 1a024b70
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v38, v112, v240/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 644de170
	v_max_num_f16_e32 v38, s3, v38                              ; 624c4c03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1) ; bf8702b1
	v_cvt_f32_f16_e32 v39, v38                                  ; 7e4e1726
	buffer_load_b128 v[88:91], v65, s[20:23], null offen offset:16 ; c405c07c 40802858 00001041
	v_rcp_f32_e32 v39, v39                                      ; 7e4e5527
	v_fma_mix_f32 v66, v49, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200042 8a024f31
	v_fma_mix_f32 v49, v49, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200831 8a024f31
	v_fma_mix_f32 v64, v48, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200040 8a024f30
	v_fma_mix_f32 v70, v47, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200046 8a024f2f
	v_fma_mix_f32 v48, v48, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200830 8a024f30
	v_fma_mix_f32 v67, v46, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200043 8a024f2e
	v_fma_mix_f32 v46, v46, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082e 8a024f2e
	v_fma_mix_f32 v54, v163, v39, neg(0) op_sel_hi:[1,0,0]      ; cc200036 8a024fa3
	v_fma_mix_f32 v163, v163, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a3 8a024fa3
	v_fma_mix_f32 v55, v12, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200037 8a024f0c
	v_fma_mix_f32 v12, v12, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080c 8a024f0c
	v_fma_mix_f32 v47, v47, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082f 8a024f2f
	v_fma_mix_f32 v71, v76, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200047 8a024f4c
	v_fma_mix_f32 v76, v76, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084c 8a024f4c
	v_fma_mix_f32 v72, v77, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200048 8a024f4d
	v_fma_mix_f32 v77, v77, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084d 8a024f4d
	v_fma_mix_f32 v73, v32, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200049 8a024f20
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v64, v48, vcc_lo                      ; 02026140
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v66, v49, vcc_lo                      ; 02026342
	v_fma_mix_f32 v32, v32, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200820 8a024f20
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v67, v46, vcc_lo                      ; 02025d43
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v54, v163, vcc_lo                     ; 02034736
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v55, v12, vcc_lo                      ; 02021937
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v70, v47, vcc_lo                      ; 02025f46
	v_fma_mix_f32 v86, v133, v39, neg(0) op_sel_hi:[1,0,0]      ; cc200056 8a024f85
	v_fma_mix_f32 v133, v133, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200885 8a024f85
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v71, v76, vcc_lo                      ; 02029947
	v_fma_mix_f32 v76, v33, v39, neg(0) op_sel_hi:[1,0,0]       ; cc20004c 8a024f21
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v1, s6, v1, 2                                ; d6470001 020a0206
	buffer_load_b128 v[104:107], v1, s[16:19], null offen       ; c405c07c 40802068 00000001
	v_fma_mix_f32 v33, v33, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200821 8a024f21
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v72, v77, vcc_lo                      ; 02029b48
	v_fma_mix_f32 v77, v132, v39, neg(0) op_sel_hi:[1,0,0]      ; cc20004d 8a024f84
	v_fma_mix_f32 v132, v132, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200884 8a024f84
	v_fma_mix_f32 v87, v117, v39, neg(0) op_sel_hi:[1,0,0]      ; cc200057 8a024f75
	v_fma_mix_f32 v117, v117, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200875 8a024f75
	v_fma_mix_f32 v92, v118, v39, neg(0) op_sel_hi:[1,0,0]      ; cc20005c 8a024f76
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v73, v32, vcc_lo                      ; 02024149
	v_fma_mix_f32 v93, v119, v39, neg(0) op_sel_hi:[1,0,0]      ; cc20005d 8a024f77
	v_fma_mix_f32 v119, v119, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a024f77
	v_fma_mix_f32 v108, v124, v39, neg(0) op_sel_hi:[1,0,0]     ; cc20006c 8a024f7c
	v_fma_mix_f32 v124, v124, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087c 8a024f7c
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v76, v33, vcc_lo                      ; 0202434c
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v93, v119, vcc_lo                     ; 0202ef5d
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v108, v124, vcc_lo                    ; 0202f96c
	buffer_load_b128 v[108:111], v1, s[16:19], null offen offset:512 ; c405c07c 4080206c 00020001
	v_fma_mix_f32 v118, v118, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200876 8a024f76
	v_lshl_add_u32 v125, v125, 5, s24                           ; d646007d 00610b7d
	v_lshl_add_u32 v126, v126, 5, s24                           ; d646007e 00610b7e
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v77, v132, vcc_lo                     ; 0203094d
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v86, v133, vcc_lo                     ; 02030b56
	v_lshl_add_u32 v127, v127, 5, s24                           ; d646007f 00610b7f
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v87, v117, vcc_lo                     ; 0202eb57
	v_lshl_add_u32 v128, v128, 5, s24                           ; d6460080 00610b80
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v92, v118, vcc_lo                     ; 0202ed5c
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[125:126]            ; 1a02fba0
(invalid instruction)                                        ; cc0f00a1
	v_min_num_f64_e32 v[1:2], v[161:162], v[126:127]            ; 1a02fda1
(invalid instruction)                                        ; cc0f00ac
	v_min_num_f64_e32 v[1:2], v[172:173], v[127:128]            ; 1a02ffac
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[128:129]            ; 1a0301ad
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[161:162]            ; 1a0343a0
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[172:173]            ; 1a0359a0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[173:174]            ; 1a035ba0
	v_permlanex16_b32 v112, v160, s5, s8 op_sel:[1,1]           ; d65c1870 00200ba0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00a0
	v_min_num_f64_e32 v[1:2], v[160:161], v[112:113]            ; 1a02e1a0
(invalid instruction)                                        ; d5321071
	v_cndmask_b32_e32 v1, v160, v160, vcc_lo                    ; 020341a0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v113, s3, v113                            ; 62e2e203
	v_cvt_f32_f16_e32 v114, v113                                ; 7ee41771
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v114, v114                                    ; 7ee45572
	v_fma_mix_f32 v116, v97, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200074 8a02e561
	v_fma_mix_f32 v119, v78, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200077 8a02e54e
	v_fma_mix_f32 v115, v96, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200073 8a02e560
	v_fma_mix_f32 v117, v98, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200075 8a02e562
	v_fma_mix_f32 v98, v98, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200862 8a02e562
	v_fma_mix_f32 v97, v97, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200861 8a02e561
	v_fma_mix_f32 v120, v79, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200078 8a02e54f
	v_fma_mix_f32 v78, v78, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084e 8a02e54e
	v_fma_mix_f32 v96, v96, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200860 8a02e560
	v_fma_mix_f32 v118, v99, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200076 8a02e563
	v_fma_mix_f32 v99, v99, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200863 8a02e563
	v_fma_mix_f32 v79, v79, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084f 8a02e54f
	v_fma_mix_f32 v121, v94, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200079 8a02e55e
	v_fma_mix_f32 v94, v94, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085e 8a02e55e
	v_fma_mix_f32 v124, v95, v114, neg(0) op_sel_hi:[1,0,0]     ; cc20007c 8a02e55f
	v_fma_mix_f32 v95, v95, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085f 8a02e55f
	v_fma_mix_f32 v129, v74, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200081 8a02e54a
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v117, v98, vcc_lo                     ; 0202c575
	v_fma_mix_f32 v74, v74, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084a 8a02e54a
	v_fma_mix_f32 v130, v75, v114, neg(0) op_sel_hi:[1,0,0]     ; cc200082 8a02e54b
	v_fma_mix_f32 v75, v75, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084b 8a02e54b
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v119, v78, vcc_lo                     ; 02029d77
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v115, v96, vcc_lo                     ; 0202c173
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v116, v97, vcc_lo                     ; 0202c374
	v_fma_mix_f32 v131, v158, v114, neg(0) op_sel_hi:[1,0,0]    ; cc200083 8a02e59e
	v_fma_mix_f32 v158, v158, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089e 8a02e59e
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v118, v99, vcc_lo                     ; 0202c776
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v120, v79, vcc_lo                     ; 02029f78
	v_fma_mix_f32 v132, v159, v114, neg(0) op_sel_hi:[1,0,0]    ; cc200084 8a02e59f
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v121, v94, vcc_lo                     ; 0202bd79
	v_fma_mix_f32 v159, v159, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089f 8a02e59f
	v_fma_mix_f32 v133, v125, v114, neg(0) op_sel_hi:[1,0,0]    ; cc200085 8a02e57d
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v124, v95, vcc_lo                     ; 0202bf7c
	v_fma_mix_f32 v125, v125, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087d 8a02e57d
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v129, v74, vcc_lo                     ; 02029581
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v130, v75, vcc_lo                     ; 02029782
	v_fma_mix_f32 v160, v128, v114, neg(0) op_sel_hi:[1,0,0]    ; cc2000a0 8a02e580
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v131, v158, vcc_lo                    ; 02033d83
	v_fma_mix_f32 v158, v126, v114, neg(0) op_sel_hi:[1,0,0]    ; cc20009e 8a02e57e
	v_fma_mix_f32 v126, v126, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087e 8a02e57e
	v_fma_mix_f32 v128, v128, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200880 8a02e580
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[20:21], v[174:175], 0 ; cc464048 1a035d14
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[20:21], v[28:29], 0 ; cc46405c 1a023914
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v132, v159, vcc_lo                    ; 02033f84
	v_fma_mix_f32 v159, v127, v114, neg(0) op_sel_hi:[1,0,0]    ; cc20009f 8a02e57f
	v_fma_mix_f32 v127, v127, v114, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087f 8a02e57f
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[4:5], 0 ; cc464070 1a020914
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v133, v125, vcc_lo                    ; 0202fb85
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v158, v126, vcc_lo                    ; 0202fd9e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[40:41], v[68:69], v[72:79] ; cc464048 1d228928
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v159, v127, vcc_lo                    ; 0202ff9f
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v160, v128, vcc_lo                    ; 020301a0
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[20:21], v[38:39], 0 ; cc46407c 1a024d14
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[40:41], v[30:31], v[92:99] ; cc46405c 1d723d28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[40:41], v[6:7], v[112:119] ; cc464070 1dc20d28
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[44:45], v[72:79] ; cc464048 1d225918
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[40:41], v[46:47], v[124:131] ; cc46407c 1df25d28
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[24:25], v[36:37], v[92:99] ; cc46405c 1d724918
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[24:25], v[8:9], v[112:119] ; cc464070 1dc21118
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[102:103], v[14:15], v[72:79] ; cc464048 1d221d66
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[24:25], v[48:49], v[124:131] ; cc46407c 1df26118
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[102:103], v[32:33], v[92:99] ; cc46405c 1d724166
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[102:103], v[10:11], v[112:119] ; cc464070 1dc21566
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[102:103], v[54:55], v[124:131] ; cc46407c 1df26d66
	s_load_b128 s[4:7], s[14:15], 0x3c                          ; f4004107 f800003c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[22:23], v[174:175], 0 ; cc464048 1a035d16
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[4:5], 0 ; cc464070 1a020916
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[62:63], v[68:69], v[72:79] ; cc464048 1d22893e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[22:23], v[28:29], 0 ; cc4640a8 1a023916
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[22:23], v[38:39], 0 ; cc46405c 1a024d16
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[6:7], v[112:119] ; cc464070 1dc20d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[84:85], v[44:45], v[72:79] ; cc464048 1d225954
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[62:63], v[30:31], v[168:175] ; cc4640a8 1ea23d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[62:63], v[46:47], v[92:99] ; cc46405c 1d725d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[84:85], v[8:9], v[112:119] ; cc464070 1dc21154
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[50:51], v[14:15], v[72:79] ; cc464048 1d221d32
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[84:85], v[36:37], v[168:175] ; cc4640a8 1ea24954
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[84:85], v[48:49], v[92:99] ; cc46405c 1d726154
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[10:11], v[112:119] ; cc464070 1dc21532
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_mul_f32_e32 v72, v144, v80                                ; 1090a190
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	v_dual_mul_f32 v74, v146, v82 :: v_dual_mul_f32 v73, v145, v81 ; c8c6a592 4a48a391
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v76, v148, v88 :: v_dual_mul_f32 v75, v147, v83 ; c8c6b194 4c4aa793
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_dual_mul_f32 v78, v150, v90 :: v_dual_mul_f32 v77, v149, v89 ; c8c6b596 4e4cb395
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[50:51], v[32:33], v[168:175] ; cc4640a8 1ea24132
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[50:51], v[54:55], v[92:99] ; cc46405c 1d726d32
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_dual_mul_f32 v112, v152, v80 :: v_dual_mul_f32 v79, v151, v91 ; c8c6a198 704eb797
	s_load_b256 s[24:31], s[0:1], 0x0                           ; f4006600 f8000000
	v_dual_mul_f32 v116, v27, v88 :: v_dual_mul_f32 v113, v153, v81 ; c8c6b11b 7470a399
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_mul_f32 v114, v154, v82 :: v_dual_mul_f32 v115, v155, v83 ; c8c6a59a 7272a79b
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_mul_f32 v118, v53, v90 :: v_dual_mul_f32 v117, v52, v89 ; c8c6b535 7674b334
	v_dual_mul_f32 v48, v176, v80 :: v_dual_mul_f32 v119, v19, v91 ; c8c6a1b0 3076b713
	v_mul_f32_e32 v49, v177, v81                                ; 1062a3b1
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
	v_dual_mul_f32 v51, v179, v83 :: v_dual_mul_f32 v50, v178, v82 ; c8c6a7b3 3332a5b2
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	v_dual_mul_f32 v53, v181, v89 :: v_dual_mul_f32 v52, v180, v88 ; c8c6b3b5 3534b1b4
	v_dual_mul_f32 v55, v183, v91 :: v_dual_mul_f32 v54, v182, v90 ; c8c6b7b7 3736b5b6
	v_dual_mul_f32 v145, v185, v81 :: v_dual_mul_f32 v144, v184, v80 ; c8c6a3b9 9190a1b8
	v_dual_mul_f32 v147, v187, v83 :: v_dual_mul_f32 v146, v186, v82 ; c8c6a7bb 9392a5ba
	v_dual_mul_f32 v149, v189, v89 :: v_dual_mul_f32 v148, v188, v88 ; c8c6b3bd 9594b1bc
	v_dual_mul_f32 v151, v191, v91 :: v_dual_mul_f32 v150, v190, v90 ; c8c6b7bf 9796b5be
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[104:105], v[20:21], v[72:79] ; cc464048 1d222968
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[104:105], v[24:25], v[112:119] ; cc464070 1dc23168
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[104:105], v[40:41], v[48:55] ; cc464030 1cc25168
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[104:105], v[66:67], v[144:151] ; cc464090 1e428568
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl1_add_u32 s32, ttmp9, s4                              ; 87200475
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[108:109], v[4:5], v[72:79] ; cc464048 1d22096c
	s_lshl_b32 s33, ttmp7, 1                                    ; 84218173
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[108:109], v[6:7], v[112:119] ; cc464070 1dc20d6c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[108:109], v[8:9], v[48:55] ; cc464030 1cc2116c
	s_add_co_u32 s34, s33, s5                                   ; 80220521
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[10:11], v[144:151] ; cc464090 1e42156c
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v168, v75, v79 :: v_dual_cndmask_b32 v163, v74, v78 ; ca529f4b a8a29d4a
	buffer_load_b128 v[28:31], v65, s[20:23], null offen offset:64 ; c405c07c 4080281c 00004041
	v_dual_cndmask_b32 v161, v72, v76 :: v_dual_cndmask_b32 v162, v73, v77 ; ca529948 a1a29b49
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_dual_cndmask_b32 v79, v79, v75 :: v_dual_cndmask_b32 v78, v78, v74 ; ca52974f 4f4e954e
	v_dual_cndmask_b32 v77, v77, v73 :: v_dual_cndmask_b32 v76, v76, v72 ; ca52934d 4d4c914c
	buffer_load_b128 v[36:39], v65, s[20:23], null offen offset:80 ; c405c07c 40802824 00005041
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_mov_b32 s35, 0xf0f0f0f0                                   ; bea300ff f0f0f0f0
	v_and_b32_e32 v180, 1, v0                                   ; 37680081
	v_bfe_u32 v175, v0, 1, 1                                    ; d61000af 02050300
	v_bfe_u32 v176, v0, 3, 1                                    ; d61000b0 02050700
	v_add_f32_dpp v78, v78, v163 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069d46fa ff0cb14e
	v_add_f32_dpp v79, v79, v168 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069f50fa ff0cb14f
	v_bfe_u32 v0, v0, 2, 1                                      ; d6100000 02050500
	v_add_f32_dpp v76, v76, v161 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069942fa ff0cb14c
	v_add_f32_dpp v77, v77, v162 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069b44fa ff0cb14d
	v_lshlrev_b32_e32 v180, 2, v180                             ; 31696882
	s_ashr_i32 s36, s34, 1                                      ; 86248122
	s_ashr_i32 s37, s32, 1                                      ; 86258120
(invalid instruction)                                        ; d58a00a9
	v_cndmask_b32_e32 v0, v78, v128, vcc_lo                     ; 0201014e
(invalid instruction)                                        ; d58a00aa
	v_cndmask_b32_e32 v0, v79, v128, vcc_lo                     ; 0201014f
	v_lshl_add_u32 v176, v176, 2, v175                          ; d64600b0 06bd05b0
	v_lshlrev_b32_e32 v0, 1, v0                                 ; 30000081
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s36, s36, s7                                      ; 96240724
	v_cndmask_b32_e64 v78, v78, v76, s35                        ; d501004e 008e994e
(invalid instruction)                                        ; d58a00ab
	v_cndmask_b32_e32 v0, v76, v128, vcc_lo                     ; 0201014c
(invalid instruction)                                        ; d58a00ac
	v_cndmask_b32_e32 v0, v77, v128, vcc_lo                     ; 0201014d
	v_cndmask_b32_e64 v79, v79, v77, s35                        ; d501004f 008e9b4f
	s_mov_b32 s40, 0x3e800000                                   ; bea800ff 3e800000
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s38, s36, s37                                  ; 80262524
	s_and_b32 s4, s4, 1                                         ; 8b048104
	v_lshl_add_u32 v176, v176, 4, v26                           ; d64600b0 046909b0
	s_bitset0_b32 s6, 0                                         ; be861080
(invalid instruction)                                        ; d58a00ae
	v_cndmask_b32_dpp v0, v78, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d644e
	v_cndmask_b32_e64 v173, v171, v169, s35                     ; d50100ad 008f53ab
	v_cndmask_b16 v173, v172, v170, s35                         ; d65d40ad 008f55ac
(invalid instruction)                                        ; d58a40ae
	v_cndmask_b32_dpp v0, v79, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d644f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s4, s4, 5                                        ; 84048504
	s_and_b32 s5, s5, 1                                         ; 8b058105
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s5, s5, 7                                        ; 84058705
(invalid instruction)                                        ; cc0f00ad
	v_min_num_f64_e32 v[1:2], v[173:174], v[174:175]            ; 1a035dad
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s39, s5, s4                                    ; 80270405
	s_lshl_b32 s38, s38, 9                                      ; 84268926
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s41, s6, s38                                   ; 80292606
	v_fma_mix_f32 v177, s40, v173, neg(0) op_sel_hi:[0,1,0]     ; cc2000b1 92035a28
	v_fma_mix_f32 v173, s40, v173, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc2010ad 92035a28
	v_add3_u32 v179, v176, s41, s39                             ; d65500b3 009c53b0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c2
(invalid instruction)                                        ; d76900b2
	v_cndmask_b32_e32 v1, v177, v173, vcc_lo                    ; 02035bb1
	v_add3_u32 v179, v0, v179, v180                             ; d65500b3 06d36700
	buffer_store_b16 v178, v179, s[28:31], null offen           ; c406407c 408038b2 000000b3
	s_mul_i32 s42, s33, s12                                     ; 962a0c21
	s_lshl1_add_u32 s42, ttmp9, s42                             ; 872a2a75
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s42, s42, 9                                      ; 842a892a
	s_add_co_u32 s43, s2, s42                                   ; 802b2a02
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add3_u32 v181, v2, s43, v134                              ; d65500b5 06185702
	buffer_store_b64 v[14:15], v181, s[24:27], null offen       ; c406c07c 4080300e 000000b5
	v_dual_cndmask_b32 v183, v113, v117 :: v_dual_cndmask_b32 v182, v112, v116 ; ca52eb71 b7b6e970
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_cndmask_b32 v117, v117, v113 :: v_dual_cndmask_b32 v116, v116, v112 ; ca52e375 7574e174
	v_dual_cndmask_b32 v185, v115, v119 :: v_dual_cndmask_b32 v184, v114, v118 ; ca52ef73 b9b8ed72
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_cndmask_b32 v119, v119, v115 :: v_dual_cndmask_b32 v118, v118, v114 ; ca52e777 7776e576
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v116, v116, v182 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06e96cfa ff0cb174
	v_add_f32_dpp v117, v117, v183 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06eb6efa ff0cb175
	s_add_co_u32 s32, s32, 1                                    ; 80208120
	v_add_f32_dpp v118, v118, v184 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ed70fa ff0cb176
	v_add_f32_dpp v119, v119, v185 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ef72fa ff0cb177
	s_ashr_i32 s44, s32, 1                                      ; 862c8120
(invalid instruction)                                        ; d58a00bc
	v_cndmask_b32_e32 v0, v116, v128, vcc_lo                    ; 02010174
(invalid instruction)                                        ; d58a00bd
	v_cndmask_b32_e32 v0, v117, v128, vcc_lo                    ; 02010175
	s_add_co_u32 s36, s36, s44                                  ; 80242c24
	s_and_b32 s32, s32, 1                                       ; 8b208120
(invalid instruction)                                        ; d58a00ba
	v_cndmask_b32_e32 v0, v118, v128, vcc_lo                    ; 02010176
	v_cndmask_b32_e64 v118, v118, v116, s35                     ; d5010076 008ee976
(invalid instruction)                                        ; d58a00bb
	v_cndmask_b32_e32 v0, v119, v128, vcc_lo                    ; 02010177
	v_cndmask_b32_e64 v119, v119, v117, s35                     ; d5010077 008eeb77
	s_lshl_b32 s32, s32, 5                                      ; 84208520
	v_cndmask_b32_e64 v190, v188, v186, s35                     ; d50100be 008f75bc
(invalid instruction)                                        ; d58a00bf
	v_cndmask_b32_dpp v0, v118, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6476
	s_add_co_u32 s5, s5, s32                                    ; 80052005
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s36, s36, 9                                      ; 84248924
	v_cndmask_b16 v190, v189, v187, s35                         ; d65d40be 008f77bd
(invalid instruction)                                        ; d58a40bf
	v_cndmask_b32_dpp v0, v119, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6477
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s45, s6, s36                                   ; 802d2406
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870119
	v_add3_u32 v1, v176, s45, s5                                ; d6550001 00145bb0
(invalid instruction)                                        ; cc0f00be
	v_min_num_f64_e32 v[1:2], v[190:191], v[191:192]            ; 1a037fbe
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_add3_u32 v1, v0, v1, v180                                 ; d6550001 06d20300
	v_fma_mix_f32 v191, s40, v190, neg(0) op_sel_hi:[0,1,0]     ; cc2000bf 92037c28
	v_fma_mix_f32 v190, s40, v190, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc2010be 92037c28
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d76900bf
	v_cndmask_b32_e32 v1, v191, v190, vcc_lo                    ; 02037dbf
	buffer_store_b16 v191, v1, s[28:31], null offen             ; c406407c 408038bf 00000001
	s_addk_co_i32 s42, 0x200                                    ; b7aa0200
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s42, s2, s42                                   ; 802a2a02
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v3, v2, s42, v134                                ; d6550003 06185502
	buffer_store_b64 v[14:15], v3, s[24:27], null offen         ; c406c07c 4080300e 00000003
	v_cndmask_b32_e32 v12, v48, v52, vcc_lo                     ; 02186930
	v_cndmask_b32_e32 v18, v49, v53, vcc_lo                     ; 02246b31
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
	v_dual_cndmask_b32 v52, v52, v48 :: v_dual_cndmask_b32 v53, v53, v49 ; ca526134 34346335
	v_dual_cndmask_b32 v22, v51, v55 :: v_dual_cndmask_b32 v19, v50, v54 ; ca526f33 16126d32
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	v_dual_cndmask_b32 v54, v54, v50 :: v_dual_cndmask_b32 v55, v55, v51 ; ca526536 36366737
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_add_co_u32 s34, s34, 1                                    ; 80228122
	v_add_f32_dpp v52, v52, v12 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066818fa ff0cb134
	v_add_f32_dpp v53, v53, v18 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066a24fa ff0cb135
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_ashr_i32 s46, s34, 1                                      ; 862e8122
	v_add_f32_dpp v55, v55, v22 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066e2cfa ff0cb137
	v_add_f32_dpp v54, v54, v19 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066c26fa ff0cb136
	s_mul_i32 s46, s46, s7                                      ; 962e072e
	v_cvt_f16_f32_e32 v27, v52                                  ; 7e361534
	v_cvt_f16_f32_e32 v32, v53                                  ; 7e401535
	s_add_co_u32 s37, s46, s37                                  ; 8025252e
	s_and_b32 s34, s34, 1                                       ; 8b228122
	v_cvt_f16_f32_e32 v26, v55                                  ; 7e341537
	v_cndmask_b32_e64 v55, v55, v53, s35                        ; d5010037 008e6b37
	v_cvt_f16_f32_e32 v23, v54                                  ; 7e2e1536
	v_cndmask_b32_e64 v54, v54, v52, s35                        ; d5010036 008e6936
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s34, s34, 7                                      ; 84228722
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s34, s4                                    ; 80040422
	s_lshl_b32 s37, s37, 9                                      ; 84258925
	v_cndmask_b32_e64 v33, v27, v23, s35                        ; d5010021 008e2f1b
	v_cndmask_b16 v33, v32, v26, s35                            ; d65d4021 008e3520
	v_cvt_f16_f32_dpp v44, v54 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e5814fa ff0d6436
(invalid instruction)                                        ; 7f5814fa
(invalid instruction)                                        ; ff0d6437
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s47, s6, s37                                   ; 802f2506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870119
	v_add3_u32 v47, v176, s47, s4                               ; d655002f 00105fb0
(invalid instruction)                                        ; cc0f0021
	v_min_num_f64_e32 v[1:2], v[33:34], v[44:45]                ; 1a025921
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_add3_u32 v47, v0, v47, v180                               ; d655002f 06d25f00
	v_fma_mix_f32 v45, s40, v33, neg(0) op_sel_hi:[0,1,0]       ; cc20002d 92024228
	v_fma_mix_f32 v33, s40, v33, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201021 92024228
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b1
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v45, v33, vcc_lo                      ; 0202432d
	buffer_store_b16 v46, v47, s[28:31], null offen             ; c406407c 4080382e 0000002f
	s_add_co_u32 s33, s33, 1                                    ; 80218121
	s_mul_i32 s33, s33, s12                                     ; 96210c21
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl1_add_u32 s33, ttmp9, s33                             ; 87212175
	s_lshl_b32 s33, s33, 9                                      ; 84218921
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s48, s2, s33                                   ; 80302102
	v_add3_u32 v48, v2, s48, v134                               ; d6550030 06186102
	buffer_store_b64 v[14:15], v48, s[24:27], null offen        ; c406c07c 4080300e 00000030
	v_dual_cndmask_b32 v50, v145, v149 :: v_dual_cndmask_b32 v49, v144, v148 ; ca532b91 32312990
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_dual_cndmask_b32 v149, v149, v145 :: v_dual_cndmask_b32 v148, v148, v144 ; ca532395 95952194
	v_dual_cndmask_b32 v52, v147, v151 :: v_dual_cndmask_b32 v51, v146, v150 ; ca532f93 34332d92
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_dual_cndmask_b32 v151, v151, v147 :: v_dual_cndmask_b32 v150, v150, v146 ; ca532797 97972596
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v149, v149, v50 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 072a64fa ff0cb195
	v_add_f32_dpp v148, v148, v49 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 072862fa ff0cb194
	s_add_co_u32 s46, s46, s44                                  ; 802e2c2e
	s_add_co_u32 s34, s34, s32                                  ; 80222022
	v_add_f32_dpp v150, v150, v51 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 072c66fa ff0cb196
	v_add_f32_dpp v151, v151, v52 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 072e68fa ff0cb197
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s46, s46, 9                                      ; 842e892e
	v_cvt_f16_f32_e32 v62, v149                                 ; 7e7c1595
	v_cvt_f16_f32_e32 v55, v148                                 ; 7e6e1594
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s49, s6, s46                                   ; 80312e06
	v_cvt_f16_f32_e32 v53, v150                                 ; 7e6a1596
	v_cndmask_b32_e64 v150, v150, v148, s35                     ; d5010096 008f2996
	v_cvt_f16_f32_e32 v54, v151                                 ; 7e6c1597
	v_cndmask_b32_e64 v151, v151, v149, s35                     ; d5010097 008f2b97
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v69, v176, s49, s34                              ; d6550045 008863b0
	v_cndmask_b32_e64 v63, v55, v53, s35                        ; d501003f 008e6b37
	v_cvt_f16_f32_dpp v64, v150 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e8014fa ff0d6496
	v_cndmask_b16 v63, v62, v54, s35                            ; d65d403f 008e6d3e
(invalid instruction)                                        ; 7f8014fa
(invalid instruction)                                        ; ff0d6497
	v_add3_u32 v69, v0, v69, v180                               ; d6550045 06d28b00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f003f
	v_min_num_f64_e32 v[1:2], v[63:64], v[64:65]                ; 1a02813f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v65, s40, v63, neg(0) op_sel_hi:[0,1,0]       ; cc200041 92027e28
	v_fma_mix_f32 v63, s40, v63, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20103f 92027e28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b1
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v65, v63, vcc_lo                      ; 02027f41
	buffer_store_b16 v68, v69, s[28:31], null offen             ; c406407c 40803844 00000045
	s_addk_co_i32 s33, 0x200                                    ; b7a10200
	s_add_co_u32 s2, s2, s33                                    ; 80022102
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v70, v2, s2, v134                                ; d6550046 06180502
	buffer_store_b64 v[14:15], v70, s[24:27], null offen        ; c406c07c 4080300e 00000046
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_dual_mul_f32 v51, v57, v31 :: v_dual_mul_f32 v50, v56, v30 ; c8c63f39 33323d38
	v_dual_mul_f32 v57, v35, v29 :: v_dual_mul_f32 v56, v34, v28 ; c8c63b23 39383922
	v_dual_mul_f32 v81, v137, v29 :: v_dual_mul_f32 v80, v136, v28 ; c8c63b89 51503988
	v_dual_mul_f32 v49, v42, v29 :: v_dual_mul_f32 v48, v13, v28 ; c8c63b2a 3130390d
	v_dual_mul_f32 v73, v165, v29 :: v_dual_mul_f32 v72, v164, v28 ; c8c63ba5 494839a4
	v_dual_mul_f32 v75, v167, v31 :: v_dual_mul_f32 v74, v166, v30 ; c8c63fa7 4b4a3da6
	v_dual_mul_f32 v83, v139, v31 :: v_dual_mul_f32 v82, v138, v30 ; c8c63f8b 53523d8a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mul_f32 v53, v59, v37 :: v_dual_mul_f32 v52, v58, v36 ; c8c64b3b 3534493a
	v_dual_mul_f32 v59, v157, v31 :: v_dual_mul_f32 v58, v156, v30 ; c8c63f9d 3b3a3d9c
	v_dual_mul_f32 v77, v123, v37 :: v_dual_mul_f32 v76, v122, v36 ; c8c64b7b 4d4c497a
	v_dual_mul_f32 v85, v141, v37 :: v_dual_mul_f32 v84, v140, v36 ; c8c64b8d 5554498c
	v_dual_mul_f32 v63, v135, v39 :: v_dual_mul_f32 v62, v101, v38 ; c8c64f87 3f3e4d65
	v_dual_mul_f32 v87, v143, v39 :: v_dual_mul_f32 v86, v142, v38 ; c8c64f8f 57564d8e
	v_dual_mul_f32 v79, v17, v39 :: v_dual_mul_f32 v78, v16, v38 ; c8c64f11 4f4e4d10
	v_dual_mul_f32 v55, v61, v39 :: v_dual_mul_f32 v54, v60, v38 ; c8c64f3d 37364d3c
	v_dual_mul_f32 v61, v100, v37 :: v_dual_mul_f32 v60, v43, v36 ; c8c64b64 3d3c492b
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[106:107], v[20:21], v[48:55] ; cc464030 1cc2296a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[106:107], v[24:25], v[56:63] ; cc464038 1ce2316a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[106:107], v[40:41], v[72:79] ; cc464048 1d22516a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[106:107], v[66:67], v[80:87] ; cc464050 1d42856a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[110:111], v[4:5], v[48:55] ; cc464030 1cc2096e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[110:111], v[6:7], v[56:63] ; cc464038 1ce20d6e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[110:111], v[8:9], v[72:79] ; cc464048 1d22116e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[110:111], v[10:11], v[80:87] ; cc464050 1d42156e
	v_dual_cndmask_b32 v88, v49, v53 :: v_dual_cndmask_b32 v71, v48, v52 ; ca526b31 58466930
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
	v_dual_cndmask_b32 v53, v53, v49 :: v_dual_cndmask_b32 v52, v52, v48 ; ca526335 35346134
	v_dual_cndmask_b32 v89, v50, v54 :: v_dual_cndmask_b32 v90, v51, v55 ; ca526d32 595a6f33
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	v_dual_cndmask_b32 v55, v55, v51 :: v_dual_cndmask_b32 v54, v54, v50 ; ca526737 37366536
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v52, v52, v71 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06688efa ff0cb134
	v_add_f32_dpp v53, v53, v88 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066ab0fa ff0cb135
	v_add_f32_dpp v54, v54, v89 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066cb2fa ff0cb136
	v_add_f32_dpp v55, v55, v90 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066eb4fa ff0cb137
	s_movk_i32 s50, 0x100                                       ; b0320100
	v_cvt_f16_f32_e32 v93, v52                                  ; 7eba1534
	v_cvt_f16_f32_e32 v94, v53                                  ; 7ebc1535
	s_add_co_u32 s38, s38, s50                                  ; 80263226
	v_cvt_f16_f32_e32 v91, v54                                  ; 7eb61536
	v_cndmask_b32_e64 v54, v54, v52, s35                        ; d5010036 008e6936
	v_cvt_f16_f32_e32 v92, v55                                  ; 7eb81537
	v_cndmask_b32_e64 v55, v55, v53, s35                        ; d5010037 008e6b37
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s38, s6, s38                                   ; 80262606
	v_cndmask_b32_e64 v95, v93, v91, s35                        ; d501005f 008eb75d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v99, v176, s38, s39                              ; d6550063 009c4db0
	v_cvt_f16_f32_dpp v96, v54 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7ec014fa ff0d6436
	v_cndmask_b16 v95, v94, v92, s35                            ; d65d405f 008eb95e
(invalid instruction)                                        ; 7fc014fa
(invalid instruction)                                        ; ff0d6437
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_add3_u32 v99, v0, v99, v180                               ; d6550063 06d2c700
(invalid instruction)                                        ; cc0f005f
	v_min_num_f64_e32 v[1:2], v[95:96], v[96:97]                ; 1a02c15f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v97, s40, v95, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201061 9202be28
	v_fma_mix_f32 v95, s40, v95, neg(0) op_sel_hi:[0,1,0]       ; cc20005f 9202be28
(invalid instruction)                                        ; d7690062
	v_cndmask_b32_e32 v1, v95, v97, vcc_lo                      ; 0202c35f
	buffer_store_b16 v98, v99, s[28:31], null offen             ; c406407c 40803862 00000063
	v_add3_u32 v100, v134, s43, s50                             ; d6550064 00c85786
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v100, v100, v2                             ; 4ac80564
	buffer_store_b64 v[4:5], v100, s[24:27], null offen         ; c406c07c 40803004 00000064
	v_dual_cndmask_b32 v102, v57, v61 :: v_dual_cndmask_b32 v101, v56, v60 ; ca527b39 66647938
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
	v_dual_cndmask_b32 v61, v61, v57 :: v_dual_cndmask_b32 v60, v60, v56 ; ca52733d 3d3c713c
	v_dual_cndmask_b32 v104, v59, v63 :: v_dual_cndmask_b32 v103, v58, v62 ; ca527f3b 68667d3a
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	v_dual_cndmask_b32 v63, v63, v59 :: v_dual_cndmask_b32 v62, v62, v58 ; ca52773f 3f3e753e
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v61, v61, v102 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067accfa ff0cb13d
	v_add_f32_dpp v60, v60, v101 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 0678cafa ff0cb13c
	v_add_f32_dpp v62, v62, v103 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067ccefa ff0cb13e
	v_add_f32_dpp v63, v63, v104 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067ed0fa ff0cb13f
	s_add_co_u32 s36, s36, s50                                  ; 80243224
	v_cvt_f16_f32_e32 v108, v61                                 ; 7ed8153d
	v_cvt_f16_f32_e32 v107, v60                                 ; 7ed6153c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s36, s6, s36                                   ; 80242406
	v_cvt_f16_f32_e32 v105, v62                                 ; 7ed2153e
	v_cndmask_b32_e64 v62, v62, v60, s35                        ; d501003e 008e793e
	v_cvt_f16_f32_e32 v106, v63                                 ; 7ed4153f
	v_cndmask_b32_e64 v63, v63, v61, s35                        ; d501003f 008e7b3f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v113, v176, s36, s5                              ; d6550071 001449b0
	v_cndmask_b32_e64 v109, v107, v105, s35                     ; d501006d 008ed36b
	v_cvt_f16_f32_dpp v110, v62 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7edc14fa ff0d643e
	v_cndmask_b16 v109, v108, v106, s35                         ; d65d406d 008ed56c
(invalid instruction)                                        ; 7fdc14fa
(invalid instruction)                                        ; ff0d643f
	v_add3_u32 v113, v0, v113, v180                             ; d6550071 06d2e300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f006d
	v_min_num_f64_e32 v[1:2], v[109:110], v[110:111]            ; 1a02dd6d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v111, s40, v109, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20106f 9202da28
	v_fma_mix_f32 v109, s40, v109, neg(0) op_sel_hi:[0,1,0]     ; cc20006d 9202da28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690070
	v_cndmask_b32_e32 v1, v109, v111, vcc_lo                    ; 0202df6d
	buffer_store_b16 v112, v113, s[28:31], null offen           ; c406407c 40803870 00000071
	v_add3_u32 v114, v134, s42, s50                             ; d6550072 00c85586
	v_add_nc_u32_e32 v114, v114, v2                             ; 4ae40572
	buffer_store_b64 v[4:5], v114, s[24:27], null offen         ; c406c07c 40803004 00000072
	v_dual_cndmask_b32 v116, v73, v77 :: v_dual_cndmask_b32 v115, v72, v76 ; ca529b49 74729948
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
	v_dual_cndmask_b32 v77, v77, v73 :: v_dual_cndmask_b32 v76, v76, v72 ; ca52934d 4d4c914c
	v_dual_cndmask_b32 v118, v75, v79 :: v_dual_cndmask_b32 v117, v74, v78 ; ca529f4b 76749d4a
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_dual_cndmask_b32 v79, v79, v75 :: v_dual_cndmask_b32 v78, v78, v74 ; ca52974f 4f4e954e
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v76, v76, v115 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 0698e6fa ff0cb14c
	v_add_f32_dpp v77, v77, v116 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069ae8fa ff0cb14d
	v_add_f32_dpp v78, v78, v117 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069ceafa ff0cb14e
	v_add_f32_dpp v79, v79, v118 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 069eecfa ff0cb14f
	s_add_co_u32 s37, s37, s50                                  ; 80253225
	v_cvt_f16_f32_e32 v121, v76                                 ; 7ef2154c
	v_cvt_f16_f32_e32 v122, v77                                 ; 7ef4154d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s6, s37                                   ; 80252506
	v_cvt_f16_f32_e32 v119, v78                                 ; 7eee154e
	v_cndmask_b32_e64 v78, v78, v76, s35                        ; d501004e 008e994e
	v_cvt_f16_f32_e32 v120, v79                                 ; 7ef0154f
	v_cndmask_b32_e64 v79, v79, v77, s35                        ; d501004f 008e9b4f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v127, v176, s37, s4                              ; d655007f 00104bb0
	v_cndmask_b32_e64 v123, v121, v119, s35                     ; d501007b 008eef79
	v_cvt_f16_f32_dpp v124, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7ef814fa ff0d644e
	v_cndmask_b16 v123, v122, v120, s35                         ; d65d407b 008ef17a
(invalid instruction)                                        ; 7ff814fa
(invalid instruction)                                        ; ff0d644f
	v_add3_u32 v127, v0, v127, v180                             ; d655007f 06d2ff00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f007b
	v_min_num_f64_e32 v[1:2], v[123:124], v[124:125]            ; 1a02f97b
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v125, s40, v123, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20107d 9202f628
	v_fma_mix_f32 v123, s40, v123, neg(0) op_sel_hi:[0,1,0]     ; cc20007b 9202f628
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d769007e
	v_cndmask_b32_e32 v1, v123, v125, vcc_lo                    ; 0202fb7b
	buffer_store_b16 v126, v127, s[28:31], null offen           ; c406407c 4080387e 0000007f
	v_add3_u32 v128, v134, s48, s50                             ; d6550080 00c86186
	v_add_nc_u32_e32 v128, v128, v2                             ; 4b000580
	buffer_store_b64 v[4:5], v128, s[24:27], null offen         ; c406c07c 40803004 00000080
	v_dual_cndmask_b32 v130, v81, v85 :: v_dual_cndmask_b32 v129, v80, v84 ; ca52ab51 8280a950
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
	v_dual_cndmask_b32 v85, v85, v81 :: v_dual_cndmask_b32 v84, v84, v80 ; ca52a355 5554a154
	v_dual_cndmask_b32 v132, v83, v87 :: v_dual_cndmask_b32 v131, v82, v86 ; ca52af53 8482ad52
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_dual_cndmask_b32 v87, v87, v83 :: v_dual_cndmask_b32 v86, v86, v82 ; ca52a757 5756a556
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v85, v85, v130 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ab04fa ff0cb155
	v_add_f32_dpp v84, v84, v129 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06a902fa ff0cb154
	v_add_f32_dpp v86, v86, v131 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ad06fa ff0cb156
	v_add_f32_dpp v87, v87, v132 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06af08fa ff0cb157
	s_add_co_u32 s46, s46, s50                                  ; 802e322e
(invalid instruction)                                        ; d58a0089
	v_cndmask_b32_e32 v0, v85, v128, vcc_lo                     ; 02010155
(invalid instruction)                                        ; d58a0088
	v_cndmask_b32_e32 v0, v84, v128, vcc_lo                     ; 02010154
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s46                                    ; 80062e06
(invalid instruction)                                        ; d58a0085
	v_cndmask_b32_e32 v0, v86, v128, vcc_lo                     ; 02010156
	v_cndmask_b32_e64 v86, v86, v84, s35                        ; d5010056 008ea956
(invalid instruction)                                        ; d58a0087
	v_cndmask_b32_e32 v0, v87, v128, vcc_lo                     ; 02010157
	v_cndmask_b32_e64 v87, v87, v85, s35                        ; d5010057 008eab57
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v176, v176, s6, s34                              ; d65500b0 00880db0
	v_cndmask_b32_e64 v138, v136, v133, s35                     ; d501008a 008f0b88
(invalid instruction)                                        ; d58a008b
	v_cndmask_b32_dpp v0, v86, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6456
	v_cndmask_b16 v138, v137, v135, s35                         ; d65d408a 008f0f89
(invalid instruction)                                        ; d58a408b
	v_cndmask_b32_dpp v0, v87, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6457
	v_add3_u32 v0, v0, v176, v180                               ; d6550000 06d36100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f008a
	v_min_num_f64_e32 v[1:2], v[138:139], v[139:140]            ; 1a03178a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v140, s40, v138, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20108c 92031428
	v_fma_mix_f32 v138, s40, v138, neg(0) op_sel_hi:[0,1,0]     ; cc20008a 92031428
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d769008d
	v_cndmask_b32_e32 v1, v138, v140, vcc_lo                    ; 0203198a
	buffer_store_b16 v141, v0, s[28:31], null offen             ; c406407c 4080388d 00000000
	v_add3_u32 v134, v134, s2, s50                              ; d6550086 00c80586
	v_add_nc_u32_e32 v134, v134, v2                             ; 4b0c0586
	buffer_store_b64 v[4:5], v134, s[24:27], null offen         ; c406c07c 40803004 00000086
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
