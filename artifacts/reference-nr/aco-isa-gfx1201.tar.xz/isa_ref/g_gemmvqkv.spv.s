BB0:
	v_and_b32_e32 v3, 31, v0                                    ; 3606009f
	s_lshr_b32 s7, s6, 4                                        ; 85078406
	s_lshl_b32 s8, ttmp9, 6                                     ; 84088675
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_lshr_b32 s9, s8, 4                                        ; 85098408
	v_lshlrev_b32_e32 v4, 2, v3                                 ; 30080682
	v_bfe_u32 v1, v0, 5, 2                                      ; d6100001 02090b00
	s_mul_i32 s9, s9, s7                                        ; 96090709
	s_lshl_b32 s9, s9, 8                                        ; 84098809
	s_add_co_u32 s10, 16, s8                                    ; 800a0890
	v_and_b32_e32 v0, 15, v0                                    ; 3600008f
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	s_lshr_b32 s11, s10, 4                                      ; 850b840a
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870159
	s_mul_i32 s11, s11, s7                                      ; 960b070b
	v_lshlrev_b32_e32 v0, 4, v0                                 ; 30000084
	v_lshlrev_b32_e32 v3, 3, v3                                 ; 30060683
	s_lshl_b32 s11, s11, 8                                      ; 840b880b
	s_add_co_u32 s12, 32, s8                                    ; 800c08a0
	v_add3_u32 v8, v0, s1, s11                                  ; d6550008 002c0300
	v_add3_u32 v7, v0, s1, s9                                   ; d6550007 00240300
	s_lshr_b32 s13, s12, 4                                      ; 850d840c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mul_i32 s13, s13, s7                                      ; 960d070d
	v_add_nc_u32_e32 v8, v8, v3                                 ; 4a100708
	v_add_nc_u32_e32 v7, v7, v3                                 ; 4a0e0707
	s_lshl_b32 s13, s13, 8                                      ; 840d880d
	s_add_co_u32 s14, 48, s8                                    ; 800e08b0
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0              ; ca100080 10100080
	v_add3_u32 v9, v0, s1, s13                                  ; d6550009 00340300
	s_lshr_b32 s15, s14, 4                                      ; 850f840e
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0              ; ca100080 12120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	s_mul_i32 s15, s15, s7                                      ; 960f070f
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0              ; ca100080 18180080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_add_nc_u32_e32 v9, v9, v3                                 ; 4a120709
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0              ; ca100080 1c1c0080
	s_lshl_b32 s15, s15, 8                                      ; 840f880f
	s_lshl_b32 s16, ttmp7, 8                                    ; 84108873
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_lshr_b32 s6, s6, 5                                        ; 85068506
	v_lshrrev_b32_e32 v7, 2, v7                                 ; 320e0e82
	v_lshrrev_b32_e32 v8, 2, v8                                 ; 32101082
	v_add3_u32 v0, v0, s1, s15                                  ; d6550000 003c0300
	s_mov_b32 s1, 0                                             ; be810080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_lshrrev_b32_e32 v9, 2, v9                                 ; 32121282
	v_lshl_add_u32 v1, v1, 6, s16                               ; d6460001 00410d01
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_add_nc_u32_e32 v0, v0, v3                                 ; 4a000700
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	v_add_nc_u32_e32 v5, 32, v1                                 ; 4a0a02a0
	v_lshrrev_b32_e32 v2, 5, v1                                 ; 32040285
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v60, 0              ; ca100080 3d3c0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v62, 0              ; ca100080 3f3e0080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v64, 0              ; ca100080 41400080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0              ; ca100080 43420080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v68, 0              ; ca100080 45440080
	v_lshrrev_b32_e32 v0, 2, v0                                 ; 32000082
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v70, 0              ; ca100080 47460080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v72, 0              ; ca100080 49480080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v74, 0              ; ca100080 4b4a0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v76, 0              ; ca100080 4d4c0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v78, 0              ; ca100080 4f4e0080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v80, 0              ; ca100080 51500080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v82, 0              ; ca100080 53520080
	v_lshrrev_b32_e32 v6, 5, v5                                 ; 320c0a85
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v84, 0              ; ca100080 55540080
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v2, v7, vcc_lo                        ; 02000f02
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v86, 0              ; ca100080 57560080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v88, 0              ; ca100080 59580080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v90, 0              ; ca100080 5b5a0080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v92, 0              ; ca100080 5d5c0080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v94, 0              ; ca100080 5f5e0080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v96, 0              ; ca100080 61600080
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v98, 0              ; ca100080 63620080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v100, 0            ; ca100080 65640080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v102, 0            ; ca100080 67660080
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v104, 0            ; ca100080 69680080
	v_dual_mov_b32 v107, 0 :: v_dual_mov_b32 v106, 0            ; ca100080 6b6a0080
	v_dual_mov_b32 v109, 0 :: v_dual_mov_b32 v108, 0            ; ca100080 6d6c0080
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v110, 0            ; ca100080 6f6e0080
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v6, v7, vcc_lo                        ; 02000f06
	v_dual_mov_b32 v113, 0 :: v_dual_mov_b32 v112, 0            ; ca100080 71700080
	v_dual_mov_b32 v115, 0 :: v_dual_mov_b32 v114, 0            ; ca100080 73720080
	v_dual_mov_b32 v117, 0 :: v_dual_mov_b32 v116, 0            ; ca100080 75740080
	v_dual_mov_b32 v119, 0 :: v_dual_mov_b32 v118, 0            ; ca100080 77760080
	v_dual_mov_b32 v121, 0 :: v_dual_mov_b32 v120, 0            ; ca100080 79780080
	v_dual_mov_b32 v123, 0 :: v_dual_mov_b32 v122, 0            ; ca100080 7b7a0080
	v_dual_mov_b32 v125, 0 :: v_dual_mov_b32 v124, 0            ; ca100080 7d7c0080
	v_dual_mov_b32 v127, 0 :: v_dual_mov_b32 v126, 0            ; ca100080 7f7e0080
	v_lshl_add_u32 v2, v2, 7, s3                                ; d6460002 000d0f02
	v_dual_mov_b32 v129, 0 :: v_dual_mov_b32 v128, 0            ; ca100080 81800080
	v_dual_mov_b32 v131, 0 :: v_dual_mov_b32 v130, 0            ; ca100080 83820080
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v132, 0            ; ca100080 85840080
	v_dual_mov_b32 v135, 0 :: v_dual_mov_b32 v134, 0            ; ca100080 87860080
	v_dual_mov_b32 v137, 0 :: v_dual_mov_b32 v136, 0            ; ca100080 89880080
	v_dual_mov_b32 v139, 0 :: v_dual_mov_b32 v138, 0            ; ca100080 8b8a0080
	v_dual_mov_b32 v141, 0 :: v_dual_mov_b32 v140, 0            ; ca100080 8d8c0080
	v_dual_mov_b32 v143, 0 :: v_dual_mov_b32 v142, 0            ; ca100080 8f8e0080
	v_lshl_add_u32 v6, v6, 7, s3                                ; d6460006 000d0f06
	s_branch BB1                                                ; bfa0008d
	s_nop 0                                                     ; bf800000
	(then repeated 1 times)
BB3:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[16:17], 0x70                        ; f4004508 f8000070
	s_load_b128 s[16:19], s[16:17], 0x30                        ; f4004408 f8000030
	s_lshl_b32 s3, s1, 5                                        ; 84038501
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s3, s3, 4                                        ; 85038403
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s7, s3, 8                                        ; 84078803
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s7, s7, 2                                        ; 85078207
	s_lshl_b32 s3, s3, 7                                        ; 84038703
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v3, s7, v7, 2                                ; d6470003 020a0e07
	v_add_lshl_u32 v10, s7, v8, 2                               ; d647000a 020a1007
	v_add_lshl_u32 v11, s7, v9, 2                               ; d647000b 020a1207
	v_add_lshl_u32 v12, s7, v0, 2                               ; d647000c 020a0007
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[14:15], v3, s[20:23], null offen          ; c405407c 4080280e 00000003
	buffer_load_b64 v[144:145], v10, s[20:23], null offen       ; c405407c 40802890 0000000a
	buffer_load_b64 v[146:147], v11, s[20:23], null offen       ; c405407c 40802892 0000000b
	buffer_load_b64 v[148:149], v12, s[20:23], null offen       ; c405407c 40802894 0000000c
	buffer_load_b64 v[152:153], v3, s[20:23], null offen offset:256 ; c405407c 40802898 00010003
	buffer_load_b64 v[154:155], v10, s[20:23], null offen offset:256 ; c405407c 4080289a 0001000a
	buffer_load_b64 v[10:11], v11, s[20:23], null offen offset:256 ; c405407c 4080280a 0001000b
	buffer_load_b64 v[156:157], v12, s[20:23], null offen offset:256 ; c405407c 4080289c 0001000c
	v_add3_u32 v13, s3, v2, v4                                  ; d655000d 04120403
	v_add3_u32 v150, s3, v6, v4                                 ; d6550096 04120c03
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshlrev_b32_e32 v13, 2, v13                               ; 301a1a82
	v_lshlrev_b32_e32 v150, 2, v150                             ; 312d2c82
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[160:163], v13, s[16:19], null offen      ; c405c07c 408020a0 0000000d
	buffer_load_b128 v[164:167], v150, s[16:19], null offen     ; c405c07c 408020a4 00000096
	buffer_load_b128 v[168:171], v13, s[16:19], null offen offset:512 ; c405c07c 408020a8 0002000d
	buffer_load_b128 v[172:175], v150, s[16:19], null offen offset:512 ; c405c07c 408020ac 00020096
	s_add_co_u32 s1, s1, 1                                      ; 80018101
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[148:149], v[160:161], v[112:119] ; cc464070 1dc34194
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[148:149], v[162:163], v[120:127] ; cc464078 1de34594
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[144:145], v[162:163], v[56:63] ; cc464038 1ce34590
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[146:147], v[160:161], v[80:87] ; cc464050 1d434192
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[146:147], v[162:163], v[88:95] ; cc464058 1d634592
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[14:15], v[160:161], v[16:23] ; cc464010 1c43410e
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[14:15], v[162:163], v[24:31] ; cc464018 1c63450e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[144:145], v[160:161], v[48:55] ; cc464030 1cc34190
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[14:15], v[166:167], v[40:47] ; cc464028 1ca34d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[14:15], v[164:165], v[32:39] ; cc464020 1c83490e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[144:145], v[164:165], v[64:71] ; cc464040 1d034990
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[144:145], v[166:167], v[72:79] ; cc464048 1d234d90
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[146:147], v[164:165], v[96:103] ; cc464060 1d834992
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[146:147], v[166:167], v[104:111] ; cc464068 1da34d92
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[148:149], v[164:165], v[128:135] ; cc464080 1e034994
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[148:149], v[166:167], v[136:143] ; cc464088 1e234d94
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[154:155], v[170:171], v[56:63] ; cc464038 1ce3559a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[10:11], v[168:169], v[80:87] ; cc464050 1d43510a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[10:11], v[170:171], v[88:95] ; cc464058 1d63550a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[156:157], v[168:169], v[112:119] ; cc464070 1dc3519c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[152:153], v[168:169], v[16:23] ; cc464010 1c435198
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[156:157], v[170:171], v[120:127] ; cc464078 1de3559c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[152:153], v[170:171], v[24:31] ; cc464018 1c635598
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[154:155], v[168:169], v[48:55] ; cc464030 1cc3519a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[152:153], v[174:175], v[40:47] ; cc464028 1ca35d98
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[152:153], v[172:173], v[32:39] ; cc464020 1c835998
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[154:155], v[172:173], v[64:71] ; cc464040 1d03599a
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[154:155], v[174:175], v[72:79] ; cc464048 1d235d9a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[10:11], v[172:173], v[96:103] ; cc464060 1d83590a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[174:175], v[104:111] ; cc464068 1da35d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[156:157], v[172:173], v[128:135] ; cc464080 1e03599c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[156:157], v[174:175], v[136:143] ; cc464088 1e235d9c
BB1:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s1, s6                                         ; bf090601
	s_cbranch_scc0 BB3                                          ; bfa1ff72
BB4:
	s_cmp_lt_u32 s8, s4                                         ; bf0a0408
	s_cbranch_scc0 BB7                                          ; bfa10061
BB5:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[16:19], s[6:7], 0x0                           ; f4004403 f8000000
(invalid instruction)                                        ; d71f000b
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_mul_i32 s1, s8, s5                                        ; 96010508
	v_cvt_f16_f32_e32 v0, v16                                   ; 7e001510
	v_cvt_f16_f32_e32 v2, v17                                   ; 7e041511
	v_cvt_f16_f32_e32 v3, v18                                   ; 7e061512
	v_cvt_f16_f32_e32 v4, v19                                   ; 7e081513
	v_cvt_f16_f32_e32 v6, v20                                   ; 7e0c1514
	v_cvt_f16_f32_e32 v7, v21                                   ; 7e0e1515
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v10, v1, s2, s1                                  ; d655000a 00040501
	v_cvt_f16_f32_e32 v8, v22                                   ; 7e101516
	v_lshrrev_b32_e32 v12, 4, v11                               ; 32181684
	v_and_b32_e32 v11, 15, v11                                  ; 3616168f
	v_cvt_f16_f32_e32 v9, v23                                   ; 7e121517
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_lshlrev_b32_e32 v12, 3, v12                               ; 30181883
	v_add_nc_u32_e32 v15, 2, v12                                ; 4a1e1882
	v_add_nc_u32_e32 v16, 3, v12                                ; 4a201883
	v_add_nc_u32_e32 v17, 4, v12                                ; 4a221884
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v12, v5, vcc_lo                       ; 02000b0c
	v_add_nc_u32_e32 v14, 1, v12                                ; 4a1c1881
(invalid instruction)                                        ; d72c000f
	v_cndmask_b32_e32 v0, v15, v5, vcc_lo                       ; 02000b0f
(invalid instruction)                                        ; d72c0010
	v_cndmask_b32_e32 v0, v16, v5, vcc_lo                       ; 02000b10
	v_add_nc_u32_e32 v18, 5, v12                                ; 4a241885
(invalid instruction)                                        ; d72c0011
	v_cndmask_b32_e32 v0, v17, v5, vcc_lo                       ; 02000b11
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v0, v14, v5, vcc_lo                       ; 02000b0e
	v_add3_u32 v13, v11, v10, v13                               ; d655000d 0436150b
	v_add_nc_u32_e32 v19, 6, v12                                ; 4a261886
	v_add3_u32 v15, v11, v10, v15                               ; d655000f 043e150b
(invalid instruction)                                        ; d72c0012
	v_cndmask_b32_e32 v0, v18, v5, vcc_lo                       ; 02000b12
	v_add3_u32 v16, v11, v10, v16                               ; d6550010 0442150b
	v_add_nc_u32_e32 v12, 7, v12                                ; 4a181887
	v_add3_u32 v17, v11, v10, v17                               ; d6550011 0446150b
	v_lshlrev_b32_e32 v13, 1, v13                               ; 301a1a81
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v0, v19, v5, vcc_lo                       ; 02000b13
	v_lshlrev_b32_e32 v15, 1, v15                               ; 301e1e81
	v_add3_u32 v14, v11, v10, v14                               ; d655000e 043a150b
	v_lshlrev_b32_e32 v16, 1, v16                               ; 30202081
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v0, v12, v5, vcc_lo                       ; 02000b0c
	v_add3_u32 v18, v11, v10, v18                               ; d6550012 044a150b
	v_lshlrev_b32_e32 v17, 1, v17                               ; 30222281
	v_lshlrev_b32_e32 v14, 1, v14                               ; 301c1c81
	v_add3_u32 v19, v11, v10, v19                               ; d6550013 044e150b
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_lshlrev_b32_e32 v18, 1, v18                               ; 30242481
	v_add3_u32 v11, v11, v10, v12                               ; d655000b 0432150b
	v_lshlrev_b32_e32 v19, 1, v19                               ; 30262681
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshlrev_b32_e32 v11, 1, v11                               ; 30161681
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b16 v0, v13, s[16:19], null offen              ; c406407c 40802000 0000000d
	buffer_store_b16 v2, v14, s[16:19], null offen              ; c406407c 40802002 0000000e
	buffer_store_b16 v3, v15, s[16:19], null offen              ; c406407c 40802003 0000000f
	buffer_store_b16 v4, v16, s[16:19], null offen              ; c406407c 40802004 00000010
	buffer_store_b16 v6, v17, s[16:19], null offen              ; c406407c 40802006 00000011
	buffer_store_b16 v7, v18, s[16:19], null offen              ; c406407c 40802007 00000012
	buffer_store_b16 v8, v19, s[16:19], null offen              ; c406407c 40802008 00000013
	buffer_store_b16 v9, v11, s[16:19], null offen              ; c406407c 40802009 0000000b
BB7:
	v_add_nc_u32_e32 v0, 16, v1                                 ; 4a000290
	s_cbranch_scc0 BB10                                         ; bfa1009a
BB8:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[16:19], s[6:7], 0x0                           ; f4004403 f8000000
(invalid instruction)                                        ; d71f000c
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_mul_i32 s1, s8, s5                                        ; 96010508
	v_cvt_f16_f32_e32 v2, v24                                   ; 7e041518
	v_cvt_f16_f32_e32 v3, v25                                   ; 7e061519
	v_cvt_f16_f32_e32 v4, v26                                   ; 7e08151a
	v_cvt_f16_f32_e32 v6, v27                                   ; 7e0c151b
	v_cvt_f16_f32_e32 v7, v28                                   ; 7e0e151c
	v_cvt_f16_f32_e32 v8, v29                                   ; 7e10151d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v11, v0, s2, s1                                  ; d655000b 00040500
	v_cvt_f16_f32_e32 v9, v30                                   ; 7e12151e
	v_lshrrev_b32_e32 v13, 4, v12                               ; 321a1884
	v_and_b32_e32 v12, 15, v12                                  ; 3618188f
	v_cvt_f16_f32_e32 v10, v31                                  ; 7e14151f
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_lshlrev_b32_e32 v13, 3, v13                               ; 301a1a83
	v_add_nc_u32_e32 v18, 2, v13                                ; 4a241a82
	v_add_nc_u32_e32 v20, 3, v13                                ; 4a281a83
	v_add_nc_u32_e32 v22, 4, v13                                ; 4a2c1a84
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v0, v13, v5, vcc_lo                       ; 02000b0d
	v_add_nc_u32_e32 v16, 1, v13                                ; 4a201a81
(invalid instruction)                                        ; d72c0012
	v_cndmask_b32_e32 v0, v18, v5, vcc_lo                       ; 02000b12
(invalid instruction)                                        ; d72c0014
	v_cndmask_b32_e32 v0, v20, v5, vcc_lo                       ; 02000b14
	v_add_nc_u32_e32 v24, 5, v13                                ; 4a301a85
(invalid instruction)                                        ; d72c0016
	v_cndmask_b32_e32 v0, v22, v5, vcc_lo                       ; 02000b16
(invalid instruction)                                        ; d72c0010
	v_cndmask_b32_e32 v0, v16, v5, vcc_lo                       ; 02000b10
	v_add3_u32 v15, v12, v11, v14                               ; d655000f 043a170c
	v_add_nc_u32_e32 v26, 6, v13                                ; 4a341a86
	v_add3_u32 v19, v12, v11, v18                               ; d6550013 044a170c
(invalid instruction)                                        ; d72c0018
	v_cndmask_b32_e32 v0, v24, v5, vcc_lo                       ; 02000b18
	v_add3_u32 v21, v12, v11, v20                               ; d6550015 0452170c
	v_cvt_f16_f32_e32 v28, v32                                  ; 7e381520
	v_cvt_f16_f32_e32 v32, v36                                  ; 7e401524
	v_add3_u32 v23, v12, v11, v22                               ; d6550017 045a170c
	v_lshlrev_b32_e32 v15, 1, v15                               ; 301e1e81
(invalid instruction)                                        ; d72c001a
	v_cndmask_b32_e32 v0, v26, v5, vcc_lo                       ; 02000b1a
	v_add3_u32 v36, v5, s2, s1                                  ; d6550024 00040505
	v_lshlrev_b32_e32 v19, 1, v19                               ; 30262681
	v_add3_u32 v17, v12, v11, v16                               ; d6550011 0442170c
	v_add_nc_u32_e32 v13, 7, v13                                ; 4a1a1a87
	v_lshlrev_b32_e32 v21, 1, v21                               ; 302a2a81
	v_add3_u32 v25, v12, v11, v24                               ; d6550019 0462170c
	v_lshlrev_b32_e32 v23, 1, v23                               ; 302e2e81
	v_add3_u32 v16, v12, v36, v16                               ; d6550010 0442490c
	v_add3_u32 v14, v12, v36, v14                               ; d655000e 043a490c
	v_add3_u32 v20, v12, v36, v20                               ; d6550014 0452490c
	v_add3_u32 v18, v12, v36, v18                               ; d6550012 044a490c
	v_add3_u32 v22, v12, v36, v22                               ; d6550016 045a490c
	v_add3_u32 v27, v12, v11, v26                               ; d655001b 046a170c
	v_lshlrev_b32_e32 v17, 1, v17                               ; 30222281
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v13, v5, vcc_lo                       ; 02000b0d
	v_add3_u32 v24, v12, v36, v24                               ; d6550018 0462490c
	v_lshlrev_b32_e32 v25, 1, v25                               ; 30323281
	v_cvt_f16_f32_e32 v29, v33                                  ; 7e3a1521
	v_cvt_f16_f32_e32 v30, v34                                  ; 7e3c1522
	v_lshlrev_b32_e32 v16, 1, v16                               ; 30202081
	v_cvt_f16_f32_e32 v31, v35                                  ; 7e3e1523
	v_lshlrev_b32_e32 v14, 1, v14                               ; 301c1c81
	v_add3_u32 v26, v12, v36, v26                               ; d655001a 046a490c
	v_lshlrev_b32_e32 v20, 1, v20                               ; 30282881
	v_lshlrev_b32_e32 v18, 1, v18                               ; 30242481
	v_lshlrev_b32_e32 v22, 1, v22                               ; 302c2c81
	v_lshlrev_b32_e32 v27, 1, v27                               ; 30363681
	v_cvt_f16_f32_e32 v33, v37                                  ; 7e421525
	v_cvt_f16_f32_e32 v34, v38                                  ; 7e441526
	v_cvt_f16_f32_e32 v35, v39                                  ; 7e461527
	v_lshlrev_b32_e32 v24, 1, v24                               ; 30303081
	v_add3_u32 v11, v12, v11, v13                               ; d655000b 0436170c
	v_add3_u32 v12, v12, v36, v13                               ; d655000c 0436490c
	v_lshlrev_b32_e32 v26, 1, v26                               ; 30343481
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_lshlrev_b32_e32 v11, 1, v11                               ; 30161681
	v_lshlrev_b32_e32 v12, 1, v12                               ; 30181881
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0xf                                                ; bf85000f
	buffer_store_b16 v2, v15, s[16:19], null offen              ; c406407c 40802002 0000000f
	buffer_store_b16 v3, v17, s[16:19], null offen              ; c406407c 40802003 00000011
	buffer_store_b16 v4, v19, s[16:19], null offen              ; c406407c 40802004 00000013
	buffer_store_b16 v6, v21, s[16:19], null offen              ; c406407c 40802006 00000015
	buffer_store_b16 v7, v23, s[16:19], null offen              ; c406407c 40802007 00000017
	buffer_store_b16 v8, v25, s[16:19], null offen              ; c406407c 40802008 00000019
	buffer_store_b16 v9, v27, s[16:19], null offen              ; c406407c 40802009 0000001b
	buffer_store_b16 v10, v11, s[16:19], null offen             ; c406407c 4080200a 0000000b
	buffer_store_b16 v28, v14, s[16:19], null offen             ; c406407c 4080201c 0000000e
	buffer_store_b16 v29, v16, s[16:19], null offen             ; c406407c 4080201d 00000010
	buffer_store_b16 v30, v18, s[16:19], null offen             ; c406407c 4080201e 00000012
	buffer_store_b16 v31, v20, s[16:19], null offen             ; c406407c 4080201f 00000014
	buffer_store_b16 v32, v22, s[16:19], null offen             ; c406407c 40802020 00000016
	buffer_store_b16 v33, v24, s[16:19], null offen             ; c406407c 40802021 00000018
	buffer_store_b16 v34, v26, s[16:19], null offen             ; c406407c 40802022 0000001a
	buffer_store_b16 v35, v12, s[16:19], null offen             ; c406407c 40802023 0000000c
BB10:
	v_add_nc_u32_e32 v2, 48, v1                                 ; 4a0402b0
	s_cbranch_scc0 BB13                                         ; bfa10061
BB11:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[16:19], s[6:7], 0x0                           ; f4004403 f8000000
(invalid instruction)                                        ; d71f000d
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_mul_i32 s8, s8, s5                                        ; 96080508
	v_cvt_f16_f32_e32 v3, v40                                   ; 7e061528
	v_cvt_f16_f32_e32 v4, v41                                   ; 7e081529
	v_cvt_f16_f32_e32 v6, v42                                   ; 7e0c152a
	v_cvt_f16_f32_e32 v7, v43                                   ; 7e0e152b
	v_cvt_f16_f32_e32 v8, v44                                   ; 7e10152c
	v_cvt_f16_f32_e32 v9, v45                                   ; 7e12152d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v12, v2, s2, s8                                  ; d655000c 00200502
	v_cvt_f16_f32_e32 v10, v46                                  ; 7e14152e
	v_lshrrev_b32_e32 v14, 4, v13                               ; 321c1a84
	v_and_b32_e32 v13, 15, v13                                  ; 361a1a8f
	v_cvt_f16_f32_e32 v11, v47                                  ; 7e16152f
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_lshlrev_b32_e32 v14, 3, v14                               ; 301c1c83
	v_add_nc_u32_e32 v17, 2, v14                                ; 4a221c82
	v_add_nc_u32_e32 v18, 3, v14                                ; 4a241c83
	v_add_nc_u32_e32 v19, 4, v14                                ; 4a261c84
(invalid instruction)                                        ; d72c000f
	v_cndmask_b32_e32 v0, v14, v5, vcc_lo                       ; 02000b0e
	v_add_nc_u32_e32 v16, 1, v14                                ; 4a201c81
(invalid instruction)                                        ; d72c0011
	v_cndmask_b32_e32 v0, v17, v5, vcc_lo                       ; 02000b11
(invalid instruction)                                        ; d72c0012
	v_cndmask_b32_e32 v0, v18, v5, vcc_lo                       ; 02000b12
	v_add_nc_u32_e32 v20, 5, v14                                ; 4a281c85
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v0, v19, v5, vcc_lo                       ; 02000b13
(invalid instruction)                                        ; d72c0010
	v_cndmask_b32_e32 v0, v16, v5, vcc_lo                       ; 02000b10
	v_add3_u32 v15, v13, v12, v15                               ; d655000f 043e190d
	v_add_nc_u32_e32 v21, 6, v14                                ; 4a2a1c86
	v_add3_u32 v17, v13, v12, v17                               ; d6550011 0446190d
(invalid instruction)                                        ; d72c0014
	v_cndmask_b32_e32 v0, v20, v5, vcc_lo                       ; 02000b14
	v_add3_u32 v18, v13, v12, v18                               ; d6550012 044a190d
	v_add_nc_u32_e32 v14, 7, v14                                ; 4a1c1c87
	v_add3_u32 v19, v13, v12, v19                               ; d6550013 044e190d
	v_lshlrev_b32_e32 v15, 1, v15                               ; 301e1e81
(invalid instruction)                                        ; d72c0015
	v_cndmask_b32_e32 v0, v21, v5, vcc_lo                       ; 02000b15
	v_lshlrev_b32_e32 v17, 1, v17                               ; 30222281
	v_add3_u32 v16, v13, v12, v16                               ; d6550010 0442190d
	v_lshlrev_b32_e32 v18, 1, v18                               ; 30242481
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v0, v14, v5, vcc_lo                       ; 02000b0e
	v_add3_u32 v20, v13, v12, v20                               ; d6550014 0452190d
	v_lshlrev_b32_e32 v19, 1, v19                               ; 30262681
	v_lshlrev_b32_e32 v16, 1, v16                               ; 30202081
	v_add3_u32 v21, v13, v12, v21                               ; d6550015 0456190d
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_lshlrev_b32_e32 v20, 1, v20                               ; 30282881
	v_add3_u32 v13, v13, v12, v14                               ; d655000d 043a190d
	v_lshlrev_b32_e32 v21, 1, v21                               ; 302a2a81
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshlrev_b32_e32 v13, 1, v13                               ; 301a1a81
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b16 v3, v15, s[16:19], null offen              ; c406407c 40802003 0000000f
	buffer_store_b16 v4, v16, s[16:19], null offen              ; c406407c 40802004 00000010
	buffer_store_b16 v6, v17, s[16:19], null offen              ; c406407c 40802006 00000011
	buffer_store_b16 v7, v18, s[16:19], null offen              ; c406407c 40802007 00000012
	buffer_store_b16 v8, v19, s[16:19], null offen              ; c406407c 40802008 00000013
	buffer_store_b16 v9, v20, s[16:19], null offen              ; c406407c 40802009 00000014
	buffer_store_b16 v10, v21, s[16:19], null offen             ; c406407c 4080200a 00000015
	buffer_store_b16 v11, v13, s[16:19], null offen             ; c406407c 4080200b 0000000d
BB13:
	s_cmp_lt_u32 s10, s4                                        ; bf0a040a
	s_cbranch_scc0 BB16                                         ; bfa1010d
BB14:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[16:19], s[6:7], 0x0                           ; f4004403 f8000000
(invalid instruction)                                        ; d71f000d
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_mul_i32 s10, s10, s5                                      ; 960a050a
	v_cvt_f16_f32_e32 v3, v48                                   ; 7e061530
	v_cvt_f16_f32_e32 v4, v49                                   ; 7e081531
	v_cvt_f16_f32_e32 v6, v50                                   ; 7e0c1532
	v_cvt_f16_f32_e32 v7, v51                                   ; 7e0e1533
	v_cvt_f16_f32_e32 v8, v52                                   ; 7e101534
	v_cvt_f16_f32_e32 v9, v53                                   ; 7e121535
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v12, v1, s2, s10                                 ; d655000c 00280501
	v_cvt_f16_f32_e32 v10, v54                                  ; 7e141536
	v_lshrrev_b32_e32 v14, 4, v13                               ; 321c1a84
	v_and_b32_e32 v13, 15, v13                                  ; 361a1a8f
	v_cvt_f16_f32_e32 v11, v55                                  ; 7e161537
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_lshlrev_b32_e32 v14, 3, v14                               ; 301c1c83
	v_add_nc_u32_e32 v19, 2, v14                                ; 4a261c82
	v_add_nc_u32_e32 v21, 3, v14                                ; 4a2a1c83
	v_add_nc_u32_e32 v23, 4, v14                                ; 4a2e1c84
(invalid instruction)                                        ; d72c000f
	v_cndmask_b32_e32 v0, v14, v5, vcc_lo                       ; 02000b0e
	v_add_nc_u32_e32 v17, 1, v14                                ; 4a221c81
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v0, v19, v5, vcc_lo                       ; 02000b13
(invalid instruction)                                        ; d72c0015
	v_cndmask_b32_e32 v0, v21, v5, vcc_lo                       ; 02000b15
	v_add_nc_u32_e32 v25, 5, v14                                ; 4a321c85
(invalid instruction)                                        ; d72c0017
	v_cndmask_b32_e32 v0, v23, v5, vcc_lo                       ; 02000b17
(invalid instruction)                                        ; d72c0011
	v_cndmask_b32_e32 v0, v17, v5, vcc_lo                       ; 02000b11
	v_add3_u32 v16, v13, v12, v15                               ; d6550010 043e190d
	v_add_nc_u32_e32 v27, 6, v14                                ; 4a361c86
	v_add3_u32 v20, v13, v12, v19                               ; d6550014 044e190d
(invalid instruction)                                        ; d72c0019
	v_cndmask_b32_e32 v0, v25, v5, vcc_lo                       ; 02000b19
	v_add3_u32 v22, v13, v12, v21                               ; d6550016 0456190d
	v_add_nc_u32_e32 v14, 7, v14                                ; 4a1c1c87
	v_add3_u32 v37, v0, s2, s10                                 ; d6550025 00280500
	v_add3_u32 v24, v13, v12, v23                               ; d6550018 045e190d
	v_lshlrev_b32_e32 v16, 1, v16                               ; 30202081
(invalid instruction)                                        ; d72c001b
	v_cndmask_b32_e32 v0, v27, v5, vcc_lo                       ; 02000b1b
	v_lshlrev_b32_e32 v20, 1, v20                               ; 30282881
	v_add3_u32 v18, v13, v12, v17                               ; d6550012 0446190d
	v_lshlrev_b32_e32 v22, 1, v22                               ; 302c2c81
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v0, v14, v5, vcc_lo                       ; 02000b0e
	v_add3_u32 v26, v13, v12, v25                               ; d655001a 0466190d
	v_add3_u32 v41, v13, v37, v21                               ; d6550029 04564b0d
	v_add3_u32 v39, v13, v37, v17                               ; d6550027 04464b0d
	v_lshlrev_b32_e32 v24, 1, v24                               ; 30303081
	v_add3_u32 v43, v13, v37, v25                               ; d655002b 04664b0d
	v_add3_u32 v38, v13, v37, v15                               ; d6550026 043e4b0d
	v_lshlrev_b32_e32 v18, 1, v18                               ; 30242481
	v_add3_u32 v40, v13, v37, v19                               ; d6550028 044e4b0d
	v_add3_u32 v28, v13, v12, v27                               ; d655001c 046e190d
	v_add3_u32 v42, v13, v37, v23                               ; d655002a 045e4b0d
	v_add3_u32 v44, v13, v37, v27                               ; d655002c 046e4b0d
	v_lshlrev_b32_e32 v26, 1, v26                               ; 30343481
	v_lshlrev_b32_e32 v41, 1, v41                               ; 30525281
	v_cvt_f16_f32_e32 v29, v56                                  ; 7e3a1538
	v_cvt_f16_f32_e32 v30, v57                                  ; 7e3c1539
	v_lshlrev_b32_e32 v39, 1, v39                               ; 304e4e81
	v_add3_u32 v12, v13, v12, v14                               ; d655000c 043a190d
	v_cvt_f16_f32_e32 v31, v58                                  ; 7e3e153a
	v_cvt_f16_f32_e32 v32, v59                                  ; 7e40153b
	v_lshlrev_b32_e32 v43, 1, v43                               ; 30565681
	v_lshlrev_b32_e32 v38, 1, v38                               ; 304c4c81
	v_cvt_f16_f32_e32 v33, v60                                  ; 7e42153c
	v_cvt_f16_f32_e32 v34, v61                                  ; 7e44153d
	v_cvt_f16_f32_e32 v35, v62                                  ; 7e46153e
	v_lshlrev_b32_e32 v40, 1, v40                               ; 30505081
	v_lshlrev_b32_e32 v28, 1, v28                               ; 30383881
	v_cvt_f16_f32_e32 v36, v63                                  ; 7e48153f
	v_add3_u32 v37, v13, v37, v14                               ; d6550025 043a4b0d
	v_lshlrev_b32_e32 v42, 1, v42                               ; 30545481
	v_lshlrev_b32_e32 v44, 1, v44                               ; 30585881
	v_add3_u32 v53, v5, s2, s10                                 ; d6550035 00280505
	v_lshlrev_b32_e32 v12, 1, v12                               ; 30181881
	v_cvt_f16_f32_e32 v45, v64                                  ; 7e5a1540
	v_cvt_f16_f32_e32 v46, v65                                  ; 7e5c1541
	v_lshlrev_b32_e32 v37, 1, v37                               ; 304a4a81
	v_cvt_f16_f32_e32 v47, v66                                  ; 7e5e1542
	v_cvt_f16_f32_e32 v48, v67                                  ; 7e601543
	v_cvt_f16_f32_e32 v49, v68                                  ; 7e621544
	v_add3_u32 v59, v13, v53, v25                               ; d655003b 04666b0d
	v_add3_u32 v57, v13, v53, v21                               ; d6550039 04566b0d
	v_add3_u32 v60, v13, v53, v27                               ; d655003c 046e6b0d
	v_add3_u32 v56, v13, v53, v19                               ; d6550038 044e6b0d
	v_add3_u32 v58, v13, v53, v23                               ; d655003a 045e6b0d
	v_add3_u32 v54, v13, v53, v15                               ; d6550036 043e6b0d
	v_add3_u32 v55, v13, v53, v17                               ; d6550037 04466b0d
	v_cvt_f16_f32_e32 v50, v69                                  ; 7e641545
	v_cvt_f16_f32_e32 v51, v70                                  ; 7e661546
	v_cvt_f16_f32_e32 v52, v71                                  ; 7e681547
	v_add3_u32 v53, v13, v53, v14                               ; d6550035 043a6b0d
	v_add3_u32 v69, v2, s2, s10                                 ; d6550045 00280502
	v_lshlrev_b32_e32 v59, 1, v59                               ; 30767681
	v_lshlrev_b32_e32 v57, 1, v57                               ; 30727281
	v_lshlrev_b32_e32 v60, 1, v60                               ; 30787881
	v_lshlrev_b32_e32 v56, 1, v56                               ; 30707081
	v_lshlrev_b32_e32 v58, 1, v58                               ; 30747481
	v_lshlrev_b32_e32 v54, 1, v54                               ; 306c6c81
	v_lshlrev_b32_e32 v55, 1, v55                               ; 306e6e81
	v_lshlrev_b32_e32 v53, 1, v53                               ; 306a6a81
	v_add3_u32 v19, v13, v69, v19                               ; d6550013 044e8b0d
	v_add3_u32 v21, v13, v69, v21                               ; d6550015 04568b0d
	v_add3_u32 v23, v13, v69, v23                               ; d6550017 045e8b0d
	v_add3_u32 v15, v13, v69, v15                               ; d655000f 043e8b0d
	v_add3_u32 v25, v13, v69, v25                               ; d6550019 04668b0d
	v_add3_u32 v17, v13, v69, v17                               ; d6550011 04468b0d
	v_add3_u32 v27, v13, v69, v27                               ; d655001b 046e8b0d
	v_cvt_f16_f32_e32 v61, v72                                  ; 7e7a1548
	v_cvt_f16_f32_e32 v62, v73                                  ; 7e7c1549
	v_cvt_f16_f32_e32 v63, v74                                  ; 7e7e154a
	v_cvt_f16_f32_e32 v64, v75                                  ; 7e80154b
	v_cvt_f16_f32_e32 v65, v76                                  ; 7e82154c
	v_cvt_f16_f32_e32 v66, v77                                  ; 7e84154d
	v_cvt_f16_f32_e32 v67, v78                                  ; 7e86154e
	v_lshlrev_b32_e32 v19, 1, v19                               ; 30262681
	v_cvt_f16_f32_e32 v68, v79                                  ; 7e88154f
	v_lshlrev_b32_e32 v21, 1, v21                               ; 302a2a81
	v_add3_u32 v13, v13, v69, v14                               ; d655000d 043a8b0d
	v_lshlrev_b32_e32 v23, 1, v23                               ; 302e2e81
	v_lshlrev_b32_e32 v15, 1, v15                               ; 301e1e81
	v_lshlrev_b32_e32 v25, 1, v25                               ; 30323281
	v_lshlrev_b32_e32 v17, 1, v17                               ; 30222281
	v_lshlrev_b32_e32 v27, 1, v27                               ; 30363681
	v_lshlrev_b32_e32 v13, 1, v13                               ; 301a1a81
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x1f                                               ; bf85001f
	buffer_store_b16 v3, v16, s[16:19], null offen              ; c406407c 40802003 00000010
	buffer_store_b16 v4, v18, s[16:19], null offen              ; c406407c 40802004 00000012
	buffer_store_b16 v6, v20, s[16:19], null offen              ; c406407c 40802006 00000014
	buffer_store_b16 v7, v22, s[16:19], null offen              ; c406407c 40802007 00000016
	buffer_store_b16 v8, v24, s[16:19], null offen              ; c406407c 40802008 00000018
	buffer_store_b16 v9, v26, s[16:19], null offen              ; c406407c 40802009 0000001a
	buffer_store_b16 v10, v28, s[16:19], null offen             ; c406407c 4080200a 0000001c
	buffer_store_b16 v11, v12, s[16:19], null offen             ; c406407c 4080200b 0000000c
	buffer_store_b16 v29, v38, s[16:19], null offen             ; c406407c 4080201d 00000026
	buffer_store_b16 v30, v39, s[16:19], null offen             ; c406407c 4080201e 00000027
	buffer_store_b16 v31, v40, s[16:19], null offen             ; c406407c 4080201f 00000028
	buffer_store_b16 v32, v41, s[16:19], null offen             ; c406407c 40802020 00000029
	buffer_store_b16 v33, v42, s[16:19], null offen             ; c406407c 40802021 0000002a
	buffer_store_b16 v34, v43, s[16:19], null offen             ; c406407c 40802022 0000002b
	buffer_store_b16 v35, v44, s[16:19], null offen             ; c406407c 40802023 0000002c
	buffer_store_b16 v36, v37, s[16:19], null offen             ; c406407c 40802024 00000025
	buffer_store_b16 v45, v54, s[16:19], null offen             ; c406407c 4080202d 00000036
	buffer_store_b16 v46, v55, s[16:19], null offen             ; c406407c 4080202e 00000037
	buffer_store_b16 v47, v56, s[16:19], null offen             ; c406407c 4080202f 00000038
	buffer_store_b16 v48, v57, s[16:19], null offen             ; c406407c 40802030 00000039
	buffer_store_b16 v49, v58, s[16:19], null offen             ; c406407c 40802031 0000003a
	buffer_store_b16 v50, v59, s[16:19], null offen             ; c406407c 40802032 0000003b
	buffer_store_b16 v51, v60, s[16:19], null offen             ; c406407c 40802033 0000003c
	buffer_store_b16 v52, v53, s[16:19], null offen             ; c406407c 40802034 00000035
	buffer_store_b16 v61, v15, s[16:19], null offen             ; c406407c 4080203d 0000000f
	buffer_store_b16 v62, v17, s[16:19], null offen             ; c406407c 4080203e 00000011
	buffer_store_b16 v63, v19, s[16:19], null offen             ; c406407c 4080203f 00000013
	buffer_store_b16 v64, v21, s[16:19], null offen             ; c406407c 40802040 00000015
	buffer_store_b16 v65, v23, s[16:19], null offen             ; c406407c 40802041 00000017
	buffer_store_b16 v66, v25, s[16:19], null offen             ; c406407c 40802042 00000019
	buffer_store_b16 v67, v27, s[16:19], null offen             ; c406407c 40802043 0000001b
	buffer_store_b16 v68, v13, s[16:19], null offen             ; c406407c 40802044 0000000d
BB16:
	s_cmp_lt_u32 s12, s4                                        ; bf0a040c
	s_cbranch_scc0 BB19                                         ; bfa1010d
BB17:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[8:11], s[6:7], 0x0                            ; f4004203 f8000000
(invalid instruction)                                        ; d71f000d
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_mul_i32 s12, s12, s5                                      ; 960c050c
	v_cvt_f16_f32_e32 v3, v80                                   ; 7e061550
	v_cvt_f16_f32_e32 v4, v81                                   ; 7e081551
	v_cvt_f16_f32_e32 v6, v82                                   ; 7e0c1552
	v_cvt_f16_f32_e32 v7, v83                                   ; 7e0e1553
	v_cvt_f16_f32_e32 v8, v84                                   ; 7e101554
	v_cvt_f16_f32_e32 v9, v85                                   ; 7e121555
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v12, v1, s2, s12                                 ; d655000c 00300501
	v_cvt_f16_f32_e32 v10, v86                                  ; 7e141556
	v_lshrrev_b32_e32 v14, 4, v13                               ; 321c1a84
	v_and_b32_e32 v13, 15, v13                                  ; 361a1a8f
	v_cvt_f16_f32_e32 v11, v87                                  ; 7e161557
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_lshlrev_b32_e32 v14, 3, v14                               ; 301c1c83
	v_add_nc_u32_e32 v19, 2, v14                                ; 4a261c82
	v_add_nc_u32_e32 v21, 3, v14                                ; 4a2a1c83
	v_add_nc_u32_e32 v23, 4, v14                                ; 4a2e1c84
(invalid instruction)                                        ; d72c000f
	v_cndmask_b32_e32 v0, v14, v5, vcc_lo                       ; 02000b0e
	v_add_nc_u32_e32 v17, 1, v14                                ; 4a221c81
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v0, v19, v5, vcc_lo                       ; 02000b13
(invalid instruction)                                        ; d72c0015
	v_cndmask_b32_e32 v0, v21, v5, vcc_lo                       ; 02000b15
	v_add_nc_u32_e32 v25, 5, v14                                ; 4a321c85
(invalid instruction)                                        ; d72c0017
	v_cndmask_b32_e32 v0, v23, v5, vcc_lo                       ; 02000b17
(invalid instruction)                                        ; d72c0011
	v_cndmask_b32_e32 v0, v17, v5, vcc_lo                       ; 02000b11
	v_add3_u32 v16, v13, v12, v15                               ; d6550010 043e190d
	v_add_nc_u32_e32 v27, 6, v14                                ; 4a361c86
	v_add3_u32 v20, v13, v12, v19                               ; d6550014 044e190d
(invalid instruction)                                        ; d72c0019
	v_cndmask_b32_e32 v0, v25, v5, vcc_lo                       ; 02000b19
	v_add3_u32 v22, v13, v12, v21                               ; d6550016 0456190d
	v_add_nc_u32_e32 v14, 7, v14                                ; 4a1c1c87
	v_add3_u32 v37, v0, s2, s12                                 ; d6550025 00300500
	v_add3_u32 v24, v13, v12, v23                               ; d6550018 045e190d
	v_lshlrev_b32_e32 v16, 1, v16                               ; 30202081
(invalid instruction)                                        ; d72c001b
	v_cndmask_b32_e32 v0, v27, v5, vcc_lo                       ; 02000b1b
	v_lshlrev_b32_e32 v20, 1, v20                               ; 30282881
	v_add3_u32 v18, v13, v12, v17                               ; d6550012 0446190d
	v_lshlrev_b32_e32 v22, 1, v22                               ; 302c2c81
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v0, v14, v5, vcc_lo                       ; 02000b0e
	v_add3_u32 v26, v13, v12, v25                               ; d655001a 0466190d
	v_add3_u32 v41, v13, v37, v21                               ; d6550029 04564b0d
	v_add3_u32 v39, v13, v37, v17                               ; d6550027 04464b0d
	v_lshlrev_b32_e32 v24, 1, v24                               ; 30303081
	v_add3_u32 v43, v13, v37, v25                               ; d655002b 04664b0d
	v_add3_u32 v38, v13, v37, v15                               ; d6550026 043e4b0d
	v_lshlrev_b32_e32 v18, 1, v18                               ; 30242481
	v_add3_u32 v40, v13, v37, v19                               ; d6550028 044e4b0d
	v_add3_u32 v28, v13, v12, v27                               ; d655001c 046e190d
	v_add3_u32 v42, v13, v37, v23                               ; d655002a 045e4b0d
	v_add3_u32 v44, v13, v37, v27                               ; d655002c 046e4b0d
	v_lshlrev_b32_e32 v26, 1, v26                               ; 30343481
	v_lshlrev_b32_e32 v41, 1, v41                               ; 30525281
	v_cvt_f16_f32_e32 v29, v88                                  ; 7e3a1558
	v_cvt_f16_f32_e32 v30, v89                                  ; 7e3c1559
	v_lshlrev_b32_e32 v39, 1, v39                               ; 304e4e81
	v_add3_u32 v12, v13, v12, v14                               ; d655000c 043a190d
	v_cvt_f16_f32_e32 v31, v90                                  ; 7e3e155a
	v_cvt_f16_f32_e32 v32, v91                                  ; 7e40155b
	v_lshlrev_b32_e32 v43, 1, v43                               ; 30565681
	v_lshlrev_b32_e32 v38, 1, v38                               ; 304c4c81
	v_cvt_f16_f32_e32 v33, v92                                  ; 7e42155c
	v_cvt_f16_f32_e32 v34, v93                                  ; 7e44155d
	v_cvt_f16_f32_e32 v35, v94                                  ; 7e46155e
	v_lshlrev_b32_e32 v40, 1, v40                               ; 30505081
	v_lshlrev_b32_e32 v28, 1, v28                               ; 30383881
	v_cvt_f16_f32_e32 v36, v95                                  ; 7e48155f
	v_add3_u32 v37, v13, v37, v14                               ; d6550025 043a4b0d
	v_lshlrev_b32_e32 v42, 1, v42                               ; 30545481
	v_lshlrev_b32_e32 v44, 1, v44                               ; 30585881
	v_add3_u32 v53, v5, s2, s12                                 ; d6550035 00300505
	v_lshlrev_b32_e32 v12, 1, v12                               ; 30181881
	v_cvt_f16_f32_e32 v45, v96                                  ; 7e5a1560
	v_cvt_f16_f32_e32 v46, v97                                  ; 7e5c1561
	v_lshlrev_b32_e32 v37, 1, v37                               ; 304a4a81
	v_cvt_f16_f32_e32 v47, v98                                  ; 7e5e1562
	v_cvt_f16_f32_e32 v48, v99                                  ; 7e601563
	v_cvt_f16_f32_e32 v49, v100                                 ; 7e621564
	v_add3_u32 v59, v13, v53, v25                               ; d655003b 04666b0d
	v_add3_u32 v57, v13, v53, v21                               ; d6550039 04566b0d
	v_add3_u32 v60, v13, v53, v27                               ; d655003c 046e6b0d
	v_add3_u32 v56, v13, v53, v19                               ; d6550038 044e6b0d
	v_add3_u32 v58, v13, v53, v23                               ; d655003a 045e6b0d
	v_add3_u32 v54, v13, v53, v15                               ; d6550036 043e6b0d
	v_add3_u32 v55, v13, v53, v17                               ; d6550037 04466b0d
	v_cvt_f16_f32_e32 v50, v101                                 ; 7e641565
	v_cvt_f16_f32_e32 v51, v102                                 ; 7e661566
	v_cvt_f16_f32_e32 v52, v103                                 ; 7e681567
	v_add3_u32 v53, v13, v53, v14                               ; d6550035 043a6b0d
	v_add3_u32 v69, v2, s2, s12                                 ; d6550045 00300502
	v_lshlrev_b32_e32 v59, 1, v59                               ; 30767681
	v_lshlrev_b32_e32 v57, 1, v57                               ; 30727281
	v_lshlrev_b32_e32 v60, 1, v60                               ; 30787881
	v_lshlrev_b32_e32 v56, 1, v56                               ; 30707081
	v_lshlrev_b32_e32 v58, 1, v58                               ; 30747481
	v_lshlrev_b32_e32 v54, 1, v54                               ; 306c6c81
	v_lshlrev_b32_e32 v55, 1, v55                               ; 306e6e81
	v_lshlrev_b32_e32 v53, 1, v53                               ; 306a6a81
	v_add3_u32 v19, v13, v69, v19                               ; d6550013 044e8b0d
	v_add3_u32 v21, v13, v69, v21                               ; d6550015 04568b0d
	v_add3_u32 v23, v13, v69, v23                               ; d6550017 045e8b0d
	v_add3_u32 v15, v13, v69, v15                               ; d655000f 043e8b0d
	v_add3_u32 v25, v13, v69, v25                               ; d6550019 04668b0d
	v_add3_u32 v17, v13, v69, v17                               ; d6550011 04468b0d
	v_add3_u32 v27, v13, v69, v27                               ; d655001b 046e8b0d
	v_cvt_f16_f32_e32 v61, v104                                 ; 7e7a1568
	v_cvt_f16_f32_e32 v62, v105                                 ; 7e7c1569
	v_cvt_f16_f32_e32 v63, v106                                 ; 7e7e156a
	v_cvt_f16_f32_e32 v64, v107                                 ; 7e80156b
	v_cvt_f16_f32_e32 v65, v108                                 ; 7e82156c
	v_cvt_f16_f32_e32 v66, v109                                 ; 7e84156d
	v_cvt_f16_f32_e32 v67, v110                                 ; 7e86156e
	v_lshlrev_b32_e32 v19, 1, v19                               ; 30262681
	v_cvt_f16_f32_e32 v68, v111                                 ; 7e88156f
	v_lshlrev_b32_e32 v21, 1, v21                               ; 302a2a81
	v_add3_u32 v13, v13, v69, v14                               ; d655000d 043a8b0d
	v_lshlrev_b32_e32 v23, 1, v23                               ; 302e2e81
	v_lshlrev_b32_e32 v15, 1, v15                               ; 301e1e81
	v_lshlrev_b32_e32 v25, 1, v25                               ; 30323281
	v_lshlrev_b32_e32 v17, 1, v17                               ; 30222281
	v_lshlrev_b32_e32 v27, 1, v27                               ; 30363681
	v_lshlrev_b32_e32 v13, 1, v13                               ; 301a1a81
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x1f                                               ; bf85001f
	buffer_store_b16 v3, v16, s[8:11], null offen               ; c406407c 40801003 00000010
	buffer_store_b16 v4, v18, s[8:11], null offen               ; c406407c 40801004 00000012
	buffer_store_b16 v6, v20, s[8:11], null offen               ; c406407c 40801006 00000014
	buffer_store_b16 v7, v22, s[8:11], null offen               ; c406407c 40801007 00000016
	buffer_store_b16 v8, v24, s[8:11], null offen               ; c406407c 40801008 00000018
	buffer_store_b16 v9, v26, s[8:11], null offen               ; c406407c 40801009 0000001a
	buffer_store_b16 v10, v28, s[8:11], null offen              ; c406407c 4080100a 0000001c
	buffer_store_b16 v11, v12, s[8:11], null offen              ; c406407c 4080100b 0000000c
	buffer_store_b16 v29, v38, s[8:11], null offen              ; c406407c 4080101d 00000026
	buffer_store_b16 v30, v39, s[8:11], null offen              ; c406407c 4080101e 00000027
	buffer_store_b16 v31, v40, s[8:11], null offen              ; c406407c 4080101f 00000028
	buffer_store_b16 v32, v41, s[8:11], null offen              ; c406407c 40801020 00000029
	buffer_store_b16 v33, v42, s[8:11], null offen              ; c406407c 40801021 0000002a
	buffer_store_b16 v34, v43, s[8:11], null offen              ; c406407c 40801022 0000002b
	buffer_store_b16 v35, v44, s[8:11], null offen              ; c406407c 40801023 0000002c
	buffer_store_b16 v36, v37, s[8:11], null offen              ; c406407c 40801024 00000025
	buffer_store_b16 v45, v54, s[8:11], null offen              ; c406407c 4080102d 00000036
	buffer_store_b16 v46, v55, s[8:11], null offen              ; c406407c 4080102e 00000037
	buffer_store_b16 v47, v56, s[8:11], null offen              ; c406407c 4080102f 00000038
	buffer_store_b16 v48, v57, s[8:11], null offen              ; c406407c 40801030 00000039
	buffer_store_b16 v49, v58, s[8:11], null offen              ; c406407c 40801031 0000003a
	buffer_store_b16 v50, v59, s[8:11], null offen              ; c406407c 40801032 0000003b
	buffer_store_b16 v51, v60, s[8:11], null offen              ; c406407c 40801033 0000003c
	buffer_store_b16 v52, v53, s[8:11], null offen              ; c406407c 40801034 00000035
	buffer_store_b16 v61, v15, s[8:11], null offen              ; c406407c 4080103d 0000000f
	buffer_store_b16 v62, v17, s[8:11], null offen              ; c406407c 4080103e 00000011
	buffer_store_b16 v63, v19, s[8:11], null offen              ; c406407c 4080103f 00000013
	buffer_store_b16 v64, v21, s[8:11], null offen              ; c406407c 40801040 00000015
	buffer_store_b16 v65, v23, s[8:11], null offen              ; c406407c 40801041 00000017
	buffer_store_b16 v66, v25, s[8:11], null offen              ; c406407c 40801042 00000019
	buffer_store_b16 v67, v27, s[8:11], null offen              ; c406407c 40801043 0000001b
	buffer_store_b16 v68, v13, s[8:11], null offen              ; c406407c 40801044 0000000d
BB19:
	s_cmp_lt_u32 s14, s4                                        ; bf0a040e
	s_cbranch_scc0 BB22                                         ; bfa1010c
BB20:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[8:11], s[0:1], 0x0                            ; f4004200 f8000000
(invalid instruction)                                        ; d71f000c
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_mul_i32 s14, s14, s5                                      ; 960e050e
	v_cvt_f16_f32_e32 v3, v112                                  ; 7e061570
	v_cvt_f16_f32_e32 v4, v113                                  ; 7e081571
	v_cvt_f16_f32_e32 v6, v114                                  ; 7e0c1572
	v_cvt_f16_f32_e32 v7, v115                                  ; 7e0e1573
	v_cvt_f16_f32_e32 v8, v116                                  ; 7e101574
	v_cvt_f16_f32_e32 v9, v117                                  ; 7e121575
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v1, v1, s2, s14                                  ; d6550001 00380501
	v_cvt_f16_f32_e32 v10, v118                                 ; 7e141576
	v_lshrrev_b32_e32 v13, 4, v12                               ; 321a1884
	v_and_b32_e32 v12, 15, v12                                  ; 3618188f
	v_cvt_f16_f32_e32 v11, v119                                 ; 7e161577
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_lshlrev_b32_e32 v13, 3, v13                               ; 301a1a83
	v_add_nc_u32_e32 v20, 3, v13                                ; 4a281a83
	v_add_nc_u32_e32 v22, 4, v13                                ; 4a2c1a84
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v0, v13, v5, vcc_lo                       ; 02000b0d
	v_add_nc_u32_e32 v16, 1, v13                                ; 4a201a81
	v_add_nc_u32_e32 v18, 2, v13                                ; 4a241a82
(invalid instruction)                                        ; d72c0014
	v_cndmask_b32_e32 v0, v20, v5, vcc_lo                       ; 02000b14
(invalid instruction)                                        ; d72c0016
	v_cndmask_b32_e32 v0, v22, v5, vcc_lo                       ; 02000b16
	v_add_nc_u32_e32 v24, 5, v13                                ; 4a301a85
(invalid instruction)                                        ; d72c0010
	v_cndmask_b32_e32 v0, v16, v5, vcc_lo                       ; 02000b10
(invalid instruction)                                        ; d72c0012
	v_cndmask_b32_e32 v0, v18, v5, vcc_lo                       ; 02000b12
	v_add3_u32 v15, v12, v1, v14                                ; d655000f 043a030c
	v_add_nc_u32_e32 v26, 6, v13                                ; 4a341a86
	v_add3_u32 v21, v12, v1, v20                                ; d6550015 0452030c
(invalid instruction)                                        ; d72c0018
	v_cndmask_b32_e32 v0, v24, v5, vcc_lo                       ; 02000b18
	v_add3_u32 v23, v12, v1, v22                                ; d6550017 045a030c
	v_add_nc_u32_e32 v13, 7, v13                                ; 4a1a1a87
	v_add3_u32 v0, v0, s2, s14                                  ; d6550000 00380500
	v_add3_u32 v17, v12, v1, v16                                ; d6550011 0442030c
	v_lshlrev_b32_e32 v15, 1, v15                               ; 301e1e81
(invalid instruction)                                        ; d72c001a
	v_cndmask_b32_e32 v0, v26, v5, vcc_lo                       ; 02000b1a
	v_add3_u32 v19, v12, v1, v18                                ; d6550013 044a030c
	v_lshlrev_b32_e32 v21, 1, v21                               ; 302a2a81
	v_lshlrev_b32_e32 v23, 1, v23                               ; 302e2e81
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v13, v5, vcc_lo                       ; 02000b0d
	v_add3_u32 v25, v12, v1, v24                                ; d6550019 0462030c
	v_add3_u32 v38, v12, v0, v18                                ; d6550026 044a010c
	v_add3_u32 v36, v12, v0, v14                                ; d6550024 043a010c
	v_lshlrev_b32_e32 v17, 1, v17                               ; 30222281
	v_add3_u32 v40, v12, v0, v22                                ; d6550028 045a010c
	v_add3_u32 v37, v12, v0, v16                                ; d6550025 0442010c
	v_lshlrev_b32_e32 v19, 1, v19                               ; 30262681
	v_add3_u32 v27, v12, v1, v26                                ; d655001b 046a030c
	v_add3_u32 v39, v12, v0, v20                                ; d6550027 0452010c
	v_add3_u32 v41, v12, v0, v24                                ; d6550029 0462010c
	v_add3_u32 v42, v12, v0, v26                                ; d655002a 046a010c
	v_lshlrev_b32_e32 v25, 1, v25                               ; 30323281
	v_lshlrev_b32_e32 v38, 1, v38                               ; 304c4c81
	v_cvt_f16_f32_e32 v28, v120                                 ; 7e381578
	v_cvt_f16_f32_e32 v29, v121                                 ; 7e3a1579
	v_lshlrev_b32_e32 v36, 1, v36                               ; 30484881
	v_add3_u32 v1, v12, v1, v13                                 ; d6550001 0436030c
	v_cvt_f16_f32_e32 v30, v122                                 ; 7e3c157a
	v_lshlrev_b32_e32 v40, 1, v40                               ; 30505081
	v_cvt_f16_f32_e32 v31, v123                                 ; 7e3e157b
	v_cvt_f16_f32_e32 v32, v124                                 ; 7e40157c
	v_lshlrev_b32_e32 v37, 1, v37                               ; 304a4a81
	v_cvt_f16_f32_e32 v33, v125                                 ; 7e42157d
	v_cvt_f16_f32_e32 v34, v126                                 ; 7e44157e
	v_lshlrev_b32_e32 v27, 1, v27                               ; 30363681
	v_cvt_f16_f32_e32 v35, v127                                 ; 7e46157f
	v_lshlrev_b32_e32 v39, 1, v39                               ; 304e4e81
	v_add3_u32 v0, v12, v0, v13                                 ; d6550000 0436010c
	v_lshlrev_b32_e32 v41, 1, v41                               ; 30525281
	v_lshlrev_b32_e32 v42, 1, v42                               ; 30545481
	v_add3_u32 v5, v5, s2, s14                                  ; d6550005 00380505
	v_lshlrev_b32_e32 v1, 1, v1                                 ; 30020281
	v_cvt_f16_f32_e32 v43, v128                                 ; 7e561580
	v_lshlrev_b32_e32 v0, 1, v0                                 ; 30000081
	v_cvt_f16_f32_e32 v44, v129                                 ; 7e581581
	v_cvt_f16_f32_e32 v45, v130                                 ; 7e5a1582
	v_cvt_f16_f32_e32 v46, v131                                 ; 7e5c1583
	v_add3_u32 v56, v12, v5, v24                                ; d6550038 04620b0c
	v_add3_u32 v51, v12, v5, v14                                ; d6550033 043a0b0c
	v_cvt_f16_f32_e32 v47, v132                                 ; 7e5e1584
	v_add3_u32 v54, v12, v5, v20                                ; d6550036 04520b0c
	v_add3_u32 v55, v12, v5, v22                                ; d6550037 045a0b0c
	v_add3_u32 v57, v12, v5, v26                                ; d6550039 046a0b0c
	v_add3_u32 v53, v12, v5, v18                                ; d6550035 044a0b0c
	v_add3_u32 v52, v12, v5, v16                                ; d6550034 04420b0c
	v_cvt_f16_f32_e32 v48, v133                                 ; 7e601585
	v_cvt_f16_f32_e32 v49, v134                                 ; 7e621586
	v_cvt_f16_f32_e32 v50, v135                                 ; 7e641587
	v_add3_u32 v5, v12, v5, v13                                 ; d6550005 04360b0c
	v_add3_u32 v2, v2, s2, s14                                  ; d6550002 00380502
	v_lshlrev_b32_e32 v56, 1, v56                               ; 30707081
	v_lshlrev_b32_e32 v51, 1, v51                               ; 30666681
	v_lshlrev_b32_e32 v54, 1, v54                               ; 306c6c81
	v_lshlrev_b32_e32 v55, 1, v55                               ; 306e6e81
	v_lshlrev_b32_e32 v57, 1, v57                               ; 30727281
	v_lshlrev_b32_e32 v53, 1, v53                               ; 306a6a81
	v_lshlrev_b32_e32 v52, 1, v52                               ; 30686881
	v_lshlrev_b32_e32 v5, 1, v5                                 ; 300a0a81
	v_add3_u32 v18, v12, v2, v18                                ; d6550012 044a050c
	v_add3_u32 v20, v12, v2, v20                                ; d6550014 0452050c
	v_add3_u32 v14, v12, v2, v14                                ; d655000e 043a050c
	v_add3_u32 v24, v12, v2, v24                                ; d6550018 0462050c
	v_add3_u32 v26, v12, v2, v26                                ; d655001a 046a050c
	v_add3_u32 v22, v12, v2, v22                                ; d6550016 045a050c
	v_add3_u32 v16, v12, v2, v16                                ; d6550010 0442050c
	v_cvt_f16_f32_e32 v58, v136                                 ; 7e741588
	v_cvt_f16_f32_e32 v59, v137                                 ; 7e761589
	v_cvt_f16_f32_e32 v60, v138                                 ; 7e78158a
	v_cvt_f16_f32_e32 v61, v139                                 ; 7e7a158b
	v_cvt_f16_f32_e32 v62, v140                                 ; 7e7c158c
	v_cvt_f16_f32_e32 v63, v141                                 ; 7e7e158d
	v_cvt_f16_f32_e32 v64, v142                                 ; 7e80158e
	v_lshlrev_b32_e32 v18, 1, v18                               ; 30242481
	v_cvt_f16_f32_e32 v65, v143                                 ; 7e82158f
	v_lshlrev_b32_e32 v20, 1, v20                               ; 30282881
	v_add3_u32 v12, v12, v2, v13                                ; d655000c 0436050c
	v_lshlrev_b32_e32 v14, 1, v14                               ; 301c1c81
	v_lshlrev_b32_e32 v24, 1, v24                               ; 30303081
	v_lshlrev_b32_e32 v26, 1, v26                               ; 30343481
	v_lshlrev_b32_e32 v22, 1, v22                               ; 302c2c81
	v_lshlrev_b32_e32 v16, 1, v16                               ; 30202081
	v_lshlrev_b32_e32 v12, 1, v12                               ; 30181881
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x1f                                               ; bf85001f
	buffer_store_b16 v3, v15, s[8:11], null offen               ; c406407c 40801003 0000000f
	buffer_store_b16 v4, v17, s[8:11], null offen               ; c406407c 40801004 00000011
	buffer_store_b16 v6, v19, s[8:11], null offen               ; c406407c 40801006 00000013
	buffer_store_b16 v7, v21, s[8:11], null offen               ; c406407c 40801007 00000015
	buffer_store_b16 v8, v23, s[8:11], null offen               ; c406407c 40801008 00000017
	buffer_store_b16 v9, v25, s[8:11], null offen               ; c406407c 40801009 00000019
	buffer_store_b16 v10, v27, s[8:11], null offen              ; c406407c 4080100a 0000001b
	buffer_store_b16 v11, v1, s[8:11], null offen               ; c406407c 4080100b 00000001
	buffer_store_b16 v28, v36, s[8:11], null offen              ; c406407c 4080101c 00000024
	buffer_store_b16 v29, v37, s[8:11], null offen              ; c406407c 4080101d 00000025
	buffer_store_b16 v30, v38, s[8:11], null offen              ; c406407c 4080101e 00000026
	buffer_store_b16 v31, v39, s[8:11], null offen              ; c406407c 4080101f 00000027
	buffer_store_b16 v32, v40, s[8:11], null offen              ; c406407c 40801020 00000028
	buffer_store_b16 v33, v41, s[8:11], null offen              ; c406407c 40801021 00000029
	buffer_store_b16 v34, v42, s[8:11], null offen              ; c406407c 40801022 0000002a
	buffer_store_b16 v35, v0, s[8:11], null offen               ; c406407c 40801023 00000000
	buffer_store_b16 v43, v51, s[8:11], null offen              ; c406407c 4080102b 00000033
	buffer_store_b16 v44, v52, s[8:11], null offen              ; c406407c 4080102c 00000034
	buffer_store_b16 v45, v53, s[8:11], null offen              ; c406407c 4080102d 00000035
	buffer_store_b16 v46, v54, s[8:11], null offen              ; c406407c 4080102e 00000036
	buffer_store_b16 v47, v55, s[8:11], null offen              ; c406407c 4080102f 00000037
	buffer_store_b16 v48, v56, s[8:11], null offen              ; c406407c 40801030 00000038
	buffer_store_b16 v49, v57, s[8:11], null offen              ; c406407c 40801031 00000039
	buffer_store_b16 v50, v5, s[8:11], null offen               ; c406407c 40801032 00000005
	buffer_store_b16 v58, v14, s[8:11], null offen              ; c406407c 4080103a 0000000e
	buffer_store_b16 v59, v16, s[8:11], null offen              ; c406407c 4080103b 00000010
	buffer_store_b16 v60, v18, s[8:11], null offen              ; c406407c 4080103c 00000012
	buffer_store_b16 v61, v20, s[8:11], null offen              ; c406407c 4080103d 00000014
	buffer_store_b16 v62, v22, s[8:11], null offen              ; c406407c 4080103e 00000016
	buffer_store_b16 v63, v24, s[8:11], null offen              ; c406407c 4080103f 00000018
	buffer_store_b16 v64, v26, s[8:11], null offen              ; c406407c 40801040 0000001a
	buffer_store_b16 v65, v12, s[8:11], null offen              ; c406407c 40801041 0000000c
BB22:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
