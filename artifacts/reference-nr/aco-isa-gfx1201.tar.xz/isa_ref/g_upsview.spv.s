BB0:
	v_lshl_add_u32 v0, ttmp9, 6, v0                             ; d6460000 04010c75
	s_lshr_b32 s9, s4, 4                                        ; 85098404
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mul_i32 s3, s3, s9                                        ; 96030903
	v_cmpx_gt_u32_e32 s3, v0                                    ; 7d980003
	s_cbranch_execz BB12                                        ; bfa500e4
BB1:
	s_mov_b32 s3, 0x4f7ffffe                                    ; be8300ff 4f7ffffe
	s_cvt_f32_u32 s10, s9                                       ; be8a6509
(invalid instruction)                                        ; d684000a
	v_cndmask_b32_e32 v0, s10, v128, vcc_lo                     ; 0201000a
	s_mul_f32 s10, s10, s3                                      ; a20a030a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s10, s10                                      ; be8a670a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s11, s9, s10                                      ; 960b0a09
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s11, 0, s11                                    ; 818b0b80
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s11, s10, s11                                  ; 968b0b0a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s10, s10, s11                                  ; 800a0b0a
	s_add_co_u32 s14, s5, 3                                     ; 800e8305
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d0001
	v_cndmask_b32_e32 v0, v0, v10, vcc_lo                       ; 02001500
	s_and_b32 s14, s14, -4                                      ; 8b0ec40e
	s_cmp_eq_i32 s7, 0                                          ; bf008007
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_cselect_b32 s14, s14, s7                                  ; 980e070e
	s_add_co_u32 s15, s6, 3                                     ; 800f8306
	s_and_b32 s15, s15, -4                                      ; 8b0fc40f
	s_cmp_eq_i32 s8, 0                                          ; bf008008
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v1, v9, vcc_lo                        ; 02001301
	s_cselect_b32 s15, s15, s8                                  ; 980f080f
	s_lshr_b32 s16, s14, 2                                      ; 8510820e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870139
	s_cvt_f32_u32 s17, s16                                      ; be916510
	v_sub_nc_u32_e32 v0, v0, v2                                 ; 4c000500
(invalid instruction)                                        ; d6840011
	v_cndmask_b32_e32 v0, s17, v128, vcc_lo                     ; 02010011
(invalid instruction)                                        ; d7026a03
	v_cndmask_b32_e32 v1, s9, v0, vcc_lo                        ; 02020009
	s_mul_f32 s17, s17, s3                                      ; a2110311
	v_cndmask_b32_e32 v3, v3, v0, vcc_lo                        ; 02060103
	v_subrev_co_ci_u32_e64 v1, s12, -1, v1, vcc_lo              ; d5220c01 01aa02c1
	s_cvt_u32_f32 s17, s17                                      ; be916711
(invalid instruction)                                        ; d7026a04
	v_cndmask_b32_e32 v1, s9, v3, vcc_lo                        ; 02020609
	s_mul_i32 s18, s16, s17                                     ; 96121110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_sub_co_i32 s18, 0, s18                                    ; 81921280
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v4, v4, v3, vcc_lo                        ; 02080704
	v_subrev_co_ci_u32_e64 v1, s13, -1, v1, vcc_lo              ; d5220d01 01aa02c1
	s_mul_hi_u32 s18, s17, s18                                  ; 96921211
	s_add_co_u32 s17, s17, s18                                  ; 80111211
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                       ; 02001d04
	v_and_b32_e32 v10, 3, v1                                    ; 36140283
	v_lshrrev_b32_e32 v5, 4, v1                                 ; 320a0284
	s_mul_i32 s6, s5, s6                                        ; 96060605
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cvt_f32_u32 s19, s6                                       ; be936506
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d0006
	v_cndmask_b32_e32 v0, v5, v17, vcc_lo                       ; 02002305
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v0, v12, v15, vcc_lo                      ; 02001f0c
(invalid instruction)                                        ; d6840013
	v_cndmask_b32_e32 v0, s19, v128, vcc_lo                     ; 02010013
(invalid instruction)                                        ; d72c0007
	v_cndmask_b32_e32 v0, v6, v16, vcc_lo                       ; 02002106
	s_mul_f32 s19, s19, s3                                      ; a2130313
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s19, s19                                      ; be936713
	v_sub_nc_u32_e32 v7, v5, v7                                 ; 4c0e0f05
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s20, s6, s19                                      ; 96141306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_sub_co_i32 s20, 0, s20                                    ; 81941480
(invalid instruction)                                        ; d7026a08
	v_cndmask_b32_e32 v1, s16, v7, vcc_lo                       ; 02020e10
	s_mul_hi_u32 s20, s19, s20                                  ; 96941413
	s_add_co_u32 s19, s19, s20                                  ; 80131413
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_dual_cndmask_b32 v8, v8, v7 :: v_dual_and_b32 v1, 15, v1  ; ca640f08 0800028f
	v_subrev_co_ci_u32_e32 v6, vcc_lo, -1, v6, vcc_lo           ; 440c0cc1
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshrrev_b32_e32 v11, 2, v1                                ; 32160282
(invalid instruction)                                        ; d7021009
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                       ; 02021010
	s_cvt_f32_u32 s23, s5                                       ; be976505
	v_cndmask_b32_e64 v9, v9, v8, s16                           ; d5010009 00421109
	v_subrev_co_ci_u32_e64 v6, vcc_lo, -1, v6, s16              ; d5226a06 00420cc1
(invalid instruction)                                        ; d6840017
	v_cndmask_b32_e32 v0, s23, v128, vcc_lo                     ; 02010017
	v_lshl_add_u32 v9, v9, 2, v10                               ; d6460009 04290509
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
	v_lshl_add_u32 v6, v6, 2, v11                               ; d6460006 042d0506
	s_mul_f32 s23, s23, s3                                      ; a2170317
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v0, v6, v14, vcc_lo                       ; 02001d06
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s23, s23                                      ; be976717
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s24, s5, s23                                      ; 96181705
	v_add3_u32 v9, v9, v12, v13                                 ; d6550009 04361909
	s_sub_co_i32 s24, 0, s24                                    ; 81981880
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_mul_hi_u32 s24, s23, s24                                  ; 96981817
(invalid instruction)                                        ; d72d000e
	v_cndmask_b32_e32 v0, v9, v19, vcc_lo                       ; 02002709
	s_add_co_u32 s23, s23, s24                                  ; 80171817
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c000f
	v_cndmask_b32_e32 v0, v14, v6, vcc_lo                       ; 02000d0e
	v_sub_nc_u32_e32 v9, v9, v15                                ; 4c121f09
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7026a10
	v_cndmask_b32_e32 v1, s6, v9, vcc_lo                        ; 02021206
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_subrev_co_ci_u32_e64 v14, s21, -1, v14, vcc_lo            ; d522150e 01aa1cc1
	v_cndmask_b32_e32 v16, v16, v9, vcc_lo                      ; 02201310
	s_lshr_b32 s26, s5, 2                                       ; 851a8205
(invalid instruction)                                        ; d7026a11
	v_cndmask_b32_e32 v1, s6, v16, vcc_lo                       ; 02022006
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_subrev_co_ci_u32_e64 v14, s22, -1, v14, vcc_lo            ; d522160e 01aa1cc1
	v_cndmask_b32_e32 v17, v17, v16, vcc_lo                     ; 02222111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72d0012
	v_cndmask_b32_e32 v0, v17, v23, vcc_lo                      ; 02002f11
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v0, v18, v5, vcc_lo                       ; 02000b12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v17, v17, v19                              ; 4c222711
(invalid instruction)                                        ; d7026a14
	v_cndmask_b32_e32 v1, s5, v17, vcc_lo                       ; 02022205
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_dual_cndmask_b32 v20, v20, v17 :: v_dual_lshlrev_b32 v25, 4, v14 ; ca622314 14181c84
	v_subrev_co_ci_u32_e32 v18, vcc_lo, -1, v18, vcc_lo         ; 442424c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
(invalid instruction)                                        ; d7021915
	v_cndmask_b32_e32 v1, s5, v20, vcc_lo                       ; 02022805
(invalid instruction)                                        ; d44c0004
	v_cndmask_b32_e32 v1, s4, v25, vcc_lo                       ; 02023204
	v_cndmask_b32_e64 v21, v21, v20, s25                        ; d5010015 00662915
	v_subrev_co_ci_u32_e64 v18, vcc_lo, -1, v18, s25            ; d5226a12 006624c1
	v_cmp_gt_u32_e32 vcc_lo, s15, v6                            ; 7c980c0f
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_and_b32_e32 v24, 3, v21                                   ; 36302a83
	v_lshrrev_b32_e32 v23, 2, v21                               ; 322e2a82
	v_lshrrev_b32_e32 v22, 2, v18                               ; 322c2482
	v_and_b32_e32 v18, 3, v18                                   ; 36242483
	s_and_b32 s4, vcc_lo, s4                                    ; 8b04046a
	s_and_b32 s5, s5, -4                                        ; 8b05c405
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d2
(invalid instruction)                                        ; d72c0016
	v_cndmask_b32_e32 v0, v22, v26, vcc_lo                      ; 02003516
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmp_gt_u32_e32 vcc_lo, s5, v21                            ; 7c982a05
	s_nand_b32 s4, s4, vcc_lo                                   ; 8e046a04
	v_add_lshl_u32 v22, v22, v23, 4                             ; d6470016 02122f16
	v_lshl_add_u32 v18, v18, 2, v22                             ; d6460012 04590512
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v18, v18, v24                              ; 4a243112
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_saveexec_b32 s4, s4                                   ; be842004
BB2:
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0                ; ca100080 09080080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0              ; ca100080 0b0a0080
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_not1_b32 exec_lo, s4, exec_lo                         ; 917e7e04
	s_cbranch_execz BB7                                         ; bfa50016
BB5:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[12:15], s[6:7], 0x0                           ; f4004303 f8000000
	v_and_b32_e32 v14, 0xfffffff, v14                           ; 361c1cff 0fffffff
	v_lshrrev_b32_e32 v0, 4, v18                                ; 32002484
	v_and_b32_e32 v18, 15, v18                                  ; 3624248f
	s_and_b32 s1, s1, -16                                       ; 8b01d001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; d72c0000
	v_cndmask_b32_e32 v0, v0, v9, vcc_lo                        ; 02001300
	v_add_lshl_u32 v0, v0, v14, 8                               ; d6470000 02221d00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v18, v18, 4, v0                              ; d6460012 04010912
	v_add_nc_u32_e32 v18, s1, v18                               ; 4a242401
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b128 v[8:11], v18, s[12:15], null offen         ; c405c07c 40801808 00000012
BB7:
	s_mov_b32 exec_lo, s4                                       ; befe0004
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[4:7], s[0:1], 0x0                             ; f4004100 f8000000
	s_and_b32 s2, s2, -16                                       ; 8b02d002
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v0, v5, v9, vcc_lo                        ; 02001305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v5, v5, v4, 8                                ; d6470005 02220905
	v_lshl_add_u32 v1, v1, 4, v5                                ; d6460001 04150901
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v1, s2, v1                                 ; 4a020202
	s_wait_loadcnt 0x0                                          ; bfc00000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b128 v[8:11], v1, s[4:7], null offen           ; c407407c 40800808 00000001
BB12:
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
