BB0:
	s_lshr_b32 s7, s6, 4                                        ; 85078406
	s_lshl_b32 s8, ttmp9, 6                                     ; 84088675
	v_bfe_u32 v1, v0, 5, 2                                      ; d6100001 02090b00
	s_lshr_b32 s9, s8, 4                                        ; 85098408
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s10, s9, s7                                       ; 960a0709
	s_lshl_b32 s10, s10, 8                                      ; 840a880a
	s_add_co_u32 s11, 16, s8                                    ; 800b0890
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshr_b32 s12, s11, 4                                      ; 850c840b
	s_mul_i32 s13, s12, s7                                      ; 960d070c
	v_and_b32_e32 v9, 15, v0                                    ; 3612008f
	s_lshl_b32 s13, s13, 8                                      ; 840d880d
	s_add_co_u32 s14, 32, s8                                    ; 800e08a0
	v_bfe_u32 v12, v0, 4, 1                                     ; d610000c 02050900
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshlrev_b32_e32 v10, 4, v9                                ; 30141284
	s_lshr_b32 s15, s14, 4                                      ; 850f840e
	v_lshlrev_b32_e32 v12, 3, v12                               ; 30181883
	s_mul_i32 s16, s15, s7                                      ; 9610070f
	v_add3_u32 v11, v10, s1, s10                                ; d655000b 0028030a
	v_add3_u32 v13, v10, s1, s13                                ; d655000d 0034030a
	s_lshl_b32 s16, s16, 8                                      ; 84108810
	s_add_co_u32 s17, 48, s8                                    ; 801108b0
	v_add3_u32 v14, v10, s1, s16                                ; d655000e 0040030a
	v_add_nc_u32_e32 v11, v11, v12                              ; 4a16190b
	s_lshr_b32 s18, s17, 4                                      ; 85128411
	v_add_nc_u32_e32 v13, v13, v12                              ; 4a1a190d
	s_mul_i32 s19, s18, s7                                      ; 96130712
	v_add_nc_u32_e32 v14, v14, v12                              ; 4a1c190e
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0              ; ca100080 10100080
	s_lshl_b32 s19, s19, 8                                      ; 84138813
	s_lshl_b32 s20, ttmp7, 8                                    ; 84148873
	v_add3_u32 v10, v10, s1, s19                                ; d655000a 004c030a
	v_lshl_add_u32 v1, v1, 6, s20                               ; d6460001 00510d01
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v10, v10, v12                              ; 4a14190a
	v_add_nc_u32_e32 v4, 16, v1                                 ; 4a080290
	v_add_nc_u32_e32 v6, 32, v1                                 ; 4a0c02a0
	v_lshrrev_b32_e32 v2, 4, v1                                 ; 32040284
	v_add_nc_u32_e32 v1, 48, v1                                 ; 4a0202b0
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0              ; ca100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0              ; ca100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0              ; ca100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0              ; ca100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0              ; ca100080 1a1a0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0              ; ca100080 1c1c0080
	s_lshr_b32 s6, s6, 5                                        ; 85068506
	v_lshrrev_b32_e32 v4, 4, v4                                 ; 32080884
	v_lshrrev_b32_e32 v11, 2, v11                               ; 32161682
	v_lshrrev_b32_e32 v6, 4, v6                                 ; 320c0c84
	v_lshrrev_b32_e32 v13, 2, v13                               ; 321a1a82
(invalid instruction)                                        ; d72c0003
	v_cndmask_b32_e32 v0, v2, v7, vcc_lo                        ; 02000f02
	v_lshrrev_b32_e32 v1, 4, v1                                 ; 32020284
	v_lshrrev_b32_e32 v14, 2, v14                               ; 321c1c82
	v_lshrrev_b32_e32 v10, 2, v10                               ; 32141482
	s_mov_b32 s1, 0                                             ; be810080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v0, v4, v7, vcc_lo                        ; 02000f04
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
(invalid instruction)                                        ; d72c0007
	v_cndmask_b32_e32 v0, v6, v7, vcc_lo                        ; 02000f06
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
(invalid instruction)                                        ; d72c0008
	v_cndmask_b32_e32 v0, v1, v7, vcc_lo                        ; 02000f01
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	v_lshl_add_u32 v3, v3, 8, s3                                ; d6460003 000d1103
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v60, 0              ; ca100080 3d3c0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v62, 0              ; ca100080 3f3e0080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v64, 0              ; ca100080 41400080
	v_lshl_add_u32 v5, v5, 8, s3                                ; d6460005 000d1105
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0              ; ca100080 43420080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v68, 0              ; ca100080 45440080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v70, 0              ; ca100080 47460080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v72, 0              ; ca100080 49480080
	v_lshl_add_u32 v7, v7, 8, s3                                ; d6460007 000d1107
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v74, 0              ; ca100080 4b4a0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v76, 0              ; ca100080 4d4c0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v78, 0              ; ca100080 4f4e0080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v80, 0              ; ca100080 51500080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v82, 0              ; ca100080 53520080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v84, 0              ; ca100080 55540080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v86, 0              ; ca100080 57560080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v88, 0              ; ca100080 59580080
	v_lshl_add_u32 v8, v8, 8, s3                                ; d6460008 000d1108
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v90, 0              ; ca100080 5b5a0080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v92, 0              ; ca100080 5d5c0080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v94, 0              ; ca100080 5f5e0080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v96, 0              ; ca100080 61600080
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v98, 0              ; ca100080 63620080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v100, 0            ; ca100080 65640080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v102, 0            ; ca100080 67660080
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v104, 0            ; ca100080 69680080
	v_dual_mov_b32 v107, 0 :: v_dual_mov_b32 v106, 0            ; ca100080 6b6a0080
	v_dual_mov_b32 v109, 0 :: v_dual_mov_b32 v108, 0            ; ca100080 6d6c0080
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v110, 0            ; ca100080 6f6e0080
	v_dual_mov_b32 v113, 0 :: v_dual_mov_b32 v112, 0            ; ca100080 71700080
	v_dual_mov_b32 v115, 0 :: v_dual_mov_b32 v114, 0            ; ca100080 73720080
	v_dual_mov_b32 v117, 0 :: v_dual_mov_b32 v116, 0            ; ca100080 75740080
	v_dual_mov_b32 v119, 0 :: v_dual_mov_b32 v118, 0            ; ca100080 77760080
	v_dual_mov_b32 v121, 0 :: v_dual_mov_b32 v120, 0            ; ca100080 79780080
	v_dual_mov_b32 v123, 0 :: v_dual_mov_b32 v122, 0            ; ca100080 7b7a0080
	v_dual_mov_b32 v125, 0 :: v_dual_mov_b32 v124, 0            ; ca100080 7d7c0080
	v_dual_mov_b32 v127, 0 :: v_dual_mov_b32 v126, 0            ; ca100080 7f7e0080
	v_dual_mov_b32 v129, 0 :: v_dual_mov_b32 v128, 0            ; ca100080 81800080
	v_dual_mov_b32 v131, 0 :: v_dual_mov_b32 v130, 0            ; ca100080 83820080
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v132, 0            ; ca100080 85840080
	v_dual_mov_b32 v135, 0 :: v_dual_mov_b32 v134, 0            ; ca100080 87860080
	v_dual_mov_b32 v137, 0 :: v_dual_mov_b32 v136, 0            ; ca100080 89880080
	v_dual_mov_b32 v139, 0 :: v_dual_mov_b32 v138, 0            ; ca100080 8b8a0080
	v_dual_mov_b32 v141, 0 :: v_dual_mov_b32 v140, 0            ; ca100080 8d8c0080
	v_dual_mov_b32 v143, 0 :: v_dual_mov_b32 v142, 0            ; ca100080 8f8e0080
	s_branch BB1                                                ; bfa000be
	s_nop 0                                                     ; bf800000
	(then repeated 6 times)
BB3:
	s_mov_b32 s20, s0                                           ; be940000
	s_movk_i32 s21, 0x8000                                      ; b0158000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[20:21], 0x70                        ; f400460a f8000070
	s_load_b128 s[20:23], s[20:21], 0x30                        ; f400450a f8000030
	s_lshl_b32 s3, s1, 5                                        ; 84038501
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s3, s3, 4                                        ; 85038403
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s3, s3, 8                                        ; 84038803
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s7, s3, 2                                        ; 85078203
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v12, s7, v11, 2                              ; d647000c 020a1607
	v_add_lshl_u32 v15, s7, v13, 2                              ; d647000f 020a1a07
	v_add_lshl_u32 v144, s7, v14, 2                             ; d6470090 020a1c07
	v_add_lshl_u32 v145, s7, v10, 2                             ; d6470091 020a1407
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[146:147], v12, s[24:27], null offen       ; c405407c 40803092 0000000c
	buffer_load_b64 v[148:149], v15, s[24:27], null offen       ; c405407c 40803094 0000000f
	buffer_load_b64 v[150:151], v144, s[24:27], null offen      ; c405407c 40803096 00000090
	buffer_load_b64 v[152:153], v145, s[24:27], null offen      ; c405407c 40803098 00000091
(invalid instruction)                                        ; d71f009b
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_add_nc_u32_e32 v154, s3, v3                               ; 4b340603
	v_add_nc_u32_e32 v158, s3, v5                               ; 4b3c0a03
	v_add_nc_u32_e32 v160, s3, v7                               ; 4b400e03
	v_add_nc_u32_e32 v162, s3, v8                               ; 4b441003
	v_and_b32_e32 v156, 15, v155                                ; 3739368f
	v_lshrrev_b32_e32 v155, 4, v155                             ; 33373684
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_lshlrev_b32_e32 v156, 4, v156                             ; 31393884
	v_lshlrev_b32_e32 v155, 3, v155                             ; 31373683
	v_add3_u32 v157, v155, v154, v156                           ; d655009d 0673359b
	v_add3_u32 v159, v155, v158, v156                           ; d655009f 06733d9b
	v_add3_u32 v161, v155, v160, v156                           ; d65500a1 0673419b
	v_add3_u32 v163, v155, v162, v156                           ; d65500a3 0673459b
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[164:165], v157, s[20:23], null offen      ; c405407c 408028a4 0000009d
	buffer_load_b64 v[166:167], v159, s[20:23], null offen      ; c405407c 408028a6 0000009f
	buffer_load_b64 v[168:169], v161, s[20:23], null offen      ; c405407c 408028a8 000000a1
	buffer_load_b64 v[170:171], v163, s[20:23], null offen      ; c405407c 408028aa 000000a3
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[172:173], v12, s[24:27], null offen offset:256 ; c405407c 408030ac 0001000c
	buffer_load_b64 v[174:175], v15, s[24:27], null offen offset:256 ; c405407c 408030ae 0001000f
	buffer_load_b64 v[176:177], v144, s[24:27], null offen offset:256 ; c405407c 408030b0 00010090
	buffer_load_b64 v[144:145], v145, s[24:27], null offen offset:256 ; c405407c 40803090 00010091
	s_movk_i32 s10, 0x100                                       ; b00a0100
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v154, v156, s10, v154                            ; d655009a 0668159c
	v_add3_u32 v158, v156, s10, v158                            ; d655009e 0678159c
	v_add3_u32 v160, v156, s10, v160                            ; d65500a0 0680159c
	v_add3_u32 v156, v156, s10, v162                            ; d655009c 0688159c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_add_nc_u32_e32 v154, v154, v155                           ; 4b35379a
	v_add_nc_u32_e32 v158, v158, v155                           ; 4b3d379e
	v_add_nc_u32_e32 v160, v160, v155                           ; 4b4137a0
	v_add_nc_u32_e32 v156, v156, v155                           ; 4b39379c
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[154:155], v154, s[20:23], null offen      ; c405407c 4080289a 0000009a
	buffer_load_b64 v[158:159], v158, s[20:23], null offen      ; c405407c 4080289e 0000009e
	buffer_load_b64 v[160:161], v160, s[20:23], null offen      ; c405407c 408028a0 000000a0
	buffer_load_b64 v[156:157], v156, s[20:23], null offen      ; c405407c 4080289c 0000009c
	s_add_co_u32 s1, s1, 1                                      ; 80018101
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[150:151], v[164:165], v[80:87] ; cc464050 1d434996
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[152:153], v[164:165], v[112:119] ; cc464070 1dc34998
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[146:147], v[164:165], v[16:23] ; cc464010 1c434992
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[148:149], v[164:165], v[48:55] ; cc464030 1cc34994
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[146:147], v[166:167], v[24:31] ; cc464018 1c634d92
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[152:153], v[166:167], v[120:127] ; cc464078 1de34d98
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[148:149], v[166:167], v[56:63] ; cc464038 1ce34d94
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[150:151], v[166:167], v[88:95] ; cc464058 1d634d96
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[146:147], v[168:169], v[32:39] ; cc464020 1c835192
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[148:149], v[168:169], v[64:71] ; cc464040 1d035194
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[150:151], v[168:169], v[96:103] ; cc464060 1d835196
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[152:153], v[168:169], v[128:135] ; cc464080 1e035198
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[148:149], v[170:171], v[72:79] ; cc464048 1d235594
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[150:151], v[170:171], v[104:111] ; cc464068 1da35596
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[152:153], v[170:171], v[136:143] ; cc464088 1e235598
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[146:147], v[170:171], v[40:47] ; cc464028 1ca35592
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[176:177], v[154:155], v[80:87] ; cc464050 1d4335b0
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[144:145], v[154:155], v[112:119] ; cc464070 1dc33590
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[172:173], v[154:155], v[16:23] ; cc464010 1c4335ac
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[174:175], v[154:155], v[48:55] ; cc464030 1cc335ae
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[172:173], v[158:159], v[24:31] ; cc464018 1c633dac
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[144:145], v[158:159], v[120:127] ; cc464078 1de33d90
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[174:175], v[158:159], v[56:63] ; cc464038 1ce33dae
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[176:177], v[158:159], v[88:95] ; cc464058 1d633db0
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[172:173], v[160:161], v[32:39] ; cc464020 1c8341ac
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[174:175], v[160:161], v[64:71] ; cc464040 1d0341ae
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[176:177], v[160:161], v[96:103] ; cc464060 1d8341b0
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[144:145], v[160:161], v[128:135] ; cc464080 1e034190
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[174:175], v[156:157], v[72:79] ; cc464048 1d2339ae
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[176:177], v[156:157], v[104:111] ; cc464068 1da339b0
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[144:145], v[156:157], v[136:143] ; cc464088 1e233990
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[172:173], v[156:157], v[40:47] ; cc464028 1ca339ac
BB1:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s1, s6                                         ; bf090601
	s_cbranch_scc0 BB3                                          ; bfa1ff46
BB4:
	s_cmp_lt_u32 s8, s4                                         ; bf0a0408
	s_cbranch_scc0 BB7                                          ; bfa10184
BB5:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[20:23], s[6:7], 0x10                          ; f4004503 f8000010
	v_and_b32_e32 v3, 16, v0                                    ; 36060090
	s_lshr_b32 s1, s5, 4                                        ; 85018405
	v_cvt_f16_f32_e32 v5, v16                                   ; 7e0a1510
	v_cvt_f16_f32_e32 v10, v17                                  ; 7e141511
	v_cvt_f16_f32_e32 v13, v18                                  ; 7e1a1512
	v_cvt_f16_f32_e32 v16, v19                                  ; 7e201513
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s9, s9, s1                                        ; 96090109
	v_cvt_f16_f32_e32 v19, v20                                  ; 7e261514
	v_lshl_or_b32 v3, v3, 3, v9                                 ; d6560003 04250703
	v_maxmin_num_f16 v5, 0xdf00, v5, neg(0xdf00)                ; d66b0005 83fe0aff 0000df00
(invalid instruction)                                        ; d58a0091
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
	v_maxmin_num_f16 v10, 0xdf00, v10, neg(0xdf00)              ; d66b000a 83fe14ff 0000df00
	v_maxmin_num_f16 v13, 0xdf00, v13, neg(0xdf00)              ; d66b000d 83fe1aff 0000df00
	v_maxmin_num_f16 v16, 0xdf00, v16, neg(0xdf00)              ; d66b0010 83fe20ff 0000df00
(invalid instruction)                                        ; d58a0094
	v_cndmask_b32_e32 v0, v22, v128, vcc_lo                     ; 02010116
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
	v_cvt_f32_f16_e32 v7, v5                                    ; 7e0e1705
	v_maxmin_num_f16 v145, 0xdf00, v145, neg(0xdf00)            ; d66b0091 83ff22ff 0000df00
(invalid instruction)                                        ; d58a0097
	v_cndmask_b32_e32 v0, v23, v128, vcc_lo                     ; 02010117
	v_cvt_f32_f16_e32 v11, v10                                  ; 7e16170a
	v_cvt_f32_f16_e32 v14, v13                                  ; 7e1c170d
	v_cvt_f32_f16_e32 v17, v16                                  ; 7e221710
	v_maxmin_num_f16 v148, 0xdf00, v148, neg(0xdf00)            ; d66b0094 83ff28ff 0000df00
	v_add_lshl_u32 v154, s9, v2, 8                              ; d647009a 02220409
	v_cvt_f32_f16_e32 v20, v19                                  ; 7e281713
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v0, v7, v128, vcc_lo                      ; 02010107
(invalid instruction)                                        ; d58b0092
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                    ; 02010191
	v_maxmin_num_f16 v151, 0xdf00, v151, neg(0xdf00)            ; d66b0097 83ff2eff 0000df00
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
(invalid instruction)                                        ; d58b0095
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                    ; 02010194
	v_add3_u32 v154, v3, s2, v154                               ; d655009a 06680503
(invalid instruction)                                        ; d7690090
	v_cndmask_b32_e32 v0, v20, v128, vcc_lo                     ; 02010114
(invalid instruction)                                        ; d7690093
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                    ; 02010192
(invalid instruction)                                        ; d58b0098
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                    ; 02010197
(invalid instruction)                                        ; d7690096
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                    ; 02010195
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690099
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                    ; 02010198
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v8, v154, s[20:23], null offen              ; c406007c 40802808 0000009a
	buffer_store_b8 v12, v154, s[20:23], null offen offset:16   ; c406007c 4080280c 0000109a
	buffer_store_b8 v15, v154, s[20:23], null offen offset:32   ; c406007c 4080280f 0000209a
	buffer_store_b8 v18, v154, s[20:23], null offen offset:48   ; c406007c 40802812 0000309a
	buffer_store_b8 v144, v154, s[20:23], null offen offset:64  ; c406007c 40802890 0000409a
	buffer_store_b8 v147, v154, s[20:23], null offen offset:80  ; c406007c 40802893 0000509a
	buffer_store_b8 v150, v154, s[20:23], null offen offset:96  ; c406007c 40802896 0000609a
	buffer_store_b8 v153, v154, s[20:23], null offen offset:112 ; c406007c 40802899 0000709a
(invalid instruction)                                        ; d58a009b
	v_cndmask_b32_e32 v0, v24, v128, vcc_lo                     ; 02010118
(invalid instruction)                                        ; d58a009e
	v_cndmask_b32_e32 v0, v25, v128, vcc_lo                     ; 02010119
(invalid instruction)                                        ; d58a00a1
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
(invalid instruction)                                        ; d58a00a4
	v_cndmask_b32_e32 v0, v27, v128, vcc_lo                     ; 0201011b
(invalid instruction)                                        ; d58a00a7
	v_cndmask_b32_e32 v0, v28, v128, vcc_lo                     ; 0201011c
(invalid instruction)                                        ; d58a00aa
	v_cndmask_b32_e32 v0, v29, v128, vcc_lo                     ; 0201011d
	v_maxmin_num_f16 v155, 0xdf00, v155, neg(0xdf00)            ; d66b009b 83ff36ff 0000df00
	v_maxmin_num_f16 v158, 0xdf00, v158, neg(0xdf00)            ; d66b009e 83ff3cff 0000df00
	v_maxmin_num_f16 v161, 0xdf00, v161, neg(0xdf00)            ; d66b00a1 83ff42ff 0000df00
(invalid instruction)                                        ; d58a00ad
	v_cndmask_b32_e32 v0, v30, v128, vcc_lo                     ; 0201011e
	v_maxmin_num_f16 v164, 0xdf00, v164, neg(0xdf00)            ; d66b00a4 83ff48ff 0000df00
	v_maxmin_num_f16 v167, 0xdf00, v167, neg(0xdf00)            ; d66b00a7 83ff4eff 0000df00
	v_maxmin_num_f16 v170, 0xdf00, v170, neg(0xdf00)            ; d66b00aa 83ff54ff 0000df00
(invalid instruction)                                        ; d58b009c
	v_cndmask_b32_e32 v0, v155, v128, vcc_lo                    ; 0201019b
(invalid instruction)                                        ; d58b009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
(invalid instruction)                                        ; d58a00b0
	v_cndmask_b32_e32 v0, v31, v128, vcc_lo                     ; 0201011f
(invalid instruction)                                        ; d58b00a2
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
	v_maxmin_num_f16 v173, 0xdf00, v173, neg(0xdf00)            ; d66b00ad 83ff5aff 0000df00
(invalid instruction)                                        ; d58b00a5
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
(invalid instruction)                                        ; d58b00a8
	v_cndmask_b32_e32 v0, v167, v128, vcc_lo                    ; 020101a7
	v_add_lshl_u32 v179, s9, v4, 8                              ; d64700b3 02220809
(invalid instruction)                                        ; d58b00ab
	v_cndmask_b32_e32 v0, v170, v128, vcc_lo                    ; 020101aa
(invalid instruction)                                        ; d769009d
	v_cndmask_b32_e32 v0, v156, v128, vcc_lo                    ; 0201019c
(invalid instruction)                                        ; d76900a0
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                    ; 0201019f
	v_maxmin_num_f16 v176, 0xdf00, v176, neg(0xdf00)            ; d66b00b0 83ff60ff 0000df00
(invalid instruction)                                        ; d76900a3
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v173, v128, vcc_lo                    ; 020101ad
(invalid instruction)                                        ; d76900a6
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
(invalid instruction)                                        ; d76900a9
	v_cndmask_b32_e32 v0, v168, v128, vcc_lo                    ; 020101a8
	v_add3_u32 v179, v3, s2, v179                               ; d65500b3 06cc0503
(invalid instruction)                                        ; d76900ac
	v_cndmask_b32_e32 v0, v171, v128, vcc_lo                    ; 020101ab
(invalid instruction)                                        ; d58b00b1
	v_cndmask_b32_e32 v0, v176, v128, vcc_lo                    ; 020101b0
(invalid instruction)                                        ; d76900af
	v_cndmask_b32_e32 v0, v174, v128, vcc_lo                    ; 020101ae
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900b2
	v_cndmask_b32_e32 v0, v177, v128, vcc_lo                    ; 020101b1
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v157, v179, s[20:23], null offen            ; c406007c 4080289d 000000b3
	buffer_store_b8 v160, v179, s[20:23], null offen offset:16  ; c406007c 408028a0 000010b3
	buffer_store_b8 v163, v179, s[20:23], null offen offset:32  ; c406007c 408028a3 000020b3
	buffer_store_b8 v166, v179, s[20:23], null offen offset:48  ; c406007c 408028a6 000030b3
	buffer_store_b8 v169, v179, s[20:23], null offen offset:64  ; c406007c 408028a9 000040b3
	buffer_store_b8 v172, v179, s[20:23], null offen offset:80  ; c406007c 408028ac 000050b3
	buffer_store_b8 v175, v179, s[20:23], null offen offset:96  ; c406007c 408028af 000060b3
	buffer_store_b8 v178, v179, s[20:23], null offen offset:112 ; c406007c 408028b2 000070b3
(invalid instruction)                                        ; d58a00b4
	v_cndmask_b32_e32 v0, v32, v128, vcc_lo                     ; 02010120
(invalid instruction)                                        ; d58a00b7
	v_cndmask_b32_e32 v0, v33, v128, vcc_lo                     ; 02010121
(invalid instruction)                                        ; d58a00ba
	v_cndmask_b32_e32 v0, v34, v128, vcc_lo                     ; 02010122
(invalid instruction)                                        ; d58a00bd
	v_cndmask_b32_e32 v0, v35, v128, vcc_lo                     ; 02010123
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_maxmin_num_f16 v180, 0xdf00, v180, neg(0xdf00)            ; d66b00b4 83ff68ff 0000df00
	v_cvt_f16_f32_e32 v8, v37                                   ; 7e101525
	v_maxmin_num_f16 v183, 0xdf00, v183, neg(0xdf00)            ; d66b00b7 83ff6eff 0000df00
	v_maxmin_num_f16 v186, 0xdf00, v186, neg(0xdf00)            ; d66b00ba 83ff74ff 0000df00
	v_maxmin_num_f16 v189, 0xdf00, v189, neg(0xdf00)            ; d66b00bd 83ff7aff 0000df00
	v_cvt_f16_f32_e32 v12, v38                                  ; 7e181526
(invalid instruction)                                        ; d58b00b5
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                    ; 020101b4
	v_maxmin_num_f16 v8, 0xdf00, v8, neg(0xdf00)                ; d66b0008 83fe10ff 0000df00
(invalid instruction)                                        ; d58b00b8
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                    ; 020101b7
(invalid instruction)                                        ; d58b00bb
	v_cndmask_b32_e32 v0, v186, v128, vcc_lo                    ; 020101ba
	v_cvt_f16_f32_e32 v15, v39                                  ; 7e1e1527
(invalid instruction)                                        ; d58b00be
	v_cndmask_b32_e32 v0, v189, v128, vcc_lo                    ; 020101bd
	v_maxmin_num_f16 v12, 0xdf00, v12, neg(0xdf00)              ; d66b000c 83fe18ff 0000df00
(invalid instruction)                                        ; d76900b6
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                    ; 020101b5
	v_cvt_f32_f16_e32 v10, v8                                   ; 7e141708
	v_add_lshl_u32 v18, s9, v6, 8                               ; d6470012 02220c09
(invalid instruction)                                        ; d76900b9
	v_cndmask_b32_e32 v0, v184, v128, vcc_lo                    ; 020101b8
(invalid instruction)                                        ; d76900bc
	v_cndmask_b32_e32 v0, v187, v128, vcc_lo                    ; 020101bb
	v_maxmin_num_f16 v15, 0xdf00, v15, neg(0xdf00)              ; d66b000f 83fe1eff 0000df00
(invalid instruction)                                        ; d76900bf
	v_cndmask_b32_e32 v0, v190, v128, vcc_lo                    ; 020101be
(invalid instruction)                                        ; d58a40bf
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
	v_cvt_f32_f16_e32 v13, v12                                  ; 7e1a170c
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v10, v128, vcc_lo                     ; 0201010a
	v_add3_u32 v18, v3, s2, v18                                 ; d6550012 04480503
	v_cvt_f32_f16_e32 v16, v15                                  ; 7e20170f
	v_maxmin_num_f16 v191, 0xdf00, v191, neg(0xdf00)            ; d66b50bf 83ff7eff 0000df00
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v0, v13, v128, vcc_lo                     ; 0201010d
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
(invalid instruction)                                        ; d58b0805
	v_cndmask_b32_e32 v0, v191, v128, vcc_lo                    ; 020101bf
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v0, v5, v128, vcc_lo                      ; 02010105
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v182, v18, s[20:23], null offen             ; c406007c 408028b6 00000012
	buffer_store_b8 v185, v18, s[20:23], null offen offset:16   ; c406007c 408028b9 00001012
	buffer_store_b8 v188, v18, s[20:23], null offen offset:32   ; c406007c 408028bc 00002012
	buffer_store_b8 v191, v18, s[20:23], null offen offset:48   ; c406007c 408028bf 00003012
	buffer_store_b8 v7, v18, s[20:23], null offen offset:64     ; c406007c 40802807 00004012
	buffer_store_b8 v11, v18, s[20:23], null offen offset:80    ; c406007c 4080280b 00005012
	buffer_store_b8 v14, v18, s[20:23], null offen offset:96    ; c406007c 4080280e 00006012
	buffer_store_b8 v17, v18, s[20:23], null offen offset:112   ; c406007c 40802811 00007012
	v_cvt_f16_f32_e32 v19, v40                                  ; 7e261528
	v_cvt_f16_f32_e32 v22, v41                                  ; 7e2c1529
	v_cvt_f16_f32_e32 v25, v42                                  ; 7e32152a
	v_cvt_f16_f32_e32 v28, v43                                  ; 7e38152b
	v_cvt_f16_f32_e32 v31, v44                                  ; 7e3e152c
	v_cvt_f16_f32_e32 v34, v45                                  ; 7e44152d
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
	v_maxmin_num_f16 v22, 0xdf00, v22, neg(0xdf00)              ; d66b0016 83fe2cff 0000df00
	v_maxmin_num_f16 v25, 0xdf00, v25, neg(0xdf00)              ; d66b0019 83fe32ff 0000df00
	v_maxmin_num_f16 v28, 0xdf00, v28, neg(0xdf00)              ; d66b001c 83fe38ff 0000df00
	v_cvt_f16_f32_e32 v37, v46                                  ; 7e4a152e
	v_maxmin_num_f16 v31, 0xdf00, v31, neg(0xdf00)              ; d66b001f 83fe3eff 0000df00
	v_maxmin_num_f16 v34, 0xdf00, v34, neg(0xdf00)              ; d66b0022 83fe44ff 0000df00
	v_cvt_f32_f16_e32 v20, v19                                  ; 7e281713
	v_cvt_f16_f32_e32 v40, v47                                  ; 7e50152f
	v_cvt_f32_f16_e32 v23, v22                                  ; 7e2e1716
	v_cvt_f32_f16_e32 v26, v25                                  ; 7e341719
	v_cvt_f32_f16_e32 v29, v28                                  ; 7e3a171c
	v_maxmin_num_f16 v37, 0xdf00, v37, neg(0xdf00)              ; d66b0025 83fe4aff 0000df00
	v_cvt_f32_f16_e32 v32, v31                                  ; 7e40171f
	v_add_lshl_u32 v43, s9, v1, 8                               ; d647002b 02220209
	v_cvt_f32_f16_e32 v35, v34                                  ; 7e461722
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v0, v20, v128, vcc_lo                     ; 02010114
	v_maxmin_num_f16 v40, 0xdf00, v40, neg(0xdf00)              ; d66b0028 83fe50ff 0000df00
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v0, v23, v128, vcc_lo                     ; 02010117
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v0, v29, v128, vcc_lo                     ; 0201011d
	v_cvt_f32_f16_e32 v38, v37                                  ; 7e4c1725
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v0, v32, v128, vcc_lo                     ; 02010120
	v_add3_u32 v3, v3, s2, v43                                  ; d6550003 04ac0503
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v0, v35, v128, vcc_lo                     ; 02010123
	v_cvt_f32_f16_e32 v41, v40                                  ; 7e521728
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v0, v38, v128, vcc_lo                     ; 02010126
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v0, v41, v128, vcc_lo                     ; 02010129
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v21, v3, s[20:23], null offen               ; c406007c 40802815 00000003
	buffer_store_b8 v24, v3, s[20:23], null offen offset:16     ; c406007c 40802818 00001003
	buffer_store_b8 v27, v3, s[20:23], null offen offset:32     ; c406007c 4080281b 00002003
	buffer_store_b8 v30, v3, s[20:23], null offen offset:48     ; c406007c 4080281e 00003003
	buffer_store_b8 v33, v3, s[20:23], null offen offset:64     ; c406007c 40802821 00004003
	buffer_store_b8 v36, v3, s[20:23], null offen offset:80     ; c406007c 40802824 00005003
	buffer_store_b8 v39, v3, s[20:23], null offen offset:96     ; c406007c 40802827 00006003
	buffer_store_b8 v42, v3, s[20:23], null offen offset:112    ; c406007c 4080282a 00007003
BB7:
	s_cmp_lt_u32 s11, s4                                        ; bf0a040b
	s_cbranch_scc0 BB10                                         ; bfa1017c
BB8:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[8:11], s[6:7], 0x10                           ; f4004203 f8000010
	v_and_b32_e32 v3, 16, v0                                    ; 36060090
	s_lshr_b32 s1, s5, 4                                        ; 85018405
	v_cvt_f16_f32_e32 v5, v48                                   ; 7e0a1530
	v_cvt_f16_f32_e32 v10, v49                                  ; 7e141531
	v_cvt_f16_f32_e32 v13, v50                                  ; 7e1a1532
	v_cvt_f16_f32_e32 v16, v51                                  ; 7e201533
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s12, s12, s1                                      ; 960c010c
	v_cvt_f16_f32_e32 v19, v52                                  ; 7e261534
	v_lshl_or_b32 v3, v3, 3, v9                                 ; d6560003 04250703
	v_maxmin_num_f16 v5, 0xdf00, v5, neg(0xdf00)                ; d66b0005 83fe0aff 0000df00
	v_cvt_f16_f32_e32 v22, v53                                  ; 7e2c1535
	v_maxmin_num_f16 v10, 0xdf00, v10, neg(0xdf00)              ; d66b000a 83fe14ff 0000df00
	v_maxmin_num_f16 v13, 0xdf00, v13, neg(0xdf00)              ; d66b000d 83fe1aff 0000df00
	v_maxmin_num_f16 v16, 0xdf00, v16, neg(0xdf00)              ; d66b0010 83fe20ff 0000df00
	v_cvt_f16_f32_e32 v25, v54                                  ; 7e321536
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
	v_cvt_f32_f16_e32 v7, v5                                    ; 7e0e1705
	v_maxmin_num_f16 v22, 0xdf00, v22, neg(0xdf00)              ; d66b0016 83fe2cff 0000df00
	v_cvt_f16_f32_e32 v28, v55                                  ; 7e381537
	v_cvt_f32_f16_e32 v11, v10                                  ; 7e16170a
	v_cvt_f32_f16_e32 v14, v13                                  ; 7e1c170d
	v_cvt_f32_f16_e32 v17, v16                                  ; 7e221710
	v_maxmin_num_f16 v25, 0xdf00, v25, neg(0xdf00)              ; d66b0019 83fe32ff 0000df00
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v31, s12, v2, 8                              ; d647001f 0222040c
	v_cvt_f32_f16_e32 v20, v19                                  ; 7e281713
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v0, v7, v128, vcc_lo                      ; 02010107
	v_cvt_f32_f16_e32 v23, v22                                  ; 7e2e1716
	v_maxmin_num_f16 v28, 0xdf00, v28, neg(0xdf00)              ; d66b001c 83fe38ff 0000df00
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
	v_cvt_f32_f16_e32 v26, v25                                  ; 7e341719
	v_add3_u32 v31, v3, s2, v31                                 ; d655001f 047c0503
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v0, v20, v128, vcc_lo                     ; 02010114
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v0, v23, v128, vcc_lo                     ; 02010117
	v_cvt_f32_f16_e32 v29, v28                                  ; 7e3a171c
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v0, v29, v128, vcc_lo                     ; 0201011d
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v8, v31, s[8:11], null offen                ; c406007c 40801008 0000001f
	buffer_store_b8 v12, v31, s[8:11], null offen offset:16     ; c406007c 4080100c 0000101f
	buffer_store_b8 v15, v31, s[8:11], null offen offset:32     ; c406007c 4080100f 0000201f
	buffer_store_b8 v18, v31, s[8:11], null offen offset:48     ; c406007c 40801012 0000301f
	buffer_store_b8 v21, v31, s[8:11], null offen offset:64     ; c406007c 40801015 0000401f
	buffer_store_b8 v24, v31, s[8:11], null offen offset:80     ; c406007c 40801018 0000501f
	buffer_store_b8 v27, v31, s[8:11], null offen offset:96     ; c406007c 4080101b 0000601f
	buffer_store_b8 v30, v31, s[8:11], null offen offset:112    ; c406007c 4080101e 0000701f
	v_cvt_f16_f32_e32 v32, v56                                  ; 7e401538
	v_cvt_f16_f32_e32 v35, v57                                  ; 7e461539
	v_cvt_f16_f32_e32 v38, v58                                  ; 7e4c153a
	v_cvt_f16_f32_e32 v41, v59                                  ; 7e52153b
	v_cvt_f16_f32_e32 v44, v60                                  ; 7e58153c
	v_cvt_f16_f32_e32 v47, v61                                  ; 7e5e153d
	v_maxmin_num_f16 v32, 0xdf00, v32, neg(0xdf00)              ; d66b0020 83fe40ff 0000df00
	v_maxmin_num_f16 v35, 0xdf00, v35, neg(0xdf00)              ; d66b0023 83fe46ff 0000df00
	v_maxmin_num_f16 v38, 0xdf00, v38, neg(0xdf00)              ; d66b0026 83fe4cff 0000df00
	v_cvt_f16_f32_e32 v50, v62                                  ; 7e64153e
	v_maxmin_num_f16 v41, 0xdf00, v41, neg(0xdf00)              ; d66b0029 83fe52ff 0000df00
	v_maxmin_num_f16 v44, 0xdf00, v44, neg(0xdf00)              ; d66b002c 83fe58ff 0000df00
	v_maxmin_num_f16 v47, 0xdf00, v47, neg(0xdf00)              ; d66b002f 83fe5eff 0000df00
	v_cvt_f32_f16_e32 v33, v32                                  ; 7e421720
	v_cvt_f32_f16_e32 v36, v35                                  ; 7e481723
	v_cvt_f16_f32_e32 v53, v63                                  ; 7e6a153f
	v_cvt_f32_f16_e32 v39, v38                                  ; 7e4e1726
	v_maxmin_num_f16 v50, 0xdf00, v50, neg(0xdf00)              ; d66b0032 83fe64ff 0000df00
	v_cvt_f32_f16_e32 v42, v41                                  ; 7e541729
	v_cvt_f32_f16_e32 v45, v44                                  ; 7e5a172c
	v_add_lshl_u32 v56, s12, v4, 8                              ; d6470038 0222080c
	v_cvt_f32_f16_e32 v48, v47                                  ; 7e60172f
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v0, v33, v128, vcc_lo                     ; 02010121
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
	v_maxmin_num_f16 v53, 0xdf00, v53, neg(0xdf00)              ; d66b0035 83fe6aff 0000df00
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v0, v39, v128, vcc_lo                     ; 02010127
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v0, v42, v128, vcc_lo                     ; 0201012a
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v0, v45, v128, vcc_lo                     ; 0201012d
	v_add3_u32 v56, v3, s2, v56                                 ; d6550038 04e00503
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
	v_cvt_f32_f16_e32 v54, v53                                  ; 7e6c1735
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v0, v54, v128, vcc_lo                     ; 02010136
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v34, v56, s[8:11], null offen               ; c406007c 40801022 00000038
	buffer_store_b8 v37, v56, s[8:11], null offen offset:16     ; c406007c 40801025 00001038
	buffer_store_b8 v40, v56, s[8:11], null offen offset:32     ; c406007c 40801028 00002038
	buffer_store_b8 v43, v56, s[8:11], null offen offset:48     ; c406007c 4080102b 00003038
	buffer_store_b8 v46, v56, s[8:11], null offen offset:64     ; c406007c 4080102e 00004038
	buffer_store_b8 v49, v56, s[8:11], null offen offset:80     ; c406007c 40801031 00005038
	buffer_store_b8 v52, v56, s[8:11], null offen offset:96     ; c406007c 40801034 00006038
	buffer_store_b8 v55, v56, s[8:11], null offen offset:112    ; c406007c 40801037 00007038
	v_cvt_f16_f32_e32 v57, v64                                  ; 7e721540
	v_cvt_f16_f32_e32 v60, v65                                  ; 7e781541
	v_cvt_f16_f32_e32 v63, v66                                  ; 7e7e1542
	v_cvt_f16_f32_e32 v66, v67                                  ; 7e841543
(invalid instruction)                                        ; d58a0091
	v_cndmask_b32_e32 v0, v68, v128, vcc_lo                     ; 02010144
(invalid instruction)                                        ; d58a0094
	v_cndmask_b32_e32 v0, v69, v128, vcc_lo                     ; 02010145
	v_maxmin_num_f16 v57, 0xdf00, v57, neg(0xdf00)              ; d66b0039 83fe72ff 0000df00
	v_maxmin_num_f16 v60, 0xdf00, v60, neg(0xdf00)              ; d66b003c 83fe78ff 0000df00
	v_maxmin_num_f16 v63, 0xdf00, v63, neg(0xdf00)              ; d66b003f 83fe7eff 0000df00
(invalid instruction)                                        ; d58a0097
	v_cndmask_b32_e32 v0, v70, v128, vcc_lo                     ; 02010146
	v_maxmin_num_f16 v66, 0xdf00, v66, neg(0xdf00)              ; d66b0042 83fe84ff 0000df00
	v_maxmin_num_f16 v145, 0xdf00, v145, neg(0xdf00)            ; d66b0091 83ff22ff 0000df00
	v_maxmin_num_f16 v148, 0xdf00, v148, neg(0xdf00)            ; d66b0094 83ff28ff 0000df00
	v_cvt_f32_f16_e32 v58, v57                                  ; 7e741739
(invalid instruction)                                        ; d58a009a
	v_cndmask_b32_e32 v0, v71, v128, vcc_lo                     ; 02010147
	v_cvt_f32_f16_e32 v61, v60                                  ; 7e7a173c
	v_cvt_f32_f16_e32 v64, v63                                  ; 7e80173f
	v_maxmin_num_f16 v151, 0xdf00, v151, neg(0xdf00)            ; d66b0097 83ff2eff 0000df00
	v_cvt_f32_f16_e32 v67, v66                                  ; 7e861742
	v_add_lshl_u32 v157, s12, v6, 8                             ; d647009d 02220c0c
(invalid instruction)                                        ; d58b0092
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                    ; 02010191
(invalid instruction)                                        ; d58b0095
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                    ; 02010194
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v0, v58, v128, vcc_lo                     ; 0201013a
	v_maxmin_num_f16 v154, 0xdf00, v154, neg(0xdf00)            ; d66b009a 83ff34ff 0000df00
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v0, v61, v128, vcc_lo                     ; 0201013d
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v0, v64, v128, vcc_lo                     ; 02010140
(invalid instruction)                                        ; d58b0098
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                    ; 02010197
(invalid instruction)                                        ; d7690090
	v_cndmask_b32_e32 v0, v67, v128, vcc_lo                     ; 02010143
	v_add3_u32 v157, v3, s2, v157                               ; d655009d 06740503
(invalid instruction)                                        ; d7690093
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                    ; 02010192
(invalid instruction)                                        ; d7690096
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                    ; 02010195
(invalid instruction)                                        ; d58b009b
	v_cndmask_b32_e32 v0, v154, v128, vcc_lo                    ; 0201019a
(invalid instruction)                                        ; d7690099
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                    ; 02010198
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769009c
	v_cndmask_b32_e32 v0, v155, v128, vcc_lo                    ; 0201019b
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v59, v157, s[8:11], null offen              ; c406007c 4080103b 0000009d
	buffer_store_b8 v62, v157, s[8:11], null offen offset:16    ; c406007c 4080103e 0000109d
	buffer_store_b8 v65, v157, s[8:11], null offen offset:32    ; c406007c 40801041 0000209d
	buffer_store_b8 v144, v157, s[8:11], null offen offset:48   ; c406007c 40801090 0000309d
	buffer_store_b8 v147, v157, s[8:11], null offen offset:64   ; c406007c 40801093 0000409d
	buffer_store_b8 v150, v157, s[8:11], null offen offset:80   ; c406007c 40801096 0000509d
	buffer_store_b8 v153, v157, s[8:11], null offen offset:96   ; c406007c 40801099 0000609d
	buffer_store_b8 v156, v157, s[8:11], null offen offset:112  ; c406007c 4080109c 0000709d
(invalid instruction)                                        ; d58a009e
	v_cndmask_b32_e32 v0, v72, v128, vcc_lo                     ; 02010148
(invalid instruction)                                        ; d58a00a1
	v_cndmask_b32_e32 v0, v73, v128, vcc_lo                     ; 02010149
(invalid instruction)                                        ; d58a00a4
	v_cndmask_b32_e32 v0, v74, v128, vcc_lo                     ; 0201014a
(invalid instruction)                                        ; d58a00a7
	v_cndmask_b32_e32 v0, v75, v128, vcc_lo                     ; 0201014b
(invalid instruction)                                        ; d58a00aa
	v_cndmask_b32_e32 v0, v76, v128, vcc_lo                     ; 0201014c
(invalid instruction)                                        ; d58a00ad
	v_cndmask_b32_e32 v0, v77, v128, vcc_lo                     ; 0201014d
	v_maxmin_num_f16 v158, 0xdf00, v158, neg(0xdf00)            ; d66b009e 83ff3cff 0000df00
	v_maxmin_num_f16 v161, 0xdf00, v161, neg(0xdf00)            ; d66b00a1 83ff42ff 0000df00
	v_maxmin_num_f16 v164, 0xdf00, v164, neg(0xdf00)            ; d66b00a4 83ff48ff 0000df00
(invalid instruction)                                        ; d58a00b0
	v_cndmask_b32_e32 v0, v78, v128, vcc_lo                     ; 0201014e
	v_maxmin_num_f16 v167, 0xdf00, v167, neg(0xdf00)            ; d66b00a7 83ff4eff 0000df00
	v_maxmin_num_f16 v170, 0xdf00, v170, neg(0xdf00)            ; d66b00aa 83ff54ff 0000df00
	v_maxmin_num_f16 v173, 0xdf00, v173, neg(0xdf00)            ; d66b00ad 83ff5aff 0000df00
(invalid instruction)                                        ; d58b009f
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                    ; 0201019e
(invalid instruction)                                        ; d58b00a2
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
(invalid instruction)                                        ; d58a00b3
	v_cndmask_b32_e32 v0, v79, v128, vcc_lo                     ; 0201014f
(invalid instruction)                                        ; d58b00a5
	v_cndmask_b32_e32 v0, v164, v128, vcc_lo                    ; 020101a4
	v_maxmin_num_f16 v176, 0xdf00, v176, neg(0xdf00)            ; d66b00b0 83ff60ff 0000df00
(invalid instruction)                                        ; d58b00a8
	v_cndmask_b32_e32 v0, v167, v128, vcc_lo                    ; 020101a7
(invalid instruction)                                        ; d58b00ab
	v_cndmask_b32_e32 v0, v170, v128, vcc_lo                    ; 020101aa
	v_add_lshl_u32 v182, s12, v1, 8                             ; d64700b6 0222020c
(invalid instruction)                                        ; d58b00ae
	v_cndmask_b32_e32 v0, v173, v128, vcc_lo                    ; 020101ad
(invalid instruction)                                        ; d76900a0
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                    ; 0201019f
(invalid instruction)                                        ; d76900a3
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
	v_maxmin_num_f16 v179, 0xdf00, v179, neg(0xdf00)            ; d66b00b3 83ff66ff 0000df00
(invalid instruction)                                        ; d76900a6
	v_cndmask_b32_e32 v0, v165, v128, vcc_lo                    ; 020101a5
(invalid instruction)                                        ; d58b00b1
	v_cndmask_b32_e32 v0, v176, v128, vcc_lo                    ; 020101b0
(invalid instruction)                                        ; d76900a9
	v_cndmask_b32_e32 v0, v168, v128, vcc_lo                    ; 020101a8
(invalid instruction)                                        ; d76900ac
	v_cndmask_b32_e32 v0, v171, v128, vcc_lo                    ; 020101ab
	v_add3_u32 v3, v3, s2, v182                                 ; d6550003 06d80503
(invalid instruction)                                        ; d76900af
	v_cndmask_b32_e32 v0, v174, v128, vcc_lo                    ; 020101ae
(invalid instruction)                                        ; d58b00b4
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                    ; 020101b3
(invalid instruction)                                        ; d76900b2
	v_cndmask_b32_e32 v0, v177, v128, vcc_lo                    ; 020101b1
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d76900b5
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                    ; 020101b4
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v160, v3, s[8:11], null offen               ; c406007c 408010a0 00000003
	buffer_store_b8 v163, v3, s[8:11], null offen offset:16     ; c406007c 408010a3 00001003
	buffer_store_b8 v166, v3, s[8:11], null offen offset:32     ; c406007c 408010a6 00002003
	buffer_store_b8 v169, v3, s[8:11], null offen offset:48     ; c406007c 408010a9 00003003
	buffer_store_b8 v172, v3, s[8:11], null offen offset:64     ; c406007c 408010ac 00004003
	buffer_store_b8 v175, v3, s[8:11], null offen offset:80     ; c406007c 408010af 00005003
	buffer_store_b8 v178, v3, s[8:11], null offen offset:96     ; c406007c 408010b2 00006003
	buffer_store_b8 v181, v3, s[8:11], null offen offset:112    ; c406007c 408010b5 00007003
BB10:
	s_cmp_lt_u32 s14, s4                                        ; bf0a040e
	s_cbranch_scc0 BB13                                         ; bfa10163
BB11:
	s_mov_b32 s6, s0                                            ; be860000
	s_movk_i32 s7, 0x8000                                       ; b0078000
	s_load_b128 s[8:11], s[6:7], 0x10                           ; f4004203 f8000010
	v_and_b32_e32 v3, 16, v0                                    ; 36060090
	s_lshr_b32 s1, s5, 4                                        ; 85018405
	v_cvt_f16_f32_e32 v5, v80                                   ; 7e0a1550
	v_cvt_f16_f32_e32 v10, v81                                  ; 7e141551
	v_cvt_f16_f32_e32 v13, v82                                  ; 7e1a1552
	v_cvt_f16_f32_e32 v16, v83                                  ; 7e201553
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s15, s15, s1                                      ; 960f010f
	v_cvt_f16_f32_e32 v19, v84                                  ; 7e261554
	v_lshl_or_b32 v3, v3, 3, v9                                 ; d6560003 04250703
	v_maxmin_num_f16 v5, 0xdf00, v5, neg(0xdf00)                ; d66b0005 83fe0aff 0000df00
	v_cvt_f16_f32_e32 v22, v85                                  ; 7e2c1555
	v_maxmin_num_f16 v10, 0xdf00, v10, neg(0xdf00)              ; d66b000a 83fe14ff 0000df00
	v_maxmin_num_f16 v13, 0xdf00, v13, neg(0xdf00)              ; d66b000d 83fe1aff 0000df00
	v_maxmin_num_f16 v16, 0xdf00, v16, neg(0xdf00)              ; d66b0010 83fe20ff 0000df00
	v_cvt_f16_f32_e32 v25, v86                                  ; 7e321556
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
	v_cvt_f32_f16_e32 v7, v5                                    ; 7e0e1705
	v_maxmin_num_f16 v22, 0xdf00, v22, neg(0xdf00)              ; d66b0016 83fe2cff 0000df00
	v_cvt_f16_f32_e32 v28, v87                                  ; 7e381557
	v_cvt_f32_f16_e32 v11, v10                                  ; 7e16170a
	v_cvt_f32_f16_e32 v14, v13                                  ; 7e1c170d
	v_cvt_f32_f16_e32 v17, v16                                  ; 7e221710
	v_maxmin_num_f16 v25, 0xdf00, v25, neg(0xdf00)              ; d66b0019 83fe32ff 0000df00
	v_add_lshl_u32 v31, s15, v2, 8                              ; d647001f 0222040f
	v_cvt_f32_f16_e32 v20, v19                                  ; 7e281713
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v0, v7, v128, vcc_lo                      ; 02010107
	v_cvt_f32_f16_e32 v23, v22                                  ; 7e2e1716
	v_maxmin_num_f16 v28, 0xdf00, v28, neg(0xdf00)              ; d66b001c 83fe38ff 0000df00
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
	v_cvt_f32_f16_e32 v26, v25                                  ; 7e341719
	v_add3_u32 v31, v3, s2, v31                                 ; d655001f 047c0503
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v0, v20, v128, vcc_lo                     ; 02010114
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v0, v23, v128, vcc_lo                     ; 02010117
	v_cvt_f32_f16_e32 v29, v28                                  ; 7e3a171c
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v0, v29, v128, vcc_lo                     ; 0201011d
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v8, v31, s[8:11], null offen                ; c406007c 40801008 0000001f
	buffer_store_b8 v12, v31, s[8:11], null offen offset:16     ; c406007c 4080100c 0000101f
	buffer_store_b8 v15, v31, s[8:11], null offen offset:32     ; c406007c 4080100f 0000201f
	buffer_store_b8 v18, v31, s[8:11], null offen offset:48     ; c406007c 40801012 0000301f
	buffer_store_b8 v21, v31, s[8:11], null offen offset:64     ; c406007c 40801015 0000401f
	buffer_store_b8 v24, v31, s[8:11], null offen offset:80     ; c406007c 40801018 0000501f
	buffer_store_b8 v27, v31, s[8:11], null offen offset:96     ; c406007c 4080101b 0000601f
	buffer_store_b8 v30, v31, s[8:11], null offen offset:112    ; c406007c 4080101e 0000701f
	v_cvt_f16_f32_e32 v32, v88                                  ; 7e401558
	v_cvt_f16_f32_e32 v35, v89                                  ; 7e461559
	v_cvt_f16_f32_e32 v38, v90                                  ; 7e4c155a
	v_cvt_f16_f32_e32 v41, v91                                  ; 7e52155b
	v_cvt_f16_f32_e32 v44, v92                                  ; 7e58155c
	v_cvt_f16_f32_e32 v47, v93                                  ; 7e5e155d
	v_maxmin_num_f16 v32, 0xdf00, v32, neg(0xdf00)              ; d66b0020 83fe40ff 0000df00
	v_maxmin_num_f16 v35, 0xdf00, v35, neg(0xdf00)              ; d66b0023 83fe46ff 0000df00
	v_maxmin_num_f16 v38, 0xdf00, v38, neg(0xdf00)              ; d66b0026 83fe4cff 0000df00
	v_cvt_f16_f32_e32 v50, v94                                  ; 7e64155e
	v_maxmin_num_f16 v41, 0xdf00, v41, neg(0xdf00)              ; d66b0029 83fe52ff 0000df00
	v_maxmin_num_f16 v44, 0xdf00, v44, neg(0xdf00)              ; d66b002c 83fe58ff 0000df00
	v_maxmin_num_f16 v47, 0xdf00, v47, neg(0xdf00)              ; d66b002f 83fe5eff 0000df00
	v_cvt_f32_f16_e32 v33, v32                                  ; 7e421720
	v_cvt_f32_f16_e32 v36, v35                                  ; 7e481723
	v_cvt_f16_f32_e32 v53, v95                                  ; 7e6a155f
	v_cvt_f32_f16_e32 v39, v38                                  ; 7e4e1726
	v_maxmin_num_f16 v50, 0xdf00, v50, neg(0xdf00)              ; d66b0032 83fe64ff 0000df00
	v_cvt_f32_f16_e32 v42, v41                                  ; 7e541729
	v_cvt_f32_f16_e32 v45, v44                                  ; 7e5a172c
	v_add_lshl_u32 v56, s15, v4, 8                              ; d6470038 0222080f
	v_cvt_f32_f16_e32 v48, v47                                  ; 7e60172f
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v0, v33, v128, vcc_lo                     ; 02010121
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
	v_maxmin_num_f16 v53, 0xdf00, v53, neg(0xdf00)              ; d66b0035 83fe6aff 0000df00
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v0, v39, v128, vcc_lo                     ; 02010127
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v0, v42, v128, vcc_lo                     ; 0201012a
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v0, v45, v128, vcc_lo                     ; 0201012d
	v_add3_u32 v56, v3, s2, v56                                 ; d6550038 04e00503
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
	v_cvt_f32_f16_e32 v54, v53                                  ; 7e6c1735
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v0, v54, v128, vcc_lo                     ; 02010136
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v34, v56, s[8:11], null offen               ; c406007c 40801022 00000038
	buffer_store_b8 v37, v56, s[8:11], null offen offset:16     ; c406007c 40801025 00001038
	buffer_store_b8 v40, v56, s[8:11], null offen offset:32     ; c406007c 40801028 00002038
	buffer_store_b8 v43, v56, s[8:11], null offen offset:48     ; c406007c 4080102b 00003038
	buffer_store_b8 v46, v56, s[8:11], null offen offset:64     ; c406007c 4080102e 00004038
	buffer_store_b8 v49, v56, s[8:11], null offen offset:80     ; c406007c 40801031 00005038
	buffer_store_b8 v52, v56, s[8:11], null offen offset:96     ; c406007c 40801034 00006038
	buffer_store_b8 v55, v56, s[8:11], null offen offset:112    ; c406007c 40801037 00007038
	v_cvt_f16_f32_e32 v57, v96                                  ; 7e721560
	v_cvt_f16_f32_e32 v60, v97                                  ; 7e781561
	v_cvt_f16_f32_e32 v63, v98                                  ; 7e7e1562
	v_cvt_f16_f32_e32 v66, v99                                  ; 7e841563
	v_cvt_f16_f32_e32 v69, v100                                 ; 7e8a1564
	v_cvt_f16_f32_e32 v72, v101                                 ; 7e901565
	v_maxmin_num_f16 v57, 0xdf00, v57, neg(0xdf00)              ; d66b0039 83fe72ff 0000df00
	v_maxmin_num_f16 v60, 0xdf00, v60, neg(0xdf00)              ; d66b003c 83fe78ff 0000df00
	v_maxmin_num_f16 v63, 0xdf00, v63, neg(0xdf00)              ; d66b003f 83fe7eff 0000df00
	v_cvt_f16_f32_e32 v75, v102                                 ; 7e961566
	v_maxmin_num_f16 v66, 0xdf00, v66, neg(0xdf00)              ; d66b0042 83fe84ff 0000df00
	v_maxmin_num_f16 v69, 0xdf00, v69, neg(0xdf00)              ; d66b0045 83fe8aff 0000df00
	v_maxmin_num_f16 v72, 0xdf00, v72, neg(0xdf00)              ; d66b0048 83fe90ff 0000df00
	v_cvt_f32_f16_e32 v58, v57                                  ; 7e741739
	v_cvt_f16_f32_e32 v78, v103                                 ; 7e9c1567
	v_cvt_f32_f16_e32 v61, v60                                  ; 7e7a173c
	v_cvt_f32_f16_e32 v64, v63                                  ; 7e80173f
	v_maxmin_num_f16 v75, 0xdf00, v75, neg(0xdf00)              ; d66b004b 83fe96ff 0000df00
	v_cvt_f32_f16_e32 v67, v66                                  ; 7e861742
	v_add_lshl_u32 v81, s15, v6, 8                              ; d6470051 02220c0f
	v_cvt_f32_f16_e32 v70, v69                                  ; 7e8c1745
	v_cvt_f32_f16_e32 v73, v72                                  ; 7e921748
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v0, v58, v128, vcc_lo                     ; 0201013a
	v_maxmin_num_f16 v78, 0xdf00, v78, neg(0xdf00)              ; d66b004e 83fe9cff 0000df00
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v0, v61, v128, vcc_lo                     ; 0201013d
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v0, v64, v128, vcc_lo                     ; 02010140
	v_cvt_f32_f16_e32 v76, v75                                  ; 7e98174b
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v0, v67, v128, vcc_lo                     ; 02010143
	v_add3_u32 v81, v3, s2, v81                                 ; d6550051 05440503
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v0, v70, v128, vcc_lo                     ; 02010146
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v0, v73, v128, vcc_lo                     ; 02010149
	v_cvt_f32_f16_e32 v79, v78                                  ; 7e9e174e
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v0, v76, v128, vcc_lo                     ; 0201014c
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v0, v79, v128, vcc_lo                     ; 0201014f
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v59, v81, s[8:11], null offen               ; c406007c 4080103b 00000051
	buffer_store_b8 v62, v81, s[8:11], null offen offset:16     ; c406007c 4080103e 00001051
	buffer_store_b8 v65, v81, s[8:11], null offen offset:32     ; c406007c 40801041 00002051
	buffer_store_b8 v68, v81, s[8:11], null offen offset:48     ; c406007c 40801044 00003051
	buffer_store_b8 v71, v81, s[8:11], null offen offset:64     ; c406007c 40801047 00004051
	buffer_store_b8 v74, v81, s[8:11], null offen offset:80     ; c406007c 4080104a 00005051
	buffer_store_b8 v77, v81, s[8:11], null offen offset:96     ; c406007c 4080104d 00006051
	buffer_store_b8 v80, v81, s[8:11], null offen offset:112    ; c406007c 40801050 00007051
	v_cvt_f16_f32_e32 v82, v104                                 ; 7ea41568
	v_cvt_f16_f32_e32 v85, v105                                 ; 7eaa1569
	v_cvt_f16_f32_e32 v88, v106                                 ; 7eb0156a
	v_cvt_f16_f32_e32 v91, v107                                 ; 7eb6156b
	v_cvt_f16_f32_e32 v94, v108                                 ; 7ebc156c
	v_cvt_f16_f32_e32 v97, v109                                 ; 7ec2156d
	v_maxmin_num_f16 v82, 0xdf00, v82, neg(0xdf00)              ; d66b0052 83fea4ff 0000df00
	v_maxmin_num_f16 v85, 0xdf00, v85, neg(0xdf00)              ; d66b0055 83feaaff 0000df00
	v_maxmin_num_f16 v88, 0xdf00, v88, neg(0xdf00)              ; d66b0058 83feb0ff 0000df00
	v_cvt_f16_f32_e32 v100, v110                                ; 7ec8156e
	v_maxmin_num_f16 v91, 0xdf00, v91, neg(0xdf00)              ; d66b005b 83feb6ff 0000df00
	v_maxmin_num_f16 v94, 0xdf00, v94, neg(0xdf00)              ; d66b005e 83febcff 0000df00
	v_maxmin_num_f16 v97, 0xdf00, v97, neg(0xdf00)              ; d66b0061 83fec2ff 0000df00
	v_cvt_f32_f16_e32 v83, v82                                  ; 7ea61752
	v_cvt_f32_f16_e32 v86, v85                                  ; 7eac1755
	v_cvt_f16_f32_e32 v103, v111                                ; 7ece156f
	v_cvt_f32_f16_e32 v89, v88                                  ; 7eb21758
	v_maxmin_num_f16 v100, 0xdf00, v100, neg(0xdf00)            ; d66b0064 83fec8ff 0000df00
	v_cvt_f32_f16_e32 v92, v91                                  ; 7eb8175b
	v_cvt_f32_f16_e32 v95, v94                                  ; 7ebe175e
	v_add_lshl_u32 v106, s15, v1, 8                             ; d647006a 0222020f
	v_cvt_f32_f16_e32 v98, v97                                  ; 7ec41761
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v0, v83, v128, vcc_lo                     ; 02010153
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v0, v86, v128, vcc_lo                     ; 02010156
	v_maxmin_num_f16 v103, 0xdf00, v103, neg(0xdf00)            ; d66b0067 83feceff 0000df00
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v0, v89, v128, vcc_lo                     ; 02010159
	v_cvt_f32_f16_e32 v101, v100                                ; 7eca1764
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v0, v92, v128, vcc_lo                     ; 0201015c
(invalid instruction)                                        ; d7690060
	v_cndmask_b32_e32 v0, v95, v128, vcc_lo                     ; 0201015f
	v_add3_u32 v3, v3, s2, v106                                 ; d6550003 05a80503
(invalid instruction)                                        ; d7690063
	v_cndmask_b32_e32 v0, v98, v128, vcc_lo                     ; 02010162
	v_cvt_f32_f16_e32 v104, v103                                ; 7ed01767
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v0, v101, v128, vcc_lo                    ; 02010165
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v0, v104, v128, vcc_lo                    ; 02010168
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v84, v3, s[8:11], null offen                ; c406007c 40801054 00000003
	buffer_store_b8 v87, v3, s[8:11], null offen offset:16      ; c406007c 40801057 00001003
	buffer_store_b8 v90, v3, s[8:11], null offen offset:32      ; c406007c 4080105a 00002003
	buffer_store_b8 v93, v3, s[8:11], null offen offset:48      ; c406007c 4080105d 00003003
	buffer_store_b8 v96, v3, s[8:11], null offen offset:64      ; c406007c 40801060 00004003
	buffer_store_b8 v99, v3, s[8:11], null offen offset:80      ; c406007c 40801063 00005003
	buffer_store_b8 v102, v3, s[8:11], null offen offset:96     ; c406007c 40801066 00006003
	buffer_store_b8 v105, v3, s[8:11], null offen offset:112    ; c406007c 40801069 00007003
BB13:
	s_cmp_lt_u32 s17, s4                                        ; bf0a0411
	s_cbranch_scc0 BB16                                         ; bfa10162
BB14:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[8:11], s[0:1], 0x10                           ; f4004200 f8000010
	v_and_b32_e32 v0, 16, v0                                    ; 36000090
	s_lshr_b32 s5, s5, 4                                        ; 85058405
	v_cvt_f16_f32_e32 v3, v112                                  ; 7e061570
	v_cvt_f16_f32_e32 v8, v113                                  ; 7e101571
	v_cvt_f16_f32_e32 v11, v114                                 ; 7e161572
	v_cvt_f16_f32_e32 v14, v115                                 ; 7e1c1573
	s_mul_i32 s18, s18, s5                                      ; 96120512
	v_cvt_f16_f32_e32 v17, v116                                 ; 7e221574
	v_lshl_or_b32 v0, v0, 3, v9                                 ; d6560000 04250700
	v_maxmin_num_f16 v3, 0xdf00, v3, neg(0xdf00)                ; d66b0003 83fe06ff 0000df00
	v_cvt_f16_f32_e32 v20, v117                                 ; 7e281575
	v_maxmin_num_f16 v8, 0xdf00, v8, neg(0xdf00)                ; d66b0008 83fe10ff 0000df00
	v_maxmin_num_f16 v11, 0xdf00, v11, neg(0xdf00)              ; d66b000b 83fe16ff 0000df00
	v_maxmin_num_f16 v14, 0xdf00, v14, neg(0xdf00)              ; d66b000e 83fe1cff 0000df00
	v_maxmin_num_f16 v17, 0xdf00, v17, neg(0xdf00)              ; d66b0011 83fe22ff 0000df00
	v_cvt_f16_f32_e32 v23, v118                                 ; 7e2e1576
	v_cvt_f32_f16_e32 v5, v3                                    ; 7e0a1703
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
	v_cvt_f16_f32_e32 v26, v119                                 ; 7e341577
	v_cvt_f32_f16_e32 v9, v8                                    ; 7e121708
	v_cvt_f32_f16_e32 v12, v11                                  ; 7e18170b
	v_cvt_f32_f16_e32 v15, v14                                  ; 7e1e170e
	v_cvt_f32_f16_e32 v18, v17                                  ; 7e241711
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v2, s18, v2, 8                               ; d6470002 02220412
	v_maxmin_num_f16 v23, 0xdf00, v23, neg(0xdf00)              ; d66b0017 83fe2eff 0000df00
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v0, v5, v128, vcc_lo                      ; 02010105
	v_cvt_f32_f16_e32 v21, v20                                  ; 7e2a1714
	v_maxmin_num_f16 v26, 0xdf00, v26, neg(0xdf00)              ; d66b001a 83fe34ff 0000df00
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v0, v9, v128, vcc_lo                      ; 02010109
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v0, v12, v128, vcc_lo                     ; 0201010c
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v0, v15, v128, vcc_lo                     ; 0201010f
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v0, v18, v128, vcc_lo                     ; 02010112
	v_add3_u32 v2, v0, s2, v2                                   ; d6550002 04080500
	v_cvt_f32_f16_e32 v24, v23                                  ; 7e301717
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
	v_cvt_f32_f16_e32 v27, v26                                  ; 7e36171a
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v0, v24, v128, vcc_lo                     ; 02010118
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v0, v27, v128, vcc_lo                     ; 0201011b
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v7, v2, s[8:11], null offen                 ; c406007c 40801007 00000002
	buffer_store_b8 v10, v2, s[8:11], null offen offset:16      ; c406007c 4080100a 00001002
	buffer_store_b8 v13, v2, s[8:11], null offen offset:32      ; c406007c 4080100d 00002002
	buffer_store_b8 v16, v2, s[8:11], null offen offset:48      ; c406007c 40801010 00003002
	buffer_store_b8 v19, v2, s[8:11], null offen offset:64      ; c406007c 40801013 00004002
	buffer_store_b8 v22, v2, s[8:11], null offen offset:80      ; c406007c 40801016 00005002
	buffer_store_b8 v25, v2, s[8:11], null offen offset:96      ; c406007c 40801019 00006002
	buffer_store_b8 v28, v2, s[8:11], null offen offset:112     ; c406007c 4080101c 00007002
	v_cvt_f16_f32_e32 v29, v120                                 ; 7e3a1578
	v_cvt_f16_f32_e32 v32, v121                                 ; 7e401579
	v_cvt_f16_f32_e32 v35, v122                                 ; 7e46157a
	v_cvt_f16_f32_e32 v38, v123                                 ; 7e4c157b
	v_cvt_f16_f32_e32 v41, v124                                 ; 7e52157c
	v_cvt_f16_f32_e32 v44, v125                                 ; 7e58157d
	v_maxmin_num_f16 v29, 0xdf00, v29, neg(0xdf00)              ; d66b001d 83fe3aff 0000df00
	v_maxmin_num_f16 v32, 0xdf00, v32, neg(0xdf00)              ; d66b0020 83fe40ff 0000df00
	v_maxmin_num_f16 v35, 0xdf00, v35, neg(0xdf00)              ; d66b0023 83fe46ff 0000df00
	v_cvt_f16_f32_e32 v47, v126                                 ; 7e5e157e
	v_maxmin_num_f16 v38, 0xdf00, v38, neg(0xdf00)              ; d66b0026 83fe4cff 0000df00
	v_maxmin_num_f16 v41, 0xdf00, v41, neg(0xdf00)              ; d66b0029 83fe52ff 0000df00
	v_maxmin_num_f16 v44, 0xdf00, v44, neg(0xdf00)              ; d66b002c 83fe58ff 0000df00
	v_cvt_f32_f16_e32 v30, v29                                  ; 7e3c171d
	v_cvt_f16_f32_e32 v50, v127                                 ; 7e64157f
	v_cvt_f32_f16_e32 v33, v32                                  ; 7e421720
	v_cvt_f32_f16_e32 v36, v35                                  ; 7e481723
	v_maxmin_num_f16 v47, 0xdf00, v47, neg(0xdf00)              ; d66b002f 83fe5eff 0000df00
	v_cvt_f32_f16_e32 v39, v38                                  ; 7e4e1726
	v_add_lshl_u32 v4, s18, v4, 8                               ; d6470004 02220812
	v_cvt_f32_f16_e32 v42, v41                                  ; 7e541729
	v_cvt_f32_f16_e32 v45, v44                                  ; 7e5a172c
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v0, v30, v128, vcc_lo                     ; 0201011e
	v_maxmin_num_f16 v50, 0xdf00, v50, neg(0xdf00)              ; d66b0032 83fe64ff 0000df00
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v0, v33, v128, vcc_lo                     ; 02010121
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
	v_cvt_f32_f16_e32 v48, v47                                  ; 7e60172f
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v0, v39, v128, vcc_lo                     ; 02010127
	v_add3_u32 v4, v0, s2, v4                                   ; d6550004 04100500
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v0, v42, v128, vcc_lo                     ; 0201012a
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v0, v45, v128, vcc_lo                     ; 0201012d
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v31, v4, s[8:11], null offen                ; c406007c 4080101f 00000004
	buffer_store_b8 v34, v4, s[8:11], null offen offset:16      ; c406007c 40801022 00001004
	buffer_store_b8 v37, v4, s[8:11], null offen offset:32      ; c406007c 40801025 00002004
	buffer_store_b8 v40, v4, s[8:11], null offen offset:48      ; c406007c 40801028 00003004
	buffer_store_b8 v43, v4, s[8:11], null offen offset:64      ; c406007c 4080102b 00004004
	buffer_store_b8 v46, v4, s[8:11], null offen offset:80      ; c406007c 4080102e 00005004
	buffer_store_b8 v49, v4, s[8:11], null offen offset:96      ; c406007c 40801031 00006004
	buffer_store_b8 v52, v4, s[8:11], null offen offset:112     ; c406007c 40801034 00007004
	v_cvt_f16_f32_e32 v53, v128                                 ; 7e6a1580
	v_cvt_f16_f32_e32 v56, v129                                 ; 7e701581
	v_cvt_f16_f32_e32 v59, v130                                 ; 7e761582
	v_cvt_f16_f32_e32 v62, v131                                 ; 7e7c1583
	v_cvt_f16_f32_e32 v65, v132                                 ; 7e821584
	v_cvt_f16_f32_e32 v68, v133                                 ; 7e881585
	v_maxmin_num_f16 v53, 0xdf00, v53, neg(0xdf00)              ; d66b0035 83fe6aff 0000df00
	v_maxmin_num_f16 v56, 0xdf00, v56, neg(0xdf00)              ; d66b0038 83fe70ff 0000df00
	v_maxmin_num_f16 v59, 0xdf00, v59, neg(0xdf00)              ; d66b003b 83fe76ff 0000df00
	v_cvt_f16_f32_e32 v71, v134                                 ; 7e8e1586
	v_maxmin_num_f16 v62, 0xdf00, v62, neg(0xdf00)              ; d66b003e 83fe7cff 0000df00
	v_maxmin_num_f16 v65, 0xdf00, v65, neg(0xdf00)              ; d66b0041 83fe82ff 0000df00
	v_maxmin_num_f16 v68, 0xdf00, v68, neg(0xdf00)              ; d66b0044 83fe88ff 0000df00
	v_cvt_f32_f16_e32 v54, v53                                  ; 7e6c1735
	v_cvt_f16_f32_e32 v74, v135                                 ; 7e941587
	v_cvt_f32_f16_e32 v57, v56                                  ; 7e721738
	v_cvt_f32_f16_e32 v60, v59                                  ; 7e78173b
	v_maxmin_num_f16 v71, 0xdf00, v71, neg(0xdf00)              ; d66b0047 83fe8eff 0000df00
	v_cvt_f32_f16_e32 v63, v62                                  ; 7e7e173e
	v_add_lshl_u32 v6, s18, v6, 8                               ; d6470006 02220c12
	v_cvt_f32_f16_e32 v66, v65                                  ; 7e841741
	v_cvt_f32_f16_e32 v69, v68                                  ; 7e8a1744
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v0, v54, v128, vcc_lo                     ; 02010136
	v_maxmin_num_f16 v74, 0xdf00, v74, neg(0xdf00)              ; d66b004a 83fe94ff 0000df00
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                     ; 02010139
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v0, v60, v128, vcc_lo                     ; 0201013c
	v_cvt_f32_f16_e32 v72, v71                                  ; 7e901747
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v0, v63, v128, vcc_lo                     ; 0201013f
	v_add3_u32 v6, v0, s2, v6                                   ; d6550006 04180500
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v0, v66, v128, vcc_lo                     ; 02010142
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v0, v69, v128, vcc_lo                     ; 02010145
	v_cvt_f32_f16_e32 v75, v74                                  ; 7e96174a
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v0, v72, v128, vcc_lo                     ; 02010148
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v0, v75, v128, vcc_lo                     ; 0201014b
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v55, v6, s[8:11], null offen                ; c406007c 40801037 00000006
	buffer_store_b8 v58, v6, s[8:11], null offen offset:16      ; c406007c 4080103a 00001006
	buffer_store_b8 v61, v6, s[8:11], null offen offset:32      ; c406007c 4080103d 00002006
	buffer_store_b8 v64, v6, s[8:11], null offen offset:48      ; c406007c 40801040 00003006
	buffer_store_b8 v67, v6, s[8:11], null offen offset:64      ; c406007c 40801043 00004006
	buffer_store_b8 v70, v6, s[8:11], null offen offset:80      ; c406007c 40801046 00005006
	buffer_store_b8 v73, v6, s[8:11], null offen offset:96      ; c406007c 40801049 00006006
	buffer_store_b8 v76, v6, s[8:11], null offen offset:112     ; c406007c 4080104c 00007006
	v_cvt_f16_f32_e32 v77, v136                                 ; 7e9a1588
	v_cvt_f16_f32_e32 v80, v137                                 ; 7ea01589
	v_cvt_f16_f32_e32 v83, v138                                 ; 7ea6158a
	v_cvt_f16_f32_e32 v86, v139                                 ; 7eac158b
	v_cvt_f16_f32_e32 v89, v140                                 ; 7eb2158c
	v_cvt_f16_f32_e32 v92, v141                                 ; 7eb8158d
	v_maxmin_num_f16 v77, 0xdf00, v77, neg(0xdf00)              ; d66b004d 83fe9aff 0000df00
	v_maxmin_num_f16 v80, 0xdf00, v80, neg(0xdf00)              ; d66b0050 83fea0ff 0000df00
	v_maxmin_num_f16 v83, 0xdf00, v83, neg(0xdf00)              ; d66b0053 83fea6ff 0000df00
	v_maxmin_num_f16 v86, 0xdf00, v86, neg(0xdf00)              ; d66b0056 83feacff 0000df00
	v_cvt_f16_f32_e32 v95, v142                                 ; 7ebe158e
	v_maxmin_num_f16 v89, 0xdf00, v89, neg(0xdf00)              ; d66b0059 83feb2ff 0000df00
	v_maxmin_num_f16 v92, 0xdf00, v92, neg(0xdf00)              ; d66b005c 83feb8ff 0000df00
	v_cvt_f32_f16_e32 v78, v77                                  ; 7e9c174d
	v_cvt_f16_f32_e32 v98, v143                                 ; 7ec4158f
	v_cvt_f32_f16_e32 v81, v80                                  ; 7ea21750
	v_cvt_f32_f16_e32 v84, v83                                  ; 7ea81753
	v_cvt_f32_f16_e32 v87, v86                                  ; 7eae1756
	v_maxmin_num_f16 v95, 0xdf00, v95, neg(0xdf00)              ; d66b005f 83febeff 0000df00
	v_cvt_f32_f16_e32 v90, v89                                  ; 7eb41759
	v_add_lshl_u32 v1, s18, v1, 8                               ; d6470001 02220212
	v_cvt_f32_f16_e32 v93, v92                                  ; 7eba175c
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v0, v78, v128, vcc_lo                     ; 0201014e
	v_maxmin_num_f16 v98, 0xdf00, v98, neg(0xdf00)              ; d66b0062 83fec4ff 0000df00
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v0, v81, v128, vcc_lo                     ; 02010151
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v0, v84, v128, vcc_lo                     ; 02010154
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v0, v87, v128, vcc_lo                     ; 02010157
	v_cvt_f32_f16_e32 v96, v95                                  ; 7ec0175f
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v0, v90, v128, vcc_lo                     ; 0201015a
	v_add3_u32 v0, v0, s2, v1                                   ; d6550000 04040500
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v0, v93, v128, vcc_lo                     ; 0201015d
	v_cvt_f32_f16_e32 v99, v98                                  ; 7ec61762
(invalid instruction)                                        ; d7690061
	v_cndmask_b32_e32 v0, v96, v128, vcc_lo                     ; 02010160
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v0, v99, v128, vcc_lo                     ; 02010163
	s_clause 0x7                                                ; bf850007
	buffer_store_b8 v79, v0, s[8:11], null offen                ; c406007c 4080104f 00000000
	buffer_store_b8 v82, v0, s[8:11], null offen offset:16      ; c406007c 40801052 00001000
	buffer_store_b8 v85, v0, s[8:11], null offen offset:32      ; c406007c 40801055 00002000
	buffer_store_b8 v88, v0, s[8:11], null offen offset:48      ; c406007c 40801058 00003000
	buffer_store_b8 v91, v0, s[8:11], null offen offset:64      ; c406007c 4080105b 00004000
	buffer_store_b8 v94, v0, s[8:11], null offen offset:80      ; c406007c 4080105e 00005000
	buffer_store_b8 v97, v0, s[8:11], null offen offset:96      ; c406007c 40801061 00006000
	buffer_store_b8 v100, v0, s[8:11], null offen offset:112    ; c406007c 40801064 00007000
BB16:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
