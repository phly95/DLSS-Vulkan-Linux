BB0:
	s_mov_b32 s14, s1                                           ; be8e0001
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b32 s1, s[14:15], 0x54                               ; f4000047 f8000054
	v_and_b32_e32 v1, 7, v0                                     ; 36020087
	v_lshrrev_b32_e32 v2, 3, v0                                 ; 32040083
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_lshl_add_u32 v1, ttmp9, 3, v1                             ; d6460001 04050675
	v_lshl_add_u32 v3, ttmp7, 3, v2                             ; d6460003 04090673
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_eq_i32 s1, 0                                          ; bf008001
	s_cbranch_scc0 BB2                                          ; bfa10006
BB1:
	s_load_b32 s11, s[14:15], 0x34                              ; f40002c7 f8000034
	s_mov_b32 s12, src_scc                                      ; be8c00fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s11, s11, 2                                      ; 840b820b
	s_branch BB3                                                ; bfa00002
BB2:
	s_mov_b32 s11, s1                                           ; be8b0001
	s_mov_b32 s12, src_scc                                      ; be8c00fd
BB3:
	s_load_b32 s16, s[14:15], 0x58                              ; f4000407 f8000058
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_eq_i32 s16, 0                                         ; bf008010
	s_cbranch_scc0 BB5                                          ; bfa10006
BB4:
	s_load_b32 s17, s[14:15], 0x38                              ; f4000447 f8000038
	s_mov_b32 s18, src_scc                                      ; be9200fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s17, s17, 2                                      ; 84118211
	s_branch BB6                                                ; bfa00002
BB5:
	s_mov_b32 s17, s16                                          ; be910010
	s_mov_b32 s18, src_scc                                      ; be9200fd
BB6:
	s_mov_b32 s20, s1                                           ; be940001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x2                                                ; bf850002
	s_load_b32 s19, s[14:15], 0x7c                              ; f40004c7 f800007c
	s_load_b256 s[24:31], s[0:1], 0x60                          ; f4006600 f8000060
	s_load_b128 s[32:35], s[0:1], 0x90                          ; f4004800 f8000090
	s_lshl1_add_u32 s21, s11, -2                                ; 8715c20b
	v_cmp_gt_u32_e32 vcc_lo, s11, v1                            ; 7c98020b
	s_cvt_f32_u32 s11, s11                                      ; be8b650b
	s_lshl1_add_u32 s22, s17, -2                                ; 8716c211
	s_bitcmp1_b32 s13, 0                                        ; bf0d800d
	v_sub_nc_u32_e32 v4, s21, v1                                ; 4c080215
	v_sub_nc_u32_e32 v5, s22, v3                                ; 4c0a0616
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d684000b
	v_cndmask_b32_e32 v0, s11, v128, vcc_lo                     ; 0201000b
	s_mov_b32 s23, src_scc                                      ; be9700fd
	v_cndmask_b32_e32 v4, v4, v1, vcc_lo                        ; 02080304
	v_cmp_gt_u32_e32 vcc_lo, s17, v3                            ; 7c980611
	s_cvt_f32_u32 s17, s17                                      ; be916511
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d2
	v_cvt_f32_i32_e32 v4, v4                                    ; 7e080b04
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840011
	v_cndmask_b32_e32 v0, s17, v128, vcc_lo                     ; 02010011
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v5, v5, v3, vcc_lo                        ; 020a0705
	v_cvt_f32_i32_e32 v5, v5                                    ; 7e0a0b05
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_and_b32 s36, s35, -2.0                                    ; 8b24f523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a1
	v_dual_add_f32 v5, 0.5, v5 :: v_dual_add_f32 v4, 0.5, v4    ; c9080af0 050408f0
	s_cmp_eq_i32 s36, -2.0                                      ; bf00f524
	s_and_b32 s23, s23, src_scc                                 ; 8b17fd17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c1
	v_dual_mul_f32 v5, s17, v5 :: v_dual_mul_f32 v4, s11, v4    ; c8c60a11 0504080b
	s_mov_b32 s37, src_scc                                      ; bea500fd
	s_and_b32 s38, s35, 0x3fffffff                              ; 8b26ff23 3fffffff
	s_cmp_lg_i32 s37, 0                                         ; bf018025
	s_cselect_b32 s35, s38, s35                                 ; 98232326
	image_sample_lz v[6:8], [v4, v5], s[24:31], s[32:35] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 10003006 00000504
	s_cmp_lg_i32 s19, 0                                         ; bf018013
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_cvt_f16_f32_e32 v9, v6                                    ; 7e121506
(invalid instruction)                                        ; 7f121507
	v_cvt_f16_f32_e32 v10, v8                                   ; 7e141508
	s_cbranch_scc0 BB8                                          ; bfa10011
BB7:
	s_load_b128 s[36:39], s[0:1], 0x40                          ; f4004900 f8000040
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_lshl_b32 s13, s10, 3                                      ; 840d830a
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v0, v3, v13, vcc_lo                       ; 02001b03
	v_add_lshl_u32 v4, v4, v1, 1                                ; d6470004 02060304
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_lshl_u32 v4, s19, v4, 2                               ; d6470004 020a0813
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b64 v[4:5], v4, s[36:39], null offen            ; c405407c 40804804 00000004
	s_branch BB9                                                ; bfa00088
BB8:
	s_clause 0x1                                                ; bf850001
	s_load_b32 s11, s[14:15], 0x5c                              ; f40002c7 f800005c
	s_load_b32 s21, s[14:15], 0x74                              ; f4000547 f8000074
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v1, 0x8da6b343, v1, vcc_lo                ; 020202ff 8da6b343
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v1, 0xd8163841, v3, vcc_lo                ; 020206ff d8163841
	s_mov_b32 s13, 0x108ef2d9                                   ; be8d00ff 108ef2d9
	s_mov_b32 s17, 0x33800000                                   ; be9100ff 33800000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s11, s11, 0x9e3779b9                              ; 960bff0b 9e3779b9
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_xor3_b32 v5, v5, s11, v4                                  ; d6400005 04101705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v5, 0x243f6a88, v5                            ; 3a0a0aff 243f6a88
	v_lshrrev_b32_e32 v6, 28, v5                                ; 320c0a9c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v6, 4, v6                                  ; 4a0c0c84
	v_lshrrev_b32_e32 v6, v6, v5                                ; 320c0b06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v6, v6, v5                                    ; 3a0c0b06
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v1, s13, v6, vcc_lo                       ; 02020c0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v7, 22, v6                                ; 320e0c96
	v_xor_b32_e32 v7, v7, v6                                    ; 3a0e0d07
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d72c0008
	v_cndmask_b32_e32 v1, 0x2c9277b5, v7, vcc_lo                ; 02020eff 2c9277b5
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v1, 0xfa6dc5f9, v7, vcc_lo                ; 02020eff fa6dc5f9
(invalid instruction)                                        ; d72c0010
	v_cndmask_b32_e32 v1, 0xcaa5b80d, v7, vcc_lo                ; 02020eff caa5b80d
(invalid instruction)                                        ; d72c0007
	v_cndmask_b32_e32 v1, 0x83232c31, v7, vcc_lo                ; 02020eff 83232c31
	v_add_nc_u32_e32 v8, 0xac564b05, v8                         ; 4a1010ff ac564b05
	v_add_nc_u32_e32 v13, 0x4712a88e, v13                       ; 4a1a1aff 4712a88e
	v_add_nc_u32_e32 v16, 0x21dd796b, v16                       ; 4a2020ff 21dd796b
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_lshrrev_b32_e32 v11, 28, v8                               ; 3216109c
	v_lshrrev_b32_e32 v14, 28, v13                              ; 321c1a9c
	v_add_nc_u32_e32 v7, 0x3463e0ac, v7                         ; 4a0e0eff 3463e0ac
	v_lshrrev_b32_e32 v17, 28, v16                              ; 3222209c
	v_add_nc_u32_e32 v11, 4, v11                                ; 4a161684
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_lshrrev_b32_e32 v19, 28, v7                               ; 32260e9c
	v_add_nc_u32_e32 v17, 4, v17                                ; 4a222284
	v_lshrrev_b32_e32 v11, v11, v8                              ; 3216110b
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_add_nc_u32_e32 v19, 4, v19                                ; 4a262684
	v_xor_b32_e32 v11, v11, v8                                  ; 3a16110b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c000b
	v_cndmask_b32_e32 v1, s13, v11, vcc_lo                      ; 0202160d
	v_lshrrev_b32_e32 v12, 8, v11                               ; 32181688
	v_lshrrev_b32_e32 v11, 30, v11                              ; 3216169e
	v_lshrrev_b32_e32 v17, v17, v16                             ; 32222111
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_xad_u32 v11, v11, v12, 1                                  ; d645000b 0206190b
	v_xor_b32_e32 v17, v17, v16                                 ; 3a222111
	v_cvt_f32_u32_e32 v11, v11                                  ; 7e160d0b
(invalid instruction)                                        ; d72c0011
	v_cndmask_b32_e32 v1, s13, v17, vcc_lo                      ; 0202220d
	v_dual_mul_f32 v11, s17, v11 :: v_dual_add_nc_u32 v14, 4, v14 ; c8e01611 0b0e1c84
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshrrev_b32_e32 v14, v14, v13                             ; 321c1b0e
	v_log_f32_e32 v11, v11                                      ; 7e164f0b
	v_lshrrev_b32_e32 v19, v19, v7                              ; 32260f13
	v_lshrrev_b32_e32 v18, 8, v17                               ; 32242288
	v_lshrrev_b32_e32 v17, 30, v17                              ; 3222229e
	v_xor_b32_e32 v14, v14, v13                                 ; 3a1c1b0e
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_xor_b32_e32 v19, v19, v7                                  ; 3a260f13
(invalid instruction)                                        ; d72c000e
	v_cndmask_b32_e32 v1, s13, v14, vcc_lo                      ; 02021c0d
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v1, s13, v19, vcc_lo                      ; 0202260d
	v_xad_u32 v17, v17, v18, 1                                  ; d6450011 02062511
	v_lshrrev_b32_e32 v15, 8, v14                               ; 321e1c88
	v_lshrrev_b32_e32 v14, 30, v14                              ; 321c1c9e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_cvt_f32_u32_e32 v17, v17                                  ; 7e220d11
	v_lshrrev_b32_e32 v20, 8, v19                               ; 32282688
	v_lshrrev_b32_e32 v19, 30, v19                              ; 3226269e
	v_xad_u32 v14, v14, v15, 1                                  ; d645000e 02061f0e
	v_mul_f32_e32 v17, s17, v17                                 ; 10222211
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_xad_u32 v19, v19, v20, 1                                  ; d6450013 02062913
	v_cvt_f32_u32_e32 v14, v14                                  ; 7e1c0d0e
	v_log_f32_e32 v17, v17                                      ; 7e224f11
	v_cvt_f32_u32_e32 v19, v19                                  ; 7e260d13
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	v_dual_mul_f32 v11, 0xbfb17218, v11 :: v_dual_mul_f32 v14, s17, v14 ; c8c616ff 0b0e1c11 bfb17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_mul_f32_e32 v19, s17, v19                                 ; 10262611
	v_sqrt_f32_e32 v11, v11                                     ; 7e16670b
	v_cos_f32_e32 v21, v14                                      ; 7e2a6d0e
	v_sin_f32_e32 v14, v14                                      ; 7e1c6b0e
	v_mul_f32_e32 v17, 0xbfb17218, v17                          ; 102222ff bfb17218
	v_cos_f32_e32 v19, v19                                      ; 7e266d13
	v_mul_f32_e32 v21, v11, v21                                 ; 102a2b0b
	v_sqrt_f32_e32 v17, v17                                     ; 7e226711
	v_mul_f32_e32 v11, v11, v14                                 ; 10161d0b
	v_fma_mixlo_f16 v4, s21, v21, neg(0) op_sel_hi:[0,0,1]      ; cc214004 82022a15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mixhi_f16 v4, s21, v11, neg(0) op_sel_hi:[0,0,1]      ; cc224004 82021615
	v_mul_f32_e32 v17, v17, v19                                 ; 10222711
	v_fma_mixlo_f16 v5, s21, v17, neg(0) op_sel_hi:[0,0,1]      ; cc214005 82022215
BB9:
	s_clause 0x2                                                ; bf850002
	s_load_b32 s13, s[14:15], 0x78                              ; f4000347 f8000078
	s_load_b128 s[36:39], s[14:15], 0x60                        ; f4004907 f8000060
	s_load_b32 s17, s[14:15], 0x70                              ; f4000447 f8000070
	v_lshlrev_b32_e32 v2, 2, v2                                 ; 30040482
(invalid instruction)                                        ; cc0f0009
	v_subrev_f32_e32 v0, v9, v241                               ; 0a01e309
	v_add_f16_e32 v10, -0.5, v10                                ; 641414f1
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mov_b32 v12, v4 :: v_dual_and_b32 v7, 3, v0          ; ca240104 0c060083
	v_bfe_u32 v6, v1, 2, 1                                      ; d6100006 02050501
	v_bfe_u32 v3, v3, 2, 1                                      ; d6100003 02050503
(invalid instruction)                                        ; cc10000e
	v_subrev_f32_e32 v0, v9, v255                               ; 0a01ff09
(invalid instruction)                                        ; 00003000
	v_mul_f16_e32 v9, 0x3000, v10                               ; 6a1214ff 00003000
	v_add_nc_u32_e32 v10, 32, v0                                ; 4a1400a0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
	v_lshl_add_u32 v3, v3, 1, v6                                ; d6460003 04190303
	v_mov_b32_e32 v8, v14                                       ; 7e10030e
	v_lshrrev_b32_e32 v10, 3, v10                               ; 32141483
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_lshl_add_u32 v3, v3, 4, v2                                ; d6460003 04090903
	v_perm_b32 v15, v8, v9, 0x5040100                           ; d644000f 03fe1308 05040100
	v_lshl_add_u32 v11, ttmp7, 3, v10                           ; d646000b 04290673
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d3
	v_add_lshl_u32 v3, v3, v7, 5                                ; d6470003 02160f03
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cvt_f16_f32 s13, s13                                      ; be8d680d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_mov_b16_e32 v17.h, s13                                    ; 7f22380d
	v_perm_b32 v13, v17, v5, 0x7060100                          ; d644000d 03fe0b11 07060100
	ds_store_b128 v3, v[12:15]                                  ; db7c0000 00000c03
	v_alignbyte_b32 v12, v9, v8, 2                              ; d617000c 020a1109
	s_cvt_f16_f32 s38, s38                                      ; bea66826
	s_cvt_f16_f32 s36, s36                                      ; bea46824
	s_cvt_f16_f32 s37, s37                                      ; bea56825
	s_cvt_f16_f32 s39, s39                                      ; bea76827
	s_cvt_f16_f32 s17, s17                                      ; be916811
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_pack_ll_b32_b16 s36, s36, s37                             ; 99242524
	s_pack_ll_b32_b16 s38, s38, s39                             ; 99262726
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_pack_ll_b32_b16 s17, s17, 0                               ; 99118011
	v_mov_b32_e32 v13, s36                                      ; 7e1a0224
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_mov_b32 v15, s17 :: v_dual_mov_b32 v14, s38          ; ca100011 0f0e0026
	ds_store_b128 v3, v[12:15] offset:16                        ; db7c0010 00000c03
	s_cmp_lg_i32 s12, 0                                         ; bf01800c
	s_cbranch_scc0 BB12                                         ; bfa10006
BB10:
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s12, s12, 2                                      ; 840c820c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mov_b32 s20, s12                                          ; be94000c
BB12:
	s_cmp_lg_i32 s18, 0                                         ; bf018012
	s_cbranch_scc0 BB15                                         ; bfa10004
BB13:
	s_load_b32 s12, s[14:15], 0x38                              ; f4000307 f8000038
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s16, s12, 2                                      ; 8410820c
BB15:
	s_lshl1_add_u32 s12, s20, -2                                ; 870cc214
	v_cmp_gt_u32_e32 vcc_lo, s20, v1                            ; 7c980214
	s_cvt_f32_u32 s20, s20                                      ; be946514
	s_lshl1_add_u32 s13, s16, -2                                ; 870dc210
	v_sub_nc_u32_e32 v2, s12, v1                                ; 4c04020c
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_sub_nc_u32_e32 v3, s13, v11                               ; 4c06160d
(invalid instruction)                                        ; d6840014
	v_cndmask_b32_e32 v0, s20, v128, vcc_lo                     ; 02010014
	s_wait_alu 0xfffd                                           ; bf88fffd
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_cndmask_b32_e32 v2, v2, v1, vcc_lo                        ; 02040302
	v_cmp_gt_u32_e32 vcc_lo, s16, v11                           ; 7c981610
	s_cvt_f32_u32 s16, s16                                      ; be906510
	v_cvt_f32_i32_e32 v2, v2                                    ; 7e040b02
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v3, v3, v11, vcc_lo                       ; 02061703
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840010
	v_cndmask_b32_e32 v0, s16, v128, vcc_lo                     ; 02010010
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_cvt_f32_i32_e32 v3, v3                                    ; 7e060b03
	v_dual_add_f32 v3, 0.5, v3 :: v_dual_add_f32 v2, 0.5, v2    ; c90806f0 030204f0
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_dual_mul_f32 v3, s16, v3 :: v_dual_mul_f32 v2, s20, v2    ; c8c60610 03020414
	image_sample_lz v[12:14], [v2, v3], s[24:31], s[32:35] dmask:0x7 dim:SQ_RSRC_IMG_2D ; e5c7c001 1000300c 00000302
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
	s_wait_samplecnt 0x0                                        ; bfc20000
	v_cvt_f16_f32_e32 v15, v12                                  ; 7e1e150c
	v_cvt_f16_f32_e32 v16, v14                                  ; 7e20150e
(invalid instruction)                                        ; 7f1e150d
	s_cbranch_scc0 BB17                                         ; bfa10010
BB16:
	s_load_b128 s[20:23], s[0:1], 0x40                          ; f4004500 f8000040
	s_lshl_b32 s11, s10, 3                                      ; 840b830a
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v11, v11, vcc_lo                      ; 0200170b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v2, v2, v1, 1                                ; d6470002 02060302
	v_add_lshl_u32 v2, s19, v2, 2                               ; d6470002 020a0413
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b64 v[2:3], v2, s[20:23], null offen            ; c405407c 40802802 00000002
	s_branch BB18                                               ; bfa00085
BB17:
	s_clause 0x1                                                ; bf850001
	s_load_b32 s11, s[14:15], 0x5c                              ; f40002c7 f800005c
	s_load_b32 s16, s[14:15], 0x74                              ; f4000407 f8000074
(invalid instruction)                                        ; d72c0001
	v_cndmask_b32_e32 v1, 0x8da6b343, v1, vcc_lo                ; 020202ff 8da6b343
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v1, 0xd8163841, v11, vcc_lo               ; 020216ff d8163841
	s_mov_b32 s12, 0x108ef2d9                                   ; be8c00ff 108ef2d9
	s_mov_b32 s13, 0x33800000                                   ; be8d00ff 33800000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s11, s11, 0x9e3779b9                              ; 960bff0b 9e3779b9
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_xor3_b32 v2, v2, s11, v1                                  ; d6400002 04041702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v2, 0x243f6a88, v2                            ; 3a0404ff 243f6a88
	v_lshrrev_b32_e32 v3, 28, v2                                ; 3206049c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v3, 4, v3                                  ; 4a060684
	v_lshrrev_b32_e32 v3, v3, v2                                ; 32060503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v3, v3, v2                                    ; 3a060503
(invalid instruction)                                        ; d72c0003
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                       ; 0202060c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v4, 22, v3                                ; 32080696
	v_xor_b32_e32 v4, v4, v3                                    ; 3a080704
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v1, 0x2c9277b5, v4, vcc_lo                ; 020208ff 2c9277b5
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v1, 0xfa6dc5f9, v4, vcc_lo                ; 020208ff fa6dc5f9
(invalid instruction)                                        ; d72c0012
	v_cndmask_b32_e32 v1, 0xcaa5b80d, v4, vcc_lo                ; 020208ff caa5b80d
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v1, 0x83232c31, v4, vcc_lo                ; 020208ff 83232c31
	v_add_nc_u32_e32 v5, 0xac564b05, v5                         ; 4a0a0aff ac564b05
	v_add_nc_u32_e32 v12, 0x4712a88e, v12                       ; 4a1818ff 4712a88e
	v_add_nc_u32_e32 v18, 0x21dd796b, v18                       ; 4a2424ff 21dd796b
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_lshrrev_b32_e32 v8, 28, v5                                ; 32100a9c
	v_lshrrev_b32_e32 v13, 28, v12                              ; 321a189c
	v_add_nc_u32_e32 v4, 0x3463e0ac, v4                         ; 4a0808ff 3463e0ac
	v_lshrrev_b32_e32 v19, 28, v18                              ; 3226249c
	v_add_nc_u32_e32 v8, 4, v8                                  ; 4a101084
	v_add_nc_u32_e32 v13, 4, v13                                ; 4a1a1a84
	v_lshrrev_b32_e32 v21, 28, v4                               ; 322a089c
	v_add_nc_u32_e32 v19, 4, v19                                ; 4a262684
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870124
	v_lshrrev_b32_e32 v8, v8, v5                                ; 32100b08
	v_lshrrev_b32_e32 v13, v13, v12                             ; 321a190d
	v_xor_b32_e32 v8, v8, v5                                    ; 3a100b08
	v_xor_b32_e32 v13, v13, v12                                 ; 3a1a190d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d2
(invalid instruction)                                        ; d72c0008
	v_cndmask_b32_e32 v1, s12, v8, vcc_lo                       ; 0202100c
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v1, s12, v13, vcc_lo                      ; 02021a0c
	v_lshrrev_b32_e32 v19, v19, v18                             ; 32262513
	v_lshrrev_b32_e32 v9, 8, v8                                 ; 32121088
	v_lshrrev_b32_e32 v8, 30, v8                                ; 3210109e
	v_xor_b32_e32 v19, v19, v18                                 ; 3a262513
	v_lshrrev_b32_e32 v14, 8, v13                               ; 321c1a88
	v_lshrrev_b32_e32 v13, 30, v13                              ; 321a1a9e
	v_xad_u32 v8, v8, v9, 1                                     ; d6450008 02061308
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v1, s12, v19, vcc_lo                      ; 0202260c
	v_xad_u32 v13, v13, v14, 1                                  ; d645000d 02061d0d
	v_cvt_f32_u32_e32 v8, v8                                    ; 7e100d08
	v_cvt_f32_u32_e32 v13, v13                                  ; 7e1a0d0d
	v_dual_mul_f32 v8, s13, v8 :: v_dual_add_nc_u32 v21, 4, v21 ; c8e0100d 08142a84
	v_lshrrev_b32_e32 v20, 8, v19                               ; 32282688
	v_lshrrev_b32_e32 v19, 30, v19                              ; 3226269e
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
	v_log_f32_e32 v8, v8                                        ; 7e104f08
	v_lshrrev_b32_e32 v21, v21, v4                              ; 322a0915
	v_xad_u32 v19, v19, v20, 1                                  ; d6450013 02062913
	v_xor_b32_e32 v21, v21, v4                                  ; 3a2a0915
	v_cvt_f32_u32_e32 v19, v19                                  ; 7e260d13
	v_dual_mul_f32 v8, 0xbfb17218, v8 :: v_dual_mul_f32 v13, s13, v13 ; c8c610ff 080c1a0d bfb17218
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d72c0015
	v_cndmask_b32_e32 v1, s12, v21, vcc_lo                      ; 02022a0c
	v_mul_f32_e32 v19, s13, v19                                 ; 1026260d
	v_cos_f32_e32 v23, v13                                      ; 7e2e6d0d
	v_sin_f32_e32 v13, v13                                      ; 7e1a6b0d
	v_sqrt_f32_e32 v8, v8                                       ; 7e106708
	v_log_f32_e32 v19, v19                                      ; 7e264f13
	v_lshrrev_b32_e32 v22, 8, v21                               ; 322c2a88
	v_lshrrev_b32_e32 v21, 30, v21                              ; 322a2a9e
	v_mul_f32_e32 v23, v8, v23                                  ; 102e2f08
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_xad_u32 v21, v21, v22, 1                                  ; d6450015 02062d15
	v_mul_f32_e32 v19, 0xbfb17218, v19                          ; 102626ff bfb17218
	v_fma_mixlo_f16 v2, s16, v23, neg(0) op_sel_hi:[0,0,1]      ; cc214002 82022e10
	v_cvt_f32_u32_e32 v21, v21                                  ; 7e2a0d15
	v_sqrt_f32_e32 v19, v19                                     ; 7e266713
	v_mul_f32_e32 v21, s13, v21                                 ; 102a2a0d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_cos_f32_e32 v21, v21                                      ; 7e2a6d15
	v_dual_mul_f32 v19, v21, v19 :: v_dual_mul_f32 v8, v8, v13  ; c8c62715 13081b08
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_fma_mixlo_f16 v3, s16, v19, neg(0) op_sel_hi:[0,0,1]      ; cc214003 82022610
	v_fma_mixhi_f16 v2, s16, v8, neg(0) op_sel_hi:[0,0,1]       ; cc224002 82021010
BB18:
	v_and_b32_e32 v10, 3, v10                                   ; 36141483
(invalid instruction)                                        ; cc0f000f
	v_subrev_f32_e32 v0, v15, v241                              ; 0a01e30f
	v_bfe_u32 v11, v11, 2, 1                                    ; d610000b 0205050b
	v_add_f16_e32 v16, -0.5, v16                                ; 642020f1
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v3.h, v17.h                                   ; 7f063991
	v_mov_b32_e32 v13, s36                                      ; 7e1a0224
(invalid instruction)                                        ; cc100004
	v_subrev_f32_e32 v0, v15, v255                              ; 0a01ff0f
(invalid instruction)                                        ; 00003000
	v_dual_mov_b32 v15, s17 :: v_dual_mov_b32 v14, s38          ; ca100011 0f0e0026
	v_lshl_add_u32 v11, v11, 1, v6                              ; d646000b 0419030b
(invalid instruction)                                        ; 6b1820ff
(invalid instruction)                                        ; 00003000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_dual_mov_b32 v1, v4 :: v_dual_lshlrev_b32 v10, 2, v10     ; ca220104 010a1482
	v_lshl_add_u32 v11, v11, 4, v10                             ; d646000b 0429090b
	v_alignbyte_b32 v5, v1, v12, 2                              ; d6170005 020a1901
	v_mov_b16_e32 v12.l, v1.h                                   ; 7e183981
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d3
	v_add_lshl_u32 v11, v11, v7, 5                              ; d647000b 02160f0b
	ds_store_b128 v11, v[2:5]                                   ; db7c0000 0000020b
	ds_store_b128 v11, v[12:15] offset:16                       ; db7c0010 00000c0b
	s_load_b32 s11, s[14:15], 0x50                              ; f40002c7 f8000050
(invalid instruction)                                        ; d71f0002
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_and_b32_e32 v3, 15, v2                                    ; 3606048f
	v_lshrrev_b32_e32 v2, 4, v2                                 ; 32040484
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_lshlrev_b32_e32 v4, 4, v3                                 ; 30080684
	v_lshlrev_b32_e32 v2, 3, v2                                 ; 30040483
	v_add_lshl_u32 v6, v4, v2, 1                                ; d6470006 02060504
	ds_load_b64 v[8:9], v6                                      ; d9d80000 08000006
	ds_load_b64 v[10:11], v6 offset:8                           ; d9d80008 0a000006
	ds_load_b64 v[12:13], v6 offset:512                         ; d9d80200 0c000006
	ds_load_b64 v[14:15], v6 offset:520                         ; d9d80208 0e000006
	ds_load_b64 v[16:17], v6 offset:1024                        ; d9d80400 10000006
	ds_load_b64 v[18:19], v6 offset:1032                        ; d9d80408 12000006
	ds_load_b64 v[20:21], v6 offset:1536                        ; d9d80600 14000006
	ds_load_b64 v[22:23], v6 offset:1544                        ; d9d80608 16000006
	s_clause 0x1                                                ; bf850001
	s_load_b32 s12, s[14:15], 0x34                              ; f4000307 f8000034
	s_load_b128 s[16:19], s[0:1], 0x40                          ; f4004400 f8000040
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_add3_u32 v5, v2, s11, v4                                  ; d6550005 04101702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
	v_lshlrev_b32_e32 v5, 1, v5                                 ; 300a0a81
	buffer_load_b128 v[24:27], v5, s[16:19], null offen         ; c405c07c 40802018 00000005
	s_cmp_eq_i32 s12, 0                                         ; bf00800c
	s_wait_loadcnt_dscnt 0x6                                    ; bfc80006
	v_wmma_f32_16x16x16_f16 v[32:39], v[24:27], v[8:11], 0      ; cc404020 1a021118
	v_cvt_f16_f32_e32 v7, v32                                   ; 7e0e1520
	v_cvt_f16_f32_e32 v24, v34                                  ; 7e301522
(invalid instruction)                                        ; 7f301523
(invalid instruction)                                        ; 7f0e1521
	v_cvt_f16_f32_e32 v25, v36                                  ; 7e321524
	v_cvt_f16_f32_e32 v26, v38                                  ; 7e341526
(invalid instruction)                                        ; 7f341527
(invalid instruction)                                        ; 7f321525
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB23                                         ; bfa1000f
BB19:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB22                                         ; bfa10007
BB20:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB22:
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v7, 0               ; ca100080 18060080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v25, 0              ; ca100080 1a180080
	s_branch BB24                                               ; bfa00001
BB23:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB24:
	buffer_load_b128 v[28:31], v5, s[16:19], null offen offset:512 ; c405c07c 4080201c 00020005
	v_cvt_f32_f16_e32 v1, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e021787
	v_cvt_f32_f16_e32 v6, v7                                    ; 7e0c1707
	v_cvt_f32_f16_e32 v27, v152/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e361798
	v_cvt_f32_f16_e32 v33, v24                                  ; 7e421718
	v_cvt_f32_f16_e32 v34, v153/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e441799
	v_cvt_f32_f16_e32 v35, v25                                  ; 7e461719
	v_cvt_f32_f16_e32 v36, v154/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e48179a
	v_cvt_f32_f16_e32 v37, v26                                  ; 7e4a171a
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v33, v27, vcc_lo                      ; 02023721
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v37, v36, vcc_lo                      ; 02024925
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[40:47], v[28:31], v[8:11], 0      ; cc404028 1a02111c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v39, v42                                  ; 7e4e152a
(invalid instruction)                                        ; 7f4e152b
	v_cvt_f16_f32_e32 v38, v40                                  ; 7e4c1528
	v_cvt_f16_f32_e32 v40, v44                                  ; 7e50152c
(invalid instruction)                                        ; 7f50152d
(invalid instruction)                                        ; 7f4c1529
	v_cvt_f16_f32_e32 v41, v46                                  ; 7e52152e
(invalid instruction)                                        ; 7f52152f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB29                                         ; bfa1000f
BB25:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB28                                         ; bfa10007
BB26:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB28:
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	s_branch BB30                                               ; bfa00001
BB29:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB30:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen          ; c405c07c 40802008 00000005
	v_cvt_f32_f16_e32 v1, v166/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217a6
	v_cvt_f32_f16_e32 v6, v38                                   ; 7e0c1726
	v_cvt_f32_f16_e32 v27, v167/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3617a7
	v_cvt_f32_f16_e32 v29, v39                                  ; 7e3a1727
	v_cvt_f32_f16_e32 v30, v168/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3c17a8
	v_cvt_f32_f16_e32 v31, v40                                  ; 7e3e1728
	v_cvt_f32_f16_e32 v34, v169/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417a9
	v_cvt_f32_f16_e32 v35, v41                                  ; 7e461729
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v29, v27, vcc_lo                      ; 0202371d
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v31, v30, vcc_lo                      ; 02023d1f
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt_dscnt 0x4                                    ; bfc80004
	v_wmma_f32_16x16x16_f16 v[48:55], v[8:11], v[12:15], 0      ; cc404030 1a021908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v37, v50                                  ; 7e4a1532
(invalid instruction)                                        ; 7f4a1533
	v_cvt_f16_f32_e32 v42, v52                                  ; 7e541534
(invalid instruction)                                        ; 7f541535
	v_cvt_f16_f32_e32 v43, v54                                  ; 7e561536
(invalid instruction)                                        ; 7f561537
	v_cvt_f16_f32_e32 v36, v48                                  ; 7e481530
(invalid instruction)                                        ; 7f481531
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB35                                         ; bfa1000f
BB31:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB34                                         ; bfa10007
BB32:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB34:
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	s_branch BB36                                               ; bfa00001
BB35:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB36:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen offset:512 ; c405c07c 40802008 00020005
	v_cvt_f32_f16_e32 v1, v164/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217a4
	v_cvt_f32_f16_e32 v6, v36                                   ; 7e0c1724
	v_cvt_f32_f16_e32 v27, v165/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3617a5
	v_cvt_f32_f16_e32 v31, v37                                  ; 7e3e1725
	v_cvt_f32_f16_e32 v34, v170/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417aa
	v_cvt_f32_f16_e32 v35, v42                                  ; 7e46172a
	v_cvt_f32_f16_e32 v44, v171/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e5817ab
	v_cvt_f32_f16_e32 v45, v43                                  ; 7e5a172b
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v31, v27, vcc_lo                      ; 0202371f
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v45, v44, vcc_lo                      ; 0202592d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[48:55], v[8:11], v[12:15], 0      ; cc404030 1a021908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v47, v50                                  ; 7e5e1532
(invalid instruction)                                        ; 7f5e1533
	v_cvt_f16_f32_e32 v46, v48                                  ; 7e5c1530
	v_cvt_f16_f32_e32 v48, v52                                  ; 7e601534
(invalid instruction)                                        ; 7f601535
(invalid instruction)                                        ; 7f5c1531
	v_cvt_f16_f32_e32 v49, v54                                  ; 7e621536
(invalid instruction)                                        ; 7f621537
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB41                                         ; bfa1000f
BB37:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB40                                         ; bfa10007
BB38:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB40:
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	s_branch BB42                                               ; bfa00001
BB41:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB42:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen          ; c405c07c 40802008 00000005
	v_cvt_f32_f16_e32 v1, v174/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217ae
	v_cvt_f32_f16_e32 v6, v46                                   ; 7e0c172e
	v_cvt_f32_f16_e32 v13, v175/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1a17af
	v_cvt_f32_f16_e32 v14, v47                                  ; 7e1c172f
	v_cvt_f32_f16_e32 v15, v176/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e17b0
	v_cvt_f32_f16_e32 v27, v48                                  ; 7e361730
	v_cvt_f32_f16_e32 v34, v177/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417b1
	v_cvt_f32_f16_e32 v35, v49                                  ; 7e461731
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v14, v13, vcc_lo                      ; 02021b0e
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v27, v15, vcc_lo                      ; 02021f1b
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt_dscnt 0x2                                    ; bfc80002
	v_wmma_f32_16x16x16_f16 v[56:63], v[8:11], v[16:19], 0      ; cc404038 1a022108
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v45, v58                                  ; 7e5a153a
(invalid instruction)                                        ; 7f5a153b
	v_cvt_f16_f32_e32 v50, v60                                  ; 7e64153c
(invalid instruction)                                        ; 7f64153d
	v_cvt_f16_f32_e32 v51, v62                                  ; 7e66153e
(invalid instruction)                                        ; 7f66153f
	v_cvt_f16_f32_e32 v44, v56                                  ; 7e581538
(invalid instruction)                                        ; 7f581539
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB47                                         ; bfa1000f
BB43:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB46                                         ; bfa10007
BB44:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB46:
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	s_branch BB48                                               ; bfa00001
BB47:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB48:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen offset:512 ; c405c07c 40802008 00020005
	v_cvt_f32_f16_e32 v1, v172/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217ac
	v_cvt_f32_f16_e32 v6, v44                                   ; 7e0c172c
	v_cvt_f32_f16_e32 v15, v173/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1e17ad
	v_cvt_f32_f16_e32 v27, v45                                  ; 7e36172d
	v_cvt_f32_f16_e32 v34, v178/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417b2
	v_cvt_f32_f16_e32 v35, v50                                  ; 7e461732
	v_cvt_f32_f16_e32 v52, v179/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e6817b3
	v_cvt_f32_f16_e32 v53, v51                                  ; 7e6a1733
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v27, v15, vcc_lo                      ; 02021f1b
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v53, v52, vcc_lo                      ; 02026935
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[56:63], v[8:11], v[16:19], 0      ; cc404038 1a022108
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v55, v58                                  ; 7e6e153a
(invalid instruction)                                        ; 7f6e153b
	v_cvt_f16_f32_e32 v54, v56                                  ; 7e6c1538
	v_cvt_f16_f32_e32 v56, v60                                  ; 7e70153c
(invalid instruction)                                        ; 7f70153d
(invalid instruction)                                        ; 7f6c1539
	v_cvt_f16_f32_e32 v57, v62                                  ; 7e72153e
(invalid instruction)                                        ; 7f72153f
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB53                                         ; bfa1000f
BB49:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB52                                         ; bfa10007
BB50:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB52:
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	s_branch BB54                                               ; bfa00001
BB53:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB54:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen          ; c405c07c 40802008 00000005
	v_cvt_f32_f16_e32 v1, v182/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217b6
	v_cvt_f32_f16_e32 v6, v54                                   ; 7e0c1736
	v_cvt_f32_f16_e32 v17, v183/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2217b7
	v_cvt_f32_f16_e32 v18, v55                                  ; 7e241737
	v_cvt_f32_f16_e32 v19, v184/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2617b8
	v_cvt_f32_f16_e32 v27, v56                                  ; 7e361738
	v_cvt_f32_f16_e32 v34, v185/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417b9
	v_cvt_f32_f16_e32 v35, v57                                  ; 7e461739
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                        ; 02020306
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v18, v17, vcc_lo                      ; 02022312
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v27, v19, vcc_lo                      ; 0202271b
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                      ; 02024523
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt_dscnt 0x0                                    ; bfc80000
	v_wmma_f32_16x16x16_f16 v[64:71], v[8:11], v[20:23], 0      ; cc404040 1a022908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v53, v66                                  ; 7e6a1542
(invalid instruction)                                        ; 7f6a1543
	v_cvt_f16_f32_e32 v58, v68                                  ; 7e741544
(invalid instruction)                                        ; 7f741545
	v_cvt_f16_f32_e32 v59, v70                                  ; 7e761546
(invalid instruction)                                        ; 7f761547
	v_cvt_f16_f32_e32 v52, v64                                  ; 7e681540
(invalid instruction)                                        ; 7f681541
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB59                                         ; bfa1000f
BB55:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB58                                         ; bfa10007
BB56:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB58:
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	s_branch BB60                                               ; bfa00001
BB59:
	s_mov_b32 s11, src_scc                                      ; be8b00fd
BB60:
	buffer_load_b128 v[8:11], v5, s[16:19], null offen offset:512 ; c405c07c 40802008 00020005
	v_cvt_f32_f16_e32 v1, v180/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0217b4
	v_cvt_f32_f16_e32 v5, v52                                   ; 7e0a1734
	v_cvt_f32_f16_e32 v6, v181/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0c17b5
	v_cvt_f32_f16_e32 v19, v53                                  ; 7e261735
	v_cvt_f32_f16_e32 v27, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3617ba
	v_cvt_f32_f16_e32 v34, v58                                  ; 7e44173a
	v_cvt_f32_f16_e32 v35, v187/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4617bb
	v_cvt_f32_f16_e32 v60, v59                                  ; 7e78173b
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                        ; 02020305
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v19, v6, vcc_lo                       ; 02020d13
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v34, v27, vcc_lo                      ; 02023722
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v60, v35, vcc_lo                      ; 0202473c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_f16 v[64:71], v[8:11], v[20:23], 0      ; cc404040 1a022908
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_cvt_f16_f32_e32 v62, v66                                  ; 7e7c1542
(invalid instruction)                                        ; 7f7c1543
	v_cvt_f16_f32_e32 v63, v68                                  ; 7e7e1544
(invalid instruction)                                        ; 7f7e1545
	v_cvt_f16_f32_e32 v61, v64                                  ; 7e7a1540
	v_cvt_f16_f32_e32 v64, v70                                  ; 7e801546
(invalid instruction)                                        ; 7f801547
(invalid instruction)                                        ; 7f7a1541
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_cbranch_scc0 BB66                                         ; bfa1000d
BB61:
	s_cmp_eq_i32 s10, -1                                        ; bf00c10a
	s_cbranch_scc0 BB64                                         ; bfa10007
BB62:
	s_load_b128 s[20:23], s[0:1], 0x0                           ; f4004500 f8000000
	v_mov_b32_e32 v1, 0                                         ; 7e020280
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b8 v1, off, s[20:23], s2                       ; c4060002 00802801 00000000
BB64:
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v61, 0              ; ca100080 3e3c0080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v63, 0              ; ca100080 403e0080
BB66:
	v_lshlrev_b32_e32 v1, 2, v0                                 ; 30020082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v5, s3, v1, 2                                ; d6470005 020a0203
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[8:11], v5, s[16:19], null offen          ; c405c07c 40802008 00000005
	buffer_load_b128 v[20:23], v5, s[16:19], null offen offset:512 ; c405c07c 40802014 00020005
	buffer_load_b128 v[68:71], v5, s[16:19], null offen offset:1024 ; c405c07c 40802044 00040005
	buffer_load_b128 v[72:75], v5, s[16:19], null offen offset:1536 ; c405c07c 40802048 00060005
	buffer_load_b128 v[76:79], v5, s[16:19], null offen offset:2048 ; c405c07c 4080204c 00080005
	buffer_load_b128 v[80:83], v5, s[16:19], null offen offset:2560 ; c405c07c 40802050 000a0005
	v_cvt_f32_f16_e32 v6, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0c17bd
	v_cvt_f32_f16_e32 v27, v61                                  ; 7e36173d
	v_cvt_f32_f16_e32 v35, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4617be
	v_cvt_f32_f16_e32 v60, v62                                  ; 7e78173e
	v_cvt_f32_f16_e32 v65, v191/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8217bf
	v_cvt_f32_f16_e32 v66, v63                                  ; 7e84173f
	v_cvt_f32_f16_e32 v67, v192/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8617c0
	v_cvt_f32_f16_e32 v84, v64                                  ; 7ea81740
	s_movk_i32 s3, 0x400                                        ; b0030400
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v27, v6, vcc_lo                       ; 02020d1b
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v60, v35, vcc_lo                      ; 0202473c
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v66, v65, vcc_lo                      ; 02028342
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v84, v67, vcc_lo                      ; 02028754
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[14:15], 0 ; cc464068 1a021d08
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[8:9], v[18:19], 0 ; cc464070 1a022508
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[30:31], 0  ; cc464060 1a023d08
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[8:9], v[32:33], 0   ; cc464058 1a024108
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[10:11], v[32:33], 0 ; cc464078 1a02410a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[10:11], v[30:31], 0 ; cc464080 1a023d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[14:15], 0 ; cc464088 1a021d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[10:11], v[18:19], 0 ; cc464090 1a02250a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[12:13], v[96:103] ; cc464060 1d821914
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[20:21], v[28:29], v[88:95] ; cc464058 1d623914
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[20:21], v[16:17], v[104:111] ; cc464068 1da22114
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[20:21], v[34:35], v[112:119] ; cc464070 1dc24514
	v_maxmin_num_f32 v157, -4.0, v92, 4.0                       ; d669009d 03dab8f7
	v_maxmin_num_f32 v155, -4.0, v91, 4.0                       ; d669009b 03dab6f7
	v_maxmin_num_f32 v159, -4.0, v93, 4.0                       ; d669009f 03dabaf7
	v_maxmin_num_f32 v153, -4.0, v90, 4.0                       ; d6690099 03dab4f7
	v_maxmin_num_f32 v85, -4.0, v88, 4.0                        ; d6690055 03dab0f7
	v_maxmin_num_f32 v87, -4.0, v89, 4.0                        ; d6690057 03dab2f7
	v_maxmin_num_f32 v161, -4.0, v94, 4.0                       ; d66900a1 03dabcf7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v95, 4.0                       ; d66900a3 03dabef7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v96, 4.0                       ; d66900a5 03dac0f7
	v_fma_mix_f32 v152, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bfeaeff 3728ab28
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v97, 4.0                       ; d66900a7 03dac2f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 ; c843419f 9f9f3b9e 3f650000
	v_dual_fmaak_f32 v156, v156, v155, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c843379c 9c993599 3f650000
	v_maxmin_num_f32 v169, -4.0, v98, 4.0                       ; d66900a9 03dac4f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v99, 4.0                       ; d66900ab 03dac6f7
	v_dual_fmaak_f32 v152, v152, v87, 0x3f650000 :: v_dual_fmaak_f32 v85, v85, v86, 0x3f650000 ; c842af98 9854ad55 3f650000
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c84349a3 a3a343a2 3f650000
	v_dual_mul_f32 v93, v93, v159 :: v_dual_mul_f32 v92, v92, v158 ; c8c73f5d 5d5d3d5c
	v_maxmin_num_f32 v173, -4.0, v100, 4.0                      ; d66900ad 03dac8f7
	v_dual_mul_f32 v91, v91, v156 :: v_dual_mul_f32 v90, v90, v153 ; c8c7395b 5b5b335a
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_maxmin_num_f32 v175, -4.0, v101, 4.0                      ; d66900af 03dacaf7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_mul_f32 v89, v89, v152 :: v_dual_mul_f32 v88, v88, v85 ; c8c73159 5958ab58
	v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 ; c8434da5 a5a94fa8 3f650000
	v_dual_mul_f32 v95, v95, v163 :: v_dual_mul_f32 v94, v94, v162 ; c8c7475f 5f5f455e
	v_maxmin_num_f32 v177, -4.0, v102, 4.0                      ; d66900b1 03daccf7
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_maxmin_num_f32 v179, -4.0, v103, 4.0                      ; d66900b3 03dacef7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v171, 0x3f650000 ; c84355a9 a9ad57ac 3f650000
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_dual_mul_f32 v97, v97, v168 :: v_dual_mul_f32 v96, v96, v165 ; c8c75161 61614b60
	v_maxmin_num_f32 v181, -4.0, v104, 4.0                      ; d66900b5 03dad0f7
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v183, -4.0, v105, 4.0                      ; d66900b7 03dad2f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v173, 0x3f650000 ; c84361af afaf5bae 3f650000
	v_maxmin_num_f32 v185, -4.0, v106, 4.0                      ; d66900b9 03dad4f7
	v_dual_mul_f32 v99, v99, v172 :: v_dual_mul_f32 v98, v98, v169 ; c8c75963 63635362
	v_maxmin_num_f32 v187, -4.0, v107, 4.0                      ; d66900bb 03dad6f7
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v108, 4.0                      ; d66900bd 03dad8f7
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_dual_fmaak_f32 v179, v179, v180, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v177, 0x3f650000 ; c84369b3 b3b363b2 3f650000
	v_dual_mul_f32 v101, v101, v175 :: v_dual_mul_f32 v100, v100, v174 ; c8c75f65 65655d64
	v_maxmin_num_f32 v191, -4.0, v109, 4.0                      ; d66900bf 03dadaf7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v27, -4.0, v110, 4.0                       ; d669001b 03dadcf7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_maxmin_num_f32 v65, -4.0, v111, 4.0                       ; d6690041 03dadef7
	v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 ; c8436db5 b5b96fb8 3f650000
	v_dual_mul_f32 v103, v103, v179 :: v_dual_mul_f32 v102, v102, v178 ; c8c76767 67676566
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_fma_mix_f32 v6, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206206 0bff7eff 3728ab28
	v_maxmin_num_f32 v67, -4.0, v112, 4.0                       ; d6690043 03dae0f7
	v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 ; c84375b9 b9bd77bc 3f650000
	v_fma_mix_f32 v60, 0xab28, |v27|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623c 0bfe36ff 3728ab28
	v_maxmin_num_f32 v85, -4.0, v113, 4.0                       ; d6690055 03dae2f7
	v_fma_mix_f32 v66, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206242 0bfe82ff 3728ab28
	v_dual_mul_f32 v105, v105, v184 :: v_dual_mul_f32 v104, v104, v181 ; c8c77169 69696b68
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v87, -4.0, v114, 4.0                       ; d6690057 03dae4f7
	v_dual_fmaak_f32 v191, v191, v6, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c8420dbf bfbf7bbe 3f650000
	v_fma_mix_f32 v84, 0xab28, |v67|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206254 0bfe86ff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v115, 4.0                       ; d6690059 03dae6f7
	v_dual_mul_f32 v107, v107, v188 :: v_dual_mul_f32 v106, v106, v185 ; c8c7796b 6b6b736a
	v_fma_mix_f32 v86, 0xab28, |v85|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206256 0bfeaaff 3728ab28
	v_dual_fmaak_f32 v65, v65, v66, 0x3f650000 :: v_dual_fmaak_f32 v60, v60, v27, 0x3f650000 ; c8428541 413c373c 3f650000
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v91, -4.0, v116, 4.0                       ; d669005b 03dae8f7
	v_maxmin_num_f32 v93, -4.0, v117, 4.0                       ; d669005d 03daeaf7
	v_fma_mix_f32 v88, 0xab28, |v87|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfeaeff 3728ab28
	v_dual_mul_f32 v109, v109, v191 :: v_dual_mul_f32 v108, v108, v190 ; c8c77f6d 6d6d7d6c
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v95, -4.0, v118, 4.0                       ; d669005f 03daecf7
	v_dual_fmaak_f32 v67, v67, v84, 0x3f650000 :: v_dual_fmaak_f32 v86, v86, v85, 0x3f650000 ; c842a943 4356ab56 3f650000
	v_dual_mul_f32 v111, v111, v65 :: v_dual_mul_f32 v110, v110, v60 ; c8c6836f 6f6e796e
	v_maxmin_num_f32 v97, -4.0, v119, 4.0                       ; d6690061 03daeef7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[28:29], v[120:127] ; cc464078 1de23916
	v_dual_fmaak_f32 v87, v87, v88, 0x3f650000 :: v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 ; c842b157 575ab35a 3f650000
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_dual_mul_f32 v113, v113, v86 :: v_dual_mul_f32 v112, v112, v67 ; c8c6ad71 71708770
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842bd5d 5d5cb75c 3f650000
	v_dual_mul_f32 v115, v115, v90 :: v_dual_mul_f32 v114, v114, v87 ; c8c6b573 7372af72
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v97, v97, v98, 0x3f650000 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c842c561 6160bf60 3f650000
	v_dual_mul_f32 v117, v117, v93 :: v_dual_mul_f32 v116, v116, v92 ; c8c6bb75 7574b974
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[12:13], v[128:135] ; cc464080 1e021916
	v_maxmin_num_f32 v103, -4.0, v122, 4.0                      ; d6690067 03daf4f7
	v_maxmin_num_f32 v105, -4.0, v123, 4.0                      ; d6690069 03daf6f7
	v_maxmin_num_f32 v101, -4.0, v121, 4.0                      ; d6690065 03daf2f7
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v99, -4.0, v120, 4.0                       ; d6690063 03daf0f7
	v_dual_mul_f32 v119, v119, v97 :: v_dual_mul_f32 v118, v118, v96 ; c8c6c377 7776c176
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[22:23], v[16:17], v[136:143] ; cc464088 1e222116
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[22:23], v[34:35], v[144:151] ; cc464090 1e424516
	v_maxmin_num_f32 v107, -4.0, v124, 4.0                      ; d669006b 03daf8f7
	v_maxmin_num_f32 v109, -4.0, v125, 4.0                      ; d669006d 03dafaf7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v111, -4.0, v126, 4.0                      ; d669006f 03dafcf7
	v_maxmin_num_f32 v113, -4.0, v127, 4.0                      ; d6690071 03dafef7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_maxmin_num_f32 v115, -4.0, v128, 4.0                      ; d6690073 03db00f7
	v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 ; c842d167 676ad36a 3f650000
	v_maxmin_num_f32 v117, -4.0, v129, 4.0                      ; d6690075 03db02f7
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v101, 0x3f650000 ; c842c963 6366cb66 3f650000
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v130, 4.0                      ; d6690077 03db04f7
	v_dual_fmaak_f32 v109, v109, v110, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 ; c842dd6d 6d6cd76c 3f650000
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_dual_mul_f32 v123, v123, v106 :: v_dual_mul_f32 v122, v122, v103 ; c8c6d57b 7b7acf7a
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_dual_mul_f32 v121, v121, v102 :: v_dual_mul_f32 v120, v120, v99 ; c8c6cd79 7978c778
	v_dual_fmaak_f32 v113, v113, v114, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v111, 0x3f650000 ; c842e571 7170df70 3f650000
	v_dual_mul_f32 v125, v125, v109 :: v_dual_mul_f32 v124, v124, v108 ; c8c6db7d 7d7cd97c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_fmaak_f32 v115, v115, v116, 0x3f650000 :: v_dual_fmaak_f32 v118, v118, v117, 0x3f650000 ; c842e973 7376eb76 3f650000
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v121, -4.0, v131, 4.0                      ; d6690079 03db06f7
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v123, -4.0, v132, 4.0                      ; d669007b 03db08f7
	v_dual_mul_f32 v127, v127, v113 :: v_dual_mul_f32 v126, v126, v112 ; c8c6e37f 7f7ee17e
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v125, -4.0, v133, 4.0                      ; d669007d 03db0af7
	v_dual_mul_f32 v129, v129, v118 :: v_dual_mul_f32 v128, v128, v115 ; c8c6ed81 8180e780
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v127, -4.0, v134, 4.0                      ; d669007f 03db0cf7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_maxmin_num_f32 v129, -4.0, v135, 4.0                      ; d6690081 03db0ef7
	v_dual_fmaak_f32 v119, v119, v120, 0x3f650000 :: v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 ; c842f177 777af37a 3f650000
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_dual_fmaak_f32 v125, v125, v126, 0x3f650000 :: v_dual_fmaak_f32 v124, v124, v123, 0x3f650000 ; c842fd7d 7d7cf77c 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_mul_f32 v131, v131, v122 :: v_dual_mul_f32 v130, v130, v119 ; c8c6f583 8382ef82
	v_dual_mul_f32 v133, v133, v125 :: v_dual_mul_f32 v132, v132, v124 ; c8c6fb85 8584f984
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v131, -4.0, v136, 4.0                      ; d6690083 03db10f7
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v133, -4.0, v137, 4.0                      ; d6690085 03db12f7
	v_maxmin_num_f32 v153, -4.0, v140, 4.0                      ; d6690099 03db18f7
	v_maxmin_num_f32 v155, -4.0, v141, 4.0                      ; d669009b 03db1af7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 ; c8430581 8180ff80 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v157, -4.0, v142, 4.0                      ; d669009d 03db1cf7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_maxmin_num_f32 v159, -4.0, v143, 4.0                      ; d669009f 03db1ef7
	v_dual_mul_f32 v135, v135, v129 :: v_dual_mul_f32 v134, v134, v128 ; c8c70387 87870186
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v135, -4.0, v138, 4.0                      ; d6690087 03db14f7
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v144, 4.0                      ; d66900a1 03db20f7
	v_maxmin_num_f32 v163, -4.0, v145, 4.0                      ; d66900a3 03db22f7
	v_dual_mul_f32 v141, v141, v155 :: v_dual_mul_f32 v140, v140, v154 ; c8c7378d 8d8d358c
	v_dual_fmaak_f32 v159, v159, v160, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 ; c843419f 9f9f3b9e 3f650000
	v_maxmin_num_f32 v165, -4.0, v146, 4.0                      ; d66900a5 03db24f7
	v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 :: v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 ; c8430b86 86830983 3f650000
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v147, 4.0                      ; d66900a7 03db26f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v159 :: v_dual_mul_f32 v142, v142, v158 ; c8c73f8f 8f8f3d8e
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_mul_f32 v137, v137, v134 :: v_dual_mul_f32 v136, v136, v131 ; c8c70d89 89890788
	v_maxmin_num_f32 v169, -4.0, v148, 4.0                      ; d66900a9 03db28f7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v149, 4.0                      ; d66900ab 03db2af7
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 ; c84345a1 a1a547a4 3f650000
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_maxmin_num_f32 v173, -4.0, v150, 4.0                      ; d66900ad 03db2cf7
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_maxmin_num_f32 v137, -4.0, v139, 4.0                      ; d6690089 03db16f7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 ; c8434da5 a5a94fa8 3f650000
	v_maxmin_num_f32 v175, -4.0, v151, 4.0                      ; d66900af 03db2ef7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_mul_f32 v145, v145, v164 :: v_dual_mul_f32 v144, v144, v161 ; c8c74991 91914390
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[32:33], 0 ; cc464060 1a024144
	v_fma_mix_f32 v152, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff12ff 3728ab28
	v_dual_mul_f32 v147, v147, v168 :: v_dual_mul_f32 v146, v146, v165 ; c8c75193 93934b92
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 ; c84359ab abab53aa 3f650000
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_dual_fmaak_f32 v152, v152, v137, 0x3f650000 :: v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 ; c8431398 98871187 3f650000
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v173, 0x3f650000 ; c84361af afaf5bae 3f650000
	v_dual_mul_f32 v149, v149, v171 :: v_dual_mul_f32 v148, v148, v170 ; c8c75795 95955594
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[72:73], v[28:29], v[96:103] ; cc464060 1d823948
	v_dual_mul_f32 v139, v139, v152 :: v_dual_mul_f32 v138, v138, v135 ; c8c7318b 8b8b0f8a
	v_dual_mul_f32 v151, v151, v175 :: v_dual_mul_f32 v150, v150, v174 ; c8c75f97 97975d96
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[68:69], v[30:31], 0 ; cc464068 1a023d44
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[68:69], v[14:15], 0 ; cc464070 1a021d44
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[18:19], 0 ; cc464078 1a022544
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_maxmin_num_f32 v181, -4.0, v98, 4.0                       ; d66900b5 03dac4f7
	v_maxmin_num_f32 v177, -4.0, v96, 4.0                       ; d66900b1 03dac0f7
	v_maxmin_num_f32 v183, -4.0, v99, 4.0                       ; d66900b7 03dac6f7
	v_maxmin_num_f32 v179, -4.0, v97, 4.0                       ; d66900b3 03dac2f7
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[72:73], v[12:13], v[104:111] ; cc464068 1da21948
	v_maxmin_num_f32 v185, -4.0, v100, 4.0                      ; d66900b9 03dac8f7
	v_maxmin_num_f32 v187, -4.0, v101, 4.0                      ; d66900bb 03dacaf7
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[72:73], v[16:17], v[112:119] ; cc464070 1dc22148
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[72:73], v[34:35], v[120:127] ; cc464078 1de24548
	v_maxmin_num_f32 v189, -4.0, v102, 4.0                      ; d66900bd 03daccf7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v103, 4.0                      ; d66900bf 03dacef7
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c8436fb8 b8b56db5 3f650000
	v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 ; c84367b4 b4b165b1 3f650000
	v_maxmin_num_f32 v27, -4.0, v104, 4.0                       ; d669001b 03dad0f7
	v_maxmin_num_f32 v65, -4.0, v105, 4.0                       ; d6690041 03dad2f7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_maxmin_num_f32 v73, -4.0, v106, 4.0                       ; d6690049 03dad4f7
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84379bb bbbb73ba 3f650000
	v_fma_mix_f32 v6, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206206 0bff7eff 3728ab28
	v_dual_mul_f32 v99, v99, v184 :: v_dual_mul_f32 v98, v98, v181 ; c8c77163 63636b62
	v_maxmin_num_f32 v91, -4.0, v107, 4.0                       ; d669005b 03dad6f7
	v_dual_mul_f32 v97, v97, v180 :: v_dual_mul_f32 v96, v96, v177 ; c8c76961 61616360
	v_fma_mix_f32 v60, 0xab28, |v27|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623c 0bfe36ff 3728ab28
	v_fma_mix_f32 v72, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206248 0bfe82ff 3728ab28
	v_maxmin_num_f32 v93, -4.0, v108, 4.0                       ; d669005d 03dad8f7
	v_fma_mix_f32 v90, 0xab28, |v73|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfe92ff 3728ab28
	v_dual_mul_f32 v101, v101, v187 :: v_dual_mul_f32 v100, v100, v186 ; c8c77765 65657564
	v_dual_fmaak_f32 v191, v191, v6, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c8420dbf bfbf7bbe 3f650000
	v_maxmin_num_f32 v95, -4.0, v109, 4.0                       ; d669005f 03dadaf7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694044
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_dual_fmaak_f32 v27, v27, v60, 0x3f650000 :: v_dual_fmaak_f32 v72, v72, v65, 0x3f650000 ; c842791b 1b488348 3f650000
	v_maxmin_num_f32 v97, -4.0, v110, 4.0                       ; d6690061 03dadcf7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_maxmin_num_f32 v99, -4.0, v111, 4.0                       ; d6690063 03dadef7
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_mul_f32 v103, v103, v191 :: v_dual_mul_f32 v102, v102, v190 ; c8c77f67 67677d66
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
	v_dual_fmaak_f32 v73, v73, v90, 0x3f650000 :: v_dual_fmaak_f32 v92, v92, v91, 0x3f650000 ; c842b549 495cb75c 3f650000
	v_maxmin_num_f32 v101, -4.0, v112, 4.0                      ; d6690065 03dae0f7
	v_dual_mul_f32 v105, v105, v72 :: v_dual_mul_f32 v104, v104, v27 ; c8c69169 69683768
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
(invalid instruction)                                        ; d7694045
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v103, -4.0, v113, 4.0                      ; d6690067 03dae2f7
	v_dual_fmaak_f32 v95, v95, v96, 0x3f650000 :: v_dual_fmaak_f32 v94, v94, v93, 0x3f650000 ; c842c15f 5f5ebb5e 3f650000
	v_dual_mul_f32 v107, v107, v92 :: v_dual_mul_f32 v106, v106, v73 ; c8c6b96b 6b6a936a
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v105, -4.0, v114, 4.0                      ; d6690069 03dae4f7
	v_dual_fmaak_f32 v99, v99, v100, 0x3f650000 :: v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 ; c842c963 6362c362 3f650000
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_mul_f32 v109, v109, v95 :: v_dual_mul_f32 v108, v108, v94 ; c8c6bf6d 6d6cbd6c
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v107, -4.0, v115, 4.0                      ; d669006b 03dae6f7
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_mul_f32 v111, v111, v99 :: v_dual_mul_f32 v110, v110, v98 ; c8c6c76f 6f6ec56e
	v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 ; c842cd65 6568cf68 3f650000
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_maxmin_num_f32 v109, -4.0, v116, 4.0                      ; d669006d 03dae8f7
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v111, -4.0, v117, 4.0                      ; d669006f 03daeaf7
	v_dual_mul_f32 v113, v113, v104 :: v_dual_mul_f32 v112, v112, v101 ; c8c6d171 7170cb70
	v_fma_mix_f32 v110, 0xab28, |v109|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626e 0bfedaff 3728ab28
	v_dual_fmaak_f32 v105, v105, v106, 0x3f650000 :: v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 ; c842d569 696cd76c 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v113, -4.0, v118, 4.0                      ; d6690071 03daecf7
	v_fma_mix_f32 v112, 0xab28, |v111|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfedeff 3728ab28
	v_dual_mul_f32 v115, v115, v108 :: v_dual_mul_f32 v114, v114, v105 ; c8c6d973 7372d372
	v_dual_fmaak_f32 v111, v111, v112, 0x3f650000 :: v_dual_fmaak_f32 v110, v110, v109, 0x3f650000 ; c842e16f 6f6edb6e 3f650000
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v115, -4.0, v119, 4.0                      ; d6690073 03daeef7
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v122, 4.0                      ; d6690081 03daf4f7
	v_maxmin_num_f32 v131, -4.0, v123, 4.0                      ; d6690083 03daf6f7
	v_dual_mul_f32 v117, v117, v111 :: v_dual_mul_f32 v116, v116, v110 ; c8c6df75 7574dd74
	v_maxmin_num_f32 v133, -4.0, v124, 4.0                      ; d6690085 03daf8f7
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v125, 4.0                      ; d6690087 03dafaf7
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v117, -4.0, v120, 4.0                      ; d6690075 03daf0f7
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
	v_maxmin_num_f32 v137, -4.0, v126, 4.0                      ; d6690089 03dafcf7
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v127, 4.0                      ; d669008b 03dafef7
	v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v131, 0x3f650000 ; c8430581 81850784 3f650000
	v_dual_fmaak_f32 v115, v115, v116, 0x3f650000 :: v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 ; c842e973 7372e372 3f650000
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_dual_fmaak_f32 v135, v135, v136, 0x3f650000 :: v_dual_fmaak_f32 v134, v134, v133, 0x3f650000 ; c8431187 87870b86 3f650000
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[70:71], v[32:33], 0 ; cc464060 1a024146
	v_dual_mul_f32 v123, v123, v132 :: v_dual_mul_f32 v122, v122, v129 ; c8c7097b 7b7b037a
	v_dual_mul_f32 v119, v119, v115 :: v_dual_mul_f32 v118, v118, v114 ; c8c6e777 7776e576
	v_dual_mul_f32 v125, v125, v135 :: v_dual_mul_f32 v124, v124, v134 ; c8c70f7d 7d7d0d7c
	v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 :: v_dual_fmaak_f32 v138, v138, v137, 0x3f650000 ; c843198b 8b8b138a 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v119, -4.0, v121, 4.0                      ; d6690077 03daf2f7
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_mul_f32 v127, v127, v139 :: v_dual_mul_f32 v126, v126, v138 ; c8c7177f 7f7f157e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[74:75], v[28:29], v[96:103] ; cc464060 1d82394a
	v_fma_mix_f32 v128, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfeeeff 3728ab28
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[30:31], 0 ; cc464068 1a023d46
	v_dual_fmaak_f32 v128, v128, v119, 0x3f650000 :: v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 ; c842ef80 8074ed75 3f650000
	v_maxmin_num_f32 v143, -4.0, v97, 4.0                       ; d669008f 03dac2f7
	v_maxmin_num_f32 v145, -4.0, v98, 4.0                       ; d6690091 03dac4f7
	v_maxmin_num_f32 v147, -4.0, v99, 4.0                       ; d6690093 03dac6f7
	v_maxmin_num_f32 v141, -4.0, v96, 4.0                       ; d669008d 03dac0f7
	v_dual_mul_f32 v121, v121, v128 :: v_dual_mul_f32 v120, v120, v117 ; c8c70179 7978eb78
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[14:15], 0 ; cc464070 1a021d46
	v_maxmin_num_f32 v149, -4.0, v100, 4.0                      ; d6690095 03dac8f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[74:75], v[12:13], v[104:111] ; cc464068 1da2194a
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[70:71], v[18:19], 0 ; cc464078 1a022546
	v_maxmin_num_f32 v151, -4.0, v101, 4.0                      ; d6690097 03dacaf7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8432794 94912591 3f650000
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v142, 0x3f650000 ; c8431f90 908d1d8d 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[74:75], v[16:17], v[112:119] ; cc464070 1dc2214a
	v_maxmin_num_f32 v153, -4.0, v102, 4.0                      ; d6690099 03daccf7
	v_maxmin_num_f32 v155, -4.0, v103, 4.0                      ; d669009b 03dacef7
	v_maxmin_num_f32 v157, -4.0, v104, 4.0                      ; d669009d 03dad0f7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_dual_mul_f32 v99, v99, v148 :: v_dual_mul_f32 v98, v98, v145 ; c8c72963 63632362
	v_dual_mul_f32 v97, v97, v144 :: v_dual_mul_f32 v96, v96, v141 ; c8c72161 61611b60
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[74:75], v[34:35], v[120:127] ; cc464078 1de2454a
	v_maxmin_num_f32 v159, -4.0, v105, 4.0                      ; d669009f 03dad2f7
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v106, 4.0                      ; d66900a1 03dad4f7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_dual_fmaak_f32 v151, v151, v152, 0x3f650000 :: v_dual_fmaak_f32 v150, v150, v149, 0x3f650000 ; c8433197 97972b96 3f650000
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v163, -4.0, v107, 4.0                      ; d66900a3 03dad6f7
	v_maxmin_num_f32 v165, -4.0, v108, 4.0                      ; d66900a5 03dad8f7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v109, 4.0                      ; d66900a7 03dadaf7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c843399b 9b9b339a 3f650000
	v_dual_mul_f32 v101, v101, v151 :: v_dual_mul_f32 v100, v100, v150 ; c8c72f65 65652d64
	v_maxmin_num_f32 v169, -4.0, v110, 4.0                      ; d66900a9 03dadcf7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v111, 4.0                      ; d66900ab 03dadef7
	v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 ; c8433d9d 9da13fa0 3f650000
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_dual_mul_f32 v103, v103, v155 :: v_dual_mul_f32 v102, v102, v154 ; c8c73767 67673566
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v173, -4.0, v112, 4.0                      ; d66900ad 03dae0f7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v163, 0x3f650000 ; c84345a1 a1a547a4 3f650000
	v_maxmin_num_f32 v175, -4.0, v113, 4.0                      ; d66900af 03dae2f7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_mul_f32 v105, v105, v160 :: v_dual_mul_f32 v104, v104, v157 ; c8c74169 69693b68
	v_dual_fmaak_f32 v167, v167, v168, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 ; c84351a7 a7a74ba6 3f650000
	v_maxmin_num_f32 v177, -4.0, v114, 4.0                      ; d66900b1 03dae4f7
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_maxmin_num_f32 v179, -4.0, v115, 4.0                      ; d66900b3 03dae6f7
	v_dual_mul_f32 v107, v107, v164 :: v_dual_mul_f32 v106, v106, v161 ; c8c7496b 6b6b436a
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 ; c84359ab abab53aa 3f650000
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_maxmin_num_f32 v181, -4.0, v116, 4.0                      ; d66900b5 03dae8f7
	v_dual_mul_f32 v109, v109, v167 :: v_dual_mul_f32 v108, v108, v166 ; c8c74f6d 6d6d4d6c
	v_maxmin_num_f32 v183, -4.0, v117, 4.0                      ; d66900b7 03daeaf7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
(invalid instruction)                                        ; d769404a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_maxmin_num_f32 v185, -4.0, v118, 4.0                      ; d66900b9 03daecf7
	v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 ; c8435dad adb15fb0 3f650000
	v_dual_mul_f32 v111, v111, v171 :: v_dual_mul_f32 v110, v110, v170 ; c8c7576f 6f6f556e
	v_maxmin_num_f32 v187, -4.0, v119, 4.0                      ; d66900bb 03daeef7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v120, 4.0                      ; d66900bd 03daf0f7
	v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 ; c84365b1 b1b567b4 3f650000
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v121, 4.0                      ; d66900bf 03daf2f7
	v_dual_mul_f32 v113, v113, v176 :: v_dual_mul_f32 v112, v112, v173 ; c8c76171 71715b70
(invalid instruction)                                        ; d769404b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v27, -4.0, v122, 4.0                       ; d669001b 03daf4f7
	v_dual_fmaak_f32 v183, v183, v184, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v181, 0x3f650000 ; c84371b7 b7b76bb6 3f650000
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_mul_f32 v115, v115, v180 :: v_dual_mul_f32 v114, v114, v177 ; c8c76973 73736372
	v_maxmin_num_f32 v98, -4.0, v124, 4.0                       ; d6690062 03daf8f7
	v_fma_mix_f32 v6, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206206 0bff7eff 3728ab28
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v65, -4.0, v123, 4.0                       ; d6690041 03daf6f7
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84379bb bbbb73ba 3f650000
	v_fma_mix_f32 v60, 0xab28, |v27|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20623c 0bfe36ff 3728ab28
	v_dual_mul_f32 v117, v117, v183 :: v_dual_mul_f32 v116, v116, v182 ; c8c76f75 75756d74
	v_maxmin_num_f32 v100, -4.0, v125, 4.0                      ; d6690064 03dafaf7
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v99, 0xab28, |v98|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206263 0bfec4ff 3728ab28
	v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 :: v_dual_fmaak_f32 v6, v6, v191, 0x3f650000 ; c8437dbd bd077f06 3f650000
	v_maxmin_num_f32 v102, -4.0, v126, 4.0                      ; d6690066 03dafcf7
	v_fma_mix_f32 v97, 0xab28, |v65|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206261 0bfe82ff 3728ab28
	v_maxmin_num_f32 v104, -4.0, v127, 4.0                      ; d6690068 03dafef7
	v_dual_mul_f32 v119, v119, v187 :: v_dual_mul_f32 v118, v118, v186 ; c8c77777 77777576
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_fma_mix_f32 v101, 0xab28, |v100|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206265 0bfec8ff 3728ab28
	v_mul_f32_e32 v121, v121, v6                                ; 10f20d79
	v_dual_fmaak_f32 v27, v27, v60, 0x3f650000 :: v_dual_mul_f32 v120, v120, v189 ; c846791b 1b797b78 3f650000
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_fma_mix_f32 v105, 0xab28, |v104|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206269 0bfed0ff 3728ab28
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
(invalid instruction)                                        ; d7690060
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_fmaak_f32 v99, v99, v98, 0x3f650000 :: v_dual_mul_f32 v122, v122, v27 ; c846c563 637a377a 3f650000
	v_dual_fmaak_f32 v103, v103, v102, 0x3f650000 :: v_dual_fmaak_f32 v104, v104, v105, 0x3f650000 ; c842cd67 6768d368 3f650000
	v_dual_mul_f32 v124, v124, v99 :: v_dual_fmaak_f32 v97, v97, v65, 0x3f650000 ; c8c2c77c 7c608361 3f650000
	v_dual_mul_f32 v127, v127, v104 :: v_dual_mul_f32 v126, v126, v103 ; c8c6d17f 7f7ecf7e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[76:77], v[32:33], 0 ; cc464068 1a02414c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[76:77], v[30:31], 0 ; cc464070 1a023d4c
	v_dual_mul_f32 v123, v97, v123 :: v_dual_fmaak_f32 v100, v100, v101, 0x3f650000 ; c8c2f761 7b64cb64 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[18:19], 0 ; cc464080 1a02254c
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[80:81], v[28:29], v[104:111] ; cc464068 1da23950
(invalid instruction)                                        ; d7694060
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[80:81], v[12:13], v[112:119] ; cc464070 1dc21950
	v_maxmin_num_f32 v140, -4.0, v106, 4.0                      ; d669008c 03dad4f7
	v_maxmin_num_f32 v144, -4.0, v108, 4.0                      ; d6690090 03dad8f7
	v_maxmin_num_f32 v136, -4.0, v104, 4.0                      ; d6690088 03dad0f7
	v_maxmin_num_f32 v138, -4.0, v105, 4.0                      ; d669008a 03dad2f7
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[34:35], v[128:135] ; cc464080 1e024550
	v_maxmin_num_f32 v142, -4.0, v107, 4.0                      ; d669008e 03dad6f7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v109, 4.0                      ; d6690092 03dadaf7
	v_maxmin_num_f32 v148, -4.0, v110, 4.0                      ; d6690094 03dadcf7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v111, 4.0                      ; d6690096 03dadef7
	v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 :: v_dual_mul_f32 v125, v125, v100 ; c8471388 887cc97d 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v112, 4.0                      ; d6690098 03dae0f7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_mul_f32 v104, v104, v136 :: v_dual_fmaak_f32 v139, v139, v138, 0x3f650000 ; c8c31168 688b158b 3f650000
	v_maxmin_num_f32 v154, -4.0, v113, 4.0                      ; d669009a 03dae2f7
(invalid instruction)                                        ; d7690061
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694061
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[76:77], v[14:15], 0 ; cc464078 1a021d4c
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c8432792 92952995 3f650000
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v114, 4.0                      ; d669009c 03dae4f7
	v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 :: v_dual_mul_f32 v105, v105, v139 ; c8471b8c 8c691769 3f650000
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_maxmin_num_f32 v160, -4.0, v116, 4.0                      ; d66900a0 03dae8f7
	v_maxmin_num_f32 v158, -4.0, v115, 4.0                      ; d669009e 03dae6f7
	v_dual_fmaak_f32 v150, v150, v151, 0x3f650000 :: v_dual_mul_f32 v109, v109, v146 ; c8472f96 966d256d 3f650000
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_dual_mul_f32 v106, v140, v106 :: v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 ; c8c2d58c 6a912191 3f650000
	v_maxmin_num_f32 v162, -4.0, v117, 4.0                      ; d66900a2 03daeaf7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v118, 4.0                      ; d66900a4 03daecf7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[80:81], v[16:17], v[120:127] ; cc464078 1de22150
	v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 :: v_dual_mul_f32 v111, v111, v150 ; c8473398 986f2d6f 3f650000
	v_dual_mul_f32 v108, v108, v145 :: v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 ; c8c3236c 6c8f1d8f 3f650000
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v119, 4.0                      ; d66900a6 03daeef7
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_mul_f32 v112, v112, v152 ; c847359b 9b713170 3f650000
	v_dual_mul_f32 v110, v110, v149 :: v_dual_mul_f32 v107, v107, v143 ; c8c72b6e 6e6b1f6b
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 ; c84347a2 a2a549a5 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v120, 4.0                      ; d66900a8 03daf0f7
	v_maxmin_num_f32 v170, -4.0, v121, 4.0                      ; d66900aa 03daf2f7
	v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 :: v_dual_mul_f32 v113, v113, v155 ; c8473b9c 9c713771 3f650000
	v_maxmin_num_f32 v172, -4.0, v122, 4.0                      ; d66900ac 03daf4f7
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_maxmin_num_f32 v176, -4.0, v124, 4.0                      ; d66900b0 03daf8f7
	v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 :: v_dual_mul_f32 v117, v117, v162 ; c8474fa6 a6754575 3f650000
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_dual_fmaak_f32 v161, v160, v161, 0x3f650000 :: v_dual_mul_f32 v114, v114, v156 ; c84743a0 a1733972 3f650000
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v174, -4.0, v123, 4.0                      ; d66900ae 03daf6f7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v178, -4.0, v125, 4.0                      ; d66900b2 03dafaf7
	v_maxmin_num_f32 v180, -4.0, v126, 4.0                      ; d66900b4 03dafcf7
	v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 :: v_dual_mul_f32 v119, v119, v166 ; c84753a8 a8774d77 3f650000
	v_dual_mul_f32 v116, v116, v161 :: v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 ; c8c34374 749f3d9f 3f650000
	v_maxmin_num_f32 v182, -4.0, v127, 4.0                      ; d66900b6 03dafef7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v184, -4.0, v128, 4.0                      ; d66900b8 03db00f7
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_mul_f32 v120, v120, v168 ; c84755ab ab795178 3f650000
	v_dual_mul_f32 v118, v118, v165 :: v_dual_mul_f32 v115, v115, v159 ; c8c74b76 76733f73
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_maxmin_num_f32 v186, -4.0, v129, 4.0                      ; d66900ba 03db02f7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 ; c84367b2 b2b569b5 3f650000
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	buffer_load_b128 v[100:103], v5, s[16:19], null offen offset:3072 ; c405c07c 40802064 000c0005
	v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 :: v_dual_mul_f32 v121, v121, v171 ; c8475bac ac795779 3f650000
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v188, -4.0, v130, 4.0                      ; d66900bc 03db04f7
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	buffer_load_b128 v[108:111], v5, s[16:19], null offen offset:3584 ; c405c07c 4080206c 000e0005
	v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 :: v_dual_mul_f32 v125, v125, v178 ; c8476fb6 b67d657d 3f650000
	v_maxmin_num_f32 v190, -4.0, v131, 4.0                      ; d66900be 03db06f7
(invalid instruction)                                        ; d7690062
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_fmaak_f32 v177, v176, v177, 0x3f650000 :: v_dual_mul_f32 v122, v122, v172 ; c84763b0 b17b597a 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_maxmin_num_f32 v6, -4.0, v133, 4.0                        ; d6690006 03db0af7
	v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 :: v_dual_mul_f32 v127, v127, v182 ; c84773b8 b87f6d7f 3f650000
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_dual_mul_f32 v124, v124, v177 :: v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 ; c8c3637c 7caf5daf 3f650000
	v_fmaak_f32 v188, v188, v189, 0x3f650000                    ; 5b797bbc 3f650000
	v_maxmin_num_f32 v60, -4.0, v134, 4.0                       ; d669003c 03db0cf7
	v_fma_mix_f32 v27, 0xab28, |v6|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe0cff 3728ab28
	v_maxmin_num_f32 v106, -4.0, v135, 4.0                      ; d669006a 03db0ef7
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_mul_f32 v128, v128, v184 ; c84775bb bb817180 3f650000
	v_fmaak_f32 v191, v191, v190, 0x3f650000                    ; 5b7f7dbf 3f650000
(invalid instruction)                                        ; d7690063
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_mul_f32 v126, v126, v181 :: v_dual_mul_f32 v123, v123, v175 ; c8c76b7e 7e7b5f7b
	v_fma_mix_f32 v65, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe78ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[78:79], v[32:33], 0 ; cc464070 1a02414e
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_dual_mul_f32 v130, v130, v188 :: v_dual_mul_f32 v129, v129, v187 ; c8c77982 82817781
	v_mul_f32_e32 v131, v131, v191                              ; 11077f83
	v_maxmin_num_f32 v191, -4.0, v132, 4.0                      ; d66900bf 03db08f7
(invalid instruction)                                        ; d7694063
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7694062
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_fmaak_f32 v65, v65, v60, 0x3f650000 :: v_dual_fmaak_f32 v106, v106, v107, 0x3f650000 ; c8427941 416ad76a 3f650000
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v135, v135, v106 :: v_dual_mul_f32 v134, v134, v65 ; c8c6d587 87868386
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[28:29], v[112:119] ; cc464070 1dc23952
	v_dual_fmaak_f32 v5, v191, v5, 0x3f650000 :: v_dual_fmaak_f32 v6, v6, v27, 0x3f650000 ; c8420bbf 05063706 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[78:79], v[30:31], 0 ; cc464078 1a023d4e
	v_dual_mul_f32 v133, v133, v6 :: v_dual_mul_f32 v132, v132, v5 ; c8c60d85 85840b84
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[78:79], v[18:19], 0 ; cc464088 1a02254e
	v_maxmin_num_f32 v146, -4.0, v113, 4.0                      ; d6690092 03dae2f7
	v_maxmin_num_f32 v144, -4.0, v112, 4.0                      ; d6690090 03dae0f7
	v_maxmin_num_f32 v148, -4.0, v114, 4.0                      ; d6690094 03dae4f7
	v_maxmin_num_f32 v150, -4.0, v115, 4.0                      ; d6690096 03dae6f7
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[78:79], v[14:15], 0 ; cc464080 1a021d4e
	v_maxmin_num_f32 v152, -4.0, v116, 4.0                      ; d6690098 03dae8f7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[82:83], v[12:13], v[120:127] ; cc464078 1de21952
	v_maxmin_num_f32 v154, -4.0, v117, 4.0                      ; d669009a 03daeaf7
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[82:83], v[34:35], v[136:143] ; cc464088 1e224552
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v118, 4.0                      ; d669009c 03daecf7
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[16:17], v[128:135] ; cc464080 1e022152
	v_maxmin_num_f32 v158, -4.0, v119, 4.0                      ; d669009e 03daeef7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v147, v147, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432593 93912390 3f650000
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8432d97 97952b94 3f650000
	v_maxmin_num_f32 v160, -4.0, v120, 4.0                      ; d66900a0 03daf0f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v162, -4.0, v121, 4.0                      ; d66900a2 03daf2f7
	v_maxmin_num_f32 v164, -4.0, v122, 4.0                      ; d66900a4 03daf4f7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v153, v153, v152, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8433199 999b379a 3f650000
	v_maxmin_num_f32 v166, -4.0, v123, 4.0                      ; d66900a6 03daf6f7
	v_dual_mul_f32 v113, v113, v147 :: v_dual_mul_f32 v112, v112, v144 ; c8c72771 71712170
	v_dual_mul_f32 v115, v115, v151 :: v_dual_mul_f32 v114, v114, v148 ; c8c72f73 73732972
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v124, 4.0                      ; d66900a8 03daf8f7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_fmaak_f32 v158, v158, v159, 0x3f650000 ; c843399d 9d9f3f9e 3f650000
	v_maxmin_num_f32 v170, -4.0, v125, 4.0                      ; d66900aa 03dafaf7
	v_dual_mul_f32 v117, v117, v154 :: v_dual_mul_f32 v116, v116, v153 ; c8c73575 75753374
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_dual_fmaak_f32 v163, v163, v162, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c84345a3 a3a143a0 3f650000
	v_maxmin_num_f32 v172, -4.0, v126, 4.0                      ; d66900ac 03dafcf7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v127, 4.0                      ; d66900ae 03dafef7
	v_dual_mul_f32 v119, v119, v158 :: v_dual_mul_f32 v118, v118, v157 ; c8c73d77 77773b76
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v164, v164, v165, 0x3f650000 ; c8434da7 a7a54ba4 3f650000
	v_maxmin_num_f32 v176, -4.0, v128, 4.0                      ; d66900b0 03db00f7
	v_dual_mul_f32 v121, v121, v163 :: v_dual_mul_f32 v120, v120, v160 ; c8c74779 79794178
	v_maxmin_num_f32 v178, -4.0, v129, 4.0                      ; d66900b2 03db02f7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_maxmin_num_f32 v180, -4.0, v130, 4.0                      ; d66900b4 03db04f7
	v_dual_fmaak_f32 v169, v169, v168, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c84351a9 a9ab57aa 3f650000
	v_maxmin_num_f32 v182, -4.0, v131, 4.0                      ; d66900b6 03db06f7
	v_dual_mul_f32 v123, v123, v167 :: v_dual_mul_f32 v122, v122, v164 ; c8c74f7b 7b7b497a
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_fmaak_f32 v174, v174, v175, 0x3f650000 ; c84359ad adaf5fae 3f650000
	v_maxmin_num_f32 v184, -4.0, v132, 4.0                      ; d66900b8 03db08f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v186, -4.0, v133, 4.0                      ; d66900ba 03db0af7
	v_dual_mul_f32 v125, v125, v170 :: v_dual_mul_f32 v124, v124, v169 ; c8c7557d 7d7d537c
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v188, -4.0, v134, 4.0                      ; d66900bc 03db0cf7
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84365b3 b3b163b0 3f650000
	v_maxmin_num_f32 v190, -4.0, v135, 4.0                      ; d66900be 03db0ef7
	v_dual_mul_f32 v127, v127, v174 :: v_dual_mul_f32 v126, v126, v173 ; c8c75d7f 7f7f5b7e
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v181, 0x3f650000 ; c8436db7 b7b56bb4 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_mul_f32 v129, v129, v179 :: v_dual_mul_f32 v128, v128, v176 ; c8c76781 81816180
	v_maxmin_num_f32 v6, -4.0, v137, 4.0                        ; d6690006 03db12f7
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v60, -4.0, v138, 4.0                       ; d669003c 03db14f7
	v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c84371b9 b9bb77ba 3f650000
	v_dual_mul_f32 v131, v131, v183 :: v_dual_mul_f32 v130, v130, v180 ; c8c76f83 83836982
	v_maxmin_num_f32 v113, -4.0, v139, 4.0                      ; d6690071 03db16f7
(invalid instruction)                                        ; d769006a
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_fma_mix_f32 v27, 0xab28, |v6|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe0cff 3728ab28
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v191, 0x3f650000 ; c84379bd bdbf7fbe 3f650000
	v_maxmin_num_f32 v191, -4.0, v136, 4.0                      ; d66900bf 03db10f7
	v_maxmin_num_f32 v115, -4.0, v140, 4.0                      ; d6690073 03db18f7
	v_fma_mix_f32 v65, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe78ff 3728ab28
	v_dual_mul_f32 v133, v133, v186 :: v_dual_mul_f32 v132, v132, v185 ; c8c77585 85857384
	v_maxmin_num_f32 v117, -4.0, v141, 4.0                      ; d6690075 03db1af7
(invalid instruction)                                        ; d769406a
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_maxmin_num_f32 v119, -4.0, v142, 4.0                      ; d6690077 03db1cf7
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	v_maxmin_num_f32 v121, -4.0, v143, 4.0                      ; d6690079 03db1ef7
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
	v_dual_fmaak_f32 v60, v60, v65, 0x3f650000 :: v_dual_fmaak_f32 v27, v27, v6, 0x3f650000 ; c842833c 3c1a0d1b 3f650000
(invalid instruction)                                        ; d769006b
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_dual_fmaak_f32 v191, v5, v191, 0x3f650000 :: v_dual_mul_f32 v134, v134, v189 ; c8477f05 bf877b86 3f650000
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 :: v_dual_mul_f32 v137, v137, v27 ; c846e372 72883789 3f650000
	v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v115, 0x3f650000 ; c842ed75 7574e774 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_mul_f32 v136, v136, v191 :: v_dual_mul_f32 v135, v135, v190 ; c8c77f88 88877d87
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 ; c842f579 7978ef78 3f650000
	v_dual_mul_f32 v139, v139, v114 :: v_dual_mul_f32 v138, v138, v60 ; c8c6e58b 8b8a798a
	v_dual_mul_f32 v140, v140, v116 :: v_dual_mul_f32 v141, v141, v117 ; c8c6e98c 8c8ceb8d
(invalid instruction)                                        ; d769406b
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690070
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_dual_mul_f32 v143, v143, v121 :: v_dual_mul_f32 v142, v142, v120 ; c8c6f38f 8f8ef18e
(invalid instruction)                                        ; d7694070
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7690071
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7694071
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[100:101], v[30:31], 0 ; cc464080 1a023d64
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[100:101], v[18:19], 0 ; cc464090 1a022564
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[100:101], v[32:33], 0 ; cc464078 1a024164
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[100:101], v[14:15], 0 ; cc464088 1a021d64
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[108:109], v[12:13], v[128:135] ; cc464080 1e02196c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[34:35], v[144:151] ; cc464090 1e42456c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[108:109], v[28:29], v[120:127] ; cc464078 1de2396c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[16:17], v[136:143] ; cc464088 1e22216c
	v_maxmin_num_f32 v160, -4.0, v124, 4.0                      ; d66900a0 03daf8f7
	v_maxmin_num_f32 v158, -4.0, v123, 4.0                      ; d669009e 03daf6f7
	v_maxmin_num_f32 v162, -4.0, v125, 4.0                      ; d66900a2 03dafaf7
	v_maxmin_num_f32 v154, -4.0, v121, 4.0                      ; d669009a 03daf2f7
	v_maxmin_num_f32 v156, -4.0, v122, 4.0                      ; d669009c 03daf4f7
	v_maxmin_num_f32 v152, -4.0, v120, 4.0                      ; d6690098 03daf0f7
	v_maxmin_num_f32 v164, -4.0, v126, 4.0                      ; d66900a4 03dafcf7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v127, 4.0                      ; d66900a6 03dafef7
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v128, 4.0                      ; d66900a8 03db00f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v170, -4.0, v129, 4.0                      ; d66900aa 03db02f7
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v161, v161, v160, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c84341a1 a1a347a2 3f650000
	v_maxmin_num_f32 v172, -4.0, v130, 4.0                      ; d66900ac 03db04f7
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v156, v156, v157, 0x3f650000 ; c8433d9f 9f9d3b9c 3f650000
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v155, v155, v154, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c843359b 9b993398 3f650000
	v_maxmin_num_f32 v174, -4.0, v131, 4.0                      ; d66900ae 03db06f7
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_fmaak_f32 v166, v166, v167, 0x3f650000 ; c84349a5 a5a74fa6 3f650000
	v_dual_mul_f32 v125, v125, v162 :: v_dual_mul_f32 v124, v124, v161 ; c8c7457d 7d7d437c
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v132, 4.0                      ; d66900b0 03db08f7
	v_dual_mul_f32 v123, v123, v159 :: v_dual_mul_f32 v122, v122, v156 ; c8c73f7b 7b7b397a
	v_maxmin_num_f32 v178, -4.0, v133, 4.0                      ; d66900b2 03db0af7
	v_dual_mul_f32 v121, v121, v155 :: v_dual_mul_f32 v120, v120, v152 ; c8c73779 79793178
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v171, v171, v170, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c84355ab aba953a8 3f650000
	v_dual_mul_f32 v127, v127, v166 :: v_dual_mul_f32 v126, v126, v165 ; c8c74d7f 7f7f4b7e
	v_maxmin_num_f32 v180, -4.0, v134, 4.0                      ; d66900b4 03db0cf7
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v135, 4.0                      ; d66900b6 03db0ef7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694064
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v172, v172, v173, 0x3f650000 ; c8435daf afad5bac 3f650000
	v_dual_mul_f32 v129, v129, v171 :: v_dual_mul_f32 v128, v128, v168 ; c8c75781 81815180
	v_maxmin_num_f32 v184, -4.0, v136, 4.0                      ; d66900b8 03db10f7
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v186, -4.0, v137, 4.0                      ; d66900ba 03db12f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v177, v177, v176, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c84361b1 b1b367b2 3f650000
	v_maxmin_num_f32 v188, -4.0, v138, 4.0                      ; d66900bc 03db14f7
	v_dual_mul_f32 v131, v131, v175 :: v_dual_mul_f32 v130, v130, v172 ; c8c75f83 83835982
	v_maxmin_num_f32 v190, -4.0, v139, 4.0                      ; d66900be 03db16f7
(invalid instruction)                                        ; d769006c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v182, v182, v183, 0x3f650000 ; c84369b5 b5b76fb6 3f650000
	v_maxmin_num_f32 v6, -4.0, v141, 4.0                        ; d6690006 03db1af7
	v_dual_mul_f32 v133, v133, v178 :: v_dual_mul_f32 v132, v132, v177 ; c8c76585 85856384
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
(invalid instruction)                                        ; d769406c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_maxmin_num_f32 v60, -4.0, v142, 4.0                       ; d669003c 03db1cf7
	v_dual_fmaak_f32 v187, v187, v186, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84375bb bbb973b8 3f650000
	v_maxmin_num_f32 v116, -4.0, v143, 4.0                      ; d6690074 03db1ef7
	v_dual_mul_f32 v135, v135, v182 :: v_dual_mul_f32 v134, v134, v181 ; c8c76d87 87876b86
	v_fma_mix_f32 v27, 0xab28, |v6|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe0cff 3728ab28
(invalid instruction)                                        ; d769006d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v189, 0x3f650000 ; c8437dbf bfbd7bbc 3f650000
	v_maxmin_num_f32 v118, -4.0, v144, 4.0                      ; d6690076 03db20f7
	v_fma_mix_f32 v65, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe78ff 3728ab28
	v_maxmin_num_f32 v120, -4.0, v145, 4.0                      ; d6690078 03db22f7
	v_dual_mul_f32 v137, v137, v187 :: v_dual_mul_f32 v136, v136, v184 ; c8c77789 89897188
	v_fma_mix_f32 v117, 0xab28, |v116|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206275 0bfee8ff 3728ab28
(invalid instruction)                                        ; d769406d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v139, v139, v191 :: v_dual_mul_f32 v138, v138, v188 ; c8c77f8b 8b8b798a
	s_load_b128 s[20:23], s[0:1], 0x30                          ; f4004500 f8000030
	v_maxmin_num_f32 v191, -4.0, v140, 4.0                      ; d66900bf 03db18f7
	v_fma_mix_f32 v119, 0xab28, |v118|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206277 0bfeecff 3728ab28
	v_lshrrev_b32_e32 v122, 4, v0                               ; 32f40084
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_dual_fmaak_f32 v65, v65, v60, 0x3f650000 :: v_dual_fmaak_f32 v116, v116, v117, 0x3f650000 ; c8427941 4174eb74 3f650000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_lshlrev_b32_e32 v122, 3, v122                             ; 30f4f483
	v_dual_fmaak_f32 v121, v121, v120, 0x3f650000 :: v_dual_fmaak_f32 v118, v118, v119, 0x3f650000 ; c842f179 7976ef76 3f650000
	v_dual_mul_f32 v143, v143, v116 :: v_dual_mul_f32 v142, v142, v65 ; c8c6e98f 8f8e838e
(invalid instruction)                                        ; d7690072
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_maxmin_num_f32 v124, -4.0, v146, 4.0                      ; d669007c 03db24f7
	v_add_lshl_u32 v123, s8, v122, 2                            ; d647007b 020af408
	v_dual_mul_f32 v145, v145, v121 :: v_dual_mul_f32 v144, v144, v118 ; c8c6f391 9190ed90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_fmaak_f32 v124, v124, v125, 0x3f650000                    ; 5af8fb7c 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mul_f32_e32 v146, v146, v124                              ; 1124f992
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[116:119], v123, s[20:23], null offen     ; c405c07c 40802874 0000007b
	buffer_load_b128 v[124:127], v123, s[20:23], null offen offset:16 ; c405c07c 4080287c 0000107b
(invalid instruction)                                        ; d7694072
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	v_maxmin_num_f32 v128, -4.0, v147, 4.0                      ; d6690080 03db26f7
	v_maxmin_num_f32 v130, -4.0, v148, 4.0                      ; d6690082 03db28f7
(invalid instruction)                                        ; d7690078
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v132, -4.0, v149, 4.0                      ; d6690084 03db2af7
	v_maxmin_num_f32 v134, -4.0, v150, 4.0                      ; d6690086 03db2cf7
	v_maxmin_num_f32 v136, -4.0, v151, 4.0                      ; d6690088 03db2ef7
	v_dual_fmaak_f32 v5, v191, v5, 0x3f650000 :: v_dual_fmaak_f32 v6, v6, v27, 0x3f650000 ; c8420bbf 05063706 3f650000
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_mul_f32 v141, v141, v6 :: v_dual_mul_f32 v140, v140, v5 ; c8c60d8d 8d8c0b8c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[102:103], v[18:19], 0 ; cc464098 1a022566
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	v_fmaak_f32 v129, v129, v128, 0x3f650000                    ; 5b030181 3f650000
	v_add_lshl_u32 v160, s4, v1, 2                              ; d64700a0 020a0204
	buffer_load_b128 v[164:167], v160, s[16:19], null offen     ; c405c07c 408020a4 000000a0
	v_dual_fmaak_f32 v131, v131, v130, 0x3f650000 :: v_dual_fmaak_f32 v132, v132, v133, 0x3f650000 ; c8430583 83850b84 3f650000
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c8430d87 87891388 3f650000
(invalid instruction)                                        ; d7690073
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694073
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_mul_f32_e32 v147, v147, v129                              ; 11270393
	v_dual_mul_f32 v149, v149, v132 :: v_dual_mul_f32 v148, v148, v131 ; c8c70995 95950794
	v_dual_mul_f32 v151, v151, v136 :: v_dual_mul_f32 v150, v150, v135 ; c8c71197 97970f96
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[102:103], v[30:31], 0 ; cc464088 1a023d66
(invalid instruction)                                        ; d7694078
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690079
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[102:103], v[32:33], 0 ; cc464080 1a024166
(invalid instruction)                                        ; d7694079
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[102:103], v[14:15], 0 ; cc464090 1a021d66
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[110:111], v[12:13], v[136:143] ; cc464088 1e22196e
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[110:111], v[16:17], v[144:151] ; cc464090 1e42216e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[12:15], v160, s[16:19], null offen offset:512 ; c405c07c 4080200c 000200a0
	buffer_load_b128 v[16:19], v160, s[16:19], null offen offset:1024 ; c405c07c 40802010 000400a0
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[110:111], v[34:35], v[152:159] ; cc464098 1e62456e
	buffer_load_b128 v[32:35], v160, s[16:19], null offen offset:1536 ; c405c07c 40802020 000600a0
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[110:111], v[28:29], v[128:135] ; cc464080 1e02396e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870241
	v_maxmin_num_f32 v169, -4.0, v130, 4.0                      ; d66900a9 03db04f7
	v_maxmin_num_f32 v161, -4.0, v128, 4.0                      ; d66900a1 03db00f7
	v_maxmin_num_f32 v171, -4.0, v131, 4.0                      ; d66900ab 03db06f7
	v_maxmin_num_f32 v163, -4.0, v129, 4.0                      ; d66900a3 03db02f7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_fma_mix_f32 v168, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff46ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3) ; bf8701d4
	v_fmaak_f32 v169, v169, v170, 0x3f650000                    ; 5b5355a9 3f650000
	v_maxmin_num_f32 v173, -4.0, v132, 4.0                      ; d66900ad 03db08f7
	v_fmaak_f32 v161, v161, v162, 0x3f650000                    ; 5b4345a1 3f650000
	v_fmaak_f32 v172, v172, v171, 0x3f650000                    ; 5b5957ac 3f650000
	v_fmaak_f32 v168, v168, v163, 0x3f650000                    ; 5b5147a8 3f650000
	v_mul_f32_e32 v128, v128, v161                              ; 11014380
	v_mul_f32_e32 v131, v131, v172                              ; 11075983
	v_maxmin_num_f32 v175, -4.0, v133, 4.0                      ; d66900af 03db0af7
	v_maxmin_num_f32 v177, -4.0, v134, 4.0                      ; d66900b1 03db0cf7
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_mul_f32 v129, v129, v168 :: v_dual_mul_f32 v130, v130, v169 ; c8c75181 81835382
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v179, -4.0, v135, 4.0                      ; d66900b3 03db0ef7
	v_fmaak_f32 v174, v174, v173, 0x3f650000                    ; 5b5d5bae 3f650000
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fmaak_f32 v178, v178, v177, 0x3f650000                    ; 5b6563b2 3f650000
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_dual_mul_f32 v132, v132, v174 :: v_dual_fmaak_f32 v175, v175, v176, 0x3f650000 ; c8c35d84 84af61af 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmaak_f32 v179, v179, v180, 0x3f650000                    ; 5b6769b3 3f650000
	v_dual_mul_f32 v134, v134, v178 :: v_dual_mul_f32 v133, v133, v175 ; c8c76586 86855f85
	v_mul_f32_e32 v135, v135, v179                              ; 110f6787
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[128:131], v160, s[16:19], null offen offset:2048 ; c405c07c 40802080 000800a0
	buffer_load_b128 v[168:171], v160, s[16:19], null offen offset:2560 ; c405c07c 408020a8 000a00a0
	buffer_load_b128 v[172:175], v160, s[16:19], null offen offset:3072 ; c405c07c 408020ac 000c00a0
	buffer_load_b128 v[132:135], v160, s[16:19], null offen offset:3584 ; c405c07c 40802084 000e00a0
	v_maxmin_num_f32 v181, -4.0, v136, 4.0                      ; d66900b5 03db10f7
	v_maxmin_num_f32 v183, -4.0, v137, 4.0                      ; d66900b7 03db12f7
	v_maxmin_num_f32 v185, -4.0, v138, 4.0                      ; d66900b9 03db14f7
	v_maxmin_num_f32 v187, -4.0, v139, 4.0                      ; d66900bb 03db16f7
	v_maxmin_num_f32 v191, -4.0, v141, 4.0                      ; d66900bf 03db1af7
	v_maxmin_num_f32 v189, -4.0, v140, 4.0                      ; d66900bd 03db18f7
	v_maxmin_num_f32 v6, -4.0, v142, 4.0                        ; d6690006 03db1cf7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 ; c8436fb8 b8b56db5 3f650000
	v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 :: v_dual_fmaak_f32 v188, v188, v187, 0x3f650000 ; c84375b9 b9bd77bc 3f650000
	v_maxmin_num_f32 v60, -4.0, v143, 4.0                       ; d669003c 03db1ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_mul_f32_e32 v137, v137, v184                              ; 11137189
	v_dual_fmaak_f32 v191, v5, v191, 0x3f650000 :: v_dual_mul_f32 v138, v138, v185 ; c8477f05 bf8b738a 3f650000
	v_dual_mul_f32 v139, v139, v188 :: v_dual_mul_f32 v136, v136, v181 ; c8c7798b 8b896b88
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[136:139], v123, s[20:23], null offen offset:64 ; c405c07c 40802888 0000407b
	buffer_load_b128 v[160:163], v123, s[20:23], null offen offset:80 ; c405c07c 408028a0 0000507b
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_fma_mix_f32 v27, 0xab28, |v6|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621b 0bfe0cff 3728ab28
	v_maxmin_num_f32 v102, -4.0, v144, 4.0                      ; d6690066 03db20f7
	v_maxmin_num_f32 v110, -4.0, v145, 4.0                      ; d669006e 03db22f7
	v_fma_mix_f32 v65, 0xab28, |v60|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206241 0bfe78ff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v146, 4.0                      ; d669007b 03db24f7
	v_dual_mul_f32 v141, v141, v191 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c8c37f8d 8dbf7bbe 3f650000
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fmaak_f32 v60, v60, v65, 0x3f650000                       ; 5a78833c 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v27, v6, v27, 0x3f650000 :: v_dual_mul_f32 v140, v140, v190 ; c8463706 1b8d7d8c 3f650000
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 ; c842dd6f 6f66cf66 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870152
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_maxmin_num_f32 v141, -4.0, v147, 4.0                      ; d669008d 03db26f7
	v_fma_mix_f32 v140, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bfef6ff 3728ab28
	v_dual_mul_f32 v142, v142, v27 :: v_dual_mul_f32 v143, v143, v60 ; c8c6378e 8e8e798f
	v_dual_mul_f32 v145, v145, v111 :: v_dual_mul_f32 v144, v144, v102 ; c8c6df91 9190cd90
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_maxmin_num_f32 v143, -4.0, v148, 4.0                      ; d669008f 03db28f7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v145, -4.0, v149, 4.0                      ; d6690091 03db2af7
	v_maxmin_num_f32 v177, -4.0, v152, 4.0                      ; d66900b1 03db30f7
	v_maxmin_num_f32 v179, -4.0, v153, 4.0                      ; d66900b3 03db32f7
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v140, 0x3f650000 ; c8431b8e 8e7b197b 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870254
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v181, -4.0, v154, 4.0                      ; d66900b5 03db34f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_maxmin_num_f32 v183, -4.0, v155, 4.0                      ; d66900b7 03db36f7
	v_dual_mul_f32 v147, v147, v142 :: v_dual_mul_f32 v146, v146, v123 ; c8c71d93 9392f792
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 :: v_dual_fmaak_f32 v180, v180, v179, 0x3f650000 ; c84365b1 b1b567b4 3f650000
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
(invalid instruction)                                        ; d7694066
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_maxmin_num_f32 v147, -4.0, v150, 4.0                      ; d6690093 03db2cf7
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v156, 4.0                      ; d66900b9 03db38f7
	v_maxmin_num_f32 v187, -4.0, v157, 4.0                      ; d66900bb 03db3af7
	v_dual_mul_f32 v153, v153, v180 :: v_dual_mul_f32 v152, v152, v177 ; c8c76999 99996398
	v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 ; c8436db5 b5b96fb8 3f650000
	v_maxmin_num_f32 v189, -4.0, v158, 4.0                      ; d66900bd 03db3cf7
	v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 ; c8432591 91911f90 3f650000
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v159, 4.0                      ; d66900bf 03db3ef7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
(invalid instruction)                                        ; d769006e
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_dual_mul_f32 v155, v155, v184 :: v_dual_mul_f32 v154, v154, v181 ; c8c7719b 9b9b6b9a
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_mul_f32 v149, v149, v145 :: v_dual_mul_f32 v148, v148, v144 ; c8c72395 95952194
	v_fma_mix_f32 v5, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206205 0bff7eff 3728ab28
	s_mov_b64 s[24:25], s[20:21]                                ; be980114
	s_mov_b64 s[26:27], s[22:23]                                ; be9a0116
	v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 ; c84379bb bbbb73ba 3f650000
(invalid instruction)                                        ; d769406e
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v149, -4.0, v151, 4.0                      ; d6690095 03db2ef7
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_dual_fmaak_f32 v191, v5, v191, 0x3f650000 :: v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 ; c8437f05 bfbf7bbe 3f650000
	v_dual_mul_f32 v157, v157, v187 :: v_dual_mul_f32 v156, v156, v186 ; c8c7779d 9d9d759c
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_fma_mix_f32 v176, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff2aff 3728ab28
	v_dual_mul_f32 v159, v159, v191 :: v_dual_mul_f32 v158, v158, v190 ; c8c77f9f 9f9f7d9e
(invalid instruction)                                        ; d769006f
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870193
	v_dual_fmaak_f32 v149, v149, v176, 0x3f650000 :: v_dual_fmaak_f32 v148, v148, v147, 0x3f650000 ; c8436195 95952794 3f650000
(invalid instruction)                                        ; d769406f
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_dual_mul_f32 v151, v151, v149 :: v_dual_mul_f32 v150, v150, v148 ; c8c72b97 97972996
(invalid instruction)                                        ; d7694067
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mix_f32 v154, v37, v118, neg(0) op_sel_hi:[1,0,0]     ; cc20009a 8a02ed25
	v_fma_mix_f32 v145, v7, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a02eb07
	v_fma_mix_f32 v146, v24, v118, neg(0) op_sel_hi:[1,0,0]     ; cc200092 8a02ed18
	v_fma_mix_f32 v153, v36, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a02eb24
	v_fma_mix_f32 v144, v7, v116, neg(0) op_sel_hi:[1,0,0]      ; cc200090 8a02e907
	v_fma_mix_f32 v152, v36, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200098 8a02e924
	v_fma_mix_f32 v155, v37, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089b 8a02ef25
	v_fma_mix_f32 v147, v24, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200893 8a02ef18
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mix_f32 v159, v43, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089f 8a02ff2b
	v_fma_mix_f32 v176, v44, v116, neg(0) op_sel_hi:[1,0,0]     ; cc2000b0 8a02e92c
	v_fma_mix_f32 v156, v42, v124, neg(0) op_sel_hi:[1,0,0]     ; cc20009c 8a02f92a
	v_fma_mix_f32 v151, v26, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a02ff1a
	v_fma_mix_f32 v148, v25, v124, neg(0) op_sel_hi:[1,0,0]     ; cc200094 8a02f919
	v_fma_mix_f32 v150, v26, v126, neg(0) op_sel_hi:[1,0,0]     ; cc200096 8a02fd1a
	v_fma_mix_f32 v149, v25, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a02fb19
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	v_fma_mix_f32 v157, v42, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a02fb2a
	v_fma_mix_f32 v177, v44, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a02eb2c
	v_fma_mix_f32 v178, v45, v118, neg(0) op_sel_hi:[1,0,0]     ; cc2000b2 8a02ed2d
	v_fma_mix_f32 v179, v45, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a02ef2d
	v_fma_mix_f32 v184, v52, v116, neg(0) op_sel_hi:[1,0,0]     ; cc2000b8 8a02e934
	v_fma_mix_f32 v158, v43, v126, neg(0) op_sel_hi:[1,0,0]     ; cc20009e 8a02fd2b
	v_fma_mix_f32 v180, v50, v124, neg(0) op_sel_hi:[1,0,0]     ; cc2000b4 8a02f932
	v_fma_mix_f32 v181, v50, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a02fb32
	v_fma_mix_f32 v182, v51, v126, neg(0) op_sel_hi:[1,0,0]     ; cc2000b6 8a02fd33
	v_fma_mix_f32 v183, v51, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b7 8a02ff33
	v_fma_mix_f32 v185, v52, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a02eb34
	v_fma_mix_f32 v186, v53, v118, neg(0) op_sel_hi:[1,0,0]     ; cc2000ba 8a02ed35
	v_fma_mix_f32 v187, v53, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a02ef35
	v_fma_mix_f32 v188, v58, v124, neg(0) op_sel_hi:[1,0,0]     ; cc2000bc 8a02f93a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v6, s5, v1, 2                                ; d6470006 020a0205
	v_fma_mix_f32 v189, v58, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a02fb3a
	v_fma_mix_f32 v190, v59, v126, neg(0) op_sel_hi:[1,0,0]     ; cc2000be 8a02fd3b
	v_fma_mix_f32 v191, v59, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a02ff3b
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[164:165], v[66:67], v[184:191] ; cc4640b8 1ee285a4
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[24:27], v6, s[16:19], null offen         ; c405c07c 40802018 00000006
	buffer_load_b128 v[116:119], v6, s[16:19], null offen offset:1024 ; c405c07c 40802074 00040006
	buffer_load_b128 v[124:127], v6, s[16:19], null offen offset:2048 ; c405c07c 4080207c 00080006
	buffer_load_b128 v[140:143], v6, s[16:19], null offen offset:512 ; c405c07c 4080208c 00020006
	buffer_load_b128 v[42:45], v6, s[16:19], null offen offset:1536 ; c405c07c 4080202a 00060006
	buffer_load_b128 v[50:53], v6, s[16:19], null offen offset:2560 ; c405c07c 40802032 000a0006
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[164:165], v[10:11], v[152:159] ; cc464098 1e6215a4
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[164:165], v[8:9], v[144:151] ; cc464090 1e4211a4
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[12:13], v[88:89], v[184:191] ; cc4640b8 1ee2b10c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[12:13], v[22:23], v[144:151] ; cc464090 1e422d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[12:13], v[84:85], v[152:159] ; cc464098 1e62a90c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[16:17], v[92:93], v[184:191] ; cc4640b8 1ee2b910
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[16:17], v[68:69], v[144:151] ; cc464090 1e428910
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[72:73], v[152:159] ; cc464098 1e629110
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[32:33], v[96:97], v[184:191] ; cc4640b8 1ee2c120
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[32:33], v[70:71], v[144:151] ; cc464090 1e428d20
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[74:75], v[152:159] ; cc464098 1e629520
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[128:129], v[104:105], v[184:191] ; cc4640b8 1ee2d180
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[128:129], v[76:77], v[144:151] ; cc464090 1e429980
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[128:129], v[80:81], v[152:159] ; cc464098 1e62a180
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[168:169], v[112:113], v[184:191] ; cc4640b8 1ee2e1a8
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[168:169], v[78:79], v[144:151] ; cc464090 1e429da8
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[168:169], v[82:83], v[152:159] ; cc464098 1e62a5a8
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[172:173], v[120:121], v[184:191] ; cc4640b8 1ee2f1ac
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[172:173], v[100:101], v[144:151] ; cc464090 1e42c9ac
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[172:173], v[108:109], v[152:159] ; cc464098 1e62d9ac
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[184:191], v[132:133], v[110:111], v[184:191] ; cc4640b8 1ee2dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[132:133], v[28:29], v[144:151] ; cc464090 1e423984
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[132:133], v[30:31], v[152:159] ; cc464098 1e623d84
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[164:165], v[20:21], v[176:183] ; cc4640b0 1ec229a4
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[86:87], v[176:183] ; cc4640b0 1ec2ad0c
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mix_f32 v36, v38, v136, neg(0) op_sel_hi:[1,0,0]      ; cc200024 8a031126
	v_fma_mix_f32 v37, v38, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200825 8a031326
	v_fma_mix_f32 v38, v39, v138, neg(0) op_sel_hi:[1,0,0]      ; cc200026 8a031527
	v_fma_mix_f32 v39, v39, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200827 8a031727
	s_load_b32 s4, s[14:15], 0x24                               ; f4000107 f8000024
	s_bitset0_b32 s25, 14                                       ; be99108e
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[90:91], v[176:183] ; cc4640b0 1ec2b510
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s4, s4, 2                                        ; 84048204
	s_buffer_load_b32 s4, s[24:27], s4 offset:0x0               ; f402010c 08000000
	v_fma_mix_f32 v164, v54, v136, neg(0) op_sel_hi:[1,0,0]     ; cc2000a4 8a031136
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[32:33], v[94:95], v[176:183] ; cc4640b0 1ec2bd20
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v188, v189, vcc_lo                    ; 02037bbc
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v190, v191, vcc_lo                    ; 02037fbe
	v_fma_mix_f32 v165, v54, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a031336
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mix_f32 v58, v40, v160, neg(0) op_sel_hi:[1,0,0]      ; cc20003a 8a034128
	v_fma_mix_f32 v59, v40, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083b 8a034328
	v_fma_mix_f32 v60, v41, v162, neg(0) op_sel_hi:[1,0,0]      ; cc20003c 8a034529
	v_fma_mix_f32 v41, v41, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200829 8a034729
	v_fma_mix_f32 v65, v46, v136, neg(0) op_sel_hi:[1,0,0]      ; cc200041 8a03112e
	v_fma_mix_f32 v46, v46, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082e 8a03132e
	v_fma_mix_f32 v136, v61, v136, neg(0) op_sel_hi:[1,0,0]     ; cc200088 8a03113d
	v_fma_mix_f32 v137, v61, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200889 8a03133d
	v_fma_mix_f32 v123, v47, v138, neg(0) op_sel_hi:[1,0,0]     ; cc20007b 8a03152f
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[128:129], v[98:99], v[176:183] ; cc4640b0 1ec2c580
	v_fma_mix_f32 v47, v47, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20082f 8a03172f
	v_fma_mix_f32 v128, v48, v160, neg(0) op_sel_hi:[1,0,0]     ; cc200080 8a034130
	v_fma_mix_f32 v129, v48, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a034330
	v_fma_mix_f32 v5, v57, v162, neg(0) op_sel_hi:[1,0,0]       ; cc200005 8a034539
	v_fma_mix_f32 v57, v57, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200839 8a034739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870251
	v_swap_b32 v39, v57                                         ; 7e4ecb39
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[168:169], v[106:107], v[176:183] ; cc4640b0 1ec2d5a8
	v_fma_mix_f32 v168, v55, v138, neg(0) op_sel_hi:[1,0,0]     ; cc2000a8 8a031537
	v_fma_mix_f32 v169, v55, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a031737
	v_dual_mov_b32 v55, v37 :: v_dual_mov_b32 v54, v36          ; ca100125 37360124
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[114:115], v[176:183] ; cc4640b0 1ec2e5ac
	v_fma_mix_f32 v172, v56, v160, neg(0) op_sel_hi:[1,0,0]     ; cc2000ac 8a034138
	v_fma_mix_f32 v173, v56, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ad 8a034338
	v_dual_mov_b32 v61, v41 :: v_dual_mov_b32 v56, v38          ; ca100129 3d380126
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_dual_mov_b32 v38, v127 :: v_dual_mov_b32 v37, v126        ; ca10017f 2624017e
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[166:167], v[8:9], v[54:61] ; cc464036 1cda11a6
	v_mov_b32_e32 v8, v35                                       ; 7e100323
	v_dual_mov_b32 v36, v125 :: v_dual_mov_b32 v35, v124        ; ca10017d 2422017c
	v_dual_mov_b32 v124, v65 :: v_dual_mov_b32 v125, v46        ; ca100141 7c7c012e
	v_dual_mov_b32 v126, v123 :: v_dual_mov_b32 v127, v47       ; ca10017b 7e7e012f
	v_fma_mix_f32 v138, v62, v138, neg(0) op_sel_hi:[1,0,0]     ; cc20008a 8a03153e
	v_fma_mix_f32 v139, v62, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088b 8a03173e
	v_fma_mix_f32 v160, v63, v160, neg(0) op_sel_hi:[1,0,0]     ; cc2000a0 8a03413f
	v_fma_mix_f32 v161, v63, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a1 8a03433f
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[132:133], v[102:103], v[176:183] ; cc4640b0 1ec2cd84
	v_fma_mix_f32 v132, v49, v162, neg(0) op_sel_hi:[1,0,0]     ; cc200084 8a034531
	v_fma_mix_f32 v133, v49, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200885 8a034731
	v_fma_mix_f32 v162, v64, v162, neg(0) op_sel_hi:[1,0,0]     ; cc2000a2 8a034540
	v_fma_mix_f32 v163, v64, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a3 8a034740
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mov_b32 v46, v140 :: v_dual_mov_b32 v47, v141        ; ca10018c 2e2e018d
	v_dual_mov_b32 v49, v143 :: v_dual_mov_b32 v48, v142        ; ca10018f 3130018e
	v_dual_mov_b32 v141, v161 :: v_dual_mov_b32 v140, v160      ; ca1001a1 8d8c01a0
	v_dual_mov_b32 v9, v8 :: v_dual_mov_b32 v8, v34             ; ca100108 09080122
	v_swap_b32 v5, v170                                         ; 7e0acbaa
	v_swap_b32 v39, v171                                        ; 7e4ecbab
	v_swap_b32 v130, v132                                       ; 7f04cb84
	v_swap_b32 v131, v133                                       ; 7f06cb85
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[14:15], v[22:23], v[54:61] ; cc464036 1cda2d0e
	v_dual_mov_b32 v143, v163 :: v_dual_mov_b32 v142, v162      ; ca1001a3 8f8e01a2
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[166:167], v[10:11], v[124:131] ; cc46407c 1df215a6
	v_dual_mov_b32 v11, v167 :: v_dual_mov_b32 v10, v166        ; ca1001a7 0b0a01a6
	v_dual_mov_b32 v166, v168 :: v_dual_mov_b32 v167, v169      ; ca1001a8 a6a601a9
	v_dual_mov_b32 v168, v172 :: v_dual_mov_b32 v169, v173      ; ca1001ac a8a801ad
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[18:19], v[68:69], v[54:61] ; cc464036 1cda8912
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[10:11], v[20:21], v[164:171] ; cc4640a4 1e92290a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[66:67], v[136:143] ; cc464088 1e22850a
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[14:15], v[84:85], v[124:131] ; cc46407c 1df2a90e
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[8:9], v[70:71], v[54:61] ; cc464036 1cda8d08
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[14:15], v[86:87], v[164:171] ; cc4640a4 1e92ad0e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[14:15], v[88:89], v[136:143] ; cc464088 1e22b10e
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[18:19], v[72:73], v[124:131] ; cc46407c 1df29112
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[132:133], v[76:77], v[54:61] ; cc464036 1cda9984
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[18:19], v[90:91], v[164:171] ; cc4640a4 1e92b512
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[92:93], v[136:143] ; cc464088 1e22b912
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[8:9], v[74:75], v[124:131] ; cc46407c 1df29508
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[8:9], v[94:95], v[164:171] ; cc4640a4 1e92bd08
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[8:9], v[96:97], v[136:143] ; cc464088 1e22c108
	v_dual_mov_b32 v9, v39 :: v_dual_mov_b32 v8, v5             ; ca100127 09080105
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[132:133], v[80:81], v[124:131] ; cc46407c 1df2a184
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[118:119], v[6:7], 0 ; cc464058 1a020d76
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[132:133], v[98:99], v[164:171] ; cc4640a4 1e92c584
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[8:9], v[78:79], v[54:61] ; cc464036 1cda9d08
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[6:7], 0   ; cc464048 1a020d1a
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[132:133], v[104:105], v[136:143] ; cc464088 1e22d184
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[8:9], v[82:83], v[124:131] ; cc46407c 1df2a508
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[8:9], v[106:107], v[164:171] ; cc4640a4 1e92d508
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[174:175], v[100:101], v[54:61] ; cc464036 1cdac9ae
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[8:9], v[112:113], v[136:143] ; cc464088 1e22e108
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[174:175], v[108:109], v[124:131] ; cc46407c 1df2d9ae
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[6:7], 0   ; cc464040 1a020d18
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[174:175], v[114:115], v[164:171] ; cc4640a4 1e92e5ae
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[116:117], v[6:7], 0 ; cc464050 1a020d74
	v_wmma_f32_16x16x16_fp8_fp8 v[54:61], v[134:135], v[28:29], v[54:61] ; cc464036 1cda3986
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[174:175], v[120:121], v[136:143] ; cc464088 1e22f1ae
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[134:135], v[30:31], v[124:131] ; cc46407c 1df23d86
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[134:135], v[102:103], v[164:171] ; cc4640a4 1e92cd86
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[134:135], v[110:111], v[136:143] ; cc464088 1e22dd86
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[42:43], v[8:9], v[80:87] ; cc464050 1d42112a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[8:9], v[64:71] ; cc464040 1d02112e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[48:49], v[8:9], v[72:79] ; cc464048 1d221130
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[8:9], v[88:95] ; cc464058 1d62112c
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[6:7], v[35:36], 0  ; cc464060 1a024706
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[6:7], v[37:38], 0 ; cc464068 1a024b06
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v21, v75, v75 :: v_dual_mul_f32 v20, v89, v89 ; c8c6974b 1514b359
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[50:51], v[96:103] ; cc464060 1d826508
	v_dual_fmac_f32 v21, v67, v67 :: v_dual_fmac_f32 v20, v81, v81 ; c8008743 1514a351
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[52:53], v[104:111] ; cc464068 1da26908
	v_dual_mul_f32 v22, v91, v91 :: v_dual_mul_f32 v9, v73, v73 ; c8c6b75b 16089349
	v_dual_fmac_f32 v21, v71, v71 :: v_dual_fmac_f32 v20, v85, v85 ; c8008f47 1514ab55
	s_mov_b32 s5, 0x76543210                                    ; be8500ff 76543210
	s_mov_b32 s8, 0xfedcba98                                    ; be8800ff fedcba98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_dual_fmac_f32 v22, v83, v83 :: v_dual_fmac_f32 v9, v65, v65 ; c800a753 16088341
	v_dual_fmac_f32 v21, v79, v79 :: v_dual_fmac_f32 v20, v93, v93 ; c8009f4f 1514bb5d
	s_movk_i32 s10, 0x410                                       ; b00a0410
	v_dual_fmac_f32 v22, v87, v87 :: v_dual_fmac_f32 v9, v69, v69 ; c800af57 16088b45
	v_dual_fmac_f32 v20, v80, v80 :: v_dual_fmac_f32 v21, v66, v66 ; c800a150 14148542
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v22, v95, v95 :: v_dual_fmac_f32 v9, v77, v77 ; c800bf5f 16089b4d
	v_dual_fmac_f32 v20, v88, v88 :: v_dual_fmac_f32 v21, v74, v74 ; c800b158 1414954a
	v_dual_fmac_f32 v22, v82, v82 :: v_dual_fmac_f32 v9, v64, v64 ; c800a552 16088140
	v_dual_fmac_f32 v20, v84, v84 :: v_dual_fmac_f32 v21, v70, v70 ; c800a954 14148d46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v22, v90, v90 :: v_dual_fmac_f32 v9, v72, v72 ; c800b55a 16089148
	v_dual_fmac_f32 v20, v92, v92 :: v_dual_fmac_f32 v21, v78, v78 ; c800b95c 14149d4e
	v_dual_fmac_f32 v22, v86, v86 :: v_dual_fmac_f32 v9, v68, v68 ; c800ad56 16088944
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmac_f32 v22, v94, v94 :: v_dual_fmac_f32 v9, v76, v76 ; c800bd5e 1608994c
	v_fma_mixlo_f16 v23, 1.0, v9, v21                           ; cc210017 045612f2
	v_fma_mixhi_f16 v23, 1.0, v20, v22                          ; cc220017 045a28f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v28, v23, s5, s8 op_sel:[1,1]             ; d65c181c 00200b17
(invalid instruction)                                        ; cc0f0017
	v_min_num_f64_e32 v[1:2], v[23:24], v[28:29]                ; 1a023917
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0017
	v_subrev_f32_e32 v0, v23, v10                               ; 0a001517
	v_cvt_f32_f16_e32 v29, v23                                  ; 7e3a1717
	v_cvt_f32_f16_e32 v23, v151/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2e1797
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(TRANS32_DEP_2) ; bf870332
	v_rsq_f32_e32 v29, v29                                      ; 7e3a5d1d
	v_rsq_f32_e32 v23, v23                                      ; 7e2e5d17
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_mul_f32_e32 v29, s4, v29                                  ; 103a3a04
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v83, v83, v23 :: v_dual_mul_f32 v82, v82, v23 ; c8c62f53 53522f52
	v_dual_mul_f32 v85, v85, v23 :: v_dual_mul_f32 v84, v84, v23 ; c8c62f55 55542f54
	v_dual_mul_f32 v87, v87, v23 :: v_dual_mul_f32 v86, v86, v23 ; c8c62f57 57562f56
	v_dual_mul_f32 v81, v81, v23 :: v_dual_mul_f32 v80, v80, v23 ; c8c62f51 51502f50
	v_dual_mul_f32 v69, v69, v29 :: v_dual_mul_f32 v68, v68, v29 ; c8c63b45 45443b44
	v_dual_mul_f32 v73, v73, v29 :: v_dual_mul_f32 v72, v72, v29 ; c8c63b49 49483b48
	v_dual_mul_f32 v71, v71, v29 :: v_dual_mul_f32 v70, v70, v29 ; c8c63b47 47463b46
	v_dual_mul_f32 v64, v64, v29 :: v_dual_mul_f32 v65, v65, v29 ; c8c63b40 40403b41
	v_dual_mul_f32 v66, v66, v29 :: v_dual_mul_f32 v67, v67, v29 ; c8c63b42 42423b43
	v_dual_mul_f32 v77, v77, v29 :: v_dual_mul_f32 v76, v76, v29 ; c8c63b4d 4d4c3b4c
	v_dual_mul_f32 v89, v89, v23 :: v_dual_mul_f32 v88, v88, v23 ; c8c62f59 59582f58
	v_dual_mul_f32 v75, v75, v29 :: v_dual_mul_f32 v74, v74, v29 ; c8c63b4b 4b4a3b4a
	v_dual_mul_f32 v79, v79, v29 :: v_dual_mul_f32 v78, v78, v29 ; c8c63b4f 4f4e3b4e
	v_dual_mul_f32 v91, v91, v23 :: v_dual_mul_f32 v90, v90, v23 ; c8c62f5b 5b5a2f5a
	v_dual_mul_f32 v93, v93, v23 :: v_dual_mul_f32 v92, v92, v23 ; c8c62f5d 5d5c2f5c
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_dual_mul_f32 v95, v95, v23 :: v_dual_mul_f32 v94, v94, v23 ; c8c62f5f 5f5e2f5e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[26:27], v[12:13], 0 ; cc464048 1a02191a
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[24:25], v[12:13], 0 ; cc464040 1a021918
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[116:117], v[12:13], 0 ; cc464050 1a021974
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[118:119], v[12:13], 0 ; cc464058 1a021976
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[48:49], v[10:11], v[72:79] ; cc464048 1d221530
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[35:36], 0 ; cc464060 1a02470c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[37:38], 0 ; cc464068 1a024b0c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[46:47], v[10:11], v[64:71] ; cc464040 1d02152e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[42:43], v[10:11], v[80:87] ; cc464050 1d42152a
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[10:11], v[88:95] ; cc464058 1d62152c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[10:11], v[50:51], v[96:103] ; cc464060 1d82650a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[52:53], v[104:111] ; cc464068 1da2690a
	v_dual_mul_f32 v40, v75, v75 :: v_dual_mul_f32 v39, v89, v89 ; c8c6974b 2826b359
	v_dual_mul_f32 v41, v91, v91 :: v_dual_mul_f32 v34, v73, v73 ; c8c6b75b 29229349
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v40, v67, v67 :: v_dual_fmac_f32 v39, v81, v81 ; c8008743 2826a351
	v_dual_fmac_f32 v41, v83, v83 :: v_dual_fmac_f32 v34, v65, v65 ; c800a753 29228341
	v_dual_fmac_f32 v40, v71, v71 :: v_dual_fmac_f32 v39, v85, v85 ; c8008f47 2826ab55
	v_dual_fmac_f32 v41, v87, v87 :: v_dual_fmac_f32 v34, v69, v69 ; c800af57 29228b45
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v40, v79, v79 :: v_dual_fmac_f32 v39, v93, v93 ; c8009f4f 2826bb5d
	v_dual_fmac_f32 v41, v95, v95 :: v_dual_fmac_f32 v34, v77, v77 ; c800bf5f 29229b4d
	v_dual_fmac_f32 v39, v80, v80 :: v_dual_fmac_f32 v40, v66, v66 ; c800a150 27288542
	v_dual_fmac_f32 v41, v82, v82 :: v_dual_fmac_f32 v34, v64, v64 ; c800a552 29228140
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v39, v88, v88 :: v_dual_fmac_f32 v40, v74, v74 ; c800b158 2728954a
	v_dual_fmac_f32 v41, v90, v90 :: v_dual_fmac_f32 v34, v72, v72 ; c800b55a 29229148
	v_dual_fmac_f32 v39, v84, v84 :: v_dual_fmac_f32 v40, v70, v70 ; c800a954 27288d46
	v_dual_fmac_f32 v41, v86, v86 :: v_dual_fmac_f32 v34, v68, v68 ; c800ad56 29228944
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v39, v92, v92 :: v_dual_fmac_f32 v40, v78, v78 ; c800b95c 27289d4e
	v_dual_fmac_f32 v41, v94, v94 :: v_dual_fmac_f32 v34, v76, v76 ; c800bd5e 2922994c
	v_fma_mixlo_f16 v62, 1.0, v34, v40                          ; cc21003e 04a244f2
	v_fma_mixhi_f16 v62, 1.0, v39, v41                          ; cc22003e 04a64ef2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v63, v62, s5, s8 op_sel:[1,1]             ; d65c183f 00200b3e
(invalid instruction)                                        ; cc0f003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[63:64]                ; 1a027f3e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c003e
	v_subrev_f32_e32 v0, v62, v10                               ; 0a00153e
	v_cvt_f32_f16_e32 v112, v62                                 ; 7ee0173e
	v_cvt_f32_f16_e32 v62, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7c17be
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v112, v112                                    ; 7ee05d70
	v_rsq_f32_e32 v62, v62                                      ; 7e7c5d3e
	v_mul_f32_e32 v112, s4, v112                                ; 10e0e004
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v89, v89, v62 :: v_dual_mul_f32 v86, v86, v62 ; c8c67d59 59567d56
	v_mul_f32_e32 v81, v81, v62                                 ; 10a27d51
	v_dual_mul_f32 v85, v85, v62 :: v_dual_mul_f32 v66, v66, v112 ; c8c67d55 5542e142
	v_mul_f32_e32 v67, v67, v112                                ; 1086e143
	v_dual_mul_f32 v73, v73, v112 :: v_dual_mul_f32 v70, v70, v112 ; c8c6e149 4946e146
	v_dual_mul_f32 v87, v87, v62 :: v_dual_mul_f32 v68, v68, v112 ; c8c67d57 5744e144
	v_dual_mul_f32 v83, v83, v62 :: v_dual_mul_f32 v64, v64, v112 ; c8c67d53 5340e140
	v_dual_mul_f32 v75, v75, v112 :: v_dual_mul_f32 v80, v80, v62 ; c8c6e14b 4b507d50
	v_dual_mul_f32 v77, v77, v112 :: v_dual_mul_f32 v82, v82, v62 ; c8c6e14d 4d527d52
	v_mul_f32_e32 v69, v69, v112                                ; 108ae145
	v_mul_f32_e32 v71, v71, v112                                ; 108ee147
	v_mul_f32_e32 v65, v65, v112                                ; 1082e141
	v_dual_mul_f32 v79, v79, v112 :: v_dual_mul_f32 v84, v84, v62 ; c8c6e14f 4f547d54
	v_dual_mul_f32 v91, v91, v62 :: v_dual_mul_f32 v72, v72, v112 ; c8c67d5b 5b48e148
	v_dual_mul_f32 v93, v93, v62 :: v_dual_mul_f32 v74, v74, v112 ; c8c67d5d 5d4ae14a
	v_dual_mul_f32 v95, v95, v62 :: v_dual_mul_f32 v76, v76, v112 ; c8c67d5f 5f4ce14c
	v_dual_mov_b32 v113, v128 :: v_dual_mul_f32 v78, v78, v112  ; ca060180 714ee14e
	v_dual_mov_b32 v115, v130 :: v_dual_mul_f32 v88, v88, v62   ; ca060182 73587d58
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[26:27], v[16:17], 0 ; cc464050 1a02211a
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[24:25], v[16:17], 0 ; cc464048 1a022118
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[118:119], v[16:17], 0 ; cc464060 1a022176
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[48:49], v[14:15], v[80:87] ; cc464050 1d421d30
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[46:47], v[14:15], v[72:79] ; cc464048 1d221d2e
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[14:15], v[96:103] ; cc464060 1d821d2c
	v_dual_mul_f32 v121, v81, v81 :: v_dual_mul_f32 v90, v90, v62 ; c8c6a351 795a7d5a
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_dual_fmac_f32 v121, v73, v73 :: v_dual_mul_f32 v92, v92, v62 ; c8069349 795c7d5c
	v_mul_f32_e32 v161, v99, v99                                ; 1142c763
	v_dual_mul_f32 v123, v97, v97 :: v_dual_mul_f32 v94, v94, v62 ; c8c6c361 7b5e7d5e
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[35:36], 0 ; cc464068 1a024710
	v_fmac_f32_e32 v121, v77, v77                               ; 56f29b4d
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[116:117], v[16:17], 0 ; cc464058 1a022174
	v_fmac_f32_e32 v121, v85, v85                               ; 56f2ab55
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[50:51], v[104:111] ; cc464068 1da2650e
	v_dual_fmac_f32 v121, v72, v72 :: v_dual_mul_f32 v160, v83, v83 ; c8069148 79a0a753
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[42:43], v[14:15], v[88:95] ; cc464058 1d621d2a
	v_dual_fmac_f32 v121, v80, v80 :: v_dual_fmac_f32 v160, v75, v75 ; c800a150 79a0974b
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_fmac_f32 v121, v76, v76 :: v_dual_fmac_f32 v160, v79, v79 ; c800994c 79a09f4f
	v_dual_fmac_f32 v161, v91, v91 :: v_dual_mov_b32 v114, v129 ; c810b75b a1720181
	v_dual_fmac_f32 v121, v84, v84 :: v_dual_fmac_f32 v160, v87, v87 ; c800a954 79a0af57
	v_fmac_f32_e32 v123, v89, v89                               ; 56f6b359
	v_fmac_f32_e32 v161, v95, v95                               ; 5742bf5f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmac_f32_e32 v123, v93, v93                               ; 56f6bb5d
	v_fmac_f32_e32 v161, v103, v103                             ; 5742cf67
	v_dual_fmac_f32 v123, v101, v101 :: v_dual_mov_b32 v120, v131 ; c810cb65 7b780183
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[16:17], v[37:38], 0 ; cc464080 1a024b10
	v_fmac_f32_e32 v161, v90, v90                               ; 5742b55a
	v_dual_fmac_f32 v123, v88, v88 :: v_dual_fmac_f32 v160, v74, v74 ; c800b158 7ba0954a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fmac_f32_e32 v161, v98, v98                               ; 5742c562
	v_dual_fmac_f32 v123, v96, v96 :: v_dual_fmac_f32 v160, v82, v82 ; c800c160 7ba0a552
	v_fmac_f32_e32 v161, v94, v94                               ; 5742bd5e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[52:53], v[128:135] ; cc464080 1e02690e
	v_dual_fmac_f32 v123, v92, v92 :: v_dual_fmac_f32 v160, v78, v78 ; c800b95c 7ba09d4e
	v_fmac_f32_e32 v161, v102, v102                             ; 5742cd66
	v_lshl_add_u32 v3, v3, 6, s7                                ; d6460003 001d0d03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_fmac_f32 v123, v100, v100 :: v_dual_fmac_f32 v160, v86, v86 ; c800c964 7ba0ad56
	v_add_lshl_u32 v3, v3, v2, 2                                ; d6470003 020a0503
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_fma_mixlo_f16 v162, 1.0, v121, v160                       ; cc2100a2 0682f2f2
	v_fma_mixhi_f16 v162, 1.0, v123, v161                       ; cc2200a2 0686f6f2
	v_permlanex16_b32 v163, v162, s5, s8 op_sel:[1,1]           ; d65c18a3 00200ba2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[162:163], v[163:164]            ; 1a0347a2
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; cc1c00a2
	v_subrev_f32_e32 v0, v162, v10                              ; 0a0015a2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d58b00ac
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
	v_rsq_f32_e32 v172, v172                                    ; 7f585dac
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
	v_mul_f32_e32 v172, s4, v172                                ; 11595804
	v_dual_mul_f32 v73, v73, v172 :: v_dual_mul_f32 v72, v72, v172 ; c8c75949 49495948
	v_dual_mul_f32 v75, v75, v172 :: v_dual_mul_f32 v74, v74, v172 ; c8c7594b 4b4b594a
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                      ; 0202974a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v3, s[20:23], null offen         ; c405c07c 40802844 00000003
	buffer_load_b128 v[72:75], v3, s[20:23], null offen offset:16 ; c405c07c 40802848 00001003
(invalid instruction)                                        ; d58b08a2
	v_cndmask_b32_e32 v0, v162, v128, vcc_lo                    ; 020101a2
	v_dual_mul_f32 v79, v79, v172 :: v_dual_mul_f32 v78, v78, v172 ; c8c7594f 4f4f594e
	v_dual_mul_f32 v77, v77, v172 :: v_dual_mul_f32 v76, v76, v172 ; c8c7594d 4d4d594c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870293
	v_rsq_f32_e32 v162, v162                                    ; 7f445da2
	v_dual_mul_f32 v89, v89, v162 :: v_dual_mul_f32 v88, v88, v162 ; c8c74559 59594558
	v_dual_mul_f32 v91, v91, v162 :: v_dual_mul_f32 v90, v90, v162 ; c8c7455b 5b5b455a
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	buffer_load_b128 v[88:91], v3, s[20:23], null offen offset:4096 ; c405c07c 40802858 00100003
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v76, v77, vcc_lo                      ; 02029b4c
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v78, v79, vcc_lo                      ; 02029f4e
	v_dual_mul_f32 v81, v81, v172 :: v_dual_mul_f32 v80, v80, v172 ; c8c75951 51515950
	v_dual_mul_f32 v95, v95, v162 :: v_dual_mul_f32 v94, v94, v162 ; c8c7455f 5f5f455e
	v_dual_mul_f32 v93, v93, v162 :: v_dual_mul_f32 v92, v92, v162 ; c8c7455d 5d5d455c
	v_dual_mul_f32 v83, v83, v172 :: v_dual_mul_f32 v82, v82, v172 ; c8c75953 53535952
	v_dual_mul_f32 v85, v85, v172 :: v_dual_mul_f32 v84, v84, v172 ; c8c75955 55555954
	v_dual_mul_f32 v87, v87, v172 :: v_dual_mul_f32 v86, v86, v172 ; c8c75957 57575956
	v_dual_mul_f32 v97, v97, v162 :: v_dual_mul_f32 v96, v96, v162 ; c8c74561 61614560
	v_dual_mul_f32 v99, v99, v162 :: v_dual_mul_f32 v98, v98, v162 ; c8c74563 63634562
	v_dual_mul_f32 v101, v101, v162 :: v_dual_mul_f32 v100, v100, v162 ; c8c74565 65654564
	v_dual_mul_f32 v103, v103, v162 :: v_dual_mul_f32 v102, v102, v162 ; c8c74567 67674566
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[26:27], v[32:33], 0 ; cc464068 1a02411a
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	v_dual_mov_b32 v27, v120 :: v_dual_mov_b32 v34, v122        ; ca100178 1b22017a
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d7694052
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694050
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694051
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[24:25], v[32:33], 0 ; cc464060 1a024118
	v_dual_mov_b32 v5, v156 :: v_dual_mov_b32 v24, v157         ; ca10019c 0518019d
	v_dual_mov_b32 v26, v159 :: v_dual_mov_b32 v25, v158        ; ca10019f 1a18019e
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694053
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[116:117], v[32:33], 0 ; cc464080 1a024174
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[118:119], v[32:33], 0 ; cc46409c 1a024176
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[32:33], v[35:36], 0 ; cc464074 1a024720
	v_dual_mov_b32 v36, v169 :: v_dual_mov_b32 v35, v168        ; ca1001a9 242201a8
	v_dual_mov_b32 v84, v171 :: v_dual_mov_b32 v39, v170        ; ca1001ab 542601aa
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[18:19], v[104:111] ; cc464068 1da22530
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[32:33], v[37:38], 0 ; cc4640a8 1a024b20
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[18:19], v[96:103] ; cc464060 1d82252e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[42:43], v[18:19], v[128:135] ; cc464080 1e02252a
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[44:45], v[18:19], v[156:163] ; cc46409c 1e72252c
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[18:19], v[50:51], v[116:123] ; cc464074 1dd26512
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[18:19], v[52:53], v[168:175] ; cc4640a8 1ea26912
	v_dual_mul_f32 v92, v159, v159 :: v_dual_mul_f32 v85, v105, v105 ; c8c73f9f 5c54d369
	v_dual_mul_f32 v87, v107, v107 :: v_dual_mul_f32 v86, v157, v157 ; c8c6d76b 57573b9d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v92, v131, v131 :: v_dual_fmac_f32 v85, v97, v97 ; c8010783 5c54c361
	v_dual_fmac_f32 v87, v99, v99 :: v_dual_fmac_f32 v86, v129, v129 ; c800c763 57570381
	v_dual_fmac_f32 v92, v135, v135 :: v_dual_fmac_f32 v85, v101, v101 ; c8010f87 5c54cb65
	v_dual_fmac_f32 v87, v103, v103 :: v_dual_fmac_f32 v86, v133, v133 ; c800cf67 57570b85
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v92, v163, v163 :: v_dual_fmac_f32 v85, v109, v109 ; c80147a3 5c54db6d
	v_dual_fmac_f32 v87, v111, v111 :: v_dual_fmac_f32 v86, v161, v161 ; c800df6f 575743a1
	v_dual_fmac_f32 v92, v130, v130 :: v_dual_fmac_f32 v85, v96, v96 ; c8010582 5c54c160
	v_dual_fmac_f32 v86, v128, v128 :: v_dual_fmac_f32 v87, v98, v98 ; c8010180 5656c562
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v92, v158, v158 :: v_dual_fmac_f32 v85, v104, v104 ; c8013d9e 5c54d168
	v_dual_fmac_f32 v86, v156, v156 :: v_dual_fmac_f32 v87, v106, v106 ; c801399c 5656d56a
	v_dual_fmac_f32 v92, v134, v134 :: v_dual_fmac_f32 v85, v100, v100 ; c8010d86 5c54c964
	v_dual_fmac_f32 v86, v132, v132 :: v_dual_fmac_f32 v87, v102, v102 ; c8010984 5656cd66
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v92, v162, v162 :: v_dual_fmac_f32 v85, v108, v108 ; c80145a2 5c54d96c
	v_dual_fmac_f32 v86, v160, v160 :: v_dual_fmac_f32 v87, v110, v110 ; c80141a0 5656dd6e
	v_fma_mixlo_f16 v93, 1.0, v85, v87                          ; cc21005d 055eaaf2
	v_mov_b32_e32 v19, v84                                      ; 7e260354
	v_fma_mixhi_f16 v93, 1.0, v86, v92                          ; cc22005d 0572acf2
	v_dual_mov_b32 v38, v35 :: v_dual_mov_b32 v37, v34          ; ca100123 26240122
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v94, v93, s5, s8 op_sel:[1,1]             ; d65c185e 00200b5d
	v_dual_mov_b32 v43, v55 :: v_dual_mov_b32 v42, v54          ; ca100137 2b2a0136
(invalid instruction)                                        ; cc0f005d
	v_min_num_f64_e32 v[1:2], v[93:94], v[94:95]                ; 1a02bd5d
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c005d
	v_subrev_f32_e32 v0, v93, v10                               ; 0a00155d
	v_cvt_f32_f16_e32 v95, v93                                  ; 7ebe175d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v95, v95                                      ; 7ebe5d5f
	v_mul_f32_e32 v95, s4, v95                                  ; 10bebe04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_dual_mul_f32 v96, v96, v95 :: v_dual_mul_f32 v97, v97, v95 ; c8c6bf60 6060bf61
	v_dual_mul_f32 v98, v98, v95 :: v_dual_mul_f32 v99, v99, v95 ; c8c6bf62 6262bf63
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[44:47], v3, s[20:23], null offen offset:4112 ; c405c07c 4080282c 00101003
	buffer_load_b128 v[48:51], v3, s[20:23], null offen offset:8192 ; c405c07c 40802830 00200003
	buffer_load_b128 v[96:99], v3, s[20:23], null offen offset:8208 ; c405c07c 40802860 00201003
	buffer_load_b128 v[84:87], v3, s[20:23], null offen offset:12288 ; c405c07c 40802854 00300003
	buffer_load_b128 v[32:35], v3, s[20:23], null offen offset:12304 ; c405c07c 40802820 00301003
	buffer_load_b128 v[52:55], v3, s[20:23], null offen offset:64 ; c405c07c 40802834 00004003
	v_cvt_f32_f16_e32 v93, v221/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eba17dd
	v_dual_mul_f32 v102, v102, v95 :: v_dual_mul_f32 v101, v101, v95 ; c8c6bf66 6664bf65
	v_mul_f32_e32 v100, v100, v95                               ; 10c8bf64
	v_dual_mul_f32 v104, v104, v95 :: v_dual_mul_f32 v105, v105, v95 ; c8c6bf68 6868bf69
	v_dual_mul_f32 v107, v107, v95 :: v_dual_mul_f32 v106, v106, v95 ; c8c6bf6b 6b6abf6a
	v_dual_mul_f32 v109, v109, v95 :: v_dual_mul_f32 v108, v108, v95 ; c8c6bf6d 6d6cbf6c
	v_dual_mul_f32 v111, v111, v95 :: v_dual_mul_f32 v110, v110, v95 ; c8c6bf6f 6f6ebf6e
	v_rsq_f32_e32 v93, v93                                      ; 7eba5d5d
(invalid instruction)                                        ; d7690074
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_mov_b32 v100, v18 :: v_dual_mul_f32 v103, v103, v95  ; ca060112 6466bf67
(invalid instruction)                                        ; d7694074
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690075
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694075
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_mul_f32 v134, v134, v93 :: v_dual_mul_f32 v135, v135, v93 ; c8c6bb86 8686bb87
	v_dual_mul_f32 v128, v128, v93 :: v_dual_mul_f32 v129, v129, v93 ; c8c6bb80 8080bb81
	v_dual_mul_f32 v132, v132, v93 :: v_dual_mul_f32 v133, v133, v93 ; c8c6bb84 8484bb85
	v_dual_mul_f32 v157, v157, v93 :: v_dual_mul_f32 v156, v156, v93 ; c8c6bb9d 9d9cbb9c
	v_dual_mul_f32 v130, v130, v93 :: v_dual_mul_f32 v131, v131, v93 ; c8c6bb82 8282bb83
	v_dual_mul_f32 v161, v161, v93 :: v_dual_mul_f32 v160, v160, v93 ; c8c6bba1 a1a0bba0
	v_dual_mul_f32 v163, v163, v93 :: v_dual_mul_f32 v162, v162, v93 ; c8c6bba3 a3a2bba2
	v_dual_mul_f32 v159, v159, v93 :: v_dual_mul_f32 v158, v158, v93 ; c8c6bb9f 9f9ebb9e
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694067
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694066
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mov_b32_e32 v18, v113                                     ; 7e240371
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[8:9], v[6:7], 0   ; cc464080 1a020d08
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[8:9], v[10:11], 0 ; cc4640a8 1a021508
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[8:9], v[14:15], 0 ; cc46409c 1a021d08
	v_wmma_f32_16x16x16_fp8_fp8 v[106:113], v[8:9], v[100:101], 0 ; cc46406a 1a02c908
	s_mov_b32 s11, 0x3d380000                                   ; be8b00ff 3d380000
	v_dual_mov_b32 v8, v40 :: v_dual_mov_b32 v9, v41            ; ca100128 08080129
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[28:29], v[30:31], v[128:135] ; cc464080 1e023d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[28:29], v[64:65], v[168:175] ; cc4640a8 1ea2811c
	s_movk_i32 s13, 0x3e47                                      ; b00d3e47
	s_movk_i32 s24, 0x3c20                                      ; b0183c20
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[28:29], v[78:79], v[156:163] ; cc46409c 1e729d1c
	v_wmma_f32_16x16x16_fp8_fp8 v[106:113], v[28:29], v[104:105], v[106:113] ; cc46406a 1daad11c
	s_wait_loadcnt 0x8                                          ; bfc00008
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_mixlo_f16 v29, s11, v130, v70                         ; cc21001d 051b040b
	v_fma_mixhi_f16 v29, s11, v131, v71                         ; cc22001d 051f060b
	v_fma_mixlo_f16 v28, s11, v128, v68                         ; cc21001c 0513000b
	v_fma_mixhi_f16 v28, s11, v129, v69                         ; cc22001c 0517020b
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v69, s11, v134, v74                         ; cc210045 052b0c0b
	v_fma_mixhi_f16 v69, s11, v135, v75                         ; cc220045 052f0e0b
	v_dual_mov_b32 v74, v124 :: v_dual_mov_b32 v75, v125        ; ca10017c 4a4a017d
	v_fma_mixlo_f16 v68, s11, v132, v72                         ; cc210044 0523080b
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v70, s11, v168, v88                         ; cc210046 0563500b
	v_fma_mixhi_f16 v70, s11, v169, v89                         ; cc220046 0567520b
	v_dual_mov_b32 v89, v43 :: v_dual_mov_b32 v88, v42          ; ca10012b 5958012a
	v_fma_mixhi_f16 v68, s11, v133, v73                         ; cc220044 05270a0b
(invalid instruction)                                        ; cc1c001d
	v_subrev_f32_e32 v0, v29, v24                               ; 0a00311d
	v_fma_mixlo_f16 v71, s11, v170, v90                         ; cc210047 056b540b
	v_fma_mixhi_f16 v71, s11, v171, v91                         ; cc220047 056f560b
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v24                               ; 0a00311c
(invalid instruction)                                        ; cc1c0045
	v_subrev_f32_e32 v0, v69, v24                               ; 0a003145
(invalid instruction)                                        ; cc1c0046
	v_subrev_f32_e32 v0, v70, v24                               ; 0a003146
(invalid instruction)                                        ; cc1c0044
	v_subrev_f32_e32 v0, v68, v24                               ; 0a003144
(invalid instruction)                                        ; cc1b001d
	v_subrev_f32_e32 v0, v29, v13                               ; 0a001b1d
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[12:13], v[6:7], 0 ; cc464080 1a020d0c
(invalid instruction)                                        ; cc1c0047
	v_subrev_f32_e32 v0, v71, v24                               ; 0a003147
(invalid instruction)                                        ; cc1b001c
	v_subrev_f32_e32 v0, v28, v13                               ; 0a001b1c
(invalid instruction)                                        ; cc1b0045
	v_subrev_f32_e32 v0, v69, v13                               ; 0a001b45
(invalid instruction)                                        ; cc1b0046
	v_subrev_f32_e32 v0, v70, v13                               ; 0a001b46
(invalid instruction)                                        ; cc1b0044
	v_subrev_f32_e32 v0, v68, v13                               ; 0a001b44
	v_wmma_f32_16x16x16_fp8_fp8 v[118:125], v[12:13], v[14:15], 0 ; cc464076 1a021d0c
(invalid instruction)                                        ; cc1b0047
	v_subrev_f32_e32 v0, v71, v13                               ; 0a001b47
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[66:67], v[30:31], v[128:135] ; cc464080 1e023d42
	v_wmma_f32_16x16x16_fp8_fp8 v[118:125], v[66:67], v[78:79], v[118:125] ; cc464076 1dda9d42
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v72, s11, v172, v44                         ; cc210048 04b3580b
	v_fma_mixlo_f16 v73, s11, v174, v46                         ; cc210049 04bb5c0b
	v_fma_mixhi_f16 v73, s11, v175, v47                         ; cc220049 04bf5e0b
	v_fma_mixhi_f16 v72, s11, v173, v45                         ; cc220048 04b75a0b
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[12:13], v[10:11], 0 ; cc4640a8 1a02150c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[12:13], v[100:101], 0 ; cc464028 1a02c90c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v91, s11, v158, v50                         ; cc21005b 04cb3c0b
	v_fma_mixlo_f16 v90, s11, v156, v48                         ; cc21005a 04c3380b
	v_fma_mixhi_f16 v90, s11, v157, v49                         ; cc22005a 04c73a0b
	v_fma_mixhi_f16 v91, s11, v159, v51                         ; cc22005b 04cf3e0b
(invalid instruction)                                        ; cc1c0049
	v_subrev_f32_e32 v0, v73, v24                               ; 0a003149
(invalid instruction)                                        ; cc1c0048
	v_subrev_f32_e32 v0, v72, v24                               ; 0a003148
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v96, s11, v160, v96                         ; cc210060 0583400b
	v_fma_mixhi_f16 v96, s11, v161, v97                         ; cc220060 0587420b
	v_fma_mixlo_f16 v97, s11, v162, v98                         ; cc210061 058b440b
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[66:67], v[64:65], v[168:175] ; cc4640a8 1ea28142
	v_fma_mixhi_f16 v97, s11, v163, v99                         ; cc220061 058f460b
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v98, s11, v106, v84                         ; cc210062 0552d40b
(invalid instruction)                                        ; cc1c005a
	v_subrev_f32_e32 v0, v90, v24                               ; 0a00315a
	v_fma_mixhi_f16 v98, s11, v107, v85                         ; cc220062 0556d60b
(invalid instruction)                                        ; cc1c005b
	v_subrev_f32_e32 v0, v91, v24                               ; 0a00315b
(invalid instruction)                                        ; cc1b0049
	v_subrev_f32_e32 v0, v73, v13                               ; 0a001b49
(invalid instruction)                                        ; cc1b0048
	v_subrev_f32_e32 v0, v72, v13                               ; 0a001b48
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[66:67], v[104:105], v[40:47] ; cc464028 1ca2d142
(invalid instruction)                                        ; cc1c0060
	v_subrev_f32_e32 v0, v96, v24                               ; 0a003160
	v_fma_mixlo_f16 v99, s11, v108, v86                         ; cc210063 055ad80b
	v_fma_mixhi_f16 v99, s11, v109, v87                         ; cc220063 055eda0b
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v106, s11, v110, v32                        ; cc21006a 0482dc0b
(invalid instruction)                                        ; cc1c0061
	v_subrev_f32_e32 v0, v97, v24                               ; 0a003161
	v_fma_mixhi_f16 v106, s11, v111, v33                        ; cc22006a 0486de0b
(invalid instruction)                                        ; cc1b005a
	v_subrev_f32_e32 v0, v90, v13                               ; 0a001b5a
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v24                               ; 0a003162
(invalid instruction)                                        ; cc1b005b
	v_subrev_f32_e32 v0, v91, v13                               ; 0a001b5b
	v_fma_mixlo_f16 v107, s11, v112, v34                        ; cc21006b 048ae00b
	v_fma_mixhi_f16 v107, s11, v113, v35                        ; cc22006b 048ee20b
	v_dual_mov_b32 v13, v115 :: v_dual_mov_b32 v12, v114        ; ca100173 0d0c0172
	s_clause 0x6                                                ; bf850006
	buffer_load_b128 v[32:35], v3, s[20:23], null offen offset:80 ; c405c07c 40802820 00005003
	buffer_load_b128 v[48:51], v3, s[20:23], null offen offset:4160 ; c405c07c 40802830 00104003
	buffer_load_b128 v[84:87], v3, s[20:23], null offen offset:4176 ; c405c07c 40802854 00105003
	buffer_load_b128 v[108:111], v3, s[20:23], null offen offset:8256 ; c405c07c 4080286c 00204003
	buffer_load_b128 v[156:159], v3, s[20:23], null offen offset:8272 ; c405c07c 4080289c 00205003
	buffer_load_b128 v[160:163], v3, s[20:23], null offen offset:12352 ; c405c07c 408028a0 00304003
	buffer_load_b128 v[112:115], v3, s[20:23], null offen offset:12368 ; c405c07c 40802870 00305003
(invalid instruction)                                        ; cc1b0060
	v_subrev_f32_e32 v0, v96, v13                               ; 0a001b60
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v24                               ; 0a003163
(invalid instruction)                                        ; cc1b0061
	v_subrev_f32_e32 v0, v97, v13                               ; 0a001b61
(invalid instruction)                                        ; cc1c006a
	v_subrev_f32_e32 v0, v106, v24                              ; 0a00316a
(invalid instruction)                                        ; cc1b0062
	v_subrev_f32_e32 v0, v98, v13                               ; 0a001b62
(invalid instruction)                                        ; cc1c006b
	v_subrev_f32_e32 v0, v107, v24                              ; 0a00316b
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v52, s11, v128, v52                         ; cc210034 04d3000b
	v_fma_mixhi_f16 v52, s11, v129, v53                         ; cc220034 04d7020b
(invalid instruction)                                        ; cc1b0063
	v_subrev_f32_e32 v0, v99, v13                               ; 0a001b63
(invalid instruction)                                        ; cc1b006a
	v_subrev_f32_e32 v0, v106, v13                              ; 0a001b6a
	v_fma_mixlo_f16 v53, s11, v130, v54                         ; cc210035 04db040b
	v_fma_mixhi_f16 v53, s11, v131, v55                         ; cc220035 04df060b
(invalid instruction)                                        ; cc1b006b
	v_subrev_f32_e32 v0, v107, v13                              ; 0a001b6b
(invalid instruction)                                        ; cc1c0034
	v_subrev_f32_e32 v0, v52, v24                               ; 0a003134
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; cc1c0035
	v_subrev_f32_e32 v0, v53, v24                               ; 0a003135
(invalid instruction)                                        ; cc1b0034
	v_subrev_f32_e32 v0, v52, v13                               ; 0a001b34
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; cc1b0035
	v_subrev_f32_e32 v0, v53, v13                               ; 0a001b35
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v55, s11, v134, v34                         ; cc210037 048b0c0b
	v_fma_mixlo_f16 v54, s11, v132, v32                         ; cc210036 0483080b
	v_fma_mixhi_f16 v54, s11, v133, v33                         ; cc220036 04870a0b
	v_fma_mixhi_f16 v55, s11, v135, v35                         ; cc220037 048f0e0b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v67, s11, v170, v50                         ; cc210043 04cb540b
	v_fma_mixlo_f16 v66, s11, v168, v48                         ; cc210042 04c3500b
	v_mov_b32_e32 v168, v36                                     ; 7f500324
	v_fma_mixhi_f16 v66, s11, v169, v49                         ; cc220042 04c7520b
	v_dual_mov_b32 v170, v38 :: v_dual_mov_b32 v169, v37        ; ca100126 aaa80125
	v_fma_mixhi_f16 v67, s11, v171, v51                         ; cc220043 04cf560b
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v172, s11, v172, v84                        ; cc2100ac 0553580b
	v_dual_mov_b32 v84, v46 :: v_dual_mov_b32 v171, v39         ; ca10012e 54aa0127
	v_fma_mixhi_f16 v172, s11, v173, v85                        ; cc2200ac 05575a0b
	v_fma_mixlo_f16 v173, s11, v174, v86                        ; cc2100ad 055b5c0b
	v_dual_mov_b32 v174, v44 :: v_dual_mov_b32 v85, v47         ; ca10012c ae54012f
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[16:17], v[6:7], 0 ; cc464080 1a020d10
	v_fma_mixhi_f16 v173, s11, v175, v87                        ; cc2200ad 055f5e0b
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v86, s11, v118, v108                        ; cc210056 05b2ec0b
(invalid instruction)                                        ; cc1c0036
	v_subrev_f32_e32 v0, v54, v24                               ; 0a003136
(invalid instruction)                                        ; cc1c0037
	v_subrev_f32_e32 v0, v55, v24                               ; 0a003137
	v_dual_mov_b32 v118, v111 :: v_dual_mov_b32 v175, v45       ; ca10016f 76ae012d
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[16:17], v[10:11], 0 ; cc464020 1a021510
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v24                               ; 0a003142
	v_fma_mixhi_f16 v86, s11, v119, v109                        ; cc220056 05b6ee0b
	v_fma_mixlo_f16 v87, s11, v120, v110                        ; cc210057 05baf00b
	buffer_load_b128 v[108:111], v3, s[20:23], null offen offset:128 ; c405c07c 4080286c 00008003
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v24                               ; 0a003143
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v24                              ; 0a0031ac
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[16:17], v[14:15], 0 ; cc46402c 1a021d10
(invalid instruction)                                        ; cc1c00ad
	v_subrev_f32_e32 v0, v173, v24                              ; 0a0031ad
(invalid instruction)                                        ; cc1b0036
	v_subrev_f32_e32 v0, v54, v13                               ; 0a001b36
(invalid instruction)                                        ; cc1b0037
	v_subrev_f32_e32 v0, v55, v13                               ; 0a001b37
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v119, s11, v122, v156                       ; cc210077 0672f40b
	v_fma_mixhi_f16 v119, s11, v123, v157                       ; cc220077 0676f60b
	v_fma_mixlo_f16 v120, s11, v124, v158                       ; cc210078 067af80b
	v_fma_mixhi_f16 v120, s11, v125, v159                       ; cc220078 067efa0b
(invalid instruction)                                        ; cc1b0042
	v_subrev_f32_e32 v0, v66, v13                               ; 0a001b42
(invalid instruction)                                        ; cc1c0056
	v_subrev_f32_e32 v0, v86, v24                               ; 0a003156
(invalid instruction)                                        ; cc1b0043
	v_subrev_f32_e32 v0, v67, v13                               ; 0a001b43
(invalid instruction)                                        ; cc1b00ac
	v_subrev_f32_e32 v0, v172, v13                              ; 0a001bac
	v_fma_mixhi_f16 v87, s11, v121, v118                        ; cc220057 05daf20b
(invalid instruction)                                        ; cc1b00ad
	v_subrev_f32_e32 v0, v173, v13                              ; 0a001bad
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[80:81], v[30:31], v[128:135] ; cc464080 1e023d50
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[80:81], v[64:65], v[32:39] ; cc464020 1c828150
(invalid instruction)                                        ; cc1c0077
	v_subrev_f32_e32 v0, v119, v24                              ; 0a003177
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v158, s11, v40, v160                        ; cc21009e 0682500b
	v_fma_mixhi_f16 v158, s11, v41, v161                        ; cc22009e 0686520b
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[80:81], v[78:79], v[44:51] ; cc46402c 1cb29d50
(invalid instruction)                                        ; cc1c0078
	v_subrev_f32_e32 v0, v120, v24                              ; 0a003178
(invalid instruction)                                        ; cc1b0056
	v_subrev_f32_e32 v0, v86, v13                               ; 0a001b56
(invalid instruction)                                        ; cc1c0057
	v_subrev_f32_e32 v0, v87, v24                               ; 0a003157
	v_fma_mixlo_f16 v159, s11, v42, v162                        ; cc21009f 068a540b
	v_fma_mixhi_f16 v159, s11, v43, v163                        ; cc22009f 068e560b
(invalid instruction)                                        ; cc1b0077
	v_subrev_f32_e32 v0, v119, v13                              ; 0a001b77
(invalid instruction)                                        ; cc1c009e
	v_subrev_f32_e32 v0, v158, v24                              ; 0a00319e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v160, s11, v174, v112                       ; cc2100a0 05c35c0b
	v_fma_mixhi_f16 v160, s11, v175, v113                       ; cc2200a0 05c75e0b
	v_fma_mixlo_f16 v161, s11, v84, v114                        ; cc2100a1 05caa80b
	v_fma_mixhi_f16 v161, s11, v85, v115                        ; cc2200a1 05ceaa0b
(invalid instruction)                                        ; cc1b0078
	v_subrev_f32_e32 v0, v120, v13                              ; 0a001b78
(invalid instruction)                                        ; cc1b0057
	v_subrev_f32_e32 v0, v87, v13                               ; 0a001b57
(invalid instruction)                                        ; cc1c009f
	v_subrev_f32_e32 v0, v159, v24                              ; 0a00319f
(invalid instruction)                                        ; cc1b009e
	v_subrev_f32_e32 v0, v158, v13                              ; 0a001b9e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v3, s[20:23], null offen offset:144 ; c405c07c 40802828 00009003
	buffer_load_b128 v[112:115], v3, s[20:23], null offen offset:4224 ; c405c07c 40802870 00108003
	v_dual_mov_b32 v157, v120 :: v_dual_mov_b32 v156, v119      ; ca100178 9d9c0177
	v_wmma_f32_16x16x16_fp8_fp8 v[118:125], v[16:17], v[100:101], 0 ; cc464076 1a02c910
	v_mov_b32_e32 v17, v131                                     ; 7e220383
(invalid instruction)                                        ; cc1c00a0
	v_subrev_f32_e32 v0, v160, v24                              ; 0a0031a0
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[118:125], v[80:81], v[104:105], v[118:125] ; cc464076 1ddad150
	v_dual_mov_b32 v81, v87 :: v_dual_mov_b32 v80, v86          ; ca100157 51500156
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_mov_b32_e32 v16, v111                                     ; 7e20036f
	v_fma_mixlo_f16 v163, s11, v130, v110                       ; cc2100a3 05bb040b
	v_fma_mixlo_f16 v162, s11, v128, v108                       ; cc2100a2 05b3000b
	v_fma_mixhi_f16 v162, s11, v129, v109                       ; cc2200a2 05b7020b
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[108:111], v3, s[20:23], null offen offset:4240 ; c405c07c 4080286c 00109003
	buffer_load_b128 v[128:131], v3, s[20:23], null offen offset:8320 ; c405c07c 40802880 00208003
	buffer_load_b128 v[84:87], v3, s[20:23], null offen offset:8336 ; c405c07c 40802854 00209003
(invalid instruction)                                        ; cc1c00a1
	v_subrev_f32_e32 v0, v161, v24                              ; 0a0031a1
(invalid instruction)                                        ; cc1b009f
	v_subrev_f32_e32 v0, v159, v13                              ; 0a001b9f
(invalid instruction)                                        ; cc1b00a0
	v_subrev_f32_e32 v0, v160, v13                              ; 0a001ba0
	v_fma_mixhi_f16 v163, s11, v17, v16                         ; cc2200a3 0442220b
(invalid instruction)                                        ; cc1c00a2
	v_subrev_f32_e32 v0, v162, v24                              ; 0a0031a2
(invalid instruction)                                        ; cc1b00a1
	v_subrev_f32_e32 v0, v161, v13                              ; 0a001ba1
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; cc1c00a3
	v_subrev_f32_e32 v0, v163, v24                              ; 0a0031a3
(invalid instruction)                                        ; cc1b00a2
	v_subrev_f32_e32 v0, v162, v13                              ; 0a001ba2
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v132, s11, v132, v40                        ; cc210084 04a3080b
	v_mov_b32_e32 v16, v35                                      ; 7e200323
	v_fma_mixhi_f16 v132, s11, v133, v41                        ; cc220084 04a70a0b
(invalid instruction)                                        ; cc1b00a3
	v_subrev_f32_e32 v0, v163, v13                              ; 0a001ba3
	v_fma_mixlo_f16 v133, s11, v134, v42                        ; cc210085 04ab0c0b
	v_fma_mixhi_f16 v133, s11, v135, v43                        ; cc220085 04af0e0b
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v135, s11, v34, v114                        ; cc210087 05ca440b
	v_fma_mixlo_f16 v134, s11, v32, v112                        ; cc210086 05c2400b
	v_fma_mixhi_f16 v134, s11, v33, v113                        ; cc220086 05c6420b
	v_mov_b32_e32 v17, v115                                     ; 7e220373
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[40:43], v3, s[20:23], null offen offset:12416 ; c405c07c 40802828 00308003
	buffer_load_b128 v[32:35], v3, s[20:23], null offen offset:12432 ; c405c07c 40802820 00309003
	buffer_load_b128 v[112:115], v3, s[20:23], null offen offset:192 ; c405c07c 40802870 0000c003
(invalid instruction)                                        ; cc1c0084
	v_subrev_f32_e32 v0, v132, v24                              ; 0a003184
(invalid instruction)                                        ; cc1c0085
	v_subrev_f32_e32 v0, v133, v24                              ; 0a003185
(invalid instruction)                                        ; cc1c0086
	v_subrev_f32_e32 v0, v134, v24                              ; 0a003186
	v_fma_mixhi_f16 v135, s11, v16, v17                         ; cc220087 0446200b
	v_dual_mov_b32 v17, v105 :: v_dual_mov_b32 v16, v104        ; ca100169 11100168
(invalid instruction)                                        ; cc1b0084
	v_subrev_f32_e32 v0, v132, v13                              ; 0a001b84
(invalid instruction)                                        ; cc1b0085
	v_subrev_f32_e32 v0, v133, v13                              ; 0a001b85
(invalid instruction)                                        ; cc1b0086
	v_subrev_f32_e32 v0, v134, v13                              ; 0a001b86
(invalid instruction)                                        ; cc1c0087
	v_subrev_f32_e32 v0, v135, v24                              ; 0a003187
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; cc1b0087
	v_subrev_f32_e32 v0, v135, v13                              ; 0a001b87
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v36, s11, v36, v108                         ; cc210024 05b2480b
	v_fma_mixhi_f16 v36, s11, v37, v109                         ; cc220024 05b64a0b
	v_fma_mixlo_f16 v37, s11, v38, v110                         ; cc210025 05ba4c0b
	v_fma_mixhi_f16 v37, s11, v39, v111                         ; cc220025 05be4e0b
	v_dual_mov_b32 v39, v107 :: v_dual_mov_b32 v38, v106        ; ca10016b 2726016a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[102:103], v[6:7], 0 ; cc464068 1a020d66
	v_dual_mov_b32 v7, v127 :: v_dual_mov_b32 v6, v126          ; ca10017f 0706017e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v44, s11, v44, v128                         ; cc21002c 0602580b
	v_fma_mixhi_f16 v44, s11, v45, v129                         ; cc22002c 06065a0b
	v_fma_mixlo_f16 v45, s11, v46, v130                         ; cc21002d 060a5c0b
	v_fma_mixhi_f16 v45, s11, v47, v131                         ; cc22002d 060e5e0b
	v_dual_mov_b32 v47, v125 :: v_dual_mov_b32 v46, v124        ; ca10017d 2f2e017c
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[102:103], v[10:11], 0 ; cc46407c 1a021566
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v24                               ; 0a003124
(invalid instruction)                                        ; cc1c0025
	v_subrev_f32_e32 v0, v37, v24                               ; 0a003125
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v10, s11, v48, v84                          ; cc21000a 0552600b
	v_fma_mixhi_f16 v10, s11, v49, v85                          ; cc22000a 0556620b
	v_fma_mixlo_f16 v11, s11, v50, v86                          ; cc21000b 055a640b
	v_fma_mixhi_f16 v11, s11, v51, v87                          ; cc22000b 055e660b
(invalid instruction)                                        ; cc1c002c
	v_subrev_f32_e32 v0, v44, v24                               ; 0a00312c
(invalid instruction)                                        ; cc1c002d
	v_subrev_f32_e32 v0, v45, v24                               ; 0a00312d
	v_dual_mov_b32 v87, v47 :: v_dual_mov_b32 v86, v46          ; ca10012f 5756012e
(invalid instruction)                                        ; cc1b0024
	v_subrev_f32_e32 v0, v36, v13                               ; 0a001b24
(invalid instruction)                                        ; cc1b0025
	v_subrev_f32_e32 v0, v37, v13                               ; 0a001b25
(invalid instruction)                                        ; cc1c000a
	v_subrev_f32_e32 v0, v10, v24                               ; 0a00310a
(invalid instruction)                                        ; cc1c000b
	v_subrev_f32_e32 v0, v11, v24                               ; 0a00310b
(invalid instruction)                                        ; cc1b002c
	v_subrev_f32_e32 v0, v44, v13                               ; 0a001b2c
(invalid instruction)                                        ; cc1b002d
	v_subrev_f32_e32 v0, v45, v13                               ; 0a001b2d
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[94:95], v[30:31], v[104:111] ; cc464068 1da23d5e
(invalid instruction)                                        ; cc1b000a
	v_subrev_f32_e32 v0, v10, v13                               ; 0a001b0a
(invalid instruction)                                        ; cc1b000b
	v_subrev_f32_e32 v0, v11, v13                               ; 0a001b0b
	v_dual_mov_b32 v85, v45 :: v_dual_mov_b32 v84, v44          ; ca10012d 5554012c
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[102:103], v[14:15], 0 ; cc46402c 1a021d66
	v_dual_mov_b32 v15, v37 :: v_dual_mov_b32 v14, v36          ; ca100125 0f0e0124
	v_wmma_f32_16x16x16_fp8_fp8 v[124:131], v[94:95], v[64:65], v[124:131] ; cc46407c 1df2815e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v118, s11, v118, v40                        ; cc210076 04a2ec0b
	v_fma_mixhi_f16 v118, s11, v119, v41                        ; cc220076 04a6ee0b
	v_fma_mixlo_f16 v119, s11, v120, v42                        ; cc210077 04aaf00b
	v_fma_mixhi_f16 v119, s11, v121, v43                        ; cc220077 04aef20b
	v_dual_mov_b32 v121, v39 :: v_dual_mov_b32 v120, v38        ; ca100127 79780126
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[102:103], v[100:101], 0 ; cc464024 1a02c966
	v_wmma_f32_16x16x16_fp8_fp8 v[44:51], v[94:95], v[78:79], v[44:51] ; cc46402c 1cb29d5e
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v122, s11, v122, v32                        ; cc21007a 0482f40b
	v_fma_mixhi_f16 v122, s11, v123, v33                        ; cc22007a 0486f60b
	v_fma_mixlo_f16 v123, s11, v86, v34                         ; cc21007b 048aac0b
	v_fma_mixhi_f16 v123, s11, v87, v35                         ; cc22007b 048eae0b
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v174, s11, v104, v112                       ; cc2100ae 05c2d00b
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[32:35], v3, s[20:23], null offen offset:208 ; c405c07c 40802820 0000d003
	buffer_load_b128 v[100:103], v3, s[20:23], null offen offset:4288 ; c405c07c 40802864 0010c003
	v_fma_mixhi_f16 v174, s11, v105, v113                       ; cc2200ae 05c6d20b
(invalid instruction)                                        ; cc1c0076
	v_subrev_f32_e32 v0, v118, v24                              ; 0a003176
	v_fma_mixlo_f16 v175, s11, v106, v114                       ; cc2100af 05cad40b
(invalid instruction)                                        ; cc1c0077
	v_subrev_f32_e32 v0, v119, v24                              ; 0a003177
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[94:95], v[16:17], v[36:43] ; cc464024 1c92215e
	v_mov_b32_e32 v16, v107                                     ; 7e20036b
	v_mov_b32_e32 v17, v115                                     ; 7e220373
	v_dual_mov_b32 v65, v29 :: v_dual_mov_b32 v64, v28          ; ca10011d 4140011c
	v_dual_mov_b32 v79, v85 :: v_dual_mov_b32 v78, v84          ; ca100155 4f4e0154
	s_clause 0x3                                                ; bf850003
	buffer_load_b128 v[104:107], v3, s[20:23], null offen offset:4304 ; c405c07c 40802868 0010d003
	buffer_load_b128 v[112:115], v3, s[20:23], null offen offset:8384 ; c405c07c 40802870 0020c003
	buffer_load_b128 v[28:31], v3, s[20:23], null offen offset:8400 ; c405c07c 4080281c 0020d003
	buffer_load_b128 v[84:87], v3, s[20:23], null offen offset:12480 ; c405c07c 40802854 0030c003
	v_fma_mixhi_f16 v175, s11, v16, v17                         ; cc2200af 0446200b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v94, s11, v108, v32                         ; cc21005e 0482d80b
	v_dual_mov_b32 v108, v19 :: v_dual_mov_b32 v95, v18         ; ca100113 6c5e0112
	buffer_load_b128 v[16:19], v3, s[20:23], null offen offset:12496 ; c405c07c 40802810 0030d003
(invalid instruction)                                        ; cc1c007a
	v_subrev_f32_e32 v0, v122, v24                              ; 0a00317a
(invalid instruction)                                        ; cc1c007b
	v_subrev_f32_e32 v0, v123, v24                              ; 0a00317b
(invalid instruction)                                        ; cc1c00ae
	v_subrev_f32_e32 v0, v174, v24                              ; 0a0031ae
(invalid instruction)                                        ; cc1b0076
	v_subrev_f32_e32 v0, v118, v13                              ; 0a001b76
(invalid instruction)                                        ; cc1b0077
	v_subrev_f32_e32 v0, v119, v13                              ; 0a001b77
(invalid instruction)                                        ; cc1c00af
	v_subrev_f32_e32 v0, v175, v24                              ; 0a0031af
	v_fma_mixhi_f16 v94, s11, v109, v33                         ; cc22005e 0486da0b
	v_fma_mixlo_f16 v109, s11, v110, v34                        ; cc21006d 048adc0b
	v_fma_mixhi_f16 v109, s11, v111, v35                        ; cc22006d 048ede0b
	s_mov_b32 s25, 0x7ff88000                                   ; be9900ff 7ff88000
(invalid instruction)                                        ; cc1b007a
	v_subrev_f32_e32 v0, v122, v13                              ; 0a001b7a
(invalid instruction)                                        ; cc1b007b
	v_subrev_f32_e32 v0, v123, v13                              ; 0a001b7b
(invalid instruction)                                        ; cc1b00ae
	v_subrev_f32_e32 v0, v174, v13                              ; 0a001bae
(invalid instruction)                                        ; cc1b00af
	v_subrev_f32_e32 v0, v175, v13                              ; 0a001baf
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v64, v64, 5, s25                             ; d6460040 00650b40
	v_lshl_add_u32 v53, v53, 5, s25                             ; d6460035 00650b35
(invalid instruction)                                        ; cc1c005e
	v_subrev_f32_e32 v0, v94, v24                               ; 0a00315e
	v_lshl_add_u32 v52, v52, 5, s25                             ; d6460034 00650b34
	v_lshl_add_u32 v65, v65, 5, s25                             ; d6460041 00650b41
	v_lshl_add_u32 v162, v162, 5, s25                           ; d64600a2 00650ba2
	v_lshl_add_u32 v163, v163, 5, s25                           ; d64600a3 00650ba3
(invalid instruction)                                        ; cc1c006d
	v_subrev_f32_e32 v0, v109, v24                              ; 0a00316d
	v_lshl_add_u32 v68, v68, 5, s25                             ; d6460044 00650b44
	v_lshl_add_u32 v54, v54, 5, s25                             ; d6460036 00650b36
	v_lshl_add_u32 v174, v174, 5, s25                           ; d64600ae 00650bae
	v_lshl_add_u32 v175, v175, 5, s25                           ; d64600af 00650baf
	v_lshl_add_u32 v132, v132, 5, s25                           ; d6460084 00650b84
(invalid instruction)                                        ; cc1b005e
	v_subrev_f32_e32 v0, v94, v13                               ; 0a001b5e
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[64:65], v[52:53]                ; 1a026940
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[65:66], v[53:54]                ; 1a026b41
	v_lshl_add_u32 v69, v69, 5, s25                             ; d6460045 00650b45
	v_lshl_add_u32 v55, v55, 5, s25                             ; d6460037 00650b37
(invalid instruction)                                        ; cc1b006d
	v_subrev_f32_e32 v0, v109, v13                              ; 0a001b6d
	v_lshl_add_u32 v133, v133, 5, s25                           ; d6460085 00650b85
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[68:69], v[54:55]                ; 1a026d44
	v_lshl_add_u32 v94, v94, 5, s25                             ; d646005e 00650b5e
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[162:163]            ; 1a03456e
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[163:164]            ; 1a03476f
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[69:70], v[55:56]                ; 1a026f45
	v_lshl_add_u32 v109, v109, 5, s25                           ; d646006d 00650b6d
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[132:133]                ; 1a030903
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[174:175]            ; 1a035d6e
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[175:176]            ; 1a035f6f
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[32:33], v[133:134]              ; 1a030b20
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[94:95]                  ; 1a02bd03
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[111:112]            ; 1a02df6e
(invalid instruction)                                        ; cc0f0020
	v_min_num_f64_e32 v[1:2], v[32:33], v[109:110]              ; 1a02db20
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[3:4]                ; 1a02076e
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[32:33]              ; 1a02416e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v33, v110, s5, s8 op_sel:[1,1]            ; d65c1821 00200b6e
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[33:34]              ; 1a02436e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v34, v110, v238/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 6445dd6e
	v_max_num_f16_e32 v34, s3, v34                              ; 62444403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v35, v34                                  ; 7e461722
	v_rcp_f32_e32 v35, v35                                      ; 7e465523
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v111, v65, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20006f 8a024741
	v_fma_mix_f32 v110, v64, v35, neg(0) op_sel_hi:[1,0,0]      ; cc20006e 8a024740
	v_fma_mix_f32 v64, v64, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200840 8a024740
	v_fma_mix_f32 v3, v68, v35, neg(0) op_sel_hi:[1,0,0]        ; cc200003 8a024744
	v_fma_mix_f32 v68, v68, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200844 8a024744
	v_fma_mix_f32 v34, v69, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200022 8a024745
	v_fma_mix_f32 v65, v65, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200841 8a024741
	v_fma_mix_f32 v69, v69, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200845 8a024745
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v110, v64, vcc_lo                     ; 0202816e
	v_fma_mix_f32 v64, v52, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200040 8a024734
	v_fma_mix_f32 v52, v52, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200834 8a024734
	v_fma_mix_f32 v110, v162, v35, neg(0) op_sel_hi:[1,0,0]     ; cc20006e 8a0247a2
	v_fma_mix_f32 v162, v162, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a2 8a0247a2
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v3, v68, vcc_lo                       ; 02028903
	v_fma_mix_f32 v68, v54, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200044 8a024736
	v_fma_mix_f32 v54, v54, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200836 8a024736
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v111, v65, vcc_lo                     ; 0202836f
	v_fma_mix_f32 v65, v53, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200041 8a024735
	v_fma_mix_f32 v53, v53, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200835 8a024735
	v_fma_mix_f32 v111, v163, v35, neg(0) op_sel_hi:[1,0,0]     ; cc20006f 8a0247a3
	v_fma_mix_f32 v163, v163, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a3 8a0247a3
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v34, v69, vcc_lo                      ; 02028b22
	v_fma_mix_f32 v69, v55, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200045 8a024737
	v_fma_mix_f32 v55, v55, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200837 8a024737
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v64, v52, vcc_lo                      ; 02026940
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v110, v162, vcc_lo                    ; 0203456e
	v_fma_mix_f32 v162, v132, v35, neg(0) op_sel_hi:[1,0,0]     ; cc2000a2 8a024784
	v_fma_mix_f32 v132, v132, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200884 8a024784
	v_fma_mix_f32 v3, v174, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200003 8a0247ae
	v_fma_mix_f32 v174, v174, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ae 8a0247ae
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v65, v53, vcc_lo                      ; 02026b41
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v68, v54, vcc_lo                      ; 02026d44
	v_fma_mix_f32 v34, v175, v35, neg(0) op_sel_hi:[1,0,0]      ; cc200022 8a0247af
	v_fma_mix_f32 v175, v175, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008af 8a0247af
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v111, v163, vcc_lo                    ; 0203476f
	v_fma_mix_f32 v163, v133, v35, neg(0) op_sel_hi:[1,0,0]     ; cc2000a3 8a024785
	v_fma_mix_f32 v133, v133, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200885 8a024785
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v69, v55, vcc_lo                      ; 02026f45
	v_fma_mix_f32 v55, v94, v35, neg(0) op_sel_hi:[1,0,0]       ; cc200037 8a02475e
	v_fma_mix_f32 v94, v94, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085e 8a02475e
	v_fma_mix_f32 v68, v109, v35, neg(0) op_sel_hi:[1,0,0]      ; cc200044 8a02476d
	v_fma_mix_f32 v109, v109, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086d 8a02476d
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v162, v132, vcc_lo                    ; 020309a2
	v_lshl_add_u32 v70, v70, 5, s25                             ; d6460046 00650b46
	v_lshl_add_u32 v66, v66, 5, s25                             ; d6460042 00650b42
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v3, v174, vcc_lo                      ; 02035d03
	v_lshl_add_u32 v134, v134, 5, s25                           ; d6460086 00650b86
	v_lshl_add_u32 v71, v71, 5, s25                             ; d6460047 00650b47
	v_lshl_add_u32 v67, v67, 5, s25                             ; d6460043 00650b43
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v34, v175, vcc_lo                     ; 02035f22
	v_lshl_add_u32 v135, v135, 5, s25                           ; d6460087 00650b87
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v163, v133, vcc_lo                    ; 02030ba3
	v_lshl_add_u32 v72, v72, 5, s25                             ; d6460048 00650b48
	v_lshl_add_u32 v172, v172, 5, s25                           ; d64600ac 00650bac
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v55, v94, vcc_lo                      ; 0202bd37
	v_lshl_add_u32 v14, v14, 5, s25                             ; d646000e 00650b0e
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v68, v109, vcc_lo                     ; 0202db44
	v_lshl_add_u32 v73, v73, 5, s25                             ; d6460049 00650b49
	v_lshl_add_u32 v173, v173, 5, s25                           ; d64600ad 00650bad
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[70:71], v[66:67]                ; 1a028546
	v_lshl_add_u32 v15, v15, 5, s25                             ; d646000f 00650b0f
	v_lshl_add_u32 v90, v90, 5, s25                             ; d646005a 00650b5a
(invalid instruction)                                        ; cc0f005e
	v_min_num_f64_e32 v[1:2], v[71:72], v[67:68]                ; 1a028747
	v_lshl_add_u32 v80, v80, 5, s25                             ; d6460050 00650b50
	v_lshl_add_u32 v78, v78, 5, s25                             ; d646004e 00650b4e
	v_lshl_add_u32 v91, v91, 5, s25                             ; d646005b 00650b5b
	v_lshl_add_u32 v81, v81, 5, s25                             ; d6460051 00650b51
(invalid instruction)                                        ; cc0f006d
	v_min_num_f64_e32 v[1:2], v[72:73], v[172:173]              ; 1a035948
	v_lshl_add_u32 v79, v79, 5, s25                             ; d646004f 00650b4f
	v_lshl_add_u32 v96, v96, 5, s25                             ; d6460060 00650b60
	v_lshl_add_u32 v156, v156, 5, s25                           ; d646009c 00650b9c
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[73:74], v[173:174]              ; 1a035b49
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[134:135]              ; 1a030d45
	v_lshl_add_u32 v10, v10, 5, s25                             ; d646000a 00650b0a
(invalid instruction)                                        ; cc0f005e
	v_min_num_f64_e32 v[1:2], v[94:95], v[135:136]              ; 1a030f5e
	v_lshl_add_u32 v97, v97, 5, s25                             ; d6460061 00650b61
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[90:91], v[80:81]                ; 1a02a15a
	v_lshl_add_u32 v157, v157, 5, s25                           ; d646009d 00650b9d
	v_lshl_add_u32 v11, v11, 5, s25                             ; d646000b 00650b0b
(invalid instruction)                                        ; cc0f0084
	v_min_num_f64_e32 v[1:2], v[91:92], v[81:82]                ; 1a02a35b
(invalid instruction)                                        ; cc0f006d
	v_min_num_f64_e32 v[1:2], v[109:110], v[14:15]              ; 1a021d6d
	v_lshl_add_u32 v98, v98, 5, s25                             ; d6460062 00650b62
	v_lshl_add_u32 v158, v158, 5, s25                           ; d646009e 00650b9e
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[96:97], v[156:157]              ; 1a033960
	v_lshl_add_u32 v118, v118, 5, s25                           ; d6460076 00650b76
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[15:16]              ; 1a021f6e
	v_lshl_add_u32 v99, v99, 5, s25                             ; d6460063 00650b63
	v_lshl_add_u32 v159, v159, 5, s25                           ; d646009f 00650b9f
	v_lshl_add_u32 v119, v119, 5, s25                           ; d6460077 00650b77
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[78:79]              ; 1a029d6f
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[97:98], v[157:158]              ; 1a033b61
	v_lshl_add_u32 v120, v120, 5, s25                           ; d6460078 00650b78
	v_lshl_add_u32 v160, v160, 5, s25                           ; d64600a0 00650ba0
(invalid instruction)                                        ; cc0f0084
	v_min_num_f64_e32 v[1:2], v[132:133], v[79:80]              ; 1a029f84
	v_lshl_add_u32 v122, v122, 5, s25                           ; d646007a 00650b7a
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[98:99], v[158:159]              ; 1a033d62
	v_lshl_add_u32 v121, v121, 5, s25                           ; d6460079 00650b79
	v_lshl_add_u32 v161, v161, 5, s25                           ; d64600a1 00650ba1
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[133:134], v[10:11]              ; 1a021585
	v_lshl_add_u32 v123, v123, 5, s25                           ; d646007b 00650b7b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v34, s11, v124, v100                        ; cc210022 0592f80b
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[99:100], v[159:160]             ; 1a033f63
	v_fma_mixhi_f16 v34, s11, v125, v101                        ; cc220022 0596fa0b
	v_fma_mixlo_f16 v35, s11, v126, v102                        ; cc210023 059afc0b
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[162:163], v[11:12]              ; 1a0217a2
	v_fma_mixhi_f16 v35, s11, v127, v103                        ; cc220023 059efe0b
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[120:121], v[160:161]            ; 1a034178
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v68, s11, v128, v104                        ; cc210044 05a3000b
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[118:119]            ; 1a02eda3
	v_fma_mixhi_f16 v68, s11, v129, v105                        ; cc220044 05a7020b
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[121:122], v[161:162]            ; 1a034379
	v_fma_mixlo_f16 v100, s11, v130, v106                       ; cc210064 05ab040b
	v_fma_mixhi_f16 v100, s11, v131, v107                       ; cc220064 05af060b
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[174:175], v[119:120]            ; 1a02efae
(invalid instruction)                                        ; cc1c0022
	v_subrev_f32_e32 v0, v34, v24                               ; 0a003122
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v101, s11, v44, v112                        ; cc210065 05c2580b
	v_fma_mixhi_f16 v101, s11, v45, v113                        ; cc220065 05c65a0b
(invalid instruction)                                        ; cc1c0023
	v_subrev_f32_e32 v0, v35, v24                               ; 0a003123
	v_fma_mixlo_f16 v102, s11, v46, v114                        ; cc210066 05ca5c0b
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[122:123]            ; 1a02f5af
	v_fma_mixhi_f16 v102, s11, v47, v115                        ; cc220066 05ce5e0b
(invalid instruction)                                        ; cc1c0044
	v_subrev_f32_e32 v0, v68, v24                               ; 0a003144
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v103, s11, v48, v28                         ; cc210067 0472600b
	v_fma_mixhi_f16 v103, s11, v49, v29                         ; cc220067 0476620b
(invalid instruction)                                        ; cc1c0064
	v_subrev_f32_e32 v0, v100, v24                              ; 0a003164
(invalid instruction)                                        ; cc1b0022
	v_subrev_f32_e32 v0, v34, v13                               ; 0a001b22
	v_fma_mixlo_f16 v104, s11, v50, v30                         ; cc210068 047a640b
	v_fma_mixhi_f16 v104, s11, v51, v31                         ; cc220068 047e660b
(invalid instruction)                                        ; cc1c0065
	v_subrev_f32_e32 v0, v101, v24                              ; 0a003165
(invalid instruction)                                        ; cc1b0023
	v_subrev_f32_e32 v0, v35, v13                               ; 0a001b23
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v105, s11, v36, v84                         ; cc210069 0552480b
	v_fma_mixhi_f16 v105, s11, v37, v85                         ; cc220069 05564a0b
(invalid instruction)                                        ; cc1c0066
	v_subrev_f32_e32 v0, v102, v24                              ; 0a003166
(invalid instruction)                                        ; cc1b0044
	v_subrev_f32_e32 v0, v68, v13                               ; 0a001b44
	v_fma_mixlo_f16 v106, s11, v38, v86                         ; cc21006a 055a4c0b
(invalid instruction)                                        ; cc1c0067
	v_subrev_f32_e32 v0, v103, v24                              ; 0a003167
	v_fma_mixhi_f16 v106, s11, v39, v87                         ; cc22006a 055e4e0b
(invalid instruction)                                        ; cc1b0064
	v_subrev_f32_e32 v0, v100, v13                              ; 0a001b64
(invalid instruction)                                        ; cc1c0068
	v_subrev_f32_e32 v0, v104, v24                              ; 0a003168
(invalid instruction)                                        ; cc1b0065
	v_subrev_f32_e32 v0, v101, v13                              ; 0a001b65
(invalid instruction)                                        ; cc1c0069
	v_subrev_f32_e32 v0, v105, v24                              ; 0a003169
(invalid instruction)                                        ; cc1b0066
	v_subrev_f32_e32 v0, v102, v13                              ; 0a001b66
	v_lshl_add_u32 v34, v34, 5, s25                             ; d6460022 00650b22
(invalid instruction)                                        ; cc1b0067
	v_subrev_f32_e32 v0, v103, v13                              ; 0a001b67
(invalid instruction)                                        ; cc1c006a
	v_subrev_f32_e32 v0, v106, v24                              ; 0a00316a
	v_lshl_add_u32 v35, v35, 5, s25                             ; d6460023 00650b23
	v_lshl_add_u32 v68, v68, 5, s25                             ; d6460044 00650b44
(invalid instruction)                                        ; cc1b0068
	v_subrev_f32_e32 v0, v104, v13                              ; 0a001b68
	v_lshl_add_u32 v100, v100, 5, s25                           ; d6460064 00650b64
(invalid instruction)                                        ; cc1b0069
	v_subrev_f32_e32 v0, v105, v13                              ; 0a001b69
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[34:35]                ; 1a024545
(invalid instruction)                                        ; cc1b006a
	v_subrev_f32_e32 v0, v106, v13                              ; 0a001b6a
(invalid instruction)                                        ; cc0f005e
	v_min_num_f64_e32 v[1:2], v[94:95], v[35:36]                ; 1a02475e
(invalid instruction)                                        ; cc0f006d
	v_min_num_f64_e32 v[1:2], v[109:110], v[68:69]              ; 1a02896d
(invalid instruction)                                        ; cc0f006e
	v_min_num_f64_e32 v[1:2], v[110:111], v[100:101]            ; 1a02c96e
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[94:95]                ; 1a02bd45
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[109:110]              ; 1a02db45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[110:111]              ; 1a02dd45
	v_permlanex16_b32 v113, v69, s5, s8 op_sel:[1,1]            ; d65c1871 00200b45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[113:114]              ; 1a02e345
	v_add_f16_e32 v114, v69, v197/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 64e58b45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v114, s3, v114                            ; 62e4e403
	v_cvt_f32_f16_e32 v115, v114                                ; 7ee61772
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_rcp_f32_e32 v115, v115                                    ; 7ee65573
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v112, s11, v42, v18                         ; cc210070 044a540b
	v_fma_mixlo_f16 v107, s11, v40, v16                         ; cc21006b 0442500b
	v_fma_mixhi_f16 v107, s11, v41, v17                         ; cc22006b 0446520b
	v_fma_mixhi_f16 v112, s11, v43, v19                         ; cc220070 044e560b
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; cc1c006b
	v_subrev_f32_e32 v0, v107, v24                              ; 0a00316b
(invalid instruction)                                        ; cc1c0070
	v_subrev_f32_e32 v0, v112, v24                              ; 0a003170
	v_fma_mix_f32 v125, v71, v115, neg(0) op_sel_hi:[1,0,0]     ; cc20007d 8a02e747
	v_fma_mix_f32 v71, v71, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200847 8a02e747
	v_fma_mix_f32 v124, v70, v115, neg(0) op_sel_hi:[1,0,0]     ; cc20007c 8a02e746
	v_fma_mix_f32 v126, v72, v115, neg(0) op_sel_hi:[1,0,0]     ; cc20007e 8a02e748
	v_fma_mix_f32 v72, v72, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200848 8a02e748
	v_fma_mix_f32 v128, v66, v115, neg(0) op_sel_hi:[1,0,0]     ; cc200080 8a02e742
	v_fma_mix_f32 v127, v73, v115, neg(0) op_sel_hi:[1,0,0]     ; cc20007f 8a02e749
	v_fma_mix_f32 v73, v73, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200849 8a02e749
	v_fma_mix_f32 v70, v70, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200846 8a02e746
	v_fma_mix_f32 v66, v66, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200842 8a02e742
	v_fma_mix_f32 v129, v67, v115, neg(0) op_sel_hi:[1,0,0]     ; cc200081 8a02e743
	v_fma_mix_f32 v67, v67, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200843 8a02e743
(invalid instruction)                                        ; cc1b006b
	v_subrev_f32_e32 v0, v107, v13                              ; 0a001b6b
	v_fma_mix_f32 v130, v172, v115, neg(0) op_sel_hi:[1,0,0]    ; cc200082 8a02e7ac
(invalid instruction)                                        ; cc1b0070
	v_subrev_f32_e32 v0, v112, v13                              ; 0a001b70
	v_fma_mix_f32 v172, v172, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ac 8a02e7ac
	v_fma_mix_f32 v131, v173, v115, neg(0) op_sel_hi:[1,0,0]    ; cc200083 8a02e7ad
	v_fma_mix_f32 v173, v173, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ad 8a02e7ad
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v126, v72, vcc_lo                     ; 0202917e
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v127, v73, vcc_lo                     ; 0202937f
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v124, v70, vcc_lo                     ; 02028d7c
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v125, v71, vcc_lo                     ; 02028f7d
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v128, v66, vcc_lo                     ; 02028580
	v_fma_mix_f32 v29, v14, v115, neg(0) op_sel_hi:[1,0,0]      ; cc20001d 8a02e70e
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v129, v67, vcc_lo                     ; 02028781
	v_fma_mix_f32 v14, v14, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080e 8a02e70e
	v_fma_mix_f32 v30, v15, v115, neg(0) op_sel_hi:[1,0,0]      ; cc20001e 8a02e70f
	v_fma_mix_f32 v15, v15, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080f 8a02e70f
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v130, v172, vcc_lo                    ; 02035982
	v_fma_mix_f32 v172, v134, v115, neg(0) op_sel_hi:[1,0,0]    ; cc2000ac 8a02e786
	v_fma_mix_f32 v134, v134, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200886 8a02e786
	v_fma_mix_f32 v31, v34, v115, neg(0) op_sel_hi:[1,0,0]      ; cc20001f 8a02e722
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v131, v173, vcc_lo                    ; 02035b83
	v_fma_mix_f32 v173, v135, v115, neg(0) op_sel_hi:[1,0,0]    ; cc2000ad 8a02e787
	v_fma_mix_f32 v135, v135, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200887 8a02e787
	v_fma_mix_f32 v34, v34, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200822 8a02e722
(invalid instruction)                                        ; d769001d
	v_cndmask_b32_e32 v1, v29, v14, vcc_lo                      ; 02021d1d
	v_fma_mix_f32 v36, v100, v115, neg(0) op_sel_hi:[1,0,0]     ; cc200024 8a02e764
(invalid instruction)                                        ; d769401d
	v_cndmask_b32_e32 v1, v30, v15, vcc_lo                      ; 02021f1e
	v_fma_mix_f32 v100, v100, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200864 8a02e764
	v_lshl_add_u32 v101, v101, 5, s25                           ; d6460065 00650b65
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v1, v172, v134, vcc_lo                    ; 02030dac
	v_lshl_add_u32 v102, v102, 5, s25                           ; d6460066 00650b66
	v_lshl_add_u32 v103, v103, 5, s25                           ; d6460067 00650b67
(invalid instruction)                                        ; d769401c
	v_cndmask_b32_e32 v1, v173, v135, vcc_lo                    ; 02030fad
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v31, v34, vcc_lo                      ; 0202451f
	v_fma_mix_f32 v34, v35, v115, neg(0) op_sel_hi:[1,0,0]      ; cc200022 8a02e723
	v_fma_mix_f32 v35, v35, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200823 8a02e723
	v_lshl_add_u32 v104, v104, 5, s25                           ; d6460068 00650b68
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[101:102]            ; 1a02cb6f
(invalid instruction)                                        ; cc0f0084
	v_min_num_f64_e32 v[1:2], v[132:133], v[102:103]            ; 1a02cd84
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[133:134], v[103:104]            ; 1a02cf85
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	v_fma_mix_f32 v35, v68, v115, neg(0) op_sel_hi:[1,0,0]      ; cc200023 8a02e744
	v_fma_mix_f32 v68, v68, v115, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200844 8a02e744
(invalid instruction)                                        ; cc0f00a2
	v_min_num_f64_e32 v[1:2], v[162:163], v[104:105]            ; 1a02d1a2
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[132:133]            ; 1a03096f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v35, v68, vcc_lo                      ; 02028923
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v36, v100, vcc_lo                     ; 0202c924
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[133:134]            ; 1a030b6f
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[162:163]            ; 1a03456f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_permlanex16_b32 v37, v111, s5, s8 op_sel:[1,1]            ; d65c1825 00200b6f
	v_add_lshl_u32 v44, s9, v169, 2                             ; d647002c 020b5209
(invalid instruction)                                        ; cc0f006f
	v_min_num_f64_e32 v[1:2], v[111:112], v[37:38]              ; 1a024b6f
	buffer_load_b128 v[48:51], v44, s[20:23], null offen        ; c405c07c 40802830 0000002c
	v_add_f16_e32 v38, v111, v239/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 644ddf6f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v38, s3, v38                              ; 624c4c03
	v_cvt_f32_f16_e32 v39, v38                                  ; 7e4e1726
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v39, v39                                      ; 7e4e5527
	v_fma_mix_f32 v41, v91, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200029 8a024f5b
	v_fma_mix_f32 v42, v96, v39, neg(0) op_sel_hi:[1,0,0]       ; cc20002a 8a024f60
	v_fma_mix_f32 v96, v96, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200860 8a024f60
	v_fma_mix_f32 v43, v97, v39, neg(0) op_sel_hi:[1,0,0]       ; cc20002b 8a024f61
	v_fma_mix_f32 v91, v91, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085b 8a024f5b
	v_fma_mix_f32 v97, v97, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200861 8a024f61
	v_fma_mix_f32 v40, v90, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200028 8a024f5a
	v_fma_mix_f32 v90, v90, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085a 8a024f5a
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v42, v96, vcc_lo                      ; 0202c12a
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v43, v97, vcc_lo                      ; 0202c32b
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v40, v90, vcc_lo                      ; 0202b528
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v41, v91, vcc_lo                      ; 0202b729
	buffer_load_b128 v[40:43], v44, s[20:23], null offen offset:16 ; c405c07c 40802828 0000102c
	v_fma_mix_f32 v45, v80, v39, neg(0) op_sel_hi:[1,0,0]       ; cc20002d 8a024f50
	v_fma_mix_f32 v80, v80, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200850 8a024f50
	v_fma_mix_f32 v46, v81, v39, neg(0) op_sel_hi:[1,0,0]       ; cc20002e 8a024f51
	v_fma_mix_f32 v81, v81, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200851 8a024f51
	v_fma_mix_f32 v47, v156, v39, neg(0) op_sel_hi:[1,0,0]      ; cc20002f 8a024f9c
	v_fma_mix_f32 v156, v156, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089c 8a024f9c
	v_fma_mix_f32 v66, v157, v39, neg(0) op_sel_hi:[1,0,0]      ; cc200042 8a024f9d
	v_fma_mix_f32 v157, v157, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a024f9d
	v_fma_mix_f32 v67, v78, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200043 8a024f4e
	v_fma_mix_f32 v78, v78, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084e 8a024f4e
	v_fma_mix_f32 v68, v79, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200044 8a024f4f
	v_fma_mix_f32 v79, v79, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084f 8a024f4f
	v_fma_mix_f32 v69, v10, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200045 8a024f0a
	v_fma_mix_f32 v10, v10, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080a 8a024f0a
	v_fma_mix_f32 v70, v11, v39, neg(0) op_sel_hi:[1,0,0]       ; cc200046 8a024f0b
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v45, v80, vcc_lo                      ; 0202a12d
	v_fma_mix_f32 v11, v11, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080b 8a024f0b
	v_fma_mix_f32 v71, v101, v39, neg(0) op_sel_hi:[1,0,0]      ; cc200047 8a024f65
	v_fma_mix_f32 v101, v101, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200865 8a024f65
	s_lshr_b32 s6, s6, 2                                        ; 85068206
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v67, v78, vcc_lo                      ; 02029d43
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v68, v79, vcc_lo                      ; 02029f44
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v69, v10, vcc_lo                      ; 02021545
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v70, v11, vcc_lo                      ; 02021746
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v1, s6, v1, 2                                ; d6470001 020a0206
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v71, v101, vcc_lo                     ; 0202cb47
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v46, v81, vcc_lo                      ; 0202a32e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[68:71], v1, s[16:19], null offen         ; c405c07c 40802044 00000001
	buffer_load_b128 v[84:87], v1, s[16:19], null offen offset:512 ; c405c07c 40802054 00020001
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v47, v156, vcc_lo                     ; 0203392f
	v_fma_mix_f32 v72, v102, v39, neg(0) op_sel_hi:[1,0,0]      ; cc200048 8a024f66
	v_fma_mix_f32 v102, v102, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200866 8a024f66
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v66, v157, vcc_lo                     ; 02033b42
	v_fma_mix_f32 v73, v103, v39, neg(0) op_sel_hi:[1,0,0]      ; cc200049 8a024f67
	v_fma_mix_f32 v103, v103, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200867 8a024f67
	v_fma_mix_f32 v78, v104, v39, neg(0) op_sel_hi:[1,0,0]      ; cc20004e 8a024f68
	v_fma_mix_f32 v104, v104, v39, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200868 8a024f68
	v_lshl_add_u32 v105, v105, 5, s25                           ; d6460069 00650b69
	v_lshl_add_u32 v106, v106, 5, s25                           ; d646006a 00650b6a
	v_lshl_add_u32 v107, v107, 5, s25                           ; d646006b 00650b6b
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[123:124]                ; 1a02f703
	v_lshl_add_u32 v112, v112, 5, s25                           ; d6460070 00650b70
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v72, v102, vcc_lo                     ; 0202cd48
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v73, v103, vcc_lo                     ; 0202cf49
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v78, v104, vcc_lo                     ; 0202d14e
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[105:106]            ; 1a02d3a3
(invalid instruction)                                        ; cc0f00ae
	v_min_num_f64_e32 v[1:2], v[174:175], v[106:107]            ; 1a02d5ae
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[107:108]            ; 1a02d7af
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[112:113]                ; 1a02e103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[174:175]            ; 1a035da3
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[175:176]            ; 1a035fa3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[3:4]                ; 1a0207a3
	v_permlanex16_b32 v79, v163, s5, s8 op_sel:[1,1]            ; d65c184f 00200ba3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f00a3
	v_min_num_f64_e32 v[1:2], v[163:164], v[79:80]              ; 1a029fa3
(invalid instruction)                                        ; d5321050
	v_cndmask_b32_e32 v1, v163, v163, vcc_lo                    ; 020347a3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f16_e32 v80, s3, v80                              ; 62a0a003
	v_cvt_f32_f16_e32 v81, v80                                  ; 7ea21750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v81, v81                                      ; 7ea25551
	v_fma_mix_f32 v96, v121, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200060 8a02a379
	v_fma_mix_f32 v94, v120, v81, neg(0) op_sel_hi:[1,0,0]      ; cc20005e 8a02a378
	v_fma_mix_f32 v120, v120, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200878 8a02a378
	v_fma_mix_f32 v97, v158, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200061 8a02a39e
	v_fma_mix_f32 v158, v158, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089e 8a02a39e
	v_fma_mix_f32 v121, v121, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200879 8a02a379
	v_fma_mix_f32 v91, v99, v81, neg(0) op_sel_hi:[1,0,0]       ; cc20005b 8a02a363
	v_fma_mix_f32 v99, v99, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200863 8a02a363
	v_fma_mix_f32 v90, v98, v81, neg(0) op_sel_hi:[1,0,0]       ; cc20005a 8a02a362
	v_fma_mix_f32 v98, v98, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200862 8a02a362
	v_fma_mix_f32 v100, v161, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200064 8a02a3a1
	v_fma_mix_f32 v161, v161, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a1 8a02a3a1
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v94, v120, vcc_lo                     ; 0202f15e
	v_fma_mix_f32 v101, v118, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200065 8a02a376
	v_fma_mix_f32 v118, v118, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200876 8a02a376
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v97, v158, vcc_lo                     ; 02033d61
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v96, v121, vcc_lo                     ; 0202f360
	v_fma_mix_f32 v102, v119, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200066 8a02a377
	v_fma_mix_f32 v119, v119, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a02a377
	v_fma_mix_f32 v103, v122, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200067 8a02a37a
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v90, v98, vcc_lo                      ; 0202c55a
	v_fma_mix_f32 v98, v159, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200062 8a02a39f
	v_fma_mix_f32 v159, v159, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089f 8a02a39f
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v91, v99, vcc_lo                      ; 0202c75b
	v_fma_mix_f32 v99, v160, v81, neg(0) op_sel_hi:[1,0,0]      ; cc200063 8a02a3a0
	v_fma_mix_f32 v160, v160, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a0 8a02a3a0
	v_fma_mix_f32 v122, v122, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087a 8a02a37a
	v_fma_mix_f32 v104, v123, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200068 8a02a37b
	v_fma_mix_f32 v123, v123, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087b 8a02a37b
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v101, v118, vcc_lo                    ; 0202ed65
	v_fma_mix_f32 v109, v105, v81, neg(0) op_sel_hi:[1,0,0]     ; cc20006d 8a02a369
	v_fma_mix_f32 v105, v105, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200869 8a02a369
	v_fma_mix_f32 v110, v106, v81, neg(0) op_sel_hi:[1,0,0]     ; cc20006e 8a02a36a
(invalid instruction)                                        ; d7694042
	v_cndmask_b32_e32 v1, v102, v119, vcc_lo                    ; 0202ef66
	v_fma_mix_f32 v106, v106, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086a 8a02a36a
	v_fma_mix_f32 v111, v107, v81, neg(0) op_sel_hi:[1,0,0]     ; cc20006f 8a02a36b
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v98, v159, vcc_lo                     ; 02033f62
	v_fma_mix_f32 v107, v107, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086b 8a02a36b
	v_fma_mix_f32 v113, v112, v81, neg(0) op_sel_hi:[1,0,0]     ; cc200071 8a02a370
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v99, v160, vcc_lo                     ; 02034163
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v100, v161, vcc_lo                    ; 02034364
	v_fma_mix_f32 v112, v112, v81, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200870 8a02a370
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v1, v103, v122, vcc_lo                    ; 0202f567
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[20:21], v[32:33], 0 ; cc464060 1a024114
(invalid instruction)                                        ; d7694043
	v_cndmask_b32_e32 v1, v104, v123, vcc_lo                    ; 0202f768
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[20:21], v[16:17], 0 ; cc464078 1a022114
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[20:21], v[30:31], 0 ; cc464080 1a023d14
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[20:21], v[38:39], 0 ; cc46409c 1a024d14
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v109, v105, vcc_lo                    ; 0202d36d
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v110, v106, vcc_lo                    ; 0202d56e
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v111, v107, vcc_lo                    ; 0202d76f
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v113, v112, vcc_lo                    ; 0202e171
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[64:65], v[96:103] ; cc464060 1d828108
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[8:9], v[18:19], v[120:127] ; cc464078 1de22508
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[8:9], v[34:35], v[128:135] ; cc464080 1e024508
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[76:77], v[52:53], v[96:103] ; cc464060 1d82694c
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[8:9], v[46:47], v[156:163] ; cc46409c 1e725d08
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[76:77], v[28:29], v[120:127] ; cc464078 1de2394c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[76:77], v[36:37], v[128:135] ; cc464080 1e02494c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[116:117], v[54:55], v[96:103] ; cc464060 1d826d74
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[76:77], v[66:67], v[156:163] ; cc46409c 1e72854c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[116:117], v[14:15], v[120:127] ; cc464078 1de21d74
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[116:117], v[10:11], v[128:135] ; cc464080 1e021574
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[116:117], v[72:73], v[156:163] ; cc46409c 1e729174
	s_load_b128 s[4:7], s[14:15], 0x3c                          ; f4004107 f800003c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[22:23], v[32:33], 0 ; cc464060 1a024116
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[22:23], v[16:17], 0 ; cc464070 1a022116
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d769004d
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769404d
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769404c
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_mul_f32_e32 v32, v144, v48                                ; 10406190
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[22:23], v[30:31], 0 ; cc464078 1a023d16
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d769404f
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769404e
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[22:23], v[38:39], 0 ; cc464080 1a024d16
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[62:63], v[64:65], v[96:103] ; cc464060 1d82813e
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[62:63], v[18:19], v[112:119] ; cc464070 1dc2253e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[62:63], v[34:35], v[120:127] ; cc464078 1de2453e
	v_dual_mul_f32 v34, v146, v50 :: v_dual_mul_f32 v33, v145, v49 ; c8c66592 22206391
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[62:63], v[46:47], v[128:135] ; cc464080 1e025d3e
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[82:83], v[52:53], v[96:103] ; cc464060 1d826952
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[82:83], v[28:29], v[112:119] ; cc464070 1dc23952
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[82:83], v[36:37], v[120:127] ; cc464078 1de24952
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_dual_mul_f32 v36, v148, v40 :: v_dual_mul_f32 v35, v147, v51 ; c8c65194 24226793
	v_dual_mul_f32 v38, v150, v42 :: v_dual_mul_f32 v37, v149, v41 ; c8c65596 26245395
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[82:83], v[66:67], v[128:135] ; cc464080 1e028552
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[92:93], v[54:55], v[96:103] ; cc464060 1d826d5c
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[92:93], v[14:15], v[112:119] ; cc464070 1dc21d5c
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[92:93], v[10:11], v[120:127] ; cc464078 1de2155c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[72:73], v[128:135] ; cc464080 1e02915c
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_mul_f32 v102, v25, v42 :: v_dual_mul_f32 v101, v24, v41 ; c8c65519 66645318
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_dual_mul_f32 v96, v152, v48 :: v_dual_mul_f32 v39, v151, v43 ; c8c66198 60265797
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_dual_mul_f32 v98, v154, v50 :: v_dual_mul_f32 v97, v153, v49 ; c8c6659a 62606399
	s_load_b256 s[24:31], s[0:1], 0x0                           ; f4006600 f8000000
	v_dual_mul_f32 v100, v5, v40 :: v_dual_mul_f32 v99, v155, v51 ; c8c65105 6462679b
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_mul_f32 v112, v176, v48 :: v_dual_mul_f32 v103, v26, v43 ; c8c661b0 7066571a
	v_mul_f32_e32 v113, v177, v49                               ; 10e263b1
	v_dual_mul_f32 v115, v179, v51 :: v_dual_mul_f32 v114, v178, v50 ; c8c667b3 737265b2
	v_dual_mul_f32 v117, v181, v41 :: v_dual_mul_f32 v116, v180, v40 ; c8c653b5 757451b4
	v_dual_mul_f32 v119, v183, v43 :: v_dual_mul_f32 v118, v182, v42 ; c8c657b7 777655b6
	v_dual_mul_f32 v121, v185, v49 :: v_dual_mul_f32 v120, v184, v48 ; c8c663b9 797861b8
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v123, v187, v51 :: v_dual_mul_f32 v122, v186, v50 ; c8c667bb 7b7a65ba
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v125, v189, v41 :: v_dual_mul_f32 v124, v188, v40 ; c8c653bd 7d7c51bc
	v_dual_mul_f32 v127, v191, v43 :: v_dual_mul_f32 v126, v190, v42 ; c8c657bf 7f7e55be
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[68:69], v[8:9], v[32:39] ; cc464020 1c821144
	s_mov_b32 vcc_lo, 0xaaaaaaaa                                ; beea00ff aaaaaaaa
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[68:69], v[20:21], v[96:103] ; cc464060 1d822944
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[68:69], v[76:77], v[112:119] ; cc464070 1dc29944
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[68:69], v[78:79], v[120:127] ; cc464078 1de29d44
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl1_add_u32 s32, ttmp9, s4                              ; 87200475
	s_lshl_b32 s33, ttmp7, 1                                    ; 84218173
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[84:85], v[10:11], v[32:39] ; cc464020 1c821554
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[84:85], v[14:15], v[96:103] ; cc464060 1d821d54
	s_add_co_u32 s34, s33, s5                                   ; 80220521
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[84:85], v[16:17], v[112:119] ; cc464070 1dc22154
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[84:85], v[18:19], v[120:127] ; cc464078 1de22554
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_dual_cndmask_b32 v129, v33, v37 :: v_dual_cndmask_b32 v128, v32, v36 ; ca524b21 81804920
	buffer_load_b128 v[28:31], v44, s[20:23], null offen offset:64 ; c405c07c 4080281c 0000402c
	v_dual_cndmask_b32 v131, v35, v39 :: v_dual_cndmask_b32 v130, v34, v38 ; ca524f23 83824d22
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_cndmask_b32 v39, v39, v35 :: v_dual_cndmask_b32 v38, v38, v34 ; ca524727 27264526
	v_dual_cndmask_b32 v37, v37, v33 :: v_dual_cndmask_b32 v36, v36, v32 ; ca524325 25244124
	buffer_load_b128 v[32:35], v44, s[20:23], null offen offset:80 ; c405c07c 40802820 0000502c
	s_mov_b32 s35, 0xf0f0f0f0                                   ; bea300ff f0f0f0f0
	v_and_b32_e32 v151, 1, v0                                   ; 372e0081
	v_bfe_u32 v146, v0, 1, 1                                    ; d6100092 02050300
	v_bfe_u32 v147, v0, 3, 1                                    ; d6100093 02050700
	v_bfe_u32 v0, v0, 2, 1                                      ; d6100000 02050500
	v_add_f32_dpp v39, v39, v131 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064f06fa ff0cb127
	v_add_f32_dpp v38, v38, v130 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064d04fa ff0cb126
	v_add_f32_dpp v37, v37, v129 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064b02fa ff0cb125
	v_add_f32_dpp v36, v36, v128 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 064900fa ff0cb124
	v_lshlrev_b32_e32 v151, 2, v151                             ; 312f2e82
	s_ashr_i32 s36, s34, 1                                      ; 86248122
	s_ashr_i32 s37, s32, 1                                      ; 86258120
	v_lshlrev_b32_e32 v0, 1, v0                                 ; 30000081
(invalid instruction)                                        ; d58a0085
	v_cndmask_b32_e32 v0, v39, v128, vcc_lo                     ; 02010127
	v_lshl_add_u32 v147, v147, 2, v146                          ; d6460093 06490593
(invalid instruction)                                        ; d58a0084
	v_cndmask_b32_e32 v0, v38, v128, vcc_lo                     ; 02010126
(invalid instruction)                                        ; d58a0087
	v_cndmask_b32_e32 v0, v37, v128, vcc_lo                     ; 02010125
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s36, s36, s7                                      ; 96240724
	v_cndmask_b32_e64 v39, v39, v37, s35                        ; d5010027 008e4b27
	v_cndmask_b32_e64 v38, v38, v36, s35                        ; d5010026 008e4926
(invalid instruction)                                        ; d58a0086
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
	s_mov_b32 s40, 0x3e800000                                   ; bea800ff 3e800000
	v_lshl_add_u32 v147, v147, 4, v169                          ; d6460093 06a50993
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s38, s36, s37                                  ; 80262524
	s_and_b32 s4, s4, 1                                         ; 8b048104
	s_bitset0_b32 s6, 0                                         ; be861080
(invalid instruction)                                        ; d58a0091
	v_cndmask_b32_dpp v0, v38, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6426
(invalid instruction)                                        ; d58a4091
	v_cndmask_b32_dpp v0, v39, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6427
	v_cndmask_b32_e64 v144, v134, v132, s35                     ; d5010090 008f0986
	v_cndmask_b16 v144, v135, v133, s35                         ; d65d4090 008f0b87
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s4, s4, 5                                        ; 84048504
	s_and_b32 s5, s5, 1                                         ; 8b058105
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s5, s5, 7                                        ; 84058705
(invalid instruction)                                        ; cc0f0090
	v_min_num_f64_e32 v[1:2], v[144:145], v[145:146]            ; 1a032390
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s39, s5, s4                                    ; 80270405
	s_lshl_b32 s38, s38, 9                                      ; 84268926
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s41, s6, s38                                   ; 80292606
	v_fma_mix_f32 v148, s40, v144, neg(0) op_sel_hi:[0,1,0]     ; cc200094 92032028
	v_fma_mix_f32 v144, s40, v144, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201090 92032028
	v_add3_u32 v150, v147, s41, s39                             ; d6550096 009c5393
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c2
(invalid instruction)                                        ; d7690095
	v_cndmask_b32_e32 v1, v148, v144, vcc_lo                    ; 02032194
	v_add3_u32 v150, v0, v150, v151                             ; d6550096 065f2d00
	buffer_store_b16 v149, v150, s[28:31], null offen           ; c406407c 40803895 00000096
	s_mul_i32 s42, s33, s12                                     ; 962a0c21
	s_lshl1_add_u32 s42, ttmp9, s42                             ; 872a2a75
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s42, s42, 9                                      ; 842a892a
	s_add_co_u32 s43, s2, s42                                   ; 802b2a02
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add3_u32 v152, v2, s43, v4                                ; d6550098 04105702
	buffer_store_b64 v[22:23], v152, s[24:27], null offen       ; c406c07c 40803016 00000098
	v_dual_cndmask_b32 v154, v97, v101 :: v_dual_cndmask_b32 v153, v96, v100 ; ca52cb61 9a98c960
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_cndmask_b32 v101, v101, v97 :: v_dual_cndmask_b32 v100, v100, v96 ; ca52c365 6564c164
	v_dual_cndmask_b32 v156, v99, v103 :: v_dual_cndmask_b32 v155, v98, v102 ; ca52cf63 9c9acd62
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_cndmask_b32 v103, v103, v99 :: v_dual_cndmask_b32 v102, v102, v98 ; ca52c767 6766c566
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v100, v100, v153 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06c932fa ff0cb164
	s_add_co_u32 s32, s32, 1                                    ; 80208120
	v_add_f32_dpp v101, v101, v154 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cb34fa ff0cb165
	v_add_f32_dpp v103, v103, v156 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cf38fa ff0cb167
	v_add_f32_dpp v102, v102, v155 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06cd36fa ff0cb166
	s_ashr_i32 s44, s32, 1                                      ; 862c8120
(invalid instruction)                                        ; d58a009f
	v_cndmask_b32_e32 v0, v100, v128, vcc_lo                    ; 02010164
(invalid instruction)                                        ; d58a00a0
	v_cndmask_b32_e32 v0, v101, v128, vcc_lo                    ; 02010165
	s_add_co_u32 s36, s36, s44                                  ; 80242c24
	s_and_b32 s32, s32, 1                                       ; 8b208120
(invalid instruction)                                        ; d58a009e
	v_cndmask_b32_e32 v0, v103, v128, vcc_lo                    ; 02010167
	v_cndmask_b32_e64 v103, v103, v101, s35                     ; d5010067 008ecb67
(invalid instruction)                                        ; d58a009d
	v_cndmask_b32_e32 v0, v102, v128, vcc_lo                    ; 02010166
	v_cndmask_b32_e64 v102, v102, v100, s35                     ; d5010066 008ec966
	s_lshl_b32 s32, s32, 5                                      ; 84208520
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s5, s5, s32                                    ; 80052005
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s36, s36, 9                                      ; 84248924
	v_cndmask_b32_e64 v161, v159, v157, s35                     ; d50100a1 008f3b9f
	v_cndmask_b16 v161, v160, v158, s35                         ; d65d40a1 008f3da0
(invalid instruction)                                        ; d58a00a2
	v_cndmask_b32_dpp v0, v102, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6466
(invalid instruction)                                        ; d58a40a2
	v_cndmask_b32_dpp v0, v103, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6467
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s45, s6, s36                                   ; 802d2406
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870119
	v_add3_u32 v172, v147, s45, s5                              ; d65500ac 00145b93
(invalid instruction)                                        ; cc0f00a1
	v_min_num_f64_e32 v[1:2], v[161:162], v[162:163]            ; 1a0345a1
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_add3_u32 v172, v0, v172, v151                             ; d65500ac 065f5900
	v_fma_mix_f32 v163, s40, v161, neg(0) op_sel_hi:[0,1,0]     ; cc2000a3 92034228
	v_fma_mix_f32 v161, s40, v161, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc2010a1 92034228
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d76900a9
	v_cndmask_b32_e32 v1, v163, v161, vcc_lo                    ; 020343a3
	buffer_store_b16 v169, v172, s[28:31], null offen           ; c406407c 408038a9 000000ac
	s_addk_co_i32 s42, 0x200                                    ; b7aa0200
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s42, s2, s42                                   ; 802a2a02
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v173, v2, s42, v4                                ; d65500ad 04105502
	buffer_store_b64 v[22:23], v173, s[24:27], null offen       ; c406c07c 40803016 000000ad
	v_dual_cndmask_b32 v175, v113, v117 :: v_dual_cndmask_b32 v174, v112, v116 ; ca52eb71 afaee970
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_cndmask_b32 v117, v117, v113 :: v_dual_cndmask_b32 v116, v116, v112 ; ca52e375 7574e174
	v_dual_cndmask_b32 v177, v115, v119 :: v_dual_cndmask_b32 v176, v114, v118 ; ca52ef73 b1b0ed72
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_cndmask_b32 v119, v119, v115 :: v_dual_cndmask_b32 v118, v118, v114 ; ca52e777 7776e576
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v117, v117, v175 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06eb5efa ff0cb175
	s_add_co_u32 s34, s34, 1                                    ; 80228122
	v_add_f32_dpp v116, v116, v174 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06e95cfa ff0cb174
	v_add_f32_dpp v119, v119, v177 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ef62fa ff0cb177
	v_add_f32_dpp v118, v118, v176 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ed60fa ff0cb176
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_ashr_i32 s46, s34, 1                                      ; 862e8122
(invalid instruction)                                        ; d58a00b5
	v_cndmask_b32_e32 v0, v117, v128, vcc_lo                    ; 02010175
(invalid instruction)                                        ; d58a00b4
	v_cndmask_b32_e32 v0, v116, v128, vcc_lo                    ; 02010174
	s_mul_i32 s46, s46, s7                                      ; 962e072e
(invalid instruction)                                        ; d58a00b3
	v_cndmask_b32_e32 v0, v119, v128, vcc_lo                    ; 02010177
	v_cndmask_b32_e64 v119, v119, v117, s35                     ; d5010077 008eeb77
(invalid instruction)                                        ; d58a00b2
	v_cndmask_b32_e32 v0, v118, v128, vcc_lo                    ; 02010176
	v_cndmask_b32_e64 v118, v118, v116, s35                     ; d5010076 008ee976
	s_add_co_u32 s37, s46, s37                                  ; 8025252e
	s_and_b32 s34, s34, 1                                       ; 8b228122
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_cndmask_b32_e64 v182, v180, v178, s35                     ; d50100b6 008f65b4
	v_cndmask_b16 v182, v181, v179, s35                         ; d65d40b6 008f67b5
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s34, s34, 7                                      ; 84228722
(invalid instruction)                                        ; d58a00b7
	v_cndmask_b32_dpp v0, v118, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6476
(invalid instruction)                                        ; d58a40b7
	v_cndmask_b32_dpp v0, v119, v128, vcc_lo row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 020100fa ff0d6477
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s4, s34, s4                                    ; 80040422
	s_lshl_b32 s37, s37, 9                                      ; 84258925
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s47, s6, s37                                   ; 802f2506
(invalid instruction)                                        ; cc0f00b6
	v_min_num_f64_e32 v[1:2], v[182:183], v[183:184]            ; 1a036fb6
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_add3_u32 v186, v147, s47, s4                              ; d65500ba 00105f93
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870132
	v_fma_mix_f32 v184, s40, v182, neg(0) op_sel_hi:[0,1,0]     ; cc2000b8 92036c28
	v_fma_mix_f32 v182, s40, v182, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc2010b6 92036c28
	v_add3_u32 v186, v0, v186, v151                             ; d65500ba 065f7500
(invalid instruction)                                        ; d76900b9
	v_cndmask_b32_e32 v1, v184, v182, vcc_lo                    ; 02036db8
	buffer_store_b16 v185, v186, s[28:31], null offen           ; c406407c 408038b9 000000ba
	s_add_co_u32 s33, s33, 1                                    ; 80218121
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s33, s33, s12                                     ; 96210c21
	s_lshl1_add_u32 s33, ttmp9, s33                             ; 87212175
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s33, s33, 9                                      ; 84218921
	s_add_co_u32 s48, s2, s33                                   ; 80302102
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	v_add3_u32 v187, v2, s48, v4                                ; d65500bb 04106102
	buffer_store_b64 v[22:23], v187, s[24:27], null offen       ; c406c07c 40803016 000000bb
	v_dual_cndmask_b32 v189, v121, v125 :: v_dual_cndmask_b32 v188, v120, v124 ; ca52fb79 bdbcf978
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_dual_cndmask_b32 v125, v125, v121 :: v_dual_cndmask_b32 v124, v124, v120 ; ca52f37d 7d7cf17c
	v_dual_cndmask_b32 v191, v123, v127 :: v_dual_cndmask_b32 v190, v122, v126 ; ca52ff7b bfbefd7a
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_cndmask_b32 v127, v127, v123 :: v_dual_cndmask_b32 v126, v126, v122 ; ca52f77f 7f7ef57e
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v125, v125, v189 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06fb7afa ff0cb17d
	s_add_co_u32 s46, s46, s44                                  ; 802e2c2e
	v_add_f32_dpp v124, v124, v188 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06f978fa ff0cb17c
	s_add_co_u32 s34, s34, s32                                  ; 80222022
	v_add_f32_dpp v126, v126, v190 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06fd7cfa ff0cb17e
	v_add_f32_dpp v127, v127, v191 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06ff7efa ff0cb17f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s46, s46, 9                                      ; 842e892e
	v_cvt_f16_f32_e32 v3, v125                                  ; 7e06157d
	v_cvt_f16_f32_e32 v1, v124                                  ; 7e02157c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s49, s6, s46                                   ; 80312e06
(invalid instruction)                                        ; d58a00bf
	v_cndmask_b32_e32 v0, v126, v128, vcc_lo                    ; 0201017e
	v_cndmask_b32_e64 v126, v126, v124, s35                     ; d501007e 008ef97e
(invalid instruction)                                        ; d58a40bf
	v_cndmask_b32_e32 v0, v127, v128, vcc_lo                    ; 0201017f
	v_cndmask_b32_e64 v127, v127, v125, s35                     ; d501007f 008efb7f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v36, v147, s49, s34                              ; d6550024 00886393
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870154
	v_cvt_f16_f32_dpp v24, v126 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e3014fa ff0d647e
	v_cndmask_b32_e64 v5, v1, v191, s35                         ; d5010005 008f7f01
	v_cndmask_b16 v5, v3, v191, s35                             ; d65d5005 008f7f03
(invalid instruction)                                        ; 7f3014fa
(invalid instruction)                                        ; ff0d647f
	v_add3_u32 v36, v0, v36, v151                               ; d6550024 065e4900
(invalid instruction)                                        ; cc0f0005
	v_min_num_f64_e32 v[1:2], v[5:6], v[24:25]                  ; 1a023105
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v25, s40, v5, neg(0) op_sel_hi:[0,1,0]        ; cc200019 92020a28
	v_fma_mix_f32 v5, s40, v5, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201005 92020a28
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v1, v25, v5, vcc_lo                       ; 02020b19
	buffer_store_b16 v26, v36, s[28:31], null offen             ; c406407c 4080381a 00000024
	s_addk_co_i32 s33, 0x200                                    ; b7a10200
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s2, s2, s33                                    ; 80022102
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v37, v2, s2, v4                                  ; d6550025 04100502
	buffer_store_b64 v[22:23], v37, s[24:27], null offen        ; c406c07c 40803016 00000025
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_dual_mul_f32 v41, v89, v29 :: v_dual_mul_f32 v40, v88, v28 ; c8c63b59 29283958
	v_dual_mul_f32 v49, v75, v29 :: v_dual_mul_f32 v48, v74, v28 ; c8c63b4b 3130394a
	v_dual_mul_f32 v51, v7, v31 :: v_dual_mul_f32 v50, v6, v30  ; c8c63f07 33323d06
	v_dual_mul_f32 v43, v57, v31 :: v_dual_mul_f32 v42, v56, v30 ; c8c63f39 2b2a3d38
	v_dual_mul_f32 v57, v165, v29 :: v_dual_mul_f32 v56, v164, v28 ; c8c63ba5 393839a4
	v_dual_mul_f32 v91, v139, v31 :: v_dual_mul_f32 v90, v138, v30 ; c8c63f8b 5b5a3d8a
	v_dual_mul_f32 v89, v137, v29 :: v_dual_mul_f32 v88, v136, v28 ; c8c63b89 59583988
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mul_f32 v47, v61, v35 :: v_dual_mul_f32 v46, v60, v34 ; c8c6473d 2f2e453c
	v_dual_mul_f32 v63, v108, v35 :: v_dual_mul_f32 v62, v171, v34 ; c8c6476c 3f3e45ab
	v_dual_mul_f32 v61, v168, v33 :: v_dual_mul_f32 v60, v170, v32 ; c8c643a8 3d3c41aa
	v_dual_mul_f32 v53, v12, v33 :: v_dual_mul_f32 v52, v95, v32 ; c8c6430c 3534415f
	v_dual_mul_f32 v55, v27, v35 :: v_dual_mul_f32 v54, v13, v34 ; c8c6471b 3736450d
	v_dual_mul_f32 v93, v141, v33 :: v_dual_mul_f32 v92, v140, v32 ; c8c6438d 5d5c418c
	v_dual_mul_f32 v45, v59, v33 :: v_dual_mul_f32 v44, v58, v32 ; c8c6433b 2d2c413a
	v_dual_mul_f32 v59, v167, v31 :: v_dual_mul_f32 v58, v166, v30 ; c8c63fa7 3b3a3da6
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[70:71], v[8:9], v[40:47] ; cc464028 1ca21146
	v_dual_mul_f32 v95, v143, v35 :: v_dual_mul_f32 v94, v142, v34 ; c8c6478f 5f5e458e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[70:71], v[20:21], v[48:55] ; cc464030 1cc22946
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[70:71], v[78:79], v[88:95] ; cc464058 1d629d46
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[70:71], v[76:77], v[56:63] ; cc464038 1ce29946
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[86:87], v[10:11], v[40:47] ; cc464028 1ca21556
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[86:87], v[14:15], v[48:55] ; cc464030 1cc21d56
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[86:87], v[18:19], v[88:95] ; cc464058 1d622556
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[86:87], v[16:17], v[56:63] ; cc464038 1ce22156
	v_dual_cndmask_b32 v39, v41, v45 :: v_dual_cndmask_b32 v38, v40, v44 ; ca525b29 27265928
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	v_dual_cndmask_b32 v45, v45, v41 :: v_dual_cndmask_b32 v44, v44, v40 ; ca52532d 2d2c512c
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_cndmask_b32 v41, v43, v47 :: v_dual_cndmask_b32 v40, v42, v46 ; ca525f2b 29285d2a
	v_dual_cndmask_b32 v47, v47, v43 :: v_dual_cndmask_b32 v46, v46, v42 ; ca52572f 2f2e552e
	v_add_f32_dpp v45, v45, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 065a4efa ff0cb12d
	v_add_f32_dpp v44, v44, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06584cfa ff0cb12c
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_add_f32_dpp v47, v47, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 065e52fa ff0cb12f
	v_add_f32_dpp v46, v46, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 065c50fa ff0cb12e
	s_movk_i32 s50, 0x100                                       ; b0320100
	v_cvt_f16_f32_e32 v65, v45                                  ; 7e82152d
	v_cvt_f16_f32_e32 v64, v44                                  ; 7e80152c
	s_add_co_u32 s38, s38, s50                                  ; 80263226
	v_cvt_f16_f32_e32 v43, v47                                  ; 7e56152f
	v_cndmask_b32_e64 v47, v47, v45, s35                        ; d501002f 008e5b2f
	v_cvt_f16_f32_e32 v42, v46                                  ; 7e54152e
	v_cndmask_b32_e64 v46, v46, v44, s35                        ; d501002e 008e592e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s38, s6, s38                                   ; 80262606
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v70, v147, s38, s39                              ; d6550046 009c4d93
	v_cndmask_b32_e64 v66, v64, v42, s35                        ; d5010042 008e5540
	v_cndmask_b16 v66, v65, v43, s35                            ; d65d4042 008e5741
	v_cvt_f16_f32_dpp v67, v46 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7e8614fa ff0d642e
(invalid instruction)                                        ; 7f8614fa
(invalid instruction)                                        ; ff0d642f
	v_add3_u32 v70, v0, v70, v151                               ; d6550046 065e8d00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f0042
	v_min_num_f64_e32 v[1:2], v[66:67], v[67:68]                ; 1a028742
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v68, s40, v66, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201044 92028428
	v_fma_mix_f32 v66, s40, v66, neg(0) op_sel_hi:[0,1,0]       ; cc200042 92028428
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690045
	v_cndmask_b32_e32 v1, v66, v68, vcc_lo                      ; 02028942
	buffer_store_b16 v69, v70, s[28:31], null offen             ; c406407c 40803845 00000046
	v_add3_u32 v71, v4, s43, s50                                ; d6550047 00c85704
	v_add_nc_u32_e32 v71, v71, v2                               ; 4a8e0547
	buffer_store_b64 v[6:7], v71, s[24:27], null offen          ; c406c07c 40803006 00000047
	v_dual_cndmask_b32 v73, v49, v53 :: v_dual_cndmask_b32 v72, v48, v52 ; ca526b31 49486930
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
	v_dual_cndmask_b32 v53, v53, v49 :: v_dual_cndmask_b32 v52, v52, v48 ; ca526335 35346134
	v_dual_cndmask_b32 v75, v51, v55 :: v_dual_cndmask_b32 v74, v50, v54 ; ca526f33 4b4a6d32
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	v_dual_cndmask_b32 v55, v55, v51 :: v_dual_cndmask_b32 v54, v54, v50 ; ca526737 37366536
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v53, v53, v73 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066a92fa ff0cb135
	v_add_f32_dpp v52, v52, v72 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066890fa ff0cb134
	v_add_f32_dpp v54, v54, v74 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066c94fa ff0cb136
	v_add_f32_dpp v55, v55, v75 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 066e96fa ff0cb137
	s_add_co_u32 s36, s36, s50                                  ; 80243224
	v_cvt_f16_f32_e32 v79, v53                                  ; 7e9e1535
	v_cvt_f16_f32_e32 v78, v52                                  ; 7e9c1534
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s36, s6, s36                                   ; 80242406
	v_cvt_f16_f32_e32 v76, v54                                  ; 7e981536
	v_cndmask_b32_e64 v54, v54, v52, s35                        ; d5010036 008e6936
	v_cvt_f16_f32_e32 v77, v55                                  ; 7e9a1537
	v_cndmask_b32_e64 v55, v55, v53, s35                        ; d5010037 008e6b37
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v84, v147, s36, s5                               ; d6550054 00144993
	v_cndmask_b32_e64 v80, v78, v76, s35                        ; d5010050 008e994e
	v_cvt_f16_f32_dpp v81, v54 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7ea214fa ff0d6436
	v_cndmask_b16 v80, v79, v77, s35                            ; d65d4050 008e9b4f
(invalid instruction)                                        ; 7fa214fa
(invalid instruction)                                        ; ff0d6437
	v_add3_u32 v84, v0, v84, v151                               ; d6550054 065ea900
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[81:82]                ; 1a02a350
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v82, s40, v80, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201052 9202a028
	v_fma_mix_f32 v80, s40, v80, neg(0) op_sel_hi:[0,1,0]       ; cc200050 9202a028
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v1, v80, v82, vcc_lo                      ; 0202a550
	buffer_store_b16 v83, v84, s[28:31], null offen             ; c406407c 40803853 00000054
	v_add3_u32 v85, v4, s42, s50                                ; d6550055 00c85504
	v_add_nc_u32_e32 v85, v85, v2                               ; 4aaa0555
	buffer_store_b64 v[6:7], v85, s[24:27], null offen          ; c406c07c 40803006 00000055
	v_dual_cndmask_b32 v87, v57, v61 :: v_dual_cndmask_b32 v86, v56, v60 ; ca527b39 57567938
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
	v_dual_cndmask_b32 v61, v61, v57 :: v_dual_cndmask_b32 v60, v60, v56 ; ca52733d 3d3c713c
	v_dual_cndmask_b32 v97, v59, v63 :: v_dual_cndmask_b32 v96, v58, v62 ; ca527f3b 61607d3a
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v62, v63, vcc_lo                      ; 02027f3e
	v_dual_cndmask_b32 v63, v63, v59 :: v_dual_cndmask_b32 v62, v62, v58 ; ca52773f 3f3e753e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                      ; 02027338
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v60, v60, v86 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 0678acfa ff0cb13c
	v_add_f32_dpp v61, v61, v87 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067aaefa ff0cb13d
	v_add_f32_dpp v62, v62, v96 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067cc0fa ff0cb13e
	v_add_f32_dpp v63, v63, v97 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 067ec2fa ff0cb13f
	s_add_co_u32 s37, s37, s50                                  ; 80253225
	v_cvt_f16_f32_e32 v100, v60                                 ; 7ec8153c
	v_cvt_f16_f32_e32 v101, v61                                 ; 7eca153d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s6, s37                                   ; 80252506
	v_cvt_f16_f32_e32 v98, v62                                  ; 7ec4153e
	v_cndmask_b32_e64 v62, v62, v60, s35                        ; d501003e 008e793e
	v_cvt_f16_f32_e32 v99, v63                                  ; 7ec6153f
	v_cndmask_b32_e64 v63, v63, v61, s35                        ; d501003f 008e7b3f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v106, v147, s37, s4                              ; d655006a 00104b93
	v_cndmask_b32_e64 v102, v100, v98, s35                      ; d5010066 008ec564
	v_cvt_f16_f32_dpp v103, v62 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7ece14fa ff0d643e
	v_cndmask_b16 v102, v101, v99, s35                          ; d65d4066 008ec765
(invalid instruction)                                        ; 7fce14fa
(invalid instruction)                                        ; ff0d643f
	v_add3_u32 v106, v0, v106, v151                             ; d655006a 065ed500
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f0066
	v_min_num_f64_e32 v[1:2], v[102:103], v[103:104]            ; 1a02cf66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v104, s40, v102, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201068 9202cc28
	v_fma_mix_f32 v102, s40, v102, neg(0) op_sel_hi:[0,1,0]     ; cc200066 9202cc28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v102, v104, vcc_lo                    ; 0202d166
	buffer_store_b16 v105, v106, s[28:31], null offen           ; c406407c 40803869 0000006a
	v_add3_u32 v107, v4, s48, s50                               ; d655006b 00c86104
	v_add_nc_u32_e32 v107, v107, v2                             ; 4ad6056b
	buffer_store_b64 v[6:7], v107, s[24:27], null offen         ; c406c07c 40803006 0000006b
	v_dual_cndmask_b32 v109, v89, v93 :: v_dual_cndmask_b32 v108, v88, v92 ; ca52bb59 6d6cb958
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_dual_cndmask_b32 v93, v93, v89 :: v_dual_cndmask_b32 v92, v92, v88 ; ca52b35d 5d5cb15c
	v_dual_cndmask_b32 v111, v91, v95 :: v_dual_cndmask_b32 v110, v90, v94 ; ca52bf5b 6f6ebd5a
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_dual_cndmask_b32 v95, v95, v91 :: v_dual_cndmask_b32 v94, v94, v90 ; ca52b75f 5f5eb55e
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_add_f32_dpp v93, v93, v109 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06badafa ff0cb15d
	v_add_f32_dpp v92, v92, v108 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06b8d8fa ff0cb15c
	v_add_f32_dpp v94, v94, v110 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06bcdcfa ff0cb15e
	v_add_f32_dpp v95, v95, v111 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 06bedefa ff0cb15f
	s_add_co_u32 s46, s46, s50                                  ; 802e322e
	v_cvt_f16_f32_e32 v115, v93                                 ; 7ee6155d
	v_cvt_f16_f32_e32 v114, v92                                 ; 7ee4155c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s6, s6, s46                                    ; 80062e06
	v_cvt_f16_f32_e32 v112, v94                                 ; 7ee0155e
	v_cndmask_b32_e64 v94, v94, v92, s35                        ; d501005e 008eb95e
	v_cvt_f16_f32_e32 v113, v95                                 ; 7ee2155f
	v_cndmask_b32_e64 v95, v95, v93, s35                        ; d501005f 008ebb5f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v147, v147, s6, s34                              ; d6550093 00880d93
	v_cndmask_b32_e64 v116, v114, v112, s35                     ; d5010074 008ee172
	v_cvt_f16_f32_dpp v117, v94 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1 fi:1 ; 7eea14fa ff0d645e
	v_cndmask_b16 v116, v115, v113, s35                         ; d65d4074 008ee373
(invalid instruction)                                        ; 7fea14fa
(invalid instruction)                                        ; ff0d645f
	v_add3_u32 v0, v0, v147, v151                               ; d6550000 065f2700
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; cc0f0074
	v_min_num_f64_e32 v[1:2], v[116:117], v[117:118]            ; 1a02eb74
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_fma_mix_f32 v118, s40, v116, neg(0) op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201076 9202e828
	v_fma_mix_f32 v116, s40, v116, neg(0) op_sel_hi:[0,1,0]     ; cc200074 9202e828
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
(invalid instruction)                                        ; d7690077
	v_cndmask_b32_e32 v1, v116, v118, vcc_lo                    ; 0202ed74
	buffer_store_b16 v119, v0, s[28:31], null offen             ; c406407c 40803877 00000000
	v_add3_u32 v4, v4, s2, s50                                  ; d6550004 00c80504
	v_add_nc_u32_e32 v4, v4, v2                                 ; 4a080504
	buffer_store_b64 v[6:7], v4, s[24:27], null offen           ; c406c07c 40803006 00000004
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
