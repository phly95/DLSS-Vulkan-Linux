BB0:
	v_lshl_add_u32 v1, ttmp9, 6, v0                             ; d6460001 04010c75
	s_and_b32 s8, s7, 3                                         ; 8b088307
	s_and_b32 s9, s6, 3                                         ; 8b098306
	s_mul_i32 s7, s6, s7                                        ; 96070706
	s_max_u32 s9, s9, s8                                        ; 8a890809
	s_lshl_b32 s10, s7, 9                                       ; 840a8907
	s_cmp_lg_i32 s9, 0                                          ; bf018009
	v_cmp_gt_u32_e32 vcc_lo, s10, v1                            ; 7c98020a
	s_cselect_b32 s11, -1, 0                                    ; 980b80c1
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_and_b32 exec_lo, vcc_lo, s11                              ; 8b7e0b6a
	s_cbranch_execz BB6                                         ; bfa5007d
BB1:
	s_mov_b32 s8, s0                                            ; be880000
	s_movk_i32 s9, 0x8000                                       ; b0098000
	s_clause 0x1                                                ; bf850001
	s_load_b256 s[16:23], s[8:9], 0x0                           ; f4006404 f8000000
	s_load_b128 s[12:15], s[8:9], 0x20                          ; f4004304 f8000020
	s_cvt_f32_u32 s8, s6                                        ; be886506
	v_lshrrev_b32_e32 v2, 9, v1                                 ; 32040289
(invalid instruction)                                        ; d6840008
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                      ; 02010008
	s_mul_f32 s8, s8, 0x4f7ffffe                                ; a208ff08 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s8, s8                                        ; be886708
	v_and_b32_e32 v14, 15, v0                                   ; 361c008f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s9, s6, s8                                        ; 96090806
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s9, 0, s9                                      ; 81890980
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s9, s8, s9                                     ; 96890908
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s8, s8, s9                                     ; 80080908
	s_lshr_b32 s24, s6, 2                                       ; 85188206
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d0003
	v_cndmask_b32_e32 v0, v2, v8, vcc_lo                        ; 02001102
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                        ; 02000d03
	v_and_b32_e32 v11, 0x1ff, v1                                ; 361602ff 000001ff
	v_sub_nc_u32_e32 v2, v2, v4                                 ; 4c040902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d7026a05
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                        ; 02020406
	v_cndmask_b32_e32 v5, v5, v2, vcc_lo                        ; 020a0505
	v_subrev_co_ci_u32_e32 v3, vcc_lo, -1, v3, vcc_lo           ; 440606c1
	v_lshrrev_b32_e32 v12, 4, v11                               ; 32181684
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
(invalid instruction)                                        ; d7020a06
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                        ; 02020a06
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v6, v6, v5, s10                           ; d5010006 002a0b06
	v_subrev_co_ci_u32_e64 v3, vcc_lo, -1, v3, s10              ; d5226a03 002a06c1
	v_and_b32_e32 v10, 3, v6                                    ; 36140c83
	v_lshrrev_b32_e32 v8, 2, v6                                 ; 32100c82
	v_and_b32_e32 v9, 3, v3                                     ; 36120683
	v_lshrrev_b32_e32 v7, 2, v3                                 ; 320e0682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0007
	v_cndmask_b32_e32 v0, v7, v24, vcc_lo                       ; 02003107
	v_add_lshl_u32 v7, v7, v8, 4                                ; d6470007 02121107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v9, v9, 2, v7                                ; d6460009 041d0509
	v_add_nc_u32_e32 v9, v9, v10                                ; 4a121509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_lshrrev_b32_e32 v13, 4, v9                                ; 321a1284
	v_and_b32_e32 v9, 15, v9                                    ; 3612128f
	v_lshl_add_u32 v13, v13, 5, v12                             ; d646000d 04310b0d
	v_lshlrev_b32_e32 v9, 4, v9                                 ; 30121284
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v13, v13, 8, v9                              ; d646000d 0425110d
	v_add_nc_u32_e32 v13, v13, v14                              ; 4a1a1d0d
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v15, s2, v13                               ; 4a1e1a02
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_u8 v16, v15, s[20:23], null offen           ; c407807c 40802810 0000000f
	v_add_lshl_u32 v17, s4, v11, 1                              ; d6470011 02061604
	buffer_load_d16_b16 v18, v17, s[12:15], null offen          ; c408007c 40801812 00000011
	s_lshr_b32 s25, s5, 2                                       ; 85198205
	v_lshrrev_b32_e32 v19, 3, v3                                ; 32260683
	v_lshrrev_b32_e32 v20, 3, v6                                ; 32280c83
	v_bfe_u32 v3, v3, 1, 2                                      ; d6100003 02090303
	v_bfe_u32 v6, v6, 1, 2                                      ; d6100006 02090306
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
(invalid instruction)                                        ; d72c0013
	v_cndmask_b32_e32 v0, v19, v25, vcc_lo                      ; 02003313
	v_add_lshl_u32 v19, v19, v20, 4                             ; d6470013 02122913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v3, v3, 2, v19                               ; d6460003 044d0503
	v_add_lshl_u32 v3, v3, v6, 9                                ; d6470003 02260d03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add3_u32 v11, v11, s1, v3                                 ; d655000b 040c030b
	v_lshlrev_b32_e32 v11, 1, v11                               ; 30161681
	buffer_load_d16_b16 v21, v11, s[16:19], null offen          ; c408007c 40802015 0000000b
	v_add_nc_u32_e32 v13, s3, v13                               ; 4a1a1a03
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v22, v16                                  ; 7e2cd910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_cvt_f16_f32_e32 v23, v22                                  ; 7e2e1516
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fmac_f16_e32 v21, v23, v18                                ; 6c2a2517
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_maxmin_num_f16 v21, 0xdf00, v21, neg(0xdf00)              ; d66b0015 83fe2aff 0000df00
	v_cvt_f32_f16_e32 v24, v21                                  ; 7e301715
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v0, v24, v128, vcc_lo                     ; 02010118
	buffer_store_b8 v25, v13, s[20:23], null offen              ; c406007c 40802819 0000000d
BB6:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_lshr_b32 s7, s7, 4                                        ; 85078407
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s7, s7, 10                                       ; 84078a07
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_cmp_gt_u32_e32 vcc_lo, s7, v1                             ; 7c980207
	s_and_not1_b32 exec_lo, vcc_lo, s11                         ; 917e0b6a
	s_cbranch_execz BB12                                        ; bfa500e0
BB7:
	s_mov_b32 s7, s1                                            ; be870001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b256 s[8:15], s[0:1], 0x0                            ; f4006200 f8000000
	s_load_b128 s[16:19], s[0:1], 0x20                          ; f4004400 f8000020
	v_bfe_u32 v2, v0, 4, 1                                      ; d6100002 02050900
	v_and_b32_e32 v7, 3, v0                                     ; 360e0083
	v_and_b32_e32 v0, 15, v0                                    ; 3600008f
	v_bfe_u32 v3, v1, 5, 5                                      ; d6100003 02150b01
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	v_lshrrev_b32_e32 v1, 10, v1                                ; 3202028a
	v_lshlrev_b32_e32 v2, 3, v2                                 ; 30040483
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_f32_u32 s20, s6                                       ; be946506
	v_lshrrev_b32_e32 v8, 2, v0                                 ; 32100082
	v_lshlrev_b32_e32 v0, 4, v0                                 ; 30000084
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_lshl_add_u32 v4, v3, 4, v2                                ; d6460004 04090903
(invalid instruction)                                        ; d6840014
	v_cndmask_b32_e32 v0, s20, v128, vcc_lo                     ; 02010014
	s_mul_f32 s20, s20, 0x4f7ffffe                              ; a214ff14 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s20, s20                                      ; be946714
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s21, s6, s20                                      ; 96151406
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s21, 0, s21                                    ; 81951580
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s21, s20, s21                                  ; 96951514
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s20, s20, s21                                  ; 80141514
	s_and_b32 s2, s2, -4                                        ; 8b02c402
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d0005
	v_cndmask_b32_e32 v0, v1, v20, vcc_lo                       ; 02002901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v5, v6, vcc_lo                        ; 02000d05
	v_sub_nc_u32_e32 v6, v1, v6                                 ; 4c0c0d01
	v_lshl_add_u32 v1, v1, 5, v3                                ; d6460001 040d0b01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v1, v1, 8, v0                                ; d6460001 04011101
	v_add_nc_u32_e32 v1, v1, v2                                 ; 4a020501
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v9, s2, v1                                 ; 4a120202
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b64 v[2:3], v9, s[12:15], null offen            ; c405407c 40801802 00000009
	s_lshr_b32 s5, s5, 2                                        ; 85058205
(invalid instruction)                                        ; d7026a0a
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                        ; 02020c06
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v10, v10, v6, vcc_lo                      ; 02140d0a
	v_subrev_co_ci_u32_e32 v5, vcc_lo, -1, v5, vcc_lo           ; 440a0ac1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d702060b
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                       ; 02021406
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_cndmask_b32_e64 v11, v11, v10, s6                         ; d501000b 001a150b
	v_subrev_co_ci_u32_e64 v5, vcc_lo, -1, v5, s6               ; d5226a05 001a0ac1
	v_lshl_add_u32 v11, v11, 2, v7                              ; d646000b 041d050b
	v_lshl_add_u32 v5, v5, 2, v8                                ; d6460005 04210505
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_lshrrev_b32_e32 v13, 3, v11                               ; 321a1683
	v_bfe_u32 v11, v11, 1, 2                                    ; d610000b 0209030b
	v_lshrrev_b32_e32 v12, 3, v5                                ; 32180a83
	v_bfe_u32 v5, v5, 1, 2                                      ; d6100005 02090305
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v0, v12, v5, vcc_lo                       ; 02000b0c
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v12, v12, v13, 4                             ; d647000c 02121b0c
	v_lshl_add_u32 v5, v5, 2, v12                               ; d6460005 04310505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v5, v5, v11, 9                               ; d6470005 02261705
	v_add3_u32 v5, v4, s7, v5                                   ; d6550005 04140f04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v5, 2, v5                                 ; 320a0a82
	v_lshlrev_b32_e32 v5, 3, v5                                 ; 300a0a83
	buffer_load_b128 v[8:11], v5, s[8:11], null offen           ; c405c07c 40801008 00000005
	v_add_lshl_u32 v4, s4, v4, 1                                ; d6470004 02060804
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_and_b32_e32 v14, -4, v4                                   ; 361c08c4
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[12:15], v14, s[16:19], null offen        ; c405c07c 4080200c 0000000e
	buffer_load_d16_b16 v16, v4, s[16:19], null offen offset:14 ; c408007c 40802010 00000e04
	s_and_b32 s3, s3, -4                                        ; 8b03c403
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_nc_u32_e32 v1, s3, v1                                 ; 4a020203
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_alignbyte_b32 v12, v13, v12, v4                           ; d617000c 0412190d
	v_alignbyte_b32 v13, v14, v13, v4                           ; d617000d 04121b0e
	v_alignbyte_b32 v14, v15, v14, v4                           ; d617000e 04121d0f
	v_alignbyte_b32 v15, v15, v15, v4                           ; d617000f 04121f0f
	v_cvt_pk_f32_fp8_e32 v[4:5], v2                             ; 7e08dd02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_cvt_f16_f32_e32 v17, v4                                   ; 7e221504
	v_cvt_f16_f32_e32 v18, v5                                   ; 7e241505
	v_cvt_pk_f32_fp8_e32 v[4:5], v130                           ; 7e08dd82
	v_fma_f16 v17, v17, v12, v8                                 ; d6480011 04221911
	v_fma_f16 v18, v18, v12, v8 op_sel:[0,1,1,0]                ; d6483012 04221912
	v_cvt_f16_f32_e32 v20, v5                                   ; 7e281505
	v_cvt_f16_f32_e32 v19, v4                                   ; 7e261504
	v_cvt_pk_f32_fp8_e32 v[4:5], v3                             ; 7e08dd03
	v_cvt_pk_f32_fp8_e32 v[2:3], v131                           ; 7e04dd83
	v_maxmin_num_f16 v17, 0xdf00, v17, neg(0xdf00)              ; d66b0011 83fe22ff 0000df00
	v_maxmin_num_f16 v18, 0xdf00, v18, neg(0xdf00)              ; d66b0012 83fe24ff 0000df00
	v_fma_f16 v20, v20, v13, v9 op_sel:[0,1,1,0]                ; d6483014 04261b14
	v_fma_f16 v19, v19, v13, v9                                 ; d6480013 04261b13
	v_cvt_f16_f32_e32 v22, v5                                   ; 7e2c1505
	v_cvt_f16_f32_e32 v21, v4                                   ; 7e2a1504
	v_cvt_f16_f32_e32 v23, v2                                   ; 7e2e1502
	v_cvt_f16_f32_e32 v24, v3                                   ; 7e301503
	v_cvt_f32_f16_e32 v25, v17                                  ; 7e321711
	v_cvt_f32_f16_e32 v26, v18                                  ; 7e341712
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
	v_maxmin_num_f16 v19, 0xdf00, v19, neg(0xdf00)              ; d66b0013 83fe26ff 0000df00
	v_fma_f16 v22, v22, v14, v10 op_sel:[0,1,1,0]               ; d6483016 042a1d16
	v_fma_f16 v21, v21, v14, v10                                ; d6480015 042a1d15
	v_fma_f16 v23, v23, v15, v11                                ; d6480017 042e1f17
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v0, v25, v128, vcc_lo                     ; 02010119
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_f16 v24, v24, v16, v11 op_sel:[0,0,1,0]               ; d6482018 042e2118
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
	v_cvt_f32_f16_e32 v29, v20                                  ; 7e3a1714
	v_cvt_f32_f16_e32 v28, v19                                  ; 7e381713
	v_maxmin_num_f16 v22, 0xdf00, v22, neg(0xdf00)              ; d66b0016 83fe2cff 0000df00
	v_maxmin_num_f16 v21, 0xdf00, v21, neg(0xdf00)              ; d66b0015 83fe2aff 0000df00
	v_maxmin_num_f16 v23, 0xdf00, v23, neg(0xdf00)              ; d66b0017 83fe2eff 0000df00
	v_maxmin_num_f16 v24, 0xdf00, v24, neg(0xdf00)              ; d66b0018 83fe30ff 0000df00
	v_perm_b32 v2, v2, v27, 0x7060004                           ; d6440002 03fe3702 07060004
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v0, v29, v128, vcc_lo                     ; 0201011d
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v0, v28, v128, vcc_lo                     ; 0201011c
	v_cvt_f32_f16_e32 v32, v22                                  ; 7e401716
	v_cvt_f32_f16_e32 v31, v21                                  ; 7e3e1715
	v_cvt_f32_f16_e32 v33, v23                                  ; 7e421717
	v_cvt_f32_f16_e32 v34, v24                                  ; 7e441718
	v_perm_b32 v2, v2, v4, 0x7020504                            ; d6440002 03fe0902 07020504
(invalid instruction)                                        ; d769001c
	v_cndmask_b32_e32 v0, v32, v128, vcc_lo                     ; 02010120
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v0, v31, v128, vcc_lo                     ; 0201011f
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v0, v33, v128, vcc_lo                     ; 02010121
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v0, v34, v128, vcc_lo                     ; 02010122
	v_perm_b32 v2, v2, v30, 0x60504                             ; d6440002 03fe3d02 00060504
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_perm_b32 v3, v3, v28, 0x7060004                           ; d6440003 03fe3903 07060004
	v_perm_b32 v3, v3, v5, 0x7020504                            ; d6440003 03fe0b03 07020504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_perm_b32 v3, v3, v31, 0x60504                             ; d6440003 03fe3f03 00060504
	buffer_store_b64 v[2:3], v1, s[12:15], null offen           ; c406c07c 40801802 00000001
BB12:
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
