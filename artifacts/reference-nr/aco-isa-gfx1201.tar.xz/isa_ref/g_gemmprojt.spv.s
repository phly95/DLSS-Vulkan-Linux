BB0:
	s_cmp_lg_i32 s12, -1                                        ; bf01c10c
	s_cbranch_scc0 BB2                                          ; bfa1000f
BB1:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_load_b128 s[16:19], s[16:17], 0x30                        ; f4004408 f8000030
	s_lshl2_add_u32 s15, s12, 24                                ; 878f980c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s15, s[16:19], s15 offset:0x0             ; f40203c8 1e000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s15, 0x54434852                                ; bf01ff0f 54434852
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s15, vcc_lo, exec_lo                              ; 8b0f7e6a
	s_cselect_b32 s12, -1, s12                                  ; 980c0cc1
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s12, -1                                        ; bf01c10c
	s_cbranch_scc0 BB5                                          ; bfa1000b
BB4:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_load_b128 s[16:19], s[16:17], 0x30                        ; f4004408 f8000030
	s_mov_b32 s15, src_scc                                      ; be8f00fd
	s_lshl2_add_u32 s20, s12, 12                                ; 87948c0c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s20, s[16:19], s20 offset:0x0             ; f4020508 28000000
	s_branch BB6                                                ; bfa00002
BB5:
	s_mov_b32 s15, src_scc                                      ; be8f00fd
	s_mov_b32 s20, -1                                           ; be9400c1
BB6:
	s_mov_b32 s16, ttmp9                                        ; be900075
	s_mov_b32 s17, ttmp7                                        ; be910073
	s_cmp_lg_i32 s11, 0                                         ; bf01800b
	s_cbranch_scc0 BB9                                          ; bfa1004d
BB7:
	s_mul_i32 s16, s13, ttmp7                                   ; 9610730d
	s_mul_i32 s17, s11, s14                                     ; 96110e0b
	s_add_co_u32 s16, ttmp9, s16                                ; 80101075
	s_cvt_f32_u32 s18, s17                                      ; be926511
(invalid instruction)                                        ; d6840012
	v_cndmask_b32_e32 v0, s18, v128, vcc_lo                     ; 02010012
	s_mul_f32 s18, s18, 0x4f7ffffe                              ; a212ff12 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s18, s18                                      ; be926712
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s19, s17, s18                                     ; 96131211
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s19, 0, s19                                    ; 81931380
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s19, s18, s19                                  ; 96931312
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s18, s18, s19                                  ; 80121312
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s18, s16, s18                                  ; 96921210
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s21, s18, s17                                     ; 96151112
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s21, s16, s21                                  ; 81951510
	s_sub_co_u32 s22, s21, s17                                  ; 80961115
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_absdiff_i32 s24, src_scc, 1                               ; 831881fd
	s_add_co_u32 s18, s18, s24                                  ; 80121812
	s_sub_co_u32 s22, s21, s17                                  ; 80961115
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s21, s21, s22                                 ; 98151615
	s_cmp_ge_u32 s21, s17                                       ; bf091115
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s18, s18, src_scc                              ; 8012fd12
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s18, s18, s11                                     ; 96120b12
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s13, s13, s18                                  ; 818d120d
	s_mul_i32 s14, s18, s14                                     ; 960e0e12
	s_min_u32 s11, s11, s13                                     ; 898b0d0b
	s_sub_co_i32 s16, s16, s14                                  ; 81900e10
	s_cvt_f32_u32 s25, s11                                      ; be99650b
(invalid instruction)                                        ; d6840019
	v_cndmask_b32_e32 v0, s25, v128, vcc_lo                     ; 02010019
	s_mul_f32 s25, s25, 0x4f7ffffe                              ; a219ff19 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s25, s25                                      ; be996719
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s26, s11, s25                                     ; 961a190b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s26, 0, s26                                    ; 819a1a80
	s_mul_hi_u32 s26, s25, s26                                  ; 969a1a19
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s25, s25, s26                                  ; 80191a19
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s25, s16, s25                                  ; 96991910
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s27, s25, s11                                     ; 961b0b19
	s_sub_co_i32 s16, s16, s27                                  ; 81901b10
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s28, s16, s11                                  ; 809c0b10
	s_absdiff_i32 s30, src_scc, 1                               ; 831e81fd
	s_sub_co_u32 s28, s16, s11                                  ; 809c0b10
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s16, s16, s28                                 ; 98101c10
	s_sub_co_u32 s11, s16, s11                                  ; 808b0b10
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mov_b32 s31, src_scc                                      ; be9f00fd
	s_absdiff_i32 s32, src_scc, 1                               ; 832081fd
	s_cmp_lg_i32 s31, 0                                         ; bf01801f
	s_cselect_b32 s16, s16, s11                                 ; 98100b10
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s16, s18, s16                                  ; 80101012
	s_add_co_u32 s25, s25, s30                                  ; 80191e19
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s25, s32                                  ; 80112019
BB9:
	s_cmp_lg_i32 s15, 0                                         ; bf01800f
	s_cbranch_scc0 BB11                                         ; bfa1000e
BB10:
	s_mov_b32 s14, s0                                           ; be8e0000
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b128 s[24:27], s[14:15], 0x30                        ; f4004607 f8000030
	s_lshl2_add_u32 s11, s12, 8                                 ; 878b880c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s25, 14                                       ; be99108e
	s_buffer_load_b32 s11, s[24:27], s11 offset:0x0             ; f40202cc 16000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s11, -1                                        ; bf01c10b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB12                                               ; bfa00001
BB11:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB12:
	s_lshl_b32 s16, s16, 5                                      ; 84108510
	s_and_b32 s11, vcc_lo, exec_lo                              ; 8b0b7e6a
	s_cbranch_scc0 BB53                                         ; bfa1007c
BB13:
	s_and_b32 s11, ttmp8, 0x3e000000                            ; 8b0bff74 3e000000
	s_cbranch_scc1 BB51                                         ; bfa20077
BB14:
	s_mov_b32 s14, s0                                           ; be8e0000
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b128 s[24:27], s[14:15], 0x30                        ; f4004607 f8000030
	s_lshl_b32 s12, s12, 2                                      ; 840c820c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s13, s12, 8                                    ; 800d880c
	s_add_co_u32 s18, s12, 16                                   ; 8012900c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s25, 14                                       ; be99108e
	s_clause 0x2                                                ; bf850002
	s_buffer_load_b32 s11, s[24:27], s12 offset:0x0             ; f40202cc 18000000
	s_buffer_load_b32 s13, s[24:27], s13 offset:0x0             ; f402034c 1a000000
	s_buffer_load_b32 s18, s[24:27], s18 offset:0x0             ; f402048c 24000000
	s_load_b128 s[28:31], s[14:15], 0x0                         ; f4004707 f8000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s18, s18, 2                                      ; 84128212
	buffer_load_b32 v1, off, s[28:31], s18 scope:SCOPE_DEV      ; c4050012 00883801 00000000
	s_lshr_b32 s19, s16, 4                                      ; 85138410
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s13, s13, s19                                  ; 800d130d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_lshl_b32 s13, s13, 2                                      ; 840d820d
	s_buffer_load_b32 s21, s[24:27], s13 offset:0x0             ; f402054c 1a000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s21, -1                                        ; bf01c115
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s22, v1                                 ; 7e2c0501
	s_cbranch_scc0 BB23                                         ; bfa1001b
BB15:
	s_bfm_b32 s14, 1, 16                                        ; 950e9081
BB16:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s14, 0                                         ; bf01800e
	s_cbranch_scc0 BB18                                         ; bfa10011
BB17:
	s_and_b32 s15, s21, 0xfffff                                 ; 8b0fff15 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s15, s11, s15                                  ; 800f0f0b
	s_lshl_b32 s15, s15, 2                                      ; 840f820f
	buffer_load_b32 v1, off, s[28:31], s15 scope:SCOPE_DEV      ; c405000f 00883801 00000000
	s_lshr_b32 s18, s21, 20                                     ; 85129415
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s18, s18, s22                                     ; 96121612
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s19, v1                                 ; 7e260501
	s_cmp_lt_u32 s19, s18                                       ; bf0a1213
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s23, -1, 0                                    ; 981780c1
	s_branch BB19                                               ; bfa00001
BB18:
	s_mov_b32 s23, 0                                            ; be970080
BB19:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s23, exec_lo, s23                            ; 9117177e
	s_cbranch_scc1 BB24                                         ; bfa20003
BB21:
	s_add_co_u32 s14, s14, -1                                   ; 800ec10e
	s_branch BB16                                               ; bfa0ffe6
BB23:
	s_bfm_b32 s14, 1, 16                                        ; 950e9081
BB24:
	s_add_co_u32 s13, s13, 4                                    ; 800d840d
	s_buffer_load_b32 s13, s[24:27], s13 offset:0x0             ; f402034c 1a000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s13, -1                                        ; bf01c10d
	s_cbranch_scc0 BB34                                         ; bfa1001a
BB25:
	s_branch BB26                                               ; bfa00001
BB31:
	s_add_co_u32 s14, s14, -1                                   ; 800ec10e
BB26:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s14, 0                                         ; bf01800e
	s_cbranch_scc0 BB28                                         ; bfa10011
BB27:
	s_and_b32 s15, s13, 0xfffff                                 ; 8b0fff0d 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s15, s11, s15                                  ; 800f0f0b
	s_lshl_b32 s15, s15, 2                                      ; 840f820f
	buffer_load_b32 v1, off, s[28:31], s15 scope:SCOPE_DEV      ; c405000f 00883801 00000000
	s_lshr_b32 s18, s13, 20                                     ; 8512940d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s18, s18, s22                                     ; 96121612
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s19, v1                                 ; 7e260501
	s_cmp_lt_u32 s19, s18                                       ; bf0a1213
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s21, -1, 0                                    ; 981580c1
	s_branch BB29                                               ; bfa00001
BB28:
	s_mov_b32 s21, 0                                            ; be950080
BB29:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s21, exec_lo, s21                            ; 9115157e
	s_cbranch_scc0 BB31                                         ; bfa1ffe7
BB34:
	s_cmp_eq_i32 s14, 0                                         ; bf00800e
	s_cbranch_scc0 BB36                                         ; bfa10002
BB35:
	s_mov_b32 s11, 1                                            ; be8b0081
	s_branch BB37                                               ; bfa00001
BB36:
	s_mov_b32 s11, 0                                            ; be8b0080
BB37:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mov_b32 exec_lo, s11                                      ; befe000b
	s_cbranch_execz BB49                                        ; bfa5000e
BB38:
	s_ctz_i32_b32 s11, exec_lo                                  ; be8b087e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s11, 1, s11                                      ; 840b0b81
	s_and_saveexec_b32 s11, s11                                 ; be8b200b
	s_cbranch_execz BB49                                        ; bfa50009
BB39:
	s_add_co_u32 s12, s12, 20                                   ; 800c940c
	s_buffer_load_b32 s12, s[24:27], s12 offset:0x0             ; f402030c 18000000
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s12, s12, 2                                      ; 840c820c
	buffer_atomic_max_u32 v1, off, s[28:31], s12                ; c40ec00c 00803801 00000000
BB49:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
BB51:
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
BB53:
	v_and_b32_e32 v3, 31, v0                                    ; 3606009f
	v_and_b32_e32 v4, 15, v0                                    ; 3608008f
	s_lshr_b32 s11, s8, 4                                       ; 850b8408
	s_lshr_b32 s12, s16, 4                                      ; 850c8410
	v_bfe_u32 v1, v0, 5, 2                                      ; d6100001 02090b00
	s_mul_i32 s13, s12, s11                                     ; 960d0b0c
	v_lshlrev_b32_e32 v5, 4, v4                                 ; 300a0884
	s_lshl_b32 s13, s13, 8                                      ; 840d880d
	s_add_co_u32 s14, 16, s16                                   ; 800e1090
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v6, v5, s1, s13                                  ; d6550006 00340305
	s_lshr_b32 s15, s14, 4                                      ; 850f840e
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0                ; ca100080 09080080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0              ; ca100080 0b0a0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v12, 0              ; ca100080 0d0c0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, 0              ; ca100080 0f0e0080
	s_mul_i32 s18, s15, s11                                     ; 96120b0f
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v16, 0              ; ca100080 11100080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s18, s18, 8                                      ; 84128812
	s_lshl_b32 s17, s17, 7                                      ; 84118711
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_lshr_b32 s8, s8, 8                                        ; 85088808
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v5, v5, s1, s18                                  ; d6550005 00480305
	s_mov_b32 s1, 0                                             ; be810080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_lshl_add_u32 v1, v1, 5, s17                               ; d6460001 00450b01
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_lshrrev_b32_e32 v2, 5, v1                                 ; 32040285
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v2, v11, vcc_lo                       ; 02001702
	v_lshl_add_u32 v2, v2, 7, s4                                ; d6460002 00110f02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshl_add_u32 v2, v3, 2, v2                                ; d6460002 04090503
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_lshlrev_b32_e32 v3, 3, v3                                 ; 30060683
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_add_nc_u32_e32 v6, v6, v3                                 ; 4a0c0706
	v_add_nc_u32_e32 v5, v5, v3                                 ; 4a0a0705
	v_lshrrev_b32_e32 v6, 2, v6                                 ; 320c0c82
	v_lshrrev_b32_e32 v5, 2, v5                                 ; 320a0a82
	s_branch BB54                                               ; bfa00149
BB56:
	s_mov_b32 s18, s0                                           ; be920000
	s_movk_i32 s19, 0x8000                                      ; b0138000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[18:19], 0x70                        ; f4004609 f8000070
	s_load_b128 s[28:31], s[18:19], 0x30                        ; f4004709 f8000030
	s_lshl_b32 s4, s1, 8                                        ; 84048801
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s4, s4, 4                                        ; 85048404
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v41, s4, 7, v2                               ; d6460029 04090e04
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v41, 2, v41                               ; 30525282
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[44:47], v41, s[28:31], null offen        ; c405c07c 4080382c 00000029
	buffer_load_b128 v[48:51], v41, s[28:31], null offen offset:512 ; c405c07c 40803830 00020029
	buffer_load_b128 v[52:55], v41, s[28:31], null offen offset:1024 ; c405c07c 40803834 00040029
	buffer_load_b128 v[56:59], v41, s[28:31], null offen offset:1536 ; c405c07c 40803838 00060029
	buffer_load_b128 v[60:63], v41, s[28:31], null offen offset:2048 ; c405c07c 4080383c 00080029
	buffer_load_b128 v[64:67], v41, s[28:31], null offen offset:2560 ; c405c07c 40803840 000a0029
	s_lshl_b32 s11, s4, 8                                       ; 840b8804
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s11, s11, 2                                      ; 850b820b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v7, s11, v6, 2                               ; d6470007 020a0c0b
	v_add_lshl_u32 v40, s11, v5, 2                              ; d6470028 020a0a0b
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0xd                                                ; bf85000d
	buffer_load_b64 v[42:43], v7, s[24:27], null offen          ; c405407c 4080302a 00000007
	buffer_load_b64 v[68:69], v40, s[24:27], null offen         ; c405407c 40803044 00000028
	buffer_load_b64 v[70:71], v7, s[24:27], null offen offset:256 ; c405407c 40803046 00010007
	buffer_load_b64 v[72:73], v40, s[24:27], null offen offset:256 ; c405407c 40803048 00010028
	buffer_load_b64 v[74:75], v7, s[24:27], null offen offset:512 ; c405407c 4080304a 00020007
	buffer_load_b64 v[76:77], v40, s[24:27], null offen offset:512 ; c405407c 4080304c 00020028
	buffer_load_b64 v[78:79], v7, s[24:27], null offen offset:768 ; c405407c 4080304e 00030007
	buffer_load_b64 v[80:81], v40, s[24:27], null offen offset:768 ; c405407c 40803050 00030028
	buffer_load_b64 v[82:83], v7, s[24:27], null offen offset:1024 ; c405407c 40803052 00040007
	buffer_load_b64 v[84:85], v40, s[24:27], null offen offset:1024 ; c405407c 40803054 00040028
	buffer_load_b64 v[86:87], v7, s[24:27], null offen offset:1280 ; c405407c 40803056 00050007
	buffer_load_b64 v[88:89], v40, s[24:27], null offen offset:1280 ; c405407c 40803058 00050028
	buffer_load_b64 v[90:91], v7, s[24:27], null offen offset:1536 ; c405407c 4080305a 00060007
	buffer_load_b64 v[92:93], v40, s[24:27], null offen offset:1536 ; c405407c 4080305c 00060028
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[42:43], v[44:45], v[8:15] ; cc464008 1c22592a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[42:43], v[46:47], v[16:23] ; cc464010 1c425d2a
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[68:69], v[44:45], v[24:31] ; cc464018 1c625944
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[68:69], v[46:47], v[32:39] ; cc464020 1c825d44
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[70:71], v[48:49], v[8:15] ; cc464008 1c226146
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[70:71], v[50:51], v[16:23] ; cc464010 1c426546
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[72:73], v[48:49], v[24:31] ; cc464018 1c626148
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[72:73], v[50:51], v[32:39] ; cc464020 1c826548
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[74:75], v[52:53], v[8:15] ; cc464008 1c22694a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[74:75], v[54:55], v[16:23] ; cc464010 1c426d4a
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[76:77], v[52:53], v[24:31] ; cc464018 1c62694c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[76:77], v[54:55], v[32:39] ; cc464020 1c826d4c
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[78:79], v[56:57], v[8:15] ; cc464008 1c22714e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[78:79], v[58:59], v[16:23] ; cc464010 1c42754e
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[80:81], v[56:57], v[24:31] ; cc464018 1c627150
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[80:81], v[58:59], v[32:39] ; cc464020 1c827550
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[82:83], v[60:61], v[8:15] ; cc464008 1c227952
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[82:83], v[62:63], v[16:23] ; cc464010 1c427d52
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[84:85], v[60:61], v[24:31] ; cc464018 1c627954
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[84:85], v[62:63], v[32:39] ; cc464020 1c827d54
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[86:87], v[64:65], v[8:15] ; cc464008 1c228156
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[86:87], v[66:67], v[16:23] ; cc464010 1c428556
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[88:89], v[64:65], v[24:31] ; cc464018 1c628158
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[88:89], v[66:67], v[32:39] ; cc464020 1c828558
	s_clause 0x6                                                ; bf850006
	buffer_load_b128 v[42:45], v41, s[28:31], null offen offset:3072 ; c405c07c 4080382a 000c0029
	buffer_load_b128 v[68:71], v41, s[28:31], null offen offset:3584 ; c405c07c 40803844 000e0029
	buffer_load_b128 v[48:51], v41, s[28:31], null offen offset:4096 ; c405c07c 40803830 00100029
	buffer_load_b128 v[52:55], v41, s[28:31], null offen offset:4608 ; c405c07c 40803834 00120029
	buffer_load_b128 v[56:59], v41, s[28:31], null offen offset:5120 ; c405c07c 40803838 00140029
	buffer_load_b128 v[60:63], v41, s[28:31], null offen offset:5632 ; c405c07c 4080383c 00160029
	buffer_load_b128 v[64:67], v41, s[28:31], null offen offset:6144 ; c405c07c 40803840 00180029
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[90:91], v[44:45], v[16:23] ; cc464010 1c42595a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[92:93], v[42:43], v[24:31] ; cc464018 1c62555c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[92:93], v[44:45], v[32:39] ; cc464020 1c82595c
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[90:91], v[42:43], v[8:15] ; cc464008 1c22555a
	s_clause 0xd                                                ; bf85000d
	buffer_load_b64 v[42:43], v7, s[24:27], null offen offset:1792 ; c405407c 4080302a 00070007
	buffer_load_b64 v[44:45], v40, s[24:27], null offen offset:1792 ; c405407c 4080302c 00070028
	buffer_load_b64 v[46:47], v7, s[24:27], null offen offset:2048 ; c405407c 4080302e 00080007
	buffer_load_b64 v[72:73], v40, s[24:27], null offen offset:2048 ; c405407c 40803048 00080028
	buffer_load_b64 v[74:75], v7, s[24:27], null offen offset:2304 ; c405407c 4080304a 00090007
	buffer_load_b64 v[76:77], v40, s[24:27], null offen offset:2304 ; c405407c 4080304c 00090028
	buffer_load_b64 v[78:79], v7, s[24:27], null offen offset:2560 ; c405407c 4080304e 000a0007
	buffer_load_b64 v[80:81], v40, s[24:27], null offen offset:2560 ; c405407c 40803050 000a0028
	buffer_load_b64 v[82:83], v7, s[24:27], null offen offset:2816 ; c405407c 40803052 000b0007
	buffer_load_b64 v[84:85], v40, s[24:27], null offen offset:2816 ; c405407c 40803054 000b0028
	buffer_load_b64 v[86:87], v7, s[24:27], null offen offset:3072 ; c405407c 40803056 000c0007
	buffer_load_b64 v[88:89], v40, s[24:27], null offen offset:3072 ; c405407c 40803058 000c0028
	buffer_load_b64 v[90:91], v7, s[24:27], null offen offset:3328 ; c405407c 4080305a 000d0007
	buffer_load_b64 v[92:93], v40, s[24:27], null offen offset:3328 ; c405407c 4080305c 000d0028
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[42:43], v[68:69], v[8:15] ; cc464008 1c22892a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[42:43], v[70:71], v[16:23] ; cc464010 1c428d2a
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[44:45], v[70:71], v[32:39] ; cc464020 1c828d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[44:45], v[68:69], v[24:31] ; cc464018 1c62892c
	v_dual_mov_b32 v69, v41 :: v_dual_mov_b32 v68, v40          ; ca100129 45440128
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[46:47], v[48:49], v[8:15] ; cc464008 1c22612e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[50:51], v[16:23] ; cc464010 1c42652e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v41, s[28:31], null offen offset:6656 ; c405c07c 40803828 001a0029
	buffer_load_b128 v[44:47], v69, s[28:31], null offen offset:7168 ; c405c07c 4080382c 001c0045
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[72:73], v[50:51], v[32:39] ; cc464020 1c826548
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[72:73], v[48:49], v[24:31] ; cc464018 1c626148
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[48:49], v7, s[24:27], null offen offset:3584 ; c405407c 40803030 000e0007
	buffer_load_b64 v[50:51], v68, s[24:27], null offen offset:3584 ; c405407c 40803032 000e0044
	buffer_load_b64 v[70:71], v7, s[24:27], null offen offset:3840 ; c405407c 40803046 000f0007
	buffer_load_b64 v[72:73], v68, s[24:27], null offen offset:3840 ; c405407c 40803048 000f0044
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[74:75], v[52:53], v[8:15] ; cc464008 1c22694a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[74:75], v[54:55], v[16:23] ; cc464010 1c426d4a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_dual_mov_b32 v75, v71 :: v_dual_mov_b32 v74, v70          ; ca100147 4b4a0146
	buffer_load_b128 v[68:71], v69, s[28:31], null offen offset:7680 ; c405c07c 40803844 001e0045
	s_add_co_u32 s1, s1, 1                                      ; 80018101
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[76:77], v[54:55], v[32:39] ; cc464020 1c826d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[76:77], v[52:53], v[24:31] ; cc464018 1c62694c
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[78:79], v[56:57], v[8:15] ; cc464008 1c22714e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[78:79], v[58:59], v[16:23] ; cc464010 1c42754e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[80:81], v[58:59], v[32:39] ; cc464020 1c827550
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[80:81], v[56:57], v[24:31] ; cc464018 1c627150
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[82:83], v[60:61], v[8:15] ; cc464008 1c227952
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[82:83], v[62:63], v[16:23] ; cc464010 1c427d52
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[84:85], v[62:63], v[32:39] ; cc464020 1c827d54
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[84:85], v[60:61], v[24:31] ; cc464018 1c627954
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[86:87], v[64:65], v[8:15] ; cc464008 1c228156
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[86:87], v[66:67], v[16:23] ; cc464010 1c428556
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[88:89], v[66:67], v[32:39] ; cc464020 1c828558
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[88:89], v[64:65], v[24:31] ; cc464018 1c628158
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[90:91], v[40:41], v[8:15] ; cc464008 1c22515a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[90:91], v[42:43], v[16:23] ; cc464010 1c42555a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[92:93], v[42:43], v[32:39] ; cc464020 1c82555c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[92:93], v[40:41], v[24:31] ; cc464018 1c62515c
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[48:49], v[44:45], v[8:15] ; cc464008 1c225930
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[48:49], v[46:47], v[16:23] ; cc464010 1c425d30
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[50:51], v[46:47], v[32:39] ; cc464020 1c825d32
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[50:51], v[44:45], v[24:31] ; cc464018 1c625932
	s_wait_loadcnt 0x0                                          ; bfc00000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[72:73], v[68:69], v[24:31] ; cc464018 1c628948
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[72:73], v[70:71], v[32:39] ; cc464020 1c828d48
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[74:75], v[68:69], v[8:15] ; cc464008 1c22894a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[74:75], v[70:71], v[16:23] ; cc464010 1c428d4a
BB54:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s1, s8                                         ; bf090801
	s_cbranch_scc0 BB56                                         ; bfa1feb4
BB57:
	s_cmp_lt_u32 s16, s6                                        ; bf0a0610
	s_cbranch_scc0 BB71                                         ; bfa1010e
BB58:
	s_mov_b32 s18, s0                                           ; be920000
	s_movk_i32 s19, 0x8000                                      ; b0138000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[18:19], 0x40                        ; f4004609 f8000040
	s_load_b128 s[28:31], s[18:19], 0x10                        ; f4004709 f8000010
	v_add3_u32 v2, v4, s5, v1                                   ; d6550002 04040b04
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v2, 1, v2                                 ; 30040481
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v5, v2, s[24:27], null offen            ; c408007c 40803005 00000002
	v_and_b32_e32 v7, 16, v0                                    ; 360e0090
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_lshr_b32 s4, s7, 4                                        ; 85048407
	v_lshrrev_b32_e32 v6, 4, v1                                 ; 320c0284
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s8, s12, s4                                       ; 9608040c
	v_lshl_or_b32 v7, v7, 3, v4                                 ; d6560007 04110707
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_add_lshl_u32 v40, s8, v6, 8                               ; d6470028 02220c08
	v_add3_u32 v7, v7, s2, v40                                  ; d6550007 04a00507
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v41, v7, s[28:31], null offen            ; c407807c 40803829 00000007
	buffer_load_d16_u8 v42, v7, s[28:31], null offen offset:16  ; c407807c 4080382a 00001007
	buffer_load_d16_u8 v43, v7, s[28:31], null offen offset:32  ; c407807c 4080382b 00002007
	buffer_load_d16_u8 v44, v7, s[28:31], null offen offset:48  ; c407807c 4080382c 00003007
	buffer_load_d16_u8 v45, v7, s[28:31], null offen offset:64  ; c407807c 4080382d 00004007
	buffer_load_d16_u8 v46, v7, s[28:31], null offen offset:80  ; c407807c 4080382e 00005007
	buffer_load_d16_u8 v47, v7, s[28:31], null offen offset:96  ; c407807c 4080382f 00006007
	buffer_load_d16_u8 v48, v7, s[28:31], null offen offset:112 ; c407807c 40803830 00007007
	v_add_nc_u32_e32 v49, s16, v3                               ; 4a620610
	s_cvt_f32_u32 s11, s9                                       ; be8b6509
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d684000b
	v_cndmask_b32_e32 v0, s11, v128, vcc_lo                     ; 0201000b
	s_mul_f32 s11, s11, 0x4f7ffffe                              ; a20bff0b 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s11, s11                                      ; be8b670b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s13, s9, s11                                      ; 960d0b09
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s13, 0, s13                                    ; 818d0d80
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s13, s11, s13                                  ; 968d0d0b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s11, s11, s13                                  ; 800b0d0b
	s_lshr_b32 s19, s9, 2                                       ; 85138209
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d0032
	v_cndmask_b32_e32 v0, v49, v11, vcc_lo                      ; 02001731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0033
	v_cndmask_b32_e32 v0, v50, v9, vcc_lo                       ; 02001332
	v_sub_nc_u32_e32 v51, v49, v51                              ; 4c666731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d7026a34
	v_cndmask_b32_e32 v1, s9, v51, vcc_lo                       ; 02026609
	v_cndmask_b32_e32 v52, v52, v51, vcc_lo                     ; 02686734
	v_subrev_co_ci_u32_e64 v50, s17, -1, v50, vcc_lo            ; d5221132 01aa64c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d7026a35
	v_cndmask_b32_e32 v1, s9, v52, vcc_lo                       ; 02026809
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v53, v53, v52, vcc_lo                     ; 026a6935
	v_subrev_co_ci_u32_e64 v50, s18, -1, v50, vcc_lo            ; d5221232 01aa64c1
	v_lshrrev_b32_e32 v53, 2, v53                               ; 326a6a82
	v_cmp_gt_u32_e32 vcc_lo, s10, v50                           ; 7c98640a
	v_lshrrev_b32_e32 v54, 2, v50                               ; 326c6482
	v_and_b32_e32 v55, 3, v50                                   ; 366e6483
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; d72c0036
	v_cndmask_b32_e32 v0, v54, v19, vcc_lo                      ; 02002736
	v_add_nc_u32_e32 v54, v54, v53                              ; 4a6c6b36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_and_b32_e32 v54, 0xfffffff, v54                           ; 366c6cff 0fffffff
(invalid instruction)                                        ; d72c0036
	v_cndmask_b32_e32 v0, v54, v4, vcc_lo                       ; 02000936
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v54, v54, v6, 8                              ; d6470036 02220d36
	v_add_nc_u32_e32 v54, s3, v54                               ; 4a6c6c03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v55, v55, 6, v54                             ; d6460037 04d90d37
	v_add_nc_u32_e32 v55, v55, v4                               ; 4a6e0937
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v56, v41                                  ; 7e70d929
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v60, v42                                  ; 7e78d92a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v64, v43                                  ; 7e80d92b
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v68, v44                                  ; 7e88d92c
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v57, v5, v56, v8 op_sel_hi:[1,0,0]          ; cc210039 0c227105
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v72, v45                                  ; 7e90d92d
	v_fma_mixlo_f16 v61, v5, v60, v9 op_sel_hi:[1,0,0]          ; cc21003d 0c267905
	v_fma_mixlo_f16 v65, v5, v64, v10 op_sel_hi:[1,0,0]         ; cc210041 0c2a8105
	v_fma_mixlo_f16 v69, v5, v68, v11 op_sel_hi:[1,0,0]         ; cc210045 0c2e8905
	v_maxmin_num_f16 v57, 0xdf00, v57, neg(0xdf00)              ; d66b0039 83fe72ff 0000df00
	v_fma_mixlo_f16 v73, v5, v72, v12 op_sel_hi:[1,0,0]         ; cc210049 0c329105
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v76, v46                                  ; 7e98d92e
	v_maxmin_num_f16 v61, 0xdf00, v61, neg(0xdf00)              ; d66b003d 83fe7aff 0000df00
	v_maxmin_num_f16 v65, 0xdf00, v65, neg(0xdf00)              ; d66b0041 83fe82ff 0000df00
	v_maxmin_num_f16 v69, 0xdf00, v69, neg(0xdf00)              ; d66b0045 83fe8aff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v80, v47                                  ; 7ea0d92f
	v_cvt_f32_f16_e32 v58, v57                                  ; 7e741739
	v_maxmin_num_f16 v73, 0xdf00, v73, neg(0xdf00)              ; d66b0049 83fe92ff 0000df00
	v_fma_mixlo_f16 v77, v5, v76, v13 op_sel_hi:[1,0,0]         ; cc21004d 0c369905
	v_cvt_f32_f16_e32 v62, v61                                  ; 7e7c173d
	v_cvt_f32_f16_e32 v66, v65                                  ; 7e841741
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v84, v48                                  ; 7ea8d930
	v_cvt_f32_f16_e32 v70, v69                                  ; 7e8c1745
	v_fma_mixlo_f16 v81, v5, v80, v14 op_sel_hi:[1,0,0]         ; cc210051 0c3aa105
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v0, v58, v128, vcc_lo                     ; 0201013a
	v_cvt_f32_f16_e32 v74, v73                                  ; 7e941749
	v_maxmin_num_f16 v77, 0xdf00, v77, neg(0xdf00)              ; d66b004d 83fe9aff 0000df00
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v0, v62, v128, vcc_lo                     ; 0201013e
(invalid instruction)                                        ; d7690043
	v_cndmask_b32_e32 v0, v66, v128, vcc_lo                     ; 02010142
	v_fma_mixlo_f16 v5, v5, v84, v15 op_sel_hi:[1,0,0]          ; cc210005 0c3ea905
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v0, v70, v128, vcc_lo                     ; 02010146
	v_maxmin_num_f16 v81, 0xdf00, v81, neg(0xdf00)              ; d66b0051 83fea2ff 0000df00
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v0, v74, v128, vcc_lo                     ; 0201014a
	v_cvt_f32_f16_e32 v78, v77                                  ; 7e9c174d
	v_maxmin_num_f16 v5, 0xdf00, v5, neg(0xdf00)                ; d66b0005 83fe0aff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_cvt_f32_f16_e32 v82, v81                                  ; 7ea41751
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v0, v78, v128, vcc_lo                     ; 0201014e
	v_cvt_f32_f16_e32 v85, v5                                   ; 7eaa1705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d7690053
	v_cndmask_b32_e32 v0, v82, v128, vcc_lo                     ; 02010152
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v0, v85, v128, vcc_lo                     ; 02010155
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB64                                        ; bfa5000d
BB59:
	s_clause 0x3                                                ; bf850003
	buffer_store_b8 v59, v55, s[28:31], null offen              ; c406007c 4080383b 00000037
	buffer_store_b8 v63, v55, s[28:31], null offen offset:16    ; c406007c 4080383f 00001037
	buffer_store_b8 v67, v55, s[28:31], null offen offset:32    ; c406007c 40803843 00002037
	buffer_store_b8 v71, v55, s[28:31], null offen offset:48    ; c406007c 40803847 00003037
BB64:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_add_nc_u32_e32 v49, 4, v49                                ; 4a626284
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72d0002
	v_cndmask_b32_e32 v0, v49, v11, vcc_lo                      ; 02001731
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                        ; 02001302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v49, v49, v5                               ; 4c620b31
(invalid instruction)                                        ; d7026a07
	v_cndmask_b32_e32 v1, s9, v49, vcc_lo                       ; 02026209
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v7, v7, v49, vcc_lo                       ; 020e6307
	v_subrev_co_ci_u32_e64 v2, s8, -1, v2, vcc_lo               ; d5220802 01aa04c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d7026a08
	v_cndmask_b32_e32 v1, s9, v7, vcc_lo                        ; 02020e09
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v8, v8, v7, vcc_lo                        ; 02100f08
	v_subrev_co_ci_u32_e64 v2, s11, -1, v2, vcc_lo              ; d5220b02 01aa04c1
	v_lshrrev_b32_e32 v8, 2, v8                                 ; 32101082
	v_and_b32_e32 v10, 3, v2                                    ; 36140483
	v_lshrrev_b32_e32 v9, 2, v2                                 ; 32120482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0009
	v_cndmask_b32_e32 v0, v9, v19, vcc_lo                       ; 02002709
	v_add_nc_u32_e32 v9, v9, v8                                 ; 4a121109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_and_b32_e32 v9, 0xfffffff, v9                             ; 361212ff 0fffffff
(invalid instruction)                                        ; d72c0009
	v_cndmask_b32_e32 v0, v9, v4, vcc_lo                        ; 02000909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v9, v9, v6, 8                                ; d6470009 02220d09
	v_add_nc_u32_e32 v9, s3, v9                                 ; 4a121203
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v10, v10, 6, v9                              ; d646000a 04250d0a
	v_add_nc_u32_e32 v10, v10, v4                               ; 4a14090a
	v_cmpx_gt_u32_e32 s10, v2                                   ; 7d98040a
	s_cbranch_execz BB70                                        ; bfa5000d
BB65:
	s_clause 0x3                                                ; bf850003
	buffer_store_b8 v75, v10, s[28:31], null offen              ; c406007c 4080384b 0000000a
	buffer_store_b8 v79, v10, s[28:31], null offen offset:16    ; c406007c 4080384f 0000100a
	buffer_store_b8 v83, v10, s[28:31], null offen offset:32    ; c406007c 40803853 0000200a
	buffer_store_b8 v86, v10, s[28:31], null offen offset:48    ; c406007c 40803856 0000300a
BB70:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_branch BB72                                               ; bfa00001
BB71:
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB72:
	v_add_nc_u32_e32 v2, 16, v1                                 ; 4a040290
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc0 BB87                                         ; bfa1010f
BB73:
	s_mov_b32 s18, s0                                           ; be920000
	s_movk_i32 s19, 0x8000                                      ; b0138000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[18:19], 0x40                        ; f4004609 f8000040
	s_load_b128 s[28:31], s[18:19], 0x10                        ; f4004709 f8000010
	v_add3_u32 v5, v4, s5, v1                                   ; d6550005 04040b04
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v5, 1, v5                                 ; 300a0a81
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v6, v5, s[24:27], null offen offset:32  ; c408007c 40803006 00002005
	v_and_b32_e32 v8, 16, v0                                    ; 36100090
	s_lshr_b32 s1, s7, 4                                        ; 85018407
	v_lshrrev_b32_e32 v7, 4, v2                                 ; 320e0484
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s4, s12, s1                                       ; 9604010c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshl_or_b32 v8, v8, 3, v4                                 ; d6560008 04110708
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v9, s4, v7, 8                                ; d6470009 02220e04
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add3_u32 v8, v8, s2, v9                                   ; d6550008 04240508
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v10, v8, s[28:31], null offen            ; c407807c 4080380a 00000008
	buffer_load_d16_u8 v11, v8, s[28:31], null offen offset:16  ; c407807c 4080380b 00001008
	buffer_load_d16_u8 v12, v8, s[28:31], null offen offset:32  ; c407807c 4080380c 00002008
	buffer_load_d16_u8 v13, v8, s[28:31], null offen offset:48  ; c407807c 4080380d 00003008
	buffer_load_d16_u8 v14, v8, s[28:31], null offen offset:64  ; c407807c 4080380e 00004008
	buffer_load_d16_u8 v15, v8, s[28:31], null offen offset:80  ; c407807c 4080380f 00005008
	buffer_load_d16_u8 v40, v8, s[28:31], null offen offset:96  ; c407807c 40803828 00006008
	buffer_load_d16_u8 v41, v8, s[28:31], null offen offset:112 ; c407807c 40803829 00007008
	v_add_nc_u32_e32 v42, s16, v3                               ; 4a540610
	s_cvt_f32_u32 s8, s9                                        ; be886509
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840008
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                      ; 02010008
	s_mul_f32 s8, s8, 0x4f7ffffe                                ; a208ff08 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s8, s8                                        ; be886708
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s11, s9, s8                                       ; 960b0809
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s11, 0, s11                                    ; 818b0b80
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s11, s8, s11                                   ; 968b0b08
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s8, s8, s11                                    ; 80080b08
	s_lshr_b32 s17, s9, 2                                       ; 85118209
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d002b
	v_cndmask_b32_e32 v0, v42, v8, vcc_lo                       ; 0200112a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c002c
	v_cndmask_b32_e32 v0, v43, v9, vcc_lo                       ; 0200132b
	v_sub_nc_u32_e32 v44, v42, v44                              ; 4c58592a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
(invalid instruction)                                        ; d7026a2d
	v_cndmask_b32_e32 v1, s9, v44, vcc_lo                       ; 02025809
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v45, v45, v44, vcc_lo                     ; 025a592d
	v_subrev_co_ci_u32_e64 v43, s13, -1, v43, vcc_lo            ; d5220d2b 01aa56c1
(invalid instruction)                                        ; d7026a2e
	v_cndmask_b32_e32 v1, s9, v45, vcc_lo                       ; 02025a09
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v46, v46, v45, vcc_lo                     ; 025c5b2e
	v_subrev_co_ci_u32_e64 v43, s16, -1, v43, vcc_lo            ; d522102b 01aa56c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_lshrrev_b32_e32 v46, 2, v46                               ; 325c5c82
	v_cmp_gt_u32_e32 vcc_lo, s10, v43                           ; 7c98560a
	v_lshrrev_b32_e32 v47, 2, v43                               ; 325e5682
	v_and_b32_e32 v48, 3, v43                                   ; 36605683
(invalid instruction)                                        ; d72c002f
	v_cndmask_b32_e32 v0, v47, v17, vcc_lo                      ; 0200232f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v47, v47, v46                              ; 4a5e5d2f
	v_and_b32_e32 v47, 0xfffffff, v47                           ; 365e5eff 0fffffff
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c002f
	v_cndmask_b32_e32 v0, v47, v1, vcc_lo                       ; 0200032f
	v_add_lshl_u32 v47, v47, v7, 8                              ; d647002f 02220f2f
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_nc_u32_e32 v47, s3, v47                               ; 4a5e5e03
	v_lshl_add_u32 v48, v48, 6, v47                             ; d6460030 04bd0d30
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v48, v48, v4                               ; 4a600930
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v49, v10                                  ; 7e62d90a
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v53, v11                                  ; 7e6ad90b
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v57, v12                                  ; 7e72d90c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v61, v13                                  ; 7e7ad90d
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v50, v6, v49, v16 op_sel_hi:[1,0,0]         ; cc210032 0c426306
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v65, v14                                  ; 7e82d90e
	v_fma_mixlo_f16 v54, v6, v53, v17 op_sel_hi:[1,0,0]         ; cc210036 0c466b06
	v_fma_mixlo_f16 v58, v6, v57, v18 op_sel_hi:[1,0,0]         ; cc21003a 0c4a7306
	v_fma_mixlo_f16 v62, v6, v61, v19 op_sel_hi:[1,0,0]         ; cc21003e 0c4e7b06
	v_maxmin_num_f16 v50, 0xdf00, v50, neg(0xdf00)              ; d66b0032 83fe64ff 0000df00
	v_fma_mixlo_f16 v66, v6, v65, v20 op_sel_hi:[1,0,0]         ; cc210042 0c528306
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v69, v15                                  ; 7e8ad90f
	v_maxmin_num_f16 v54, 0xdf00, v54, neg(0xdf00)              ; d66b0036 83fe6cff 0000df00
	v_maxmin_num_f16 v58, 0xdf00, v58, neg(0xdf00)              ; d66b003a 83fe74ff 0000df00
	v_maxmin_num_f16 v62, 0xdf00, v62, neg(0xdf00)              ; d66b003e 83fe7cff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v73, v40                                  ; 7e92d928
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
	v_maxmin_num_f16 v66, 0xdf00, v66, neg(0xdf00)              ; d66b0042 83fe84ff 0000df00
	v_fma_mixlo_f16 v70, v6, v69, v21 op_sel_hi:[1,0,0]         ; cc210046 0c568b06
	v_cvt_f32_f16_e32 v55, v54                                  ; 7e6e1736
	v_cvt_f32_f16_e32 v59, v58                                  ; 7e76173a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v77, v41                                  ; 7e9ad929
	v_cvt_f32_f16_e32 v63, v62                                  ; 7e7e173e
	v_fma_mixlo_f16 v74, v6, v73, v22 op_sel_hi:[1,0,0]         ; cc21004a 0c5a9306
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
	v_cvt_f32_f16_e32 v67, v66                                  ; 7e861742
	v_maxmin_num_f16 v70, 0xdf00, v70, neg(0xdf00)              ; d66b0046 83fe8cff 0000df00
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v0, v55, v128, vcc_lo                     ; 02010137
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v0, v59, v128, vcc_lo                     ; 0201013b
	v_fma_mixlo_f16 v6, v6, v77, v23 op_sel_hi:[1,0,0]          ; cc210006 0c5e9b06
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v0, v63, v128, vcc_lo                     ; 0201013f
	v_maxmin_num_f16 v74, 0xdf00, v74, neg(0xdf00)              ; d66b004a 83fe94ff 0000df00
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v0, v67, v128, vcc_lo                     ; 02010143
	v_cvt_f32_f16_e32 v71, v70                                  ; 7e8e1746
	v_maxmin_num_f16 v6, 0xdf00, v6, neg(0xdf00)                ; d66b0006 83fe0cff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_cvt_f32_f16_e32 v75, v74                                  ; 7e96174a
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v0, v71, v128, vcc_lo                     ; 02010147
	v_cvt_f32_f16_e32 v78, v6                                   ; 7e9c1706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v0, v75, v128, vcc_lo                     ; 0201014b
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v0, v78, v128, vcc_lo                     ; 0201014e
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB79                                        ; bfa5000d
BB74:
	s_clause 0x3                                                ; bf850003
	buffer_store_b8 v52, v48, s[28:31], null offen              ; c406007c 40803834 00000030
	buffer_store_b8 v56, v48, s[28:31], null offen offset:16    ; c406007c 40803838 00001030
	buffer_store_b8 v60, v48, s[28:31], null offen offset:32    ; c406007c 4080383c 00002030
	buffer_store_b8 v64, v48, s[28:31], null offen offset:48    ; c406007c 40803840 00003030
BB79:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_add_nc_u32_e32 v42, 4, v42                                ; 4a545484
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72d0005
	v_cndmask_b32_e32 v0, v42, v8, vcc_lo                       ; 0200112a
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v5, v9, vcc_lo                        ; 02001305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v42, v42, v6                               ; 4c540d2a
(invalid instruction)                                        ; d7026a08
	v_cndmask_b32_e32 v1, s9, v42, vcc_lo                       ; 02025409
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v8, v8, v42, vcc_lo                       ; 02105508
	v_subrev_co_ci_u32_e64 v5, s4, -1, v5, vcc_lo               ; d5220405 01aa0ac1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
(invalid instruction)                                        ; d7026a09
	v_cndmask_b32_e32 v1, s9, v8, vcc_lo                        ; 02021009
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v9, v9, v8, vcc_lo                        ; 02121109
	v_subrev_co_ci_u32_e64 v5, s8, -1, v5, vcc_lo               ; d5220805 01aa0ac1
	v_lshrrev_b32_e32 v9, 2, v9                                 ; 32121282
	v_and_b32_e32 v11, 3, v5                                    ; 36160a83
	v_lshrrev_b32_e32 v10, 2, v5                                ; 32140a82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c000a
	v_cndmask_b32_e32 v0, v10, v17, vcc_lo                      ; 0200230a
	v_add_nc_u32_e32 v10, v10, v9                               ; 4a14130a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_and_b32_e32 v10, 0xfffffff, v10                           ; 361414ff 0fffffff
(invalid instruction)                                        ; d72c000a
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                       ; 0200030a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v10, v10, v7, 8                              ; d647000a 02220f0a
	v_add_nc_u32_e32 v10, s3, v10                               ; 4a141403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v11, v11, 6, v10                             ; d646000b 04290d0b
	v_add_nc_u32_e32 v11, v11, v4                               ; 4a16090b
	v_cmpx_gt_u32_e32 s10, v5                                   ; 7d980a0a
	s_cbranch_execz BB85                                        ; bfa5000d
BB80:
	s_clause 0x3                                                ; bf850003
	buffer_store_b8 v68, v11, s[28:31], null offen              ; c406007c 40803844 0000000b
	buffer_store_b8 v72, v11, s[28:31], null offen offset:16    ; c406007c 40803848 0000100b
	buffer_store_b8 v76, v11, s[28:31], null offen offset:32    ; c406007c 4080384c 0000200b
	buffer_store_b8 v79, v11, s[28:31], null offen offset:48    ; c406007c 4080384f 0000300b
BB85:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
BB87:
	s_cmp_lt_u32 s14, s6                                        ; bf0a060e
	s_cbranch_scc0 BB114                                        ; bfa101ae
BB88:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[16:17], 0x40                        ; f4004608 f8000040
	s_load_b128 s[16:19], s[16:17], 0x10                        ; f4004408 f8000010
	v_lshrrev_b32_e32 v5, 4, v1                                 ; 320a0284
	v_add3_u32 v1, v4, s5, v1                                   ; d6550001 04040b04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d1
	v_lshlrev_b32_e32 v1, 1, v1                                 ; 30020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_d16_b16 v6, v1, s[24:27], null offen            ; c408007c 40803006 00000001
	v_and_b32_e32 v0, 16, v0                                    ; 36000090
	s_lshr_b32 s7, s7, 4                                        ; 85078407
	s_mul_i32 s15, s15, s7                                      ; 960f070f
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshl_or_b32 v0, v0, 3, v4                                 ; d6560000 04110700
	v_add_lshl_u32 v7, s15, v5, 8                               ; d6470007 02220a0f
	v_add3_u32 v7, v0, s2, v7                                   ; d6550007 041c0500
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v8, v7, s[16:19], null offen             ; c407807c 40802008 00000007
	buffer_load_d16_u8 v9, v7, s[16:19], null offen offset:16   ; c407807c 40802009 00001007
	buffer_load_d16_u8 v10, v7, s[16:19], null offen offset:32  ; c407807c 4080200a 00002007
	buffer_load_d16_u8 v11, v7, s[16:19], null offen offset:48  ; c407807c 4080200b 00003007
	buffer_load_d16_u8 v12, v7, s[16:19], null offen offset:64  ; c407807c 4080200c 00004007
	buffer_load_d16_u8 v13, v7, s[16:19], null offen offset:80  ; c407807c 4080200d 00005007
	buffer_load_d16_u8 v14, v7, s[16:19], null offen offset:96  ; c407807c 4080200e 00006007
	buffer_load_d16_u8 v15, v7, s[16:19], null offen offset:112 ; c407807c 4080200f 00007007
	v_add_nc_u32_e32 v3, s14, v3                                ; 4a06060e
	s_cvt_f32_u32 s1, s9                                        ; be816509
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d6840001
	v_cndmask_b32_e32 v0, s1, v128, vcc_lo                      ; 02010001
	s_mul_f32 s1, s1, 0x4f7ffffe                                ; a201ff01 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s1, s1                                        ; be816701
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s4, s9, s1                                        ; 96040109
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s4, 0, s4                                      ; 81840480
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s4, s1, s4                                     ; 96840401
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s1, s1, s4                                     ; 80010401
	s_lshr_b32 s8, s9, 2                                        ; 85088209
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; d72d0010
	v_cndmask_b32_e32 v0, v3, v1, vcc_lo                        ; 02000303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0011
	v_cndmask_b32_e32 v0, v16, v9, vcc_lo                       ; 02001310
	v_sub_nc_u32_e32 v17, v3, v17                               ; 4c222303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
(invalid instruction)                                        ; d7026a12
	v_cndmask_b32_e32 v1, s9, v17, vcc_lo                       ; 02022209
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v18, v18, v17, vcc_lo                     ; 02242312
	v_subrev_co_ci_u32_e64 v16, s5, -1, v16, vcc_lo             ; d5220510 01aa20c1
(invalid instruction)                                        ; d7026a13
	v_cndmask_b32_e32 v1, s9, v18, vcc_lo                       ; 02022409
	s_wait_alu 0xfffd                                           ; bf88fffd
	v_cndmask_b32_e32 v19, v19, v18, vcc_lo                     ; 02262513
	v_subrev_co_ci_u32_e64 v16, s6, -1, v16, vcc_lo             ; d5220610 01aa20c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870142
	v_lshrrev_b32_e32 v19, 2, v19                               ; 32262682
	v_cmp_gt_u32_e32 vcc_lo, s10, v16                           ; 7c98200a
	v_lshrrev_b32_e32 v20, 2, v16                               ; 32282082
	v_and_b32_e32 v22, 3, v16                                   ; 362c2083
(invalid instruction)                                        ; d72c0014
	v_cndmask_b32_e32 v0, v20, v8, vcc_lo                       ; 02001114
	v_lshlrev_b32_e32 v22, 6, v22                               ; 302c2c86
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_add_nc_u32_e32 v20, v20, v19                              ; 4a282714
	v_and_b32_e32 v20, 0xfffffff, v20                           ; 362828ff 0fffffff
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0014
	v_cndmask_b32_e32 v0, v20, v7, vcc_lo                       ; 02000f14
	v_add_lshl_u32 v21, v20, v5, 8                              ; d6470015 02220b14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add3_u32 v21, v22, s3, v21                                ; d6550015 04540716
	v_add_nc_u32_e32 v21, v21, v4                               ; 4a2a0915
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v23, v8                                   ; 7e2ed908
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v42, v9                                   ; 7e54d909
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v46, v10                                  ; 7e5cd90a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v50, v11                                  ; 7e64d90b
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v24, v6, v23, v24 op_sel_hi:[1,0,0]         ; cc210018 0c622f06
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v54, v12                                  ; 7e6cd90c
	v_fma_mixlo_f16 v43, v6, v42, v25 op_sel_hi:[1,0,0]         ; cc21002b 0c665506
	v_fma_mixlo_f16 v47, v6, v46, v26 op_sel_hi:[1,0,0]         ; cc21002f 0c6a5d06
	v_fma_mixlo_f16 v51, v6, v50, v27 op_sel_hi:[1,0,0]         ; cc210033 0c6e6506
	v_maxmin_num_f16 v24, 0xdf00, v24, neg(0xdf00)              ; d66b0018 83fe30ff 0000df00
	v_fma_mixlo_f16 v55, v6, v54, v28 op_sel_hi:[1,0,0]         ; cc210037 0c726d06
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v58, v13                                  ; 7e74d90d
	v_maxmin_num_f16 v43, 0xdf00, v43, neg(0xdf00)              ; d66b002b 83fe56ff 0000df00
	v_maxmin_num_f16 v47, 0xdf00, v47, neg(0xdf00)              ; d66b002f 83fe5eff 0000df00
	v_maxmin_num_f16 v51, 0xdf00, v51, neg(0xdf00)              ; d66b0033 83fe66ff 0000df00
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v62, v14                                  ; 7e7cd90e
	v_cvt_f32_f16_e32 v40, v24                                  ; 7e501718
	v_maxmin_num_f16 v55, 0xdf00, v55, neg(0xdf00)              ; d66b0037 83fe6eff 0000df00
	v_fma_mixlo_f16 v59, v6, v58, v29 op_sel_hi:[1,0,0]         ; cc21003b 0c767506
	v_cvt_f32_f16_e32 v44, v43                                  ; 7e58172b
	v_cvt_f32_f16_e32 v48, v47                                  ; 7e60172f
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v66, v15                                  ; 7e84d90f
	v_cvt_f32_f16_e32 v52, v51                                  ; 7e681733
	v_fma_mixlo_f16 v63, v6, v62, v30 op_sel_hi:[1,0,0]         ; cc21003f 0c7a7d06
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v0, v40, v128, vcc_lo                     ; 02010128
	v_cvt_f32_f16_e32 v56, v55                                  ; 7e701737
	v_maxmin_num_f16 v59, 0xdf00, v59, neg(0xdf00)              ; d66b003b 83fe76ff 0000df00
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v0, v44, v128, vcc_lo                     ; 0201012c
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
	v_fma_mixlo_f16 v6, v6, v66, v31 op_sel_hi:[1,0,0]          ; cc210006 0c7e8506
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v0, v52, v128, vcc_lo                     ; 02010134
	v_maxmin_num_f16 v63, 0xdf00, v63, neg(0xdf00)              ; d66b003f 83fe7eff 0000df00
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v0, v56, v128, vcc_lo                     ; 02010138
	v_cvt_f32_f16_e32 v60, v59                                  ; 7e78173b
	v_maxmin_num_f16 v6, 0xdf00, v6, neg(0xdf00)                ; d66b0006 83fe0cff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_cvt_f32_f16_e32 v64, v63                                  ; 7e80173f
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v0, v60, v128, vcc_lo                     ; 0201013c
	v_cvt_f32_f16_e32 v67, v6                                   ; 7e861706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v0, v64, v128, vcc_lo                     ; 02010140
(invalid instruction)                                        ; d7690044
	v_cndmask_b32_e32 v0, v67, v128, vcc_lo                     ; 02010143
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB94                                        ; bfa5000d
BB89:
	s_clause 0x3                                                ; bf850003
	buffer_store_b8 v41, v21, s[16:19], null offen              ; c406007c 40802029 00000015
	buffer_store_b8 v45, v21, s[16:19], null offen offset:16    ; c406007c 4080202d 00001015
	buffer_store_b8 v49, v21, s[16:19], null offen offset:32    ; c406007c 40802031 00002015
	buffer_store_b8 v53, v21, s[16:19], null offen offset:48    ; c406007c 40802035 00003015
BB94:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_add_nc_u32_e32 v3, 4, v3                                  ; 4a060684
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72d0006
	v_cndmask_b32_e32 v0, v3, v1, vcc_lo                        ; 02000303
(invalid instruction)                                        ; d72c0007
	v_cndmask_b32_e32 v0, v6, v9, vcc_lo                        ; 02001306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v3, v3, v7                                 ; 4c060f03
(invalid instruction)                                        ; d7020108
	v_cndmask_b32_e32 v1, s9, v3, vcc_lo                        ; 02020609
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_subrev_co_ci_u32_e64 v6, s4, -1, v6, s1                   ; d5220406 00060cc1
	v_cndmask_b32_e64 v8, v8, v3, s1                            ; d5010008 00060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
(invalid instruction)                                        ; d7020909
	v_cndmask_b32_e32 v1, s9, v8, vcc_lo                        ; 02021009
	s_wait_alu 0xf1ff                                           ; bf88f1ff
	v_subrev_co_ci_u32_e64 v6, s5, -1, v6, s9                   ; d5220506 00260cc1
	v_cndmask_b32_e64 v9, v9, v8, s9                            ; d5010009 00261109
	v_and_b32_e32 v11, 3, v6                                    ; 36160c83
	v_lshrrev_b32_e32 v10, 2, v6                                ; 32140c82
	v_lshrrev_b32_e32 v9, 2, v9                                 ; 32121282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a3
	v_lshlrev_b32_e32 v11, 6, v11                               ; 30161686
(invalid instruction)                                        ; d72c000a
	v_cndmask_b32_e32 v0, v10, v8, vcc_lo                       ; 0200110a
	v_add_nc_u32_e32 v10, v10, v9                               ; 4a14130a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_and_b32_e32 v10, 0xfffffff, v10                           ; 361414ff 0fffffff
(invalid instruction)                                        ; d72c000a
	v_cndmask_b32_e32 v0, v10, v7, vcc_lo                       ; 02000f0a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v5, v10, v5, 8                               ; d6470005 02220b0a
	v_add3_u32 v5, v11, s3, v5                                  ; d6550005 0414070b
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v5, v5, v4                                 ; 4a0a0905
	v_cmpx_gt_u32_e32 s10, v6                                   ; 7d980c0a
	s_mov_b32 s10, exec_lo                                      ; be8a007e
	s_cbranch_execz BB100                                       ; bfa5000d
BB95:
	s_clause 0x3                                                ; bf850003
	buffer_store_b8 v57, v5, s[16:19], null offen               ; c406007c 40802039 00000005
	buffer_store_b8 v61, v5, s[16:19], null offen offset:16     ; c406007c 4080203d 00001005
	buffer_store_b8 v65, v5, s[16:19], null offen offset:32     ; c406007c 40802041 00002005
	buffer_store_b8 v68, v5, s[16:19], null offen offset:48     ; c406007c 40802044 00003005
BB100:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	buffer_load_d16_b16 v1, v1, s[24:27], null offen offset:32  ; c408007c 40803001 00002001
	v_lshrrev_b32_e32 v2, 4, v2                                 ; 32040484
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_lshl_u32 v3, s15, v2, 8                               ; d6470003 0222040f
	v_add3_u32 v0, v0, s2, v3                                   ; d6550000 040c0500
	s_clause 0x7                                                ; bf850007
	buffer_load_d16_u8 v5, v0, s[16:19], null offen             ; c407807c 40802005 00000000
	buffer_load_d16_u8 v6, v0, s[16:19], null offen offset:16   ; c407807c 40802006 00001000
	buffer_load_d16_u8 v7, v0, s[16:19], null offen offset:32   ; c407807c 40802007 00002000
	buffer_load_d16_u8 v8, v0, s[16:19], null offen offset:48   ; c407807c 40802008 00003000
	buffer_load_d16_u8 v9, v0, s[16:19], null offen offset:64   ; c407807c 40802009 00004000
	buffer_load_d16_u8 v12, v0, s[16:19], null offen offset:80  ; c407807c 4080200c 00005000
	buffer_load_d16_u8 v13, v0, s[16:19], null offen offset:96  ; c407807c 4080200d 00006000
	buffer_load_d16_u8 v14, v0, s[16:19], null offen offset:112 ; c407807c 4080200e 00007000
	v_add_lshl_u32 v20, v20, v2, 8                              ; d6470014 02220514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add3_u32 v22, v22, s3, v20                                ; d6550016 04500716
	v_add_nc_u32_e32 v22, v22, v4                               ; 4a2c0916
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_cvt_f32_fp8_e32 v15, v5                                   ; 7e1ed905
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_cvt_f32_fp8_e32 v19, v6                                   ; 7e26d906
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_cvt_f32_fp8_e32 v24, v7                                   ; 7e30d907
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_cvt_f32_fp8_e32 v28, v8                                   ; 7e38d908
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mixlo_f16 v16, v1, v15, v32 op_sel_hi:[1,0,0]         ; cc210010 0c821f01
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_cvt_f32_fp8_e32 v32, v9                                   ; 7e40d909
	v_fma_mixlo_f16 v20, v1, v19, v33 op_sel_hi:[1,0,0]         ; cc210014 0c862701
	v_fma_mixlo_f16 v25, v1, v24, v34 op_sel_hi:[1,0,0]         ; cc210019 0c8a3101
	v_fma_mixlo_f16 v29, v1, v28, v35 op_sel_hi:[1,0,0]         ; cc21001d 0c8e3901
	v_maxmin_num_f16 v16, 0xdf00, v16, neg(0xdf00)              ; d66b0010 83fe20ff 0000df00
	v_fma_mixlo_f16 v33, v1, v32, v36 op_sel_hi:[1,0,0]         ; cc210021 0c924101
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_f32_fp8_e32 v36, v12                                  ; 7e48d90c
	v_maxmin_num_f16 v20, 0xdf00, v20, neg(0xdf00)              ; d66b0014 83fe28ff 0000df00
	v_maxmin_num_f16 v25, 0xdf00, v25, neg(0xdf00)              ; d66b0019 83fe32ff 0000df00
	v_maxmin_num_f16 v29, 0xdf00, v29, neg(0xdf00)              ; d66b001d 83fe3aff 0000df00
	v_cvt_f32_f16_e32 v17, v16                                  ; 7e221710
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_cvt_f32_fp8_e32 v42, v13                                  ; 7e54d90d
	v_maxmin_num_f16 v33, 0xdf00, v33, neg(0xdf00)              ; d66b0021 83fe42ff 0000df00
	v_fma_mixlo_f16 v37, v1, v36, v37 op_sel_hi:[1,0,0]         ; cc210025 0c964901
	v_cvt_f32_f16_e32 v21, v20                                  ; 7e2a1714
	v_cvt_f32_f16_e32 v26, v25                                  ; 7e341719
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_f32_fp8_e32 v46, v14                                  ; 7e5cd90e
	v_cvt_f32_f16_e32 v30, v29                                  ; 7e3c171d
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                     ; 02010111
	v_fma_mixlo_f16 v43, v1, v42, v38 op_sel_hi:[1,0,0]         ; cc21002b 0c9a5501
	v_cvt_f32_f16_e32 v34, v33                                  ; 7e441721
	v_maxmin_num_f16 v37, 0xdf00, v37, neg(0xdf00)              ; d66b0025 83fe4aff 0000df00
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v26, v128, vcc_lo                     ; 0201011a
	v_fma_mixlo_f16 v1, v1, v46, v39 op_sel_hi:[1,0,0]          ; cc210001 0c9e5d01
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v0, v30, v128, vcc_lo                     ; 0201011e
	v_maxmin_num_f16 v43, 0xdf00, v43, neg(0xdf00)              ; d66b002b 83fe56ff 0000df00
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v0, v34, v128, vcc_lo                     ; 02010122
	v_cvt_f32_f16_e32 v40, v37                                  ; 7e501725
	v_maxmin_num_f16 v1, 0xdf00, v1, neg(0xdf00)                ; d66b0001 83fe02ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_cvt_f32_f16_e32 v44, v43                                  ; 7e58172b
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v0, v40, v128, vcc_lo                     ; 02010128
	v_cvt_f32_f16_e32 v47, v1                                   ; 7e5e1701
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v0, v44, v128, vcc_lo                     ; 0201012c
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v0, v47, v128, vcc_lo                     ; 0201012f
	s_mov_b32 exec_lo, vcc_lo                                   ; befe006a
	s_cbranch_execz BB106                                       ; bfa5000d
BB101:
	s_clause 0x3                                                ; bf850003
	buffer_store_b8 v18, v22, s[16:19], null offen              ; c406007c 40802012 00000016
	buffer_store_b8 v23, v22, s[16:19], null offen offset:16    ; c406007c 40802017 00001016
	buffer_store_b8 v27, v22, s[16:19], null offen offset:32    ; c406007c 4080201b 00002016
	buffer_store_b8 v31, v22, s[16:19], null offen offset:48    ; c406007c 4080201f 00003016
BB106:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	v_add_lshl_u32 v10, v10, v2, 8                              ; d647000a 0222050a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add3_u32 v11, v11, s3, v10                                ; d655000b 0428070b
	v_add_nc_u32_e32 v11, v11, v4                               ; 4a16090b
	s_mov_b32 exec_lo, s10                                      ; befe000a
	s_cbranch_execz BB114                                       ; bfa5000d
BB107:
	s_clause 0x3                                                ; bf850003
	buffer_store_b8 v35, v11, s[16:19], null offen              ; c406007c 40802023 0000000b
	buffer_store_b8 v41, v11, s[16:19], null offen offset:16    ; c406007c 40802029 0000100b
	buffer_store_b8 v45, v11, s[16:19], null offen offset:32    ; c406007c 4080202d 0000200b
	buffer_store_b8 v48, v11, s[16:19], null offen offset:48    ; c406007c 40802030 0000300b
BB114:
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s20, -1                                        ; bf01c114
	s_cbranch_scc0 BB123                                        ; bfa1000f
BB115:
	s_mov_b32 exec_lo, 3                                        ; befe0083
BB116:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[0:3], s[0:1], 0x0                             ; f4004000 f8000000
	s_add_co_u32 s20, s20, s12                                  ; 80140c14
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
(invalid instruction)                                        ; d71f0000
	v_cndmask_b32_e32 v0, -1, v20, vcc_lo                       ; 020028c1
	v_dual_mov_b32 v1, 1 :: v_dual_lshlrev_b32 v0, 2, v0        ; ca220081 01000082
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_atomic_add_u32 v1, v0, s[0:3], null offen            ; c40d407c 40800001 00000000
BB123:
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
