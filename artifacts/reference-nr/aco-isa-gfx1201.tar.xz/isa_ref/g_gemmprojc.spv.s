BB0:
	s_cmp_lg_i32 s10, -1                                        ; bf01c10a
	s_cbranch_scc0 BB2                                          ; bfa1000f
BB1:
	s_mov_b32 s14, s0                                           ; be8e0000
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b128 s[16:19], s[14:15], 0x30                        ; f4004407 f8000030
	s_lshl2_add_u32 s13, s10, 24                                ; 878d980a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s13, s[16:19], s13 offset:0x0             ; f4020348 1a000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s13, 0x54434852                                ; bf01ff0d 54434852
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s13, vcc_lo, exec_lo                              ; 8b0d7e6a
	s_cselect_b32 s10, -1, s10                                  ; 980a0ac1
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s10, -1                                        ; bf01c10a
	s_cbranch_scc0 BB5                                          ; bfa1000b
BB4:
	s_mov_b32 s14, s0                                           ; be8e0000
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_load_b128 s[16:19], s[14:15], 0x30                        ; f4004407 f8000030
	s_mov_b32 s13, src_scc                                      ; be8d00fd
	s_lshl2_add_u32 s14, s10, 12                                ; 878e8c0a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s14, s[16:19], s14 offset:0x0             ; f4020388 1c000000
	s_branch BB6                                                ; bfa00002
BB5:
	s_mov_b32 s13, src_scc                                      ; be8d00fd
	s_mov_b32 s14, -1                                           ; be8e00c1
BB6:
	s_mov_b32 s15, ttmp9                                        ; be8f0075
	s_mov_b32 s16, ttmp7                                        ; be900073
	s_cmp_lg_i32 s9, 0                                          ; bf018009
	s_cbranch_scc0 BB9                                          ; bfa1004c
BB7:
	s_mul_i32 s15, s11, ttmp7                                   ; 960f730b
	s_mul_i32 s16, s9, s12                                      ; 96100c09
	s_add_co_u32 s15, ttmp9, s15                                ; 800f0f75
	s_cvt_f32_u32 s17, s16                                      ; be916510
(invalid instruction)                                        ; d6840011
	v_cndmask_b32_e32 v0, s17, v128, vcc_lo                     ; 02010011
	s_mul_f32 s17, s17, 0x4f7ffffe                              ; a211ff11 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s17, s17                                      ; be916711
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s18, s16, s17                                     ; 96121110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s18, 0, s18                                    ; 81921280
	s_mul_hi_u32 s18, s17, s18                                  ; 96921211
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s17, s17, s18                                  ; 80111211
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s17, s15, s17                                  ; 9691110f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s19, s17, s16                                     ; 96131011
	s_sub_co_i32 s19, s15, s19                                  ; 8193130f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s20, s19, s16                                  ; 80941013
	s_absdiff_i32 s22, src_scc, 1                               ; 831681fd
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_add_co_u32 s17, s17, s22                                  ; 80111611
	s_sub_co_u32 s20, s19, s16                                  ; 80941013
	s_cselect_b32 s19, s19, s20                                 ; 98131413
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_ge_u32 s19, s16                                       ; bf091013
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s17, s17, src_scc                              ; 8011fd11
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s17, s17, s9                                      ; 96110911
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s11, s11, s17                                  ; 818b110b
	s_mul_i32 s12, s17, s12                                     ; 960c0c11
	s_min_u32 s9, s9, s11                                       ; 89890b09
	s_sub_co_i32 s15, s15, s12                                  ; 818f0c0f
	s_cvt_f32_u32 s23, s9                                       ; be976509
(invalid instruction)                                        ; d6840017
	v_cndmask_b32_e32 v0, s23, v128, vcc_lo                     ; 02010017
	s_mul_f32 s23, s23, 0x4f7ffffe                              ; a217ff17 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s23, s23                                      ; be976717
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s24, s9, s23                                      ; 96181709
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s24, 0, s24                                    ; 81981880
	s_mul_hi_u32 s24, s23, s24                                  ; 96981817
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1) ; bf8704d9
	s_add_co_u32 s23, s23, s24                                  ; 80171817
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s23, s15, s23                                  ; 9697170f
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s25, s23, s9                                      ; 96190917
	s_sub_co_i32 s15, s15, s25                                  ; 818f190f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s26, s15, s9                                   ; 809a090f
	s_absdiff_i32 s28, src_scc, 1                               ; 831c81fd
	s_sub_co_u32 s26, s15, s9                                   ; 809a090f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s15, s15, s26                                 ; 980f1a0f
	s_sub_co_u32 s9, s15, s9                                    ; 8089090f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mov_b32 s29, src_scc                                      ; be9d00fd
	s_absdiff_i32 s30, src_scc, 1                               ; 831e81fd
	s_cmp_lg_i32 s29, 0                                         ; bf01801d
	s_cselect_b32 s15, s15, s9                                  ; 980f090f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s15, s17, s15                                  ; 800f0f11
	s_add_co_u32 s23, s23, s28                                  ; 80171c17
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s23, s30                                  ; 80101e17
BB9:
	s_cmp_lg_i32 s13, 0                                         ; bf01800d
	s_cbranch_scc0 BB11                                         ; bfa1000e
BB10:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[20:23], s[12:13], 0x30                        ; f4004506 f8000030
	s_lshl2_add_u32 s9, s10, 8                                  ; 8789880a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_buffer_load_b32 s9, s[20:23], s9 offset:0x0               ; f402024a 12000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s9, -1                                         ; bf01c109
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB12                                               ; bfa00001
BB11:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB12:
	s_lshl_b32 s15, s15, 5                                      ; 840f850f
	s_and_b32 s9, vcc_lo, exec_lo                               ; 8b097e6a
	s_cbranch_scc0 BB53                                         ; bfa1007b
BB13:
	s_and_b32 s9, ttmp8, 0x3e000000                             ; 8b09ff74 3e000000
	s_cbranch_scc1 BB51                                         ; bfa20076
BB14:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[20:23], s[12:13], 0x30                        ; f4004506 f8000030
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s11, s10, 8                                    ; 800b880a
	s_add_co_u32 s17, s10, 16                                   ; 8011900a
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_clause 0x2                                                ; bf850002
	s_buffer_load_b32 s9, s[20:23], s10 offset:0x0              ; f402024a 14000000
	s_buffer_load_b32 s11, s[20:23], s11 offset:0x0             ; f40202ca 16000000
	s_buffer_load_b32 s17, s[20:23], s17 offset:0x0             ; f402044a 22000000
	s_load_b128 s[24:27], s[12:13], 0x0                         ; f4004606 f8000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s17, s17, 2                                      ; 84118211
	buffer_load_b32 v1, off, s[24:27], s17 scope:SCOPE_DEV      ; c4050011 00883001 00000000
	s_lshr_b32 s18, s15, 4                                      ; 8512840f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s11, s11, s18                                  ; 800b120b
	s_lshl_b32 s11, s11, 2                                      ; 840b820b
	s_buffer_load_b32 s19, s[20:23], s11 offset:0x0             ; f40204ca 16000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s19, -1                                        ; bf01c113
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s28, v1                                 ; 7e380501
	s_cbranch_scc0 BB23                                         ; bfa1001b
BB15:
	s_bfm_b32 s12, 1, 16                                        ; 950c9081
BB16:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s12, 0                                         ; bf01800c
	s_cbranch_scc0 BB18                                         ; bfa10011
BB17:
	s_and_b32 s13, s19, 0xfffff                                 ; 8b0dff13 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s13, s9, s13                                   ; 800d0d09
	s_lshl_b32 s13, s13, 2                                      ; 840d820d
	buffer_load_b32 v1, off, s[24:27], s13 scope:SCOPE_DEV      ; c405000d 00883001 00000000
	s_lshr_b32 s17, s19, 20                                     ; 85119413
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s17, s17, s28                                     ; 96111c11
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s18, v1                                 ; 7e240501
	s_cmp_lt_u32 s18, s17                                       ; bf0a1112
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s29, -1, 0                                    ; 981d80c1
	s_branch BB19                                               ; bfa00001
BB18:
	s_mov_b32 s29, 0                                            ; be9d0080
BB19:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s29, exec_lo, s29                            ; 911d1d7e
	s_cbranch_scc1 BB24                                         ; bfa20003
BB21:
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
	s_branch BB16                                               ; bfa0ffe6
BB23:
	s_bfm_b32 s12, 1, 16                                        ; 950c9081
BB24:
	s_add_co_u32 s11, s11, 4                                    ; 800b840b
	s_buffer_load_b32 s11, s[20:23], s11 offset:0x0             ; f40202ca 16000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s11, -1                                        ; bf01c10b
	s_cbranch_scc0 BB34                                         ; bfa1001a
BB25:
	s_branch BB26                                               ; bfa00001
BB31:
	s_add_co_u32 s12, s12, -1                                   ; 800cc10c
BB26:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s12, 0                                         ; bf01800c
	s_cbranch_scc0 BB28                                         ; bfa10011
BB27:
	s_and_b32 s13, s11, 0xfffff                                 ; 8b0dff0b 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s13, s9, s13                                   ; 800d0d09
	s_lshl_b32 s13, s13, 2                                      ; 840d820d
	buffer_load_b32 v1, off, s[24:27], s13 scope:SCOPE_DEV      ; c405000d 00883001 00000000
	s_lshr_b32 s17, s11, 20                                     ; 8511940b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s17, s17, s28                                     ; 96111c11
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s18, v1                                 ; 7e240501
	s_cmp_lt_u32 s18, s17                                       ; bf0a1112
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s19, -1, 0                                    ; 981380c1
	s_branch BB29                                               ; bfa00001
BB28:
	s_mov_b32 s19, 0                                            ; be930080
BB29:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s19, exec_lo, s19                            ; 9113137e
	s_cbranch_scc0 BB31                                         ; bfa1ffe7
BB34:
	s_cmp_eq_i32 s12, 0                                         ; bf00800c
	s_cbranch_scc0 BB36                                         ; bfa10002
BB35:
	s_mov_b32 s9, 1                                             ; be890081
	s_branch BB37                                               ; bfa00001
BB36:
	s_mov_b32 s9, 0                                             ; be890080
BB37:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mov_b32 exec_lo, s9                                       ; befe0009
	s_cbranch_execz BB49                                        ; bfa5000e
BB38:
	s_ctz_i32_b32 s9, exec_lo                                   ; be89087e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s9, 1, s9                                        ; 84090981
	s_and_saveexec_b32 s9, s9                                   ; be892009
	s_cbranch_execz BB49                                        ; bfa50009
BB39:
	s_add_co_u32 s10, s10, 20                                   ; 800a940a
	s_buffer_load_b32 s10, s[20:23], s10 offset:0x0             ; f402028a 14000000
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s10, s10, 2                                      ; 840a820a
	buffer_atomic_max_u32 v1, off, s[24:27], s10                ; c40ec00a 00803001 00000000
BB49:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
BB51:
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
BB53:
	v_and_b32_e32 v3, 31, v0                                    ; 3606009f
	v_bfe_u32 v1, v0, 5, 2                                      ; d6100001 02090b00
	v_and_b32_e32 v0, 15, v0                                    ; 3600008f
	s_lshr_b32 s9, s8, 4                                        ; 85098408
	s_lshr_b32 s10, s15, 4                                      ; 850a840f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1) ; bf8700c9
	s_mul_i32 s11, s10, s9                                      ; 960b090a
	v_lshlrev_b32_e32 v0, 4, v0                                 ; 30000084
	s_lshl_b32 s11, s11, 8                                      ; 840b880b
	s_add_co_u32 s12, 16, s15                                   ; 800c0f90
	v_add3_u32 v4, v0, s1, s11                                  ; d6550004 002c0300
	s_lshr_b32 s13, s12, 4                                      ; 850d840c
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0                ; ca100080 09080080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0              ; ca100080 0b0a0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v12, 0              ; ca100080 0d0c0080
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0              ; ca100080 0e0e0080
	s_mul_i32 s17, s13, s9                                      ; 9611090d
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v16, 0              ; ca100080 11100080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s17, s17, 8                                      ; 84118811
	s_lshl_b32 s16, s16, 7                                      ; 84108710
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	s_lshr_b32 s8, s8, 8                                        ; 85088808
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v5, v0, s1, s17                                  ; d6550005 00440300
	s_mov_b32 s1, 0                                             ; be810080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_lshl_add_u32 v1, v1, 5, s16                               ; d6460001 00410b01
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_lshrrev_b32_e32 v2, 5, v1                                 ; 32040285
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                        ; 02001302
	v_lshl_add_u32 v2, v2, 7, s4                                ; d6460002 00110f02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_lshl_add_u32 v2, v3, 2, v2                                ; d6460002 04090503
	v_lshrrev_b32_e32 v3, 4, v3                                 ; 32060684
	v_lshlrev_b32_e32 v3, 3, v3                                 ; 30060683
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_add_nc_u32_e32 v4, v4, v3                                 ; 4a080704
	v_add_nc_u32_e32 v5, v5, v3                                 ; 4a0a0705
	v_lshrrev_b32_e32 v4, 2, v4                                 ; 32080882
	v_lshrrev_b32_e32 v5, 2, v5                                 ; 320a0a82
	s_branch BB54                                               ; bfa00148
	s_nop 0                                                     ; bf800000
BB56:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[16:17], 0x70                        ; f4004508 f8000070
	s_load_b128 s[16:19], s[16:17], 0x30                        ; f4004408 f8000030
	s_lshl_b32 s4, s1, 8                                        ; 84048801
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s4, s4, 4                                        ; 85048404
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v40, s4, 7, v2                               ; d6460028 04090e04
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v40, 2, v40                               ; 30505082
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[44:47], v40, s[16:19], null offen        ; c405c07c 4080202c 00000028
	buffer_load_b128 v[48:51], v40, s[16:19], null offen offset:512 ; c405c07c 40802030 00020028
	buffer_load_b128 v[52:55], v40, s[16:19], null offen offset:1024 ; c405c07c 40802034 00040028
	buffer_load_b128 v[56:59], v40, s[16:19], null offen offset:1536 ; c405c07c 40802038 00060028
	buffer_load_b128 v[60:63], v40, s[16:19], null offen offset:2048 ; c405c07c 4080203c 00080028
	buffer_load_b128 v[64:67], v40, s[16:19], null offen offset:2560 ; c405c07c 40802040 000a0028
	s_lshl_b32 s9, s4, 8                                        ; 84098804
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshr_b32 s9, s9, 2                                        ; 85098209
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v6, s9, v4, 2                                ; d6470006 020a0809
	v_add_lshl_u32 v7, s9, v5, 2                                ; d6470007 020a0a09
	s_wait_storecnt 0x0                                         ; bfc10000
	s_clause 0xd                                                ; bf85000d
	buffer_load_b64 v[42:43], v6, s[20:23], null offen          ; c405407c 4080282a 00000006
	buffer_load_b64 v[68:69], v7, s[20:23], null offen          ; c405407c 40802844 00000007
	buffer_load_b64 v[70:71], v6, s[20:23], null offen offset:256 ; c405407c 40802846 00010006
	buffer_load_b64 v[72:73], v7, s[20:23], null offen offset:256 ; c405407c 40802848 00010007
	buffer_load_b64 v[74:75], v6, s[20:23], null offen offset:512 ; c405407c 4080284a 00020006
	buffer_load_b64 v[76:77], v7, s[20:23], null offen offset:512 ; c405407c 4080284c 00020007
	buffer_load_b64 v[78:79], v6, s[20:23], null offen offset:768 ; c405407c 4080284e 00030006
	buffer_load_b64 v[80:81], v7, s[20:23], null offen offset:768 ; c405407c 40802850 00030007
	buffer_load_b64 v[82:83], v6, s[20:23], null offen offset:1024 ; c405407c 40802852 00040006
	buffer_load_b64 v[84:85], v7, s[20:23], null offen offset:1024 ; c405407c 40802854 00040007
	buffer_load_b64 v[86:87], v6, s[20:23], null offen offset:1280 ; c405407c 40802856 00050006
	buffer_load_b64 v[88:89], v7, s[20:23], null offen offset:1280 ; c405407c 40802858 00050007
	buffer_load_b64 v[90:91], v6, s[20:23], null offen offset:1536 ; c405407c 4080285a 00060006
	buffer_load_b64 v[92:93], v7, s[20:23], null offen offset:1536 ; c405407c 4080285c 00060007
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[44:45], v[42:43], v[8:15] ; cc464008 1c22552c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[42:43], v[16:23] ; cc464010 1c42552e
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[44:45], v[68:69], v[24:31] ; cc464018 1c62892c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[46:47], v[68:69], v[32:39] ; cc464020 1c82892e
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[48:49], v[70:71], v[8:15] ; cc464008 1c228d30
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[50:51], v[70:71], v[16:23] ; cc464010 1c428d32
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[48:49], v[72:73], v[24:31] ; cc464018 1c629130
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[50:51], v[72:73], v[32:39] ; cc464020 1c829132
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[52:53], v[74:75], v[8:15] ; cc464008 1c229534
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[74:75], v[16:23] ; cc464010 1c429536
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[52:53], v[76:77], v[24:31] ; cc464018 1c629934
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[54:55], v[76:77], v[32:39] ; cc464020 1c829936
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[56:57], v[78:79], v[8:15] ; cc464008 1c229d38
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[58:59], v[78:79], v[16:23] ; cc464010 1c429d3a
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[56:57], v[80:81], v[24:31] ; cc464018 1c62a138
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[58:59], v[80:81], v[32:39] ; cc464020 1c82a13a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[60:61], v[82:83], v[8:15] ; cc464008 1c22a53c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[62:63], v[82:83], v[16:23] ; cc464010 1c42a53e
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[60:61], v[84:85], v[24:31] ; cc464018 1c62a93c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[62:63], v[84:85], v[32:39] ; cc464020 1c82a93e
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[64:65], v[86:87], v[8:15] ; cc464008 1c22ad40
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[66:67], v[86:87], v[16:23] ; cc464010 1c42ad42
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[64:65], v[88:89], v[24:31] ; cc464018 1c62b140
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[66:67], v[88:89], v[32:39] ; cc464020 1c82b142
	s_clause 0x6                                                ; bf850006
	buffer_load_b128 v[42:45], v40, s[16:19], null offen offset:3072 ; c405c07c 4080202a 000c0028
	buffer_load_b128 v[68:71], v40, s[16:19], null offen offset:3584 ; c405c07c 40802044 000e0028
	buffer_load_b128 v[48:51], v40, s[16:19], null offen offset:4096 ; c405c07c 40802030 00100028
	buffer_load_b128 v[52:55], v40, s[16:19], null offen offset:4608 ; c405c07c 40802034 00120028
	buffer_load_b128 v[56:59], v40, s[16:19], null offen offset:5120 ; c405c07c 40802038 00140028
	buffer_load_b128 v[60:63], v40, s[16:19], null offen offset:5632 ; c405c07c 4080203c 00160028
	buffer_load_b128 v[64:67], v40, s[16:19], null offen offset:6144 ; c405c07c 40802040 00180028
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[90:91], v[16:23] ; cc464010 1c42b52c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[42:43], v[92:93], v[24:31] ; cc464018 1c62b92a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[44:45], v[92:93], v[32:39] ; cc464020 1c82b92c
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[42:43], v[90:91], v[8:15] ; cc464008 1c22b52a
	s_clause 0xd                                                ; bf85000d
	buffer_load_b64 v[42:43], v6, s[20:23], null offen offset:1792 ; c405407c 4080282a 00070006
	buffer_load_b64 v[44:45], v7, s[20:23], null offen offset:1792 ; c405407c 4080282c 00070007
	buffer_load_b64 v[46:47], v6, s[20:23], null offen offset:2048 ; c405407c 4080282e 00080006
	buffer_load_b64 v[72:73], v7, s[20:23], null offen offset:2048 ; c405407c 40802848 00080007
	buffer_load_b64 v[74:75], v6, s[20:23], null offen offset:2304 ; c405407c 4080284a 00090006
	buffer_load_b64 v[76:77], v7, s[20:23], null offen offset:2304 ; c405407c 4080284c 00090007
	buffer_load_b64 v[78:79], v6, s[20:23], null offen offset:2560 ; c405407c 4080284e 000a0006
	buffer_load_b64 v[80:81], v7, s[20:23], null offen offset:2560 ; c405407c 40802850 000a0007
	buffer_load_b64 v[82:83], v6, s[20:23], null offen offset:2816 ; c405407c 40802852 000b0006
	buffer_load_b64 v[84:85], v7, s[20:23], null offen offset:2816 ; c405407c 40802854 000b0007
	buffer_load_b64 v[86:87], v6, s[20:23], null offen offset:3072 ; c405407c 40802856 000c0006
	buffer_load_b64 v[88:89], v7, s[20:23], null offen offset:3072 ; c405407c 40802858 000c0007
	buffer_load_b64 v[90:91], v6, s[20:23], null offen offset:3328 ; c405407c 4080285a 000d0006
	buffer_load_b64 v[92:93], v7, s[20:23], null offen offset:3328 ; c405407c 4080285c 000d0007
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[68:69], v[42:43], v[8:15] ; cc464008 1c225544
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[70:71], v[42:43], v[16:23] ; cc464010 1c425546
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[70:71], v[44:45], v[32:39] ; cc464020 1c825946
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[68:69], v[44:45], v[24:31] ; cc464018 1c625944
	v_mov_b32_e32 v68, v40                                      ; 7e880328
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[48:49], v[46:47], v[8:15] ; cc464008 1c225d30
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[50:51], v[46:47], v[16:23] ; cc464010 1c425d32
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v40, s[16:19], null offen offset:6656 ; c405c07c 40802028 001a0028
	buffer_load_b128 v[44:47], v68, s[16:19], null offen offset:7168 ; c405c07c 4080202c 001c0044
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[50:51], v[72:73], v[32:39] ; cc464020 1c829132
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[48:49], v[72:73], v[24:31] ; cc464018 1c629130
	s_clause 0x3                                                ; bf850003
	buffer_load_b64 v[48:49], v6, s[20:23], null offen offset:3584 ; c405407c 40802830 000e0006
	buffer_load_b64 v[50:51], v7, s[20:23], null offen offset:3584 ; c405407c 40802832 000e0007
	buffer_load_b64 v[70:71], v6, s[20:23], null offen offset:3840 ; c405407c 40802846 000f0006
	buffer_load_b64 v[6:7], v7, s[20:23], null offen offset:3840 ; c405407c 40802806 000f0007
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_dual_mov_b32 v73, v71 :: v_dual_mov_b32 v72, v70          ; ca100147 49480146
	buffer_load_b128 v[68:71], v68, s[16:19], null offen offset:7680 ; c405c07c 40802044 001e0044
	s_add_co_u32 s1, s1, 1                                      ; 80018101
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[52:53], v[74:75], v[8:15] ; cc464008 1c229534
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[54:55], v[74:75], v[16:23] ; cc464010 1c429536
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[54:55], v[76:77], v[32:39] ; cc464020 1c829936
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[52:53], v[76:77], v[24:31] ; cc464018 1c629934
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[56:57], v[78:79], v[8:15] ; cc464008 1c229d38
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[58:59], v[78:79], v[16:23] ; cc464010 1c429d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[58:59], v[80:81], v[32:39] ; cc464020 1c82a13a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[56:57], v[80:81], v[24:31] ; cc464018 1c62a138
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[60:61], v[82:83], v[8:15] ; cc464008 1c22a53c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[62:63], v[82:83], v[16:23] ; cc464010 1c42a53e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[62:63], v[84:85], v[32:39] ; cc464020 1c82a93e
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[60:61], v[84:85], v[24:31] ; cc464018 1c62a93c
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[64:65], v[86:87], v[8:15] ; cc464008 1c22ad40
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[66:67], v[86:87], v[16:23] ; cc464010 1c42ad42
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[66:67], v[88:89], v[32:39] ; cc464020 1c82b142
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[64:65], v[88:89], v[24:31] ; cc464018 1c62b140
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[40:41], v[90:91], v[8:15] ; cc464008 1c22b528
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[42:43], v[90:91], v[16:23] ; cc464010 1c42b52a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[42:43], v[92:93], v[32:39] ; cc464020 1c82b92a
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[40:41], v[92:93], v[24:31] ; cc464018 1c62b928
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[44:45], v[48:49], v[8:15] ; cc464008 1c22612c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[48:49], v[16:23] ; cc464010 1c42612e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[46:47], v[50:51], v[32:39] ; cc464020 1c82652e
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[44:45], v[50:51], v[24:31] ; cc464018 1c62652c
	s_wait_loadcnt 0x0                                          ; bfc00000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[68:69], v[6:7], v[24:31] ; cc464018 1c620d44
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[70:71], v[6:7], v[32:39] ; cc464020 1c820d46
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[68:69], v[72:73], v[8:15] ; cc464008 1c229144
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[70:71], v[72:73], v[16:23] ; cc464010 1c429146
BB54:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s1, s8                                         ; bf090801
	s_cbranch_scc0 BB56                                         ; bfa1feb6
BB57:
	s_cmp_lt_u32 s15, s6                                        ; bf0a060f
	s_cbranch_scc0 BB59                                         ; bfa10082
BB58:
	s_mov_b32 s8, s0                                            ; be880000
	s_movk_i32 s9, 0x8000                                       ; b0098000
	s_load_b256 s[16:23], s[8:9], 0x60                          ; f4006404 f8000060
	v_add3_u32 v2, v3, s5, v1                                   ; d6550002 04040b03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v2, 2, v2                                 ; 32040482
	v_lshlrev_b32_e32 v2, 3, v2                                 ; 30040483
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b128 v[4:7], v2, s[16:19], null offen           ; c405c07c 40802004 00000002
	s_mov_b32 s1, src_scc                                       ; be8100fd
	s_lshr_b32 s4, s7, 4                                        ; 85048407
	v_lshrrev_b32_e32 v40, 4, v1                                ; 32500284
	s_and_b32 s8, s2, -4                                        ; 8b08c402
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s4, s10, s4                                       ; 9604040a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v40, s4, v40, 8                              ; d6470028 02225004
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add3_u32 v41, v0, s8, v40                                 ; d6550029 04a01100
	v_add_nc_u32_e32 v41, v41, v3                               ; 4a520729
	s_wait_storecnt 0x0                                         ; bfc10000
	buffer_load_b64 v[42:43], v41, s[20:23], null offen         ; c405407c 4080282a 00000029
	s_and_b32 s9, s3, -4                                        ; 8b09c403
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v40, v0, s9, v40                                 ; d6550028 04a01300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_add_nc_u32_e32 v40, v40, v3                               ; 4a500728
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_pk_f32_fp8_e32 v[44:45], v42                          ; 7e58dd2a
	v_fma_mixlo_f16 v44, v4, v44, v8 op_sel_hi:[1,0,0]          ; cc21002c 0c225904
	v_fma_mixlo_f16 v47, v4, v45, v9 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc21082f 0c265b04
	v_cvt_pk_f32_fp8_e32 v[8:9], v170                           ; 7e10ddaa
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_maxmin_num_f16 v44, 0xdf00, v44, neg(0xdf00)              ; d66b002c 83fe58ff 0000df00
	v_maxmin_num_f16 v47, 0xdf00, v47, neg(0xdf00)              ; d66b002f 83fe5eff 0000df00
	v_fma_mixlo_f16 v52, v5, v9, v11 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc210834 0c2e1305
	v_fma_mixlo_f16 v50, v5, v8, v10 op_sel_hi:[1,0,0]          ; cc210032 0c2a1105
	v_cvt_pk_f32_fp8_e32 v[4:5], v43                            ; 7e08dd2b
	v_cvt_f32_f16_e32 v46, v44                                  ; 7e5c172c
	v_cvt_f32_f16_e32 v48, v47                                  ; 7e60172f
	v_maxmin_num_f16 v52, 0xdf00, v52, neg(0xdf00)              ; d66b0034 83fe68ff 0000df00
	v_maxmin_num_f16 v50, 0xdf00, v50, neg(0xdf00)              ; d66b0032 83fe64ff 0000df00
	v_fma_mixlo_f16 v55, v6, v4, v12 op_sel_hi:[1,0,0]          ; cc210037 0c320906
	v_fma_mixlo_f16 v57, v6, v5, v13 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc210839 0c360b06
	v_cvt_pk_f32_fp8_e32 v[4:5], v171                           ; 7e08ddab
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
	v_cvt_f32_f16_e32 v53, v52                                  ; 7e6a1734
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
	v_maxmin_num_f16 v55, 0xdf00, v55, neg(0xdf00)              ; d66b0037 83fe6eff 0000df00
	v_maxmin_num_f16 v57, 0xdf00, v57, neg(0xdf00)              ; d66b0039 83fe72ff 0000df00
	v_fma_mixlo_f16 v61, v7, v5, v15 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc21083d 0c3e0b07
	v_fma_mixlo_f16 v59, v7, v4, v14 op_sel_hi:[1,0,0]          ; cc21003b 0c3a0907
	v_perm_b32 v46, v46, v49, 0x7060004                         ; d644002e 03fe632e 07060004
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v0, v53, v128, vcc_lo                     ; 02010135
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
	v_cvt_f32_f16_e32 v56, v55                                  ; 7e701737
	v_cvt_f32_f16_e32 v58, v57                                  ; 7e741739
	v_maxmin_num_f16 v61, 0xdf00, v61, neg(0xdf00)              ; d66b003d 83fe7aff 0000df00
	v_maxmin_num_f16 v59, 0xdf00, v59, neg(0xdf00)              ; d66b003b 83fe76ff 0000df00
	v_perm_b32 v46, v46, v44, 0x7020504                         ; d644002e 03fe592e 07020504
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v0, v56, v128, vcc_lo                     ; 02010138
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v0, v58, v128, vcc_lo                     ; 0201013a
	v_cvt_f32_f16_e32 v62, v61                                  ; 7e7c173d
	v_cvt_f32_f16_e32 v60, v59                                  ; 7e78173b
	v_perm_b32 v46, v46, v54, 0x60504                           ; d644002e 03fe6d2e 00060504
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b4
	v_perm_b32 v47, v47, v50, 0x7060004                         ; d644002f 03fe652f 07060004
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v0, v62, v128, vcc_lo                     ; 0201013e
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v0, v60, v128, vcc_lo                     ; 0201013c
	v_perm_b32 v47, v47, v45, 0x7020504                         ; d644002f 03fe5b2f 07020504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_perm_b32 v47, v47, v55, 0x60504                           ; d644002f 03fe6f2f 00060504
	buffer_store_b64 v[46:47], v40, s[20:23], null offen        ; c406c07c 4080282e 00000028
	s_branch BB60                                               ; bfa00001
BB59:
	s_mov_b32 s1, src_scc                                       ; be8100fd
BB60:
	v_add_nc_u32_e32 v2, 16, v1                                 ; 4a040290
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s1, 0                                          ; bf018001
	s_cbranch_scc0 BB63                                         ; bfa10081
BB61:
	s_mov_b32 s8, s0                                            ; be880000
	s_movk_i32 s9, 0x8000                                       ; b0098000
	s_load_b256 s[16:23], s[8:9], 0x60                          ; f4006404 f8000060
	v_add3_u32 v4, v3, s5, v2                                   ; d6550004 04080b03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v4, 2, v4                                 ; 32080882
	v_lshlrev_b32_e32 v4, 3, v4                                 ; 30080883
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b128 v[4:7], v4, s[16:19], null offen           ; c405c07c 40802004 00000004
	s_lshr_b32 s1, s7, 4                                        ; 85018407
	v_lshrrev_b32_e32 v8, 4, v2                                 ; 32100484
	s_and_b32 s4, s2, -4                                        ; 8b04c402
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s1, s10, s1                                       ; 9601010a
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v8, s1, v8, 8                                ; d6470008 02221001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add3_u32 v9, v0, s4, v8                                   ; d6550009 04200900
	v_add_nc_u32_e32 v9, v9, v3                                 ; 4a120709
	s_wait_storecnt 0x0                                         ; bfc10000
	buffer_load_b64 v[10:11], v9, s[20:23], null offen          ; c405407c 4080280a 00000009
	s_and_b32 s8, s3, -4                                        ; 8b08c403
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v8, v0, s8, v8                                   ; d6550008 04201100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b1
	v_add_nc_u32_e32 v8, v8, v3                                 ; 4a100708
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_pk_f32_fp8_e32 v[12:13], v10                          ; 7e18dd0a
	v_fma_mixlo_f16 v12, v4, v12, v16 op_sel_hi:[1,0,0]         ; cc21000c 0c421904
	v_fma_mixlo_f16 v15, v4, v13, v17 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc21080f 0c461b04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_maxmin_num_f16 v12, 0xdf00, v12, neg(0xdf00)              ; d66b000c 83fe18ff 0000df00
	v_maxmin_num_f16 v15, 0xdf00, v15, neg(0xdf00)              ; d66b000f 83fe1eff 0000df00
	v_cvt_f32_f16_e32 v14, v12                                  ; 7e1c170c
	v_cvt_pk_f32_fp8_e32 v[12:13], v138                         ; 7e18dd8a
	v_cvt_f32_f16_e32 v16, v15                                  ; 7e20170f
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870253
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v0, v14, v128, vcc_lo                     ; 0201010e
	v_fma_mixlo_f16 v41, v5, v13, v19 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc210829 0c4e1b05
	v_fma_mixlo_f16 v18, v5, v12, v18 op_sel_hi:[1,0,0]         ; cc210012 0c4a1905
	v_cvt_pk_f32_fp8_e32 v[4:5], v11                            ; 7e08dd0b
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v0, v16, v128, vcc_lo                     ; 02010110
	v_maxmin_num_f16 v41, 0xdf00, v41, neg(0xdf00)              ; d66b0029 83fe52ff 0000df00
	v_maxmin_num_f16 v18, 0xdf00, v18, neg(0xdf00)              ; d66b0012 83fe24ff 0000df00
	v_fma_mixlo_f16 v44, v6, v4, v20 op_sel_hi:[1,0,0]          ; cc21002c 0c520906
	v_fma_mixlo_f16 v46, v6, v5, v21 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc21082e 0c560b06
	v_cvt_pk_f32_fp8_e32 v[4:5], v139                           ; 7e08dd8b
	v_cvt_f32_f16_e32 v42, v41                                  ; 7e541729
	v_cvt_f32_f16_e32 v40, v18                                  ; 7e501712
	v_maxmin_num_f16 v44, 0xdf00, v44, neg(0xdf00)              ; d66b002c 83fe58ff 0000df00
	v_maxmin_num_f16 v46, 0xdf00, v46, neg(0xdf00)              ; d66b002e 83fe5cff 0000df00
	v_perm_b32 v14, v14, v17, 0x7060004                         ; d644000e 03fe230e 07060004
	v_fma_mixlo_f16 v48, v7, v4, v22 op_sel_hi:[1,0,0]          ; cc210030 0c5a0907
	v_fma_mixlo_f16 v50, v7, v5, v23 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc210832 0c5e0b07
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v0, v42, v128, vcc_lo                     ; 0201012a
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v0, v40, v128, vcc_lo                     ; 02010128
	v_cvt_f32_f16_e32 v45, v44                                  ; 7e5a172c
	v_cvt_f32_f16_e32 v47, v46                                  ; 7e5e172e
	v_maxmin_num_f16 v48, 0xdf00, v48, neg(0xdf00)              ; d66b0030 83fe60ff 0000df00
	v_maxmin_num_f16 v50, 0xdf00, v50, neg(0xdf00)              ; d66b0032 83fe64ff 0000df00
	v_perm_b32 v14, v14, v40, 0x7020504                         ; d644000e 03fe510e 07020504
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v0, v45, v128, vcc_lo                     ; 0201012d
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v0, v47, v128, vcc_lo                     ; 0201012f
	v_cvt_f32_f16_e32 v49, v48                                  ; 7e621730
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
	v_perm_b32 v14, v14, v43, 0x60504                           ; d644000e 03fe570e 00060504
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870134
	v_perm_b32 v15, v15, v18, 0x7060004                         ; d644000f 03fe250f 07060004
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v0, v49, v128, vcc_lo                     ; 02010131
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
	v_perm_b32 v15, v15, v41, 0x7020504                         ; d644000f 03fe530f 07020504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_perm_b32 v15, v15, v44, 0x60504                           ; d644000f 03fe590f 00060504
	buffer_store_b64 v[14:15], v8, s[20:23], null offen         ; c406c07c 4080280e 00000008
BB63:
	s_cmp_lt_u32 s12, s6                                        ; bf0a060c
	s_cbranch_scc0 BB66                                         ; bfa100f3
BB64:
	s_mov_b32 s8, s0                                            ; be880000
	s_movk_i32 s9, 0x8000                                       ; b0098000
	s_load_b256 s[16:23], s[8:9], 0x60                          ; f4006404 f8000060
	v_lshrrev_b32_e32 v4, 4, v1                                 ; 32080284
	s_lshr_b32 s7, s7, 4                                        ; 85078407
	s_and_b32 s2, s2, -4                                        ; 8b02c402
	s_mul_i32 s13, s13, s7                                      ; 960d070d
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v4, s13, v4, 8                               ; d6470004 0222080d
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add3_u32 v5, v0, s2, v4                                   ; d6550005 04100500
	v_add_nc_u32_e32 v5, v5, v3                                 ; 4a0a0705
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b64 v[6:7], v5, s[20:23], null offen            ; c405407c 40802806 00000005
	v_add3_u32 v1, v3, s5, v1                                   ; d6550001 04040b03
	v_lshrrev_b32_e32 v8, 4, v2                                 ; 32100484
	v_add3_u32 v2, v3, s5, v2                                   ; d6550002 04080b03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_lshrrev_b32_e32 v1, 2, v1                                 ; 32020282
	v_lshrrev_b32_e32 v2, 2, v2                                 ; 32040482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	v_lshlrev_b32_e32 v2, 3, v2                                 ; 30040483
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[12:15], v1, s[16:19], null offen         ; c405c07c 4080200c 00000001
	buffer_load_b128 v[16:19], v2, s[16:19], null offen         ; c405c07c 40802010 00000002
	s_and_b32 s3, s3, -4                                        ; 8b03c403
	v_add_lshl_u32 v8, s13, v8, 8                               ; d6470008 0222100d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v4, v0, s3, v4                                   ; d6550004 04100700
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_add3_u32 v9, v0, s2, v8                                   ; d6550009 04200500
	v_add3_u32 v0, v0, s3, v8                                   ; d6550000 04200700
	v_add_nc_u32_e32 v4, v4, v3                                 ; 4a080704
	v_add_nc_u32_e32 v9, v9, v3                                 ; 4a120709
	v_add_nc_u32_e32 v0, v0, v3                                 ; 4a000700
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_cvt_pk_f32_fp8_e32 v[2:3], v6                             ; 7e04dd06
	s_wait_loadcnt 0x1                                          ; bfc00001
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_fma_mixlo_f16 v10, v12, v2, v24 op_sel_hi:[1,0,0]         ; cc21000a 0c62050c
	v_fma_mixlo_f16 v12, v12, v3, v25 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc21080c 0c66070c
	v_cvt_pk_f32_fp8_e32 v[2:3], v134                           ; 7e04dd86
	v_maxmin_num_f16 v10, 0xdf00, v10, neg(0xdf00)              ; d66b000a 83fe14ff 0000df00
	v_maxmin_num_f16 v12, 0xdf00, v12, neg(0xdf00)              ; d66b000c 83fe18ff 0000df00
	v_fma_mixlo_f16 v22, v13, v2, v26 op_sel_hi:[1,0,0]         ; cc210016 0c6a050d
	v_fma_mixlo_f16 v24, v13, v3, v27 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc210818 0c6e070d
	v_cvt_pk_f32_fp8_e32 v[2:3], v7                             ; 7e04dd07
	v_cvt_f32_f16_e32 v11, v10                                  ; 7e16170a
	v_cvt_f32_f16_e32 v20, v12                                  ; 7e28170c
	v_maxmin_num_f16 v22, 0xdf00, v22, neg(0xdf00)              ; d66b0016 83fe2cff 0000df00
	v_maxmin_num_f16 v24, 0xdf00, v24, neg(0xdf00)              ; d66b0018 83fe30ff 0000df00
	v_fma_mixlo_f16 v27, v14, v2, v28 op_sel_hi:[1,0,0]         ; cc21001b 0c72050e
	v_fma_mixlo_f16 v29, v14, v3, v29 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc21081d 0c76070e
	v_cvt_pk_f32_fp8_e32 v[2:3], v135                           ; 7e04dd87
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v0, v11, v128, vcc_lo                     ; 0201010b
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v0, v20, v128, vcc_lo                     ; 02010114
	v_cvt_f32_f16_e32 v23, v22                                  ; 7e2e1716
	v_cvt_f32_f16_e32 v25, v24                                  ; 7e321718
	v_maxmin_num_f16 v27, 0xdf00, v27, neg(0xdf00)              ; d66b001b 83fe36ff 0000df00
	v_maxmin_num_f16 v29, 0xdf00, v29, neg(0xdf00)              ; d66b001d 83fe3aff 0000df00
	v_fma_mixlo_f16 v41, v15, v2, v30 op_sel_hi:[1,0,0]         ; cc210029 0c7a050f
	v_fma_mixlo_f16 v43, v15, v3, v31 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc21082b 0c7e070f
	v_perm_b32 v10, v10, v21, 0x7060004                         ; d644000a 03fe2b0a 07060004
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v0, v23, v128, vcc_lo                     ; 02010117
(invalid instruction)                                        ; d769001a
	v_cndmask_b32_e32 v0, v25, v128, vcc_lo                     ; 02010119
	v_cvt_f32_f16_e32 v28, v27                                  ; 7e38171b
	v_cvt_f32_f16_e32 v40, v29                                  ; 7e50171d
	v_maxmin_num_f16 v41, 0xdf00, v41, neg(0xdf00)              ; d66b0029 83fe52ff 0000df00
	v_maxmin_num_f16 v43, 0xdf00, v43, neg(0xdf00)              ; d66b002b 83fe56ff 0000df00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v28, v128, vcc_lo                     ; 0201011c
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v0, v40, v128, vcc_lo                     ; 02010128
	v_cvt_f32_f16_e32 v42, v41                                  ; 7e541729
	v_cvt_f32_f16_e32 v44, v43                                  ; 7e58172b
	v_perm_b32 v10, v10, v22, 0x7020504                         ; d644000a 03fe2d0a 07020504
	v_perm_b32 v11, v11, v22, 0x7060004                         ; d644000b 03fe2d0b 07060004
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v0, v42, v128, vcc_lo                     ; 0201012a
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v0, v44, v128, vcc_lo                     ; 0201012c
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_perm_b32 v10, v10, v26, 0x60504                           ; d644000a 03fe350a 00060504
	v_perm_b32 v11, v11, v23, 0x7020504                         ; d644000b 03fe2f0b 07020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
	v_perm_b32 v11, v11, v27, 0x60504                           ; d644000b 03fe370b 00060504
	buffer_store_b64 v[10:11], v4, s[20:23], null offen         ; c406c07c 4080280a 00000004
	buffer_load_b64 v[2:3], v9, s[20:23], null offen            ; c405407c 40802802 00000009
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_cvt_pk_f32_fp8_e32 v[4:5], v2                             ; 7e08dd02
	v_fma_mixlo_f16 v45, v16, v4, v32 op_sel_hi:[1,0,0]         ; cc21002d 0c820910
	v_fma_mixlo_f16 v47, v16, v5, v33 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc21082f 0c860b10
	v_cvt_pk_f32_fp8_e32 v[4:5], v130                           ; 7e08dd82
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_maxmin_num_f16 v45, 0xdf00, v45, neg(0xdf00)              ; d66b002d 83fe5aff 0000df00
	v_maxmin_num_f16 v47, 0xdf00, v47, neg(0xdf00)              ; d66b002f 83fe5eff 0000df00
	v_fma_mixlo_f16 v50, v17, v4, v34 op_sel_hi:[1,0,0]         ; cc210032 0c8a0911
	v_fma_mixlo_f16 v52, v17, v5, v35 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc210834 0c8e0b11
	v_cvt_pk_f32_fp8_e32 v[4:5], v3                             ; 7e08dd03
	v_cvt_f32_f16_e32 v46, v45                                  ; 7e5c172d
	v_cvt_f32_f16_e32 v48, v47                                  ; 7e60172f
	v_maxmin_num_f16 v50, 0xdf00, v50, neg(0xdf00)              ; d66b0032 83fe64ff 0000df00
	v_maxmin_num_f16 v52, 0xdf00, v52, neg(0xdf00)              ; d66b0034 83fe68ff 0000df00
	v_cvt_pk_f32_fp8_e32 v[2:3], v131                           ; 7e04dd83
	v_fma_mixlo_f16 v55, v18, v4, v36 op_sel_hi:[1,0,0]         ; cc210037 0c920912
	v_fma_mixlo_f16 v57, v18, v5, v37 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc210839 0c960b12
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
	v_cvt_f32_f16_e32 v51, v50                                  ; 7e661732
	v_cvt_f32_f16_e32 v53, v52                                  ; 7e6a1734
	v_fma_mixlo_f16 v59, v19, v2, v38 op_sel_hi:[1,0,0]         ; cc21003b 0c9a0513
	v_fma_mixlo_f16 v61, v19, v3, v39 op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc21083d 0c9e0713
	v_maxmin_num_f16 v55, 0xdf00, v55, neg(0xdf00)              ; d66b0037 83fe6eff 0000df00
	v_maxmin_num_f16 v57, 0xdf00, v57, neg(0xdf00)              ; d66b0039 83fe72ff 0000df00
	v_perm_b32 v6, v6, v49, 0x7060004                           ; d6440006 03fe6306 07060004
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v0, v53, v128, vcc_lo                     ; 02010135
	v_maxmin_num_f16 v59, 0xdf00, v59, neg(0xdf00)              ; d66b003b 83fe76ff 0000df00
	v_maxmin_num_f16 v61, 0xdf00, v61, neg(0xdf00)              ; d66b003d 83fe7aff 0000df00
	v_cvt_f32_f16_e32 v56, v55                                  ; 7e701737
	v_cvt_f32_f16_e32 v58, v57                                  ; 7e741739
	v_perm_b32 v6, v6, v8, 0x7020504                            ; d6440006 03fe1106 07020504
	v_cvt_f32_f16_e32 v60, v59                                  ; 7e78173b
	v_cvt_f32_f16_e32 v62, v61                                  ; 7e7c173d
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v0, v56, v128, vcc_lo                     ; 02010138
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v0, v58, v128, vcc_lo                     ; 0201013a
	v_perm_b32 v6, v6, v54, 0x60504                             ; d6440006 03fe6d06 00060504
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v0, v60, v128, vcc_lo                     ; 0201013c
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v0, v62, v128, vcc_lo                     ; 0201013e
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870094
	v_perm_b32 v7, v7, v50, 0x7060004                           ; d6440007 03fe6507 07060004
	v_perm_b32 v7, v7, v9, 0x7020504                            ; d6440007 03fe1307 07020504
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_perm_b32 v7, v7, v55, 0x60504                             ; d6440007 03fe6f07 00060504
	buffer_store_b64 v[6:7], v0, s[20:23], null offen           ; c406c07c 40802806 00000000
BB66:
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s14, -1                                        ; bf01c10e
	s_cbranch_scc0 BB75                                         ; bfa1000f
BB67:
	s_mov_b32 exec_lo, 3                                        ; befe0083
BB68:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[0:3], s[0:1], 0x0                             ; f4004000 f8000000
	s_add_co_u32 s14, s14, s10                                  ; 800e0a0e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
(invalid instruction)                                        ; d71f0000
	v_cndmask_b32_e32 v0, -1, v14, vcc_lo                       ; 02001cc1
	v_dual_mov_b32 v1, 1 :: v_dual_lshlrev_b32 v0, 2, v0        ; ca220081 01000082
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_atomic_add_u32 v1, v0, s[0:3], null offen            ; c40d407c 40800001 00000000
BB75:
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
