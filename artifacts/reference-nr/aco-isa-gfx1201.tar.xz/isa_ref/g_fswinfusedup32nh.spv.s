BB0:
	s_mov_b32 s10, s1                                           ; be8a0001
	s_movk_i32 s11, 0x8000                                      ; b00b8000
	s_load_b32 s1, s[10:11], 0x7c                               ; f4000045 f800007c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s1, -1                                         ; bf01c101
	s_cbranch_scc0 BB2                                          ; bfa1000f
BB1:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[12:15], s[12:13], 0x40                        ; f4004306 f8000040
	s_lshl2_add_u32 s16, s1, 24                                 ; 87909801
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s13, 14                                       ; be8d108e
	s_buffer_load_b32 s16, s[12:15], s16 offset:0x0             ; f4020406 20000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s16, 0x54434852                                ; bf01ff10 54434852
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s12, vcc_lo, exec_lo                              ; 8b0c7e6a
	s_cselect_b32 s1, -1, s1                                    ; 980101c1
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s1, -1                                         ; bf01c101
	s_cbranch_scc0 BB5                                          ; bfa1000f
BB4:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[12:15], s[12:13], 0x40                        ; f4004306 f8000040
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_lshl2_add_u32 s17, s1, 4                                  ; 87918401
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s13, 14                                       ; be8d108e
	s_buffer_load_b32 s17, s[12:15], s17 offset:0x0             ; f4020446 22000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s17, 0                                         ; bf018011
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s18, -1, 0                                    ; 981280c1
	s_branch BB6                                                ; bfa00002
BB5:
	s_mov_b32 s16, src_scc                                      ; be9000fd
	s_mov_b32 s18, 0                                            ; be920080
BB6:
	s_cmp_eq_i32 ttmp9, 0                                       ; bf008075
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s12, -1, 0                                    ; 980c80c1
	s_and_b32 s18, s18, s12                                     ; 8b120c12
	s_cmp_eq_i32 ttmp7, 0                                       ; bf008073
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s13, -1, 0                                    ; 980d80c1
	s_and_b32 s18, s18, s13                                     ; 8b120d12
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 exec_lo, s18, 1                                   ; 8b7e8112
	s_cbranch_execz BB12                                        ; bfa50012
BB7:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[12:13], 0x40                        ; f4004506 f8000040
	s_load_b128 s[24:27], s[12:13], 0x0                         ; f4004606 f8000000
	s_lshl2_add_u32 s14, s1, 16                                 ; 878e9001
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_buffer_load_b32 s14, s[20:23], s14 offset:0x0             ; f402038a 1c000000
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s14, s14, 2                                      ; 840e820e
	buffer_atomic_add_u32 v1, off, s[24:27], s14                ; c40d400e 00803001 00000000
BB12:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
	s_cmp_lg_i32 s16, 0                                         ; bf018010
	s_cbranch_scc0 BB14                                         ; bfa1000e
BB13:
	s_mov_b32 s12, s0                                           ; be8c0000
	s_movk_i32 s13, 0x8000                                      ; b00d8000
	s_load_b128 s[12:15], s[12:13], 0x40                        ; f4004306 f8000040
	s_lshl2_add_u32 s16, s1, 8                                  ; 87908801
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s13, 14                                       ; be8d108e
	s_buffer_load_b32 s16, s[12:15], s16 offset:0x0             ; f4020406 20000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s16, -1                                        ; bf01c110
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB15                                               ; bfa00001
BB14:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB15:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s12, vcc_lo, exec_lo                              ; 8b0c7e6a
	s_cbranch_scc0 BB47                                         ; bfa10083
BB16:
	s_mov_b32 s14, s0                                           ; be8e0000
	s_movk_i32 s15, 0x8000                                      ; b00f8000
	s_clause 0x2                                                ; bf850002
	s_load_b64 s[12:13], s[10:11], 0x3c                         ; f4002305 f800003c
	s_load_b64 s[16:17], s[10:11], 0x68                         ; f4002405 f8000068
	s_load_b128 s[20:23], s[14:15], 0x40                        ; f4004507 f8000040
	s_lshl_b32 s1, s1, 2                                        ; 84018201
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s19, s1, 8                                     ; 80138801
	s_add_co_u32 s24, s1, 16                                    ; 80189001
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s21, 14                                       ; be95108e
	s_clause 0x2                                                ; bf850002
	s_buffer_load_b32 s18, s[20:23], s1 offset:0x0              ; f402048a 02000000
	s_buffer_load_b32 s19, s[20:23], s19 offset:0x0             ; f40204ca 26000000
	s_buffer_load_b32 s24, s[20:23], s24 offset:0x0             ; f402060a 30000000
	s_load_b128 s[28:31], s[14:15], 0x0                         ; f4004707 f8000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s24, s24, 2                                      ; 84188218
	buffer_load_b32 v1, off, s[28:31], s24 scope:SCOPE_DEV      ; c4050018 00883801 00000000
	s_bfm_b64 s[14:15], 1, 16                                   ; 958e9081
	s_lshl_b32 s12, s12, 1                                      ; 840c810c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_lshl2_add_u32 s12, ttmp9, s12                             ; 878c0c75
	s_lshl_b32 s13, s13, 1                                      ; 840d810d
	s_lshl2_add_u32 s13, ttmp7, s13                             ; 878d0d73
	s_lshl2_add_u32 s26, s16, -1                                ; 879ac110
	s_lshl2_add_u32 s17, s17, -1                                ; 8791c111
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s25, v1                                 ; 7e320501
BB17:
	s_and_b32 s24, s15, 1                                       ; 8b18810f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s24, 3, s24                                       ; 96181883
	s_add_co_u32 s24, s12, s24                                  ; 8018180c
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_max_i32 s24, s24, 0                                       ; 8a188018
	s_min_i32 s24, s24, s26                                     ; 89181a18
	s_lshr_b32 s27, s15, 1                                      ; 851b810f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s27, 3, s27                                       ; 961b1b83
	s_add_co_u32 s27, s13, s27                                  ; 801b1b0d
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_max_i32 s27, s27, 0                                       ; 8a1b801b
	s_min_i32 s27, s27, s17                                     ; 891b111b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_abs_i32 s32, s27                                          ; bea0151b
	s_lshr_b32 s32, s32, 2                                      ; 85208220
	s_max_i32 s27, s27, -1                                      ; 8a1bc11b
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s27, s27, 1                                       ; 891b811b
	s_abs_i32 s33, s24                                          ; bea11518
	s_mul_i32 s27, s27, s32                                     ; 961b201b
	s_lshr_b32 s33, s33, 2                                      ; 85218221
	s_max_i32 s24, s24, -1                                      ; 8a18c118
	s_mul_i32 s27, s27, s16                                     ; 961b101b
	s_min_i32 s24, s24, 1                                       ; 89188118
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_mul_i32 s24, s24, s33                                     ; 96182118
	s_add_co_u32 s27, s27, s24                                  ; 801b181b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s27, s19, s27                                  ; 801b1b13
	s_lshl_b32 s27, s27, 2                                      ; 841b821b
	s_buffer_load_b32 s27, s[20:23], s27 offset:0x0             ; f40206ca 36000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s27, -1                                        ; bf01c11b
	s_cbranch_scc0 BB27                                         ; bfa1001c
BB18:
	s_branch BB19                                               ; bfa00004
	s_nop 0                                                     ; bf800000
	(then repeated 2 times)
BB24:
	s_add_co_u32 s14, s14, -1                                   ; 800ec10e
BB19:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s14, 0                                         ; bf01800e
	s_cbranch_scc0 BB21                                         ; bfa10010
BB20:
	s_and_b32 s24, s27, 0xfffff                                 ; 8b18ff1b 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s24, s18, s24                                  ; 80181812
	s_lshl_b32 s24, s24, 2                                      ; 84188218
	buffer_load_b32 v1, off, s[28:31], s24 scope:SCOPE_DEV      ; c4050018 00883801 00000000
	s_lshr_b32 s32, s27, 20                                     ; 8520941b
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s32, s32, s25                                     ; 96201920
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s33, v1                                 ; 7e420501
	s_cmp_lt_u32 s33, s32                                       ; bf0a2021
	s_cselect_b32 s34, -1, 0                                    ; 982280c1
	s_branch BB22                                               ; bfa00001
BB21:
	s_mov_b32 s34, 0                                            ; bea20080
BB22:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s34, exec_lo, s34                            ; 9122227e
	s_cbranch_scc0 BB24                                         ; bfa1ffe8
BB27:
	s_add_co_u32 s15, s15, 1                                    ; 800f810f
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_ge_u32 s15, 4                                         ; bf09840f
	s_cbranch_scc0 BB17                                         ; bfa1ffbb
BB30:
	s_cmp_eq_i32 s14, 0                                         ; bf00800e
	s_cbranch_scc0 BB32                                         ; bfa10002
BB31:
	s_mov_b32 s12, 1                                            ; be8c0081
	s_branch BB33                                               ; bfa00001
BB32:
	s_mov_b32 s12, 0                                            ; be8c0080
BB33:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mov_b32 exec_lo, s12                                      ; befe000c
	s_cbranch_execz BB45                                        ; bfa5000e
BB34:
	s_ctz_i32_b32 s12, exec_lo                                  ; be8c087e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s12, 1, s12                                      ; 840c0c81
	s_and_saveexec_b32 s12, s12                                 ; be8c200c
	s_cbranch_execz BB45                                        ; bfa50009
BB35:
	s_add_co_u32 s1, s1, 20                                     ; 80019401
	s_buffer_load_b32 s1, s[20:23], s1 offset:0x0               ; f402004a 02000000
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s1, s1, 2                                        ; 84018201
	buffer_atomic_max_u32 v1, off, s[28:31], s1                 ; c40ec001 00803801 00000000
BB45:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
BB47:
	s_clause 0x3                                                ; bf850003
	s_load_b128 s[12:15], s[10:11], 0x34                        ; f4004305 f8000034
	s_load_b128 s[16:19], s[10:11], 0x68                        ; f4004405 f8000068
	s_load_b32 s1, s[10:11], 0x50                               ; f4000045 f8000050
	s_load_b32 s20, s[10:11], 0x78                              ; f4000505 f8000078
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mov_b32 s21, s1                                           ; be950001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[24:27], s[0:1], 0x0                           ; f4004600 f8000000
	s_load_b128 s[28:31], s[0:1], 0x20                          ; f4004700 f8000020
	v_and_b32_e32 v1, 3, v0                                     ; 36020083
	v_and_b32_e32 v2, 15, v0                                    ; 3604008f
	v_lshrrev_b32_e32 v4, 4, v0                                 ; 32080084
	s_lshl_b32 s22, s14, 1                                      ; 8416810e
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_lshl2_add_u32 s22, ttmp9, s22                             ; 87961675
	s_lshl_b32 s23, s15, 1                                      ; 8417810f
	v_lshrrev_b32_e32 v3, 2, v2                                 ; 32060482
	v_lshlrev_b32_e32 v4, 3, v4                                 ; 30080883
	v_add_nc_u32_e32 v5, s22, v1                                ; 4a0a0216
	s_lshl2_add_u32 s23, ttmp7, s23                             ; 87971773
	s_lshl2_add_u32 s32, s16, -1                                ; 87a0c110
	s_lshl2_add_u32 s17, s17, -1                                ; 8791c111
	s_and_b32 s33, s21, -4                                      ; 8b21c415
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_nc_u32_e32 v3, s23, v3                                ; 4a060617
	v_maxmin_i32 v5, 0, v5, s32                                 ; d6640005 00820a80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_maxmin_i32 v3, 0, v3, s17                                 ; d6640003 00460680
	v_lshrrev_b32_e32 v7, 2, v5                                 ; 320e0a82
	v_and_b32_e32 v5, 3, v5                                     ; 360a0a83
	v_lshrrev_b32_e32 v6, 2, v3                                 ; 320c0682
	v_and_b32_e32 v3, 3, v3                                     ; 36060683
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v0, v6, v16, vcc_lo                       ; 02002106
	v_lshl_add_u32 v3, v3, 2, v5                                ; d6460003 04150503
	v_lshlrev_b32_e32 v3, 4, v3                                 ; 30060684
	v_add_lshl_u32 v6, v6, v7, 10                               ; d6470006 022a0f06
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v9, 0x100, v6                              ; 4a120cff 00000100
	v_add_nc_u32_e32 v11, 0x200, v6                             ; 4a160cff 00000200
	v_add3_u32 v13, v3, s21, v6                                 ; d655000d 04182b03
	v_add3_u32 v8, v3, s33, v6                                  ; d6550008 04184303
	v_add_nc_u32_e32 v6, 0x300, v6                              ; 4a0c0cff 00000300
	v_add3_u32 v10, v3, s21, v9                                 ; d655000a 04242b03
	v_add3_u32 v9, v3, s33, v9                                  ; d6550009 04244303
	v_add3_u32 v12, v3, s21, v11                                ; d655000c 042c2b03
	v_add3_u32 v11, v3, s33, v11                                ; d655000b 042c4303
	v_add_nc_u32_e32 v8, v8, v4                                 ; 4a100908
	v_add3_u32 v14, v3, s21, v6                                 ; d655000e 04182b03
	v_add3_u32 v3, v3, s33, v6                                  ; d6550003 04184303
	v_add_nc_u32_e32 v9, v9, v4                                 ; 4a120909
	v_add_nc_u32_e32 v11, v11, v4                               ; 4a16090b
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_add_nc_u32_e32 v3, v3, v4                                 ; 4a060903
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x3                                                ; bf850003
	buffer_load_b96 v[15:17], v8, s[24:27], null offen          ; c405807c 4080300f 00000008
	buffer_load_b96 v[18:20], v9, s[24:27], null offen          ; c405807c 40803012 00000009
	buffer_load_b96 v[21:23], v11, s[24:27], null offen         ; c405807c 40803015 0000000b
	buffer_load_b96 v[24:26], v3, s[24:27], null offen          ; c405807c 40803018 00000003
(invalid instruction)                                        ; d71f001b
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_and_b32_e32 v28, 15, v27                                  ; 3638368f
	v_lshrrev_b32_e32 v27, 4, v27                               ; 32363684
	v_lshlrev_b32_e32 v29, 4, v28                               ; 303a3884
	v_lshlrev_b32_e32 v27, 3, v27                               ; 30363683
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add3_u32 v31, v29, s20, 0x100                             ; d655001f 03fc291d 00000100
	v_add3_u32 v37, v29, s20, 0x700                             ; d6550025 03fc291d 00000700
	v_add3_u32 v36, v29, s20, 0x600                             ; d6550024 03fc291d 00000600
	v_add3_u32 v34, v29, s20, 0x400                             ; d6550022 03fc291d 00000400
	v_add3_u32 v32, v29, s20, 0x200                             ; d6550020 03fc291d 00000200
	v_add3_u32 v35, v29, s20, 0x500                             ; d6550023 03fc291d 00000500
	v_add3_u32 v33, v29, s20, 0x300                             ; d6550021 03fc291d 00000300
	v_add3_u32 v30, v27, s20, v29                               ; d655001e 0474291b
	v_add_nc_u32_e32 v31, v31, v27                              ; 4a3e371f
	v_add_nc_u32_e32 v37, v37, v27                              ; 4a4a3725
	v_add_nc_u32_e32 v36, v36, v27                              ; 4a483724
	v_add_nc_u32_e32 v34, v34, v27                              ; 4a443722
	v_add_nc_u32_e32 v32, v32, v27                              ; 4a403720
	v_add_nc_u32_e32 v35, v35, v27                              ; 4a463723
	v_add_nc_u32_e32 v33, v33, v27                              ; 4a423721
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[6:7], v30, s[28:31], null offen           ; c405407c 40803806 0000001e
	buffer_load_b64 v[8:9], v31, s[28:31], null offen           ; c405407c 40803808 0000001f
	buffer_load_b64 v[30:31], v32, s[28:31], null offen         ; c405407c 4080381e 00000020
	buffer_load_b64 v[32:33], v33, s[28:31], null offen         ; c405407c 40803820 00000021
	buffer_load_b64 v[38:39], v34, s[28:31], null offen         ; c405407c 40803826 00000022
	buffer_load_b64 v[34:35], v35, s[28:31], null offen         ; c405407c 40803822 00000023
	buffer_load_b64 v[40:41], v36, s[28:31], null offen         ; c405407c 40803828 00000024
	buffer_load_b64 v[36:37], v37, s[28:31], null offen         ; c405407c 40803824 00000025
	v_add_nc_u32_e32 v13, v13, v4                               ; 4a1a090d
	v_add_nc_u32_e32 v10, v10, v4                               ; 4a14090a
	v_add_nc_u32_e32 v12, v12, v4                               ; 4a18090c
	v_add_nc_u32_e32 v14, v14, v4                               ; 4a1c090e
	v_add_lshl_u32 v42, v29, v27, 1                             ; d647002a 0206371d
	s_lshl1_add_u32 s14, ttmp9, s14                             ; 870e0e75
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_max_i32 s34, s14, 0                                       ; 8a22800e
	s_add_co_u32 s35, s12, -1                                   ; 8023c10c
	s_min_i32 s34, s34, s35                                     ; 89222322
	s_lshl_b32 s36, ttmp7, 1                                    ; 84248173
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s15, s36, s15                                  ; 800f0f24
	s_max_i32 s37, s15, 0                                       ; 8a25800f
	s_add_co_u32 s13, s13, -1                                   ; 800dc10d
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_min_i32 s37, s37, s13                                     ; 89250d25
	s_cmp_eq_i32 s19, 0                                         ; bf008013
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_alignbyte_b32 v45, v17, v16, v13                          ; d617002d 04362111
	v_alignbyte_b32 v44, v16, v15, v13                          ; d617002c 04361f10
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_alignbyte_b32 v17, v20, v19, v10                          ; d6170011 042a2714
	v_alignbyte_b32 v16, v19, v18, v10                          ; d6170010 042a2513
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_alignbyte_b32 v10, v22, v21, v12                          ; d617000a 04322b16
	v_alignbyte_b32 v11, v23, v22, v12                          ; d617000b 04322d17
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_alignbyte_b32 v12, v25, v24, v14                          ; d617000c 043a3119
	v_alignbyte_b32 v13, v26, v25, v14                          ; d617000d 043a331a
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[6:7], v[44:45], 0   ; cc464030 1a025906
	s_wait_loadcnt 0x6                                          ; bfc00006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[8:9], v[16:17], v[48:55] ; cc464030 1cc22108
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[30:31], v[10:11], v[48:55] ; cc464030 1cc2151e
	s_wait_loadcnt 0x4                                          ; bfc00004
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[32:33], v[12:13], v[48:55] ; cc464030 1cc21920
	v_cvt_f16_f32_e32 v20, v48                                  ; 7e281530
	v_cvt_f16_f32_e32 v22, v52                                  ; 7e2c1534
(invalid instruction)                                        ; 7f281531
	v_cvt_f16_f32_e32 v23, v54                                  ; 7e2e1536
	v_cvt_f16_f32_e32 v21, v50                                  ; 7e2a1532
(invalid instruction)                                        ; 7f2a1533
(invalid instruction)                                        ; 7f2e1537
(invalid instruction)                                        ; 7f2c1535
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[38:39], v[44:45], 0 ; cc464030 1a025926
	s_wait_loadcnt 0x2                                          ; bfc00002
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[34:35], v[16:17], v[48:55] ; cc464030 1cc22122
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[40:41], v[10:11], v[48:55] ; cc464030 1cc21528
	s_wait_loadcnt 0x0                                          ; bfc00000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[36:37], v[12:13], v[48:55] ; cc464030 1cc21924
	v_cvt_f16_f32_e32 v9, v50                                   ; 7e121532
(invalid instruction)                                        ; 7f121533
	v_cvt_f16_f32_e32 v10, v52                                  ; 7e141534
(invalid instruction)                                        ; 7f141535
	v_cvt_f16_f32_e32 v8, v48                                   ; 7e101530
(invalid instruction)                                        ; 7f101531
	v_cvt_f16_f32_e32 v11, v54                                  ; 7e161536
(invalid instruction)                                        ; 7f161537
	ds_store_b128 v42, v[20:23]                                 ; db7c0000 0000142a
	ds_store_b128 v42, v[8:11] offset:512                       ; db7c0200 0000082a
	s_cbranch_scc0 BB49                                         ; bfa10003
BB48:
	s_load_b32 s16, s[10:11], 0x60                              ; f4000405 f8000060
	s_branch BB50                                               ; bfa00001
BB49:
	s_mov_b32 s16, s19                                          ; be900013
BB50:
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[20:23], s[10:11], 0x54                        ; f4004505 f8000054
	s_load_b128 s[28:31], s[0:1], 0x40                          ; f4004700 f8000040
	v_lshlrev_b32_e32 v3, 4, v2                                 ; 30060484
	s_mov_b32 s18, src_scc                                      ; be9200fd
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_mul_i32 s16, s37, s16                                     ; 96101025
	s_movk_i32 s21, 0x100                                       ; b0150100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s16, s16, s34                                  ; 80102210
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s16, s16, 9                                      ; 84108910
	s_and_b32 s20, s20, -4                                      ; 8b14c414
	s_cmp_lg_i32 s18, 0                                         ; bf018012
	v_add_lshl_u32 v6, s22, v4, 1                               ; d6470006 02060816
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v5, v3, s20, s16                                 ; d6550005 00402903
	s_cselect_b32 s23, s23, s19                                 ; 98171317
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s37, s37, s23                                     ; 96251725
	v_and_b32_e32 v7, -4, v6                                    ; 360e0cc4
	v_add_nc_u32_e32 v5, v5, v4                                 ; 4a0a0905
	s_add_co_u32 s19, s37, s34                                  ; 80132225
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s19, s19, 9                                      ; 84138913
	s_add_co_u32 s19, s19, s21                                  ; 80131513
	s_add_co_u32 s14, s14, 1                                    ; 800e810e
	v_add3_u32 v8, v3, s20, s19                                 ; d6550008 004c2903
	s_max_i32 s14, s14, 0                                       ; 8a0e800e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870099
	s_min_i32 s14, s14, s35                                     ; 890e230e
	v_add_nc_u32_e32 v8, v8, v4                                 ; 4a100908
	s_add_co_u32 s37, s37, s14                                  ; 80250e25
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s37, s37, 9                                      ; 84258925
	v_add3_u32 v9, v3, s20, s37                                 ; d6550009 00942903
	s_add_co_u32 s37, s37, s21                                  ; 80251525
	s_add_co_u32 s15, s15, 1                                    ; 800f810f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v10, v3, s20, s37                                ; d655000a 00942903
	s_max_i32 s15, s15, 0                                       ; 8a0f800f
	v_add_nc_u32_e32 v9, v9, v4                                 ; 4a120909
	s_min_i32 s15, s15, s13                                     ; 890f0d0f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a2
	v_add_nc_u32_e32 v10, v10, v4                               ; 4a14090a
	s_mul_i32 s15, s15, s23                                     ; 960f170f
	s_add_co_u32 s34, s15, s34                                  ; 8022220f
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s34, s34, 9                                      ; 84228922
	v_add3_u32 v11, v3, s20, s34                                ; d655000b 00882903
	s_add_co_u32 s34, s34, s21                                  ; 80221522
	s_add_co_u32 s15, s15, s14                                  ; 800f0e0f
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v12, v3, s20, s34                                ; d655000c 00882903
	s_lshl_b32 s15, s15, 9                                      ; 840f890f
	v_add_nc_u32_e32 v11, v11, v4                               ; 4a16090b
	v_add3_u32 v13, v3, s20, s15                                ; d655000d 003c2903
	s_add_co_u32 s15, s15, s21                                  ; 800f150f
	v_add_nc_u32_e32 v12, v12, v4                               ; 4a18090c
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v3, v3, s20, s15                                 ; d6550003 003c2903
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_add_nc_u32_e32 v13, v13, v4                               ; 4a1a090d
	v_add_nc_u32_e32 v3, v3, v4                                 ; 4a060903
	s_clause 0x7                                                ; bf850007
	buffer_load_b64 v[14:15], v5, s[24:27], null offen          ; c405407c 4080300e 00000005
	buffer_load_b64 v[16:17], v8, s[24:27], null offen          ; c405407c 40803010 00000008
	buffer_load_b64 v[8:9], v9, s[24:27], null offen            ; c405407c 40803008 00000009
	buffer_load_b64 v[18:19], v10, s[24:27], null offen         ; c405407c 40803012 0000000a
	buffer_load_b64 v[10:11], v11, s[24:27], null offen         ; c405407c 4080300a 0000000b
	buffer_load_b64 v[20:21], v12, s[24:27], null offen         ; c405407c 40803014 0000000c
	buffer_load_b64 v[12:13], v13, s[24:27], null offen         ; c405407c 4080300c 0000000d
	buffer_load_b64 v[22:23], v3, s[24:27], null offen          ; c405407c 40803016 00000003
	v_lshlrev_b32_e32 v0, 2, v0                                 ; 30000082
	s_lshr_b32 s3, s3, 2                                        ; 85038203
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)     ; bf870481
	v_add_lshl_u32 v24, s3, v0, 2                               ; d6470018 020a0003
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[32:35], v7, s[28:31], null offen         ; c405c07c 40803820 00000007
	buffer_load_d16_hi_b16 v25, v6, s[28:31], null offen offset:14 ; c408c07c 40803819 00000e06
	buffer_load_b128 v[36:39], v7, s[28:31], null offen offset:32 ; c405c07c 40803824 00002007
	buffer_load_b128 v[40:43], v24, s[28:31], null offen        ; c405c07c 40803828 00000018
	buffer_load_b128 v[44:47], v24, s[28:31], null offen offset:512 ; c405c07c 4080382c 00020018
	buffer_load_b128 v[48:51], v24, s[28:31], null offen offset:1024 ; c405c07c 40803830 00040018
	buffer_load_b128 v[52:55], v24, s[28:31], null offen offset:1536 ; c405c07c 40803834 00060018
	buffer_load_d16_hi_b16 v30, v6, s[28:31], null offen offset:46 ; c408c07c 4080381e 00002e06
	v_add_nc_u32_e32 v26, 32, v6                                ; 4a340ca0
	v_lshrrev_b32_e32 v1, 1, v1                                 ; 32020281
	v_lshrrev_b32_e32 v2, 3, v2                                 ; 32040483
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v2, v2, 2, v1                                ; d6460002 04050502
	v_lshl_add_u32 v2, v2, 4, v4                                ; d6460002 04110902
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v2, 1, v2                                 ; 30040481
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_alignbyte_b32 v32, v33, v32, v6                           ; d6170020 041a4121
	v_alignbyte_b32 v33, v34, v33, v6                           ; d6170021 041a4322
	v_alignbyte_b32 v34, v35, v34, v6                           ; d6170022 041a4523
	v_alignbyte_b32 v35, v35, v35, v6                           ; d6170023 041a4723
	ds_load_b64 v[6:7], v2                                      ; d9d80000 06000002
	ds_load_b64 v[56:57], v2 offset:8                           ; d9d80008 38000002
	ds_load_b64 v[58:59], v2 offset:512                         ; d9d80200 3a000002
	ds_load_b64 v[60:61], v2 offset:520                         ; d9d80208 3c000002
	ds_load_b64 v[62:63], v2 offset:64                          ; d9d80040 3e000002
	ds_load_b64 v[64:65], v2 offset:72                          ; d9d80048 40000002
	ds_load_b64 v[66:67], v2 offset:576                         ; d9d80240 42000002
	ds_load_b64 v[68:69], v2 offset:584                         ; d9d80248 44000002
	ds_load_b64 v[70:71], v2 offset:256                         ; d9d80100 46000002
	ds_load_b64 v[72:73], v2 offset:264                         ; d9d80108 48000002
	ds_load_b64 v[74:75], v2 offset:768                         ; d9d80300 4a000002
	ds_load_b64 v[76:77], v2 offset:776                         ; d9d80308 4c000002
	ds_load_b64 v[78:79], v2 offset:320                         ; d9d80140 4e000002
	ds_load_b64 v[80:81], v2 offset:328                         ; d9d80148 50000002
	ds_load_b64 v[82:83], v2 offset:832                         ; d9d80340 52000002
	ds_load_b64 v[2:3], v2 offset:840                           ; d9d80348 02000002
	v_cvt_pk_f32_fp8_e32 v[84:85], v14                          ; 7ea8dd0e
	v_cvt_pk_f32_fp8_e32 v[86:87], v142                         ; 7eacdd8e
	v_cvt_pk_f32_fp8_e32 v[88:89], v15                          ; 7eb0dd0f
	v_cvt_pk_f32_fp8_e32 v[14:15], v143                         ; 7e1cdd8f
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_pk_rtz_f16_f32_e32 v84, v84, v85                      ; 5ea8ab54
	v_cvt_pk_rtz_f16_f32_e32 v86, v86, v87                      ; 5eacaf56
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_mov_b16_e32 v35.h, v25.h                                  ; 7f463999
	v_cvt_pk_rtz_f16_f32_e32 v88, v88, v89                      ; 5eb0b358
	v_cvt_pk_rtz_f16_f32_e32 v14, v14, v15                      ; 5e1c1f0e
	s_wait_dscnt 0xf                                            ; bfc6000f
	v_pk_fmac_f16 v6, v84, v32                                  ; 780c4154
	v_pk_fmac_f16 v7, v86, v33                                  ; 780e4356
	s_wait_dscnt 0xe                                            ; bfc6000e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_pk_fmac_f16 v56, v88, v34                                 ; 78704558
	v_pk_fmac_f16 v57, v14, v35                                 ; 7872470e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_pk_f32_fp8_e32 v[14:15], v16                          ; 7e1cdd10
	v_cvt_f32_f16_e32 v84, v6                                   ; 7ea81706
	v_cvt_f32_f16_e32 v31, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3e1786
	v_cvt_f32_f16_e32 v85, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eaa1787
	v_cvt_f32_f16_e32 v86, v7                                   ; 7eac1707
	v_cvt_f32_f16_e32 v87, v184/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eae17b8
	v_cvt_f32_f16_e32 v88, v56                                  ; 7eb01738
	v_cvt_f32_f16_e32 v90, v57                                  ; 7eb41739
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_alignbyte_b32 v36, v37, v36, v26                          ; d6170024 046a4925
	v_cvt_f32_f16_e32 v89, v185/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eb217b9
	v_alignbyte_b32 v37, v38, v37, v26                          ; d6170025 046a4b26
	v_cvt_pk_rtz_f16_f32_e32 v14, v14, v15                      ; 5e1c1f0e
	v_alignbyte_b32 v38, v39, v38, v26                          ; d6170026 046a4d27
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v84, v31, vcc_lo                      ; 02023f54
	v_alignbyte_b32 v39, v39, v39, v26                          ; d6170027 046a4f27
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v86, v85, vcc_lo                      ; 0202ab56
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v88, v87, vcc_lo                      ; 0202af58
	v_cvt_pk_f32_fp8_e32 v[86:87], v144                         ; 7eacdd90
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v90, v89, vcc_lo                      ; 0202b35a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_cvt_pk_f32_fp8_e32 v[88:89], v17                          ; 7eb0dd11
	v_cvt_pk_f32_fp8_e32 v[16:17], v145                         ; 7e20dd91
	s_wait_dscnt 0xd                                            ; bfc6000d
	v_pk_fmac_f16 v58, v14, v36                                 ; 7874490e
	v_cvt_pk_rtz_f16_f32_e32 v86, v86, v87                      ; 5eacaf56
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_pk_rtz_f16_f32_e32 v88, v88, v89                      ; 5eb0b358
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	v_cvt_f32_f16_e32 v92, v58                                  ; 7eb8173a
	v_cvt_f32_f16_e32 v91, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eb617ba
	v_pk_fmac_f16 v59, v86, v37                                 ; 78764b56
	v_cvt_pk_f32_fp8_e32 v[86:87], v8                           ; 7eacdd08
	s_wait_dscnt 0xc                                            ; bfc6000c
	v_pk_fmac_f16 v60, v88, v38                                 ; 78784d58
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v92, v91, vcc_lo                      ; 0202b75c
	v_cvt_f32_f16_e32 v93, v187/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eba17bb
	v_cvt_f32_f16_e32 v94, v59                                  ; 7ebc173b
	v_cvt_pk_rtz_f16_f32_e32 v86, v86, v87                      ; 5eacaf56
	v_cvt_f32_f16_e32 v96, v60                                  ; 7ec0173c
	v_cvt_f32_f16_e32 v95, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ebe17bc
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v94, v93, vcc_lo                      ; 0202bb5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_dscnt 0xb                                            ; bfc6000b
	v_pk_fmac_f16 v62, v86, v32                                 ; 787c4156
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_pk_f32_fp8_e32 v[86:87], v136                         ; 7eacdd88
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v96, v95, vcc_lo                      ; 0202bf60
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_cvt_f32_f16_e32 v97, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ec217be
	v_cvt_f32_f16_e32 v98, v62                                  ; 7ec4173e
	v_cvt_pk_rtz_f16_f32_e32 v86, v86, v87                      ; 5eacaf56
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_pk_fmac_f16 v63, v86, v33                                 ; 787e4356
	v_cvt_pk_f32_fp8_e32 v[86:87], v9                           ; 7eacdd09
	v_cvt_pk_f32_fp8_e32 v[8:9], v137                           ; 7e10dd89
	v_cvt_f32_f16_e32 v100, v63                                 ; 7ec8173f
	v_cvt_f32_f16_e32 v99, v191/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ec617bf
	v_cvt_pk_rtz_f16_f32_e32 v86, v86, v87                      ; 5eacaf56
	v_cvt_pk_rtz_f16_f32_e32 v8, v8, v9                         ; 5e101308
	s_wait_dscnt 0xa                                            ; bfc6000a
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_pk_fmac_f16 v64, v86, v34                                 ; 78804556
	v_cvt_pk_f32_fp8_e32 v[86:87], v18                          ; 7eacdd12
	v_pk_fmac_f16 v65, v8, v35                                  ; 78824708
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v98, v97, vcc_lo                      ; 0202c362
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v100, v99, vcc_lo                     ; 0202c764
	v_cvt_f32_f16_e32 v101, v192/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eca17c0
	v_cvt_f32_f16_e32 v102, v64                                 ; 7ecc1740
	v_cvt_pk_rtz_f16_f32_e32 v86, v86, v87                      ; 5eacaf56
	v_cvt_f32_f16_e32 v104, v65                                 ; 7ed01741
	v_cvt_f32_f16_e32 v103, v193/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ece17c1
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v102, v101, vcc_lo                    ; 0202cb66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_dscnt 0x9                                            ; bfc60009
	v_pk_fmac_f16 v66, v86, v36                                 ; 78844956
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_pk_f32_fp8_e32 v[86:87], v146                         ; 7eacdd92
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v104, v103, vcc_lo                    ; 0202cf68
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_cvt_f32_f16_e32 v105, v194/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ed217c2
	v_cvt_f32_f16_e32 v106, v66                                 ; 7ed41742
	v_cvt_pk_f32_fp8_e32 v[88:89], v10                          ; 7eb0dd0a
	v_cvt_pk_rtz_f16_f32_e32 v86, v86, v87                      ; 5eacaf56
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870252
	v_cvt_pk_rtz_f16_f32_e32 v88, v88, v89                      ; 5eb0b358
	v_pk_fmac_f16 v67, v86, v37                                 ; 78864b56
	v_cvt_pk_f32_fp8_e32 v[86:87], v19                          ; 7eacdd13
	v_cvt_pk_f32_fp8_e32 v[18:19], v147                         ; 7e24dd93
	s_wait_dscnt 0x7                                            ; bfc60007
	v_pk_fmac_f16 v70, v88, v32                                 ; 788c4158
	v_cvt_pk_f32_fp8_e32 v[88:89], v138                         ; 7eb0dd8a
	v_cvt_f32_f16_e32 v107, v195/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ed617c3
	v_cvt_f32_f16_e32 v108, v67                                 ; 7ed81743
	v_cvt_pk_rtz_f16_f32_e32 v86, v86, v87                      ; 5eacaf56
	v_cvt_pk_rtz_f16_f32_e32 v18, v18, v19                      ; 5e242712
	v_cvt_f32_f16_e32 v111, v198/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ede17c6
	v_cvt_f32_f16_e32 v112, v70                                 ; 7ee01746
	v_cvt_pk_rtz_f16_f32_e32 v88, v88, v89                      ; 5eb0b358
	v_pk_fmac_f16 v68, v86, v38                                 ; 78884d56
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v106, v105, vcc_lo                    ; 0202d36a
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v108, v107, vcc_lo                    ; 0202d76c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_pk_fmac_f16 v71, v88, v33                                 ; 788e4358
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_pk_f32_fp8_e32 v[88:89], v11                          ; 7eb0dd0b
	v_cvt_pk_f32_fp8_e32 v[10:11], v139                         ; 7e14dd8b
	v_cvt_f32_f16_e32 v109, v196/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eda17c4
	v_cvt_f32_f16_e32 v110, v68                                 ; 7edc1744
	v_cvt_f32_f16_e32 v114, v71                                 ; 7ee41747
	v_cvt_f32_f16_e32 v113, v199/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ee217c7
	v_cvt_pk_rtz_f16_f32_e32 v88, v88, v89                      ; 5eb0b358
	v_cvt_pk_rtz_f16_f32_e32 v10, v10, v11                      ; 5e14170a
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v110, v109, vcc_lo                    ; 0202db6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_mov_b16_e32 v39.h, v30.h                                  ; 7f4e399e
	s_wait_dscnt 0x6                                            ; bfc60006
	v_pk_fmac_f16 v72, v88, v34                                 ; 78904558
	v_cvt_pk_f32_fp8_e32 v[88:89], v20                          ; 7eb0dd14
	v_pk_fmac_f16 v73, v10, v35                                 ; 7892470a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v112, v111, vcc_lo                    ; 0202df70
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v114, v113, vcc_lo                    ; 0202e372
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_pk_fmac_f16 v61, v16, v39                                 ; 787a4f10
	v_pk_fmac_f16 v69, v18, v39                                 ; 788a4f12
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_f32_f16_e32 v115, v200/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ee617c8
	v_cvt_f32_f16_e32 v116, v72                                 ; 7ee81748
	v_cvt_pk_rtz_f16_f32_e32 v88, v88, v89                      ; 5eb0b358
	v_cvt_f32_f16_e32 v117, v201/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eea17c9
	v_cvt_f32_f16_e32 v118, v73                                 ; 7eec1749
	v_cvt_pk_f32_fp8_e32 v[16:17], v21                          ; 7e20dd15
	v_cvt_f32_f16_e32 v119, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eee17bd
	v_cvt_f32_f16_e32 v120, v61                                 ; 7ef0173d
	v_cvt_f32_f16_e32 v122, v69                                 ; 7ef41745
	v_cvt_f32_f16_e32 v121, v197/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ef217c5
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v116, v115, vcc_lo                    ; 0202e774
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_dscnt 0x5                                            ; bfc60005
	v_pk_fmac_f16 v74, v88, v36                                 ; 78944958
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_pk_f32_fp8_e32 v[88:89], v148                         ; 7eb0dd94
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v118, v117, vcc_lo                    ; 0202eb76
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v120, v119, vcc_lo                    ; 0202ef78
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v122, v121, vcc_lo                    ; 0202f37a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_cvt_f32_f16_e32 v123, v202/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ef617ca
	v_cvt_f32_f16_e32 v124, v74                                 ; 7ef8174a
	v_cvt_pk_rtz_f16_f32_e32 v88, v88, v89                      ; 5eb0b358
	v_cvt_pk_f32_fp8_e32 v[18:19], v12                          ; 7e24dd0c
	s_wait_dscnt 0x4                                            ; bfc60004
	v_pk_fmac_f16 v76, v16, v38                                 ; 78984d10
	v_cvt_pk_f32_fp8_e32 v[16:17], v149                         ; 7e20dd95
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_pk_fmac_f16 v75, v88, v37                                 ; 78964b58
	v_cvt_pk_rtz_f16_f32_e32 v18, v18, v19                      ; 5e242712
	v_cvt_f32_f16_e32 v128, v76                                 ; 7f00174c
	v_cvt_f32_f16_e32 v127, v204/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7efe17cc
	v_cvt_pk_rtz_f16_f32_e32 v16, v16, v17                      ; 5e202310
	v_cvt_f32_f16_e32 v125, v203/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7efa17cb
	v_cvt_f32_f16_e32 v126, v75                                 ; 7efc174b
	s_wait_dscnt 0x3                                            ; bfc60003
	v_pk_fmac_f16 v78, v18, v32                                 ; 789c4112
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_pk_f32_fp8_e32 v[18:19], v140                         ; 7e24dd8c
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v128, v127, vcc_lo                    ; 0202ff80
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_pk_fmac_f16 v77, v16, v39                                 ; 789a4f10
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v124, v123, vcc_lo                    ; 0202f77c
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v126, v125, vcc_lo                    ; 0202fb7e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_cvt_f32_f16_e32 v131, v206/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f0617ce
	v_cvt_f32_f16_e32 v132, v78                                 ; 7f08174e
	v_cvt_pk_rtz_f16_f32_e32 v18, v18, v19                      ; 5e242712
	v_cvt_f32_f16_e32 v129, v205/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f0217cd
	v_cvt_f32_f16_e32 v130, v77                                 ; 7f04174d
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_pk_fmac_f16 v79, v18, v33                                 ; 789e4312
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_pk_f32_fp8_e32 v[18:19], v13                          ; 7e24dd0d
	v_cvt_pk_f32_fp8_e32 v[12:13], v141                         ; 7e18dd8d
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v130, v129, vcc_lo                    ; 02030382
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_cvt_f32_f16_e32 v133, v207/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f0a17cf
	v_cvt_f32_f16_e32 v134, v79                                 ; 7f0c174f
	v_cvt_pk_rtz_f16_f32_e32 v18, v18, v19                      ; 5e242712
	v_cvt_pk_rtz_f16_f32_e32 v12, v12, v13                      ; 5e181b0c
	s_wait_dscnt 0x2                                            ; bfc60002
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_pk_fmac_f16 v80, v18, v34                                 ; 78a04512
	v_cvt_pk_f32_fp8_e32 v[18:19], v22                          ; 7e24dd16
	v_pk_fmac_f16 v81, v12, v35                                 ; 78a2470c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v132, v131, vcc_lo                    ; 02030784
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v134, v133, vcc_lo                    ; 02030b86
	v_cvt_f32_f16_e32 v136, v80                                 ; 7f101750
	v_cvt_f32_f16_e32 v135, v208/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f0e17d0
	v_cvt_pk_rtz_f16_f32_e32 v18, v18, v19                      ; 5e242712
	v_cvt_f32_f16_e32 v137, v209/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f1217d1
	v_cvt_f32_f16_e32 v138, v81                                 ; 7f141751
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v136, v135, vcc_lo                    ; 02030f88
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_wait_dscnt 0x1                                            ; bfc60001
	v_pk_fmac_f16 v82, v18, v36                                 ; 78a44912
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_pk_f32_fp8_e32 v[18:19], v150                         ; 7e24dd96
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v138, v137, vcc_lo                    ; 0203138a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_cvt_pk_rtz_f16_f32_e32 v18, v18, v19                      ; 5e242712
	v_pk_fmac_f16 v83, v18, v37                                 ; 78a64b12
	v_cvt_pk_f32_fp8_e32 v[18:19], v23                          ; 7e24dd17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c1
	v_cvt_pk_rtz_f16_f32_e32 v18, v18, v19                      ; 5e242712
	v_cvt_f32_f16_e32 v139, v210/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f1617d2
	v_cvt_f32_f16_e32 v140, v82                                 ; 7f181752
	s_wait_dscnt 0x0                                            ; bfc60000
	v_pk_fmac_f16 v2, v18, v38                                  ; 78044d12
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_cvt_pk_f32_fp8_e32 v[18:19], v151                         ; 7e24dd97
	v_cvt_f32_f16_e32 v141, v211/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f1a17d3
	v_cvt_f32_f16_e32 v142, v83                                 ; 7f1c1753
	v_cvt_f32_f16_e32 v143, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f1e1782
	v_cvt_f32_f16_e32 v144, v2                                  ; 7f201702
	v_cvt_pk_rtz_f16_f32_e32 v18, v18, v19                      ; 5e242712
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v144, v143, vcc_lo                    ; 02031f90
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_pk_fmac_f16 v3, v18, v39                                  ; 78064f12
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[40:41], v[84:85], 0 ; cc464020 1a02a928
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v140, v139, vcc_lo                    ; 0203178c
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v142, v141, vcc_lo                    ; 02031b8e
	v_cvt_f32_f16_e32 v146, v3                                  ; 7f241703
	v_cvt_f32_f16_e32 v145, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f221783
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[40:41], v[8:9], 0   ; cc464058 1a021128
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[40:41], v[10:11], 0 ; cc464060 1a021528
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[40:41], v[12:13], 0 ; cc464068 1a021928
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v146, v145, vcc_lo                    ; 02032392
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[44:45], v[14:15], v[32:39] ; cc464020 1c821d2c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[44:45], v[86:87], v[88:95] ; cc464058 1d62ad2c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[44:45], v[16:17], v[96:103] ; cc464060 1d82212c
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[44:45], v[18:19], v[104:111] ; cc464068 1da2252c
	v_maxmin_num_f32 v151, -4.0, v34, 4.0                       ; d6690097 03da44f7
	v_maxmin_num_f32 v147, -4.0, v32, 4.0                       ; d6690093 03da40f7
	v_maxmin_num_f32 v153, -4.0, v35, 4.0                       ; d6690099 03da46f7
	v_maxmin_num_f32 v155, -4.0, v36, 4.0                       ; d669009b 03da48f7
	v_maxmin_num_f32 v149, -4.0, v33, 4.0                       ; d6690095 03da42f7
	v_maxmin_num_f32 v157, -4.0, v37, 4.0                       ; d669009d 03da4af7
	v_maxmin_num_f32 v159, -4.0, v38, 4.0                       ; d669009f 03da4cf7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_maxmin_num_f32 v163, -4.0, v88, 4.0                       ; d66900a3 03dab0f7
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v39, 4.0                       ; d66900a1 03da4ef7
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_maxmin_num_f32 v165, -4.0, v89, 4.0                       ; d66900a5 03dab2f7
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_fmaak_f32 v147, v147, v148, 0x3f650000                    ; 5b272993 3f650000
	v_dual_fmaak_f32 v149, v149, v150, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v153, 0x3f650000 ; c8432d95 959b339a 3f650000
	v_maxmin_num_f32 v169, -4.0, v91, 4.0                       ; d66900a9 03dab6f7
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_maxmin_num_f32 v167, -4.0, v90, 4.0                       ; d66900a7 03dab4f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_dual_mul_f32 v33, v33, v149 :: v_dual_mul_f32 v32, v32, v147 ; c8c72b21 21212720
	v_dual_mul_f32 v35, v35, v154 :: v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 ; c8c33523 23992f98 3f650000
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v92, 4.0                       ; d66900ab 03dab8f7
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_maxmin_num_f32 v173, -4.0, v93, 4.0                       ; d66900ad 03dabaf7
	v_dual_fmaak_f32 v165, v165, v166, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v161, 0x3f650000 ; c8434da5 a5a343a2 3f650000
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	v_dual_fmaak_f32 v155, v156, v155, 0x3f650000 :: v_dual_mul_f32 v34, v34, v152 ; c847379c 9b233122 3f650000
	v_maxmin_num_f32 v175, -4.0, v94, 4.0                       ; d66900af 03dabcf7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_maxmin_num_f32 v179, -4.0, v96, 4.0                       ; d66900b3 03dac0f7
	v_dual_fmaak_f32 v170, v170, v169, 0x3f650000 :: v_dual_mul_f32 v39, v39, v162 ; c84753aa aa274527 3f650000
	v_dual_fmaak_f32 v157, v157, v158, 0x3f650000 :: v_dual_mul_f32 v36, v36, v155 ; c8473d9d 9d253724 3f650000
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	v_maxmin_num_f32 v177, -4.0, v95, 4.0                       ; d66900b1 03dabef7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_maxmin_num_f32 v181, -4.0, v97, 4.0                       ; d66900b5 03dac2f7
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_dual_mul_f32 v91, v91, v170 :: v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 ; c8c3555b 5ba94fa8 3f650000
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_mul_f32 v37, v37, v157 ; c8473fa0 a0253b25 3f650000
	v_maxmin_num_f32 v185, -4.0, v99, 4.0                       ; d66900b9 03dac6f7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_maxmin_num_f32 v183, -4.0, v98, 4.0                       ; d66900b7 03dac4f7
	v_dual_fmaak_f32 v171, v172, v171, 0x3f650000 :: v_dual_mul_f32 v90, v90, v168 ; c84757ac ab5b515a 3f650000
	v_dual_fmaak_f32 v163, v164, v163, 0x3f650000 :: v_dual_mul_f32 v38, v38, v160 ; c84747a4 a3274126 3f650000
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v187, -4.0, v100, 4.0                      ; d66900bb 03dac8f7
	v_dual_fmaak_f32 v181, v181, v182, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v177, 0x3f650000 ; c8436db5 b5b363b2 3f650000
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_maxmin_num_f32 v191, -4.0, v102, 4.0                      ; d66900bf 03daccf7
	v_dual_fmaak_f32 v173, v173, v174, 0x3f650000 :: v_dual_mul_f32 v92, v92, v171 ; c8475dad ad5d575c 3f650000
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
	v_dual_mul_f32 v89, v89, v165 :: v_dual_mul_f32 v88, v88, v163 ; c8c74b59 59594758
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v101, 4.0                      ; d66900bd 03dacaf7
	v_dual_fmaak_f32 v186, v186, v185, 0x3f650000 :: v_dual_mul_f32 v95, v95, v178 ; c84773ba ba5f655f 3f650000
	v_maxmin_num_f32 v26, -4.0, v104, 4.0                       ; d669001a 03dad0f7
	v_fma_mix_f32 v1, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206201 0bff7eff 3728ab28
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_mul_f32 v93, v93, v173 ; c8475fb0 b05d5b5d 3f650000
(invalid instruction)                                        ; d7690016
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694016
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v5, -4.0, v103, 4.0                        ; d6690005 03dacef7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_dual_mul_f32 v99, v99, v186 :: v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 ; c8c37563 63b96fb8 3f650000
	v_maxmin_num_f32 v35, -4.0, v106, 4.0                       ; d6690023 03dad4f7
	v_fma_mix_f32 v32, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206220 0bfe34ff 3728ab28
(invalid instruction)                                        ; d7690017
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_dual_fmaak_f32 v179, v180, v179, 0x3f650000 :: v_dual_mul_f32 v94, v94, v176 ; c84767b4 b35f615e 3f650000
	v_maxmin_num_f32 v33, -4.0, v105, 4.0                       ; d6690021 03dad2f7
	v_fma_mix_f32 v25, 0xab28, |v5|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe0aff 3728ab28
	v_dual_fmaak_f32 v187, v188, v187, 0x3f650000 :: v_dual_mul_f32 v98, v98, v184 ; c84777bc bb637162 3f650000
	v_fma_mix_f32 v36, 0xab28, |v35|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206224 0bfe46ff 3728ab28
	v_maxmin_num_f32 v37, -4.0, v107, 4.0                       ; d6690025 03dad6f7
	v_maxmin_num_f32 v39, -4.0, v108, 4.0                       ; d6690027 03dad8f7
	v_dual_mul_f32 v97, v97, v181 :: v_dual_mul_f32 v96, v96, v179 ; c8c76b61 61616760
(invalid instruction)                                        ; d7694017
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_fma_mix_f32 v34, 0xab28, |v33|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206222 0bfe42ff 3728ab28
	v_dual_fmaak_f32 v1, v191, v1, 0x3f650000 :: v_dual_mul_f32 v100, v100, v187 ; c84603bf 01657764 3f650000
	v_maxmin_num_f32 v45, -4.0, v110, 4.0                       ; d669002d 03dadcf7
	v_fma_mix_f32 v38, 0xab28, |v37|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206226 0bfe4aff 3728ab28
	v_fma_mix_f32 v40, 0xab28, |v39|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206228 0bfe4eff 3728ab28
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v41, -4.0, v109, 4.0                       ; d6690029 03dadaf7
	v_maxmin_num_f32 v89, -4.0, v111, 4.0                       ; d6690059 03dadef7
	v_dual_mul_f32 v102, v102, v1 :: v_dual_fmaak_f32 v189, v189, v190, 0x3f650000 ; c8c20366 66bd7dbd 3f650000
	v_fma_mix_f32 v88, 0xab28, |v45|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfe5aff 3728ab28
	v_dual_fmaak_f32 v38, v38, v37, 0x3f650000 :: v_dual_fmaak_f32 v39, v39, v40, 0x3f650000 ; c8424b26 26265127 3f650000
	v_fma_mix_f32 v44, 0xab28, |v41|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622c 0bfe52ff 3728ab28
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_mul_f32 v101, v101, v189 :: v_dual_fmaak_f32 v26, v26, v32, 0x3f650000 ; c8c37b65 651a411a 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v88, v88, v45, 0x3f650000 :: v_dual_mul_f32 v107, v107, v38 ; c8465b58 586a4d6b 3f650000
	v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 :: v_dual_fmaak_f32 v41, v41, v44, 0x3f650000 ; c842b35a 5a285929 3f650000
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_dual_mul_f32 v104, v104, v26 :: v_dual_fmaak_f32 v25, v25, v5, 0x3f650000 ; c8c23568 68180b19 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b3
	v_dual_mul_f32 v111, v111, v90 :: v_dual_mul_f32 v110, v110, v88 ; c8c6b56f 6f6eb16e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[42:43], v[84:85], 0 ; cc464058 1a02a92a
	v_dual_fmaak_f32 v36, v36, v35, 0x3f650000 :: v_dual_mul_f32 v103, v103, v25 ; c8464724 24663367 3f650000
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_dual_mul_f32 v106, v106, v36 :: v_dual_fmaak_f32 v33, v33, v34, 0x3f650000 ; c8c2496a 6a204521 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[46:47], v[14:15], v[88:95] ; cc464058 1d621d2e
	v_dual_mul_f32 v108, v108, v39 :: v_dual_mul_f32 v105, v105, v33 ; c8c64f6c 6c684369
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[42:43], v[8:9], 0  ; cc464060 1a02112a
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[42:43], v[12:13], 0 ; cc464070 1a02192a
	v_maxmin_num_f32 v120, -4.0, v88, 4.0                       ; d6690078 03dab0f7
	v_maxmin_num_f32 v126, -4.0, v91, 4.0                       ; d669007e 03dab6f7
	v_maxmin_num_f32 v122, -4.0, v89, 4.0                       ; d669007a 03dab2f7
	v_maxmin_num_f32 v124, -4.0, v90, 4.0                       ; d669007c 03dab4f7
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[46:47], v[86:87], v[96:103] ; cc464060 1d82ad2e
	v_maxmin_num_f32 v130, -4.0, v93, 4.0                       ; d6690082 03dabaf7
	v_fma_mix_f32 v121, 0xab28, |v120|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfef0ff 3728ab28
	v_fma_mix_f32 v127, 0xab28, |v126|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627f 0bfefcff 3728ab28
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_fma_mix_f32 v125, 0xab28, |v124|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627d 0bfef8ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[46:47], v[18:19], v[112:119] ; cc464070 1dc2252e
	v_maxmin_num_f32 v128, -4.0, v92, 4.0                       ; d6690080 03dab8f7
	v_maxmin_num_f32 v134, -4.0, v95, 4.0                       ; d6690086 03dabef7
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_dual_fmaak_f32 v127, v127, v126, 0x3f650000 :: v_dual_fmaak_f32 v120, v120, v121, 0x3f650000 ; c842fd7f 7f78f378 3f650000
	v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 :: v_dual_mul_f32 v109, v109, v41 ; c846f77a 7a6c536d 3f650000
	v_maxmin_num_f32 v132, -4.0, v94, 4.0                       ; d6690084 03dabcf7
	v_maxmin_num_f32 v138, -4.0, v97, 4.0                       ; d669008a 03dac2f7
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
	v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 :: v_dual_fmaak_f32 v125, v125, v124, 0x3f650000 ; c8430782 827cf97d 3f650000
	v_dual_mul_f32 v91, v91, v127 :: v_dual_mul_f32 v88, v88, v120 ; c8c6ff5b 5b58f158
	v_mul_f32_e32 v89, v89, v122                                ; 10b2f559
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[42:43], v[10:11], 0 ; cc464068 1a02152a
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_maxmin_num_f32 v136, -4.0, v96, 4.0                       ; d6690088 03dac0f7
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v142, -4.0, v99, 4.0                       ; d669008e 03dac6f7
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430d87 87810380 3f650000
	v_dual_mul_f32 v93, v93, v130 :: v_dual_mul_f32 v90, v90, v125 ; c8c7055d 5d5afb5a
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_maxmin_num_f32 v140, -4.0, v98, 4.0                       ; d669008c 03dac4f7
	v_maxmin_num_f32 v146, -4.0, v101, 4.0                      ; d6690092 03dacaf7
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 ; c843178a 8a850985 3f650000
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v144, -4.0, v100, 4.0                      ; d6690090 03dac8f7
	v_dual_mul_f32 v95, v95, v135 :: v_dual_mul_f32 v92, v92, v128 ; c8c70f5f 5f5d015c
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[46:47], v[16:17], v[104:111] ; cc464068 1da2212e
	v_maxmin_num_f32 v150, -4.0, v103, 4.0                      ; d6690096 03dacef7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_dual_mul_f32 v97, v97, v138 :: v_dual_mul_f32 v94, v94, v133 ; c8c71561 615f0b5e
	v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v137, 0x3f650000 ; c8431d8f 8f891388 3f650000
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v148, -4.0, v102, 4.0                      ; d6690094 03daccf7
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 ; c8432792 928d198d 3f650000
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_dual_mul_f32 v99, v99, v143 :: v_dual_mul_f32 v96, v96, v136 ; c8c71f63 63611160
	v_maxmin_num_f32 v154, -4.0, v105, 4.0                      ; d669009a 03dad2f7
	v_maxmin_num_f32 v158, -4.0, v107, 4.0                      ; d669009e 03dad6f7
	v_maxmin_num_f32 v152, -4.0, v104, 4.0                      ; d6690098 03dad0f7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432d97 97912390 3f650000
	v_dual_mul_f32 v101, v101, v146 :: v_dual_mul_f32 v98, v98, v141 ; c8c72565 65631b62
	v_maxmin_num_f32 v156, -4.0, v106, 4.0                      ; d669009c 03dad4f7
	v_maxmin_num_f32 v162, -4.0, v109, 4.0                      ; d66900a2 03dadaf7
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_mul_f32 v103, v103, v151 :: v_dual_mul_f32 v100, v100, v144 ; c8c72f67 67652164
	v_maxmin_num_f32 v160, -4.0, v108, 4.0                      ; d66900a0 03dad8f7
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v166, -4.0, v111, 4.0                      ; d66900a6 03dadef7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c843379a 9a952995 3f650000
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c8433d9f 9f993398 3f650000
	v_maxmin_num_f32 v164, -4.0, v110, 4.0                      ; d66900a4 03dadcf7
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v170, -4.0, v113, 4.0                      ; d66900aa 03dae2f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c84347a2 a29d399d 3f650000
	v_maxmin_num_f32 v168, -4.0, v112, 4.0                      ; d66900a8 03dae0f7
	v_dual_mul_f32 v105, v105, v154 :: v_dual_mul_f32 v102, v102, v149 ; c8c73569 69672b66
	v_dual_mul_f32 v107, v107, v159 :: v_dual_mul_f32 v104, v104, v152 ; c8c73f6b 6b693168
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v115, 4.0                      ; d66900ae 03dae6f7
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c8434da7 a7a143a0 3f650000
	v_dual_mul_f32 v109, v109, v162 :: v_dual_mul_f32 v106, v106, v157 ; c8c7456d 6d6b3b6a
	v_maxmin_num_f32 v172, -4.0, v114, 4.0                      ; d66900ac 03dae4f7
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v178, -4.0, v117, 4.0                      ; d66900b2 03daeaf7
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 ; c84357aa aaa549a5 3f650000
	v_dual_mul_f32 v111, v111, v167 :: v_dual_mul_f32 v108, v108, v160 ; c8c74f6f 6f6d416c
	v_maxmin_num_f32 v176, -4.0, v116, 4.0                      ; d66900b0 03dae8f7
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v118, 4.0                      ; d66900b4 03daecf7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v119, 4.0                      ; d66900b6 03daeef7
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c8435daf afa953a8 3f650000
	v_dual_mul_f32 v113, v113, v170 :: v_dual_mul_f32 v110, v110, v165 ; c8c75571 716f4b6e
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[84:85], 0 ; cc464058 1a02a930
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 ; c84367b2 b2ad59ad 3f650000
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_mul_f32 v115, v115, v175 :: v_dual_mul_f32 v112, v112, v168 ; c8c75f73 73715170
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84369b5 b5b163b0 3f650000
	v_dual_mul_f32 v117, v117, v178 :: v_dual_mul_f32 v114, v114, v173 ; c8c76575 75735b72
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[14:15], v[88:95] ; cc464058 1d621d34
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[48:49], v[8:9], 0  ; cc464060 1a021130
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[48:49], v[10:11], 0 ; cc464068 1a021530
	v_maxmin_num_f32 v190, -4.0, v91, 4.0                       ; d66900be 03dab6f7
	v_maxmin_num_f32 v186, -4.0, v89, 4.0                       ; d66900ba 03dab2f7
	v_maxmin_num_f32 v184, -4.0, v88, 4.0                       ; d66900b8 03dab0f7
	v_maxmin_num_f32 v188, -4.0, v90, 4.0                       ; d66900bc 03dab4f7
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[52:53], v[86:87], v[96:103] ; cc464060 1d82ad34
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[52:53], v[16:17], v[104:111] ; cc464068 1da22134
	v_maxmin_num_f32 v5, -4.0, v93, 4.0                         ; d6690005 03dabaf7
	v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 :: v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 ; c84377ba bab76db7 3f650000
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8437dbf bfb973b8 3f650000
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_mul_f32 v118, v118, v181 ; c84779bd bd776b76 3f650000
	v_maxmin_num_f32 v26, -4.0, v94, 4.0                        ; d669001a 03dabcf7
	v_maxmin_num_f32 v47, -4.0, v96, 4.0                        ; d669002f 03dac0f7
	v_fma_mix_f32 v25, 0xab28, |v5|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe0aff 3728ab28
	v_mul_f32_e32 v89, v89, v186                                ; 10b37559
	v_dual_mul_f32 v119, v119, v183 :: v_dual_mul_f32 v116, v116, v176 ; c8c76f77 77756174
	v_dual_mul_f32 v91, v91, v191 :: v_dual_mul_f32 v88, v88, v184 ; c8c77f5b 5b597158
	v_maxmin_num_f32 v191, -4.0, v92, 4.0                       ; d66900bf 03dab8f7
	v_maxmin_num_f32 v45, -4.0, v95, 4.0                        ; d669002d 03dabef7
	v_fma_mix_f32 v44, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622c 0bfe34ff 3728ab28
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[48:49], v[12:13], 0 ; cc464070 1a021930
	v_maxmin_num_f32 v49, -4.0, v97, 4.0                        ; d6690031 03dac2f7
	v_fma_mix_f32 v48, 0xab28, |v47|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206230 0bfe5eff 3728ab28
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
	v_fma_mix_f32 v1, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206201 0bff7eff 3728ab28
	v_fma_mix_f32 v46, 0xab28, |v45|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20622e 0bfe5aff 3728ab28
	v_maxmin_num_f32 v89, -4.0, v99, 4.0                        ; d6690059 03dac6f7
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_dual_fmaak_f32 v191, v1, v191, 0x3f650000 :: v_dual_mul_f32 v90, v90, v189 ; c8477f01 bf5b7b5a 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[52:53], v[18:19], v[112:119] ; cc464070 1dc22534
	v_maxmin_num_f32 v53, -4.0, v98, 4.0                        ; d6690035 03dac4f7
	v_fma_mix_f32 v52, 0xab28, |v49|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206234 0bfe62ff 3728ab28
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	v_maxmin_num_f32 v91, -4.0, v100, 4.0                       ; d669005b 03dac8f7
	v_fma_mix_f32 v90, 0xab28, |v89|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625a 0bfeb2ff 3728ab28
	v_dual_fmaak_f32 v5, v5, v25, 0x3f650000 :: v_dual_mul_f32 v92, v92, v191 ; c8463305 055d7f5c 3f650000
	v_fma_mix_f32 v88, 0xab28, |v53|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206258 0bfe6aff 3728ab28
	v_dual_fmaak_f32 v49, v49, v52, 0x3f650000 :: v_dual_fmaak_f32 v46, v46, v45, 0x3f650000 ; c8426931 312e5b2e 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_mul_f32 v93, v93, v5 :: v_dual_fmaak_f32 v44, v44, v26, 0x3f650000 ; c8c20b5d 5d2c352c 3f650000
	v_dual_fmaak_f32 v90, v90, v89, 0x3f650000 :: v_dual_mul_f32 v95, v95, v46 ; c846b35a 5a5e5d5f 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870152
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
	v_maxmin_num_f32 v93, -4.0, v101, 4.0                       ; d669005d 03dacaf7
	v_fma_mix_f32 v92, 0xab28, |v91|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625c 0bfeb6ff 3728ab28
	v_dual_fmaak_f32 v47, v48, v47, 0x3f650000 :: v_dual_mul_f32 v94, v94, v44 ; c8465f30 2f5e595e 3f650000
	v_dual_mul_f32 v99, v99, v90 :: v_dual_fmaak_f32 v88, v88, v53, 0x3f650000 ; c8c2b563 63586b58 3f650000
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	v_maxmin_num_f32 v95, -4.0, v102, 4.0                       ; d669005f 03daccf7
	v_fma_mix_f32 v94, 0xab28, |v93|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20625e 0bfebaff 3728ab28
	v_dual_mul_f32 v97, v97, v49 :: v_dual_mul_f32 v96, v96, v47 ; c8c66361 61605f60
	v_dual_fmaak_f32 v91, v92, v91, 0x3f650000 :: v_dual_mul_f32 v98, v98, v88 ; c846b75c 5b62b162 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4) ; bf870252
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
	v_maxmin_num_f32 v97, -4.0, v103, 4.0                       ; d6690061 03dacef7
	v_fma_mix_f32 v96, 0xab28, |v95|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfebeff 3728ab28
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_maxmin_num_f32 v99, -4.0, v104, 4.0                       ; d6690063 03dad0f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v93, v93, v94, 0x3f650000 ; c842c362 625cbd5d 3f650000
	v_dual_mul_f32 v101, v101, v93 :: v_dual_mul_f32 v100, v100, v91 ; c8c6bb65 6564b764
	v_dual_mul_f32 v103, v103, v98 :: v_dual_fmaak_f32 v96, v96, v95, 0x3f650000 ; c8c2c567 6760bf60 3f650000
	v_maxmin_num_f32 v121, -4.0, v108, 4.0                      ; d6690079 03dad8f7
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	v_maxmin_num_f32 v101, -4.0, v105, 4.0                      ; d6690065 03dad2f7
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v123, -4.0, v109, 4.0                      ; d669007b 03dadaf7
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_maxmin_num_f32 v125, -4.0, v110, 4.0                      ; d669007d 03dadcf7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_fmaak_f32 v99, v100, v99, 0x3f650000 :: v_dual_mul_f32 v102, v102, v96 ; c846c764 6366c166 3f650000
	v_fma_mix_f32 v124, 0xab28, |v123|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627c 0bfef6ff 3728ab28
	v_maxmin_num_f32 v127, -4.0, v111, 4.0                      ; d669007f 03dadef7
	v_fma_mix_f32 v126, 0xab28, |v125|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627e 0bfefaff 3728ab28
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v103, -4.0, v106, 4.0                      ; d6690067 03dad4f7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_fma_mix_f32 v128, 0xab28, |v127|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206280 0bfefeff 3728ab28
	v_maxmin_num_f32 v129, -4.0, v112, 4.0                      ; d6690081 03dae0f7
	v_dual_fmaak_f32 v126, v126, v125, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v124, 0x3f650000 ; c842fb7e 7e7af97b 3f650000
	v_maxmin_num_f32 v131, -4.0, v113, 4.0                      ; d6690083 03dae2f7
	v_fmaak_f32 v101, v101, v102, 0x3f650000                    ; 5acacd65 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v130, 0xab28, |v129|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206282 0bff02ff 3728ab28
	v_dual_mul_f32 v109, v123, v109 :: v_dual_fmaak_f32 v128, v128, v127, 0x3f650000 ; c8c2db7b 6d80ff80 3f650000
	v_fma_mix_f32 v132, 0xab28, |v131|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206284 0bff06ff 3728ab28
	buffer_load_b128 v[88:91], v24, s[28:31], null offen offset:2048 ; c405c07c 40803858 00080018
	v_maxmin_num_f32 v133, -4.0, v114, 4.0                      ; d6690085 03dae4f7
	v_dual_mul_f32 v105, v105, v101 :: v_dual_mul_f32 v104, v104, v99 ; c8c6cb69 6968c768
	v_dual_mul_f32 v111, v111, v128 :: v_dual_mul_f32 v110, v110, v126 ; c8c7016f 6f6efd6e
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_fma_mix_f32 v134, 0xab28, |v133|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206286 0bff0aff 3728ab28
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	buffer_load_b128 v[92:95], v24, s[28:31], null offen offset:2560 ; c405c07c 4080385c 000a0018
	v_maxmin_num_f32 v105, -4.0, v107, 4.0                      ; d6690069 03dad6f7
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_maxmin_num_f32 v135, -4.0, v115, 4.0                      ; d6690087 03dae6f7
	v_maxmin_num_f32 v137, -4.0, v116, 4.0                      ; d6690089 03dae8f7
	v_fmaak_f32 v134, v134, v133, 0x3f650000                    ; 5b0d0b86 3f650000
	v_maxmin_num_f32 v141, -4.0, v118, 4.0                      ; d669008d 03daecf7
	v_fma_mix_f32 v120, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfed2ff 3728ab28
	v_fma_mix_f32 v136, 0xab28, |v135|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206288 0bff0eff 3728ab28
	v_fma_mix_f32 v138, 0xab28, |v137|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628a 0bff12ff 3728ab28
	v_maxmin_num_f32 v139, -4.0, v117, 4.0                      ; d669008b 03daeaf7
	v_fma_mix_f32 v142, 0xab28, |v141|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628e 0bff1aff 3728ab28
	v_fmaak_f32 v120, v120, v105, 0x3f650000                    ; 5af0d378 3f650000
	v_maxmin_num_f32 v143, -4.0, v119, 4.0                      ; d669008f 03daeef7
	v_dual_fmaak_f32 v137, v137, v138, 0x3f650000 :: v_dual_fmaak_f32 v136, v136, v135, 0x3f650000 ; c8431589 89890f88 3f650000
	v_fma_mix_f32 v140, 0xab28, |v139|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628c 0bff16ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v107, v107, v120 :: v_dual_fmaak_f32 v104, v104, v103, 0x3f650000 ; c8c2f16b 6b68cf68 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[50:51], v[84:85], 0 ; cc464060 1a02a932
	v_fma_mix_f32 v144, 0xab28, |v143|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206290 0bff1eff 3728ab28
	v_dual_fmaak_f32 v142, v142, v141, 0x3f650000 :: v_dual_mul_f32 v115, v115, v136 ; c8471b8e 8e731173 3f650000
	v_mul_f32_e32 v116, v116, v137                              ; 10e91374
	v_dual_fmaak_f32 v121, v121, v122, 0x3f650000 :: v_dual_mul_f32 v106, v106, v104 ; c846f579 796ad16a 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_dual_mul_f32 v118, v118, v142 :: v_dual_fmaak_f32 v139, v139, v140, 0x3f650000 ; c8c31d76 768b198b 3f650000
	v_dual_fmaak_f32 v129, v129, v130, 0x3f650000 :: v_dual_mul_f32 v108, v108, v121 ; c8470581 816cf36c 3f650000
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[54:55], v[14:15], v[96:103] ; cc464060 1d821d36
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_fmaak_f32 v131, v131, v132, 0x3f650000 :: v_dual_mul_f32 v112, v112, v129 ; c8470983 83710370 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[50:51], v[8:9], 0 ; cc464068 1a021132
	v_dual_mul_f32 v114, v114, v134 :: v_dual_mul_f32 v113, v113, v131 ; c8c70d72 72710771
	v_maxmin_num_f32 v145, -4.0, v96, 4.0                       ; d6690091 03dac0f7
	v_maxmin_num_f32 v147, -4.0, v97, 4.0                       ; d6690093 03dac2f7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[50:51], v[12:13], 0 ; cc464078 1a021932
	v_maxmin_num_f32 v149, -4.0, v98, 4.0                       ; d6690095 03dac4f7
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v146, 0xab28, |v145|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206292 0bff22ff 3728ab28
	v_fma_mix_f32 v148, 0xab28, |v147|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206294 0bff26ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[54:55], v[86:87], v[104:111] ; cc464068 1da2ad36
	v_maxmin_num_f32 v151, -4.0, v99, 4.0                       ; d6690097 03dac6f7
	v_maxmin_num_f32 v153, -4.0, v100, 4.0                      ; d6690099 03dac8f7
	v_fma_mix_f32 v150, 0xab28, |v149|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206296 0bff2aff 3728ab28
	v_dual_fmaak_f32 v144, v144, v143, 0x3f650000 :: v_dual_fmaak_f32 v145, v145, v146, 0x3f650000 ; c8431f90 90912591 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[54:55], v[18:19], v[120:127] ; cc464078 1de22536
	v_maxmin_num_f32 v157, -4.0, v102, 4.0                      ; d669009d 03daccf7
	v_fma_mix_f32 v152, 0xab28, |v151|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206298 0bff2eff 3728ab28
	v_fma_mix_f32 v154, 0xab28, |v153|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629a 0bff32ff 3728ab28
	v_dual_fmaak_f32 v150, v150, v149, 0x3f650000 :: v_dual_mul_f32 v119, v119, v144 ; c8472b96 96772177 3f650000
	v_dual_mul_f32 v96, v96, v145 :: v_dual_mul_f32 v117, v117, v139 ; c8c72360 60751775
	v_maxmin_num_f32 v155, -4.0, v101, 4.0                      ; d669009b 03dacaf7
	v_maxmin_num_f32 v159, -4.0, v103, 4.0                      ; d669009f 03dacef7
	v_fma_mix_f32 v158, 0xab28, |v157|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629e 0bff3aff 3728ab28
	v_maxmin_num_f32 v161, -4.0, v104, 4.0                      ; d66900a1 03dad0f7
	v_dual_fmaak_f32 v152, v152, v151, 0x3f650000 :: v_dual_fmaak_f32 v153, v153, v154, 0x3f650000 ; c8432f98 98993599 3f650000
	v_dual_mul_f32 v98, v98, v150 :: v_dual_fmaak_f32 v147, v147, v148, 0x3f650000 ; c8c32d62 62932993 3f650000
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[50:51], v[10:11], 0 ; cc464070 1a021532
	v_maxmin_num_f32 v165, -4.0, v106, 4.0                      ; d66900a5 03dad4f7
	v_fma_mix_f32 v156, 0xab28, |v155|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629c 0bff36ff 3728ab28
	v_fma_mix_f32 v160, 0xab28, |v159|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a0 0bff3eff 3728ab28
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_dual_fmaak_f32 v158, v158, v157, 0x3f650000 :: v_dual_mul_f32 v99, v99, v152 ; c8473b9e 9e633163 3f650000
	v_dual_mul_f32 v100, v100, v153 :: v_dual_mul_f32 v97, v97, v147 ; c8c73364 64612761
	v_maxmin_num_f32 v163, -4.0, v105, 4.0                      ; d66900a3 03dad2f7
	v_maxmin_num_f32 v167, -4.0, v107, 4.0                      ; d66900a7 03dad6f7
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_maxmin_num_f32 v169, -4.0, v108, 4.0                      ; d66900a9 03dad8f7
	v_dual_fmaak_f32 v160, v160, v159, 0x3f650000 :: v_dual_fmaak_f32 v161, v161, v162, 0x3f650000 ; c8433fa0 a0a145a1 3f650000
	v_maxmin_num_f32 v173, -4.0, v110, 4.0                      ; d66900ad 03dadcf7
	v_dual_mul_f32 v102, v102, v158 :: v_dual_fmaak_f32 v155, v155, v156, 0x3f650000 ; c8c33d66 669b399b 3f650000
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694032
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[54:55], v[16:17], v[112:119] ; cc464070 1dc22136
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_fma_mix_f32 v168, 0xab28, |v167|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a8 0bff4eff 3728ab28
	v_maxmin_num_f32 v171, -4.0, v109, 4.0                      ; d66900ab 03dadaf7
	v_fma_mix_f32 v170, 0xab28, |v169|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062aa 0bff52ff 3728ab28
	v_dual_fmaak_f32 v166, v166, v165, 0x3f650000 :: v_dual_mul_f32 v103, v103, v160 ; c8474ba6 a6674167 3f650000
	v_fma_mix_f32 v174, 0xab28, |v173|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ae 0bff5aff 3728ab28
	v_dual_mul_f32 v104, v104, v161 :: v_dual_mul_f32 v101, v101, v155 ; c8c74368 68653765
	v_maxmin_num_f32 v175, -4.0, v111, 4.0                      ; d66900af 03dadef7
	v_fma_mix_f32 v172, 0xab28, |v171|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ac 0bff56ff 3728ab28
	v_dual_fmaak_f32 v168, v168, v167, 0x3f650000 :: v_dual_fmaak_f32 v169, v169, v170, 0x3f650000 ; c8434fa8 a8a955a9 3f650000
	v_dual_mul_f32 v106, v106, v166 :: v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 ; c8c34d6a 6aa349a3 3f650000
	v_maxmin_num_f32 v177, -4.0, v112, 4.0                      ; d66900b1 03dae0f7
	v_maxmin_num_f32 v181, -4.0, v114, 4.0                      ; d66900b5 03dae4f7
(invalid instruction)                                        ; d7690033
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694033
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	v_maxmin_num_f32 v179, -4.0, v113, 4.0                      ; d66900b3 03dae2f7
	v_fma_mix_f32 v176, 0xab28, |v175|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b0 0bff5eff 3728ab28
	v_dual_fmaak_f32 v174, v174, v173, 0x3f650000 :: v_dual_mul_f32 v107, v107, v168 ; c8475bae ae6b516b 3f650000
	v_dual_mul_f32 v108, v108, v169 :: v_dual_mul_f32 v105, v105, v163 ; c8c7536c 6c694769
	v_maxmin_num_f32 v183, -4.0, v115, 4.0                      ; d66900b7 03dae6f7
	v_fma_mix_f32 v178, 0xab28, |v177|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b2 0bff62ff 3728ab28
	v_maxmin_num_f32 v185, -4.0, v116, 4.0                      ; d66900b9 03dae8f7
	v_fma_mix_f32 v182, 0xab28, |v181|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b6 0bff6aff 3728ab28
	v_fma_mix_f32 v180, 0xab28, |v179|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b4 0bff66ff 3728ab28
	v_maxmin_num_f32 v189, -4.0, v118, 4.0                      ; d66900bd 03daecf7
	v_dual_mul_f32 v110, v110, v174 :: v_dual_fmaak_f32 v171, v171, v172, 0x3f650000 ; c8c35d6e 6eab59ab 3f650000
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_fma_mix_f32 v184, 0xab28, |v183|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b8 0bff6eff 3728ab28
	v_dual_fmaak_f32 v176, v176, v175, 0x3f650000 :: v_dual_fmaak_f32 v177, v177, v178, 0x3f650000 ; c8435fb0 b0b165b1 3f650000
	v_maxmin_num_f32 v5, -4.0, v120, 4.0                        ; d6690005 03daf0f7
	v_fma_mix_f32 v186, 0xab28, |v185|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ba 0bff72ff 3728ab28
	v_maxmin_num_f32 v187, -4.0, v117, 4.0                      ; d66900bb 03daeaf7
	v_fma_mix_f32 v190, 0xab28, |v189|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062be 0bff7aff 3728ab28
	v_maxmin_num_f32 v26, -4.0, v121, 4.0                       ; d669001a 03daf2f7
	v_dual_fmaak_f32 v182, v182, v181, 0x3f650000 :: v_dual_mul_f32 v111, v111, v176 ; c8476bb6 b66f616f 3f650000
	v_dual_mul_f32 v112, v112, v177 :: v_dual_mul_f32 v109, v109, v171 ; c8c76370 706d576d
	v_fma_mix_f32 v25, 0xab28, |v5|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206219 0bfe0aff 3728ab28
	v_dual_fmaak_f32 v184, v184, v183, 0x3f650000 :: v_dual_fmaak_f32 v185, v185, v186, 0x3f650000 ; c8436fb8 b8b975b9 3f650000
	v_maxmin_num_f32 v191, -4.0, v119, 4.0                      ; d66900bf 03daeef7
	v_fma_mix_f32 v188, 0xab28, |v187|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bc 0bff76ff 3728ab28
	v_maxmin_num_f32 v97, -4.0, v122, 4.0                       ; d6690061 03daf4f7
	v_fma_mix_f32 v96, 0xab28, |v26|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206260 0bfe34ff 3728ab28
	v_dual_mul_f32 v114, v114, v182 :: v_dual_fmaak_f32 v179, v179, v180, 0x3f650000 ; c8c36d72 72b369b3 3f650000
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_dual_fmaak_f32 v190, v190, v189, 0x3f650000 :: v_dual_mul_f32 v115, v115, v184 ; c8477bbe be737173 3f650000
	v_maxmin_num_f32 v99, -4.0, v123, 4.0                       ; d6690063 03daf6f7
	v_fma_mix_f32 v1, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206201 0bff7eff 3728ab28
	v_maxmin_num_f32 v101, -4.0, v124, 4.0                      ; d6690065 03daf8f7
	v_fma_mix_f32 v98, 0xab28, |v97|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206262 0bfec2ff 3728ab28
	v_dual_mul_f32 v116, v116, v185 :: v_dual_mul_f32 v113, v113, v179 ; c8c77374 74716771
	v_maxmin_num_f32 v105, -4.0, v126, 4.0                      ; d6690069 03dafcf7
	v_dual_mul_f32 v118, v118, v190 :: v_dual_fmaak_f32 v5, v5, v25, 0x3f650000 ; c8c37d76 76043305 3f650000
	v_fma_mix_f32 v100, 0xab28, |v99|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206264 0bfec6ff 3728ab28
	v_maxmin_num_f32 v103, -4.0, v125, 4.0                      ; d6690067 03dafaf7
	v_fma_mix_f32 v102, 0xab28, |v101|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206266 0bfecaff 3728ab28
	v_dual_fmaak_f32 v98, v98, v97, 0x3f650000 :: v_dual_fmaak_f32 v1, v1, v191, 0x3f650000 ; c842c362 62017f01 3f650000
	v_maxmin_num_f32 v107, -4.0, v127, 4.0                      ; d669006b 03dafef7
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v106, 0xab28, |v105|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626a 0bfed2ff 3728ab28
	v_dual_mul_f32 v120, v120, v5 :: v_dual_fmaak_f32 v187, v187, v188, 0x3f650000 ; c8c20b78 78bb79bb 3f650000
	v_fma_mix_f32 v104, 0xab28, |v103|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206268 0bfeceff 3728ab28
	v_dual_fmaak_f32 v100, v100, v99, 0x3f650000 :: v_dual_fmaak_f32 v101, v101, v102, 0x3f650000 ; c842c764 6464cd65 3f650000
	v_dual_mul_f32 v122, v122, v98 :: v_dual_mul_f32 v119, v119, v1 ; c8c6c57a 7a760377
	v_fma_mix_f32 v108, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626c 0bfed6ff 3728ab28
	v_dual_fmaak_f32 v26, v26, v96, 0x3f650000 :: v_dual_mul_f32 v117, v117, v187 ; c846c11a 1a757775 3f650000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_dual_fmaak_f32 v106, v106, v105, 0x3f650000 :: v_dual_mul_f32 v123, v123, v100 ; c846d36a 6a7ac97b 3f650000
	v_dual_fmaak_f32 v108, v108, v107, 0x3f650000 :: v_dual_fmaak_f32 v103, v103, v104, 0x3f650000 ; c842d76c 6c66d167 3f650000
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_mul_f32 v124, v124, v101 :: v_dual_mul_f32 v121, v121, v26 ; c8c6cb7c 7c783579
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870114
	v_dual_mul_f32 v127, v127, v108 :: v_dual_mul_f32 v126, v126, v106 ; c8c6d97f 7f7ed57e
(invalid instruction)                                        ; d7690060
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d7694060
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[88:89], v[84:85], 0 ; cc464068 1a02a958
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[88:89], v[8:9], 0 ; cc464070 1a021158
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[88:89], v[12:13], 0 ; cc464080 1a021958
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[92:93], v[14:15], v[104:111] ; cc464068 1da21d5c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_maxmin_num_f32 v140, -4.0, v106, 4.0                      ; d669008c 03dad4f7
	v_maxmin_num_f32 v144, -4.0, v108, 4.0                      ; d6690090 03dad8f7
	v_maxmin_num_f32 v136, -4.0, v104, 4.0                      ; d6690088 03dad0f7
	v_maxmin_num_f32 v138, -4.0, v105, 4.0                      ; d669008a 03dad2f7
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[92:93], v[86:87], v[112:119] ; cc464070 1dc2ad5c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[92:93], v[18:19], v[128:135] ; cc464080 1e02255c
	v_maxmin_num_f32 v142, -4.0, v107, 4.0                      ; d669008e 03dad6f7
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v137, 0xab28, |v136|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206289 0bff10ff 3728ab28
	v_fma_mix_f32 v139, 0xab28, |v138|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628b 0bff14ff 3728ab28
	v_maxmin_num_f32 v146, -4.0, v109, 4.0                      ; d6690092 03dadaf7
	v_maxmin_num_f32 v148, -4.0, v110, 4.0                      ; d6690094 03dadcf7
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v152, -4.0, v112, 4.0                      ; d6690098 03dae0f7
	v_fmaak_f32 v136, v136, v137, 0x3f650000                    ; 5b111388 3f650000
	v_dual_fmaak_f32 v138, v138, v139, 0x3f650000 :: v_dual_fmaak_f32 v141, v141, v140, 0x3f650000 ; c843178a 8a8d198d 3f650000
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_maxmin_num_f32 v150, -4.0, v111, 4.0                      ; d6690096 03dadef7
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_dual_mul_f32 v104, v104, v136 :: v_dual_mul_f32 v125, v125, v103 ; c8c71168 687ccf7d
	v_maxmin_num_f32 v154, -4.0, v113, 4.0                      ; d669009a 03dae2f7
	v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 :: v_dual_mul_f32 v105, v105, v138 ; c8472390 90691569 3f650000
	v_mul_f32_e32 v106, v106, v141                              ; 10d51b6a
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v114, 4.0                      ; d669009c 03dae4f7
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c8432792 92952995 3f650000
(invalid instruction)                                        ; d7690061
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694061
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[88:89], v[10:11], 0 ; cc464078 1a021558
	v_maxmin_num_f32 v160, -4.0, v116, 4.0                      ; d66900a0 03dae8f7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_mul_f32 v108, v108, v144 :: v_dual_fmaak_f32 v143, v143, v142, 0x3f650000 ; c8c3216c 6c8f1d8f 3f650000
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 :: v_dual_mul_f32 v109, v109, v146 ; c8473398 986d256d 3f650000
	v_maxmin_num_f32 v158, -4.0, v115, 4.0                      ; d669009e 03dae6f7
	v_maxmin_num_f32 v162, -4.0, v117, 4.0                      ; d66900a2 03daeaf7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v164, -4.0, v118, 4.0                      ; d66900a4 03daecf7
	v_dual_mul_f32 v110, v110, v149 :: v_dual_mul_f32 v107, v107, v143 ; c8c72b6e 6e6b1f6b
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c843379a 9a9d399d 3f650000
(invalid instruction)                                        ; d7690059
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	v_dual_mul_f32 v112, v112, v152 :: v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 ; c8c33170 70972d97 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[92:93], v[16:17], v[120:127] ; cc464078 1de2215c
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
(invalid instruction)                                        ; d7694058
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 :: v_dual_mul_f32 v113, v113, v154 ; c84743a0 a0713571 3f650000
	v_dual_mul_f32 v114, v114, v157 :: v_dual_mul_f32 v111, v111, v151 ; c8c73b72 726f2f6f
	v_maxmin_num_f32 v166, -4.0, v119, 4.0                      ; d66900a6 03daeef7
	v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 ; c84347a2 a2a549a5 3f650000
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_dual_mul_f32 v116, v116, v160 :: v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 ; c8c34174 749f3d9f 3f650000
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694059
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v170, -4.0, v121, 4.0                      ; d66900aa 03daf2f7
	v_maxmin_num_f32 v172, -4.0, v122, 4.0                      ; d66900ac 03daf4f7
	v_maxmin_num_f32 v168, -4.0, v120, 4.0                      ; d66900a8 03daf0f7
	v_maxmin_num_f32 v176, -4.0, v124, 4.0                      ; d66900b0 03daf8f7
	v_dual_mul_f32 v118, v118, v165 :: v_dual_mul_f32 v115, v115, v159 ; c8c74b76 76733f73
	v_maxmin_num_f32 v174, -4.0, v123, 4.0                      ; d66900ae 03daf6f7
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_maxmin_num_f32 v178, -4.0, v125, 4.0                      ; d66900b2 03dafaf7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v126, 4.0                      ; d66900b4 03dafcf7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v127, 4.0                      ; d66900b6 03dafef7
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 ; c84357aa aaad59ad 3f650000
	v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 :: v_dual_mul_f32 v117, v117, v162 ; c84753a8 a8754575 3f650000
	v_maxmin_num_f32 v184, -4.0, v128, 4.0                      ; d66900b8 03db00f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_maxmin_num_f32 v186, -4.0, v129, 4.0                      ; d66900ba 03db02f7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 :: v_dual_mul_f32 v121, v121, v170 ; c84763b0 b0795579 3f650000
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_dual_mul_f32 v120, v120, v168 :: v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 ; c8c35178 78a74da7 3f650000
	buffer_load_b128 v[100:103], v24, s[28:31], null offen offset:3072 ; c405c07c 40803864 000c0018
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 ; c84367b2 b2b569b5 3f650000
	v_maxmin_num_f32 v188, -4.0, v130, 4.0                      ; d66900bc 03db04f7
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_mul_f32 v124, v124, v176 :: v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 ; c8c3617c 7caf5daf 3f650000
	buffer_load_b128 v[108:111], v24, s[28:31], null offen offset:3584 ; c405c07c 4080386c 000e0018
(invalid instruction)                                        ; d7690062
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_dual_mul_f32 v122, v122, v173 :: v_dual_mul_f32 v119, v119, v167 ; c8c75b7a 7a774f77
	v_maxmin_num_f32 v190, -4.0, v131, 4.0                      ; d66900be 03db06f7
	v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 :: v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 ; c84373b8 b8b76db7 3f650000
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 :: v_dual_mul_f32 v125, v125, v178 ; c84777ba ba7d657d 3f650000
	v_dual_mul_f32 v126, v126, v181 :: v_dual_mul_f32 v123, v123, v175 ; c8c76b7e 7e7b5f7b
	v_maxmin_num_f32 v5, -4.0, v133, 4.0                        ; d6690005 03db0af7
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_maxmin_num_f32 v25, -4.0, v134, 4.0                       ; d6690019 03db0cf7
	v_dual_mul_f32 v128, v128, v184 :: v_dual_mul_f32 v127, v127, v183 ; c8c77180 807f6f7f
	v_fmaak_f32 v189, v189, v188, 0x3f650000                    ; 5b7b79bd 3f650000
(invalid instruction)                                        ; d7690063
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
(invalid instruction)                                        ; d7694062
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v106, -4.0, v135, 4.0                      ; d669006a 03db0ef7
	v_fma_mix_f32 v24, 0xab28, |v5|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206218 0bfe0aff 3728ab28
	v_fmaak_f32 v191, v191, v190, 0x3f650000                    ; 5b7f7dbf 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[90:91], v[84:85], 0 ; cc464070 1a02a95a
	v_fma_mix_f32 v26, 0xab28, |v25|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe32ff 3728ab28
(invalid instruction)                                        ; d7694063
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_dual_mul_f32 v129, v129, v186 :: v_dual_mul_f32 v130, v130, v189 ; c8c77581 81837b82
	v_fma_mix_f32 v107, 0xab28, |v106|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626b 0bfed4ff 3728ab28
	v_mul_f32_e32 v131, v131, v191                              ; 11077f83
	v_maxmin_num_f32 v191, -4.0, v132, 4.0                      ; d66900bf 03db08f7
	v_dual_fmaak_f32 v5, v5, v24, 0x3f650000 :: v_dual_fmaak_f32 v26, v26, v25, 0x3f650000 ; c8423105 051a331a 3f650000
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fma_mix_f32 v1, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206201 0bff7eff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[94:95], v[14:15], v[112:119] ; cc464070 1dc21d5e
	v_fmaak_f32 v191, v191, v1, 0x3f650000                      ; 5b7e03bf 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[90:91], v[8:9], 0 ; cc464078 1a02115a
	v_dual_mul_f32 v133, v133, v5 :: v_dual_mul_f32 v132, v132, v191 ; c8c60b85 85857f84
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[90:91], v[12:13], 0 ; cc464088 1a02195a
	v_maxmin_num_f32 v146, -4.0, v113, 4.0                      ; d6690092 03dae2f7
	v_maxmin_num_f32 v144, -4.0, v112, 4.0                      ; d6690090 03dae0f7
	v_maxmin_num_f32 v150, -4.0, v115, 4.0                      ; d6690096 03dae6f7
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v148, -4.0, v114, 4.0                      ; d6690094 03dae4f7
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[94:95], v[86:87], v[120:127] ; cc464078 1de2ad5e
	v_maxmin_num_f32 v154, -4.0, v117, 4.0                      ; d669009a 03daeaf7
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[94:95], v[18:19], v[136:143] ; cc464088 1e22255e
	v_maxmin_num_f32 v152, -4.0, v116, 4.0                      ; d6690098 03dae8f7
	v_maxmin_num_f32 v158, -4.0, v119, 4.0                      ; d669009e 03daeef7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_fmaak_f32 v107, v107, v106, 0x3f650000 ; c8432792 926ad56b 3f650000
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8432d97 97912390 3f650000
	v_maxmin_num_f32 v156, -4.0, v118, 4.0                      ; d669009c 03daecf7
	v_maxmin_num_f32 v162, -4.0, v121, 4.0                      ; d66900a2 03daf2f7
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c843379a 9a952995 3f650000
	v_mul_f32_e32 v113, v113, v146                              ; 10e32571
	v_dual_mul_f32 v135, v135, v107 :: v_dual_mul_f32 v134, v134, v26 ; c8c6d787 87863586
	v_dual_mul_f32 v115, v115, v151 :: v_dual_mul_f32 v112, v112, v144 ; c8c72f73 73712170
	v_maxmin_num_f32 v160, -4.0, v120, 4.0                      ; d66900a0 03daf0f7
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_maxmin_num_f32 v166, -4.0, v123, 4.0                      ; d66900a6 03daf6f7
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c8433d9f 9f993398 3f650000
	v_dual_mul_f32 v117, v117, v154 :: v_dual_mul_f32 v114, v114, v149 ; c8c73575 75732b72
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[90:91], v[10:11], 0 ; cc464080 1a02155a
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
	v_maxmin_num_f32 v164, -4.0, v122, 4.0                      ; d66900a4 03daf4f7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_maxmin_num_f32 v170, -4.0, v125, 4.0                      ; d66900aa 03dafaf7
	v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 :: v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 ; c84347a2 a29d399d 3f650000
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_dual_mul_f32 v119, v119, v159 :: v_dual_mul_f32 v116, v116, v152 ; c8c73f77 77753174
(invalid instruction)                                        ; d7694018
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_maxmin_num_f32 v168, -4.0, v124, 4.0                      ; d66900a8 03daf8f7
	v_maxmin_num_f32 v174, -4.0, v127, 4.0                      ; d66900ae 03dafef7
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_dual_mul_f32 v121, v121, v162 :: v_dual_mul_f32 v118, v118, v157 ; c8c74579 79773b76
	v_maxmin_num_f32 v172, -4.0, v126, 4.0                      ; d66900ac 03dafcf7
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c8434da7 a7a143a0 3f650000
(invalid instruction)                                        ; d7690019
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[94:95], v[16:17], v[128:135] ; cc464080 1e02215e
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 :: v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 ; c84357aa aaa549a5 3f650000
(invalid instruction)                                        ; d7694019
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_mul_f32 v123, v123, v167 :: v_dual_mul_f32 v120, v120, v160 ; c8c74f7b 7b794178
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c8435daf afa953a8 3f650000
	v_dual_mul_f32 v125, v125, v170 :: v_dual_mul_f32 v122, v122, v165 ; c8c7557d 7d7b4b7a
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	v_maxmin_num_f32 v180, -4.0, v130, 4.0                      ; d66900b4 03db04f7
	v_maxmin_num_f32 v182, -4.0, v131, 4.0                      ; d66900b6 03db06f7
	v_maxmin_num_f32 v176, -4.0, v128, 4.0                      ; d66900b0 03db00f7
	v_maxmin_num_f32 v178, -4.0, v129, 4.0                      ; d66900b2 03db02f7
	v_dual_mul_f32 v127, v127, v175 :: v_dual_mul_f32 v124, v124, v168 ; c8c75f7f 7f7d517c
	v_maxmin_num_f32 v184, -4.0, v132, 4.0                      ; d66900b8 03db08f7
(invalid instruction)                                        ; d769405a
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_maxmin_num_f32 v188, -4.0, v134, 4.0                      ; d66900bc 03db0cf7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_maxmin_num_f32 v186, -4.0, v133, 4.0                      ; d66900ba 03db0af7
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	v_maxmin_num_f32 v190, -4.0, v135, 4.0                      ; d66900be 03db0ef7
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c84369b5 b5b163b0 3f650000
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 ; c84367b2 b2ad59ad 3f650000
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_maxmin_num_f32 v5, -4.0, v137, 4.0                        ; d6690005 03db12f7
	v_dual_fmaak_f32 v189, v189, v188, 0x3f650000 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c84379bd bdb973b8 3f650000
	v_maxmin_num_f32 v107, -4.0, v138, 4.0                      ; d669006b 03db14f7
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_mul_f32 v128, v128, v176 ; c8476db7 b7816180 3f650000
	v_dual_mul_f32 v129, v129, v178 :: v_dual_mul_f32 v126, v126, v173 ; c8c76581 817f5b7e
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8437dbf bfbb77ba 3f650000
	v_fma_mix_f32 v26, 0xab28, |v5|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe0aff 3728ab28
	v_maxmin_num_f32 v113, -4.0, v139, 4.0                      ; d6690071 03db16f7
	v_fma_mix_f32 v112, 0xab28, |v107|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206270 0bfed6ff 3728ab28
	v_maxmin_num_f32 v115, -4.0, v140, 4.0                      ; d6690073 03db18f7
	v_dual_mul_f32 v131, v131, v183 :: v_dual_mul_f32 v130, v130, v181 ; c8c76f83 83836b82
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769405b
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_maxmin_num_f32 v117, -4.0, v141, 4.0                      ; d6690075 03db1af7
	v_dual_mul_f32 v135, v135, v191 :: v_dual_mul_f32 v132, v132, v184 ; c8c77f87 87857184
	v_maxmin_num_f32 v191, -4.0, v136, 4.0                      ; d66900bf 03db10f7
	v_fma_mix_f32 v114, 0xab28, |v113|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206272 0bfee2ff 3728ab28
	v_dual_fmaak_f32 v5, v5, v26, 0x3f650000 :: v_dual_fmaak_f32 v112, v112, v107, 0x3f650000 ; c8423505 0570d770 3f650000
	v_maxmin_num_f32 v119, -4.0, v142, 4.0                      ; d6690077 03db1cf7
	v_fma_mix_f32 v116, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206274 0bfee6ff 3728ab28
(invalid instruction)                                        ; d769405e
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v121, -4.0, v143, 4.0                      ; d6690079 03db1ef7
	v_fma_mix_f32 v118, 0xab28, |v117|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206276 0bfeeaff 3728ab28
	v_fma_mix_f32 v1, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206201 0bff7eff 3728ab28
	v_dual_mul_f32 v137, v137, v5 :: v_dual_mul_f32 v138, v138, v112 ; c8c60b89 898ae18a
	v_fma_mix_f32 v120, 0xab28, |v119|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206278 0bfeeeff 3728ab28
	v_dual_fmaak_f32 v115, v115, v116, 0x3f650000 :: v_dual_fmaak_f32 v114, v114, v113, 0x3f650000 ; c842e973 7372e372 3f650000
	v_fma_mix_f32 v122, 0xab28, |v121|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627a 0bfef2ff 3728ab28
	v_dual_fmaak_f32 v191, v1, v191, 0x3f650000 :: v_dual_mul_f32 v134, v134, v189 ; c8477f01 bf877b86 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b3
	v_dual_fmaak_f32 v117, v117, v118, 0x3f650000 :: v_dual_mul_f32 v140, v140, v115 ; c846ed75 758ce78c 3f650000
	v_dual_fmaak_f32 v122, v122, v121, 0x3f650000 :: v_dual_mul_f32 v139, v139, v114 ; c846f37a 7a8ae58b 3f650000
	v_dual_mul_f32 v133, v133, v186 :: v_dual_mul_f32 v136, v136, v191 ; c8c77585 85897f88
	v_dual_fmaak_f32 v120, v120, v119, 0x3f650000 :: v_dual_mul_f32 v141, v141, v117 ; c846ef78 788ceb8d 3f650000
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
(invalid instruction)                                        ; d769006a
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d769406a
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d769005f
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769405f
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769006b
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[100:101], v[84:85], 0 ; cc464070 1a02a964
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[100:101], v[10:11], 0 ; cc464080 1a021564
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[108:109], v[14:15], v[112:119] ; cc464070 1dc21d6c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_maxmin_num_f32 v154, -4.0, v117, 4.0                      ; d669009a 03daeaf7
	v_maxmin_num_f32 v150, -4.0, v115, 4.0                      ; d6690096 03dae6f7
	v_maxmin_num_f32 v146, -4.0, v113, 4.0                      ; d6690092 03dae2f7
	v_maxmin_num_f32 v148, -4.0, v114, 4.0                      ; d6690094 03dae4f7
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[108:109], v[16:17], v[128:135] ; cc464080 1e02216c
	v_maxmin_num_f32 v144, -4.0, v112, 4.0                      ; d6690090 03dae0f7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v156, -4.0, v118, 4.0                      ; d669009c 03daecf7
	v_maxmin_num_f32 v158, -4.0, v119, 4.0                      ; d669009e 03daeef7
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_dual_fmaak_f32 v151, v151, v150, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c8432d97 979b379a 3f650000
	v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 :: v_dual_mul_f32 v143, v143, v122 ; c8472792 928ef58f 3f650000
	v_dual_mul_f32 v142, v120, v142 :: v_dual_fmaak_f32 v149, v149, v148, 0x3f650000 ; c8c31d78 8e952995 3f650000
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[100:101], v[8:9], 0 ; cc464078 1a021164
	v_fma_mix_f32 v157, 0xab28, |v156|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629d 0bff38ff 3728ab28
	v_fma_mix_f32 v159, 0xab28, |v158|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629f 0bff3cff 3728ab28
	v_dual_mul_f32 v115, v115, v151 :: v_dual_fmaak_f32 v144, v144, v145, 0x3f650000 ; c8c32f73 73912390 3f650000
	v_mul_f32_e32 v113, v113, v146                              ; 10e32571
(invalid instruction)                                        ; d769406b
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[100:101], v[12:13], 0 ; cc464088 1a021964
	v_maxmin_num_f32 v152, -4.0, v116, 4.0                      ; d6690098 03dae8f7
	v_dual_fmaak_f32 v157, v157, v156, 0x3f650000 :: v_dual_mul_f32 v114, v114, v149 ; c847399d 9d732b72 3f650000
	v_dual_mul_f32 v117, v117, v154 :: v_dual_mul_f32 v112, v112, v144 ; c8c73575 75712170
	v_wmma_f32_16x16x16_fp8_fp8 v[120:127], v[108:109], v[86:87], v[120:127] ; cc464078 1de2ad6c
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694064
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[108:109], v[18:19], v[136:143] ; cc464088 1e22256c
	v_maxmin_num_f32 v160, -4.0, v120, 4.0                      ; d66900a0 03daf0f7
	v_maxmin_num_f32 v170, -4.0, v125, 4.0                      ; d66900aa 03dafaf7
	v_maxmin_num_f32 v166, -4.0, v123, 4.0                      ; d66900a6 03daf6f7
	v_maxmin_num_f32 v162, -4.0, v121, 4.0                      ; d66900a2 03daf2f7
	v_maxmin_num_f32 v164, -4.0, v122, 4.0                      ; d66900a4 03daf4f7
	v_maxmin_num_f32 v172, -4.0, v126, 4.0                      ; d66900ac 03dafcf7
	v_fma_mix_f32 v161, 0xab28, |v160|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a1 0bff40ff 3728ab28
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
	v_fma_mix_f32 v167, 0xab28, |v166|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a7 0bff4cff 3728ab28
	v_maxmin_num_f32 v174, -4.0, v127, 4.0                      ; d66900ae 03dafef7
	v_fma_mix_f32 v163, 0xab28, |v162|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a3 0bff44ff 3728ab28
	v_fma_mix_f32 v165, 0xab28, |v164|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a5 0bff48ff 3728ab28
	v_maxmin_num_f32 v178, -4.0, v129, 4.0                      ; d66900b2 03db02f7
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_dual_fmaak_f32 v167, v167, v166, 0x3f650000 :: v_dual_fmaak_f32 v170, v170, v171, 0x3f650000 ; c8434da7 a7ab57aa 3f650000
	v_maxmin_num_f32 v168, -4.0, v124, 4.0                      ; d66900a8 03daf8f7
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_dual_fmaak_f32 v159, v159, v158, 0x3f650000 :: v_dual_fmaak_f32 v162, v162, v163, 0x3f650000 ; c8433d9f 9fa347a2 3f650000
	v_dual_fmaak_f32 v165, v165, v164, 0x3f650000 :: v_dual_mul_f32 v118, v118, v157 ; c84749a5 a5773b76 3f650000
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v130, 4.0                      ; d66900b4 03db04f7
	v_dual_mul_f32 v123, v123, v167 :: v_dual_fmaak_f32 v160, v160, v161, 0x3f650000 ; c8c34f7b 7ba143a0 3f650000
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_maxmin_num_f32 v182, -4.0, v131, 4.0                      ; d66900b6 03db06f7
	v_dual_mul_f32 v119, v119, v159 :: v_dual_fmaak_f32 v152, v152, v153, 0x3f650000 ; c8c33f77 77993398 3f650000
	v_maxmin_num_f32 v186, -4.0, v133, 4.0                      ; d66900ba 03db0af7
	v_dual_fmaak_f32 v173, v173, v172, 0x3f650000 :: v_dual_mul_f32 v122, v122, v165 ; c84759ad ad7b4b7a 3f650000
	v_dual_fmaak_f32 v175, v175, v174, 0x3f650000 :: v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 ; c8435daf afb367b2 3f650000
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_dual_mul_f32 v125, v125, v170 :: v_dual_mul_f32 v120, v120, v160 ; c8c7557d 7d794178
	v_maxmin_num_f32 v176, -4.0, v128, 4.0                      ; d66900b0 03db00f7
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_dual_mul_f32 v121, v121, v162 :: v_dual_mul_f32 v116, v116, v152 ; c8c74579 79753174
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	v_maxmin_num_f32 v188, -4.0, v134, 4.0                      ; d66900bc 03db0cf7
	v_dual_mul_f32 v127, v127, v175 :: v_dual_fmaak_f32 v168, v168, v169, 0x3f650000 ; c8c35f7f 7fa953a8 3f650000
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v126, v126, v173 ; c84769b5 b57f5b7e 3f650000
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_maxmin_num_f32 v190, -4.0, v135, 4.0                      ; d66900be 03db0ef7
(invalid instruction)                                        ; d7690065
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694065
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d769006c
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
(invalid instruction)                                        ; d769406c
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8436db7 b7bb77ba 3f650000
	v_maxmin_num_f32 v184, -4.0, v132, 4.0                      ; d66900b8 03db08f7
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_dual_mul_f32 v129, v129, v178 :: v_dual_mul_f32 v124, v124, v168 ; c8c76581 817d517c
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_maxmin_num_f32 v5, -4.0, v137, 4.0                        ; d6690005 03db12f7
	v_dual_mul_f32 v131, v131, v183 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c8c36f83 83b163b0 3f650000
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fmaak_f32 v189, v189, v188, 0x3f650000                    ; 5b7b79bd 3f650000
(invalid instruction)                                        ; d769006d
	v_cndmask_b32_e32 v1, v124, v125, vcc_lo                    ; 0202fb7c
	s_load_b128 s[16:19], s[0:1], 0x30                          ; f4004400 f8000030
(invalid instruction)                                        ; d769406d
	v_cndmask_b32_e32 v1, v126, v127, vcc_lo                    ; 0202ff7e
	v_add_lshl_u32 v114, s8, v4, 2                              ; d6470072 020a0808
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b128 v[116:119], v114, s[16:19], null offen     ; c405c07c 40802074 00000072
	v_dual_fmaak_f32 v191, v191, v190, 0x3f650000 :: v_dual_mul_f32 v130, v130, v181 ; c8477dbf bf836b82 3f650000
	v_fma_mix_f32 v26, 0xab28, |v5|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe0aff 3728ab28
	v_dual_mul_f32 v133, v133, v186 :: v_dual_mul_f32 v128, v128, v176 ; c8c77585 85816180
	v_maxmin_num_f32 v115, -4.0, v138, 4.0                      ; d6690073 03db14f7
	buffer_load_b128 v[124:127], v114, s[16:19], null offen offset:16 ; c405c07c 4080207c 00001072
	v_maxmin_num_f32 v122, -4.0, v139, 4.0                      ; d669007a 03db16f7
	v_dual_mul_f32 v135, v135, v191 :: v_dual_fmaak_f32 v184, v184, v185, 0x3f650000 ; c8c37f87 87b973b8 3f650000
	v_maxmin_num_f32 v191, -4.0, v136, 4.0                      ; d66900bf 03db10f7
	v_dual_fmaak_f32 v5, v5, v26, 0x3f650000 :: v_dual_mul_f32 v134, v134, v189 ; c8463505 05877b86 3f650000
(invalid instruction)                                        ; d7690070
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694070
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_maxmin_num_f32 v130, -4.0, v141, 4.0                      ; d6690082 03db1af7
	v_fma_mix_f32 v121, 0xab28, |v115|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206279 0bfee6ff 3728ab28
	v_maxmin_num_f32 v128, -4.0, v140, 4.0                      ; d6690080 03db18f7
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_fma_mix_f32 v1, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206201 0bff7eff 3728ab28
	v_fma_mix_f32 v131, 0xab28, |v130|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206283 0bff04ff 3728ab28
	v_fmaak_f32 v121, v121, v115, 0x3f650000                    ; 5af2e779 3f650000
	v_fma_mix_f32 v129, 0xab28, |v128|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206281 0bff00ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
	v_dual_fmaak_f32 v191, v191, v1, 0x3f650000 :: v_dual_mul_f32 v132, v132, v184 ; c84603bf bf857184 3f650000
	v_dual_fmaak_f32 v130, v130, v131, 0x3f650000 :: v_dual_fmaak_f32 v123, v123, v122, 0x3f650000 ; c8430782 827af57b 3f650000
	v_mul_f32_e32 v138, v138, v121                              ; 1114f38a
(invalid instruction)                                        ; d7690071
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	v_maxmin_num_f32 v132, -4.0, v142, 4.0                      ; d6690084 03db1cf7
(invalid instruction)                                        ; d7694071
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_maxmin_num_f32 v134, -4.0, v143, 4.0                      ; d6690086 03db1ef7
	v_dual_mul_f32 v137, v137, v5 :: v_dual_mul_f32 v136, v136, v191 ; c8c60b89 89897f88
	v_mul_f32_e32 v141, v141, v130                              ; 111b058d
	v_mul_f32_e32 v139, v139, v123                              ; 1116f78b
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[102:103], v[10:11], 0 ; cc464090 1a021566
	s_lshr_b32 s4, s4, 2                                        ; 85048204
	v_fma_mix_f32 v133, 0xab28, |v132|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206285 0bff08ff 3728ab28
	v_fma_mix_f32 v135, 0xab28, |v134|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206287 0bff0cff 3728ab28
(invalid instruction)                                        ; d7690078
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7694078
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[102:103], v[12:13], 0 ; cc464098 1a021966
	v_add_lshl_u32 v160, s4, v0, 2                              ; d64700a0 020a0004
	v_dual_fmaak_f32 v133, v133, v132, 0x3f650000 :: v_dual_fmaak_f32 v128, v128, v129, 0x3f650000 ; c8430985 85810380 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v135, v135, v134, 0x3f650000 :: v_dual_mul_f32 v140, v140, v128 ; c8470d87 878d018c 3f650000
(invalid instruction)                                        ; d7690079
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_dual_mul_f32 v143, v143, v135 :: v_dual_mul_f32 v142, v142, v133 ; c8c70f8f 8f8f0b8e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[102:103], v[84:85], 0 ; cc464080 1a02a966
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[110:111], v[16:17], v[144:151] ; cc464090 1e42216e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[110:111], v[18:19], v[152:159] ; cc464098 1e62256e
(invalid instruction)                                        ; d7694079
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[102:103], v[8:9], 0 ; cc464088 1a021166
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[110:111], v[14:15], v[128:135] ; cc464080 1e021d6e
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[110:111], v[86:87], v[136:143] ; cc464088 1e22ad6e
	v_maxmin_num_f32 v165, -4.0, v130, 4.0                      ; d66900a5 03db04f7
	v_maxmin_num_f32 v161, -4.0, v128, 4.0                      ; d66900a1 03db00f7
	v_maxmin_num_f32 v163, -4.0, v129, 4.0                      ; d66900a3 03db02f7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
	v_fma_mix_f32 v166, 0xab28, |v165|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a6 0bff4aff 3728ab28
	v_fma_mix_f32 v162, 0xab28, |v161|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a2 0bff42ff 3728ab28
	v_fma_mix_f32 v164, 0xab28, |v163|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a4 0bff46ff 3728ab28
	v_maxmin_num_f32 v168, -4.0, v131, 4.0                      ; d66900a8 03db06f7
	v_fmaak_f32 v166, v166, v165, 0x3f650000                    ; 5b4d4ba6 3f650000
	v_fmaak_f32 v161, v161, v162, 0x3f650000                    ; 5b4345a1 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v169, 0xab28, |v168|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062a9 0bff50ff 3728ab28
	v_dual_fmaak_f32 v163, v163, v164, 0x3f650000 :: v_dual_mul_f32 v128, v128, v161 ; c84749a3 a3814380 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_fmaak_f32 v169, v169, v168, 0x3f650000                    ; 5b5351a9 3f650000
	v_dual_mul_f32 v130, v130, v166 :: v_dual_mul_f32 v129, v129, v163 ; c8c74d82 82814781
	v_maxmin_num_f32 v170, -4.0, v132, 4.0                      ; d66900aa 03db08f7
	v_mul_f32_e32 v131, v131, v169                              ; 11075383
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
	v_fma_mix_f32 v171, 0xab28, |v170|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ab 0bff54ff 3728ab28
(invalid instruction)                                        ; d7694054
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_fmaak_f32 v170, v170, v171, 0x3f650000                    ; 5b5557aa 3f650000
	v_maxmin_num_f32 v172, -4.0, v133, 4.0                      ; d66900ac 03db0af7
	v_maxmin_num_f32 v174, -4.0, v134, 4.0                      ; d66900ae 03db0cf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2) ; bf870133
	v_mul_f32_e32 v132, v132, v170                              ; 11095584
	v_fma_mix_f32 v173, 0xab28, |v172|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062ad 0bff58ff 3728ab28
	v_fma_mix_f32 v175, 0xab28, |v174|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062af 0bff5cff 3728ab28
	v_fmaak_f32 v172, v172, v173, 0x3f650000                    ; 5b595bac 3f650000
	v_maxmin_num_f32 v176, -4.0, v135, 4.0                      ; d66900b0 03db0ef7
	v_fmaak_f32 v175, v175, v174, 0x3f650000                    ; 5b5f5daf 3f650000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_dual_mul_f32 v133, v133, v172 :: v_dual_mul_f32 v134, v134, v175 ; c8c75985 85875f86
	v_fmaak_f32 v177, v177, v176, 0x3f650000                    ; 5b6361b1 3f650000
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
	v_mul_f32_e32 v135, v135, v177                              ; 110f6387
(invalid instruction)                                        ; d7694055
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[8:11], v160, s[28:31], null offen        ; c405c07c 40803808 000000a0
	buffer_load_b128 v[12:15], v160, s[28:31], null offen offset:512 ; c405c07c 4080380c 000200a0
	buffer_load_b128 v[16:19], v160, s[28:31], null offen offset:1024 ; c405c07c 40803810 000400a0
	buffer_load_b128 v[164:167], v160, s[28:31], null offen offset:1536 ; c405c07c 408038a4 000600a0
	buffer_load_b128 v[128:131], v160, s[28:31], null offen offset:2048 ; c405c07c 40803880 000800a0
	buffer_load_b128 v[168:171], v160, s[28:31], null offen offset:2560 ; c405c07c 408038a8 000a00a0
	buffer_load_b128 v[172:175], v160, s[28:31], null offen offset:3072 ; c405c07c 408038ac 000c00a0
	buffer_load_b128 v[132:135], v160, s[28:31], null offen offset:3584 ; c405c07c 40803884 000e00a0
	v_maxmin_num_f32 v180, -4.0, v137, 4.0                      ; d66900b4 03db12f7
	v_maxmin_num_f32 v178, -4.0, v136, 4.0                      ; d66900b2 03db10f7
	v_maxmin_num_f32 v182, -4.0, v138, 4.0                      ; d66900b6 03db14f7
	v_maxmin_num_f32 v184, -4.0, v139, 4.0                      ; d66900b8 03db16f7
	v_maxmin_num_f32 v188, -4.0, v141, 4.0                      ; d66900bc 03db1af7
	v_maxmin_num_f32 v186, -4.0, v140, 4.0                      ; d66900ba 03db18f7
	v_maxmin_num_f32 v190, -4.0, v142, 4.0                      ; d66900be 03db1cf7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_fma_mix_f32 v183, 0xab28, |v182|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b7 0bff6cff 3728ab28
	v_fma_mix_f32 v185, 0xab28, |v184|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b9 0bff70ff 3728ab28
	v_fma_mix_f32 v189, 0xab28, |v188|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bd 0bff78ff 3728ab28
	v_fmaak_f32 v180, v180, v181, 0x3f650000                    ; 5b696bb4 3f650000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_dual_fmaak_f32 v178, v178, v179, 0x3f650000 :: v_dual_mul_f32 v137, v137, v180 ; c84767b2 b2896989 3f650000
	v_dual_mul_f32 v136, v178, v136 :: v_dual_fmaak_f32 v183, v183, v182, 0x3f650000 ; c8c311b2 88b76db7 3f650000
	v_fma_mix_f32 v187, 0xab28, |v186|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bb 0bff74ff 3728ab28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_mul_f32 v138, v138, v183 :: v_dual_fmaak_f32 v185, v185, v184, 0x3f650000 ; c8c36f8a 8ab971b9 3f650000
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
	v_dual_fmaak_f32 v188, v189, v188, 0x3f650000 :: v_dual_mul_f32 v139, v139, v185 ; c84779bd bc8b738b 3f650000
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
(invalid instruction)                                        ; d7694056
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[136:139], v114, s[16:19], null offen offset:64 ; c405c07c 40802088 00004072
	buffer_load_b128 v[160:163], v114, s[16:19], null offen offset:80 ; c405c07c 408020a0 00005072
	v_fma_mix_f32 v191, 0xab28, |v190|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062bf 0bff7cff 3728ab28
	v_maxmin_num_f32 v5, -4.0, v144, 4.0                        ; d6690005 03db20f7
	v_maxmin_num_f32 v102, -4.0, v145, 4.0                      ; d6690066 03db22f7
	v_dual_mul_f32 v141, v141, v188 :: v_dual_fmaak_f32 v186, v186, v187, 0x3f650000 ; c8c3798d 8dbb77ba 3f650000
	v_maxmin_num_f32 v110, -4.0, v146, 4.0                      ; d669006e 03db24f7
	v_maxmin_num_f32 v114, -4.0, v147, 4.0                      ; d6690072 03db26f7
	v_fma_mix_f32 v26, 0xab28, |v5|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20621a 0bfe0aff 3728ab28
	v_fma_mix_f32 v103, 0xab28, |v102|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206267 0bfeccff 3728ab28
	v_dual_fmaak_f32 v191, v190, v191, 0x3f650000 :: v_dual_mul_f32 v140, v140, v186 ; c8477fbe bf8d758c 3f650000
	v_fma_mix_f32 v111, 0xab28, |v110|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20626f 0bfedcff 3728ab28
	v_fma_mix_f32 v115, 0xab28, |v114|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206273 0bfee4ff 3728ab28
	v_maxmin_num_f32 v122, -4.0, v148, 4.0                      ; d669007a 03db28f7
	v_dual_fmaak_f32 v102, v102, v103, 0x3f650000 :: v_dual_fmaak_f32 v5, v5, v26, 0x3f650000 ; c842cf66 66043505 3f650000
	v_mul_f32_e32 v142, v142, v191                              ; 111d7f8e
	v_maxmin_num_f32 v191, -4.0, v143, 4.0                      ; d66900bf 03db1ef7
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
	v_maxmin_num_f32 v140, -4.0, v149, 4.0                      ; d669008c 03db2af7
	v_fma_mix_f32 v123, 0xab28, |v122|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20627b 0bfef4ff 3728ab28
	v_dual_fmaak_f32 v111, v111, v110, 0x3f650000 :: v_dual_mul_f32 v144, v144, v5 ; c846dd6f 6f900b90 3f650000
	v_mul_f32_e32 v145, v145, v102                              ; 1122cd91
	v_fma_mix_f32 v1, 0xab28, |v191|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206201 0bff7eff 3728ab28
	v_fma_mix_f32 v141, 0xab28, |v140|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628d 0bff18ff 3728ab28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
	v_dual_fmaak_f32 v115, v115, v114, 0x3f650000 :: v_dual_mul_f32 v146, v146, v111 ; c846e573 7392df92 3f650000
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	v_maxmin_num_f32 v144, -4.0, v151, 4.0                      ; d6690090 03db2ef7
	v_fmaak_f32 v1, v1, v191, 0x3f650000                        ; 5a037f01 3f650000
	v_dual_fmaak_f32 v140, v140, v141, 0x3f650000 :: v_dual_mul_f32 v147, v147, v115 ; c8471b8c 8c92e793 3f650000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_fma_mix_f32 v145, 0xab28, |v144|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206291 0bff20ff 3728ab28
	v_mul_f32_e32 v143, v143, v1                                ; 111e038f
	v_dual_mul_f32 v149, v149, v140 :: v_dual_fmaak_f32 v122, v122, v123, 0x3f650000 ; c8c31995 957af77a 3f650000
(invalid instruction)                                        ; d7694066
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_maxmin_num_f32 v146, -4.0, v152, 4.0                      ; d6690092 03db30f7
(invalid instruction)                                        ; d7694057
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	v_maxmin_num_f32 v142, -4.0, v150, 4.0                      ; d669008e 03db2cf7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
	v_fma_mix_f32 v147, 0xab28, |v146|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206293 0bff24ff 3728ab28
	v_fma_mix_f32 v143, 0xab28, |v142|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20628f 0bff1cff 3728ab28
	v_maxmin_num_f32 v176, -4.0, v157, 4.0                      ; d66900b0 03db3af7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmaak_f32 v143, v142, v143, 0x3f650000 :: v_dual_mul_f32 v148, v148, v122 ; c8471f8e 8f94f594 3f650000
	v_fma_mix_f32 v177, 0xab28, |v176|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b1 0bff60ff 3728ab28
	v_dual_fmaak_f32 v145, v145, v144, 0x3f650000 :: v_dual_mul_f32 v150, v150, v143 ; c8472191 91971f96 3f650000
(invalid instruction)                                        ; d7690067
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
	v_maxmin_num_f32 v148, -4.0, v153, 4.0                      ; d6690094 03db32f7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_fma_mix_f32 v149, 0xab28, |v148|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206295 0bff28ff 3728ab28
	v_maxmin_num_f32 v178, -4.0, v158, 4.0                      ; d66900b2 03db3cf7
	v_dual_mul_f32 v151, v145, v151 :: v_dual_fmaak_f32 v148, v148, v149, 0x3f650000 ; c8c32f91 97952b94 3f650000
	v_fma_mix_f32 v179, 0xab28, |v178|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b3 0bff64ff 3728ab28
	v_maxmin_num_f32 v180, -4.0, v159, 4.0                      ; d66900b4 03db3ef7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870143
	v_dual_mul_f32 v153, v153, v148 :: v_dual_fmaak_f32 v146, v146, v147, 0x3f650000 ; c8c32999 99932792 3f650000
(invalid instruction)                                        ; d7694067
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
	v_maxmin_num_f32 v150, -4.0, v154, 4.0                      ; d6690096 03db34f7
	v_fma_mix_f32 v181, 0xab28, |v180|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc2062b5 0bff68ff 3728ab28
	v_fma_mix_f32 v151, 0xab28, |v150|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206297 0bff2cff 3728ab28
	s_mov_b64 s[32:33], s[16:17]                                ; bea00110
	s_mov_b64 s[34:35], s[18:19]                                ; bea20112
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mix_f32 v144, v6, v116, neg(0) op_sel_hi:[1,0,0]      ; cc200090 8a02e906
	v_fma_mix_f32 v145, v6, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200891 8a02eb06
	v_dual_fmaak_f32 v151, v150, v151, 0x3f650000 :: v_dual_mul_f32 v152, v152, v146 ; c8472f96 97992598 3f650000
	v_fma_mix_f32 v146, v7, v118, neg(0) op_sel_hi:[1,0,0]      ; cc200092 8a02ed07
	v_fma_mix_f32 v147, v7, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200893 8a02ef07
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_fma_mix_f32 v148, v56, v124, neg(0) op_sel_hi:[1,0,0]     ; cc200094 8a02f938
	v_fma_mix_f32 v149, v56, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200895 8a02fb38
	v_fma_mix_f32 v150, v57, v126, neg(0) op_sel_hi:[1,0,0]     ; cc200096 8a02fd39
(invalid instruction)                                        ; d769006e
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
	v_maxmin_num_f32 v152, -4.0, v155, 4.0                      ; d6690098 03db36f7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_fma_mix_f32 v153, 0xab28, |v152|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc206299 0bff30ff 3728ab28
	v_fmaak_f32 v153, v153, v152, 0x3f650000                    ; 5b333199 3f650000
	v_fma_mix_f32 v152, v62, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200098 8a02e93e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_mul_f32 v155, v153, v155 :: v_dual_fmaak_f32 v176, v176, v177, 0x3f650000 ; c8c33799 9bb163b0 3f650000
	v_fma_mix_f32 v153, v62, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a02eb3e
	v_dual_mul_f32 v157, v157, v176 :: v_dual_mul_f32 v154, v154, v151 ; c8c7619d 9d9b2f9a
	v_fma_mix_f32 v151, v57, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200897 8a02ff39
	v_fma_mix_f32 v176, v70, v116, neg(0) op_sel_hi:[1,0,0]     ; cc2000b0 8a02e946
	v_fma_mix_f32 v177, v70, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b1 8a02eb46
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a4
(invalid instruction)                                        ; d769406e
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_maxmin_num_f32 v154, -4.0, v156, 4.0                      ; d669009a 03db38f7
	v_fma_mix_f32 v155, 0xab28, |v154|, 0xab28 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc20629b 0bff34ff 3728ab28
	v_fma_mix_f32 v182, v73, v126, neg(0) op_sel_hi:[1,0,0]     ; cc2000b6 8a02fd49
	s_lshr_b32 s5, s5, 2                                        ; 85058205
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v183, s5, v0, 2                              ; d64700b7 020a0005
	v_dual_fmaak_f32 v179, v179, v178, 0x3f650000 :: v_dual_fmaak_f32 v154, v154, v155, 0x3f650000 ; c84365b3 b39b379a 3f650000
	buffer_load_b128 v[140:143], v183, s[28:31], null offen     ; c405c07c 4080388c 000000b7
	v_fma_mix_f32 v155, v63, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089b 8a02ef3f
	v_fma_mix_f32 v178, v71, v118, neg(0) op_sel_hi:[1,0,0]     ; cc2000b2 8a02ed47
	v_fma_mix_f32 v191, v73, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bf 8a02ff49
	v_fma_mix_f32 v116, v78, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200074 8a02e94e
	v_dual_fmaak_f32 v181, v181, v180, 0x3f650000 :: v_dual_mul_f32 v156, v156, v154 ; c84769b5 b59d359c 3f650000
	buffer_load_b128 v[184:187], v183, s[28:31], null offen offset:1024 ; c405c07c 408038b8 000400b7
	v_fma_mix_f32 v154, v63, v118, neg(0) op_sel_hi:[1,0,0]     ; cc20009a 8a02ed3f
	v_fma_mix_f32 v180, v72, v124, neg(0) op_sel_hi:[1,0,0]     ; cc2000b4 8a02f948
	v_fma_mix_f32 v117, v78, v117, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200875 8a02eb4e
	v_fma_mix_f32 v118, v79, v118, neg(0) op_sel_hi:[1,0,0]     ; cc200076 8a02ed4f
(invalid instruction)                                        ; d769006f
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
	v_fma_mix_f32 v156, v64, v124, neg(0) op_sel_hi:[1,0,0]     ; cc20009c 8a02f940
	v_fma_mix_f32 v157, v64, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089d 8a02fb40
	v_dual_mul_f32 v159, v159, v181 :: v_dual_mul_f32 v158, v158, v179 ; c8c76b9f 9f9f679e
	v_fma_mix_f32 v179, v71, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b3 8a02ef47
	v_fma_mix_f32 v181, v72, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b5 8a02fb48
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d769406f
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
	v_fma_mix_f32 v158, v65, v126, neg(0) op_sel_hi:[1,0,0]     ; cc20009e 8a02fd41
	v_fma_mix_f32 v159, v65, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20089f 8a02ff41
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[62:65], v183, s[28:31], null offen offset:2048 ; c405c07c 4080383e 000800b7
	buffer_load_b128 v[70:73], v183, s[28:31], null offen offset:512 ; c405c07c 40803846 000200b7
	v_fma_mix_f32 v124, v80, v124, neg(0) op_sel_hi:[1,0,0]     ; cc20007c 8a02f950
	v_fma_mix_f32 v125, v80, v125, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087d 8a02fb50
	v_fma_mix_f32 v122, v81, v126, neg(0) op_sel_hi:[1,0,0]     ; cc20007a 8a02fd51
	v_fma_mix_f32 v123, v81, v127, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087b 8a02ff51
	v_fma_mix_f32 v119, v79, v119, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a02ef4f
	v_dual_mov_b32 v7, v121 :: v_dual_mov_b32 v6, v120          ; ca100179 07060178
	v_swap_b32 v183, v191                                       ; 7f6ecbbf
	v_dual_mov_b32 v121, v125 :: v_dual_mov_b32 v120, v124      ; ca10017d 7978017c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[124:127], v191, s[28:31], null offen offset:1536 ; c405c07c 4080387c 000600bf
	buffer_load_b128 v[188:191], v191, s[28:31], null offen offset:2560 ; c405c07c 408038bc 000a00bf
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[8:9], v[22:23], v[152:159] ; cc464098 1e622d08
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[8:9], v[32:33], v[116:123] ; cc464074 1dd24108
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[8:9], v[30:31], v[176:183] ; cc4640b0 1ec23d08
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[8:9], v[20:21], v[144:151] ; cc464090 1e422908
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[12:13], v[36:37], v[152:159] ; cc464098 1e62490c
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[12:13], v[40:41], v[116:123] ; cc464074 1dd2510c
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[12:13], v[38:39], v[176:183] ; cc4640b0 1ec24d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[12:13], v[34:35], v[144:151] ; cc464090 1e42450c
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[44:45], v[152:159] ; cc464098 1e625910
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[16:17], v[48:49], v[116:123] ; cc464074 1dd26110
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[16:17], v[46:47], v[176:183] ; cc4640b0 1ec25d10
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[16:17], v[42:43], v[144:151] ; cc464090 1e425510
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[164:165], v[52:53], v[152:159] ; cc464098 1e6269a4
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[164:165], v[96:97], v[116:123] ; cc464074 1dd2c1a4
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[164:165], v[54:55], v[176:183] ; cc4640b0 1ec26da4
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[164:165], v[50:51], v[144:151] ; cc464090 1e4265a4
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[128:129], v[92:93], v[152:159] ; cc464098 1e62b980
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[128:129], v[104:105], v[116:123] ; cc464074 1dd2d180
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[128:129], v[98:99], v[176:183] ; cc4640b0 1ec2c580
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[128:129], v[88:89], v[144:151] ; cc464090 1e42b180
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[168:169], v[90:91], v[152:159] ; cc464098 1e62b5a8
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[168:169], v[106:107], v[116:123] ; cc464074 1dd2d5a8
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[168:169], v[94:95], v[176:183] ; cc4640b0 1ec2bda8
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[168:169], v[24:25], v[144:151] ; cc464090 1e4231a8
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[172:173], v[108:109], v[152:159] ; cc464098 1e62d9ac
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[172:173], v[6:7], v[116:123] ; cc464074 1dd20dac
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[172:173], v[112:113], v[176:183] ; cc4640b0 1ec2e1ac
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[172:173], v[100:101], v[144:151] ; cc464090 1e42c9ac
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[132:133], v[86:87], v[152:159] ; cc464098 1e62ad84
	v_wmma_f32_16x16x16_fp8_fp8 v[116:123], v[132:133], v[110:111], v[116:123] ; cc464074 1dd2dd84
	v_wmma_f32_16x16x16_fp8_fp8 v[176:183], v[132:133], v[102:103], v[176:183] ; cc4640b0 1ec2cd84
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[132:133], v[84:85], v[144:151] ; cc464090 1e42a984
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v120, v121, vcc_lo                    ; 0202f378
	s_load_b32 s22, s[10:11], 0x24                              ; f4000585 f8000024
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v122, v123, vcc_lo                    ; 0202f77a
	s_bitset0_b32 s33, 14                                       ; bea1108e
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s22, s22, 2                                      ; 84168216
	s_buffer_load_b32 s22, s[32:35], s22 offset:0x0             ; f4020590 2c000000
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mix_f32 v1, v58, v136, neg(0) op_sel_hi:[1,0,0]       ; cc200001 8a03113a
	v_fma_mix_f32 v58, v58, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083a 8a03133a
	v_fma_mix_f32 v5, v59, v138, neg(0) op_sel_hi:[1,0,0]       ; cc200005 8a03153b
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                    ; 020363b0
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                    ; 020367b2
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
	v_fma_mix_f32 v59, v59, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083b 8a03173b
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mix_f32 v26, v60, v160, neg(0) op_sel_hi:[1,0,0]      ; cc20001a 8a03413c
	v_fma_mix_f32 v60, v60, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083c 8a03433c
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
	v_fma_mix_f32 v78, v61, v162, neg(0) op_sel_hi:[1,0,0]      ; cc20004e 8a03453d
	v_fma_mix_f32 v128, v68, v160, neg(0) op_sel_hi:[1,0,0]     ; cc200080 8a034144
	v_fma_mix_f32 v129, v68, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a034344
	v_fma_mix_f32 v132, v69, v162, neg(0) op_sel_hi:[1,0,0]     ; cc200084 8a034545
	v_fma_mix_f32 v133, v69, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200885 8a034745
	v_fma_mix_f32 v172, v76, v160, neg(0) op_sel_hi:[1,0,0]     ; cc2000ac 8a03414c
	v_fma_mix_f32 v173, v76, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ad 8a03434c
	v_fma_mix_f32 v160, v2, v160, neg(0) op_sel_hi:[1,0,0]      ; cc2000a0 8a034102
	v_fma_mix_f32 v79, v61, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084f 8a03473d
	v_fma_mix_f32 v61, v77, v162, neg(0) op_sel_hi:[1,0,0]      ; cc20003d 8a03454d
	v_fma_mix_f32 v77, v77, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20084d 8a03474d
	v_fma_mix_f32 v161, v2, v161, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a1 8a034302
	v_fma_mix_f32 v162, v3, v162, neg(0) op_sel_hi:[1,0,0]      ; cc2000a2 8a034503
	v_fma_mix_f32 v163, v3, v163, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a3 8a034703
	v_dual_mov_b32 v3, v23 :: v_dual_mov_b32 v2, v22            ; ca100117 03020116
	v_fma_mix_f32 v80, v66, v136, neg(0) op_sel_hi:[1,0,0]      ; cc200050 8a031142
	v_fma_mix_f32 v81, v66, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200851 8a031342
	v_fma_mix_f32 v114, v67, v138, neg(0) op_sel_hi:[1,0,0]     ; cc200072 8a031543
	v_fma_mix_f32 v115, v67, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200873 8a031743
	v_dual_mov_b32 v67, v25 :: v_dual_mov_b32 v66, v24          ; ca100119 43420118
	v_dual_mov_b32 v23, v58 :: v_dual_mov_b32 v22, v1           ; ca10013a 17160101
	v_fma_mix_f32 v164, v74, v136, neg(0) op_sel_hi:[1,0,0]     ; cc2000a4 8a03114a
	v_fma_mix_f32 v165, v74, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a5 8a03134a
	v_fma_mix_f32 v168, v75, v138, neg(0) op_sel_hi:[1,0,0]     ; cc2000a8 8a03154b
	v_fma_mix_f32 v169, v75, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a03174b
	v_dual_mov_b32 v25, v59 :: v_dual_mov_b32 v24, v5           ; ca10013b 19180105
	v_fma_mix_f32 v136, v82, v136, neg(0) op_sel_hi:[1,0,0]     ; cc200088 8a031152
	v_fma_mix_f32 v137, v82, v137, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200889 8a031352
	v_fma_mix_f32 v138, v83, v138, neg(0) op_sel_hi:[1,0,0]     ; cc20008a 8a031553
	v_fma_mix_f32 v139, v83, v139, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20088b 8a031753
	v_swap_b32 v28, v78                                         ; 7e38cb4e
	v_swap_b32 v29, v79                                         ; 7e3acb4f
	v_swap_b32 v27, v60                                         ; 7e36cb3c
	v_mov_b32_e32 v58, v86                                      ; 7e740356
	v_dual_mov_b32 v86, v132 :: v_dual_mov_b32 v83, v115        ; ca100184 56520173
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_wmma_f32_16x16x16_fp8_fp8 v[22:29], v[10:11], v[20:21], v[22:29] ; cc464016 1c5a290a
	v_mov_b32_e32 v20, v84                                      ; 7e280354
	v_dual_mov_b32 v84, v128 :: v_dual_mov_b32 v59, v87         ; ca100180 543a0157
	v_dual_mov_b32 v82, v114 :: v_dual_mov_b32 v21, v85         ; ca100172 52140155
	v_dual_mov_b32 v68, v166 :: v_dual_mov_b32 v85, v129        ; ca1001a6 44540181
	v_dual_mov_b32 v166, v168 :: v_dual_mov_b32 v87, v133       ; ca1001a8 a6560185
	v_dual_mov_b32 v168, v172 :: v_dual_mov_b32 v69, v167       ; ca1001ac a84401a7
	v_swap_b32 v61, v170                                        ; 7e7acbaa
	v_swap_b32 v77, v171                                        ; 7e9acbab
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[10:11], v[2:3], v[80:87] ; cc464050 1d42050a
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_mov_b32 v2, v142 :: v_dual_mov_b32 v167, v169        ; ca10018e 02a601a9
	v_dual_mov_b32 v74, v0 :: v_dual_mov_b32 v169, v173         ; ca100100 4aa801ad
	v_dual_mov_b32 v0, v140 :: v_dual_mov_b32 v3, v143          ; ca10018c 0002018f
	v_dual_mov_b32 v140, v160 :: v_dual_mov_b32 v1, v141        ; ca1001a0 8c00018d
	v_dual_mov_b32 v142, v162 :: v_dual_mov_b32 v141, v161      ; ca1001a2 8e8c01a1
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b4
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[10:11], v[30:31], v[164:171] ; cc4640a4 1e923d0a
	v_wmma_f32_16x16x16_fp8_fp8 v[22:29], v[14:15], v[34:35], v[22:29] ; cc464016 1c5a450e
	v_dual_mov_b32 v76, v61 :: v_dual_mov_b32 v143, v163        ; ca10013d 4c8e01a3
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[10:11], v[32:33], v[136:143] ; cc464088 1e22410a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[14:15], v[36:37], v[80:87] ; cc464050 1d42490e
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[14:15], v[38:39], v[164:171] ; cc4640a4 1e924d0e
	v_wmma_f32_16x16x16_fp8_fp8 v[22:29], v[18:19], v[42:43], v[22:29] ; cc464016 1c5a5512
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[14:15], v[40:41], v[136:143] ; cc464088 1e22510e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[18:19], v[44:45], v[80:87] ; cc464050 1d425912
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[18:19], v[46:47], v[164:171] ; cc4640a4 1e925d12
	v_wmma_f32_16x16x16_fp8_fp8 v[22:29], v[68:69], v[50:51], v[22:29] ; cc464016 1c5a6544
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[18:19], v[48:49], v[136:143] ; cc464088 1e226112
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[68:69], v[52:53], v[80:87] ; cc464050 1d426944
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[68:69], v[54:55], v[164:171] ; cc4640a4 1e926d44
	v_wmma_f32_16x16x16_fp8_fp8 v[22:29], v[130:131], v[88:89], v[22:29] ; cc464016 1c5ab182
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[68:69], v[96:97], v[136:143] ; cc464088 1e22c144
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[130:131], v[92:93], v[80:87] ; cc464050 1d42b982
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[2:3], v[8:9], 0     ; cc464028 1a021102
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[130:131], v[98:99], v[164:171] ; cc4640a4 1e92c582
	v_wmma_f32_16x16x16_fp8_fp8 v[22:29], v[76:77], v[66:67], v[22:29] ; cc464016 1c5a854c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[130:131], v[104:105], v[136:143] ; cc464088 1e22d182
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[76:77], v[90:91], v[80:87] ; cc464050 1d42b54c
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[76:77], v[94:95], v[164:171] ; cc4640a4 1e92bd4c
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[186:187], v[8:9], 0 ; cc464058 1a0211ba
	v_wmma_f32_16x16x16_fp8_fp8 v[22:29], v[174:175], v[100:101], v[22:29] ; cc464016 1c5ac9ae
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[76:77], v[106:107], v[136:143] ; cc464088 1e22d54c
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[174:175], v[108:109], v[80:87] ; cc464050 1d42d9ae
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[174:175], v[112:113], v[164:171] ; cc4640a4 1e92e1ae
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[0:1], v[8:9], 0     ; cc464020 1a021100
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[184:185], v[8:9], 0 ; cc464030 1a0211b8
	v_wmma_f32_16x16x16_fp8_fp8 v[22:29], v[134:135], v[20:21], v[22:29] ; cc464016 1c5a2986
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[174:175], v[6:7], v[136:143] ; cc464088 1e220dae
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[134:135], v[58:59], v[80:87] ; cc464050 1d427586
	v_wmma_f32_16x16x16_fp8_fp8 v[164:171], v[134:135], v[102:103], v[164:171] ; cc4640a4 1e92cd86
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                      ; 0202371a
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                      ; 02023318
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
	v_wmma_f32_16x16x16_fp8_fp8 v[136:143], v[134:135], v[110:111], v[136:143] ; cc464088 1e22dd86
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[72:73], v[6:7], v[40:47] ; cc464028 1ca20d48
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[70:71], v[6:7], v[32:39] ; cc464020 1c820d46
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[124:125], v[6:7], v[48:55] ; cc464030 1cc20d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[126:127], v[6:7], v[88:95] ; cc464058 1d620d7e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v164, v165, vcc_lo                    ; 02034ba4
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v166, v167, vcc_lo                    ; 02034fa6
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                    ; 02031388
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v140, v141, vcc_lo                    ; 02031b8c
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v138, v139, vcc_lo                    ; 0203178a
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                    ; 02031f8e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[8:9], v[62:63], 0  ; cc464060 1a027d08
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[8:9], v[64:65], 0 ; cc464068 1a028108
	v_dual_mul_f32 v77, v43, v43 :: v_dual_mul_f32 v76, v89, v89 ; c8c6572b 4d4cb359
	v_dual_mul_f32 v112, v91, v91 :: v_dual_mul_f32 v75, v41, v41 ; c8c6b75b 704a5329
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[6:7], v[188:189], v[96:103] ; cc464060 1d837906
	v_dual_fmac_f32 v77, v35, v35 :: v_dual_fmac_f32 v76, v49, v49 ; c8004723 4d4c6331
	v_dual_fmac_f32 v112, v51, v51 :: v_dual_fmac_f32 v75, v33, v33 ; c8006733 704a4321
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[6:7], v[190:191], v[104:111] ; cc464068 1da37d06
	s_mov_b32 s23, 0x76543210                                   ; be9700ff 76543210
	v_dual_fmac_f32 v77, v39, v39 :: v_dual_fmac_f32 v76, v53, v53 ; c8004f27 4d4c6b35
	v_dual_fmac_f32 v112, v55, v55 :: v_dual_fmac_f32 v75, v37, v37 ; c8006f37 704a4b25
	s_mov_b32 s32, 0xfedcba98                                   ; bea000ff fedcba98
	s_movk_i32 s33, 0x410                                       ; b0210410
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v77, v47, v47 :: v_dual_fmac_f32 v76, v93, v93 ; c8005f2f 4d4cbb5d
	v_dual_fmac_f32 v112, v95, v95 :: v_dual_fmac_f32 v75, v45, v45 ; c800bf5f 704a5b2d
	v_dual_fmac_f32 v76, v48, v48 :: v_dual_fmac_f32 v77, v34, v34 ; c8006130 4c4c4522
	v_dual_fmac_f32 v112, v50, v50 :: v_dual_fmac_f32 v75, v32, v32 ; c8006532 704a4120
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v76, v88, v88 :: v_dual_fmac_f32 v77, v42, v42 ; c800b158 4c4c552a
	v_dual_fmac_f32 v112, v90, v90 :: v_dual_fmac_f32 v75, v40, v40 ; c800b55a 704a5128
	v_dual_fmac_f32 v76, v52, v52 :: v_dual_fmac_f32 v77, v38, v38 ; c8006934 4c4c4d26
	v_dual_fmac_f32 v112, v54, v54 :: v_dual_fmac_f32 v75, v36, v36 ; c8006d36 704a4924
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v76, v92, v92 :: v_dual_fmac_f32 v77, v46, v46 ; c800b95c 4c4c5d2e
	v_dual_fmac_f32 v112, v94, v94 :: v_dual_fmac_f32 v75, v44, v44 ; c800bd5e 704a592c
	v_fma_mixlo_f16 v113, 1.0, v75, v77                         ; cc210071 053696f2
	v_fma_mixhi_f16 v113, 1.0, v76, v112                        ; cc220071 05c298f2
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v114, v113, s23, s32 op_sel:[1,1]         ; d65c1872 00802f71
(invalid instruction)                                        ; cc0f0071
	v_min_num_f64_e32 v[1:2], v[113:114], v[114:115]            ; 1a02e571
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0071
	v_subrev_f32_e32 v0, v113, v33                              ; 0a004371
	v_cvt_f32_f16_e32 v115, v113                                ; 7ee61771
	v_cvt_f32_f16_e32 v113, v241/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ee217f1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(TRANS32_DEP_2) ; bf870332
	v_rsq_f32_e32 v115, v115                                    ; 7ee65d73
	v_rsq_f32_e32 v113, v113                                    ; 7ee25d71
	s_wait_kmcnt 0x0                                            ; bfc70000
	v_mul_f32_e32 v115, s22, v115                               ; 10e6e616
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v55, v55, v113 :: v_dual_mul_f32 v54, v54, v113 ; c8c6e337 3736e336
	v_dual_mul_f32 v51, v51, v113 :: v_dual_mul_f32 v50, v50, v113 ; c8c6e333 3332e332
	v_dual_mul_f32 v49, v49, v113 :: v_dual_mul_f32 v48, v48, v113 ; c8c6e331 3130e330
	v_dual_mul_f32 v53, v53, v113 :: v_dual_mul_f32 v52, v52, v113 ; c8c6e335 3534e334
	v_dual_mul_f32 v45, v45, v115 :: v_dual_mul_f32 v44, v44, v115 ; c8c6e72d 2d2ce72c
	v_dual_mul_f32 v32, v32, v115 :: v_dual_mul_f32 v33, v33, v115 ; c8c6e720 2020e721
	v_dual_mul_f32 v34, v34, v115 :: v_dual_mul_f32 v35, v35, v115 ; c8c6e722 2222e723
	v_dual_mul_f32 v37, v37, v115 :: v_dual_mul_f32 v36, v36, v115 ; c8c6e725 2524e724
	v_dual_mul_f32 v39, v39, v115 :: v_dual_mul_f32 v38, v38, v115 ; c8c6e727 2726e726
	v_dual_mul_f32 v43, v43, v115 :: v_dual_mul_f32 v42, v42, v115 ; c8c6e72b 2b2ae72a
	v_dual_mul_f32 v89, v89, v113 :: v_dual_mul_f32 v88, v88, v113 ; c8c6e359 5958e358
	v_dual_mul_f32 v41, v41, v115 :: v_dual_mul_f32 v40, v40, v115 ; c8c6e729 2928e728
	v_dual_mul_f32 v47, v47, v115 :: v_dual_mul_f32 v46, v46, v115 ; c8c6e72f 2f2ee72e
	v_dual_mul_f32 v91, v91, v113 :: v_dual_mul_f32 v90, v90, v113 ; c8c6e35b 5b5ae35a
	v_dual_mul_f32 v93, v93, v113 :: v_dual_mul_f32 v92, v92, v113 ; c8c6e35d 5d5ce35c
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	v_lshl_add_u32 v128, v78, 5, v60                            ; d6460080 04f10b4e
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v95, v95, v113 :: v_dual_mul_f32 v94, v94, v113 ; c8c6e35f 5f5ee35e
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v128, v[8:9], v[32:33] offset0:128 offset1:130 ; d9388280 00200880
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[2:3], v[12:13], 0   ; cc464028 1a021902
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[186:187], v[12:13], 0 ; cc464058 1a0219ba
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[0:1], v[12:13], 0   ; cc464020 1a021900
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[184:185], v[12:13], 0 ; cc464030 1a0219b8
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[12:13], v[62:63], 0 ; cc464060 1a027d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[72:73], v[10:11], v[40:47] ; cc464028 1ca21548
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[12:13], v[64:65], 0 ; cc464068 1a02810c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[126:127], v[10:11], v[88:95] ; cc464058 1d62157e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[70:71], v[10:11], v[32:39] ; cc464020 1c821546
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[124:125], v[10:11], v[48:55] ; cc464030 1cc2157c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[10:11], v[188:189], v[96:103] ; cc464060 1d83790a
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[10:11], v[190:191], v[104:111] ; cc464068 1da37d0a
	v_dual_mul_f32 v132, v91, v91 :: v_dual_mul_f32 v129, v41, v41 ; c8c6b75b 84805329
	v_dual_mul_f32 v131, v43, v43 :: v_dual_mul_f32 v130, v89, v89 ; c8c6572b 8382b359
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v132, v51, v51 :: v_dual_fmac_f32 v129, v33, v33 ; c8006733 84804321
	v_dual_fmac_f32 v131, v35, v35 :: v_dual_fmac_f32 v130, v49, v49 ; c8004723 83826331
	v_dual_fmac_f32 v132, v55, v55 :: v_dual_fmac_f32 v129, v37, v37 ; c8006f37 84804b25
	v_dual_fmac_f32 v131, v39, v39 :: v_dual_fmac_f32 v130, v53, v53 ; c8004f27 83826b35
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v132, v95, v95 :: v_dual_fmac_f32 v129, v45, v45 ; c800bf5f 84805b2d
	v_dual_fmac_f32 v131, v47, v47 :: v_dual_fmac_f32 v130, v93, v93 ; c8005f2f 8382bb5d
	v_dual_fmac_f32 v132, v50, v50 :: v_dual_fmac_f32 v129, v32, v32 ; c8006532 84804120
	v_dual_fmac_f32 v130, v48, v48 :: v_dual_fmac_f32 v131, v34, v34 ; c8006130 82824522
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v132, v90, v90 :: v_dual_fmac_f32 v129, v40, v40 ; c800b55a 84805128
	v_dual_fmac_f32 v130, v88, v88 :: v_dual_fmac_f32 v131, v42, v42 ; c800b158 8282552a
	v_dual_fmac_f32 v132, v54, v54 :: v_dual_fmac_f32 v129, v36, v36 ; c8006d36 84804924
	v_dual_fmac_f32 v130, v52, v52 :: v_dual_fmac_f32 v131, v38, v38 ; c8006934 82824d26
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v132, v94, v94 :: v_dual_fmac_f32 v129, v44, v44 ; c800bd5e 8480592c
	v_dual_fmac_f32 v130, v92, v92 :: v_dual_fmac_f32 v131, v46, v46 ; c800b95c 82825d2e
	v_fma_mixlo_f16 v133, 1.0, v129, v131                       ; cc210085 060f02f2
	v_fma_mixhi_f16 v133, 1.0, v130, v132                       ; cc220085 061304f2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v134, v133, s23, s32 op_sel:[1,1]         ; d65c1886 00802f85
(invalid instruction)                                        ; cc0f0085
	v_min_num_f64_e32 v[1:2], v[133:134], v[134:135]            ; 1a030d85
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0085
	v_subrev_f32_e32 v0, v133, v33                              ; 0a004385
(invalid instruction)                                        ; d58b0087
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                    ; 02010185
(invalid instruction)                                        ; d58b0885
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                    ; 02010185
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v135, v135                                    ; 7f0e5d87
	v_rsq_f32_e32 v133, v133                                    ; 7f0a5d85
	v_mul_f32_e32 v135, s22, v135                               ; 110f0e16
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_dual_mul_f32 v49, v49, v133 :: v_dual_mul_f32 v48, v48, v133 ; c8c70b31 31310b30
	v_dual_mul_f32 v53, v53, v133 :: v_dual_mul_f32 v52, v52, v133 ; c8c70b35 35350b34
	v_dual_mul_f32 v55, v55, v133 :: v_dual_mul_f32 v54, v54, v133 ; c8c70b37 37370b36
	v_dual_mul_f32 v51, v51, v133 :: v_dual_mul_f32 v50, v50, v133 ; c8c70b33 33330b32
	v_dual_mul_f32 v32, v32, v135 :: v_dual_mul_f32 v33, v33, v135 ; c8c70f20 20210f21
	v_dual_mul_f32 v41, v41, v135 :: v_dual_mul_f32 v40, v40, v135 ; c8c70f29 29290f28
	v_dual_mul_f32 v43, v43, v135 :: v_dual_mul_f32 v42, v42, v135 ; c8c70f2b 2b2b0f2a
	v_dual_mul_f32 v39, v39, v135 :: v_dual_mul_f32 v38, v38, v135 ; c8c70f27 27270f26
	v_dual_mul_f32 v89, v89, v133 :: v_dual_mul_f32 v88, v88, v133 ; c8c70b59 59590b58
	v_dual_mul_f32 v34, v34, v135 :: v_dual_mul_f32 v35, v35, v135 ; c8c70f22 22230f23
	v_dual_mul_f32 v47, v47, v135 :: v_dual_mul_f32 v46, v46, v135 ; c8c70f2f 2f2f0f2e
	v_dual_mul_f32 v36, v36, v135 :: v_dual_mul_f32 v37, v37, v135 ; c8c70f24 24250f25
	v_dual_mul_f32 v45, v45, v135 :: v_dual_mul_f32 v44, v44, v135 ; c8c70f2d 2d2d0f2c
	v_dual_mul_f32 v91, v91, v133 :: v_dual_mul_f32 v90, v90, v133 ; c8c70b5b 5b5b0b5a
	v_dual_mul_f32 v93, v93, v133 :: v_dual_mul_f32 v92, v92, v133 ; c8c70b5d 5d5d0b5c
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                      ; 02024320
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v95, v95, v133 :: v_dual_mul_f32 v94, v94, v133 ; c8c70b5f 5f5f0b5e
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                      ; 02024722
(invalid instruction)                                        ; d7690022
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694022
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v36, v37, vcc_lo                      ; 02024b24
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v38, v39, vcc_lo                      ; 02024f26
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7690023
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694023
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v128, v[12:13], v[36:37] offset0:192 offset1:194 ; d938c2c0 00240c80
	v_mov_b32_e32 v5, v128                                      ; 7e0a0380
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[0:1], v[16:17], 0   ; cc464028 1a022100
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[2:3], v[16:17], 0   ; cc464030 1a022102
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[184:185], v[16:17], 0 ; cc464058 1a0221b8
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[186:187], v[16:17], 0 ; cc464060 1a0221ba
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[16:17], v[62:63], 0 ; cc464068 1a027d10
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[16:17], v[64:65], 0 ; cc464080 1a028110
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[70:71], v[14:15], v[40:47] ; cc464028 1ca21d46
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[72:73], v[14:15], v[48:55] ; cc464030 1cc21d48
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[124:125], v[14:15], v[88:95] ; cc464058 1d621d7c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[126:127], v[14:15], v[96:103] ; cc464060 1d821d7e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[188:189], v[104:111] ; cc464068 1da3790e
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[14:15], v[190:191], v[128:135] ; cc464080 1e037d0e
	v_dual_mul_f32 v15, v97, v97 :: v_dual_mul_f32 v16, v51, v51 ; c8c6c361 0f106733
	v_dual_mul_f32 v17, v99, v99 :: v_dual_mul_f32 v14, v49, v49 ; c8c6c763 110e6331
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v15, v89, v89 :: v_dual_fmac_f32 v16, v43, v43 ; c800b359 0f10572b
	v_dual_fmac_f32 v17, v91, v91 :: v_dual_fmac_f32 v14, v41, v41 ; c800b75b 110e5329
	v_dual_fmac_f32 v16, v47, v47 :: v_dual_fmac_f32 v15, v93, v93 ; c8005f2f 100ebb5d
	v_dual_fmac_f32 v17, v95, v95 :: v_dual_fmac_f32 v14, v45, v45 ; c800bf5f 110e5b2d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v16, v55, v55 :: v_dual_fmac_f32 v15, v101, v101 ; c8006f37 100ecb65
	v_dual_fmac_f32 v17, v103, v103 :: v_dual_fmac_f32 v14, v53, v53 ; c800cf67 110e6b35
	v_dual_fmac_f32 v15, v88, v88 :: v_dual_fmac_f32 v16, v42, v42 ; c800b158 0f10552a
	v_dual_fmac_f32 v17, v90, v90 :: v_dual_fmac_f32 v14, v40, v40 ; c800b55a 110e5128
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v15, v96, v96 :: v_dual_fmac_f32 v16, v50, v50 ; c800c160 0f106532
	v_dual_fmac_f32 v17, v98, v98 :: v_dual_fmac_f32 v14, v48, v48 ; c800c562 110e6130
	v_dual_fmac_f32 v15, v92, v92 :: v_dual_fmac_f32 v16, v46, v46 ; c800b95c 0f105d2e
	v_dual_fmac_f32 v17, v94, v94 :: v_dual_fmac_f32 v14, v44, v44 ; c800bd5e 110e592c
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_dual_fmac_f32 v15, v100, v100 :: v_dual_fmac_f32 v16, v54, v54 ; c800c964 0f106d36
	v_dual_fmac_f32 v17, v102, v102 :: v_dual_fmac_f32 v14, v52, v52 ; c800cd66 110e6934
	v_fma_mixlo_f16 v36, 1.0, v14, v16                          ; cc210024 04421cf2
	v_fma_mixhi_f16 v36, 1.0, v15, v17                          ; cc220024 04461ef2
	v_lshl_add_u32 v78, v78, 6, s7                              ; d646004e 001d0d4e
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_permlanex16_b32 v37, v36, s23, s32 op_sel:[1,1]           ; d65c1825 00802f24
	v_add_lshl_u32 v78, v78, v60, 2                             ; d647004e 020a794e
(invalid instruction)                                        ; cc0f0024
	v_min_num_f64_e32 v[1:2], v[36:37], v[37:38]                ; 1a024b24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v33                               ; 0a004324
	v_cvt_f32_f16_e32 v38, v36                                  ; 7e4c1724
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rsq_f32_e32 v38, v38                                      ; 7e4c5d26
	v_mul_f32_e32 v38, s22, v38                                 ; 104c4c16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870241
	v_dual_mul_f32 v41, v41, v38 :: v_dual_mul_f32 v40, v40, v38 ; c8c64d29 29284d28
	v_dual_mul_f32 v45, v45, v38 :: v_dual_mul_f32 v44, v44, v38 ; c8c64d2d 2d2c4d2c
	v_dual_mul_f32 v43, v43, v38 :: v_dual_mul_f32 v42, v42, v38 ; c8c64d2b 2b2a4d2a
	v_dual_mul_f32 v47, v47, v38 :: v_dual_mul_f32 v46, v46, v38 ; c8c64d2f 2f2e4d2e
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v78, s[16:19], null offen        ; c405c07c 40802028 0000004e
	buffer_load_b128 v[44:47], v78, s[16:19], null offen offset:16 ; c405c07c 4080202c 0000104e
	v_cvt_f32_f16_e32 v36, v164/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4817a4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1) ; bf8702b1
	v_rsq_f32_e32 v36, v36                                      ; 7e485d24
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v48, v48, v38 :: v_dual_mul_f32 v95, v95, v36 ; c8c64d30 305e495f
	v_dual_mul_f32 v94, v94, v36 :: v_dual_mul_f32 v93, v93, v36 ; c8c6495e 5e5c495d
	v_dual_mul_f32 v92, v92, v36 :: v_dual_mul_f32 v91, v91, v36 ; c8c6495c 5c5a495b
	v_dual_mul_f32 v90, v90, v36 :: v_dual_mul_f32 v89, v89, v36 ; c8c6495a 5a584959
	v_mul_f32_e32 v88, v88, v36                                 ; 10b04958
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v92, v93, vcc_lo                      ; 0202bb5c
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v94, v95, vcc_lo                      ; 0202bf5e
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                      ; 0202b358
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                      ; 0202b75a
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[88:91], v78, s[16:19], null offen offset:4096 ; c405c07c 40802058 0010004e
	buffer_load_b128 v[92:95], v78, s[16:19], null offen offset:4112 ; c405c07c 4080205c 0010104e
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
	v_mul_f32_e32 v49, v49, v38                                 ; 10624d31
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_dual_mul_f32 v51, v51, v38 :: v_dual_mul_f32 v50, v50, v38 ; c8c64d33 33324d32
	v_dual_mul_f32 v53, v53, v38 :: v_dual_mul_f32 v52, v52, v38 ; c8c64d35 35344d34
	v_dual_mul_f32 v55, v55, v38 :: v_dual_mul_f32 v54, v54, v38 ; c8c64d37 37364d36
	v_dual_mul_f32 v97, v97, v36 :: v_dual_mul_f32 v96, v96, v36 ; c8c64961 61604960
	v_dual_mul_f32 v99, v99, v36 :: v_dual_mul_f32 v98, v98, v36 ; c8c64963 63624962
(invalid instruction)                                        ; d7690030
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7690031
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694031
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[52:55], v78, s[16:19], null offen offset:8192 ; c405c07c 40802034 0020004e
	buffer_load_b128 v[96:99], v78, s[16:19], null offen offset:8208 ; c405c07c 40802060 0020104e
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_mul_f32_e32 v100, v100, v36                               ; 10c84964
	v_dual_mul_f32 v102, v102, v36 :: v_dual_mul_f32 v101, v101, v36 ; c8c64966 66644965
(invalid instruction)                                        ; d7694030
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
	v_dual_mul_f32 v103, v103, v36 :: v_dual_add_nc_u32 v50, 0x800, v5 ; c8e04967 67320aff 00000800
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870113
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v50, v[16:17], v[38:39] offset1:2        ; d9380200 00261032
	v_mov_b32_e32 v51, v116                                     ; 7e660374
	v_mov_b32_e32 v61, v117                                     ; 7e7a0375
	v_dual_mov_b32 v67, v119 :: v_dual_mov_b32 v66, v118        ; ca100177 43420176
	v_dual_mov_b32 v69, v157 :: v_dual_mov_b32 v68, v156        ; ca10019d 4544019c
	v_dual_mov_b32 v75, v158 :: v_dual_mov_b32 v76, v159        ; ca10019e 4b4c019f
	v_dual_mov_b32 v77, v168 :: v_dual_mov_b32 v100, v169       ; ca1001a8 4d6401a9
	v_dual_mov_b32 v101, v170 :: v_dual_mov_b32 v102, v171      ; ca1001aa 656601ab
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[0:1], v[56:57], 0 ; cc464068 1a027100
	v_dual_mov_b32 v1, v182 :: v_dual_mov_b32 v0, v181          ; ca1001b6 010001b5
(invalid instruction)                                        ; d7690010
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694010
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690011
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694011
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[2:3], v[56:57], 0 ; cc464080 1a027102
	v_dual_mov_b32 v103, v180 :: v_dual_mov_b32 v2, v183        ; ca1001b4 670201b7
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[184:185], v[56:57], 0 ; cc464070 1a0271b8
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[186:187], v[56:57], 0 ; cc46409c 1a0271ba
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[56:57], v[62:63], 0 ; cc4640a8 1a027d38
	v_wmma_f32_16x16x16_fp8_fp8 v[180:187], v[56:57], v[64:65], 0 ; cc4640b4 1a028138
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[36:39], v78, s[16:19], null offen offset:12288 ; c405c07c 40802024 0030004e
	buffer_load_b128 v[62:65], v78, s[16:19], null offen offset:12304 ; c405c07c 4080203e 0030104e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[70:71], v[18:19], v[104:111] ; cc464068 1da22546
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[124:125], v[18:19], v[112:119] ; cc464070 1dc2257c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[18:19], v[128:135] ; cc464080 1e022548
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[126:127], v[18:19], v[156:163] ; cc46409c 1e72257e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[18:19], v[188:189], v[168:175] ; cc4640a8 1ea37912
	v_wmma_f32_16x16x16_fp8_fp8 v[180:187], v[18:19], v[190:191], v[180:187] ; cc4640b4 1ed37d12
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[124:127], v78, s[16:19], null offen offset:64 ; c405c07c 4080207c 0000404e
	buffer_load_b128 v[188:191], v78, s[16:19], null offen offset:80 ; c405c07c 408020bc 0000504e
	v_mul_f32_e32 v3, v129, v129                                ; 10070381
	v_dual_mul_f32 v19, v131, v131 :: v_dual_mul_f32 v18, v157, v157 ; c8c70783 13133b9d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v3, v105, v105 :: v_dual_mul_f32 v56, v159, v159 ; c806d369 03393f9f
	v_dual_fmac_f32 v19, v107, v107 :: v_dual_fmac_f32 v18, v113, v113 ; c800d76b 1312e371
	v_dual_fmac_f32 v3, v109, v109 :: v_dual_fmac_f32 v56, v115, v115 ; c800db6d 0338e773
	v_dual_fmac_f32 v19, v111, v111 :: v_dual_fmac_f32 v18, v117, v117 ; c800df6f 1312eb75
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_fmac_f32 v3, v133, v133 :: v_dual_fmac_f32 v56, v119, v119 ; c8010b85 0338ef77
	v_dual_fmac_f32 v19, v135, v135 :: v_dual_fmac_f32 v18, v161, v161 ; c8010f87 131343a1
	v_dual_fmac_f32 v3, v104, v104 :: v_dual_fmac_f32 v56, v163, v163 ; c800d168 033947a3
	v_dual_fmac_f32 v18, v112, v112 :: v_dual_fmac_f32 v19, v106, v106 ; c800e170 1212d56a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b2
	v_fmac_f32_e32 v56, v114, v114                              ; 5670e572
	v_fmac_f32_e32 v3, v128, v128                               ; 56070180
	v_dual_fmac_f32 v18, v156, v156 :: v_dual_fmac_f32 v19, v130, v130 ; c801399c 12130582
	v_fmac_f32_e32 v56, v158, v158                              ; 56713d9e
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v18, v116, v116 :: v_dual_fmac_f32 v19, v110, v110 ; c800e974 1212dd6e
	v_dual_fmac_f32 v56, v118, v118 :: v_dual_fmac_f32 v3, v108, v108 ; c800ed76 3802d96c
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2) ; bf870112
	v_dual_fmac_f32 v18, v160, v160 :: v_dual_fmac_f32 v19, v134, v134 ; c80141a0 12130d86
	v_dual_fmac_f32 v56, v162, v162 :: v_dual_fmac_f32 v3, v132, v132 ; c80145a2 38030984
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mixlo_f16 v57, 1.0, v3, v19                           ; cc210039 044e06f2
	v_fma_mixhi_f16 v57, 1.0, v18, v56                          ; cc220039 04e224f2
	v_permlanex16_b32 v70, v57, s23, s32 op_sel:[1,1]           ; d65c1846 00802f39
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f0039
	v_min_num_f64_e32 v[1:2], v[57:58], v[70:71]                ; 1a028d39
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v33                               ; 0a004339
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_cvt_f32_f16_e32 v71, v57                                  ; 7e8e1739
	v_cvt_f32_f16_e32 v57, v185/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7217b9
	v_rsq_f32_e32 v71, v71                                      ; 7e8e5d47
	v_rsq_f32_e32 v57, v57                                      ; 7e725d39
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870296
	v_mul_f32_e32 v71, s22, v71                                 ; 108e8e16
	v_dual_mul_f32 v115, v115, v57 :: v_dual_mul_f32 v114, v114, v57 ; c8c67373 73727372
	v_dual_mul_f32 v113, v113, v57 :: v_dual_mul_f32 v112, v112, v57 ; c8c67371 71707370
	v_dual_mul_f32 v117, v117, v57 :: v_dual_mul_f32 v116, v116, v57 ; c8c67375 75747374
	v_dual_mul_f32 v119, v119, v57 :: v_dual_mul_f32 v118, v118, v57 ; c8c67377 77767376
	v_dual_mul_f32 v157, v157, v57 :: v_dual_mul_f32 v156, v156, v57 ; c8c6739d 9d9c739c
	v_dual_mul_f32 v133, v133, v71 :: v_dual_mul_f32 v132, v132, v71 ; c8c68f85 85848f84
	v_dual_mul_f32 v111, v111, v71 :: v_dual_mul_f32 v110, v110, v71 ; c8c68f6f 6f6e8f6e
	v_dual_mul_f32 v104, v104, v71 :: v_dual_mul_f32 v105, v105, v71 ; c8c68f68 68688f69
	v_dual_mul_f32 v108, v108, v71 :: v_dual_mul_f32 v109, v109, v71 ; c8c68f6c 6c6c8f6d
	v_dual_mul_f32 v106, v106, v71 :: v_dual_mul_f32 v107, v107, v71 ; c8c68f6a 6a6a8f6b
	v_dual_mul_f32 v135, v135, v71 :: v_dual_mul_f32 v134, v134, v71 ; c8c68f87 87868f86
	v_dual_mul_f32 v129, v129, v71 :: v_dual_mul_f32 v128, v128, v71 ; c8c68f81 81808f80
	v_dual_mul_f32 v131, v131, v71 :: v_dual_mul_f32 v130, v130, v71 ; c8c68f83 83828f82
	v_dual_mul_f32 v159, v159, v57 :: v_dual_mul_f32 v158, v158, v57 ; c8c6739f 9f9e739e
	v_dual_mul_f32 v161, v161, v57 :: v_dual_mul_f32 v160, v160, v57 ; c8c673a1 a1a073a0
(invalid instruction)                                        ; d7690048
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                    ; 0202e370
(invalid instruction)                                        ; d7694048
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                    ; 0202e772
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                    ; 0202eb74
(invalid instruction)                                        ; d7694049
	v_cndmask_b32_e32 v1, v118, v119, vcc_lo                    ; 0202ef76
	v_dual_mul_f32 v163, v163, v57 :: v_dual_mul_f32 v162, v162, v57 ; c8c673a3 a3a273a2
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                    ; 0202d368
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694068
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d7690069
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694069
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                    ; 0202db6c
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v110, v111, vcc_lo                    ; 0202df6e
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                    ; 0202d76a
(invalid instruction)                                        ; d769006b
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769406b
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690046
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769006a
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769406a
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7694046
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690047
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                    ; 020343a0
(invalid instruction)                                        ; d7694047
	v_cndmask_b32_e32 v1, v162, v163, vcc_lo                    ; 020347a2
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	ds_store_2addr_b64 v50, v[72:73], v[70:71] offset0:64 offset1:66 ; d9384240 00464832
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                    ; 02036bb4
(invalid instruction)                                        ; d7694038
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                    ; 02036fb6
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                    ; 020373b8
(invalid instruction)                                        ; d7694039
	v_cndmask_b32_e32 v1, v186, v187, vcc_lo                    ; 020377ba
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 0             ; b98005c1 00000000
	ds_load_b64 v[70:71], v5 offset:1024                        ; d9d80400 46000005
	ds_load_b64 v[72:73], v5 offset:1040                        ; d9d80410 48000005
	s_mov_b32 s34, 0x3d380000                                   ; bea200ff 3d380000
	s_movk_i32 s35, 0x3c20                                      ; b0233c20
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[70:71], v[10:11], 0 ; cc464080 1a021546
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[70:71], v[6:7], 0 ; cc464070 1a020d46
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[70:71], v[14:15], 0 ; cc4640a8 1a021d46
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[70:71], v[18:19], 0 ; cc46409c 1a022546
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[72:73], v[34:35], v[128:135] ; cc464080 1e024548
	v_wmma_f32_16x16x16_fp8_fp8 v[112:119], v[72:73], v[30:31], v[112:119] ; cc464070 1dc23d48
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[72:73], v[48:49], v[168:175] ; cc4640a8 1ea26148
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[72:73], v[106:107], v[156:163] ; cc46409c 1e72d548
	s_wait_loadcnt 0x9                                          ; bfc00009
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_fma_mixlo_f16 v73, s34, v114, v42                         ; cc210049 04aae422
	v_fma_mixhi_f16 v73, s34, v115, v43                         ; cc220049 04aee622
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v108, s34, v116, v44                        ; cc21006c 04b2e822
	v_fma_mixlo_f16 v72, s34, v112, v40                         ; cc210048 04a2e022
	v_fma_mixhi_f16 v72, s34, v113, v41                         ; cc220048 04a6e222
	v_fma_mixhi_f16 v108, s34, v117, v45                        ; cc22006c 04b6ea22
	v_dual_mov_b32 v50, v69 :: v_dual_mov_b32 v45, v68          ; ca100145 322c0144
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_mov_b16_e32 v3.l, v108.l                                  ; 7e06396c
	v_mov_b16_e32 v44.l, v108.h                                 ; 7e5839ec
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[40:43], v78, s[16:19], null offen offset:4160 ; c405c07c 40802028 0010404e
	buffer_load_b128 v[112:115], v78, s[16:19], null offen offset:4176 ; c405c07c 40802070 0010504e
	buffer_load_b128 v[180:183], v78, s[16:19], null offen offset:8256 ; c405c07c 408020b4 0020404e
	buffer_load_b128 v[184:187], v78, s[16:19], null offen offset:8272 ; c405c07c 408020b8 0020504e
	buffer_load_b128 v[108:111], v78, s[16:19], null offen offset:12352 ; c405c07c 4080206c 0030404e
	buffer_load_b128 v[68:71], v78, s[16:19], null offen offset:12368 ; c405c07c 40802044 0030504e
	v_fma_mixlo_f16 v116, s34, v118, v46                        ; cc210074 04baec22
	v_fma_mixhi_f16 v116, s34, v119, v47                        ; cc220074 04beee22
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_fma_mixlo_f16 v117, s34, v128, v88                        ; cc210075 05630022
(invalid instruction)                                        ; cc1c0049
	v_subrev_f32_e32 v0, v73, v35                               ; 0a004749
(invalid instruction)                                        ; cc1c0048
	v_subrev_f32_e32 v0, v72, v35                               ; 0a004748
	v_fma_mixhi_f16 v117, s34, v129, v89                        ; cc220075 05670222
	v_fma_mixlo_f16 v118, s34, v130, v90                        ; cc210076 056b0422
	ds_load_b64 v[46:47], v5 offset:1536                        ; d9d80600 2e000005
	v_fma_mixhi_f16 v118, s34, v131, v91                        ; cc220076 056f0622
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_fma_mixlo_f16 v119, s34, v132, v92                        ; cc210077 05730822
	v_mov_b16_e32 v3.h, v44.l                                   ; 7f06392c
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_fma_mixlo_f16 v129, s34, v168, v52                        ; cc210081 04d35022
	v_fma_mixhi_f16 v129, s34, v169, v53                        ; cc220081 04d75222
	ds_load_b64 v[52:53], v5 offset:1552                        ; d9d80610 34000005
	v_fma_mixhi_f16 v119, s34, v133, v93                        ; cc220077 05770a22
	v_fma_mixlo_f16 v128, s34, v134, v94                        ; cc210080 057b0c22
	v_fma_mixhi_f16 v128, s34, v135, v95                        ; cc220080 057f0e22
(invalid instruction)                                        ; cc1c0074
	v_subrev_f32_e32 v0, v116, v35                              ; 0a004774
	v_fma_mixlo_f16 v130, s34, v170, v54                        ; cc210082 04db5422
	v_fma_mixhi_f16 v130, s34, v171, v55                        ; cc220082 04df5622
(invalid instruction)                                        ; cc1c0075
	v_subrev_f32_e32 v0, v117, v35                              ; 0a004775
(invalid instruction)                                        ; cc1c0076
	v_subrev_f32_e32 v0, v118, v35                              ; 0a004776
(invalid instruction)                                        ; cc1c0003
	v_subrev_f32_e32 v0, v3, v35                                ; 0a004703
(invalid instruction)                                        ; cc1c0081
	v_subrev_f32_e32 v0, v129, v35                              ; 0a004781
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_fma_mixlo_f16 v133, s34, v156, v36                        ; cc210085 04933822
	v_fma_mixhi_f16 v133, s34, v157, v37                        ; cc220085 04973a22
	v_fma_mixlo_f16 v134, s34, v158, v38                        ; cc210086 049b3c22
	v_dual_mov_b32 v38, v61 :: v_dual_mov_b32 v37, v60          ; ca10013d 2624013c
	v_fma_mixhi_f16 v134, s34, v159, v39                        ; cc220086 049f3e22
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_fma_mixlo_f16 v156, s34, v162, v64                        ; cc21009c 05034422
	v_fma_mixhi_f16 v156, s34, v163, v65                        ; cc22009c 05074622
	v_dual_mov_b32 v44, v67 :: v_dual_mov_b32 v39, v66          ; ca100143 2c260142
(invalid instruction)                                        ; cc1c0077
	v_subrev_f32_e32 v0, v119, v35                              ; 0a004777
	v_fma_mixlo_f16 v131, s34, v172, v96                        ; cc210083 05835822
(invalid instruction)                                        ; cc1c0080
	v_subrev_f32_e32 v0, v128, v35                              ; 0a004780
	v_fma_mixhi_f16 v131, s34, v173, v97                        ; cc220083 05875a22
	v_fma_mixlo_f16 v132, s34, v174, v98                        ; cc210084 058b5c22
(invalid instruction)                                        ; cc1c0082
	v_subrev_f32_e32 v0, v130, v35                              ; 0a004782
	v_fma_mixhi_f16 v132, s34, v175, v99                        ; cc220084 058f5e22
	v_fma_mixlo_f16 v135, s34, v160, v62                        ; cc210087 04fb4022
	v_fma_mixhi_f16 v135, s34, v161, v63                        ; cc220087 04ff4222
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[46:47], v[6:7], 0   ; cc464058 1a020d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[46:47], v[10:11], 0 ; cc4640a8 1a02152e
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[46:47], v[18:19], 0 ; cc46403c 1a02252e
(invalid instruction)                                        ; cc1c009c
	v_subrev_f32_e32 v0, v156, v35                              ; 0a00479c
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mov_b32_e32 v36, v156                                     ; 7e48039c
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[46:47], v[14:15], 0 ; cc46409c 1a021d2e
	ds_load_b64 v[46:47], v5 offset:2048                        ; d9d80800 2e000005
(invalid instruction)                                        ; cc1c0085
	v_subrev_f32_e32 v0, v133, v35                              ; 0a004785
(invalid instruction)                                        ; cc1c0086
	v_subrev_f32_e32 v0, v134, v35                              ; 0a004786
(invalid instruction)                                        ; cc1c0083
	v_subrev_f32_e32 v0, v131, v35                              ; 0a004783
(invalid instruction)                                        ; cc1c0084
	v_subrev_f32_e32 v0, v132, v35                              ; 0a004784
(invalid instruction)                                        ; cc1c0087
	v_subrev_f32_e32 v0, v135, v35                              ; 0a004787
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[52:53], v[30:31], v[88:95] ; cc464058 1d623d34
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[52:53], v[34:35], v[168:175] ; cc4640a8 1ea24534
	v_wmma_f32_16x16x16_fp8_fp8 v[60:67], v[52:53], v[106:107], v[60:67] ; cc46403c 1cf2d534
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[52:53], v[48:49], v[156:163] ; cc46409c 1e726134
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v52, s34, v88, v124                         ; cc210034 05f2b022
	v_fma_mixhi_f16 v52, s34, v89, v125                         ; cc220034 05f6b222
	ds_load_b64 v[88:89], v5 offset:2064                        ; d9d80810 58000005
	v_dual_mov_b32 v125, v37 :: v_dual_mov_b32 v124, v36        ; ca100125 7d7c0124
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v55, s34, v94, v190                         ; cc210037 06fabc22
	v_fma_mixlo_f16 v54, s34, v92, v188                         ; cc210036 06f2b822
	v_fma_mixhi_f16 v55, s34, v95, v191                         ; cc220037 06febe22
	v_fma_mixhi_f16 v54, s34, v93, v189                         ; cc220036 06f6ba22
	v_fma_mixlo_f16 v53, s34, v90, v126                         ; cc210035 05fab422
	v_fma_mixhi_f16 v53, s34, v91, v127                         ; cc220035 05feb622
	v_dual_mov_b32 v127, v39 :: v_dual_mov_b32 v126, v38        ; ca100127 7f7e0126
(invalid instruction)                                        ; cc1c0034
	v_subrev_f32_e32 v0, v52, v35                               ; 0a004734
(invalid instruction)                                        ; cc1c0037
	v_subrev_f32_e32 v0, v55, v35                               ; 0a004737
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[46:47], v[6:7], 0   ; cc46405c 1a020d2e
(invalid instruction)                                        ; cc1c0036
	v_subrev_f32_e32 v0, v54, v35                               ; 0a004736
(invalid instruction)                                        ; cc1c0035
	v_subrev_f32_e32 v0, v53, v35                               ; 0a004735
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v90, s34, v168, v40                         ; cc21005a 04a35022
	v_fma_mixhi_f16 v90, s34, v169, v41                         ; cc22005a 04a75222
	v_fma_mixlo_f16 v91, s34, v170, v42                         ; cc21005b 04ab5422
	v_fma_mixhi_f16 v91, s34, v171, v43                         ; cc22005b 04af5622
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v112, s34, v172, v112                       ; cc210070 05c35822
	v_fma_mixhi_f16 v112, s34, v173, v113                       ; cc220070 05c75a22
	v_fma_mixlo_f16 v113, s34, v174, v114                       ; cc210071 05cb5c22
	v_fma_mixhi_f16 v113, s34, v175, v115                       ; cc220071 05cf5e22
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v114, s34, v156, v180                       ; cc210072 06d33822
	v_fma_mixhi_f16 v114, s34, v157, v181                       ; cc220072 06d73a22
	v_dual_mov_b32 v181, v153 :: v_dual_mov_b32 v180, v152      ; ca100199 b5b40198
	v_fma_mixlo_f16 v115, s34, v158, v182                       ; cc210073 06db3c22
	v_fma_mixhi_f16 v115, s34, v159, v183                       ; cc220073 06df3e22
	v_dual_mov_b32 v183, v155 :: v_dual_mov_b32 v182, v154      ; ca10019b b7b6019a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[46:47], v[10:11], 0 ; cc4640a8 1a02152e
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[46:47], v[14:15], 0 ; cc464024 1a021d2e
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[46:47], v[18:19], 0 ; cc464098 1a02252e
(invalid instruction)                                        ; cc1c005a
	v_subrev_f32_e32 v0, v90, v35                               ; 0a00475a
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[92:99], v[88:89], v[30:31], v[92:99] ; cc46405c 1d723d58
(invalid instruction)                                        ; cc1c005b
	v_subrev_f32_e32 v0, v91, v35                               ; 0a00475b
(invalid instruction)                                        ; cc1c0070
	v_subrev_f32_e32 v0, v112, v35                              ; 0a004770
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v184, s34, v160, v184                       ; cc2100b8 06e34022
	v_fma_mixhi_f16 v184, s34, v161, v185                       ; cc2200b8 06e74222
(invalid instruction)                                        ; cc1c0071
	v_subrev_f32_e32 v0, v113, v35                              ; 0a004771
(invalid instruction)                                        ; cc1c0072
	v_subrev_f32_e32 v0, v114, v35                              ; 0a004772
(invalid instruction)                                        ; cc1c0073
	v_subrev_f32_e32 v0, v115, v35                              ; 0a004773
	v_fma_mixlo_f16 v185, s34, v162, v186                       ; cc2100b9 06eb4422
	v_fma_mixhi_f16 v185, s34, v163, v187                       ; cc2200b9 06ef4622
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[88:89], v[34:35], v[168:175] ; cc4640a8 1ea24558
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v186, s34, v60, v108                        ; cc2100ba 05b27822
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[88:89], v[48:49], v[36:43] ; cc464024 1c926158
	v_fma_mixhi_f16 v186, s34, v61, v109                        ; cc2200ba 05b67a22
	v_fma_mixlo_f16 v187, s34, v62, v110                        ; cc2100bb 05ba7c22
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[88:89], v[106:107], v[152:159] ; cc464098 1e62d558
	v_fma_mixhi_f16 v187, s34, v63, v111                        ; cc2200bb 05be7e22
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v188, s34, v64, v68                         ; cc2100bc 05128022
	v_fma_mixhi_f16 v188, s34, v65, v69                         ; cc2200bc 05168222
	v_fma_mixlo_f16 v189, s34, v66, v70                         ; cc2100bd 051a8422
	v_fma_mixhi_f16 v189, s34, v67, v71                         ; cc2200bd 051e8622
	v_dual_mov_b32 v191, v45 :: v_dual_mov_b32 v190, v44        ; ca10012d bfbe012c
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[60:63], v78, s[16:19], null offen offset:128 ; c405c07c 4080203c 0000804e
	buffer_load_b128 v[64:67], v78, s[16:19], null offen offset:144 ; c405c07c 40802040 0000904e
	buffer_load_b128 v[68:71], v78, s[16:19], null offen offset:4224 ; c405c07c 40802044 0010804e
	buffer_load_b128 v[108:111], v78, s[16:19], null offen offset:4240 ; c405c07c 4080206c 0010904e
	buffer_load_b128 v[160:163], v78, s[16:19], null offen offset:8320 ; c405c07c 408020a0 0020804e
	buffer_load_b128 v[44:47], v78, s[16:19], null offen offset:8336 ; c405c07c 4080202c 0020904e
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v60, s34, v92, v60                          ; cc21003c 04f2b822
	v_fma_mixhi_f16 v60, s34, v93, v61                          ; cc22003c 04f6ba22
(invalid instruction)                                        ; cc1c00b8
	v_subrev_f32_e32 v0, v184, v35                              ; 0a0047b8
	v_fma_mixlo_f16 v61, s34, v94, v62                          ; cc21003d 04fabc22
	v_fma_mixhi_f16 v61, s34, v95, v63                          ; cc22003d 04febe22
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v62, s34, v96, v64                          ; cc21003e 0502c022
	v_fma_mixhi_f16 v62, s34, v97, v65                          ; cc22003e 0506c222
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_mov_b16_e32 v89.l, v62.h                                  ; 7eb239be
	v_mov_b16_e32 v88.l, v62.l                                  ; 7eb0393e
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[92:95], v78, s[16:19], null offen offset:12416 ; c405c07c 4080205c 0030804e
	buffer_load_b128 v[62:65], v78, s[16:19], null offen offset:12432 ; c405c07c 4080203e 0030904e
	v_fma_mixlo_f16 v96, s34, v98, v66                          ; cc210060 050ac422
	ds_load_b64 v[97:98], v5 offset:2560                        ; d9d80a00 61000005
(invalid instruction)                                        ; cc1c00b9
	v_subrev_f32_e32 v0, v185, v35                              ; 0a0047b9
(invalid instruction)                                        ; cc1c00ba
	v_subrev_f32_e32 v0, v186, v35                              ; 0a0047ba
(invalid instruction)                                        ; cc1c00bb
	v_subrev_f32_e32 v0, v187, v35                              ; 0a0047bb
(invalid instruction)                                        ; cc1c00bc
	v_subrev_f32_e32 v0, v188, v35                              ; 0a0047bc
(invalid instruction)                                        ; cc1c00bd
	v_subrev_f32_e32 v0, v189, v35                              ; 0a0047bd
	v_fma_mixhi_f16 v96, s34, v99, v67                          ; cc220060 050ec622
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v35                               ; 0a00473c
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v35                               ; 0a00473d
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v99, s34, v168, v68                         ; cc210063 05135022
	v_fma_mixhi_f16 v99, s34, v169, v69                         ; cc220063 05175222
	v_fma_mixlo_f16 v168, s34, v170, v70                        ; cc2100a8 051b5422
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v169, s34, v172, v108                       ; cc2100a9 05b35822
	v_fma_mixhi_f16 v169, s34, v173, v109                       ; cc2200a9 05b75a22
	v_fma_mixlo_f16 v170, s34, v174, v110                       ; cc2100aa 05bb5c22
	v_mov_b16_e32 v88.h, v89.l                                  ; 7fb03959
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v173, s34, v40, v44                         ; cc2100ad 04b25022
	v_fma_mixhi_f16 v173, s34, v41, v45                         ; cc2200ad 04b65222
	v_fma_mixlo_f16 v174, s34, v42, v46                         ; cc2100ae 04ba5422
	v_fma_mixhi_f16 v174, s34, v43, v47                         ; cc2200ae 04be5622
	v_fma_mixhi_f16 v168, s34, v171, v71                        ; cc2200a8 051f5622
(invalid instruction)                                        ; cc1c0060
	v_subrev_f32_e32 v0, v96, v35                               ; 0a004760
	v_fma_mixlo_f16 v171, s34, v36, v160                        ; cc2100ab 06824822
	v_fma_mixhi_f16 v171, s34, v37, v161                        ; cc2200ab 06864a22
(invalid instruction)                                        ; cc1c0063
	v_subrev_f32_e32 v0, v99, v35                               ; 0a004763
	v_dual_mov_b32 v37, v115 :: v_dual_mov_b32 v36, v114        ; ca100173 25240172
	v_fma_mixhi_f16 v170, s34, v175, v111                       ; cc2200aa 05bf5e22
(invalid instruction)                                        ; cc1c00a9
	v_subrev_f32_e32 v0, v169, v35                              ; 0a0047a9
(invalid instruction)                                        ; cc1c0058
	v_subrev_f32_e32 v0, v88, v35                               ; 0a004758
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[97:98], v[6:7], 0   ; cc464028 1a020d61
	v_dual_mov_b32 v7, v73 :: v_dual_mov_b32 v6, v72            ; ca100149 07060148
	v_wmma_f32_16x16x16_fp8_fp8 v[66:73], v[97:98], v[10:11], 0 ; cc464042 1a021561
	v_dual_mov_b32 v11, v113 :: v_dual_mov_b32 v10, v112        ; ca100171 0b0a0170
	v_fma_mixlo_f16 v172, s34, v38, v162                        ; cc2100ac 068a4c22
	v_fma_mixhi_f16 v172, s34, v39, v163                        ; cc2200ac 068e4e22
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[97:98], v[14:15], 0 ; cc46406c 1a021d61
	v_dual_mov_b32 v39, v157 :: v_dual_mov_b32 v14, v159        ; ca10019d 270e019f
	v_dual_mov_b32 v89, v158 :: v_dual_mov_b32 v38, v156        ; ca10019e 5926019c
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[97:98], v[18:19], 0 ; cc46409c 1a022561
	ds_load_b64 v[18:19], v5 offset:2576                        ; d9d80a10 12000005
(invalid instruction)                                        ; cc1c00a8
	v_subrev_f32_e32 v0, v168, v35                              ; 0a0047a8
(invalid instruction)                                        ; cc1c00ad
	v_subrev_f32_e32 v0, v173, v35                              ; 0a0047ad
(invalid instruction)                                        ; cc1c00ae
	v_subrev_f32_e32 v0, v174, v35                              ; 0a0047ae
(invalid instruction)                                        ; cc1c00ab
	v_subrev_f32_e32 v0, v171, v35                              ; 0a0047ab
(invalid instruction)                                        ; cc1c00aa
	v_subrev_f32_e32 v0, v170, v35                              ; 0a0047aa
(invalid instruction)                                        ; cc1c00ac
	v_subrev_f32_e32 v0, v172, v35                              ; 0a0047ac
	s_wait_dscnt 0x0                                            ; bfc60000
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[18:19], v[30:31], v[40:47] ; cc464028 1ca23d12
	v_wmma_f32_16x16x16_fp8_fp8 v[66:73], v[18:19], v[34:35], v[66:73] ; cc464042 1d0a4512
	v_wmma_f32_16x16x16_fp8_fp8 v[108:115], v[18:19], v[48:49], v[108:115] ; cc46406c 1db26112
	v_wmma_f32_16x16x16_fp8_fp8 v[156:163], v[18:19], v[106:107], v[156:163] ; cc46409c 1e72d512
	v_dual_mov_b32 v34, v37 :: v_dual_mov_b32 v31, v36          ; ca100125 221e0124
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v18, s34, v154, v94                         ; cc210012 057b3422
	v_fma_mixhi_f16 v18, s34, v155, v95                         ; cc220012 057f3622
	v_mov_b32_e32 v5, v51                                       ; 7e0a0333
	v_fma_mixlo_f16 v15, s34, v152, v92                         ; cc21000f 05733022
	v_fma_mixhi_f16 v15, s34, v153, v93                         ; cc22000f 05773222
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v30, s34, v89, v64                          ; cc21001e 0502b222
	v_fma_mixhi_f16 v30, s34, v14, v65                          ; cc22001e 05061c22
	v_mov_b32_e32 v35, v50                                      ; 7e460332
	v_fma_mixlo_f16 v19, s34, v38, v62                          ; cc210013 04fa4c22
	v_fma_mixhi_f16 v19, s34, v39, v63                          ; cc220013 04fe4e22
	v_dual_mov_b32 v89, v99 :: v_dual_mov_b32 v14, v96          ; ca100163 590e0160
	s_clause 0x5                                                ; bf850005
	buffer_load_b128 v[92:95], v78, s[16:19], null offen offset:192 ; c405c07c 4080205c 0000c04e
	buffer_load_b128 v[152:155], v78, s[16:19], null offen offset:208 ; c405c07c 40802098 0000d04e
	buffer_load_b128 v[62:65], v78, s[16:19], null offen offset:4288 ; c405c07c 4080203e 0010c04e
	buffer_load_b128 v[36:39], v78, s[16:19], null offen offset:4304 ; c405c07c 40802024 0010d04e
	buffer_load_b128 v[48:51], v78, s[16:19], null offen offset:8384 ; c405c07c 40802030 0020c04e
	buffer_load_b128 v[96:99], v78, s[16:19], null offen offset:8400 ; c405c07c 40802060 0020d04e
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v92, s34, v40, v92                          ; cc21005c 05725022
	v_fma_mixhi_f16 v92, s34, v41, v93                          ; cc22005c 05765222
	v_fma_mixlo_f16 v93, s34, v42, v94                          ; cc21005d 057a5422
	v_fma_mixhi_f16 v93, s34, v43, v95                          ; cc22005d 057e5622
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc1c005c
	v_subrev_f32_e32 v0, v92, v35                               ; 0a00475c
	v_dual_mov_b32 v107, v93 :: v_dual_mov_b32 v106, v92        ; ca10015d 6b6a015c
	s_clause 0x1                                                ; bf850001
	buffer_load_b128 v[40:43], v78, s[16:19], null offen offset:12480 ; c405c07c 40802028 0030c04e
	buffer_load_b128 v[92:95], v78, s[16:19], null offen offset:12496 ; c405c07c 4080205c 0030d04e
(invalid instruction)                                        ; cc1c0012
	v_subrev_f32_e32 v0, v18, v35                               ; 0a004712
(invalid instruction)                                        ; cc1c000f
	v_subrev_f32_e32 v0, v15, v35                               ; 0a00470f
(invalid instruction)                                        ; cc1c001e
	v_subrev_f32_e32 v0, v30, v35                               ; 0a00471e
(invalid instruction)                                        ; cc1c0013
	v_subrev_f32_e32 v0, v19, v35                               ; 0a004713
	s_mov_b32 s37, 0x7ff88000                                   ; bea500ff 7ff88000
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v152, s34, v44, v152                        ; cc210098 06625822
	v_fma_mixhi_f16 v152, s34, v45, v153                        ; cc220098 06665a22
	v_fma_mixlo_f16 v153, s34, v46, v154                        ; cc210099 066a5c22
	v_fma_mixhi_f16 v153, s34, v47, v155                        ; cc220099 066e5e22
(invalid instruction)                                        ; cc1c006b
	v_subrev_f32_e32 v0, v107, v35                              ; 0a00476b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v60, v60, 5, s37                             ; d646003c 00950b3c
	v_lshl_add_u32 v6, v6, 5, s37                               ; d6460006 00950b06
	v_lshl_add_u32 v61, v61, 5, s37                             ; d646003d 00950b3d
	v_lshl_add_u32 v106, v106, 5, s37                           ; d646006a 00950b6a
	v_lshl_add_u32 v7, v7, 5, s37                               ; d6460007 00950b07
	v_lshl_add_u32 v53, v53, 5, s37                             ; d6460035 00950b35
	v_lshl_add_u32 v52, v52, 5, s37                             ; d6460034 00950b34
	v_lshl_add_u32 v3, v3, 5, s37                               ; d6460003 00950b03
	v_lshl_add_u32 v54, v54, 5, s37                             ; d6460036 00950b36
(invalid instruction)                                        ; cc1c0098
	v_subrev_f32_e32 v0, v152, v35                              ; 0a004798
	v_lshl_add_u32 v88, v88, 5, s37                             ; d6460058 00950b58
(invalid instruction)                                        ; cc1c0099
	v_subrev_f32_e32 v0, v153, v35                              ; 0a004799
	v_lshl_add_u32 v107, v107, 5, s37                           ; d646006b 00950b6b
	v_lshl_add_u32 v116, v116, 5, s37                           ; d6460074 00950b74
	v_lshl_add_u32 v55, v55, 5, s37                             ; d6460037 00950b37
	v_lshl_add_u32 v14, v14, 5, s37                             ; d646000e 00950b0e
(invalid instruction)                                        ; cc0f009b
	v_min_num_f64_e32 v[1:2], v[7:8], v[53:54]                  ; 1a026b07
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[6:7], v[52:53]                  ; 1a026906
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[3:4], v[54:55]                  ; 1a026d03
	v_lshl_add_u32 v152, v152, 5, s37                           ; d6460098 00950b98
	v_lshl_add_u32 v153, v153, 5, s37                           ; d6460099 00950b99
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[116:117], v[55:56]              ; 1a026f74
	s_movk_i32 s38, 0x400                                       ; b0260400
(invalid instruction)                                        ; cc0f009b
	v_min_num_f64_e32 v[1:2], v[155:156], v[61:62]              ; 1a027b9b
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[60:61]              ; 1a02799a
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[88:89]              ; 1a02b1af
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[44:45], v[14:15]                ; 1a021d2c
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c4
(invalid instruction)                                        ; cc0f009b
	v_min_num_f64_e32 v[1:2], v[155:156], v[107:108]            ; 1a02d79b
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[106:107]            ; 1a02d59a
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[152:153]            ; 1a0331af
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[44:45], v[153:154]              ; 1a03332c
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[155:156]            ; 1a03379a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[175:176]            ; 1a035f9a
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[44:45]              ; 1a02599a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v45, v154, s23, s32 op_sel:[1,1]          ; d65c182d 00802f9a
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[45:46]              ; 1a025b9a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d532102e
	v_cndmask_b32_e32 v1, v154, v154, vcc_lo                    ; 0203359a
	v_max_num_f16_e32 v46, s38, v46                             ; 625c5c26
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v47, v46                                  ; 7e5e172e
	v_rcp_f32_e32 v47, v47                                      ; 7e5e552f
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v155, v3, v47, neg(0) op_sel_hi:[1,0,0]       ; cc20009b 8a025f03
	v_fma_mix_f32 v3, v3, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200803 8a025f03
	v_fma_mix_f32 v154, v7, v47, neg(0) op_sel_hi:[1,0,0]       ; cc20009a 8a025f07
	v_fma_mix_f32 v7, v7, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200807 8a025f07
	v_fma_mix_f32 v78, v6, v47, neg(0) op_sel_hi:[1,0,0]        ; cc20004e 8a025f06
	v_fma_mix_f32 v6, v6, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200806 8a025f06
	v_fma_mix_f32 v175, v116, v47, neg(0) op_sel_hi:[1,0,0]     ; cc2000af 8a025f74
	v_fma_mix_f32 v116, v116, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200874 8a025f74
	v_fma_mix_f32 v46, v54, v47, neg(0) op_sel_hi:[1,0,0]       ; cc20002e 8a025f36
	v_fma_mix_f32 v54, v54, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200836 8a025f36
(invalid instruction)                                        ; d769002d
	v_cndmask_b32_e32 v1, v155, v3, vcc_lo                      ; 0202079b
	v_fma_mix_f32 v3, v52, v47, neg(0) op_sel_hi:[1,0,0]        ; cc200003 8a025f34
	v_fma_mix_f32 v52, v52, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200834 8a025f34
(invalid instruction)                                        ; d769002c
	v_cndmask_b32_e32 v1, v78, v6, vcc_lo                       ; 02020d4e
(invalid instruction)                                        ; d769402c
	v_cndmask_b32_e32 v1, v154, v7, vcc_lo                      ; 02020f9a
	v_fma_mix_f32 v7, v53, v47, neg(0) op_sel_hi:[1,0,0]        ; cc200007 8a025f35
	v_fma_mix_f32 v53, v53, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200835 8a025f35
(invalid instruction)                                        ; d769402d
	v_cndmask_b32_e32 v1, v175, v116, vcc_lo                    ; 0202e9af
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v3, v52, vcc_lo                       ; 02026903
	v_fma_mix_f32 v52, v55, v47, neg(0) op_sel_hi:[1,0,0]       ; cc200034 8a025f37
	v_fma_mix_f32 v55, v55, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200837 8a025f37
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v7, v53, vcc_lo                       ; 02026b07
	v_fma_mix_f32 v53, v60, v47, neg(0) op_sel_hi:[1,0,0]       ; cc200035 8a025f3c
	v_fma_mix_f32 v60, v60, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083c 8a025f3c
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v46, v54, vcc_lo                      ; 02026d2e
	v_fma_mix_f32 v54, v61, v47, neg(0) op_sel_hi:[1,0,0]       ; cc200036 8a025f3d
	v_fma_mix_f32 v61, v61, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083d 8a025f3d
	v_fma_mix_f32 v78, v107, v47, neg(0) op_sel_hi:[1,0,0]      ; cc20004e 8a025f6b
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v52, v55, vcc_lo                      ; 02026f34
	v_fma_mix_f32 v55, v88, v47, neg(0) op_sel_hi:[1,0,0]       ; cc200037 8a025f58
	v_fma_mix_f32 v88, v88, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200858 8a025f58
	v_fma_mix_f32 v107, v107, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086b 8a025f6b
(invalid instruction)                                        ; d7690034
	v_cndmask_b32_e32 v1, v53, v60, vcc_lo                      ; 02027935
	v_fma_mix_f32 v60, v14, v47, neg(0) op_sel_hi:[1,0,0]       ; cc20003c 8a025f0e
	v_fma_mix_f32 v14, v14, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080e 8a025f0e
(invalid instruction)                                        ; d7694034
	v_cndmask_b32_e32 v1, v54, v61, vcc_lo                      ; 02027b36
	v_fma_mix_f32 v61, v106, v47, neg(0) op_sel_hi:[1,0,0]      ; cc20003d 8a025f6a
	v_fma_mix_f32 v106, v106, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20086a 8a025f6a
	v_lshl_add_u32 v117, v117, 5, s37                           ; d6460075 00950b75
	v_lshl_add_u32 v90, v90, 5, s37                             ; d646005a 00950b5a
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v55, v88, vcc_lo                      ; 0202b137
	v_fma_mix_f32 v88, v152, v47, neg(0) op_sel_hi:[1,0,0]      ; cc200058 8a025f98
	v_fma_mix_f32 v152, v152, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200898 8a025f98
	v_lshl_add_u32 v89, v89, 5, s37                             ; d6460059 00950b59
	v_lshl_add_u32 v118, v118, 5, s37                           ; d6460076 00950b76
	v_lshl_add_u32 v91, v91, 5, s37                             ; d646005b 00950b5b
(invalid instruction)                                        ; d7694035
	v_cndmask_b32_e32 v1, v60, v14, vcc_lo                      ; 02021d3c
	v_lshl_add_u32 v168, v168, 5, s37                           ; d64600a8 00950ba8
	v_lshl_add_u32 v119, v119, 5, s37                           ; d6460077 00950b77
(invalid instruction)                                        ; d7690036
	v_cndmask_b32_e32 v1, v61, v106, vcc_lo                     ; 0202d53d
	v_fma_mix_f32 v106, v153, v47, neg(0) op_sel_hi:[1,0,0]     ; cc20006a 8a025f99
	v_fma_mix_f32 v153, v153, v47, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200899 8a025f99
(invalid instruction)                                        ; d7694036
	v_cndmask_b32_e32 v1, v78, v107, vcc_lo                     ; 0202d74e
	v_lshl_add_u32 v10, v10, 5, s37                             ; d646000a 00950b0a
(invalid instruction)                                        ; cc0f006b
	v_min_num_f64_e32 v[1:2], v[117:118], v[90:91]              ; 1a02b575
	v_lshl_add_u32 v169, v169, 5, s37                           ; d64600a9 00950ba9
	v_lshl_add_u32 v128, v128, 5, s37                           ; d6460080 00950b80
(invalid instruction)                                        ; d7690037
	v_cndmask_b32_e32 v1, v88, v152, vcc_lo                     ; 02033158
	v_lshl_add_u32 v11, v11, 5, s37                             ; d646000b 00950b0b
(invalid instruction)                                        ; cc0f0074
	v_min_num_f64_e32 v[1:2], v[118:119], v[91:92]              ; 1a02b776
	v_lshl_add_u32 v170, v170, 5, s37                           ; d64600aa 00950baa
	v_lshl_add_u32 v129, v129, 5, s37                           ; d6460081 00950b81
	v_lshl_add_u32 v31, v31, 5, s37                             ; d646001f 00950b1f
	v_lshl_add_u32 v171, v171, 5, s37                           ; d64600ab 00950bab
(invalid instruction)                                        ; d7694037
	v_cndmask_b32_e32 v1, v106, v153, vcc_lo                    ; 0203336a
	v_lshl_add_u32 v130, v130, 5, s37                           ; d6460082 00950b82
(invalid instruction)                                        ; cc0f0098
	v_min_num_f64_e32 v[1:2], v[119:120], v[10:11]              ; 1a021577
	v_lshl_add_u32 v34, v34, 5, s37                             ; d6460022 00950b22
(invalid instruction)                                        ; cc0f006b
	v_min_num_f64_e32 v[1:2], v[107:108], v[89:90]              ; 1a02b36b
	v_lshl_add_u32 v172, v172, 5, s37                           ; d64600ac 00950bac
	v_lshl_add_u32 v131, v131, 5, s37                           ; d6460083 00950b83
	v_lshl_add_u32 v184, v184, 5, s37                           ; d64600b8 00950bb8
(invalid instruction)                                        ; cc0f0099
	v_min_num_f64_e32 v[1:2], v[128:129], v[11:12]              ; 1a021780
(invalid instruction)                                        ; cc0f0074
	v_min_num_f64_e32 v[1:2], v[116:117], v[168:169]            ; 1a035174
	v_lshl_add_u32 v173, v173, 5, s37                           ; d64600ad 00950bad
	v_lshl_add_u32 v132, v132, 5, s37                           ; d6460084 00950b84
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[129:130], v[31:32]              ; 1a023f81
	v_lshl_add_u32 v185, v185, 5, s37                           ; d64600b9 00950bb9
	v_lshl_add_u32 v174, v174, 5, s37                           ; d64600ae 00950bae
(invalid instruction)                                        ; cc0f0098
	v_min_num_f64_e32 v[1:2], v[152:153], v[169:170]            ; 1a035398
(invalid instruction)                                        ; cc0f009b
	v_min_num_f64_e32 v[1:2], v[130:131], v[34:35]              ; 1a024582
	v_lshl_add_u32 v133, v133, 5, s37                           ; d6460085 00950b85
	v_lshl_add_u32 v186, v186, 5, s37                           ; d64600ba 00950bba
	v_lshl_add_u32 v15, v15, 5, s37                             ; d646000f 00950b0f
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[131:132], v[184:185]            ; 1a037183
(invalid instruction)                                        ; cc0f0099
	v_min_num_f64_e32 v[1:2], v[153:154], v[170:171]            ; 1a035599
	v_lshl_add_u32 v134, v134, 5, s37                           ; d6460086 00950b86
	v_lshl_add_u32 v187, v187, 5, s37                           ; d64600bb 00950bbb
	v_lshl_add_u32 v18, v18, 5, s37                             ; d6460012 00950b12
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[171:172]            ; 1a03579a
	v_lshl_add_u32 v135, v135, 5, s37                           ; d6460087 00950b87
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[132:133], v[185:186]            ; 1a037384
	v_lshl_add_u32 v188, v188, 5, s37                           ; d64600bc 00950bbc
	v_lshl_add_u32 v19, v19, 5, s37                             ; d6460013 00950b13
(invalid instruction)                                        ; cc0f009b
	v_min_num_f64_e32 v[1:2], v[155:156], v[172:173]            ; 1a03599b
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[133:134], v[186:187]            ; 1a037585
	v_lshl_add_u32 v124, v124, 5, s37                           ; d646007c 00950b7c
	v_lshl_add_u32 v189, v189, 5, s37                           ; d64600bd 00950bbd
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[173:174]            ; 1a035baf
	v_lshl_add_u32 v30, v30, 5, s37                             ; d646001e 00950b1e
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v61, s34, v66, v62                          ; cc21003d 04fa8422
	v_fma_mixhi_f16 v61, s34, v67, v63                          ; cc22003d 04fe8622
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[134:135], v[187:188]            ; 1a037786
	v_fma_mixlo_f16 v62, s34, v68, v64                          ; cc21003e 05028822
	v_fma_mixhi_f16 v62, s34, v69, v65                          ; cc22003e 05068a22
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[174:175]                ; 1a035d03
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v63, s34, v70, v36                          ; cc21003f 04928c22
(invalid instruction)                                        ; cc0f002f
	v_min_num_f64_e32 v[1:2], v[135:136], v[188:189]            ; 1a037987
	v_fma_mixhi_f16 v63, s34, v71, v37                          ; cc22003f 04968e22
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[15:16]                ; 1a021f0e
	v_fma_mixlo_f16 v64, s34, v72, v38                          ; cc210040 049a9022
	v_fma_mixhi_f16 v64, s34, v73, v39                          ; cc220040 049e9222
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[124:125], v[189:190]            ; 1a037b7c
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v65, s34, v108, v48                         ; cc210041 04c2d822
	v_fma_mixhi_f16 v65, s34, v109, v49                         ; cc220041 04c6da22
	v_fma_mixlo_f16 v66, s34, v110, v50                         ; cc210042 04cadc22
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v35                               ; 0a00473d
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[18:19]                ; 1a02252e
	v_fma_mixhi_f16 v66, s34, v111, v51                         ; cc220042 04cede22
(invalid instruction)                                        ; cc1c003e
	v_subrev_f32_e32 v0, v62, v35                               ; 0a00473e
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v67, s34, v112, v96                         ; cc210043 0582e022
	v_fma_mixhi_f16 v67, s34, v113, v97                         ; cc220043 0586e222
	v_fma_mixlo_f16 v68, s34, v114, v98                         ; cc210044 058ae422
(invalid instruction)                                        ; cc0f002f
	v_min_num_f64_e32 v[1:2], v[47:48], v[19:20]                ; 1a02272f
	v_fma_mixhi_f16 v68, s34, v115, v99                         ; cc220044 058ee622
(invalid instruction)                                        ; cc1c003f
	v_subrev_f32_e32 v0, v63, v35                               ; 0a00473f
(invalid instruction)                                        ; cc1c0040
	v_subrev_f32_e32 v0, v64, v35                               ; 0a004740
(invalid instruction)                                        ; cc1c0041
	v_subrev_f32_e32 v0, v65, v35                               ; 0a004741
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v35                               ; 0a004742
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v35                               ; 0a004743
	v_lshl_add_u32 v61, v61, 5, s37                             ; d646003d 00950b3d
	v_lshl_add_u32 v62, v62, 5, s37                             ; d646003e 00950b3e
(invalid instruction)                                        ; cc1c0044
	v_subrev_f32_e32 v0, v68, v35                               ; 0a004744
	v_lshl_add_u32 v63, v63, 5, s37                             ; d646003f 00950b3f
	v_lshl_add_u32 v64, v64, 5, s37                             ; d6460040 00950b40
(invalid instruction)                                        ; cc0f006b
	v_min_num_f64_e32 v[1:2], v[107:108], v[61:62]              ; 1a027b6b
(invalid instruction)                                        ; cc0f0074
	v_min_num_f64_e32 v[1:2], v[116:117], v[62:63]              ; 1a027d74
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a4
(invalid instruction)                                        ; cc0f0098
	v_min_num_f64_e32 v[1:2], v[152:153], v[63:64]              ; 1a027f98
(invalid instruction)                                        ; cc0f0099
	v_min_num_f64_e32 v[1:2], v[153:154], v[64:65]              ; 1a028199
(invalid instruction)                                        ; cc0f006b
	v_min_num_f64_e32 v[1:2], v[107:108], v[116:117]            ; 1a02e96b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f006b
	v_min_num_f64_e32 v[1:2], v[107:108], v[152:153]            ; 1a03316b
(invalid instruction)                                        ; cc0f006b
	v_min_num_f64_e32 v[1:2], v[107:108], v[153:154]            ; 1a03336b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v73, v107, s23, s32 op_sel:[1,1]          ; d65c1849 00802f6b
(invalid instruction)                                        ; cc0f006b
	v_min_num_f64_e32 v[1:2], v[107:108], v[73:74]              ; 1a02936b
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f16_e32 v78, v107, v235/*Invalid register, operand has 'VGPR_32_Lo128' register class*/ ; 649dd76b
	v_max_num_f16_e32 v78, s38, v78                             ; 629c9c26
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v88, v78                                  ; 7eb0174e
	v_rcp_f32_e32 v88, v88                                      ; 7eb05558
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v69, s34, v156, v40                         ; cc210045 04a33822
	v_fma_mixhi_f16 v69, s34, v157, v41                         ; cc220045 04a73a22
	v_fma_mixlo_f16 v70, s34, v158, v42                         ; cc210046 04ab3c22
	v_fma_mixhi_f16 v70, s34, v159, v43                         ; cc220046 04af3e22
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v72, s34, v162, v94                         ; cc210048 057b4422
	v_fma_mixhi_f16 v72, s34, v163, v95                         ; cc220048 057f4622
	v_fma_mixlo_f16 v71, s34, v160, v92                         ; cc210047 05734022
	v_fma_mix_f32 v92, v117, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005c 8a02b175
	v_fma_mix_f32 v117, v117, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200875 8a02b175
	v_fma_mixhi_f16 v71, s34, v161, v93                         ; cc220047 05774222
	v_fma_mix_f32 v93, v118, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005d 8a02b176
	v_fma_mix_f32 v118, v118, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200876 8a02b176
	v_fma_mix_f32 v94, v119, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005e 8a02b177
	v_fma_mix_f32 v119, v119, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200877 8a02b177
	v_fma_mix_f32 v95, v128, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20005f 8a02b180
(invalid instruction)                                        ; cc1c0045
	v_subrev_f32_e32 v0, v69, v35                               ; 0a004745
	v_fma_mix_f32 v128, v128, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200880 8a02b180
	v_fma_mix_f32 v96, v90, v88, neg(0) op_sel_hi:[1,0,0]       ; cc200060 8a02b15a
(invalid instruction)                                        ; cc1c0046
	v_subrev_f32_e32 v0, v70, v35                               ; 0a004746
	v_fma_mix_f32 v90, v90, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085a 8a02b15a
(invalid instruction)                                        ; cc1c0048
	v_subrev_f32_e32 v0, v72, v35                               ; 0a004748
	v_fma_mix_f32 v97, v91, v88, neg(0) op_sel_hi:[1,0,0]       ; cc200061 8a02b15b
	v_fma_mix_f32 v91, v91, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20085b 8a02b15b
(invalid instruction)                                        ; d7690024
	v_cndmask_b32_e32 v1, v92, v117, vcc_lo                     ; 0202eb5c
(invalid instruction)                                        ; cc1c0047
	v_subrev_f32_e32 v0, v71, v35                               ; 0a004747
	v_fma_mix_f32 v98, v10, v88, neg(0) op_sel_hi:[1,0,0]       ; cc200062 8a02b10a
	v_fma_mix_f32 v10, v10, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080a 8a02b10a
(invalid instruction)                                        ; d7694024
	v_cndmask_b32_e32 v1, v93, v118, vcc_lo                     ; 0202ed5d
	v_fma_mix_f32 v99, v11, v88, neg(0) op_sel_hi:[1,0,0]       ; cc200063 8a02b10b
(invalid instruction)                                        ; d7690025
	v_cndmask_b32_e32 v1, v94, v119, vcc_lo                     ; 0202ef5e
	v_fma_mix_f32 v11, v11, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080b 8a02b10b
	v_fma_mix_f32 v106, v89, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20006a 8a02b159
	v_fma_mix_f32 v89, v89, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200859 8a02b159
(invalid instruction)                                        ; d7694025
	v_cndmask_b32_e32 v1, v95, v128, vcc_lo                     ; 0203015f
	v_fma_mix_f32 v107, v168, v88, neg(0) op_sel_hi:[1,0,0]     ; cc20006b 8a02b1a8
(invalid instruction)                                        ; d7690026
	v_cndmask_b32_e32 v1, v96, v90, vcc_lo                      ; 0202b560
	v_fma_mix_f32 v168, v168, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a8 8a02b1a8
	v_fma_mix_f32 v108, v169, v88, neg(0) op_sel_hi:[1,0,0]     ; cc20006c 8a02b1a9
(invalid instruction)                                        ; d7694026
	v_cndmask_b32_e32 v1, v97, v91, vcc_lo                      ; 0202b761
	v_fma_mix_f32 v169, v169, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008a9 8a02b1a9
	v_fma_mix_f32 v109, v170, v88, neg(0) op_sel_hi:[1,0,0]     ; cc20006d 8a02b1aa
	v_fma_mix_f32 v170, v170, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008aa 8a02b1aa
(invalid instruction)                                        ; d7690027
	v_cndmask_b32_e32 v1, v98, v10, vcc_lo                      ; 02021562
	v_fma_mix_f32 v110, v61, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20006e 8a02b13d
	v_fma_mix_f32 v61, v61, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083d 8a02b13d
(invalid instruction)                                        ; d7694027
	v_cndmask_b32_e32 v1, v99, v11, vcc_lo                      ; 02021763
	v_fma_mix_f32 v111, v62, v88, neg(0) op_sel_hi:[1,0,0]      ; cc20006f 8a02b13e
	v_fma_mix_f32 v62, v62, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083e 8a02b13e
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v106, v89, vcc_lo                     ; 0202b36a
	v_fma_mix_f32 v112, v63, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200070 8a02b13f
	v_fma_mix_f32 v63, v63, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083f 8a02b13f
	v_fma_mix_f32 v113, v64, v88, neg(0) op_sel_hi:[1,0,0]      ; cc200071 8a02b140
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v107, v168, vcc_lo                    ; 0203516b
	v_fma_mix_f32 v64, v64, v88, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200840 8a02b140
	v_lshl_add_u32 v65, v65, 5, s37                             ; d6460041 00950b41
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v108, v169, vcc_lo                    ; 0203536c
	v_lshl_add_u32 v66, v66, 5, s37                             ; d6460042 00950b42
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v109, v170, vcc_lo                    ; 0203556d
	v_lshl_add_u32 v67, v67, 5, s37                             ; d6460043 00950b43
(invalid instruction)                                        ; d7690028
	v_cndmask_b32_e32 v1, v110, v61, vcc_lo                     ; 02027b6e
	v_lshl_add_u32 v68, v68, 5, s37                             ; d6460044 00950b44
(invalid instruction)                                        ; d7694028
	v_cndmask_b32_e32 v1, v111, v62, vcc_lo                     ; 02027d6f
(invalid instruction)                                        ; d7690029
	v_cndmask_b32_e32 v1, v112, v63, vcc_lo                     ; 02027f70
(invalid instruction)                                        ; d7694029
	v_cndmask_b32_e32 v1, v113, v64, vcc_lo                     ; 02028171
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[65:66]              ; 1a02839a
(invalid instruction)                                        ; cc0f009b
	v_min_num_f64_e32 v[1:2], v[155:156], v[66:67]              ; 1a02859b
(invalid instruction)                                        ; cc0f00af
	v_min_num_f64_e32 v[1:2], v[175:176], v[67:68]              ; 1a0287af
(invalid instruction)                                        ; cc0f0003
	v_min_num_f64_e32 v[1:2], v[3:4], v[68:69]                  ; 1a028903
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[155:156]            ; 1a03379a
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[175:176]            ; 1a035f9a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[3:4]                ; 1a02079a
	v_permlanex16_b32 v114, v154, s23, s32 op_sel:[1,1]         ; d65c1872 00802f9a
	v_add_lshl_u32 v4, s9, v4, 2                                ; d6470004 020a0809
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
(invalid instruction)                                        ; cc0f009a
	v_min_num_f64_e32 v[1:2], v[154:155], v[114:115]            ; 1a02e59a
	buffer_load_b128 v[48:51], v4, s[16:19], null offen         ; c405c07c 40802030 00000004
(invalid instruction)                                        ; d5321073
	v_cndmask_b32_e32 v1, v154, v154, vcc_lo                    ; 0203359a
	v_max_num_f16_e32 v115, s38, v115                           ; 62e6e626
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_cvt_f32_f16_e32 v116, v115                                ; 7ee81773
	v_rcp_f32_e32 v116, v116                                    ; 7ee85574
	buffer_load_b128 v[88:91], v4, s[16:19], null offen offset:16 ; c405c07c 40802058 00001004
	v_fma_mix_f32 v118, v130, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200076 8a02e982
	v_fma_mix_f32 v128, v132, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200080 8a02e984
	v_fma_mix_f32 v132, v132, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200884 8a02e984
	v_fma_mix_f32 v117, v129, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200075 8a02e981
	v_fma_mix_f32 v129, v129, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200881 8a02e981
	v_fma_mix_f32 v130, v130, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200882 8a02e982
	v_fma_mix_f32 v119, v131, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200077 8a02e983
	v_fma_mix_f32 v131, v131, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200883 8a02e983
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769002a
	v_cndmask_b32_e32 v1, v117, v129, vcc_lo                    ; 02030375
	v_fma_mix_f32 v129, v31, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200081 8a02e91f
	v_fma_mix_f32 v31, v31, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081f 8a02e91f
	v_fma_mix_f32 v152, v171, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200098 8a02e9ab
(invalid instruction)                                        ; d769402a
	v_cndmask_b32_e32 v1, v118, v130, vcc_lo                    ; 02030576
	v_fma_mix_f32 v130, v34, v116, neg(0) op_sel_hi:[1,0,0]     ; cc200082 8a02e922
	v_fma_mix_f32 v34, v34, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200822 8a02e922
	v_fma_mix_f32 v171, v171, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ab 8a02e9ab
(invalid instruction)                                        ; d769002b
	v_cndmask_b32_e32 v1, v119, v131, vcc_lo                    ; 02030777
	v_fma_mix_f32 v131, v184, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200083 8a02e9b8
	v_fma_mix_f32 v184, v184, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b8 8a02e9b8
(invalid instruction)                                        ; d769402b
	v_cndmask_b32_e32 v1, v128, v132, vcc_lo                    ; 02030980
	v_fma_mix_f32 v132, v185, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200084 8a02e9b9
	v_fma_mix_f32 v185, v185, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008b9 8a02e9b9
	v_fma_mix_f32 v153, v172, v116, neg(0) op_sel_hi:[1,0,0]    ; cc200099 8a02e9ac
	v_fma_mix_f32 v172, v172, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ac 8a02e9ac
	v_fma_mix_f32 v154, v173, v116, neg(0) op_sel_hi:[1,0,0]    ; cc20009a 8a02e9ad
	v_fma_mix_f32 v173, v173, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ad 8a02e9ad
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v129, v31, vcc_lo                     ; 02023f81
	v_fma_mix_f32 v155, v174, v116, neg(0) op_sel_hi:[1,0,0]    ; cc20009b 8a02e9ae
	v_fma_mix_f32 v174, v174, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ae 8a02e9ae
	s_lshr_b32 s6, s6, 2                                        ; 85068206
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v74, s6, v74, 2                              ; d647004a 020a9406
	buffer_load_b128 v[96:99], v74, s[28:31], null offen        ; c405c07c 40803860 0000004a
(invalid instruction)                                        ; d769403e
	v_cndmask_b32_e32 v1, v130, v34, vcc_lo                     ; 02024582
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v152, v171, vcc_lo                    ; 02035798
	v_fma_mix_f32 v156, v65, v116, neg(0) op_sel_hi:[1,0,0]     ; cc20009c 8a02e941
	v_fma_mix_f32 v65, v65, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200841 8a02e941
	v_fma_mix_f32 v157, v66, v116, neg(0) op_sel_hi:[1,0,0]     ; cc20009d 8a02e942
(invalid instruction)                                        ; d769003f
	v_cndmask_b32_e32 v1, v131, v184, vcc_lo                    ; 02037183
	v_fma_mix_f32 v66, v66, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200842 8a02e942
	buffer_load_b128 v[108:111], v74, s[28:31], null offen offset:512 ; c405c07c 4080386c 0002004a
(invalid instruction)                                        ; d769403f
	v_cndmask_b32_e32 v1, v132, v185, vcc_lo                    ; 02037384
(invalid instruction)                                        ; d769405c
	v_cndmask_b32_e32 v1, v153, v172, vcc_lo                    ; 02035999
	v_fma_mix_f32 v158, v67, v116, neg(0) op_sel_hi:[1,0,0]     ; cc20009e 8a02e943
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v1, v154, v173, vcc_lo                    ; 02035b9a
	v_fma_mix_f32 v67, v67, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200843 8a02e943
(invalid instruction)                                        ; d769405d
	v_cndmask_b32_e32 v1, v155, v174, vcc_lo                    ; 02035d9b
	v_fma_mix_f32 v159, v68, v116, neg(0) op_sel_hi:[1,0,0]     ; cc20009f 8a02e944
	v_fma_mix_f32 v68, v68, v116, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200844 8a02e944
	v_lshl_add_u32 v69, v69, 5, s37                             ; d6460045 00950b45
	v_lshl_add_u32 v70, v70, 5, s37                             ; d6460046 00950b46
(invalid instruction)                                        ; d7690040
	v_cndmask_b32_e32 v1, v156, v65, vcc_lo                     ; 0202839c
	v_lshl_add_u32 v71, v71, 5, s37                             ; d6460047 00950b47
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[60:61], v[30:31]                ; 1a023d3c
(invalid instruction)                                        ; d7694040
	v_cndmask_b32_e32 v1, v157, v66, vcc_lo                     ; 0202859d
	v_lshl_add_u32 v72, v72, 5, s37                             ; d6460048 00950b48
(invalid instruction)                                        ; d7690041
	v_cndmask_b32_e32 v1, v158, v67, vcc_lo                     ; 0202879e
(invalid instruction)                                        ; d7694041
	v_cndmask_b32_e32 v1, v159, v68, vcc_lo                     ; 0202899f
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[69:70]                ; 1a028b0e
(invalid instruction)                                        ; cc0f002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[70:71]                ; 1a028d2e
(invalid instruction)                                        ; cc0f002f
	v_min_num_f64_e32 v[1:2], v[47:48], v[71:72]                ; 1a028f2f
(invalid instruction)                                        ; cc0f003c
	v_min_num_f64_e32 v[1:2], v[60:61], v[72:73]                ; 1a02913c
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870093
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[46:47]                ; 1a025d0e
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[47:48]                ; 1a025f0e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[60:61]                ; 1a02790e
	v_permlanex16_b32 v160, v14, s23, s32 op_sel:[1,1]          ; d65c18a0 00802f0e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc0f000e
	v_min_num_f64_e32 v[1:2], v[14:15], v[160:161]              ; 1a03410e
(invalid instruction)                                        ; d53210a1
	v_cndmask_b32_e32 v1, v14, v14, vcc_lo                      ; 02021d0e
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d53100a1
	v_cndmask_b32_e32 v1, s38, v161, vcc_lo                     ; 02034226
(invalid instruction)                                        ; d58b00a2
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                    ; 020101a1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1) ; bf870291
	v_rcp_f32_e32 v162, v162                                    ; 7f4455a2
	v_fma_mix_f32 v171, v186, v162, neg(0) op_sel_hi:[1,0,0]    ; cc2000ab 8a0345ba
	v_fma_mix_f32 v172, v187, v162, neg(0) op_sel_hi:[1,0,0]    ; cc2000ac 8a0345bb
	v_fma_mix_f32 v168, v134, v162, neg(0) op_sel_hi:[1,0,0]    ; cc2000a8 8a034586
	v_fma_mix_f32 v169, v135, v162, neg(0) op_sel_hi:[1,0,0]    ; cc2000a9 8a034587
	v_fma_mix_f32 v135, v135, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200887 8a034587
	v_fma_mix_f32 v170, v124, v162, neg(0) op_sel_hi:[1,0,0]    ; cc2000aa 8a03457c
	v_fma_mix_f32 v134, v134, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200886 8a034586
	v_fma_mix_f32 v124, v124, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20087c 8a03457c
	v_fma_mix_f32 v186, v186, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008ba 8a0345ba
	v_fma_mix_f32 v163, v133, v162, neg(0) op_sel_hi:[1,0,0]    ; cc2000a3 8a034585
	v_fma_mix_f32 v133, v133, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200885 8a034585
	v_fma_mix_f32 v187, v187, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bb 8a0345bb
	v_fma_mix_f32 v173, v188, v162, neg(0) op_sel_hi:[1,0,0]    ; cc2000ad 8a0345bc
	v_fma_mix_f32 v188, v188, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bc 8a0345bc
	v_fma_mix_f32 v174, v189, v162, neg(0) op_sel_hi:[1,0,0]    ; cc2000ae 8a0345bd
	v_fma_mix_f32 v189, v189, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc2008bd 8a0345bd
	v_fma_mix_f32 v175, v15, v162, neg(0) op_sel_hi:[1,0,0]     ; cc2000af 8a03450f
(invalid instruction)                                        ; d769002f
	v_cndmask_b32_e32 v1, v169, v135, vcc_lo                    ; 02030fa9
	v_fma_mix_f32 v15, v15, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20080f 8a03450f
	buffer_load_b128 v[112:115], v4, s[16:19], null offen offset:64 ; c405c07c 40802070 00004004
	v_fma_mix_f32 v184, v18, v162, neg(0) op_sel_hi:[1,0,0]     ; cc2000b8 8a034512
(invalid instruction)                                        ; d769402f
	v_cndmask_b32_e32 v1, v170, v124, vcc_lo                    ; 0202f9aa
	v_fma_mix_f32 v18, v18, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200812 8a034512
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v171, v186, vcc_lo                    ; 020375ab
	buffer_load_b128 v[116:119], v4, s[16:19], null offen offset:80 ; c405c07c 40802074 00005004
	v_fma_mix_f32 v185, v19, v162, neg(0) op_sel_hi:[1,0,0]     ; cc2000b9 8a034513
	v_fma_mix_f32 v19, v19, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200813 8a034513
(invalid instruction)                                        ; d769002e
	v_cndmask_b32_e32 v1, v163, v133, vcc_lo                    ; 02030ba3
(invalid instruction)                                        ; d769402e
	v_cndmask_b32_e32 v1, v168, v134, vcc_lo                    ; 02030da8
(invalid instruction)                                        ; d769403c
	v_cndmask_b32_e32 v1, v172, v187, vcc_lo                    ; 020377ac
(invalid instruction)                                        ; d769003d
	v_cndmask_b32_e32 v1, v173, v188, vcc_lo                    ; 020379ad
	v_fma_mix_f32 v186, v30, v162, neg(0) op_sel_hi:[1,0,0]     ; cc2000ba 8a03451e
	v_fma_mix_f32 v30, v30, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20081e 8a03451e
(invalid instruction)                                        ; d769403d
	v_cndmask_b32_e32 v1, v174, v189, vcc_lo                    ; 02037bae
	v_fma_mix_f32 v187, v69, v162, neg(0) op_sel_hi:[1,0,0]     ; cc2000bb 8a034545
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v175, v15, vcc_lo                     ; 02021faf
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[20:21], v[36:37], 0 ; cc464098 1a024914
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v184, v18, vcc_lo                     ; 020225b8
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v185, v19, vcc_lo                     ; 020227b9
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v186, v30, vcc_lo                     ; 02023dba
	v_fma_mix_f32 v69, v69, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200845 8a034545
	v_fma_mix_f32 v188, v70, v162, neg(0) op_sel_hi:[1,0,0]     ; cc2000bc 8a034546
	v_fma_mix_f32 v70, v70, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200846 8a034546
	v_fma_mix_f32 v189, v71, v162, neg(0) op_sel_hi:[1,0,0]     ; cc2000bd 8a034547
	v_fma_mix_f32 v71, v71, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200847 8a034547
	v_fma_mix_f32 v3, v72, v162, neg(0) op_sel_hi:[1,0,0]       ; cc200003 8a034548
	v_fma_mix_f32 v72, v72, v162, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200848 8a034548
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v187, v69, vcc_lo                     ; 02028bbb
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v188, v70, vcc_lo                     ; 02028dbc
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[20:21], v[44:45], 0 ; cc464080 1a025914
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[20:21], v[42:43], 0 ; cc4640a8 1a025514
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[32:33], v[38:39], v[152:159] ; cc464098 1e624d20
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v189, v71, vcc_lo                     ; 02028fbd
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v3, v72, vcc_lo                       ; 02029103
	s_setreg_imm32_b32 hwreg(HW_REG_MODE, 23, 1), 1             ; b98005c1 00000001
	v_wmma_f32_16x16x16_fp8_fp8 v[66:73], v[20:21], v[46:47], 0 ; cc464042 1a025d14
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[32:33], v[6:7], v[128:135] ; cc464080 1e020d20
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[32:33], v[62:63], v[168:175] ; cc4640a8 1ea27d20
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[58:59], v[10:11], v[152:159] ; cc464098 1e62153a
	v_wmma_f32_16x16x16_fp8_fp8 v[66:73], v[32:33], v[60:61], v[66:73] ; cc464042 1d0a7920
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[58:59], v[52:53], v[128:135] ; cc464080 1e02693a
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[58:59], v[92:93], v[168:175] ; cc4640a8 1ea2b93a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[104:105], v[40:41], v[152:159] ; cc464098 1e625168
	v_wmma_f32_16x16x16_fp8_fp8 v[66:73], v[58:59], v[14:15], v[66:73] ; cc464042 1d0a1d3a
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[104:105], v[54:55], v[128:135] ; cc464080 1e026d68
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[104:105], v[64:65], v[168:175] ; cc4640a8 1ea28168
(invalid instruction)                                        ; d769001f
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d769401f
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d769401e
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[8:9], v[36:37], 0 ; cc464098 1a024908
	v_wmma_f32_16x16x16_fp8_fp8 v[66:73], v[104:105], v[18:19], v[66:73] ; cc464042 1d0a2568
(invalid instruction)                                        ; d7690014
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7694014
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694015
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d7690021
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d7694021
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690020
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d7694020
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[8:9], v[42:43], 0 ; cc4640a8 1a025508
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_dual_mul_f32 v43, v147, v51 :: v_dual_mul_f32 v42, v146, v50 ; c8c66793 2b2a6592
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[8:9], v[44:45], 0 ; cc464080 1a025908
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_dual_mul_f32 v45, v149, v89 :: v_dual_mul_f32 v44, v148, v88 ; c8c6b395 2d2cb194
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[12:13], v[38:39], v[152:159] ; cc464098 1e624d0c
(invalid instruction)                                        ; d769003a
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
(invalid instruction)                                        ; d769403a
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d769403b
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	v_wmma_f32_16x16x16_fp8_fp8 v[66:73], v[8:9], v[46:47], 0   ; cc464042 1a025d08
	v_dual_mul_f32 v47, v151, v91 :: v_dual_mul_f32 v46, v150, v90 ; c8c6b797 2f2eb596
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[12:13], v[62:63], v[168:175] ; cc4640a8 1ea27d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[12:13], v[6:7], v[128:135] ; cc464080 1e020d0c
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[16:17], v[10:11], v[152:159] ; cc464098 1e621510
	v_wmma_f32_16x16x16_fp8_fp8 v[66:73], v[12:13], v[60:61], v[66:73] ; cc464042 1d0a790c
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[16:17], v[92:93], v[168:175] ; cc4640a8 1ea2b910
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[16:17], v[52:53], v[128:135] ; cc464080 1e026910
	v_wmma_f32_16x16x16_fp8_fp8 v[152:159], v[56:57], v[40:41], v[152:159] ; cc464098 1e625138
	v_dual_mul_f32 v41, v145, v49 :: v_dual_mul_f32 v40, v144, v48 ; c8c66391 29286190
	v_wmma_f32_16x16x16_fp8_fp8 v[66:73], v[16:17], v[14:15], v[66:73] ; cc464042 1d0a1d10
	v_wmma_f32_16x16x16_fp8_fp8 v[168:175], v[56:57], v[64:65], v[168:175] ; cc4640a8 1ea28138
	v_dual_mul_f32 v65, v181, v49 :: v_dual_mul_f32 v64, v180, v48 ; c8c663b5 414061b4
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[56:57], v[54:55], v[128:135] ; cc464080 1e026d38
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v156, v157, vcc_lo                    ; 02033b9c
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                    ; 02033f9e
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                    ; 02033398
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v1, v154, v155, vcc_lo                    ; 0203379a
	v_wmma_f32_16x16x16_fp8_fp8 v[66:73], v[56:57], v[18:19], v[66:73] ; cc464042 1d0a2538
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v1, v168, v169, vcc_lo                    ; 020353a8
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                    ; 020357aa
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                    ; 02035bac
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                    ; 02035fae
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	v_dual_mul_f32 v129, v177, v49 :: v_dual_mul_f32 v128, v176, v48 ; c8c663b1 818061b0
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
	v_dual_mul_f32 v131, v179, v51 :: v_dual_mul_f32 v130, v178, v50 ; c8c667b3 838265b2
	v_dual_mul_f32 v133, v0, v89 :: v_dual_mul_f32 v132, v103, v88 ; c8c6b300 8584b167
	v_dual_mul_f32 v135, v2, v91 :: v_dual_mul_f32 v134, v1, v90 ; c8c6b702 8786b501
	v_dual_mul_f32 v145, v126, v49 :: v_dual_mul_f32 v144, v5, v48 ; c8c6637e 91906105
	v_dual_mul_f32 v147, v190, v51 :: v_dual_mul_f32 v146, v127, v50 ; c8c667be 9392657f
	v_dual_mul_f32 v149, v121, v89 :: v_dual_mul_f32 v148, v120, v88 ; c8c6b379 9594b178
	v_dual_mul_f32 v151, v123, v91 :: v_dual_mul_f32 v150, v122, v90 ; c8c6b77b 9796b57a
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[96:97], v[20:21], v[40:47] ; cc464028 1ca22960
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
	v_dual_mul_f32 v71, v76, v91 :: v_dual_mul_f32 v70, v75, v90 ; c8c6b74c 4746b54b
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_dual_mul_f32 v67, v183, v51 :: v_dual_mul_f32 v66, v182, v50 ; c8c667b7 434265b6
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
	v_dual_mul_f32 v69, v89, v35 :: v_dual_mul_f32 v68, v191, v88 ; c8c64759 4544b1bf
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                      ; 02029348
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[96:97], v[58:59], v[144:151] ; cc464090 1e427560
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[96:97], v[30:31], v[64:71] ; cc464040 1d023d60
	s_mul_i32 s39, s36, s12                                     ; 96270c24
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[96:97], v[32:33], v[128:135] ; cc464080 1e024160
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[108:109], v[6:7], v[40:47] ; cc464028 1ca20d6c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl1_add_u32 s39, ttmp9, s39                             ; 87272775
	v_wmma_f32_16x16x16_fp8_fp8 v[144:151], v[108:109], v[12:13], v[144:151] ; cc464090 1e42196c
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[108:109], v[8:9], v[64:71] ; cc464040 1d02116c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s39, s39, 9                                      ; 84278927
	v_wmma_f32_16x16x16_fp8_fp8 v[128:135], v[108:109], v[10:11], v[128:135] ; cc464080 1e02156c
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s40, s2, s39                                   ; 80282702
	s_addk_co_i32 s39, 0x200                                    ; b7a70200
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_add3_u32 v4, v125, s40, v79                               ; d6550004 053c517d
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v144, v145, vcc_lo                    ; 02032390
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s39, s2, s39                                   ; 80272702
	s_add_co_u32 s36, s36, 1                                    ; 80248124
(invalid instruction)                                        ; d7694012
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                    ; 02032792
(invalid instruction)                                        ; d7690013
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                    ; 02032b94
(invalid instruction)                                        ; d7694013
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                    ; 02032f96
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v132, v133, vcc_lo                    ; 02030b84
(invalid instruction)                                        ; d769400f
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                    ; 02030f86
(invalid instruction)                                        ; d769000e
	v_cndmask_b32_e32 v1, v128, v129, vcc_lo                    ; 02030380
(invalid instruction)                                        ; d769400e
	v_cndmask_b32_e32 v1, v130, v131, vcc_lo                    ; 02030782
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v5, v125, s39, v79                               ; d6550005 053c4f7d
	s_mul_i32 s36, s36, s12                                     ; 96240c24
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl1_add_u32 s36, ttmp9, s36                             ; 87242475
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s36, s36, 9                                      ; 84248924
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s41, s2, s36                                   ; 80292402
	s_addk_co_i32 s36, 0x200                                    ; b7a40200
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v16, v125, s41, v79                              ; d6550010 053c537d
	s_add_co_u32 s2, s2, s36                                    ; 80022402
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v17, v125, s2, v79                               ; d6550011 053c057d
	s_clause 0x3                                                ; bf850003
	buffer_store_b64 v[0:1], v4, s[24:27], null offen           ; c406c07c 40803000 00000004
	buffer_store_b64 v[2:3], v5, s[24:27], null offen           ; c406c07c 40803002 00000005
	buffer_store_b64 v[14:15], v16, s[24:27], null offen        ; c406c07c 4080300e 00000010
	buffer_store_b64 v[18:19], v17, s[24:27], null offen        ; c406c07c 40803012 00000011
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_dual_mul_f32 v41, v23, v113 :: v_dual_mul_f32 v40, v22, v112 ; c8c6e317 2928e116
	v_dual_mul_f32 v43, v25, v115 :: v_dual_mul_f32 v42, v24, v114 ; c8c6e719 2b2ae518
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_dual_mul_f32 v45, v27, v117 :: v_dual_mul_f32 v44, v26, v116 ; c8c6eb1b 2d2ce91a
	v_dual_mul_f32 v47, v29, v119 :: v_dual_mul_f32 v46, v28, v118 ; c8c6ef1d 2f2eed1c
	v_dual_mul_f32 v49, v81, v113 :: v_dual_mul_f32 v48, v80, v112 ; c8c6e351 3130e150
	v_dual_mul_f32 v51, v83, v115 :: v_dual_mul_f32 v50, v82, v114 ; c8c6e753 3332e552
	v_dual_mul_f32 v53, v85, v117 :: v_dual_mul_f32 v52, v84, v116 ; c8c6eb55 3534e954
	v_dual_mul_f32 v55, v87, v119 :: v_dual_mul_f32 v54, v86, v118 ; c8c6ef57 3736ed56
	v_dual_mul_f32 v65, v165, v113 :: v_dual_mul_f32 v64, v164, v112 ; c8c6e3a5 4140e1a4
	v_dual_mul_f32 v67, v167, v115 :: v_dual_mul_f32 v66, v166, v114 ; c8c6e7a7 4342e5a6
	v_dual_mul_f32 v69, v100, v117 :: v_dual_mul_f32 v68, v77, v116 ; c8c6eb64 4544e94d
	v_dual_mul_f32 v71, v102, v119 :: v_dual_mul_f32 v70, v101, v118 ; c8c6ef66 4746ed65
	v_dual_mul_f32 v81, v137, v113 :: v_dual_mul_f32 v80, v136, v112 ; c8c6e389 5150e188
	v_add3_u32 v18, v79, s40, s21                               ; d6550012 0054514f
	v_dual_mul_f32 v85, v141, v117 :: v_dual_mul_f32 v82, v138, v114 ; c8c6eb8d 5552e58a
	v_add3_u32 v19, v79, s39, s21                               ; d6550013 00544f4f
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[98:99], v[30:31], v[48:55] ; cc464030 1cc23d62
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[98:99], v[32:33], v[64:71] ; cc464040 1d024162
	v_dual_mul_f32 v83, v139, v115 :: v_dual_add_nc_u32 v18, v18, v125 ; c8e0e78b 5312fb12
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[98:99], v[20:21], v[40:47] ; cc464028 1ca22962
	v_add3_u32 v20, v79, s41, s21                               ; d6550014 0054534f
	v_add3_u32 v79, v79, s2, s21                                ; d655004f 0054054f
	v_dual_mul_f32 v84, v140, v116 :: v_dual_add_nc_u32 v19, v19, v125 ; c8e0e98c 5412fb13
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[110:111], v[8:9], v[48:55] ; cc464030 1cc2116e
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[110:111], v[10:11], v[64:71] ; cc464040 1d02156e
	v_dual_mul_f32 v87, v143, v119 :: v_dual_add_nc_u32 v20, v20, v125 ; c8e0ef8f 5714fb14
	v_dual_mul_f32 v86, v142, v118 :: v_dual_add_nc_u32 v79, v79, v125 ; c8e0ed8e 564efb4f
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[98:99], v[58:59], v[80:87] ; cc464050 1d427562
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[110:111], v[6:7], v[40:47] ; cc464028 1ca20d6e
(invalid instruction)                                        ; d7690003
	v_cndmask_b32_e32 v1, v52, v53, vcc_lo                      ; 02026b34
(invalid instruction)                                        ; d7694003
	v_cndmask_b32_e32 v1, v54, v55, vcc_lo                      ; 02026f36
(invalid instruction)                                        ; d7690002
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
(invalid instruction)                                        ; d7694002
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                      ; 02026732
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                      ; 02028b44
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v70, v71, vcc_lo                      ; 02028f46
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                      ; 02028742
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[110:111], v[12:13], v[80:87] ; cc464050 1d42196e
(invalid instruction)                                        ; d7690001
	v_cndmask_b32_e32 v1, v44, v45, vcc_lo                      ; 02025b2c
(invalid instruction)                                        ; d7694001
	v_cndmask_b32_e32 v1, v46, v47, vcc_lo                      ; 02025f2e
(invalid instruction)                                        ; d7690000
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                      ; 02025328
(invalid instruction)                                        ; d7694000
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                      ; 0202572a
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                      ; 0202a350
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                      ; 0202a752
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v1, v84, v85, vcc_lo                      ; 0202ab54
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v1, v86, v87, vcc_lo                      ; 0202af56
	s_clause 0x3                                                ; bf850003
	buffer_store_b64 v[0:1], v18, s[24:27], null offen          ; c406c07c 40803000 00000012
	buffer_store_b64 v[2:3], v19, s[24:27], null offen          ; c406c07c 40803002 00000013
	buffer_store_b64 v[4:5], v20, s[24:27], null offen          ; c406c07c 40803004 00000014
	buffer_store_b64 v[6:7], v79, s[24:27], null offen          ; c406c07c 40803006 0000004f
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
