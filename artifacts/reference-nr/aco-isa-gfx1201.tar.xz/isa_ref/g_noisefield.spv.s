BB0:
	v_and_b32_e32 v1, 7, v0                                     ; 36020087
	v_lshrrev_b32_e32 v0, 10, v0                                ; 3200008a
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_lshl_add_u32 v1, ttmp9, 3, v1                             ; d6460001 04050675
	v_lshl_add_u32 v0, ttmp7, 3, v0                             ; d6460000 04010673
	v_cmp_le_u32_e32 vcc_lo, s2, v1                             ; 7c960202
(invalid instruction)                                        ; d44b0003
	v_cndmask_b32_e32 v1, s3, v0, vcc_lo                        ; 02020003
	s_nor_b32 exec_lo, vcc_lo, s3                               ; 8f7e036a
	s_cbranch_execz BB6                                         ; bfa5008f
BB1:
	s_mul_i32 s4, s4, 0x9e3779b9                                ; 9604ff04 9e3779b9
(invalid instruction)                                        ; d72c0002
	v_cndmask_b32_e32 v1, 0x8da6b343, v1, vcc_lo                ; 020202ff 8da6b343
(invalid instruction)                                        ; d72c0003
	v_cndmask_b32_e32 v1, 0xd8163841, v0, vcc_lo                ; 020200ff d8163841
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_xor3_b32 v3, v3, s4, v2                                   ; d6400003 04080903
	s_mov_b32 s4, s1                                            ; be840001
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[8:11], s[0:1], 0x0                            ; f4004200 f8000000
	s_mov_b32 s3, 0x108ef2d9                                    ; be8300ff 108ef2d9
	v_xor_b32_e32 v3, 0x243f6a88, v3                            ; 3a0606ff 243f6a88
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v4, 28, v3                                ; 3208069c
	v_add_nc_u32_e32 v4, 4, v4                                  ; 4a080884
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v4, v4, v3                                ; 32080704
	v_xor_b32_e32 v4, v4, v3                                    ; 3a080704
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72c0004
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                        ; 02020803
	v_lshrrev_b32_e32 v5, 22, v4                                ; 320a0896
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_xor_b32_e32 v5, v5, v4                                    ; 3a0a0905
(invalid instruction)                                        ; d72c0009
	v_cndmask_b32_e32 v1, 0xfa6dc5f9, v5, vcc_lo                ; 02020aff fa6dc5f9
(invalid instruction)                                        ; d72c0006
	v_cndmask_b32_e32 v1, 0x2c9277b5, v5, vcc_lo                ; 02020aff 2c9277b5
(invalid instruction)                                        ; d72c000c
	v_cndmask_b32_e32 v1, 0xcaa5b80d, v5, vcc_lo                ; 02020aff caa5b80d
(invalid instruction)                                        ; d72c0005
	v_cndmask_b32_e32 v1, 0x83232c31, v5, vcc_lo                ; 02020aff 83232c31
	v_add_nc_u32_e32 v9, 0x4712a88e, v9                         ; 4a1212ff 4712a88e
	v_add_nc_u32_e32 v6, 0xac564b05, v6                         ; 4a0c0cff ac564b05
	s_mov_b32 s6, 0x33800000                                    ; be8600ff 33800000
	v_add_nc_u32_e32 v12, 0x21dd796b, v12                       ; 4a1818ff 21dd796b
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3) ; bf8701c3
	v_lshrrev_b32_e32 v10, 28, v9                               ; 3214129c
	v_lshrrev_b32_e32 v7, 28, v6                                ; 320e0c9c
	v_add_nc_u32_e32 v5, 0x3463e0ac, v5                         ; 4a0a0aff 3463e0ac
	v_lshrrev_b32_e32 v13, 28, v12                              ; 321a189c
	v_add_nc_u32_e32 v7, 4, v7                                  ; 4a0e0e84
	v_lshrrev_b32_e32 v15, 28, v5                               ; 321e0a9c
	v_add_nc_u32_e32 v13, 4, v13                                ; 4a1a1a84
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
	v_lshrrev_b32_e32 v7, v7, v6                                ; 320e0d07
	v_add_nc_u32_e32 v15, 4, v15                                ; 4a1e1e84
	v_xor_b32_e32 v7, v7, v6                                    ; 3a0e0d07
	v_lshrrev_b32_e32 v13, v13, v12                             ; 321a190d
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
(invalid instruction)                                        ; d72c0007
	v_cndmask_b32_e32 v1, s3, v7, vcc_lo                        ; 02020e03
	v_xor_b32_e32 v13, v13, v12                                 ; 3a1a190d
(invalid instruction)                                        ; d72c000d
	v_cndmask_b32_e32 v1, s3, v13, vcc_lo                       ; 02021a03
	v_lshrrev_b32_e32 v8, 8, v7                                 ; 32100e88
	v_lshrrev_b32_e32 v7, 30, v7                                ; 320e0e9e
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b1
	v_xad_u32 v7, v7, v8, 1                                     ; d6450007 02061107
	v_lshrrev_b32_e32 v14, 8, v13                               ; 321c1a88
	v_lshrrev_b32_e32 v13, 30, v13                              ; 321a1a9e
	v_cvt_f32_u32_e32 v7, v7                                    ; 7e0e0d07
	v_lshrrev_b32_e32 v15, v15, v5                              ; 321e0b0f
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870122
	v_dual_mul_f32 v7, s6, v7 :: v_dual_add_nc_u32 v10, 4, v10  ; c8e00e06 070a1484
	v_xor_b32_e32 v15, v15, v5                                  ; 3a1e0b0f
	v_lshrrev_b32_e32 v10, v10, v9                              ; 3214130a
	v_log_f32_e32 v7, v7                                        ; 7e0e4f07
(invalid instruction)                                        ; d72c000f
	v_cndmask_b32_e32 v1, s3, v15, vcc_lo                       ; 02021e03
	v_xor_b32_e32 v10, v10, v9                                  ; 3a14130a
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2) ; bf870141
(invalid instruction)                                        ; d72c000a
	v_cndmask_b32_e32 v1, s3, v10, vcc_lo                       ; 02021403
	v_lshrrev_b32_e32 v16, 8, v15                               ; 32201e88
	v_lshrrev_b32_e32 v15, 30, v15                              ; 321e1e9e
	v_xad_u32 v13, v13, v14, 1                                  ; d645000d 02061d0d
	v_xad_u32 v15, v15, v16, 1                                  ; d645000f 0206210f
	v_lshrrev_b32_e32 v11, 8, v10                               ; 32161488
	v_lshrrev_b32_e32 v10, 30, v10                              ; 3214149e
	v_cvt_f32_u32_e32 v13, v13                                  ; 7e1a0d0d
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3) ; bf870194
	v_cvt_f32_u32_e32 v15, v15                                  ; 7e1e0d0f
	v_xad_u32 v10, v10, v11, 1                                  ; d645000a 0206170a
	v_mul_f32_e32 v13, s6, v13                                  ; 101a1a06
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_mul_f32_e32 v15, s6, v15                                  ; 101e1e06
(invalid instruction)                                        ; d72c0000
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                        ; 02000500
	v_cvt_f32_u32_e32 v10, v10                                  ; 7e140d0a
	v_log_f32_e32 v13, v13                                      ; 7e1a4f0d
	v_cos_f32_e32 v15, v15                                      ; 7e1e6d0f
	v_dual_mul_f32 v7, 0xbfb17218, v7 :: v_dual_mul_f32 v10, s6, v10 ; c8c60eff 070a1406 bfb17218
	v_add_lshl_u32 v0, v0, v1, 1                                ; d6470000 02060300
	v_mul_f32_e32 v13, 0xbfb17218, v13                          ; 101a1aff bfb17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(TRANS32_DEP_2) ; bf870353
	v_cos_f32_e32 v17, v10                                      ; 7e226d0a
	v_sin_f32_e32 v10, v10                                      ; 7e146b0a
	v_sqrt_f32_e32 v7, v7                                       ; 7e0e6707
	v_add_lshl_u32 v0, s4, v0, 2                                ; d6470000 020a0004
	v_sqrt_f32_e32 v13, v13                                     ; 7e1a670d
	v_mul_f32_e32 v17, v7, v17                                  ; 10222307
	v_mul_f32_e32 v7, v7, v10                                   ; 100e1507
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b5
	v_mul_f32_e32 v13, v13, v15                                 ; 101a1f0d
	v_fma_mixlo_f16 v2, s5, v17, neg(0) op_sel_hi:[0,0,1]       ; cc214002 82022205
	v_fma_mixhi_f16 v2, s5, v7, neg(0) op_sel_hi:[0,0,1]        ; cc224002 82020e05
	v_fma_mixlo_f16 v3, s5, v13, neg(0) op_sel_hi:[0,0,1]       ; cc214003 82021a05
	v_mov_b16_e32 v3.h, 0                                       ; 7f063880
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b64 v[2:3], v0, s[8:11], null offen            ; c406c07c 40801002 00000000
BB6:
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
