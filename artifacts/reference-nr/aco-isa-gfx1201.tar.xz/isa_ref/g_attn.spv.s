BB0:
	s_mul_i32 s16, s13, s14                                     ; 96100e0d
	s_pack_hh_b32_b16 s17, ttmp7, 0                             ; 9a118073
	s_pack_ll_b32_b16 s18, ttmp7, 0                             ; 99128073
	s_cvt_f32_u32 s19, s16                                      ; be936510
	s_mul_i32 s14, s14, s17                                     ; 960e110e
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s18, s18, s14                                  ; 80120e12
(invalid instruction)                                        ; d6840013
	v_cndmask_b32_e32 v0, s19, v128, vcc_lo                     ; 02010013
	s_mul_i32 s18, s13, s18                                     ; 9612120d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s18, ttmp9, s18                                ; 80121275
	s_mul_f32 s19, s19, 0x4f7ffffe                              ; a213ff13 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s19, s19                                      ; be936713
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s20, s16, s19                                     ; 96141310
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s20, 0, s20                                    ; 81941480
	s_mul_hi_u32 s20, s19, s20                                  ; 96941413
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s19, s19, s20                                  ; 80131413
	s_lshr_b32 s21, s18, 4                                      ; 85158412
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s19, s21, s19                                  ; 96931315
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s19, s19, s16                                     ; 96131013
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s21, s21, s19                                  ; 81951315
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s22, s21, s16                                  ; 80961015
	s_cselect_b32 s21, s21, s22                                 ; 98151615
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s23, s21, s16                                  ; 80971015
	s_cselect_b32 s21, s21, s23                                 ; 98151715
	s_lshl_b32 s16, s16, 4                                      ; 84108410
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cvt_f32_u32 s24, s16                                      ; be986510
(invalid instruction)                                        ; d6840018
	v_cndmask_b32_e32 v0, s24, v128, vcc_lo                     ; 02010018
	s_mul_f32 s24, s24, 0x4f7ffffe                              ; a218ff18 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cvt_u32_f32 s24, s24                                      ; be986718
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s25, s16, s24                                     ; 96191810
	s_cvt_f32_u32 s30, s13                                      ; be9e650d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_sub_co_i32 s25, 0, s25                                    ; 81991980
(invalid instruction)                                        ; d684001e
	v_cndmask_b32_e32 v0, s30, v128, vcc_lo                     ; 0201001e
	s_mul_hi_u32 s25, s24, s25                                  ; 96991918
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s24, s24, s25                                  ; 80181918
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s24, s18, s24                                  ; 96981812
	s_mul_f32 s30, s30, 0x4f7ffffe                              ; a21eff1e 4f7ffffe
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s26, s24, s16                                     ; 961a1018
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_sub_co_i32 s26, s18, s26                                  ; 819a1a12
	s_cvt_u32_f32 s30, s30                                      ; be9e671e
	s_sub_co_u32 s27, s26, s16                                  ; 809b101a
	s_absdiff_i32 s29, src_scc, 1                               ; 831d81fd
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s31, s13, s30                                     ; 961f1e0d
	s_add_co_u32 s24, s24, s29                                  ; 80181d18
	s_sub_co_u32 s27, s26, s16                                  ; 809b101a
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_cselect_b32 s26, s26, s27                                 ; 981a1b1a
	s_cmp_ge_u32 s26, s16                                       ; bf09101a
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s24, s24, src_scc                              ; 8018fd18
	s_and_b32 s18, s18, 15                                      ; 8b128f12
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl4_add_u32 s24, s24, s18                               ; 88981218
	s_sub_co_i32 s31, 0, s31                                    ; 819f1f80
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s31, s30, s31                                  ; 969f1f1e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s30, s30, s31                                  ; 801e1f1e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_hi_u32 s30, s21, s30                                  ; 969e1e15
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s32, s30, s13                                     ; 96200d1e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_i32 s21, s21, s32                                  ; 81952015
	s_sub_co_u32 s33, s21, s13                                  ; 80a10d15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_absdiff_i32 s35, src_scc, 1                               ; 832381fd
	s_sub_co_u32 s33, s21, s13                                  ; 80a10d15
	s_cselect_b32 s21, s21, s33                                 ; 98152115
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_sub_co_u32 s13, s21, s13                                  ; 808d0d15
	s_mov_b32 s36, src_scc                                      ; bea400fd
	s_absdiff_i32 s37, src_scc, 1                               ; 832581fd
	s_cmp_lg_i32 s36, 0                                         ; bf018024
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 s21, s21, s13                                 ; 98150d15
	s_add_co_u32 s30, s30, s35                                  ; 801e231e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s30, s30, s37                                  ; 801e251e
	s_cmp_lg_i32 s12, -1                                        ; bf01c10c
	s_cbranch_scc0 BB2                                          ; bfa1000f
BB1:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_load_b128 s[16:19], s[16:17], 0x20                        ; f4004408 f8000020
	s_lshl2_add_u32 s13, s12, 24                                ; 878d980c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b32 s13, s[16:19], s13 offset:0x0             ; f4020348 1a000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s13, 0x54434852                                ; bf01ff0d 54434852
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB3                                                ; bfa00001
BB2:
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB3:
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_and_b32 s13, vcc_lo, exec_lo                              ; 8b0d7e6a
	s_cselect_b32 s12, -1, s12                                  ; 980c0cc1
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s12, -1                                        ; bf01c10c
	s_cbranch_scc0 BB5                                          ; bfa1000e
BB4:
	s_mov_b32 s16, s0                                           ; be900000
	s_movk_i32 s17, 0x8000                                      ; b0118000
	s_load_b128 s[16:19], s[16:17], 0x20                        ; f4004408 f8000020
	s_lshl2_add_u32 s13, s12, 8                                 ; 878d880c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s17, 14                                       ; be91108e
	s_buffer_load_b64 s[16:17], s[16:19], s13 offset:0x0        ; f4022408 1a000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s16, -1                                        ; bf01c110
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cselect_b32 vcc_lo, -1, 0                                 ; 986a80c1
	s_branch BB6                                                ; bfa00002
BB5:
	s_mov_b32 s17, -1                                           ; be9100c1
	s_mov_b32 vcc_lo, 0                                         ; beea0080
BB6:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s13, vcc_lo, exec_lo                              ; 8b0d7e6a
	s_cbranch_scc0 BB44                                         ; bfa10074
BB7:
	s_and_b32 s13, ttmp8, 0x3e000000                            ; 8b0dff74 3e000000
	s_cbranch_scc1 BB42                                         ; bfa2006f
BB8:
	s_mov_b32 s18, s0                                           ; be920000
	s_movk_i32 s19, 0x8000                                      ; b0138000
	s_load_b128 s[32:35], s[18:19], 0x20                        ; f4004809 f8000020
	s_lshl_b32 s12, s12, 2                                      ; 840c820c
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s14, s12, 8                                    ; 800e880c
	s_add_co_u32 s16, s12, 16                                   ; 8010900c
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s33, 14                                       ; bea1108e
	s_clause 0x2                                                ; bf850002
	s_buffer_load_b32 s13, s[32:35], s12 offset:0x0             ; f4020350 18000000
	s_buffer_load_b32 s14, s[32:35], s14 offset:0x0             ; f4020390 1c000000
	s_buffer_load_b32 s16, s[32:35], s16 offset:0x0             ; f4020410 20000000
	s_load_b128 s[36:39], s[18:19], 0x0                         ; f4004909 f8000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s16, s16, 2                                      ; 84108210
	buffer_load_b32 v1, off, s[36:39], s16 scope:SCOPE_DEV      ; c4050010 00884801 00000000
	s_lshl1_add_u32 s18, s21, s10                               ; 87120a15
	s_lshl1_add_u32 s19, s30, s11                               ; 87130b1e
	s_bfm_b32 s16, 1, 16                                        ; 95109081
	s_mov_b32 s22, 0                                            ; be960080
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s20, v1                                 ; 7e280501
BB9:
	s_and_b32 s23, s22, 1                                       ; 8b178116
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s23, s18, s23                                  ; 80171712
	s_lshr_b32 s25, s22, 1                                      ; 85198116
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s25, s19, s25                                  ; 80191913
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s26, s25, s23                                     ; 891a1719
	s_cmp_lt_i32 s23, s8                                        ; bf040817
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_mov_b32 s27, src_scc                                      ; be9b00fd
	s_cmp_lt_i32 s25, s9                                        ; bf040919
	s_and_b32 s27, src_scc, s27                                 ; 8b1b1bfd
	s_cmp_ge_i32 s26, 0                                         ; bf03801a
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_b32 s27, src_scc, s27                                 ; 8b1b1bfd
	s_cbranch_scc0 BB22                                         ; bfa10025
BB10:
	s_mul_i32 s25, s25, s8                                      ; 96190819
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s25, s25, s23                                  ; 80191719
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s25, s14, s25                                  ; 8019190e
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s25, s25, 2                                      ; 84198219
	s_buffer_load_b32 s25, s[32:35], s25 offset:0x0             ; f4020650 32000000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cmp_lg_i32 s25, -1                                        ; bf01c119
	s_cbranch_scc0 BB22                                         ; bfa10019
BB11:
	s_branch BB12                                               ; bfa00001
BB17:
	s_add_co_u32 s16, s16, -1                                   ; 8010c110
BB12:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_lg_i32 s16, 0                                         ; bf018010
	s_cbranch_scc0 BB14                                         ; bfa10010
BB13:
	s_and_b32 s23, s25, 0xfffff                                 ; 8b17ff19 000fffff
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_add_co_u32 s23, s13, s23                                  ; 8017170d
	s_lshl_b32 s23, s23, 2                                      ; 84178217
	buffer_load_b32 v1, off, s[36:39], s23 scope:SCOPE_DEV      ; c4050017 00884801 00000000
	s_lshr_b32 s26, s25, 20                                     ; 851a9419
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1) ; bf8704c9
	s_mul_i32 s26, s26, s20                                     ; 961a141a
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_readfirstlane_b32 s27, v1                                 ; 7e360501
	s_cmp_lt_u32 s27, s26                                       ; bf0a1a1b
	s_cselect_b32 s28, -1, 0                                    ; 981c80c1
	s_branch BB15                                               ; bfa00001
BB14:
	s_mov_b32 s28, 0                                            ; be9c0080
BB15:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_and_not1_b32 s28, exec_lo, s28                            ; 911c1c7e
	s_cbranch_scc0 BB17                                         ; bfa1ffe8
BB22:
	s_add_co_u32 s22, s22, 1                                    ; 80168116
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_cmp_ge_u32 s22, 4                                         ; bf098416
	s_cbranch_scc0 BB9                                          ; bfa1ffc6
BB25:
	s_cmp_eq_i32 s16, 0                                         ; bf008010
	s_cbranch_scc0 BB27                                         ; bfa10002
BB26:
	s_mov_b32 s13, 1                                            ; be8d0081
	s_branch BB28                                               ; bfa00001
BB27:
	s_mov_b32 s13, 0                                            ; be8d0080
BB28:
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mov_b32 exec_lo, s13                                      ; befe000d
	s_cbranch_execz BB40                                        ; bfa5000e
BB29:
	s_ctz_i32_b32 s13, exec_lo                                  ; be8d087e
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_lshl_b32 s13, 1, s13                                      ; 840d0d81
	s_and_saveexec_b32 s13, s13                                 ; be8d200d
	s_cbranch_execz BB40                                        ; bfa50009
BB30:
	s_add_co_u32 s12, s12, 20                                   ; 800c940c
	s_buffer_load_b32 s12, s[32:35], s12 offset:0x0             ; f4020310 18000000
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_lshl_b32 s12, s12, 2                                      ; 840c820c
	buffer_atomic_max_u32 v1, off, s[36:39], s12                ; c40ec00c 00804801 00000000
BB40:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
BB42:
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
BB44:
	v_and_b32_e32 v2, 31, v0                                    ; 3604009f
	v_lshrrev_b32_e32 v1, 5, v0                                 ; 32020085
	s_mul_i32 s7, s30, s7                                       ; 9607071e
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_add_co_u32 s7, s7, s21                                    ; 80071507
	v_readfirstlane_b32 s12, v1                                 ; 7e180501
	s_lshl_b32 s13, s12, 5                                      ; 840d850c
	s_lshl_b32 s14, s12, 4                                      ; 840e840c
	s_branch BB45                                               ; bfa00003
BB90:
	s_barrier_signal -1                                         ; be804ec1
	s_add_co_u32 s24, s24, s15                                  ; 80180f18
	s_barrier_wait 0xffff                                       ; bf94ffff
BB45:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s24, 16                                        ; bf099018
	s_cbranch_scc1 BB91                                         ; bfa21177
BB47:
	v_lshrrev_b32_e32 v1, 4, v2                                 ; 32020484
	v_lshlrev_b32_e32 v6, 4, v2                                 ; 300c0484
	v_and_b32_e32 v3, 15, v0                                    ; 3606008f
	s_lshl1_add_u32 s16, s21, s10                               ; 87100a15
	s_lshl1_add_u32 s18, s30, s11                               ; 87120b1e
	v_lshlrev_b32_e32 v1, 3, v1                                 ; 30020283
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s19, s18, s12                                  ; 80130c12
	s_max_i32 s20, s16, 0                                       ; 8a148010
	s_add_co_u32 s22, s8, -1                                    ; 8016c108
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshl_add_u32 v4, v3, 4, v1                                ; d6460004 04050903
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s20, s20, s22                                     ; 89141614
	s_add_co_u32 s23, s9, -1                                    ; 8017c109
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_max_i32 s25, s19, 0                                       ; 8a198013
	s_mul_i32 s29, s24, 0x60                                    ; 961dff18 00000060
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s25, s25, s23                                     ; 89191719
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s25, s25, s8                                      ; 96190819
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s20, s25, s20                                  ; 80141419
	s_lshr_b32 s26, s6, 4                                       ; 851a8406
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s20, s20, s26                                     ; 96141a14
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s20, s20, 8                                      ; 84148814
	s_add_co_u32 s27, s16, 1                                    ; 801b8110
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v5, v4, s1, s20                                  ; d6550005 00500304
	s_max_i32 s28, s27, 0                                       ; 8a1c801b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s28, s28, s22                                     ; 891c161c
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s25, s25, s28                                  ; 80191c19
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s25, s25, s26                                     ; 96191a19
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s25, s25, 8                                      ; 84198819
	s_lshr_b32 s29, s29, 5                                      ; 851d851d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v4, v4, s1, s25                                  ; d6550004 00640304
	s_mul_i32 s31, s29, s26                                     ; 961f1a1d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s31, s31, 9                                      ; 841f891f
	s_add_co_u32 s32, s29, 1                                    ; 8020811d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v7, v6, s3, s31                                  ; d6550007 007c0706
	s_mul_i32 s32, s32, s26                                     ; 96201a20
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s32, s32, 9                                      ; 84208920
	s_add_co_u32 s29, s29, 2                                    ; 801d821d
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v8, v6, s3, s32                                  ; d6550008 00800706
	s_mul_i32 s29, s29, s26                                     ; 961d1a1d
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s29, s29, 9                                      ; 841d891d
	s_min_i32 s33, s19, s16                                     ; 89211013
	s_cmp_ge_i32 s16, s8                                        ; bf030810
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v6, v6, s3, s29                                  ; d6550006 00740706
	s_mov_b32 s34, src_scc                                      ; bea200fd
	s_cmp_ge_i32 s19, s9                                        ; bf030913
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_mov_b32 s35, src_scc                                      ; bea300fd
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_or_b32 s34, src_scc, s34                                  ; 8c2222fd
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s33, 0                                         ; bf048021
	v_lshrrev_b32_e32 v5, 2, v5                                 ; 320a0a82
	v_lshrrev_b32_e32 v4, 2, v4                                 ; 32080882
	v_lshrrev_b32_e32 v7, 2, v7                                 ; 320e0e82
	v_lshrrev_b32_e32 v8, 2, v8                                 ; 32101082
	v_lshrrev_b32_e32 v6, 2, v6                                 ; 320c0c82
	s_or_b32 s34, src_scc, s34                                  ; 8c2222fd
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_mov_b32 s36, src_scc                                      ; bea400fd
	s_min_i32 s19, s19, s27                                     ; 89131b13
	s_cmp_ge_i32 s27, s8                                        ; bf03081b
	s_or_b32 s35, s35, src_scc                                  ; 8c23fd23
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lt_i32 s19, 0                                         ; bf048013
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1) ; bf870499
	s_or_b32 s35, src_scc, s35                                  ; 8c2323fd
	s_mov_b32 s37, src_scc                                      ; bea500fd
	s_absdiff_i32 s38, s36, 1                                   ; 83268124
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_lg_i32 s37, 0                                         ; bf018025
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1) ; bf8704b9
	s_cselect_b32 s39, 0, 2                                     ; 98278280
	s_mov_b32 s40, src_scc                                      ; bea800fd
	s_or_b32 s38, s38, s39                                      ; 8c262726
	s_cmp_eq_i32 s38, 3                                         ; bf008326
	s_cbranch_scc0 BB59                                         ; bfa106a6
BB48:
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v16, 0              ; ca100080 11100080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	s_mov_b32 s19, 0                                            ; be930080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v60, 0              ; ca100080 3d3c0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v62, 0              ; ca100080 3f3e0080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v64, 0              ; ca100080 41400080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v66, 0              ; ca100080 43420080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v68, 0              ; ca100080 45440080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v70, 0              ; ca100080 47460080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v72, 0              ; ca100080 49480080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v74, 0              ; ca100080 4b4a0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v76, 0              ; ca100080 4d4c0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v78, 0              ; ca100080 4f4e0080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v80, 0              ; ca100080 51500080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v82, 0              ; ca100080 53520080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v84, 0              ; ca100080 55540080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v86, 0              ; ca100080 57560080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v88, 0              ; ca100080 59580080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v90, 0              ; ca100080 5b5a0080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v92, 0              ; ca100080 5d5c0080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v94, 0              ; ca100080 5f5e0080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v96, 0              ; ca100080 61600080
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v98, 0              ; ca100080 63620080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v100, 0            ; ca100080 65640080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v102, 0            ; ca100080 67660080
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v104, 0            ; ca100080 69680080
	v_dual_mov_b32 v107, 0 :: v_dual_mov_b32 v106, 0            ; ca100080 6b6a0080
	v_dual_mov_b32 v109, 0 :: v_dual_mov_b32 v108, 0            ; ca100080 6d6c0080
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v110, 0            ; ca100080 6f6e0080
	s_branch BB49                                               ; bfa00167
	s_nop 0                                                     ; bf800000
BB51:
	s_mov_b32 s28, s0                                           ; be9c0000
	s_movk_i32 s29, 0x8000                                      ; b01d8000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[32:35], s[28:29], 0x40                        ; f400480e f8000040
	s_load_b128 s[44:47], s[28:29], 0x20                        ; f4004b0e f8000020
	s_lshl_b32 s20, s19, 2                                      ; 84148213
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v9, s20, v5, 2                               ; d6470009 020a0a14
	v_add_lshl_u32 v10, s20, v4, 2                              ; d647000a 020a0814
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x1                                                ; bf850001
	buffer_load_b64 v[12:13], v9, s[32:35], null offen          ; c405407c 4080400c 00000009
	buffer_load_b64 v[14:15], v10, s[32:35], null offen         ; c405407c 4080400e 0000000a
	s_lshl_b32 s25, s19, 3                                      ; 84198313
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v11, s25, v7, 2                              ; d647000b 020a0e19
	v_add_lshl_u32 v112, s25, v8, 2                             ; d6470070 020a1019
	v_add_lshl_u32 v113, s25, v6, 2                             ; d6470071 020a0c19
	s_clause 0x14                                               ; bf850014
	buffer_load_b128 v[116:119], v11, s[44:47], null offen      ; c405c07c 40805874 0000000b
	buffer_load_b128 v[120:123], v112, s[44:47], null offen     ; c405c07c 40805878 00000070
	buffer_load_b128 v[124:127], v113, s[44:47], null offen     ; c405c07c 4080587c 00000071
	buffer_load_b128 v[128:131], v11, s[44:47], null offen offset:512 ; c405c07c 40805880 0002000b
	buffer_load_b128 v[132:135], v112, s[44:47], null offen offset:512 ; c405c07c 40805884 00020070
	buffer_load_b128 v[136:139], v113, s[44:47], null offen offset:512 ; c405c07c 40805888 00020071
	buffer_load_b128 v[140:143], v11, s[44:47], null offen offset:1024 ; c405c07c 4080588c 0004000b
	buffer_load_b128 v[144:147], v112, s[44:47], null offen offset:1024 ; c405c07c 40805890 00040070
	buffer_load_b128 v[148:151], v113, s[44:47], null offen offset:1024 ; c405c07c 40805894 00040071
	buffer_load_b128 v[152:155], v11, s[44:47], null offen offset:1536 ; c405c07c 40805898 0006000b
	buffer_load_b128 v[156:159], v112, s[44:47], null offen offset:1536 ; c405c07c 4080589c 00060070
	buffer_load_b128 v[160:163], v113, s[44:47], null offen offset:1536 ; c405c07c 408058a0 00060071
	buffer_load_b128 v[164:167], v11, s[44:47], null offen offset:2048 ; c405c07c 408058a4 0008000b
	buffer_load_b128 v[168:171], v112, s[44:47], null offen offset:2048 ; c405c07c 408058a8 00080070
	buffer_load_b128 v[172:175], v113, s[44:47], null offen offset:2048 ; c405c07c 408058ac 00080071
	buffer_load_b128 v[176:179], v11, s[44:47], null offen offset:2560 ; c405c07c 408058b0 000a000b
	buffer_load_b128 v[180:183], v112, s[44:47], null offen offset:2560 ; c405c07c 408058b4 000a0070
	buffer_load_b128 v[184:187], v113, s[44:47], null offen offset:2560 ; c405c07c 408058b8 000a0071
	buffer_load_b128 v[188:191], v11, s[44:47], null offen offset:3072 ; c405c07c 408058bc 000c000b
	buffer_load_b128 v[192:195], v112, s[44:47], null offen offset:3072 ; c405c07c 408058c0 000c0070
	buffer_load_b128 v[196:199], v113, s[44:47], null offen offset:3072 ; c405c07c 408058c4 000c0071
	s_clause 0xd                                                ; bf85000d
	buffer_load_b64 v[114:115], v9, s[32:35], null offen offset:256 ; c405407c 40804072 00010009
	buffer_load_b64 v[200:201], v10, s[32:35], null offen offset:256 ; c405407c 408040c8 0001000a
	buffer_load_b64 v[202:203], v9, s[32:35], null offen offset:512 ; c405407c 408040ca 00020009
	buffer_load_b64 v[204:205], v10, s[32:35], null offen offset:512 ; c405407c 408040cc 0002000a
	buffer_load_b64 v[206:207], v9, s[32:35], null offen offset:768 ; c405407c 408040ce 00030009
	buffer_load_b64 v[208:209], v10, s[32:35], null offen offset:768 ; c405407c 408040d0 0003000a
	buffer_load_b64 v[210:211], v9, s[32:35], null offen offset:1024 ; c405407c 408040d2 00040009
	buffer_load_b64 v[212:213], v10, s[32:35], null offen offset:1024 ; c405407c 408040d4 0004000a
	buffer_load_b64 v[214:215], v9, s[32:35], null offen offset:1280 ; c405407c 408040d6 00050009
	buffer_load_b64 v[216:217], v10, s[32:35], null offen offset:1280 ; c405407c 408040d8 0005000a
	buffer_load_b64 v[218:219], v9, s[32:35], null offen offset:1536 ; c405407c 408040da 00060009
	buffer_load_b64 v[220:221], v10, s[32:35], null offen offset:1536 ; c405407c 408040dc 0006000a
	buffer_load_b64 v[222:223], v9, s[32:35], null offen offset:1792 ; c405407c 408040de 00070009
	buffer_load_b64 v[224:225], v10, s[32:35], null offen offset:1792 ; c405407c 408040e0 0007000a
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[228:231], v11, s[44:47], null offen offset:3584 ; c405c07c 408058e4 000e000b
	buffer_load_b128 v[232:235], v112, s[44:47], null offen offset:3584 ; c405c07c 408058e8 000e0070
	buffer_load_b128 v[236:239], v113, s[44:47], null offen offset:3584 ; c405c07c 408058ec 000e0071
	s_addk_co_i32 s19, 0x80                                     ; b7930080
	s_wait_loadcnt 0x25                                         ; bfc00025
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[116:117], v[12:13], v[16:23] ; cc464010 1c421974
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[118:119], v[12:13], v[24:31] ; cc464018 1c621976
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[116:117], v[14:15], v[64:71] ; cc464040 1d021d74
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[118:119], v[14:15], v[72:79] ; cc464048 1d221d76
	s_wait_loadcnt 0x24                                         ; bfc00024
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[120:121], v[12:13], v[32:39] ; cc464020 1c821978
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[122:123], v[12:13], v[40:47] ; cc464028 1ca2197a
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[120:121], v[14:15], v[80:87] ; cc464050 1d421d78
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[122:123], v[14:15], v[88:95] ; cc464058 1d621d7a
	s_wait_loadcnt 0x23                                         ; bfc00023
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[12:13], v[124:125], v[48:55] ; cc464030 1cc2f90c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[12:13], v[126:127], v[56:63] ; cc464038 1ce2fd0c
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[14:15], v[124:125], v[96:103] ; cc464060 1d82f90e
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[14:15], v[126:127], v[104:111] ; cc464068 1da2fd0e
	s_wait_loadcnt 0x10                                         ; bfc00010
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[128:129], v[114:115], v[16:23] ; cc464010 1c42e580
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[130:131], v[114:115], v[24:31] ; cc464018 1c62e582
	s_wait_loadcnt 0xf                                          ; bfc0000f
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[128:129], v[200:201], v[64:71] ; cc464040 1d039180
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[130:131], v[200:201], v[72:79] ; cc464048 1d239182
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[132:133], v[114:115], v[32:39] ; cc464020 1c82e584
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[134:135], v[114:115], v[40:47] ; cc464028 1ca2e586
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[132:133], v[200:201], v[80:87] ; cc464050 1d439184
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[134:135], v[200:201], v[88:95] ; cc464058 1d639186
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[114:115], v[136:137], v[48:55] ; cc464030 1cc31172
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[114:115], v[138:139], v[56:63] ; cc464038 1ce31572
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[200:201], v[136:137], v[96:103] ; cc464060 1d8311c8
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[200:201], v[138:139], v[104:111] ; cc464068 1da315c8
	s_wait_loadcnt 0xe                                          ; bfc0000e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[140:141], v[202:203], v[16:23] ; cc464010 1c43958c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[142:143], v[202:203], v[24:31] ; cc464018 1c63958e
	s_wait_loadcnt 0xd                                          ; bfc0000d
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[140:141], v[204:205], v[64:71] ; cc464040 1d03998c
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[142:143], v[204:205], v[72:79] ; cc464048 1d23998e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[144:145], v[202:203], v[32:39] ; cc464020 1c839590
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[146:147], v[202:203], v[40:47] ; cc464028 1ca39592
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[144:145], v[204:205], v[80:87] ; cc464050 1d439990
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[146:147], v[204:205], v[88:95] ; cc464058 1d639992
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[202:203], v[148:149], v[48:55] ; cc464030 1cc329ca
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[202:203], v[150:151], v[56:63] ; cc464038 1ce32dca
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[204:205], v[148:149], v[96:103] ; cc464060 1d8329cc
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[204:205], v[150:151], v[104:111] ; cc464068 1da32dcc
	s_wait_loadcnt 0xc                                          ; bfc0000c
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[152:153], v[206:207], v[16:23] ; cc464010 1c439d98
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[154:155], v[206:207], v[24:31] ; cc464018 1c639d9a
	s_wait_loadcnt 0xb                                          ; bfc0000b
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[152:153], v[208:209], v[64:71] ; cc464040 1d03a198
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[154:155], v[208:209], v[72:79] ; cc464048 1d23a19a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[156:157], v[206:207], v[32:39] ; cc464020 1c839d9c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[158:159], v[206:207], v[40:47] ; cc464028 1ca39d9e
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[156:157], v[208:209], v[80:87] ; cc464050 1d43a19c
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[158:159], v[208:209], v[88:95] ; cc464058 1d63a19e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[206:207], v[160:161], v[48:55] ; cc464030 1cc341ce
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[206:207], v[162:163], v[56:63] ; cc464038 1ce345ce
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[208:209], v[160:161], v[96:103] ; cc464060 1d8341d0
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[208:209], v[162:163], v[104:111] ; cc464068 1da345d0
	s_wait_loadcnt 0xa                                          ; bfc0000a
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[164:165], v[210:211], v[16:23] ; cc464010 1c43a5a4
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[166:167], v[210:211], v[24:31] ; cc464018 1c63a5a6
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[164:165], v[212:213], v[64:71] ; cc464040 1d03a9a4
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[166:167], v[212:213], v[72:79] ; cc464048 1d23a9a6
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[168:169], v[210:211], v[32:39] ; cc464020 1c83a5a8
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[170:171], v[210:211], v[40:47] ; cc464028 1ca3a5aa
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[168:169], v[212:213], v[80:87] ; cc464050 1d43a9a8
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[170:171], v[212:213], v[88:95] ; cc464058 1d63a9aa
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[210:211], v[172:173], v[48:55] ; cc464030 1cc359d2
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[210:211], v[174:175], v[56:63] ; cc464038 1ce35dd2
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[212:213], v[172:173], v[96:103] ; cc464060 1d8359d4
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[212:213], v[174:175], v[104:111] ; cc464068 1da35dd4
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[176:177], v[214:215], v[16:23] ; cc464010 1c43adb0
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[178:179], v[214:215], v[24:31] ; cc464018 1c63adb2
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[176:177], v[216:217], v[64:71] ; cc464040 1d03b1b0
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[178:179], v[216:217], v[72:79] ; cc464048 1d23b1b2
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[180:181], v[214:215], v[32:39] ; cc464020 1c83adb4
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[182:183], v[214:215], v[40:47] ; cc464028 1ca3adb6
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[180:181], v[216:217], v[80:87] ; cc464050 1d43b1b4
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[182:183], v[216:217], v[88:95] ; cc464058 1d63b1b6
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[214:215], v[184:185], v[48:55] ; cc464030 1cc371d6
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[214:215], v[186:187], v[56:63] ; cc464038 1ce375d6
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[216:217], v[184:185], v[96:103] ; cc464060 1d8371d8
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[216:217], v[186:187], v[104:111] ; cc464068 1da375d8
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[188:189], v[218:219], v[16:23] ; cc464010 1c43b5bc
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[190:191], v[218:219], v[24:31] ; cc464018 1c63b5be
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[188:189], v[220:221], v[64:71] ; cc464040 1d03b9bc
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[190:191], v[220:221], v[72:79] ; cc464048 1d23b9be
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[192:193], v[218:219], v[32:39] ; cc464020 1c83b5c0
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[194:195], v[218:219], v[40:47] ; cc464028 1ca3b5c2
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[192:193], v[220:221], v[80:87] ; cc464050 1d43b9c0
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[194:195], v[220:221], v[88:95] ; cc464058 1d63b9c2
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[218:219], v[196:197], v[48:55] ; cc464030 1cc389da
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[218:219], v[198:199], v[56:63] ; cc464038 1ce38dda
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[220:221], v[196:197], v[96:103] ; cc464060 1d8389dc
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[220:221], v[198:199], v[104:111] ; cc464068 1da38ddc
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[228:229], v[222:223], v[16:23] ; cc464010 1c43bde4
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[230:231], v[222:223], v[24:31] ; cc464018 1c63bde6
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[228:229], v[224:225], v[64:71] ; cc464040 1d03c1e4
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[230:231], v[224:225], v[72:79] ; cc464048 1d23c1e6
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[232:233], v[222:223], v[32:39] ; cc464020 1c83bde8
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[234:235], v[222:223], v[40:47] ; cc464028 1ca3bdea
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[232:233], v[224:225], v[80:87] ; cc464050 1d43c1e8
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[234:235], v[224:225], v[88:95] ; cc464058 1d63c1ea
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[222:223], v[236:237], v[48:55] ; cc464030 1cc3d9de
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[222:223], v[238:239], v[56:63] ; cc464038 1ce3ddde
	v_wmma_f32_16x16x16_fp8_fp8 v[96:103], v[224:225], v[236:237], v[96:103] ; cc464060 1d83d9e0
	v_wmma_f32_16x16x16_fp8_fp8 v[104:111], v[224:225], v[238:239], v[104:111] ; cc464068 1da3dde0
BB49:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s19, s6                                        ; bf090613
	s_cbranch_scc0 BB51                                         ; bfa1fe97
BB52:
	s_cmp_lg_i32 s36, 0                                         ; bf018024
	s_cbranch_scc1 BB54                                         ; bfa2025c
BB53:
	v_cvt_f16_f32_e32 v4, v48                                   ; 7e081530
(invalid instruction)                                        ; 7f081538
	s_movk_i32 s19, 0x5f00                                      ; b0135f00
	s_movk_i32 s20, 0xdf00                                      ; b014df00
	v_cvt_f16_f32_e32 v7, v49                                   ; 7e0e1531
(invalid instruction)                                        ; 7f0e1539
	v_cvt_f16_f32_e32 v10, v50                                  ; 7e141532
(invalid instruction)                                        ; 7f14153a
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c0004
	v_subrev_f32_e32 v0, v4, v20                                ; 0a002904
	v_cvt_f16_f32_e32 v13, v51                                  ; 7e1a1533
(invalid instruction)                                        ; 7f1a153b
(invalid instruction)                                        ; cc1c0007
	v_subrev_f32_e32 v0, v7, v20                                ; 0a002907
(invalid instruction)                                        ; cc1c000a
	v_subrev_f32_e32 v0, v10, v20                               ; 0a00290a
(invalid instruction)                                        ; cc1b0004
	v_subrev_f32_e32 v0, v4, v19                                ; 0a002704
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v20                               ; 0a00290d
(invalid instruction)                                        ; cc1b0007
	v_subrev_f32_e32 v0, v7, v19                                ; 0a002707
(invalid instruction)                                        ; cc1b000a
	v_subrev_f32_e32 v0, v10, v19                               ; 0a00270a
	v_cvt_f32_f16_e32 v5, v132/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a1784
	v_cvt_f32_f16_e32 v4, v4                                    ; 7e081704
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v19                               ; 0a00270d
	v_cvt_f32_f16_e32 v8, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e101787
	v_cvt_f32_f16_e32 v7, v7                                    ; 7e0e1707
	v_cvt_f32_f16_e32 v11, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e16178a
	v_cvt_f32_f16_e32 v10, v10                                  ; 7e14170a
	v_cvt_f16_f32_e32 v48, v52                                  ; 7e601534
(invalid instruction)                                        ; 7f60153c
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                        ; 02020b04
	v_cvt_f32_f16_e32 v14, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1c178d
	v_cvt_f32_f16_e32 v13, v13                                  ; 7e1a170d
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                        ; 02021107
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	v_cvt_f16_f32_e32 v51, v53                                  ; 7e661535
(invalid instruction)                                        ; 7f66153d
(invalid instruction)                                        ; cc1c0030
	v_subrev_f32_e32 v0, v48, v20                               ; 0a002930
	v_perm_b32 v4, v4, v6, 0x7060500                            ; d6440004 03fe0d04 07060500
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                      ; 02021d0d
	v_cvt_f16_f32_e32 v54, v54                                  ; 7e6c1536
(invalid instruction)                                        ; 7f6c153e
(invalid instruction)                                        ; cc1c0033
	v_subrev_f32_e32 v0, v51, v20                               ; 0a002933
(invalid instruction)                                        ; cc1b0030
	v_subrev_f32_e32 v0, v48, v19                               ; 0a002730
	v_perm_b32 v4, v4, v9, 0x7060004                            ; d6440004 03fe1304 07060004
	v_perm_b32 v9, v9, v6, 0x7060501                            ; d6440009 03fe0d09 07060501
(invalid instruction)                                        ; cc1c0036
	v_subrev_f32_e32 v0, v54, v20                               ; 0a002936
(invalid instruction)                                        ; cc1b0033
	v_subrev_f32_e32 v0, v51, v19                               ; 0a002733
	v_cvt_f16_f32_e32 v58, v55                                  ; 7e741537
(invalid instruction)                                        ; 7f74153f
	v_cvt_f32_f16_e32 v49, v176/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e6217b0
	v_cvt_f32_f16_e32 v48, v48                                  ; 7e601730
	v_perm_b32 v4, v4, v12, 0x7000504                           ; d6440004 03fe1904 07000504
	v_perm_b32 v9, v9, v12, 0x7010504                           ; d6440009 03fe1909 07010504
(invalid instruction)                                        ; cc1b0036
	v_subrev_f32_e32 v0, v54, v19                               ; 0a002736
	v_cvt_f32_f16_e32 v52, v179/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e6817b3
	v_cvt_f32_f16_e32 v51, v51                                  ; 7e661733
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v20                               ; 0a00293a
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
	v_perm_b32 v4, v4, v15, 0x60504                             ; d6440004 03fe1f04 00060504
	v_perm_b32 v9, v9, v15, 0x1060504                           ; d6440009 03fe1f09 01060504
	v_cvt_f32_f16_e32 v56, v182/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7017b6
	v_cvt_f32_f16_e32 v54, v54                                  ; 7e6c1736
	v_cvt_f16_f32_e32 v61, v16                                  ; 7e7a1510
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v51, v52, vcc_lo                      ; 02026933
(invalid instruction)                                        ; 7f7a1520
	s_mov_b32 s28, s0                                           ; be9c0000
	s_movk_i32 s29, 0x8000                                      ; b01d8000
	s_load_b128 s[32:35], s[28:29], 0x30                        ; f400480e f8000030
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v19                               ; 0a00273a
	s_add_co_u32 s25, s5, s24                                   ; 80191805
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s25, s25, 2                                      ; 84198219
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s33, 14                                       ; bea1108e
	s_buffer_load_b32 s25, s[32:35], s25 offset:0x0             ; f4020650 32000000
	v_perm_b32 v5, v5, v50, 0x7060500                           ; d6440005 03fe6505 07060500
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v54, v56, vcc_lo                      ; 02027136
	v_cvt_f16_f32_e32 v62, v24                                  ; 7e7c1518
(invalid instruction)                                        ; 7f7c1528
	v_cvt_f32_f16_e32 v59, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7617ba
	v_cvt_f32_f16_e32 v58, v58                                  ; 7e74173a
(invalid instruction)                                        ; cc100070
	v_min_num_f64_e32 v[1:2], v[61:62], v[61:62]                ; 1a027b3d
	s_mov_b32 s27, 0x76543210                                   ; be9b00ff 76543210
	s_mov_b32 s28, 0xfedcba98                                   ; be9c00ff fedcba98
	v_cvt_f16_f32_e32 v114, v17                                 ; 7ee41511
	v_perm_b32 v5, v5, v53, 0x7060004                           ; d6440005 03fe6b05 07060004
	v_perm_b32 v53, v53, v50, 0x7060501                         ; d6440035 03fe6535 07060501
(invalid instruction)                                        ; 7fe41521
	v_cvt_f16_f32_e32 v115, v25                                 ; 7ee61519
(invalid instruction)                                        ; 7fe61529
(invalid instruction)                                        ; cc10003f
	v_min_num_f64_e32 v[1:2], v[62:63], v[62:63]                ; 1a027d3e
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	v_cvt_f16_f32_e32 v119, v18                                 ; 7eee1512
(invalid instruction)                                        ; 7fee1522
	v_cvt_f16_f32_e32 v120, v26                                 ; 7ef0151a
	v_perm_b32 v5, v5, v57, 0x7000504                           ; d6440005 03fe7305 07000504
(invalid instruction)                                        ; 7ff0152a
	v_perm_b32 v53, v53, v57, 0x7010504                         ; d6440035 03fe7335 07010504
(invalid instruction)                                        ; cc100075
	v_min_num_f64_e32 v[1:2], v[114:115], v[114:115]            ; 1a02e572
(invalid instruction)                                        ; cc100074
	v_min_num_f64_e32 v[1:2], v[115:116], v[115:116]            ; 1a02e773
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[112:113], v[63:64]              ; 1a027f70
	v_cvt_f16_f32_e32 v124, v19                                 ; 7ef81513
(invalid instruction)                                        ; cc10007a
	v_min_num_f64_e32 v[1:2], v[119:120], v[119:120]            ; 1a02ef77
(invalid instruction)                                        ; 7ff81523
	v_cvt_f16_f32_e32 v125, v27                                 ; 7efa151b
(invalid instruction)                                        ; 7ffa152b
	v_perm_b32 v5, v5, v60, 0x60504                             ; d6440005 03fe7905 00060504
(invalid instruction)                                        ; cc100079
	v_min_num_f64_e32 v[1:2], v[120:121], v[120:121]            ; 1a02f178
	v_perm_b32 v53, v53, v60, 0x1060504                         ; d6440035 03fe7935 01060504
(invalid instruction)                                        ; cc0f0075
	v_min_num_f64_e32 v[1:2], v[117:118], v[116:117]            ; 1a02e975
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_permlanex16_b32 v113, v112, s27, s28 op_sel:[1,1]         ; d65c1871 00703770
(invalid instruction)                                        ; d58a0081
	v_cndmask_b32_e32 v0, v20, v128, vcc_lo                     ; 02010114
(invalid instruction)                                        ; d58a4081
	v_cndmask_b32_e32 v0, v36, v128, vcc_lo                     ; 02010124
(invalid instruction)                                        ; cc10007f
	v_min_num_f64_e32 v[1:2], v[124:125], v[124:125]            ; 1a02f97c
(invalid instruction)                                        ; d58a0082
	v_cndmask_b32_e32 v0, v28, v128, vcc_lo                     ; 0201011c
(invalid instruction)                                        ; d58a4082
	v_cndmask_b32_e32 v0, v44, v128, vcc_lo                     ; 0201012c
(invalid instruction)                                        ; cc10007e
	v_min_num_f64_e32 v[1:2], v[125:126], v[125:126]            ; 1a02fb7d
(invalid instruction)                                        ; cc0f007a
	v_min_num_f64_e32 v[1:2], v[122:123], v[121:122]            ; 1a02f37a
	v_permlanex16_b32 v118, v117, s27, s28 op_sel:[1,1]         ; d65c1876 00703775
(invalid instruction)                                        ; d58a0086
	v_cndmask_b32_e32 v0, v21, v128, vcc_lo                     ; 02010115
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[112:113], v[113:114]            ; 1a02e370
(invalid instruction)                                        ; d58a4086
	v_cndmask_b32_e32 v0, v37, v128, vcc_lo                     ; 02010125
(invalid instruction)                                        ; cc100084
	v_min_num_f64_e32 v[1:2], v[129:130], v[129:130]            ; 1a030381
(invalid instruction)                                        ; d58a0087
	v_cndmask_b32_e32 v0, v29, v128, vcc_lo                     ; 0201011d
(invalid instruction)                                        ; d58a4087
	v_cndmask_b32_e32 v0, v45, v128, vcc_lo                     ; 0201012d
(invalid instruction)                                        ; cc100083
	v_min_num_f64_e32 v[1:2], v[130:131], v[130:131]            ; 1a030582
(invalid instruction)                                        ; cc0f007f
	v_min_num_f64_e32 v[1:2], v[127:128], v[126:127]            ; 1a02fd7f
	v_permlanex16_b32 v123, v122, s27, s28 op_sel:[1,1]         ; d65c187b 0070377a
(invalid instruction)                                        ; cc0f0075
	v_min_num_f64_e32 v[1:2], v[117:118], v[118:119]            ; 1a02ed75
(invalid instruction)                                        ; d58a008b
	v_cndmask_b32_e32 v0, v22, v128, vcc_lo                     ; 02010116
(invalid instruction)                                        ; d58a408b
	v_cndmask_b32_e32 v0, v38, v128, vcc_lo                     ; 02010126
(invalid instruction)                                        ; d58a008c
	v_cndmask_b32_e32 v0, v30, v128, vcc_lo                     ; 0201011e
(invalid instruction)                                        ; cc100089
	v_min_num_f64_e32 v[1:2], v[134:135], v[134:135]            ; 1a030d86
(invalid instruction)                                        ; d58a408c
	v_cndmask_b32_e32 v0, v46, v128, vcc_lo                     ; 0201012e
(invalid instruction)                                        ; cc100088
	v_min_num_f64_e32 v[1:2], v[135:136], v[135:136]            ; 1a030f87
(invalid instruction)                                        ; cc0f0084
	v_min_num_f64_e32 v[1:2], v[132:133], v[131:132]            ; 1a030784
	v_permlanex16_b32 v128, v127, s27, s28 op_sel:[1,1]         ; d65c1880 0070377f
(invalid instruction)                                        ; cc0f007a
	v_min_num_f64_e32 v[1:2], v[122:123], v[123:124]            ; 1a02f77a
(invalid instruction)                                        ; d58a0090
	v_cndmask_b32_e32 v0, v23, v128, vcc_lo                     ; 02010117
(invalid instruction)                                        ; d58a4090
	v_cndmask_b32_e32 v0, v39, v128, vcc_lo                     ; 02010127
(invalid instruction)                                        ; cc10008e
	v_min_num_f64_e32 v[1:2], v[139:140], v[139:140]            ; 1a03178b
(invalid instruction)                                        ; d58a0091
	v_cndmask_b32_e32 v0, v31, v128, vcc_lo                     ; 0201011f
(invalid instruction)                                        ; d58a4091
	v_cndmask_b32_e32 v0, v47, v128, vcc_lo                     ; 0201012f
(invalid instruction)                                        ; cc10008d
	v_min_num_f64_e32 v[1:2], v[140:141], v[140:141]            ; 1a03198c
(invalid instruction)                                        ; cc0f0089
	v_min_num_f64_e32 v[1:2], v[137:138], v[136:137]            ; 1a031189
	v_permlanex16_b32 v133, v132, s27, s28 op_sel:[1,1]         ; d65c1885 00703784
(invalid instruction)                                        ; cc0f007f
	v_min_num_f64_e32 v[1:2], v[127:128], v[128:129]            ; 1a03017f
(invalid instruction)                                        ; cc100093
	v_min_num_f64_e32 v[1:2], v[144:145], v[144:145]            ; 1a032190
(invalid instruction)                                        ; cc100092
	v_min_num_f64_e32 v[1:2], v[145:146], v[145:146]            ; 1a032391
(invalid instruction)                                        ; cc0f008e
	v_min_num_f64_e32 v[1:2], v[142:143], v[141:142]            ; 1a031b8e
	v_permlanex16_b32 v138, v137, s27, s28 op_sel:[1,1]         ; d65c188a 00703789
(invalid instruction)                                        ; cc0f0084
	v_min_num_f64_e32 v[1:2], v[132:133], v[133:134]            ; 1a030b84
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f0093
	v_min_num_f64_e32 v[1:2], v[147:148], v[146:147]            ; 1a032593
	v_permlanex16_b32 v143, v142, s27, s28 op_sel:[1,1]         ; d65c188f 0070378e
(invalid instruction)                                        ; cc0f0089
	v_min_num_f64_e32 v[1:2], v[137:138], v[138:139]            ; 1a031589
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[112:113], v[132:133]            ; 1a030970
	v_permlanex16_b32 v148, v147, s27, s28 op_sel:[1,1]         ; d65c1894 00703793
(invalid instruction)                                        ; cc0f008e
	v_min_num_f64_e32 v[1:2], v[142:143], v[143:144]            ; 1a031f8e
(invalid instruction)                                        ; cc0f0075
	v_min_num_f64_e32 v[1:2], v[117:118], v[137:138]            ; 1a031375
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0093
	v_min_num_f64_e32 v[1:2], v[147:148], v[148:149]            ; 1a032993
(invalid instruction)                                        ; cc0f007a
	v_min_num_f64_e32 v[1:2], v[122:123], v[142:143]            ; 1a031d7a
(invalid instruction)                                        ; cc0f007f
	v_min_num_f64_e32 v[1:2], v[127:128], v[147:148]            ; 1a03277f
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[112:113], v[122:123]            ; 1a02f570
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f0075
	v_min_num_f64_e32 v[1:2], v[117:118], v[127:128]            ; 1a02ff75
(invalid instruction)                                        ; cc0f0070
	v_min_num_f64_e32 v[1:2], v[112:113], v[117:118]            ; 1a02eb70
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0070
	v_subrev_f32_e32 v0, v112, v255                             ; 0a01ff70
(invalid instruction)                                        ; 00000410
	v_cvt_f32_f16_e32 v149, v112                                ; 7f2a1770
	v_cvt_f32_f16_e32 v112, v240/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ee017f0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v149, v149                                    ; 7f2a5d95
	v_rsq_f32_e32 v112, v112                                    ; 7ee05d70
(invalid instruction)                                        ; d58a0096
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                    ; 02010195
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
(invalid instruction)                                        ; d58a4096
	v_cndmask_b32_e32 v0, v112, v128, vcc_lo                    ; 02010170
(invalid instruction)                                        ; cc10003d
	v_min_num_f64_e32 v[1:2], v[61:62], v[150:151]              ; 1a032d3d
(invalid instruction)                                        ; cc10003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[150:151]              ; 1a032d3e
(invalid instruction)                                        ; cc100072
	v_min_num_f64_e32 v[1:2], v[114:115], v[150:151]            ; 1a032d72
(invalid instruction)                                        ; cc100073
	v_min_num_f64_e32 v[1:2], v[115:116], v[150:151]            ; 1a032d73
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cvt_f16_f32 s25, s25                                      ; be996819
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_pack_ll_b32_b16 s25, s25, 0x3c00                          ; 9919ff19 00003c00
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc10003e
	v_min_num_f64_e32 v[0:1], v[62:63], v[25:26]                ; 1a00333e
(invalid instruction)                                        ; cc100072
	v_min_num_f64_e32 v[0:1], v[114:115], v[25:26]              ; 1a003372
(invalid instruction)                                        ; cc10003d
	v_min_num_f64_e32 v[0:1], v[61:62], v[25:26]                ; 1a00333d
(invalid instruction)                                        ; cc100073
	v_min_num_f64_e32 v[0:1], v[115:116], v[25:26]              ; 1a003373
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c003e
	v_subrev_f32_e32 v0, v62, v20                               ; 0a00293e
(invalid instruction)                                        ; cc1c0072
	v_subrev_f32_e32 v0, v114, v20                              ; 0a002972
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v20                               ; 0a00293d
(invalid instruction)                                        ; cc1c0073
	v_subrev_f32_e32 v0, v115, v20                              ; 0a002973
(invalid instruction)                                        ; cc1b003e
	v_subrev_f32_e32 v0, v62, v19                               ; 0a00273e
(invalid instruction)                                        ; cc100077
	v_min_num_f64_e32 v[1:2], v[119:120], v[150:151]            ; 1a032d77
(invalid instruction)                                        ; cc1b0072
	v_subrev_f32_e32 v0, v114, v19                              ; 0a002772
(invalid instruction)                                        ; cc100078
	v_min_num_f64_e32 v[1:2], v[120:121], v[150:151]            ; 1a032d78
(invalid instruction)                                        ; cc1b003d
	v_subrev_f32_e32 v0, v61, v19                               ; 0a00273d
(invalid instruction)                                        ; cc1b0073
	v_subrev_f32_e32 v0, v115, v19                              ; 0a002773
	v_cvt_f32_f16_e32 v153, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f3217be
	v_cvt_f32_f16_e32 v62, v62                                  ; 7e7c173e
(invalid instruction)                                        ; cc100077
	v_min_num_f64_e32 v[0:1], v[119:120], v[25:26]              ; 1a003377
	v_cvt_f32_f16_e32 v155, v242/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f3617f2
	v_cvt_f32_f16_e32 v114, v114                                ; 7ee41772
(invalid instruction)                                        ; cc100078
	v_min_num_f64_e32 v[0:1], v[120:121], v[25:26]              ; 1a003378
	v_cvt_f32_f16_e32 v151, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f2e17bd
	v_cvt_f32_f16_e32 v61, v61                                  ; 7e7a173d
	v_cvt_f32_f16_e32 v157, v243/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f3a17f3
	v_cvt_f32_f16_e32 v115, v115                                ; 7ee61773
(invalid instruction)                                        ; d769009a
	v_cndmask_b32_e32 v1, v62, v153, vcc_lo                     ; 0203333e
(invalid instruction)                                        ; cc1c0077
	v_subrev_f32_e32 v0, v119, v20                              ; 0a002977
(invalid instruction)                                        ; cc10007c
	v_min_num_f64_e32 v[1:2], v[124:125], v[150:151]            ; 1a032d7c
(invalid instruction)                                        ; cc10007d
	v_min_num_f64_e32 v[1:2], v[125:126], v[150:151]            ; 1a032d7d
(invalid instruction)                                        ; d769009c
	v_cndmask_b32_e32 v1, v114, v155, vcc_lo                    ; 02033772
(invalid instruction)                                        ; cc1c0078
	v_subrev_f32_e32 v0, v120, v20                              ; 0a002978
(invalid instruction)                                        ; d7690098
	v_cndmask_b32_e32 v1, v61, v151, vcc_lo                     ; 02032f3d
(invalid instruction)                                        ; d769009e
	v_cndmask_b32_e32 v1, v115, v157, vcc_lo                    ; 02033b73
(invalid instruction)                                        ; cc1b0077
	v_subrev_f32_e32 v0, v119, v19                              ; 0a002777
(invalid instruction)                                        ; cc10007c
	v_min_num_f64_e32 v[0:1], v[124:125], v[25:26]              ; 1a00337c
(invalid instruction)                                        ; cc10007d
	v_min_num_f64_e32 v[0:1], v[125:126], v[25:26]              ; 1a00337d
(invalid instruction)                                        ; cc1b0078
	v_subrev_f32_e32 v0, v120, v19                              ; 0a002778
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f32_f16_e32 v159, v247/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f3e17f7
	v_cvt_f32_f16_e32 v119, v119                                ; 7eee1777
	v_perm_b32 v6, v6, v152, 0x7060500                          ; d6440006 03ff3106 07060500
(invalid instruction)                                        ; cc1c007c
	v_subrev_f32_e32 v0, v124, v20                              ; 0a00297c
(invalid instruction)                                        ; cc1c007d
	v_subrev_f32_e32 v0, v125, v20                              ; 0a00297d
	v_cvt_f32_f16_e32 v161, v248/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f4217f8
	v_cvt_f32_f16_e32 v120, v120                                ; 7ef01778
(invalid instruction)                                        ; d76900a0
	v_cndmask_b32_e32 v1, v119, v159, vcc_lo                    ; 02033f77
	v_perm_b32 v6, v6, v156, 0x7060004                          ; d6440006 03ff3906 07060004
	v_perm_b32 v156, v156, v152, 0x7060501                      ; d644009c 03ff319c 07060501
	v_perm_b32 v10, v10, v154, 0x7060500                        ; d644000a 03ff350a 07060500
(invalid instruction)                                        ; cc1b007c
	v_subrev_f32_e32 v0, v124, v19                              ; 0a00277c
(invalid instruction)                                        ; cc1b007d
	v_subrev_f32_e32 v0, v125, v19                              ; 0a00277d
(invalid instruction)                                        ; d76900a2
	v_cndmask_b32_e32 v1, v120, v161, vcc_lo                    ; 02034378
	v_perm_b32 v6, v6, v160, 0x7000504                          ; d6440006 03ff4106 07000504
	v_perm_b32 v156, v156, v160, 0x7010504                      ; d644009c 03ff419c 07010504
(invalid instruction)                                        ; cc100081
	v_min_num_f64_e32 v[1:2], v[129:130], v[150:151]            ; 1a032d81
	v_perm_b32 v10, v10, v158, 0x7060004                        ; d644000a 03ff3d0a 07060004
	v_perm_b32 v158, v158, v154, 0x7060501                      ; d644009e 03ff359e 07060501
(invalid instruction)                                        ; cc100082
	v_min_num_f64_e32 v[1:2], v[130:131], v[150:151]            ; 1a032d82
	v_cvt_f32_f16_e32 v163, v252/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f4617fc
	v_cvt_f32_f16_e32 v124, v124                                ; 7ef8177c
	v_cvt_f32_f16_e32 v165, v253/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f4a17fd
	v_cvt_f32_f16_e32 v125, v125                                ; 7efa177d
(invalid instruction)                                        ; cc100081
	v_min_num_f64_e32 v[0:1], v[129:130], v[25:26]              ; 1a003381
	v_perm_b32 v10, v10, v162, 0x7000504                        ; d644000a 03ff450a 07000504
	v_perm_b32 v158, v158, v162, 0x7010504                      ; d644009e 03ff459e 07010504
(invalid instruction)                                        ; cc100082
	v_min_num_f64_e32 v[0:1], v[130:131], v[25:26]              ; 1a003382
(invalid instruction)                                        ; d76900a4
	v_cndmask_b32_e32 v1, v124, v163, vcc_lo                    ; 0203477c
(invalid instruction)                                        ; d76900a6
	v_cndmask_b32_e32 v1, v125, v165, vcc_lo                    ; 02034b7d
(invalid instruction)                                        ; cc100086
	v_min_num_f64_e32 v[1:2], v[134:135], v[150:151]            ; 1a032d86
(invalid instruction)                                        ; cc1c0081
	v_subrev_f32_e32 v0, v129, v20                              ; 0a002981
(invalid instruction)                                        ; cc100087
	v_min_num_f64_e32 v[1:2], v[135:136], v[150:151]            ; 1a032d87
(invalid instruction)                                        ; cc1c0082
	v_subrev_f32_e32 v0, v130, v20                              ; 0a002982
	v_perm_b32 v156, v156, v164, 0x1060504                      ; d644009c 03ff499c 01060504
	v_perm_b32 v6, v6, v164, 0x60504                            ; d6440006 03ff4906 00060504
	v_perm_b32 v158, v158, v166, 0x1060504                      ; d644009e 03ff4d9e 01060504
	v_perm_b32 v10, v10, v166, 0x60504                          ; d644000a 03ff4d0a 00060504
(invalid instruction)                                        ; cc100086
	v_min_num_f64_e32 v[0:1], v[134:135], v[25:26]              ; 1a003386
(invalid instruction)                                        ; cc1b0081
	v_subrev_f32_e32 v0, v129, v19                              ; 0a002781
(invalid instruction)                                        ; cc100087
	v_min_num_f64_e32 v[0:1], v[135:136], v[25:26]              ; 1a003387
(invalid instruction)                                        ; cc1b0082
	v_subrev_f32_e32 v0, v130, v19                              ; 0a002782
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c0086
	v_subrev_f32_e32 v0, v134, v20                              ; 0a002986
(invalid instruction)                                        ; cc10008b
	v_min_num_f64_e32 v[1:2], v[139:140], v[150:151]            ; 1a032d8b
(invalid instruction)                                        ; d58b08a7
	v_cndmask_b32_e32 v0, v129, v128, vcc_lo                    ; 02010181
(invalid instruction)                                        ; d58b0081
	v_cndmask_b32_e32 v0, v129, v128, vcc_lo                    ; 02010181
(invalid instruction)                                        ; cc10008c
	v_min_num_f64_e32 v[1:2], v[140:141], v[150:151]            ; 1a032d8c
(invalid instruction)                                        ; cc1c0087
	v_subrev_f32_e32 v0, v135, v20                              ; 0a002987
(invalid instruction)                                        ; d58b08a9
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                    ; 02010182
(invalid instruction)                                        ; d58b0082
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                    ; 02010182
(invalid instruction)                                        ; cc1b0086
	v_subrev_f32_e32 v0, v134, v19                              ; 0a002786
(invalid instruction)                                        ; cc10008b
	v_min_num_f64_e32 v[0:1], v[139:140], v[25:26]              ; 1a00338b
(invalid instruction)                                        ; d76900a8
	v_cndmask_b32_e32 v1, v129, v167, vcc_lo                    ; 02034f81
(invalid instruction)                                        ; cc10008c
	v_min_num_f64_e32 v[0:1], v[140:141], v[25:26]              ; 1a00338c
(invalid instruction)                                        ; cc1b0087
	v_subrev_f32_e32 v0, v135, v19                              ; 0a002787
(invalid instruction)                                        ; d76900aa
	v_cndmask_b32_e32 v1, v130, v169, vcc_lo                    ; 02035382
(invalid instruction)                                        ; d58b08ab
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                    ; 02010186
(invalid instruction)                                        ; d58b0086
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                    ; 02010186
(invalid instruction)                                        ; cc100090
	v_min_num_f64_e32 v[1:2], v[144:145], v[150:151]            ; 1a032d90
(invalid instruction)                                        ; cc1c008b
	v_subrev_f32_e32 v0, v139, v20                              ; 0a00298b
(invalid instruction)                                        ; cc100091
	v_min_num_f64_e32 v[1:2], v[145:146], v[150:151]            ; 1a032d91
(invalid instruction)                                        ; cc1c008c
	v_subrev_f32_e32 v0, v140, v20                              ; 0a00298c
(invalid instruction)                                        ; d58b08ad
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                    ; 02010187
(invalid instruction)                                        ; d58b0087
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                    ; 02010187
(invalid instruction)                                        ; d76900ac
	v_cndmask_b32_e32 v1, v134, v171, vcc_lo                    ; 02035786
(invalid instruction)                                        ; cc100090
	v_min_num_f64_e32 v[0:1], v[144:145], v[25:26]              ; 1a003390
(invalid instruction)                                        ; cc1b008b
	v_subrev_f32_e32 v0, v139, v19                              ; 0a00278b
(invalid instruction)                                        ; cc100091
	v_min_num_f64_e32 v[0:1], v[145:146], v[25:26]              ; 1a003391
(invalid instruction)                                        ; cc1b008c
	v_subrev_f32_e32 v0, v140, v19                              ; 0a00278c
(invalid instruction)                                        ; d76900ae
	v_cndmask_b32_e32 v1, v135, v173, vcc_lo                    ; 02035b87
(invalid instruction)                                        ; cc1c0090
	v_subrev_f32_e32 v0, v144, v20                              ; 0a002990
(invalid instruction)                                        ; d58b08af
	v_cndmask_b32_e32 v0, v139, v128, vcc_lo                    ; 0201018b
(invalid instruction)                                        ; d58b008b
	v_cndmask_b32_e32 v0, v139, v128, vcc_lo                    ; 0201018b
	v_perm_b32 v7, v7, v168, 0x7060500                          ; d6440007 03ff5107 07060500
(invalid instruction)                                        ; cc1c0091
	v_subrev_f32_e32 v0, v145, v20                              ; 0a002991
(invalid instruction)                                        ; d58b08b1
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                    ; 0201018c
(invalid instruction)                                        ; d58b008c
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                    ; 0201018c
(invalid instruction)                                        ; cc1b0090
	v_subrev_f32_e32 v0, v144, v19                              ; 0a002790
	v_perm_b32 v11, v11, v170, 0x7060500                        ; d644000b 03ff550b 07060500
(invalid instruction)                                        ; d76900b0
	v_cndmask_b32_e32 v1, v139, v175, vcc_lo                    ; 02035f8b
	v_perm_b32 v7, v7, v172, 0x7060004                          ; d6440007 03ff5907 07060004
	v_perm_b32 v172, v172, v168, 0x7060501                      ; d64400ac 03ff51ac 07060501
(invalid instruction)                                        ; cc1b0091
	v_subrev_f32_e32 v0, v145, v19                              ; 0a002791
(invalid instruction)                                        ; d76900b2
	v_cndmask_b32_e32 v1, v140, v177, vcc_lo                    ; 0203638c
(invalid instruction)                                        ; d58b08b3
	v_cndmask_b32_e32 v0, v144, v128, vcc_lo                    ; 02010190
(invalid instruction)                                        ; d58b0090
	v_cndmask_b32_e32 v0, v144, v128, vcc_lo                    ; 02010190
	v_perm_b32 v11, v11, v174, 0x7060004                        ; d644000b 03ff5d0b 07060004
	v_perm_b32 v174, v174, v170, 0x7060501                      ; d64400ae 03ff55ae 07060501
	v_perm_b32 v7, v7, v176, 0x7000504                          ; d6440007 03ff6107 07000504
	v_perm_b32 v172, v172, v176, 0x7010504                      ; d64400ac 03ff61ac 07010504
(invalid instruction)                                        ; d58b08b5
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                    ; 02010191
(invalid instruction)                                        ; d58b0091
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                    ; 02010191
(invalid instruction)                                        ; d76900b4
	v_cndmask_b32_e32 v1, v144, v179, vcc_lo                    ; 02036790
	v_perm_b32 v11, v11, v178, 0x7000504                        ; d644000b 03ff650b 07000504
	v_perm_b32 v174, v174, v178, 0x7010504                      ; d64400ae 03ff65ae 07010504
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
(invalid instruction)                                        ; d76900b6
	v_cndmask_b32_e32 v1, v145, v181, vcc_lo                    ; 02036b91
	v_perm_b32 v172, v172, v180, 0x1060504                      ; d64400ac 03ff69ac 01060504
	v_perm_b32 v7, v7, v180, 0x60504                            ; d6440007 03ff6907 00060504
	v_perm_b32 v174, v174, v182, 0x1060504                      ; d64400ae 03ff6dae 01060504
	v_perm_b32 v11, v11, v182, 0x60504                          ; d644000b 03ff6d0b 00060504
	s_branch BB55                                               ; bfa0000c
BB54:
	v_mov_b32_e32 v4, 0                                         ; 7e080280
	v_mov_b32_e32 v6, 0                                         ; 7e0c0280
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v5, 0               ; ca100080 0a040080
	v_dual_mov_b32 v156, 0 :: v_dual_mov_b32 v7, 0              ; ca100080 9c060080
	v_dual_mov_b32 v158, 0 :: v_dual_mov_b32 v9, 0              ; ca100080 9e080080
	v_dual_mov_b32 v172, 0 :: v_dual_mov_b32 v11, 0             ; ca100080 ac0a0080
	v_dual_mov_b32 v174, 0 :: v_dual_mov_b32 v53, 0             ; ca100080 ae340080
BB55:
(invalid instruction)                                        ; d71f0008
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
	v_mov_b32_e32 v159, v174                                    ; 7f3e03ae
	v_and_b32_e32 v12, 15, v8                                   ; 3618108f
	v_lshrrev_b32_e32 v8, 4, v8                                 ; 32101084
	v_lshlrev_b32_e32 v8, 3, v8                                 ; 30101083
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mad_u32_u24 v13, 36, v12, v8                              ; d60b000d 042218a4
	v_mad_u32_u24 v13, s12, 0x480, v13                          ; d60b000d 0435fe0c 00000480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
	v_dual_mov_b32 v157, v172 :: v_dual_add_nc_u32 v14, 0x800, v13 ; ca2001ac 9d0e1aff 00000800
	ds_store_2addr_b64 v13, v[6:7], v[10:11] offset1:2          ; d9380200 000a060d
	ds_store_2addr_b64 v14, v[156:157], v[158:159] offset0:32 offset1:34 ; d9382220 009e9c0e
	v_mov_b32_e32 v10, v53                                      ; 7e140335
	v_lshl_add_u32 v12, v12, 6, v8                              ; d646000c 04210d0c
	v_add_nc_u32_e32 v12, s13, v12                              ; 4a18180d
	ds_store_2addr_stride64_b64 v12, v[4:5], v[9:10] offset0:9 offset1:11 ; d93c0b09 0009040c
	s_cmp_lg_i32 s40, 0                                         ; bf018028
	s_cbranch_scc1 BB57                                         ; bfa2023a
BB56:
	v_cvt_f16_f32_e32 v4, v96                                   ; 7e081560
(invalid instruction)                                        ; 7f081568
	s_movk_i32 s19, 0x5f00                                      ; b0135f00
	s_movk_i32 s20, 0xdf00                                      ; b014df00
	v_cvt_f16_f32_e32 v7, v97                                   ; 7e0e1561
(invalid instruction)                                        ; 7f0e1569
	v_cvt_f16_f32_e32 v10, v98                                  ; 7e141562
(invalid instruction)                                        ; 7f14156a
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c0004
	v_subrev_f32_e32 v0, v4, v20                                ; 0a002904
	v_cvt_f16_f32_e32 v16, v99                                  ; 7e201563
(invalid instruction)                                        ; 7f20156b
(invalid instruction)                                        ; cc1c0007
	v_subrev_f32_e32 v0, v7, v20                                ; 0a002907
(invalid instruction)                                        ; cc1c000a
	v_subrev_f32_e32 v0, v10, v20                               ; 0a00290a
(invalid instruction)                                        ; cc1b0004
	v_subrev_f32_e32 v0, v4, v19                                ; 0a002704
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c0010
	v_subrev_f32_e32 v0, v16, v20                               ; 0a002910
(invalid instruction)                                        ; cc1b0007
	v_subrev_f32_e32 v0, v7, v19                                ; 0a002707
(invalid instruction)                                        ; cc1b000a
	v_subrev_f32_e32 v0, v10, v19                               ; 0a00270a
	v_cvt_f32_f16_e32 v5, v132/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a1784
	v_cvt_f32_f16_e32 v4, v4                                    ; 7e081704
(invalid instruction)                                        ; cc1b0010
	v_subrev_f32_e32 v0, v16, v19                               ; 0a002710
	v_cvt_f32_f16_e32 v8, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e101787
	v_cvt_f32_f16_e32 v7, v7                                    ; 7e0e1707
	v_cvt_f32_f16_e32 v11, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e16178a
	v_cvt_f32_f16_e32 v10, v10                                  ; 7e14170a
	v_cvt_f16_f32_e32 v19, v100                                 ; 7e261564
(invalid instruction)                                        ; 7f26156c
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                        ; 02020b04
	v_cvt_f32_f16_e32 v17, v144/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e221790
	v_cvt_f32_f16_e32 v16, v16                                  ; 7e201710
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                        ; 02021107
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	v_cvt_f16_f32_e32 v22, v101                                 ; 7e2c1565
(invalid instruction)                                        ; 7f2c156d
(invalid instruction)                                        ; cc1c0013
	v_subrev_f32_e32 v0, v19, v20                               ; 0a002913
	v_perm_b32 v4, v4, v6, 0x7060500                            ; d6440004 03fe0d04 07060500
(invalid instruction)                                        ; d7690012
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                      ; 02022310
	v_cvt_f16_f32_e32 v25, v102                                 ; 7e321566
(invalid instruction)                                        ; 7f32156e
(invalid instruction)                                        ; cc1c0016
	v_subrev_f32_e32 v0, v22, v20                               ; 0a002916
(invalid instruction)                                        ; cc1b0013
	v_subrev_f32_e32 v0, v19, v19                               ; 0a002713
	v_perm_b32 v4, v4, v9, 0x7060004                            ; d6440004 03fe1304 07060004
	v_perm_b32 v9, v9, v6, 0x7060501                            ; d6440009 03fe0d09 07060501
(invalid instruction)                                        ; cc1c0019
	v_subrev_f32_e32 v0, v25, v20                               ; 0a002919
(invalid instruction)                                        ; cc1b0016
	v_subrev_f32_e32 v0, v22, v19                               ; 0a002716
	v_cvt_f16_f32_e32 v28, v103                                 ; 7e381567
(invalid instruction)                                        ; 7f38156f
	v_cvt_f32_f16_e32 v20, v147/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e281793
	v_cvt_f32_f16_e32 v19, v19                                  ; 7e261713
	v_perm_b32 v4, v4, v15, 0x7000504                           ; d6440004 03fe1f04 07000504
	v_perm_b32 v9, v9, v15, 0x7010504                           ; d6440009 03fe1f09 07010504
(invalid instruction)                                        ; cc1b0019
	v_subrev_f32_e32 v0, v25, v19                               ; 0a002719
	v_cvt_f32_f16_e32 v23, v150/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e2e1796
	v_cvt_f32_f16_e32 v22, v22                                  ; 7e2c1716
(invalid instruction)                                        ; cc1c001c
	v_subrev_f32_e32 v0, v28, v20                               ; 0a00291c
(invalid instruction)                                        ; d7690015
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                      ; 02022913
	v_perm_b32 v4, v4, v18, 0x60504                             ; d6440004 03fe2504 00060504
	v_perm_b32 v9, v9, v18, 0x1060504                           ; d6440009 03fe2509 01060504
	v_cvt_f32_f16_e32 v26, v153/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e341799
	v_cvt_f32_f16_e32 v25, v25                                  ; 7e321719
	v_cvt_f16_f32_e32 v31, v64                                  ; 7e3e1540
(invalid instruction)                                        ; d7690018
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                      ; 02022f16
(invalid instruction)                                        ; 7f3e1550
	s_mov_b32 s28, s0                                           ; be9c0000
	s_movk_i32 s29, 0x8000                                      ; b01d8000
	s_load_b128 s[32:35], s[28:29], 0x30                        ; f400480e f8000030
(invalid instruction)                                        ; cc1b001c
	v_subrev_f32_e32 v0, v28, v19                               ; 0a00271c
	s_add_co_u32 s25, s5, s24                                   ; 80191805
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s25, s25, 2                                      ; 84198219
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s33, 14                                       ; bea1108e
	s_buffer_load_b32 s25, s[32:35], s25 offset:0x0             ; f4020650 32000000
	v_perm_b32 v5, v5, v21, 0x7060500                           ; d6440005 03fe2b05 07060500
(invalid instruction)                                        ; d769001b
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                      ; 02023519
	v_cvt_f16_f32_e32 v32, v72                                  ; 7e401548
(invalid instruction)                                        ; 7f401558
	v_cvt_f32_f16_e32 v29, v156/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e3a179c
	v_cvt_f32_f16_e32 v28, v28                                  ; 7e38171c
(invalid instruction)                                        ; cc100022
	v_min_num_f64_e32 v[1:2], v[31:32], v[31:32]                ; 1a023f1f
	s_mov_b32 s27, 0x76543210                                   ; be9b00ff 76543210
	s_mov_b32 s28, 0xfedcba98                                   ; be9c00ff fedcba98
	v_cvt_f16_f32_e32 v36, v65                                  ; 7e481541
	v_perm_b32 v5, v5, v24, 0x7060004                           ; d6440005 03fe3105 07060004
	v_perm_b32 v24, v24, v21, 0x7060501                         ; d6440018 03fe2b18 07060501
(invalid instruction)                                        ; 7f481551
	v_cvt_f16_f32_e32 v37, v73                                  ; 7e4a1549
(invalid instruction)                                        ; 7f4a1559
(invalid instruction)                                        ; cc100021
	v_min_num_f64_e32 v[1:2], v[32:33], v[32:33]                ; 1a024120
(invalid instruction)                                        ; d769001e
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                      ; 02023b1c
	v_cvt_f16_f32_e32 v41, v66                                  ; 7e521542
(invalid instruction)                                        ; 7f521552
	v_cvt_f16_f32_e32 v42, v74                                  ; 7e54154a
	v_perm_b32 v5, v5, v27, 0x7000504                           ; d6440005 03fe3705 07000504
(invalid instruction)                                        ; 7f54155a
	v_perm_b32 v24, v24, v27, 0x7010504                         ; d6440018 03fe3718 07010504
(invalid instruction)                                        ; cc100027
	v_min_num_f64_e32 v[1:2], v[36:37], v[36:37]                ; 1a024924
(invalid instruction)                                        ; cc100026
	v_min_num_f64_e32 v[1:2], v[37:38], v[37:38]                ; 1a024b25
(invalid instruction)                                        ; cc0f0022
	v_min_num_f64_e32 v[1:2], v[34:35], v[33:34]                ; 1a024322
	v_cvt_f16_f32_e32 v46, v67                                  ; 7e5c1543
(invalid instruction)                                        ; cc10002c
	v_min_num_f64_e32 v[1:2], v[41:42], v[41:42]                ; 1a025329
(invalid instruction)                                        ; 7f5c1553
	v_cvt_f16_f32_e32 v47, v75                                  ; 7e5e154b
(invalid instruction)                                        ; 7f5e155b
	v_perm_b32 v5, v5, v30, 0x60504                             ; d6440005 03fe3d05 00060504
(invalid instruction)                                        ; cc10002b
	v_min_num_f64_e32 v[1:2], v[42:43], v[42:43]                ; 1a02552a
	v_perm_b32 v24, v24, v30, 0x1060504                         ; d6440018 03fe3d18 01060504
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[38:39]                ; 1a024d27
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_permlanex16_b32 v35, v34, s27, s28 op_sel:[1,1]           ; d65c1823 00703722
	v_cvt_f16_f32_e32 v51, v68                                  ; 7e661544
(invalid instruction)                                        ; 7f661554
(invalid instruction)                                        ; cc100031
	v_min_num_f64_e32 v[1:2], v[46:47], v[46:47]                ; 1a025d2e
	v_cvt_f16_f32_e32 v52, v76                                  ; 7e68154c
(invalid instruction)                                        ; 7f68155c
(invalid instruction)                                        ; cc100030
	v_min_num_f64_e32 v[1:2], v[47:48], v[47:48]                ; 1a025f2f
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[44:45], v[43:44]                ; 1a02572c
	v_permlanex16_b32 v40, v39, s27, s28 op_sel:[1,1]           ; d65c1828 00703727
	v_cvt_f16_f32_e32 v56, v69                                  ; 7e701545
(invalid instruction)                                        ; cc0f0022
	v_min_num_f64_e32 v[1:2], v[34:35], v[35:36]                ; 1a024722
(invalid instruction)                                        ; 7f701555
(invalid instruction)                                        ; cc100036
	v_min_num_f64_e32 v[1:2], v[51:52], v[51:52]                ; 1a026733
	v_cvt_f16_f32_e32 v57, v77                                  ; 7e72154d
(invalid instruction)                                        ; 7f72155d
(invalid instruction)                                        ; cc100035
	v_min_num_f64_e32 v[1:2], v[52:53], v[52:53]                ; 1a026934
(invalid instruction)                                        ; cc0f0031
	v_min_num_f64_e32 v[1:2], v[49:50], v[48:49]                ; 1a026131
	v_permlanex16_b32 v45, v44, s27, s28 op_sel:[1,1]           ; d65c182d 0070372c
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[40:41]                ; 1a025127
	v_cvt_f16_f32_e32 v61, v70                                  ; 7e7a1546
(invalid instruction)                                        ; 7f7a1556
	v_cvt_f16_f32_e32 v62, v78                                  ; 7e7c154e
(invalid instruction)                                        ; cc10003b
	v_min_num_f64_e32 v[1:2], v[56:57], v[56:57]                ; 1a027138
(invalid instruction)                                        ; 7f7c155e
(invalid instruction)                                        ; cc10003a
	v_min_num_f64_e32 v[1:2], v[57:58], v[57:58]                ; 1a027339
(invalid instruction)                                        ; cc0f0036
	v_min_num_f64_e32 v[1:2], v[54:55], v[53:54]                ; 1a026b36
	v_permlanex16_b32 v50, v49, s27, s28 op_sel:[1,1]           ; d65c1832 00703731
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[44:45], v[45:46]                ; 1a025b2c
	v_cvt_f16_f32_e32 v66, v71                                  ; 7e841547
(invalid instruction)                                        ; 7f841557
(invalid instruction)                                        ; cc100040
	v_min_num_f64_e32 v[1:2], v[61:62], v[61:62]                ; 1a027b3d
	v_cvt_f16_f32_e32 v67, v79                                  ; 7e86154f
(invalid instruction)                                        ; 7f86155f
(invalid instruction)                                        ; cc10003f
	v_min_num_f64_e32 v[1:2], v[62:63], v[62:63]                ; 1a027d3e
(invalid instruction)                                        ; cc0f003b
	v_min_num_f64_e32 v[1:2], v[59:60], v[58:59]                ; 1a02753b
	v_permlanex16_b32 v55, v54, s27, s28 op_sel:[1,1]           ; d65c1837 00703736
(invalid instruction)                                        ; cc0f0031
	v_min_num_f64_e32 v[1:2], v[49:50], v[50:51]                ; 1a026531
(invalid instruction)                                        ; cc100045
	v_min_num_f64_e32 v[1:2], v[66:67], v[66:67]                ; 1a028542
(invalid instruction)                                        ; cc100044
	v_min_num_f64_e32 v[1:2], v[67:68], v[67:68]                ; 1a028743
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[64:65], v[63:64]                ; 1a027f40
	v_permlanex16_b32 v60, v59, s27, s28 op_sel:[1,1]           ; d65c183c 0070373b
(invalid instruction)                                        ; cc0f0036
	v_min_num_f64_e32 v[1:2], v[54:55], v[55:56]                ; 1a026f36
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[68:69]                ; 1a028945
	v_permlanex16_b32 v65, v64, s27, s28 op_sel:[1,1]           ; d65c1841 00703740
(invalid instruction)                                        ; cc0f003b
	v_min_num_f64_e32 v[1:2], v[59:60], v[60:61]                ; 1a02793b
(invalid instruction)                                        ; cc0f0022
	v_min_num_f64_e32 v[1:2], v[34:35], v[54:55]                ; 1a026d22
	v_permlanex16_b32 v70, v69, s27, s28 op_sel:[1,1]           ; d65c1846 00703745
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[64:65], v[65:66]                ; 1a028340
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[59:60]                ; 1a027727
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[70:71]                ; 1a028d45
(invalid instruction)                                        ; cc0f002c
	v_min_num_f64_e32 v[1:2], v[44:45], v[64:65]                ; 1a02812c
(invalid instruction)                                        ; cc0f0031
	v_min_num_f64_e32 v[1:2], v[49:50], v[69:70]                ; 1a028b31
(invalid instruction)                                        ; cc0f0022
	v_min_num_f64_e32 v[1:2], v[34:35], v[44:45]                ; 1a025922
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f0027
	v_min_num_f64_e32 v[1:2], v[39:40], v[49:50]                ; 1a026327
(invalid instruction)                                        ; cc0f0022
	v_min_num_f64_e32 v[1:2], v[34:35], v[39:40]                ; 1a024f22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0022
	v_subrev_f32_e32 v0, v34, v255                              ; 0a01ff22
(invalid instruction)                                        ; 00000410
	v_cvt_f32_f16_e32 v71, v34                                  ; 7e8e1722
	v_cvt_f32_f16_e32 v34, v162/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e4417a2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v71, v71                                      ; 7e8e5d47
	v_rsq_f32_e32 v34, v34                                      ; 7e445d22
	v_cvt_f16_f32_e32 v72, v71                                  ; 7e901547
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
(invalid instruction)                                        ; 7f901522
(invalid instruction)                                        ; cc10001f
	v_min_num_f64_e32 v[1:2], v[31:32], v[72:73]                ; 1a02911f
(invalid instruction)                                        ; cc100020
	v_min_num_f64_e32 v[1:2], v[32:33], v[72:73]                ; 1a029120
(invalid instruction)                                        ; cc100024
	v_min_num_f64_e32 v[1:2], v[36:37], v[72:73]                ; 1a029124
(invalid instruction)                                        ; cc100025
	v_min_num_f64_e32 v[1:2], v[37:38], v[72:73]                ; 1a029125
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cvt_f16_f32 s25, s25                                      ; be996819
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_pack_ll_b32_b16 s25, s25, 0x3c00                          ; 9919ff19 00003c00
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc100020
	v_min_num_f64_e32 v[0:1], v[32:33], v[25:26]                ; 1a003320
(invalid instruction)                                        ; cc100024
	v_min_num_f64_e32 v[0:1], v[36:37], v[25:26]                ; 1a003324
(invalid instruction)                                        ; cc10001f
	v_min_num_f64_e32 v[0:1], v[31:32], v[25:26]                ; 1a00331f
(invalid instruction)                                        ; cc100025
	v_min_num_f64_e32 v[0:1], v[37:38], v[25:26]                ; 1a003325
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c0020
	v_subrev_f32_e32 v0, v32, v20                               ; 0a002920
(invalid instruction)                                        ; cc1c0024
	v_subrev_f32_e32 v0, v36, v20                               ; 0a002924
(invalid instruction)                                        ; cc1c001f
	v_subrev_f32_e32 v0, v31, v20                               ; 0a00291f
(invalid instruction)                                        ; cc1c0025
	v_subrev_f32_e32 v0, v37, v20                               ; 0a002925
(invalid instruction)                                        ; cc1b0020
	v_subrev_f32_e32 v0, v32, v19                               ; 0a002720
(invalid instruction)                                        ; cc100029
	v_min_num_f64_e32 v[1:2], v[41:42], v[72:73]                ; 1a029129
(invalid instruction)                                        ; cc1b0024
	v_subrev_f32_e32 v0, v36, v19                               ; 0a002724
(invalid instruction)                                        ; cc10002a
	v_min_num_f64_e32 v[1:2], v[42:43], v[72:73]                ; 1a02912a
(invalid instruction)                                        ; cc1b001f
	v_subrev_f32_e32 v0, v31, v19                               ; 0a00271f
(invalid instruction)                                        ; cc1b0025
	v_subrev_f32_e32 v0, v37, v19                               ; 0a002725
	v_cvt_f32_f16_e32 v75, v160/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e9617a0
	v_cvt_f32_f16_e32 v32, v32                                  ; 7e401720
(invalid instruction)                                        ; cc100029
	v_min_num_f64_e32 v[0:1], v[41:42], v[25:26]                ; 1a003329
	v_cvt_f32_f16_e32 v77, v164/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e9a17a4
	v_cvt_f32_f16_e32 v36, v36                                  ; 7e481724
(invalid instruction)                                        ; cc10002a
	v_min_num_f64_e32 v[0:1], v[42:43], v[25:26]                ; 1a00332a
	v_cvt_f32_f16_e32 v73, v159/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e92179f
	v_cvt_f32_f16_e32 v31, v31                                  ; 7e3e171f
	v_cvt_f32_f16_e32 v79, v165/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e9e17a5
	v_cvt_f32_f16_e32 v37, v37                                  ; 7e4a1725
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v1, v32, v75, vcc_lo                      ; 02029720
(invalid instruction)                                        ; cc1c0029
	v_subrev_f32_e32 v0, v41, v20                               ; 0a002929
(invalid instruction)                                        ; cc10002e
	v_min_num_f64_e32 v[1:2], v[46:47], v[72:73]                ; 1a02912e
(invalid instruction)                                        ; cc10002f
	v_min_num_f64_e32 v[1:2], v[47:48], v[72:73]                ; 1a02912f
(invalid instruction)                                        ; d769004e
	v_cndmask_b32_e32 v1, v36, v77, vcc_lo                      ; 02029b24
(invalid instruction)                                        ; cc1c002a
	v_subrev_f32_e32 v0, v42, v20                               ; 0a00292a
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v1, v31, v73, vcc_lo                      ; 0202931f
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v1, v37, v79, vcc_lo                      ; 02029f25
(invalid instruction)                                        ; cc1b0029
	v_subrev_f32_e32 v0, v41, v19                               ; 0a002729
(invalid instruction)                                        ; cc10002e
	v_min_num_f64_e32 v[0:1], v[46:47], v[25:26]                ; 1a00332e
(invalid instruction)                                        ; cc10002f
	v_min_num_f64_e32 v[0:1], v[47:48], v[25:26]                ; 1a00332f
(invalid instruction)                                        ; cc1b002a
	v_subrev_f32_e32 v0, v42, v19                               ; 0a00272a
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f32_f16_e32 v81, v169/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea217a9
	v_cvt_f32_f16_e32 v41, v41                                  ; 7e521729
	v_perm_b32 v6, v6, v74, 0x7060500                           ; d6440006 03fe9506 07060500
(invalid instruction)                                        ; cc1c002e
	v_subrev_f32_e32 v0, v46, v20                               ; 0a00292e
(invalid instruction)                                        ; cc1c002f
	v_subrev_f32_e32 v0, v47, v20                               ; 0a00292f
	v_cvt_f32_f16_e32 v83, v170/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ea617aa
	v_cvt_f32_f16_e32 v42, v42                                  ; 7e54172a
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v1, v41, v81, vcc_lo                      ; 0202a329
	v_perm_b32 v6, v6, v78, 0x7060004                           ; d6440006 03fe9d06 07060004
	v_perm_b32 v78, v78, v74, 0x7060501                         ; d644004e 03fe954e 07060501
	v_perm_b32 v10, v10, v76, 0x7060500                         ; d644000a 03fe990a 07060500
(invalid instruction)                                        ; cc1b002e
	v_subrev_f32_e32 v0, v46, v19                               ; 0a00272e
(invalid instruction)                                        ; cc1b002f
	v_subrev_f32_e32 v0, v47, v19                               ; 0a00272f
(invalid instruction)                                        ; d7690054
	v_cndmask_b32_e32 v1, v42, v83, vcc_lo                      ; 0202a72a
	v_perm_b32 v6, v6, v82, 0x7000504                           ; d6440006 03fea506 07000504
	v_perm_b32 v78, v78, v82, 0x7010504                         ; d644004e 03fea54e 07010504
(invalid instruction)                                        ; cc100033
	v_min_num_f64_e32 v[1:2], v[51:52], v[72:73]                ; 1a029133
	v_perm_b32 v10, v10, v80, 0x7060004                         ; d644000a 03fea10a 07060004
	v_perm_b32 v80, v80, v76, 0x7060501                         ; d6440050 03fe9950 07060501
(invalid instruction)                                        ; cc100034
	v_min_num_f64_e32 v[1:2], v[52:53], v[72:73]                ; 1a029134
	v_cvt_f32_f16_e32 v85, v174/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eaa17ae
	v_cvt_f32_f16_e32 v46, v46                                  ; 7e5c172e
	v_cvt_f32_f16_e32 v87, v175/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eae17af
	v_cvt_f32_f16_e32 v47, v47                                  ; 7e5e172f
(invalid instruction)                                        ; cc100033
	v_min_num_f64_e32 v[0:1], v[51:52], v[25:26]                ; 1a003333
	v_perm_b32 v10, v10, v84, 0x7000504                         ; d644000a 03fea90a 07000504
	v_perm_b32 v80, v80, v84, 0x7010504                         ; d6440050 03fea950 07010504
(invalid instruction)                                        ; cc100034
	v_min_num_f64_e32 v[0:1], v[52:53], v[25:26]                ; 1a003334
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v1, v46, v85, vcc_lo                      ; 0202ab2e
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v1, v47, v87, vcc_lo                      ; 0202af2f
(invalid instruction)                                        ; cc100038
	v_min_num_f64_e32 v[1:2], v[56:57], v[72:73]                ; 1a029138
(invalid instruction)                                        ; cc1c0033
	v_subrev_f32_e32 v0, v51, v20                               ; 0a002933
(invalid instruction)                                        ; cc100039
	v_min_num_f64_e32 v[1:2], v[57:58], v[72:73]                ; 1a029139
(invalid instruction)                                        ; cc1c0034
	v_subrev_f32_e32 v0, v52, v20                               ; 0a002934
	v_perm_b32 v78, v78, v86, 0x1060504                         ; d644004e 03fead4e 01060504
	v_perm_b32 v6, v6, v86, 0x60504                             ; d6440006 03fead06 00060504
	v_perm_b32 v80, v80, v88, 0x1060504                         ; d6440050 03feb150 01060504
	v_perm_b32 v10, v10, v88, 0x60504                           ; d644000a 03feb10a 00060504
(invalid instruction)                                        ; cc100038
	v_min_num_f64_e32 v[0:1], v[56:57], v[25:26]                ; 1a003338
(invalid instruction)                                        ; cc1b0033
	v_subrev_f32_e32 v0, v51, v19                               ; 0a002733
(invalid instruction)                                        ; cc100039
	v_min_num_f64_e32 v[0:1], v[57:58], v[25:26]                ; 1a003339
(invalid instruction)                                        ; cc1b0034
	v_subrev_f32_e32 v0, v52, v19                               ; 0a002734
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c0038
	v_subrev_f32_e32 v0, v56, v20                               ; 0a002938
(invalid instruction)                                        ; cc10003d
	v_min_num_f64_e32 v[1:2], v[61:62], v[72:73]                ; 1a02913d
	v_cvt_f32_f16_e32 v89, v179/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eb217b3
	v_cvt_f32_f16_e32 v51, v51                                  ; 7e661733
(invalid instruction)                                        ; cc10003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[72:73]                ; 1a02913e
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v20                               ; 0a002939
	v_cvt_f32_f16_e32 v91, v180/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eb617b4
	v_cvt_f32_f16_e32 v52, v52                                  ; 7e681734
(invalid instruction)                                        ; cc1b0038
	v_subrev_f32_e32 v0, v56, v19                               ; 0a002738
(invalid instruction)                                        ; cc10003d
	v_min_num_f64_e32 v[0:1], v[61:62], v[25:26]                ; 1a00333d
(invalid instruction)                                        ; d769005a
	v_cndmask_b32_e32 v1, v51, v89, vcc_lo                      ; 0202b333
(invalid instruction)                                        ; cc10003e
	v_min_num_f64_e32 v[0:1], v[62:63], v[25:26]                ; 1a00333e
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v19                               ; 0a002739
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v1, v52, v91, vcc_lo                      ; 0202b734
	v_cvt_f32_f16_e32 v93, v184/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eba17b8
	v_cvt_f32_f16_e32 v56, v56                                  ; 7e701738
(invalid instruction)                                        ; cc100042
	v_min_num_f64_e32 v[1:2], v[66:67], v[72:73]                ; 1a029142
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v20                               ; 0a00293d
(invalid instruction)                                        ; cc100043
	v_min_num_f64_e32 v[1:2], v[67:68], v[72:73]                ; 1a029143
(invalid instruction)                                        ; cc1c003e
	v_subrev_f32_e32 v0, v62, v20                               ; 0a00293e
	v_cvt_f32_f16_e32 v95, v185/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ebe17b9
	v_cvt_f32_f16_e32 v57, v57                                  ; 7e721739
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v1, v56, v93, vcc_lo                      ; 0202bb38
(invalid instruction)                                        ; cc100042
	v_min_num_f64_e32 v[0:1], v[66:67], v[25:26]                ; 1a003342
(invalid instruction)                                        ; cc1b003d
	v_subrev_f32_e32 v0, v61, v19                               ; 0a00273d
(invalid instruction)                                        ; cc100043
	v_min_num_f64_e32 v[0:1], v[67:68], v[25:26]                ; 1a003343
(invalid instruction)                                        ; cc1b003e
	v_subrev_f32_e32 v0, v62, v19                               ; 0a00273e
(invalid instruction)                                        ; d7690060
	v_cndmask_b32_e32 v1, v57, v95, vcc_lo                      ; 0202bf39
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v20                               ; 0a002942
	v_cvt_f32_f16_e32 v97, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ec217bd
	v_cvt_f32_f16_e32 v61, v61                                  ; 7e7a173d
	v_perm_b32 v7, v7, v90, 0x7060500                           ; d6440007 03feb507 07060500
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v20                               ; 0a002943
	v_cvt_f32_f16_e32 v99, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ec617be
	v_cvt_f32_f16_e32 v62, v62                                  ; 7e7c173e
(invalid instruction)                                        ; cc1b0042
	v_subrev_f32_e32 v0, v66, v19                               ; 0a002742
	v_perm_b32 v11, v11, v92, 0x7060500                         ; d644000b 03feb90b 07060500
(invalid instruction)                                        ; d7690062
	v_cndmask_b32_e32 v1, v61, v97, vcc_lo                      ; 0202c33d
	v_perm_b32 v7, v7, v94, 0x7060004                           ; d6440007 03febd07 07060004
	v_perm_b32 v94, v94, v90, 0x7060501                         ; d644005e 03feb55e 07060501
(invalid instruction)                                        ; cc1b0043
	v_subrev_f32_e32 v0, v67, v19                               ; 0a002743
(invalid instruction)                                        ; d7690064
	v_cndmask_b32_e32 v1, v62, v99, vcc_lo                      ; 0202c73e
	v_cvt_f32_f16_e32 v101, v194/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eca17c2
	v_cvt_f32_f16_e32 v66, v66                                  ; 7e841742
	v_perm_b32 v11, v11, v96, 0x7060004                         ; d644000b 03fec10b 07060004
	v_perm_b32 v96, v96, v92, 0x7060501                         ; d6440060 03feb960 07060501
	v_perm_b32 v7, v7, v98, 0x7000504                           ; d6440007 03fec507 07000504
	v_perm_b32 v94, v94, v98, 0x7010504                         ; d644005e 03fec55e 07010504
	v_cvt_f32_f16_e32 v103, v195/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ece17c3
	v_cvt_f32_f16_e32 v67, v67                                  ; 7e861743
(invalid instruction)                                        ; d7690066
	v_cndmask_b32_e32 v1, v66, v101, vcc_lo                     ; 0202cb42
	v_perm_b32 v11, v11, v100, 0x7000504                        ; d644000b 03fec90b 07000504
	v_perm_b32 v96, v96, v100, 0x7010504                        ; d6440060 03fec960 07010504
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v67, v103, vcc_lo                     ; 0202cf43
	v_perm_b32 v94, v94, v102, 0x1060504                        ; d644005e 03fecd5e 01060504
	v_perm_b32 v7, v7, v102, 0x60504                            ; d6440007 03fecd07 00060504
	v_perm_b32 v96, v96, v104, 0x1060504                        ; d6440060 03fed160 01060504
	v_perm_b32 v11, v11, v104, 0x60504                          ; d644000b 03fed10b 00060504
	s_branch BB58                                               ; bfa0000c
BB57:
	v_mov_b32_e32 v4, 0                                         ; 7e080280
	v_mov_b32_e32 v6, 0                                         ; 7e0c0280
	v_mov_b32_e32 v10, 0                                        ; 7e140280
	v_mov_b32_e32 v24, 0                                        ; 7e300280
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v5, 0               ; ca100080 4e040080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v7, 0               ; ca100080 50060080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v9, 0               ; ca100080 5e080080
	v_dual_mov_b32 v96, 0 :: v_dual_mov_b32 v11, 0              ; ca100080 600a0080
BB58:
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_mov_b32_e32 v79, v94                                      ; 7e9e035e
	v_mov_b32_e32 v81, v96                                      ; 7ea20360
	ds_store_2addr_b64 v13, v[6:7], v[10:11] offset0:72 offset1:74 ; d9384a48 000a060d
	ds_store_2addr_b64 v14, v[78:79], v[80:81] offset0:104 offset1:106 ; d9386a68 00504e0e
	v_add_nc_u32_e32 v12, 0x1000, v12                           ; 4a1818ff 00001000
	v_mov_b32_e32 v10, v24                                      ; 7e140318
	ds_store_2addr_b64 v12, v[4:5], v[9:10] offset0:66 offset1:194 ; d938c242 0009040c
	s_branch BB80                                               ; bfa00737
BB59:
	s_cmp_eq_i32 s38, 1                                         ; bf008126
	s_cbranch_scc0 BB68                                         ; bfa10388
BB60:
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v16, 0              ; ca100080 11100080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	s_mov_b32 s19, 0                                            ; be930080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v60, 0              ; ca100080 3d3c0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v62, 0              ; ca100080 3f3e0080
	s_branch BB61                                               ; bfa000e5
BB63:
	s_mov_b32 s28, s0                                           ; be9c0000
	s_movk_i32 s29, 0x8000                                      ; b01d8000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[32:35], s[28:29], 0x40                        ; f400480e f8000040
	s_load_b128 s[40:43], s[28:29], 0x20                        ; f4004a0e f8000020
	v_lshl_add_u32 v4, s19, 2, v5                               ; d6460004 04150413
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v4, 2, v4                                 ; 30080882
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b64 v[10:11], v4, s[32:35], null offen          ; c405407c 4080400a 00000004
	s_lshl_b32 s20, s19, 3                                      ; 84148313
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v9, s20, v7, 2                               ; d6470009 020a0e14
	v_add_lshl_u32 v12, s20, v8, 2                              ; d647000c 020a1014
	v_add_lshl_u32 v13, s20, v6, 2                              ; d647000d 020a0c14
	s_clause 0x14                                               ; bf850014
	buffer_load_b128 v[64:67], v9, s[40:43], null offen         ; c405c07c 40805040 00000009
	buffer_load_b128 v[68:71], v12, s[40:43], null offen        ; c405c07c 40805044 0000000c
	buffer_load_b128 v[72:75], v13, s[40:43], null offen        ; c405c07c 40805048 0000000d
	buffer_load_b128 v[76:79], v9, s[40:43], null offen offset:512 ; c405c07c 4080504c 00020009
	buffer_load_b128 v[80:83], v12, s[40:43], null offen offset:512 ; c405c07c 40805050 0002000c
	buffer_load_b128 v[84:87], v13, s[40:43], null offen offset:512 ; c405c07c 40805054 0002000d
	buffer_load_b128 v[88:91], v9, s[40:43], null offen offset:1024 ; c405c07c 40805058 00040009
	buffer_load_b128 v[92:95], v12, s[40:43], null offen offset:1024 ; c405c07c 4080505c 0004000c
	buffer_load_b128 v[96:99], v13, s[40:43], null offen offset:1024 ; c405c07c 40805060 0004000d
	buffer_load_b128 v[100:103], v9, s[40:43], null offen offset:1536 ; c405c07c 40805064 00060009
	buffer_load_b128 v[104:107], v12, s[40:43], null offen offset:1536 ; c405c07c 40805068 0006000c
	buffer_load_b128 v[108:111], v13, s[40:43], null offen offset:1536 ; c405c07c 4080506c 0006000d
	buffer_load_b128 v[112:115], v9, s[40:43], null offen offset:2048 ; c405c07c 40805070 00080009
	buffer_load_b128 v[116:119], v12, s[40:43], null offen offset:2048 ; c405c07c 40805074 0008000c
	buffer_load_b128 v[120:123], v13, s[40:43], null offen offset:2048 ; c405c07c 40805078 0008000d
	buffer_load_b128 v[124:127], v9, s[40:43], null offen offset:2560 ; c405c07c 4080507c 000a0009
	buffer_load_b128 v[128:131], v12, s[40:43], null offen offset:2560 ; c405c07c 40805080 000a000c
	buffer_load_b128 v[132:135], v13, s[40:43], null offen offset:2560 ; c405c07c 40805084 000a000d
	buffer_load_b128 v[136:139], v9, s[40:43], null offen offset:3072 ; c405c07c 40805088 000c0009
	buffer_load_b128 v[140:143], v12, s[40:43], null offen offset:3072 ; c405c07c 4080508c 000c000c
	buffer_load_b128 v[144:147], v13, s[40:43], null offen offset:3072 ; c405c07c 40805090 000c000d
	s_clause 0x6                                                ; bf850006
	buffer_load_b64 v[14:15], v4, s[32:35], null offen offset:256 ; c405407c 4080400e 00010004
	buffer_load_b64 v[148:149], v4, s[32:35], null offen offset:512 ; c405407c 40804094 00020004
	buffer_load_b64 v[150:151], v4, s[32:35], null offen offset:768 ; c405407c 40804096 00030004
	buffer_load_b64 v[152:153], v4, s[32:35], null offen offset:1024 ; c405407c 40804098 00040004
	buffer_load_b64 v[154:155], v4, s[32:35], null offen offset:1280 ; c405407c 4080409a 00050004
	buffer_load_b64 v[156:157], v4, s[32:35], null offen offset:1536 ; c405407c 4080409c 00060004
	buffer_load_b64 v[158:159], v4, s[32:35], null offen offset:1792 ; c405407c 4080409e 00070004
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[160:163], v9, s[40:43], null offen offset:3584 ; c405c07c 408050a0 000e0009
	buffer_load_b128 v[164:167], v12, s[40:43], null offen offset:3584 ; c405c07c 408050a4 000e000c
	buffer_load_b128 v[168:171], v13, s[40:43], null offen offset:3584 ; c405c07c 408050a8 000e000d
	s_addk_co_i32 s19, 0x80                                     ; b7930080
	s_wait_loadcnt 0x1e                                         ; bfc0001e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[64:65], v[10:11], v[16:23] ; cc464010 1c421540
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[66:67], v[10:11], v[24:31] ; cc464018 1c621542
	s_wait_loadcnt 0x1d                                         ; bfc0001d
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[68:69], v[10:11], v[32:39] ; cc464020 1c821544
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[70:71], v[10:11], v[40:47] ; cc464028 1ca21546
	s_wait_loadcnt 0x1c                                         ; bfc0001c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[10:11], v[74:75], v[56:63] ; cc464038 1ce2950a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[10:11], v[72:73], v[48:55] ; cc464030 1cc2910a
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[76:77], v[14:15], v[16:23] ; cc464010 1c421d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[78:79], v[14:15], v[24:31] ; cc464018 1c621d4e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[80:81], v[14:15], v[32:39] ; cc464020 1c821d50
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[82:83], v[14:15], v[40:47] ; cc464028 1ca21d52
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[14:15], v[86:87], v[56:63] ; cc464038 1ce2ad0e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[14:15], v[84:85], v[48:55] ; cc464030 1cc2a90e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[88:89], v[148:149], v[16:23] ; cc464010 1c432958
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[90:91], v[148:149], v[24:31] ; cc464018 1c63295a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[92:93], v[148:149], v[32:39] ; cc464020 1c83295c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[94:95], v[148:149], v[40:47] ; cc464028 1ca3295e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[148:149], v[98:99], v[56:63] ; cc464038 1ce2c594
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[148:149], v[96:97], v[48:55] ; cc464030 1cc2c194
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[100:101], v[150:151], v[16:23] ; cc464010 1c432d64
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[102:103], v[150:151], v[24:31] ; cc464018 1c632d66
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[104:105], v[150:151], v[32:39] ; cc464020 1c832d68
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[106:107], v[150:151], v[40:47] ; cc464028 1ca32d6a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[150:151], v[110:111], v[56:63] ; cc464038 1ce2dd96
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[150:151], v[108:109], v[48:55] ; cc464030 1cc2d996
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[112:113], v[152:153], v[16:23] ; cc464010 1c433170
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[114:115], v[152:153], v[24:31] ; cc464018 1c633172
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[116:117], v[152:153], v[32:39] ; cc464020 1c833174
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[118:119], v[152:153], v[40:47] ; cc464028 1ca33176
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[152:153], v[122:123], v[56:63] ; cc464038 1ce2f598
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[152:153], v[120:121], v[48:55] ; cc464030 1cc2f198
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[124:125], v[154:155], v[16:23] ; cc464010 1c43357c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[126:127], v[154:155], v[24:31] ; cc464018 1c63357e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[128:129], v[154:155], v[32:39] ; cc464020 1c833580
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[130:131], v[154:155], v[40:47] ; cc464028 1ca33582
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[154:155], v[134:135], v[56:63] ; cc464038 1ce30d9a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[154:155], v[132:133], v[48:55] ; cc464030 1cc3099a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[136:137], v[156:157], v[16:23] ; cc464010 1c433988
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[138:139], v[156:157], v[24:31] ; cc464018 1c63398a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[140:141], v[156:157], v[32:39] ; cc464020 1c83398c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[142:143], v[156:157], v[40:47] ; cc464028 1ca3398e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[156:157], v[146:147], v[56:63] ; cc464038 1ce3259c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[156:157], v[144:145], v[48:55] ; cc464030 1cc3219c
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[160:161], v[158:159], v[16:23] ; cc464010 1c433da0
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[162:163], v[158:159], v[24:31] ; cc464018 1c633da2
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[164:165], v[158:159], v[32:39] ; cc464020 1c833da4
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[166:167], v[158:159], v[40:47] ; cc464028 1ca33da6
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[158:159], v[170:171], v[56:63] ; cc464038 1ce3559e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[158:159], v[168:169], v[48:55] ; cc464030 1cc3519e
BB61:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s19, s6                                        ; bf090613
	s_cbranch_scc0 BB63                                         ; bfa1ff18
BB64:
	s_cmp_lg_i32 s36, 0                                         ; bf018024
	s_cbranch_scc1 BB66                                         ; bfa2023a
BB65:
	s_movk_i32 s19, 0x5f00                                      ; b0135f00
	s_movk_i32 s20, 0xdf00                                      ; b014df00
	v_cvt_f16_f32_e32 v4, v48                                   ; 7e081530
(invalid instruction)                                        ; 7f081538
	v_cvt_f16_f32_e32 v10, v50                                  ; 7e141532
(invalid instruction)                                        ; 7f14153a
	v_cvt_f16_f32_e32 v7, v49                                   ; 7e0e1531
(invalid instruction)                                        ; 7f0e1539
	v_cvt_f16_f32_e32 v13, v51                                  ; 7e1a1533
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c0004
	v_subrev_f32_e32 v0, v4, v20                                ; 0a002904
(invalid instruction)                                        ; 7f1a153b
(invalid instruction)                                        ; cc1c000a
	v_subrev_f32_e32 v0, v10, v20                               ; 0a00290a
(invalid instruction)                                        ; cc1c0007
	v_subrev_f32_e32 v0, v7, v20                                ; 0a002907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1b0004
	v_subrev_f32_e32 v0, v4, v19                                ; 0a002704
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v20                               ; 0a00290d
(invalid instruction)                                        ; cc1b000a
	v_subrev_f32_e32 v0, v10, v19                               ; 0a00270a
(invalid instruction)                                        ; cc1b0007
	v_subrev_f32_e32 v0, v7, v19                                ; 0a002707
	v_cvt_f32_f16_e32 v5, v132/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a1784
	v_cvt_f32_f16_e32 v4, v4                                    ; 7e081704
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v19                               ; 0a00270d
	v_cvt_f32_f16_e32 v11, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e16178a
	v_cvt_f32_f16_e32 v10, v10                                  ; 7e14170a
	v_cvt_f32_f16_e32 v8, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e101787
	v_cvt_f32_f16_e32 v7, v7                                    ; 7e0e1707
	v_cvt_f16_f32_e32 v48, v52                                  ; 7e601534
(invalid instruction)                                        ; 7f60153c
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                        ; 02020b04
	v_cvt_f32_f16_e32 v14, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1c178d
	v_cvt_f32_f16_e32 v13, v13                                  ; 7e1a170d
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	v_cvt_f16_f32_e32 v51, v53                                  ; 7e661535
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                        ; 02021107
(invalid instruction)                                        ; 7f66153d
(invalid instruction)                                        ; cc1c0030
	v_subrev_f32_e32 v0, v48, v20                               ; 0a002930
	v_perm_b32 v4, v4, v6, 0x7060500                            ; d6440004 03fe0d04 07060500
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                      ; 02021d0d
	v_cvt_f16_f32_e32 v54, v54                                  ; 7e6c1536
(invalid instruction)                                        ; 7f6c153e
(invalid instruction)                                        ; cc1c0033
	v_subrev_f32_e32 v0, v51, v20                               ; 0a002933
(invalid instruction)                                        ; cc1b0030
	v_subrev_f32_e32 v0, v48, v19                               ; 0a002730
	v_perm_b32 v4, v4, v9, 0x7060004                            ; d6440004 03fe1304 07060004
	v_perm_b32 v9, v9, v6, 0x7060501                            ; d6440009 03fe0d09 07060501
(invalid instruction)                                        ; cc1c0036
	v_subrev_f32_e32 v0, v54, v20                               ; 0a002936
	v_cvt_f16_f32_e32 v58, v55                                  ; 7e741537
(invalid instruction)                                        ; cc1b0033
	v_subrev_f32_e32 v0, v51, v19                               ; 0a002733
(invalid instruction)                                        ; 7f74153f
	v_cvt_f32_f16_e32 v49, v176/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e6217b0
	v_cvt_f32_f16_e32 v48, v48                                  ; 7e601730
	v_perm_b32 v4, v4, v12, 0x7000504                           ; d6440004 03fe1904 07000504
	v_perm_b32 v9, v9, v12, 0x7010504                           ; d6440009 03fe1909 07010504
(invalid instruction)                                        ; cc1b0036
	v_subrev_f32_e32 v0, v54, v19                               ; 0a002736
	v_cvt_f32_f16_e32 v52, v179/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e6817b3
	v_cvt_f32_f16_e32 v51, v51                                  ; 7e661733
(invalid instruction)                                        ; cc1c003a
	v_subrev_f32_e32 v0, v58, v20                               ; 0a00293a
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
	v_perm_b32 v4, v4, v15, 0x60504                             ; d6440004 03fe1f04 00060504
	v_perm_b32 v9, v9, v15, 0x1060504                           ; d6440009 03fe1f09 01060504
	v_cvt_f32_f16_e32 v56, v182/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7017b6
	v_cvt_f32_f16_e32 v54, v54                                  ; 7e6c1736
	v_cvt_f16_f32_e32 v61, v16                                  ; 7e7a1510
(invalid instruction)                                        ; 7f7a1520
(invalid instruction)                                        ; d7690035
	v_cndmask_b32_e32 v1, v51, v52, vcc_lo                      ; 02026933
	s_mov_b32 s28, s0                                           ; be9c0000
	s_movk_i32 s29, 0x8000                                      ; b01d8000
	s_load_b128 s[32:35], s[28:29], 0x30                        ; f400480e f8000030
(invalid instruction)                                        ; cc1b003a
	v_subrev_f32_e32 v0, v58, v19                               ; 0a00273a
	s_add_co_u32 s25, s5, s24                                   ; 80191805
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s25, s25, 2                                      ; 84198219
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s33, 14                                       ; bea1108e
	s_buffer_load_b32 s25, s[32:35], s25 offset:0x0             ; f4020650 32000000
	v_perm_b32 v5, v5, v50, 0x7060500                           ; d6440005 03fe6505 07060500
(invalid instruction)                                        ; d7690039
	v_cndmask_b32_e32 v1, v54, v56, vcc_lo                      ; 02027136
	v_cvt_f16_f32_e32 v62, v24                                  ; 7e7c1518
(invalid instruction)                                        ; 7f7c1528
	v_cvt_f32_f16_e32 v59, v186/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7617ba
	v_cvt_f32_f16_e32 v58, v58                                  ; 7e74173a
(invalid instruction)                                        ; cc100040
	v_min_num_f64_e32 v[1:2], v[61:62], v[61:62]                ; 1a027b3d
	s_mov_b32 s27, 0x76543210                                   ; be9b00ff 76543210
	s_mov_b32 s28, 0xfedcba98                                   ; be9c00ff fedcba98
	v_cvt_f16_f32_e32 v66, v17                                  ; 7e841511
(invalid instruction)                                        ; 7f841521
	v_perm_b32 v5, v5, v53, 0x7060004                           ; d6440005 03fe6b05 07060004
	v_perm_b32 v53, v53, v50, 0x7060501                         ; d6440035 03fe6535 07060501
	v_cvt_f16_f32_e32 v67, v25                                  ; 7e861519
(invalid instruction)                                        ; 7f861529
(invalid instruction)                                        ; cc10003f
	v_min_num_f64_e32 v[1:2], v[62:63], v[62:63]                ; 1a027d3e
(invalid instruction)                                        ; d769003c
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                      ; 0202773a
	v_cvt_f16_f32_e32 v71, v18                                  ; 7e8e1512
(invalid instruction)                                        ; 7f8e1522
	v_cvt_f16_f32_e32 v72, v26                                  ; 7e90151a
(invalid instruction)                                        ; cc100045
	v_min_num_f64_e32 v[1:2], v[66:67], v[66:67]                ; 1a028542
	v_perm_b32 v5, v5, v57, 0x7000504                           ; d6440005 03fe7305 07000504
(invalid instruction)                                        ; 7f90152a
	v_perm_b32 v53, v53, v57, 0x7010504                         ; d6440035 03fe7335 07010504
(invalid instruction)                                        ; cc100044
	v_min_num_f64_e32 v[1:2], v[67:68], v[67:68]                ; 1a028743
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[64:65], v[63:64]                ; 1a027f40
	v_cvt_f16_f32_e32 v76, v19                                  ; 7e981513
(invalid instruction)                                        ; 7f981523
(invalid instruction)                                        ; cc10004a
	v_min_num_f64_e32 v[1:2], v[71:72], v[71:72]                ; 1a028f47
	v_cvt_f16_f32_e32 v77, v27                                  ; 7e9a151b
(invalid instruction)                                        ; 7f9a152b
	v_perm_b32 v5, v5, v60, 0x60504                             ; d6440005 03fe7905 00060504
(invalid instruction)                                        ; cc100049
	v_min_num_f64_e32 v[1:2], v[72:73], v[72:73]                ; 1a029148
	v_perm_b32 v53, v53, v60, 0x1060504                         ; d6440035 03fe7935 01060504
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[68:69]                ; 1a028945
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_permlanex16_b32 v65, v64, s27, s28 op_sel:[1,1]           ; d65c1841 00703740
	v_cvt_f16_f32_e32 v81, v20                                  ; 7ea21514
(invalid instruction)                                        ; cc10004f
	v_min_num_f64_e32 v[1:2], v[76:77], v[76:77]                ; 1a02994c
(invalid instruction)                                        ; 7fa21524
	v_cvt_f16_f32_e32 v82, v28                                  ; 7ea4151c
(invalid instruction)                                        ; 7fa4152c
(invalid instruction)                                        ; cc10004e
	v_min_num_f64_e32 v[1:2], v[77:78], v[77:78]                ; 1a029b4d
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[73:74]                ; 1a02934a
	v_permlanex16_b32 v70, v69, s27, s28 op_sel:[1,1]           ; d65c1846 00703745
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[64:65], v[65:66]                ; 1a028340
	v_cvt_f16_f32_e32 v86, v21                                  ; 7eac1515
(invalid instruction)                                        ; 7fac1525
	v_cvt_f16_f32_e32 v87, v29                                  ; 7eae151d
(invalid instruction)                                        ; 7fae152d
(invalid instruction)                                        ; cc100054
	v_min_num_f64_e32 v[1:2], v[81:82], v[81:82]                ; 1a02a351
(invalid instruction)                                        ; cc100053
	v_min_num_f64_e32 v[1:2], v[82:83], v[82:83]                ; 1a02a552
(invalid instruction)                                        ; cc0f004f
	v_min_num_f64_e32 v[1:2], v[79:80], v[78:79]                ; 1a029d4f
	v_permlanex16_b32 v75, v74, s27, s28 op_sel:[1,1]           ; d65c184b 0070374a
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[70:71]                ; 1a028d45
	v_cvt_f16_f32_e32 v91, v22                                  ; 7eb61516
(invalid instruction)                                        ; 7fb61526
(invalid instruction)                                        ; cc100059
	v_min_num_f64_e32 v[1:2], v[86:87], v[86:87]                ; 1a02ad56
	v_cvt_f16_f32_e32 v92, v30                                  ; 7eb8151e
(invalid instruction)                                        ; 7fb8152e
(invalid instruction)                                        ; cc100058
	v_min_num_f64_e32 v[1:2], v[87:88], v[87:88]                ; 1a02af57
(invalid instruction)                                        ; cc0f0054
	v_min_num_f64_e32 v[1:2], v[84:85], v[83:84]                ; 1a02a754
	v_permlanex16_b32 v80, v79, s27, s28 op_sel:[1,1]           ; d65c1850 0070374f
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[75:76]                ; 1a02974a
	v_cvt_f16_f32_e32 v96, v23                                  ; 7ec01517
(invalid instruction)                                        ; 7fc01527
	v_cvt_f16_f32_e32 v97, v31                                  ; 7ec2151f
(invalid instruction)                                        ; cc10005e
	v_min_num_f64_e32 v[1:2], v[91:92], v[91:92]                ; 1a02b75b
(invalid instruction)                                        ; 7fc2152f
(invalid instruction)                                        ; cc10005d
	v_min_num_f64_e32 v[1:2], v[92:93], v[92:93]                ; 1a02b95c
(invalid instruction)                                        ; cc0f0059
	v_min_num_f64_e32 v[1:2], v[89:90], v[88:89]                ; 1a02b159
	v_permlanex16_b32 v85, v84, s27, s28 op_sel:[1,1]           ; d65c1855 00703754
(invalid instruction)                                        ; cc0f004f
	v_min_num_f64_e32 v[1:2], v[79:80], v[80:81]                ; 1a02a14f
(invalid instruction)                                        ; cc100063
	v_min_num_f64_e32 v[1:2], v[96:97], v[96:97]                ; 1a02c160
(invalid instruction)                                        ; cc100062
	v_min_num_f64_e32 v[1:2], v[97:98], v[97:98]                ; 1a02c361
(invalid instruction)                                        ; cc0f005e
	v_min_num_f64_e32 v[1:2], v[94:95], v[93:94]                ; 1a02bb5e
	v_permlanex16_b32 v90, v89, s27, s28 op_sel:[1,1]           ; d65c185a 00703759
(invalid instruction)                                        ; cc0f0054
	v_min_num_f64_e32 v[1:2], v[84:85], v[85:86]                ; 1a02ab54
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f0063
	v_min_num_f64_e32 v[1:2], v[99:100], v[98:99]               ; 1a02c563
	v_permlanex16_b32 v95, v94, s27, s28 op_sel:[1,1]           ; d65c185f 0070375e
(invalid instruction)                                        ; cc0f0059
	v_min_num_f64_e32 v[1:2], v[89:90], v[90:91]                ; 1a02b559
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[64:65], v[84:85]                ; 1a02a940
	v_permlanex16_b32 v100, v99, s27, s28 op_sel:[1,1]          ; d65c1864 00703763
(invalid instruction)                                        ; cc0f005e
	v_min_num_f64_e32 v[1:2], v[94:95], v[95:96]                ; 1a02bf5e
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[89:90]                ; 1a02b345
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0063
	v_min_num_f64_e32 v[1:2], v[99:100], v[100:101]             ; 1a02c963
(invalid instruction)                                        ; cc0f004a
	v_min_num_f64_e32 v[1:2], v[74:75], v[94:95]                ; 1a02bd4a
(invalid instruction)                                        ; cc0f004f
	v_min_num_f64_e32 v[1:2], v[79:80], v[99:100]               ; 1a02c74f
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[64:65], v[74:75]                ; 1a029540
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f0045
	v_min_num_f64_e32 v[1:2], v[69:70], v[79:80]                ; 1a029f45
(invalid instruction)                                        ; cc0f0040
	v_min_num_f64_e32 v[1:2], v[64:65], v[69:70]                ; 1a028b40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0040
	v_subrev_f32_e32 v0, v64, v255                              ; 0a01ff40
(invalid instruction)                                        ; 00000410
	v_cvt_f32_f16_e32 v101, v64                                 ; 7eca1740
	v_cvt_f32_f16_e32 v64, v192/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8017c0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v101, v101                                    ; 7eca5d65
	v_rsq_f32_e32 v64, v64                                      ; 7e805d40
	v_cvt_f16_f32_e32 v102, v101                                ; 7ecc1565
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
(invalid instruction)                                        ; 7fcc1540
(invalid instruction)                                        ; cc10003d
	v_min_num_f64_e32 v[1:2], v[61:62], v[102:103]              ; 1a02cd3d
(invalid instruction)                                        ; cc10003e
	v_min_num_f64_e32 v[1:2], v[62:63], v[102:103]              ; 1a02cd3e
(invalid instruction)                                        ; cc100042
	v_min_num_f64_e32 v[1:2], v[66:67], v[102:103]              ; 1a02cd42
(invalid instruction)                                        ; cc100043
	v_min_num_f64_e32 v[1:2], v[67:68], v[102:103]              ; 1a02cd43
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cvt_f16_f32 s25, s25                                      ; be996819
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_pack_ll_b32_b16 s25, s25, 0x3c00                          ; 9919ff19 00003c00
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc100042
	v_min_num_f64_e32 v[0:1], v[66:67], v[25:26]                ; 1a003342
(invalid instruction)                                        ; cc10003e
	v_min_num_f64_e32 v[0:1], v[62:63], v[25:26]                ; 1a00333e
(invalid instruction)                                        ; cc10003d
	v_min_num_f64_e32 v[0:1], v[61:62], v[25:26]                ; 1a00333d
(invalid instruction)                                        ; cc100043
	v_min_num_f64_e32 v[0:1], v[67:68], v[25:26]                ; 1a003343
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v20                               ; 0a002942
(invalid instruction)                                        ; cc1c003e
	v_subrev_f32_e32 v0, v62, v20                               ; 0a00293e
(invalid instruction)                                        ; cc1c003d
	v_subrev_f32_e32 v0, v61, v20                               ; 0a00293d
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v20                               ; 0a002943
(invalid instruction)                                        ; cc1b0042
	v_subrev_f32_e32 v0, v66, v19                               ; 0a002742
(invalid instruction)                                        ; cc1b003e
	v_subrev_f32_e32 v0, v62, v19                               ; 0a00273e
(invalid instruction)                                        ; cc100047
	v_min_num_f64_e32 v[1:2], v[71:72], v[102:103]              ; 1a02cd47
(invalid instruction)                                        ; cc100048
	v_min_num_f64_e32 v[1:2], v[72:73], v[102:103]              ; 1a02cd48
(invalid instruction)                                        ; cc1b003d
	v_subrev_f32_e32 v0, v61, v19                               ; 0a00273d
(invalid instruction)                                        ; cc1b0043
	v_subrev_f32_e32 v0, v67, v19                               ; 0a002743
	v_cvt_f32_f16_e32 v107, v194/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ed617c2
	v_cvt_f32_f16_e32 v66, v66                                  ; 7e841742
	v_cvt_f32_f16_e32 v105, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ed217be
	v_cvt_f32_f16_e32 v62, v62                                  ; 7e7c173e
(invalid instruction)                                        ; cc100047
	v_min_num_f64_e32 v[0:1], v[71:72], v[25:26]                ; 1a003347
(invalid instruction)                                        ; cc100048
	v_min_num_f64_e32 v[0:1], v[72:73], v[25:26]                ; 1a003348
	v_cvt_f32_f16_e32 v103, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ece17bd
	v_cvt_f32_f16_e32 v61, v61                                  ; 7e7a173d
	v_cvt_f32_f16_e32 v109, v195/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eda17c3
	v_cvt_f32_f16_e32 v67, v67                                  ; 7e861743
(invalid instruction)                                        ; d769006c
	v_cndmask_b32_e32 v1, v66, v107, vcc_lo                     ; 0202d742
(invalid instruction)                                        ; d769006a
	v_cndmask_b32_e32 v1, v62, v105, vcc_lo                     ; 0202d33e
(invalid instruction)                                        ; cc10004c
	v_min_num_f64_e32 v[1:2], v[76:77], v[102:103]              ; 1a02cd4c
(invalid instruction)                                        ; cc10004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[102:103]              ; 1a02cd4d
(invalid instruction)                                        ; cc1c0047
	v_subrev_f32_e32 v0, v71, v20                               ; 0a002947
(invalid instruction)                                        ; cc1c0048
	v_subrev_f32_e32 v0, v72, v20                               ; 0a002948
(invalid instruction)                                        ; d7690068
	v_cndmask_b32_e32 v1, v61, v103, vcc_lo                     ; 0202cf3d
(invalid instruction)                                        ; d769006e
	v_cndmask_b32_e32 v1, v67, v109, vcc_lo                     ; 0202db43
(invalid instruction)                                        ; cc10004c
	v_min_num_f64_e32 v[0:1], v[76:77], v[25:26]                ; 1a00334c
(invalid instruction)                                        ; cc10004d
	v_min_num_f64_e32 v[0:1], v[77:78], v[25:26]                ; 1a00334d
(invalid instruction)                                        ; cc1b0047
	v_subrev_f32_e32 v0, v71, v19                               ; 0a002747
(invalid instruction)                                        ; cc1b0048
	v_subrev_f32_e32 v0, v72, v19                               ; 0a002748
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c004c
	v_subrev_f32_e32 v0, v76, v20                               ; 0a00294c
	v_perm_b32 v6, v6, v104, 0x7060500                          ; d6440006 03fed106 07060500
(invalid instruction)                                        ; cc1c004d
	v_subrev_f32_e32 v0, v77, v20                               ; 0a00294d
	v_cvt_f32_f16_e32 v111, v199/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ede17c7
	v_cvt_f32_f16_e32 v71, v71                                  ; 7e8e1747
	v_cvt_f32_f16_e32 v113, v200/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ee217c8
	v_cvt_f32_f16_e32 v72, v72                                  ; 7e901748
(invalid instruction)                                        ; cc1b004c
	v_subrev_f32_e32 v0, v76, v19                               ; 0a00274c
	v_perm_b32 v6, v6, v108, 0x7060004                          ; d6440006 03fed906 07060004
	v_perm_b32 v108, v108, v104, 0x7060501                      ; d644006c 03fed16c 07060501
	v_perm_b32 v10, v10, v106, 0x7060500                        ; d644000a 03fed50a 07060500
(invalid instruction)                                        ; cc1b004d
	v_subrev_f32_e32 v0, v77, v19                               ; 0a00274d
(invalid instruction)                                        ; d7690070
	v_cndmask_b32_e32 v1, v71, v111, vcc_lo                     ; 0202df47
(invalid instruction)                                        ; d7690072
	v_cndmask_b32_e32 v1, v72, v113, vcc_lo                     ; 0202e348
	v_cvt_f32_f16_e32 v115, v204/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ee617cc
	v_cvt_f32_f16_e32 v76, v76                                  ; 7e98174c
(invalid instruction)                                        ; cc100051
	v_min_num_f64_e32 v[1:2], v[81:82], v[102:103]              ; 1a02cd51
(invalid instruction)                                        ; cc100052
	v_min_num_f64_e32 v[1:2], v[82:83], v[102:103]              ; 1a02cd52
	v_perm_b32 v10, v10, v110, 0x7060004                        ; d644000a 03fedd0a 07060004
	v_perm_b32 v110, v110, v106, 0x7060501                      ; d644006e 03fed56e 07060501
	v_cvt_f32_f16_e32 v117, v205/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eea17cd
	v_cvt_f32_f16_e32 v77, v77                                  ; 7e9a174d
	v_perm_b32 v108, v108, v112, 0x7010504                      ; d644006c 03fee16c 07010504
	v_perm_b32 v6, v6, v112, 0x7000504                          ; d6440006 03fee106 07000504
(invalid instruction)                                        ; d7690074
	v_cndmask_b32_e32 v1, v76, v115, vcc_lo                     ; 0202e74c
(invalid instruction)                                        ; cc100051
	v_min_num_f64_e32 v[0:1], v[81:82], v[25:26]                ; 1a003351
(invalid instruction)                                        ; cc100052
	v_min_num_f64_e32 v[0:1], v[82:83], v[25:26]                ; 1a003352
	v_perm_b32 v10, v10, v114, 0x7000504                        ; d644000a 03fee50a 07000504
	v_perm_b32 v110, v110, v114, 0x7010504                      ; d644006e 03fee56e 07010504
(invalid instruction)                                        ; d7690076
	v_cndmask_b32_e32 v1, v77, v117, vcc_lo                     ; 0202eb4d
(invalid instruction)                                        ; cc100056
	v_min_num_f64_e32 v[1:2], v[86:87], v[102:103]              ; 1a02cd56
	v_perm_b32 v6, v6, v116, 0x60504                            ; d6440006 03fee906 00060504
	v_perm_b32 v108, v108, v116, 0x1060504                      ; d644006c 03fee96c 01060504
(invalid instruction)                                        ; cc100057
	v_min_num_f64_e32 v[1:2], v[87:88], v[102:103]              ; 1a02cd57
(invalid instruction)                                        ; cc1c0051
	v_subrev_f32_e32 v0, v81, v20                               ; 0a002951
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v20                               ; 0a002952
	v_perm_b32 v10, v10, v118, 0x60504                          ; d644000a 03feed0a 00060504
	v_perm_b32 v110, v110, v118, 0x1060504                      ; d644006e 03feed6e 01060504
(invalid instruction)                                        ; cc100056
	v_min_num_f64_e32 v[0:1], v[86:87], v[25:26]                ; 1a003356
(invalid instruction)                                        ; cc100057
	v_min_num_f64_e32 v[0:1], v[87:88], v[25:26]                ; 1a003357
(invalid instruction)                                        ; cc1b0051
	v_subrev_f32_e32 v0, v81, v19                               ; 0a002751
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v19                               ; 0a002752
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c0056
	v_subrev_f32_e32 v0, v86, v20                               ; 0a002956
(invalid instruction)                                        ; cc1c0057
	v_subrev_f32_e32 v0, v87, v20                               ; 0a002957
(invalid instruction)                                        ; cc10005b
	v_min_num_f64_e32 v[1:2], v[91:92], v[102:103]              ; 1a02cd5b
(invalid instruction)                                        ; cc10005c
	v_min_num_f64_e32 v[1:2], v[92:93], v[102:103]              ; 1a02cd5c
	v_cvt_f32_f16_e32 v119, v209/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eee17d1
	v_cvt_f32_f16_e32 v81, v81                                  ; 7ea21751
	v_cvt_f32_f16_e32 v121, v210/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ef217d2
	v_cvt_f32_f16_e32 v82, v82                                  ; 7ea41752
(invalid instruction)                                        ; cc1b0056
	v_subrev_f32_e32 v0, v86, v19                               ; 0a002756
(invalid instruction)                                        ; cc1b0057
	v_subrev_f32_e32 v0, v87, v19                               ; 0a002757
(invalid instruction)                                        ; cc10005b
	v_min_num_f64_e32 v[0:1], v[91:92], v[25:26]                ; 1a00335b
(invalid instruction)                                        ; cc10005c
	v_min_num_f64_e32 v[0:1], v[92:93], v[25:26]                ; 1a00335c
(invalid instruction)                                        ; d7690078
	v_cndmask_b32_e32 v1, v81, v119, vcc_lo                     ; 0202ef51
(invalid instruction)                                        ; d769007a
	v_cndmask_b32_e32 v1, v82, v121, vcc_lo                     ; 0202f352
	v_cvt_f32_f16_e32 v123, v214/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ef617d6
	v_cvt_f32_f16_e32 v86, v86                                  ; 7eac1756
	v_cvt_f32_f16_e32 v125, v215/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7efa17d7
(invalid instruction)                                        ; cc100060
	v_min_num_f64_e32 v[1:2], v[96:97], v[102:103]              ; 1a02cd60
	v_cvt_f32_f16_e32 v87, v87                                  ; 7eae1757
(invalid instruction)                                        ; cc1c005b
	v_subrev_f32_e32 v0, v91, v20                               ; 0a00295b
(invalid instruction)                                        ; cc100061
	v_min_num_f64_e32 v[1:2], v[97:98], v[102:103]              ; 1a02cd61
(invalid instruction)                                        ; cc1c005c
	v_subrev_f32_e32 v0, v92, v20                               ; 0a00295c
(invalid instruction)                                        ; d769007c
	v_cndmask_b32_e32 v1, v86, v123, vcc_lo                     ; 0202f756
(invalid instruction)                                        ; cc100060
	v_min_num_f64_e32 v[0:1], v[96:97], v[25:26]                ; 1a003360
(invalid instruction)                                        ; d769007e
	v_cndmask_b32_e32 v1, v87, v125, vcc_lo                     ; 0202fb57
(invalid instruction)                                        ; cc1b005b
	v_subrev_f32_e32 v0, v91, v19                               ; 0a00275b
(invalid instruction)                                        ; cc100061
	v_min_num_f64_e32 v[0:1], v[97:98], v[25:26]                ; 1a003361
(invalid instruction)                                        ; cc1b005c
	v_subrev_f32_e32 v0, v92, v19                               ; 0a00275c
(invalid instruction)                                        ; cc1c0060
	v_subrev_f32_e32 v0, v96, v20                               ; 0a002960
	v_perm_b32 v7, v7, v120, 0x7060500                          ; d6440007 03fef107 07060500
	v_cvt_f32_f16_e32 v127, v219/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7efe17db
	v_cvt_f32_f16_e32 v91, v91                                  ; 7eb6175b
(invalid instruction)                                        ; cc1c0061
	v_subrev_f32_e32 v0, v97, v20                               ; 0a002961
	v_cvt_f32_f16_e32 v129, v220/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f0217dc
	v_cvt_f32_f16_e32 v92, v92                                  ; 7eb8175c
(invalid instruction)                                        ; cc1b0060
	v_subrev_f32_e32 v0, v96, v19                               ; 0a002760
	v_perm_b32 v7, v7, v124, 0x7060004                          ; d6440007 03fef907 07060004
	v_perm_b32 v124, v124, v120, 0x7060501                      ; d644007c 03fef17c 07060501
	v_perm_b32 v11, v11, v122, 0x7060500                        ; d644000b 03fef50b 07060500
(invalid instruction)                                        ; d7690080
	v_cndmask_b32_e32 v1, v91, v127, vcc_lo                     ; 0202ff5b
(invalid instruction)                                        ; cc1b0061
	v_subrev_f32_e32 v0, v97, v19                               ; 0a002761
(invalid instruction)                                        ; d7690082
	v_cndmask_b32_e32 v1, v92, v129, vcc_lo                     ; 0203035c
	v_cvt_f32_f16_e32 v131, v224/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f0617e0
	v_cvt_f32_f16_e32 v96, v96                                  ; 7ec01760
	v_perm_b32 v11, v11, v126, 0x7060004                        ; d644000b 03fefd0b 07060004
	v_perm_b32 v126, v126, v122, 0x7060501                      ; d644007e 03fef57e 07060501
	v_perm_b32 v124, v124, v128, 0x7010504                      ; d644007c 03ff017c 07010504
	v_perm_b32 v7, v7, v128, 0x7000504                          ; d6440007 03ff0107 07000504
	v_cvt_f32_f16_e32 v133, v225/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f0a17e1
	v_cvt_f32_f16_e32 v97, v97                                  ; 7ec21761
(invalid instruction)                                        ; d7690084
	v_cndmask_b32_e32 v1, v96, v131, vcc_lo                     ; 02030760
	v_perm_b32 v11, v11, v130, 0x7000504                        ; d644000b 03ff050b 07000504
	v_perm_b32 v126, v126, v130, 0x7010504                      ; d644007e 03ff057e 07010504
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
(invalid instruction)                                        ; d7690086
	v_cndmask_b32_e32 v1, v97, v133, vcc_lo                     ; 02030b61
	v_perm_b32 v7, v7, v132, 0x60504                            ; d6440007 03ff0907 00060504
	v_perm_b32 v124, v124, v132, 0x1060504                      ; d644007c 03ff097c 01060504
	v_perm_b32 v126, v126, v134, 0x1060504                      ; d644007e 03ff0d7e 01060504
	v_perm_b32 v11, v11, v134, 0x60504                          ; d644000b 03ff0d0b 00060504
	s_branch BB67                                               ; bfa0000c
BB66:
	v_mov_b32_e32 v4, 0                                         ; 7e080280
	v_mov_b32_e32 v6, 0                                         ; 7e0c0280
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v5, 0               ; ca100080 0a040080
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v7, 0              ; ca100080 6c060080
	v_dual_mov_b32 v110, 0 :: v_dual_mov_b32 v9, 0              ; ca100080 6e080080
	v_dual_mov_b32 v124, 0 :: v_dual_mov_b32 v11, 0             ; ca100080 7c0a0080
	v_dual_mov_b32 v126, 0 :: v_dual_mov_b32 v53, 0             ; ca100080 7e340080
BB67:
(invalid instruction)                                        ; d71f0008
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1) ; bf8700b2
	v_mov_b32_e32 v111, v126                                    ; 7ede037e
	v_and_b32_e32 v12, 15, v8                                   ; 3618108f
	v_lshrrev_b32_e32 v8, 4, v8                                 ; 32101084
	v_lshlrev_b32_e32 v8, 3, v8                                 ; 30101083
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mad_u32_u24 v13, 36, v12, v8                              ; d60b000d 042218a4
	v_mad_u32_u24 v13, s12, 0x480, v13                          ; d60b000d 0435fe0c 00000480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
	v_dual_mov_b32 v109, v124 :: v_dual_add_nc_u32 v14, 0x800, v13 ; ca20017c 6d0e1aff 00000800
	ds_store_2addr_b64 v13, v[6:7], v[10:11] offset1:2          ; d9380200 000a060d
	ds_store_2addr_b64 v14, v[108:109], v[110:111] offset0:32 offset1:34 ; d9382220 006e6c0e
	v_mov_b32_e32 v10, v53                                      ; 7e140335
	v_lshl_add_u32 v12, v12, 6, v8                              ; d646000c 04210d0c
	v_add_nc_u32_e32 v12, s13, v12                              ; 4a18180d
	ds_store_2addr_stride64_b64 v12, v[4:5], v[9:10] offset0:9 offset1:11 ; d93c0b09 0009040c
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0                ; ca100080 05040080
	v_add_nc_u32_e32 v12, 0x1000, v12                           ; 4a1818ff 00001000
	ds_store_2addr_b64 v13, v[4:5], v[4:5] offset0:72 offset1:74 ; d9384a48 0004040d
	ds_store_2addr_b64 v14, v[4:5], v[4:5] offset0:104 offset1:106 ; d9386a68 0004040e
	ds_store_2addr_b64 v12, v[4:5], v[4:5] offset0:66 offset1:194 ; d938c242 0004040c
	s_branch BB80                                               ; bfa003ad
BB68:
	s_cmp_eq_i32 s38, 2                                         ; bf008226
	s_cbranch_scc0 BB77                                         ; bfa10389
BB69:
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v16, 0              ; ca100080 11100080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0              ; ca100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0              ; ca100080 15140080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0              ; ca100080 17160080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0              ; ca100080 19180080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0              ; ca100080 1b1a0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v28, 0              ; ca100080 1d1c0080
	s_mov_b32 s19, 0                                            ; be930080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0              ; ca100080 1f1e0080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0              ; ca100080 21200080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0              ; ca100080 23220080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0              ; ca100080 25240080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0              ; ca100080 27260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0              ; ca100080 29280080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0              ; ca100080 2b2a0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0              ; ca100080 2d2c0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0              ; ca100080 2f2e0080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0              ; ca100080 31300080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0              ; ca100080 33320080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0              ; ca100080 35340080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v54, 0              ; ca100080 37360080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v56, 0              ; ca100080 39380080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v58, 0              ; ca100080 3b3a0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v60, 0              ; ca100080 3d3c0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v62, 0              ; ca100080 3f3e0080
	s_branch BB70                                               ; bfa000e5
BB72:
	s_mov_b32 s28, s0                                           ; be9c0000
	s_movk_i32 s29, 0x8000                                      ; b01d8000
	s_clause 0x1                                                ; bf850001
	s_load_b128 s[32:35], s[28:29], 0x40                        ; f400480e f8000040
	s_load_b128 s[36:39], s[28:29], 0x20                        ; f400490e f8000020
	v_lshl_add_u32 v5, s19, 2, v4                               ; d6460005 04110413
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_lshlrev_b32_e32 v5, 2, v5                                 ; 300a0a82
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_load_b64 v[10:11], v5, s[32:35], null offen          ; c405407c 4080400a 00000005
	s_lshl_b32 s20, s19, 3                                      ; 84148313
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_lshl_u32 v9, s20, v7, 2                               ; d6470009 020a0e14
	v_add_lshl_u32 v12, s20, v8, 2                              ; d647000c 020a1014
	v_add_lshl_u32 v13, s20, v6, 2                              ; d647000d 020a0c14
	s_clause 0x14                                               ; bf850014
	buffer_load_b128 v[64:67], v9, s[36:39], null offen         ; c405c07c 40804840 00000009
	buffer_load_b128 v[68:71], v12, s[36:39], null offen        ; c405c07c 40804844 0000000c
	buffer_load_b128 v[72:75], v13, s[36:39], null offen        ; c405c07c 40804848 0000000d
	buffer_load_b128 v[76:79], v9, s[36:39], null offen offset:512 ; c405c07c 4080484c 00020009
	buffer_load_b128 v[80:83], v12, s[36:39], null offen offset:512 ; c405c07c 40804850 0002000c
	buffer_load_b128 v[84:87], v13, s[36:39], null offen offset:512 ; c405c07c 40804854 0002000d
	buffer_load_b128 v[88:91], v9, s[36:39], null offen offset:1024 ; c405c07c 40804858 00040009
	buffer_load_b128 v[92:95], v12, s[36:39], null offen offset:1024 ; c405c07c 4080485c 0004000c
	buffer_load_b128 v[96:99], v13, s[36:39], null offen offset:1024 ; c405c07c 40804860 0004000d
	buffer_load_b128 v[100:103], v9, s[36:39], null offen offset:1536 ; c405c07c 40804864 00060009
	buffer_load_b128 v[104:107], v12, s[36:39], null offen offset:1536 ; c405c07c 40804868 0006000c
	buffer_load_b128 v[108:111], v13, s[36:39], null offen offset:1536 ; c405c07c 4080486c 0006000d
	buffer_load_b128 v[112:115], v9, s[36:39], null offen offset:2048 ; c405c07c 40804870 00080009
	buffer_load_b128 v[116:119], v12, s[36:39], null offen offset:2048 ; c405c07c 40804874 0008000c
	buffer_load_b128 v[120:123], v13, s[36:39], null offen offset:2048 ; c405c07c 40804878 0008000d
	buffer_load_b128 v[124:127], v9, s[36:39], null offen offset:2560 ; c405c07c 4080487c 000a0009
	buffer_load_b128 v[128:131], v12, s[36:39], null offen offset:2560 ; c405c07c 40804880 000a000c
	buffer_load_b128 v[132:135], v13, s[36:39], null offen offset:2560 ; c405c07c 40804884 000a000d
	buffer_load_b128 v[136:139], v9, s[36:39], null offen offset:3072 ; c405c07c 40804888 000c0009
	buffer_load_b128 v[140:143], v12, s[36:39], null offen offset:3072 ; c405c07c 4080488c 000c000c
	buffer_load_b128 v[144:147], v13, s[36:39], null offen offset:3072 ; c405c07c 40804890 000c000d
	s_clause 0x6                                                ; bf850006
	buffer_load_b64 v[14:15], v5, s[32:35], null offen offset:256 ; c405407c 4080400e 00010005
	buffer_load_b64 v[148:149], v5, s[32:35], null offen offset:512 ; c405407c 40804094 00020005
	buffer_load_b64 v[150:151], v5, s[32:35], null offen offset:768 ; c405407c 40804096 00030005
	buffer_load_b64 v[152:153], v5, s[32:35], null offen offset:1024 ; c405407c 40804098 00040005
	buffer_load_b64 v[154:155], v5, s[32:35], null offen offset:1280 ; c405407c 4080409a 00050005
	buffer_load_b64 v[156:157], v5, s[32:35], null offen offset:1536 ; c405407c 4080409c 00060005
	buffer_load_b64 v[158:159], v5, s[32:35], null offen offset:1792 ; c405407c 4080409e 00070005
	s_clause 0x2                                                ; bf850002
	buffer_load_b128 v[160:163], v9, s[36:39], null offen offset:3584 ; c405c07c 408048a0 000e0009
	buffer_load_b128 v[164:167], v12, s[36:39], null offen offset:3584 ; c405c07c 408048a4 000e000c
	buffer_load_b128 v[168:171], v13, s[36:39], null offen offset:3584 ; c405c07c 408048a8 000e000d
	s_addk_co_i32 s19, 0x80                                     ; b7930080
	s_wait_loadcnt 0x1e                                         ; bfc0001e
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[64:65], v[10:11], v[16:23] ; cc464010 1c421540
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[66:67], v[10:11], v[24:31] ; cc464018 1c621542
	s_wait_loadcnt 0x1d                                         ; bfc0001d
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[68:69], v[10:11], v[32:39] ; cc464020 1c821544
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[70:71], v[10:11], v[40:47] ; cc464028 1ca21546
	s_wait_loadcnt 0x1c                                         ; bfc0001c
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[10:11], v[74:75], v[56:63] ; cc464038 1ce2950a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[10:11], v[72:73], v[48:55] ; cc464030 1cc2910a
	s_wait_loadcnt 0x9                                          ; bfc00009
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[76:77], v[14:15], v[16:23] ; cc464010 1c421d4c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[78:79], v[14:15], v[24:31] ; cc464018 1c621d4e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[80:81], v[14:15], v[32:39] ; cc464020 1c821d50
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[82:83], v[14:15], v[40:47] ; cc464028 1ca21d52
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[14:15], v[86:87], v[56:63] ; cc464038 1ce2ad0e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[14:15], v[84:85], v[48:55] ; cc464030 1cc2a90e
	s_wait_loadcnt 0x8                                          ; bfc00008
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[88:89], v[148:149], v[16:23] ; cc464010 1c432958
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[90:91], v[148:149], v[24:31] ; cc464018 1c63295a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[92:93], v[148:149], v[32:39] ; cc464020 1c83295c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[94:95], v[148:149], v[40:47] ; cc464028 1ca3295e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[148:149], v[98:99], v[56:63] ; cc464038 1ce2c594
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[148:149], v[96:97], v[48:55] ; cc464030 1cc2c194
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[100:101], v[150:151], v[16:23] ; cc464010 1c432d64
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[102:103], v[150:151], v[24:31] ; cc464018 1c632d66
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[104:105], v[150:151], v[32:39] ; cc464020 1c832d68
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[106:107], v[150:151], v[40:47] ; cc464028 1ca32d6a
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[150:151], v[110:111], v[56:63] ; cc464038 1ce2dd96
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[150:151], v[108:109], v[48:55] ; cc464030 1cc2d996
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[112:113], v[152:153], v[16:23] ; cc464010 1c433170
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[114:115], v[152:153], v[24:31] ; cc464018 1c633172
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[116:117], v[152:153], v[32:39] ; cc464020 1c833174
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[118:119], v[152:153], v[40:47] ; cc464028 1ca33176
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[152:153], v[122:123], v[56:63] ; cc464038 1ce2f598
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[152:153], v[120:121], v[48:55] ; cc464030 1cc2f198
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[124:125], v[154:155], v[16:23] ; cc464010 1c43357c
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[126:127], v[154:155], v[24:31] ; cc464018 1c63357e
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[128:129], v[154:155], v[32:39] ; cc464020 1c833580
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[130:131], v[154:155], v[40:47] ; cc464028 1ca33582
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[154:155], v[134:135], v[56:63] ; cc464038 1ce30d9a
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[154:155], v[132:133], v[48:55] ; cc464030 1cc3099a
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[136:137], v[156:157], v[16:23] ; cc464010 1c433988
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[138:139], v[156:157], v[24:31] ; cc464018 1c63398a
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[140:141], v[156:157], v[32:39] ; cc464020 1c83398c
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[142:143], v[156:157], v[40:47] ; cc464028 1ca3398e
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[156:157], v[146:147], v[56:63] ; cc464038 1ce3259c
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[156:157], v[144:145], v[48:55] ; cc464030 1cc3219c
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[160:161], v[158:159], v[16:23] ; cc464010 1c433da0
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[162:163], v[158:159], v[24:31] ; cc464018 1c633da2
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_wmma_f32_16x16x16_fp8_fp8 v[32:39], v[164:165], v[158:159], v[32:39] ; cc464020 1c833da4
	v_wmma_f32_16x16x16_fp8_fp8 v[40:47], v[166:167], v[158:159], v[40:47] ; cc464028 1ca33da6
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_wmma_f32_16x16x16_fp8_fp8 v[56:63], v[158:159], v[170:171], v[56:63] ; cc464038 1ce3559e
	v_wmma_f32_16x16x16_fp8_fp8 v[48:55], v[158:159], v[168:169], v[48:55] ; cc464030 1cc3519e
BB70:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s19, s6                                        ; bf090613
	s_cbranch_scc0 BB72                                         ; bfa1ff18
BB73:
(invalid instruction)                                        ; d71f0004
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0                ; ca100080 09080080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_and_b32_e32 v5, 15, v4                                    ; 360a088f
	v_lshrrev_b32_e32 v4, 4, v4                                 ; 32080884
	v_lshlrev_b32_e32 v4, 3, v4                                 ; 30080883
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_mad_u32_u24 v6, 36, v5, v4                                ; d60b0006 04120aa4
	v_lshl_add_u32 v5, v5, 6, v4                                ; d6460005 04110d05
	v_mad_u32_u24 v6, s12, 0x480, v6                            ; d60b0006 0419fe0c 00000480
	v_add_nc_u32_e32 v5, s13, v5                                ; 4a0a0a0d
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v7, 0x800, v6                              ; 4a0e0cff 00000800
	ds_store_2addr_b64 v6, v[8:9], v[8:9] offset1:2             ; d9380200 00080806
	ds_store_2addr_b64 v7, v[8:9], v[8:9] offset0:32 offset1:34 ; d9382220 00080807
	ds_store_2addr_stride64_b64 v5, v[8:9], v[8:9] offset0:9 offset1:11 ; d93c0b09 00080805
	s_cmp_lg_i32 s40, 0                                         ; bf018028
	s_cbranch_scc1 BB75                                         ; bfa2023a
BB74:
	v_cvt_f16_f32_e32 v4, v48                                   ; 7e081530
(invalid instruction)                                        ; 7f081538
	s_movk_i32 s19, 0x5f00                                      ; b0135f00
	s_movk_i32 s20, 0xdf00                                      ; b014df00
	v_cvt_f16_f32_e32 v10, v49                                  ; 7e141531
(invalid instruction)                                        ; 7f141539
	v_cvt_f16_f32_e32 v13, v50                                  ; 7e1a1532
(invalid instruction)                                        ; 7f1a153a
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c0004
	v_subrev_f32_e32 v0, v4, v20                                ; 0a002904
	v_cvt_f16_f32_e32 v48, v51                                  ; 7e601533
(invalid instruction)                                        ; 7f60153b
(invalid instruction)                                        ; cc1c000a
	v_subrev_f32_e32 v0, v10, v20                               ; 0a00290a
(invalid instruction)                                        ; cc1c000d
	v_subrev_f32_e32 v0, v13, v20                               ; 0a00290d
(invalid instruction)                                        ; cc1b0004
	v_subrev_f32_e32 v0, v4, v19                                ; 0a002704
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c0030
	v_subrev_f32_e32 v0, v48, v20                               ; 0a002930
(invalid instruction)                                        ; cc1b000a
	v_subrev_f32_e32 v0, v10, v19                               ; 0a00270a
(invalid instruction)                                        ; cc1b000d
	v_subrev_f32_e32 v0, v13, v19                               ; 0a00270d
	v_cvt_f32_f16_e32 v8, v132/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e101784
	v_cvt_f32_f16_e32 v4, v4                                    ; 7e081704
(invalid instruction)                                        ; cc1b0030
	v_subrev_f32_e32 v0, v48, v19                               ; 0a002730
	v_cvt_f32_f16_e32 v11, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e16178a
	v_cvt_f32_f16_e32 v10, v10                                  ; 7e14170a
	v_cvt_f32_f16_e32 v14, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e1c178d
	v_cvt_f32_f16_e32 v13, v13                                  ; 7e1a170d
	v_cvt_f16_f32_e32 v51, v52                                  ; 7e661534
(invalid instruction)                                        ; 7f66153c
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v1, v4, v8, vcc_lo                        ; 02021104
	v_cvt_f32_f16_e32 v49, v176/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e6217b0
	v_cvt_f32_f16_e32 v48, v48                                  ; 7e601730
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
(invalid instruction)                                        ; d769000f
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                      ; 02021d0d
	v_cvt_f16_f32_e32 v57, v53                                  ; 7e721535
(invalid instruction)                                        ; 7f72153d
(invalid instruction)                                        ; cc1c0033
	v_subrev_f32_e32 v0, v51, v20                               ; 0a002933
	v_perm_b32 v10, v10, v9, 0x7060500                          ; d644000a 03fe130a 07060500
(invalid instruction)                                        ; d7690032
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                      ; 02026330
	v_cvt_f16_f32_e32 v60, v54                                  ; 7e781536
(invalid instruction)                                        ; 7f78153e
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v20                               ; 0a002939
(invalid instruction)                                        ; cc1b0033
	v_subrev_f32_e32 v0, v51, v19                               ; 0a002733
	v_perm_b32 v10, v10, v12, 0x7060004                         ; d644000a 03fe190a 07060004
	v_perm_b32 v12, v12, v9, 0x7060501                          ; d644000c 03fe130c 07060501
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v20                               ; 0a00293c
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v19                               ; 0a002739
	v_cvt_f16_f32_e32 v64, v55                                  ; 7e801537
(invalid instruction)                                        ; 7f80153f
	v_cvt_f32_f16_e32 v52, v179/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e6817b3
	v_cvt_f32_f16_e32 v51, v51                                  ; 7e661733
	v_perm_b32 v10, v10, v15, 0x7000504                         ; d644000a 03fe1f0a 07000504
	v_perm_b32 v12, v12, v15, 0x7010504                         ; d644000c 03fe1f0c 07010504
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v19                               ; 0a00273c
	v_cvt_f32_f16_e32 v58, v185/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7417b9
	v_cvt_f32_f16_e32 v57, v57                                  ; 7e721739
(invalid instruction)                                        ; cc1c0040
	v_subrev_f32_e32 v0, v64, v20                               ; 0a002940
(invalid instruction)                                        ; d7690038
	v_cndmask_b32_e32 v1, v51, v52, vcc_lo                      ; 02026933
	v_perm_b32 v10, v10, v50, 0x60504                           ; d644000a 03fe650a 00060504
	v_perm_b32 v12, v12, v50, 0x1060504                         ; d644000c 03fe650c 01060504
	v_cvt_f32_f16_e32 v61, v188/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e7a17bc
	v_cvt_f32_f16_e32 v60, v60                                  ; 7e78173c
	v_cvt_f16_f32_e32 v67, v16                                  ; 7e861510
(invalid instruction)                                        ; d769003b
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                      ; 02027539
(invalid instruction)                                        ; 7f861520
	s_mov_b32 s28, s0                                           ; be9c0000
	s_movk_i32 s29, 0x8000                                      ; b01d8000
	s_load_b128 s[32:35], s[28:29], 0x30                        ; f400480e f8000030
(invalid instruction)                                        ; cc1b0040
	v_subrev_f32_e32 v0, v64, v19                               ; 0a002740
	s_add_co_u32 s25, s5, s24                                   ; 80191805
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s25, s25, 2                                      ; 84198219
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_bitset0_b32 s33, 14                                       ; bea1108e
	s_buffer_load_b32 s25, s[32:35], s25 offset:0x0             ; f4020650 32000000
	v_perm_b32 v11, v11, v56, 0x7060500                         ; d644000b 03fe710b 07060500
(invalid instruction)                                        ; d769003e
	v_cndmask_b32_e32 v1, v60, v61, vcc_lo                      ; 02027b3c
	v_cvt_f16_f32_e32 v68, v24                                  ; 7e881518
(invalid instruction)                                        ; 7f881528
	v_cvt_f32_f16_e32 v65, v192/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8217c0
	v_cvt_f32_f16_e32 v64, v64                                  ; 7e801740
(invalid instruction)                                        ; cc100046
	v_min_num_f64_e32 v[1:2], v[67:68], v[67:68]                ; 1a028743
	s_mov_b32 s27, 0x76543210                                   ; be9b00ff 76543210
	s_mov_b32 s28, 0xfedcba98                                   ; be9c00ff fedcba98
	v_cvt_f16_f32_e32 v72, v17                                  ; 7e901511
	v_perm_b32 v11, v11, v59, 0x7060004                         ; d644000b 03fe770b 07060004
	v_perm_b32 v59, v59, v56, 0x7060501                         ; d644003b 03fe713b 07060501
(invalid instruction)                                        ; 7f901521
	v_cvt_f16_f32_e32 v73, v25                                  ; 7e921519
(invalid instruction)                                        ; 7f921529
(invalid instruction)                                        ; cc100045
	v_min_num_f64_e32 v[1:2], v[68:69], v[68:69]                ; 1a028944
(invalid instruction)                                        ; d7690042
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                      ; 02028340
	v_cvt_f16_f32_e32 v77, v18                                  ; 7e9a1512
(invalid instruction)                                        ; 7f9a1522
	v_cvt_f16_f32_e32 v78, v26                                  ; 7e9c151a
	v_perm_b32 v11, v11, v62, 0x7000504                         ; d644000b 03fe7d0b 07000504
(invalid instruction)                                        ; 7f9c152a
	v_perm_b32 v59, v59, v62, 0x7010504                         ; d644003b 03fe7d3b 07010504
(invalid instruction)                                        ; cc10004b
	v_min_num_f64_e32 v[1:2], v[72:73], v[72:73]                ; 1a029148
(invalid instruction)                                        ; cc10004a
	v_min_num_f64_e32 v[1:2], v[73:74], v[73:74]                ; 1a029349
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[69:70]                ; 1a028b46
	v_cvt_f16_f32_e32 v82, v19                                  ; 7ea41513
(invalid instruction)                                        ; cc100050
	v_min_num_f64_e32 v[1:2], v[77:78], v[77:78]                ; 1a029b4d
(invalid instruction)                                        ; 7fa41523
	v_cvt_f16_f32_e32 v83, v27                                  ; 7ea6151b
(invalid instruction)                                        ; 7fa6152b
	v_perm_b32 v11, v11, v66, 0x60504                           ; d644000b 03fe850b 00060504
(invalid instruction)                                        ; cc10004f
	v_min_num_f64_e32 v[1:2], v[78:79], v[78:79]                ; 1a029d4e
	v_perm_b32 v59, v59, v66, 0x1060504                         ; d644003b 03fe853b 01060504
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[74:75]                ; 1a02954b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_permlanex16_b32 v71, v70, s27, s28 op_sel:[1,1]           ; d65c1847 00703746
	v_cvt_f16_f32_e32 v87, v20                                  ; 7eae1514
(invalid instruction)                                        ; 7fae1524
(invalid instruction)                                        ; cc100055
	v_min_num_f64_e32 v[1:2], v[82:83], v[82:83]                ; 1a02a552
	v_cvt_f16_f32_e32 v88, v28                                  ; 7eb0151c
(invalid instruction)                                        ; 7fb0152c
(invalid instruction)                                        ; cc100054
	v_min_num_f64_e32 v[1:2], v[83:84], v[83:84]                ; 1a02a753
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[79:80]                ; 1a029f50
	v_permlanex16_b32 v76, v75, s27, s28 op_sel:[1,1]           ; d65c184c 0070374b
	v_cvt_f16_f32_e32 v92, v21                                  ; 7eb81515
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[71:72]                ; 1a028f46
(invalid instruction)                                        ; 7fb81525
(invalid instruction)                                        ; cc10005a
	v_min_num_f64_e32 v[1:2], v[87:88], v[87:88]                ; 1a02af57
	v_cvt_f16_f32_e32 v93, v29                                  ; 7eba151d
(invalid instruction)                                        ; 7fba152d
(invalid instruction)                                        ; cc100059
	v_min_num_f64_e32 v[1:2], v[88:89], v[88:89]                ; 1a02b158
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[84:85]                ; 1a02a955
	v_permlanex16_b32 v81, v80, s27, s28 op_sel:[1,1]           ; d65c1851 00703750
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[76:77]                ; 1a02994b
	v_cvt_f16_f32_e32 v97, v22                                  ; 7ec21516
(invalid instruction)                                        ; 7fc21526
	v_cvt_f16_f32_e32 v98, v30                                  ; 7ec4151e
(invalid instruction)                                        ; cc10005f
	v_min_num_f64_e32 v[1:2], v[92:93], v[92:93]                ; 1a02b95c
(invalid instruction)                                        ; 7fc4152e
(invalid instruction)                                        ; cc10005e
	v_min_num_f64_e32 v[1:2], v[93:94], v[93:94]                ; 1a02bb5d
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[89:90]                ; 1a02b35a
	v_permlanex16_b32 v86, v85, s27, s28 op_sel:[1,1]           ; d65c1856 00703755
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[81:82]                ; 1a02a350
	v_cvt_f16_f32_e32 v102, v23                                 ; 7ecc1517
(invalid instruction)                                        ; 7fcc1527
(invalid instruction)                                        ; cc100064
	v_min_num_f64_e32 v[1:2], v[97:98], v[97:98]                ; 1a02c361
	v_cvt_f16_f32_e32 v103, v31                                 ; 7ece151f
(invalid instruction)                                        ; 7fce152f
(invalid instruction)                                        ; cc100063
	v_min_num_f64_e32 v[1:2], v[98:99], v[98:99]                ; 1a02c562
(invalid instruction)                                        ; cc0f005f
	v_min_num_f64_e32 v[1:2], v[95:96], v[94:95]                ; 1a02bd5f
	v_permlanex16_b32 v91, v90, s27, s28 op_sel:[1,1]           ; d65c185b 0070375a
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[86:87]                ; 1a02ad55
(invalid instruction)                                        ; cc100069
	v_min_num_f64_e32 v[1:2], v[102:103], v[102:103]            ; 1a02cd66
(invalid instruction)                                        ; cc100068
	v_min_num_f64_e32 v[1:2], v[103:104], v[103:104]            ; 1a02cf67
(invalid instruction)                                        ; cc0f0064
	v_min_num_f64_e32 v[1:2], v[100:101], v[99:100]             ; 1a02c764
	v_permlanex16_b32 v96, v95, s27, s28 op_sel:[1,1]           ; d65c1860 0070375f
(invalid instruction)                                        ; cc0f005a
	v_min_num_f64_e32 v[1:2], v[90:91], v[91:92]                ; 1a02b75a
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc0f0069
	v_min_num_f64_e32 v[1:2], v[105:106], v[104:105]            ; 1a02d169
	v_permlanex16_b32 v101, v100, s27, s28 op_sel:[1,1]         ; d65c1865 00703764
(invalid instruction)                                        ; cc0f005f
	v_min_num_f64_e32 v[1:2], v[95:96], v[96:97]                ; 1a02c15f
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[90:91]                ; 1a02b546
	v_permlanex16_b32 v106, v105, s27, s28 op_sel:[1,1]         ; d65c186a 00703769
(invalid instruction)                                        ; cc0f0064
	v_min_num_f64_e32 v[1:2], v[100:101], v[101:102]            ; 1a02cb64
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[95:96]                ; 1a02bf4b
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870123
(invalid instruction)                                        ; cc0f0069
	v_min_num_f64_e32 v[1:2], v[105:106], v[106:107]            ; 1a02d569
(invalid instruction)                                        ; cc0f0050
	v_min_num_f64_e32 v[1:2], v[80:81], v[100:101]              ; 1a02c950
(invalid instruction)                                        ; cc0f0055
	v_min_num_f64_e32 v[1:2], v[85:86], v[105:106]              ; 1a02d355
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[80:81]                ; 1a02a146
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870092
(invalid instruction)                                        ; cc0f004b
	v_min_num_f64_e32 v[1:2], v[75:76], v[85:86]                ; 1a02ab4b
(invalid instruction)                                        ; cc0f0046
	v_min_num_f64_e32 v[1:2], v[70:71], v[75:76]                ; 1a029746
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; cc1c0046
	v_subrev_f32_e32 v0, v70, v255                              ; 0a01ff46
(invalid instruction)                                        ; 00000410
	v_cvt_f32_f16_e32 v107, v70                                 ; 7ed61746
	v_cvt_f32_f16_e32 v70, v198/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e8c17c6
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2) ; bf870322
	v_rsq_f32_e32 v107, v107                                    ; 7ed65d6b
	v_rsq_f32_e32 v70, v70                                      ; 7e8c5d46
	v_cvt_f16_f32_e32 v108, v107                                ; 7ed8156b
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870095
(invalid instruction)                                        ; 7fd81546
(invalid instruction)                                        ; cc100043
	v_min_num_f64_e32 v[1:2], v[67:68], v[108:109]              ; 1a02d943
(invalid instruction)                                        ; cc100044
	v_min_num_f64_e32 v[1:2], v[68:69], v[108:109]              ; 1a02d944
(invalid instruction)                                        ; cc100048
	v_min_num_f64_e32 v[1:2], v[72:73], v[108:109]              ; 1a02d948
(invalid instruction)                                        ; cc100049
	v_min_num_f64_e32 v[1:2], v[73:74], v[108:109]              ; 1a02d949
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_cvt_f16_f32 s25, s25                                      ; be996819
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_pack_ll_b32_b16 s25, s25, 0x3c00                          ; 9919ff19 00003c00
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc100044
	v_min_num_f64_e32 v[0:1], v[68:69], v[25:26]                ; 1a003344
(invalid instruction)                                        ; cc100048
	v_min_num_f64_e32 v[0:1], v[72:73], v[25:26]                ; 1a003348
(invalid instruction)                                        ; cc100043
	v_min_num_f64_e32 v[0:1], v[67:68], v[25:26]                ; 1a003343
(invalid instruction)                                        ; cc100049
	v_min_num_f64_e32 v[0:1], v[73:74], v[25:26]                ; 1a003349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c0044
	v_subrev_f32_e32 v0, v68, v20                               ; 0a002944
(invalid instruction)                                        ; cc1c0048
	v_subrev_f32_e32 v0, v72, v20                               ; 0a002948
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v20                               ; 0a002943
(invalid instruction)                                        ; cc1c0049
	v_subrev_f32_e32 v0, v73, v20                               ; 0a002949
(invalid instruction)                                        ; cc1b0044
	v_subrev_f32_e32 v0, v68, v19                               ; 0a002744
(invalid instruction)                                        ; cc10004d
	v_min_num_f64_e32 v[1:2], v[77:78], v[108:109]              ; 1a02d94d
(invalid instruction)                                        ; cc1b0048
	v_subrev_f32_e32 v0, v72, v19                               ; 0a002748
(invalid instruction)                                        ; cc10004e
	v_min_num_f64_e32 v[1:2], v[78:79], v[108:109]              ; 1a02d94e
(invalid instruction)                                        ; cc1b0043
	v_subrev_f32_e32 v0, v67, v19                               ; 0a002743
(invalid instruction)                                        ; cc1b0049
	v_subrev_f32_e32 v0, v73, v19                               ; 0a002749
	v_cvt_f32_f16_e32 v111, v196/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ede17c4
	v_cvt_f32_f16_e32 v68, v68                                  ; 7e881744
(invalid instruction)                                        ; cc10004d
	v_min_num_f64_e32 v[0:1], v[77:78], v[25:26]                ; 1a00334d
	v_cvt_f32_f16_e32 v113, v200/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ee217c8
	v_cvt_f32_f16_e32 v72, v72                                  ; 7e901748
(invalid instruction)                                        ; cc10004e
	v_min_num_f64_e32 v[0:1], v[78:79], v[25:26]                ; 1a00334e
	v_cvt_f32_f16_e32 v109, v195/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eda17c3
	v_cvt_f32_f16_e32 v67, v67                                  ; 7e861743
	v_cvt_f32_f16_e32 v115, v201/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ee617c9
	v_cvt_f32_f16_e32 v73, v73                                  ; 7e921749
(invalid instruction)                                        ; d7690070
	v_cndmask_b32_e32 v1, v68, v111, vcc_lo                     ; 0202df44
(invalid instruction)                                        ; cc1c004d
	v_subrev_f32_e32 v0, v77, v20                               ; 0a00294d
(invalid instruction)                                        ; cc100052
	v_min_num_f64_e32 v[1:2], v[82:83], v[108:109]              ; 1a02d952
(invalid instruction)                                        ; cc100053
	v_min_num_f64_e32 v[1:2], v[83:84], v[108:109]              ; 1a02d953
(invalid instruction)                                        ; d7690072
	v_cndmask_b32_e32 v1, v72, v113, vcc_lo                     ; 0202e348
(invalid instruction)                                        ; cc1c004e
	v_subrev_f32_e32 v0, v78, v20                               ; 0a00294e
(invalid instruction)                                        ; d769006e
	v_cndmask_b32_e32 v1, v67, v109, vcc_lo                     ; 0202db43
(invalid instruction)                                        ; d7690074
	v_cndmask_b32_e32 v1, v73, v115, vcc_lo                     ; 0202e749
(invalid instruction)                                        ; cc1b004d
	v_subrev_f32_e32 v0, v77, v19                               ; 0a00274d
(invalid instruction)                                        ; cc100052
	v_min_num_f64_e32 v[0:1], v[82:83], v[25:26]                ; 1a003352
(invalid instruction)                                        ; cc100053
	v_min_num_f64_e32 v[0:1], v[83:84], v[25:26]                ; 1a003353
(invalid instruction)                                        ; cc1b004e
	v_subrev_f32_e32 v0, v78, v19                               ; 0a00274e
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_cvt_f32_f16_e32 v117, v205/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eea17cd
	v_cvt_f32_f16_e32 v77, v77                                  ; 7e9a174d
	v_perm_b32 v8, v8, v110, 0x7060500                          ; d6440008 03fedd08 07060500
(invalid instruction)                                        ; cc1c0052
	v_subrev_f32_e32 v0, v82, v20                               ; 0a002952
(invalid instruction)                                        ; cc1c0053
	v_subrev_f32_e32 v0, v83, v20                               ; 0a002953
	v_cvt_f32_f16_e32 v119, v206/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eee17ce
	v_cvt_f32_f16_e32 v78, v78                                  ; 7e9c174e
(invalid instruction)                                        ; d7690076
	v_cndmask_b32_e32 v1, v77, v117, vcc_lo                     ; 0202eb4d
	v_perm_b32 v8, v8, v114, 0x7060004                          ; d6440008 03fee508 07060004
	v_perm_b32 v114, v114, v110, 0x7060501                      ; d6440072 03fedd72 07060501
	v_perm_b32 v14, v14, v112, 0x7060500                        ; d644000e 03fee10e 07060500
(invalid instruction)                                        ; cc1b0052
	v_subrev_f32_e32 v0, v82, v19                               ; 0a002752
(invalid instruction)                                        ; cc1b0053
	v_subrev_f32_e32 v0, v83, v19                               ; 0a002753
(invalid instruction)                                        ; d7690078
	v_cndmask_b32_e32 v1, v78, v119, vcc_lo                     ; 0202ef4e
	v_perm_b32 v8, v8, v118, 0x7000504                          ; d6440008 03feed08 07000504
	v_perm_b32 v114, v114, v118, 0x7010504                      ; d6440072 03feed72 07010504
(invalid instruction)                                        ; cc100057
	v_min_num_f64_e32 v[1:2], v[87:88], v[108:109]              ; 1a02d957
	v_perm_b32 v14, v14, v116, 0x7060004                        ; d644000e 03fee90e 07060004
	v_perm_b32 v116, v116, v112, 0x7060501                      ; d6440074 03fee174 07060501
(invalid instruction)                                        ; cc100058
	v_min_num_f64_e32 v[1:2], v[88:89], v[108:109]              ; 1a02d958
	v_cvt_f32_f16_e32 v121, v210/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ef217d2
	v_cvt_f32_f16_e32 v82, v82                                  ; 7ea41752
	v_cvt_f32_f16_e32 v123, v211/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ef617d3
	v_cvt_f32_f16_e32 v83, v83                                  ; 7ea61753
(invalid instruction)                                        ; cc100057
	v_min_num_f64_e32 v[0:1], v[87:88], v[25:26]                ; 1a003357
	v_perm_b32 v14, v14, v120, 0x7000504                        ; d644000e 03fef10e 07000504
	v_perm_b32 v116, v116, v120, 0x7010504                      ; d6440074 03fef174 07010504
(invalid instruction)                                        ; cc100058
	v_min_num_f64_e32 v[0:1], v[88:89], v[25:26]                ; 1a003358
(invalid instruction)                                        ; d769007a
	v_cndmask_b32_e32 v1, v82, v121, vcc_lo                     ; 0202f352
(invalid instruction)                                        ; d769007c
	v_cndmask_b32_e32 v1, v83, v123, vcc_lo                     ; 0202f753
(invalid instruction)                                        ; cc10005c
	v_min_num_f64_e32 v[1:2], v[92:93], v[108:109]              ; 1a02d95c
(invalid instruction)                                        ; cc1c0057
	v_subrev_f32_e32 v0, v87, v20                               ; 0a002957
(invalid instruction)                                        ; cc10005d
	v_min_num_f64_e32 v[1:2], v[93:94], v[108:109]              ; 1a02d95d
(invalid instruction)                                        ; cc1c0058
	v_subrev_f32_e32 v0, v88, v20                               ; 0a002958
	v_perm_b32 v114, v114, v122, 0x1060504                      ; d6440072 03fef572 01060504
	v_perm_b32 v8, v8, v122, 0x60504                            ; d6440008 03fef508 00060504
	v_perm_b32 v116, v116, v124, 0x1060504                      ; d6440074 03fef974 01060504
	v_perm_b32 v14, v14, v124, 0x60504                          ; d644000e 03fef90e 00060504
(invalid instruction)                                        ; cc10005c
	v_min_num_f64_e32 v[0:1], v[92:93], v[25:26]                ; 1a00335c
(invalid instruction)                                        ; cc1b0057
	v_subrev_f32_e32 v0, v87, v19                               ; 0a002757
(invalid instruction)                                        ; cc10005d
	v_min_num_f64_e32 v[0:1], v[93:94], v[25:26]                ; 1a00335d
(invalid instruction)                                        ; cc1b0058
	v_subrev_f32_e32 v0, v88, v19                               ; 0a002758
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1c005c
	v_subrev_f32_e32 v0, v92, v20                               ; 0a00295c
(invalid instruction)                                        ; cc100061
	v_min_num_f64_e32 v[1:2], v[97:98], v[108:109]              ; 1a02d961
	v_cvt_f32_f16_e32 v125, v215/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7efa17d7
	v_cvt_f32_f16_e32 v87, v87                                  ; 7eae1757
(invalid instruction)                                        ; cc100062
	v_min_num_f64_e32 v[1:2], v[98:99], v[108:109]              ; 1a02d962
(invalid instruction)                                        ; cc1c005d
	v_subrev_f32_e32 v0, v93, v20                               ; 0a00295d
	v_cvt_f32_f16_e32 v127, v216/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7efe17d8
	v_cvt_f32_f16_e32 v88, v88                                  ; 7eb01758
(invalid instruction)                                        ; cc1b005c
	v_subrev_f32_e32 v0, v92, v19                               ; 0a00275c
(invalid instruction)                                        ; cc100061
	v_min_num_f64_e32 v[0:1], v[97:98], v[25:26]                ; 1a003361
(invalid instruction)                                        ; d769007e
	v_cndmask_b32_e32 v1, v87, v125, vcc_lo                     ; 0202fb57
(invalid instruction)                                        ; cc100062
	v_min_num_f64_e32 v[0:1], v[98:99], v[25:26]                ; 1a003362
(invalid instruction)                                        ; cc1b005d
	v_subrev_f32_e32 v0, v93, v19                               ; 0a00275d
(invalid instruction)                                        ; d7690080
	v_cndmask_b32_e32 v1, v88, v127, vcc_lo                     ; 0202ff58
	v_cvt_f32_f16_e32 v129, v220/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f0217dc
	v_cvt_f32_f16_e32 v92, v92                                  ; 7eb8175c
(invalid instruction)                                        ; cc100066
	v_min_num_f64_e32 v[1:2], v[102:103], v[108:109]            ; 1a02d966
(invalid instruction)                                        ; cc1c0061
	v_subrev_f32_e32 v0, v97, v20                               ; 0a002961
(invalid instruction)                                        ; cc100067
	v_min_num_f64_e32 v[1:2], v[103:104], v[108:109]            ; 1a02d967
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v20                               ; 0a002962
	v_cvt_f32_f16_e32 v131, v221/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f0617dd
	v_cvt_f32_f16_e32 v93, v93                                  ; 7eba175d
(invalid instruction)                                        ; d7690082
	v_cndmask_b32_e32 v1, v92, v129, vcc_lo                     ; 0203035c
(invalid instruction)                                        ; cc100066
	v_min_num_f64_e32 v[0:1], v[102:103], v[25:26]              ; 1a003366
(invalid instruction)                                        ; cc1b0061
	v_subrev_f32_e32 v0, v97, v19                               ; 0a002761
(invalid instruction)                                        ; cc100067
	v_min_num_f64_e32 v[0:1], v[103:104], v[25:26]              ; 1a003367
(invalid instruction)                                        ; cc1b0062
	v_subrev_f32_e32 v0, v98, v19                               ; 0a002762
(invalid instruction)                                        ; d7690084
	v_cndmask_b32_e32 v1, v93, v131, vcc_lo                     ; 0203075d
(invalid instruction)                                        ; cc1c0066
	v_subrev_f32_e32 v0, v102, v20                              ; 0a002966
	v_cvt_f32_f16_e32 v133, v225/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f0a17e1
	v_cvt_f32_f16_e32 v97, v97                                  ; 7ec21761
	v_perm_b32 v9, v9, v126, 0x7060500                          ; d6440009 03fefd09 07060500
(invalid instruction)                                        ; cc1c0067
	v_subrev_f32_e32 v0, v103, v20                              ; 0a002967
	v_cvt_f32_f16_e32 v135, v226/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f0e17e2
	v_cvt_f32_f16_e32 v98, v98                                  ; 7ec41762
(invalid instruction)                                        ; cc1b0066
	v_subrev_f32_e32 v0, v102, v19                              ; 0a002766
	v_perm_b32 v15, v15, v128, 0x7060500                        ; d644000f 03ff010f 07060500
(invalid instruction)                                        ; d7690086
	v_cndmask_b32_e32 v1, v97, v133, vcc_lo                     ; 02030b61
	v_perm_b32 v9, v9, v130, 0x7060004                          ; d6440009 03ff0509 07060004
	v_perm_b32 v130, v130, v126, 0x7060501                      ; d6440082 03fefd82 07060501
(invalid instruction)                                        ; cc1b0067
	v_subrev_f32_e32 v0, v103, v19                              ; 0a002767
(invalid instruction)                                        ; d7690088
	v_cndmask_b32_e32 v1, v98, v135, vcc_lo                     ; 02030f62
	v_cvt_f32_f16_e32 v137, v230/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f1217e6
	v_cvt_f32_f16_e32 v102, v102                                ; 7ecc1766
	v_perm_b32 v15, v15, v132, 0x7060004                        ; d644000f 03ff090f 07060004
	v_perm_b32 v132, v132, v128, 0x7060501                      ; d6440084 03ff0184 07060501
	v_perm_b32 v9, v9, v134, 0x7000504                          ; d6440009 03ff0d09 07000504
	v_perm_b32 v130, v130, v134, 0x7010504                      ; d6440082 03ff0d82 07010504
	v_cvt_f32_f16_e32 v139, v231/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7f1617e7
	v_cvt_f32_f16_e32 v103, v103                                ; 7ece1767
(invalid instruction)                                        ; d769008a
	v_cndmask_b32_e32 v1, v102, v137, vcc_lo                    ; 02031366
	v_perm_b32 v15, v15, v136, 0x7000504                        ; d644000f 03ff110f 07000504
	v_perm_b32 v132, v132, v136, 0x7010504                      ; d6440084 03ff1184 07010504
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3) ; bf8701b4
(invalid instruction)                                        ; d769008c
	v_cndmask_b32_e32 v1, v103, v139, vcc_lo                    ; 02031767
	v_perm_b32 v130, v130, v138, 0x1060504                      ; d6440082 03ff1582 01060504
	v_perm_b32 v9, v9, v138, 0x60504                            ; d6440009 03ff1509 00060504
	v_perm_b32 v132, v132, v140, 0x1060504                      ; d6440084 03ff1984 01060504
	v_perm_b32 v15, v15, v140, 0x60504                          ; d644000f 03ff190f 00060504
	s_branch BB76                                               ; bfa0000c
BB75:
	v_mov_b32_e32 v8, 0                                         ; 7e100280
	v_mov_b32_e32 v10, 0                                        ; 7e140280
	v_mov_b32_e32 v12, 0                                        ; 7e180280
	v_mov_b32_e32 v14, 0                                        ; 7e1c0280
	v_dual_mov_b32 v114, 0 :: v_dual_mov_b32 v9, 0              ; ca100080 72080080
	v_dual_mov_b32 v116, 0 :: v_dual_mov_b32 v11, 0             ; ca100080 740a0080
	v_dual_mov_b32 v130, 0 :: v_dual_mov_b32 v15, 0             ; ca100080 820e0080
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v59, 0             ; ca100080 843a0080
BB76:
	v_add_nc_u32_e32 v5, 0x1000, v5                             ; 4a0a0aff 00001000
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
	v_mov_b32_e32 v115, v130                                    ; 7ee60382
	v_mov_b32_e32 v117, v132                                    ; 7eea0384
	v_mov_b32_e32 v13, v59                                      ; 7e1a033b
	ds_store_2addr_b64 v6, v[8:9], v[14:15] offset0:72 offset1:74 ; d9384a48 000e0806
	ds_store_2addr_b64 v7, v[114:115], v[116:117] offset0:104 offset1:106 ; d9386a68 00747207
	ds_store_2addr_b64 v5, v[10:11], v[12:13] offset0:66 offset1:194 ; d938c242 000c0a05
	s_branch BB80                                               ; bfa00022
BB77:
(invalid instruction)                                        ; d71f0004
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0                ; ca100080 09080080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a2
	v_and_b32_e32 v5, 15, v4                                    ; 360a088f
	v_lshrrev_b32_e32 v4, 4, v4                                 ; 32080884
	v_lshlrev_b32_e32 v4, 3, v4                                 ; 30080883
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2) ; bf870121
	v_mad_u32_u24 v6, 36, v5, v4                                ; d60b0006 04120aa4
	v_lshl_add_u32 v5, v5, 6, v4                                ; d6460005 04110d05
	v_mad_u32_u24 v6, s12, 0x480, v6                            ; d60b0006 0419fe0c 00000480
	v_add_nc_u32_e32 v5, s13, v5                                ; 4a0a0a0d
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_add_nc_u32_e32 v7, 0x800, v6                              ; 4a0e0cff 00000800
	ds_store_2addr_b64 v6, v[8:9], v[8:9] offset1:2             ; d9380200 00080806
	ds_store_2addr_b64 v7, v[8:9], v[8:9] offset0:32 offset1:34 ; d9382220 00080807
	ds_store_2addr_stride64_b64 v5, v[8:9], v[8:9] offset0:9 offset1:11 ; d93c0b09 00080805
	ds_store_2addr_b64 v6, v[8:9], v[8:9] offset0:72 offset1:74 ; d9384a48 00080806
	ds_store_2addr_b64 v7, v[8:9], v[8:9] offset0:104 offset1:106 ; d9386a68 00080807
	v_add_nc_u32_e32 v5, 0x1000, v5                             ; 4a0a0aff 00001000
	ds_store_2addr_b64 v5, v[8:9], v[8:9] offset0:66 offset1:194 ; d938c242 00080805
BB80:
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	s_barrier_wait 0xffff                                       ; bf94ffff
	s_mov_b32 s19, s14                                          ; be93000e
	s_nop 0                                                     ; bf800000
	(then repeated 1 times)
BB81:
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_cmp_ge_u32 s19, 64                                        ; bf09c013
	s_cbranch_scc1 BB90                                         ; bfa2f1ad
BB83:
	s_mov_b32 s28, s0                                           ; be9c0000
	s_movk_i32 s29, 0x8000                                      ; b01d8000
	s_load_b128 s[32:35], s[28:29], 0x30                        ; f400480e f8000030
	s_lshl_b32 s20, s24, 6                                      ; 84148618
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add3_u32 v4, s20, s19, v3                                 ; d6550004 040c2614
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshl_add_u32 v4, v4, 6, s4                                ; d6460004 00110d04
	v_add_lshl_u32 v4, v4, v1, 2                                ; d6470004 020a0304
	s_wait_kmcnt 0x0                                            ; bfc70000
	s_clause 0x7                                                ; bf850007
	buffer_load_b128 v[8:11], v4, s[32:35], null offen          ; c405c07c 40804008 00000004
	buffer_load_b128 v[12:15], v4, s[32:35], null offen offset:16 ; c405c07c 4080400c 00001004
	buffer_load_b128 v[16:19], v4, s[32:35], null offen offset:64 ; c405c07c 40804010 00004004
	buffer_load_b128 v[20:23], v4, s[32:35], null offen offset:80 ; c405c07c 40804014 00005004
	buffer_load_b128 v[24:27], v4, s[32:35], null offen offset:128 ; c405c07c 40804018 00008004
	buffer_load_b128 v[28:31], v4, s[32:35], null offen offset:144 ; c405c07c 4080401c 00009004
	buffer_load_b128 v[32:35], v4, s[32:35], null offen offset:192 ; c405c07c 40804020 0000c004
	buffer_load_b128 v[4:7], v4, s[32:35], null offen offset:208 ; c405c07c 40804004 0000d004
(invalid instruction)                                        ; d71f0024
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                      ; 020100c1
	s_mul_i32 s25, s19, 36                                      ; 9619a413
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_and_b32_e32 v37, 15, v36                                  ; 364a488f
	v_lshrrev_b32_e32 v36, 4, v36                               ; 32484884
	v_lshlrev_b32_e32 v36, 3, v36                               ; 30484883
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_mad_u32_u24 v38, 36, v37, v36                             ; d60b0026 04924aa4
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_nc_u32_e32 v39, s25, v38                              ; 4a4e4c19
	ds_load_b64 v[40:41], v39                                   ; d9d80000 28000027
	ds_load_b64 v[42:43], v38 offset:2304                       ; d9d80900 2a000026
	ds_load_b64 v[44:45], v38 offset:2880                       ; d9d80b40 2c000026
	ds_load_b64 v[46:47], v38 offset:3456                       ; d9d80d80 2e000026
	ds_load_b64 v[48:49], v38 offset:4032                       ; d9d80fc0 30000026
	ds_load_b64 v[50:51], v39 offset:16                         ; d9d80010 32000027
	ds_load_b64 v[52:53], v38 offset:2320                       ; d9d80910 34000026
	ds_load_b64 v[54:55], v38 offset:2896                       ; d9d80b50 36000026
	ds_load_b64 v[56:57], v38 offset:3472                       ; d9d80d90 38000026
	ds_load_b64 v[38:39], v38 offset:4048                       ; d9d80fd0 26000026
	s_movk_i32 s27, 0x3e47                                      ; b01b3e47
	s_movk_i32 s31, 0x3c20                                      ; b01f3c20
	s_wait_dscnt 0x8                                            ; bfc60008
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[42:43], v[40:41], 0 ; cc464040 1a02512a
	s_wait_dscnt 0x7                                            ; bfc60007
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[44:45], v[40:41], 0 ; cc464048 1a02512c
	s_wait_dscnt 0x6                                            ; bfc60006
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[46:47], v[40:41], 0 ; cc464050 1a02512e
	s_wait_dscnt 0x5                                            ; bfc60005
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[48:49], v[40:41], 0 ; cc464058 1a025130
	v_lshl_add_u32 v40, v37, 6, v36                             ; d6460028 04910d25
	s_wait_dscnt 0x0                                            ; bfc60000
	s_delay_alu instid0(VALU_DEP_2)                             ; bf870002
	v_wmma_f32_16x16x16_fp8_fp8 v[88:95], v[38:39], v[50:51], v[88:95] ; cc464058 1d626526
	ds_load_b64 v[38:39], v40 offset:4608                       ; d9d81200 26000028
	ds_load_b64 v[42:43], v40 offset:4624                       ; d9d81210 2a000028
	ds_load_b64 v[44:45], v40 offset:4640                       ; d9d81220 2c000028
	ds_load_b64 v[46:47], v40 offset:4656                       ; d9d81230 2e000028
	s_mov_b32 s32, 0x7ff88000                                   ; bea000ff 7ff88000
	s_mov_b32 s33, 0xfedcba98                                   ; bea100ff fedcba98
	s_movk_i32 s34, 0x5f00                                      ; b0225f00
	s_movk_i32 s35, 0xdf00                                      ; b023df00
	s_bfe_u32 s36, s19, 0x10004                                 ; 9324ff13 00010004
	v_wmma_f32_16x16x16_fp8_fp8 v[64:71], v[52:53], v[50:51], v[64:71] ; cc464040 1d026534
	v_wmma_f32_16x16x16_fp8_fp8 v[72:79], v[54:55], v[50:51], v[72:79] ; cc464048 1d226536
	v_wmma_f32_16x16x16_fp8_fp8 v[80:87], v[56:57], v[50:51], v[80:87] ; cc464050 1d426538
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s36, s16, s36                                  ; 80242410
	s_lshr_b32 s37, s19, 5                                      ; 85258513
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s18, s37                                  ; 80252512
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s38, s37, s36                                     ; 89262425
	s_cmp_ge_i32 s36, s8                                        ; bf030824
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1) ; bf8704a9
	s_mov_b32 s39, src_scc                                      ; bea700fd
	s_cmp_ge_i32 s37, s9                                        ; bf030925
	s_or_b32 s39, src_scc, s39                                  ; 8c2727fd
	s_cmp_lt_i32 s38, 0                                         ; bf048026
	s_delay_alu instid0(SALU_CYCLE_1)                           ; bf870009
	s_or_b32 s39, src_scc, s39                                  ; 8c2727fd
	s_wait_loadcnt 0x7                                          ; bfc00007
	v_fma_mixlo_f16 v48, 1.0, v66, v10                          ; cc210030 042a84f2
	v_fma_mixhi_f16 v48, 1.0, v67, v11                          ; cc220030 042e86f2
	v_fma_mixlo_f16 v41, 1.0, v64, v8                           ; cc210029 042280f2
	v_fma_mixhi_f16 v41, 1.0, v65, v9                           ; cc220029 042682f2
	s_wait_loadcnt 0x6                                          ; bfc00006
	v_fma_mixlo_f16 v49, 1.0, v68, v12                          ; cc210031 043288f2
	v_fma_mixhi_f16 v49, 1.0, v69, v13                          ; cc220031 04368af2
	v_fma_mixlo_f16 v50, 1.0, v70, v14                          ; cc210032 043a8cf2
	v_fma_mixhi_f16 v50, 1.0, v71, v15                          ; cc220032 043e8ef2
	v_pk_fma_f16 v48, v48, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6030 0bfdff30 3d3429c0
	v_pk_fma_f16 v41, v41, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6029 0bfdff29 3d3429c0
	s_wait_loadcnt 0x5                                          ; bfc00005
	v_fma_mixlo_f16 v51, 1.0, v72, v16                          ; cc210033 044290f2
	v_fma_mixhi_f16 v51, 1.0, v73, v17                          ; cc220033 044692f2
	v_pk_fma_f16 v49, v49, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6031 0bfdff31 3d3429c0
	v_pk_fma_f16 v50, v50, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6032 0bfdff32 3d3429c0
(invalid instruction)                                        ; cc1c0030
	v_subrev_f32_e32 v0, v48, v31                               ; 0a003f30
(invalid instruction)                                        ; cc1c0029
	v_subrev_f32_e32 v0, v41, v31                               ; 0a003f29
	v_pk_fma_f16 v51, v51, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6033 0bfdff33 3d3429c0
	v_fma_mixlo_f16 v54, 1.0, v74, v18                          ; cc210036 044a94f2
(invalid instruction)                                        ; cc1c0031
	v_subrev_f32_e32 v0, v49, v31                               ; 0a003f31
	v_fma_mixhi_f16 v54, 1.0, v75, v19                          ; cc220036 044e96f2
(invalid instruction)                                        ; cc1c0032
	v_subrev_f32_e32 v0, v50, v31                               ; 0a003f32
(invalid instruction)                                        ; cc1b0030
	v_subrev_f32_e32 v0, v48, v27                               ; 0a003730
(invalid instruction)                                        ; cc1b0029
	v_subrev_f32_e32 v0, v41, v27                               ; 0a003729
(invalid instruction)                                        ; cc1c0033
	v_subrev_f32_e32 v0, v51, v31                               ; 0a003f33
(invalid instruction)                                        ; cc1b0031
	v_subrev_f32_e32 v0, v49, v27                               ; 0a003731
	s_wait_loadcnt 0x4                                          ; bfc00004
	v_fma_mixlo_f16 v57, 1.0, v76, v20                          ; cc210039 045298f2
	v_pk_fma_f16 v54, v54, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6036 0bfdff36 3d3429c0
	v_fma_mixhi_f16 v57, 1.0, v77, v21                          ; cc220039 04569af2
(invalid instruction)                                        ; cc1b0032
	v_subrev_f32_e32 v0, v50, v27                               ; 0a003732
	v_lshl_add_u32 v48, v48, 5, s32                             ; d6460030 00810b30
	v_lshl_add_u32 v41, v41, 5, s32                             ; d6460029 00810b29
(invalid instruction)                                        ; cc1b0033
	v_subrev_f32_e32 v0, v51, v27                               ; 0a003733
	v_lshl_add_u32 v49, v49, 5, s32                             ; d6460031 00810b31
(invalid instruction)                                        ; cc1c0036
	v_subrev_f32_e32 v0, v54, v31                               ; 0a003f36
	v_fma_mixlo_f16 v60, 1.0, v78, v22                          ; cc21003c 045a9cf2
	v_pk_fma_f16 v57, v57, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6039 0bfdff39 3d3429c0
	v_fma_mixhi_f16 v60, 1.0, v79, v23                          ; cc22003c 045e9ef2
	v_lshl_add_u32 v50, v50, 5, s32                             ; d6460032 00810b32
	v_lshl_add_u32 v51, v51, 5, s32                             ; d6460033 00810b33
(invalid instruction)                                        ; cc1b0036
	v_subrev_f32_e32 v0, v54, v27                               ; 0a003736
(invalid instruction)                                        ; cc1c0039
	v_subrev_f32_e32 v0, v57, v31                               ; 0a003f39
	v_pk_fma_f16 v60, v60, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603c 0bfdff3c 3d3429c0
	s_wait_loadcnt 0x3                                          ; bfc00003
	v_fma_mixlo_f16 v63, 1.0, v80, v24                          ; cc21003f 0462a0f2
	v_fma_mixhi_f16 v63, 1.0, v81, v25                          ; cc22003f 0466a2f2
	v_fma_mix_f32 v53, 1.0, v41, v51 op_sel:[0,1,1] op_sel_hi:[0,1,1] ; cc207035 14ce52f2
	v_fma_mix_f32 v52, 1.0, v41, v51 op_sel_hi:[0,1,1]          ; cc204034 14ce52f2
	v_lshl_add_u32 v54, v54, 5, s32                             ; d6460036 00810b36
(invalid instruction)                                        ; cc1b0039
	v_subrev_f32_e32 v0, v57, v27                               ; 0a003739
(invalid instruction)                                        ; cc1c003c
	v_subrev_f32_e32 v0, v60, v31                               ; 0a003f3c
	v_pk_fma_f16 v63, v63, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e603f 0bfdff3f 3d3429c0
	v_fma_mixlo_f16 v64, 1.0, v82, v26                          ; cc210040 046aa4f2
	v_fma_mixhi_f16 v64, 1.0, v83, v27                          ; cc220040 046ea6f2
	v_fma_mix_f32 v56, 1.0, v48, v54 op_sel:[0,1,1] op_sel_hi:[0,1,1] ; cc207038 14da60f2
	v_fma_mix_f32 v55, 1.0, v48, v54 op_sel_hi:[0,1,1]          ; cc204037 14da60f2
	v_lshl_add_u32 v57, v57, 5, s32                             ; d6460039 00810b39
(invalid instruction)                                        ; cc1b003c
	v_subrev_f32_e32 v0, v60, v27                               ; 0a00373c
(invalid instruction)                                        ; cc1c003f
	v_subrev_f32_e32 v0, v63, v31                               ; 0a003f3f
	s_wait_loadcnt 0x2                                          ; bfc00002
	v_fma_mixlo_f16 v65, 1.0, v84, v28                          ; cc210041 0472a8f2
	v_pk_fma_f16 v64, v64, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6040 0bfdff40 3d3429c0
	v_fma_mixhi_f16 v65, 1.0, v85, v29                          ; cc220041 0476aaf2
	v_fma_mix_f32 v59, 1.0, v49, v57 op_sel:[0,1,1] op_sel_hi:[0,1,1] ; cc20703b 14e662f2
	v_fma_mix_f32 v58, 1.0, v49, v57 op_sel_hi:[0,1,1]          ; cc20403a 14e662f2
	v_lshl_add_u32 v60, v60, 5, s32                             ; d646003c 00810b3c
(invalid instruction)                                        ; cc1b003f
	v_subrev_f32_e32 v0, v63, v27                               ; 0a00373f
(invalid instruction)                                        ; cc1c0040
	v_subrev_f32_e32 v0, v64, v31                               ; 0a003f40
	v_fma_mixlo_f16 v66, 1.0, v86, v30                          ; cc210042 047aacf2
	v_pk_fma_f16 v65, v65, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6041 0bfdff41 3d3429c0
	v_fma_mixhi_f16 v66, 1.0, v87, v31                          ; cc220042 047eaef2
	v_fma_mix_f32 v61, 1.0, v50, v60 op_sel_hi:[0,1,1]          ; cc20403d 14f264f2
	v_fma_mix_f32 v62, 1.0, v50, v60 op_sel:[0,1,1] op_sel_hi:[0,1,1] ; cc20703e 14f264f2
	v_lshl_add_u32 v63, v63, 5, s32                             ; d646003f 00810b3f
(invalid instruction)                                        ; cc1b0040
	v_subrev_f32_e32 v0, v64, v27                               ; 0a003740
(invalid instruction)                                        ; cc1c0041
	v_subrev_f32_e32 v0, v65, v31                               ; 0a003f41
	s_wait_loadcnt 0x1                                          ; bfc00001
	v_fma_mixlo_f16 v67, 1.0, v88, v32                          ; cc210043 0482b0f2
	v_pk_fma_f16 v66, v66, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6042 0bfdff42 3d3429c0
	v_fma_mixhi_f16 v67, 1.0, v89, v33                          ; cc220043 0486b2f2
	v_fma_mix_f32 v52, 1.0, v63, v52 op_sel_hi:[0,1,0]          ; cc200034 14d27ef2
	v_fma_mix_f32 v53, 1.0, v63, v53 op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201035 14d67ef2
	v_lshl_add_u32 v64, v64, 5, s32                             ; d6460040 00810b40
(invalid instruction)                                        ; cc1b0041
	v_subrev_f32_e32 v0, v65, v27                               ; 0a003741
(invalid instruction)                                        ; cc1c0042
	v_subrev_f32_e32 v0, v66, v31                               ; 0a003f42
	v_fma_mixlo_f16 v68, 1.0, v90, v34                          ; cc210044 048ab4f2
	v_pk_fma_f16 v67, v67, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6043 0bfdff43 3d3429c0
	v_fma_mixhi_f16 v68, 1.0, v91, v35                          ; cc220044 048eb6f2
	v_fma_mix_f32 v56, 1.0, v64, v56 op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201038 14e280f2
	v_fma_mix_f32 v55, 1.0, v64, v55 op_sel_hi:[0,1,0]          ; cc200037 14de80f2
	v_lshl_add_u32 v65, v65, 5, s32                             ; d6460041 00810b41
(invalid instruction)                                        ; cc1b0042
	v_subrev_f32_e32 v0, v66, v27                               ; 0a003742
(invalid instruction)                                        ; cc1c0043
	v_subrev_f32_e32 v0, v67, v31                               ; 0a003f43
	v_pk_fma_f16 v68, v68, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6044 0bfdff44 3d3429c0
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v59, 1.0, v65, v59 op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20103b 14ee82f2
	v_fma_mix_f32 v58, 1.0, v65, v58 op_sel_hi:[0,1,0]          ; cc20003a 14ea82f2
	s_wait_loadcnt 0x0                                          ; bfc00000
	v_fma_mixlo_f16 v69, 1.0, v92, v4                           ; cc210045 0412b8f2
	v_lshl_add_u32 v66, v66, 5, s32                             ; d6460042 00810b42
(invalid instruction)                                        ; cc1b0043
	v_subrev_f32_e32 v0, v67, v27                               ; 0a003743
	v_fma_mixhi_f16 v69, 1.0, v93, v5                           ; cc220045 0416baf2
(invalid instruction)                                        ; cc1c0044
	v_subrev_f32_e32 v0, v68, v31                               ; 0a003f44
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
	v_fma_mix_f32 v62, 1.0, v66, v62 op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20103e 14fa84f2
	v_fma_mix_f32 v61, 1.0, v66, v61 op_sel_hi:[0,1,0]          ; cc20003d 14f684f2
	v_lshl_add_u32 v67, v67, 5, s32                             ; d6460043 00810b43
	v_pk_fma_f16 v69, v69, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6045 0bfdff45 3d3429c0
	v_fma_mixlo_f16 v70, 1.0, v94, v6                           ; cc210046 041abcf2
(invalid instruction)                                        ; cc1b0044
	v_subrev_f32_e32 v0, v68, v27                               ; 0a003744
	v_fma_mixhi_f16 v70, 1.0, v95, v7                           ; cc220046 041ebef2
	v_fma_mix_f32 v52, 1.0, v67, v52 op_sel_hi:[0,1,0]          ; cc200034 14d286f2
	v_fma_mix_f32 v53, 1.0, v67, v53 op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201035 14d686f2
(invalid instruction)                                        ; cc1c0045
	v_subrev_f32_e32 v0, v69, v31                               ; 0a003f45
	v_lshl_add_u32 v68, v68, 5, s32                             ; d6460044 00810b44
	v_pk_fma_f16 v70, v70, 0x3d3429c0, 0x3d3429c0 op_sel:[0,0,1] op_sel_hi:[1,0,1] ; cc0e6046 0bfdff46 3d3429c0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870243
(invalid instruction)                                        ; cc1b0045
	v_subrev_f32_e32 v0, v69, v27                               ; 0a003745
	v_fma_mix_f32 v56, 1.0, v68, v56 op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc201038 14e288f2
	v_fma_mix_f32 v55, 1.0, v68, v55 op_sel_hi:[0,1,0]          ; cc200037 14de88f2
(invalid instruction)                                        ; cc1c0046
	v_subrev_f32_e32 v0, v70, v31                               ; 0a003f46
	v_lshl_add_u32 v69, v69, 5, s32                             ; d6460045 00810b45
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3) ; bf8701a3
	v_dual_add_f32 v55, v55, v56 :: v_dual_add_f32 v52, v52, v53 ; c9087137 37346b34
(invalid instruction)                                        ; cc1b0046
	v_subrev_f32_e32 v0, v70, v27                               ; 0a003746
	v_fma_mix_f32 v59, 1.0, v69, v59 op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20103b 14ee8af2
	v_fma_mix_f32 v58, 1.0, v69, v58 op_sel_hi:[0,1,0]          ; cc20003a 14ea8af2
	v_add_f32_e32 v52, v52, v55                                 ; 06686f34
	v_lshl_add_u32 v70, v70, 5, s32                             ; d6460046 00810b46
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_fma_mix_f32 v61, 1.0, v70, v61 op_sel_hi:[0,1,0]          ; cc20003d 14f68cf2
	v_fma_mix_f32 v62, 1.0, v70, v62 op_sel:[0,1,0] op_sel_hi:[0,1,0] ; cc20103e 14fa8cf2
	v_dual_add_f32 v61, v61, v62 :: v_dual_add_f32 v58, v58, v59 ; c9087d3d 3d3a773a
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_add_f32_e32 v58, v58, v61                                 ; 06747b3a
	v_add_f32_e32 v52, v52, v58                                 ; 06687534
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_permlanex16_b32 v71, v52, 0x76543210, s33 op_sel:[1,1]    ; d65c1847 0085ff34 76543210
	v_add_f32_e32 v52, v52, v71                                 ; 06688f34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_max_num_f32_e32 v52, 0x38800000, v52                      ; 2c6868ff 38800000
	v_rcp_f32_e32 v52, v52                                      ; 7e685534
	s_delay_alu instid0(TRANS32_DEP_1)                          ; bf870005
	v_fma_mix_f32 v74, v48, v52, neg(0) op_sel_hi:[1,0,0]       ; cc20004a 8a026930
	v_fma_mix_f32 v77, v50, v52, neg(0) op_sel_hi:[1,0,0]       ; cc20004d 8a026932
	v_fma_mix_f32 v48, v48, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200830 8a026930
	v_fma_mix_f32 v72, v41, v52, neg(0) op_sel_hi:[1,0,0]       ; cc200048 8a026929
	v_fma_mix_f32 v41, v41, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200829 8a026929
	v_fma_mix_f32 v76, v49, v52, neg(0) op_sel_hi:[1,0,0]       ; cc20004c 8a026931
	v_fma_mix_f32 v50, v50, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200832 8a026932
	v_fma_mix_f32 v49, v49, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200831 8a026931
(invalid instruction)                                        ; d7694006
	v_cndmask_b32_e32 v0, v74, v128, vcc_lo                     ; 0201014a
(invalid instruction)                                        ; d7694007
	v_cndmask_b32_e32 v0, v77, v128, vcc_lo                     ; 0201014d
	v_fma_mix_f32 v78, v51, v52, neg(0) op_sel_hi:[1,0,0]       ; cc20004e 8a026933
(invalid instruction)                                        ; d769004b
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                     ; 02010130
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v0, v72, v128, vcc_lo                     ; 02010148
	v_fma_mix_f32 v51, v51, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200833 8a026933
(invalid instruction)                                        ; d7690049
	v_cndmask_b32_e32 v0, v41, v128, vcc_lo                     ; 02010129
	v_fma_mix_f32 v80, v54, v52, neg(0) op_sel_hi:[1,0,0]       ; cc200050 8a026936
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v0, v76, v128, vcc_lo                     ; 0201014c
(invalid instruction)                                        ; d769004c
	v_cndmask_b32_e32 v0, v50, v128, vcc_lo                     ; 02010132
	v_fma_mix_f32 v54, v54, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200836 8a026936
(invalid instruction)                                        ; d769004a
	v_cndmask_b32_e32 v0, v49, v128, vcc_lo                     ; 02010131
	v_fma_mix_f32 v82, v57, v52, neg(0) op_sel_hi:[1,0,0]       ; cc200052 8a026939
	v_fma_mix_f32 v57, v57, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200839 8a026939
	v_fma_mix_f32 v83, v60, v52, neg(0) op_sel_hi:[1,0,0]       ; cc200053 8a02693c
(invalid instruction)                                        ; d769004f
	v_cndmask_b32_e32 v0, v51, v128, vcc_lo                     ; 02010133
	v_perm_b32 v4, v4, v73, 0x7060004                           ; d6440004 03fe9304 07060004
	v_fma_mix_f32 v60, v60, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083c 8a02693c
(invalid instruction)                                        ; d7694008
	v_cndmask_b32_e32 v0, v80, v128, vcc_lo                     ; 02010150
(invalid instruction)                                        ; d7690051
	v_cndmask_b32_e32 v0, v54, v128, vcc_lo                     ; 02010136
	v_perm_b32 v5, v5, v74, 0x7060004                           ; d6440005 03fe9505 07060004
(invalid instruction)                                        ; d7690050
	v_cndmask_b32_e32 v0, v57, v128, vcc_lo                     ; 02010139
(invalid instruction)                                        ; d7694009
	v_cndmask_b32_e32 v0, v83, v128, vcc_lo                     ; 02010153
	v_fma_mix_f32 v84, v63, v52, neg(0) op_sel_hi:[1,0,0]       ; cc200054 8a02693f
	v_perm_b32 v4, v4, v6, 0x7020504                            ; d6440004 03fe0d04 07020504
(invalid instruction)                                        ; d7690006
	v_cndmask_b32_e32 v0, v78, v128, vcc_lo                     ; 0201014e
	v_fma_mix_f32 v63, v63, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc20083f 8a02693f
	v_fma_mix_f32 v86, v64, v52, neg(0) op_sel_hi:[1,0,0]       ; cc200056 8a026940
	v_perm_b32 v5, v5, v7, 0x7020504                            ; d6440005 03fe0f05 07020504
(invalid instruction)                                        ; d7690007
	v_cndmask_b32_e32 v0, v82, v128, vcc_lo                     ; 02010152
(invalid instruction)                                        ; d7690052
	v_cndmask_b32_e32 v0, v60, v128, vcc_lo                     ; 0201013c
	v_fma_mix_f32 v64, v64, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200840 8a026940
	v_fma_mix_f32 v88, v65, v52, neg(0) op_sel_hi:[1,0,0]       ; cc200058 8a026941
	v_perm_b32 v4, v4, v75, 0x60504                             ; d6440004 03fe9704 00060504
	v_perm_b32 v6, v6, v79, 0x7060004                           ; d6440006 03fe9f06 07060004
	v_fma_mix_f32 v65, v65, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200841 8a026941
(invalid instruction)                                        ; d7690055
	v_cndmask_b32_e32 v0, v63, v128, vcc_lo                     ; 0201013f
	v_fma_mix_f32 v89, v66, v52, neg(0) op_sel_hi:[1,0,0]       ; cc200059 8a026942
(invalid instruction)                                        ; d769400a
	v_cndmask_b32_e32 v0, v86, v128, vcc_lo                     ; 02010156
	v_perm_b32 v5, v5, v76, 0x60504                             ; d6440005 03fe9905 00060504
	v_perm_b32 v7, v7, v80, 0x7060004                           ; d6440007 03fea107 07060004
	v_fma_mix_f32 v66, v66, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200842 8a026942
(invalid instruction)                                        ; d7690057
	v_cndmask_b32_e32 v0, v64, v128, vcc_lo                     ; 02010140
	v_perm_b32 v6, v6, v8, 0x7020504                            ; d6440006 03fe1106 07020504
(invalid instruction)                                        ; d7690008
	v_cndmask_b32_e32 v0, v84, v128, vcc_lo                     ; 02010154
(invalid instruction)                                        ; d7690056
	v_cndmask_b32_e32 v0, v65, v128, vcc_lo                     ; 02010141
	v_fma_mix_f32 v90, v67, v52, neg(0) op_sel_hi:[1,0,0]       ; cc20005a 8a026943
(invalid instruction)                                        ; d769400b
	v_cndmask_b32_e32 v0, v89, v128, vcc_lo                     ; 02010159
	v_fma_mix_f32 v67, v67, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200843 8a026943
	v_perm_b32 v7, v7, v9, 0x7020504                            ; d6440007 03fe1307 07020504
(invalid instruction)                                        ; d7690009
	v_cndmask_b32_e32 v0, v88, v128, vcc_lo                     ; 02010158
	v_fma_mix_f32 v92, v68, v52, neg(0) op_sel_hi:[1,0,0]       ; cc20005c 8a026944
(invalid instruction)                                        ; d7690058
	v_cndmask_b32_e32 v0, v66, v128, vcc_lo                     ; 02010142
	v_perm_b32 v6, v6, v81, 0x60504                             ; d6440006 03fea306 00060504
	v_fma_mix_f32 v68, v68, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200844 8a026944
	v_perm_b32 v8, v8, v85, 0x7060004                           ; d6440008 03feab08 07060004
	v_fma_mix_f32 v94, v69, v52, neg(0) op_sel_hi:[1,0,0]       ; cc20005e 8a026945
	v_fma_mix_f32 v69, v69, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200845 8a026945
(invalid instruction)                                        ; d769005b
	v_cndmask_b32_e32 v0, v67, v128, vcc_lo                     ; 02010143
	v_perm_b32 v7, v7, v82, 0x60504                             ; d6440007 03fea507 00060504
	v_fma_mix_f32 v95, v70, v52, neg(0) op_sel_hi:[1,0,0]       ; cc20005f 8a026946
	v_perm_b32 v9, v9, v86, 0x7060004                           ; d6440009 03fead09 07060004
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v0, v92, v128, vcc_lo                     ; 0201015c
	v_fma_mix_f32 v70, v70, v52, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0] ; cc200846 8a026946
(invalid instruction)                                        ; d769005d
	v_cndmask_b32_e32 v0, v68, v128, vcc_lo                     ; 02010144
	v_perm_b32 v8, v8, v10, 0x7020504                           ; d6440008 03fe1508 07020504
(invalid instruction)                                        ; d769000a
	v_cndmask_b32_e32 v0, v90, v128, vcc_lo                     ; 0201015a
(invalid instruction)                                        ; d769005c
	v_cndmask_b32_e32 v0, v69, v128, vcc_lo                     ; 02010145
	s_wait_dscnt 0x3                                            ; bfc60003
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[38:39], v[4:5], 0   ; cc464010 1a020926
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v0, v95, v128, vcc_lo                     ; 0201015f
	v_perm_b32 v9, v9, v11, 0x7020504                           ; d6440009 03fe1709 07020504
(invalid instruction)                                        ; d769000b
	v_cndmask_b32_e32 v0, v94, v128, vcc_lo                     ; 0201015e
(invalid instruction)                                        ; d769005e
	v_cndmask_b32_e32 v0, v70, v128, vcc_lo                     ; 02010146
	v_perm_b32 v8, v8, v87, 0x60504                             ; d6440008 03feaf08 00060504
	v_perm_b32 v10, v10, v91, 0x7060004                         ; d644000a 03feb70a 07060004
	v_perm_b32 v9, v9, v88, 0x60504                             ; d6440009 03feb109 00060504
	v_perm_b32 v11, v11, v92, 0x7060004                         ; d644000b 03feb90b 07060004
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2) ; bf870153
	v_perm_b32 v10, v10, v12, 0x7020504                         ; d644000a 03fe190a 07020504
	s_wait_dscnt 0x2                                            ; bfc60002
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[42:43], v[6:7], v[16:23] ; cc464010 1c420d2a
	v_perm_b32 v11, v11, v13, 0x7020504                         ; d644000b 03fe1b0b 07020504
	v_perm_b32 v10, v10, v93, 0x60504                           ; d644000a 03febb0a 00060504
	v_perm_b32 v11, v11, v94, 0x60504                           ; d644000b 03febd0b 00060504
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[44:45], v[8:9], v[16:23] ; cc464010 1c42112c
	s_wait_dscnt 0x0                                            ; bfc60000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[46:47], v[10:11], v[16:23] ; cc464010 1c42152e
	v_cvt_f16_f32_e32 v98, v18                                  ; 7ec41512
	v_cvt_f16_f32_e32 v100, v20                                 ; 7ec81514
	v_cvt_f16_f32_e32 v96, v16                                  ; 7ec01510
(invalid instruction)                                        ; 7fc81515
(invalid instruction)                                        ; 7fc01511
(invalid instruction)                                        ; 7fc41513
	v_cvt_f16_f32_e32 v102, v22                                 ; 7ecc1516
(invalid instruction)                                        ; 7fcc1517
(invalid instruction)                                        ; cc1c0064
	v_subrev_f32_e32 v0, v100, v35                              ; 0a004764
(invalid instruction)                                        ; cc1c0060
	v_subrev_f32_e32 v0, v96, v35                               ; 0a004760
(invalid instruction)                                        ; cc1c0062
	v_subrev_f32_e32 v0, v98, v35                               ; 0a004762
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4) ; bf870244
(invalid instruction)                                        ; cc1c0066
	v_subrev_f32_e32 v0, v102, v35                              ; 0a004766
(invalid instruction)                                        ; cc1b0064
	v_subrev_f32_e32 v0, v100, v34                              ; 0a004564
(invalid instruction)                                        ; cc1b0060
	v_subrev_f32_e32 v0, v96, v34                               ; 0a004560
(invalid instruction)                                        ; cc1b0062
	v_subrev_f32_e32 v0, v98, v34                               ; 0a004562
(invalid instruction)                                        ; cc1b0066
	v_subrev_f32_e32 v0, v102, v34                              ; 0a004566
	v_cvt_f32_f16_e32 v101, v228/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7eca17e4
	v_cvt_f32_f16_e32 v100, v100                                ; 7ec81764
	v_cvt_f32_f16_e32 v97, v224/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ec217e0
	v_cvt_f32_f16_e32 v96, v96                                  ; 7ec01760
	v_cvt_f32_f16_e32 v99, v226/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ec617e2
	v_cvt_f32_f16_e32 v98, v98                                  ; 7ec41762
	v_cvt_f32_f16_e32 v103, v230/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7ece17e6
	v_cvt_f32_f16_e32 v102, v102                                ; 7ecc1766
(invalid instruction)                                        ; d769000d
	v_cndmask_b32_e32 v1, v100, v101, vcc_lo                    ; 0202cb64
(invalid instruction)                                        ; d769000c
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                      ; 0202c360
(invalid instruction)                                        ; d769400c
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                      ; 0202c762
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; d769400d
	v_cndmask_b32_e32 v1, v102, v103, vcc_lo                    ; 0202cf66
	s_cbranch_scc1 BB85                                         ; bfa20021
BB84:
	s_load_b128 s[32:35], s[28:29], 0x0                         ; f400480e f8000000
	s_mov_b32 s20, src_scc                                      ; be9400fd
	s_max_i32 s25, s36, 0                                       ; 8a198024
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s25, s25, s22                                     ; 89191619
	s_max_i32 s27, s37, 0                                       ; 8a1b8025
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s27, s27, s23                                     ; 891b171b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s27, s27, s8                                      ; 961b081b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s27, s27, s25                                  ; 801b191b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s27, s27, s26                                     ; 961b1a1b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s27, s27, 8                                      ; 841b881b
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s27, s2, s27                                   ; 801b1b02
	s_lshl_b32 s31, s24, 9                                      ; 841f8918
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s27, s27, s31                                  ; 801b1f1b
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v14, v37, 4, s27                             ; d646000e 006d0925
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v14, v14, v36                              ; 4a1c490e
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b64 v[12:13], v14, s[32:35], null offen        ; c406c07c 4080400c 0000000e
	s_branch BB86                                               ; bfa00001
BB85:
	s_mov_b32 s20, src_scc                                      ; be9400fd
BB86:
	ds_load_b64 v[12:13], v40 offset:5632                       ; d9d81600 0c000028
	ds_load_b64 v[14:15], v40 offset:5648                       ; d9d81610 0e000028
	ds_load_b64 v[16:17], v40 offset:5664                       ; d9d81620 10000028
	ds_load_b64 v[18:19], v40 offset:5680                       ; d9d81630 12000028
	s_movk_i32 s25, 0xdf00                                      ; b019df00
	s_movk_i32 s27, 0x5f00                                      ; b01b5f00
	s_wait_dscnt 0x3                                            ; bfc60003
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[12:13], v[4:5], 0   ; cc464018 1a02090c
	s_wait_dscnt 0x2                                            ; bfc60002
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1) ; bf8700a1
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[14:15], v[6:7], v[24:31] ; cc464018 1c620d0e
	s_wait_dscnt 0x1                                            ; bfc60001
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[16:17], v[8:9], v[24:31] ; cc464018 1c621110
	s_wait_dscnt 0x0                                            ; bfc60000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[18:19], v[10:11], v[24:31] ; cc464018 1c621512
	v_cvt_f16_f32_e32 v6, v26                                   ; 7e0c151a
(invalid instruction)                                        ; 7f0c151b
	v_cvt_f16_f32_e32 v8, v28                                   ; 7e10151c
(invalid instruction)                                        ; 7f10151d
	v_cvt_f16_f32_e32 v4, v24                                   ; 7e081518
(invalid instruction)                                        ; 7f081519
	v_cvt_f16_f32_e32 v10, v30                                  ; 7e14151e
	s_wait_alu 0xfffe                                           ; bf88fffe
(invalid instruction)                                        ; cc1c0006
	v_subrev_f32_e32 v0, v6, v25                                ; 0a003306
(invalid instruction)                                        ; 7f14151f
(invalid instruction)                                        ; cc1c0008
	v_subrev_f32_e32 v0, v8, v25                                ; 0a003308
(invalid instruction)                                        ; cc1c0004
	v_subrev_f32_e32 v0, v4, v25                                ; 0a003304
	s_delay_alu instid0(VALU_DEP_4)                             ; bf870004
(invalid instruction)                                        ; cc1b0006
	v_subrev_f32_e32 v0, v6, v27                                ; 0a003706
(invalid instruction)                                        ; cc1c000a
	v_subrev_f32_e32 v0, v10, v25                               ; 0a00330a
(invalid instruction)                                        ; cc1b0008
	v_subrev_f32_e32 v0, v8, v27                                ; 0a003708
	s_cmp_lg_i32 s20, 0                                         ; bf018014
(invalid instruction)                                        ; cc1b0004
	v_subrev_f32_e32 v0, v4, v27                                ; 0a003704
	v_cvt_f32_f16_e32 v7, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0e1786
	v_cvt_f32_f16_e32 v6, v6                                    ; 7e0c1706
(invalid instruction)                                        ; cc1b000a
	v_subrev_f32_e32 v0, v10, v27                               ; 0a00370a
	v_cvt_f32_f16_e32 v9, v136/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e121788
	v_cvt_f32_f16_e32 v8, v8                                    ; 7e101708
	v_cvt_f32_f16_e32 v5, v132/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e0a1784
	v_cvt_f32_f16_e32 v4, v4                                    ; 7e081704
	v_cvt_f32_f16_e32 v11, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/ ; 7e16178a
	v_cvt_f32_f16_e32 v10, v10                                  ; 7e14170a
	s_delay_alu instid0(VALU_DEP_3)                             ; bf870003
(invalid instruction)                                        ; d7690004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                        ; 02020b04
(invalid instruction)                                        ; d7694004
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                        ; 02020f06
(invalid instruction)                                        ; d7690005
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                        ; 02021308
(invalid instruction)                                        ; d7694005
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                      ; 0202170a
	s_cbranch_scc1 BB89                                         ; bfa20021
BB87:
	s_load_b128 s[32:35], s[28:29], 0x0                         ; f400480e f8000000
	s_max_i32 s36, s36, 0                                       ; 8a248024
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s36, s36, s22                                     ; 89241624
	s_max_i32 s37, s37, 0                                       ; 8a258025
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_min_i32 s37, s37, s23                                     ; 89251725
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s37, s37, s8                                      ; 96250825
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s37, s36                                  ; 80252425
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_mul_i32 s37, s37, s26                                     ; 96251a25
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_lshl_b32 s37, s37, 8                                      ; 84258825
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s2, s37                                   ; 80252502
	s_lshl_b32 s20, s24, 9                                      ; 84148918
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_addk_co_i32 s20, 0x100                                    ; b7940100
	s_wait_alu 0xfffe                                           ; bf88fffe
	s_add_co_u32 s37, s37, s20                                  ; 80251425
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_lshl_add_u32 v37, v37, 4, s37                             ; d6460025 00950925
	s_delay_alu instid0(VALU_DEP_1)                             ; bf870001
	v_add_nc_u32_e32 v37, v37, v36                              ; 4a4a4925
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b64 v[4:5], v37, s[32:35], null offen          ; c406c07c 40804004 00000025
BB89:
	s_add_co_u32 s19, s19, 32                                   ; 8013a013
	s_branch BB81                                               ; bfa0fcd3
BB91:
	s_cmp_lg_i32 s17, -1                                        ; bf01c111
	s_cbranch_scc0 BB100                                        ; bfa10011
BB92:
	s_wait_storecnt 0x0                                         ; bfc10000
	s_barrier_signal -1                                         ; be804ec1
	v_cmpx_eq_i32_e32 0, v0                                     ; 7d840080
	s_barrier_wait 0xffff                                       ; bf94ffff
	s_cbranch_execz BB98                                        ; bfa5000b
BB93:
	s_mov_b32 s2, s0                                            ; be820000
	s_movk_i32 s3, 0x8000                                       ; b0038000
	s_load_b128 s[8:11], s[2:3], 0x0                            ; f4004201 f8000000
	s_add_co_u32 s17, s17, s7                                   ; 80110711
	v_mov_b32_e32 v1, 1                                         ; 7e020281
	s_lshl_b32 s17, s17, 2                                      ; 84118211
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_atomic_add_u32 v1, off, s[8:11], s17                 ; c40d4011 00801001 00000000
BB98:
	s_mov_b32 exec_lo, -1                                       ; befe00c1
BB100:
	s_cmp_eq_i32 s6, 0                                          ; bf008006
	s_cbranch_scc0 BB109                                        ; bfa1002d
BB101:
	s_mul_i32 s1, ttmp9, 0x83                                   ; 9601ff75 00000083
	s_wait_alu 0xfffe                                           ; bf88fffe
	v_add_nc_u32_e32 v0, s1, v0                                 ; 4a000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
(invalid instruction)                                        ; d72d0001
	v_cndmask_b32_e32 v0, v0, v255, vcc_lo                      ; 0201ff00
	s_mul_u64 s[42:43], 43, 42                                  ; aaaaaaab
	v_lshrrev_b32_e32 v1, 9, v1                                 ; 32020289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_mul_u32_u24_e32 v1, 0x300, v1                             ; 160202ff 00000300
	v_sub_nc_u32_e32 v0, v0, v1                                 ; 4c000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1) ; bf8700d1
	v_lshlrev_b32_e32 v2, 2, v0                                 ; 30040082
	ds_store_b32 v2, v0 offset:6656                             ; d8341a00 00000002
	s_wait_alu 0xffe3                                           ; bf88ffe3
	s_barrier_signal -1                                         ; be804ec1
	v_add_nc_u32_e32 v3, 1, v0                                  ; 4a060081
(invalid instruction)                                        ; d72d0003
	v_cndmask_b32_e32 v0, v3, v255, vcc_lo                      ; 0201ff03
	s_mul_u64 s[42:43], 43, 42                                  ; aaaaaaab
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_lshrrev_b32_e32 v3, 9, v3                                 ; 32060689
	v_mul_u32_u24_e32 v3, 0x300, v3                             ; 160606ff 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1) ; bf870091
	v_sub_nc_u32_e32 v0, v0, v3                                 ; 4c000700
	v_lshlrev_b32_e32 v0, 2, v0                                 ; 30000082
	s_barrier_wait 0xffff                                       ; bf94ffff
	ds_load_b32 v0, v0 offset:6660                              ; d8d81a04 00000000
	s_wait_dscnt 0x0                                            ; bfc60000
	v_cmpx_eq_i32_e32 5, v0                                     ; 7d840085
	s_cbranch_execz BB109                                       ; bfa50009
BB102:
	s_movk_i32 s1, 0x8000                                       ; b0018000
	s_load_b128 s[0:3], s[0:1], 0x10                            ; f4004000 f8000010
	v_mov_b32_e32 v0, 0                                         ; 7e000280
	s_wait_storecnt 0x0                                         ; bfc10000
	s_wait_kmcnt 0x0                                            ; bfc70000
	buffer_store_b32 v0, off, s[0:3], null                      ; c406807c 00800000 00000000
BB109:
	s_nop 0                                                     ; bf800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                        ; bfb60003
	s_endpgm                                                    ; bfb00000
MEM_ORDERED = 0
